//line aot_arbace_reflect.ae:1
package aot_arbace_reflect

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_New() *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A { A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_Init(); t := &A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_reflect_A_Init(); tmp4 = A_arbace_reflect_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_reflect_A_Init(); tmp6 = A_arbace_reflect_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_reflect_A_Init(); tmp7 = A_arbace_reflect_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_reflect_A_Init(); tmp9 = A_arbace_reflect_A_const_3; tmp3 = tmp8.Invoke_O__O(tmp9) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp10 != nil { panic(tmp10) }; return tmp3 }
//line :9:1
func A_arbace_reflect_eval659000008_fn__659000009_A_New() *A_arbace_reflect_eval659000008_fn__659000009_A { A_arbace_reflect_eval659000008_fn__659000009_A_Init(); t := &A_arbace_reflect_eval659000008_fn__659000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_reflect_eval659000008_fn__659000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_reflect_eval659000008_fn__659000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_reflect_A_Init(); tmp7 = A_arbace_reflect_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_reflect_A_Init(); tmp9 = A_arbace_reflect_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }










func A_arbace_reflect_eval1938000010_fn__1938000011_A_New() *A_arbace_reflect_eval1938000010_fn__1938000011_A { A_arbace_reflect_eval1938000010_fn__1938000011_A_Init(); t := &A_arbace_reflect_eval1938000010_fn__1938000011_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_reflect_eval1938000010_fn__1938000011_A) Ctor() {}
//line :20:1
func (t *A_arbace_reflect_eval1938000010_fn__1938000011_A) Invoke_O_O__O(self, s__1 any) any {

	var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_39; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_40; return tmp2.Invoke_O_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__1), Lit_90, Lit_88) }
//line :20:1
func A_arbace_reflect_eval1938000014_fn__1938000015_A_New() *A_arbace_reflect_eval1938000014_fn__1938000015_A { A_arbace_reflect_eval1938000014_fn__1938000015_A_Init(); t := &A_arbace_reflect_eval1938000014_fn__1938000015_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_reflect_eval1938000014_fn__1938000015_A) Ctor() {}
//line :20:1
func (t *A_arbace_reflect_eval1938000014_fn__1938000015_A) Invoke_O_O__O(self, c__1 any) any {








	if jrt.NN(jrt.Class_Cast(c__1)).IsArray__Z() {
		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_88); var tmp2 any; var target_3 any = jrt.NN(jrt.Class_Cast(c__1)).GetComponentType__Class().Ref(); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_reflect_TypeReference_A_InstanceOf(target_3); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z(target_3) }; tmp3 = tmp4; if tmp3 { tmp2 = A_arbace_reflect_TypeReference_A_Cast(target_3).Typename__O() } else { var tmp5 *lang.Var; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_41; tmp2 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(target_3) }; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref() } else {
			return jrt.NN(jrt.Class_Cast(c__1)).GetName__String().Ref()
		} }
func A_arbace_reflect_typesym_A_New() *A_arbace_reflect_typesym_A { A_arbace_reflect_typesym_A_Init(); t := &A_arbace_reflect_typesym_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_reflect_typesym_A) Ctor() {}
//line :33:1
func (t *A_arbace_reflect_typesym_A) Invoke_O_O__O(self, t__0 any) any { var G__1938000018__2_ any; var tmp1 *lang.Var;






	A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_42; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_39; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; var target_4 any = t__0; var tmp6 bool; var tmp7 bool; tmp7 = /*line :38:1*/A_arbace_reflect_TypeReference_A_InstanceOf(target_4); if tmp7 { tmp7 = !lang.Compiler_AOT_IsDyn_O__Z(target_4) }; tmp6 = tmp7; if tmp6 { tmp5 = A_arbace_reflect_TypeReference_A_Cast(target_4).Typename__O() } else { var tmp8 *lang.Var; A_arbace_reflect_A_Init(); tmp8 = A_arbace_reflect_A_const_41; tmp5 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(target_4) }; G__1938000018__2_ =

	tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp5, Lit_88, Lit_90)); var tmp9 /*line :37:1*/*lang.Var; A_arbace_reflect_A_Init(); tmp9 = A_arbace_reflect_A_const_37; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(t__0)) {



		var tmp10 *lang.Var; A_arbace_reflect_A_Init(); tmp10 = A_arbace_reflect_A_const_43; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any; A_arbace_reflect_A_Init(); tmp12 = A_arbace_reflect_A_const_44; var tmp13 any = tmp12; var tmp14 any = A_arbace_reflect_typesym_fn__1938000019_A_New_O(t__0); var tmp15 *jrt.Class; A_arbace_reflect_typesym_fn__1938000019_A_Init(); tmp15 = A_arbace_reflect_typesym_fn__1938000019_A_fn_class; return tmp11.Invoke_O_O__O(G__1938000018__2_, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)))) } else {
//line :37:1
			return G__1938000018__2_ } }




func A_arbace_reflect_typesym_fn__1938000019_A_New_O(p0 any) *A_arbace_reflect_typesym_fn__1938000019_A { A_arbace_reflect_typesym_fn__1938000019_A_Init(); t := &A_arbace_reflect_typesym_fn__1938000019_A{}; t.Ctor_O(p0); return t }
//line :42:1
func (t *A_arbace_reflect_typesym_fn__1938000019_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :42:1
func (t *A_arbace_reflect_typesym_fn__1938000019_A) Invoke_O_O__O(self, ___1 any) any { var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_45; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_t) }

func A_arbace_reflect_eval659000020_fn__659000021_A_New() *A_arbace_reflect_eval659000020_fn__659000021_A { A_arbace_reflect_eval659000020_fn__659000021_A_Init(); t := &A_arbace_reflect_eval659000020_fn__659000021_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_A) Ctor() {}
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__659000013__2_ any; var tmp1 any = A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_New(); var tmp2 *jrt.Class; A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_Init(); tmp2 = A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_fn_class; G__659000013__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_New_O(G__659000013__2_); var tmp4 *jrt.Class; A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_Init(); tmp4 = A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :44:1
func A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_New_O(p0 any) *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A { A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_Init(); t := &A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A{}; t.Ctor_O(p0); return t }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) Ctor_O(c__G__659000013 any) { t.F_G__659000013 = c__G__659000013 }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) Invoke_O_O_O__O(self, gf__reflector__659000026__1, gf__typeref__659000027__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__reflector__659000026__1)); if jrt.A2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__reflector__659000026__1, gf__typeref__659000027__2) } else { var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_10; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__reflector__659000026__1, tmp3.Ref(), t.F_G__659000013)).Invoke_O_O__O(gf__reflector__659000026__1, gf__typeref__659000027__2) } }
//line :44:1
func A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_New() *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A { A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_Init(); t := &A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) Ctor() {}
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) Invoke_O_O_O__O(self, gf__reflector__659000022__1, gf__typeref__659000023__2 any) any { var target_1 any = gf__reflector__659000022__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_1 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_1) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_1, Lit_112, jrt.RefArrayOf(jrt.Object_class, gf__typeref__659000023__2)) } else { return A_arbace_reflect_Reflector_A_Cast(target_1).Do_reflect_O__O(gf__typeref__659000023__2) } }
//line :44:1
func A_arbace_reflect_resource_name_A_New() *A_arbace_reflect_resource_name_A { A_arbace_reflect_resource_name_A_Init(); t := &A_arbace_reflect_resource_name_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_reflect_resource_name_A) Ctor() {}
//line :44:1
func (t *A_arbace_reflect_resource_name_A) Invoke_O_O__O(self, typeref__0 any) any {





	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_126); var tmp2 *lang.Var; A_arbace_reflect_A_Init(); tmp2 = A_arbace_reflect_A_const_39; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var target_5 any = typeref__0; var tmp5 bool; var tmp6 bool
//line :48:1
	tmp6 = A_arbace_reflect_TypeReference_A_InstanceOf(target_5); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z(target_5) }; tmp5 = tmp6; if tmp5 { tmp4 = A_arbace_reflect_TypeReference_A_Cast(target_5).Typename__O() } else { var tmp7 *lang.Var; A_arbace_reflect_A_Init(); tmp7 = A_arbace_reflect_A_const_41; tmp4 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(target_5)
	}
	return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3.Invoke_O_O_O__O(tmp4, Lit_87, Lit_86), nil)).Ref() }
//line :48:1
func A_arbace_reflect_eval659000044_fn__659000045_A_New() *A_arbace_reflect_eval659000044_fn__659000045_A { A_arbace_reflect_eval659000044_fn__659000045_A_Init(); t := &A_arbace_reflect_eval659000044_fn__659000045_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_A) Ctor() {}
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__659000037__2_ any; var tmp1 any = A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_New(); var tmp2 *jrt.Class; A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_Init(); tmp2 = A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_fn_class; G__659000037__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_New_O(G__659000037__2_); var tmp4 *jrt.Class; A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_Init(); tmp4 = A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :48:1
func A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_New_O(p0 any) *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A { A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_Init(); t := &A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) Ctor_O(c__G__659000037 any) { t.F_G__659000037 = c__G__659000037 }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) Invoke_O_O__O(self, gf__o__659000049__1 any) any { var cache__231000236__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__o__659000049__1)); if jrt.A2g_Truth(f__231000237__auto____3) { return lang.IFn_Cast(f__231000237__auto____3).Invoke_O__O(gf__o__659000049__1) } else { var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_11; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__o__659000049__1, tmp3.Ref(), t.F_G__659000037)).Invoke_O__O(gf__o__659000049__1) } }
//line :48:1
func A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_New() *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A { A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_Init(); t := &A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) Ctor() {}
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) Invoke_O_O__O(self, gf__o__659000046__1 any) any { var target_2 any = gf__o__659000046__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_2 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_2) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_2, Lit_49, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_reflect_TypeReference_A_Cast(target_2).Typename__O() } }



func A_arbace_reflect_access_flag_A_New() *A_arbace_reflect_access_flag_A { A_arbace_reflect_access_flag_A_Init(); t := &A_arbace_reflect_access_flag_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_reflect_access_flag_A) Ctor() {}
//line :52:1
func (t *A_arbace_reflect_access_flag_A) Invoke_O_O__O(self, p__1938000023__0 any) any { var vec__1938000024__2 any = p__1938000023__0; var seq__1938000025__3 any; var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_15; seq__1938000025__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__1938000024__2); var first__1938000026__4 any; var tmp2 *lang.Var; A_arbace_reflect_A_Init(); tmp2 = A_arbace_reflect_A_const_16; first__1938000026__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__1938000025__3); var seq__1938000025__5 any; var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_13; seq__1938000025__5 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__1938000025__3); var name__6 any = first__1938000026__4; var first__1938000026__7 any; var tmp4 *lang.Var; A_arbace_reflect_A_Init(); tmp4 = A_arbace_reflect_A_const_16; first__1938000026__7 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__1938000025__5); var seq__1938000025__8 any; var tmp5 *lang.Var; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_13; seq__1938000025__8 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1938000025__5); var flag__9 any = first__1938000026__7; var contexts__10 any = seq__1938000025__8; var tmp6 *lang.Keyword; A_arbace_reflect_A_Init(); tmp6 = A_arbace_reflect_A_const_46; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Keyword; A_arbace_reflect_A_Init(); tmp8 = A_arbace_reflect_A_const_47; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Keyword; A_arbace_reflect_A_Init(); tmp10 = A_arbace_reflect_A_const_48; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Var; A_arbace_reflect_A_Init(); tmp12 = A_arbace_reflect_A_const_22; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_reflect_A_Init(); tmp14 = A_arbace_reflect_A_const_21; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_reflect_A_Init(); tmp16 = A_arbace_reflect_A_const_49; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, name__6, tmp9, flag__9, tmp11, tmp13.Invoke_O__O(tmp15.Invoke_O_O__O(jrt.NN(tmp16).GetRawRoot__O(), contexts__10)))) }



func A_arbace_reflect_descriptor_class_name_A_New() *A_arbace_reflect_descriptor_class_name_A { A_arbace_reflect_descriptor_class_name_A_Init(); t := &A_arbace_reflect_descriptor_class_name_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_reflect_descriptor_class_name_A) Ctor() {}
//line :56:1
func (t *A_arbace_reflect_descriptor_class_name_A) Invoke_O_O__O(self, d__0 any) any { var G__1938000028__2_ uint16 = jrt.NN(jrt.String_Cast(d__0)).CharAt_I__C(lang.RT_IntCast_J__I(0)); switch


	lang.Util_Hash_O__I(jrt.Character_ValueOf_C__Character(G__1938000028__2_).Ref()) { case 76: var tmp1 any = jrt.Character_ValueOf_C__Character(G__1938000028__2_).Ref(); var tmp2 any; A_arbace_reflect_A_Init(); tmp2 = A_arbace_reflect_A_const_50; if lang.Util_Equiv_O_O__Z(tmp1, tmp2) {

		var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_39; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_54; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_reflect_A_Init(); tmp7 = A_arbace_reflect_A_const_55; var tmp8 any = tmp7; return tmp4.Invoke_O_O_O__O(tmp6.Invoke_O_O_O__O(d__0, tmp8, jrt.Long_ValueOf_J__Long(lang.Numbers_Dec_J__J(int64(lang.RT_Count_O__I(d__0)))).Ref()), Lit_86, Lit_87) }
//line :59:1
	case 91: var tmp9 any = jrt.Character_ValueOf_C__Character(G__1938000028__2_).Ref(); var tmp10 any; A_arbace_reflect_A_Init(); tmp10 = A_arbace_reflect_A_const_51; if lang.Util_Equiv_O_O__Z(tmp9, tmp10) {
		var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_88); var tmp12 *lang.Var; A_arbace_reflect_A_Init(); tmp12 = A_arbace_reflect_A_const_52; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_reflect_A_Init(); tmp14 = A_arbace_reflect_A_const_54; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 any; A_arbace_reflect_A_Init(); tmp16 = A_arbace_reflect_A_const_55; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp11, jrt.RefArrayOf(jrt.Object_class, tmp13.Invoke_O__O(tmp15.Invoke_O_O__O(d__0, tmp16)), nil)).Ref() }
//line :59:1
	default:}; var tmp17 any;


	A_arbace_reflect_A_Init(); tmp17 = A_arbace_reflect_A_const_53; return lang.IFn_Cast(tmp17).Invoke_O__O(d__0) }
//line :58:1
func A_arbace_reflect_type_reflect_A_New() *A_arbace_reflect_type_reflect_A { A_arbace_reflect_type_reflect_A_Init(); t := &A_arbace_reflect_type_reflect_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_reflect_type_reflect_A) Ctor() {}
//line :58:1
func (t *A_arbace_reflect_type_reflect_A) DoInvoke_O_O_O__O(self, typeref__0, options__1 any) any { { var map__659000059__3 any; var tmp1 *lang.Var






































	A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_18; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_25; var tmp6 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, jrt.NN(tmp5).GetRawRoot__O())); var tmp7 *lang.Var; A_arbace_reflect_A_Init(); tmp7 = A_arbace_reflect_A_const_24; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_reflect_A_Init(); tmp9 = A_arbace_reflect_A_const_26; map__659000059__3 = tmp2.Invoke_O_O__O(tmp6, tmp8.Invoke_O_O__O(jrt.NN(tmp9).GetRawRoot__O(), options__1))
//line :58:1
	var map__659000059__4 any





































	if lang.ISeq_InstanceOf(map__659000059__3) { var tmp10 *lang.Var; A_arbace_reflect_A_Init(); tmp10 = A_arbace_reflect_A_const_13; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(map__659000059__3)) { var tmp11 *lang.Var; A_arbace_reflect_A_Init(); tmp11 = A_arbace_reflect_A_const_14; map__659000059__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(map__659000059__3), jrt.Object_class.ArrayClass())).Ref() } else { var tmp12 *lang.Var; A_arbace_reflect_A_Init(); tmp12 = A_arbace_reflect_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(map__659000059__3)) { var tmp13 *lang.Var; A_arbace_reflect_A_Init(); tmp13 = A_arbace_reflect_A_const_16; map__659000059__4 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(map__659000059__3) } else { lang.PersistentArrayMap_Init(); map__659000059__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__659000059__4 = map__659000059__3 }
//line :58:1
	var ancestors__5 any; var tmp14 *lang.Keyword





































	A_arbace_reflect_A_Init(); tmp14 = A_arbace_reflect_A_const_17; ancestors__5 = lang.RT_Get_O_O__O(map__659000059__4, tmp14.Ref())
//line :58:1
	var reflector__6 any; var tmp15 *lang.Keyword





































	A_arbace_reflect_A_Init(); tmp15 = A_arbace_reflect_A_const_18; reflector__6 = lang.RT_Get_O_O__O(map__659000059__4, tmp15.Ref())
//line :58:1
	var refl__7 any; var tmp16 *lang.Var








































	A_arbace_reflect_A_Init(); tmp16 = A_arbace_reflect_A_const_19; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_reflect_A_Init(); tmp18 = A_arbace_reflect_A_const_27; refl__7 = tmp17.Invoke_O_O__O(jrt.NN(tmp18).GetRawRoot__O(), reflector__6)
//line :58:1
	var result__8 any = lang.IFn_Cast(refl__7).Invoke_O__O(typeref__0)











































	if jrt.A2g_Truth(ancestors__5) { var make_ancestor_map__9 any; var tmp19 any = A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_New_O(refl__7); var tmp20 *jrt.Class
		A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_Init(); tmp20 = A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_fn_class; make_ancestor_map__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil)
//line :102:1
		var reflections__10 any; var tmp21 lang.IFn = lang.IFn_Cast(make_ancestor_map__9); var tmp22 *lang.Keyword


		A_arbace_reflect_A_Init(); tmp22 = A_arbace_reflect_A_const_28; reflections__10 = tmp21.Invoke_O__O(jrt.NN(tmp22).Invoke_O__O(result__8))
//line :102:1
	L1: for { var ancestors_visited__11 any; var tmp23 *lang.Var



		A_arbace_reflect_A_Init(); tmp23 = A_arbace_reflect_A_const_22; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_reflect_A_Init(); tmp25 = A_arbace_reflect_A_const_29; ancestors_visited__11 = tmp24.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(reflections__10))
//line :102:1
		var ancestors_to_visit__12 any; var tmp26 *lang.Var




		A_arbace_reflect_A_Init(); tmp26 = A_arbace_reflect_A_const_23; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_reflect_A_Init(); tmp28 = A_arbace_reflect_A_const_22; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_reflect_A_Init(); tmp30 = A_arbace_reflect_A_const_30; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Keyword; A_arbace_reflect_A_Init(); tmp32 = A_arbace_reflect_A_const_28; var tmp33 any = tmp32.Ref(); var tmp34 *lang.Var; A_arbace_reflect_A_Init(); tmp34 = A_arbace_reflect_A_const_31; ancestors_to_visit__12 = tmp27.Invoke_O_O__O(tmp29.Invoke_O__O(tmp31.Invoke_O_O__O(tmp33, lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(reflections__10))), ancestors_visited__11)

		var tmp35 *lang.Var; A_arbace_reflect_A_Init(); tmp35 = A_arbace_reflect_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(ancestors_to_visit__12)) {
			var tmp36 *lang.Var; A_arbace_reflect_A_Init(); tmp36 = A_arbace_reflect_A_const_12; reflections__10 = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O_O__O(reflections__10, lang.IFn_Cast(make_ancestor_map__9).Invoke_O__O(ancestors_to_visit__12)); continue L1 } else {
				var tmp37 *lang.Var; A_arbace_reflect_A_Init(); tmp37 = A_arbace_reflect_A_const_24; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_reflect_A_Init(); tmp39 = A_arbace_reflect_A_const_32; var tmp40 any = jrt.NN(tmp39).GetRawRoot__O(); var tmp41 *lang.Var; A_arbace_reflect_A_Init(); tmp41 = A_arbace_reflect_A_const_33; var tmp42 any = jrt.NN(tmp41).GetRawRoot__O(); var tmp43 *lang.Keyword; A_arbace_reflect_A_Init(); tmp43 = A_arbace_reflect_A_const_17; var tmp44 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43.Ref(), ancestors_visited__11)); var tmp45 *lang.Var; A_arbace_reflect_A_Init(); tmp45 = A_arbace_reflect_A_const_21; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 any = A_arbace_reflect_type_reflect_fn__659000063_A_New(); var tmp48 *jrt.Class; A_arbace_reflect_type_reflect_fn__659000063_A_Init(); tmp48 = A_arbace_reflect_type_reflect_fn__659000063_A_fn_class; var tmp49 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp47, tmp48, nil); var tmp50 *lang.Var; A_arbace_reflect_A_Init(); tmp50 = A_arbace_reflect_A_const_31; return tmp38.Invoke_O_O_O_O_O__O(tmp40, tmp42, result__8, tmp44, tmp46.Invoke_O_O__O(tmp49, lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()).Invoke_O__O(reflections__10))) } } } else {
//line :102:1
					return result__8 } }; /*line :58:1*/panic("a2g: unreachable") }






func A_arbace_reflect_field_descriptor__GT_class_symbol_A_New() *A_arbace_reflect_field_descriptor__GT_class_symbol_A { A_arbace_reflect_field_descriptor__GT_class_symbol_A_Init(); t := &A_arbace_reflect_field_descriptor__GT_class_symbol_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) Ctor() {}
//line :65:1
func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_56; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__0)) { } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_118, nil); var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_57; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_58; panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4.Invoke_O__O(tmp5))).Ref()))) }; var tmp6 /*line :71:1*/*lang.Var; A_arbace_reflect_A_Init(); tmp6 = A_arbace_reflect_A_const_42; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_reflect_A_Init(); tmp8 = A_arbace_reflect_A_const_39; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_reflect_A_Init(); tmp10 = A_arbace_reflect_A_const_52; return tmp7.Invoke_O__O(tmp9.Invoke_O_O_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(d__0), Lit_88, Lit_90)) }

func A_arbace_reflect_internal_name__GT_class_symbol_A_New() *A_arbace_reflect_internal_name__GT_class_symbol_A { A_arbace_reflect_internal_name__GT_class_symbol_A_Init(); t := &A_arbace_reflect_internal_name__GT_class_symbol_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) Ctor() {}
//line :73:1
func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_56; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__0)) { } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_118, nil); var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_57; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_59; panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp4.Invoke_O__O(tmp5))).Ref()))) }; var tmp6 /*line :81:1*/*lang.Var; A_arbace_reflect_A_Init(); tmp6 = A_arbace_reflect_A_const_42; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_reflect_A_Init(); tmp8 = A_arbace_reflect_A_const_39; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; if jrt.NN(jrt.String_Cast(d__0)).StartsWith_String__Z(Lit_120) { var tmp11 *lang.Var; A_arbace_reflect_A_Init(); tmp11 = A_arbace_reflect_A_const_52; tmp10 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(d__0) } else { var tmp12 *lang.Var; A_arbace_reflect_A_Init(); tmp12 = A_arbace_reflect_A_const_39; tmp10 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O_O__O(d__0, Lit_86, Lit_87) }; return tmp7.Invoke_O__O(tmp9.Invoke_O_O_O__O(tmp10, Lit_88, Lit_90)) }





















func A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_New_O(p0 any) *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A { A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_Init(); t := &A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A{}; t.Ctor_O(p0); return t }
//line :103:1
func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) Ctor_O(c__refl any) { t.F_refl = c__refl }
//line :103:1
func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) Invoke_O_O__O(self, names__1 any) any {
	var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_21; return tmp2.Invoke_O_O__O(names__1, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(t.F_refl, names__1))
}




func A_arbace_reflect_parse_flags_A_New() *A_arbace_reflect_parse_flags_A { A_arbace_reflect_parse_flags_A_Init(); t := &A_arbace_reflect_parse_flags_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_reflect_parse_flags_A) Ctor() {}
//line :110:1
func (t *A_arbace_reflect_parse_flags_A) Invoke_O_O_O__O(self, flags__0, context__1 any) any {


	var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_60; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_reflect_parse_flags_fn__1938000032_A_New_O_O(flags__0, context__1); var tmp4 *jrt.Class; A_arbace_reflect_parse_flags_fn__1938000032_A_Init(); tmp4 = A_arbace_reflect_parse_flags_fn__1938000032_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp6 = lang.PersistentHashSet_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_reflect_A_Init(); tmp8 = A_arbace_reflect_A_const_62; return tmp2.Invoke_O_O_O__O(tmp5, tmp7, jrt.NN(tmp8).GetRawRoot__O()) }
//line :112:1
func A_arbace_reflect_type_reflect_fn__659000063_A_New() *A_arbace_reflect_type_reflect_fn__659000063_A { A_arbace_reflect_type_reflect_fn__659000063_A_Init(); t := &A_arbace_reflect_type_reflect_fn__659000063_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_reflect_type_reflect_fn__659000063_A) Ctor() {}
//line :112:1
func (t *A_arbace_reflect_type_reflect_fn__659000063_A) Invoke_O_O__O(self, p1__659000058_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_34; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_35; return tmp2.Invoke_O_O__O(p1__659000058_SHARP___1, tmp3) }

func A_arbace_reflect_parse_flags_fn__1938000032_A_New_O_O(p0, p1 any) *A_arbace_reflect_parse_flags_fn__1938000032_A { A_arbace_reflect_parse_flags_fn__1938000032_A_Init(); t := &A_arbace_reflect_parse_flags_fn__1938000032_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_reflect_parse_flags_fn__1938000032_A) Ctor_O_O(c__flags, c__context any) { t.F_flags = c__flags; t.F_context = c__context }
//line :114:1
func (t *A_arbace_reflect_parse_flags_fn__1938000032_A) Invoke_O_O_O__O(self, result__1, fd__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any; var tmp2 *lang.Keyword; A_arbace_reflect_A_Init(); tmp2 = A_arbace_reflect_A_const_48; and__1927000168__auto____3 = lang.RT_Get_O_O__O(jrt.NN(tmp2).Invoke_O__O(fd__2), t.F_context); if jrt.A2g_Truth(and__1927000168__auto____3) {
		var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_61; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_flags; var tmp6 *lang.Keyword; A_arbace_reflect_A_Init(); tmp6 = A_arbace_reflect_A_const_47; tmp1 = tmp4.Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_O__J(tmp5, jrt.NN(tmp6).Invoke_O__O(fd__2)))).Ref()) } else {
//line :115:1
			tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) {

				var tmp7 *lang.Var; A_arbace_reflect_A_Init(); tmp7 = A_arbace_reflect_A_const_6; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_reflect_A_Init(); tmp9 = A_arbace_reflect_A_const_46; return tmp8.Invoke_O_O__O(result__1, jrt.NN(tmp9).Invoke_O__O(fd__2)) } else {
//line :115:1
					return result__1 } }
//line :115:1
func A_arbace_reflect_reflect_A_New() *A_arbace_reflect_reflect_A { A_arbace_reflect_reflect_A_Init(); t := &A_arbace_reflect_reflect_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_reflect_reflect_A) Ctor() {}
//line :115:1
func (t *A_arbace_reflect_reflect_A) DoInvoke_O_O_O__O(self, obj__0, options__1 any) any {





	var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_24; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_36; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 any; var tmp6 *lang.Var; A_arbace_reflect_A_Init(); tmp6 = A_arbace_reflect_A_const_37; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(obj__0)) { tmp5 = obj__0 } else { var tmp7 *lang.Var; A_arbace_reflect_A_Init(); tmp7 = A_arbace_reflect_A_const_38; tmp5 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(obj__0) }; return tmp2.Invoke_O_O_O__O(tmp4, tmp5, options__1) }
func A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_New() *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A { A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_Init(); t := &A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A) Ctor() {}
//line :122:1
func (t *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A) Invoke_O_O_O_O_O_O__O(self, name__1, declaring_class__2, parameter_types__3, exception_types__4, flags__5 any) any { return A_arbace_reflect_Constructor_A_New_O_O_O_O_O(name__1, declaring_class__2, parameter_types__3, exception_types__4, flags__5) }
//line :122:1
func A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_New() *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A { A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_Init(); t := &A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A) Ctor() {}
//line :122:1
func (t *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A) Invoke_O_O__O(self, m__231000174__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000174__auto____1) { tmp1 = m__231000174__auto____1 } else { var tmp2 *lang.Var; A_arbace_reflect_A_Init(); tmp2 = A_arbace_reflect_A_const_33; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; tmp1 = tmp3.Invoke_O_O__O(tmp4.Ref(), m__231000174__auto____1) }; return A_arbace_reflect_Constructor_A_Create_IPersistentMap__A_arbace_reflect_Constructor_A(lang.IPersistentMap_Cast(tmp1)).Ref() }


func A_arbace_reflect_constructor__GT_map_A_New() *A_arbace_reflect_constructor__GT_map_A { A_arbace_reflect_constructor__GT_map_A_Init(); t := &A_arbace_reflect_constructor__GT_map_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_reflect_constructor__GT_map_A) Ctor() {}
//line :125:1
func (t *A_arbace_reflect_constructor__GT_map_A) Invoke_O_O__O(self, constructor__0 any) any { var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_42; var tmp2 any = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Constructor_Cast(constructor__0)).GetName__String().Ref()); var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_63; var tmp4 any = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Constructor_Cast(constructor__0)).GetDeclaringClass__Class().Ref()); var tmp5 *lang.Var; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_64; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_reflect_A_Init(); tmp7 = A_arbace_reflect_A_const_21; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_reflect_A_Init(); tmp9 = A_arbace_reflect_A_const_63; var tmp10 any = tmp6.Invoke_O__O(tmp8.Invoke_O_O__O(jrt.NN(tmp9).GetRawRoot__O(), jrt.NN(jrt.Constructor_Cast(constructor__0)).GetParameterTypes__Class1().Ref())); var tmp11 *lang.Var; A_arbace_reflect_A_Init(); tmp11 = A_arbace_reflect_A_const_64; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_reflect_A_Init(); tmp13 = A_arbace_reflect_A_const_21; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_reflect_A_Init(); tmp15 = A_arbace_reflect_A_const_63; var tmp16 any = tmp12.Invoke_O__O(tmp14.Invoke_O_O__O(jrt.NN(tmp15).GetRawRoot__O(), jrt.NN(jrt.Constructor_Cast(constructor__0)).GetExceptionTypes__Class1().Ref())); var tmp17 *lang.Var; A_arbace_reflect_A_Init(); tmp17 = A_arbace_reflect_A_const_65; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Constructor_Cast(constructor__0)).GetModifiers__I()).Ref(); var tmp20 *lang.Keyword; A_arbace_reflect_A_Init(); tmp20 = A_arbace_reflect_A_const_66; return A_arbace_reflect_Constructor_A_New_O_O_O_O_O(tmp2, tmp4, tmp10, tmp16, tmp18.Invoke_O_O__O(tmp19, tmp20.Ref())) }








func A_arbace_reflect_declared_constructors_A_New() *A_arbace_reflect_declared_constructors_A { A_arbace_reflect_declared_constructors_A_Init(); t := &A_arbace_reflect_declared_constructors_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_reflect_declared_constructors_A) Ctor() {}
//line :134:1
func (t *A_arbace_reflect_declared_constructors_A) Invoke_O_O__O(self, cls__0 any) any {


	var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_22; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_67; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(jrt.NN(tmp5).GetRawRoot__O(), jrt.NN(jrt.Class_Cast(cls__0)).GetDeclaredConstructors__Constructor1().Ref()))
}


func A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_New() *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A { A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_Init(); t := &A_arbace_reflect_eval1938000060___GT_Method__1938000078_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A) Ctor() {}
//line :141:1
func (t *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A) Invoke_O_O_O_O_O_O_O__O(self, name__1, return_type__2, declaring_class__3, parameter_types__4, exception_types__5, flags__6 any) any { return A_arbace_reflect_Method_A_New_O_O_O_O_O_O(name__1, return_type__2, declaring_class__3, parameter_types__4, exception_types__5, flags__6) }
//line :141:1
func A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_New() *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A { A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_Init(); t := &A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A) Ctor() {}
//line :141:1
func (t *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A) Invoke_O_O__O(self, m__231000174__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000174__auto____1) { tmp1 = m__231000174__auto____1 } else { var tmp2 *lang.Var; A_arbace_reflect_A_Init(); tmp2 = A_arbace_reflect_A_const_33; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; tmp1 = tmp3.Invoke_O_O__O(tmp4.Ref(), m__231000174__auto____1) }; return A_arbace_reflect_Method_A_Create_IPersistentMap__A_arbace_reflect_Method_A(lang.IPersistentMap_Cast(tmp1)).Ref() }


func A_arbace_reflect_method__GT_map_A_New() *A_arbace_reflect_method__GT_map_A { A_arbace_reflect_method__GT_map_A_Init(); t := &A_arbace_reflect_method__GT_map_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_reflect_method__GT_map_A) Ctor() {}
//line :144:1
func (t *A_arbace_reflect_method__GT_map_A) Invoke_O_O__O(self, method__0 any) any { var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_42; var tmp2 any = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(method__0)).GetName__String().Ref()); var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_63; var tmp4 any = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(method__0)).GetReturnType__Class().Ref()); var tmp5 *lang.Var; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_63; var tmp6 any = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(method__0)).GetDeclaringClass__Class().Ref()); var tmp7 *lang.Var; A_arbace_reflect_A_Init(); tmp7 = A_arbace_reflect_A_const_64; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_reflect_A_Init(); tmp9 = A_arbace_reflect_A_const_21; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_reflect_A_Init(); tmp11 = A_arbace_reflect_A_const_63; var tmp12 any = tmp8.Invoke_O__O(tmp10.Invoke_O_O__O(jrt.NN(tmp11).GetRawRoot__O(), jrt.NN(jrt.Method_Cast(method__0)).GetParameterTypes__Class1().Ref())); var tmp13 *lang.Var; A_arbace_reflect_A_Init(); tmp13 = A_arbace_reflect_A_const_64; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_reflect_A_Init(); tmp15 = A_arbace_reflect_A_const_21; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_reflect_A_Init(); tmp17 = A_arbace_reflect_A_const_63; var tmp18 any = tmp14.Invoke_O__O(tmp16.Invoke_O_O__O(jrt.NN(tmp17).GetRawRoot__O(), jrt.NN(jrt.Method_Cast(method__0)).GetExceptionTypes__Class1().Ref())); var tmp19 *lang.Var; A_arbace_reflect_A_Init(); tmp19 = A_arbace_reflect_A_const_65; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Method_Cast(method__0)).GetModifiers__I()).Ref(); var tmp22 *lang.Keyword; A_arbace_reflect_A_Init(); tmp22 = A_arbace_reflect_A_const_66; return A_arbace_reflect_Method_A_New_O_O_O_O_O_O(tmp2, tmp4, tmp6, tmp12, tmp18, tmp20.Invoke_O_O__O(tmp21, tmp22.Ref())) }









func A_arbace_reflect_declared_methods_A_New() *A_arbace_reflect_declared_methods_A { A_arbace_reflect_declared_methods_A_Init(); t := &A_arbace_reflect_declared_methods_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_reflect_declared_methods_A) Ctor() {}
//line :154:1
func (t *A_arbace_reflect_declared_methods_A) Invoke_O_O__O(self, cls__0 any) any {


	var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_22; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_68; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(jrt.NN(tmp5).GetRawRoot__O(), jrt.NN(jrt.Class_Cast(cls__0)).GetDeclaredMethods__Method1().Ref()))
}


func A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_New() *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A { A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_Init(); t := &A_arbace_reflect_eval1938000086___GT_Field__1938000100_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A) Ctor() {}
//line :161:1
func (t *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A) Invoke_O_O_O_O_O__O(self, name__1, type__2, declaring_class__3, flags__4 any) any { return A_arbace_reflect_Field_A_New_O_O_O_O(name__1, type__2, declaring_class__3, flags__4) }
//line :161:1
func A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_New() *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A { A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_Init(); t := &A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A) Ctor() {}
//line :161:1
func (t *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A) Invoke_O_O__O(self, m__231000174__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000174__auto____1) { tmp1 = m__231000174__auto____1 } else { var tmp2 *lang.Var; A_arbace_reflect_A_Init(); tmp2 = A_arbace_reflect_A_const_33; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; tmp1 = tmp3.Invoke_O_O__O(tmp4.Ref(), m__231000174__auto____1) }; return A_arbace_reflect_Field_A_Create_IPersistentMap__A_arbace_reflect_Field_A(lang.IPersistentMap_Cast(tmp1)).Ref() }


func A_arbace_reflect_field__GT_map_A_New() *A_arbace_reflect_field__GT_map_A { A_arbace_reflect_field__GT_map_A_Init(); t := &A_arbace_reflect_field__GT_map_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_reflect_field__GT_map_A) Ctor() {}
//line :164:1
func (t *A_arbace_reflect_field__GT_map_A) Invoke_O_O__O(self, field__0 any) any { var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_42; var tmp2 any = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(field__0)).GetName__String().Ref()); var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_63; var tmp4 any = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(field__0)).GetType__Class().Ref()); var tmp5 *lang.Var; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_63; var tmp6 any = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(field__0)).GetDeclaringClass__Class().Ref()); var tmp7 *lang.Var; A_arbace_reflect_A_Init(); tmp7 = A_arbace_reflect_A_const_65; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = jrt.Integer_ValueOf_I__Integer(jrt.NN(jrt.Field_Cast(field__0)).GetModifiers__I()).Ref(); var tmp10 *lang.Keyword; A_arbace_reflect_A_Init(); tmp10 = A_arbace_reflect_A_const_69; return A_arbace_reflect_Field_A_New_O_O_O_O(tmp2, tmp4, tmp6, tmp8.Invoke_O_O__O(tmp9, tmp10.Ref())) }







func A_arbace_reflect_declared_fields_A_New() *A_arbace_reflect_declared_fields_A { A_arbace_reflect_declared_fields_A_Init(); t := &A_arbace_reflect_declared_fields_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_reflect_declared_fields_A) Ctor() {}
//line :172:1
func (t *A_arbace_reflect_declared_fields_A) Invoke_O_O__O(self, cls__0 any) any {


	var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_22; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_70; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(jrt.NN(tmp5).GetRawRoot__O(), jrt.NN(jrt.Class_Cast(cls__0)).GetDeclaredFields__Field1().Ref()))
}


func A_arbace_reflect_typeref__GT_class_A_New() *A_arbace_reflect_typeref__GT_class_A { A_arbace_reflect_typeref__GT_class_A_Init(); t := &A_arbace_reflect_typeref__GT_class_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_reflect_typeref__GT_class_A) Ctor() {}
//line :179:1
func (t *A_arbace_reflect_typeref__GT_class_A) Invoke_O_O_O__O(self, typeref__0, classloader__1 any) any {

	var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_37; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(typeref__0)) { return typeref__0 } else {

		var tmp2 any; var target_7 any = typeref__0; var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_reflect_TypeReference_A_InstanceOf(target_7); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z(target_7) }; tmp3 = tmp4; if tmp3 { tmp2 = A_arbace_reflect_TypeReference_A_Cast(target_7).Typename__O() } else { var tmp5 *lang.Var; A_arbace_reflect_A_Init(); tmp5 = A_arbace_reflect_A_const_41; tmp2 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(target_7) }; var tmp6 *jrt.String = jrt.String_Cast(tmp2); var tmp7 *jrt.Boolean; jrt.Boolean_Init(); tmp7 = jrt.Boolean_FALSE; return lang.RT_ClassForName_String_Z_ClassLoader__Class(tmp6, jrt.NN(tmp7).BooleanValue__Z(), jrt.ClassLoader_Cast(classloader__1)).Ref()
	} }
func A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_New() *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A { A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_Init(); t := &A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A) Ctor() {}
//line :185:1
func (t *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A) Invoke_O_O__O(self, classloader__1 any) any { return A_arbace_reflect_JavaReflector_A_New_O(classloader__1) }












func A_arbace_reflect_eval1938000121_fn__1938000122_A_New() *A_arbace_reflect_eval1938000121_fn__1938000122_A { A_arbace_reflect_eval1938000121_fn__1938000122_A_Init(); t := &A_arbace_reflect_eval1938000121_fn__1938000122_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_A) Ctor() {}
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1938000114__2_ any; var tmp1 any = A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_New(); var tmp2 *jrt.Class; A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_Init(); tmp2 = A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_fn_class; G__1938000114__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_New_O(G__1938000114__2_); var tmp4 *jrt.Class; A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_Init(); tmp4 = A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :198:1
func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_New_O(p0 any) *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A { A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_Init(); t := &A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A{}; t.Ctor_O(p0); return t }
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A) Ctor_O(c__G__1938000114 any) { t.F_G__1938000114 = c__G__1938000114 }
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A) Invoke_O_O_O__O(self, gf__this__1938000127__1, gf__name__1938000128__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__this__1938000127__1)); if jrt.A2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__this__1938000127__1, gf__name__1938000128__2) } else { var tmp1 *lang.Var; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_71; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__this__1938000127__1, tmp3.Ref(), t.F_G__1938000114)).Invoke_O_O__O(gf__this__1938000127__1, gf__name__1938000128__2) } }
//line :198:1
func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_New() *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A { A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_Init(); t := &A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A) Ctor() {}
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A) Invoke_O_O_O__O(self, gf__this__1938000123__1, gf__name__1938000124__2 any) any { var target_8 any = gf__this__1938000123__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_8 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_8) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_8, Lit_102, jrt.RefArrayOf(jrt.Object_class, gf__name__1938000124__2)) } else { return A_arbace_reflect_ClassResolver_A_Cast(target_8).Resolve_class_O__O(gf__name__1938000124__2) } }



func A_arbace_reflect_eval1938000137_fn__1938000138_A_New() *A_arbace_reflect_eval1938000137_fn__1938000138_A { A_arbace_reflect_eval1938000137_fn__1938000138_A_Init(); t := &A_arbace_reflect_eval1938000137_fn__1938000138_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_reflect_eval1938000137_fn__1938000138_A) Ctor() {}
//line :202:1
func (t *A_arbace_reflect_eval1938000137_fn__1938000138_A) Invoke_O_O_O__O(self, this__1, typeref__2 any) any {

	return lang.IFn_Cast(this__1).Invoke_O__O(typeref__2) }
//line :202:1
func A_arbace_reflect_eval1938000141_fn__1938000142_A_New() *A_arbace_reflect_eval1938000141_fn__1938000142_A { A_arbace_reflect_eval1938000141_fn__1938000142_A_Init(); t := &A_arbace_reflect_eval1938000141_fn__1938000142_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_reflect_eval1938000141_fn__1938000142_A) Ctor() {}
//line :202:1
func (t *A_arbace_reflect_eval1938000141_fn__1938000142_A) Invoke_O_O_O__O(self, this__1, typeref__2 any) any {





	var tmp1 *jrt.Class; A_arbace_reflect_A_Init(); tmp1 = A_arbace_reflect_A_const_72; var tmp2 *jrt.Class = tmp1; var tmp3 *lang.Var; A_arbace_reflect_A_Init(); tmp3 = A_arbace_reflect_A_const_73; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(this__1, tmp2, Lit_105, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(typeref__2)))
}



func A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_New() *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A { A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_Init(); t := &A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A) Ctor() {}
//line :213:1
func (t *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A) Invoke_O_O__O(self, class_resolver__1 any) any { return A_arbace_reflect_AsmReflector_A_New_O(class_resolver__1) }


























































type A_arbace_reflect_A struct{ jrt.Object }

var A_arbace_reflect_A_const_0 *lang.Var

var A_arbace_reflect_A_const_1 *lang.Var

var A_arbace_reflect_A_const_2 any

var A_arbace_reflect_A_const_3 any

var A_arbace_reflect_A_const_4 *lang.Var

var A_arbace_reflect_A_const_5 *lang.Var

var A_arbace_reflect_A_const_6 *lang.Var

var A_arbace_reflect_A_const_7 any

var A_arbace_reflect_A_const_8 *lang.Var

var A_arbace_reflect_A_const_9 *lang.Var

var A_arbace_reflect_A_const_10 *jrt.Class

var A_arbace_reflect_A_const_11 *jrt.Class

var A_arbace_reflect_A_const_12 *lang.Var

var A_arbace_reflect_A_const_13 *lang.Var

var A_arbace_reflect_A_const_14 *lang.Var

var A_arbace_reflect_A_const_15 *lang.Var

var A_arbace_reflect_A_const_16 *lang.Var

var A_arbace_reflect_A_const_17 *lang.Keyword

var A_arbace_reflect_A_const_18 *lang.Keyword

var A_arbace_reflect_A_const_19 *lang.Var

var A_arbace_reflect_A_const_20 *lang.Var

var A_arbace_reflect_A_const_21 *lang.Var

var A_arbace_reflect_A_const_22 *lang.Var

var A_arbace_reflect_A_const_23 *lang.Var

var A_arbace_reflect_A_const_24 *lang.Var

var A_arbace_reflect_A_const_25 *lang.Var

var A_arbace_reflect_A_const_26 *lang.Var

var A_arbace_reflect_A_const_27 *lang.Var

var A_arbace_reflect_A_const_28 *lang.Keyword

var A_arbace_reflect_A_const_29 *lang.Var

var A_arbace_reflect_A_const_30 *lang.Var

var A_arbace_reflect_A_const_31 *lang.Var

var A_arbace_reflect_A_const_32 *lang.Var

var A_arbace_reflect_A_const_33 *lang.Var

var A_arbace_reflect_A_const_34 *lang.Var

var A_arbace_reflect_A_const_35 any

var A_arbace_reflect_A_const_36 *lang.Var

var A_arbace_reflect_A_const_37 *lang.Var

var A_arbace_reflect_A_const_38 *lang.Var

var A_arbace_reflect_A_const_39 *lang.Var

var A_arbace_reflect_A_const_40 *lang.Var

var A_arbace_reflect_A_const_41 *lang.Var

var A_arbace_reflect_A_const_42 *lang.Var

var A_arbace_reflect_A_const_43 *lang.Var

var A_arbace_reflect_A_const_44 any

var A_arbace_reflect_A_const_45 *lang.Var

var A_arbace_reflect_A_const_46 *lang.Keyword

var A_arbace_reflect_A_const_47 *lang.Keyword

var A_arbace_reflect_A_const_48 *lang.Keyword

var A_arbace_reflect_A_const_49 *lang.Var

var A_arbace_reflect_A_const_50 any

var A_arbace_reflect_A_const_51 any

var A_arbace_reflect_A_const_52 *lang.Var

var A_arbace_reflect_A_const_53 any

var A_arbace_reflect_A_const_54 *lang.Var

var A_arbace_reflect_A_const_55 any

var A_arbace_reflect_A_const_56 *lang.Var

var A_arbace_reflect_A_const_57 *lang.Var

var A_arbace_reflect_A_const_58 any

var A_arbace_reflect_A_const_59 any

var A_arbace_reflect_A_const_60 *lang.Var

var A_arbace_reflect_A_const_61 *lang.Var

var A_arbace_reflect_A_const_62 *lang.Var

var A_arbace_reflect_A_const_63 *lang.Var

var A_arbace_reflect_A_const_64 *lang.Var

var A_arbace_reflect_A_const_65 *lang.Var

var A_arbace_reflect_A_const_66 *lang.Keyword

var A_arbace_reflect_A_const_67 *lang.Var

var A_arbace_reflect_A_const_68 *lang.Var

var A_arbace_reflect_A_const_69 *lang.Keyword

var A_arbace_reflect_A_const_70 *lang.Var

var A_arbace_reflect_A_const_71 *jrt.Class

var A_arbace_reflect_A_const_72 *jrt.Class

var A_arbace_reflect_A_const_73 *lang.Var

var A_arbace_reflect_A_init jrt.ClassInit

func A_arbace_reflect_A_Init() { if !A_arbace_reflect_A_init.Done() { A_arbace_reflect_A_init.Run(A_arbace_reflect_A_clinit) } }

func A_arbace_reflect_A_clinit() { A_arbace_reflect_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_reflect_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_reflect_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_reflect_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_reflect_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_reflect_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_reflect_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_reflect_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_reflect_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_reflect_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_reflect_A_const_10 = lang.RT_ClassForNameNonLoading_String__Class(Lit_18); A_arbace_reflect_A_const_11 = lang.RT_ClassForNameNonLoading_String__Class(Lit_19); A_arbace_reflect_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_reflect_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_reflect_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_reflect_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_reflect_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_reflect_A_const_17 = lang.RT_Keyword_String_String__Keyword(nil, Lit_25); A_arbace_reflect_A_const_18 = lang.RT_Keyword_String_String__Keyword(nil, Lit_26); A_arbace_reflect_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_reflect_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_reflect_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_reflect_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_reflect_A_const_23 = lang.RT_Var_String_String__Var(Lit_3, Lit_30); A_arbace_reflect_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_reflect_A_const_25 = lang.RT_Var_String_String__Var(Lit_9, Lit_32); A_arbace_reflect_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_reflect_A_const_27 = lang.RT_Var_String_String__Var(Lit_9, Lit_34); A_arbace_reflect_A_const_28 = lang.RT_Keyword_String_String__Keyword(nil, Lit_35); A_arbace_reflect_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_reflect_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_reflect_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_reflect_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_reflect_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_reflect_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_reflect_A_const_35 = lang.Tuple_Create_O__IPersistentVector(lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref()); A_arbace_reflect_A_const_36 = lang.RT_Var_String_String__Var(Lit_9, Lit_43); A_arbace_reflect_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_reflect_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_reflect_A_const_39 = lang.RT_Var_String_String__Var(Lit_46, Lit_47); A_arbace_reflect_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_reflect_A_const_41 = lang.RT_Var_String_String__Var(Lit_9, Lit_49); A_arbace_reflect_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_reflect_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_reflect_A_const_44 = lang.Symbol_Intern_String_String__Symbol(Lit_52, Lit_53).Ref(); A_arbace_reflect_A_const_45 = lang.RT_Var_String_String__Var(Lit_54, Lit_53); A_arbace_reflect_A_const_46 = lang.RT_Keyword_String_String__Keyword(nil, Lit_55); A_arbace_reflect_A_const_47 = lang.RT_Keyword_String_String__Keyword(nil, Lit_56); A_arbace_reflect_A_const_48 = lang.RT_Keyword_String_String__Keyword(nil, Lit_57); A_arbace_reflect_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_reflect_A_const_50 = jrt.Character_ValueOf_C__Character(76).Ref(); A_arbace_reflect_A_const_51 = jrt.Character_ValueOf_C__Character(91).Ref(); A_arbace_reflect_A_const_52 = lang.RT_Var_String_String__Var(Lit_9, Lit_59); A_arbace_reflect_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.ConstRefArray("[0,18,s1:Js4:longs1:Ss5:shorts1:Zs7:booleans1:Cs4:chars1:Fs5:floats1:Bs4:bytes1:Vs4:voids1:Is3:ints1:Ds6:double", []*jrt.Class{jrt.Object_class})); A_arbace_reflect_A_const_54 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_reflect_A_const_55 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_reflect_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_61); A_arbace_reflect_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); A_arbace_reflect_A_const_58 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_63).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), jrt.Integer_ValueOf_I__Integer(70).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), jrt.Integer_ValueOf_I__Integer(10).Ref()))); A_arbace_reflect_A_const_59 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_63).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), jrt.Integer_ValueOf_I__Integer(80).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), jrt.Integer_ValueOf_I__Integer(10).Ref()))); A_arbace_reflect_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_66); A_arbace_reflect_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_67); A_arbace_reflect_A_const_62 = lang.RT_Var_String_String__Var(Lit_9, Lit_68); A_arbace_reflect_A_const_63 = lang.RT_Var_String_String__Var(Lit_9, Lit_69); A_arbace_reflect_A_const_64 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_reflect_A_const_65 = lang.RT_Var_String_String__Var(Lit_9, Lit_71); A_arbace_reflect_A_const_66 = lang.RT_Keyword_String_String__Keyword(nil, Lit_72); A_arbace_reflect_A_const_67 = lang.RT_Var_String_String__Var(Lit_9, Lit_73); A_arbace_reflect_A_const_68 = lang.RT_Var_String_String__Var(Lit_9, Lit_74); A_arbace_reflect_A_const_69 = lang.RT_Keyword_String_String__Keyword(nil, Lit_75); A_arbace_reflect_A_const_70 = lang.RT_Var_String_String__Var(Lit_9, Lit_76); A_arbace_reflect_A_const_71 = lang.RT_ClassForNameNonLoading_String__Class(Lit_77); A_arbace_reflect_A_const_72 = lang.RT_ClassForNameNonLoading_String__Class(Lit_78); A_arbace_reflect_A_const_73 = lang.RT_Var_String_String__Var(Lit_9, Lit_79) }

func A_arbace_reflect_A_New() *A_arbace_reflect_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_A) Ctor() {}

func (t *A_arbace_reflect_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_A_class }

func (t *A_arbace_reflect_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_A); return ok }

func A_arbace_reflect_A_Cast(x any) *A_arbace_reflect_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_A_class)) }; return v }



type A_arbace_reflect_access_flag_A struct{ jrt.Object }

func (t *A_arbace_reflect_access_flag_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_access_flag_A_fn_class *jrt.Class

var A_arbace_reflect_access_flag_A_init jrt.ClassInit

func A_arbace_reflect_access_flag_A_Init() { if !A_arbace_reflect_access_flag_A_init.Done() { A_arbace_reflect_access_flag_A_init.Run(A_arbace_reflect_access_flag_A_clinit) } }

func A_arbace_reflect_access_flag_A_clinit() { A_arbace_reflect_access_flag_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_80, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_access_flag_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_access_flag_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_access_flag_A_class }

func (t *A_arbace_reflect_access_flag_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_access_flag_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_access_flag_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_access_flag_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_access_flag_A); return ok }

func A_arbace_reflect_access_flag_A_Cast(x any) *A_arbace_reflect_access_flag_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_access_flag_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_access_flag_A_class)) }; return v }



type A_arbace_reflect_constructor__GT_map_A struct{ jrt.Object }

func (t *A_arbace_reflect_constructor__GT_map_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_constructor__GT_map_A_fn_class *jrt.Class

var A_arbace_reflect_constructor__GT_map_A_init jrt.ClassInit

func A_arbace_reflect_constructor__GT_map_A_Init() { if !A_arbace_reflect_constructor__GT_map_A_init.Done() { A_arbace_reflect_constructor__GT_map_A_init.Run(A_arbace_reflect_constructor__GT_map_A_clinit) } }

func A_arbace_reflect_constructor__GT_map_A_clinit() { A_arbace_reflect_constructor__GT_map_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_81, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_constructor__GT_map_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_constructor__GT_map_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_constructor__GT_map_A_class }

func (t *A_arbace_reflect_constructor__GT_map_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_constructor__GT_map_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_constructor__GT_map_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_constructor__GT_map_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_constructor__GT_map_A); return ok }

func A_arbace_reflect_constructor__GT_map_A_Cast(x any) *A_arbace_reflect_constructor__GT_map_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_constructor__GT_map_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_constructor__GT_map_A_class)) }; return v }



type A_arbace_reflect_declared_constructors_A struct{ jrt.Object }

func (t *A_arbace_reflect_declared_constructors_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_declared_constructors_A_fn_class *jrt.Class

var A_arbace_reflect_declared_constructors_A_init jrt.ClassInit

func A_arbace_reflect_declared_constructors_A_Init() { if !A_arbace_reflect_declared_constructors_A_init.Done() { A_arbace_reflect_declared_constructors_A_init.Run(A_arbace_reflect_declared_constructors_A_clinit) } }

func A_arbace_reflect_declared_constructors_A_clinit() { A_arbace_reflect_declared_constructors_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_82, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_declared_constructors_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_declared_constructors_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_declared_constructors_A_class }

func (t *A_arbace_reflect_declared_constructors_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_declared_constructors_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_declared_constructors_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_declared_constructors_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_declared_constructors_A); return ok }

func A_arbace_reflect_declared_constructors_A_Cast(x any) *A_arbace_reflect_declared_constructors_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_declared_constructors_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_declared_constructors_A_class)) }; return v }



type A_arbace_reflect_declared_fields_A struct{ jrt.Object }

func (t *A_arbace_reflect_declared_fields_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_declared_fields_A_fn_class *jrt.Class

var A_arbace_reflect_declared_fields_A_init jrt.ClassInit

func A_arbace_reflect_declared_fields_A_Init() { if !A_arbace_reflect_declared_fields_A_init.Done() { A_arbace_reflect_declared_fields_A_init.Run(A_arbace_reflect_declared_fields_A_clinit) } }

func A_arbace_reflect_declared_fields_A_clinit() { A_arbace_reflect_declared_fields_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_83, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_declared_fields_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_declared_fields_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_declared_fields_A_class }

func (t *A_arbace_reflect_declared_fields_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_declared_fields_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_declared_fields_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_declared_fields_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_declared_fields_A); return ok }

func A_arbace_reflect_declared_fields_A_Cast(x any) *A_arbace_reflect_declared_fields_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_declared_fields_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_declared_fields_A_class)) }; return v }



type A_arbace_reflect_declared_methods_A struct{ jrt.Object }

func (t *A_arbace_reflect_declared_methods_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_declared_methods_A_fn_class *jrt.Class

var A_arbace_reflect_declared_methods_A_init jrt.ClassInit

func A_arbace_reflect_declared_methods_A_Init() { if !A_arbace_reflect_declared_methods_A_init.Done() { A_arbace_reflect_declared_methods_A_init.Run(A_arbace_reflect_declared_methods_A_clinit) } }

func A_arbace_reflect_declared_methods_A_clinit() { A_arbace_reflect_declared_methods_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_84, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_declared_methods_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_declared_methods_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_declared_methods_A_class }

func (t *A_arbace_reflect_declared_methods_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_declared_methods_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_declared_methods_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_declared_methods_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_declared_methods_A); return ok }

func A_arbace_reflect_declared_methods_A_Cast(x any) *A_arbace_reflect_declared_methods_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_declared_methods_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_declared_methods_A_class)) }; return v }



type A_arbace_reflect_descriptor_class_name_A struct{ jrt.Object }

func (t *A_arbace_reflect_descriptor_class_name_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_descriptor_class_name_A_fn_class *jrt.Class

var A_arbace_reflect_descriptor_class_name_A_init jrt.ClassInit

func A_arbace_reflect_descriptor_class_name_A_Init() { if !A_arbace_reflect_descriptor_class_name_A_init.Done() { A_arbace_reflect_descriptor_class_name_A_init.Run(A_arbace_reflect_descriptor_class_name_A_clinit) } }

func A_arbace_reflect_descriptor_class_name_A_clinit() { A_arbace_reflect_descriptor_class_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_85, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_descriptor_class_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_descriptor_class_name_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_descriptor_class_name_A_class }

func (t *A_arbace_reflect_descriptor_class_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_descriptor_class_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_descriptor_class_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_descriptor_class_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_descriptor_class_name_A); return ok }

func A_arbace_reflect_descriptor_class_name_A_Cast(x any) *A_arbace_reflect_descriptor_class_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_descriptor_class_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_descriptor_class_name_A_class)) }; return v }



type A_arbace_reflect_eval1938000010_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000010_A_New() *A_arbace_reflect_eval1938000010_A { t := &A_arbace_reflect_eval1938000010_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000010_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000010_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000010_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000010_A_class }

func (t *A_arbace_reflect_eval1938000010_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000010_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000010_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000010_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000010_A); return ok }

func A_arbace_reflect_eval1938000010_A_Cast(x any) *A_arbace_reflect_eval1938000010_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000010_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000010_A_class)) }; return v }



type A_arbace_reflect_eval1938000010_fn__1938000011_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000010_fn__1938000011_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_eval1938000010_fn__1938000011_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000010_fn__1938000011_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000010_fn__1938000011_A_Init() { if !A_arbace_reflect_eval1938000010_fn__1938000011_A_init.Done() { A_arbace_reflect_eval1938000010_fn__1938000011_A_init.Run(A_arbace_reflect_eval1938000010_fn__1938000011_A_clinit) } }

func A_arbace_reflect_eval1938000010_fn__1938000011_A_clinit() { A_arbace_reflect_eval1938000010_fn__1938000011_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_89, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000010_fn__1938000011_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000010_fn__1938000011_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000010_fn__1938000011_A_class }

func (t *A_arbace_reflect_eval1938000010_fn__1938000011_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000010_fn__1938000011_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000010_fn__1938000011_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000010_fn__1938000011_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000010_fn__1938000011_A); return ok }

func A_arbace_reflect_eval1938000010_fn__1938000011_A_Cast(x any) *A_arbace_reflect_eval1938000010_fn__1938000011_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000010_fn__1938000011_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000010_fn__1938000011_A_class)) }; return v }



type A_arbace_reflect_eval1938000014_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000014_A_New() *A_arbace_reflect_eval1938000014_A { t := &A_arbace_reflect_eval1938000014_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000014_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000014_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000014_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000014_A_class }

func (t *A_arbace_reflect_eval1938000014_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000014_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000014_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000014_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000014_A); return ok }

func A_arbace_reflect_eval1938000014_A_Cast(x any) *A_arbace_reflect_eval1938000014_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000014_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000014_A_class)) }; return v }



type A_arbace_reflect_eval1938000014_fn__1938000015_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000014_fn__1938000015_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_eval1938000014_fn__1938000015_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000014_fn__1938000015_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000014_fn__1938000015_A_Init() { if !A_arbace_reflect_eval1938000014_fn__1938000015_A_init.Done() { A_arbace_reflect_eval1938000014_fn__1938000015_A_init.Run(A_arbace_reflect_eval1938000014_fn__1938000015_A_clinit) } }

func A_arbace_reflect_eval1938000014_fn__1938000015_A_clinit() { A_arbace_reflect_eval1938000014_fn__1938000015_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_91, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000014_fn__1938000015_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000014_fn__1938000015_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000014_fn__1938000015_A_class }

func (t *A_arbace_reflect_eval1938000014_fn__1938000015_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000014_fn__1938000015_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000014_fn__1938000015_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000014_fn__1938000015_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000014_fn__1938000015_A); return ok }

func A_arbace_reflect_eval1938000014_fn__1938000015_A_Cast(x any) *A_arbace_reflect_eval1938000014_fn__1938000015_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000014_fn__1938000015_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000014_fn__1938000015_A_class)) }; return v }



type A_arbace_reflect_eval1938000036_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000036_A_New() *A_arbace_reflect_eval1938000036_A { t := &A_arbace_reflect_eval1938000036_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000036_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000036_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000036_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000036_A_class }

func (t *A_arbace_reflect_eval1938000036_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000036_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000036_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000036_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000036_A); return ok }

func A_arbace_reflect_eval1938000036_A_Cast(x any) *A_arbace_reflect_eval1938000036_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000036_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000036_A_class)) }; return v }



type A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A) Is_Compiler_AOTF5() {}

var A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_Init() { if !A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_init.Done() { A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_init.Run(A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_clinit) } }

func A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_clinit() { A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_92, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_class }

func (t *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A); return ok }

func A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_Cast(x any) *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_class)) }; return v }



type A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_Init() { if !A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_init.Done() { A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_init.Run(A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_clinit) } }

func A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_clinit() { A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_93, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_class }

func (t *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A); return ok }

func A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_Cast(x any) *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_class)) }; return v }



type A_arbace_reflect_eval1938000060_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000060_A_New() *A_arbace_reflect_eval1938000060_A { t := &A_arbace_reflect_eval1938000060_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000060_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000060_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000060_A_class }

func (t *A_arbace_reflect_eval1938000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000060_A); return ok }

func A_arbace_reflect_eval1938000060_A_Cast(x any) *A_arbace_reflect_eval1938000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000060_A_class)) }; return v }



type A_arbace_reflect_eval1938000060___GT_Method__1938000078_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A) Is_Compiler_AOTF6() {}

var A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_Init() { if !A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_init.Done() { A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_init.Run(A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_clinit) } }

func A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_clinit() { A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_94, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_class }

func (t *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000060___GT_Method__1938000078_A); return ok }

func A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_Cast(x any) *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000060___GT_Method__1938000078_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_class)) }; return v }



type A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_Init() { if !A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_init.Done() { A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_init.Run(A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_clinit) } }

func A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_clinit() { A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_95, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_class }

func (t *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A); return ok }

func A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_Cast(x any) *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_class)) }; return v }



type A_arbace_reflect_eval1938000086_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000086_A_New() *A_arbace_reflect_eval1938000086_A { t := &A_arbace_reflect_eval1938000086_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000086_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000086_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000086_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000086_A_class }

func (t *A_arbace_reflect_eval1938000086_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000086_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000086_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000086_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000086_A); return ok }

func A_arbace_reflect_eval1938000086_A_Cast(x any) *A_arbace_reflect_eval1938000086_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000086_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000086_A_class)) }; return v }



type A_arbace_reflect_eval1938000086___GT_Field__1938000100_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A) Is_Compiler_AOTF4() {}

var A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_Init() { if !A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_init.Done() { A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_init.Run(A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_clinit) } }

func A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_clinit() { A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_96, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_class }

func (t *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000086___GT_Field__1938000100_A); return ok }

func A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_Cast(x any) *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000086___GT_Field__1938000100_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_class)) }; return v }



type A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_Init() { if !A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_init.Done() { A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_init.Run(A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_clinit) } }

func A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_clinit() { A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_97, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_class }

func (t *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A); return ok }

func A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_Cast(x any) *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_class)) }; return v }



type A_arbace_reflect_eval1938000108_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000108_A_New() *A_arbace_reflect_eval1938000108_A { t := &A_arbace_reflect_eval1938000108_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000108_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000108_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000108_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000108_A_class }

func (t *A_arbace_reflect_eval1938000108_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000108_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000108_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000108_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000108_A); return ok }

func A_arbace_reflect_eval1938000108_A_Cast(x any) *A_arbace_reflect_eval1938000108_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000108_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000108_A_class)) }; return v }



type A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_Init() { if !A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_init.Done() { A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_init.Run(A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_clinit) } }

func A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_clinit() { A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_98, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_class }

func (t *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A); return ok }

func A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_Cast(x any) *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_class)) }; return v }



type A_arbace_reflect_eval1938000121_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000121_A_New() *A_arbace_reflect_eval1938000121_A { t := &A_arbace_reflect_eval1938000121_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000121_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000121_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000121_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000121_A_class }

func (t *A_arbace_reflect_eval1938000121_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000121_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000121_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000121_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000121_A); return ok }

func A_arbace_reflect_eval1938000121_A_Cast(x any) *A_arbace_reflect_eval1938000121_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000121_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000121_A_class)) }; return v }



type A_arbace_reflect_eval1938000121_fn__1938000122_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_eval1938000121_fn__1938000122_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000121_fn__1938000122_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000121_fn__1938000122_A_Init() { if !A_arbace_reflect_eval1938000121_fn__1938000122_A_init.Done() { A_arbace_reflect_eval1938000121_fn__1938000122_A_init.Run(A_arbace_reflect_eval1938000121_fn__1938000122_A_clinit) } }

func A_arbace_reflect_eval1938000121_fn__1938000122_A_clinit() { A_arbace_reflect_eval1938000121_fn__1938000122_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_99, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000121_fn__1938000122_A_class }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000121_fn__1938000122_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000121_fn__1938000122_A); return ok }

func A_arbace_reflect_eval1938000121_fn__1938000122_A_Cast(x any) *A_arbace_reflect_eval1938000121_fn__1938000122_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000121_fn__1938000122_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000121_fn__1938000122_A_class)) }; return v }



type A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A struct{ jrt.Object; F_G__1938000114 any }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A) Is_Compiler_AOTF2() {}

var A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_Init() { if !A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_init.Done() { A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_init.Run(A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_clinit) } }

func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_clinit() { A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_100, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_class }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A); return ok }

func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_Cast(x any) *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_class)) }; return v }



type A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A) Is_Compiler_AOTF2() {}

var A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_Init() { if !A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_init.Done() { A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_init.Run(A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_clinit) } }

func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_clinit() { A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_101, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_class }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A); return ok }

func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_Cast(x any) *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_class)) }; return v }



type A_arbace_reflect_eval1938000137_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000137_A_New() *A_arbace_reflect_eval1938000137_A { t := &A_arbace_reflect_eval1938000137_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000137_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000137_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000137_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000137_A_class }

func (t *A_arbace_reflect_eval1938000137_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000137_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000137_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000137_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000137_A); return ok }

func A_arbace_reflect_eval1938000137_A_Cast(x any) *A_arbace_reflect_eval1938000137_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000137_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000137_A_class)) }; return v }



type A_arbace_reflect_eval1938000137_fn__1938000138_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000137_fn__1938000138_A) Is_Compiler_AOTF2() {}

var A_arbace_reflect_eval1938000137_fn__1938000138_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000137_fn__1938000138_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000137_fn__1938000138_A_Init() { if !A_arbace_reflect_eval1938000137_fn__1938000138_A_init.Done() { A_arbace_reflect_eval1938000137_fn__1938000138_A_init.Run(A_arbace_reflect_eval1938000137_fn__1938000138_A_clinit) } }

func A_arbace_reflect_eval1938000137_fn__1938000138_A_clinit() { A_arbace_reflect_eval1938000137_fn__1938000138_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_103, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000137_fn__1938000138_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000137_fn__1938000138_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000137_fn__1938000138_A_class }

func (t *A_arbace_reflect_eval1938000137_fn__1938000138_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000137_fn__1938000138_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000137_fn__1938000138_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000137_fn__1938000138_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000137_fn__1938000138_A); return ok }

func A_arbace_reflect_eval1938000137_fn__1938000138_A_Cast(x any) *A_arbace_reflect_eval1938000137_fn__1938000138_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000137_fn__1938000138_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000137_fn__1938000138_A_class)) }; return v }



type A_arbace_reflect_eval1938000141_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000141_A_New() *A_arbace_reflect_eval1938000141_A { t := &A_arbace_reflect_eval1938000141_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000141_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000141_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000141_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000141_A_class }

func (t *A_arbace_reflect_eval1938000141_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000141_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000141_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000141_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000141_A); return ok }

func A_arbace_reflect_eval1938000141_A_Cast(x any) *A_arbace_reflect_eval1938000141_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000141_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000141_A_class)) }; return v }



type A_arbace_reflect_eval1938000141_fn__1938000142_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000141_fn__1938000142_A) Is_Compiler_AOTF2() {}

var A_arbace_reflect_eval1938000141_fn__1938000142_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000141_fn__1938000142_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000141_fn__1938000142_A_Init() { if !A_arbace_reflect_eval1938000141_fn__1938000142_A_init.Done() { A_arbace_reflect_eval1938000141_fn__1938000142_A_init.Run(A_arbace_reflect_eval1938000141_fn__1938000142_A_clinit) } }

func A_arbace_reflect_eval1938000141_fn__1938000142_A_clinit() { A_arbace_reflect_eval1938000141_fn__1938000142_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_104, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000141_fn__1938000142_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000141_fn__1938000142_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000141_fn__1938000142_A_class }

func (t *A_arbace_reflect_eval1938000141_fn__1938000142_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000141_fn__1938000142_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000141_fn__1938000142_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000141_fn__1938000142_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000141_fn__1938000142_A); return ok }

func A_arbace_reflect_eval1938000141_fn__1938000142_A_Cast(x any) *A_arbace_reflect_eval1938000141_fn__1938000142_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000141_fn__1938000142_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000141_fn__1938000142_A_class)) }; return v }



type A_arbace_reflect_eval1938000145_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000145_A_New() *A_arbace_reflect_eval1938000145_A { t := &A_arbace_reflect_eval1938000145_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000145_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000145_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000145_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000145_A_class }

func (t *A_arbace_reflect_eval1938000145_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000145_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000145_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000145_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000145_A); return ok }

func A_arbace_reflect_eval1938000145_A_Cast(x any) *A_arbace_reflect_eval1938000145_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000145_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000145_A_class)) }; return v }



type A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_fn_class *jrt.Class

var A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_init jrt.ClassInit

func A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_Init() { if !A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_init.Done() { A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_init.Run(A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_clinit) } }

func A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_clinit() { A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_106, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_class }

func (t *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A); return ok }

func A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_Cast(x any) *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_class)) }; return v }



type A_arbace_reflect_eval659000004_A struct{ jrt.Object }

func A_arbace_reflect_eval659000004_A_New() *A_arbace_reflect_eval659000004_A { t := &A_arbace_reflect_eval659000004_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000004_A) Ctor() {}

func (t *A_arbace_reflect_eval659000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000004_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000004_A_class }

func (t *A_arbace_reflect_eval659000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000004_A); return ok }

func A_arbace_reflect_eval659000004_A_Cast(x any) *A_arbace_reflect_eval659000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000004_A_class)) }; return v }



type A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) Is_Compiler_AOTF0() {}

var A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_fn_class *jrt.Class

var A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_init jrt.ClassInit

func A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_Init() { if !A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_init.Done() { A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_init.Run(A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_clinit) } }

func A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_clinit() { A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_107, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_class }

func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A); return ok }

func A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_Cast(x any) *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_class)) }; return v }



type A_arbace_reflect_eval659000008_A struct{ jrt.Object }

func A_arbace_reflect_eval659000008_A_New() *A_arbace_reflect_eval659000008_A { t := &A_arbace_reflect_eval659000008_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000008_A) Ctor() {}

func (t *A_arbace_reflect_eval659000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000008_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000008_A_class }

func (t *A_arbace_reflect_eval659000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000008_A); return ok }

func A_arbace_reflect_eval659000008_A_Cast(x any) *A_arbace_reflect_eval659000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000008_A_class)) }; return v }



type A_arbace_reflect_eval659000008_fn__659000009_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval659000008_fn__659000009_A) Is_Compiler_AOTF0() {}

var A_arbace_reflect_eval659000008_fn__659000009_A_fn_class *jrt.Class

var A_arbace_reflect_eval659000008_fn__659000009_A_init jrt.ClassInit

func A_arbace_reflect_eval659000008_fn__659000009_A_Init() { if !A_arbace_reflect_eval659000008_fn__659000009_A_init.Done() { A_arbace_reflect_eval659000008_fn__659000009_A_init.Run(A_arbace_reflect_eval659000008_fn__659000009_A_clinit) } }

func A_arbace_reflect_eval659000008_fn__659000009_A_clinit() { A_arbace_reflect_eval659000008_fn__659000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_108, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval659000008_fn__659000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000008_fn__659000009_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000008_fn__659000009_A_class }

func (t *A_arbace_reflect_eval659000008_fn__659000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000008_fn__659000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000008_fn__659000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000008_fn__659000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000008_fn__659000009_A); return ok }

func A_arbace_reflect_eval659000008_fn__659000009_A_Cast(x any) *A_arbace_reflect_eval659000008_fn__659000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000008_fn__659000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000008_fn__659000009_A_class)) }; return v }



type A_arbace_reflect_eval659000020_A struct{ jrt.Object }

func A_arbace_reflect_eval659000020_A_New() *A_arbace_reflect_eval659000020_A { t := &A_arbace_reflect_eval659000020_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000020_A) Ctor() {}

func (t *A_arbace_reflect_eval659000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000020_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000020_A_class }

func (t *A_arbace_reflect_eval659000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000020_A); return ok }

func A_arbace_reflect_eval659000020_A_Cast(x any) *A_arbace_reflect_eval659000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000020_A_class)) }; return v }



type A_arbace_reflect_eval659000020_fn__659000021_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval659000020_fn__659000021_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_eval659000020_fn__659000021_A_fn_class *jrt.Class

var A_arbace_reflect_eval659000020_fn__659000021_A_init jrt.ClassInit

func A_arbace_reflect_eval659000020_fn__659000021_A_Init() { if !A_arbace_reflect_eval659000020_fn__659000021_A_init.Done() { A_arbace_reflect_eval659000020_fn__659000021_A_init.Run(A_arbace_reflect_eval659000020_fn__659000021_A_clinit) } }

func A_arbace_reflect_eval659000020_fn__659000021_A_clinit() { A_arbace_reflect_eval659000020_fn__659000021_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_109, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval659000020_fn__659000021_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000020_fn__659000021_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000020_fn__659000021_A_class }

func (t *A_arbace_reflect_eval659000020_fn__659000021_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000020_fn__659000021_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000020_fn__659000021_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000020_fn__659000021_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000020_fn__659000021_A); return ok }

func A_arbace_reflect_eval659000020_fn__659000021_A_Cast(x any) *A_arbace_reflect_eval659000020_fn__659000021_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000020_fn__659000021_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000020_fn__659000021_A_class)) }; return v }



type A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A struct{ jrt.Object; F_G__659000013 any }

func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) Is_Compiler_AOTF2() {}

var A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_fn_class *jrt.Class

var A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_init jrt.ClassInit

func A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_Init() { if !A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_init.Done() { A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_init.Run(A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_clinit) } }

func A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_clinit() { A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_110, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_class }

func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A); return ok }

func A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_Cast(x any) *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_class)) }; return v }



type A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) Is_Compiler_AOTF2() {}

var A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_fn_class *jrt.Class

var A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_init jrt.ClassInit

func A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_Init() { if !A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_init.Done() { A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_init.Run(A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_clinit) } }

func A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_clinit() { A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_111, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_class }

func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A); return ok }

func A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_Cast(x any) *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_class)) }; return v }



type A_arbace_reflect_eval659000044_A struct{ jrt.Object }

func A_arbace_reflect_eval659000044_A_New() *A_arbace_reflect_eval659000044_A { t := &A_arbace_reflect_eval659000044_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000044_A) Ctor() {}

func (t *A_arbace_reflect_eval659000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000044_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000044_A_class }

func (t *A_arbace_reflect_eval659000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000044_A); return ok }

func A_arbace_reflect_eval659000044_A_Cast(x any) *A_arbace_reflect_eval659000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000044_A_class)) }; return v }



type A_arbace_reflect_eval659000044_fn__659000045_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval659000044_fn__659000045_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_eval659000044_fn__659000045_A_fn_class *jrt.Class

var A_arbace_reflect_eval659000044_fn__659000045_A_init jrt.ClassInit

func A_arbace_reflect_eval659000044_fn__659000045_A_Init() { if !A_arbace_reflect_eval659000044_fn__659000045_A_init.Done() { A_arbace_reflect_eval659000044_fn__659000045_A_init.Run(A_arbace_reflect_eval659000044_fn__659000045_A_clinit) } }

func A_arbace_reflect_eval659000044_fn__659000045_A_clinit() { A_arbace_reflect_eval659000044_fn__659000045_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_113, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval659000044_fn__659000045_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000044_fn__659000045_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000044_fn__659000045_A_class }

func (t *A_arbace_reflect_eval659000044_fn__659000045_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000044_fn__659000045_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000044_fn__659000045_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000044_fn__659000045_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000044_fn__659000045_A); return ok }

func A_arbace_reflect_eval659000044_fn__659000045_A_Cast(x any) *A_arbace_reflect_eval659000044_fn__659000045_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000044_fn__659000045_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000044_fn__659000045_A_class)) }; return v }



type A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A struct{ jrt.Object; F_G__659000037 any }

func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_fn_class *jrt.Class

var A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_init jrt.ClassInit

func A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_Init() { if !A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_init.Done() { A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_init.Run(A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_clinit) } }

func A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_clinit() { A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_114, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_class }

func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A); return ok }

func A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_Cast(x any) *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_class)) }; return v }



type A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A struct{ jrt.Object }

func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_fn_class *jrt.Class

var A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_init jrt.ClassInit

func A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_Init() { if !A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_init.Done() { A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_init.Run(A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_clinit) } }

func A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_clinit() { A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_115, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_class }

func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A); return ok }

func A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_Cast(x any) *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_class)) }; return v }



type A_arbace_reflect_field__GT_map_A struct{ jrt.Object }

func (t *A_arbace_reflect_field__GT_map_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_field__GT_map_A_fn_class *jrt.Class

var A_arbace_reflect_field__GT_map_A_init jrt.ClassInit

func A_arbace_reflect_field__GT_map_A_Init() { if !A_arbace_reflect_field__GT_map_A_init.Done() { A_arbace_reflect_field__GT_map_A_init.Run(A_arbace_reflect_field__GT_map_A_clinit) } }

func A_arbace_reflect_field__GT_map_A_clinit() { A_arbace_reflect_field__GT_map_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_116, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_field__GT_map_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_field__GT_map_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_field__GT_map_A_class }

func (t *A_arbace_reflect_field__GT_map_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_field__GT_map_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_field__GT_map_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_field__GT_map_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_field__GT_map_A); return ok }

func A_arbace_reflect_field__GT_map_A_Cast(x any) *A_arbace_reflect_field__GT_map_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_field__GT_map_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_field__GT_map_A_class)) }; return v }



type A_arbace_reflect_field_descriptor__GT_class_symbol_A struct{ jrt.Object }

func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_field_descriptor__GT_class_symbol_A_fn_class *jrt.Class

var A_arbace_reflect_field_descriptor__GT_class_symbol_A_init jrt.ClassInit

func A_arbace_reflect_field_descriptor__GT_class_symbol_A_Init() { if !A_arbace_reflect_field_descriptor__GT_class_symbol_A_init.Done() { A_arbace_reflect_field_descriptor__GT_class_symbol_A_init.Run(A_arbace_reflect_field_descriptor__GT_class_symbol_A_clinit) } }

func A_arbace_reflect_field_descriptor__GT_class_symbol_A_clinit() { A_arbace_reflect_field_descriptor__GT_class_symbol_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_field_descriptor__GT_class_symbol_A_class }

func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_field_descriptor__GT_class_symbol_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_field_descriptor__GT_class_symbol_A); return ok }

func A_arbace_reflect_field_descriptor__GT_class_symbol_A_Cast(x any) *A_arbace_reflect_field_descriptor__GT_class_symbol_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_field_descriptor__GT_class_symbol_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_field_descriptor__GT_class_symbol_A_class)) }; return v }



type A_arbace_reflect_internal_name__GT_class_symbol_A struct{ jrt.Object }

func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_internal_name__GT_class_symbol_A_fn_class *jrt.Class

var A_arbace_reflect_internal_name__GT_class_symbol_A_init jrt.ClassInit

func A_arbace_reflect_internal_name__GT_class_symbol_A_Init() { if !A_arbace_reflect_internal_name__GT_class_symbol_A_init.Done() { A_arbace_reflect_internal_name__GT_class_symbol_A_init.Run(A_arbace_reflect_internal_name__GT_class_symbol_A_clinit) } }

func A_arbace_reflect_internal_name__GT_class_symbol_A_clinit() { A_arbace_reflect_internal_name__GT_class_symbol_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_119, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_internal_name__GT_class_symbol_A_class }

func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_internal_name__GT_class_symbol_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_internal_name__GT_class_symbol_A); return ok }

func A_arbace_reflect_internal_name__GT_class_symbol_A_Cast(x any) *A_arbace_reflect_internal_name__GT_class_symbol_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_internal_name__GT_class_symbol_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_internal_name__GT_class_symbol_A_class)) }; return v }



type A_arbace_reflect_method__GT_map_A struct{ jrt.Object }

func (t *A_arbace_reflect_method__GT_map_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_method__GT_map_A_fn_class *jrt.Class

var A_arbace_reflect_method__GT_map_A_init jrt.ClassInit

func A_arbace_reflect_method__GT_map_A_Init() { if !A_arbace_reflect_method__GT_map_A_init.Done() { A_arbace_reflect_method__GT_map_A_init.Run(A_arbace_reflect_method__GT_map_A_clinit) } }

func A_arbace_reflect_method__GT_map_A_clinit() { A_arbace_reflect_method__GT_map_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_121, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_method__GT_map_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_method__GT_map_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_method__GT_map_A_class }

func (t *A_arbace_reflect_method__GT_map_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_method__GT_map_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_method__GT_map_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_method__GT_map_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_method__GT_map_A); return ok }

func A_arbace_reflect_method__GT_map_A_Cast(x any) *A_arbace_reflect_method__GT_map_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_method__GT_map_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_method__GT_map_A_class)) }; return v }



type A_arbace_reflect_parse_flags_A struct{ jrt.Object }

func (t *A_arbace_reflect_parse_flags_A) Is_Compiler_AOTF2() {}

var A_arbace_reflect_parse_flags_A_fn_class *jrt.Class

var A_arbace_reflect_parse_flags_A_init jrt.ClassInit

func A_arbace_reflect_parse_flags_A_Init() { if !A_arbace_reflect_parse_flags_A_init.Done() { A_arbace_reflect_parse_flags_A_init.Run(A_arbace_reflect_parse_flags_A_clinit) } }

func A_arbace_reflect_parse_flags_A_clinit() { A_arbace_reflect_parse_flags_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_122, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_parse_flags_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_parse_flags_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_parse_flags_A_class }

func (t *A_arbace_reflect_parse_flags_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_parse_flags_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_parse_flags_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_parse_flags_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_parse_flags_A); return ok }

func A_arbace_reflect_parse_flags_A_Cast(x any) *A_arbace_reflect_parse_flags_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_parse_flags_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_parse_flags_A_class)) }; return v }



type A_arbace_reflect_parse_flags_fn__1938000032_A struct{ jrt.Object; F_flags, F_context any }

func (t *A_arbace_reflect_parse_flags_fn__1938000032_A) Is_Compiler_AOTF2() {}

var A_arbace_reflect_parse_flags_fn__1938000032_A_fn_class *jrt.Class

var A_arbace_reflect_parse_flags_fn__1938000032_A_init jrt.ClassInit

func A_arbace_reflect_parse_flags_fn__1938000032_A_Init() { if !A_arbace_reflect_parse_flags_fn__1938000032_A_init.Done() { A_arbace_reflect_parse_flags_fn__1938000032_A_init.Run(A_arbace_reflect_parse_flags_fn__1938000032_A_clinit) } }

func A_arbace_reflect_parse_flags_fn__1938000032_A_clinit() { A_arbace_reflect_parse_flags_fn__1938000032_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_123, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_parse_flags_fn__1938000032_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_parse_flags_fn__1938000032_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_parse_flags_fn__1938000032_A_class }

func (t *A_arbace_reflect_parse_flags_fn__1938000032_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_parse_flags_fn__1938000032_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_parse_flags_fn__1938000032_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_parse_flags_fn__1938000032_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_parse_flags_fn__1938000032_A); return ok }

func A_arbace_reflect_parse_flags_fn__1938000032_A_Cast(x any) *A_arbace_reflect_parse_flags_fn__1938000032_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_parse_flags_fn__1938000032_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_parse_flags_fn__1938000032_A_class)) }; return v }



type A_arbace_reflect_reflect_A struct{ jrt.Object }

func (t *A_arbace_reflect_reflect_A) Is_Compiler_AOTR1() {}

var A_arbace_reflect_reflect_A_fn_class *jrt.Class

var A_arbace_reflect_reflect_A_init jrt.ClassInit

func A_arbace_reflect_reflect_A_Init() { if !A_arbace_reflect_reflect_A_init.Done() { A_arbace_reflect_reflect_A_init.Run(A_arbace_reflect_reflect_A_clinit) } }

func A_arbace_reflect_reflect_A_clinit() { A_arbace_reflect_reflect_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_124, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_reflect_reflect_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_reflect_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_reflect_A_class }

func (t *A_arbace_reflect_reflect_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_reflect_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_reflect_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_reflect_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_reflect_A); return ok }

func A_arbace_reflect_reflect_A_Cast(x any) *A_arbace_reflect_reflect_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_reflect_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_reflect_A_class)) }; return v }



type A_arbace_reflect_resource_name_A struct{ jrt.Object }

func (t *A_arbace_reflect_resource_name_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_resource_name_A_fn_class *jrt.Class

var A_arbace_reflect_resource_name_A_init jrt.ClassInit

func A_arbace_reflect_resource_name_A_Init() { if !A_arbace_reflect_resource_name_A_init.Done() { A_arbace_reflect_resource_name_A_init.Run(A_arbace_reflect_resource_name_A_clinit) } }

func A_arbace_reflect_resource_name_A_clinit() { A_arbace_reflect_resource_name_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_resource_name_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_resource_name_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_resource_name_A_class }

func (t *A_arbace_reflect_resource_name_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_resource_name_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_resource_name_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_resource_name_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_resource_name_A); return ok }

func A_arbace_reflect_resource_name_A_Cast(x any) *A_arbace_reflect_resource_name_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_resource_name_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_resource_name_A_class)) }; return v }



type A_arbace_reflect_type_reflect_A struct{ jrt.Object }

func (t *A_arbace_reflect_type_reflect_A) Is_Compiler_AOTR1() {}

var A_arbace_reflect_type_reflect_A_fn_class *jrt.Class

var A_arbace_reflect_type_reflect_A_init jrt.ClassInit

func A_arbace_reflect_type_reflect_A_Init() { if !A_arbace_reflect_type_reflect_A_init.Done() { A_arbace_reflect_type_reflect_A_init.Run(A_arbace_reflect_type_reflect_A_clinit) } }

func A_arbace_reflect_type_reflect_A_clinit() { A_arbace_reflect_type_reflect_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_127, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_reflect_type_reflect_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_type_reflect_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_type_reflect_A_class }

func (t *A_arbace_reflect_type_reflect_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_type_reflect_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_type_reflect_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_type_reflect_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_type_reflect_A); return ok }

func A_arbace_reflect_type_reflect_A_Cast(x any) *A_arbace_reflect_type_reflect_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_type_reflect_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_type_reflect_A_class)) }; return v }



type A_arbace_reflect_type_reflect_fn__659000063_A struct{ jrt.Object }

func (t *A_arbace_reflect_type_reflect_fn__659000063_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_type_reflect_fn__659000063_A_fn_class *jrt.Class

var A_arbace_reflect_type_reflect_fn__659000063_A_init jrt.ClassInit

func A_arbace_reflect_type_reflect_fn__659000063_A_Init() { if !A_arbace_reflect_type_reflect_fn__659000063_A_init.Done() { A_arbace_reflect_type_reflect_fn__659000063_A_init.Run(A_arbace_reflect_type_reflect_fn__659000063_A_clinit) } }

func A_arbace_reflect_type_reflect_fn__659000063_A_clinit() { A_arbace_reflect_type_reflect_fn__659000063_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_type_reflect_fn__659000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_type_reflect_fn__659000063_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_type_reflect_fn__659000063_A_class }

func (t *A_arbace_reflect_type_reflect_fn__659000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_type_reflect_fn__659000063_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_type_reflect_fn__659000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_type_reflect_fn__659000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_type_reflect_fn__659000063_A); return ok }

func A_arbace_reflect_type_reflect_fn__659000063_A_Cast(x any) *A_arbace_reflect_type_reflect_fn__659000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_type_reflect_fn__659000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_type_reflect_fn__659000063_A_class)) }; return v }



type A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A struct{ jrt.Object; F_refl any }

func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_fn_class *jrt.Class

var A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_init jrt.ClassInit

func A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_Init() { if !A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_init.Done() { A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_init.Run(A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_clinit) } }

func A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_clinit() { A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_129, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_class }

func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A); return ok }

func A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_Cast(x any) *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_class)) }; return v }



type A_arbace_reflect_typeref__GT_class_A struct{ jrt.Object }

func (t *A_arbace_reflect_typeref__GT_class_A) Is_Compiler_AOTF2() {}

var A_arbace_reflect_typeref__GT_class_A_fn_class *jrt.Class

var A_arbace_reflect_typeref__GT_class_A_init jrt.ClassInit

func A_arbace_reflect_typeref__GT_class_A_Init() { if !A_arbace_reflect_typeref__GT_class_A_init.Done() { A_arbace_reflect_typeref__GT_class_A_init.Run(A_arbace_reflect_typeref__GT_class_A_clinit) } }

func A_arbace_reflect_typeref__GT_class_A_clinit() { A_arbace_reflect_typeref__GT_class_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_typeref__GT_class_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_typeref__GT_class_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_typeref__GT_class_A_class }

func (t *A_arbace_reflect_typeref__GT_class_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_typeref__GT_class_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_typeref__GT_class_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_typeref__GT_class_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_typeref__GT_class_A); return ok }

func A_arbace_reflect_typeref__GT_class_A_Cast(x any) *A_arbace_reflect_typeref__GT_class_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_typeref__GT_class_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_typeref__GT_class_A_class)) }; return v }



type A_arbace_reflect_typesym_A struct{ jrt.Object }

func (t *A_arbace_reflect_typesym_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_typesym_A_fn_class *jrt.Class

var A_arbace_reflect_typesym_A_init jrt.ClassInit

func A_arbace_reflect_typesym_A_Init() { if !A_arbace_reflect_typesym_A_init.Done() { A_arbace_reflect_typesym_A_init.Run(A_arbace_reflect_typesym_A_clinit) } }

func A_arbace_reflect_typesym_A_clinit() { A_arbace_reflect_typesym_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_131, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_typesym_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_typesym_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_typesym_A_class }

func (t *A_arbace_reflect_typesym_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_typesym_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_typesym_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_typesym_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_typesym_A); return ok }

func A_arbace_reflect_typesym_A_Cast(x any) *A_arbace_reflect_typesym_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_typesym_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_typesym_A_class)) }; return v }



type A_arbace_reflect_typesym_fn__1938000019_A struct{ jrt.Object; F_t any }

func (t *A_arbace_reflect_typesym_fn__1938000019_A) Is_Compiler_AOTF1() {}

var A_arbace_reflect_typesym_fn__1938000019_A_fn_class *jrt.Class

var A_arbace_reflect_typesym_fn__1938000019_A_init jrt.ClassInit

func A_arbace_reflect_typesym_fn__1938000019_A_Init() { if !A_arbace_reflect_typesym_fn__1938000019_A_init.Done() { A_arbace_reflect_typesym_fn__1938000019_A_init.Run(A_arbace_reflect_typesym_fn__1938000019_A_clinit) } }

func A_arbace_reflect_typesym_fn__1938000019_A_clinit() { A_arbace_reflect_typesym_fn__1938000019_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_132, lang.Compiler_AOTFn_class) }

func (t *A_arbace_reflect_typesym_fn__1938000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_typesym_fn__1938000019_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_typesym_fn__1938000019_A_class }

func (t *A_arbace_reflect_typesym_fn__1938000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_typesym_fn__1938000019_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect_typesym_fn__1938000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_typesym_fn__1938000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_typesym_fn__1938000019_A); return ok }

func A_arbace_reflect_typesym_fn__1938000019_A_Cast(x any) *A_arbace_reflect_typesym_fn__1938000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_typesym_fn__1938000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_typesym_fn__1938000019_A_class)) }; return v }
