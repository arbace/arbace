//line aot_arbace_reflect.ae:1
package aot_arbace_reflect

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_New() *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_reflect_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_reflect_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_A_const_3); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_reflect_eval659000008_fn__659000009_A_New() *A_arbace_reflect_eval659000008_fn__659000009_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000008_fn__659000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_reflect_eval659000008_fn__659000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_reflect_eval659000008_fn__659000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_reflect_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_A_const_8), A_arbace_reflect_A_const_6.GetRawRoot__O(), A_arbace_reflect_A_const_7) }










func A_arbace_reflect_eval1938000010_fn__1938000011_A_New() *A_arbace_reflect_eval1938000010_fn__1938000011_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000010_fn__1938000011_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_reflect_eval1938000010_fn__1938000011_A) Ctor() {}
//line :20:1
func (t *A_arbace_reflect_eval1938000010_fn__1938000011_A) Invoke_O_O__O(self, s__1 any) any {

	return lang.IFn_Cast(A_arbace_reflect_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_40.GetRawRoot__O()).Invoke_O__O(s__1), Lit_4, Lit_3) }
//line :20:1
func A_arbace_reflect_eval1938000014_fn__1938000015_A_New() *A_arbace_reflect_eval1938000014_fn__1938000015_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000014_fn__1938000015_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_reflect_eval1938000014_fn__1938000015_A) Ctor() {}
//line :20:1
func (t *A_arbace_reflect_eval1938000014_fn__1938000015_A) Invoke_O_O__O(self, c__1 any) any {








	if jrt.NN(jrt.Class_Cast(c__1)).IsArray__Z() {
		var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_3); var tmp2 any; var target_9 any = jrt.NN(jrt.Class_Cast(c__1)).GetComponentType__Class().Ref(); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_reflect_TypeReference_A_InstanceOf(target_9); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_9) }; tmp3 = tmp4; if tmp3 { tmp2 = A_arbace_reflect_TypeReference_A_Cast(target_9).Typename__O() } else { tmp2 = lang.IFn_Cast(A_arbace_reflect_A_const_41.GetRawRoot__O()).Invoke_O__O(target_9) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref() } else {
			return jrt.NN(jrt.Class_Cast(c__1)).GetName__String().Ref()
		} }
func A_arbace_reflect_typesym_A_New() *A_arbace_reflect_typesym_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_typesym_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_reflect_typesym_A) Ctor() {}
//line :33:1
func (t *A_arbace_reflect_typesym_A) Invoke_O_O__O(self, t__0 any) any { var G__1938000018__2_ any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_42.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_39.GetRawRoot__O()); var tmp3 any; var target_10 any = t__0; var tmp4 bool; var tmp5 bool; tmp5 =




	A_arbace_reflect_TypeReference_A_InstanceOf(target_10); if tmp5 { tmp5 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_10) }; tmp4 = tmp5; if tmp4 { tmp3 = A_arbace_reflect_TypeReference_A_Cast(target_10).Typename__O() } else { tmp3 = lang.IFn_Cast(A_arbace_reflect_A_const_41.GetRawRoot__O()).Invoke_O__O(target_10) }; G__1938000018__2_ =

	tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(tmp3, Lit_3, Lit_4)); if /*line :37:1*/ jrt.J2g_Truth(lang.IFn_Cast(A_arbace_reflect_A_const_37.GetRawRoot__O()).Invoke_O__O(t__0)) {



		var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_43.GetRawRoot__O()); var tmp7 any = A_arbace_reflect_A_const_44; var tmp8 any = A_arbace_reflect_typesym_fn__1938000019_A_New_O(t__0); var tmp9 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_reflect_typesym_fn__1938000019_A_fn_class
		if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_reflect_typesym_fn__1938000019_A_fn_class = fncls__11d; tmp9 = fncls__11d } else { tmp9 = fncls__11 }
//line :41:1
		return tmp6.Invoke_O_O__O(G__1938000018__2_, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)))) } else {
//line :37:1
			return G__1938000018__2_ } }




func A_arbace_reflect_typesym_fn__1938000019_A_New_O(p0 any) *A_arbace_reflect_typesym_fn__1938000019_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_typesym_fn__1938000019_A{}; t.Ctor_O(p0); return t }
//line :42:1
func (t *A_arbace_reflect_typesym_fn__1938000019_A) Ctor_O(c__t any) { t.F_t = c__t }
//line :42:1
func (t *A_arbace_reflect_typesym_fn__1938000019_A) Invoke_O_O__O(self, ___1 any) any { return lang.IFn_Cast(A_arbace_reflect_A_const_45.GetRawRoot__O()).Invoke_O__O(t.F_t) }

func A_arbace_reflect_eval659000020_fn__659000021_A_New() *A_arbace_reflect_eval659000020_fn__659000021_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000020_fn__659000021_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_A) Ctor() {}
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__659000013__2_ any; var tmp1 any = A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; G__659000013__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_New_O(G__659000013__2_); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :44:1
func A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_New_O(p0 any) *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A{}; t.Ctor_O(p0); return t }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) Ctor_O(c__G__659000013 any) { t.F_G__659000013 = c__G__659000013 }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A) Invoke_O_O_O__O(self, gf__reflector__659000026__1, gf__typeref__659000027__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__reflector__659000026__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__reflector__659000026__1, gf__typeref__659000027__2) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_reflect_A_const_9.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__reflector__659000026__1, A_arbace_reflect_A_const_10, t.F_G__659000013)).Invoke_O_O__O(gf__reflector__659000026__1, gf__typeref__659000027__2) } }
//line :44:1
func A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_New() *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) Ctor() {}
//line :44:1
func (t *A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A) Invoke_O_O_O__O(self, gf__reflector__659000022__1, gf__typeref__659000023__2 any) any { var target_1 any = gf__reflector__659000022__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_1 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_1) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_1, Lit_11, jrt.RefArrayOf(jrt.Object_class, gf__typeref__659000023__2)) } else { return A_arbace_reflect_Reflector_A_Cast(target_1).Do_reflect_O__O(gf__typeref__659000023__2) } }
//line :44:1
func A_arbace_reflect_resource_name_A_New() *A_arbace_reflect_resource_name_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_resource_name_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_reflect_resource_name_A) Ctor() {}
//line :44:1
func (t *A_arbace_reflect_resource_name_A) Invoke_O_O__O(self, typeref__0 any) any {





	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_18); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_39.GetRawRoot__O()); var tmp3 any; var target_12 any = typeref__0; var tmp4 bool; var tmp5 bool
//line :48:1
	tmp5 = A_arbace_reflect_TypeReference_A_InstanceOf(target_12); if tmp5 { tmp5 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_12) }; tmp4 = tmp5; if tmp4 { tmp3 = A_arbace_reflect_TypeReference_A_Cast(target_12).Typename__O() } else { tmp3 = lang.IFn_Cast(A_arbace_reflect_A_const_41.GetRawRoot__O()).Invoke_O__O(target_12)
	}
	return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2.Invoke_O_O_O__O(tmp3, Lit_2, Lit_1), nil)).Ref() }
//line :48:1
func A_arbace_reflect_eval659000044_fn__659000045_A_New() *A_arbace_reflect_eval659000044_fn__659000045_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000044_fn__659000045_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_A) Ctor() {}
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__659000037__2_ any; var tmp1 any = A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_New(); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; G__659000037__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_New_O(G__659000037__2_); var tmp4 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_fn_class = fncls__6d; tmp4 = fncls__6d } else { tmp4 = fncls__6 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :48:1
func A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_New_O(p0 any) *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) Ctor_O(c__G__659000037 any) { t.F_G__659000037 = c__G__659000037 }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A) Invoke_O_O__O(self, gf__o__659000049__1 any) any { var cache__231000236__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__o__659000049__1)); if jrt.J2g_Truth(f__231000237__auto____3) { return lang.IFn_Cast(f__231000237__auto____3).Invoke_O__O(gf__o__659000049__1) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_reflect_A_const_9.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__o__659000049__1, A_arbace_reflect_A_const_11, t.F_G__659000037)).Invoke_O__O(gf__o__659000049__1) } }
//line :48:1
func A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_New() *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) Ctor() {}
//line :48:1
func (t *A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A) Invoke_O_O__O(self, gf__o__659000046__1 any) any { var target_4 any = gf__o__659000046__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_4 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_4) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_4, Lit_14, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_reflect_TypeReference_A_Cast(target_4).Typename__O() } }



func A_arbace_reflect_access_flag_A_New() *A_arbace_reflect_access_flag_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_access_flag_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_reflect_access_flag_A) Ctor() {}
//line :52:1
func (t *A_arbace_reflect_access_flag_A) Invoke_O_O__O(self, p__1938000023__0 any) any { var vec__1938000024__2 any = p__1938000023__0; var seq__1938000025__3 any = lang.IFn_Cast(A_arbace_reflect_A_const_15.GetRawRoot__O()).Invoke_O__O(vec__1938000024__2); var first__1938000026__4 any = lang.IFn_Cast(A_arbace_reflect_A_const_16.GetRawRoot__O()).Invoke_O__O(seq__1938000025__3); var seq__1938000025__5 any = lang.IFn_Cast(A_arbace_reflect_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__1938000025__3); var name__6 any = first__1938000026__4; var first__1938000026__7 any = lang.IFn_Cast(A_arbace_reflect_A_const_16.GetRawRoot__O()).Invoke_O__O(seq__1938000025__5); var seq__1938000025__8 any = lang.IFn_Cast(A_arbace_reflect_A_const_13.GetRawRoot__O()).Invoke_O__O(seq__1938000025__5); var flag__9 any = first__1938000026__7; var contexts__10 any = seq__1938000025__8; var tmp1 any = A_arbace_reflect_A_const_46; var tmp2 any = A_arbace_reflect_A_const_47; var tmp3 any = A_arbace_reflect_A_const_48; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, name__6, tmp2, flag__9, tmp3, lang.IFn_Cast(A_arbace_reflect_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_A_const_49.GetRawRoot__O(), contexts__10)))) }



func A_arbace_reflect_descriptor_class_name_A_New() *A_arbace_reflect_descriptor_class_name_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_descriptor_class_name_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_reflect_descriptor_class_name_A) Ctor() {}
//line :56:1
func (t *A_arbace_reflect_descriptor_class_name_A) Invoke_O_O__O(self, d__0 any) any { var G__1938000028__2_ uint16 = jrt.NN(jrt.String_Cast(d__0)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0)); switch


	lang.Util_Hash_O__I_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1938000028__2_).Ref()) { case 76: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1938000028__2_).Ref(), A_arbace_reflect_A_const_50) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_54.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_A_const_55; return lang.IFn_Cast(A_arbace_reflect_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(tmp1.Invoke_O_O_O__O(d__0, tmp2, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(d__0)))).Ref()), Lit_1, Lit_2) }
//line :59:1
	case 91: if lang.Util_Equiv_O_O__Z_NoInit(jrt.Character_ValueOf_C__Character_NoInit(G__1938000028__2_).Ref(), A_arbace_reflect_A_const_51) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_3), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_reflect_A_const_52.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_54.GetRawRoot__O()).Invoke_O_O__O(d__0, A_arbace_reflect_A_const_55)), nil)).Ref() }
//line :59:1
	default:}; return /*line :62:1*/ lang.IFn_Cast(A_arbace_reflect_A_const_53).Invoke_O__O(d__0) }
//line :58:1
func A_arbace_reflect_type_reflect_A_New() *A_arbace_reflect_type_reflect_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_type_reflect_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_reflect_type_reflect_A) Ctor() {}
//line :58:1
func (t *A_arbace_reflect_type_reflect_A) DoInvoke_O_O_O__O(self, typeref__0, options__1 any) any { { var tmp1 any = A_arbace_reflect_A_const_18; var map__659000059__3 any = lang.IFn_Cast(A_arbace_reflect_A_const_12.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, A_arbace_reflect_A_const_25.GetRawRoot__O())), lang.IFn_Cast(A_arbace_reflect_A_const_24.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_A_const_26.GetRawRoot__O(), options__1)); var map__659000059__4 any





































	if lang.ISeq_InstanceOf(map__659000059__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_reflect_A_const_13.GetRawRoot__O()).Invoke_O__O(map__659000059__3)) { map__659000059__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_reflect_A_const_14.GetRawRoot__O()).Invoke_O__O(map__659000059__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_reflect_A_const_15.GetRawRoot__O()).Invoke_O__O(map__659000059__3)) { map__659000059__4 = lang.IFn_Cast(A_arbace_reflect_A_const_16.GetRawRoot__O()).Invoke_O__O(map__659000059__3) } else { map__659000059__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__659000059__4 = map__659000059__3 }
//line :58:1
	var ancestors__5 any = lang.RT_Get_O_O__O_NoInit(map__659000059__4, A_arbace_reflect_A_const_17); var reflector__6 any = lang.RT_Get_O_O__O_NoInit(map__659000059__4, A_arbace_reflect_A_const_18); var refl__7 any = lang.IFn_Cast(A_arbace_reflect_A_const_19.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_A_const_27.GetRawRoot__O(), reflector__6); var result__8 any = lang.IFn_Cast(refl__7).Invoke_O__O(typeref__0)











































	if jrt.J2g_Truth(ancestors__5) { var make_ancestor_map__9 any; var tmp2 any = A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_New_O(refl__7); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_fn_class
		if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; make_ancestor_map__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :102:1
		var reflections__10 any = lang.IFn_Cast(make_ancestor_map__9).Invoke_O__O(A_arbace_reflect_A_const_28.Invoke_O__O(result__8)); L1: for { var ancestors_visited__11 any = lang.IFn_Cast(A_arbace_reflect_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_29.GetRawRoot__O()).Invoke_O__O(reflections__10)); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_30.GetRawRoot__O()); var tmp5 any = A_arbace_reflect_A_const_28; var ancestors_to_visit__12 any = lang.IFn_Cast(A_arbace_reflect_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_22.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_reflect_A_const_31.GetRawRoot__O()).Invoke_O__O(reflections__10))), ancestors_visited__11)






			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_reflect_A_const_15.GetRawRoot__O()).Invoke_O__O(ancestors_to_visit__12)) {
				reflections__10 = lang.IFn_Cast(A_arbace_reflect_A_const_12.GetRawRoot__O()).Invoke_O_O__O(reflections__10, lang.IFn_Cast(make_ancestor_map__9).Invoke_O__O(ancestors_to_visit__12)); continue L1 } else {
					var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_24.GetRawRoot__O()); var tmp7 any = A_arbace_reflect_A_const_32.GetRawRoot__O(); var tmp8 any = A_arbace_reflect_A_const_33.GetRawRoot__O(); var tmp9 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_reflect_A_const_17, ancestors_visited__11)); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_21.GetRawRoot__O()); var tmp11 any = A_arbace_reflect_type_reflect_fn__659000063_A_New(); var tmp12 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_reflect_type_reflect_fn__659000063_A_fn_class
					if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_reflect_type_reflect_fn__659000063_A_fn_class = fncls__8d; tmp12 = fncls__8d } else { tmp12 = fncls__8 }
//line :111:1
					return tmp6.Invoke_O_O_O_O_O__O(tmp7, tmp8, result__8, tmp9, tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), lang.IFn_Cast(A_arbace_reflect_A_const_31.GetRawRoot__O()).Invoke_O__O(reflections__10))) } } } else {
//line :102:1
						return result__8 } }; /*line :58:1*/panic("j2g: unreachable") }






func A_arbace_reflect_field_descriptor__GT_class_symbol_A_New() *A_arbace_reflect_field_descriptor__GT_class_symbol_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_field_descriptor__GT_class_symbol_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) Ctor() {}
//line :65:1
func (t *A_arbace_reflect_field_descriptor__GT_class_symbol_A) Invoke_O_O__O(self, d__0 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_reflect_A_const_56.GetRawRoot__O()).Invoke_O__O(d__0)) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_reflect_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_A_const_58))).Ref())))
}




	return lang.IFn_Cast(A_arbace_reflect_A_const_42.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_52.GetRawRoot__O()).Invoke_O__O(d__0), Lit_3, Lit_4))
}
func A_arbace_reflect_internal_name__GT_class_symbol_A_New() *A_arbace_reflect_internal_name__GT_class_symbol_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_internal_name__GT_class_symbol_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) Ctor() {}
//line :73:1
func (t *A_arbace_reflect_internal_name__GT_class_symbol_A) Invoke_O_O__O(self, d__0 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_reflect_A_const_56.GetRawRoot__O()).Invoke_O__O(d__0)) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_reflect_A_const_57.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect_A_const_59))).Ref())))
}






	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_42.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_39.GetRawRoot__O()); var tmp3 any; if jrt.NN(jrt.String_Cast(d__0)).StartsWith_String__Z(Lit_16) { tmp3 = lang.IFn_Cast(A_arbace_reflect_A_const_52.GetRawRoot__O()).Invoke_O__O(d__0) } else { tmp3 = lang.IFn_Cast(A_arbace_reflect_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(d__0, Lit_1, Lit_2) }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(tmp3, Lit_3, Lit_4))
}




















func A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_New_O(p0 any) *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A{}; t.Ctor_O(p0); return t }
//line :103:1
func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) Ctor_O(c__refl any) { t.F_refl = c__refl }
//line :103:1
func (t *A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A) Invoke_O_O__O(self, names__1 any) any {
	return lang.IFn_Cast(A_arbace_reflect_A_const_20.GetRawRoot__O()).Invoke_O_O__O(names__1, lang.IFn_Cast(A_arbace_reflect_A_const_21.GetRawRoot__O()).Invoke_O_O__O(t.F_refl, names__1))
}




func A_arbace_reflect_parse_flags_A_New() *A_arbace_reflect_parse_flags_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_parse_flags_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_reflect_parse_flags_A) Ctor() {}
//line :110:1
func (t *A_arbace_reflect_parse_flags_A) Invoke_O_O_O__O(self, flags__0, context__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_60.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_parse_flags_fn__1938000032_A_New_O_O(flags__0, context__1); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_reflect_parse_flags_fn__1938000032_A_fn_class
	if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_reflect_parse_flags_fn__1938000032_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }
//line :113:1
	var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any = lang.PersistentHashSet_EMPTY.Ref(); return tmp1.Invoke_O_O_O__O(tmp4, tmp5, A_arbace_reflect_A_const_62.GetRawRoot__O()) }
//line :112:1
func A_arbace_reflect_type_reflect_fn__659000063_A_New() *A_arbace_reflect_type_reflect_fn__659000063_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_type_reflect_fn__659000063_A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_reflect_type_reflect_fn__659000063_A) Ctor() {}
//line :112:1
func (t *A_arbace_reflect_type_reflect_fn__659000063_A) Invoke_O_O__O(self, p1__659000058_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_reflect_A_const_34.GetRawRoot__O()).Invoke_O_O__O(p1__659000058_SHARP___1, A_arbace_reflect_A_const_35) }

func A_arbace_reflect_parse_flags_fn__1938000032_A_New_O_O(p0, p1 any) *A_arbace_reflect_parse_flags_fn__1938000032_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_parse_flags_fn__1938000032_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_reflect_parse_flags_fn__1938000032_A) Ctor_O_O(c__flags, c__context any) { t.F_flags = c__flags; t.F_context = c__context }
//line :114:1
func (t *A_arbace_reflect_parse_flags_fn__1938000032_A) Invoke_O_O_O__O(self, result__1, fd__2 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.RT_Get_O_O__O_NoInit(A_arbace_reflect_A_const_48.Invoke_O__O(fd__2), t.F_context); if jrt.J2g_Truth(and__1927000168__auto____3) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_61.GetRawRoot__O()); var tmp3 int64; var na_14 any = t.F_flags; var na_15 any = A_arbace_reflect_A_const_47.Invoke_O__O(fd__2); var tmp4 bool; var tmp5 bool; tmp5 = jrt.Long_InstanceOf(na_14); if tmp5 { tmp5 = jrt.Long_InstanceOf(na_15) }; tmp4 = tmp5; if tmp4 { var n0_16 int64 = jrt.NN(jrt.Long_Cast(na_14)).LongValue__J(); var n1_17 int64 = jrt.NN(jrt.Long_Cast(na_15)).LongValue__J(); tmp3 = n0_16 & n1_17 } else { tmp3 = lang.Numbers_And_O_O__J_NoInit(na_14, na_15) }; tmp1 = tmp2.Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp3)).Ref()) } else {
//line :115:1
			tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {

				return lang.IFn_Cast(A_arbace_reflect_A_const_6.GetRawRoot__O()).Invoke_O_O__O(result__1, A_arbace_reflect_A_const_46.Invoke_O__O(fd__2)) } else {
//line :115:1
					return result__1 } }
//line :115:1
func A_arbace_reflect_reflect_A_New() *A_arbace_reflect_reflect_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_reflect_A{}; t.Ctor(); return t }
//line :115:1
func (t *A_arbace_reflect_reflect_A) Ctor() {}
//line :115:1
func (t *A_arbace_reflect_reflect_A) DoInvoke_O_O_O__O(self, obj__0, options__1 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect_A_const_24.GetRawRoot__O()); var tmp2 any = A_arbace_reflect_A_const_36.GetRawRoot__O(); var tmp3 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_reflect_A_const_37.GetRawRoot__O()).Invoke_O__O(obj__0)) { tmp3 = obj__0 } else { tmp3 = lang.IFn_Cast(A_arbace_reflect_A_const_38.GetRawRoot__O()).Invoke_O__O(obj__0) }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, options__1) }
func A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_New() *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A) Ctor() {}
//line :122:1
func (t *A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A) Invoke_O_O_O_O_O_O__O(self, name__1, declaring_class__2, parameter_types__3, exception_types__4, flags__5 any) any { return A_arbace_reflect_Constructor_A_New_O_O_O_O_O(name__1, declaring_class__2, parameter_types__3, exception_types__4, flags__5) }
//line :122:1
func A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_New() *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A) Ctor() {}
//line :122:1
func (t *A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A) Invoke_O_O__O(self, m__231000174__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000174__auto____1) { tmp1 = m__231000174__auto____1 } else { tmp1 = lang.IFn_Cast(A_arbace_reflect_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.PersistentArrayMap_EMPTY.Ref(), m__231000174__auto____1) }; return A_arbace_reflect_Constructor_A_Create_IPersistentMap__A_arbace_reflect_Constructor_A(lang.IPersistentMap_Cast(tmp1)).Ref() }


func A_arbace_reflect_constructor__GT_map_A_New() *A_arbace_reflect_constructor__GT_map_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_constructor__GT_map_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_reflect_constructor__GT_map_A) Ctor() {}
//line :125:1
func (t *A_arbace_reflect_constructor__GT_map_A) Invoke_O_O__O(self, constructor__0 any) any { return A_arbace_reflect_Constructor_A_New_O_O_O_O_O(lang.IFn_Cast(A_arbace_reflect_A_const_42.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Constructor_Cast(constructor__0)).GetName__String().Ref()), lang.IFn_Cast(A_arbace_reflect_A_const_63.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Constructor_Cast(constructor__0)).GetDeclaringClass__Class().Ref()), lang.IFn_Cast(A_arbace_reflect_A_const_64.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_A_const_63.GetRawRoot__O(), jrt.NN(jrt.Constructor_Cast(constructor__0)).GetParameterTypes__Class1().Ref())), lang.IFn_Cast(A_arbace_reflect_A_const_64.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_A_const_63.GetRawRoot__O(), jrt.NN(jrt.Constructor_Cast(constructor__0)).GetExceptionTypes__Class1().Ref())), lang.IFn_Cast(A_arbace_reflect_A_const_65.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Constructor_Cast(constructor__0)).GetModifiers__I()).Ref(), A_arbace_reflect_A_const_66)) }








func A_arbace_reflect_declared_constructors_A_New() *A_arbace_reflect_declared_constructors_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_declared_constructors_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_reflect_declared_constructors_A) Ctor() {}
//line :134:1
func (t *A_arbace_reflect_declared_constructors_A) Invoke_O_O__O(self, cls__0 any) any {


	return lang.IFn_Cast(A_arbace_reflect_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_A_const_67.GetRawRoot__O(), jrt.NN(jrt.Class_Cast(cls__0)).GetDeclaredConstructors__Constructor1().Ref()))
}


func A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_New() *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000060___GT_Method__1938000078_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A) Ctor() {}
//line :141:1
func (t *A_arbace_reflect_eval1938000060___GT_Method__1938000078_A) Invoke_O_O_O_O_O_O_O__O(self, name__1, return_type__2, declaring_class__3, parameter_types__4, exception_types__5, flags__6 any) any { return A_arbace_reflect_Method_A_New_O_O_O_O_O_O(name__1, return_type__2, declaring_class__3, parameter_types__4, exception_types__5, flags__6) }
//line :141:1
func A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_New() *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A) Ctor() {}
//line :141:1
func (t *A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A) Invoke_O_O__O(self, m__231000174__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000174__auto____1) { tmp1 = m__231000174__auto____1 } else { tmp1 = lang.IFn_Cast(A_arbace_reflect_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.PersistentArrayMap_EMPTY.Ref(), m__231000174__auto____1) }; return A_arbace_reflect_Method_A_Create_IPersistentMap__A_arbace_reflect_Method_A(lang.IPersistentMap_Cast(tmp1)).Ref() }


func A_arbace_reflect_method__GT_map_A_New() *A_arbace_reflect_method__GT_map_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_method__GT_map_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_reflect_method__GT_map_A) Ctor() {}
//line :144:1
func (t *A_arbace_reflect_method__GT_map_A) Invoke_O_O__O(self, method__0 any) any { return A_arbace_reflect_Method_A_New_O_O_O_O_O_O(lang.IFn_Cast(A_arbace_reflect_A_const_42.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(method__0)).GetName__String().Ref()), lang.IFn_Cast(A_arbace_reflect_A_const_63.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(method__0)).GetReturnType__Class().Ref()), lang.IFn_Cast(A_arbace_reflect_A_const_63.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(method__0)).GetDeclaringClass__Class().Ref()), lang.IFn_Cast(A_arbace_reflect_A_const_64.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_A_const_63.GetRawRoot__O(), jrt.NN(jrt.Method_Cast(method__0)).GetParameterTypes__Class1().Ref())), lang.IFn_Cast(A_arbace_reflect_A_const_64.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_A_const_63.GetRawRoot__O(), jrt.NN(jrt.Method_Cast(method__0)).GetExceptionTypes__Class1().Ref())), lang.IFn_Cast(A_arbace_reflect_A_const_65.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Method_Cast(method__0)).GetModifiers__I()).Ref(), A_arbace_reflect_A_const_66)) }









func A_arbace_reflect_declared_methods_A_New() *A_arbace_reflect_declared_methods_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_declared_methods_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_reflect_declared_methods_A) Ctor() {}
//line :154:1
func (t *A_arbace_reflect_declared_methods_A) Invoke_O_O__O(self, cls__0 any) any {


	return lang.IFn_Cast(A_arbace_reflect_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_A_const_68.GetRawRoot__O(), jrt.NN(jrt.Class_Cast(cls__0)).GetDeclaredMethods__Method1().Ref()))
}


func A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_New() *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000086___GT_Field__1938000100_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A) Ctor() {}
//line :161:1
func (t *A_arbace_reflect_eval1938000086___GT_Field__1938000100_A) Invoke_O_O_O_O_O__O(self, name__1, type__2, declaring_class__3, flags__4 any) any { return A_arbace_reflect_Field_A_New_O_O_O_O(name__1, type__2, declaring_class__3, flags__4) }
//line :161:1
func A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_New() *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A) Ctor() {}
//line :161:1
func (t *A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A) Invoke_O_O__O(self, m__231000174__auto____1 any) any { var tmp1 any; if lang.MapEquivalence_InstanceOf(m__231000174__auto____1) { tmp1 = m__231000174__auto____1 } else { tmp1 = lang.IFn_Cast(A_arbace_reflect_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.PersistentArrayMap_EMPTY.Ref(), m__231000174__auto____1) }; return A_arbace_reflect_Field_A_Create_IPersistentMap__A_arbace_reflect_Field_A(lang.IPersistentMap_Cast(tmp1)).Ref() }


func A_arbace_reflect_field__GT_map_A_New() *A_arbace_reflect_field__GT_map_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_field__GT_map_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_reflect_field__GT_map_A) Ctor() {}
//line :164:1
func (t *A_arbace_reflect_field__GT_map_A) Invoke_O_O__O(self, field__0 any) any { return A_arbace_reflect_Field_A_New_O_O_O_O(lang.IFn_Cast(A_arbace_reflect_A_const_42.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(field__0)).GetName__String().Ref()), lang.IFn_Cast(A_arbace_reflect_A_const_63.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(field__0)).GetType__Class().Ref()), lang.IFn_Cast(A_arbace_reflect_A_const_63.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(field__0)).GetDeclaringClass__Class().Ref()), lang.IFn_Cast(A_arbace_reflect_A_const_65.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.Field_Cast(field__0)).GetModifiers__I()).Ref(), A_arbace_reflect_A_const_69)) }







func A_arbace_reflect_declared_fields_A_New() *A_arbace_reflect_declared_fields_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_declared_fields_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_reflect_declared_fields_A) Ctor() {}
//line :172:1
func (t *A_arbace_reflect_declared_fields_A) Invoke_O_O__O(self, cls__0 any) any {


	return lang.IFn_Cast(A_arbace_reflect_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_A_const_70.GetRawRoot__O(), jrt.NN(jrt.Class_Cast(cls__0)).GetDeclaredFields__Field1().Ref()))
}


func A_arbace_reflect_typeref__GT_class_A_New() *A_arbace_reflect_typeref__GT_class_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_typeref__GT_class_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_reflect_typeref__GT_class_A) Ctor() {}
//line :179:1
func (t *A_arbace_reflect_typeref__GT_class_A) Invoke_O_O_O__O(self, typeref__0, classloader__1 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_reflect_A_const_37.GetRawRoot__O()).Invoke_O__O(typeref__0)) { return typeref__0 } else {

		var tmp1 any; var target_20 any = typeref__0; var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_reflect_TypeReference_A_InstanceOf(target_20); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_20) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_reflect_TypeReference_A_Cast(target_20).Typename__O() } else { tmp1 = lang.IFn_Cast(A_arbace_reflect_A_const_41.GetRawRoot__O()).Invoke_O__O(target_20) }; return lang.RT_ClassForName_String_Z_ClassLoader__Class_NoInit(jrt.String_Cast(tmp1), jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), jrt.ClassLoader_Cast(classloader__1)).Ref()
	} }
func A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_New() *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A{}; t.Ctor(); return t }
//line :185:1
func (t *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A) Ctor() {}
//line :185:1
func (t *A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A) Invoke_O_O__O(self, classloader__1 any) any { return A_arbace_reflect_JavaReflector_A_New_O(classloader__1) }












func A_arbace_reflect_eval1938000121_fn__1938000122_A_New() *A_arbace_reflect_eval1938000121_fn__1938000122_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000121_fn__1938000122_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_A) Ctor() {}
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1938000114__2_ any; var tmp1 any = A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_New(); var tmp2 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; G__1938000114__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_New_O(G__1938000114__2_); var tmp4 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_fn_class = fncls__23d; tmp4 = fncls__23d } else { tmp4 = fncls__23 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :198:1
func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_New_O(p0 any) *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A{}; t.Ctor_O(p0); return t }
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A) Ctor_O(c__G__1938000114 any) { t.F_G__1938000114 = c__G__1938000114 }
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A) Invoke_O_O_O__O(self, gf__this__1938000127__1, gf__name__1938000128__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__this__1938000127__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__this__1938000127__1, gf__name__1938000128__2) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_reflect_A_const_9.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__this__1938000127__1, A_arbace_reflect_A_const_71, t.F_G__1938000114)).Invoke_O_O__O(gf__this__1938000127__1, gf__name__1938000128__2) } }
//line :198:1
func A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_New() *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A) Ctor() {}
//line :198:1
func (t *A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A) Invoke_O_O_O__O(self, gf__this__1938000123__1, gf__name__1938000124__2 any) any { var target_21 any = gf__this__1938000123__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_21 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_21) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_21, Lit_7, jrt.RefArrayOf(jrt.Object_class, gf__name__1938000124__2)) } else { return A_arbace_reflect_ClassResolver_A_Cast(target_21).Resolve_class_O__O(gf__name__1938000124__2) } }



func A_arbace_reflect_eval1938000137_fn__1938000138_A_New() *A_arbace_reflect_eval1938000137_fn__1938000138_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000137_fn__1938000138_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_reflect_eval1938000137_fn__1938000138_A) Ctor() {}
//line :202:1
func (t *A_arbace_reflect_eval1938000137_fn__1938000138_A) Invoke_O_O_O__O(self, this__1, typeref__2 any) any {

	return lang.IFn_Cast(this__1).Invoke_O__O(typeref__2) }
//line :202:1
func A_arbace_reflect_eval1938000141_fn__1938000142_A_New() *A_arbace_reflect_eval1938000141_fn__1938000142_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000141_fn__1938000142_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_reflect_eval1938000141_fn__1938000142_A) Ctor() {}
//line :202:1
func (t *A_arbace_reflect_eval1938000141_fn__1938000142_A) Invoke_O_O_O__O(self, this__1, typeref__2 any) any {





	var tmp1 *jrt.Class = A_arbace_reflect_A_const_72; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(this__1, tmp1, Lit_8, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_reflect_A_const_73.GetRawRoot__O()).Invoke_O__O(typeref__2)))
}



func A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_New() *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A) Ctor() {}
//line :213:1
func (t *A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A) Invoke_O_O__O(self, class_resolver__1 any) any { return A_arbace_reflect_AsmReflector_A_New_O(class_resolver__1) }


























































type A_arbace_reflect_A struct{ jrt.Object }

var A_arbace_reflect_A_const_pool *jrt.RefArray

var A_arbace_reflect_A_const_0 *lang.Var

var A_arbace_reflect_A_const_1 *lang.Var

var A_arbace_reflect_A_const_2 any

var A_arbace_reflect_A_const_3 any

var A_arbace_reflect_A_const_4 *lang.Var

var A_arbace_reflect_A_const_5 *lang.Var

var A_arbace_reflect_A_const_6 *lang.Var

var A_arbace_reflect_A_const_7 any

var A_arbace_reflect_A_const_8 *lang.Var

var A_arbace_reflect_A_const_9 *lang.Var

var A_arbace_reflect_A_const_10 *jrt.Class

var A_arbace_reflect_A_const_11 *jrt.Class

var A_arbace_reflect_A_const_12 *lang.Var

var A_arbace_reflect_A_const_13 *lang.Var

var A_arbace_reflect_A_const_14 *lang.Var

var A_arbace_reflect_A_const_15 *lang.Var

var A_arbace_reflect_A_const_16 *lang.Var

var A_arbace_reflect_A_const_17 *lang.Keyword

var A_arbace_reflect_A_const_18 *lang.Keyword

var A_arbace_reflect_A_const_19 *lang.Var

var A_arbace_reflect_A_const_20 *lang.Var

var A_arbace_reflect_A_const_21 *lang.Var

var A_arbace_reflect_A_const_22 *lang.Var

var A_arbace_reflect_A_const_23 *lang.Var

var A_arbace_reflect_A_const_24 *lang.Var

var A_arbace_reflect_A_const_25 *lang.Var

var A_arbace_reflect_A_const_26 *lang.Var

var A_arbace_reflect_A_const_27 *lang.Var

var A_arbace_reflect_A_const_28 *lang.Keyword

var A_arbace_reflect_A_const_29 *lang.Var

var A_arbace_reflect_A_const_30 *lang.Var

var A_arbace_reflect_A_const_31 *lang.Var

var A_arbace_reflect_A_const_32 *lang.Var

var A_arbace_reflect_A_const_33 *lang.Var

var A_arbace_reflect_A_const_34 *lang.Var

var A_arbace_reflect_A_const_35 any

var A_arbace_reflect_A_const_36 *lang.Var

var A_arbace_reflect_A_const_37 *lang.Var

var A_arbace_reflect_A_const_38 *lang.Var

var A_arbace_reflect_A_const_39 *lang.Var

var A_arbace_reflect_A_const_40 *lang.Var

var A_arbace_reflect_A_const_41 *lang.Var

var A_arbace_reflect_A_const_42 *lang.Var

var A_arbace_reflect_A_const_43 *lang.Var

var A_arbace_reflect_A_const_44 any

var A_arbace_reflect_A_const_45 *lang.Var

var A_arbace_reflect_A_const_46 *lang.Keyword

var A_arbace_reflect_A_const_47 *lang.Keyword

var A_arbace_reflect_A_const_48 *lang.Keyword

var A_arbace_reflect_A_const_49 *lang.Var

var A_arbace_reflect_A_const_50 any

var A_arbace_reflect_A_const_51 any

var A_arbace_reflect_A_const_52 *lang.Var

var A_arbace_reflect_A_const_53 any

var A_arbace_reflect_A_const_54 *lang.Var

var A_arbace_reflect_A_const_55 any

var A_arbace_reflect_A_const_56 *lang.Var

var A_arbace_reflect_A_const_57 *lang.Var

var A_arbace_reflect_A_const_58 any

var A_arbace_reflect_A_const_59 any

var A_arbace_reflect_A_const_60 *lang.Var

var A_arbace_reflect_A_const_61 *lang.Var

var A_arbace_reflect_A_const_62 *lang.Var

var A_arbace_reflect_A_const_63 *lang.Var

var A_arbace_reflect_A_const_64 *lang.Var

var A_arbace_reflect_A_const_65 *lang.Var

var A_arbace_reflect_A_const_66 *lang.Keyword

var A_arbace_reflect_A_const_67 *lang.Var

var A_arbace_reflect_A_const_68 *lang.Var

var A_arbace_reflect_A_const_69 *lang.Keyword

var A_arbace_reflect_A_const_70 *lang.Var

var A_arbace_reflect_A_const_71 *jrt.Class

var A_arbace_reflect_A_const_72 *jrt.Class

var A_arbace_reflect_A_const_73 *lang.Var

var A_arbace_reflect_A_init jrt.ClassInit

func A_arbace_reflect_A_Init() { if !A_arbace_reflect_A_init.Done() { A_arbace_reflect_A_init.Run(A_arbace_reflect_A_clinit) } }

func A_arbace_reflect_A_clinit() { A_arbace_reflect_A_clinit_p0(); A_arbace_reflect_A_clinit_p1(); A_arbace_reflect_A_clinit_p2(); A_arbace_reflect_A_clinit_p3(); A_arbace_reflect_A_clinit_p4(); A_arbace_reflect_A_clinit_p5(); A_arbace_reflect_A_clinit_p6() }

func A_arbace_reflect_A_clinit_p0() { jrt.StartCheck(); A_arbace_reflect_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 95); A_arbace_reflect_A_const_0 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[21]); A_arbace_reflect_A_const_1 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[22]); A_arbace_reflect_A_const_2 = A_arbace_reflect_A_const_pool.A[23]; A_arbace_reflect_A_const_3 = A_arbace_reflect_A_const_pool.A[24]; A_arbace_reflect_A_const_4 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[25]); A_arbace_reflect_A_const_5 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[26]); A_arbace_reflect_A_const_6 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[27]); A_arbace_reflect_A_const_7 = A_arbace_reflect_A_const_pool.A[28]; A_arbace_reflect_A_const_8 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[29]); A_arbace_reflect_A_const_9 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[30]); A_arbace_reflect_A_const_10 = jrt.Class_Cast(A_arbace_reflect_A_const_pool.A[31]); A_arbace_reflect_A_const_11 = jrt.Class_Cast(A_arbace_reflect_A_const_pool.A[32]) }

func A_arbace_reflect_A_clinit_p1() { A_arbace_reflect_A_const_12 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[33]); A_arbace_reflect_A_const_13 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[34]); A_arbace_reflect_A_const_14 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[35]); A_arbace_reflect_A_const_15 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[36]); A_arbace_reflect_A_const_16 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[37]); A_arbace_reflect_A_const_17 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[38]); A_arbace_reflect_A_const_18 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[39]); A_arbace_reflect_A_const_19 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[40]); A_arbace_reflect_A_const_20 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[41]); A_arbace_reflect_A_const_21 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[42]); A_arbace_reflect_A_const_22 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[43]); A_arbace_reflect_A_const_23 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[44]) }

func A_arbace_reflect_A_clinit_p2() { A_arbace_reflect_A_const_24 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[45]); A_arbace_reflect_A_const_25 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[46]); A_arbace_reflect_A_const_26 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[47]); A_arbace_reflect_A_const_27 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[48]); A_arbace_reflect_A_const_28 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[49]); A_arbace_reflect_A_const_29 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[50]); A_arbace_reflect_A_const_30 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[51]); A_arbace_reflect_A_const_31 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[52]); A_arbace_reflect_A_const_32 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[53]); A_arbace_reflect_A_const_33 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[54]); A_arbace_reflect_A_const_34 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[55]); A_arbace_reflect_A_const_35 = A_arbace_reflect_A_const_pool.A[56] }

func A_arbace_reflect_A_clinit_p3() { A_arbace_reflect_A_const_36 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[57]); A_arbace_reflect_A_const_37 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[58]); A_arbace_reflect_A_const_38 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[59]); A_arbace_reflect_A_const_39 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[60]); A_arbace_reflect_A_const_40 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[61]); A_arbace_reflect_A_const_41 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[62]); A_arbace_reflect_A_const_42 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[63]); A_arbace_reflect_A_const_43 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[64]); A_arbace_reflect_A_const_44 = A_arbace_reflect_A_const_pool.A[65]; A_arbace_reflect_A_const_45 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[66]); A_arbace_reflect_A_const_46 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[67]); A_arbace_reflect_A_const_47 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[68]) }

func A_arbace_reflect_A_clinit_p4() { A_arbace_reflect_A_const_48 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[69]); A_arbace_reflect_A_const_49 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[70]); A_arbace_reflect_A_const_50 = A_arbace_reflect_A_const_pool.A[71]; A_arbace_reflect_A_const_51 = A_arbace_reflect_A_const_pool.A[72]; A_arbace_reflect_A_const_52 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[73]); A_arbace_reflect_A_const_53 = A_arbace_reflect_A_const_pool.A[74]; A_arbace_reflect_A_const_54 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[75]); A_arbace_reflect_A_const_55 = A_arbace_reflect_A_const_pool.A[76]; A_arbace_reflect_A_const_56 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[77]); A_arbace_reflect_A_const_57 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[78]); A_arbace_reflect_A_const_58 = A_arbace_reflect_A_const_pool.A[79]; A_arbace_reflect_A_const_59 = A_arbace_reflect_A_const_pool.A[80]; A_arbace_reflect_A_const_60 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[81]) }

func A_arbace_reflect_A_clinit_p5() { A_arbace_reflect_A_const_61 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[82]); A_arbace_reflect_A_const_62 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[83]); A_arbace_reflect_A_const_63 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[84]); A_arbace_reflect_A_const_64 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[85]); A_arbace_reflect_A_const_65 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[86]); A_arbace_reflect_A_const_66 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[87]); A_arbace_reflect_A_const_67 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[88]); A_arbace_reflect_A_const_68 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[89]); A_arbace_reflect_A_const_69 = lang.Keyword_Cast(A_arbace_reflect_A_const_pool.A[90]); A_arbace_reflect_A_const_70 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[91]); A_arbace_reflect_A_const_71 = jrt.Class_Cast(A_arbace_reflect_A_const_pool.A[92]); A_arbace_reflect_A_const_72 = jrt.Class_Cast(A_arbace_reflect_A_const_pool.A[93]) }

func A_arbace_reflect_A_clinit_p6() { A_arbace_reflect_A_const_73 = lang.Var_Cast(A_arbace_reflect_A_const_pool.A[94]) }

func A_arbace_reflect_A_New() *A_arbace_reflect_A { A_arbace_reflect_A_Init(); t := &A_arbace_reflect_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_A) Ctor() {}

func (t *A_arbace_reflect_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_A_class }

func (t *A_arbace_reflect_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_A); return ok }

func A_arbace_reflect_A_Cast(x any) *A_arbace_reflect_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_A_class)) }; return v }



type A_arbace_reflect_access_flag_A struct{ j2g_header uint64 }

var A_arbace_reflect_access_flag_A_fn_class *jrt.Class



type A_arbace_reflect_constructor__GT_map_A struct{ j2g_header uint64 }

var A_arbace_reflect_constructor__GT_map_A_fn_class *jrt.Class



type A_arbace_reflect_declared_constructors_A struct{ j2g_header uint64 }

var A_arbace_reflect_declared_constructors_A_fn_class *jrt.Class



type A_arbace_reflect_declared_fields_A struct{ j2g_header uint64 }

var A_arbace_reflect_declared_fields_A_fn_class *jrt.Class



type A_arbace_reflect_declared_methods_A struct{ j2g_header uint64 }

var A_arbace_reflect_declared_methods_A_fn_class *jrt.Class



type A_arbace_reflect_descriptor_class_name_A struct{ j2g_header uint64 }

var A_arbace_reflect_descriptor_class_name_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000010_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000010_A_New() *A_arbace_reflect_eval1938000010_A { t := &A_arbace_reflect_eval1938000010_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000010_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000010_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000010_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000010_A_class }

func (t *A_arbace_reflect_eval1938000010_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000010_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000010_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000010_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000010_A); return ok }

func A_arbace_reflect_eval1938000010_A_Cast(x any) *A_arbace_reflect_eval1938000010_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000010_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000010_A_class)) }; return v }



type A_arbace_reflect_eval1938000010_fn__1938000011_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000010_fn__1938000011_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000014_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000014_A_New() *A_arbace_reflect_eval1938000014_A { t := &A_arbace_reflect_eval1938000014_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000014_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000014_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000014_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000014_A_class }

func (t *A_arbace_reflect_eval1938000014_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000014_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000014_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000014_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000014_A); return ok }

func A_arbace_reflect_eval1938000014_A_Cast(x any) *A_arbace_reflect_eval1938000014_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000014_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000014_A_class)) }; return v }



type A_arbace_reflect_eval1938000014_fn__1938000015_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000014_fn__1938000015_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000036_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000036_A_New() *A_arbace_reflect_eval1938000036_A { t := &A_arbace_reflect_eval1938000036_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000036_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000036_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000036_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000036_A_class }

func (t *A_arbace_reflect_eval1938000036_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000036_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000036_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000036_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000036_A); return ok }

func A_arbace_reflect_eval1938000036_A_Cast(x any) *A_arbace_reflect_eval1938000036_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000036_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000036_A_class)) }; return v }



type A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000036___GT_Constructor__1938000052_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000036_map__GT_Constructor__1938000054_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000060_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000060_A_New() *A_arbace_reflect_eval1938000060_A { t := &A_arbace_reflect_eval1938000060_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000060_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000060_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000060_A_class }

func (t *A_arbace_reflect_eval1938000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000060_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000060_A); return ok }

func A_arbace_reflect_eval1938000060_A_Cast(x any) *A_arbace_reflect_eval1938000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000060_A_class)) }; return v }



type A_arbace_reflect_eval1938000060___GT_Method__1938000078_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000060___GT_Method__1938000078_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000060_map__GT_Method__1938000080_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000086_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000086_A_New() *A_arbace_reflect_eval1938000086_A { t := &A_arbace_reflect_eval1938000086_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000086_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000086_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000086_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000086_A_class }

func (t *A_arbace_reflect_eval1938000086_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000086_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000086_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000086_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000086_A); return ok }

func A_arbace_reflect_eval1938000086_A_Cast(x any) *A_arbace_reflect_eval1938000086_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000086_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000086_A_class)) }; return v }



type A_arbace_reflect_eval1938000086___GT_Field__1938000100_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000086___GT_Field__1938000100_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000086_map__GT_Field__1938000102_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000108_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000108_A_New() *A_arbace_reflect_eval1938000108_A { t := &A_arbace_reflect_eval1938000108_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000108_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000108_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000108_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000108_A_class }

func (t *A_arbace_reflect_eval1938000108_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000108_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000108_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000108_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000108_A); return ok }

func A_arbace_reflect_eval1938000108_A_Cast(x any) *A_arbace_reflect_eval1938000108_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000108_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000108_A_class)) }; return v }



type A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000108___GT_JavaReflector__1938000110_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000121_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000121_A_New() *A_arbace_reflect_eval1938000121_A { t := &A_arbace_reflect_eval1938000121_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000121_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000121_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000121_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000121_A_class }

func (t *A_arbace_reflect_eval1938000121_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000121_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000121_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000121_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000121_A); return ok }

func A_arbace_reflect_eval1938000121_A_Cast(x any) *A_arbace_reflect_eval1938000121_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000121_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000121_A_class)) }; return v }



type A_arbace_reflect_eval1938000121_fn__1938000122_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000121_fn__1938000122_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A struct{ j2g_header uint64; F_G__1938000114 any }

var A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000113__1938000129_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000121_fn__1938000122_G__1938000114__1938000125_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000137_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000137_A_New() *A_arbace_reflect_eval1938000137_A { t := &A_arbace_reflect_eval1938000137_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000137_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000137_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000137_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000137_A_class }

func (t *A_arbace_reflect_eval1938000137_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000137_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000137_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000137_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000137_A); return ok }

func A_arbace_reflect_eval1938000137_A_Cast(x any) *A_arbace_reflect_eval1938000137_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000137_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000137_A_class)) }; return v }



type A_arbace_reflect_eval1938000137_fn__1938000138_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000137_fn__1938000138_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000141_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000141_A_New() *A_arbace_reflect_eval1938000141_A { t := &A_arbace_reflect_eval1938000141_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000141_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000141_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000141_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000141_A_class }

func (t *A_arbace_reflect_eval1938000141_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000141_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000141_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000141_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000141_A); return ok }

func A_arbace_reflect_eval1938000141_A_Cast(x any) *A_arbace_reflect_eval1938000141_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000141_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000141_A_class)) }; return v }



type A_arbace_reflect_eval1938000141_fn__1938000142_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000141_fn__1938000142_A_fn_class *jrt.Class



type A_arbace_reflect_eval1938000145_A struct{ jrt.Object }

func A_arbace_reflect_eval1938000145_A_New() *A_arbace_reflect_eval1938000145_A { t := &A_arbace_reflect_eval1938000145_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval1938000145_A) Ctor() {}

func (t *A_arbace_reflect_eval1938000145_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval1938000145_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval1938000145_A_class }

func (t *A_arbace_reflect_eval1938000145_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval1938000145_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval1938000145_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval1938000145_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval1938000145_A); return ok }

func A_arbace_reflect_eval1938000145_A_Cast(x any) *A_arbace_reflect_eval1938000145_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval1938000145_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval1938000145_A_class)) }; return v }



type A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval1938000145___GT_AsmReflector__1938000147_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000004_A struct{ jrt.Object }

func A_arbace_reflect_eval659000004_A_New() *A_arbace_reflect_eval659000004_A { t := &A_arbace_reflect_eval659000004_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000004_A) Ctor() {}

func (t *A_arbace_reflect_eval659000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000004_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000004_A_class }

func (t *A_arbace_reflect_eval659000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000004_A); return ok }

func A_arbace_reflect_eval659000004_A_Cast(x any) *A_arbace_reflect_eval659000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000004_A_class)) }; return v }



type A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000008_A struct{ jrt.Object }

func A_arbace_reflect_eval659000008_A_New() *A_arbace_reflect_eval659000008_A { t := &A_arbace_reflect_eval659000008_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000008_A) Ctor() {}

func (t *A_arbace_reflect_eval659000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000008_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000008_A_class }

func (t *A_arbace_reflect_eval659000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000008_A); return ok }

func A_arbace_reflect_eval659000008_A_Cast(x any) *A_arbace_reflect_eval659000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000008_A_class)) }; return v }



type A_arbace_reflect_eval659000008_fn__659000009_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000008_fn__659000009_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000020_A struct{ jrt.Object }

func A_arbace_reflect_eval659000020_A_New() *A_arbace_reflect_eval659000020_A { t := &A_arbace_reflect_eval659000020_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000020_A) Ctor() {}

func (t *A_arbace_reflect_eval659000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000020_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000020_A_class }

func (t *A_arbace_reflect_eval659000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000020_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000020_A); return ok }

func A_arbace_reflect_eval659000020_A_Cast(x any) *A_arbace_reflect_eval659000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000020_A_class)) }; return v }



type A_arbace_reflect_eval659000020_fn__659000021_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000020_fn__659000021_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A struct{ j2g_header uint64; F_G__659000013 any }

var A_arbace_reflect_eval659000020_fn__659000021_G__659000012__659000028_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000020_fn__659000021_G__659000013__659000024_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000044_A struct{ jrt.Object }

func A_arbace_reflect_eval659000044_A_New() *A_arbace_reflect_eval659000044_A { t := &A_arbace_reflect_eval659000044_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect_eval659000044_A) Ctor() {}

func (t *A_arbace_reflect_eval659000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_eval659000044_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_eval659000044_A_class }

func (t *A_arbace_reflect_eval659000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_eval659000044_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_eval659000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_eval659000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_eval659000044_A); return ok }

func A_arbace_reflect_eval659000044_A_Cast(x any) *A_arbace_reflect_eval659000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_eval659000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_eval659000044_A_class)) }; return v }



type A_arbace_reflect_eval659000044_fn__659000045_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000044_fn__659000045_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A struct{ j2g_header uint64; F_G__659000037 any }

var A_arbace_reflect_eval659000044_fn__659000045_G__659000036__659000050_A_fn_class *jrt.Class



type A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A struct{ j2g_header uint64 }

var A_arbace_reflect_eval659000044_fn__659000045_G__659000037__659000047_A_fn_class *jrt.Class



type A_arbace_reflect_field__GT_map_A struct{ j2g_header uint64 }

var A_arbace_reflect_field__GT_map_A_fn_class *jrt.Class



type A_arbace_reflect_field_descriptor__GT_class_symbol_A struct{ j2g_header uint64 }

var A_arbace_reflect_field_descriptor__GT_class_symbol_A_fn_class *jrt.Class



type A_arbace_reflect_internal_name__GT_class_symbol_A struct{ j2g_header uint64 }

var A_arbace_reflect_internal_name__GT_class_symbol_A_fn_class *jrt.Class



type A_arbace_reflect_method__GT_map_A struct{ j2g_header uint64 }

var A_arbace_reflect_method__GT_map_A_fn_class *jrt.Class



type A_arbace_reflect_parse_flags_A struct{ j2g_header uint64 }

var A_arbace_reflect_parse_flags_A_fn_class *jrt.Class



type A_arbace_reflect_parse_flags_fn__1938000032_A struct{ j2g_header uint64; F_flags, F_context any }

var A_arbace_reflect_parse_flags_fn__1938000032_A_fn_class *jrt.Class



type A_arbace_reflect_reflect_A struct{ j2g_header uint64 }

var A_arbace_reflect_reflect_A_fn_class *jrt.Class



type A_arbace_reflect_resource_name_A struct{ j2g_header uint64 }

var A_arbace_reflect_resource_name_A_fn_class *jrt.Class



type A_arbace_reflect_type_reflect_A struct{ j2g_header uint64 }

var A_arbace_reflect_type_reflect_A_fn_class *jrt.Class



type A_arbace_reflect_type_reflect_fn__659000063_A struct{ j2g_header uint64 }

var A_arbace_reflect_type_reflect_fn__659000063_A_fn_class *jrt.Class



type A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A struct{ j2g_header uint64; F_refl any }

var A_arbace_reflect_type_reflect_make_ancestor_map__659000061_A_fn_class *jrt.Class



type A_arbace_reflect_typeref__GT_class_A struct{ j2g_header uint64 }

var A_arbace_reflect_typeref__GT_class_A_fn_class *jrt.Class



type A_arbace_reflect_typesym_A struct{ j2g_header uint64 }

var A_arbace_reflect_typesym_A_fn_class *jrt.Class



type A_arbace_reflect_typesym_fn__1938000019_A struct{ j2g_header uint64; F_t any }

var A_arbace_reflect_typesym_fn__1938000019_A_fn_class *jrt.Class
