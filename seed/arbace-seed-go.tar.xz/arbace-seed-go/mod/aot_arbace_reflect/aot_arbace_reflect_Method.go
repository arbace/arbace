//line aot_arbace_reflect_Method.ae:1
package aot_arbace_reflect

import (
	"arbace/jrt"
	"arbace/lang"
)






































































































































func A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O_I_I(p0, p1, p2, p3, p4, p5, p6, p7 any, p8, p9 int32) *A_arbace_reflect_Method_A { A_arbace_reflect_Method_A_Init(); t := &A_arbace_reflect_Method_A{}; t.Ctor_O_O_O_O_O_O_O_O_I_I(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9); return t }
//line :141:1
func (t *A_arbace_reflect_Method_A) Ctor_O_O_O_O_O_O_O_O_I_I(name, return_type, declaring_class, parameter_types, exception_types, flags, __meta, __extmap any, __hash, __hasheq int32) { t.F_name = name; t.F_return_type = return_type; t.F_declaring_class = declaring_class; t.F_parameter_types = parameter_types; t.F_exception_types = exception_types; t.F_flags = flags; t.F___meta = __meta; t.F___extmap = __extmap; t.F___hash = __hash; t.F___hasheq = __hasheq }
//line :141:1
func A_arbace_reflect_Method_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_reflect_Method_A { A_arbace_reflect_Method_A_Init(); t := &A_arbace_reflect_Method_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :141:1
func (t *A_arbace_reflect_Method_A) Ctor_O_O_O_O_O_O(name, return_type, declaring_class, parameter_types, exception_types, flags any) { t.Ctor_O_O_O_O_O_O_O_O_I_I(name, return_type, declaring_class, parameter_types, exception_types, flags, nil, nil, 0, 0) }
//line :141:1
func A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_reflect_Method_A { A_arbace_reflect_Method_A_Init(); t := &A_arbace_reflect_Method_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :141:1
func (t *A_arbace_reflect_Method_A) Ctor_O_O_O_O_O_O_O_O(name, return_type, declaring_class, parameter_types, exception_types, flags, __meta, __extmap any) { t.Ctor_O_O_O_O_O_O_O_O_I_I(name, return_type, declaring_class, parameter_types, exception_types, flags, __meta, __extmap, 0, 0) }
//line :141:1
func A_arbace_reflect_Method_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_reflect_Method_A_Init(); return lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_30).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref()) }
//line :141:1
func A_arbace_reflect_Method_A_Create_IPersistentMap__A_arbace_reflect_Method_A(m__ lang.IPersistentMap) *A_arbace_reflect_Method_A { A_arbace_reflect_Method_A_Init(); var m___2 lang.IPersistentMap = m__; var v__0 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_27).Ref(), nil); var v__1 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_40).Ref(), nil); var v__2 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_28).Ref(), nil); var v__3 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_29).Ref(), nil); var v__4 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_30).Ref(), nil); var v__5 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_31).Ref(), nil); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_27).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_40).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_28).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_29).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_30).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_31).Ref()); return A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O_I_I(v__0, v__1, v__2, v__3, v__4, v__5, nil, lang.RT_SeqOrElse_O__O_NoInit(m___2), 0, 0) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Hasheq__I() int32 { var hq__231000058__auto____1 int32 = t.F___hasheq; if lang.Numbers_IsZero_J__Z_NoInit(int64(hq__231000058__auto____1)) { var h__231000059__auto____2 int32 = lang.RT_IntCast_J__I_NoInit(lang.Numbers_Xor_J_J__J_NoInit(-2028208926, int64(lang.APersistentMap_MapHasheq_IPersistentMap__I_NoInit(t)))); t.F___hasheq = h__231000059__auto____2; return h__231000059__auto____2 } else { return hq__231000058__auto____1 } }
//line :141:1
func (t *A_arbace_reflect_Method_A) HashCode__I() int32 { var hash__231000061__auto____1 int32 = t.F___hash; if lang.Numbers_IsZero_J__Z_NoInit(int64(hash__231000061__auto____1)) { var h__231000062__auto____2 int32 = lang.APersistentMap_MapHash_IPersistentMap__I_NoInit(t); t.F___hash = h__231000062__auto____2; return h__231000062__auto____2 } else { return hash__231000061__auto____1 } }
//line :141:1
func (t *A_arbace_reflect_Method_A) Equals_O__Z(G__1938000059__1_ any) bool { return lang.APersistentMap_MapEquals_IPersistentMap_O__Z_NoInit(t, G__1938000059__1_) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Meta__IPersistentMap() lang.IPersistentMap { return lang.IPersistentMap_Cast(t.F___meta) }
//line :141:1
func (t *A_arbace_reflect_Method_A) WithMeta_IPersistentMap__IObj(G__1938000059__1_ lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O_I_I(t.F_name, t.F_return_type, t.F_declaring_class, t.F_parameter_types, t.F_exception_types, t.F_flags, G__1938000059__1_, t.F___extmap, t.F___hash, t.F___hasheq) }
//line :141:1
func (t *A_arbace_reflect_Method_A) ValAt_O__O(k__231000067__auto____1 any) any { return t.ValAt_O_O__O(k__231000067__auto____1, nil) }
//line :141:1
func (t *A_arbace_reflect_Method_A) ValAt_O_O__O(k__231000069__auto____1, else__231000070__auto____2 any) any { var G__1938000076__3_ any = k__231000069__auto____1; switch lang.Util_Hash_O__I_NoInit(G__1938000076__3_) >> 0 & 7 { case 0: if any(G__1938000076__3_) == any(A_arbace_reflect_Method_A_const_0) { return t.F_declaring_class }; case 1: if any(G__1938000076__3_) == any(A_arbace_reflect_Method_A_const_1) { return t.F_name }; case 2: if any(G__1938000076__3_) == any(A_arbace_reflect_Method_A_const_2) { return t.F_return_type }; case 4: if any(G__1938000076__3_) == any(A_arbace_reflect_Method_A_const_3) { return t.F_parameter_types }; case 5: if any(G__1938000076__3_) == any(A_arbace_reflect_Method_A_const_4) { return t.F_exception_types }; case 6: if any(G__1938000076__3_) == any(A_arbace_reflect_Method_A_const_5) { return t.F_flags }; default:}; return lang.RT_Get_O_O_O__O_NoInit(t.F___extmap, k__231000069__auto____1, else__231000070__auto____2) }
//line :141:1
func (t *A_arbace_reflect_Method_A) GetLookupThunk_Keyword__ILookupThunk(k__231000072__auto____1 *lang.Keyword) lang.ILookupThunk { var tmp1 any; var gclass__2 any = lang.IFn_Cast(A_arbace_reflect_Method_A_const_6.GetRawRoot__O()).Invoke_O__O(t); var G__1938000063__3_ any = k__231000072__auto____1.Ref(); L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1938000063__3_) >> 0 & 7 { case 0: if any(G__1938000063__3_) == any(A_arbace_reflect_Method_A_const_0) { tmp1 = A_arbace_reflect_Method_reify__1938000064_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 1: if any(G__1938000063__3_) == any(A_arbace_reflect_Method_A_const_1) { tmp1 = A_arbace_reflect_Method_reify__1938000066_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 2: if any(G__1938000063__3_) == any(A_arbace_reflect_Method_A_const_2) { tmp1 = A_arbace_reflect_Method_reify__1938000068_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 4: if any(G__1938000063__3_) == any(A_arbace_reflect_Method_A_const_3) { tmp1 = A_arbace_reflect_Method_reify__1938000070_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 5: if any(G__1938000063__3_) == any(A_arbace_reflect_Method_A_const_4) { tmp1 = A_arbace_reflect_Method_reify__1938000072_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 6: if any(G__1938000063__3_) == any(A_arbace_reflect_Method_A_const_5) { tmp1 = A_arbace_reflect_Method_reify__1938000074_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; default:}; tmp1 = nil}; return lang.ILookupThunk_Cast(tmp1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Count__I() int32 { return lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(6, int64(lang.RT_Count_O__I_NoInit(t.F___extmap)))) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Empty__IPersistentCollection() lang.IPersistentCollection { panic(jrt.Thrown(jrt.UnsupportedOperationException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_32, Lit_41), jrt.RefArrayOf(jrt.Object_class, nil, nil))))) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Cons_O__IPersistentCollection(e__231000076__auto____1 any) lang.IPersistentCollection { return lang.IPersistentCollection_Cast(A_arbace_reflect_Method_A_const_7.Invoke_O_O__O(t, e__231000076__auto____1)) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Equiv_O__Z(G__1938000059__1_ any) bool { var tmp1 *jrt.Boolean; var or__1927000174__auto____2 bool = lang.Util_Identical_O_O__Z_NoInit(t, G__1938000059__1_); if or__1927000174__auto____2 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2) } else { if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_reflect_Method_A_const_6.GetRawRoot__O()).Invoke_O__O(t), lang.IFn_Cast(A_arbace_reflect_Method_A_const_6.GetRawRoot__O()).Invoke_O__O(G__1938000059__1_)) { var G__1938000059__3_ any = G__1938000059__1_; var tmp2 any = t.F_name; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_reflect_Method_A_Cast(G__1938000059__3_).F_name); if and__1927000168__auto____4 { var tmp3 any = t.F_return_type; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_reflect_Method_A_Cast(G__1938000059__3_).F_return_type); if and__1927000168__auto____5 { var tmp4 any = t.F_declaring_class; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_reflect_Method_A_Cast(G__1938000059__3_).F_declaring_class); if and__1927000168__auto____6 { var tmp5 any = t.F_parameter_types; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_reflect_Method_A_Cast(G__1938000059__3_).F_parameter_types); if and__1927000168__auto____7 { var tmp6 any = t.F_exception_types; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_reflect_Method_A_Cast(G__1938000059__3_).F_exception_types); if and__1927000168__auto____8 { var tmp7 any = t.F_flags; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp7, A_arbace_reflect_Method_A_Cast(G__1938000059__3_).F_flags); if and__1927000168__auto____9 { var tmp8 any = t.F___extmap; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp8, A_arbace_reflect_Method_A_Cast(G__1938000059__3_).F___extmap)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4) } } else { tmp1 = nil } }; return lang.RT_BooleanCast_O__Z_NoInit(tmp1.Ref()) }
//line :141:1
func (t *A_arbace_reflect_Method_A) ContainsKey_O__Z(k__231000079__auto____1 any) bool { return jrt.NN(jrt.Boolean_Cast(lang.IFn_Cast(A_arbace_reflect_Method_A_const_8.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(t, t.ValAt_O_O__O(k__231000079__auto____1, t))).Ref()))).BooleanValue__Z() }
//line :141:1
func (t *A_arbace_reflect_Method_A) EntryAt_O__IMapEntry(k__231000081__auto____1 any) lang.IMapEntry { var tmp1 *lang.MapEntry; var v__231000082__auto____2 any = t.ValAt_O_O__O(k__231000081__auto____1, t); if lang.Util_Identical_O_O__Z_NoInit(t, v__231000082__auto____2) { tmp1 = nil } else { tmp1 = lang.MapEntry_Create_O_O__MapEntry(k__231000081__auto____1, v__231000082__auto____2) }; return Up_MapEntry_IMapEntry(tmp1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Seq__ISeq() lang.ISeq { return lang.ISeq_Cast(lang.IFn_Cast(A_arbace_reflect_Method_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_Method_A_const_10.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Method_A_const_1, t.F_name).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Method_A_const_2, t.F_return_type).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Method_A_const_0, t.F_declaring_class).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Method_A_const_3, t.F_parameter_types).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Method_A_const_4, t.F_exception_types).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Method_A_const_5, t.F_flags).Ref()), t.F___extmap))) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Iterator__Iterator() jrt.Iterator { var tmp1 lang.ILookup = t; var tmp2 lang.IPersistentVector = lang.IPersistentVector_Cast(A_arbace_reflect_Method_A_const_11); return lang.RecordIterator_New_ILookup_IPersistentVector_Iterator(tmp1, tmp2, lang.RT_Iter_O__Iterator_NoInit(t.F___extmap)) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Assoc_O_O__IPersistentMap(k__231000086__auto____1, G__1938000059__2_ any) lang.IPersistentMap { var tmp1 *A_arbace_reflect_Method_A; var pred__1938000061__3 any = A_arbace_reflect_Method_A_const_12.GetRawRoot__O(); var expr__1938000062__4 any = k__231000086__auto____1; if jrt.J2g_Truth(lang.IFn_Cast(pred__1938000061__3).Invoke_O_O__O(A_arbace_reflect_Method_A_const_1, expr__1938000062__4)) { tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(G__1938000059__2_, t.F_return_type, t.F_declaring_class, t.F_parameter_types, t.F_exception_types, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__1938000061__3).Invoke_O_O__O(A_arbace_reflect_Method_A_const_2, expr__1938000062__4)) { tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(t.F_name, G__1938000059__2_, t.F_declaring_class, t.F_parameter_types, t.F_exception_types, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__1938000061__3).Invoke_O_O__O(A_arbace_reflect_Method_A_const_0, expr__1938000062__4)) { tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(t.F_name, t.F_return_type, G__1938000059__2_, t.F_parameter_types, t.F_exception_types, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__1938000061__3).Invoke_O_O__O(A_arbace_reflect_Method_A_const_3, expr__1938000062__4)) { tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(t.F_name, t.F_return_type, t.F_declaring_class, G__1938000059__2_, t.F_exception_types, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__1938000061__3).Invoke_O_O__O(A_arbace_reflect_Method_A_const_4, expr__1938000062__4)) { tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(t.F_name, t.F_return_type, t.F_declaring_class, t.F_parameter_types, G__1938000059__2_, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__1938000061__3).Invoke_O_O__O(A_arbace_reflect_Method_A_const_5, expr__1938000062__4)) { tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(t.F_name, t.F_return_type, t.F_declaring_class, t.F_parameter_types, t.F_exception_types, G__1938000059__2_, t.F___meta, t.F___extmap) } else { var tmp2 any = t.F_name; var tmp3 any = t.F_return_type; var tmp4 any = t.F_declaring_class; var tmp5 any = t.F_parameter_types; var tmp6 any = t.F_exception_types; var tmp7 any = t.F_flags; var tmp8 any = t.F___meta; tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, lang.IFn_Cast(A_arbace_reflect_Method_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(t.F___extmap, k__231000086__auto____1, G__1938000059__2_)) } } } } } }; return Up_A_arbace_reflect_Method_A_IPersistentMap(tmp1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Without_O__IPersistentMap(k__231000088__auto____1 any) lang.IPersistentMap { var tmp1 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_reflect_Method_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect_Method_A_const_17, k__231000088__auto____1)) { tmp1 = lang.IFn_Cast(A_arbace_reflect_Method_A_const_15.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_reflect_Method_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_reflect_Method_A_const_19.GetRawRoot__O()).Invoke_O_O__O(lang.PersistentArrayMap_EMPTY.Ref(), t), t.F___meta), k__231000088__auto____1) } else { var tmp2 any = t.F_name; var tmp3 any = t.F_return_type; var tmp4 any = t.F_declaring_class; var tmp5 any = t.F_parameter_types; var tmp6 any = t.F_exception_types; var tmp7 any = t.F_flags; var tmp8 any = t.F___meta; tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, lang.IFn_Cast(A_arbace_reflect_Method_A_const_16.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_Method_A_const_15.GetRawRoot__O()).Invoke_O_O__O(t.F___extmap, k__231000088__auto____1))) }; return lang.IPersistentMap_Cast(tmp1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Size__I() int32 { return t.Count__I() }
//line :141:1
func (t *A_arbace_reflect_Method_A) IsEmpty__Z() bool { return lang.Util_Equiv_J_J__Z_NoInit(0, int64(t.Count__I())) }
//line :141:1
func (t *A_arbace_reflect_Method_A) ContainsValue_O__Z(v__231000092__auto____1 any) bool { return lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(A_arbace_reflect_Method_A_const_20.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, v__231000092__auto____1)), lang.IFn_Cast(A_arbace_reflect_Method_A_const_21.GetRawRoot__O()).Invoke_O__O(t))) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Get_O__O(k__231000094__auto____1 any) any { return t.ValAt_O__O(k__231000094__auto____1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Put_O_O__O(k__231000096__auto____1, v__231000097__auto____2 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Remove_O__O(k__231000099__auto____1 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :141:1
func (t *A_arbace_reflect_Method_A) PutAll_Map__V(m__231000101__auto____1 jrt.Map) { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Clear__V() { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :141:1
func (t *A_arbace_reflect_Method_A) KeySet__Set() jrt.Set { return jrt.Set_Cast(lang.IFn_Cast(A_arbace_reflect_Method_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_reflect_Method_A_const_23.GetRawRoot__O()).Invoke_O__O(t))) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Values__Collection() jrt.Collection { return jrt.Collection_Cast(lang.IFn_Cast(A_arbace_reflect_Method_A_const_21.GetRawRoot__O()).Invoke_O__O(t)) }
//line :141:1
func (t *A_arbace_reflect_Method_A) EntrySet__Set() jrt.Set { return jrt.Set_Cast(lang.IFn_Cast(A_arbace_reflect_Method_A_const_22.GetRawRoot__O()).Invoke_O__O(t)) }
//line :141:1
func A_arbace_reflect_Method_reify__1938000064_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Method_reify__1938000064_A { t := &A_arbace_reflect_Method_reify__1938000064_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000064_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000064_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_reflect_Method_A_Init(); tmp1 = A_arbace_reflect_Method_A_const_6; if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_reflect_Method_A_Cast(gtarget__1).F_declaring_class } else { return t } }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000064_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000064_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_reify__1938000064_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :141:1
func A_arbace_reflect_Method_reify__1938000066_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Method_reify__1938000066_A { t := &A_arbace_reflect_Method_reify__1938000066_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000066_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000066_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_reflect_Method_A_Init(); tmp1 = A_arbace_reflect_Method_A_const_6; if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_reflect_Method_A_Cast(gtarget__1).F_name } else { return t } }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000066_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000066_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_reify__1938000066_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :141:1
func A_arbace_reflect_Method_reify__1938000068_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Method_reify__1938000068_A { t := &A_arbace_reflect_Method_reify__1938000068_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000068_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000068_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_reflect_Method_A_Init(); tmp1 = A_arbace_reflect_Method_A_const_6; if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_reflect_Method_A_Cast(gtarget__1).F_return_type } else { return t } }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000068_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000068_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_reify__1938000068_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :141:1
func A_arbace_reflect_Method_reify__1938000070_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Method_reify__1938000070_A { t := &A_arbace_reflect_Method_reify__1938000070_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000070_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000070_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_reflect_Method_A_Init(); tmp1 = A_arbace_reflect_Method_A_const_6; if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_reflect_Method_A_Cast(gtarget__1).F_parameter_types } else { return t } }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000070_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000070_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_reify__1938000070_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :141:1
func A_arbace_reflect_Method_reify__1938000072_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Method_reify__1938000072_A { t := &A_arbace_reflect_Method_reify__1938000072_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000072_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000072_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_reflect_Method_A_Init(); tmp1 = A_arbace_reflect_Method_A_const_6; if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_reflect_Method_A_Cast(gtarget__1).F_exception_types } else { return t } }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000072_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000072_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_reify__1938000072_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :141:1
func A_arbace_reflect_Method_reify__1938000074_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Method_reify__1938000074_A { t := &A_arbace_reflect_Method_reify__1938000074_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000074_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000074_A) Get_O__O(gtarget__1 any) any { var tmp1 *lang.Var; A_arbace_reflect_Method_A_Init(); tmp1 = A_arbace_reflect_Method_A_const_6; if lang.Util_Identical_O_O__Z_NoInit(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(gtarget__1), t.F_gclass) { return A_arbace_reflect_Method_A_Cast(gtarget__1).F_flags } else { return t } }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000074_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1938000074_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_reify__1938000074_A_New_IPersistentMap_O(m, t.F_gclass) }







































































































































type A_arbace_reflect_Method_A struct{ jrt.Object; F_name, F_return_type, F_declaring_class, F_parameter_types, F_exception_types, F_flags, F___meta, F___extmap any; F___hash, F___hasheq int32 }

func (t *A_arbace_reflect_Method_A) Is_IRecord() {}

func (t *A_arbace_reflect_Method_A) Is_IHashEq() {}

func (t *A_arbace_reflect_Method_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_A) Is_ILookup() {}

func (t *A_arbace_reflect_Method_A) Is_IKeywordLookup() {}

func (t *A_arbace_reflect_Method_A) Is_IPersistentMap() {}

func (t *A_arbace_reflect_Method_A) Is_Map() {}

func (t *A_arbace_reflect_Method_A) Is_Serializable() {}

func (t *A_arbace_reflect_Method_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_A) Is_Iterable() {}

func (t *A_arbace_reflect_Method_A) Is_Associative() {}

func (t *A_arbace_reflect_Method_A) Is_Counted() {}

func (t *A_arbace_reflect_Method_A) Is_IPersistentCollection() {}

func (t *A_arbace_reflect_Method_A) Is_Seqable() {}

var A_arbace_reflect_Method_A_const_pool *jrt.RefArray

var A_arbace_reflect_Method_A_const_0 *lang.Keyword

var A_arbace_reflect_Method_A_const_1 *lang.Keyword

var A_arbace_reflect_Method_A_const_2 *lang.Keyword

var A_arbace_reflect_Method_A_const_3 *lang.Keyword

var A_arbace_reflect_Method_A_const_4 *lang.Keyword

var A_arbace_reflect_Method_A_const_5 *lang.Keyword

var A_arbace_reflect_Method_A_const_6 *lang.Var

var A_arbace_reflect_Method_A_const_7 *lang.Var

var A_arbace_reflect_Method_A_const_8 *lang.Var

var A_arbace_reflect_Method_A_const_9 *lang.Var

var A_arbace_reflect_Method_A_const_10 *lang.Var

var A_arbace_reflect_Method_A_const_11 any

var A_arbace_reflect_Method_A_const_12 *lang.Var

var A_arbace_reflect_Method_A_const_13 *lang.Var

var A_arbace_reflect_Method_A_const_14 *lang.Var

var A_arbace_reflect_Method_A_const_15 *lang.Var

var A_arbace_reflect_Method_A_const_16 *lang.Var

var A_arbace_reflect_Method_A_const_17 any

var A_arbace_reflect_Method_A_const_18 *lang.Var

var A_arbace_reflect_Method_A_const_19 *lang.Var

var A_arbace_reflect_Method_A_const_20 *lang.Var

var A_arbace_reflect_Method_A_const_21 *lang.Var

var A_arbace_reflect_Method_A_const_22 *lang.Var

var A_arbace_reflect_Method_A_const_23 *lang.Var

var A_arbace_reflect_Method_A_init jrt.ClassInit

func A_arbace_reflect_Method_A_Init() { if !A_arbace_reflect_Method_A_init.Done() { A_arbace_reflect_Method_A_init.Run(A_arbace_reflect_Method_A_clinit) } }

func A_arbace_reflect_Method_A_clinit() { A_arbace_reflect_Method_A_clinit_p0(); A_arbace_reflect_Method_A_clinit_p1(); A_arbace_reflect_Method_A_clinit_p2() }

func A_arbace_reflect_Method_A_clinit_p0() { jrt.StartCheck(); A_arbace_reflect_Method_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_39, 30); A_arbace_reflect_Method_A_const_0 = lang.Keyword_Cast(A_arbace_reflect_Method_A_const_pool.A[6]); A_arbace_reflect_Method_A_const_1 = lang.Keyword_Cast(A_arbace_reflect_Method_A_const_pool.A[7]); A_arbace_reflect_Method_A_const_2 = lang.Keyword_Cast(A_arbace_reflect_Method_A_const_pool.A[8]); A_arbace_reflect_Method_A_const_3 = lang.Keyword_Cast(A_arbace_reflect_Method_A_const_pool.A[9]); A_arbace_reflect_Method_A_const_4 = lang.Keyword_Cast(A_arbace_reflect_Method_A_const_pool.A[10]); A_arbace_reflect_Method_A_const_5 = lang.Keyword_Cast(A_arbace_reflect_Method_A_const_pool.A[11]); A_arbace_reflect_Method_A_const_6 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[12]); A_arbace_reflect_Method_A_const_7 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[13]); A_arbace_reflect_Method_A_const_8 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[14]); A_arbace_reflect_Method_A_const_9 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[15]); A_arbace_reflect_Method_A_const_10 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[16]) }

func A_arbace_reflect_Method_A_clinit_p1() { A_arbace_reflect_Method_A_const_11 = A_arbace_reflect_Method_A_const_pool.A[17]; A_arbace_reflect_Method_A_const_12 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[18]); A_arbace_reflect_Method_A_const_13 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[19]); A_arbace_reflect_Method_A_const_14 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[20]); A_arbace_reflect_Method_A_const_15 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[21]); A_arbace_reflect_Method_A_const_16 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[22]); A_arbace_reflect_Method_A_const_17 = A_arbace_reflect_Method_A_const_pool.A[23]; A_arbace_reflect_Method_A_const_18 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[24]); A_arbace_reflect_Method_A_const_19 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[25]); A_arbace_reflect_Method_A_const_20 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[26]); A_arbace_reflect_Method_A_const_21 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[27]); A_arbace_reflect_Method_A_const_22 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[28]) }

func A_arbace_reflect_Method_A_clinit_p2() { A_arbace_reflect_Method_A_const_23 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[29]) }

func (t *A_arbace_reflect_Method_A) Assoc_O_O__Associative(p0, p1 any) lang.Associative { return t.Assoc_O_O__IPersistentMap(p0, p1) }

func (t *A_arbace_reflect_Method_A) Spliterator__Spliterator() jrt.Spliterator { return jrt.Iterable_Spliterator__Spliterator(t) }

func (t *A_arbace_reflect_Method_A) Replace_O_O__O(p0, p1 any) any { return jrt.Map_Replace_O_O__O(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) AssocEx_O_O__IPersistentMap(p0, p1 any) lang.IPersistentMap { panic(jrt.AbstractMethodError_New_String(jrt.Str("Receiver class arbace.reflect.Method does not define or inherit an implementation of the resolved method 'abstract arbace.lang.IPersistentMap assocEx(java.lang.Object, java.lang.Object)' of interface arbace.lang.IPersistentMap."))) }

func (t *A_arbace_reflect_Method_A) Compute_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_Compute_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) Remove_O_O__Z(p0, p1 any) bool { return jrt.Map_Remove_O_O__Z(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) GetOrDefault_O_O__O(p0, p1 any) any { return jrt.Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) Merge_O_O_BiFunction__O(p0, p1 any, p2 jrt.BiFunction) any { return jrt.Map_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *A_arbace_reflect_Method_A) ComputeIfPresent_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) ReplaceAll_BiFunction__V(p0 jrt.BiFunction) { jrt.Map_ReplaceAll_BiFunction__V(t, p0) }

func (t *A_arbace_reflect_Method_A) PutIfAbsent_O_O__O(p0, p1 any) any { return jrt.Map_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) ForEach_BiConsumer__V(p0 jrt.BiConsumer) { jrt.Map_ForEach_BiConsumer__V(t, p0) }

func (t *A_arbace_reflect_Method_A) ForEach_Consumer__V(p0 jrt.Consumer) { jrt.Iterable_ForEach_Consumer__V(t, p0) }

func (t *A_arbace_reflect_Method_A) Replace_O_O_O__Z(p0, p1, p2 any) bool { return jrt.Map_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *A_arbace_reflect_Method_A) ComputeIfAbsent_O_Function__O(p0 any, p1 jrt.Function) any { return jrt.Map_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_A_class }

func (t *A_arbace_reflect_Method_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_A); return ok }

func A_arbace_reflect_Method_A_Cast(x any) *A_arbace_reflect_Method_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_A_class)) }; return v }



type A_arbace_reflect_Method_reify__1938000064_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Method_reify__1938000064_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Method_reify__1938000064_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_reify__1938000064_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_reify__1938000064_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_reify__1938000064_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_reify__1938000064_A_class }

func (t *A_arbace_reflect_Method_reify__1938000064_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_reify__1938000064_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_reify__1938000064_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_reify__1938000064_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_reify__1938000064_A); return ok }

func A_arbace_reflect_Method_reify__1938000064_A_Cast(x any) *A_arbace_reflect_Method_reify__1938000064_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_reify__1938000064_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_reify__1938000064_A_class)) }; return v }



type A_arbace_reflect_Method_reify__1938000066_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Method_reify__1938000066_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Method_reify__1938000066_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_reify__1938000066_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_reify__1938000066_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_reify__1938000066_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_reify__1938000066_A_class }

func (t *A_arbace_reflect_Method_reify__1938000066_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_reify__1938000066_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_reify__1938000066_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_reify__1938000066_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_reify__1938000066_A); return ok }

func A_arbace_reflect_Method_reify__1938000066_A_Cast(x any) *A_arbace_reflect_Method_reify__1938000066_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_reify__1938000066_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_reify__1938000066_A_class)) }; return v }



type A_arbace_reflect_Method_reify__1938000068_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Method_reify__1938000068_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Method_reify__1938000068_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_reify__1938000068_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_reify__1938000068_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_reify__1938000068_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_reify__1938000068_A_class }

func (t *A_arbace_reflect_Method_reify__1938000068_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_reify__1938000068_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_reify__1938000068_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_reify__1938000068_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_reify__1938000068_A); return ok }

func A_arbace_reflect_Method_reify__1938000068_A_Cast(x any) *A_arbace_reflect_Method_reify__1938000068_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_reify__1938000068_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_reify__1938000068_A_class)) }; return v }



type A_arbace_reflect_Method_reify__1938000070_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Method_reify__1938000070_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Method_reify__1938000070_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_reify__1938000070_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_reify__1938000070_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_reify__1938000070_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_reify__1938000070_A_class }

func (t *A_arbace_reflect_Method_reify__1938000070_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_reify__1938000070_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_reify__1938000070_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_reify__1938000070_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_reify__1938000070_A); return ok }

func A_arbace_reflect_Method_reify__1938000070_A_Cast(x any) *A_arbace_reflect_Method_reify__1938000070_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_reify__1938000070_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_reify__1938000070_A_class)) }; return v }



type A_arbace_reflect_Method_reify__1938000072_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Method_reify__1938000072_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Method_reify__1938000072_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_reify__1938000072_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_reify__1938000072_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_reify__1938000072_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_reify__1938000072_A_class }

func (t *A_arbace_reflect_Method_reify__1938000072_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_reify__1938000072_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_reify__1938000072_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_reify__1938000072_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_reify__1938000072_A); return ok }

func A_arbace_reflect_Method_reify__1938000072_A_Cast(x any) *A_arbace_reflect_Method_reify__1938000072_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_reify__1938000072_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_reify__1938000072_A_class)) }; return v }



type A_arbace_reflect_Method_reify__1938000074_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Method_reify__1938000074_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Method_reify__1938000074_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_reify__1938000074_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_reify__1938000074_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_reify__1938000074_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_reify__1938000074_A_class }

func (t *A_arbace_reflect_Method_reify__1938000074_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_reify__1938000074_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_reify__1938000074_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_reify__1938000074_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_reify__1938000074_A); return ok }

func A_arbace_reflect_Method_reify__1938000074_A_Cast(x any) *A_arbace_reflect_Method_reify__1938000074_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_reify__1938000074_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_reify__1938000074_A_class)) }; return v }
