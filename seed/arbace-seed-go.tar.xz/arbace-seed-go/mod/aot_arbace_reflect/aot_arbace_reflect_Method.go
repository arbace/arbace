//line aot_arbace_reflect_Method.ae:1
package aot_arbace_reflect

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)





































































































































func A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O_I_I(p0, p1, p2, p3, p4, p5, p6, p7 any, p8, p9 int32) *A_arbace_reflect_Method_A { A_arbace_reflect_Method_A_Init(); t := &A_arbace_reflect_Method_A{}; t.Ctor_O_O_O_O_O_O_O_O_I_I(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9); return t }
//line :141:1
func (t *A_arbace_reflect_Method_A) Ctor_O_O_O_O_O_O_O_O_I_I(name, return_type, declaring_class, parameter_types, exception_types, flags, __meta, __extmap any, __hash, __hasheq int32) { t.F_name = name; t.F_return_type = return_type; t.F_declaring_class = declaring_class; t.F_parameter_types = parameter_types; t.F_exception_types = exception_types; t.F_flags = flags; t.F___meta = __meta; t.F___extmap = __extmap; t.F___hash = __hash; t.F___hasheq = __hasheq }
//line :141:1
func A_arbace_reflect_Method_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_reflect_Method_A { A_arbace_reflect_Method_A_Init(); t := &A_arbace_reflect_Method_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :141:1
func (t *A_arbace_reflect_Method_A) Ctor_O_O_O_O_O_O(name, return_type, declaring_class, parameter_types, exception_types, flags any) { t.Ctor_O_O_O_O_O_O_O_O_I_I(name, return_type, declaring_class, parameter_types, exception_types, flags, nil, nil, 0, 0) }
//line :141:1
func A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_reflect_Method_A { A_arbace_reflect_Method_A_Init(); t := &A_arbace_reflect_Method_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :141:1
func (t *A_arbace_reflect_Method_A) Ctor_O_O_O_O_O_O_O_O(name, return_type, declaring_class, parameter_types, exception_types, flags, __meta, __extmap any) { t.Ctor_O_O_O_O_O_O_O_O_I_I(name, return_type, declaring_class, parameter_types, exception_types, flags, __meta, __extmap, 0, 0) }
//line :141:1
func A_arbace_reflect_Method_A_GetBasis__IPersistentVector() lang.IPersistentVector { A_arbace_reflect_Method_A_Init(); return lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_40).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_28).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_29).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_30).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref()) }
//line :141:1
func A_arbace_reflect_Method_A_Create_IPersistentMap__A_arbace_reflect_Method_A(m__ lang.IPersistentMap) *A_arbace_reflect_Method_A { A_arbace_reflect_Method_A_Init(); var m___2 lang.IPersistentMap = m__; var v__0 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_27).Ref(), nil); var v__1 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_40).Ref(), nil); var v__2 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_28).Ref(), nil); var v__3 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_29).Ref(), nil); var v__4 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_30).Ref(), nil); var v__5 any = m___2.ValAt_O_O__O(lang.Keyword_Intern_String__Keyword_NoInit(Lit_31).Ref(), nil); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_27).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_40).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_28).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_29).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_30).Ref()); m___2 = m___2.Without_O__IPersistentMap(lang.Keyword_Intern_String__Keyword_NoInit(Lit_31).Ref()); return A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O_I_I(v__0, v__1, v__2, v__3, v__4, v__5, nil, lang.RT_SeqOrElse_O__O_NoInit(m___2), 0, 0) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Hasheq__I() int32 { var hq__231000102__auto____1 int32 = t.F___hasheq; if lang.Numbers_IsZero_J__Z_NoInit(int64(hq__231000102__auto____1)) { var h__231000103__auto____2 int32 = lang.RT_IntCast_J__I_NoInit(lang.Numbers_Xor_J_J__J_NoInit(-2028208926, int64(lang.APersistentMap_MapHasheq_IPersistentMap__I_NoInit(t)))); t.F___hasheq = h__231000103__auto____2; return h__231000103__auto____2 } else { return hq__231000102__auto____1 } }
//line :141:1
func (t *A_arbace_reflect_Method_A) HashCode__I() int32 { var hash__231000105__auto____1 int32 = t.F___hash; if lang.Numbers_IsZero_J__Z_NoInit(int64(hash__231000105__auto____1)) { var h__231000106__auto____2 int32 = lang.APersistentMap_MapHash_IPersistentMap__I_NoInit(t); t.F___hash = h__231000106__auto____2; return h__231000106__auto____2 } else { return hash__231000105__auto____1 } }
//line :141:1
func (t *A_arbace_reflect_Method_A) Equals_O__Z(G__1939000059__1_ any) bool { return lang.APersistentMap_MapEquals_IPersistentMap_O__Z_NoInit(t, G__1939000059__1_) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Meta__IPersistentMap() lang.IPersistentMap { return lang.IPersistentMap_Cast(t.F___meta) }
//line :141:1
func (t *A_arbace_reflect_Method_A) WithMeta_IPersistentMap__IObj(G__1939000059__1_ lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O_I_I(t.F_name, t.F_return_type, t.F_declaring_class, t.F_parameter_types, t.F_exception_types, t.F_flags, G__1939000059__1_, t.F___extmap, t.F___hash, t.F___hasheq) }
//line :141:1
func (t *A_arbace_reflect_Method_A) ValAt_O__O(k__231000111__auto____1 any) any { return t.ValAt_O_O__O(k__231000111__auto____1, nil) }
//line :141:1
func (t *A_arbace_reflect_Method_A) ValAt_O_O__O(k__231000113__auto____1, else__231000114__auto____2 any) any { var G__1939000076__3_ any = k__231000113__auto____1; switch lang.Util_Hash_O__I_NoInit(G__1939000076__3_) >> 0 & 7 { case 0: if any(G__1939000076__3_) == any(A_arbace_reflect_Method_A_const_0) { return t.F_declaring_class }; case 1: if any(G__1939000076__3_) == any(A_arbace_reflect_Method_A_const_1) { return t.F_name }; case 2: if any(G__1939000076__3_) == any(A_arbace_reflect_Method_A_const_2) { return t.F_return_type }; case 4: if any(G__1939000076__3_) == any(A_arbace_reflect_Method_A_const_3) { return t.F_parameter_types }; case 5: if any(G__1939000076__3_) == any(A_arbace_reflect_Method_A_const_4) { return t.F_exception_types }; case 6: if any(G__1939000076__3_) == any(A_arbace_reflect_Method_A_const_5) { return t.F_flags }; default:}; return lang.RT_Get_O_O_O__O_NoInit(t.F___extmap, k__231000113__auto____1, else__231000114__auto____2) }
//line :141:1
func (t *A_arbace_reflect_Method_A) GetLookupThunk_Keyword__ILookupThunk(k__231000116__auto____1 *lang.Keyword) lang.ILookupThunk { var tmp1 any; var gclass__2 any; var root_2 any = A_arbace_reflect_Method_A_const_6.GetRawRoot__O(); var linked_3 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_4 lang.IFn; if linked_3 == nil { ifn_4 = lang.IFn_Cast(root_2) } else { ifn_4 = nil }; var arg_5 any = t; if linked_3 == nil { gclass__2 = ifn_4.Invoke_O__O(arg_5) } else { gclass__2 = linked_3.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_2, arg_5) }; var G__1939000063__3_ any = k__231000116__auto____1.Ref(); L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1939000063__3_) >> 0 & 7 { case 0: if any(G__1939000063__3_) == any(A_arbace_reflect_Method_A_const_0) { tmp1 = A_arbace_reflect_Method_reify__1939000064_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 1: if any(G__1939000063__3_) == any(A_arbace_reflect_Method_A_const_1) { tmp1 = A_arbace_reflect_Method_reify__1939000066_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 2: if any(G__1939000063__3_) == any(A_arbace_reflect_Method_A_const_2) { tmp1 = A_arbace_reflect_Method_reify__1939000068_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 4: if any(G__1939000063__3_) == any(A_arbace_reflect_Method_A_const_3) { tmp1 = A_arbace_reflect_Method_reify__1939000070_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 5: if any(G__1939000063__3_) == any(A_arbace_reflect_Method_A_const_4) { tmp1 = A_arbace_reflect_Method_reify__1939000072_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; case 6: if any(G__1939000063__3_) == any(A_arbace_reflect_Method_A_const_5) { tmp1 = A_arbace_reflect_Method_reify__1939000074_A_New_IPersistentMap_O(nil, gclass__2); break L1 }; default:}; tmp1 = nil}; return lang.ILookupThunk_Cast(tmp1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Count__I() int32 { return lang.RT_IntCast_J__I_NoInit(lang.Numbers_Add_J_J__J_NoInit(6, int64(lang.RT_Count_O__I_NoInit(t.F___extmap)))) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Empty__IPersistentCollection() lang.IPersistentCollection { panic(jrt.Thrown(jrt.UnsupportedOperationException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_32, Lit_41), jrt.RefArrayOf(jrt.Object_class, nil, nil))))) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Cons_O__IPersistentCollection(e__231000120__auto____1 any) lang.IPersistentCollection { return lang.IPersistentCollection_Cast(A_arbace_reflect_Method_A_const_7.Invoke_O_O__O(t, e__231000120__auto____1)) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Equiv_O__Z(G__1939000059__1_ any) bool { var tmp1 *jrt.Boolean; var or__1927000174__auto____2 bool = lang.Util_Identical_O_O__Z_NoInit(t, G__1939000059__1_); if or__1927000174__auto____2 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2) } else { var tmp2 any; var root_31 any = A_arbace_reflect_Method_A_const_6.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = t; if linked_32 == nil { tmp2 = ifn_33.Invoke_O__O(arg_34) } else { tmp2 = linked_32.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_31, arg_34) }; var tmp3 any = tmp2; var tmp4 any; var root_35 any = A_arbace_reflect_Method_A_const_6.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = G__1939000059__1_; if linked_36 == nil { tmp4 = ifn_37.Invoke_O__O(arg_38) } else { tmp4 = linked_36.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_35, arg_38) }; if lang.Util_Identical_O_O__Z_NoInit(tmp3, tmp4) { var G__1939000059__3_ any = G__1939000059__1_; var tmp5 any = t.F_name; var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp5, A_arbace_reflect_Method_A_Cast(G__1939000059__3_).F_name); if and__1927000168__auto____4 { var tmp6 any = t.F_return_type; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_reflect_Method_A_Cast(G__1939000059__3_).F_return_type); if and__1927000168__auto____5 { var tmp7 any = t.F_declaring_class; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp7, A_arbace_reflect_Method_A_Cast(G__1939000059__3_).F_declaring_class); if and__1927000168__auto____6 { var tmp8 any = t.F_parameter_types; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp8, A_arbace_reflect_Method_A_Cast(G__1939000059__3_).F_parameter_types); if and__1927000168__auto____7 { var tmp9 any = t.F_exception_types; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp9, A_arbace_reflect_Method_A_Cast(G__1939000059__3_).F_exception_types); if and__1927000168__auto____8 { var tmp10 any = t.F_flags; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp10, A_arbace_reflect_Method_A_Cast(G__1939000059__3_).F_flags); if and__1927000168__auto____9 { var tmp11 any = t.F___extmap; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp11, A_arbace_reflect_Method_A_Cast(G__1939000059__3_).F___extmap)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____9) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____8) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4) } } else { tmp1 = nil } }; return lang.RT_BooleanCast_O__Z_NoInit(tmp1.Ref()) }
//line :141:1
func (t *A_arbace_reflect_Method_A) ContainsKey_O__Z(k__231000123__auto____1 any) bool { var tmp1 any; var root_39 any = A_arbace_reflect_Method_A_const_8.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(t, t.ValAt_O_O__O(k__231000123__auto____1, t))).Ref(); if linked_40 == nil { tmp1 = ifn_41.Invoke_O__O(arg_42) } else { tmp1 = linked_40.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_39, arg_42) }; return jrt.NN(jrt.Boolean_Cast(tmp1)).BooleanValue__Z() }
//line :141:1
func (t *A_arbace_reflect_Method_A) EntryAt_O__IMapEntry(k__231000125__auto____1 any) lang.IMapEntry { var tmp1 *lang.MapEntry; var v__231000126__auto____2 any = t.ValAt_O_O__O(k__231000125__auto____1, t); if lang.Util_Identical_O_O__Z_NoInit(t, v__231000126__auto____2) { tmp1 = nil } else { tmp1 = lang.MapEntry_Create_O_O__MapEntry(k__231000125__auto____1, v__231000126__auto____2) }; return Up_MapEntry_IMapEntry(tmp1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Seq__ISeq() lang.ISeq { var tmp1 any; var root_43 any = A_arbace_reflect_Method_A_const_9.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any; var root_47 any = A_arbace_reflect_Method_A_const_10.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Method_A_const_1, t.F_name).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Method_A_const_2, t.F_return_type).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Method_A_const_0, t.F_declaring_class).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Method_A_const_3, t.F_parameter_types).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Method_A_const_4, t.F_exception_types).Ref(), lang.MapEntry_Create_O_O__MapEntry(A_arbace_reflect_Method_A_const_5, t.F_flags).Ref()); var arg_51 any = t.F___extmap; if linked_48 == nil { arg_46 = ifn_49.Invoke_O_O__O(arg_50, arg_51) } else { arg_46 = linked_48.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_47, arg_50, arg_51) }; if linked_44 == nil { tmp1 = ifn_45.Invoke_O__O(arg_46) } else { tmp1 = linked_44.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_43, arg_46) }; return lang.ISeq_Cast(tmp1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Iterator__Iterator() jrt.Iterator { var tmp1 lang.ILookup = t; var tmp2 lang.IPersistentVector = lang.IPersistentVector_Cast(A_arbace_reflect_Method_A_const_11); return lang.RecordIterator_New_ILookup_IPersistentVector_Iterator(tmp1, tmp2, lang.RT_Iter_O__Iterator_NoInit(t.F___extmap)) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Assoc_O_O__IPersistentMap(k__231000130__auto____1, G__1939000059__2_ any) lang.IPersistentMap { var tmp1 *A_arbace_reflect_Method_A; var pred__1939000061__3 any = A_arbace_reflect_Method_A_const_12.GetRawRoot__O(); var expr__1939000062__4 any = k__231000130__auto____1; if jrt.J2g_Truth(lang.IFn_Cast(pred__1939000061__3).Invoke_O_O__O(A_arbace_reflect_Method_A_const_1, expr__1939000062__4)) { tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(G__1939000059__2_, t.F_return_type, t.F_declaring_class, t.F_parameter_types, t.F_exception_types, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__1939000061__3).Invoke_O_O__O(A_arbace_reflect_Method_A_const_2, expr__1939000062__4)) { tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(t.F_name, G__1939000059__2_, t.F_declaring_class, t.F_parameter_types, t.F_exception_types, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__1939000061__3).Invoke_O_O__O(A_arbace_reflect_Method_A_const_0, expr__1939000062__4)) { tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(t.F_name, t.F_return_type, G__1939000059__2_, t.F_parameter_types, t.F_exception_types, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__1939000061__3).Invoke_O_O__O(A_arbace_reflect_Method_A_const_3, expr__1939000062__4)) { tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(t.F_name, t.F_return_type, t.F_declaring_class, G__1939000059__2_, t.F_exception_types, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__1939000061__3).Invoke_O_O__O(A_arbace_reflect_Method_A_const_4, expr__1939000062__4)) { tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(t.F_name, t.F_return_type, t.F_declaring_class, t.F_parameter_types, G__1939000059__2_, t.F_flags, t.F___meta, t.F___extmap) } else { if jrt.J2g_Truth(lang.IFn_Cast(pred__1939000061__3).Invoke_O_O__O(A_arbace_reflect_Method_A_const_5, expr__1939000062__4)) { tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(t.F_name, t.F_return_type, t.F_declaring_class, t.F_parameter_types, t.F_exception_types, G__1939000059__2_, t.F___meta, t.F___extmap) } else { var tmp2 any = t.F_name; var tmp3 any = t.F_return_type; var tmp4 any = t.F_declaring_class; var tmp5 any = t.F_parameter_types; var tmp6 any = t.F_exception_types; var tmp7 any = t.F_flags; var tmp8 any = t.F___meta; var tmp9 any; var root_52 any = A_arbace_reflect_Method_A_const_13.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = t.F___extmap; var arg_56 any = k__231000130__auto____1; var arg_57 any = G__1939000059__2_; if linked_53 == nil { tmp9 = ifn_54.Invoke_O_O_O__O(arg_55, arg_56, arg_57) } else { tmp9 = linked_53.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_52, arg_55, arg_56, arg_57) }; tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9) } } } } } }; return Up_A_arbace_reflect_Method_A_IPersistentMap(tmp1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Without_O__IPersistentMap(k__231000132__auto____1 any) lang.IPersistentMap { var tmp1 any; var tmp2 any; var root_58 any = A_arbace_reflect_Method_A_const_14.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = A_arbace_reflect_Method_A_const_15; var arg_62 any = k__231000132__auto____1; if linked_59 == nil { tmp2 = ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { tmp2 = linked_59.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_58, arg_61, arg_62) }; if jrt.J2g_Truth(tmp2) { var root_63 any = A_arbace_reflect_Method_A_const_16.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any; var root_68 any = A_arbace_reflect_Method_A_const_17.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any; var root_73 any = A_arbace_reflect_Method_A_const_18.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_77 any = t; if linked_74 == nil { arg_71 = ifn_75.Invoke_O_O__O(arg_76, arg_77) } else { arg_71 = linked_74.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_73, arg_76, arg_77) }; var arg_72 any = t.F___meta; if linked_69 == nil { arg_66 = ifn_70.Invoke_O_O__O(arg_71, arg_72) } else { arg_66 = linked_69.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_68, arg_71, arg_72) }; var arg_67 any = k__231000132__auto____1; if linked_64 == nil { tmp1 = ifn_65.Invoke_O_O__O(arg_66, arg_67) } else { tmp1 = linked_64.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_63, arg_66, arg_67) } } else { var tmp3 any = t.F_name; var tmp4 any = t.F_return_type; var tmp5 any = t.F_declaring_class; var tmp6 any = t.F_parameter_types; var tmp7 any = t.F_exception_types; var tmp8 any = t.F_flags; var tmp9 any = t.F___meta; var tmp10 any; var root_78 any = A_arbace_reflect_Method_A_const_19.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_not_empty_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any; var root_82 any = A_arbace_reflect_Method_A_const_16.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = t.F___extmap; var arg_86 any = k__231000132__auto____1; if linked_83 == nil { arg_81 = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { arg_81 = linked_83.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_82, arg_85, arg_86) }; if linked_79 == nil { tmp10 = ifn_80.Invoke_O__O(arg_81) } else { tmp10 = linked_79.(*aot_arbace_core.A_arbace_core_not_empty_A).Invoke_O_O__O(root_78, arg_81) }; tmp1 = A_arbace_reflect_Method_A_New_O_O_O_O_O_O_O_O(tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10) }; return lang.IPersistentMap_Cast(tmp1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Size__I() int32 { return t.Count__I() }
//line :141:1
func (t *A_arbace_reflect_Method_A) IsEmpty__Z() bool { return lang.Util_Equiv_J_J__Z_NoInit(0, int64(t.Count__I())) }
//line :141:1
func (t *A_arbace_reflect_Method_A) ContainsValue_O__Z(v__231000136__auto____1 any) bool { var tmp1 any; var root_87 any = A_arbace_reflect_Method_A_const_20.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, v__231000136__auto____1)); var arg_91 any; var root_92 any = A_arbace_reflect_Method_A_const_21.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = t; if linked_93 == nil { arg_91 = ifn_94.Invoke_O__O(arg_95) } else { arg_91 = linked_93.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_92, arg_95) }; if linked_88 == nil { tmp1 = ifn_89.Invoke_O_O__O(arg_90, arg_91) } else { tmp1 = linked_88.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_87, arg_90, arg_91) }; return lang.RT_BooleanCast_O__Z_NoInit(tmp1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Get_O__O(k__231000138__auto____1 any) any { return t.ValAt_O__O(k__231000138__auto____1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Put_O_O__O(k__231000140__auto____1, v__231000141__auto____2 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Remove_O__O(k__231000143__auto____1 any) any { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :141:1
func (t *A_arbace_reflect_Method_A) PutAll_Map__V(m__231000145__auto____1 jrt.Map) { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Clear__V() { panic(jrt.Thrown(jrt.UnsupportedOperationException_New())) }
//line :141:1
func (t *A_arbace_reflect_Method_A) KeySet__Set() jrt.Set { var tmp1 any; var root_96 any = A_arbace_reflect_Method_A_const_22.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any; var root_100 any = A_arbace_reflect_Method_A_const_23.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = t; if linked_101 == nil { arg_99 = ifn_102.Invoke_O__O(arg_103) } else { arg_99 = linked_101.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_100, arg_103) }; if linked_97 == nil { tmp1 = ifn_98.Invoke_O__O(arg_99) } else { tmp1 = linked_97.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_96, arg_99) }; return jrt.Set_Cast(tmp1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) Values__Collection() jrt.Collection { var tmp1 any; var root_104 any = A_arbace_reflect_Method_A_const_21.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = t; if linked_105 == nil { tmp1 = ifn_106.Invoke_O__O(arg_107) } else { tmp1 = linked_105.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_104, arg_107) }; return jrt.Collection_Cast(tmp1) }
//line :141:1
func (t *A_arbace_reflect_Method_A) EntrySet__Set() jrt.Set { var tmp1 any; var root_108 any = A_arbace_reflect_Method_A_const_22.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = t; if linked_109 == nil { tmp1 = ifn_110.Invoke_O__O(arg_111) } else { tmp1 = linked_109.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_108, arg_111) }; return jrt.Set_Cast(tmp1) }
//line :141:1
func A_arbace_reflect_Method_reify__1939000064_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Method_reify__1939000064_A { t := &A_arbace_reflect_Method_reify__1939000064_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000064_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000064_A) Get_O__O(gtarget__1 any) any { var tmp1 any; var root_7 any; var tmp2 *lang.Var; A_arbace_reflect_Method_A_Init(); tmp2 = A_arbace_reflect_Method_A_const_6; root_7 = jrt.NN(tmp2).GetRawRoot__O(); var linked_8 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_7, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_9 lang.IFn; if linked_8 == nil { ifn_9 = lang.IFn_Cast(root_7) } else { ifn_9 = nil }; var arg_10 any = gtarget__1; if linked_8 == nil { tmp1 = ifn_9.Invoke_O__O(arg_10) } else { tmp1 = linked_8.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_7, arg_10) }; if lang.Util_Identical_O_O__Z_NoInit(tmp1, t.F_gclass) { return A_arbace_reflect_Method_A_Cast(gtarget__1).F_declaring_class } else { return t } }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000064_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000064_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_reify__1939000064_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :141:1
func A_arbace_reflect_Method_reify__1939000066_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Method_reify__1939000066_A { t := &A_arbace_reflect_Method_reify__1939000066_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000066_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000066_A) Get_O__O(gtarget__1 any) any { var tmp1 any; var root_11 any; var tmp2 *lang.Var; A_arbace_reflect_Method_A_Init(); tmp2 = A_arbace_reflect_Method_A_const_6; root_11 = jrt.NN(tmp2).GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = gtarget__1; if linked_12 == nil { tmp1 = ifn_13.Invoke_O__O(arg_14) } else { tmp1 = linked_12.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_11, arg_14) }; if lang.Util_Identical_O_O__Z_NoInit(tmp1, t.F_gclass) { return A_arbace_reflect_Method_A_Cast(gtarget__1).F_name } else { return t } }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000066_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000066_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_reify__1939000066_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :141:1
func A_arbace_reflect_Method_reify__1939000068_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Method_reify__1939000068_A { t := &A_arbace_reflect_Method_reify__1939000068_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000068_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000068_A) Get_O__O(gtarget__1 any) any { var tmp1 any; var root_15 any; var tmp2 *lang.Var; A_arbace_reflect_Method_A_Init(); tmp2 = A_arbace_reflect_Method_A_const_6; root_15 = jrt.NN(tmp2).GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = gtarget__1; if linked_16 == nil { tmp1 = ifn_17.Invoke_O__O(arg_18) } else { tmp1 = linked_16.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_15, arg_18) }; if lang.Util_Identical_O_O__Z_NoInit(tmp1, t.F_gclass) { return A_arbace_reflect_Method_A_Cast(gtarget__1).F_return_type } else { return t } }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000068_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000068_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_reify__1939000068_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :141:1
func A_arbace_reflect_Method_reify__1939000070_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Method_reify__1939000070_A { t := &A_arbace_reflect_Method_reify__1939000070_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000070_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000070_A) Get_O__O(gtarget__1 any) any { var tmp1 any; var root_19 any; var tmp2 *lang.Var; A_arbace_reflect_Method_A_Init(); tmp2 = A_arbace_reflect_Method_A_const_6; root_19 = jrt.NN(tmp2).GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = gtarget__1; if linked_20 == nil { tmp1 = ifn_21.Invoke_O__O(arg_22) } else { tmp1 = linked_20.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_19, arg_22) }; if lang.Util_Identical_O_O__Z_NoInit(tmp1, t.F_gclass) { return A_arbace_reflect_Method_A_Cast(gtarget__1).F_parameter_types } else { return t } }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000070_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000070_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_reify__1939000070_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :141:1
func A_arbace_reflect_Method_reify__1939000072_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Method_reify__1939000072_A { t := &A_arbace_reflect_Method_reify__1939000072_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000072_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000072_A) Get_O__O(gtarget__1 any) any { var tmp1 any; var root_23 any; var tmp2 *lang.Var; A_arbace_reflect_Method_A_Init(); tmp2 = A_arbace_reflect_Method_A_const_6; root_23 = jrt.NN(tmp2).GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = gtarget__1; if linked_24 == nil { tmp1 = ifn_25.Invoke_O__O(arg_26) } else { tmp1 = linked_24.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_23, arg_26) }; if lang.Util_Identical_O_O__Z_NoInit(tmp1, t.F_gclass) { return A_arbace_reflect_Method_A_Cast(gtarget__1).F_exception_types } else { return t } }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000072_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000072_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_reify__1939000072_A_New_IPersistentMap_O(m, t.F_gclass) }
//line :141:1
func A_arbace_reflect_Method_reify__1939000074_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_reflect_Method_reify__1939000074_A { t := &A_arbace_reflect_Method_reify__1939000074_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000074_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__gclass any) { t.F___meta = meta__; t.F_gclass = c__gclass }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000074_A) Get_O__O(gtarget__1 any) any { var tmp1 any; var root_27 any; var tmp2 *lang.Var; A_arbace_reflect_Method_A_Init(); tmp2 = A_arbace_reflect_Method_A_const_6; root_27 = jrt.NN(tmp2).GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = gtarget__1; if linked_28 == nil { tmp1 = ifn_29.Invoke_O__O(arg_30) } else { tmp1 = linked_28.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_27, arg_30) }; if lang.Util_Identical_O_O__Z_NoInit(tmp1, t.F_gclass) { return A_arbace_reflect_Method_A_Cast(gtarget__1).F_flags } else { return t } }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000074_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :141:1
func (t *A_arbace_reflect_Method_reify__1939000074_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_reflect_Method_reify__1939000074_A_New_IPersistentMap_O(m, t.F_gclass) }







































































































































type A_arbace_reflect_Method_A struct{ jrt.Object; F_name, F_return_type, F_declaring_class, F_parameter_types, F_exception_types, F_flags, F___meta, F___extmap any; F___hash, F___hasheq int32 }

func (t *A_arbace_reflect_Method_A) Is_IRecord() {}

func (t *A_arbace_reflect_Method_A) Is_IHashEq() {}

func (t *A_arbace_reflect_Method_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_A) Is_ILookup() {}

func (t *A_arbace_reflect_Method_A) Is_IKeywordLookup() {}

func (t *A_arbace_reflect_Method_A) Is_IPersistentMap() {}

func (t *A_arbace_reflect_Method_A) Is_Map() {}

func (t *A_arbace_reflect_Method_A) Is_Serializable() {}

func (t *A_arbace_reflect_Method_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_A) Is_Iterable() {}

func (t *A_arbace_reflect_Method_A) Is_Associative() {}

func (t *A_arbace_reflect_Method_A) Is_Counted() {}

func (t *A_arbace_reflect_Method_A) Is_IPersistentCollection() {}

func (t *A_arbace_reflect_Method_A) Is_Seqable() {}

var A_arbace_reflect_Method_A_const_pool *jrt.RefArray

var A_arbace_reflect_Method_A_const_0 *lang.Keyword

var A_arbace_reflect_Method_A_const_1 *lang.Keyword

var A_arbace_reflect_Method_A_const_2 *lang.Keyword

var A_arbace_reflect_Method_A_const_3 *lang.Keyword

var A_arbace_reflect_Method_A_const_4 *lang.Keyword

var A_arbace_reflect_Method_A_const_5 *lang.Keyword

var A_arbace_reflect_Method_A_const_6 *lang.Var

var A_arbace_reflect_Method_A_const_7 *lang.Var

var A_arbace_reflect_Method_A_const_8 *lang.Var

var A_arbace_reflect_Method_A_const_9 *lang.Var

var A_arbace_reflect_Method_A_const_10 *lang.Var

var A_arbace_reflect_Method_A_const_11 any

var A_arbace_reflect_Method_A_const_12 *lang.Var

var A_arbace_reflect_Method_A_const_13 *lang.Var

var A_arbace_reflect_Method_A_const_14 *lang.Var

var A_arbace_reflect_Method_A_const_15 any

var A_arbace_reflect_Method_A_const_16 *lang.Var

var A_arbace_reflect_Method_A_const_17 *lang.Var

var A_arbace_reflect_Method_A_const_18 *lang.Var

var A_arbace_reflect_Method_A_const_19 *lang.Var

var A_arbace_reflect_Method_A_const_20 *lang.Var

var A_arbace_reflect_Method_A_const_21 *lang.Var

var A_arbace_reflect_Method_A_const_22 *lang.Var

var A_arbace_reflect_Method_A_const_23 *lang.Var

var A_arbace_reflect_Method_A_init jrt.ClassInit

func A_arbace_reflect_Method_A_Init() { if !A_arbace_reflect_Method_A_init.Done() { A_arbace_reflect_Method_A_init.Run(A_arbace_reflect_Method_A_clinit) } }

func A_arbace_reflect_Method_A_clinit() { A_arbace_reflect_Method_A_clinit_p0(); A_arbace_reflect_Method_A_clinit_p1(); A_arbace_reflect_Method_A_clinit_p2() }

func A_arbace_reflect_Method_A_clinit_p0() { jrt.StartCheck(); A_arbace_reflect_Method_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_39, 30); A_arbace_reflect_Method_A_const_0 = lang.Keyword_Cast(A_arbace_reflect_Method_A_const_pool.A[6]); A_arbace_reflect_Method_A_const_1 = lang.Keyword_Cast(A_arbace_reflect_Method_A_const_pool.A[7]); A_arbace_reflect_Method_A_const_2 = lang.Keyword_Cast(A_arbace_reflect_Method_A_const_pool.A[8]); A_arbace_reflect_Method_A_const_3 = lang.Keyword_Cast(A_arbace_reflect_Method_A_const_pool.A[9]); A_arbace_reflect_Method_A_const_4 = lang.Keyword_Cast(A_arbace_reflect_Method_A_const_pool.A[10]); A_arbace_reflect_Method_A_const_5 = lang.Keyword_Cast(A_arbace_reflect_Method_A_const_pool.A[11]); A_arbace_reflect_Method_A_const_6 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[12]); A_arbace_reflect_Method_A_const_7 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[13]); A_arbace_reflect_Method_A_const_8 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[14]); A_arbace_reflect_Method_A_const_9 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[15]); A_arbace_reflect_Method_A_const_10 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[16]) }

func A_arbace_reflect_Method_A_clinit_p1() { A_arbace_reflect_Method_A_const_11 = A_arbace_reflect_Method_A_const_pool.A[17]; A_arbace_reflect_Method_A_const_12 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[18]); A_arbace_reflect_Method_A_const_13 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[19]); A_arbace_reflect_Method_A_const_14 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[20]); A_arbace_reflect_Method_A_const_15 = A_arbace_reflect_Method_A_const_pool.A[21]; A_arbace_reflect_Method_A_const_16 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[22]); A_arbace_reflect_Method_A_const_17 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[23]); A_arbace_reflect_Method_A_const_18 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[24]); A_arbace_reflect_Method_A_const_19 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[25]); A_arbace_reflect_Method_A_const_20 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[26]); A_arbace_reflect_Method_A_const_21 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[27]); A_arbace_reflect_Method_A_const_22 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[28]) }

func A_arbace_reflect_Method_A_clinit_p2() { A_arbace_reflect_Method_A_const_23 = lang.Var_Cast(A_arbace_reflect_Method_A_const_pool.A[29]) }

func (t *A_arbace_reflect_Method_A) Assoc_O_O__Associative(p0, p1 any) lang.Associative { return t.Assoc_O_O__IPersistentMap(p0, p1) }

func (t *A_arbace_reflect_Method_A) Spliterator__Spliterator() jrt.Spliterator { return jrt.Iterable_Spliterator__Spliterator(t) }

func (t *A_arbace_reflect_Method_A) Replace_O_O__O(p0, p1 any) any { return jrt.Map_Replace_O_O__O(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) AssocEx_O_O__IPersistentMap(p0, p1 any) lang.IPersistentMap { panic(jrt.AbstractMethodError_New_String(jrt.Str("Receiver class arbace.reflect.Method does not define or inherit an implementation of the resolved method 'abstract arbace.lang.IPersistentMap assocEx(java.lang.Object, java.lang.Object)' of interface arbace.lang.IPersistentMap."))) }

func (t *A_arbace_reflect_Method_A) Compute_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_Compute_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) Remove_O_O__Z(p0, p1 any) bool { return jrt.Map_Remove_O_O__Z(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) GetOrDefault_O_O__O(p0, p1 any) any { return jrt.Map_GetOrDefault_O_O__O(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) Merge_O_O_BiFunction__O(p0, p1 any, p2 jrt.BiFunction) any { return jrt.Map_Merge_O_O_BiFunction__O(t, p0, p1, p2) }

func (t *A_arbace_reflect_Method_A) ComputeIfPresent_O_BiFunction__O(p0 any, p1 jrt.BiFunction) any { return jrt.Map_ComputeIfPresent_O_BiFunction__O(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) ReplaceAll_BiFunction__V(p0 jrt.BiFunction) { jrt.Map_ReplaceAll_BiFunction__V(t, p0) }

func (t *A_arbace_reflect_Method_A) PutIfAbsent_O_O__O(p0, p1 any) any { return jrt.Map_PutIfAbsent_O_O__O(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) ForEach_BiConsumer__V(p0 jrt.BiConsumer) { jrt.Map_ForEach_BiConsumer__V(t, p0) }

func (t *A_arbace_reflect_Method_A) ForEach_Consumer__V(p0 jrt.Consumer) { jrt.Iterable_ForEach_Consumer__V(t, p0) }

func (t *A_arbace_reflect_Method_A) Replace_O_O_O__Z(p0, p1, p2 any) bool { return jrt.Map_Replace_O_O_O__Z(t, p0, p1, p2) }

func (t *A_arbace_reflect_Method_A) ComputeIfAbsent_O_Function__O(p0 any, p1 jrt.Function) any { return jrt.Map_ComputeIfAbsent_O_Function__O(t, p0, p1) }

func (t *A_arbace_reflect_Method_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_A_class }

func (t *A_arbace_reflect_Method_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_A); return ok }

func A_arbace_reflect_Method_A_Cast(x any) *A_arbace_reflect_Method_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_A_class)) }; return v }



type A_arbace_reflect_Method_reify__1939000064_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Method_reify__1939000064_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Method_reify__1939000064_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_reify__1939000064_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_reify__1939000064_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_reify__1939000064_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_reify__1939000064_A_class }

func (t *A_arbace_reflect_Method_reify__1939000064_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_reify__1939000064_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_reify__1939000064_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_reify__1939000064_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_reify__1939000064_A); return ok }

func A_arbace_reflect_Method_reify__1939000064_A_Cast(x any) *A_arbace_reflect_Method_reify__1939000064_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_reify__1939000064_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_reify__1939000064_A_class)) }; return v }



type A_arbace_reflect_Method_reify__1939000066_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Method_reify__1939000066_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Method_reify__1939000066_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_reify__1939000066_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_reify__1939000066_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_reify__1939000066_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_reify__1939000066_A_class }

func (t *A_arbace_reflect_Method_reify__1939000066_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_reify__1939000066_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_reify__1939000066_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_reify__1939000066_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_reify__1939000066_A); return ok }

func A_arbace_reflect_Method_reify__1939000066_A_Cast(x any) *A_arbace_reflect_Method_reify__1939000066_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_reify__1939000066_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_reify__1939000066_A_class)) }; return v }



type A_arbace_reflect_Method_reify__1939000068_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Method_reify__1939000068_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Method_reify__1939000068_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_reify__1939000068_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_reify__1939000068_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_reify__1939000068_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_reify__1939000068_A_class }

func (t *A_arbace_reflect_Method_reify__1939000068_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_reify__1939000068_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_reify__1939000068_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_reify__1939000068_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_reify__1939000068_A); return ok }

func A_arbace_reflect_Method_reify__1939000068_A_Cast(x any) *A_arbace_reflect_Method_reify__1939000068_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_reify__1939000068_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_reify__1939000068_A_class)) }; return v }



type A_arbace_reflect_Method_reify__1939000070_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Method_reify__1939000070_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Method_reify__1939000070_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_reify__1939000070_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_reify__1939000070_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_reify__1939000070_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_reify__1939000070_A_class }

func (t *A_arbace_reflect_Method_reify__1939000070_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_reify__1939000070_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_reify__1939000070_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_reify__1939000070_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_reify__1939000070_A); return ok }

func A_arbace_reflect_Method_reify__1939000070_A_Cast(x any) *A_arbace_reflect_Method_reify__1939000070_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_reify__1939000070_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_reify__1939000070_A_class)) }; return v }



type A_arbace_reflect_Method_reify__1939000072_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Method_reify__1939000072_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Method_reify__1939000072_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_reify__1939000072_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_reify__1939000072_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_reify__1939000072_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_reify__1939000072_A_class }

func (t *A_arbace_reflect_Method_reify__1939000072_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_reify__1939000072_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_reify__1939000072_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_reify__1939000072_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_reify__1939000072_A); return ok }

func A_arbace_reflect_Method_reify__1939000072_A_Cast(x any) *A_arbace_reflect_Method_reify__1939000072_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_reify__1939000072_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_reify__1939000072_A_class)) }; return v }



type A_arbace_reflect_Method_reify__1939000074_A struct{ jrt.Object; F_gclass any; F___meta lang.IPersistentMap }

func (t *A_arbace_reflect_Method_reify__1939000074_A) Is_ILookupThunk() {}

func (t *A_arbace_reflect_Method_reify__1939000074_A) Is_IObj() {}

func (t *A_arbace_reflect_Method_reify__1939000074_A) Is_IMeta() {}

func (t *A_arbace_reflect_Method_reify__1939000074_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect_Method_reify__1939000074_A) GetClass__Class() *jrt.Class { return A_arbace_reflect_Method_reify__1939000074_A_class }

func (t *A_arbace_reflect_Method_reify__1939000074_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect_Method_reify__1939000074_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect_Method_reify__1939000074_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect_Method_reify__1939000074_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect_Method_reify__1939000074_A); return ok }

func A_arbace_reflect_Method_reify__1939000074_A_Cast(x any) *A_arbace_reflect_Method_reify__1939000074_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect_Method_reify__1939000074_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect_Method_reify__1939000074_A_class)) }; return v }
