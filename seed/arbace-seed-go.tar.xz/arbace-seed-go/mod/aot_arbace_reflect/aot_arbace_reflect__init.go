//line aot_arbace_reflect__init.ae:1
package aot_arbace_reflect

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_reflect__init_A_Load__O() any { A_arbace_reflect__init_A_Init(); jrt.StartCheck(); A_arbace_reflect__init_A_Unit0__O(); A_arbace_reflect__init_A_Unit1__O(); A_arbace_reflect__init_A_Unit2__O(); A_arbace_reflect__init_A_Unit3__O(); A_arbace_reflect__init_A_Unit4__O(); A_arbace_reflect__init_A_Unit5__O(); A_arbace_reflect__init_A_Unit6__O(); A_arbace_reflect__init_A_Unit7__O(); A_arbace_reflect__init_A_Unit8__O(); A_arbace_reflect__init_A_Unit9__O(); A_arbace_reflect__init_A_Unit10__O(); A_arbace_reflect__init_A_Unit11__O(); A_arbace_reflect__init_A_Unit12__O(); A_arbace_reflect__init_A_Unit13__O(); A_arbace_reflect__init_A_Unit14__O(); A_arbace_reflect__init_A_Unit15__O(); A_arbace_reflect__init_A_Unit16__O(); A_arbace_reflect__init_A_Unit17__O(); A_arbace_reflect__init_A_Unit18__O(); A_arbace_reflect__init_A_Unit19__O(); A_arbace_reflect__init_A_Unit20__O(); A_arbace_reflect__init_A_Unit21__O(); return nil }



func A_arbace_reflect__init_A_Unit0__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_reflect__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect__init_A_const_1) }
//line :9:1
func A_arbace_reflect__init_A_Unit1__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_reflect__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_2)) }
//line :9:1
func A_arbace_reflect__init_A_Unit2__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); var tmp1 any = A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_reflect__init_A_Unit3__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_reflect__init_A_const_1)).Equals_O__Z(A_arbace_reflect__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_reflect_eval659000008_fn__659000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_reflect_eval659000008_fn__659000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_reflect_eval659000008_fn__659000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }


































func A_arbace_reflect__init_A_Unit4__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_reflect__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_5)); v__1927001498__auto____1 = A_arbace_reflect__init_A_const_4; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_reflect__init_A_const_4; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_6)); A_arbace_reflect__init_A_const_4.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_reflect__init_A_const_4 } }
//line :44:1
func A_arbace_reflect__init_A_Unit5__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); return A_arbace_reflect__init_A_const_7 }
//line :44:1
func A_arbace_reflect__init_A_Unit6__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect__init_A_const_8.GetRawRoot__O()); var tmp2 any = A_arbace_reflect__init_A_const_4; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_reflect__init_A_const_9.GetRawRoot__O(), A_arbace_reflect__init_A_const_10, Lit_45) }
//line :44:1
func A_arbace_reflect__init_A_Unit7__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); return A_arbace_reflect__init_A_const_11.Invoke_O_O__O(A_arbace_reflect__init_A_const_4, A_arbace_reflect__init_A_const_12) }
//line :44:1
func A_arbace_reflect__init_A_Unit8__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect__init_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_reflect__init_A_const_4; var tmp3 any = A_arbace_reflect__init_A_const_14.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_reflect__init_A_const_9.GetRawRoot__O()); var tmp5 any = A_arbace_reflect__init_A_const_15; var tmp6 any = A_arbace_reflect__init_A_const_16; var tmp7 any = A_arbace_reflect__init_A_const_17; var tmp8 any = A_arbace_reflect__init_A_const_18; var tmp9 any = A_arbace_reflect__init_A_const_4; var tmp10 any = A_arbace_reflect__init_A_const_19; var tmp11 any = A_arbace_reflect__init_A_const_20; var tmp12 any = A_arbace_reflect__init_A_const_21; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_reflect__init_A_const_24.GetRawRoot__O()); var tmp14 any = A_arbace_reflect__init_A_const_25; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_reflect__init_A_const_14.GetRawRoot__O()); var tmp16 any = A_arbace_reflect__init_A_const_26; var tmp17 any = lang.IFn_Cast(A_arbace_reflect__init_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect__init_A_const_23.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_reflect__init_A_const_27, A_arbace_reflect__init_A_const_4))))); var tmp18 any = A_arbace_reflect_eval659000020_fn__659000021_A_New(); var tmp19 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_reflect_eval659000020_fn__659000021_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_reflect_eval659000020_fn__659000021_A_fn_class = fncls__3d; tmp19 = fncls__3d } else { tmp19 = fncls__3 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :44:1
func A_arbace_reflect__init_A_Unit9__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); return lang.IFn_Cast(A_arbace_reflect__init_A_const_28.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect__init_A_const_4.GetRawRoot__O()) }
//line :44:1
func A_arbace_reflect__init_A_Unit10__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); return A_arbace_reflect__init_A_const_29 }



func A_arbace_reflect__init_A_Unit11__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_reflect__init_A_const_30; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_31)); v__1927001498__auto____1 = A_arbace_reflect__init_A_const_30; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_reflect__init_A_const_30; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_32)); A_arbace_reflect__init_A_const_30.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_reflect__init_A_const_30 } }
//line :48:1
func A_arbace_reflect__init_A_Unit12__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_reflect__init_A_const_33 }
//line :48:1
func A_arbace_reflect__init_A_Unit13__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect__init_A_const_8.GetRawRoot__O()); var tmp2 any = A_arbace_reflect__init_A_const_30; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_reflect__init_A_const_9.GetRawRoot__O(), A_arbace_reflect__init_A_const_10, Lit_47) }
//line :48:1
func A_arbace_reflect__init_A_Unit14__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_reflect__init_A_const_11.Invoke_O_O__O(A_arbace_reflect__init_A_const_30, A_arbace_reflect__init_A_const_34) }
//line :48:1
func A_arbace_reflect__init_A_Unit15__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_reflect__init_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_reflect__init_A_const_30; var tmp3 any = A_arbace_reflect__init_A_const_14.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_reflect__init_A_const_9.GetRawRoot__O()); var tmp5 any = A_arbace_reflect__init_A_const_35; var tmp6 any = A_arbace_reflect__init_A_const_16; var tmp7 any = A_arbace_reflect__init_A_const_36; var tmp8 any = A_arbace_reflect__init_A_const_18; var tmp9 any = A_arbace_reflect__init_A_const_30; var tmp10 any = A_arbace_reflect__init_A_const_19; var tmp11 any = A_arbace_reflect__init_A_const_37; var tmp12 any = A_arbace_reflect__init_A_const_21; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_reflect__init_A_const_24.GetRawRoot__O()); var tmp14 any = A_arbace_reflect__init_A_const_38; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_reflect__init_A_const_14.GetRawRoot__O()); var tmp16 any = A_arbace_reflect__init_A_const_39; var tmp17 any = lang.IFn_Cast(A_arbace_reflect__init_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_reflect__init_A_const_23.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_reflect__init_A_const_27, A_arbace_reflect__init_A_const_30))))); var tmp18 any = A_arbace_reflect_eval659000044_fn__659000045_A_New(); var tmp19 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_reflect_eval659000044_fn__659000045_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_reflect_eval659000044_fn__659000045_A_fn_class = fncls__4d; tmp19 = fncls__4d } else { tmp19 = fncls__4 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :48:1
func A_arbace_reflect__init_A_Unit16__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return lang.IFn_Cast(A_arbace_reflect__init_A_const_28.GetRawRoot__O()).Invoke_O__O(A_arbace_reflect__init_A_const_30.GetRawRoot__O()) }
//line :48:1
func A_arbace_reflect__init_A_Unit17__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_reflect__init_A_const_40 }







func A_arbace_reflect__init_A_Unit18__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_reflect__init_A_const_41; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_42)); return A_arbace_reflect__init_A_const_41 }

func A_arbace_reflect__init_A_Unit19__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); var tmp1 *lang.Var = A_arbace_reflect__init_A_const_43; var tmp2 any = A_arbace_reflect_type_reflect_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_reflect_type_reflect_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, true); A_arbace_reflect_type_reflect_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_reflect__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_44)); return A_arbace_reflect__init_A_const_43 }
























































func A_arbace_reflect__init_A_Unit20__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(115, 1); var tmp1 *lang.Var = A_arbace_reflect__init_A_const_45; var tmp2 any = A_arbace_reflect_reflect_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_reflect_reflect_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, true); A_arbace_reflect_reflect_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_reflect__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_46)); return A_arbace_reflect__init_A_const_45 }







func A_arbace_reflect__init_A_Unit21__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); return lang.IFn_Cast(A_arbace_reflect__init_A_const_47.GetRawRoot__O()).Invoke_O__O(Lit_51) }



type A_arbace_reflect__init_A struct{ jrt.Object }

var A_arbace_reflect__init_A_const_pool *jrt.RefArray

var A_arbace_reflect__init_A_const_0 *lang.Var

var A_arbace_reflect__init_A_const_1 any

var A_arbace_reflect__init_A_const_2 any

var A_arbace_reflect__init_A_const_3 any

var A_arbace_reflect__init_A_const_4 *lang.Var

var A_arbace_reflect__init_A_const_5 any

var A_arbace_reflect__init_A_const_6 any

var A_arbace_reflect__init_A_const_7 *jrt.Class

var A_arbace_reflect__init_A_const_8 *lang.Var

var A_arbace_reflect__init_A_const_9 *lang.Var

var A_arbace_reflect__init_A_const_10 *lang.Keyword

var A_arbace_reflect__init_A_const_11 *lang.Var

var A_arbace_reflect__init_A_const_12 any

var A_arbace_reflect__init_A_const_13 *lang.Var

var A_arbace_reflect__init_A_const_14 *lang.Var

var A_arbace_reflect__init_A_const_15 any

var A_arbace_reflect__init_A_const_16 *lang.Keyword

var A_arbace_reflect__init_A_const_17 any

var A_arbace_reflect__init_A_const_18 *lang.Keyword

var A_arbace_reflect__init_A_const_19 *lang.Keyword

var A_arbace_reflect__init_A_const_20 any

var A_arbace_reflect__init_A_const_21 *lang.Keyword

var A_arbace_reflect__init_A_const_22 *lang.Var

var A_arbace_reflect__init_A_const_23 *lang.Var

var A_arbace_reflect__init_A_const_24 *lang.Var

var A_arbace_reflect__init_A_const_25 any

var A_arbace_reflect__init_A_const_26 any

var A_arbace_reflect__init_A_const_27 *lang.Keyword

var A_arbace_reflect__init_A_const_28 *lang.Var

var A_arbace_reflect__init_A_const_29 any

var A_arbace_reflect__init_A_const_30 *lang.Var

var A_arbace_reflect__init_A_const_31 any

var A_arbace_reflect__init_A_const_32 any

var A_arbace_reflect__init_A_const_33 *jrt.Class

var A_arbace_reflect__init_A_const_34 any

var A_arbace_reflect__init_A_const_35 any

var A_arbace_reflect__init_A_const_36 any

var A_arbace_reflect__init_A_const_37 any

var A_arbace_reflect__init_A_const_38 any

var A_arbace_reflect__init_A_const_39 any

var A_arbace_reflect__init_A_const_40 any

var A_arbace_reflect__init_A_const_41 *lang.Var

var A_arbace_reflect__init_A_const_42 any

var A_arbace_reflect__init_A_const_43 *lang.Var

var A_arbace_reflect__init_A_const_44 any

var A_arbace_reflect__init_A_const_45 *lang.Var

var A_arbace_reflect__init_A_const_46 any

var A_arbace_reflect__init_A_const_47 *lang.Var

var A_arbace_reflect__init_A_init jrt.ClassInit

func A_arbace_reflect__init_A_Init() { if !A_arbace_reflect__init_A_init.Done() { A_arbace_reflect__init_A_init.Run(A_arbace_reflect__init_A_clinit) } }

func A_arbace_reflect__init_A_clinit() { A_arbace_reflect__init_A_clinit_p0(); A_arbace_reflect__init_A_clinit_p1(); A_arbace_reflect__init_A_clinit_p2(); A_arbace_reflect__init_A_clinit_p3() }

func A_arbace_reflect__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_reflect__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_42, 78); A_arbace_reflect__init_A_const_0 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[30]); A_arbace_reflect__init_A_const_1 = A_arbace_reflect__init_A_const_pool.A[31]; A_arbace_reflect__init_A_const_2 = A_arbace_reflect__init_A_const_pool.A[32]; A_arbace_reflect__init_A_const_3 = A_arbace_reflect__init_A_const_pool.A[33]; A_arbace_reflect__init_A_const_4 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[34]); A_arbace_reflect__init_A_const_5 = A_arbace_reflect__init_A_const_pool.A[35]; A_arbace_reflect__init_A_const_6 = A_arbace_reflect__init_A_const_pool.A[36]; A_arbace_reflect__init_A_const_7 = jrt.Class_Cast(A_arbace_reflect__init_A_const_pool.A[37]); A_arbace_reflect__init_A_const_8 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[38]); A_arbace_reflect__init_A_const_9 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[39]); A_arbace_reflect__init_A_const_10 = lang.Keyword_Cast(A_arbace_reflect__init_A_const_pool.A[40]); A_arbace_reflect__init_A_const_11 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[41]) }

func A_arbace_reflect__init_A_clinit_p1() { A_arbace_reflect__init_A_const_12 = A_arbace_reflect__init_A_const_pool.A[42]; A_arbace_reflect__init_A_const_13 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[43]); A_arbace_reflect__init_A_const_14 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[44]); A_arbace_reflect__init_A_const_15 = A_arbace_reflect__init_A_const_pool.A[45]; A_arbace_reflect__init_A_const_16 = lang.Keyword_Cast(A_arbace_reflect__init_A_const_pool.A[46]); A_arbace_reflect__init_A_const_17 = A_arbace_reflect__init_A_const_pool.A[47]; A_arbace_reflect__init_A_const_18 = lang.Keyword_Cast(A_arbace_reflect__init_A_const_pool.A[48]); A_arbace_reflect__init_A_const_19 = lang.Keyword_Cast(A_arbace_reflect__init_A_const_pool.A[49]); A_arbace_reflect__init_A_const_20 = A_arbace_reflect__init_A_const_pool.A[50]; A_arbace_reflect__init_A_const_21 = lang.Keyword_Cast(A_arbace_reflect__init_A_const_pool.A[51]); A_arbace_reflect__init_A_const_22 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[52]); A_arbace_reflect__init_A_const_23 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[53]); A_arbace_reflect__init_A_const_24 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[54]) }

func A_arbace_reflect__init_A_clinit_p2() { A_arbace_reflect__init_A_const_25 = A_arbace_reflect__init_A_const_pool.A[55]; A_arbace_reflect__init_A_const_26 = A_arbace_reflect__init_A_const_pool.A[56]; A_arbace_reflect__init_A_const_27 = lang.Keyword_Cast(A_arbace_reflect__init_A_const_pool.A[57]); A_arbace_reflect__init_A_const_28 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[58]); A_arbace_reflect__init_A_const_29 = A_arbace_reflect__init_A_const_pool.A[59]; A_arbace_reflect__init_A_const_30 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[60]); A_arbace_reflect__init_A_const_31 = A_arbace_reflect__init_A_const_pool.A[61]; A_arbace_reflect__init_A_const_32 = A_arbace_reflect__init_A_const_pool.A[62]; A_arbace_reflect__init_A_const_33 = jrt.Class_Cast(A_arbace_reflect__init_A_const_pool.A[63]); A_arbace_reflect__init_A_const_34 = A_arbace_reflect__init_A_const_pool.A[64]; A_arbace_reflect__init_A_const_35 = A_arbace_reflect__init_A_const_pool.A[65]; A_arbace_reflect__init_A_const_36 = A_arbace_reflect__init_A_const_pool.A[66]; A_arbace_reflect__init_A_const_37 = A_arbace_reflect__init_A_const_pool.A[67]; A_arbace_reflect__init_A_const_38 = A_arbace_reflect__init_A_const_pool.A[68] }

func A_arbace_reflect__init_A_clinit_p3() { A_arbace_reflect__init_A_const_39 = A_arbace_reflect__init_A_const_pool.A[69]; A_arbace_reflect__init_A_const_40 = A_arbace_reflect__init_A_const_pool.A[70]; A_arbace_reflect__init_A_const_41 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[71]); A_arbace_reflect__init_A_const_42 = A_arbace_reflect__init_A_const_pool.A[72]; A_arbace_reflect__init_A_const_43 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[73]); A_arbace_reflect__init_A_const_44 = A_arbace_reflect__init_A_const_pool.A[74]; A_arbace_reflect__init_A_const_45 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[75]); A_arbace_reflect__init_A_const_46 = A_arbace_reflect__init_A_const_pool.A[76]; A_arbace_reflect__init_A_const_47 = lang.Var_Cast(A_arbace_reflect__init_A_const_pool.A[77]) }

func A_arbace_reflect__init_A_New() *A_arbace_reflect__init_A { A_arbace_reflect__init_A_Init(); t := &A_arbace_reflect__init_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect__init_A) Ctor() {}

func (t *A_arbace_reflect__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect__init_A) GetClass__Class() *jrt.Class { return A_arbace_reflect__init_A_class }

func (t *A_arbace_reflect__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_reflect__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect__init_A); return ok }

func A_arbace_reflect__init_A_Cast(x any) *A_arbace_reflect__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect__init_A_class)) }; return v }
