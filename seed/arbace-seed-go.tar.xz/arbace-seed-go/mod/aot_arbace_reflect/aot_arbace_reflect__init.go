//line aot_arbace_reflect__init.ae:1
package aot_arbace_reflect

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_reflect__init_A_Load__O() any { A_arbace_reflect__init_A_Init(); A_arbace_reflect__init_A_Unit0__O(); A_arbace_reflect__init_A_Unit1__O(); A_arbace_reflect__init_A_Unit2__O(); A_arbace_reflect__init_A_Unit3__O(); A_arbace_reflect__init_A_Unit4__O(); A_arbace_reflect__init_A_Unit5__O(); A_arbace_reflect__init_A_Unit6__O(); A_arbace_reflect__init_A_Unit7__O(); A_arbace_reflect__init_A_Unit8__O(); A_arbace_reflect__init_A_Unit9__O(); A_arbace_reflect__init_A_Unit10__O(); A_arbace_reflect__init_A_Unit11__O(); A_arbace_reflect__init_A_Unit12__O(); A_arbace_reflect__init_A_Unit13__O(); A_arbace_reflect__init_A_Unit14__O(); A_arbace_reflect__init_A_Unit15__O(); A_arbace_reflect__init_A_Unit16__O(); A_arbace_reflect__init_A_Unit17__O(); A_arbace_reflect__init_A_Unit18__O(); A_arbace_reflect__init_A_Unit19__O(); A_arbace_reflect__init_A_Unit20__O(); A_arbace_reflect__init_A_Unit21__O(); return nil }



func A_arbace_reflect__init_A_Unit0__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_reflect__init_A_const_1) }
//line :9:1
func A_arbace_reflect__init_A_Unit1__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_reflect__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_2)) }
//line :9:1
func A_arbace_reflect__init_A_Unit2__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 any = A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_New(); var tmp2 *jrt.Class; A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_Init(); tmp2 = A_arbace_reflect_eval659000004_loading__1927001464__auto____659000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_reflect__init_A_Unit3__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_reflect__init_A_const_1)).Equals_O__Z(A_arbace_reflect__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_reflect_eval659000008_fn__659000009_A_New(); var tmp2 *jrt.Class; A_arbace_reflect_eval659000008_fn__659000009_A_Init(); tmp2 = A_arbace_reflect_eval659000008_fn__659000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }


































func A_arbace_reflect__init_A_Unit4__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_reflect__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_5)); v__1927001498__auto____1 = A_arbace_reflect__init_A_const_4.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_reflect__init_A_const_4; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_6)); var tmp3 *lang.Var = A_arbace_reflect__init_A_const_4; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_reflect__init_A_const_4.Ref() } }
//line :44:1
func A_arbace_reflect__init_A_Unit5__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); return A_arbace_reflect__init_A_const_7.Ref() }
//line :44:1
func A_arbace_reflect__init_A_Unit6__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_8).GetRawRoot__O()); var tmp2 any = A_arbace_reflect__init_A_const_4.Ref(); return tmp1.Invoke_O_O_O_O__O(tmp2, jrt.NN(A_arbace_reflect__init_A_const_9).GetRawRoot__O(), A_arbace_reflect__init_A_const_10.Ref(), Lit_171) }
//line :44:1
func A_arbace_reflect__init_A_Unit7__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); return Up_Var_IFn(A_arbace_reflect__init_A_const_11).Invoke_O_O__O(A_arbace_reflect__init_A_const_4.Ref(), A_arbace_reflect__init_A_const_12) }
//line :44:1
func A_arbace_reflect__init_A_Unit8__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_13).GetRawRoot__O()); var tmp2 any = A_arbace_reflect__init_A_const_4.Ref(); var tmp3 any = jrt.NN(A_arbace_reflect__init_A_const_14).GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_9).GetRawRoot__O()); var tmp5 any = A_arbace_reflect__init_A_const_15; var tmp6 any = A_arbace_reflect__init_A_const_16.Ref(); var tmp7 any = A_arbace_reflect__init_A_const_17; var tmp8 any = A_arbace_reflect__init_A_const_18.Ref(); var tmp9 any = A_arbace_reflect__init_A_const_4.Ref(); var tmp10 any = A_arbace_reflect__init_A_const_19.Ref(); var tmp11 any = A_arbace_reflect__init_A_const_20; var tmp12 any = A_arbace_reflect__init_A_const_21.Ref(); var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_24).GetRawRoot__O()); var tmp14 any = A_arbace_reflect__init_A_const_25; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_14).GetRawRoot__O()); var tmp16 any = A_arbace_reflect__init_A_const_26; var tmp17 any = lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_22).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_reflect__init_A_const_23).Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_reflect__init_A_const_27.Ref(), A_arbace_reflect__init_A_const_4.Ref()))))); var tmp18 any = A_arbace_reflect_eval659000020_fn__659000021_A_New(); var tmp19 *jrt.Class; A_arbace_reflect_eval659000020_fn__659000021_A_Init(); tmp19 = A_arbace_reflect_eval659000020_fn__659000021_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :44:1
func A_arbace_reflect__init_A_Unit9__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); return lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_28).GetRawRoot__O()).Invoke_O__O(jrt.NN(A_arbace_reflect__init_A_const_4).GetRawRoot__O()) }
//line :44:1
func A_arbace_reflect__init_A_Unit10__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(44, 1); return A_arbace_reflect__init_A_const_29 }



func A_arbace_reflect__init_A_Unit11__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_reflect__init_A_const_30; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_31)); v__1927001498__auto____1 = A_arbace_reflect__init_A_const_30.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_reflect__init_A_const_30; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_32)); var tmp3 *lang.Var = A_arbace_reflect__init_A_const_30; var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Ref()); return A_arbace_reflect__init_A_const_30.Ref() } }
//line :48:1
func A_arbace_reflect__init_A_Unit12__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return A_arbace_reflect__init_A_const_33.Ref() }
//line :48:1
func A_arbace_reflect__init_A_Unit13__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_8).GetRawRoot__O()); var tmp2 any = A_arbace_reflect__init_A_const_30.Ref(); return tmp1.Invoke_O_O_O_O__O(tmp2, jrt.NN(A_arbace_reflect__init_A_const_9).GetRawRoot__O(), A_arbace_reflect__init_A_const_10.Ref(), Lit_184) }
//line :48:1
func A_arbace_reflect__init_A_Unit14__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return Up_Var_IFn(A_arbace_reflect__init_A_const_11).Invoke_O_O__O(A_arbace_reflect__init_A_const_30.Ref(), A_arbace_reflect__init_A_const_34) }
//line :48:1
func A_arbace_reflect__init_A_Unit15__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_13).GetRawRoot__O()); var tmp2 any = A_arbace_reflect__init_A_const_30.Ref(); var tmp3 any = jrt.NN(A_arbace_reflect__init_A_const_14).GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_9).GetRawRoot__O()); var tmp5 any = A_arbace_reflect__init_A_const_35; var tmp6 any = A_arbace_reflect__init_A_const_16.Ref(); var tmp7 any = A_arbace_reflect__init_A_const_36; var tmp8 any = A_arbace_reflect__init_A_const_18.Ref(); var tmp9 any = A_arbace_reflect__init_A_const_30.Ref(); var tmp10 any = A_arbace_reflect__init_A_const_19.Ref(); var tmp11 any = A_arbace_reflect__init_A_const_37; var tmp12 any = A_arbace_reflect__init_A_const_21.Ref(); var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_24).GetRawRoot__O()); var tmp14 any = A_arbace_reflect__init_A_const_38; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_14).GetRawRoot__O()); var tmp16 any = A_arbace_reflect__init_A_const_39; var tmp17 any = lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_22).GetRawRoot__O()).Invoke_O_O__O(jrt.NN(A_arbace_reflect__init_A_const_23).Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_reflect__init_A_const_27.Ref(), A_arbace_reflect__init_A_const_30.Ref()))))); var tmp18 any = A_arbace_reflect_eval659000044_fn__659000045_A_New(); var tmp19 *jrt.Class; A_arbace_reflect_eval659000044_fn__659000045_A_Init(); tmp19 = A_arbace_reflect_eval659000044_fn__659000045_A_fn_class; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil))))) }
//line :48:1
func A_arbace_reflect__init_A_Unit16__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_28).GetRawRoot__O()).Invoke_O__O(jrt.NN(A_arbace_reflect__init_A_const_30).GetRawRoot__O()) }
//line :48:1
func A_arbace_reflect__init_A_Unit17__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); return A_arbace_reflect__init_A_const_40 }







func A_arbace_reflect__init_A_Unit18__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(56, 1); var tmp1 *lang.Var = A_arbace_reflect__init_A_const_41; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_42)); return A_arbace_reflect__init_A_const_41.Ref() }

func A_arbace_reflect__init_A_Unit19__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); var tmp1 *lang.Var = A_arbace_reflect__init_A_const_43; var tmp2 any = A_arbace_reflect_type_reflect_A_New(); var tmp3 *jrt.Class; A_arbace_reflect_type_reflect_A_Init(); tmp3 = A_arbace_reflect_type_reflect_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_reflect__init_A_const_43; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_44)); return A_arbace_reflect__init_A_const_43.Ref() }
























































func A_arbace_reflect__init_A_Unit20__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(115, 1); var tmp1 *lang.Var = A_arbace_reflect__init_A_const_45; var tmp2 any = A_arbace_reflect_reflect_A_New(); var tmp3 *jrt.Class; A_arbace_reflect_reflect_A_Init(); tmp3 = A_arbace_reflect_reflect_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_reflect__init_A_const_45; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_reflect__init_A_const_46)); return A_arbace_reflect__init_A_const_45.Ref() }







func A_arbace_reflect__init_A_Unit21__O() any { A_arbace_reflect__init_A_Init(); lang.Compiler_AOT_At_I_I__V(123, 1); return lang.IFn_Cast(jrt.NN(A_arbace_reflect__init_A_const_47).GetRawRoot__O()).Invoke_O__O(Lit_193) }



type A_arbace_reflect__init_A struct{ jrt.Object }

var A_arbace_reflect__init_A_const_0 *lang.Var

var A_arbace_reflect__init_A_const_1 any

var A_arbace_reflect__init_A_const_2 any

var A_arbace_reflect__init_A_const_3 any

var A_arbace_reflect__init_A_const_4 *lang.Var

var A_arbace_reflect__init_A_const_5 any

var A_arbace_reflect__init_A_const_6 any

var A_arbace_reflect__init_A_const_7 *jrt.Class

var A_arbace_reflect__init_A_const_8 *lang.Var

var A_arbace_reflect__init_A_const_9 *lang.Var

var A_arbace_reflect__init_A_const_10 *lang.Keyword

var A_arbace_reflect__init_A_const_11 *lang.Var

var A_arbace_reflect__init_A_const_12 any

var A_arbace_reflect__init_A_const_13 *lang.Var

var A_arbace_reflect__init_A_const_14 *lang.Var

var A_arbace_reflect__init_A_const_15 any

var A_arbace_reflect__init_A_const_16 *lang.Keyword

var A_arbace_reflect__init_A_const_17 any

var A_arbace_reflect__init_A_const_18 *lang.Keyword

var A_arbace_reflect__init_A_const_19 *lang.Keyword

var A_arbace_reflect__init_A_const_20 any

var A_arbace_reflect__init_A_const_21 *lang.Keyword

var A_arbace_reflect__init_A_const_22 *lang.Var

var A_arbace_reflect__init_A_const_23 *lang.Var

var A_arbace_reflect__init_A_const_24 *lang.Var

var A_arbace_reflect__init_A_const_25 any

var A_arbace_reflect__init_A_const_26 any

var A_arbace_reflect__init_A_const_27 *lang.Keyword

var A_arbace_reflect__init_A_const_28 *lang.Var

var A_arbace_reflect__init_A_const_29 any

var A_arbace_reflect__init_A_const_30 *lang.Var

var A_arbace_reflect__init_A_const_31 any

var A_arbace_reflect__init_A_const_32 any

var A_arbace_reflect__init_A_const_33 *jrt.Class

var A_arbace_reflect__init_A_const_34 any

var A_arbace_reflect__init_A_const_35 any

var A_arbace_reflect__init_A_const_36 any

var A_arbace_reflect__init_A_const_37 any

var A_arbace_reflect__init_A_const_38 any

var A_arbace_reflect__init_A_const_39 any

var A_arbace_reflect__init_A_const_40 any

var A_arbace_reflect__init_A_const_41 *lang.Var

var A_arbace_reflect__init_A_const_42 any

var A_arbace_reflect__init_A_const_43 *lang.Var

var A_arbace_reflect__init_A_const_44 any

var A_arbace_reflect__init_A_const_45 *lang.Var

var A_arbace_reflect__init_A_const_46 any

var A_arbace_reflect__init_A_const_47 *lang.Var

var A_arbace_reflect__init_A_init jrt.ClassInit

func A_arbace_reflect__init_A_Init() { if !A_arbace_reflect__init_A_init.Done() { A_arbace_reflect__init_A_init.Run(A_arbace_reflect__init_A_clinit) } }

func A_arbace_reflect__init_A_clinit() { A_arbace_reflect__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_160); A_arbace_reflect__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15))); A_arbace_reflect__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_15)); A_arbace_reflect__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_reflect__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_9, Lit_161); A_arbace_reflect__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_162).Ref(), Lit_163)); A_arbace_reflect__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), jrt.Integer_ValueOf_I__Integer(44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_162).Ref(), Lit_163)); A_arbace_reflect__init_A_const_7 = lang.RT_ClassForNameNonLoading_String__Class(Lit_18); A_arbace_reflect__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_164); A_arbace_reflect__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_143); A_arbace_reflect__init_A_const_10 = lang.RT_Keyword_String_String__Keyword(nil, Lit_14); A_arbace_reflect__init_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_165); A_arbace_reflect__init_A_const_12 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_26).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_167).Ref())))))))))); A_arbace_reflect__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_168); A_arbace_reflect__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_reflect__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_169).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_170).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_171)); A_arbace_reflect__init_A_const_16 = lang.RT_Keyword_String_String__Keyword(nil, Lit_172); A_arbace_reflect__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_34).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_26).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_167).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_26).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_167).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), nil)))); A_arbace_reflect__init_A_const_18 = lang.RT_Keyword_String_String__Keyword(nil, Lit_174); A_arbace_reflect__init_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_175); A_arbace_reflect__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_34).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_34).Ref())); A_arbace_reflect__init_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_176); A_arbace_reflect__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_177); A_arbace_reflect__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_178); A_arbace_reflect__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_reflect__init_A_const_25 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_26).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_167).Ref()))))))); A_arbace_reflect__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_26).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_167).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_26).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_167).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), nil)); A_arbace_reflect__init_A_const_27 = lang.RT_Keyword_String_String__Keyword(nil, Lit_179); A_arbace_reflect__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_180); A_arbace_reflect__init_A_const_29 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_161).Ref(); A_arbace_reflect__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_9, Lit_181); A_arbace_reflect__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_162).Ref(), Lit_163)); A_arbace_reflect__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_162).Ref(), Lit_163)); A_arbace_reflect__init_A_const_33 = lang.RT_ClassForNameNonLoading_String__Class(Lit_19); A_arbace_reflect__init_A_const_34 = lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_49)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_182, lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref())))))))))); A_arbace_reflect__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_169).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_170).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_184)); A_arbace_reflect__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_49).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_49)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_182, lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_182)))); A_arbace_reflect__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_49).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_49).Ref())); A_arbace_reflect__init_A_const_38 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_49)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_182, lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref()))))))); A_arbace_reflect__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_173).Ref(), nil, lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_49)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_182, lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_182)); A_arbace_reflect__init_A_const_40 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_181).Ref(); A_arbace_reflect__init_A_const_41 = lang.RT_Var_String_String__Var(Lit_9, Lit_32); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_185).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_reflect__init_A_const_42 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), jrt.Integer_ValueOf_I__Integer(56).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_162).Ref(), Lit_163)); A_arbace_reflect__init_A_const_43 = lang.RT_Var_String_String__Var(Lit_9, Lit_43); A_arbace_reflect__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_167).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_186).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_187).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_188, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), jrt.Integer_ValueOf_I__Integer(58).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_162).Ref(), Lit_163)); A_arbace_reflect__init_A_const_45 = lang.RT_Var_String_String__Var(Lit_9, Lit_189); A_arbace_reflect__init_A_const_46 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_166).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_190).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_186).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_187).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_14).Ref(), Lit_191, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13, lang.RT_Keyword_String_String__Keyword(nil, Lit_64).Ref(), jrt.Integer_ValueOf_I__Integer(115).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_65).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_162).Ref(), Lit_163)); A_arbace_reflect__init_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_192) }

func A_arbace_reflect__init_A_New() *A_arbace_reflect__init_A { A_arbace_reflect__init_A_Init(); t := &A_arbace_reflect__init_A{}; t.Ctor(); return t }

func (t *A_arbace_reflect__init_A) Ctor() {}

func (t *A_arbace_reflect__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_reflect__init_A) GetClass__Class() *jrt.Class { return A_arbace_reflect__init_A_class }

func (t *A_arbace_reflect__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_reflect__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_reflect__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_reflect__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_reflect__init_A); return ok }

func A_arbace_reflect__init_A_Cast(x any) *A_arbace_reflect__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_reflect__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_reflect__init_A_class)) }; return v }
