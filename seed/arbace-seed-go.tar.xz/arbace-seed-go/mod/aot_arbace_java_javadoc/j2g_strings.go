//line j2g_strings.ae:1
package aot_arbace_java_javadoc

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn18,arbace.java.browsekn4,onlyyn10,browse-urlkn4,linekn6,columnyn13,arbace.stringkn2,asyn3,strkn6,authorkn3,docv11,arbace.core5,referR0,v11,arbace.core3,useV3,R1,R2,ML1,R3,m4,R4,i12,R5,i35,v11,arbace.core7,requireV3,R6,R7,R8,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn19,arbace.java.javadocm4,R9,s31,Christophe Grand, Stuart SierraR10,s39,A repl helper to quickly open javadocs.v19,arbace.java.javadoc16,*local-javadocs*v19,arbace.java.javadoc17,*remote-javadocs*v11,arbace.core5,assocv11,arbace.core6,formatv13,arbace.string7,replacep4,\\$.*c46,c47,v11,arbace.core5,firstv11,arbace.core6,filterv11,arbace.core3,mapv11,arbace.core3,strv11,arbace.core4,somev19,arbace.java.javadoc19,fill-in-module-namev11,arbace.core5,classv19,arbace.java.javadoc11,javadoc-urlv18,arbace.java.browse10,browse-urlv11,arbace.core7,println")

var Lit_1 *jrt.String = jrt.Intern("arbace.java.javadoc$add_local_javadoc$fn__1949000014")

var Lit_2 *jrt.String = jrt.Intern("arbace.java.javadoc$add_remote_javadoc$fn__1949000017")

var Lit_3 *jrt.String = jrt.Intern("java.io.File")

var Lit_4 *jrt.String = jrt.Intern("%s")

var Lit_5 *jrt.String = jrt.Intern("java.specification.version")

var Lit_6 *jrt.String = jrt.Intern("https://docs.oracle.com/en/java/javase/")

var Lit_7 *jrt.String = jrt.Intern("/docs/api/%s/")

var Lit_8 *jrt.String = jrt.Intern("Could not find Javadoc for")

var Lit_9 *jrt.String = jrt.Intern("")

var Lit_10 *jrt.String = jrt.Intern("arbace.java.javadoc$javadoc_url$fn__1949000023")

var Lit_11 *jrt.String = jrt.Intern("arbace.java.javadoc$javadoc_url$fn__1949000025")

var Lit_12 *jrt.String = jrt.Intern("arbace.java.javadoc$javadoc_url$fn__1949000028")

var Lit_13 *jrt.String = jrt.Intern(".html")

var Lit_14 *jrt.String = jrt.Intern("kn6,authorkn3,docyn11,arbace.corekn7,dynamickn10,deprecatedkn4,linekn6,columnkn4,filekn8,arglistsyn4,pathkn5,addedyn14,package-prefixyn3,urlkn7,privatekn3,tagyn6,Stringyn15,class-or-objectv11,arbace.core5,in-nsMyn19,arbace.java.javadocm4,R0,s31,Christophe Grand, Stuart SierraR1,s39,A repl helper to quickly open javadocs.m4,R0,s31,Christophe Grand, Stuart SierraR1,s39,A repl helper to quickly open javadocs.R2,v19,arbace.java.javadoc19,*feeling-lucky-url*m10,R3,TR4,s4,1.13R5,i17,R6,i1,R7,s22,arbace/java/javadoc.aev19,arbace.java.javadoc15,*feeling-lucky*m10,R3,TR4,s4,1.13R5,i18,R6,i1,R7,s22,arbace/java/javadoc.aev19,arbace.java.javadoc16,*local-javadocs*v11,arbace.core3,refv11,arbace.core4,listm8,R3,TR5,i20,R6,i1,R7,s22,arbace/java/javadoc.aev19,arbace.java.javadoc15,*core-java-api*m8,R3,TR5,i22,R6,i1,R7,s22,arbace/java/javadoc.aev19,arbace.java.javadoc17,*remote-javadocs*v11,arbace.core10,sorted-mapm8,R3,TR5,i26,R6,i1,R7,s22,arbace/java/javadoc.aev19,arbace.java.javadoc17,add-local-javadocm12,R8,L1,V1,R9,R1,s40,Adds to the list of local Javadoc paths.R10,s3,1.2R5,i40,R6,i1,R7,s22,arbace/java/javadoc.aev19,arbace.java.javadoc18,add-remote-javadocm12,R8,L1,V2,R11,R12,R1,s122,Adds to the list of remote Javadoc URLs.  package-prefix is the\n  beginning of the package name that has docs at this URL.R10,s3,1.2R5,i46,R6,i1,R7,s22,arbace/java/javadoc.aev19,arbace.java.javadoc19,fill-in-module-namem10,R13,TR8,L1,V2,Myn3,urlm2,R14,R15,Myn9,classnamem2,R14,R15,R5,i53,R6,i1,R7,s22,arbace/java/javadoc.aev19,arbace.java.javadoc11,javadoc-urlm14,R8,L1,V1,Myn9,classnamem2,R14,R15,R1,s120,Searches for a URL for the given class name.  Tries\n  *local-javadocs* first, then *remote-javadocs*.  Returns a string.R14,C16,java.lang.StringR10,s3,1.2R5,i63,R6,i1,R7,s22,arbace/java/javadoc.aev19,arbace.java.javadoc7,javadocm12,R8,L1,V1,R16,R1,s119,Opens a browser window displaying the javadoc for the argument.\n  Tries *local-javadocs* first, then *remote-javadocs*.R10,s3,1.2R5,i84,R6,i1,R7,s22,arbace/java/javadoc.ae")

var Lit_15 *jrt.String = jrt.Intern("arbace.java.javadoc$eval1949000004$loading__1927001464__auto____1949000005")

var Lit_16 *jrt.String = jrt.Intern("arbace.java.javadoc$eval1949000008$fn__1949000009")

var Lit_17 *jrt.String = jrt.Intern("arbace.java.javadoc$fn__1949000012")

var Lit_18 *jrt.String = jrt.Intern("com.google.common.")

var Lit_19 *jrt.String = jrt.Intern("https://guava.dev/releases/snapshot-jre/api/docs/")

var Lit_20 *jrt.String = jrt.Intern("java.")

var Lit_21 *jrt.String = jrt.Intern("javax.")

var Lit_22 *jrt.String = jrt.Intern("org.ietf.jgss.")

var Lit_23 *jrt.String = jrt.Intern("org.omg.")

var Lit_24 *jrt.String = jrt.Intern("org.w3c.dom.")

var Lit_25 *jrt.String = jrt.Intern("org.xml.sax.")

var Lit_26 *jrt.String = jrt.Intern("org.apache.commons.codec.")

var Lit_27 *jrt.String = jrt.Intern("https://commons.apache.org/proper/commons-codec/apidocs/")

var Lit_28 *jrt.String = jrt.Intern("org.apache.commons.io.")

var Lit_29 *jrt.String = jrt.Intern("https://commons.apache.org/proper/commons-io/apidocs/")

var Lit_30 *jrt.String = jrt.Intern("org.apache.commons.lang.")

var Lit_31 *jrt.String = jrt.Intern("https://commons.apache.org/proper/commons-lang/javadocs/api-2.6/")

var Lit_32 *jrt.String = jrt.Intern("org.apache.commons.lang3.")

var Lit_33 *jrt.String = jrt.Intern("https://commons.apache.org/proper/commons-lang/apidocs/")

var Lit_34 *jrt.String = jrt.Intern("arbace.java.javadoc$add_local_javadoc")

var Lit_35 *jrt.String = jrt.Intern("arbace.java.javadoc$add_remote_javadoc")

var Lit_36 *jrt.String = jrt.Intern("arbace.java.javadoc$fill_in_module_name")

var Lit_37 *jrt.String = jrt.Intern("arbace.java.javadoc$javadoc_url")

var Lit_38 *jrt.String = jrt.Intern("arbace.java.javadoc$javadoc")
