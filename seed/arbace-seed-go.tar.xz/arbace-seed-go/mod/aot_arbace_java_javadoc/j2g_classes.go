//line j2g_classes.ae:1
package aot_arbace_java_javadoc

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_java_javadoc_add_local_javadoc_A_class, Name: "arbace.java.javadoc$add_local_javadoc", Modifiers: 25, Simple: "add_local_javadoc", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_add_local_javadoc_A", Source: "javadoc.ae", Declaring: &A_arbace_java_javadoc_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A_class, Name: "arbace.java.javadoc$add_local_javadoc$fn__1949000014", Modifiers: 25, Simple: "fn__1949000014", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A", Source: "javadoc.ae", Declaring: &A_arbace_java_javadoc_add_local_javadoc_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_javadoc_add_remote_javadoc_A_class, Name: "arbace.java.javadoc$add_remote_javadoc", Modifiers: 25, Simple: "add_remote_javadoc", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_add_remote_javadoc_A", Source: "javadoc.ae", Declaring: &A_arbace_java_javadoc_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A_class, Name: "arbace.java.javadoc$add_remote_javadoc$fn__1949000017", Modifiers: 25, Simple: "fn__1949000017", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A", Source: "javadoc.ae", Declaring: &A_arbace_java_javadoc_add_remote_javadoc_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A_class, Name: "arbace.java.javadoc$eval1949000004$loading__1927001464__auto____1949000005", Modifiers: 25, Simple: "loading__1927001464__auto____1949000005", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A", Source: "javadoc.ae", Declaring: &A_arbace_java_javadoc_eval1949000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_javadoc_eval1949000008_fn__1949000009_A_class, Name: "arbace.java.javadoc$eval1949000008$fn__1949000009", Modifiers: 25, Simple: "fn__1949000009", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_eval1949000008_fn__1949000009_A", Source: "javadoc.ae", Declaring: &A_arbace_java_javadoc_eval1949000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_javadoc_fill_in_module_name_A_class, Name: "arbace.java.javadoc$fill_in_module_name", Modifiers: 25, Simple: "fill_in_module_name", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_fill_in_module_name_A", Source: "javadoc.ae", Declaring: &A_arbace_java_javadoc_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_javadoc_fn__1949000012_A_class, Name: "arbace.java.javadoc$fn__1949000012", Modifiers: 25, Simple: "fn__1949000012", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_fn__1949000012_A", Source: "javadoc.ae", Declaring: &A_arbace_java_javadoc_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_javadoc_javadoc_A_class, Name: "arbace.java.javadoc$javadoc", Modifiers: 25, Simple: "javadoc", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_javadoc_A", Source: "javadoc.ae", Declaring: &A_arbace_java_javadoc_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_javadoc_javadoc_url_A_class, Name: "arbace.java.javadoc$javadoc_url", Modifiers: 25, Simple: "javadoc_url", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_javadoc_url_A", Source: "javadoc.ae", Declaring: &A_arbace_java_javadoc_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_javadoc_javadoc_url_fn__1949000023_A_class, Name: "arbace.java.javadoc$javadoc_url$fn__1949000023", Modifiers: 25, Simple: "fn__1949000023", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_javadoc_url_fn__1949000023_A", Source: "javadoc.ae", Declaring: &A_arbace_java_javadoc_javadoc_url_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_javadoc_javadoc_url_fn__1949000025_A_class, Name: "arbace.java.javadoc$javadoc_url$fn__1949000025", Modifiers: 25, Simple: "fn__1949000025", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_javadoc_url_fn__1949000025_A", Source: "javadoc.ae", Declaring: &A_arbace_java_javadoc_javadoc_url_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_javadoc_javadoc_url_fn__1949000028_A_class, Name: "arbace.java.javadoc$javadoc_url$fn__1949000028", Modifiers: 25, Simple: "fn__1949000028", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_javadoc_url_fn__1949000028_A", Source: "javadoc.ae", Declaring: &A_arbace_java_javadoc_javadoc_url_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_java_javadoc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_javadoc_A_New()}; return nil }

var A_arbace_java_javadoc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_javadoc_A_new}

var A_arbace_java_javadoc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.javadoc", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_A"})

func init() { i := A_arbace_java_javadoc_A_class.Info(); i.IsInstance = A_arbace_java_javadoc_A_InstanceOf; i.Init = A_arbace_java_javadoc_A_Init; i.Table = A_arbace_java_javadoc_A_members }

var A_arbace_java_javadoc_add_local_javadoc_A_class *jrt.Class

var A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A_class *jrt.Class

var A_arbace_java_javadoc_add_remote_javadoc_A_class *jrt.Class

var A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A_class *jrt.Class

func A_arbace_java_javadoc_eval1949000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_javadoc_eval1949000004_A_New()}; return nil }

var A_arbace_java_javadoc_eval1949000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_javadoc_eval1949000004_A_new}

var A_arbace_java_javadoc_eval1949000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.javadoc$eval1949000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_javadoc_A_class, Simple: "eval1949000004", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_eval1949000004_A"})

func init() { i := A_arbace_java_javadoc_eval1949000004_A_class.Info(); i.IsInstance = A_arbace_java_javadoc_eval1949000004_A_InstanceOf; i.Table = A_arbace_java_javadoc_eval1949000004_A_members }

var A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A_class *jrt.Class

func A_arbace_java_javadoc_eval1949000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_javadoc_eval1949000008_A_New()}; return nil }

var A_arbace_java_javadoc_eval1949000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_javadoc_eval1949000008_A_new}

var A_arbace_java_javadoc_eval1949000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.javadoc$eval1949000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_javadoc_A_class, Simple: "eval1949000008", Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc_eval1949000008_A"})

func init() { i := A_arbace_java_javadoc_eval1949000008_A_class.Info(); i.IsInstance = A_arbace_java_javadoc_eval1949000008_A_InstanceOf; i.Table = A_arbace_java_javadoc_eval1949000008_A_members }

var A_arbace_java_javadoc_eval1949000008_fn__1949000009_A_class *jrt.Class

var A_arbace_java_javadoc_fill_in_module_name_A_class *jrt.Class

var A_arbace_java_javadoc_fn__1949000012_A_class *jrt.Class

var A_arbace_java_javadoc_javadoc_A_class *jrt.Class

var A_arbace_java_javadoc_javadoc_url_A_class *jrt.Class

var A_arbace_java_javadoc_javadoc_url_fn__1949000023_A_class *jrt.Class

var A_arbace_java_javadoc_javadoc_url_fn__1949000025_A_class *jrt.Class

var A_arbace_java_javadoc_javadoc_url_fn__1949000028_A_class *jrt.Class

func A_arbace_java_javadoc__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_java_javadoc__init_A_Load__O()}; return nil }

func A_arbace_java_javadoc__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_javadoc__init_A_New()}; return nil }

var A_arbace_java_javadoc__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_java_javadoc__init_A_invoke, New: A_arbace_java_javadoc__init_A_new}

var A_arbace_java_javadoc__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.javadoc__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_java_javadoc.A_arbace_java_javadoc__init_A", Source: "javadoc.ae"})

func init() { i := A_arbace_java_javadoc__init_A_class.Info(); i.IsInstance = A_arbace_java_javadoc__init_A_InstanceOf; i.Init = A_arbace_java_javadoc__init_A_Init; i.Table = A_arbace_java_javadoc__init_A_members }
