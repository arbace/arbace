//line aot_arbace_java_javadoc__init.ae:1
package aot_arbace_java_javadoc

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_java_javadoc__init_A_Load__O() any { A_arbace_java_javadoc__init_A_Init(); jrt.StartCheck(); A_arbace_java_javadoc__init_A_Unit0__O(); A_arbace_java_javadoc__init_A_Unit1__O(); A_arbace_java_javadoc__init_A_Unit2__O(); A_arbace_java_javadoc__init_A_Unit3__O(); A_arbace_java_javadoc__init_A_Unit4__O(); A_arbace_java_javadoc__init_A_Unit5__O(); A_arbace_java_javadoc__init_A_Unit6__O(); A_arbace_java_javadoc__init_A_Unit7__O(); A_arbace_java_javadoc__init_A_Unit8__O(); A_arbace_java_javadoc__init_A_Unit9__O(); A_arbace_java_javadoc__init_A_Unit10__O(); A_arbace_java_javadoc__init_A_Unit11__O(); A_arbace_java_javadoc__init_A_Unit12__O(); A_arbace_java_javadoc__init_A_Unit13__O(); return nil }


func A_arbace_java_javadoc__init_A_Unit0__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(8, 1); return lang.IFn_Cast(A_arbace_java_javadoc__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_javadoc__init_A_const_1) }
//line :8:1
func A_arbace_java_javadoc__init_A_Unit1__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(8, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_java_javadoc__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_java_javadoc__init_A_const_2)) }
//line :8:1
func A_arbace_java_javadoc__init_A_Unit2__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(8, 1); var tmp1 any = A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :8:1
func A_arbace_java_javadoc__init_A_Unit3__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(8, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_java_javadoc__init_A_const_1)).Equals_O__Z(A_arbace_java_javadoc__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_java_javadoc_eval1949000008_fn__1949000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_java_javadoc_eval1949000008_fn__1949000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_java_javadoc_eval1949000008_fn__1949000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }








func A_arbace_java_javadoc__init_A_Unit4__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); A_arbace_java_javadoc__init_A_const_4.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_java_javadoc__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_javadoc__init_A_const_5)); return A_arbace_java_javadoc__init_A_const_4.SetDynamic_Z__Var(true).Ref() }
func A_arbace_java_javadoc__init_A_Unit5__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); A_arbace_java_javadoc__init_A_const_6.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_java_javadoc__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_javadoc__init_A_const_7)); return A_arbace_java_javadoc__init_A_const_6.SetDynamic_Z__Var(true).Ref() }

func A_arbace_java_javadoc__init_A_Unit6__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(20, 1); var tmp1 *lang.Var = A_arbace_java_javadoc__init_A_const_8; var tmp2 any; var root_3 any = A_arbace_java_javadoc__init_A_const_9.GetRawRoot__O(); var linked_4 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3, aot_arbace_core.A_arbace_core_ref_A_fn_class); var ifn_5 lang.IFn; if linked_4 == nil { ifn_5 = lang.IFn_Cast(root_3) } else { ifn_5 = nil }; var arg_6 any = lang.IFn_Cast(A_arbace_java_javadoc__init_A_const_10.GetRawRoot__O()).Invoke__O(); if linked_4 == nil { tmp2 = ifn_5.Invoke_O__O(arg_6) } else { tmp2 = linked_4.(*aot_arbace_core.A_arbace_core_ref_A).Invoke_O_O__O(root_3, arg_6) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_java_javadoc__init_A_const_8; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_javadoc__init_A_const_11)); return A_arbace_java_javadoc__init_A_const_8.SetDynamic_Z__Var(true).Ref() }

func A_arbace_java_javadoc__init_A_Unit7__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); var tmp1 *lang.Var = A_arbace_java_javadoc__init_A_const_12; var tmp2 any = A_arbace_java_javadoc_fn__1949000012_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_java_javadoc_fn__1949000012_A_fn_class; if
							fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_java_javadoc_fn__1949000012_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; /*line :22:1*/tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()); var tmp4 *lang.Var = A_arbace_java_javadoc__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_javadoc__init_A_const_13)); return A_arbace_java_javadoc__init_A_const_12.SetDynamic_Z__Var(true).Ref() }



func A_arbace_java_javadoc__init_A_Unit8__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); var tmp1 *lang.Var = A_arbace_java_javadoc__init_A_const_14; var tmp2 any; var root_8 any = A_arbace_java_javadoc__init_A_const_9.GetRawRoot__O(); var linked_9 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_8, aot_arbace_core.A_arbace_core_ref_A_fn_class); var ifn_10 lang.IFn; if
							linked_9 == nil { ifn_10 = lang.IFn_Cast(root_8) } else { ifn_10 = nil }; var arg_11 any = lang.IFn_Cast(A_arbace_java_javadoc__init_A_const_15.GetRawRoot__O()).ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, Lit_18, Lit_19, Lit_20, A_arbace_java_javadoc__init_A_const_12.Get__O(), Lit_21, A_arbace_java_javadoc__init_A_const_12.Get__O(), Lit_22, A_arbace_java_javadoc__init_A_const_12.Get__O(), Lit_23, A_arbace_java_javadoc__init_A_const_12.Get__O(), Lit_24, A_arbace_java_javadoc__init_A_const_12.Get__O(), Lit_25, A_arbace_java_javadoc__init_A_const_12.Get__O(), Lit_26, Lit_27, Lit_28, Lit_29, Lit_30, Lit_31, Lit_32, Lit_33)))); if linked_9 == nil { tmp2 = ifn_10.Invoke_O__O(arg_11) } else { tmp2 = linked_9.(*aot_arbace_core.A_arbace_core_ref_A).Invoke_O_O__O(root_8, arg_11) }; /*line :26:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_java_javadoc__init_A_const_14; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_javadoc__init_A_const_16)); return A_arbace_java_javadoc__init_A_const_14.SetDynamic_Z__Var(true).Ref() }













func A_arbace_java_javadoc__init_A_Unit9__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_java_javadoc__init_A_const_17; var tmp2 any = A_arbace_java_javadoc_add_local_javadoc_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_java_javadoc_add_local_javadoc_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_java_javadoc_add_local_javadoc_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_javadoc__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_javadoc__init_A_const_18)); return A_arbace_java_javadoc__init_A_const_17 }





func A_arbace_java_javadoc__init_A_Unit10__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(46, 1); var tmp1 *lang.Var = A_arbace_java_javadoc__init_A_const_19; var tmp2 any = A_arbace_java_javadoc_add_remote_javadoc_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_java_javadoc_add_remote_javadoc_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_java_javadoc_add_remote_javadoc_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_javadoc__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_javadoc__init_A_const_20)); return A_arbace_java_javadoc__init_A_const_19 }






func A_arbace_java_javadoc__init_A_Unit11__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_java_javadoc__init_A_const_21; var tmp2 any = A_arbace_java_javadoc_fill_in_module_name_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_java_javadoc_fill_in_module_name_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_java_javadoc_fill_in_module_name_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_javadoc__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_javadoc__init_A_const_22)); return A_arbace_java_javadoc__init_A_const_21 }









func A_arbace_java_javadoc__init_A_Unit12__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); var tmp1 *lang.Var = A_arbace_java_javadoc__init_A_const_23; var tmp2 any = A_arbace_java_javadoc_javadoc_url_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_java_javadoc_javadoc_url_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_java_javadoc_javadoc_url_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_javadoc__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_javadoc__init_A_const_24)); return A_arbace_java_javadoc__init_A_const_23 }




















func A_arbace_java_javadoc__init_A_Unit13__O() any { A_arbace_java_javadoc__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(84, 1); var tmp1 *lang.Var = A_arbace_java_javadoc__init_A_const_25; var tmp2 any = A_arbace_java_javadoc_javadoc_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_java_javadoc_javadoc_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_java_javadoc_javadoc_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_javadoc__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_javadoc__init_A_const_26)); return A_arbace_java_javadoc__init_A_const_25 }



type A_arbace_java_javadoc__init_A struct{ jrt.Object }

var A_arbace_java_javadoc__init_A_const_pool *jrt.RefArray

var A_arbace_java_javadoc__init_A_const_0 *lang.Var

var A_arbace_java_javadoc__init_A_const_1 any

var A_arbace_java_javadoc__init_A_const_2 any

var A_arbace_java_javadoc__init_A_const_3 any

var A_arbace_java_javadoc__init_A_const_4 *lang.Var

var A_arbace_java_javadoc__init_A_const_5 any

var A_arbace_java_javadoc__init_A_const_6 *lang.Var

var A_arbace_java_javadoc__init_A_const_7 any

var A_arbace_java_javadoc__init_A_const_8 *lang.Var

var A_arbace_java_javadoc__init_A_const_9 *lang.Var

var A_arbace_java_javadoc__init_A_const_10 *lang.Var

var A_arbace_java_javadoc__init_A_const_11 any

var A_arbace_java_javadoc__init_A_const_12 *lang.Var

var A_arbace_java_javadoc__init_A_const_13 any

var A_arbace_java_javadoc__init_A_const_14 *lang.Var

var A_arbace_java_javadoc__init_A_const_15 *lang.Var

var A_arbace_java_javadoc__init_A_const_16 any

var A_arbace_java_javadoc__init_A_const_17 *lang.Var

var A_arbace_java_javadoc__init_A_const_18 any

var A_arbace_java_javadoc__init_A_const_19 *lang.Var

var A_arbace_java_javadoc__init_A_const_20 any

var A_arbace_java_javadoc__init_A_const_21 *lang.Var

var A_arbace_java_javadoc__init_A_const_22 any

var A_arbace_java_javadoc__init_A_const_23 *lang.Var

var A_arbace_java_javadoc__init_A_const_24 any

var A_arbace_java_javadoc__init_A_const_25 *lang.Var

var A_arbace_java_javadoc__init_A_const_26 any

var A_arbace_java_javadoc__init_A_init jrt.ClassInit

func A_arbace_java_javadoc__init_A_Init() { if !A_arbace_java_javadoc__init_A_init.Done() { A_arbace_java_javadoc__init_A_init.Run(A_arbace_java_javadoc__init_A_clinit) } }

func A_arbace_java_javadoc__init_A_clinit() { A_arbace_java_javadoc__init_A_clinit_p0(); A_arbace_java_javadoc__init_A_clinit_p1(); A_arbace_java_javadoc__init_A_clinit_p2() }

func A_arbace_java_javadoc__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_javadoc__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_14, 44); A_arbace_java_javadoc__init_A_const_0 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[17]); A_arbace_java_javadoc__init_A_const_1 = A_arbace_java_javadoc__init_A_const_pool.A[18]; A_arbace_java_javadoc__init_A_const_2 = A_arbace_java_javadoc__init_A_const_pool.A[19]; A_arbace_java_javadoc__init_A_const_3 = A_arbace_java_javadoc__init_A_const_pool.A[20]; A_arbace_java_javadoc__init_A_const_4 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[21]); A_arbace_java_javadoc__init_A_const_5 = A_arbace_java_javadoc__init_A_const_pool.A[22]; A_arbace_java_javadoc__init_A_const_6 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[23]); A_arbace_java_javadoc__init_A_const_7 = A_arbace_java_javadoc__init_A_const_pool.A[24]; A_arbace_java_javadoc__init_A_const_8 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[25]); A_arbace_java_javadoc__init_A_const_9 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[26]); A_arbace_java_javadoc__init_A_const_10 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[27]); A_arbace_java_javadoc__init_A_const_11 = A_arbace_java_javadoc__init_A_const_pool.A[28] }

func A_arbace_java_javadoc__init_A_clinit_p1() { A_arbace_java_javadoc__init_A_const_12 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[29]); A_arbace_java_javadoc__init_A_const_13 = A_arbace_java_javadoc__init_A_const_pool.A[30]; A_arbace_java_javadoc__init_A_const_14 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[31]); A_arbace_java_javadoc__init_A_const_15 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[32]); A_arbace_java_javadoc__init_A_const_16 = A_arbace_java_javadoc__init_A_const_pool.A[33]; A_arbace_java_javadoc__init_A_const_17 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[34]); A_arbace_java_javadoc__init_A_const_18 = A_arbace_java_javadoc__init_A_const_pool.A[35]; A_arbace_java_javadoc__init_A_const_19 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[36]); A_arbace_java_javadoc__init_A_const_20 = A_arbace_java_javadoc__init_A_const_pool.A[37]; A_arbace_java_javadoc__init_A_const_21 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[38]); A_arbace_java_javadoc__init_A_const_22 = A_arbace_java_javadoc__init_A_const_pool.A[39]; A_arbace_java_javadoc__init_A_const_23 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[40]); A_arbace_java_javadoc__init_A_const_24 = A_arbace_java_javadoc__init_A_const_pool.A[41] }

func A_arbace_java_javadoc__init_A_clinit_p2() { A_arbace_java_javadoc__init_A_const_25 = lang.Var_Cast(A_arbace_java_javadoc__init_A_const_pool.A[42]); A_arbace_java_javadoc__init_A_const_26 = A_arbace_java_javadoc__init_A_const_pool.A[43] }

func A_arbace_java_javadoc__init_A_New() *A_arbace_java_javadoc__init_A { A_arbace_java_javadoc__init_A_Init(); t := &A_arbace_java_javadoc__init_A{}; t.Ctor(); return t }

func (t *A_arbace_java_javadoc__init_A) Ctor() {}

func (t *A_arbace_java_javadoc__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_javadoc__init_A) GetClass__Class() *jrt.Class { return A_arbace_java_javadoc__init_A_class }

func (t *A_arbace_java_javadoc__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_javadoc__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_javadoc__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_javadoc__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_javadoc__init_A); return ok }

func A_arbace_java_javadoc__init_A_Cast(x any) *A_arbace_java_javadoc__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_javadoc__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_javadoc__init_A_class)) }; return v }
