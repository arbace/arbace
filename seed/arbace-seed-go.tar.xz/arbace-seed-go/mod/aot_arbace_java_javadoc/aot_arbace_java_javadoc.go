//line aot_arbace_java_javadoc.ae:1
package aot_arbace_java_javadoc

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_browse"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :8:1
func A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A_New() *A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A{}; t.Ctor(); return t }
//line :8:1
func (t *A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A) Ctor() {}
//line :8:1
func (t *A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_java_javadoc_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_javadoc_A_const_1); lang.IFn_Cast(A_arbace_java_javadoc_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_java_javadoc_A_const_3); lang.IFn_Cast(A_arbace_java_javadoc_A_const_4.GetRawRoot__O()).Invoke_O__O(A_arbace_java_javadoc_A_const_5); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :8:1
func A_arbace_java_javadoc_eval1949000008_fn__1949000009_A_New() *A_arbace_java_javadoc_eval1949000008_fn__1949000009_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_eval1949000008_fn__1949000009_A{}; t.Ctor(); return t }
//line :8:1
func (t *A_arbace_java_javadoc_eval1949000008_fn__1949000009_A) Ctor() {}
//line :8:1
func (t *A_arbace_java_javadoc_eval1949000008_fn__1949000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_javadoc_A_const_6.GetRawRoot__O()); var tmp2 any; var root_19 any = A_arbace_java_javadoc_A_const_7.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_java_javadoc_A_const_8; if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_19, arg_22) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_java_javadoc_A_const_9.GetRawRoot__O(), A_arbace_java_javadoc_A_const_10) }














func A_arbace_java_javadoc_fn__1949000012_A_New() *A_arbace_java_javadoc_fn__1949000012_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_fn__1949000012_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_java_javadoc_fn__1949000012_A) Ctor() {}
//line :23:1
func (t *A_arbace_java_javadoc_fn__1949000012_A) Invoke_O__O(self any) any { var java_version__1 any = jrt.System_GetProperty_String__String(Lit_5).Ref(); return /*line :24:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, java_version__1, nil)).Ref() }















func A_arbace_java_javadoc_add_local_javadoc_A_New() *A_arbace_java_javadoc_add_local_javadoc_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_add_local_javadoc_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_java_javadoc_add_local_javadoc_A) Ctor() {}
//line :40:1
func (t *A_arbace_java_javadoc_add_local_javadoc_A) Invoke_O_O__O(self, path__0 any) any {



	var tmp1 any = A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A_New_O(path__0); var tmp2 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A_fn_class = fncls__29d; tmp2 = fncls__29d } else { tmp2 = fncls__29 }; return lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :44:1
func A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A_New_O(p0 any) *A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A{}; t.Ctor_O(p0); return t }
//line :44:1
func (t *A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A) Ctor_O(c__path any) { t.F_path = c__path }
//line :44:1
func (t *A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_java_javadoc_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_java_javadoc_A_const_11.Get__O(), A_arbace_java_javadoc_A_const_9.GetRawRoot__O(), t.F_path) }

func A_arbace_java_javadoc_add_remote_javadoc_A_New() *A_arbace_java_javadoc_add_remote_javadoc_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_add_remote_javadoc_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_java_javadoc_add_remote_javadoc_A) Ctor() {}
//line :46:1
func (t *A_arbace_java_javadoc_add_remote_javadoc_A) Invoke_O_O_O__O(self, package_prefix__0, url__1 any) any {




	var tmp1 any = A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A_New_O_O(package_prefix__0, url__1); var tmp2 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A_fn_class = fncls__37d; tmp2 = fncls__37d } else { tmp2 = fncls__37 }; return lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :51:1
func A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A_New_O_O(p0, p1 any) *A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A{}; t.Ctor_O_O(p0, p1); return t }
//line :51:1
func (t *A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A) Ctor_O_O(c__package_prefix, c__url any) { t.F_package_prefix = c__package_prefix; t.F_url = c__url }
//line :51:1
func (t *A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_java_javadoc_A_const_6.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_java_javadoc_A_const_12.Get__O(), A_arbace_java_javadoc_A_const_13.GetRawRoot__O(), t.F_package_prefix, t.F_url) }

func A_arbace_java_javadoc_fill_in_module_name_A_New() *A_arbace_java_javadoc_fill_in_module_name_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_fill_in_module_name_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_java_javadoc_fill_in_module_name_A) Ctor() {}
//line :53:1
func (t *A_arbace_java_javadoc_fill_in_module_name_A) Invoke_O_O_O__O(self, url__0, classname__1 any) any {



	if jrt.NN(jrt.String_Cast(url__0)).Contains_CharSequence__Z(Lit_4) { var klass__3 any = jrt.Class_ForName_String__Class(jrt.String_Cast(classname__1)).Ref(); var module_name__4 any = jrt.NN(jrt.NN(jrt.Class_Cast(klass__3)).GetModule__Module()).GetName__String().Ref()


		return lang.IFn_Cast(A_arbace_java_javadoc_A_const_14.GetRawRoot__O()).Invoke_O_O__O(url__0, module_name__4) } else {
//line :57:1
			return url__0
		}
}



func A_arbace_java_javadoc_javadoc_url_A_New() *A_arbace_java_javadoc_javadoc_url_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_javadoc_url_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_java_javadoc_javadoc_url_A) Ctor() {}
//line :63:1
func (t *A_arbace_java_javadoc_javadoc_url_A) Invoke_O_O__O(self, classname__0 any) any { var classname__2 any; var root_43 any = A_arbace_java_javadoc_A_const_15.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_45 lang.IFn; if





	linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = classname__0; var arg_47 any = A_arbace_java_javadoc_A_const_16; var arg_48 any = Lit_9; if linked_44 == nil { classname__2 = ifn_45.Invoke_O_O_O__O(arg_46, arg_47, arg_48) } else { classname__2 = linked_44.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_43, arg_46, arg_47, arg_48) }; var file_path__3 any = /*line :63:1*/jrt.NN(jrt.String_Cast(classname__2)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_java_javadoc_A_const_17)).CharValue__C(), jrt.File_separatorChar).Ref(); var url_path__4 any = jrt.NN(jrt.String_Cast(classname__2)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_java_javadoc_A_const_17)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_java_javadoc_A_const_18)).CharValue__C()).Ref(); var temp__1927000408__auto____5 any; var root_49 any = A_arbace_java_javadoc_A_const_19.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_51 lang.IFn; if








	linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any; var root_53 any = A_arbace_java_javadoc_A_const_20.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_55 lang.IFn; if
	linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any; var tmp1 any = A_arbace_java_javadoc_javadoc_url_fn__1949000023_A_New(); var tmp2 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_java_javadoc_javadoc_url_fn__1949000023_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_java_javadoc_javadoc_url_fn__1949000023_A_fn_class = fncls__58d; tmp2 = fncls__58d } else { tmp2 = fncls__58 }; arg_56 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_57 any; var root_59 any = A_arbace_java_javadoc_A_const_21.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_61 lang.IFn; if
	linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any; var tmp3 any = A_arbace_java_javadoc_javadoc_url_fn__1949000025_A_New_O(file_path__3); var tmp4 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_java_javadoc_javadoc_url_fn__1949000025_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_java_javadoc_javadoc_url_fn__1949000025_A_fn_class = fncls__68d; tmp4 = fncls__68d } else { tmp4 = fncls__68 }; arg_62 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_63 any; var root_69 any = A_arbace_java_javadoc_A_const_7.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = A_arbace_java_javadoc_A_const_11.Get__O(); if linked_70 == nil { arg_63 = ifn_71.Invoke_O__O(arg_72) } else { arg_63 = linked_70.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_69, arg_72) }; if linked_60 == nil { arg_57 = ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { arg_57 = linked_60.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }; if /*line :73:1*/ linked_54 == nil { arg_52 = ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { arg_52 = linked_54.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_53, arg_56, arg_57) }; if /*line :72:1*/ linked_50 == nil { temp__1927000408__auto____5 = ifn_51.Invoke_O__O(arg_52) } else { temp__1927000408__auto____5 = linked_50.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_49, arg_52) }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var file__6 any = temp__1927000408__auto____5; var root_73 any = A_arbace_java_javadoc_A_const_22.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_75 lang.IFn



		if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = jrt.NN(jrt.File_Cast(file__6)).ToURI__URI().Ref(); if linked_74 == nil { return ifn_75.Invoke_O__O(arg_76) } else { return linked_74.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_73, arg_76) } } else {

			var root_77 any = A_arbace_java_javadoc_A_const_23.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any; var tmp5 any = A_arbace_java_javadoc_javadoc_url_fn__1949000028_A_New_O_O(classname__2, url_path__4); var tmp6 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_java_javadoc_javadoc_url_fn__1949000028_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_java_javadoc_javadoc_url_fn__1949000028_A_fn_class = fncls__87d; tmp6 = fncls__87d } else { tmp6 = fncls__87 }; arg_80 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_81 any; var root_88 any = A_arbace_java_javadoc_A_const_7.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = A_arbace_java_javadoc_A_const_12.Get__O(); if linked_89 == nil { arg_81 = ifn_90.Invoke_O__O(arg_91) } else { arg_81 = linked_89.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_88, arg_91) }; if linked_78 == nil { return ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { return linked_78.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_77, arg_80, arg_81) } } }
//line :73:1
func A_arbace_java_javadoc_javadoc_url_fn__1949000023_A_New() *A_arbace_java_javadoc_javadoc_url_fn__1949000023_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_javadoc_url_fn__1949000023_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_java_javadoc_javadoc_url_fn__1949000023_A) Ctor() {}
//line :73:1
func (t *A_arbace_java_javadoc_javadoc_url_fn__1949000023_A) Invoke_O_O__O(self, p1__1949000021_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(p1__1949000021_SHARP___1)).Exists__Z()).Ref() }
func A_arbace_java_javadoc_javadoc_url_fn__1949000025_A_New_O(p0 any) *A_arbace_java_javadoc_javadoc_url_fn__1949000025_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_javadoc_url_fn__1949000025_A{}; t.Ctor_O(p0); return t }
//line :74:1
func (t *A_arbace_java_javadoc_javadoc_url_fn__1949000025_A) Ctor_O(c__file_path any) { t.F_file_path = c__file_path }
//line :74:1
func (t *A_arbace_java_javadoc_javadoc_url_fn__1949000025_A) Invoke_O_O__O(self, p1__1949000022_SHARP___1 any) any { var tmp1 any; var root_64 any = A_arbace_java_javadoc_A_const_22.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = p1__1949000022_SHARP___1; if linked_65 == nil { tmp1 = ifn_66.Invoke_O__O(arg_67) } else { tmp1 = linked_65.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_64, arg_67) }; return jrt.File_New_String_String(jrt.String_Cast(tmp1), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_13), jrt.RefArrayOf(jrt.Object_class, t.F_file_path, nil))) }



func A_arbace_java_javadoc_javadoc_url_fn__1949000028_A_New_O_O(p0, p1 any) *A_arbace_java_javadoc_javadoc_url_fn__1949000028_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_javadoc_url_fn__1949000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :78:1
func (t *A_arbace_java_javadoc_javadoc_url_fn__1949000028_A) Ctor_O_O(c__classname, c__url_path any) { t.F_classname = c__classname; t.F_url_path = c__url_path }
//line :78:1
func (t *A_arbace_java_javadoc_javadoc_url_fn__1949000028_A) Invoke_O_O__O(self, p__1949000027__1 any) any { var vec__1949000029__2 any = p__1949000027__1; var prefix__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1949000029__2, lang.RT_IntCast_J__I_NoInit(0), nil); var url__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1949000029__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.String = jrt.String_Cast(t.F_classname); if
														jrt.NN(tmp1).StartsWith_String__Z(jrt.String_Cast(prefix__3)) {
															var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_13); var tmp3 any; var root_82 any = A_arbace_java_javadoc_A_const_24.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, A_arbace_java_javadoc_fill_in_module_name_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = url__4; var arg_86 any = t.F_classname; if linked_83 == nil { tmp3 = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { tmp3 = linked_83.(*A_arbace_java_javadoc_fill_in_module_name_A).Invoke_O_O_O__O(root_82, arg_85, arg_86) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, t.F_url_path, nil)).Ref() } else {
//line :79:1
			return nil } }




func A_arbace_java_javadoc_javadoc_A_New() *A_arbace_java_javadoc_javadoc_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_javadoc_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_java_javadoc_javadoc_A) Ctor() {}
//line :84:1
func (t *A_arbace_java_javadoc_javadoc_A) Invoke_O_O__O(self, class_or_object__0 any) any { var c__2 any; if




	jrt.Class_InstanceOf(class_or_object__0) { c__2 = class_or_object__0 } else {

		var root_92 any = A_arbace_java_javadoc_A_const_25.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = class_or_object__0; if linked_93 == nil { c__2 = ifn_94.Invoke_O__O(arg_95) } else { c__2 = linked_93.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_92, arg_95) } }; var temp__1927000408__auto____3 any; var root_96 any = /*line :84:1*/A_arbace_java_javadoc_A_const_26.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, A_arbace_java_javadoc_javadoc_url_A_fn_class); var ifn_98 lang.IFn; if







	linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = jrt.NN(jrt.Class_Cast(c__2)).GetName__String().Ref(); if linked_97 == nil { temp__1927000408__auto____3 = ifn_98.Invoke_O__O(arg_99) } else { temp__1927000408__auto____3 = linked_97.(*A_arbace_java_javadoc_javadoc_url_A).Invoke_O_O__O(root_96, arg_99) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var url__4 any = temp__1927000408__auto____3; var root_100 any = A_arbace_java_javadoc_A_const_27.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_java_browse.A_arbace_java_browse_browse_url_A_fn_class); var ifn_102 lang.IFn
		if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = url__4; if linked_101 == nil { return ifn_102.Invoke_O__O(arg_103) } else { return linked_101.(*aot_arbace_java_browse.A_arbace_java_browse_browse_url_A).Invoke_O_O__O(root_100, arg_103) } } else {
			return lang.IFn_Cast(A_arbace_java_javadoc_A_const_28.GetRawRoot__O()).Invoke_O_O__O(Lit_8, c__2) } }







type A_arbace_java_javadoc_A struct{ jrt.Object }

var A_arbace_java_javadoc_A_const_pool *jrt.RefArray

var A_arbace_java_javadoc_A_const_0 *lang.Var

var A_arbace_java_javadoc_A_const_1 any

var A_arbace_java_javadoc_A_const_2 *lang.Var

var A_arbace_java_javadoc_A_const_3 any

var A_arbace_java_javadoc_A_const_4 *lang.Var

var A_arbace_java_javadoc_A_const_5 any

var A_arbace_java_javadoc_A_const_6 *lang.Var

var A_arbace_java_javadoc_A_const_7 *lang.Var

var A_arbace_java_javadoc_A_const_8 *lang.Var

var A_arbace_java_javadoc_A_const_9 *lang.Var

var A_arbace_java_javadoc_A_const_10 any

var A_arbace_java_javadoc_A_const_11 *lang.Var

var A_arbace_java_javadoc_A_const_12 *lang.Var

var A_arbace_java_javadoc_A_const_13 *lang.Var

var A_arbace_java_javadoc_A_const_14 *lang.Var

var A_arbace_java_javadoc_A_const_15 *lang.Var

var A_arbace_java_javadoc_A_const_16 any

var A_arbace_java_javadoc_A_const_17 any

var A_arbace_java_javadoc_A_const_18 any

var A_arbace_java_javadoc_A_const_19 *lang.Var

var A_arbace_java_javadoc_A_const_20 *lang.Var

var A_arbace_java_javadoc_A_const_21 *lang.Var

var A_arbace_java_javadoc_A_const_22 *lang.Var

var A_arbace_java_javadoc_A_const_23 *lang.Var

var A_arbace_java_javadoc_A_const_24 *lang.Var

var A_arbace_java_javadoc_A_const_25 *lang.Var

var A_arbace_java_javadoc_A_const_26 *lang.Var

var A_arbace_java_javadoc_A_const_27 *lang.Var

var A_arbace_java_javadoc_A_const_28 *lang.Var

var A_arbace_java_javadoc_A_init jrt.ClassInit

func A_arbace_java_javadoc_A_Init() { if !A_arbace_java_javadoc_A_init.Done() { A_arbace_java_javadoc_A_init.Run(A_arbace_java_javadoc_A_clinit) } }

func A_arbace_java_javadoc_A_clinit() { A_arbace_java_javadoc_A_clinit_p0(); A_arbace_java_javadoc_A_clinit_p1(); A_arbace_java_javadoc_A_clinit_p2() }

func A_arbace_java_javadoc_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_javadoc_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 40); A_arbace_java_javadoc_A_const_0 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[11]); A_arbace_java_javadoc_A_const_1 = A_arbace_java_javadoc_A_const_pool.A[12]; A_arbace_java_javadoc_A_const_2 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[13]); A_arbace_java_javadoc_A_const_3 = A_arbace_java_javadoc_A_const_pool.A[14]; A_arbace_java_javadoc_A_const_4 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[15]); A_arbace_java_javadoc_A_const_5 = A_arbace_java_javadoc_A_const_pool.A[16]; A_arbace_java_javadoc_A_const_6 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[17]); A_arbace_java_javadoc_A_const_7 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[18]); A_arbace_java_javadoc_A_const_8 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[19]); A_arbace_java_javadoc_A_const_9 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[20]); A_arbace_java_javadoc_A_const_10 = A_arbace_java_javadoc_A_const_pool.A[21]; A_arbace_java_javadoc_A_const_11 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[22]) }

func A_arbace_java_javadoc_A_clinit_p1() { A_arbace_java_javadoc_A_const_12 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[23]); A_arbace_java_javadoc_A_const_13 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[24]); A_arbace_java_javadoc_A_const_14 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[25]); A_arbace_java_javadoc_A_const_15 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[26]); A_arbace_java_javadoc_A_const_16 = A_arbace_java_javadoc_A_const_pool.A[27]; A_arbace_java_javadoc_A_const_17 = A_arbace_java_javadoc_A_const_pool.A[28]; A_arbace_java_javadoc_A_const_18 = A_arbace_java_javadoc_A_const_pool.A[29]; A_arbace_java_javadoc_A_const_19 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[30]); A_arbace_java_javadoc_A_const_20 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[31]); A_arbace_java_javadoc_A_const_21 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[32]); A_arbace_java_javadoc_A_const_22 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[33]); A_arbace_java_javadoc_A_const_23 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[34]) }

func A_arbace_java_javadoc_A_clinit_p2() { A_arbace_java_javadoc_A_const_24 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[35]); A_arbace_java_javadoc_A_const_25 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[36]); A_arbace_java_javadoc_A_const_26 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[37]); A_arbace_java_javadoc_A_const_27 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[38]); A_arbace_java_javadoc_A_const_28 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[39]) }

func A_arbace_java_javadoc_A_New() *A_arbace_java_javadoc_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_A{}; t.Ctor(); return t }

func (t *A_arbace_java_javadoc_A) Ctor() {}

func (t *A_arbace_java_javadoc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_javadoc_A) GetClass__Class() *jrt.Class { return A_arbace_java_javadoc_A_class }

func (t *A_arbace_java_javadoc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_javadoc_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_javadoc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_javadoc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_javadoc_A); return ok }

func A_arbace_java_javadoc_A_Cast(x any) *A_arbace_java_javadoc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_javadoc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_javadoc_A_class)) }; return v }



type A_arbace_java_javadoc_add_local_javadoc_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_add_local_javadoc_A_fn_class *jrt.Class



type A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A struct{ j2g_header uint64; F_path any }

var A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A_fn_class *jrt.Class



type A_arbace_java_javadoc_add_remote_javadoc_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_add_remote_javadoc_A_fn_class *jrt.Class



type A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A struct{ j2g_header uint64; F_package_prefix, F_url any }

var A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A_fn_class *jrt.Class



type A_arbace_java_javadoc_eval1949000004_A struct{ jrt.Object }

func A_arbace_java_javadoc_eval1949000004_A_New() *A_arbace_java_javadoc_eval1949000004_A { t := &A_arbace_java_javadoc_eval1949000004_A{}; t.Ctor(); return t }

func (t *A_arbace_java_javadoc_eval1949000004_A) Ctor() {}

func (t *A_arbace_java_javadoc_eval1949000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_javadoc_eval1949000004_A) GetClass__Class() *jrt.Class { return A_arbace_java_javadoc_eval1949000004_A_class }

func (t *A_arbace_java_javadoc_eval1949000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_javadoc_eval1949000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_javadoc_eval1949000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_javadoc_eval1949000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_javadoc_eval1949000004_A); return ok }

func A_arbace_java_javadoc_eval1949000004_A_Cast(x any) *A_arbace_java_javadoc_eval1949000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_javadoc_eval1949000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_javadoc_eval1949000004_A_class)) }; return v }



type A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A_fn_class *jrt.Class



type A_arbace_java_javadoc_eval1949000008_A struct{ jrt.Object }

func A_arbace_java_javadoc_eval1949000008_A_New() *A_arbace_java_javadoc_eval1949000008_A { t := &A_arbace_java_javadoc_eval1949000008_A{}; t.Ctor(); return t }

func (t *A_arbace_java_javadoc_eval1949000008_A) Ctor() {}

func (t *A_arbace_java_javadoc_eval1949000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_javadoc_eval1949000008_A) GetClass__Class() *jrt.Class { return A_arbace_java_javadoc_eval1949000008_A_class }

func (t *A_arbace_java_javadoc_eval1949000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_javadoc_eval1949000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_javadoc_eval1949000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_javadoc_eval1949000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_javadoc_eval1949000008_A); return ok }

func A_arbace_java_javadoc_eval1949000008_A_Cast(x any) *A_arbace_java_javadoc_eval1949000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_javadoc_eval1949000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_javadoc_eval1949000008_A_class)) }; return v }



type A_arbace_java_javadoc_eval1949000008_fn__1949000009_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_eval1949000008_fn__1949000009_A_fn_class *jrt.Class



type A_arbace_java_javadoc_fill_in_module_name_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_fill_in_module_name_A_fn_class *jrt.Class



type A_arbace_java_javadoc_fn__1949000012_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_fn__1949000012_A_fn_class *jrt.Class



type A_arbace_java_javadoc_javadoc_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_javadoc_A_fn_class *jrt.Class



type A_arbace_java_javadoc_javadoc_url_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_javadoc_url_A_fn_class *jrt.Class



type A_arbace_java_javadoc_javadoc_url_fn__1949000023_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_javadoc_url_fn__1949000023_A_fn_class *jrt.Class



type A_arbace_java_javadoc_javadoc_url_fn__1949000025_A struct{ j2g_header uint64; F_file_path any }

var A_arbace_java_javadoc_javadoc_url_fn__1949000025_A_fn_class *jrt.Class



type A_arbace_java_javadoc_javadoc_url_fn__1949000028_A struct{ j2g_header uint64; F_classname, F_url_path any }

var A_arbace_java_javadoc_javadoc_url_fn__1949000028_A_fn_class *jrt.Class
