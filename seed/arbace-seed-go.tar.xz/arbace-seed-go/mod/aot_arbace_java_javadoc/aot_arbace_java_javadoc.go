//line aot_arbace_java_javadoc.ae:1
package aot_arbace_java_javadoc

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_browse"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :8:1
func A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A_New() *A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A{}; t.Ctor(); return t }
//line :8:1
func (t *A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A) Ctor() {}
//line :8:1
func (t *A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_java_javadoc_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_javadoc_A_const_1); lang.IFn_Cast(A_arbace_java_javadoc_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_java_javadoc_A_const_3); lang.IFn_Cast(A_arbace_java_javadoc_A_const_4.GetRawRoot__O()).Invoke_O__O(A_arbace_java_javadoc_A_const_5); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :8:1
func A_arbace_java_javadoc_eval1949000008_fn__1949000009_A_New() *A_arbace_java_javadoc_eval1949000008_fn__1949000009_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_eval1949000008_fn__1949000009_A{}; t.Ctor(); return t }
//line :8:1
func (t *A_arbace_java_javadoc_eval1949000008_fn__1949000009_A) Ctor() {}
//line :8:1
func (t *A_arbace_java_javadoc_eval1949000008_fn__1949000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_javadoc_A_const_6.GetRawRoot__O()); var tmp2 any; var root_19 any = A_arbace_java_javadoc_A_const_7.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_java_javadoc_A_const_8; if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_19, arg_22) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_java_javadoc_A_const_9.GetRawRoot__O(), A_arbace_java_javadoc_A_const_10) }














func A_arbace_java_javadoc_fn__1949000012_A_New() *A_arbace_java_javadoc_fn__1949000012_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_fn__1949000012_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_java_javadoc_fn__1949000012_A) Ctor() {}
//line :23:1
func (t *A_arbace_java_javadoc_fn__1949000012_A) Invoke_O__O(self any) any { var java_version__1 any = jrt.System_GetProperty_String__String(Lit_5).Ref(); return /*line :24:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil, Lit_7), jrt.RefArrayOf(jrt.Object_class, nil, java_version__1, nil)).Ref() }















func A_arbace_java_javadoc_add_local_javadoc_A_New() *A_arbace_java_javadoc_add_local_javadoc_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_add_local_javadoc_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_java_javadoc_add_local_javadoc_A) Ctor() {}
//line :40:1
func (t *A_arbace_java_javadoc_add_local_javadoc_A) Invoke_O_O__O(self, path__0 any) any {



	var tmp1 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A_New_O(path__0); var tmp2 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, fnbody__30); A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A_fn_class = fncls__29d; tmp2 = fncls__29d } else { tmp2 = fncls__29 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp2, nil); return lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)) }
//line :44:1
func A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A_New_O(p0 any) *A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A{}; t.Ctor_O(p0); return t }
//line :44:1
func (t *A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A) Ctor_O(c__path any) { t.F_path = c__path }
//line :44:1
func (t *A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_java_javadoc_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_java_javadoc_A_const_11.Get__O(), A_arbace_java_javadoc_A_const_9.GetRawRoot__O(), t.F_path) }

func A_arbace_java_javadoc_add_remote_javadoc_A_New() *A_arbace_java_javadoc_add_remote_javadoc_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_add_remote_javadoc_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_java_javadoc_add_remote_javadoc_A) Ctor() {}
//line :46:1
func (t *A_arbace_java_javadoc_add_remote_javadoc_A) Invoke_O_O_O__O(self, package_prefix__0, url__1 any) any {




	var tmp1 *lang.Compiler_AOTFn; var fnbody__39 any = A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A_New_O_O(package_prefix__0, url__1); var tmp2 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__39); A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A_fn_class = fncls__38d; tmp2 = fncls__38d } else { tmp2 = fncls__38 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__39, tmp2, nil); return lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)) }
//line :51:1
func A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A_New_O_O(p0, p1 any) *A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A{}; t.Ctor_O_O(p0, p1); return t }
//line :51:1
func (t *A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A) Ctor_O_O(c__package_prefix, c__url any) { t.F_package_prefix = c__package_prefix; t.F_url = c__url }
//line :51:1
func (t *A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_java_javadoc_A_const_6.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_java_javadoc_A_const_12.Get__O(), A_arbace_java_javadoc_A_const_13.GetRawRoot__O(), t.F_package_prefix, t.F_url) }

func A_arbace_java_javadoc_fill_in_module_name_A_New() *A_arbace_java_javadoc_fill_in_module_name_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_fill_in_module_name_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_java_javadoc_fill_in_module_name_A) Ctor() {}
//line :53:1
func (t *A_arbace_java_javadoc_fill_in_module_name_A) Invoke_O_O_O__O(self, url__0, classname__1 any) any {



	if jrt.NN(jrt.String_Cast(url__0)).Contains_CharSequence__Z(Lit_4) { var klass__3 any = jrt.Class_ForName_String__Class(jrt.String_Cast(classname__1)).Ref(); var module_name__4 any = jrt.NN(jrt.NN(jrt.Class_Cast(klass__3)).GetModule__Module()).GetName__String().Ref()


		return lang.IFn_Cast(A_arbace_java_javadoc_A_const_14.GetRawRoot__O()).Invoke_O_O__O(url__0, module_name__4) } else {
//line :57:1
			return url__0
		}
}



func A_arbace_java_javadoc_javadoc_url_A_New() *A_arbace_java_javadoc_javadoc_url_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_javadoc_url_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_java_javadoc_javadoc_url_A) Ctor() {}
//line :63:1
func (t *A_arbace_java_javadoc_javadoc_url_A) Invoke_O_O__O(self, classname__0 any) any { var classname__2 any; var root_45 any = A_arbace_java_javadoc_A_const_15.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_47 lang.IFn; if





	linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = classname__0; var arg_49 any = A_arbace_java_javadoc_A_const_16; var arg_50 any = Lit_9; if linked_46 == nil { classname__2 = ifn_47.Invoke_O_O_O__O(arg_48, arg_49, arg_50) } else { classname__2 = linked_46.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_45, arg_48, arg_49, arg_50) }; var file_path__3 any = /*line :63:1*/jrt.NN(jrt.String_Cast(classname__2)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_java_javadoc_A_const_17)).CharValue__C(), jrt.File_separatorChar).Ref(); var url_path__4 any = jrt.NN(jrt.String_Cast(classname__2)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_java_javadoc_A_const_17)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_java_javadoc_A_const_18)).CharValue__C()).Ref(); var temp__1927000408__auto____5 any; var root_51 any = A_arbace_java_javadoc_A_const_19.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_53 lang.IFn; if








	linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any; var root_55 any = A_arbace_java_javadoc_A_const_20.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_57 lang.IFn; if
	linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any; var fnbody__61 any = A_arbace_java_javadoc_javadoc_url_fn__1949000023_A_New(); var tmp1 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_java_javadoc_javadoc_url_fn__1949000023_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); A_arbace_java_javadoc_javadoc_url_fn__1949000023_A_fn_class = fncls__60d; tmp1 = fncls__60d } else { tmp1 = fncls__60 }; arg_58 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__61, tmp1, nil); var arg_59 any; var root_62 any = A_arbace_java_javadoc_A_const_21.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_64 lang.IFn; if
	linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any; var fnbody__72 any = A_arbace_java_javadoc_javadoc_url_fn__1949000025_A_New_O(file_path__3); var tmp2 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_java_javadoc_javadoc_url_fn__1949000025_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__72); A_arbace_java_javadoc_javadoc_url_fn__1949000025_A_fn_class = fncls__71d; tmp2 = fncls__71d } else { tmp2 = fncls__71 }; arg_65 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp2, nil); var arg_66 any; var root_73 any = A_arbace_java_javadoc_A_const_7.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = A_arbace_java_javadoc_A_const_11.Get__O(); if linked_74 == nil { arg_66 = ifn_75.Invoke_O__O(arg_76) } else { arg_66 = linked_74.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_73, arg_76) }; if linked_63 == nil { arg_59 = ifn_64.Invoke_O_O__O(arg_65, arg_66) } else { arg_59 = linked_63.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_62, arg_65, arg_66) }; if /*line :73:1*/ linked_56 == nil { arg_54 = ifn_57.Invoke_O_O__O(arg_58, arg_59) } else { arg_54 = linked_56.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_55, arg_58, arg_59) }; if /*line :72:1*/ linked_52 == nil { temp__1927000408__auto____5 = ifn_53.Invoke_O__O(arg_54) } else { temp__1927000408__auto____5 = linked_52.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_51, arg_54) }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var file__6 any = temp__1927000408__auto____5; var root_77 any = A_arbace_java_javadoc_A_const_22.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_79 lang.IFn



		if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = jrt.File_Cast(file__6).ToURI__URI().Ref(); if linked_78 == nil { return ifn_79.Invoke_O__O(arg_80) } else { return linked_78.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_77, arg_80) } } else {

			var root_81 any = A_arbace_java_javadoc_A_const_23.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any; var fnbody__92 any = A_arbace_java_javadoc_javadoc_url_fn__1949000028_A_New_O_O(classname__2, url_path__4); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_java_javadoc_javadoc_url_fn__1949000028_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__92); A_arbace_java_javadoc_javadoc_url_fn__1949000028_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; arg_84 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); var arg_85 any; var root_93 any = A_arbace_java_javadoc_A_const_7.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = A_arbace_java_javadoc_A_const_12.Get__O(); if linked_94 == nil { arg_85 = ifn_95.Invoke_O__O(arg_96) } else { arg_85 = linked_94.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_93, arg_96) }; if linked_82 == nil { return ifn_83.Invoke_O_O__O(arg_84, arg_85) } else { return linked_82.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_81, arg_84, arg_85) } } }
//line :73:1
func A_arbace_java_javadoc_javadoc_url_fn__1949000023_A_New() *A_arbace_java_javadoc_javadoc_url_fn__1949000023_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_javadoc_url_fn__1949000023_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_java_javadoc_javadoc_url_fn__1949000023_A) Ctor() {}
//line :73:1
func (t *A_arbace_java_javadoc_javadoc_url_fn__1949000023_A) Invoke_O_O__O(self, p1__1949000021_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(p1__1949000021_SHARP___1).Exists__Z()).Ref() }
func A_arbace_java_javadoc_javadoc_url_fn__1949000025_A_New_O(p0 any) *A_arbace_java_javadoc_javadoc_url_fn__1949000025_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_javadoc_url_fn__1949000025_A{}; t.Ctor_O(p0); return t }
//line :74:1
func (t *A_arbace_java_javadoc_javadoc_url_fn__1949000025_A) Ctor_O(c__file_path any) { t.F_file_path = c__file_path }
//line :74:1
func (t *A_arbace_java_javadoc_javadoc_url_fn__1949000025_A) Invoke_O_O__O(self, p1__1949000022_SHARP___1 any) any { var tmp1 any; var root_67 any = A_arbace_java_javadoc_A_const_22.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = p1__1949000022_SHARP___1; if linked_68 == nil { tmp1 = ifn_69.Invoke_O__O(arg_70) } else { tmp1 = linked_68.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_67, arg_70) }; return jrt.File_New_String_String(jrt.String_Cast(tmp1), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_13), jrt.RefArrayOf(jrt.Object_class, t.F_file_path, nil))) }



func A_arbace_java_javadoc_javadoc_url_fn__1949000028_A_New_O_O(p0, p1 any) *A_arbace_java_javadoc_javadoc_url_fn__1949000028_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_javadoc_url_fn__1949000028_A{}; t.Ctor_O_O(p0, p1); return t }
//line :78:1
func (t *A_arbace_java_javadoc_javadoc_url_fn__1949000028_A) Ctor_O_O(c__classname, c__url_path any) { t.F_classname = c__classname; t.F_url_path = c__url_path }
//line :78:1
func (t *A_arbace_java_javadoc_javadoc_url_fn__1949000028_A) Invoke_O_O__O(self, p__1949000027__1 any) any { var vec__1949000029__2 any = p__1949000027__1; var prefix__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1949000029__2, lang.RT_IntCast_J__I_NoInit(0), nil); var url__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1949000029__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.String = jrt.String_Cast(t.F_classname); if
														jrt.NN(tmp1).StartsWith_String__Z(jrt.String_Cast(prefix__3)) {
															var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_13); var tmp3 any; var root_86 any = A_arbace_java_javadoc_A_const_24.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, A_arbace_java_javadoc_fill_in_module_name_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = url__4; var arg_90 any = t.F_classname; if linked_87 == nil { tmp3 = ifn_88.Invoke_O_O__O(arg_89, arg_90) } else { tmp3 = linked_87.(*A_arbace_java_javadoc_fill_in_module_name_A).Invoke_O_O_O__O(root_86, arg_89, arg_90) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, t.F_url_path, nil)).Ref() } else {
//line :79:1
			return nil } }




func A_arbace_java_javadoc_javadoc_A_New() *A_arbace_java_javadoc_javadoc_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_javadoc_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_java_javadoc_javadoc_A) Ctor() {}
//line :84:1
func (t *A_arbace_java_javadoc_javadoc_A) Invoke_O_O__O(self, class_or_object__0 any) any { var c__2 any; if




	jrt.Class_InstanceOf(class_or_object__0) { c__2 = class_or_object__0 } else {

		var root_97 any = A_arbace_java_javadoc_A_const_25.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = class_or_object__0; if linked_98 == nil { c__2 = ifn_99.Invoke_O__O(arg_100) } else { c__2 = linked_98.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_97, arg_100) } }; var temp__1927000408__auto____3 any; var root_101 any = /*line :84:1*/A_arbace_java_javadoc_A_const_26.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, A_arbace_java_javadoc_javadoc_url_A_fn_class); var ifn_103 lang.IFn; if







	linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = jrt.NN(jrt.Class_Cast(c__2)).GetName__String().Ref(); if linked_102 == nil { temp__1927000408__auto____3 = ifn_103.Invoke_O__O(arg_104) } else { temp__1927000408__auto____3 = linked_102.(*A_arbace_java_javadoc_javadoc_url_A).Invoke_O_O__O(root_101, arg_104) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var url__4 any = temp__1927000408__auto____3; var root_105 any = A_arbace_java_javadoc_A_const_27.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_java_browse.A_arbace_java_browse_browse_url_A_fn_class); var ifn_107 lang.IFn
		if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = url__4; if linked_106 == nil { return ifn_107.Invoke_O__O(arg_108) } else { return linked_106.(*aot_arbace_java_browse.A_arbace_java_browse_browse_url_A).Invoke_O_O__O(root_105, arg_108) } } else {
			return lang.IFn_Cast(A_arbace_java_javadoc_A_const_28.GetRawRoot__O()).Invoke_O_O__O(Lit_8, c__2) } }







type A_arbace_java_javadoc_A struct{ jrt.Object }

var A_arbace_java_javadoc_A_const_pool *jrt.RefArray

var A_arbace_java_javadoc_A_const_0 *lang.Var

var A_arbace_java_javadoc_A_const_1 any

var A_arbace_java_javadoc_A_const_2 *lang.Var

var A_arbace_java_javadoc_A_const_3 any

var A_arbace_java_javadoc_A_const_4 *lang.Var

var A_arbace_java_javadoc_A_const_5 any

var A_arbace_java_javadoc_A_const_6 *lang.Var

var A_arbace_java_javadoc_A_const_7 *lang.Var

var A_arbace_java_javadoc_A_const_8 *lang.Var

var A_arbace_java_javadoc_A_const_9 *lang.Var

var A_arbace_java_javadoc_A_const_10 any

var A_arbace_java_javadoc_A_const_11 *lang.Var

var A_arbace_java_javadoc_A_const_12 *lang.Var

var A_arbace_java_javadoc_A_const_13 *lang.Var

var A_arbace_java_javadoc_A_const_14 *lang.Var

var A_arbace_java_javadoc_A_const_15 *lang.Var

var A_arbace_java_javadoc_A_const_16 any

var A_arbace_java_javadoc_A_const_17 any

var A_arbace_java_javadoc_A_const_18 any

var A_arbace_java_javadoc_A_const_19 *lang.Var

var A_arbace_java_javadoc_A_const_20 *lang.Var

var A_arbace_java_javadoc_A_const_21 *lang.Var

var A_arbace_java_javadoc_A_const_22 *lang.Var

var A_arbace_java_javadoc_A_const_23 *lang.Var

var A_arbace_java_javadoc_A_const_24 *lang.Var

var A_arbace_java_javadoc_A_const_25 *lang.Var

var A_arbace_java_javadoc_A_const_26 *lang.Var

var A_arbace_java_javadoc_A_const_27 *lang.Var

var A_arbace_java_javadoc_A_const_28 *lang.Var

var A_arbace_java_javadoc_A_init jrt.ClassInit

func A_arbace_java_javadoc_A_Init() { if !A_arbace_java_javadoc_A_init.Done() { A_arbace_java_javadoc_A_init.Run(A_arbace_java_javadoc_A_clinit) } }

func A_arbace_java_javadoc_A_clinit() { A_arbace_java_javadoc_A_clinit_p0(); A_arbace_java_javadoc_A_clinit_p1(); A_arbace_java_javadoc_A_clinit_p2() }

func A_arbace_java_javadoc_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_javadoc_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 40); A_arbace_java_javadoc_A_const_0 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[11]); A_arbace_java_javadoc_A_const_1 = A_arbace_java_javadoc_A_const_pool.A[12]; A_arbace_java_javadoc_A_const_2 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[13]); A_arbace_java_javadoc_A_const_3 = A_arbace_java_javadoc_A_const_pool.A[14]; A_arbace_java_javadoc_A_const_4 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[15]); A_arbace_java_javadoc_A_const_5 = A_arbace_java_javadoc_A_const_pool.A[16]; A_arbace_java_javadoc_A_const_6 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[17]); A_arbace_java_javadoc_A_const_7 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[18]); A_arbace_java_javadoc_A_const_8 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[19]); A_arbace_java_javadoc_A_const_9 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[20]); A_arbace_java_javadoc_A_const_10 = A_arbace_java_javadoc_A_const_pool.A[21]; A_arbace_java_javadoc_A_const_11 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[22]) }

func A_arbace_java_javadoc_A_clinit_p1() { A_arbace_java_javadoc_A_const_12 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[23]); A_arbace_java_javadoc_A_const_13 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[24]); A_arbace_java_javadoc_A_const_14 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[25]); A_arbace_java_javadoc_A_const_15 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[26]); A_arbace_java_javadoc_A_const_16 = A_arbace_java_javadoc_A_const_pool.A[27]; A_arbace_java_javadoc_A_const_17 = A_arbace_java_javadoc_A_const_pool.A[28]; A_arbace_java_javadoc_A_const_18 = A_arbace_java_javadoc_A_const_pool.A[29]; A_arbace_java_javadoc_A_const_19 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[30]); A_arbace_java_javadoc_A_const_20 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[31]); A_arbace_java_javadoc_A_const_21 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[32]); A_arbace_java_javadoc_A_const_22 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[33]); A_arbace_java_javadoc_A_const_23 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[34]) }

func A_arbace_java_javadoc_A_clinit_p2() { A_arbace_java_javadoc_A_const_24 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[35]); A_arbace_java_javadoc_A_const_25 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[36]); A_arbace_java_javadoc_A_const_26 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[37]); A_arbace_java_javadoc_A_const_27 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[38]); A_arbace_java_javadoc_A_const_28 = lang.Var_Cast(A_arbace_java_javadoc_A_const_pool.A[39]) }

func A_arbace_java_javadoc_A_New() *A_arbace_java_javadoc_A { A_arbace_java_javadoc_A_Init(); t := &A_arbace_java_javadoc_A{}; t.Ctor(); return t }

func (t *A_arbace_java_javadoc_A) Ctor() {}

func (t *A_arbace_java_javadoc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_javadoc_A) GetClass__Class() *jrt.Class { return A_arbace_java_javadoc_A_class }

func (t *A_arbace_java_javadoc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_javadoc_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_javadoc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_javadoc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_javadoc_A); return ok }

func A_arbace_java_javadoc_A_Cast(x any) *A_arbace_java_javadoc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_javadoc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_javadoc_A_class)) }; return v }



type A_arbace_java_javadoc_add_local_javadoc_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_add_local_javadoc_A_fn_class *jrt.Class



type A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A struct{ j2g_header uint64; F_path any }

var A_arbace_java_javadoc_add_local_javadoc_fn__1949000014_A_fn_class *jrt.Class



type A_arbace_java_javadoc_add_remote_javadoc_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_add_remote_javadoc_A_fn_class *jrt.Class



type A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A struct{ j2g_header uint64; F_package_prefix, F_url any }

var A_arbace_java_javadoc_add_remote_javadoc_fn__1949000017_A_fn_class *jrt.Class



type A_arbace_java_javadoc_eval1949000004_A struct{ jrt.Object }

func A_arbace_java_javadoc_eval1949000004_A_New() *A_arbace_java_javadoc_eval1949000004_A { t := &A_arbace_java_javadoc_eval1949000004_A{}; t.Ctor(); return t }

func (t *A_arbace_java_javadoc_eval1949000004_A) Ctor() {}

func (t *A_arbace_java_javadoc_eval1949000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_javadoc_eval1949000004_A) GetClass__Class() *jrt.Class { return A_arbace_java_javadoc_eval1949000004_A_class }

func (t *A_arbace_java_javadoc_eval1949000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_javadoc_eval1949000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_javadoc_eval1949000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_javadoc_eval1949000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_javadoc_eval1949000004_A); return ok }

func A_arbace_java_javadoc_eval1949000004_A_Cast(x any) *A_arbace_java_javadoc_eval1949000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_javadoc_eval1949000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_javadoc_eval1949000004_A_class)) }; return v }



type A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_eval1949000004_loading__1927001464__auto____1949000005_A_fn_class *jrt.Class



type A_arbace_java_javadoc_eval1949000008_A struct{ jrt.Object }

func A_arbace_java_javadoc_eval1949000008_A_New() *A_arbace_java_javadoc_eval1949000008_A { t := &A_arbace_java_javadoc_eval1949000008_A{}; t.Ctor(); return t }

func (t *A_arbace_java_javadoc_eval1949000008_A) Ctor() {}

func (t *A_arbace_java_javadoc_eval1949000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_javadoc_eval1949000008_A) GetClass__Class() *jrt.Class { return A_arbace_java_javadoc_eval1949000008_A_class }

func (t *A_arbace_java_javadoc_eval1949000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_javadoc_eval1949000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_javadoc_eval1949000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_javadoc_eval1949000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_javadoc_eval1949000008_A); return ok }

func A_arbace_java_javadoc_eval1949000008_A_Cast(x any) *A_arbace_java_javadoc_eval1949000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_javadoc_eval1949000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_javadoc_eval1949000008_A_class)) }; return v }



type A_arbace_java_javadoc_eval1949000008_fn__1949000009_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_eval1949000008_fn__1949000009_A_fn_class *jrt.Class



type A_arbace_java_javadoc_fill_in_module_name_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_fill_in_module_name_A_fn_class *jrt.Class



type A_arbace_java_javadoc_fn__1949000012_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_fn__1949000012_A_fn_class *jrt.Class



type A_arbace_java_javadoc_javadoc_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_javadoc_A_fn_class *jrt.Class



type A_arbace_java_javadoc_javadoc_url_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_javadoc_url_A_fn_class *jrt.Class



type A_arbace_java_javadoc_javadoc_url_fn__1949000023_A struct{ j2g_header uint64 }

var A_arbace_java_javadoc_javadoc_url_fn__1949000023_A_fn_class *jrt.Class



type A_arbace_java_javadoc_javadoc_url_fn__1949000025_A struct{ j2g_header uint64; F_file_path any }

var A_arbace_java_javadoc_javadoc_url_fn__1949000025_A_fn_class *jrt.Class



type A_arbace_java_javadoc_javadoc_url_fn__1949000028_A struct{ j2g_header uint64; F_classname, F_url_path any }

var A_arbace_java_javadoc_javadoc_url_fn__1949000028_A_fn_class *jrt.Class
