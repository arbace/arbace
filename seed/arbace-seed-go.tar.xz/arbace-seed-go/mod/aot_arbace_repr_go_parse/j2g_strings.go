//line j2g_strings.ae:1
package aot_arbace_repr_go_parse

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn10,arbace.setyn3,setyn14,arbace.go.replyn4,replyn15,arbace.go.checkyn2,ckyn19,arbace.repr.go.readyn2,rdyn19,arbace.repr.go.loadyn2,ldkn3,docys2,go4,typeys2,go6,methodkn3,tagyn1,*yn3,Posyn3,Endyn9,interfaceys5,token3,Poskn3,posys5,token5,Tokenkn5,tokenyn7,ChanDirkn8,chan-diryn12,CommentGroupkn4,linekn6,columnkn7,commentyn6,stringkn6,stringyn4,boolkn4,boolyn5,slicekn5,nodeskn4,nodekn4,elsekn7,unknownyn6,structkn4,namekn6,fieldskn3,keykn4,kindyn4,set!yn2,kvyn6,appendyn1,xyn7,chanDiryn4,whenyn2,!=yn4,.stryn1,dyn3,letyn2,xsyn4,makeyn3,anyyn3,lenyn5,rangeyn4,asetyn1,iyn5,.nodeyn1,eys6,arbace4,Callyn5,vecFnyn6,spreadyn8,.IsValidyn4,.posys5,token7,ILLEGALyn7,.Stringyn14,TypeAssertExpryn12,SelectorExpryn3,dotyn9,.dotAfteryn4,.Endyn6,kw_dotyn4,.Posyn6,.-docsyn4,caseyn2,==yn6,returnyn5,panicyn4,mkFnyn2,nsyn24,go.arbace.repr.go.godumpkn7,requireyn9,arbace.goyn2,goys2,go7,packageyn6,godumpkn4,pathkn5,filesyn5,in-nsyn5,quoteys2,go4,filekn7,importsyn6,arbaceyn3,astyn6,parseryn5,tokenyn2,osyn8,filepathyn7,strconvyn7,stringsyn4,timeyn4,utf8yn6,dumperys5,token7,FileSetys5,token4,Fileyn4,byteyn3,mapys3,ast12,CommentGroupys2,go3,varys2,go4,funcyn4,Inityn2,mkyn3,vecyn5,mapFnyn1,mys6,arbace2,Kwyn3,posyn3,notyn1,pyn2,ppyn12,.PositionForyn6,.-fsetyn1,+ys7,strconv4,Itoayn6,.-Lineyn8,.-Columnyn7,posFileys8,filepath4,Baseyn10,.-Filenameys4,utf811,ValidStringyn1,syn2,bsyn3,foryn1,<yn4,inc!yn4,convyn5,int64yn4,agetyn8,kw_bytesys3,ast7,ChanDiryn6,switchyn3,dirys3,ast4,SENDyn7,kw_sendys3,ast4,RECVyn7,kw_recvyn7,kw_bothyn8,dotAfteryn3,srcyn5,.-srcyn2,tfyn4,.-tfyn2,oryn4,fromys5,token5,NoPosyn3,offyn7,.Offsetyn5,whileyn1,cyn4,condyn3,andyn3,endys7,strings5,Indexyn8,subsliceyn11,isDirectiveys7,strings9,HasPrefixyn4,textyn6,valuesyn1,_yn2,okys3,ast14,ParseDirectiveyn6,inExprys3,ast4,Fileyn5,foundys3,ast7,Inspectyn1,fyn2,fnys3,ast4,Nodeyn1,nyn2,>=yn6,assertys3,ast4,Expryn8,commentsyn2,gsyn10,.-Commentsyn1,gyn2,csyn6,.-Listyn1,kyn7,.-Slashyn6,.-Textyn6,.-dirsyn8,.posFileyn7,.-warnsyn2,ifyn7,kw_listyn7,kw_textyn5,.Textyn8,DumpFileyn3,errys2,os8,ReadFileyn4,pathyn6,.Erroryn2,t0ys4,time3,Nowyn4,fsetys5,token10,NewFileSetkn6,assignys6,parser9,ParseFileyn6,bit-orys6,parser13,ParseCommentsys6,parser20,SkipObjectResolutionyn2,t1yn4,addryn3,litkn4,fsetkn3,srckn2,tfyn5,.Fileyn11,.-FileStartkn4,docsyn4,treeyn9,.commentsyn2,wsyn1,wyn12,.Nanosecondsyn4,.Subys4,time5,Sinceyn4,nodeyn11,type-switchkn2,nskn6,configkn4,optskn5,funcskn7,globalskn5,typeskn7,definedkn6,errorskn4,filekn3,msgkn5,vars?kn5,initskn10,init-funcsys24,go.arbace.repr.go.godump4,Initys24,go.arbace.repr.go.godump8,DumpFilekn9,dump-filekn2,mskn5,errorkn3,astkn8,commentskn10,directiveskn8,warningskn8,parse-mskn7,dump-msyn4,loadkn3,dirkn6,headerkn10,go-versionkn6,godumpkn5,timeskn5,byteskn3,nilkn7,keywordkn7,booleankn7,integerkn3,mapkn6,vectorkn4,listks20,arbace.repr.go.parse7,missingkn5,countkn7,packagekn4,keyskn4,failkn8,rejectedkn5,extrakn7,read-mskn9,native-mskn4,diffkn3,subkn7,tsv-keykn5,loadskn6,statuskn5,dumpskn3,tsvkn7,missingkn6,corpuskn4,jobskn7,resultskn5,equalkn6,load-skn7,parse-skn6,dump-skn6,read-skn6,differkn6,wall-skn5,formskn3,outkn6,reportkn5,knownkn7,headerskn7,corporav11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn20,arbace.repr.go.parsem2,R14,s1693,repr/go's native reader, its tree (doc/go/GO-PARSER-SURVEY.md, GP1): Go's own go/parser, as\n  the Go forms of tamago/goroot, run by goi (interpreted, GPS1 (c), GPS4 (b)), and a dumper that\n  builds the tree of the helper's dump (doc/go/HELPER-NOTES.md, \"The tree\") directly as Arbace\n  data (GPS6 (a): format :godump 2, positions \"L:C\"), without the dump's text.\n\n  The dumper is a Go package of Go forms, generated here from go/ast's forms\n  (tamago/goroot/go/go/ast/ast.ae, GPS5 (a)): one case of a type switch per node type of go/ast,\n  its fields in go/ast's order and of the helper's kinds (positions, tokens, channel\n  directions, strings, booleans, comment groups as their first position, nodes and lists of\n  nodes; the parser's resolution, File.Imports and File.Comments not written), plus the parts\n  that are not go/ast's: the selector's and type assertion's :dot, the comment groups with :text\n  on doc groups, the directives and the :warnings, after tools/godump/dump.go. It is checked and\n  defined by goi (arbace.go.repl) once per process, under the import path\n  arbace/repr/go/godump, and imports go/parser, go/ast and go/token (interpreted from the\n  digest), strconv, strings, path/filepath, os, time and arbace (compiled).\n\n  No annotations: they are GP4's. The files and each dump's header come from the loader\n  (arbace.repr.go.load, GP2; go list's part in arbace.box.plan), not from the helper: native-dump\n  takes a loader's job (its header, directory and files) and parses its files. E-tree compares\n  the native dumps with the helper's: the headers, the trees and the sets of dumps.\n\n  bin/repr-go read --reader native ... and bin/repr-go native-check run -main here.v15,arbace.go.check17,read-string-formsv11,arbace.core5,slurpv11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core4,seq?R15,v11,arbace.core6,removev11,arbace.core7,string?v11,arbace.core4,restv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core7,symbol?v11,arbace.core7,vector?v11,arbace.core4,lastv11,arbace.core6,secondv11,arbace.core6,concatv11,arbace.core3,setR16,v11,arbace.core6,filterR17,R18,v13,arbace.string10,lower-casev13,arbace.string7,replacep13,(?<=.)([A-Z])v20,arbace.repr.go.parse9,ast-formsv20,arbace.repr.go.parse10,type-specsv10,arbace.set12,intersectionv20,arbace.repr.go.parse14,receiver-typesR19,R20,R21,v11,arbace.core9,contains?R18,R22,R23,R24,R25,R26,R27,ML2,R18,R28,m4,R29,i85,R30,i24,R31,R32,R33,R34,R35,R36,R37,R38,R39,R40,v11,arbace.core6,pr-strv11,arbace.core3,vecR41,R42,R43,v11,arbace.core3,notv20,arbace.repr.go.parse10,skip-fieldv11,arbace.core4,nameR44,v20,arbace.repr.go.parse5,kebabR45,v11,arbace.core6,symbolv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core4,listv20,arbace.repr.go.parse6,kw-varR46,R47,R48,R47,R49,R50,R51,R52,R53,R54,R51,R52,R55,R56,R57,ML2,R36,R58,m4,R29,i130,R30,i50,R59,R60,ML4,R61,R56,R62,ML3,R63,R54,R64,m4,R29,i131,R30,i63,m4,R29,i131,R30,i52,R62,R64,ML3,R65,R66,ML2,R67,R56,m4,R29,i132,R30,i52,m4,R29,i132,R30,i33,R51,R68,R69,R54,R51,R51,R52,R70,R71,v11,arbace.core5,list*R51,R52,R63,R54,S2,R72,R73,R55,R74,R75,R54,R76,R51,ML2,R68,R74,m4,R29,i127,R30,i43,ML3,R46,R47,ML4,R48,R47,R77,ML3,R69,R54,R74,m4,R29,i128,R30,i64,m4,R29,i128,R30,i46,m4,R29,i128,R30,i37,R51,R52,R69,R54,R78,R61,ML2,R79,R54,m4,R29,i121,R30,i58,v11,arbace.core4,someR80,ML3,R51,ML3,R81,R49,nm4,R29,i138,R30,i20,ML2,R82,nm4,R29,i138,R30,i31,m4,R29,i138,R30,i14,R18,v11,arbace.core3,strR83,R55,R47,R57,ML2,R36,R58,m4,R29,i141,R30,i40,l1,R61,R47,l0,v11,arbace.core6,mapcatv20,arbace.repr.go.parse11,field-stmtsV1,ML2,R82,ML3,R65,R84,ML2,R67,R47,m4,R29,i144,R30,i53,m4,R29,i144,R30,i35,m4,R29,i144,R30,i27,v20,arbace.repr.go.parse9,ast-nodesv11,arbace.core8,distinctv20,arbace.repr.go.parse10,fixed-keysv11,arbace.core3,mapv11,arbace.core4,compV9,ML3,R85,R86,ML2,R87,V3,R88,R2,R89,m4,R29,i158,R30,i38,m4,R29,i158,R30,i9,ML6,R90,R91,R92,s21,arbace/repr/go/godumpR93,V1,s7,dump.gom4,R29,i159,R30,i9,ML2,R94,L2,R95,R86,m4,R29,i160,R30,i9,ML6,R96,s7,dump.goR14,s170,Package godump builds the tree of repr/go's dump (doc/go/HELPER-NOTES.md, \"The tree\") of a Go file as Arbace data: generated by arbace.repr.go.parse from go/ast's forms.\nR97,V10,V2,R98,s6,arbaceV2,R99,s6,go/astV2,R100,s9,go/parserV2,R101,s8,go/tokenV2,R102,s2,osV2,R103,s13,path/filepathV2,R104,s7,strconvV2,R105,s7,stringsV2,R106,s4,timeV2,R107,s12,unicode/utf8m4,R29,i161,R30,i9,ML3,R15,R108,ML7,R41,Myn4,fsetm2,R17,ML2,R18,R109,m4,R29,i167,R30,i34,Myn2,tfm2,R17,ML2,R18,R110,m4,R29,i168,R30,i34,Myn3,srcm2,R17,ML2,R36,R111,m4,R29,i169,R30,i34,Myn4,docsm2,R17,ML3,R112,ML2,R18,R113,m4,R29,i170,R30,i39,R34,m4,R29,i170,R30,i34,Myn4,dirsm2,R17,ML2,R36,R58,m4,R29,i171,R30,i34,Myn5,warnsm2,R17,ML2,R36,R58,m4,R29,i172,R30,i34,m4,R29,i166,R30,i25,m4,R29,i166,R30,i9,ML2,R114,Myn4,mkFnm4,R17,R58,R14,s66,mkFn makes a node, (head {key value ...}) from head key value ...\nm4,R29,i173,R30,i9,ML2,R114,Myn5,vecFnm4,R17,R58,R14,s29,vecFn is arbace.core/vector.\nm4,R29,i174,R30,i9,ML2,R114,Myn5,mapFnm4,R17,R58,R14,s32,mapFn is arbace.core/array-map.\nm4,R29,i175,R30,i9,ML7,R115,R116,s58,Init sets the Arbace fns the dumper builds its data with.\nV3,Myn2,mkm2,R17,R58,Myn3,vecm2,R17,R58,Myn1,mm2,R17,R58,ML3,R46,R84,R117,m4,R29,i177,R30,i11,ML3,R46,R66,R118,m4,R29,i178,R30,i11,ML3,R46,R119,R120,m4,R29,i179,R30,i11,m4,R29,i176,R30,i9,R114,R121,ML6,R16,R122,s90,pos is p as \"L:C\": raw (not adjusted by //line), byte columns from 1; nil when not valid.\nMV2,Myn1,dm2,R17,ML2,R18,R108,m4,R29,i182,R30,i24,Myn1,pm2,R17,R22,m2,R17,R58,ML3,R51,ML2,R123,ML2,R68,R124,m4,R29,i183,R30,i22,m4,R29,i183,R30,i17,ML2,R82,nm4,R29,i183,R30,i36,m4,R29,i183,R30,i11,ML3,R55,V2,R125,ML4,R126,ML2,R127,R54,m4,R29,i184,R30,i34,R124,Fm4,R29,i184,R30,i20,ML4,R128,ML2,R129,ML2,R130,R125,m4,R29,i185,R30,i30,m4,R29,i185,R30,i16,s1,:ML2,R129,ML2,R131,R125,m4,R29,i185,R30,i61,m4,R29,i185,R30,i47,m4,R29,i185,R30,i13,m4,R29,i184,R30,i11,m4,R29,i181,R30,i9,ML5,R16,R132,s46,posFile is p as \"FILE:L:C\", FILE a base name.\nMV2,Myn1,dm2,R17,ML2,R18,R108,m4,R29,i187,R30,i27,Myn1,pm2,R17,R22,m2,R17,R32,ML3,R55,V2,R125,ML4,R126,ML2,R127,R54,m4,R29,i188,R30,i34,R124,Fm4,R29,i188,R30,i20,ML6,R128,ML2,R133,ML2,R134,R125,m4,R29,i189,R30,i31,m4,R29,i189,R30,i16,s1,:ML2,R129,ML2,R130,R125,m4,R29,i189,R30,i66,m4,R29,i189,R30,i52,s1,:ML2,R129,ML2,R131,R125,m4,R29,i189,R30,i97,m4,R29,i189,R30,i83,m4,R29,i189,R30,i13,m4,R29,i188,R30,i11,m4,R29,i186,R30,i9,ML6,R16,R3,s57,str is s, or (:bytes [b ...]) when s is not valid UTF-8.\nMV2,Myn1,dm2,R17,ML2,R18,R108,m4,R29,i191,R30,i24,Myn1,sm2,R17,R32,m2,R17,R58,ML3,R51,ML2,R123,ML2,R135,R136,m4,R29,i192,R30,i22,m4,R29,i192,R30,i17,ML4,R55,V2,R137,ML3,R57,ML2,R36,R58,m4,R29,i193,R30,i28,ML2,R59,R136,m4,R29,i193,R30,i40,m4,R29,i193,R30,i22,ML5,R138,V2,R62,l0,ML3,R139,R62,ML2,R59,R136,m4,R29,i194,R30,i31,m4,R29,i194,R30,i26,ML2,R140,R62,m4,R29,i194,R30,i40,ML4,R61,R137,R62,ML3,R141,R142,ML3,R143,R136,R62,m4,R29,i195,R30,i40,m4,R29,i195,R30,i28,m4,R29,i195,R30,i17,m4,R29,i194,R30,i15,ML2,R82,ML4,R65,s16,arbace.core/listR144,ML3,R65,R66,ML2,R67,R137,m4,R29,i196,R30,i83,m4,R29,i196,R30,i64,m4,R29,i196,R30,i23,m4,R29,i196,R30,i15,m4,R29,i193,R30,i13,m4,R29,i192,R30,i11,R136,m4,R29,i190,R30,i9,ML5,R115,R50,MV1,Myn3,dirm2,R17,R145,m2,R17,R58,ML4,R146,R147,ML3,R80,V1,R148,ML2,R82,R149,m4,R29,i200,R30,i30,m4,R29,i200,R30,i13,ML3,R80,V1,R150,ML2,R82,R151,m4,R29,i201,R30,i30,m4,R29,i201,R30,i13,m4,R29,i199,R30,i11,R152,m4,R29,i198,R30,i9,ML5,R16,R153,s131,dotAfter is the position of the first \".\" at or after from, skipping white space and comments; NoPos if another token comes first.\nMV2,Myn1,dm2,R17,ML2,R18,R108,m4,R29,i204,R30,i30,Myn4,fromm2,R17,R22,m2,R17,R22,ML4,R55,V4,R154,ML2,R155,R54,m4,R29,i205,R30,i21,R156,ML2,R157,R54,m4,R29,i205,R30,i34,ML3,R51,ML3,R158,ML3,R81,R156,nm4,R29,i206,R30,i23,ML2,R123,ML2,R68,R159,m4,R29,i206,R30,i40,m4,R29,i206,R30,i35,m4,R29,i206,R30,i19,ML2,R82,R160,m4,R29,i206,R30,i58,m4,R29,i206,R30,i13,ML4,R55,V2,R161,ML3,R162,R156,R159,m4,R29,i207,R30,i23,ML3,R163,ML3,R139,R161,ML2,R59,R154,m4,R29,i208,R30,i29,m4,R29,i208,R30,i22,ML3,R55,V2,R164,ML3,R143,R154,R161,m4,R29,i209,R30,i25,ML11,R165,ML5,R158,ML3,R81,R164,c32,m4,R29,i211,R30,i25,ML3,R81,R164,c9,m4,R29,i211,R30,i39,ML3,R81,R164,c10,m4,R29,i211,R30,i51,ML3,R81,R164,c13,m4,R29,i211,R30,i67,m4,R29,i211,R30,i21,ML2,R140,R161,m4,R29,i211,R30,i83,ML4,R166,ML3,R81,R164,c47,m4,R29,i212,R30,i26,ML3,R139,ML3,R128,R161,l1,m4,R29,i212,R30,i39,ML2,R59,R154,m4,R29,i212,R30,i49,m4,R29,i212,R30,i36,ML3,R81,ML3,R143,R154,ML3,R128,R161,l1,m4,R29,i212,R30,i74,m4,R29,i212,R30,i64,c47,m4,R29,i212,R30,i60,m4,R29,i212,R30,i21,ML3,R163,ML3,R166,ML3,R139,R161,ML2,R59,R154,m4,R29,i213,R30,i40,m4,R29,i213,R30,i33,ML3,R52,ML3,R143,R154,R161,m4,R29,i213,R30,i55,c10,m4,R29,i213,R30,i51,m4,R29,i213,R30,i28,ML2,R140,R161,m4,R29,i213,R30,i81,m4,R29,i213,R30,i21,ML4,R166,ML3,R81,R164,c47,m4,R29,i214,R30,i26,ML3,R139,ML3,R128,R161,l1,m4,R29,i214,R30,i39,ML2,R59,R154,m4,R29,i214,R30,i49,m4,R29,i214,R30,i36,ML3,R81,ML3,R143,R154,ML3,R128,R161,l1,m4,R29,i214,R30,i74,m4,R29,i214,R30,i64,c42,m4,R29,i214,R30,i60,m4,R29,i214,R30,i21,ML4,R55,V2,R167,ML3,R168,ML3,R141,R32,ML3,R169,R154,ML3,R128,R161,l2,m4,R29,i215,R30,i73,m4,R29,i215,R30,i59,m4,R29,i215,R30,i46,s2,*/m4,R29,i215,R30,i31,ML3,R51,ML3,R139,R167,l0,m4,R29,i216,R30,i29,ML2,R82,R160,m4,R29,i216,R30,i39,m4,R29,i216,R30,i23,ML4,R46,R161,R128,ML4,R128,l2,R167,l2,m4,R29,i217,R30,i35,m4,R29,i217,R30,i23,m4,R29,i215,R30,i21,ML3,R81,R164,c46,m4,R29,i218,R30,i21,ML2,R82,ML3,R78,R156,R161,m4,R29,i218,R30,i39,m4,R29,i218,R30,i31,R39,ML2,R82,R160,m4,R29,i219,R30,i27,m4,R29,i210,R30,i19,m4,R29,i209,R30,i17,m4,R29,i208,R30,i15,R160,m4,R29,i207,R30,i13,m4,R29,i205,R30,i11,m4,R29,i203,R30,i9,ML6,R115,R170,s146,isDirective: //go: directives, build constraints, line directives, cgo's //export, gccgo's //extern, and every other directive go/ast recognises.\nMV1,Myn4,textm2,R17,R32,m2,R17,R34,ML3,R51,ML7,R158,ML3,R171,R172,s5,//go:m4,R29,i223,R30,i21,ML3,R171,R172,s7,//line m4,R29,i223,R30,i54,ML3,R171,R172,s7,/*line m4,R29,i224,R30,i21,ML3,R171,R172,s9,// +buildm4,R29,i224,R30,i56,ML3,R171,R172,s9,//export m4,R29,i225,R30,i21,ML3,R171,R172,s9,//extern m4,R29,i225,R30,i58,m4,R29,i223,R30,i17,ML2,R82,Tm4,R29,i226,R30,i13,m4,R29,i223,R30,i11,ML3,R55,V2,ML3,R173,R174,R175,m4,R29,i227,R30,i17,ML3,R176,R160,R172,m4,R29,i227,R30,i31,R175,m4,R29,i227,R30,i11,m4,R29,i221,R30,i9,ML5,R115,R177,s75,inExpr reports whether position p lies strictly inside an expression of f.\nMV2,Myn1,fm2,R17,ML2,R18,R178,m4,R29,i230,R30,i25,Myn1,pm2,R17,R22,m2,R17,R34,ML4,R55,V2,R179,FML3,R180,R181,ML5,R182,MV1,Myn1,nm2,R17,R183,m2,R17,R34,ML3,R51,ML5,R158,R179,ML3,R81,R184,nm4,R29,i233,R30,i46,ML3,R139,R124,ML2,R78,R184,m4,R29,i233,R30,i62,m4,R29,i233,R30,i57,ML3,R185,R124,ML2,R76,R184,m4,R29,i233,R30,i78,m4,R29,i233,R30,i72,m4,R29,i233,R30,i36,ML2,R82,Fm4,R29,i234,R30,i32,m4,R29,i233,R30,i30,ML3,R55,V2,ML3,R173,R174,R175,m4,R29,i235,R30,i36,ML3,R186,R187,R184,m4,R29,i235,R30,i50,ML3,R51,ML3,R166,R175,ML3,R139,ML2,R78,R184,m4,R29,i236,R30,i49,R124,m4,R29,i236,R30,i46,m4,R29,i236,R30,i38,ML3,R46,R179,Tm4,R29,i237,R30,i34,m4,R29,i236,R30,i32,m4,R29,i235,R30,i30,ML2,R123,R179,m4,R29,i238,R30,i30,m4,R29,i232,R30,i28,m4,R29,i232,R30,i13,R179,m4,R29,i231,R30,i11,m4,R29,i229,R30,i9,ML5,R16,R188,s151,comments is the file's comment groups, [{:list [[\"L:C\" text] ...] [:text ...]} ...], :text on doc groups; it collects the directives and the warnings.\nMV2,Myn1,dm2,R17,ML2,R18,R108,m4,R29,i241,R30,i24,Myn1,fm2,R17,ML2,R18,R178,m4,R29,i241,R30,i45,m2,R17,R58,ML4,R55,V2,R189,ML3,R57,ML2,R36,R58,m4,R29,i242,R30,i26,ML2,R59,ML2,R190,R181,m4,R29,i242,R30,i43,m4,R29,i242,R30,i38,m4,R29,i242,R30,i20,ML3,R60,V3,R62,R191,ML2,R190,R181,m4,R29,i243,R30,i25,ML4,R55,V2,R192,ML3,R57,ML2,R36,R58,m4,R29,i244,R30,i30,ML2,R59,ML2,R193,R191,m4,R29,i244,R30,i47,m4,R29,i244,R30,i42,m4,R29,i244,R30,i24,ML4,R60,V3,R194,R164,ML2,R193,R191,m4,R29,i245,R30,i29,ML4,R61,R192,R194,ML4,R65,R66,ML3,R69,R54,ML2,R195,R164,m4,R29,i246,R30,i57,m4,R29,i246,R30,i49,ML3,R53,R54,ML2,R196,R164,m4,R29,i246,R30,i78,m4,R29,i246,R30,i70,m4,R29,i246,R30,i30,m4,R29,i246,R30,i19,ML4,R51,ML2,R170,ML2,R196,R164,m4,R29,i247,R30,i38,m4,R29,i247,R30,i25,ML3,R46,ML2,R197,R54,m4,R29,i248,R30,i27,ML3,R48,ML2,R197,R54,m4,R29,i248,R30,i46,ML4,R65,R66,ML3,R198,R54,ML2,R195,R164,m4,R29,i248,R30,i88,m4,R29,i248,R30,i76,ML3,R53,R54,ML2,R196,R164,m4,R29,i248,R30,i109,m4,R29,i248,R30,i101,m4,R29,i248,R30,i57,m4,R29,i248,R30,i38,m4,R29,i248,R30,i21,ML3,R51,ML3,R166,ML3,R171,ML2,R196,R164,m4,R29,i249,R30,i51,s7,/*line m4,R29,i249,R30,i32,ML3,R177,R181,ML2,R195,R164,m4,R29,i249,R30,i83,m4,R29,i249,R30,i73,m4,R29,i249,R30,i27,ML3,R46,ML2,R199,R54,m4,R29,i250,R30,i29,ML3,R48,ML2,R199,R54,m4,R29,i250,R30,i49,ML3,R128,ML3,R198,R54,ML2,R195,R164,m4,R29,i250,R30,i76,m4,R29,i250,R30,i64,s41,: /*line*/ directive inside an expressionm4,R29,i250,R30,i61,m4,R29,i250,R30,i41,m4,R29,i250,R30,i23,m4,R29,i249,R30,i21,m4,R29,i247,R30,i19,m4,R29,i245,R30,i17,ML4,R200,ML3,R143,ML2,R79,R54,m4,R29,i251,R30,i27,R191,m4,R29,i251,R30,i21,ML4,R61,R189,R62,ML6,R65,R119,R201,ML3,R65,R66,ML2,R67,R192,m4,R29,i252,R30,i76,m4,R29,i252,R30,i57,R202,ML3,R53,R54,ML2,R203,R191,m4,R29,i252,R30,i105,m4,R29,i252,R30,i97,m4,R29,i252,R30,i30,m4,R29,i252,R30,i19,ML4,R61,R189,R62,ML4,R65,R119,R201,ML3,R65,R66,ML2,R67,R192,m4,R29,i253,R30,i76,m4,R29,i253,R30,i57,m4,R29,i253,R30,i30,m4,R29,i253,R30,i19,m4,R29,i251,R30,i17,m4,R29,i244,R30,i15,m4,R29,i243,R30,i13,ML3,R65,R66,ML2,R67,R189,m4,R29,i254,R30,i32,m4,R29,i254,R30,i13,m4,R29,i242,R30,i11,m4,R29,i240,R30,i9,ML5,R115,R204,s163,DumpFile parses the Go file at path (ParseComments, SkipObjectResolution) and dumps it: [tree comments directives warnings parse-ns dump-ns], or the error's text.\nMV1,Myn4,pathm2,R17,R32,m2,R17,R58,ML4,R55,V2,ML3,R173,R154,R205,m4,R29,i262,R30,i17,ML2,R206,R207,m4,R29,i262,R30,i34,ML3,R51,ML3,R52,R205,nm4,R29,i263,R30,i19,ML2,R82,ML2,R208,R205,m4,R29,i263,R30,i40,m4,R29,i263,R30,i32,m4,R29,i263,R30,i13,ML4,R55,V6,R209,ML1,R210,m4,R29,i264,R30,i22,R211,ML1,R212,m4,R29,i265,R30,i24,ML3,R173,R181,Myn3,errm2,R213,Tm4,R29,i266,R30,i19,ML5,R214,R211,R207,R154,ML3,R215,R216,R217,m4,R29,i266,R30,i75,m4,R29,i266,R30,i43,ML3,R51,ML3,R52,R205,nm4,R29,i267,R30,i21,ML2,R82,ML2,R208,R205,m4,R29,i267,R30,i42,m4,R29,i267,R30,i34,m4,R29,i267,R30,i15,ML4,R55,V10,R218,ML1,R210,m4,R29,i268,R30,i24,R54,ML2,R219,ML10,R220,R108,R221,R211,R222,R154,R223,ML3,R224,R211,ML2,R225,R181,m4,R29,i269,R30,i77,m4,R29,i269,R30,i65,R226,ML2,R57,ML3,R112,ML2,R18,R113,m4,R29,i270,R30,i51,R34,m4,R29,i270,R30,i46,m4,R29,i270,R30,i40,m4,R29,i269,R30,i29,m4,R29,i269,R30,i23,R227,ML3,R63,R54,R181,m4,R29,i271,R30,i26,R192,ML3,R228,R54,R181,m4,R29,i272,R30,i24,R229,ML3,R57,ML2,R36,R58,m4,R29,i273,R30,i30,ML2,R59,ML2,R199,R54,m4,R29,i273,R30,i47,m4,R29,i273,R30,i42,m4,R29,i273,R30,i24,ML3,R60,V3,R62,R230,ML2,R199,R54,m4,R29,i274,R30,i29,ML4,R61,R229,R62,R230,m4,R29,i274,R30,i42,m4,R29,i274,R30,i17,ML8,R65,R66,R227,R192,ML3,R65,R66,ML2,R67,ML2,R197,R54,m4,R29,i275,R30,i71,m4,R29,i275,R30,i63,m4,R29,i275,R30,i44,ML3,R65,R66,ML2,R67,R229,m4,R29,i275,R30,i103,m4,R29,i275,R30,i84,ML2,R231,ML3,R232,R218,R209,m4,R29,i276,R30,i44,m4,R29,i276,R30,i30,ML2,R231,ML2,R233,R218,m4,R29,i276,R30,i72,m4,R29,i276,R30,i58,m4,R29,i275,R30,i17,m4,R29,i268,R30,i15,m4,R29,i264,R30,i13,m4,R29,i262,R30,i11,m4,R29,i260,R30,i9,R16,R234,MV2,Myn1,dm2,R17,ML2,R18,R108,m4,R29,i256,R30,i28,Myn1,nm2,R17,R183,m2,R17,R58,R235,V2,R49,R184,v20,arbace.repr.go.parse9,node-caseML2,R83,s48,godump: a node of a type go/ast does not declarem4,R29,i259,R30,i15,v20,arbace.repr.go.parse6,loadedv20,arbace.repr.go.parse12,dumper-formsv15,arbace.go.check12,forms-sourcev14,arbace.go.repl6,configv11,arbace.core4,atomR92,R236,R86,R237,R238,R93,R239,R240,R241,R242,v11,arbace.core5,swap!v14,arbace.go.repl8,packagesv11,arbace.core5,assocv14,arbace.go.repl12,check-sourceR243,v11,arbace.core7,ex-infov13,arbace.string4,joinR244,R29,R245,v11,arbace.core4,takel10,v14,arbace.go.repl7,define!m2,R246,TR247,R248,v14,arbace.go.repl5,call0v11,arbace.core7,resolveR249,R250,v11,arbace.core6,reset!R251,R252,v11,arbace.core6,dissocv11,arbace.core5,applyv11,arbace.core9,array-mapv11,arbace.core6,vectorv11,arbace.core7,re-findp33,^go1\\.(0|[1-9][0-9]*)(?:$|[.a-z])v11,arbace.core10,parse-longv20,arbace.repr.go.parse7,go-langv20,arbace.repr.go.parse5,load!R253,R254,R255,R256,R257,R258,R259,v20,arbace.repr.go.parse10,strip-metav11,arbace.core4,mapvv11,arbace.core4,map?v11,arbace.core4,intoS5,R90,R260,R96,R94,R85,S5,R90,R260,R96,R94,R85,R90,v11,arbace.core8,hash-mapv11,arbace.core5,nnextv20,arbace.repr.go.parse10,decl-formsp5,\\.go$v14,arbace.go.repl12,digest-formsv20,arbace.repr.go.parse15,parser-packagesR261,v11,arbace.core6,get-inV3,R262,R237,R263,v20,arbace.repr.go.parse10,parse-filev11,arbace.core4,not=v11,arbace.core5,mergem2,R264,l2,R262,v20,arbace.repr.go.parse15,file-go-versionR263,R265,v11,arbace.core6,reducev11,arbace.core1,+R266,v11,arbace.core11,select-keysv20,arbace.repr.go.parse11,header-keysV4,R244,R263,R254,R255,R267,v11,arbace.core8,keyword?R268,v11,arbace.core8,boolean?R269,v11,arbace.core8,integer?R270,R271,R272,R273,v11,arbace.core5,classv20,arbace.repr.go.parse7,kind-ofR274,v11,arbace.core4,keysv20,arbace.repr.go.parse4,diffS2,R272,R273,v11,arbace.core4,keepv11,arbace.core8,identityv11,arbace.core11,map-indexedR275,v11,arbace.core4,subsl300,V2,R262,R261,V2,R262,R261,v19,arbace.repr.go.read9,read-dumpv20,arbace.repr.go.parse11,native-dumpR276,V2,R262,R276,R277,v20,arbace.repr.go.parse8,job-keysR278,R279,R280,v19,arbace.repr.go.read5,nodesv20,arbace.repr.go.parse7,tree-ofR281,R282,R283,v20,arbace.repr.go.parse7,file-atv20,arbace.repr.go.parse9,short-strv11,arbace.core4,spitv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core12,*print-meta*v11,arbace.core11,read-stringv11,arbace.core11,*read-eval*R284,R285,v19,arbace.repr.go.load4,jobsR286,v11,arbace.core7,filtervR287,v13,arbace.string5,splitp2,\\tv13,arbace.string11,split-linesV2,R262,R276,v20,arbace.repr.go.parse13,helper-headerR288,p3,/+$v20,arbace.repr.go.parse9,spec-jobsp6,\\.edn$v19,arbace.repr.go.read10,dump-filesv20,arbace.repr.go.parse14,helper-resultsR289,v20,arbace.repr.go.parse12,check-headerv20,arbace.repr.go.parse9,check-jobv20,arbace.repr.go.parse13,write-native!m2,R17,C29,java.util.concurrent.CallableR290,v11,arbace.core4,sortR291,R292,R293,R294,R295,R296,R297,R298,R299,R300,v11,arbace.core7,printlnv11,arbace.core6,formatm2,R17,C29,java.util.concurrent.CallableS2,s4,reads5,checkm4,R292,l1,R301,s13,tamago/gorootR302,R303,R304,R305,R301,m2,R252,l0,v20,arbace.repr.go.parse11,forms-checkv20,arbace.repr.go.parse9,read-specv20,arbace.repr.go.parse12,check-corpusv20,arbace.repr.go.parse11,read-corpusv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core3,prnR306,v11,arbace.core15,shutdown-agents")

var Lit_1 *jrt.String = jrt.Intern("arbace.repr.go.parse$_main$fn__1050000487")

var Lit_2 *jrt.String = jrt.Intern("arbace.repr.go.parse$_main$fn__1050000496")

var Lit_3 *jrt.String = jrt.Intern("arbace.repr.go.parse$_main$fn__1050000502")

var Lit_4 *jrt.String = jrt.Intern("the dumper generated from go/ast's forms and loaded with go/parser by goi in %.2f s")

var Lit_5 *jrt.String = jrt.Intern("arbace.repr.go.parse$_main$fn__1050000508")

var Lit_6 *jrt.String = jrt.Intern("arbace.repr.go.parse$_main$fn__1050000516")

var Lit_7 *jrt.String = jrt.Intern("arbace.repr.go.parse$_main$iter__1050000518__1050000522")

var Lit_8 *jrt.String = jrt.Intern("check")

var Lit_9 *jrt.String = jrt.Intern("the headers: %d corpora, %d of %d dumps' equal, %d files%s; %d not known")

var Lit_10 *jrt.String = jrt.Intern("E-tree: %d corpora, %d of %d dumps equal (header and tree), %d files, %d nodes; %d not known")

var Lit_11 *jrt.String = jrt.Intern("")

var Lit_12 *jrt.String = jrt.Intern("arbace.repr.go.parse$_main$fn__1050000528")

var Lit_13 *jrt.String = jrt.Intern("usage: check|read [--jobs N] [--forms DIR] [--known FILE] [--report FILE] [--out DIR] SPEC...")

var Lit_14 *jrt.String = jrt.Intern("--out")

var Lit_15 *jrt.String = jrt.Intern("--report")

var Lit_16 *jrt.String = jrt.Intern("--known")

var Lit_17 *jrt.String = jrt.Intern("--headers")

var Lit_18 *jrt.String = jrt.Intern("--forms")

var Lit_19 *jrt.String = jrt.Intern("--jobs")

var Lit_20 *jrt.String = jrt.Intern("%s: %d declarations, the digest's %s tamago/goroot's")

var Lit_21 *jrt.String = jrt.Intern("equal to")

var Lit_22 *jrt.String = jrt.Intern("NOT equal to")

var Lit_23 *jrt.String = jrt.Intern("arbace.repr.go.parse$_main$fn__1050000528$fn__1050000529")

var Lit_24 *jrt.String = jrt.Intern("arbace.repr.go.parse$_main$iter__1050000518__1050000522$fn__1050000523")

var Lit_25 *jrt.String = jrt.Intern("arbace.repr.go.parse$_main$iter__1050000518__1050000522$fn__1050000523$fn__1050000524")

var Lit_26 *jrt.String = jrt.Intern("ast.ae")

var Lit_27 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$iter__1050000052__1050000056")

var Lit_28 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$node_type_QMARK___1050000068")

var Lit_29 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$kind__1050000070")

var Lit_30 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$iter__1050000072__1050000076")

var Lit_31 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$iter__1050000052__1050000056$fn__1050000057")

var Lit_32 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$iter__1050000052__1050000056$fn__1050000057$fn__1050000058")

var Lit_33 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$iter__1050000072__1050000076$fn__1050000077")

var Lit_34 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$iter__1050000072__1050000076$fn__1050000077$fn__1050000078")

var Lit_35 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$iter__1050000072__1050000076$fn__1050000077$iter__1050000096__1050000100")

var Lit_36 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$iter__1050000072__1050000076$fn__1050000077$fn__1050000078$iter__1050000082__1050000086")

var Lit_37 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$iter__1050000072__1050000076$fn__1050000077$fn__1050000078$iter__1050000082__1050000086$fn__1050000087")

var Lit_38 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$iter__1050000072__1050000076$fn__1050000077$fn__1050000078$iter__1050000082__1050000086$fn__1050000087$fn__1050000088")

var Lit_39 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$iter__1050000072__1050000076$fn__1050000077$iter__1050000096__1050000100$fn__1050000101")

var Lit_40 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes$iter__1050000072__1050000076$fn__1050000077$iter__1050000096__1050000100$fn__1050000101$fn__1050000102")

var Lit_41 *jrt.String = jrt.Intern("godump: field ")

var Lit_42 *jrt.String = jrt.Intern(".")

var Lit_43 *jrt.String = jrt.Intern(" of type ")

var Lit_44 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000328__1050000332")

var Lit_45 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$fn__1050000338")

var Lit_46 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$fn__1050000344")

var Lit_47 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000346__1050000350")

var Lit_48 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$helper_failed_QMARK___1050000366")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$known_QMARK___1050000370")

var Lit_50 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$fn__1050000374")

var Lit_51 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$sum__1050000376")

var Lit_52 *jrt.String = jrt.Intern("FAIL known")

var Lit_53 *jrt.String = jrt.Intern("FAIL")

var Lit_54 *jrt.String = jrt.Intern("DIFF known")

var Lit_55 *jrt.String = jrt.Intern("DIFF")

var Lit_56 *jrt.String = jrt.Intern("MISSING known")

var Lit_57 *jrt.String = jrt.Intern("MISSING")

var Lit_58 *jrt.String = jrt.Intern("EXTRA known")

var Lit_59 *jrt.String = jrt.Intern("EXTRA")

var Lit_60 *jrt.String = jrt.Intern("dumped natively, not by the helper")

var Lit_61 *jrt.String = jrt.Intern("%s: ")

var Lit_62 *jrt.String = jrt.Intern(" (%d files, %d nodes, %.1f MB of Go); %d differ, %d failed, %d missing, %d extra (%d the helper's failures), %d rejected by both, %d excluded or failed by both, %d not known; load %.1f s, parse %.1f s, dump %.1f s (CPU), helper's dumps read %.1f s")

var Lit_63 *jrt.String = jrt.Intern("the headers: %d of %d dumps' equal")

var Lit_64 *jrt.String = jrt.Intern("E-tree %d of %d dumps equal, header and tree")

var Lit_65 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$fn__1050000396")

var Lit_66 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000398__1050000402")

var Lit_67 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000408__1050000412")

var Lit_68 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000418__1050000422")

var Lit_69 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000428__1050000432")

var Lit_70 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$fn__1050000338$fn__1050000339")

var Lit_71 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$fn__1050000338$fn__1050000339$fn__1050000340")

var Lit_72 *jrt.String = jrt.Intern("/")

var Lit_73 *jrt.String = jrt.Intern(".edn")

var Lit_74 *jrt.String = jrt.Intern("fail")

var Lit_75 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$helper_failed_QMARK___1050000366$fn__1050000367")

var Lit_76 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000328__1050000332$fn__1050000333")

var Lit_77 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000328__1050000332$fn__1050000333$fn__1050000334")

var Lit_78 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000346__1050000350$fn__1050000351")

var Lit_79 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000346__1050000350$fn__1050000351$fn__1050000352")

var Lit_80 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000346__1050000350$fn__1050000351$fn__1050000362")

var Lit_81 *jrt.String = jrt.Intern("the loader: ")

var Lit_82 *jrt.String = jrt.Intern(" ")

var Lit_83 *jrt.String = jrt.Intern("no such dump from the loader")

var Lit_84 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000346__1050000350$fn__1050000351$fn__1050000352$fn__1050000356")

var Lit_85 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000398__1050000402$fn__1050000403")

var Lit_86 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000398__1050000402$fn__1050000403$fn__1050000404")

var Lit_87 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000408__1050000412$fn__1050000413")

var Lit_88 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000408__1050000412$fn__1050000413$fn__1050000414")

var Lit_89 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000418__1050000422$fn__1050000423")

var Lit_90 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000418__1050000422$fn__1050000423$fn__1050000424")

var Lit_91 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000428__1050000432$fn__1050000433")

var Lit_92 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$iter__1050000428__1050000432$fn__1050000433$fn__1050000434")

var Lit_93 *jrt.String = jrt.Intern("not the helper's failure")

var Lit_94 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$known_QMARK___1050000370$fn__1050000371")

var Lit_95 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus$sum__1050000376$fn__1050000377")

var Lit_96 *jrt.String = jrt.Intern(": ")

var Lit_97 *jrt.String = jrt.Intern("arbace.repr.go.parse$decl_forms$iter__1050000178__1050000182")

var Lit_98 *jrt.String = jrt.Intern("arbace.repr.go.parse$decl_forms$iter__1050000178__1050000182$fn__1050000183")

var Lit_99 *jrt.String = jrt.Intern("arbace.repr.go.parse$decl_forms$iter__1050000178__1050000182$fn__1050000183$fn__1050000184")

var Lit_100 *jrt.String = jrt.Intern("arbace.repr.go.parse$diff$fn__1050000248")

var Lit_101 *jrt.String = jrt.Intern("arbace.repr.go.parse$diff$fn__1050000251")

var Lit_102 *jrt.String = jrt.Intern("arbace.repr.go.parse$diff$fn__1050000257")

var Lit_103 *jrt.String = jrt.Intern("arbace.repr.go.parse$dumper_forms$iter__1050000127__1050000131")

var Lit_104 *jrt.String = jrt.Intern("node is n as the dump's tree: (:kebab-type {:kebab-field value ...}), fields in go/ast's order, those at their zero value left out.\n")

var Lit_105 *jrt.String = jrt.Intern("arbace.repr.go.parse$dumper_forms$iter__1050000127__1050000131$fn__1050000132")

var Lit_106 *jrt.String = jrt.Intern("arbace.repr.go.parse$dumper_forms$iter__1050000127__1050000131$fn__1050000132$fn__1050000133")

var Lit_107 *jrt.String = jrt.Intern("java.io.File")

var Lit_108 *jrt.String = jrt.Intern("java.util.concurrent.Executors")

var Lit_109 *jrt.String = jrt.Intern("java.util.concurrent.TimeUnit")

var Lit_110 *jrt.String = jrt.Intern(".-")

var Lit_111 *jrt.String = jrt.Intern("arbace.repr.go.parse$field_stmts$add__1050000113")

var Lit_112 *jrt.String = jrt.Intern("x")

var Lit_113 *jrt.String = jrt.Intern("doc")

var Lit_114 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_115 *jrt.String = jrt.Intern("go1.21")

var Lit_116 *jrt.String = jrt.Intern("arbace.repr.go.parse$forms_check$iter__1050000191__1050000195")

var Lit_117 *jrt.String = jrt.Intern("arbace.repr.go.parse$forms_check$iter__1050000191__1050000195$fn__1050000196")

var Lit_118 *jrt.String = jrt.Intern("arbace.repr.go.parse$forms_check$iter__1050000191__1050000195$fn__1050000196$fn__1050000197")

var Lit_119 *jrt.String = jrt.Intern("/go/")

var Lit_120 *jrt.String = jrt.Intern(".ae")

var Lit_121 *jrt.String = jrt.Intern("arbace.repr.go.parse$forms_check$iter__1050000191__1050000195$fn__1050000196$fn__1050000203")

var Lit_122 *jrt.String = jrt.Intern("arbace.repr.go.parse$forms_check$iter__1050000191__1050000195$fn__1050000196$fn__1050000205")

var Lit_123 *jrt.String = jrt.Intern("arbace.repr.go.parse$forms_check$iter__1050000191__1050000195$fn__1050000196$fn__1050000197$fn__1050000198")

var Lit_124 *jrt.String = jrt.Intern("arbace.repr.go.parse$forms_check$iter__1050000191__1050000195$fn__1050000196$fn__1050000197$fn__1050000200")

var Lit_125 *jrt.String = jrt.Intern("go1.")

var Lit_126 *jrt.String = jrt.Intern("\n :files [")

var Lit_127 *jrt.String = jrt.Intern("}")

var Lit_128 *jrt.String = jrt.Intern("{")

var Lit_129 *jrt.String = jrt.Intern("arbace.repr.go.parse$helper_results$iter__1050000297__1050000301")

var Lit_130 *jrt.String = jrt.Intern("arbace.repr.go.parse$helper_results$iter__1050000297__1050000301$fn__1050000302")

var Lit_131 *jrt.String = jrt.Intern("arbace.repr.go.parse$helper_results$iter__1050000297__1050000301$fn__1050000302$fn__1050000303")

var Lit_132 *jrt.String = jrt.Intern("arbace.repr.go.parse$job_keys$iter__1050000265__1050000269")

var Lit_133 *jrt.String = jrt.Intern("arbace.repr.go.parse$job_keys$iter__1050000265__1050000269$fn__1050000270")

var Lit_134 *jrt.String = jrt.Intern("arbace.repr.go.parse$job_keys$iter__1050000265__1050000269$fn__1050000270$fn__1050000271")

var Lit_135 *jrt.String = jrt.Intern("-$1")

var Lit_136 *jrt.String = jrt.Intern("kw_")

var Lit_137 *jrt.String = jrt.Intern("-")

var Lit_138 *jrt.String = jrt.Intern("_")

var Lit_139 *jrt.String = jrt.Intern("/go/go/ast")

var Lit_140 *jrt.String = jrt.Intern("the dumper does not check:\n")

var Lit_141 *jrt.String = jrt.Intern("\n")

var Lit_142 *jrt.String = jrt.Intern("arbace.repr.go.parse$load_BANG_$iter__1050000140__1050000144")

var Lit_143 *jrt.String = jrt.Intern("init")

var Lit_144 *jrt.String = jrt.Intern("arbace.repr.go.parse$load_BANG_$fn__1050000154")

var Lit_145 *jrt.String = jrt.Intern("arbace.repr.go.parse$load_BANG_$fn__1050000156")

var Lit_146 *jrt.String = jrt.Intern("arbace.repr.go.parse$load_BANG_$iter__1050000140__1050000144$fn__1050000145")

var Lit_147 *jrt.String = jrt.Intern("arbace.repr.go.parse$load_BANG_$iter__1050000140__1050000144$fn__1050000145$fn__1050000146")

var Lit_148 *jrt.String = jrt.Intern(":")

var Lit_149 *jrt.String = jrt.Intern("arbace.repr.go.parse$native_dump$iter__1050000213__1050000217")

var Lit_150 *jrt.String = jrt.Intern("arbace.repr.go.parse$native_dump$fn__1050000223")

var Lit_151 *jrt.String = jrt.Intern("arbace.repr.go.parse$native_dump$fn__1050000225")

var Lit_152 *jrt.String = jrt.Intern("arbace.repr.go.parse$native_dump$iter__1050000228__1050000232")

var Lit_153 *jrt.String = jrt.Intern("arbace.repr.go.parse$native_dump$fn__1050000240")

var Lit_154 *jrt.String = jrt.Intern("arbace.repr.go.parse$native_dump$iter__1050000213__1050000217$fn__1050000218")

var Lit_155 *jrt.String = jrt.Intern("arbace.repr.go.parse$native_dump$iter__1050000213__1050000217$fn__1050000218$fn__1050000219")

var Lit_156 *jrt.String = jrt.Intern("arbace.repr.go.parse$native_dump$iter__1050000228__1050000232$fn__1050000233")

var Lit_157 *jrt.String = jrt.Intern("arbace.repr.go.parse$native_dump$iter__1050000228__1050000232$fn__1050000233$fn__1050000234")

var Lit_158 *jrt.String = jrt.Intern("arbace.repr.go.parse$node_case$fn__1050000122")

var Lit_159 *jrt.String = jrt.Intern("ast")

var Lit_160 *jrt.String = jrt.Intern("arbace.repr.go.parse$node_case$fn__1050000124")

var Lit_161 *jrt.String = jrt.Intern("arbace.repr.go.parse$read_corpus$fn__1050000449")

var Lit_162 *jrt.String = jrt.Intern("arbace.repr.go.parse$read_corpus$fn__1050000455")

var Lit_163 *jrt.String = jrt.Intern("arbace.repr.go.parse$read_corpus$sum__1050000457")

var Lit_164 *jrt.String = jrt.Intern("arbace.repr.go.parse$read_corpus$fn__1050000465")

var Lit_165 *jrt.String = jrt.Intern("REJECTED")

var Lit_166 *jrt.String = jrt.Intern("%s: %d dumps natively (%d files, %d nodes, %.1f MB of Go), %d rejected by go/parser, %d excluded, %d failed to load; load %.1f s, parse %.1f s, dump %.1f s (CPU), %.1f s")

var Lit_167 *jrt.String = jrt.Intern("arbace.repr.go.parse$read_corpus$fn__1050000471")

var Lit_168 *jrt.String = jrt.Intern("arbace.repr.go.parse$read_corpus$fn__1050000473")

var Lit_169 *jrt.String = jrt.Intern("arbace.repr.go.parse$read_corpus$fn__1050000475")

var Lit_170 *jrt.String = jrt.Intern("arbace.repr.go.parse$read_corpus$fn__1050000449$fn__1050000450")

var Lit_171 *jrt.String = jrt.Intern("arbace.repr.go.parse$read_corpus$fn__1050000449$fn__1050000450$fn__1050000451")

var Lit_172 *jrt.String = jrt.Intern("excluded")

var Lit_173 *jrt.String = jrt.Intern("arbace.repr.go.parse$read_corpus$sum__1050000457$fn__1050000458")

var Lit_174 *jrt.String = jrt.Intern("arbace.repr.go.parse$receiver_types$iter__1050000040__1050000044")

var Lit_175 *jrt.String = jrt.Intern("arbace.repr.go.parse$receiver_types$iter__1050000040__1050000044$fn__1050000045")

var Lit_176 *jrt.String = jrt.Intern("arbace.repr.go.parse$receiver_types$iter__1050000040__1050000044$fn__1050000045$fn__1050000046")

var Lit_177 *jrt.String = jrt.Intern("...")

var Lit_178 *jrt.String = jrt.Intern("arbace.repr.go.parse$spec_jobs$fn__1050000282")

var Lit_179 *jrt.String = jrt.Intern("arbace.repr.go.parse$spec_jobs$fn__1050000282$iter__1050000283__1050000287")

var Lit_180 *jrt.String = jrt.Intern("arbace.repr.go.parse$spec_jobs$fn__1050000282$iter__1050000283__1050000287$fn__1050000288")

var Lit_181 *jrt.String = jrt.Intern("arbace.repr.go.parse$spec_jobs$fn__1050000282$iter__1050000283__1050000287$fn__1050000288$fn__1050000289")

var Lit_182 *jrt.String = jrt.Intern("arbace.repr.go.parse$strip_meta$fn__1050000172")

var Lit_183 *jrt.String = jrt.Intern("arbace.repr.go.parse$tree_of$fn__1050000244")

var Lit_184 *jrt.String = jrt.Intern("arbace.repr.go.parse$type_specs$iter__1050000013__1050000019")

var Lit_185 *jrt.String = jrt.Intern("arbace.repr.go.parse$type_specs$iter__1050000013__1050000019$fn__1050000020")

var Lit_186 *jrt.String = jrt.Intern("arbace.repr.go.parse$type_specs$iter__1050000013__1050000019$fn__1050000020$iter__1050000015__1050000021")

var Lit_187 *jrt.String = jrt.Intern("arbace.repr.go.parse$type_specs$iter__1050000013__1050000019$fn__1050000020$iter__1050000027__1050000031")

var Lit_188 *jrt.String = jrt.Intern("arbace.repr.go.parse$type_specs$iter__1050000013__1050000019$fn__1050000020$iter__1050000015__1050000021$fn__1050000022")

var Lit_189 *jrt.String = jrt.Intern("arbace.repr.go.parse$type_specs$iter__1050000013__1050000019$fn__1050000020$iter__1050000015__1050000021$fn__1050000022$fn__1050000023")

var Lit_190 *jrt.String = jrt.Intern("arbace.repr.go.parse$type_specs$iter__1050000013__1050000019$fn__1050000020$iter__1050000027__1050000031$fn__1050000032")

var Lit_191 *jrt.String = jrt.Intern("arbace.repr.go.parse$type_specs$iter__1050000013__1050000019$fn__1050000020$iter__1050000027__1050000031$fn__1050000032$fn__1050000033")

var Lit_192 *jrt.String = jrt.Intern(";; repr/go's native dump (arbace.repr.go.parse): the tree of a Go package, no annotations\n")

var Lit_193 *jrt.String = jrt.Intern("arbace.repr.go.parse$write_native_BANG_$fn__1050000278")

var Lit_194 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistskn3,tagyn6,Stringkn4,linekn6,columnkn4,fileyn5,formsyn1,myn3,Objyn10,Unresolvedyn7,Importsyn5,Scopeyn8,Commentsyn1,kyn5,tnamekn4,keysyn4,nameyn3,keyyn4,kindyn6,fieldsyn1,vyn14,ast-go-versionyn4,langyn12,goroot-formsyn1,xkn6,godumpkn7,packagekn6,configkn3,dirkn8,for-testkn8,go-fileskn9,cgo-fileskn7,c-fileskn9,cxx-fileskn7,m-fileskn7,h-fileskn7,f-fileskn7,s-fileskn10,swig-fileskn14,swig-cxx-fileskn10,syso-fileskn16,ignored-go-fileskn19,ignored-other-fileskn14,embed-patternskn11,embed-fileskn13,test-go-fileskn19,test-embed-patternskn16,test-embed-fileskn8,dir-testkn13,local-importskn7,importsyn1,jyn1,dyn1,ayn1,byn4,pathyn5,writeyn1,nyn4,specyn4,poolyn3,outyn5,knownyn7,headersyn1,&yn4,argsv11,arbace.core5,in-nsMyn20,arbace.repr.go.parsem2,R0,s1693,repr/go's native reader, its tree (doc/go/GO-PARSER-SURVEY.md, GP1): Go's own go/parser, as\n  the Go forms of tamago/goroot, run by goi (interpreted, GPS1 (c), GPS4 (b)), and a dumper that\n  builds the tree of the helper's dump (doc/go/HELPER-NOTES.md, \"The tree\") directly as Arbace\n  data (GPS6 (a): format :godump 2, positions \"L:C\"), without the dump's text.\n\n  The dumper is a Go package of Go forms, generated here from go/ast's forms\n  (tamago/goroot/go/go/ast/ast.ae, GPS5 (a)): one case of a type switch per node type of go/ast,\n  its fields in go/ast's order and of the helper's kinds (positions, tokens, channel\n  directions, strings, booleans, comment groups as their first position, nodes and lists of\n  nodes; the parser's resolution, File.Imports and File.Comments not written), plus the parts\n  that are not go/ast's: the selector's and type assertion's :dot, the comment groups with :text\n  on doc groups, the directives and the :warnings, after tools/godump/dump.go. It is checked and\n  defined by goi (arbace.go.repl) once per process, under the import path\n  arbace/repr/go/godump, and imports go/parser, go/ast and go/token (interpreted from the\n  digest), strconv, strings, path/filepath, os, time and arbace (compiled).\n\n  No annotations: they are GP4's. The files and each dump's header come from the loader\n  (arbace.repr.go.load, GP2; go list's part in arbace.box.plan), not from the helper: native-dump\n  takes a loader's job (its header, directory and files) and parses its files. E-tree compares\n  the native dumps with the helper's: the headers, the trees and the sets of dumps.\n\n  bin/repr-go read --reader native ... and bin/repr-go native-check run -main here.m2,R0,s1693,repr/go's native reader, its tree (doc/go/GO-PARSER-SURVEY.md, GP1): Go's own go/parser, as\n  the Go forms of tamago/goroot, run by goi (interpreted, GPS1 (c), GPS4 (b)), and a dumper that\n  builds the tree of the helper's dump (doc/go/HELPER-NOTES.md, \"The tree\") directly as Arbace\n  data (GPS6 (a): format :godump 2, positions \"L:C\"), without the dump's text.\n\n  The dumper is a Go package of Go forms, generated here from go/ast's forms\n  (tamago/goroot/go/go/ast/ast.ae, GPS5 (a)): one case of a type switch per node type of go/ast,\n  its fields in go/ast's order and of the helper's kinds (positions, tokens, channel\n  directions, strings, booleans, comment groups as their first position, nodes and lists of\n  nodes; the parser's resolution, File.Imports and File.Comments not written), plus the parts\n  that are not go/ast's: the selector's and type assertion's :dot, the comment groups with :text\n  on doc groups, the directives and the :warnings, after tools/godump/dump.go. It is checked and\n  defined by goi (arbace.go.repl) once per process, under the import path\n  arbace/repr/go/godump, and imports go/parser, go/ast and go/token (interpreted from the\n  digest), strconv, strings, path/filepath, os, time and arbace (compiled).\n\n  No annotations: they are GP4's. The files and each dump's header come from the loader\n  (arbace.repr.go.load, GP2; go list's part in arbace.box.plan), not from the helper: native-dump\n  takes a loader's job (its header, directory and files) and parses its files. E-tree compares\n  the native dumps with the helper's: the headers, the trees and the sets of dumps.\n\n  bin/repr-go read --reader native ... and bin/repr-go native-check run -main here.R1,v20,arbace.repr.go.parse9,ast-formsm10,R2,TR3,L1,V1,Myn7,ast-dirm2,R4,R5,R6,i35,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse10,type-specsm12,R2,TR3,L1,V1,R9,R0,s59,[name type-form] of every go/type form (single or grouped).R6,i38,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse14,receiver-typesm12,R2,TR3,L1,V2,R9,R10,R0,s59,The names T of the methods named m with the receiver (* T).R6,i49,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse10,skip-fieldS5,R11,R12,R13,R14,R15,m10,R2,TR6,i59,R7,i1,R8,s23,arbace/repr/go/parse.aeR0,s143,Fields the helper does not write: the parser's resolution, File.Imports (the import specs\n  again) and File.Comments (written beside the tree).v20,arbace.repr.go.parse5,kebabm10,R3,L1,V1,Myn1,sm2,R4,R5,R0,s68,go/ast's name as the dump's keyword name: BinaryExpr is binary-expr.R6,i64,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse9,ast-nodesm10,R3,L1,V1,Myn7,ast-dirm2,R4,R5,R0,s265,go/ast's node types (structs whose pointer has the method Pos and End), in source order:\n  [{:name T :fields [{:name F :key k :kind K :tag tag} ...]} ...]; K is :pos, :token, :chan-dir,\n  :string, :bool, :comment, :node or :nodes (tools/godump/dump.go's fieldKind).R6,i69,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse6,kw-varm10,R2,TR3,L1,V1,R16,R6,i105,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse11,field-stmtsm12,R2,TR3,L1,V2,R17,m2,R18,V3,R19,R20,R21,R0,s65,The statements appending field f of node x (of type tname) to kv.R6,i107,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse9,node-casem10,R2,TR3,L1,V1,m2,R18,V2,R19,R22,R6,i134,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse10,fixed-keysV7,s3,dots4,sends4,recvs4,boths4,lists4,texts5,bytesm10,R2,TR6,i146,R7,i1,R8,s23,arbace/repr/go/parse.aeR0,s58,Keywords of the dumper beside the nodes' heads and fields.v20,arbace.repr.go.parse12,dumper-formsm10,R3,L1,V1,Myn7,ast-dirm2,R4,R5,R0,s86,The dumper's package as Go forms (one file), generated from go/ast's forms in ast-dir.R6,i150,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse11,dumper-pathm8,R2,TR6,i280,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse6,loadedv11,arbace.core4,atomm8,R2,TR6,i282,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse5,load!m10,R3,L1,V1,Myn12,goroot-formsm2,R4,R5,R0,s178,Generates the dumper from the go/ast forms of goroot-forms (tamago/goroot), checks and\n  defines it with goi (once per process) and returns {:dump-file fn :ms ms}: its load time.R6,i284,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse7,go-langm12,R2,TR3,L1,V1,R23,R0,s79,go/version.Lang of v (\"go1.21.3\" is \"go1.21\"), or nil when not a valid version.R6,i312,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse15,file-go-versionm10,R3,L1,V2,R24,R25,R0,s149,The file's language version as go/types gives it (Info.FileVersions): max(its //go:build\n  version, go1.21) when it has one, else the package's lang.R6,i318,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse10,parse-filem10,R3,L1,V2,R26,Myn4,pathm2,R4,R5,R0,s147,The native tree of the Go file at path: {:ast :comments :directives :warnings :parse-ms\n  :dump-ms}, or {:error message} when go/parser rejects it.R6,i326,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse15,parser-packagesV4,s9,go/parsers10,go/scanners6,go/asts8,go/tokenm8,R6,i339,R7,i1,R8,s23,arbace/repr/go/parse.aeR0,s81,The packages of the parser that goi interprets: go/parser and what it is made of.v20,arbace.repr.go.parse10,strip-metam10,R2,TR3,L1,V1,R27,R6,i343,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse10,decl-formsm10,R2,TR3,L1,V1,R9,R6,i349,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse11,forms-checkm10,R3,L1,V1,Myn12,goroot-formsm2,R4,R5,R0,s283,goi interprets go/parser, go/scanner, go/ast and go/token from the executable's digest (its\n  configuration's conversion, arbace.go.repl): each package's declarations there, in order and\n  metadata aside, against tamago/goroot's forms under goroot-forms. [[path n-decls equal?] ...].R6,i354,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse11,header-keysV26,R28,R29,R30,R31,R32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,m8,R6,i370,R7,i1,R8,s23,arbace/repr/go/parse.aeR0,s235,A dump's header (doc/go/GO-PARSER-SURVEY.md §5) as the loader (arbace.repr.go.load) gives it\n  and E-tree compares it: the package, configuration, directory, file lists, embedded files,\n  the directory test, local imports and :imports.v20,arbace.repr.go.parse11,native-dumpm10,R3,L1,V2,R26,R54,R0,s336,The native dump of loader job j ({:header :dir :files}): its header and its files parsed by\n  go/parser under goi and dumped, without annotations: {:godump 2 ... :name :files [{:file\n  :go-version :ast :comments}] :directives [:warnings]}, plus :times {:parse-ms :dump-ms\n  :bytes}; or {:error message :file} when a file does not parse.R6,i379,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse7,tree-ofm10,R3,L1,V1,R55,R0,s276,What E-tree compares of a dump (doc/go/GO-PARSER-SURVEY.md §5, §6): the header (header-keys),\n  the package's name, each file's name, language version, tree and comments, the directives and\n  the warnings. The annotations are the trees' metadata, which the comparison ignores.R6,i411,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse7,kind-ofm10,R2,TR3,L1,V1,R27,R6,i422,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse4,diffm10,R3,L1,V3,R56,R57,R58,R0,s206,The first difference between the data a (the helper's) and b (native), strictly: lists,\n  vectors and maps are different kinds (Arbace's = takes a list for a vector); metadata\n  ignored. nil, or [path a b].R6,i434,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse9,short-strm10,R2,TR3,L1,V1,R27,R6,i450,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse7,file-atm10,R3,L1,V2,R55,R58,R0,s52,The file a difference's path is in, from the dump d.R6,i452,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse8,job-keysm10,R2,TR3,L1,V1,R54,R6,i458,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse9,check-jobm10,R3,L1,V4,R26,R54,Myn4,pathm2,R4,R5,R59,R0,s374,E-tree for loader job j against the helper's dump at path (nil: the helper made none):\n  {:key :package :files :keys :nodes :diff [...] :times}; :fail when a file does not parse\n  natively and the helper dumped it, :rejected when neither dumps it (a file go/parser\n  rejects), :extra when only the native reader dumps it. write, when given, is called with the\n  native dump.R6,i460,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse13,write-native!m12,R2,TR3,L1,V3,R60,Myn3,outm2,R4,R5,Myn3,relm2,R4,R5,R0,s110,Writes native dump n as text the reader reads back (the helper's format, without\n  annotations), at out/<rel>.R6,i490,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse9,read-specm10,R2,TR3,L1,V1,Myn1,fm2,R4,R5,R6,i501,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse9,spec-jobsm12,R2,TR3,L1,V1,R61,R0,s86,A corpus spec's loads' jobs, each keyed under its load's :sub: [jobs results load-ms].R6,i504,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse14,helper-resultsm12,R2,TR3,L1,V1,Myn3,tsvm2,R4,R5,R0,s56,The helper's summary (godump's TSV): {key [status msg]}.R6,i514,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse13,helper-headerm10,R3,L1,V1,Myn4,pathm2,R4,R5,R0,s77,The header of the helper's dump at path (its text before :files, read alone).R6,i524,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse12,check-headerm12,R2,TR3,L1,V2,R54,Myn4,pathm2,R4,R5,R0,s85,The headers' comparison alone (--headers): job j's against the helper's dump at path.R6,i532,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse12,check-corpusm12,R2,TR3,L1,V6,R26,R61,R62,R63,R64,R65,R0,s141,E-tree over corpus spec (its :dumps the helper's), in pool: the report's entry. headers:\n  the headers and the sets of dumps alone, no parse.R6,i545,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse11,read-corpusm12,R2,TR3,L1,V4,R26,R61,R62,R63,R0,s79,The native reader over corpus spec, no comparison: native dumps under out/NAME.R6,i599,R7,i1,R8,s23,arbace/repr/go/parse.aev20,arbace.repr.go.parse5,-mainm10,R3,L1,V2,R66,R67,R0,s883,check|read [--headers] [--jobs N] [--forms DIR] [--known FILE] [--report FILE] [--out DIR] SPEC...\n\n  check: E-tree (doc/go/GO-PARSER-SURVEY.md §5, §6) of each corpus SPEC (a file read by the\n  Clojure reader: {:name :dumps DIR :tsv FILE :loads [LOAD ...]}, LOAD arbace.repr.go.load's):\n  the loader's dumps, each package's files parsed by go/parser under goi and dumped natively,\n  against the helper's dumps under :dumps (annotations ignored): the header and the tree, the\n  sets of dumps. --out writes the native dumps under DIR/NAME. Exits 1 when a dump differs,\n  fails or is missing and the known differences (a map of file key, \"$GOROOT/src/fmt/print.go\",\n  dump key or package path to the reason) do not list it.\n\n  --headers (check): the loader alone, the headers and the sets of dumps, no parse.\n\n  read: the native reader alone (no helper): the dumps under --out DIR/NAME.R6,i624,R7,i1,R8,s23,arbace/repr/go/parse.ae")

var Lit_195 *jrt.String = jrt.Intern("arbace.repr.go.parse$eval1050000004$loading__1927001464__auto____1050000005")

var Lit_196 *jrt.String = jrt.Intern("arbace.repr.go.parse$eval1050000008$fn__1050000009")

var Lit_197 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_forms")

var Lit_198 *jrt.String = jrt.Intern("arbace.repr.go.parse$type_specs")

var Lit_199 *jrt.String = jrt.Intern("arbace.repr.go.parse$receiver_types")

var Lit_200 *jrt.String = jrt.Intern("arbace.repr.go.parse$kebab")

var Lit_201 *jrt.String = jrt.Intern("arbace.repr.go.parse$ast_nodes")

var Lit_202 *jrt.String = jrt.Intern("arbace.repr.go.parse$kw_var")

var Lit_203 *jrt.String = jrt.Intern("arbace.repr.go.parse$field_stmts")

var Lit_204 *jrt.String = jrt.Intern("arbace.repr.go.parse$node_case")

var Lit_205 *jrt.String = jrt.Intern("arbace.repr.go.parse$dumper_forms")

var Lit_206 *jrt.String = jrt.Intern("arbace/repr/go/godump")

var Lit_207 *jrt.String = jrt.Intern("arbace.repr.go.parse$load_BANG_")

var Lit_208 *jrt.String = jrt.Intern("arbace.repr.go.parse$go_lang")

var Lit_209 *jrt.String = jrt.Intern("arbace.repr.go.parse$file_go_version")

var Lit_210 *jrt.String = jrt.Intern("arbace.repr.go.parse$parse_file")

var Lit_211 *jrt.String = jrt.Intern("arbace.repr.go.parse$strip_meta")

var Lit_212 *jrt.String = jrt.Intern("arbace.repr.go.parse$decl_forms")

var Lit_213 *jrt.String = jrt.Intern("arbace.repr.go.parse$forms_check")

var Lit_214 *jrt.String = jrt.Intern("arbace.repr.go.parse$native_dump")

var Lit_215 *jrt.String = jrt.Intern("arbace.repr.go.parse$tree_of")

var Lit_216 *jrt.String = jrt.Intern("arbace.repr.go.parse$kind_of")

var Lit_217 *jrt.String = jrt.Intern("arbace.repr.go.parse$diff")

var Lit_218 *jrt.String = jrt.Intern("arbace.repr.go.parse$short_str")

var Lit_219 *jrt.String = jrt.Intern("arbace.repr.go.parse$file_at")

var Lit_220 *jrt.String = jrt.Intern("arbace.repr.go.parse$job_keys")

var Lit_221 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_job")

var Lit_222 *jrt.String = jrt.Intern("arbace.repr.go.parse$write_native_BANG_")

var Lit_223 *jrt.String = jrt.Intern("arbace.repr.go.parse$read_spec")

var Lit_224 *jrt.String = jrt.Intern("arbace.repr.go.parse$spec_jobs")

var Lit_225 *jrt.String = jrt.Intern("arbace.repr.go.parse$helper_results")

var Lit_226 *jrt.String = jrt.Intern("arbace.repr.go.parse$helper_header")

var Lit_227 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_header")

var Lit_228 *jrt.String = jrt.Intern("arbace.repr.go.parse$check_corpus")

var Lit_229 *jrt.String = jrt.Intern("arbace.repr.go.parse$read_corpus")

var Lit_230 *jrt.String = jrt.Intern("arbace.repr.go.parse$_main")
