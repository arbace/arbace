//line aot_arbace_repr_go_parse.ae:1
package aot_arbace_repr_go_parse

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_go_check"
	"arbace/aot_arbace_go_repl"
	"arbace/aot_arbace_repr_go_load"
	"arbace/aot_arbace_repr_go_read"
	"arbace/aot_arbace_set"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_parse_eval1050000004_loading__1927001464__auto____1050000005_A_New() *A_arbace_repr_go_parse_eval1050000004_loading__1927001464__auto____1050000005_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_eval1050000004_loading__1927001464__auto____1050000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_parse_eval1050000004_loading__1927001464__auto____1050000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_parse_eval1050000004_loading__1927001464__auto____1050000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_parse_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_parse_A_const_1); lang.IFn_Cast(A_arbace_repr_go_parse_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_repr_go_parse_A_const_3, A_arbace_repr_go_parse_A_const_4, A_arbace_repr_go_parse_A_const_5, A_arbace_repr_go_parse_A_const_6, A_arbace_repr_go_parse_A_const_7, A_arbace_repr_go_parse_A_const_8); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_107)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_108)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_109)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_parse_eval1050000008_fn__1050000009_A_New() *A_arbace_repr_go_parse_eval1050000008_fn__1050000009_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_eval1050000008_fn__1050000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_parse_eval1050000008_fn__1050000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_parse_eval1050000008_fn__1050000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_9.GetRawRoot__O()); var tmp2 any; var root_20 any = A_arbace_repr_go_parse_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = A_arbace_repr_go_parse_A_const_11; if linked_21 == nil { tmp2 = ifn_22.Invoke_O__O(arg_23) } else { tmp2 = linked_21.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_20, arg_23) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_parse_A_const_12.GetRawRoot__O(), A_arbace_repr_go_parse_A_const_13) }

































func A_arbace_repr_go_parse_ast_forms_A_New() *A_arbace_repr_go_parse_ast_forms_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_forms_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_repr_go_parse_ast_forms_A) Ctor() {}
//line :35:1
func (t *A_arbace_repr_go_parse_ast_forms_A) Invoke_O_O__O(self, ast_dir__0 any) any {
	var root_24 any = A_arbace_repr_go_parse_A_const_14.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_go_check.A_arbace_go_check_read_string_forms_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_15.GetRawRoot__O()).Invoke_O__O(jrt.File_New_String_String(jrt.String_Cast(ast_dir__0), Lit_26)); if linked_25 == nil { return ifn_26.Invoke_O__O(arg_27) } else { return linked_25.(*aot_arbace_go_check.A_arbace_go_check_read_string_forms_A).Invoke_O_O__O(root_24, arg_27)
	} }
func A_arbace_repr_go_parse_type_specs_A_New() *A_arbace_repr_go_parse_type_specs_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_type_specs_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_repr_go_parse_type_specs_A) Ctor() {}
//line :38:1
func (t *A_arbace_repr_go_parse_type_specs_A) Invoke_O_O__O(self, forms__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_A_New(); var tmp2 *jrt.Class; var fncls__251 *jrt.Class = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_A_fn_class; if


	fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_184, false); A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_A_fn_class = fncls__251d; tmp2 = fncls__251d } else { tmp2 = fncls__251 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(forms__0) }
//line :41:1
func A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_A_New() *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_A) Ctor() {}
//line :41:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_A) Invoke_O_O__O(self, s__1050000014__1 any) any { var tmp1 any = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_A_New_O_O(s__1050000014__1, self); var tmp2 *jrt.Class; var fncls__250 *jrt.Class = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_A_fn_class; if fncls__250 == nil { var fncls__250d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_185, false); A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_A_fn_class = fncls__250d; tmp2 = fncls__250d } else { tmp2 = fncls__250 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :41:1
func A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_A{}; t.Ctor_O_O(p0, p1); return t }
//line :41:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_A) Ctor_O_O(c__s__1050000014, c__iter__1050000013 any) { t.F_s__1050000014 = c__s__1050000014; t.F_iter__1050000013 = c__iter__1050000013 }
//line :41:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_A) Invoke_O__O(self any) any { { var s__1050000014__1 any; var t_ any = t.F_s__1050000014; t.F_s__1050000014 = nil; s__1050000014__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_32 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_34 lang.IFn; if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = s__1050000014__1; if linked_33 == nil { temp__1927000414__auto____2 = ifn_34.Invoke_O__O(arg_35) } else { temp__1927000414__auto____2 = linked_33.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_32, arg_35) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var f__4 any; var root_36 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = xs__1927001018__auto____3; if linked_37 == nil { f__4 = ifn_38.Invoke_O__O(arg_39) } else { f__4 = linked_37.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_36, arg_39) }; var tmp1 any; var and__1927000168__auto____5 any; var root_40 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_42 lang.IFn
															if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = f__4; if linked_41 == nil { and__1927000168__auto____5 = ifn_42.Invoke_O__O(arg_43) } else { and__1927000168__auto____5 = linked_41.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_40, arg_43) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 any = A_arbace_repr_go_parse_A_const_19; var tmp3 any; var root_44 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = f__4; if linked_45 == nil { tmp3 = ifn_46.Invoke_O__O(arg_47) } else { tmp3 = linked_45.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_44, arg_47) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____5 }
//line :41:1
	if jrt.J2g_Truth(tmp1) { var body__5 any; var root_48 any = A_arbace_repr_go_parse_A_const_20.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_50 lang.IFn

		if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = A_arbace_repr_go_parse_A_const_21.GetRawRoot__O(); var arg_52 any; var root_53 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = f__4; if linked_54 == nil { arg_52 = ifn_55.Invoke_O__O(arg_56) } else { arg_52 = linked_54.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_53, arg_56) }; if linked_49 == nil { body__5 = ifn_50.Invoke_O_O__O(arg_51, arg_52) } else { body__5 = linked_49.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_48, arg_51, arg_52) }
//line :41:1
		var iterys__1927001035__auto____6 any; var tmp4 any = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_A_New(); var tmp5 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_186, false); A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_A_fn_class = fncls__115d; tmp5 = fncls__115d } else { tmp5 = fncls__115 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var fs__1927001036__auto____7 any; var root_116 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any; var tmp6 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____6); var tmp7 any; var tmp8 any; var root_120 any = A_arbace_repr_go_parse_A_const_31.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_122 lang.IFn


		if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any; var root_124 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = body__5; if linked_125 == nil { arg_123 = ifn_126.Invoke_O__O(arg_127) } else { arg_123 = linked_125.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_124, arg_127) }; if linked_121 == nil { tmp8 = ifn_122.Invoke_O__O(arg_123) } else { tmp8 = linked_121.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_120, arg_123) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_225 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_227 lang.IFn
			if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = body__5; if linked_226 == nil { tmp9 = ifn_227.Invoke_O__O(arg_228) } else { tmp9 = linked_226.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_225, arg_228) }
//line :44:1
			var tmp10 any = tmp9; var tmp11 any; var root_229 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_231 lang.IFn
			if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = body__5; if linked_230 == nil { tmp11 = ifn_231.Invoke_O__O(arg_232) } else { tmp11 = linked_230.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_229, arg_232) }
//line :44:1
			tmp7 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(tmp10, tmp11)) } else { var iter__1927001039__auto____7 any; var tmp12 any = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_A_New(); var tmp13 *jrt.Class
				var fncls__224 /*line :44:1*/*jrt.Class = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_A_fn_class

				if fncls__224 == nil { var fncls__224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_187, false); A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_A_fn_class = fncls__224d; tmp13 = fncls__224d } else { tmp13 = fncls__224 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); tmp7 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(body__5) }
//line :41:1
		arg_119 = tmp6.Invoke_O__O(tmp7); if linked_117 == nil { fs__1927001036__auto____7 = ifn_118.Invoke_O__O(arg_119) } else { fs__1927001036__auto____7 = linked_117.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_116, arg_119) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_233 any = A_arbace_repr_go_parse_A_const_35.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = fs__1927001036__auto____7; var arg_237 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1050000013); var tmp15 any; var root_238 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = s__1050000014__1; if linked_239 == nil { tmp15 = ifn_240.Invoke_O__O(arg_241) } else { tmp15 = linked_239.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_238, arg_241) }; arg_237 = tmp14.Invoke_O__O(tmp15); if linked_234 == nil { return ifn_235.Invoke_O_O__O(arg_236, arg_237) } else { return linked_234.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_233, arg_236, arg_237) } } else { var tmp16 any; var root_242 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_244 lang.IFn; if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = s__1050000014__1; if linked_243 == nil { tmp16 = ifn_244.Invoke_O__O(arg_245) } else { tmp16 = linked_243.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_242, arg_245) }; s__1050000014__1 = tmp16; continue L1 } } else { var tmp17 any; var root_246 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = s__1050000014__1; if linked_247 == nil { tmp17 = ifn_248.Invoke_O__O(arg_249) } else { tmp17 = linked_247.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_246, arg_249) }; s__1050000014__1 = tmp17; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :41:1
func A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_A_New() *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_A) Ctor() {}
//line :41:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_A) Invoke_O_O__O(self, s__1050000016__1 any) any { var tmp1 any = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_A_New_O_O(s__1050000016__1, self); var tmp2 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_188, false); A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_A_fn_class = fncls__114d; tmp2 = fncls__114d } else { tmp2 = fncls__114 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :41:1
func A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_A{}; t.Ctor_O_O(p0, p1); return t }
//line :41:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_A) Ctor_O_O(c__s__1050000016, c__iter__1050000015 any) { t.F_s__1050000016 = c__s__1050000016; t.F_iter__1050000015 = c__iter__1050000015 }
//line :41:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_A) Invoke_O__O(self any) any { { var s__1050000016__1 any; var t_ any = t.F_s__1050000016; t.F_s__1050000016 = nil; s__1050000016__1 = t_; for { var temp__1927000414__auto____2 any; var root_57 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = s__1050000016__1; if linked_58 == nil { temp__1927000414__auto____2 = ifn_59.Invoke_O__O(arg_60) } else { temp__1927000414__auto____2 = linked_58.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_57, arg_60) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000016__3 any = temp__1927000414__auto____2; var tmp1 any; var root_61 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = s__1050000016__3; if linked_62 == nil { tmp1 = ifn_63.Invoke_O__O(arg_64) } else { tmp1 = linked_62.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_61, arg_64) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_65 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = s__1050000016__3; if linked_66 == nil { c__1927001037__auto____4 = ifn_67.Invoke_O__O(arg_68) } else { c__1927001037__auto____4 = linked_66.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_65, arg_68) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000018__6 any; var root_69 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_70 == nil { b__1050000018__6 = ifn_71.Invoke_O__O(arg_72) } else { b__1050000018__6 = linked_70.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_69, arg_72) }; var tmp2 any = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_fn__1050000023_A_New_I_O_O(size__1927001038__auto____5, b__1050000018__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_fn__1050000023_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_189, false); A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_fn__1050000023_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_79 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any; var root_84 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = b__1050000018__6; if linked_85 == nil { arg_82 = ifn_86.Invoke_O__O(arg_87) } else { arg_82 = linked_85.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_84, arg_87) }; var arg_83 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000015); var tmp5 any; var root_88 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = s__1050000016__3; if linked_89 == nil { tmp5 = ifn_90.Invoke_O__O(arg_91) } else { tmp5 = linked_89.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_88, arg_91) }; arg_83 = tmp4.Invoke_O__O(tmp5); if linked_80 == nil { return ifn_81.Invoke_O_O__O(arg_82, arg_83) } else { return linked_80.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_79, arg_82, arg_83) } } else { var root_92 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any; var root_97 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = b__1050000018__6; if linked_98 == nil { arg_95 = ifn_99.Invoke_O__O(arg_100) } else { arg_95 = linked_98.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_97, arg_100) }; var arg_96 any; if linked_93 == nil { return ifn_94.Invoke_O_O__O(arg_95, arg_96) } else { return linked_93.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_92, arg_95, arg_96) } } } else { var spec__4 any; var root_101 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = s__1050000016__3; if linked_102 == nil { spec__4 = ifn_103.Invoke_O__O(arg_104) } else { spec__4 = linked_102.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_101, arg_104) }; var root_105 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = spec__4; var arg_109 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1050000015); var tmp7 any; var root_110 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = s__1050000016__3; if linked_111 == nil { tmp7 = ifn_112.Invoke_O__O(arg_113) } else { tmp7 = linked_111.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_110, arg_113) }; arg_109 = tmp6.Invoke_O__O(tmp7); if linked_106 == nil { return ifn_107.Invoke_O_O__O(arg_108, arg_109) } else { return linked_106.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_105, arg_108, arg_109) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :41:1
func A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_fn__1050000023_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_fn__1050000023_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_fn__1050000023_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :41:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_fn__1050000023_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1050000018, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1050000018 = c__b__1050000018; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :41:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_fn__1050000023_A) Invoke_O__O(self any) any { { var i__1050000017__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000017__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var spec__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000017__1)); var root_73 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = t.F_b__1050000018; var arg_77 any = spec__2; if linked_74 == nil { ifn_75.Invoke_O_O__O(arg_76, arg_77) } else { linked_74.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_73, arg_76, arg_77) }; i__1050000017__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000017__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_A_New() *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_A) Ctor() {}
//line :46:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_A) Invoke_O_O__O(self, s__1050000028__1 any) any { var tmp1 any = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_A_New_O_O(s__1050000028__1, self); var tmp2 *jrt.Class; var fncls__223 *jrt.Class = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_A_fn_class; if fncls__223 == nil { var fncls__223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_190, false); A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_A_fn_class = fncls__223d; tmp2 = fncls__223d } else { tmp2 = fncls__223 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :46:1
func A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_A{}; t.Ctor_O_O(p0, p1); return t }
//line :46:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_A) Ctor_O_O(c__s__1050000028, c__iter__1050000027 any) { t.F_s__1050000028 = c__s__1050000028; t.F_iter__1050000027 = c__iter__1050000027 }
//line :46:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_A) Invoke_O__O(self any) any { { var s__1050000028__1 any; var t_ any = t.F_s__1050000028; t.F_s__1050000028 = nil; s__1050000028__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_128 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = s__1050000028__1; if linked_129 == nil { temp__1927000414__auto____2 = ifn_130.Invoke_O__O(arg_131) } else { temp__1927000414__auto____2 = linked_129.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_128, arg_131) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000028__3 any = temp__1927000414__auto____2; var tmp1 any; var root_132 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = s__1050000028__3; if linked_133 == nil { tmp1 = ifn_134.Invoke_O__O(arg_135) } else { tmp1 = linked_133.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_132, arg_135) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_136 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = s__1050000028__3; if linked_137 == nil { c__1927001037__auto____4 = ifn_138.Invoke_O__O(arg_139) } else { c__1927001037__auto____4 = linked_137.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_136, arg_139) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000030__6 any; var root_140 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_141 == nil { b__1050000030__6 = ifn_142.Invoke_O__O(arg_143) } else { b__1050000030__6 = linked_141.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_140, arg_143) }; var tmp2 any = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_fn__1050000033_A_New_O_I_O(b__1050000030__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__166 *jrt.Class = A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_fn__1050000033_A_fn_class; if fncls__166 == nil { var fncls__166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_191, false); A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_fn__1050000033_A_fn_class = fncls__166d; tmp3 = fncls__166d } else { tmp3 = fncls__166 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_167 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any; var root_172 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = b__1050000030__6; if linked_173 == nil { arg_170 = ifn_174.Invoke_O__O(arg_175) } else { arg_170 = linked_173.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_172, arg_175) }; var arg_171 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000027); var tmp5 any; var root_176 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = s__1050000028__3; if linked_177 == nil { tmp5 = ifn_178.Invoke_O__O(arg_179) } else { tmp5 = linked_177.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_176, arg_179) }; arg_171 = tmp4.Invoke_O__O(tmp5); if linked_168 == nil { return ifn_169.Invoke_O_O__O(arg_170, arg_171) } else { return linked_168.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_167, arg_170, arg_171) } } else { var root_180 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any; var root_185 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = b__1050000030__6; if linked_186 == nil { arg_183 = ifn_187.Invoke_O__O(arg_188) } else { arg_183 = linked_186.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_185, arg_188) }; var arg_184 any; if linked_181 == nil { return ifn_182.Invoke_O_O__O(arg_183, arg_184) } else { return linked_181.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_180, arg_183, arg_184) } } } else { var v__4 any; var root_189 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = s__1050000028__3; if linked_190 == nil { v__4 = ifn_191.Invoke_O__O(arg_192) } else { v__4 = linked_190.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_189, arg_192) }; var tmp6 any; var root_193 any = A_arbace_repr_go_parse_A_const_32.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = v__4; if linked_194 == nil { tmp6 = ifn_195.Invoke_O__O(arg_196) } else { tmp6 = linked_194.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_193, arg_196) }; if jrt.J2g_Truth(tmp6) { var root_197 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any; var tmp7 any; var root_202 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any; var root_206 any = A_arbace_repr_go_parse_A_const_20.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = A_arbace_repr_go_parse_A_const_21.GetRawRoot__O(); var arg_210 any = v__4; if linked_207 == nil { arg_205 = ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { arg_205 = linked_207.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) }; if linked_203 == nil { tmp7 = ifn_204.Invoke_O__O(arg_205) } else { tmp7 = linked_203.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_202, arg_205) }; var tmp8 any = tmp7; var tmp9 any; var root_211 any = A_arbace_repr_go_parse_A_const_33.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = v__4; if linked_212 == nil { tmp9 = ifn_213.Invoke_O__O(arg_214) } else { tmp9 = linked_212.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_211, arg_214) }; arg_200 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); var arg_201 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1050000027); var tmp11 any; var root_215 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = s__1050000028__3; if linked_216 == nil { tmp11 = ifn_217.Invoke_O__O(arg_218) } else { tmp11 = linked_216.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_215, arg_218) }; arg_201 = tmp10.Invoke_O__O(tmp11); if linked_198 == nil { return ifn_199.Invoke_O_O__O(arg_200, arg_201) } else { return linked_198.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_197, arg_200, arg_201) } } else { var tmp12 any; var root_219 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = s__1050000028__3; if linked_220 == nil { tmp12 = ifn_221.Invoke_O__O(arg_222) } else { tmp12 = linked_220.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_219, arg_222) }; s__1050000028__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :46:1
func A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_fn__1050000033_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_fn__1050000033_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_fn__1050000033_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :46:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_fn__1050000033_A) Ctor_O_I_O(c__b__1050000030 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1050000030 = c__b__1050000030; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :46:1
func (t *A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_fn__1050000033_A) Invoke_O__O(self any) any { { var i__1050000029__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000029__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var v__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000029__1)); var tmp2 any; var root_144 any = A_arbace_repr_go_parse_A_const_32.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = v__2; if linked_145 == nil { tmp2 = ifn_146.Invoke_O__O(arg_147) } else { tmp2 = linked_145.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_144, arg_147) }; if jrt.J2g_Truth(tmp2) { var root_148 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = t.F_b__1050000030; var arg_152 any; var tmp3 any; var root_153 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any; var root_157 any = A_arbace_repr_go_parse_A_const_20.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = A_arbace_repr_go_parse_A_const_21.GetRawRoot__O(); var arg_161 any = v__2; if linked_158 == nil { arg_156 = ifn_159.Invoke_O_O__O(arg_160, arg_161) } else { arg_156 = linked_158.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_157, arg_160, arg_161) }; if linked_154 == nil { tmp3 = ifn_155.Invoke_O__O(arg_156) } else { tmp3 = linked_154.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_153, arg_156) }; var tmp4 any = tmp3; var tmp5 any; var root_162 any = A_arbace_repr_go_parse_A_const_33.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = v__2; if linked_163 == nil { tmp5 = ifn_164.Invoke_O__O(arg_165) } else { tmp5 = linked_163.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_162, arg_165) }; arg_152 = lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5); if linked_149 == nil { ifn_150.Invoke_O_O__O(arg_151, arg_152) } else { linked_149.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_148, arg_151, arg_152) }; i__1050000029__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000029__1); continue L1 } else { i__1050000029__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000029__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_go_parse_receiver_types_A_New() *A_arbace_repr_go_parse_receiver_types_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_receiver_types_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_repr_go_parse_receiver_types_A) Ctor() {}
//line :49:1
func (t *A_arbace_repr_go_parse_receiver_types_A) Invoke_O_O_O__O(self, forms__0, m__1 any) any {


	var root_252 any = A_arbace_repr_go_parse_A_const_36.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_A_New_O(m__1); var tmp2 *jrt.Class; var fncls__396 *jrt.Class = A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_A_fn_class; if fncls__396 == nil { var fncls__396d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_174, false); A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_A_fn_class = fncls__396d; tmp2 = fncls__396d } else { tmp2 = fncls__396 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_255 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(forms__0); if linked_253 == nil { return ifn_254.Invoke_O__O(arg_255) } else { return linked_253.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_252, arg_255) } }
//line :52:1
func A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_A_New_O(p0 any) *A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_A{}; t.Ctor_O(p0); return t }
//line :52:1
func (t *A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :52:1
func (t *A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_A) Invoke_O_O__O(self, s__1050000041__1 any) any { var tmp1 any = A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_A_New_O_O_O(s__1050000041__1, t.F_m, self); var tmp2 *jrt.Class; var fncls__395 *jrt.Class = A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_A_fn_class; if fncls__395 == nil { var fncls__395d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_175, false); A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_A_fn_class = fncls__395d; tmp2 = fncls__395d } else { tmp2 = fncls__395 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :52:1
func A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :52:1
func (t *A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_A) Ctor_O_O_O(c__s__1050000041, c__m, c__iter__1050000040 any) { t.F_s__1050000041 = c__s__1050000041; t.F_m = c__m; t.F_iter__1050000040 = c__iter__1050000040 }
//line :52:1
func (t *A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_A) Invoke_O__O(self any) any { { var s__1050000041__1 any; var t_ any = t.F_s__1050000041; t.F_s__1050000041 = nil; s__1050000041__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_256 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = s__1050000041__1; if linked_257 == nil { temp__1927000414__auto____2 = ifn_258.Invoke_O__O(arg_259) } else { temp__1927000414__auto____2 = linked_257.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_256, arg_259) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000041__3 any = temp__1927000414__auto____2; var tmp1 any; var root_260 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = s__1050000041__3; if linked_261 == nil { tmp1 = ifn_262.Invoke_O__O(arg_263) } else { tmp1 = linked_261.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_260, arg_263) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_264 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = s__1050000041__3; if linked_265 == nil { c__1927001037__auto____4 = ifn_266.Invoke_O__O(arg_267) } else { c__1927001037__auto____4 = linked_265.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_264, arg_267) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000043__6 any; var root_268 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_269 == nil { b__1050000043__6 = ifn_270.Invoke_O__O(arg_271) } else { b__1050000043__6 = linked_269.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_268, arg_271) }; var tmp2 any = A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_fn__1050000046_A_New_O_O_I_O(t.F_m, b__1050000043__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__314 *jrt.Class = A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_fn__1050000046_A_fn_class; if fncls__314 == nil { var fncls__314d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_176, false); A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_fn__1050000046_A_fn_class = fncls__314d; tmp3 = fncls__314d } else { tmp3 = fncls__314 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_315 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any; var root_320 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = b__1050000043__6; if linked_321 == nil { arg_318 = ifn_322.Invoke_O__O(arg_323) } else { arg_318 = linked_321.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_320, arg_323) }; var arg_319 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000040); var tmp5 any; var root_324 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = s__1050000041__3; if linked_325 == nil { tmp5 = ifn_326.Invoke_O__O(arg_327) } else { tmp5 = linked_325.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_324, arg_327) }; arg_319 = tmp4.Invoke_O__O(tmp5); if linked_316 == nil { return ifn_317.Invoke_O_O__O(arg_318, arg_319) } else { return linked_316.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_315, arg_318, arg_319) } } else { var root_328 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any; var root_333 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = b__1050000043__6; if linked_334 == nil { arg_331 = ifn_335.Invoke_O__O(arg_336) } else { arg_331 = linked_334.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_333, arg_336) }; var arg_332 any; if linked_329 == nil { return ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { return linked_329.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_328, arg_331, arg_332) } } } else { var f__4 any; var root_337 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = s__1050000041__3; if linked_338 == nil { f__4 = ifn_339.Invoke_O__O(arg_340) } else { f__4 = linked_338.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_337, arg_340) }; var tmp6 any; var and__1927000168__auto____5 any; var root_341 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_343 lang.IFn
															if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = f__4; if linked_342 == nil { and__1927000168__auto____5 = ifn_343.Invoke_O__O(arg_344) } else { and__1927000168__auto____5 = linked_342.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_341, arg_344) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 bool; var tmp7 any = A_arbace_repr_go_parse_A_const_37; var tmp8 any; var root_345 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = f__4; if linked_346 == nil { tmp8 = ifn_347.Invoke_O__O(arg_348) } else { tmp8 = linked_346.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_345, arg_348) }; and__1927000168__auto____6 = lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8); if and__1927000168__auto____6 { var tmp9 any = t.F_m; var tmp10 any; var root_349 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = f__4; if linked_350 == nil { tmp10 = ifn_351.Invoke_O__O(arg_352) } else { tmp10 = linked_350.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_349, arg_352) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp9, tmp10)).Ref() } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp6 = and__1927000168__auto____5 }
//line :52:1
	if jrt.J2g_Truth(tmp6) { var params__5 any; var root_353 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_355 lang.IFn

		if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any; var root_357 any = A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = A_arbace_repr_go_parse_A_const_32.GetRawRoot__O(); var arg_361 any = f__4; if linked_358 == nil { arg_356 = ifn_359.Invoke_O_O__O(arg_360, arg_361) } else { arg_356 = linked_358.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_357, arg_360, arg_361) }; if linked_354 == nil { params__5 = ifn_355.Invoke_O__O(arg_356) } else { params__5 = linked_354.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_353, arg_356) }
//line :52:1
		var tag__6 any; var tmp11 *lang.Keyword = A_arbace_repr_go_parse_A_const_39; var tmp12 any; var root_362 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_364 lang.IFn


		if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = params__5; if linked_363 == nil { tmp12 = ifn_364.Invoke_O__O(arg_365) } else { tmp12 = linked_363.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_362, arg_365) }; tag__6 = tmp11.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp12))
//line :52:1
		var tmp13 any; var and__1927000168__auto____7 any; var root_366 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_368 lang.IFn



		if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = tag__6; if linked_367 == nil { and__1927000168__auto____7 = ifn_368.Invoke_O__O(arg_369) } else { and__1927000168__auto____7 = linked_367.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_366, arg_369) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp14 any = A_arbace_repr_go_parse_A_const_40; var tmp15 any; var root_370 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = tag__6; if linked_371 == nil { tmp15 = ifn_372.Invoke_O__O(arg_373) } else { tmp15 = linked_371.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_370, arg_373) }; tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp14, tmp15)).Ref() } else { tmp13 = and__1927000168__auto____7 }
//line :52:1
		if jrt.J2g_Truth(tmp13) { var root_374 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any; var root_379 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_381 lang.IFn




			if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = tag__6; if linked_380 == nil { arg_377 = ifn_381.Invoke_O__O(arg_382) } else { arg_377 = linked_380.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_379, arg_382) }
//line :52:1
			var arg_378 any; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__1050000040); var tmp17 any; var root_383 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = s__1050000041__3; if linked_384 == nil { tmp17 = ifn_385.Invoke_O__O(arg_386) } else { tmp17 = linked_384.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_383, arg_386) }; arg_378 = tmp16.Invoke_O__O(tmp17); if linked_375 == nil { return ifn_376.Invoke_O_O__O(arg_377, arg_378) } else { return linked_375.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_374, arg_377, arg_378) } } else { var tmp18 any; var root_387 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = s__1050000041__3; if linked_388 == nil { tmp18 = ifn_389.Invoke_O__O(arg_390) } else { tmp18 = linked_388.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_387, arg_390) }; s__1050000041__1 = tmp18; continue L1 } } else { var tmp19 any; var root_391 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = s__1050000041__3; if linked_392 == nil { tmp19 = ifn_393.Invoke_O__O(arg_394) } else { tmp19 = linked_392.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_391, arg_394) }; s__1050000041__1 = tmp19; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :52:1
func A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_fn__1050000046_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_fn__1050000046_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_fn__1050000046_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :52:1
func (t *A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_fn__1050000046_A) Ctor_O_O_I_O(c__m, c__b__1050000043 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_m = c__m; t.F_b__1050000043 = c__b__1050000043; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :52:1
func (t *A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_fn__1050000046_A) Invoke_O__O(self any) any { { var i__1050000042__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000042__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000042__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_272 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_274 lang.IFn
																	if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = f__2; if linked_273 == nil { and__1927000168__auto____3 = ifn_274.Invoke_O__O(arg_275) } else { and__1927000168__auto____3 = linked_273.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_272, arg_275) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool; var tmp3 any = A_arbace_repr_go_parse_A_const_37; var tmp4 any; var root_276 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = f__2; if linked_277 == nil { tmp4 = ifn_278.Invoke_O__O(arg_279) } else { tmp4 = linked_277.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_276, arg_279) }; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4); if and__1927000168__auto____4 { var tmp5 any = t.F_m; var tmp6 any; var root_280 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = f__2; if linked_281 == nil { tmp6 = ifn_282.Invoke_O__O(arg_283) } else { tmp6 = linked_281.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_280, arg_283) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp5, tmp6)).Ref() } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp2 = and__1927000168__auto____3 }
//line :52:1
	if jrt.J2g_Truth(tmp2) { var params__3 any; var root_284 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_286 lang.IFn

		if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any; var root_288 any = A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = A_arbace_repr_go_parse_A_const_32.GetRawRoot__O(); var arg_292 any = f__2; if linked_289 == nil { arg_287 = ifn_290.Invoke_O_O__O(arg_291, arg_292) } else { arg_287 = linked_289.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_288, arg_291, arg_292) }; if linked_285 == nil { params__3 = ifn_286.Invoke_O__O(arg_287) } else { params__3 = linked_285.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_284, arg_287) }
//line :52:1
		var tag__4 any; var tmp7 *lang.Keyword = A_arbace_repr_go_parse_A_const_39; var tmp8 any; var root_293 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_295 lang.IFn


		if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = params__3; if linked_294 == nil { tmp8 = ifn_295.Invoke_O__O(arg_296) } else { tmp8 = linked_294.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_293, arg_296) }; tag__4 = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp8))
//line :52:1
		var tmp9 any; var and__1927000168__auto____5 any; var root_297 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_299 lang.IFn



		if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = tag__4; if linked_298 == nil { and__1927000168__auto____5 = ifn_299.Invoke_O__O(arg_300) } else { and__1927000168__auto____5 = linked_298.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_297, arg_300) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp10 any = A_arbace_repr_go_parse_A_const_40; var tmp11 any; var root_301 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = tag__4; if linked_302 == nil { tmp11 = ifn_303.Invoke_O__O(arg_304) } else { tmp11 = linked_302.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_301, arg_304) }; tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp10, tmp11)).Ref() } else { tmp9 = and__1927000168__auto____5 }
//line :52:1
		if jrt.J2g_Truth(tmp9) { var root_305 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = t.F_b__1050000043; var arg_309 any; var root_310 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_312 lang.IFn




			if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = tag__4; if linked_311 == nil { arg_309 = ifn_312.Invoke_O__O(arg_313) } else { arg_309 = linked_311.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_310, arg_313) }
//line :52:1
			if linked_306 == nil { ifn_307.Invoke_O_O__O(arg_308, arg_309) } else { linked_306.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_305, arg_308, arg_309) }; i__1050000042__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000042__1); continue L1 } else { i__1050000042__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000042__1); continue L1 } } else { i__1050000042__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000042__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_repr_go_parse_kebab_A_New() *A_arbace_repr_go_parse_kebab_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_kebab_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_repr_go_parse_kebab_A) Ctor() {}
//line :64:1
func (t *A_arbace_repr_go_parse_kebab_A) Invoke_O_O__O(self, s__0 any) any {


	var root_397 any = A_arbace_repr_go_parse_A_const_41.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any; var root_401 any = A_arbace_repr_go_parse_A_const_42.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = s__0; var arg_405 any = A_arbace_repr_go_parse_A_const_43; var arg_406 any = Lit_135; if linked_402 == nil { arg_400 = ifn_403.Invoke_O_O_O__O(arg_404, arg_405, arg_406) } else { arg_400 = linked_402.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_401, arg_404, arg_405, arg_406) }; if linked_398 == nil { return ifn_399.Invoke_O__O(arg_400) } else { return linked_398.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_397, arg_400)
	} }
func A_arbace_repr_go_parse_ast_nodes_A_New() *A_arbace_repr_go_parse_ast_nodes_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_repr_go_parse_ast_nodes_A) Ctor() {}
//line :69:1
func (t *A_arbace_repr_go_parse_ast_nodes_A) Invoke_O_O__O(self, ast_dir__0 any) any { var forms__2 any; var root_407 any = A_arbace_repr_go_parse_A_const_44.GetRawRoot__O(); var linked_408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_407, A_arbace_repr_go_parse_ast_forms_A_fn_class); var ifn_409 lang.IFn; if




	linked_408 == nil { ifn_409 = lang.IFn_Cast(root_407) } else { ifn_409 = nil }; var arg_410 any = ast_dir__0; if linked_408 == nil { forms__2 = ifn_409.Invoke_O__O(arg_410) } else { forms__2 = linked_408.(*A_arbace_repr_go_parse_ast_forms_A).Invoke_O_O__O(root_407, arg_410) }; var specs__3 any; var root_411 any = /*line :69:1*/A_arbace_repr_go_parse_A_const_45.GetRawRoot__O(); var linked_412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_411, A_arbace_repr_go_parse_type_specs_A_fn_class); var ifn_413 lang.IFn; if





	linked_412 == nil { ifn_413 = lang.IFn_Cast(root_411) } else { ifn_413 = nil }; var arg_414 any = forms__2; if linked_412 == nil { specs__3 = ifn_413.Invoke_O__O(arg_414) } else { specs__3 = linked_412.(*A_arbace_repr_go_parse_type_specs_A).Invoke_O_O__O(root_411, arg_414) }; var nodes__4 any; var root_415 any = /*line :69:1*/A_arbace_repr_go_parse_A_const_46.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_415, aot_arbace_set.A_arbace_set_intersection_A_fn_class); var ifn_417 lang.IFn; if






	linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any; var root_420 any = A_arbace_repr_go_parse_A_const_47.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, A_arbace_repr_go_parse_receiver_types_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = forms__2; var arg_424 any = A_arbace_repr_go_parse_A_const_48; if linked_421 == nil { arg_418 = ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { arg_418 = linked_421.(*A_arbace_repr_go_parse_receiver_types_A).Invoke_O_O_O__O(root_420, arg_423, arg_424) }; var arg_419 any; var root_425 any = A_arbace_repr_go_parse_A_const_47.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, A_arbace_repr_go_parse_receiver_types_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = forms__2; var arg_429 any = A_arbace_repr_go_parse_A_const_49; if linked_426 == nil { arg_419 = ifn_427.Invoke_O_O__O(arg_428, arg_429) } else { arg_419 = linked_426.(*A_arbace_repr_go_parse_receiver_types_A).Invoke_O_O_O__O(root_425, arg_428, arg_429) }; if linked_416 == nil { nodes__4 = ifn_417.Invoke_O_O__O(arg_418, arg_419) } else { nodes__4 = linked_416.(*aot_arbace_set.A_arbace_set_intersection_A).Invoke_O_O_O__O(root_415, arg_418, arg_419) }; var ifaces__5 any; var root_430 any = /*line :69:1*/A_arbace_repr_go_parse_A_const_36.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_432 lang.IFn; if







	linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_A_New(); var tmp2 *jrt.Class; var fncls__512 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_A_fn_class; if fncls__512 == nil { var fncls__512d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_A_fn_class = fncls__512d; tmp2 = fncls__512d } else { tmp2 = fncls__512 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_433 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(specs__3); if linked_431 == nil { ifaces__5 = ifn_432.Invoke_O__O(arg_433) } else { ifaces__5 = linked_431.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_430, arg_433) }; var node_type_QMARK___6 any; var tmp3 any = /*line :69:1*/A_arbace_repr_go_parse_ast_nodes_node_type_QMARK___1050000068_A_New_O_O(ifaces__5, nodes__4); var tmp4 *jrt.Class; var fncls__535 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_node_type_QMARK___1050000068_A_fn_class; if








	fncls__535 == nil { var fncls__535d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_repr_go_parse_ast_nodes_node_type_QMARK___1050000068_A_fn_class = fncls__535d; tmp4 = fncls__535d } else { tmp4 = fncls__535 }; node_type_QMARK___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var kind__7 any; var tmp5 any = /*line :69:1*/A_arbace_repr_go_parse_ast_nodes_kind__1050000070_A_New_O(node_type_QMARK___6); var tmp6 *jrt.Class; var fncls__552 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_kind__1050000070_A_fn_class; if










	fncls__552 == nil { var fncls__552d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_repr_go_parse_ast_nodes_kind__1050000070_A_fn_class = fncls__552d; tmp6 = fncls__552d } else { tmp6 = fncls__552 }; kind__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var root_553 any =












	A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any; var iter__1927001039__auto____8 any; var tmp7 any = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_A_New_O_O(kind__7, nodes__4); var tmp8 *jrt.Class; var fncls__903 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_A_fn_class; if fncls__903 == nil { var fncls__903d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_A_fn_class = fncls__903d; tmp8 = fncls__903d } else { tmp8 = fncls__903 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); arg_556 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(specs__3); if linked_554 == nil { return ifn_555.Invoke_O__O(arg_556) } else { return linked_554.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_553, arg_556) } }
//line :77:1
func A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_A_New() *A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_A) Ctor() {}
//line :77:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_A) Invoke_O_O__O(self, s__1050000053__1 any) any { var tmp1 any = A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_A_New_O_O(s__1050000053__1, self); var tmp2 *jrt.Class; var fncls__511 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_A_fn_class; if fncls__511 == nil { var fncls__511d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_A_fn_class = fncls__511d; tmp2 = fncls__511d } else { tmp2 = fncls__511 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :77:1
func A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :77:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_A) Ctor_O_O(c__s__1050000053, c__iter__1050000052 any) { t.F_s__1050000053 = c__s__1050000053; t.F_iter__1050000052 = c__iter__1050000052 }
//line :77:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_A) Invoke_O__O(self any) any { { var s__1050000053__1 any; var t_ any = t.F_s__1050000053; t.F_s__1050000053 = nil; s__1050000053__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_434 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_436 lang.IFn; if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = s__1050000053__1; if linked_435 == nil { temp__1927000414__auto____2 = ifn_436.Invoke_O__O(arg_437) } else { temp__1927000414__auto____2 = linked_435.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_434, arg_437) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000053__3 any = temp__1927000414__auto____2; var tmp1 any; var root_438 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_440 lang.IFn; if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = s__1050000053__3; if linked_439 == nil { tmp1 = ifn_440.Invoke_O__O(arg_441) } else { tmp1 = linked_439.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_438, arg_441) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_442 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = s__1050000053__3; if linked_443 == nil { c__1927001037__auto____4 = ifn_444.Invoke_O__O(arg_445) } else { c__1927001037__auto____4 = linked_443.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_442, arg_445) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000055__6 any; var root_446 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_448 lang.IFn; if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_447 == nil { b__1050000055__6 = ifn_448.Invoke_O__O(arg_449) } else { b__1050000055__6 = linked_447.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_446, arg_449) }; var tmp2 any = A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_fn__1050000058_A_New_O_I_O(b__1050000055__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__463 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_fn__1050000058_A_fn_class; if fncls__463 == nil { var fncls__463d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_fn__1050000058_A_fn_class = fncls__463d; tmp3 = fncls__463d } else { tmp3 = fncls__463 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_464 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_466 lang.IFn; if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any; var root_469 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = b__1050000055__6; if linked_470 == nil { arg_467 = ifn_471.Invoke_O__O(arg_472) } else { arg_467 = linked_470.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_469, arg_472) }; var arg_468 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000052); var tmp5 any; var root_473 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_475 lang.IFn; if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = s__1050000053__3; if linked_474 == nil { tmp5 = ifn_475.Invoke_O__O(arg_476) } else { tmp5 = linked_474.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_473, arg_476) }; arg_468 = tmp4.Invoke_O__O(tmp5); if linked_465 == nil { return ifn_466.Invoke_O_O__O(arg_467, arg_468) } else { return linked_465.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_464, arg_467, arg_468) } } else { var root_477 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_479 lang.IFn; if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any; var root_482 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = b__1050000055__6; if linked_483 == nil { arg_480 = ifn_484.Invoke_O__O(arg_485) } else { arg_480 = linked_483.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_482, arg_485) }; var arg_481 any; if linked_478 == nil { return ifn_479.Invoke_O_O__O(arg_480, arg_481) } else { return linked_478.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_477, arg_480, arg_481) } } } else { var vec__1050000063__4 any; var root_486 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any = s__1050000053__3; if linked_487 == nil { vec__1050000063__4 = ifn_488.Invoke_O__O(arg_489) } else { vec__1050000063__4 = linked_487.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_486, arg_489) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000063__4, lang.RT_IntCast_J__I_NoInit(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000063__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var and__1927000168__auto____7 any; var root_490 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = t__6; if linked_491 == nil { and__1927000168__auto____7 = ifn_492.Invoke_O__O(arg_493) } else { and__1927000168__auto____7 = linked_491.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_490, arg_493) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp7 any = A_arbace_repr_go_parse_A_const_50; var tmp8 any; var root_494 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any = t__6; if linked_495 == nil { tmp8 = ifn_496.Invoke_O__O(arg_497) } else { tmp8 = linked_495.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_494, arg_497) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8)).Ref() } else { tmp6 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp6) { var root_498 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_500 lang.IFn; if linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = n__5; var arg_502 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1050000052); var tmp10 any; var root_503 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = s__1050000053__3; if linked_504 == nil { tmp10 = ifn_505.Invoke_O__O(arg_506) } else { tmp10 = linked_504.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_503, arg_506) }; arg_502 = tmp9.Invoke_O__O(tmp10); if linked_499 == nil { return ifn_500.Invoke_O_O__O(arg_501, arg_502) } else { return linked_499.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_498, arg_501, arg_502) } } else { var tmp11 any; var root_507 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = s__1050000053__3; if linked_508 == nil { tmp11 = ifn_509.Invoke_O__O(arg_510) } else { tmp11 = linked_508.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_507, arg_510) }; s__1050000053__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :77:1
func A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_fn__1050000058_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_fn__1050000058_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_fn__1050000058_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :77:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_fn__1050000058_A) Ctor_O_I_O(c__b__1050000055 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1050000055 = c__b__1050000055; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :77:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_fn__1050000058_A) Invoke_O__O(self any) any { { var i__1050000054__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000054__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1050000059__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000054__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000059__2, lang.RT_IntCast_J__I_NoInit(0), nil); var t__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000059__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var and__1927000168__auto____5 any; var root_450 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = t__4; if linked_451 == nil { and__1927000168__auto____5 = ifn_452.Invoke_O__O(arg_453) } else { and__1927000168__auto____5 = linked_451.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_450, arg_453) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp3 any = A_arbace_repr_go_parse_A_const_50; var tmp4 any; var root_454 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = t__4; if linked_455 == nil { tmp4 = ifn_456.Invoke_O__O(arg_457) } else { tmp4 = linked_455.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_454, arg_457) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp2) { var root_458 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = t.F_b__1050000055; var arg_462 any = n__3; if linked_459 == nil { ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { linked_459.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_458, arg_461, arg_462) }; i__1050000054__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000054__1); continue L1 } else { i__1050000054__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000054__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_go_parse_ast_nodes_node_type_QMARK___1050000068_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_ast_nodes_node_type_QMARK___1050000068_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_node_type_QMARK___1050000068_A{}; t.Ctor_O_O(p0, p1); return t }
//line :78:1
func (t *A_arbace_repr_go_parse_ast_nodes_node_type_QMARK___1050000068_A) Ctor_O_O(c__ifaces, c__nodes any) { t.F_ifaces = c__ifaces; t.F_nodes = c__nodes }
//line :78:1
func (t *A_arbace_repr_go_parse_ast_nodes_node_type_QMARK___1050000068_A) Invoke_O_O__O(self, t__1 any) any { var or__1927000174__auto____2 any; var root_513 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = t.F_ifaces; var arg_517 any = t__1; if linked_514 == nil { or__1927000174__auto____2 = ifn_515.Invoke_O_O__O(arg_516, arg_517) } else { or__1927000174__auto____2 = linked_514.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_513, arg_516, arg_517) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var and__1927000168__auto____3 any; var root_518 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_520 lang.IFn
														if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = t__1; if linked_519 == nil { and__1927000168__auto____3 = ifn_520.Invoke_O__O(arg_521) } else { and__1927000168__auto____3 = linked_519.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_518, arg_521) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool; var tmp1 any = A_arbace_repr_go_parse_A_const_52; var tmp2 any; var root_522 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = t__1; if linked_523 == nil { tmp2 = ifn_524.Invoke_O__O(arg_525) } else { tmp2 = linked_523.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_522, arg_525) }; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2); if and__1927000168__auto____4 { var root_526 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = t.F_nodes; var arg_530 any; var root_531 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = t__1; if linked_532 == nil { arg_530 = ifn_533.Invoke_O__O(arg_534) } else { arg_530 = linked_532.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_531, arg_534) }; if linked_527 == nil { return ifn_528.Invoke_O_O__O(arg_529, arg_530) } else { return linked_527.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_526, arg_529, arg_530) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } } }
func A_arbace_repr_go_parse_ast_nodes_kind__1050000070_A_New_O(p0 any) *A_arbace_repr_go_parse_ast_nodes_kind__1050000070_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_kind__1050000070_A{}; t.Ctor_O(p0); return t }
//line :80:1
func (t *A_arbace_repr_go_parse_ast_nodes_kind__1050000070_A) Ctor_O(c__node_type_QMARK_ any) { t.F_node_type_QMARK_ = c__node_type_QMARK_ }
//line :80:1
func (t *A_arbace_repr_go_parse_ast_nodes_kind__1050000070_A) Invoke_O_O_O_O__O(self, tname__1, fname__2, t__3 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(t__3, A_arbace_repr_go_parse_A_const_53) { return A_arbace_repr_go_parse_A_const_54 } else { if lang.Util_Equiv_O_O__Z_NoInit(t__3, A_arbace_repr_go_parse_A_const_55) { return A_arbace_repr_go_parse_A_const_56 } else { if lang.Util_Equiv_O_O__Z_NoInit(t__3, A_arbace_repr_go_parse_A_const_57) { return A_arbace_repr_go_parse_A_const_58 } else { if lang.Util_Equiv_O_O__Z_NoInit(t__3, A_arbace_repr_go_parse_A_const_59) { return A_arbace_repr_go_parse_A_const_60 } else { if lang.Util_Equiv_O_O__Z_NoInit(t__3, A_arbace_repr_go_parse_A_const_61) { return A_arbace_repr_go_parse_A_const_62 } else { if lang.Util_Equiv_O_O__Z_NoInit(t__3, A_arbace_repr_go_parse_A_const_63) { return A_arbace_repr_go_parse_A_const_64 } else { var tmp1 any; var and__1927000168__auto____4 any; var root_536 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_538 lang.IFn






		if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = t__3; if linked_537 == nil { and__1927000168__auto____4 = ifn_538.Invoke_O__O(arg_539) } else { and__1927000168__auto____4 = linked_537.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_536, arg_539) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 bool; var tmp2 any = A_arbace_repr_go_parse_A_const_65; var tmp3 any; var root_540 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_542 lang.IFn; if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = t__3; if linked_541 == nil { tmp3 = ifn_542.Invoke_O__O(arg_543) } else { tmp3 = linked_541.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_540, arg_543) }; and__1927000168__auto____5 = lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3); if and__1927000168__auto____5 { var tmp4 lang.IFn = lang.IFn_Cast(t.F_node_type_QMARK_); var tmp5 any; var root_544 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = t__3; if linked_545 == nil { tmp5 = ifn_546.Invoke_O__O(arg_547) } else { tmp5 = linked_545.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_544, arg_547) }; tmp1 = tmp4.Invoke_O__O(tmp5) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() } } else { tmp1 = and__1927000168__auto____4 }
//line :81:1
		if jrt.J2g_Truth(tmp1) { return A_arbace_repr_go_parse_A_const_66 } else { if jrt.J2g_Truth(lang.IFn_Cast(t.F_node_type_QMARK_).Invoke_O__O(t__3)) { return A_arbace_repr_go_parse_A_const_67 } else { if A_arbace_repr_go_parse_A_const_68 != nil { var tmp6 any = A_arbace_repr_go_parse_A_const_69; return lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil, Lit_42, nil, Lit_43, nil), jrt.RefArrayOf(jrt.Object_class, nil, tname__1, nil, fname__2, nil, lang.IFn_Cast(A_arbace_repr_go_parse_A_const_70.GetRawRoot__O()).Invoke_O__O(t__3))).Ref()) } else { return nil
		}
		}
		}
	}
	}
	}
	}
	}
	}
}

func A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :93:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_A) Ctor_O_O(c__kind, c__nodes any) { t.F_kind = c__kind; t.F_nodes = c__nodes }
//line :93:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_A) Invoke_O_O__O(self, s__1050000073__1 any) any { var tmp1 any = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_A_New_O_O_O_O(s__1050000073__1, t.F_kind, t.F_nodes, self); var tmp2 *jrt.Class; var fncls__902 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_A_fn_class; if fncls__902 == nil { var fncls__902d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_A_fn_class = fncls__902d; tmp2 = fncls__902d } else { tmp2 = fncls__902 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :93:1
func A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :93:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_A) Ctor_O_O_O_O(c__s__1050000073, c__kind, c__nodes, c__iter__1050000072 any) { t.F_s__1050000073 = c__s__1050000073; t.F_kind = c__kind; t.F_nodes = c__nodes; t.F_iter__1050000072 = c__iter__1050000072 }
//line :93:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_A) Invoke_O__O(self any) any { { var s__1050000073__1 any; var t_ any = t.F_s__1050000073; t.F_s__1050000073 = nil; s__1050000073__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_557 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = s__1050000073__1; if linked_558 == nil { temp__1927000414__auto____2 = ifn_559.Invoke_O__O(arg_560) } else { temp__1927000414__auto____2 = linked_558.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_557, arg_560) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000073__3 any = temp__1927000414__auto____2; var tmp1 any; var root_561 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = s__1050000073__3; if linked_562 == nil { tmp1 = ifn_563.Invoke_O__O(arg_564) } else { tmp1 = linked_562.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_561, arg_564) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_565 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = s__1050000073__3; if linked_566 == nil { c__1927001037__auto____4 = ifn_567.Invoke_O__O(arg_568) } else { c__1927001037__auto____4 = linked_566.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_565, arg_568) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000075__6 any; var root_569 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_570 == nil { b__1050000075__6 = ifn_571.Invoke_O__O(arg_572) } else { b__1050000075__6 = linked_570.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_569, arg_572) }; var tmp2 any = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_A_New_O_O_O_I_O(t.F_kind, t.F_nodes, b__1050000075__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__720 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_A_fn_class; if fncls__720 == nil { var fncls__720d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_A_fn_class = fncls__720d; tmp3 = fncls__720d } else { tmp3 = fncls__720 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_721 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any; var root_726 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = b__1050000075__6; if linked_727 == nil { arg_724 = ifn_728.Invoke_O__O(arg_729) } else { arg_724 = linked_727.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_726, arg_729) }; var arg_725 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000072); var tmp5 any; var root_730 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_732 lang.IFn; if linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any = s__1050000073__3; if linked_731 == nil { tmp5 = ifn_732.Invoke_O__O(arg_733) } else { tmp5 = linked_731.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_730, arg_733) }; arg_725 = tmp4.Invoke_O__O(tmp5); if linked_722 == nil { return ifn_723.Invoke_O_O__O(arg_724, arg_725) } else { return linked_722.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_721, arg_724, arg_725) } } else { var root_734 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any; var root_739 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = b__1050000075__6; if linked_740 == nil { arg_737 = ifn_741.Invoke_O__O(arg_742) } else { arg_737 = linked_740.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_739, arg_742) }; var arg_738 any; if linked_735 == nil { return ifn_736.Invoke_O_O__O(arg_737, arg_738) } else { return linked_735.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_734, arg_737, arg_738) } } } else { var vec__1050000093__4 any; var root_743 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = s__1050000073__3; if linked_744 == nil { vec__1050000093__4 = ifn_745.Invoke_O__O(arg_746) } else { vec__1050000093__4 = linked_744.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_743, arg_746) }; var n__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000093__4, lang.RT_IntCast_J__I_NoInit(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000093__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var and__1927000168__auto____7 any; var root_747 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_749 lang.IFn
															if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = t.F_nodes; var arg_751 any = n__5; if linked_748 == nil { and__1927000168__auto____7 = ifn_749.Invoke_O_O__O(arg_750, arg_751) } else { and__1927000168__auto____7 = linked_748.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_747, arg_750, arg_751) }; if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var root_752 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_754 lang.IFn; if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = t__6; if linked_753 == nil { and__1927000168__auto____8 = ifn_754.Invoke_O__O(arg_755) } else { and__1927000168__auto____8 = linked_753.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_752, arg_755) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp7 any = A_arbace_repr_go_parse_A_const_72; var tmp8 any; var root_756 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_758 lang.IFn; if linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = t__6; if linked_757 == nil { tmp8 = ifn_758.Invoke_O__O(arg_759) } else { tmp8 = linked_757.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_756, arg_759) }; tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp7, tmp8)).Ref() } else { tmp6 = and__1927000168__auto____8 } } else { tmp6 = and__1927000168__auto____7 }
//line :93:1
	if jrt.J2g_Truth(tmp6) { var root_760 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_762 lang.IFn; if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any; var tmp9 any = A_arbace_repr_go_parse_A_const_73; var tmp10 any = A_arbace_repr_go_parse_A_const_74; var tmp11 any; var root_765 any = A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_767 lang.IFn


		if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any; var iter__1927001039__auto____7 any; var tmp12 any = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_A_New_O_O(n__5, t.F_kind); var tmp13 *jrt.Class; var fncls__889 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_A_fn_class; if fncls__889 == nil { var fncls__889d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_A_fn_class = fncls__889d; tmp13 = fncls__889d } else { tmp13 = fncls__889 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var tmp14 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp15 any; var root_890 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any = t__6; if linked_891 == nil { tmp15 = ifn_892.Invoke_O__O(arg_893) } else { tmp15 = linked_891.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_890, arg_893) }; arg_768 = tmp14.Invoke_O__O(tmp15); if linked_766 == nil { tmp11 = ifn_767.Invoke_O__O(arg_768) } else { tmp11 = linked_766.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_765, arg_768) }
//line :93:1
		arg_763 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, n__5, tmp10, tmp11)); var arg_764 any; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__1050000072); var tmp17 any; var root_894 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = s__1050000073__3; if linked_895 == nil { tmp17 = ifn_896.Invoke_O__O(arg_897) } else { tmp17 = linked_895.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_894, arg_897) }; arg_764 = tmp16.Invoke_O__O(tmp17); if linked_761 == nil { return ifn_762.Invoke_O_O__O(arg_763, arg_764) } else { return linked_761.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_760, arg_763, arg_764) } } else { var tmp18 any; var root_898 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = s__1050000073__3; if linked_899 == nil { tmp18 = ifn_900.Invoke_O__O(arg_901) } else { tmp18 = linked_899.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_898, arg_901) }; s__1050000073__1 = tmp18; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :93:1
func A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :93:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_A) Ctor_O_O_O_I_O(c__kind, c__nodes, c__b__1050000075 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_kind = c__kind; t.F_nodes = c__nodes; t.F_b__1050000075 = c__b__1050000075; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :93:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_A) Invoke_O__O(self any) any { { var i__1050000074__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000074__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1050000079__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000074__1)); var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000079__2, lang.RT_IntCast_J__I_NoInit(0), nil); var t__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000079__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var and__1927000168__auto____5 any; var root_573 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_575 lang.IFn
																	if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = t.F_nodes; var arg_577 any = n__3; if linked_574 == nil { and__1927000168__auto____5 = ifn_575.Invoke_O_O__O(arg_576, arg_577) } else { and__1927000168__auto____5 = linked_574.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_573, arg_576, arg_577) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var root_578 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = t__4; if linked_579 == nil { and__1927000168__auto____6 = ifn_580.Invoke_O__O(arg_581) } else { and__1927000168__auto____6 = linked_579.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_578, arg_581) }; if jrt.J2g_Truth(and__1927000168__auto____6) { var tmp3 any = A_arbace_repr_go_parse_A_const_72; var tmp4 any; var root_582 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = t__4; if linked_583 == nil { tmp4 = ifn_584.Invoke_O__O(arg_585) } else { tmp4 = linked_583.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_582, arg_585) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____6 } } else { tmp2 = and__1927000168__auto____5 }
//line :93:1
	if jrt.J2g_Truth(tmp2) { var root_586 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = t.F_b__1050000075; var arg_590 any; var tmp5 any = A_arbace_repr_go_parse_A_const_73; var tmp6 any = A_arbace_repr_go_parse_A_const_74; var tmp7 any; var root_591 any = A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_593 lang.IFn


		if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any; var iter__1927001039__auto____5 any; var tmp8 any = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_A_New_O_O(n__3, t.F_kind); var tmp9 *jrt.Class; var fncls__715 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_A_fn_class; if fncls__715 == nil { var fncls__715d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_A_fn_class = fncls__715d; tmp9 = fncls__715d } else { tmp9 = fncls__715 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp10 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp11 any; var root_716 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = t__4; if linked_717 == nil { tmp11 = ifn_718.Invoke_O__O(arg_719) } else { tmp11 = linked_717.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_716, arg_719) }; arg_594 = tmp10.Invoke_O__O(tmp11); if linked_592 == nil { tmp7 = ifn_593.Invoke_O__O(arg_594) } else { tmp7 = linked_592.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_591, arg_594) }
//line :93:1
		arg_590 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, n__3, tmp6, tmp7)); if linked_587 == nil { ifn_588.Invoke_O_O__O(arg_589, arg_590) } else { linked_587.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_586, arg_589, arg_590) }; i__1050000074__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000074__1); continue L1 } else { i__1050000074__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000074__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_A{}; t.Ctor_O_O(p0, p1); return t }
//line :96:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_A) Ctor_O_O(c__n, c__kind any) { t.F_n = c__n; t.F_kind = c__kind }
//line :96:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_A) Invoke_O_O__O(self, s__1050000083__1 any) any { var tmp1 any = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_A_New_O_O_O_O(s__1050000083__1, t.F_n, self, t.F_kind); var tmp2 *jrt.Class; var fncls__714 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_A_fn_class; if fncls__714 == nil { var fncls__714d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_A_fn_class = fncls__714d; tmp2 = fncls__714d } else { tmp2 = fncls__714 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :96:1
func A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :96:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_A) Ctor_O_O_O_O(c__s__1050000083, c__n, c__iter__1050000082, c__kind any) { t.F_s__1050000083 = c__s__1050000083; t.F_n = c__n; t.F_iter__1050000082 = c__iter__1050000082; t.F_kind = c__kind }
//line :96:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_A) Invoke_O__O(self any) any { { var s__1050000083__1 any; var t_ any = t.F_s__1050000083; t.F_s__1050000083 = nil; s__1050000083__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_595 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = s__1050000083__1; if linked_596 == nil { temp__1927000414__auto____2 = ifn_597.Invoke_O__O(arg_598) } else { temp__1927000414__auto____2 = linked_596.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_595, arg_598) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000083__3 any = temp__1927000414__auto____2; var tmp1 any; var root_599 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_601 lang.IFn; if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = s__1050000083__3; if linked_600 == nil { tmp1 = ifn_601.Invoke_O__O(arg_602) } else { tmp1 = linked_600.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_599, arg_602) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_603 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = s__1050000083__3; if linked_604 == nil { c__1927001037__auto____4 = ifn_605.Invoke_O__O(arg_606) } else { c__1927001037__auto____4 = linked_604.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_603, arg_606) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000085__6 any; var root_607 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_608 == nil { b__1050000085__6 = ifn_609.Invoke_O__O(arg_610) } else { b__1050000085__6 = linked_608.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_607, arg_610) }; var tmp2 any = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_fn__1050000088_A_New_O_O_O_I_O(t.F_n, t.F_kind, b__1050000085__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__641 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_fn__1050000088_A_fn_class; if fncls__641 == nil { var fncls__641d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_fn__1050000088_A_fn_class = fncls__641d; tmp3 = fncls__641d } else { tmp3 = fncls__641 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_642 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any; var root_647 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = b__1050000085__6; if linked_648 == nil { arg_645 = ifn_649.Invoke_O__O(arg_650) } else { arg_645 = linked_648.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_647, arg_650) }; var arg_646 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000082); var tmp5 any; var root_651 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = s__1050000083__3; if linked_652 == nil { tmp5 = ifn_653.Invoke_O__O(arg_654) } else { tmp5 = linked_652.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_651, arg_654) }; arg_646 = tmp4.Invoke_O__O(tmp5); if linked_643 == nil { return ifn_644.Invoke_O_O__O(arg_645, arg_646) } else { return linked_643.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_642, arg_645, arg_646) } } else { var root_655 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any; var root_660 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = b__1050000085__6; if linked_661 == nil { arg_658 = ifn_662.Invoke_O__O(arg_663) } else { arg_658 = linked_661.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_660, arg_663) }; var arg_659 any; if linked_656 == nil { return ifn_657.Invoke_O_O__O(arg_658, arg_659) } else { return linked_656.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_655, arg_658, arg_659) } } } else { var f__4 any; var root_664 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = s__1050000083__3; if linked_665 == nil { f__4 = ifn_666.Invoke_O__O(arg_667) } else { f__4 = linked_665.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_664, arg_667) }; var tmp6 any; var root_668 any = A_arbace_repr_go_parse_A_const_31.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_670 lang.IFn
																						if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = f__4; if linked_669 == nil { tmp6 = ifn_670.Invoke_O__O(arg_671) } else { tmp6 = linked_669.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_668, arg_671) }
//line :96:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_672 any = A_arbace_repr_go_parse_A_const_75.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_674 lang.IFn

		if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any; var root_676 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = A_arbace_repr_go_parse_A_const_76.GetRawRoot__O(); var arg_680 any = f__4; if linked_677 == nil { arg_675 = ifn_678.Invoke_O_O__O(arg_679, arg_680) } else { arg_675 = linked_677.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_676, arg_679, arg_680) }; if linked_673 == nil { tmp7 = ifn_674.Invoke_O__O(arg_675) } else { tmp7 = linked_673.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_672, arg_675) }
//line :96:1
		if jrt.J2g_Truth(tmp7) { var tmp8 any; var root_681 any = A_arbace_repr_go_parse_A_const_77.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_683 lang.IFn


			if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = f__4; if linked_682 == nil { tmp8 = ifn_683.Invoke_O__O(arg_684) } else { tmp8 = linked_682.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_681, arg_684) }
//line :96:1
			if jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(tmp8)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0))) { var tmp9 *lang.Keyword = A_arbace_repr_go_parse_A_const_39; var tag__5 any = tmp9.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__4)); var root_685 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any; var tmp10 any = A_arbace_repr_go_parse_A_const_73; var tmp11 any = A_arbace_repr_go_parse_A_const_78; var tmp12 any; var root_690 any = A_arbace_repr_go_parse_A_const_79.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, A_arbace_repr_go_parse_kebab_A_fn_class); var ifn_692 lang.IFn




				if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any; var root_694 any = A_arbace_repr_go_parse_A_const_77.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = f__4; if linked_695 == nil { arg_693 = ifn_696.Invoke_O__O(arg_697) } else { arg_693 = linked_695.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_694, arg_697) }; if linked_691 == nil { tmp12 = ifn_692.Invoke_O__O(arg_693) } else { tmp12 = linked_691.(*A_arbace_repr_go_parse_kebab_A).Invoke_O_O__O(root_690, arg_693) }
//line :96:1
				var tmp13 any = tmp12; var tmp14 any = A_arbace_repr_go_parse_A_const_39; var tmp15 any = A_arbace_repr_go_parse_A_const_80; arg_688 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, f__4, tmp11, tmp13, tmp14, tag__5, tmp15, lang.IFn_Cast(t.F_kind).Invoke_O_O_O__O(t.F_n, f__4, tag__5))); var arg_689 any; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__1050000082); var tmp17 any; var root_698 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = s__1050000083__3; if linked_699 == nil { tmp17 = ifn_700.Invoke_O__O(arg_701) } else { tmp17 = linked_699.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_698, arg_701) }; arg_689 = tmp16.Invoke_O__O(tmp17); if linked_686 == nil { return ifn_687.Invoke_O_O__O(arg_688, arg_689) } else { return linked_686.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_685, arg_688, arg_689) } } else { var tmp18 any; var root_702 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = s__1050000083__3; if linked_703 == nil { tmp18 = ifn_704.Invoke_O__O(arg_705) } else { tmp18 = linked_703.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_702, arg_705) }; s__1050000083__1 = tmp18; continue L1 } } else { var tmp19 any; var root_706 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = s__1050000083__3; if linked_707 == nil { tmp19 = ifn_708.Invoke_O__O(arg_709) } else { tmp19 = linked_707.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_706, arg_709) }; s__1050000083__1 = tmp19; continue L1 } } else { var tmp20 any; var root_710 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = s__1050000083__3; if linked_711 == nil { tmp20 = ifn_712.Invoke_O__O(arg_713) } else { tmp20 = linked_711.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_710, arg_713) }; s__1050000083__1 = tmp20; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :96:1
func A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_fn__1050000088_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_fn__1050000088_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_fn__1050000088_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :96:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_fn__1050000088_A) Ctor_O_O_O_I_O(c__n, c__kind, c__b__1050000085 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_kind = c__kind; t.F_b__1050000085 = c__b__1050000085; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :96:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_fn__1050000088_A) Invoke_O__O(self any) any { { var i__1050000084__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000084__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000084__1)); var tmp2 any; var root_611 any = A_arbace_repr_go_parse_A_const_31.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_613 lang.IFn
																								if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = f__2; if linked_612 == nil { tmp2 = ifn_613.Invoke_O__O(arg_614) } else { tmp2 = linked_612.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_611, arg_614) }
//line :96:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_615 any = A_arbace_repr_go_parse_A_const_75.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_617 lang.IFn

		if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any; var root_619 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = A_arbace_repr_go_parse_A_const_76.GetRawRoot__O(); var arg_623 any = f__2; if linked_620 == nil { arg_618 = ifn_621.Invoke_O_O__O(arg_622, arg_623) } else { arg_618 = linked_620.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_619, arg_622, arg_623) }; if linked_616 == nil { tmp3 = ifn_617.Invoke_O__O(arg_618) } else { tmp3 = linked_616.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_615, arg_618) }
//line :96:1
		if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_624 any = A_arbace_repr_go_parse_A_const_77.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_626 lang.IFn


			if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = f__2; if linked_625 == nil { tmp4 = ifn_626.Invoke_O__O(arg_627) } else { tmp4 = linked_625.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_624, arg_627) }
//line :96:1
			if jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(tmp4)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0))) { var tmp5 *lang.Keyword = A_arbace_repr_go_parse_A_const_39; var tag__3 any = tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__2)); var root_628 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = t.F_b__1050000085; var arg_632 any; var tmp6 any = A_arbace_repr_go_parse_A_const_73; var tmp7 any = A_arbace_repr_go_parse_A_const_78; var tmp8 any; var root_633 any = A_arbace_repr_go_parse_A_const_79.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, A_arbace_repr_go_parse_kebab_A_fn_class); var ifn_635 lang.IFn




				if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any; var root_637 any = A_arbace_repr_go_parse_A_const_77.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_639 lang.IFn; if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = f__2; if linked_638 == nil { arg_636 = ifn_639.Invoke_O__O(arg_640) } else { arg_636 = linked_638.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_637, arg_640) }; if linked_634 == nil { tmp8 = ifn_635.Invoke_O__O(arg_636) } else { tmp8 = linked_634.(*A_arbace_repr_go_parse_kebab_A).Invoke_O_O__O(root_633, arg_636) }
//line :96:1
				var tmp9 any = tmp8; var tmp10 any = A_arbace_repr_go_parse_A_const_39; var tmp11 any = A_arbace_repr_go_parse_A_const_80; arg_632 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, f__2, tmp7, tmp9, tmp10, tag__3, tmp11, lang.IFn_Cast(t.F_kind).Invoke_O_O_O__O(t.F_n, f__2, tag__3))); if linked_629 == nil { ifn_630.Invoke_O_O__O(arg_631, arg_632) } else { linked_629.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_628, arg_631, arg_632) }; i__1050000084__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000084__1); continue L1 } else { i__1050000084__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000084__1); continue L1 } } else { i__1050000084__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000084__1); continue L1 } } else { i__1050000084__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000084__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :96:1
func A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_A{}; t.Ctor_O_O(p0, p1); return t }
//line :96:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_A) Ctor_O_O(c__n, c__kind any) { t.F_n = c__n; t.F_kind = c__kind }
//line :96:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_A) Invoke_O_O__O(self, s__1050000097__1 any) any { var tmp1 any = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_A_New_O_O_O_O(t.F_n, s__1050000097__1, t.F_kind, self); var tmp2 *jrt.Class; var fncls__888 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_A_fn_class; if fncls__888 == nil { var fncls__888d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_A_fn_class = fncls__888d; tmp2 = fncls__888d } else { tmp2 = fncls__888 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :96:1
func A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :96:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_A) Ctor_O_O_O_O(c__n, c__s__1050000097, c__kind, c__iter__1050000096 any) { t.F_n = c__n; t.F_s__1050000097 = c__s__1050000097; t.F_kind = c__kind; t.F_iter__1050000096 = c__iter__1050000096 }
//line :96:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_A) Invoke_O__O(self any) any { { var s__1050000097__1 any; var t_ any = t.F_s__1050000097; t.F_s__1050000097 = nil; s__1050000097__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_769 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = s__1050000097__1; if linked_770 == nil { temp__1927000414__auto____2 = ifn_771.Invoke_O__O(arg_772) } else { temp__1927000414__auto____2 = linked_770.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_769, arg_772) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000097__3 any = temp__1927000414__auto____2; var tmp1 any; var root_773 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = s__1050000097__3; if linked_774 == nil { tmp1 = ifn_775.Invoke_O__O(arg_776) } else { tmp1 = linked_774.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_773, arg_776) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_777 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = s__1050000097__3; if linked_778 == nil { c__1927001037__auto____4 = ifn_779.Invoke_O__O(arg_780) } else { c__1927001037__auto____4 = linked_778.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_777, arg_780) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000099__6 any; var root_781 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_782 == nil { b__1050000099__6 = ifn_783.Invoke_O__O(arg_784) } else { b__1050000099__6 = linked_782.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_781, arg_784) }; var tmp2 any = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_fn__1050000102_A_New_O_O_O_I_O(t.F_n, t.F_kind, b__1050000099__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__815 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_fn__1050000102_A_fn_class; if fncls__815 == nil { var fncls__815d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_fn__1050000102_A_fn_class = fncls__815d; tmp3 = fncls__815d } else { tmp3 = fncls__815 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_816 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any; var root_821 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = b__1050000099__6; if linked_822 == nil { arg_819 = ifn_823.Invoke_O__O(arg_824) } else { arg_819 = linked_822.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_821, arg_824) }; var arg_820 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000096); var tmp5 any; var root_825 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_827 lang.IFn; if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = s__1050000097__3; if linked_826 == nil { tmp5 = ifn_827.Invoke_O__O(arg_828) } else { tmp5 = linked_826.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_825, arg_828) }; arg_820 = tmp4.Invoke_O__O(tmp5); if linked_817 == nil { return ifn_818.Invoke_O_O__O(arg_819, arg_820) } else { return linked_817.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_816, arg_819, arg_820) } } else { var root_829 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any; var root_834 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_834, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_836 lang.IFn; if linked_835 == nil { ifn_836 = lang.IFn_Cast(root_834) } else { ifn_836 = nil }; var arg_837 any = b__1050000099__6; if linked_835 == nil { arg_832 = ifn_836.Invoke_O__O(arg_837) } else { arg_832 = linked_835.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_834, arg_837) }; var arg_833 any; if linked_830 == nil { return ifn_831.Invoke_O_O__O(arg_832, arg_833) } else { return linked_830.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_829, arg_832, arg_833) } } } else { var f__4 any; var root_838 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_840 lang.IFn; if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any = s__1050000097__3; if linked_839 == nil { f__4 = ifn_840.Invoke_O__O(arg_841) } else { f__4 = linked_839.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_838, arg_841) }; var tmp6 any; var root_842 any = A_arbace_repr_go_parse_A_const_31.GetRawRoot__O(); var linked_843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_842, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_844 lang.IFn
																				if linked_843 == nil { ifn_844 = lang.IFn_Cast(root_842) } else { ifn_844 = nil }; var arg_845 any = f__4; if linked_843 == nil { tmp6 = ifn_844.Invoke_O__O(arg_845) } else { tmp6 = linked_843.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_842, arg_845) }
//line :96:1
	if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_846 any = A_arbace_repr_go_parse_A_const_75.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_848 lang.IFn

		if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any; var root_850 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = A_arbace_repr_go_parse_A_const_76.GetRawRoot__O(); var arg_854 any = f__4; if linked_851 == nil { arg_849 = ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { arg_849 = linked_851.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; if linked_847 == nil { tmp7 = ifn_848.Invoke_O__O(arg_849) } else { tmp7 = linked_847.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_846, arg_849) }
//line :96:1
		if jrt.J2g_Truth(tmp7) { var tmp8 any; var root_855 any = A_arbace_repr_go_parse_A_const_77.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_857 lang.IFn


			if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = f__4; if linked_856 == nil { tmp8 = ifn_857.Invoke_O__O(arg_858) } else { tmp8 = linked_856.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_855, arg_858) }
//line :96:1
			if jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(tmp8)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0))) { var tmp9 *lang.Keyword = A_arbace_repr_go_parse_A_const_39; var tag__5 any = tmp9.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__4)); var root_859 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_859, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_861 lang.IFn; if linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any; var tmp10 any = A_arbace_repr_go_parse_A_const_73; var tmp11 any = A_arbace_repr_go_parse_A_const_78; var tmp12 any; var root_864 any = A_arbace_repr_go_parse_A_const_79.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, A_arbace_repr_go_parse_kebab_A_fn_class); var ifn_866 lang.IFn




				if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any; var root_868 any = A_arbace_repr_go_parse_A_const_77.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_870 lang.IFn; if linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any = f__4; if linked_869 == nil { arg_867 = ifn_870.Invoke_O__O(arg_871) } else { arg_867 = linked_869.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_868, arg_871) }; if linked_865 == nil { tmp12 = ifn_866.Invoke_O__O(arg_867) } else { tmp12 = linked_865.(*A_arbace_repr_go_parse_kebab_A).Invoke_O_O__O(root_864, arg_867) }
//line :96:1
				var tmp13 any = tmp12; var tmp14 any = A_arbace_repr_go_parse_A_const_39; var tmp15 any = A_arbace_repr_go_parse_A_const_80; arg_862 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, f__4, tmp11, tmp13, tmp14, tag__5, tmp15, lang.IFn_Cast(t.F_kind).Invoke_O_O_O__O(t.F_n, f__4, tag__5))); var arg_863 any; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__1050000096); var tmp17 any; var root_872 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = s__1050000097__3; if linked_873 == nil { tmp17 = ifn_874.Invoke_O__O(arg_875) } else { tmp17 = linked_873.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_872, arg_875) }; arg_863 = tmp16.Invoke_O__O(tmp17); if linked_860 == nil { return ifn_861.Invoke_O_O__O(arg_862, arg_863) } else { return linked_860.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_859, arg_862, arg_863) } } else { var tmp18 any; var root_876 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = s__1050000097__3; if linked_877 == nil { tmp18 = ifn_878.Invoke_O__O(arg_879) } else { tmp18 = linked_877.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_876, arg_879) }; s__1050000097__1 = tmp18; continue L1 } } else { var tmp19 any; var root_880 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = s__1050000097__3; if linked_881 == nil { tmp19 = ifn_882.Invoke_O__O(arg_883) } else { tmp19 = linked_881.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_880, arg_883) }; s__1050000097__1 = tmp19; continue L1 } } else { var tmp20 any; var root_884 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_884, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_886 lang.IFn; if linked_885 == nil { ifn_886 = lang.IFn_Cast(root_884) } else { ifn_886 = nil }; var arg_887 any = s__1050000097__3; if linked_885 == nil { tmp20 = ifn_886.Invoke_O__O(arg_887) } else { tmp20 = linked_885.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_884, arg_887) }; s__1050000097__1 = tmp20; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :96:1
func A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_fn__1050000102_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_fn__1050000102_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_fn__1050000102_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :96:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_fn__1050000102_A) Ctor_O_O_O_I_O(c__n, c__kind, c__b__1050000099 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_kind = c__kind; t.F_b__1050000099 = c__b__1050000099; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :96:1
func (t *A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_fn__1050000102_A) Invoke_O__O(self any) any { { var i__1050000098__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000098__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000098__1)); var tmp2 any; var root_785 any = A_arbace_repr_go_parse_A_const_31.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_787 lang.IFn
																						if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = f__2; if linked_786 == nil { tmp2 = ifn_787.Invoke_O__O(arg_788) } else { tmp2 = linked_786.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_785, arg_788) }
//line :96:1
	if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_789 any = A_arbace_repr_go_parse_A_const_75.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_791 lang.IFn

		if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any; var root_793 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = A_arbace_repr_go_parse_A_const_76.GetRawRoot__O(); var arg_797 any = f__2; if linked_794 == nil { arg_792 = ifn_795.Invoke_O_O__O(arg_796, arg_797) } else { arg_792 = linked_794.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_793, arg_796, arg_797) }; if linked_790 == nil { tmp3 = ifn_791.Invoke_O__O(arg_792) } else { tmp3 = linked_790.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_789, arg_792) }
//line :96:1
		if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_798 any = A_arbace_repr_go_parse_A_const_77.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_800 lang.IFn


			if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = f__2; if linked_799 == nil { tmp4 = ifn_800.Invoke_O__O(arg_801) } else { tmp4 = linked_799.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_798, arg_801) }
//line :96:1
			if jrt.Character_IsUpperCase_C__Z_NoInit(jrt.NN(jrt.String_Cast(tmp4)).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(0))) { var tmp5 *lang.Keyword = A_arbace_repr_go_parse_A_const_39; var tag__3 any = tmp5.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__2)); var root_802 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = t.F_b__1050000099; var arg_806 any; var tmp6 any = A_arbace_repr_go_parse_A_const_73; var tmp7 any = A_arbace_repr_go_parse_A_const_78; var tmp8 any; var root_807 any = A_arbace_repr_go_parse_A_const_79.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, A_arbace_repr_go_parse_kebab_A_fn_class); var ifn_809 lang.IFn




				if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any; var root_811 any = A_arbace_repr_go_parse_A_const_77.GetRawRoot__O(); var linked_812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_811, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_813 lang.IFn; if linked_812 == nil { ifn_813 = lang.IFn_Cast(root_811) } else { ifn_813 = nil }; var arg_814 any = f__2; if linked_812 == nil { arg_810 = ifn_813.Invoke_O__O(arg_814) } else { arg_810 = linked_812.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_811, arg_814) }; if linked_808 == nil { tmp8 = ifn_809.Invoke_O__O(arg_810) } else { tmp8 = linked_808.(*A_arbace_repr_go_parse_kebab_A).Invoke_O_O__O(root_807, arg_810) }
//line :96:1
				var tmp9 any = tmp8; var tmp10 any = A_arbace_repr_go_parse_A_const_39; var tmp11 any = A_arbace_repr_go_parse_A_const_80; arg_806 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, f__2, tmp7, tmp9, tmp10, tag__3, tmp11, lang.IFn_Cast(t.F_kind).Invoke_O_O_O__O(t.F_n, f__2, tag__3))); if linked_803 == nil { ifn_804.Invoke_O_O__O(arg_805, arg_806) } else { linked_803.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_802, arg_805, arg_806) }; i__1050000098__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000098__1); continue L1 } else { i__1050000098__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000098__1); continue L1 } } else { i__1050000098__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000098__1); continue L1 } } else { i__1050000098__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000098__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_repr_go_parse_kw_var_A_New() *A_arbace_repr_go_parse_kw_var_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_kw_var_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_repr_go_parse_kw_var_A) Ctor() {}
//line :105:1
func (t *A_arbace_repr_go_parse_kw_var_A) Invoke_O_O__O(self, k__0 any) any { var root_904 any = A_arbace_repr_go_parse_A_const_81.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_136, nil); var tmp2 any; var root_908 any = A_arbace_repr_go_parse_A_const_42.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = k__0; var arg_912 any = Lit_137; var arg_913 any = Lit_138; if linked_909 == nil { tmp2 = ifn_910.Invoke_O_O_O__O(arg_911, arg_912, arg_913) } else { tmp2 = linked_909.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_908, arg_911, arg_912, arg_913) }; arg_907 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_905 == nil { return ifn_906.Invoke_O__O(arg_907) } else { return linked_905.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_904, arg_907) } }

func A_arbace_repr_go_parse_field_stmts_A_New() *A_arbace_repr_go_parse_field_stmts_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_field_stmts_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_repr_go_parse_field_stmts_A) Ctor() {}
//line :107:1
func (t *A_arbace_repr_go_parse_field_stmts_A) Invoke_O_O_O__O(self, tname__0, p__1050000110__1 any) any { var map__1050000111__3 any = p__1050000110__1; var map__1050000111__4 any; if lang.ISeq_InstanceOf(map__1050000111__3) { var tmp1 any; var root_914 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_914, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_916 lang.IFn; if linked_915 == nil { ifn_916 = lang.IFn_Cast(root_914) } else { ifn_916 = nil }; var arg_917 any = map__1050000111__3; if linked_915 == nil { tmp1 = ifn_916.Invoke_O__O(arg_917) } else { tmp1 = linked_915.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_914, arg_917) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_918 any = A_arbace_repr_go_parse_A_const_83.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = map__1050000111__3; if linked_919 == nil { tmp2 = ifn_920.Invoke_O__O(arg_921) } else { tmp2 = linked_919.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_918, arg_921) }; map__1050000111__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_922 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_922, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_924 lang.IFn; if linked_923 == nil { ifn_924 = lang.IFn_Cast(root_922) } else { ifn_924 = nil }; var arg_925 any = map__1050000111__3; if linked_923 == nil { tmp3 = ifn_924.Invoke_O__O(arg_925) } else { tmp3 = linked_923.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_922, arg_925) }; if jrt.J2g_Truth(tmp3) { var root_926 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_926, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_928 lang.IFn; if linked_927 == nil { ifn_928 = lang.IFn_Cast(root_926) } else { ifn_928 = nil }; var arg_929 any = map__1050000111__3; if linked_927 == nil { map__1050000111__4 = ifn_928.Invoke_O__O(arg_929) } else { map__1050000111__4 = linked_927.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_926, arg_929) } } else { map__1050000111__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1050000111__4 = map__1050000111__3 }; var name__5 any = lang.RT_Get_O_O__O_NoInit(map__1050000111__4, A_arbace_repr_go_parse_A_const_73); var key__6 any = lang.RT_Get_O_O__O_NoInit(map__1050000111__4, A_arbace_repr_go_parse_A_const_78); var kind__7 any = lang.RT_Get_O_O__O_NoInit(map__1050000111__4, A_arbace_repr_go_parse_A_const_80); var fx__8 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp5 any; var root_936 any = A_arbace_repr_go_parse_A_const_81.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_938 lang.IFn; if


	linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_110, nil), jrt.RefArrayOf(jrt.Object_class, nil, name__5)).Ref(); if linked_937 == nil { tmp5 = ifn_938.Invoke_O__O(arg_939) } else { tmp5 = linked_937.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_936, arg_939) }; fx__8 = tmp4.Invoke_O_O__O(tmp5, A_arbace_repr_go_parse_A_const_90); var kv__9 any; var root_930 any = /*line :107:1*/A_arbace_repr_go_parse_A_const_85.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, A_arbace_repr_go_parse_kw_var_A_fn_class); var ifn_932 lang.IFn; if



	linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = key__6; if linked_931 == nil { kv__9 = ifn_932.Invoke_O__O(arg_933) } else { kv__9 = linked_931.(*A_arbace_repr_go_parse_kw_var_A).Invoke_O_O__O(root_930, arg_933) }; var add__10 any; var tmp6 any = /*line :107:1*/A_arbace_repr_go_parse_field_stmts_add__1050000113_A_New_O(kv__9); var tmp7 *jrt.Class; var fncls__934 *jrt.Class = A_arbace_repr_go_parse_field_stmts_add__1050000113_A_fn_class; if




	fncls__934 == nil { var fncls__934d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_repr_go_parse_field_stmts_add__1050000113_A_fn_class = fncls__934d; tmp7 = fncls__934d } else { tmp7 = fncls__934 }; add__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var G__1050000115__11_ any = kind__7; switch
	lang.Util_Hash_O__I_NoInit(G__1050000115__11_) >> 12 & 15 { case 0: if any(G__1050000115__11_) == any(A_arbace_repr_go_parse_A_const_58) { return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(add__10).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_91, fx__8))) }; case 2: if any(G__1050000115__11_) == any(A_arbace_repr_go_parse_A_const_62) { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_parse_A_const_92; return lang.Tuple_Create_O__IPersistentVector(tmp8.Invoke_O_O_O__O(tmp9, lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_parse_A_const_93, fx__8, Lit_11), lang.IFn_Cast(add__10).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_parse_A_const_94, A_arbace_repr_go_parse_A_const_95, fx__8)))) }; case 3: if any(G__1050000115__11_) == any(A_arbace_repr_go_parse_A_const_66) { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_parse_A_const_96; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp13 any = A_arbace_repr_go_parse_A_const_98; var tmp14 any = A_arbace_repr_go_parse_A_const_99; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp16 any = A_arbace_repr_go_parse_A_const_100; var tmp17 any = A_arbace_repr_go_parse_A_const_101; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp19 any = A_arbace_repr_go_parse_A_const_103; return lang.Tuple_Create_O__IPersistentVector(tmp10.Invoke_O_O_O__O(tmp11, lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_parse_A_const_97, fx__8, nil), tmp12.Invoke_O_O_O_O__O(tmp13, lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15.Invoke_O_O_O__O(tmp16, tmp17, lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_102, fx__8))), tmp18.Invoke_O_O_O__O(tmp19, lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_repr_go_parse_A_const_105, A_arbace_repr_go_parse_A_const_106, fx__8), A_arbace_repr_go_parse_A_const_104), lang.IFn_Cast(add__10).Invoke_O__O(A_arbace_repr_go_parse_A_const_107)))) }; case 4: if any(G__1050000115__11_) == any(A_arbace_repr_go_parse_A_const_54) { var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp21 any = A_arbace_repr_go_parse_A_const_108; return lang.Tuple_Create_O__IPersistentVector(tmp20.Invoke_O_O_O__O(tmp21, lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_109, fx__8), lang.IFn_Cast(add__10).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_parse_A_const_110, A_arbace_repr_go_parse_A_const_111, fx__8)))) }; case 7: if any(G__1050000115__11_) == any(A_arbace_repr_go_parse_A_const_64) { var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp23 any = A_arbace_repr_go_parse_A_const_112; return lang.Tuple_Create_O__IPersistentVector(tmp22.Invoke_O_O_O__O(tmp23, fx__8, lang.IFn_Cast(add__10).Invoke_O__O(jrt.Boolean_TRUE.Ref()))) }; case 9: if any(G__1050000115__11_) == any(A_arbace_repr_go_parse_A_const_56) { var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp25 any = A_arbace_repr_go_parse_A_const_113; return lang.Tuple_Create_O__IPersistentVector(tmp24.Invoke_O_O_O__O(tmp25, lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_parse_A_const_114, fx__8, A_arbace_repr_go_parse_A_const_115), lang.IFn_Cast(add__10).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_116, fx__8)))) }; case 12: if any(G__1050000115__11_) == any(A_arbace_repr_go_parse_A_const_67) { var tmp26 any; var root_940 any = A_arbace_repr_go_parse_A_const_117.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_942 lang.IFn








		if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = A_arbace_repr_go_parse_A_const_118; var arg_944 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_parse_A_const_119, fx__8, nil); var arg_945 any = lang.IFn_Cast(add__10).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_parse_A_const_120, A_arbace_repr_go_parse_A_const_121, fx__8)); var arg_946 any; var tmp27 any; var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z_NoInit(key__6, Lit_112)


		if and__1927000168__auto____12 { tmp27 = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_122).Invoke_O__O(tname__0) } else { tmp27 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12).Ref() }; if jrt.J2g_Truth(tmp27) { var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp29 any = A_arbace_repr_go_parse_A_const_123; var tmp30 any = A_arbace_repr_go_parse_A_const_124; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp32 any = A_arbace_repr_go_parse_A_const_125; var tmp33 any = A_arbace_repr_go_parse_A_const_126; arg_946 = lang.Tuple_Create_O__IPersistentVector(tmp28.Invoke_O_O_O__O(tmp29, lang.Tuple_Create_O_O__IPersistentVector(tmp30, tmp31.Invoke_O_O_O__O(tmp32, tmp33, lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_127, fx__8))), lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_parse_A_const_128, A_arbace_repr_go_parse_A_const_129, A_arbace_repr_go_parse_A_const_130))) } else { arg_946 = nil }
//line :122:1
		if linked_941 == nil { tmp26 = ifn_942.Invoke_O_O_O_O__O(arg_943, arg_944, arg_945, arg_946) } else { tmp26 = linked_941.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O_O__O(root_940, arg_943, arg_944, arg_945, arg_946) }
//line :113:1
		return lang.Tuple_Create_O__IPersistentVector(tmp26) }; case 13: if any(G__1050000115__11_) == any(A_arbace_repr_go_parse_A_const_60) { var tmp34 any; var root_947 any = A_arbace_repr_go_parse_A_const_117.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_947, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_949 lang.IFn





			if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = A_arbace_repr_go_parse_A_const_131; var arg_951 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_parse_A_const_132, fx__8, nil); var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp36 any = A_arbace_repr_go_parse_A_const_133; var tmp37 any = A_arbace_repr_go_parse_A_const_134; var arg_952 any = lang.IFn_Cast(add__10).Invoke_O__O(tmp35.Invoke_O_O_O__O(tmp36, tmp37, lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_135, fx__8))); var arg_953 any

			if lang.Util_Equiv_O_O__Z_NoInit(key__6, Lit_113) { arg_953 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_repr_go_parse_A_const_136, A_arbace_repr_go_parse_A_const_137, fx__8, jrt.Boolean_TRUE.Ref())) } else { arg_953 = nil }
//line :119:1
			if linked_948 == nil { tmp34 = ifn_949.Invoke_O_O_O_O__O(arg_950, arg_951, arg_952, arg_953) } else { tmp34 = linked_948.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O_O__O(root_947, arg_950, arg_951, arg_952, arg_953) }
//line :113:1
			return lang.Tuple_Create_O__IPersistentVector(tmp34) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1050000115__11_))))) }
//line :112:1
func A_arbace_repr_go_parse_field_stmts_add__1050000113_A_New_O(p0 any) *A_arbace_repr_go_parse_field_stmts_add__1050000113_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_field_stmts_add__1050000113_A{}; t.Ctor_O(p0); return t }
//line :112:1
func (t *A_arbace_repr_go_parse_field_stmts_add__1050000113_A) Ctor_O(c__kv any) { t.F_kv = c__kv }
//line :112:1
func (t *A_arbace_repr_go_parse_field_stmts_add__1050000113_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_parse_A_const_86; var tmp3 any = A_arbace_repr_go_parse_A_const_87; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_repr_go_parse_A_const_88, A_arbace_repr_go_parse_A_const_89, t.F_kv, v__1)) }





















func A_arbace_repr_go_parse_node_case_A_New() *A_arbace_repr_go_parse_node_case_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_node_case_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_repr_go_parse_node_case_A) Ctor() {}
//line :134:1
func (t *A_arbace_repr_go_parse_node_case_A) Invoke_O_O__O(self, p__1050000119__0 any) any { var map__1050000120__2 any = p__1050000119__0; var map__1050000120__3 any; if lang.ISeq_InstanceOf(map__1050000120__2) { var tmp1 any; var root_954 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = map__1050000120__2; if linked_955 == nil { tmp1 = ifn_956.Invoke_O__O(arg_957) } else { tmp1 = linked_955.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_954, arg_957) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_958 any = A_arbace_repr_go_parse_A_const_83.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = map__1050000120__2; if linked_959 == nil { tmp2 = ifn_960.Invoke_O__O(arg_961) } else { tmp2 = linked_959.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_958, arg_961) }; map__1050000120__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_962 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any = map__1050000120__2; if linked_963 == nil { tmp3 = ifn_964.Invoke_O__O(arg_965) } else { tmp3 = linked_963.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_962, arg_965) }; if jrt.J2g_Truth(tmp3) { var root_966 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = map__1050000120__2; if linked_967 == nil { map__1050000120__3 = ifn_968.Invoke_O__O(arg_969) } else { map__1050000120__3 = linked_967.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_966, arg_969) } } else { map__1050000120__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1050000120__3 = map__1050000120__2 }; var name__4 any = lang.RT_Get_O_O__O_NoInit(map__1050000120__3, A_arbace_repr_go_parse_A_const_73); var fields__5 any = lang.RT_Get_O_O__O_NoInit(map__1050000120__3, A_arbace_repr_go_parse_A_const_74); var unknown__6 any; var root_970 any = A_arbace_repr_go_parse_A_const_138.GetRawRoot__O(); var linked_971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_970, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_972 lang.IFn; if
												linked_971 == nil { ifn_972 = lang.IFn_Cast(root_970) } else { ifn_972 = nil }; var arg_973 any; var tmp4 any = A_arbace_repr_go_parse_node_case_fn__1050000122_A_New(); var tmp5 *jrt.Class; var fncls__983 *jrt.Class = A_arbace_repr_go_parse_node_case_fn__1050000122_A_fn_class; if fncls__983 == nil { var fncls__983d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_repr_go_parse_node_case_fn__1050000122_A_fn_class = fncls__983d; tmp5 = fncls__983d } else { tmp5 = fncls__983 }; arg_973 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_974 any = fields__5; if linked_971 == nil { unknown__6 = ifn_972.Invoke_O_O__O(arg_973, arg_974) } else { unknown__6 = linked_971.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_970, arg_973, arg_974) }; var root_984 any =
												A_arbace_repr_go_parse_A_const_35.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_parse_A_const_139; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp9 any = A_arbace_repr_go_parse_A_const_141; var tmp10 any; var root_989 any = A_arbace_repr_go_parse_A_const_81.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_991 lang.IFn; if
												linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = Lit_159; var arg_993 any; var root_994 any = A_arbace_repr_go_parse_A_const_142.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = name__4; if linked_995 == nil { arg_993 = ifn_996.Invoke_O__O(arg_997) } else { arg_993 = linked_995.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_994, arg_997) }; if linked_990 == nil { tmp10 = ifn_991.Invoke_O_O__O(arg_992, arg_993) } else { tmp10 = linked_990.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_989, arg_992, arg_993) }; arg_987 = tmp6.Invoke_O_O_O__O(tmp7, lang.Tuple_Create_O__IPersistentVector(tmp8.Invoke_O_O__O(tmp9, tmp10)), A_arbace_repr_go_parse_A_const_140); var arg_988 any; if

	jrt.J2g_Truth(unknown__6) { arg_988 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_143, unknown__6)) } else { var tmp11 any; var root_998 any = A_arbace_repr_go_parse_A_const_117.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1000 lang.IFn

		if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any = A_arbace_repr_go_parse_A_const_144; var tmp12 any = A_arbace_repr_go_parse_A_const_145; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp14 any = A_arbace_repr_go_parse_A_const_146; var tmp15 any = A_arbace_repr_go_parse_A_const_147; var tmp16 any = A_arbace_repr_go_parse_A_const_148; var arg_1002 any = lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13.Invoke_O_O_O_O__O(tmp14, tmp15, tmp16, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(lang.Numbers_Multiply_J_J__J_NoInit(2, int64(lang.RT_Count_O__I_NoInit(fields__5))))).Ref())); var arg_1003 any; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp18 any = A_arbace_repr_go_parse_A_const_149; var tmp19 any = A_arbace_repr_go_parse_A_const_150; var tmp20 any = A_arbace_repr_go_parse_A_const_151; var tmp21 any; var root_1005 any = A_arbace_repr_go_parse_A_const_85.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, A_arbace_repr_go_parse_kw_var_A_fn_class); var ifn_1007 lang.IFn
		if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any; var root_1009 any = A_arbace_repr_go_parse_A_const_79.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, A_arbace_repr_go_parse_kebab_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any; var root_1013 any = A_arbace_repr_go_parse_A_const_142.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = name__4; if linked_1014 == nil { arg_1012 = ifn_1015.Invoke_O__O(arg_1016) } else { arg_1012 = linked_1014.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1013, arg_1016) }; if linked_1010 == nil { arg_1008 = ifn_1011.Invoke_O__O(arg_1012) } else { arg_1008 = linked_1010.(*A_arbace_repr_go_parse_kebab_A).Invoke_O_O__O(root_1009, arg_1012) }; if linked_1006 == nil { tmp21 = ifn_1007.Invoke_O__O(arg_1008) } else { tmp21 = linked_1006.(*A_arbace_repr_go_parse_kw_var_A).Invoke_O_O__O(root_1005, arg_1008) }; arg_1003 = tmp17.Invoke_O_O_O_O__O(tmp18, tmp19, tmp20, tmp21)
//line :141:1
		var arg_1004 any; var root_1017 any = A_arbace_repr_go_parse_A_const_35.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1019 lang.IFn

		if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_152.GetRawRoot__O()); var tmp23 any = A_arbace_repr_go_parse_node_case_fn__1050000124_A_New_O(name__4); var tmp24 *jrt.Class; var fncls__1032 *jrt.Class = A_arbace_repr_go_parse_node_case_fn__1050000124_A_fn_class; if fncls__1032 == nil { var fncls__1032d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_160, false); A_arbace_repr_go_parse_node_case_fn__1050000124_A_fn_class = fncls__1032d; tmp24 = fncls__1032d } else { tmp24 = fncls__1032 }; arg_1020 = tmp22.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil), fields__5); var arg_1021 any = A_arbace_repr_go_parse_A_const_154; if linked_1018 == nil { arg_1004 = ifn_1019.Invoke_O_O__O(arg_1020, arg_1021) } else { arg_1004 = linked_1018.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1017, arg_1020, arg_1021) }
//line :141:1
		if linked_999 == nil { tmp11 = ifn_1000.Invoke_O_O_O_O__O(arg_1001, arg_1002, arg_1003, arg_1004) } else { tmp11 = linked_999.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O_O__O(root_998, arg_1001, arg_1002, arg_1003, arg_1004) }
//line :139:1
		arg_988 = lang.Tuple_Create_O__IPersistentVector(tmp11) }; if /*line :136:1*/ linked_985 == nil { return ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { return linked_985.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_984, arg_987, arg_988) } }
//line :135:1
func A_arbace_repr_go_parse_node_case_fn__1050000122_A_New() *A_arbace_repr_go_parse_node_case_fn__1050000122_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_node_case_fn__1050000122_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_repr_go_parse_node_case_fn__1050000122_A) Ctor() {}
//line :135:1
func (t *A_arbace_repr_go_parse_node_case_fn__1050000122_A) Invoke_O_O__O(self, p1__1050000117_SHARP___1 any) any { var tmp1 any; var root_975 any = A_arbace_repr_go_parse_A_const_32.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = A_arbace_repr_go_parse_A_const_80.Invoke_O__O(p1__1050000117_SHARP___1); if linked_976 == nil { tmp1 = ifn_977.Invoke_O__O(arg_978) } else { tmp1 = linked_976.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_975, arg_978) }; if jrt.J2g_Truth(tmp1) { var root_979 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_981 lang.IFn; if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = A_arbace_repr_go_parse_A_const_80.Invoke_O__O(p1__1050000117_SHARP___1); if linked_980 == nil { return ifn_981.Invoke_O__O(arg_982) } else { return linked_980.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_979, arg_982) } } else { return nil } }







func A_arbace_repr_go_parse_node_case_fn__1050000124_A_New_O(p0 any) *A_arbace_repr_go_parse_node_case_fn__1050000124_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_node_case_fn__1050000124_A{}; t.Ctor_O(p0); return t }
//line :143:1
func (t *A_arbace_repr_go_parse_node_case_fn__1050000124_A) Ctor_O(c__name any) { t.F_name = c__name }
//line :143:1
func (t *A_arbace_repr_go_parse_node_case_fn__1050000124_A) Invoke_O_O__O(self, p1__1050000118_SHARP___1 any) any { var root_1027 any = A_arbace_repr_go_parse_A_const_153.GetRawRoot__O(); var linked_1028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1027, A_arbace_repr_go_parse_field_stmts_A_fn_class); var ifn_1029 lang.IFn; if linked_1028 == nil { ifn_1029 = lang.IFn_Cast(root_1027) } else { ifn_1029 = nil }; var arg_1030 any = t.F_name; var arg_1031 any = p1__1050000118_SHARP___1; if linked_1028 == nil { return ifn_1029.Invoke_O_O__O(arg_1030, arg_1031) } else { return linked_1028.(*A_arbace_repr_go_parse_field_stmts_A).Invoke_O_O_O__O(root_1027, arg_1030, arg_1031) } }






func A_arbace_repr_go_parse_dumper_forms_A_New() *A_arbace_repr_go_parse_dumper_forms_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_dumper_forms_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_repr_go_parse_dumper_forms_A) Ctor() {}
//line :150:1
func (t *A_arbace_repr_go_parse_dumper_forms_A) Invoke_O_O__O(self, ast_dir__0 any) any { var nodes__2 any; var root_1033 any = A_arbace_repr_go_parse_A_const_155.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, A_arbace_repr_go_parse_ast_nodes_A_fn_class); var ifn_1035 lang.IFn; if


	linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = ast_dir__0; if linked_1034 == nil { nodes__2 = ifn_1035.Invoke_O__O(arg_1036) } else { nodes__2 = linked_1034.(*A_arbace_repr_go_parse_ast_nodes_A).Invoke_O_O__O(root_1033, arg_1036) }; var keys__3 any; var root_1037 any = /*line :150:1*/A_arbace_repr_go_parse_A_const_156.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1039 lang.IFn; if



	linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_35.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_parse_A_const_157.GetRawRoot__O(); var tmp3 any; var root_1047 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1049 lang.IFn; if
	linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_159.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_parse_A_const_79.GetRawRoot__O(), A_arbace_repr_go_parse_A_const_142.GetRawRoot__O(), A_arbace_repr_go_parse_A_const_73); var arg_1051 any = nodes__2; if linked_1048 == nil { tmp3 = ifn_1049.Invoke_O_O__O(arg_1050, arg_1051) } else { tmp3 = linked_1048.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1047, arg_1050, arg_1051) }; var tmp4 any = tmp3; var tmp5 any; var root_1058 any = /*line :154:1*/A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1060 lang.IFn; if

	linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = A_arbace_repr_go_parse_A_const_78; var arg_1062 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_152.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_74, nodes__2); if linked_1059 == nil { tmp5 = ifn_1060.Invoke_O_O__O(arg_1061, arg_1062) } else { tmp5 = linked_1059.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1058, arg_1061, arg_1062) }; arg_1040 = /*line :154:1*/tmp1.Invoke_O_O_O__O(tmp2, tmp4, tmp5); if linked_1038 == nil { keys__3 = ifn_1039.Invoke_O__O(arg_1040) } else { keys__3 = linked_1038.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1037, arg_1040) }; var tmp6 lang.IFn =


	lang.IFn_Cast(A_arbace_repr_go_parse_A_const_35.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_parse_A_const_160; var tmp8 any; var iter__1927001039__auto____4 any; var tmp9 any = A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_A_New(); var tmp10 *jrt.Class; var fncls__1140 *jrt.Class = A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_A_fn_class; if






















	fncls__1140 == nil { var fncls__1140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_A_fn_class = fncls__1140d; tmp10 = fncls__1140d } else { tmp10 = fncls__1140 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); tmp8 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(keys__3); var tmp11 any = tmp8; var tmp12 any = A_arbace_repr_go_parse_A_const_163; var tmp13 any = A_arbace_repr_go_parse_A_const_164; var tmp14 any = A_arbace_repr_go_parse_A_const_165; var tmp15 any = A_arbace_repr_go_parse_A_const_166; var tmp16 any = A_arbace_repr_go_parse_A_const_167; var tmp17 any = A_arbace_repr_go_parse_A_const_168; var tmp18 any = A_arbace_repr_go_parse_A_const_169; var tmp19 any = A_arbace_repr_go_parse_A_const_170; var tmp20 lang.IFn = /*line :157:1*/lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp21 any = A_arbace_repr_go_parse_A_const_172; var tmp22 any = A_arbace_repr_go_parse_A_const_173; var tmp23 any = A_arbace_repr_go_parse_A_const_174; var tmp24 any; var root_1141 any = A_arbace_repr_go_parse_A_const_35.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1141, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1143 lang.IFn; if



































































































	linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_175, A_arbace_repr_go_parse_A_const_176); var arg_1145 any; var root_1146 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1148 lang.IFn; if
	linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any = A_arbace_repr_go_parse_A_const_177.GetRawRoot__O(); var arg_1150 any = nodes__2; if linked_1147 == nil { arg_1145 = ifn_1148.Invoke_O_O__O(arg_1149, arg_1150) } else { arg_1145 = linked_1147.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1146, arg_1149, arg_1150) }; if /*line :257:1*/ linked_1142 == nil { tmp24 = ifn_1143.Invoke_O_O__O(arg_1144, arg_1145) } else { tmp24 = linked_1142.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1141, arg_1144, arg_1145) }; return /*line :157:1*/ tmp6.Invoke_O_O_O__O(tmp7, tmp11, lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20.Invoke_O_O_O_O_O_O__O(tmp21, tmp22, Lit_104, tmp23, tmp24, A_arbace_repr_go_parse_A_const_178), A_arbace_repr_go_parse_A_const_171))) }






















func A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_A_New() *A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_A) Ctor() {}
//line :180:1
func (t *A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_A) Invoke_O_O__O(self, s__1050000128__1 any) any { var tmp1 any = A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_A_New_O_O(s__1050000128__1, self); var tmp2 *jrt.Class; var fncls__1139 *jrt.Class = A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_A_fn_class; if fncls__1139 == nil { var fncls__1139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_A_fn_class = fncls__1139d; tmp2 = fncls__1139d } else { tmp2 = fncls__1139 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :180:1
func A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_A{}; t.Ctor_O_O(p0, p1); return t }
//line :180:1
func (t *A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_A) Ctor_O_O(c__s__1050000128, c__iter__1050000127 any) { t.F_s__1050000128 = c__s__1050000128; t.F_iter__1050000127 = c__iter__1050000127 }
//line :180:1
func (t *A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_A) Invoke_O__O(self any) any { { var s__1050000128__1 any; var t_ any = t.F_s__1050000128; t.F_s__1050000128 = nil; s__1050000128__1 = t_; for { var temp__1927000414__auto____2 any; var root_1074 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = s__1050000128__1; if linked_1075 == nil { temp__1927000414__auto____2 = ifn_1076.Invoke_O__O(arg_1077) } else { temp__1927000414__auto____2 = linked_1075.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1074, arg_1077) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000128__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1078 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = s__1050000128__3; if linked_1079 == nil { tmp1 = ifn_1080.Invoke_O__O(arg_1081) } else { tmp1 = linked_1079.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1078, arg_1081) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1082 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = s__1050000128__3; if linked_1083 == nil { c__1927001037__auto____4 = ifn_1084.Invoke_O__O(arg_1085) } else { c__1927001037__auto____4 = linked_1083.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1082, arg_1085) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000130__6 any; var root_1086 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1088 lang.IFn; if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1087 == nil { b__1050000130__6 = ifn_1088.Invoke_O__O(arg_1089) } else { b__1050000130__6 = linked_1087.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1086, arg_1089) }; var tmp2 any = A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_fn__1050000133_A_New_O_I_O(b__1050000130__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1099 *jrt.Class = A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_fn__1050000133_A_fn_class; if fncls__1099 == nil { var fncls__1099d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_fn__1050000133_A_fn_class = fncls__1099d; tmp3 = fncls__1099d } else { tmp3 = fncls__1099 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1100 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any; var root_1105 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any = b__1050000130__6; if linked_1106 == nil { arg_1103 = ifn_1107.Invoke_O__O(arg_1108) } else { arg_1103 = linked_1106.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1105, arg_1108) }; var arg_1104 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000127); var tmp5 any; var root_1109 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_1110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1109, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1111 lang.IFn; if linked_1110 == nil { ifn_1111 = lang.IFn_Cast(root_1109) } else { ifn_1111 = nil }; var arg_1112 any = s__1050000128__3; if linked_1110 == nil { tmp5 = ifn_1111.Invoke_O__O(arg_1112) } else { tmp5 = linked_1110.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1109, arg_1112) }; arg_1104 = tmp4.Invoke_O__O(tmp5); if linked_1101 == nil { return ifn_1102.Invoke_O_O__O(arg_1103, arg_1104) } else { return linked_1101.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1100, arg_1103, arg_1104) } } else { var root_1113 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any; var root_1118 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_1119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1118, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1120 lang.IFn; if linked_1119 == nil { ifn_1120 = lang.IFn_Cast(root_1118) } else { ifn_1120 = nil }; var arg_1121 any = b__1050000130__6; if linked_1119 == nil { arg_1116 = ifn_1120.Invoke_O__O(arg_1121) } else { arg_1116 = linked_1119.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1118, arg_1121) }; var arg_1117 any; if linked_1114 == nil { return ifn_1115.Invoke_O_O__O(arg_1116, arg_1117) } else { return linked_1114.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1113, arg_1116, arg_1117) } } } else { var k__4 any; var root_1122 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1122, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1124 lang.IFn; if linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any = s__1050000128__3; if linked_1123 == nil { k__4 = ifn_1124.Invoke_O__O(arg_1125) } else { k__4 = linked_1123.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1122, arg_1125) }; var root_1126 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_1127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1126, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1128 lang.IFn; if linked_1127 == nil { ifn_1128 = lang.IFn_Cast(root_1126) } else { ifn_1128 = nil }; var arg_1129 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_parse_A_const_161; var tmp8 any; var root_1131 any = A_arbace_repr_go_parse_A_const_85.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, A_arbace_repr_go_parse_kw_var_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = k__4; if linked_1132 == nil { tmp8 = ifn_1133.Invoke_O__O(arg_1134) } else { tmp8 = linked_1132.(*A_arbace_repr_go_parse_kw_var_A).Invoke_O_O__O(root_1131, arg_1134) }; arg_1129 = tmp6.Invoke_O_O_O__O(tmp7, tmp8, lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_162, k__4)); var arg_1130 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1050000127); var tmp10 any; var root_1135 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1137 lang.IFn; if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = s__1050000128__3; if linked_1136 == nil { tmp10 = ifn_1137.Invoke_O__O(arg_1138) } else { tmp10 = linked_1136.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1135, arg_1138) }; arg_1130 = tmp9.Invoke_O__O(tmp10); if linked_1127 == nil { return ifn_1128.Invoke_O_O__O(arg_1129, arg_1130) } else { return linked_1127.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1126, arg_1129, arg_1130) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :180:1
func A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_fn__1050000133_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_fn__1050000133_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_fn__1050000133_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :180:1
func (t *A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_fn__1050000133_A) Ctor_O_I_O(c__b__1050000130 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1050000130 = c__b__1050000130; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :180:1
func (t *A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_fn__1050000133_A) Invoke_O__O(self any) any { { var i__1050000129__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000129__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000129__1)); var root_1090 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = t.F_b__1050000130; var arg_1094 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_parse_A_const_161; var tmp4 any; var root_1095 any = A_arbace_repr_go_parse_A_const_85.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, A_arbace_repr_go_parse_kw_var_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = k__2; if linked_1096 == nil { tmp4 = ifn_1097.Invoke_O__O(arg_1098) } else { tmp4 = linked_1096.(*A_arbace_repr_go_parse_kw_var_A).Invoke_O_O__O(root_1095, arg_1098) }; arg_1094 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_162, k__2)); if linked_1091 == nil { ifn_1092.Invoke_O_O__O(arg_1093, arg_1094) } else { linked_1091.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1090, arg_1093, arg_1094) }; i__1050000129__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000129__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







































































































func A_arbace_repr_go_parse_load_BANG__A_New() *A_arbace_repr_go_parse_load_BANG__A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_load_BANG__A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_repr_go_parse_load_BANG__A) Ctor() {}
//line :284:1
func (t *A_arbace_repr_go_parse_load_BANG__A) Invoke_O_O__O(self, goroot_forms__0 any) any { var lockee__1927000360__auto____2 any = A_arbace_repr_go_parse_A_const_179.GetRawRoot__O(); var locklocal__1927000361__auto____5 any = lockee__1927000360__auto____2; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____5); var tmp1 any; tmp34 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var or__1927000174__auto____8 any; var root_1151 any = A_arbace_repr_go_parse_A_const_10.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1153 lang.IFn




	if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = A_arbace_repr_go_parse_A_const_179.GetRawRoot__O(); if linked_1152 == nil { or__1927000174__auto____8 = ifn_1153.Invoke_O__O(arg_1154) } else { or__1927000174__auto____8 = linked_1152.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1151, arg_1154) }; if jrt.J2g_Truth(or__1927000174__auto____8) { tmp1 = or__1927000174__auto____8 } else { var t0__9 int64 = jrt.System_NanoTime__J(); var forms__10 any; var root_1155 any = A_arbace_repr_go_parse_A_const_180.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, A_arbace_repr_go_parse_dumper_forms_A_fn_class); var ifn_1157 lang.IFn

		if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_139), jrt.RefArrayOf(jrt.Object_class, goroot_forms__0, nil)).Ref(); if linked_1156 == nil { forms__10 = ifn_1157.Invoke_O__O(arg_1158) } else { forms__10 = linked_1156.(*A_arbace_repr_go_parse_dumper_forms_A).Invoke_O_O__O(root_1155, arg_1158) }
//line :289:1
		var src__11 any; var root_1159 any = A_arbace_repr_go_parse_A_const_181.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_go_check.A_arbace_go_check_forms_source_A_fn_class); var ifn_1161 lang.IFn


		if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = forms__10; var arg_1163 any; var root_1164 any = A_arbace_repr_go_parse_A_const_10.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1166 lang.IFn; if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = A_arbace_repr_go_parse_A_const_182.GetRawRoot__O(); if linked_1165 == nil { arg_1163 = ifn_1166.Invoke_O__O(arg_1167) } else { arg_1163 = linked_1165.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1164, arg_1167) }; if linked_1160 == nil { src__11 = ifn_1161.Invoke_O_O__O(arg_1162, arg_1163) } else { src__11 = linked_1160.(*aot_arbace_go_check.A_arbace_go_check_forms_source_A).Invoke_O_O_O__O(root_1159, arg_1162, arg_1163) }
//line :289:1
		var st__12 any; var root_1168 any = A_arbace_repr_go_parse_A_const_183.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1170 lang.IFn



		if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var tmp2 any = A_arbace_repr_go_parse_A_const_184; var tmp3 any = A_arbace_repr_go_parse_A_const_184.Invoke_O__O(src__11); var tmp4 any = A_arbace_repr_go_parse_A_const_73; var tmp5 any = A_arbace_repr_go_parse_A_const_73.Invoke_O__O(src__11); var tmp6 any = A_arbace_repr_go_parse_A_const_185; var tmp7 any = A_arbace_repr_go_parse_A_const_186; var tmp8 any = A_arbace_repr_go_parse_A_const_187; var tmp9 any = A_arbace_repr_go_parse_A_const_187.Invoke_O__O(src__11); var tmp10 any = A_arbace_repr_go_parse_A_const_188; var tmp11 any = A_arbace_repr_go_parse_A_const_188.Invoke_O__O(src__11); var tmp12 any = A_arbace_repr_go_parse_A_const_189; var arg_1171 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, A_arbace_repr_go_parse_A_const_189.Invoke_O__O(src__11), A_arbace_repr_go_parse_A_const_190, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_repr_go_parse_A_const_191, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_repr_go_parse_A_const_192, lang.PersistentArrayMap_EMPTY.Ref(), A_arbace_repr_go_parse_A_const_193, lang.PersistentHashSet_EMPTY.Ref())); if linked_1169 == nil { st__12 = ifn_1170.Invoke_O__O(arg_1171) } else { st__12 = linked_1169.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1168, arg_1171) }
//line :289:1
		var ___13 any; var root_1172 any = A_arbace_repr_go_parse_A_const_194.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1174 lang.IFn; _ = ___13






		if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any = A_arbace_repr_go_parse_A_const_195.GetRawRoot__O(); var arg_1176 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var arg_1177 any = A_arbace_repr_go_parse_A_const_184.Invoke_O__O(src__11); var arg_1178 any = st__12; if linked_1173 == nil { ___13 = ifn_1174.Invoke_O_O_O_O__O(arg_1175, arg_1176, arg_1177, arg_1178) } else { ___13 = linked_1173.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1172, arg_1175, arg_1176, arg_1177, arg_1178) }
//line :289:1
		var r__14 any; var root_1179 any = A_arbace_repr_go_parse_A_const_197.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_go_repl.A_arbace_go_repl_check_source_A_fn_class); var ifn_1181 lang.IFn







		if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any = src__11; var arg_1183 any; if linked_1180 == nil { r__14 = ifn_1181.Invoke_O_O__O(arg_1182, arg_1183) } else { r__14 = linked_1180.(*aot_arbace_go_repl.A_arbace_go_repl_check_source_A).Invoke_O_O_O__O(root_1179, arg_1182, arg_1183) }
//line :289:1
		var ___15 any; var tmp13 any; var root_1184 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1186 lang.IFn; _ = ___15








		if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = A_arbace_repr_go_parse_A_const_198.Invoke_O__O(r__14); if linked_1185 == nil { tmp13 = ifn_1186.Invoke_O__O(arg_1187) } else { tmp13 = linked_1185.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1184, arg_1187) }; if jrt.J2g_Truth(tmp13) {
			var root_1345 any = A_arbace_repr_go_parse_A_const_194.GetRawRoot__O(); var linked_1346 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1345, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1347 lang.IFn; if linked_1346 == nil { ifn_1347 = lang.IFn_Cast(root_1345) } else { ifn_1347 = nil }; var arg_1348 any = A_arbace_repr_go_parse_A_const_195.GetRawRoot__O(); var arg_1349 any = A_arbace_repr_go_parse_A_const_217.GetRawRoot__O(); var arg_1350 any = A_arbace_repr_go_parse_A_const_184.Invoke_O__O(src__11); if linked_1346 == nil { ifn_1347.Invoke_O_O_O__O(arg_1348, arg_1349, arg_1350) } else { linked_1346.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1345, arg_1348, arg_1349, arg_1350) }
//line :298:1
			var tmp14 any; var root_1188 any = A_arbace_repr_go_parse_A_const_199.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1190 lang.IFn

			if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any; var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_140, nil); var tmp16 any; var root_1193 any = A_arbace_repr_go_parse_A_const_200.GetRawRoot__O(); var linked_1194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1193, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1195 lang.IFn
			if linked_1194 == nil { ifn_1195 = lang.IFn_Cast(root_1193) } else { ifn_1195 = nil }; var arg_1196 any = Lit_141; var arg_1197 any; var iter__1927001039__auto____17 any; var tmp17 any = A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_A_New(); var tmp18 *jrt.Class; var fncls__1256 *jrt.Class = A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_A_fn_class; if fncls__1256 == nil { var fncls__1256d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_A_fn_class = fncls__1256d; tmp18 = fncls__1256d } else { tmp18 = fncls__1256 }; iter__1927001039__auto____17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var tmp19 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____17); var tmp20 any; var root_1257 any = A_arbace_repr_go_parse_A_const_204.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = A_arbace_repr_go_parse_A_const_205; var arg_1261 any = A_arbace_repr_go_parse_A_const_198.Invoke_O__O(r__14); if linked_1258 == nil { tmp20 = ifn_1259.Invoke_O_O__O(arg_1260, arg_1261) } else { tmp20 = linked_1258.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_1257, arg_1260, arg_1261) }; arg_1197 = tmp19.Invoke_O__O(tmp20); if linked_1194 == nil { tmp16 = ifn_1195.Invoke_O_O__O(arg_1196, arg_1197) } else { tmp16 = linked_1194.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1193, arg_1196, arg_1197) }
//line :300:1
			arg_1191 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16)).Ref(); var tmp21 any = A_arbace_repr_go_parse_A_const_198; var arg_1192 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp21, A_arbace_repr_go_parse_A_const_198.Invoke_O__O(r__14))); if linked_1189 == nil { tmp14 = ifn_1190.Invoke_O_O__O(arg_1191, arg_1192) } else { tmp14 = linked_1189.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1188, arg_1191, arg_1192) }
//line :298:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp14))) } else { ___15 = nil }
//line :289:1
		var map__1050000138__16 any; var root_1262 any = A_arbace_repr_go_parse_A_const_206.GetRawRoot__O(); var linked_1263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1262, aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A_fn_class); var ifn_1264 lang.IFn














		if linked_1263 == nil { ifn_1264 = lang.IFn_Cast(root_1262) } else { ifn_1264 = nil }; var arg_1265 any = st__12; var arg_1266 any = r__14; var arg_1267 any = A_arbace_repr_go_parse_A_const_207; if linked_1263 == nil { map__1050000138__16 = ifn_1264.Invoke_O_O_O__O(arg_1265, arg_1266, arg_1267) } else { map__1050000138__16 = linked_1263.(*aot_arbace_go_repl.A_arbace_go_repl_define_BANG__A).Invoke_O_O_O_O__O(root_1262, arg_1265, arg_1266, arg_1267) }
//line :289:1
		var map__1050000138__17 any
		if lang.ISeq_InstanceOf(map__1050000138__16) { var tmp22 any; var root_1268 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_1269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1268, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1270 lang.IFn; if linked_1269 == nil { ifn_1270 = lang.IFn_Cast(root_1268) } else { ifn_1270 = nil }; var arg_1271 any = map__1050000138__16; if linked_1269 == nil { tmp22 = ifn_1270.Invoke_O__O(arg_1271) } else { tmp22 = linked_1269.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1268, arg_1271) }; if jrt.J2g_Truth(tmp22) { var tmp23 any; var root_1272 any = A_arbace_repr_go_parse_A_const_83.GetRawRoot__O(); var linked_1273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1272, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1274 lang.IFn; if linked_1273 == nil { ifn_1274 = lang.IFn_Cast(root_1272) } else { ifn_1274 = nil }; var arg_1275 any = map__1050000138__16; if linked_1273 == nil { tmp23 = ifn_1274.Invoke_O__O(arg_1275) } else { tmp23 = linked_1273.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1272, arg_1275) }; map__1050000138__17 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp23, jrt.Object_class.ArrayClass())).Ref() } else { var tmp24 any; var root_1276 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1278 lang.IFn; if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any = map__1050000138__16; if linked_1277 == nil { tmp24 = ifn_1278.Invoke_O__O(arg_1279) } else { tmp24 = linked_1277.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1276, arg_1279) }; if jrt.J2g_Truth(tmp24) { var root_1280 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; var arg_1283 any = map__1050000138__16; if linked_1281 == nil { map__1050000138__17 = ifn_1282.Invoke_O__O(arg_1283) } else { map__1050000138__17 = linked_1281.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1280, arg_1283) } } else { map__1050000138__17 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1050000138__17 = map__1050000138__16 }
//line :289:1
		var inits__18 any = lang.RT_Get_O_O__O_NoInit(map__1050000138__17, A_arbace_repr_go_parse_A_const_208); var init_funcs__19 any = lang.RT_Get_O_O__O_NoInit(map__1050000138__17, A_arbace_repr_go_parse_A_const_209); var ___20 any; var root_1284 any = A_arbace_repr_go_parse_A_const_210.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_go_repl.A_arbace_go_repl_call0_A_fn_class); var ifn_1286 lang.IFn; _ = ___20















		if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any = inits__18; var arg_1288 any = Lit_143; if linked_1285 == nil { ___20 = ifn_1286.Invoke_O_O__O(arg_1287, arg_1288) } else { ___20 = linked_1285.(*aot_arbace_go_repl.A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_1284, arg_1287, arg_1288) }
//line :289:1
		var ___21 any; var tmp25 any = A_arbace_repr_go_parse_load_BANG__fn__1050000154_A_New_O(init_funcs__19); var tmp26 *jrt.Class; var fncls__1327 *jrt.Class = A_arbace_repr_go_parse_load_BANG__fn__1050000154_A_fn_class; _ = ___21
















		if fncls__1327 == nil { var fncls__1327d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_repr_go_parse_load_BANG__fn__1050000154_A_fn_class = fncls__1327d; tmp26 = fncls__1327d } else { tmp26 = fncls__1327 }; ___21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil).Invoke__O()
//line :289:1
		var init__22 any; var root_1328 any = A_arbace_repr_go_parse_A_const_211.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_1330 lang.IFn

















		if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = A_arbace_repr_go_parse_A_const_212; if linked_1329 == nil { init__22 = ifn_1330.Invoke_O__O(arg_1331) } else { init__22 = linked_1329.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_1328, arg_1331) }
//line :289:1
		var dump__23 any; var root_1332 any = A_arbace_repr_go_parse_A_const_211.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_1334 lang.IFn


















		if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = A_arbace_repr_go_parse_A_const_213; if linked_1333 == nil { dump__23 = ifn_1334.Invoke_O__O(arg_1335) } else { dump__23 = linked_1333.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_1332, arg_1335) }
		var tmp27 lang.IFn = lang.IFn_Cast(init__22); var tmp28 any = A_arbace_repr_go_parse_load_BANG__fn__1050000156_A_New(); var tmp29 *jrt.Class; var fncls__1356 *jrt.Class = A_arbace_repr_go_parse_load_BANG__fn__1050000156_A_fn_class; if fncls__1356 == nil { var fncls__1356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, true); A_arbace_repr_go_parse_load_BANG__fn__1050000156_A_fn_class = fncls__1356d; tmp29 = fncls__1356d } else { tmp29 = fncls__1356 }; tmp27.Invoke_O_O_O__O(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp28, tmp29, nil, 1), A_arbace_repr_go_parse_A_const_220.GetRawRoot__O(), A_arbace_repr_go_parse_A_const_219.GetRawRoot__O())
		var root_1336 any = A_arbace_repr_go_parse_A_const_214.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = A_arbace_repr_go_parse_A_const_179.GetRawRoot__O(); var arg_1340 any; var tmp30 any = A_arbace_repr_go_parse_A_const_215; var tmp31 any; var root_1341 any = A_arbace_repr_go_parse_A_const_10.GetRawRoot__O(); var linked_1342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1341, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1343 lang.IFn; if linked_1342 == nil { ifn_1343 = lang.IFn_Cast(root_1341) } else { ifn_1343 = nil }; var arg_1344 any = dump__23; if linked_1342 == nil { tmp31 = ifn_1343.Invoke_O__O(arg_1344) } else { tmp31 = linked_1342.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1341, arg_1344) }; var tmp32 any = tmp31; var tmp33 any = A_arbace_repr_go_parse_A_const_216; arg_1340 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp30, tmp32, tmp33, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__9), 1000000.0)).Ref())); if linked_1337 == nil { tmp1 = ifn_1338.Invoke_O_O__O(arg_1339, arg_1340) } else { tmp1 = linked_1337.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_1336, arg_1339, arg_1340) } } }; return nil }(); /*line :284:1*/lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____5); if tmp34 != nil { panic(tmp34) }; return tmp1 }
















func A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_A_New() *A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_A{}; t.Ctor(); return t }
//line :301:1
func (t *A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_A) Ctor() {}
//line :301:1
func (t *A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_A) Invoke_O_O__O(self, s__1050000141__1 any) any { var tmp1 any = A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_A_New_O_O(s__1050000141__1, self); var tmp2 *jrt.Class; var fncls__1255 *jrt.Class = A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_A_fn_class; if fncls__1255 == nil { var fncls__1255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_A_fn_class = fncls__1255d; tmp2 = fncls__1255d } else { tmp2 = fncls__1255 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :301:1
func A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_A{}; t.Ctor_O_O(p0, p1); return t }
//line :301:1
func (t *A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_A) Ctor_O_O(c__s__1050000141, c__iter__1050000140 any) { t.F_s__1050000141 = c__s__1050000141; t.F_iter__1050000140 = c__iter__1050000140 }
//line :301:1
func (t *A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_A) Invoke_O__O(self any) any { { var s__1050000141__1 any; var t_ any = t.F_s__1050000141; t.F_s__1050000141 = nil; s__1050000141__1 = t_; for { var temp__1927000414__auto____2 any; var root_1198 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1198, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = s__1050000141__1; if linked_1199 == nil { temp__1927000414__auto____2 = ifn_1200.Invoke_O__O(arg_1201) } else { temp__1927000414__auto____2 = linked_1199.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1198, arg_1201) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000141__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1202 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_1203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1202, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1204 lang.IFn; if linked_1203 == nil { ifn_1204 = lang.IFn_Cast(root_1202) } else { ifn_1204 = nil }; var arg_1205 any = s__1050000141__3; if linked_1203 == nil { tmp1 = ifn_1204.Invoke_O__O(arg_1205) } else { tmp1 = linked_1203.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1202, arg_1205) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1206 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1208 lang.IFn; if linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = s__1050000141__3; if linked_1207 == nil { c__1927001037__auto____4 = ifn_1208.Invoke_O__O(arg_1209) } else { c__1927001037__auto____4 = linked_1207.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1206, arg_1209) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000143__6 any; var root_1210 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1211 == nil { b__1050000143__6 = ifn_1212.Invoke_O__O(arg_1213) } else { b__1050000143__6 = linked_1211.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1210, arg_1213) }; var tmp2 any = A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_fn__1050000146_A_New_O_I_O(b__1050000143__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1219 *jrt.Class = A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_fn__1050000146_A_fn_class; if fncls__1219 == nil { var fncls__1219d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_fn__1050000146_A_fn_class = fncls__1219d; tmp3 = fncls__1219d } else { tmp3 = fncls__1219 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1220 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any; var root_1225 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = b__1050000143__6; if linked_1226 == nil { arg_1223 = ifn_1227.Invoke_O__O(arg_1228) } else { arg_1223 = linked_1226.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1225, arg_1228) }; var arg_1224 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000140); var tmp5 any; var root_1229 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1231 lang.IFn; if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any = s__1050000141__3; if linked_1230 == nil { tmp5 = ifn_1231.Invoke_O__O(arg_1232) } else { tmp5 = linked_1230.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1229, arg_1232) }; arg_1224 = tmp4.Invoke_O__O(tmp5); if linked_1221 == nil { return ifn_1222.Invoke_O_O__O(arg_1223, arg_1224) } else { return linked_1221.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1220, arg_1223, arg_1224) } } else { var root_1233 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1233, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1235 lang.IFn; if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any; var root_1238 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1240 lang.IFn; if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any = b__1050000143__6; if linked_1239 == nil { arg_1236 = ifn_1240.Invoke_O__O(arg_1241) } else { arg_1236 = linked_1239.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1238, arg_1241) }; var arg_1237 any; if linked_1234 == nil { return ifn_1235.Invoke_O_O__O(arg_1236, arg_1237) } else { return linked_1234.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1233, arg_1236, arg_1237) } } } else { var e__4 any; var root_1242 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1242, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1244 lang.IFn; if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = s__1050000141__3; if linked_1243 == nil { e__4 = ifn_1244.Invoke_O__O(arg_1245) } else { e__4 = linked_1243.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1242, arg_1245) }; var root_1246 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_148, nil, Lit_96, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_parse_A_const_201.Invoke_O__O(e__4), nil, A_arbace_repr_go_parse_A_const_202.Invoke_O__O(e__4), nil, A_arbace_repr_go_parse_A_const_203.Invoke_O__O(e__4))).Ref(); var arg_1250 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1050000140); var tmp7 any; var root_1251 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1253 lang.IFn; if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any = s__1050000141__3; if linked_1252 == nil { tmp7 = ifn_1253.Invoke_O__O(arg_1254) } else { tmp7 = linked_1252.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1251, arg_1254) }; arg_1250 = tmp6.Invoke_O__O(tmp7); if linked_1247 == nil { return ifn_1248.Invoke_O_O__O(arg_1249, arg_1250) } else { return linked_1247.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1246, arg_1249, arg_1250) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :301:1
func A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_fn__1050000146_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_fn__1050000146_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_fn__1050000146_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :301:1
func (t *A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_fn__1050000146_A) Ctor_O_I_O(c__b__1050000143 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1050000143 = c__b__1050000143; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :301:1
func (t *A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_fn__1050000146_A) Invoke_O__O(self any) any { { var i__1050000142__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000142__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000142__1)); var root_1214 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_1215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1214, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1216 lang.IFn; if linked_1215 == nil { ifn_1216 = lang.IFn_Cast(root_1214) } else { ifn_1216 = nil }; var arg_1217 any = t.F_b__1050000143; var arg_1218 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_148, nil, Lit_96, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_parse_A_const_201.Invoke_O__O(e__2), nil, A_arbace_repr_go_parse_A_const_202.Invoke_O__O(e__2), nil, A_arbace_repr_go_parse_A_const_203.Invoke_O__O(e__2))).Ref(); if linked_1215 == nil { ifn_1216.Invoke_O_O__O(arg_1217, arg_1218) } else { linked_1215.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1214, arg_1217, arg_1218) }; i__1050000142__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000142__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_parse_load_BANG__fn__1050000154_A_New_O(p0 any) *A_arbace_repr_go_parse_load_BANG__fn__1050000154_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_load_BANG__fn__1050000154_A{}; t.Ctor_O(p0); return t }
//line :306:1
func (t *A_arbace_repr_go_parse_load_BANG__fn__1050000154_A) Ctor_O(c__init_funcs any) { t.F_init_funcs = c__init_funcs }
//line :306:1
func (t *A_arbace_repr_go_parse_load_BANG__fn__1050000154_A) Invoke_O__O(self any) any { { var seq_1050000150__1 any; var root_1289 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any; var t_ any = t.F_init_funcs; t.F_init_funcs = nil; arg_1292 = t_; if linked_1290 == nil { seq_1050000150__1 = ifn_1291.Invoke_O__O(arg_1292) } else { seq_1050000150__1 = linked_1290.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1289, arg_1292) }; var chunk_1050000151__2 any; var count_1050000152__3 int64 = 0; var i_1050000153__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1050000153__4, count_1050000152__3) { var f__5 any = lang.Indexed_Cast(chunk_1050000151__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1050000153__4)); var root_1309 any = A_arbace_repr_go_parse_A_const_210.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1309, aot_arbace_go_repl.A_arbace_go_repl_call0_A_fn_class); var ifn_1311 lang.IFn; if linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any = f__5; var arg_1313 any = Lit_143; if linked_1310 == nil { ifn_1311.Invoke_O_O__O(arg_1312, arg_1313) } else { linked_1310.(*aot_arbace_go_repl.A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_1309, arg_1312, arg_1313) }; seq_1050000150__1, chunk_1050000151__2, count_1050000152__3, i_1050000153__4 = seq_1050000150__1, chunk_1050000151__2, count_1050000152__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1050000153__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_1293 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = seq_1050000150__1; if linked_1294 == nil { temp__1927000414__auto____5 = ifn_1295.Invoke_O__O(arg_1296) } else { temp__1927000414__auto____5 = linked_1294.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1293, arg_1296) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1050000150__6 any = temp__1927000414__auto____5; var tmp1 any; var root_1297 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1299 lang.IFn; if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = seq_1050000150__6; if linked_1298 == nil { tmp1 = ifn_1299.Invoke_O__O(arg_1300) } else { tmp1 = linked_1298.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1297, arg_1300) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____7 any; var root_1301 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = seq_1050000150__6; if linked_1302 == nil { c__1927000678__auto____7 = ifn_1303.Invoke_O__O(arg_1304) } else { c__1927000678__auto____7 = linked_1302.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1301, arg_1304) }; var tmp2 any; var root_1314 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any = seq_1050000150__6; if linked_1315 == nil { tmp2 = ifn_1316.Invoke_O__O(arg_1317) } else { tmp2 = linked_1315.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1314, arg_1317) }; seq_1050000150__1, chunk_1050000151__2, count_1050000152__3, i_1050000153__4 = tmp2, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__7 any; var root_1305 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1307 lang.IFn; if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any = seq_1050000150__6; if linked_1306 == nil { f__7 = ifn_1307.Invoke_O__O(arg_1308) } else { f__7 = linked_1306.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1305, arg_1308) }; var root_1318 any = A_arbace_repr_go_parse_A_const_210.GetRawRoot__O(); var linked_1319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1318, aot_arbace_go_repl.A_arbace_go_repl_call0_A_fn_class); var ifn_1320 lang.IFn; if linked_1319 == nil { ifn_1320 = lang.IFn_Cast(root_1318) } else { ifn_1320 = nil }; var arg_1321 any = f__7; var arg_1322 any = Lit_143; if linked_1319 == nil { ifn_1320.Invoke_O_O__O(arg_1321, arg_1322) } else { linked_1319.(*aot_arbace_go_repl.A_arbace_go_repl_call0_A).Invoke_O_O_O__O(root_1318, arg_1321, arg_1322) }; var tmp3 any; var root_1323 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_1324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1323, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1325 lang.IFn; if linked_1324 == nil { ifn_1325 = lang.IFn_Cast(root_1323) } else { ifn_1325 = nil }; var arg_1326 any = seq_1050000150__6; if linked_1324 == nil { tmp3 = ifn_1325.Invoke_O__O(arg_1326) } else { tmp3 = linked_1324.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1323, arg_1326) }; seq_1050000150__1, chunk_1050000151__2, count_1050000152__3, i_1050000153__4 = tmp3, nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }


func A_arbace_repr_go_parse_load_BANG__fn__1050000156_A_New() *A_arbace_repr_go_parse_load_BANG__fn__1050000156_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_load_BANG__fn__1050000156_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_repr_go_parse_load_BANG__fn__1050000156_A) Ctor() {}
//line :309:1
func (t *A_arbace_repr_go_parse_load_BANG__fn__1050000156_A) DoInvoke_O_O_O__O(self, h__1, kvs__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_84.GetRawRoot__O()); var tmp2 any; var root_1351 any = A_arbace_repr_go_parse_A_const_218.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1353 lang.IFn; if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = A_arbace_repr_go_parse_A_const_219.GetRawRoot__O(); var arg_1355 any = kvs__2; if linked_1352 == nil { tmp2 = ifn_1353.Invoke_O_O__O(arg_1354, arg_1355) } else { tmp2 = linked_1352.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1351, arg_1354, arg_1355) }; return tmp1.Invoke_O_O__O(h__1, tmp2) }


func A_arbace_repr_go_parse_go_lang_A_New() *A_arbace_repr_go_parse_go_lang_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_go_lang_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_repr_go_parse_go_lang_A) Ctor() {}
//line :312:1
func (t *A_arbace_repr_go_parse_go_lang_A) Invoke_O_O__O(self, v__0 any) any { var temp__1927000414__auto____2 any; var and__1927000168__auto____2 any; var root_1357 any = A_arbace_repr_go_parse_A_const_21.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1359 lang.IFn; if


	linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = v__0; if linked_1358 == nil { and__1927000168__auto____2 = ifn_1359.Invoke_O__O(arg_1360) } else { and__1927000168__auto____2 = linked_1358.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1357, arg_1360) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_1361 any = A_arbace_repr_go_parse_A_const_221.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1363 lang.IFn; if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any = A_arbace_repr_go_parse_A_const_222; var arg_1365 any = v__0; if linked_1362 == nil { temp__1927000414__auto____2 = ifn_1363.Invoke_O_O__O(arg_1364, arg_1365) } else { temp__1927000414__auto____2 = linked_1362.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1361, arg_1364, arg_1365) } } else { temp__1927000414__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var vec__1050000159__3 any = temp__1927000414__auto____2; var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000159__3, lang.RT_IntCast_J__I_NoInit(0), nil); var minor__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000159__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_125, nil), jrt.RefArrayOf(jrt.Object_class, nil, minor__5)).Ref(); var tmp2 any; var root_1366 any = A_arbace_repr_go_parse_A_const_223.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_parse_long_A_fn_class); var ifn_1368 lang.IFn; _ = ___4
		if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = minor__5; if linked_1367 == nil { tmp2 = ifn_1368.Invoke_O__O(arg_1369) } else { tmp2 = linked_1367.(*aot_arbace_core.A_arbace_core_parse_long_A).Invoke_O_O__O(root_1366, arg_1369) }
//line :315:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) } else { return nil } }


func A_arbace_repr_go_parse_file_go_version_A_New() *A_arbace_repr_go_parse_file_go_version_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_file_go_version_A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_repr_go_parse_file_go_version_A) Ctor() {}
//line :318:1
func (t *A_arbace_repr_go_parse_file_go_version_A) Invoke_O_O_O__O(self, ast_go_version__0, lang__1 any) any { var temp__1927000408__auto____3 any; var root_1370 any = A_arbace_repr_go_parse_A_const_224.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, A_arbace_repr_go_parse_go_lang_A_fn_class); var ifn_1372 lang.IFn; if



	linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = ast_go_version__0; if linked_1371 == nil { temp__1927000408__auto____3 = ifn_1372.Invoke_O__O(arg_1373) } else { temp__1927000408__auto____3 = linked_1371.(*A_arbace_repr_go_parse_go_lang_A).Invoke_O_O__O(root_1370, arg_1373) }; if jrt.J2g_Truth(temp__1927000408__auto____3) { var vec__1050000163__4 any = temp__1927000408__auto____3; var v__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000163__4, lang.RT_IntCast_J__I_NoInit(0), nil); var minor__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000163__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 bool; var na_1374 any = minor__6; var na_1375 int64 = 21
		if jrt.Long_InstanceOf(na_1374) { var n0_1376 int64 = jrt.NN(jrt.Long_Cast(na_1374)).LongValue__J(); var n1_1377 int64 = na_1375; tmp1 = n0_1376 < n1_1377 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_1374, na_1375) }; if tmp1 { return Lit_115 } else { return v__5 } } else {
//line :322:1
			return lang__1 } }



func A_arbace_repr_go_parse_parse_file_A_New() *A_arbace_repr_go_parse_parse_file_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_parse_file_A{}; t.Ctor(); return t }
//line :326:1
func (t *A_arbace_repr_go_parse_parse_file_A) Ctor() {}
//line :326:1
func (t *A_arbace_repr_go_parse_parse_file_A) Invoke_O_O_O__O(self, goroot_forms__0, path__1 any) any { var r__3 any; var tmp1 *lang.Keyword = A_arbace_repr_go_parse_A_const_215; var tmp2 any; var root_1379 any = A_arbace_repr_go_parse_A_const_225.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, A_arbace_repr_go_parse_load_BANG__A_fn_class); var ifn_1381 lang.IFn; if



	linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = goroot_forms__0; if linked_1380 == nil { tmp2 = ifn_1381.Invoke_O__O(arg_1382) } else { tmp2 = linked_1380.(*A_arbace_repr_go_parse_load_BANG__A).Invoke_O_O__O(root_1379, arg_1382) }; r__3 = lang.IFn_Cast(tmp1.Invoke_O__O(tmp2)).Invoke_O__O(path__1); var tmp3 any; var root_1383 any =
	A_arbace_repr_go_parse_A_const_21.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_1385 lang.IFn; if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = r__3; if linked_1384 == nil { tmp3 = ifn_1385.Invoke_O__O(arg_1386) } else { tmp3 = linked_1384.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_1383, arg_1386) }; if jrt.J2g_Truth(tmp3) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_parse_A_const_226, r__3)) } else { var vec__1050000167__4 any = r__3; var tree__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000167__4, lang.RT_IntCast_J__I_NoInit(0), nil); var comments__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000167__4, lang.RT_IntCast_J__I_NoInit(1), nil); var dirs__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000167__4, lang.RT_IntCast_J__I_NoInit(2), nil); var warns__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000167__4, lang.RT_IntCast_J__I_NoInit(3), nil); var parse_ns__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000167__4, lang.RT_IntCast_J__I_NoInit(4), nil); var dump_ns__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000167__4, lang.RT_IntCast_J__I_NoInit(5), nil); var tmp4 any = A_arbace_repr_go_parse_A_const_227; var tmp5 any = A_arbace_repr_go_parse_A_const_228; var tmp6 any = A_arbace_repr_go_parse_A_const_229; var tmp7 any = A_arbace_repr_go_parse_A_const_230; var tmp8 any = A_arbace_repr_go_parse_A_const_231; var tmp9 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(parse_ns__9, 1000000.0)).Ref(); var tmp10 any = A_arbace_repr_go_parse_A_const_232; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tree__5, tmp5, comments__6, tmp6, dirs__7, tmp7, warns__8, tmp8, tmp9, tmp10, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(dump_ns__10, 1000000.0)).Ref())) } }











func A_arbace_repr_go_parse_strip_meta_A_New() *A_arbace_repr_go_parse_strip_meta_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_strip_meta_A{}; t.Ctor(); return t }
//line :343:1
func (t *A_arbace_repr_go_parse_strip_meta_A) Ctor() {}
//line :343:1
func (t *A_arbace_repr_go_parse_strip_meta_A) Invoke_O_O__O(self, x__0 any) any {
	var tmp1 any; var root_1387 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = x__0; if linked_1388 == nil { tmp1 = ifn_1389.Invoke_O__O(arg_1390) } else { tmp1 = linked_1388.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1387, arg_1390) }; if jrt.J2g_Truth(tmp1) { var root_1391 any = A_arbace_repr_go_parse_A_const_218.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = A_arbace_repr_go_parse_A_const_84.GetRawRoot__O(); var arg_1395 any; var root_1396 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = A_arbace_repr_go_parse_A_const_233.GetRawRoot__O(); var arg_1400 any = x__0; if linked_1397 == nil { arg_1395 = ifn_1398.Invoke_O_O__O(arg_1399, arg_1400) } else { arg_1395 = linked_1397.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1396, arg_1399, arg_1400) }; if linked_1392 == nil { return ifn_1393.Invoke_O_O__O(arg_1394, arg_1395) } else { return linked_1392.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1391, arg_1394, arg_1395) } } else { var tmp2 any; var root_1401 any = A_arbace_repr_go_parse_A_const_32.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1403 lang.IFn
		if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = x__0; if linked_1402 == nil { tmp2 = ifn_1403.Invoke_O__O(arg_1404) } else { tmp2 = linked_1402.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1401, arg_1404) }
//line :344:1
		if jrt.J2g_Truth(tmp2) {
			var root_1405 any = A_arbace_repr_go_parse_A_const_234.GetRawRoot__O(); var linked_1406 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1405, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1407 lang.IFn; if linked_1406 == nil { ifn_1407 = lang.IFn_Cast(root_1405) } else { ifn_1407 = nil }; var arg_1408 any = A_arbace_repr_go_parse_A_const_233.GetRawRoot__O(); var arg_1409 any = x__0; if linked_1406 == nil { return ifn_1407.Invoke_O_O__O(arg_1408, arg_1409) } else { return linked_1406.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1405, arg_1408, arg_1409) } } else {
//line :344:1
				var tmp3 any; var root_1410 any = A_arbace_repr_go_parse_A_const_235.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1410, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1412 lang.IFn

				if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any = x__0; if linked_1411 == nil { tmp3 = ifn_1412.Invoke_O__O(arg_1413) } else { tmp3 = linked_1411.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1410, arg_1413) }
//line :344:1
				if jrt.J2g_Truth(tmp3) {

					var root_1414 any = A_arbace_repr_go_parse_A_const_236.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1414, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1416 lang.IFn; if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1418 any; var root_1420 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any; var tmp4 any = A_arbace_repr_go_parse_strip_meta_fn__1050000172_A_New(); var tmp5 *jrt.Class; var fncls__1432 *jrt.Class = A_arbace_repr_go_parse_strip_meta_fn__1050000172_A_fn_class; if fncls__1432 == nil { var fncls__1432d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_182, false); A_arbace_repr_go_parse_strip_meta_fn__1050000172_A_fn_class = fncls__1432d; tmp5 = fncls__1432d } else { tmp5 = fncls__1432 }; arg_1423 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); if linked_1421 == nil { arg_1418 = ifn_1422.Invoke_O__O(arg_1423) } else { arg_1418 = linked_1421.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_1420, arg_1423) }; var arg_1419 any = x__0; if linked_1415 == nil { return ifn_1416.Invoke_O_O_O__O(arg_1417, arg_1418, arg_1419) } else { return linked_1415.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_1414, arg_1417, arg_1418, arg_1419) } } else {
//line :344:1
						if A_arbace_repr_go_parse_A_const_68 != nil { return x__0 } else { return nil
						} } } } }
func A_arbace_repr_go_parse_strip_meta_fn__1050000172_A_New() *A_arbace_repr_go_parse_strip_meta_fn__1050000172_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_strip_meta_fn__1050000172_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_repr_go_parse_strip_meta_fn__1050000172_A) Ctor() {}
//line :346:1
func (t *A_arbace_repr_go_parse_strip_meta_fn__1050000172_A) Invoke_O_O__O(self, p__1050000171__1 any) any { var vec__1050000173__2 any = p__1050000171__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000173__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000173__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1424 any = A_arbace_repr_go_parse_A_const_233.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, A_arbace_repr_go_parse_strip_meta_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any = k__3; if linked_1425 == nil { tmp1 = ifn_1426.Invoke_O__O(arg_1427) } else { tmp1 = linked_1425.(*A_arbace_repr_go_parse_strip_meta_A).Invoke_O_O__O(root_1424, arg_1427) }; var tmp2 any = tmp1; var tmp3 any; var root_1428 any = A_arbace_repr_go_parse_A_const_233.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, A_arbace_repr_go_parse_strip_meta_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = v__4; if linked_1429 == nil { tmp3 = ifn_1430.Invoke_O__O(arg_1431) } else { tmp3 = linked_1429.(*A_arbace_repr_go_parse_strip_meta_A).Invoke_O_O__O(root_1428, arg_1431) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }


func A_arbace_repr_go_parse_decl_forms_A_New() *A_arbace_repr_go_parse_decl_forms_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_decl_forms_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_repr_go_parse_decl_forms_A) Ctor() {}
//line :349:1
func (t *A_arbace_repr_go_parse_decl_forms_A) Invoke_O_O__O(self, forms__0 any) any {
	var root_1433 any = A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_A_New(); var tmp2 *jrt.Class; var fncls__1531 *jrt.Class = A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_A_fn_class; if fncls__1531 == nil { var fncls__1531d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_A_fn_class = fncls__1531d; tmp2 = fncls__1531d } else { tmp2 = fncls__1531 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_1436 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(forms__0); if linked_1434 == nil { return ifn_1435.Invoke_O__O(arg_1436) } else { return linked_1434.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1433, arg_1436) } }
//line :350:1
func A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_A_New() *A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_A{}; t.Ctor(); return t }
//line :350:1
func (t *A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_A) Ctor() {}
//line :350:1
func (t *A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_A) Invoke_O_O__O(self, s__1050000179__1 any) any { var tmp1 any = A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_A_New_O_O(s__1050000179__1, self); var tmp2 *jrt.Class; var fncls__1530 *jrt.Class = A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_A_fn_class; if fncls__1530 == nil { var fncls__1530d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_A_fn_class = fncls__1530d; tmp2 = fncls__1530d } else { tmp2 = fncls__1530 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :350:1
func A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_A{}; t.Ctor_O_O(p0, p1); return t }
//line :350:1
func (t *A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_A) Ctor_O_O(c__s__1050000179, c__iter__1050000178 any) { t.F_s__1050000179 = c__s__1050000179; t.F_iter__1050000178 = c__iter__1050000178 }
//line :350:1
func (t *A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_A) Invoke_O__O(self any) any { { var s__1050000179__1 any; var t_ any = t.F_s__1050000179; t.F_s__1050000179 = nil; s__1050000179__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1437 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = s__1050000179__1; if linked_1438 == nil { temp__1927000414__auto____2 = ifn_1439.Invoke_O__O(arg_1440) } else { temp__1927000414__auto____2 = linked_1438.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1437, arg_1440) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000179__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1441 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1443 lang.IFn; if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = s__1050000179__3; if linked_1442 == nil { tmp1 = ifn_1443.Invoke_O__O(arg_1444) } else { tmp1 = linked_1442.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1441, arg_1444) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1445 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1447 lang.IFn; if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = s__1050000179__3; if linked_1446 == nil { c__1927001037__auto____4 = ifn_1447.Invoke_O__O(arg_1448) } else { c__1927001037__auto____4 = linked_1446.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1445, arg_1448) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000181__6 any; var root_1449 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1451 lang.IFn; if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1450 == nil { b__1050000181__6 = ifn_1451.Invoke_O__O(arg_1452) } else { b__1050000181__6 = linked_1450.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1449, arg_1452) }; var tmp2 any = A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_fn__1050000184_A_New_O_I_O(b__1050000181__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1474 *jrt.Class = A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_fn__1050000184_A_fn_class; if fncls__1474 == nil { var fncls__1474d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_fn__1050000184_A_fn_class = fncls__1474d; tmp3 = fncls__1474d } else { tmp3 = fncls__1474 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1475 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any; var root_1480 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = b__1050000181__6; if linked_1481 == nil { arg_1478 = ifn_1482.Invoke_O__O(arg_1483) } else { arg_1478 = linked_1481.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1480, arg_1483) }; var arg_1479 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000178); var tmp5 any; var root_1484 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any = s__1050000179__3; if linked_1485 == nil { tmp5 = ifn_1486.Invoke_O__O(arg_1487) } else { tmp5 = linked_1485.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1484, arg_1487) }; arg_1479 = tmp4.Invoke_O__O(tmp5); if linked_1476 == nil { return ifn_1477.Invoke_O_O__O(arg_1478, arg_1479) } else { return linked_1476.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1475, arg_1478, arg_1479) } } else { var root_1488 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_1489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1488, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1490 lang.IFn; if linked_1489 == nil { ifn_1490 = lang.IFn_Cast(root_1488) } else { ifn_1490 = nil }; var arg_1491 any; var root_1493 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = b__1050000181__6; if linked_1494 == nil { arg_1491 = ifn_1495.Invoke_O__O(arg_1496) } else { arg_1491 = linked_1494.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1493, arg_1496) }; var arg_1492 any; if linked_1489 == nil { return ifn_1490.Invoke_O_O__O(arg_1491, arg_1492) } else { return linked_1489.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1488, arg_1491, arg_1492) } } } else { var f__4 any; var root_1497 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = s__1050000179__3; if linked_1498 == nil { f__4 = ifn_1499.Invoke_O__O(arg_1500) } else { f__4 = linked_1498.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1497, arg_1500) }; var tmp6 any; var and__1927000168__auto____5 any; var root_1501 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1503 lang.IFn
															if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = f__4; if linked_1502 == nil { and__1927000168__auto____5 = ifn_1503.Invoke_O__O(arg_1504) } else { and__1927000168__auto____5 = linked_1502.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1501, arg_1504) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var root_1505 any = A_arbace_repr_go_parse_A_const_75.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_238); var tmp8 any; var root_1509 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1509, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = f__4; if linked_1510 == nil { tmp8 = ifn_1511.Invoke_O__O(arg_1512) } else { tmp8 = linked_1510.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1509, arg_1512) }; arg_1508 = tmp7.Invoke_O__O(tmp8); if linked_1506 == nil { tmp6 = ifn_1507.Invoke_O__O(arg_1508) } else { tmp6 = linked_1506.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1505, arg_1508) } } else { tmp6 = and__1927000168__auto____5 }
//line :350:1
	if jrt.J2g_Truth(tmp6) { var root_1513 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any; var root_1518 any = A_arbace_repr_go_parse_A_const_233.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, A_arbace_repr_go_parse_strip_meta_A_fn_class); var ifn_1520 lang.IFn

		if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any = f__4; if linked_1519 == nil { arg_1516 = ifn_1520.Invoke_O__O(arg_1521) } else { arg_1516 = linked_1519.(*A_arbace_repr_go_parse_strip_meta_A).Invoke_O_O__O(root_1518, arg_1521) }
//line :350:1
		var arg_1517 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1050000178); var tmp10 any; var root_1522 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = s__1050000179__3; if linked_1523 == nil { tmp10 = ifn_1524.Invoke_O__O(arg_1525) } else { tmp10 = linked_1523.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1522, arg_1525) }; arg_1517 = tmp9.Invoke_O__O(tmp10); if linked_1514 == nil { return ifn_1515.Invoke_O_O__O(arg_1516, arg_1517) } else { return linked_1514.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1513, arg_1516, arg_1517) } } else { var tmp11 any; var root_1526 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any = s__1050000179__3; if linked_1527 == nil { tmp11 = ifn_1528.Invoke_O__O(arg_1529) } else { tmp11 = linked_1527.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1526, arg_1529) }; s__1050000179__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :350:1
func A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_fn__1050000184_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_fn__1050000184_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_fn__1050000184_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :350:1
func (t *A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_fn__1050000184_A) Ctor_O_I_O(c__b__1050000181 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1050000181 = c__b__1050000181; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :350:1
func (t *A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_fn__1050000184_A) Invoke_O__O(self any) any { { var i__1050000180__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000180__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000180__1)); var tmp2 any; var and__1927000168__auto____3 any; var root_1453 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1455 lang.IFn
																	if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = f__2; if linked_1454 == nil { and__1927000168__auto____3 = ifn_1455.Invoke_O__O(arg_1456) } else { and__1927000168__auto____3 = linked_1454.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1453, arg_1456) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_1457 any = A_arbace_repr_go_parse_A_const_75.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_237); var tmp4 any; var root_1461 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1461, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1463 lang.IFn; if linked_1462 == nil { ifn_1463 = lang.IFn_Cast(root_1461) } else { ifn_1463 = nil }; var arg_1464 any = f__2; if linked_1462 == nil { tmp4 = ifn_1463.Invoke_O__O(arg_1464) } else { tmp4 = linked_1462.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1461, arg_1464) }; arg_1460 = tmp3.Invoke_O__O(tmp4); if linked_1458 == nil { tmp2 = ifn_1459.Invoke_O__O(arg_1460) } else { tmp2 = linked_1458.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1457, arg_1460) } } else { tmp2 = and__1927000168__auto____3 }
//line :350:1
	if jrt.J2g_Truth(tmp2) { var root_1465 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = t.F_b__1050000181; var arg_1469 any; var root_1470 any = A_arbace_repr_go_parse_A_const_233.GetRawRoot__O(); var linked_1471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1470, A_arbace_repr_go_parse_strip_meta_A_fn_class); var ifn_1472 lang.IFn

		if linked_1471 == nil { ifn_1472 = lang.IFn_Cast(root_1470) } else { ifn_1472 = nil }; var arg_1473 any = f__2; if linked_1471 == nil { arg_1469 = ifn_1472.Invoke_O__O(arg_1473) } else { arg_1469 = linked_1471.(*A_arbace_repr_go_parse_strip_meta_A).Invoke_O_O__O(root_1470, arg_1473) }
//line :350:1
		if linked_1466 == nil { ifn_1467.Invoke_O_O__O(arg_1468, arg_1469) } else { linked_1466.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1465, arg_1468, arg_1469) }; i__1050000180__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000180__1); continue L1 } else { i__1050000180__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000180__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_repr_go_parse_forms_check_A_New() *A_arbace_repr_go_parse_forms_check_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_forms_check_A{}; t.Ctor(); return t }
//line :354:1
func (t *A_arbace_repr_go_parse_forms_check_A) Ctor() {}
//line :354:1
func (t *A_arbace_repr_go_parse_forms_check_A) Invoke_O_O__O(self, goroot_forms__0 any) any {




	var root_1532 any = A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var arg_1535 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_A_New_O(goroot_forms__0); var tmp2 *jrt.Class; var fncls__1728 *jrt.Class = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_A_fn_class; if fncls__1728 == nil { var fncls__1728d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_A_fn_class = fncls__1728d; tmp2 = fncls__1728d } else { tmp2 = fncls__1728 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_1535 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(A_arbace_repr_go_parse_A_const_245.GetRawRoot__O()); if linked_1533 == nil { return ifn_1534.Invoke_O__O(arg_1535) } else { return linked_1533.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1532, arg_1535) } }
//line :359:1
func A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_A_New_O(p0 any) *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_A{}; t.Ctor_O(p0); return t }
//line :359:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_A) Ctor_O(c__goroot_forms any) { t.F_goroot_forms = c__goroot_forms }
//line :359:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_A) Invoke_O_O__O(self, s__1050000192__1 any) any { var tmp1 any = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_A_New_O_O_O(s__1050000192__1, self, t.F_goroot_forms); var tmp2 *jrt.Class; var fncls__1727 *jrt.Class = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_A_fn_class; if fncls__1727 == nil { var fncls__1727d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_A_fn_class = fncls__1727d; tmp2 = fncls__1727d } else { tmp2 = fncls__1727 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :359:1
func A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :359:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_A) Ctor_O_O_O(c__s__1050000192, c__iter__1050000191, c__goroot_forms any) { t.F_s__1050000192 = c__s__1050000192; t.F_iter__1050000191 = c__iter__1050000191; t.F_goroot_forms = c__goroot_forms }
//line :359:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_A) Invoke_O__O(self any) any { { var s__1050000192__1 any; var t_ any = t.F_s__1050000192; t.F_s__1050000192 = nil; s__1050000192__1 = t_; for { var temp__1927000414__auto____2 any; var root_1536 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1538 lang.IFn; if linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any = s__1050000192__1; if linked_1537 == nil { temp__1927000414__auto____2 = ifn_1538.Invoke_O__O(arg_1539) } else { temp__1927000414__auto____2 = linked_1537.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1536, arg_1539) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000192__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1540 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1542 lang.IFn; if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any = s__1050000192__3; if linked_1541 == nil { tmp1 = ifn_1542.Invoke_O__O(arg_1543) } else { tmp1 = linked_1541.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1540, arg_1543) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1544 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_1545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1544, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1546 lang.IFn; if linked_1545 == nil { ifn_1546 = lang.IFn_Cast(root_1544) } else { ifn_1546 = nil }; var arg_1547 any = s__1050000192__3; if linked_1545 == nil { c__1927001037__auto____4 = ifn_1546.Invoke_O__O(arg_1547) } else { c__1927001037__auto____4 = linked_1545.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1544, arg_1547) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000194__6 any; var root_1548 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1550 lang.IFn; if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1549 == nil { b__1050000194__6 = ifn_1550.Invoke_O__O(arg_1551) } else { b__1050000194__6 = linked_1549.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1548, arg_1551) }; var tmp2 any = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_A_New_O_O_I_O(b__1050000194__6, t.F_goroot_forms, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1624 *jrt.Class = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_A_fn_class; if fncls__1624 == nil { var fncls__1624d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_A_fn_class = fncls__1624d; tmp3 = fncls__1624d } else { tmp3 = fncls__1624 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1625 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1625, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1627 lang.IFn; if linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any; var root_1630 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_1631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1630, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1632 lang.IFn; if linked_1631 == nil { ifn_1632 = lang.IFn_Cast(root_1630) } else { ifn_1632 = nil }; var arg_1633 any = b__1050000194__6; if linked_1631 == nil { arg_1628 = ifn_1632.Invoke_O__O(arg_1633) } else { arg_1628 = linked_1631.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1630, arg_1633) }; var arg_1629 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000191); var tmp5 any; var root_1634 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_1635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1634, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1636 lang.IFn; if linked_1635 == nil { ifn_1636 = lang.IFn_Cast(root_1634) } else { ifn_1636 = nil }; var arg_1637 any = s__1050000192__3; if linked_1635 == nil { tmp5 = ifn_1636.Invoke_O__O(arg_1637) } else { tmp5 = linked_1635.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1634, arg_1637) }; arg_1629 = tmp4.Invoke_O__O(tmp5); if linked_1626 == nil { return ifn_1627.Invoke_O_O__O(arg_1628, arg_1629) } else { return linked_1626.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1625, arg_1628, arg_1629) } } else { var root_1638 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1640 lang.IFn; if linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any; var root_1643 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_1644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1643, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1645 lang.IFn; if linked_1644 == nil { ifn_1645 = lang.IFn_Cast(root_1643) } else { ifn_1645 = nil }; var arg_1646 any = b__1050000194__6; if linked_1644 == nil { arg_1641 = ifn_1645.Invoke_O__O(arg_1646) } else { arg_1641 = linked_1644.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1643, arg_1646) }; var arg_1642 any; if linked_1639 == nil { return ifn_1640.Invoke_O_O__O(arg_1641, arg_1642) } else { return linked_1639.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1638, arg_1641, arg_1642) } } } else { var p__4 any; var root_1647 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1647, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1649 lang.IFn; if linked_1648 == nil { ifn_1649 = lang.IFn_Cast(root_1647) } else { ifn_1649 = nil }; var arg_1650 any = s__1050000192__3; if linked_1648 == nil { p__4 = ifn_1649.Invoke_O__O(arg_1650) } else { p__4 = linked_1648.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1647, arg_1650) }; var root_1651 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_1652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1651, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1653 lang.IFn; if linked_1652 == nil { ifn_1653 = lang.IFn_Cast(root_1651) } else { ifn_1653 = nil }; var arg_1654 any; var dir__5 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_119, nil), jrt.RefArrayOf(jrt.Object_class, t.F_goroot_forms, nil, p__4)).Ref(); var pkg__6 any; var root_1656 any = A_arbace_repr_go_parse_A_const_14.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, aot_arbace_go_check.A_arbace_go_check_read_string_forms_A_fn_class); var ifn_1658 lang.IFn

	if linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_120), jrt.RefArrayOf(jrt.Object_class, dir__5, nil)).Ref()); if linked_1657 == nil { pkg__6 = ifn_1658.Invoke_O__O(arg_1659) } else { pkg__6 = linked_1657.(*aot_arbace_go_check.A_arbace_go_check_read_string_forms_A).Invoke_O_O__O(root_1656, arg_1659) }
//line :359:1
	var gp__7 any; var root_1664 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1666 lang.IFn


	if linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any; var root_1668 any = A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any; var tmp6 any = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000203_A_New(); var tmp7 *jrt.Class; var fncls__1681 *jrt.Class = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000203_A_fn_class; if fncls__1681 == nil { var fncls__1681d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000203_A_fn_class = fncls__1681d; tmp7 = fncls__1681d } else { tmp7 = fncls__1681 }; arg_1671 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1672 any = pkg__6; if linked_1669 == nil { arg_1667 = ifn_1670.Invoke_O_O__O(arg_1671, arg_1672) } else { arg_1667 = linked_1669.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1668, arg_1671, arg_1672) }; if linked_1665 == nil { gp__7 = ifn_1666.Invoke_O__O(arg_1667) } else { gp__7 = linked_1665.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1664, arg_1667) }
//line :359:1
	var files__8 any; var tmp8 *lang.Keyword = A_arbace_repr_go_parse_A_const_189; var tmp9 any; var root_1682 any = A_arbace_repr_go_parse_A_const_218.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1682, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1684 lang.IFn



	if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any = A_arbace_repr_go_parse_A_const_240.GetRawRoot__O(); var arg_1686 any; var root_1687 any = A_arbace_repr_go_parse_A_const_241.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1687, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_1689 lang.IFn; if linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any = gp__7; if linked_1688 == nil { arg_1686 = ifn_1689.Invoke_O__O(arg_1690) } else { arg_1686 = linked_1688.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_1687, arg_1690) }; if linked_1683 == nil { tmp9 = ifn_1684.Invoke_O_O__O(arg_1685, arg_1686) } else { tmp9 = linked_1683.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1682, arg_1685, arg_1686) }; files__8 = tmp8.Invoke_O__O(tmp9)
//line :359:1
	var ours__9 any; var root_1691 any = A_arbace_repr_go_parse_A_const_242.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, A_arbace_repr_go_parse_decl_forms_A_fn_class); var ifn_1693 lang.IFn




	if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_152.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000205_A_New_O(dir__5); var tmp12 *jrt.Class; var fncls__1714 *jrt.Class = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000205_A_fn_class; if fncls__1714 == nil { var fncls__1714d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000205_A_fn_class = fncls__1714d; tmp12 = fncls__1714d } else { tmp12 = fncls__1714 }; arg_1694 = tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), files__8); if linked_1692 == nil { ours__9 = ifn_1693.Invoke_O__O(arg_1694) } else { ours__9 = linked_1692.(*A_arbace_repr_go_parse_decl_forms_A).Invoke_O_O__O(root_1691, arg_1694) }
//line :359:1
	var digest__10 any; var root_1715 any = A_arbace_repr_go_parse_A_const_242.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, A_arbace_repr_go_parse_decl_forms_A_fn_class); var ifn_1717 lang.IFn





	if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any; var root_1719 any = A_arbace_repr_go_parse_A_const_244.GetRawRoot__O(); var linked_1720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1719, aot_arbace_go_repl.A_arbace_go_repl_digest_forms_A_fn_class); var ifn_1721 lang.IFn; if linked_1720 == nil { ifn_1721 = lang.IFn_Cast(root_1719) } else { ifn_1721 = nil }; var arg_1722 any = p__4; if linked_1720 == nil { arg_1718 = ifn_1721.Invoke_O__O(arg_1722) } else { arg_1718 = linked_1720.(*aot_arbace_go_repl.A_arbace_go_repl_digest_forms_A).Invoke_O_O__O(root_1719, arg_1722) }; if linked_1716 == nil { digest__10 = ifn_1717.Invoke_O__O(arg_1718) } else { digest__10 = linked_1716.(*A_arbace_repr_go_parse_decl_forms_A).Invoke_O_O__O(root_1715, arg_1718) }
//line :359:1
	arg_1654 = lang.Tuple_Create_O_O_O__IPersistentVector(p__4, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ours__9)).Ref(), jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(ours__9, digest__10)).Ref()); var arg_1655 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__1050000191); var tmp14 any; var root_1723 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = s__1050000192__3; if linked_1724 == nil { tmp14 = ifn_1725.Invoke_O__O(arg_1726) } else { tmp14 = linked_1724.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1723, arg_1726) }; arg_1655 = tmp13.Invoke_O__O(tmp14); if linked_1652 == nil { return ifn_1653.Invoke_O_O__O(arg_1654, arg_1655) } else { return linked_1652.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1651, arg_1654, arg_1655) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :359:1
func A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :359:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_A) Ctor_O_O_I_O(c__b__1050000194, c__goroot_forms any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1050000194 = c__b__1050000194; t.F_goroot_forms = c__goroot_forms; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :359:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_A) Invoke_O__O(self any) any { { var i__1050000193__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000193__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000193__1)); var root_1552 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = t.F_b__1050000194; var arg_1556 any; var dir__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_119, nil), jrt.RefArrayOf(jrt.Object_class, t.F_goroot_forms, nil, p__2)).Ref(); var pkg__4 any; var root_1557 any = A_arbace_repr_go_parse_A_const_14.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_go_check.A_arbace_go_check_read_string_forms_A_fn_class); var ifn_1559 lang.IFn

	if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_15.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_120), jrt.RefArrayOf(jrt.Object_class, dir__3, nil)).Ref()); if linked_1558 == nil { pkg__4 = ifn_1559.Invoke_O__O(arg_1560) } else { pkg__4 = linked_1558.(*aot_arbace_go_check.A_arbace_go_check_read_string_forms_A).Invoke_O_O__O(root_1557, arg_1560) }
//line :359:1
	var gp__5 any; var root_1565 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1567 lang.IFn


	if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any; var root_1569 any = A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_1570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1569, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1571 lang.IFn; if linked_1570 == nil { ifn_1571 = lang.IFn_Cast(root_1569) } else { ifn_1571 = nil }; var arg_1572 any; var tmp2 any = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000198_A_New(); var tmp3 *jrt.Class; var fncls__1582 *jrt.Class = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000198_A_fn_class; if fncls__1582 == nil { var fncls__1582d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000198_A_fn_class = fncls__1582d; tmp3 = fncls__1582d } else { tmp3 = fncls__1582 }; arg_1572 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1573 any = pkg__4; if linked_1570 == nil { arg_1568 = ifn_1571.Invoke_O_O__O(arg_1572, arg_1573) } else { arg_1568 = linked_1570.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1569, arg_1572, arg_1573) }; if linked_1566 == nil { gp__5 = ifn_1567.Invoke_O__O(arg_1568) } else { gp__5 = linked_1566.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1565, arg_1568) }
//line :359:1
	var files__6 any; var tmp4 *lang.Keyword = A_arbace_repr_go_parse_A_const_189; var tmp5 any; var root_1583 any = A_arbace_repr_go_parse_A_const_218.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1585 lang.IFn



	if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = A_arbace_repr_go_parse_A_const_240.GetRawRoot__O(); var arg_1587 any; var root_1588 any = A_arbace_repr_go_parse_A_const_241.GetRawRoot__O(); var linked_1589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1588, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_1590 lang.IFn; if linked_1589 == nil { ifn_1590 = lang.IFn_Cast(root_1588) } else { ifn_1590 = nil }; var arg_1591 any = gp__5; if linked_1589 == nil { arg_1587 = ifn_1590.Invoke_O__O(arg_1591) } else { arg_1587 = linked_1589.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_1588, arg_1591) }; if linked_1584 == nil { tmp5 = ifn_1585.Invoke_O_O__O(arg_1586, arg_1587) } else { tmp5 = linked_1584.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1583, arg_1586, arg_1587) }; files__6 = tmp4.Invoke_O__O(tmp5)
//line :359:1
	var ours__7 any; var root_1592 any = A_arbace_repr_go_parse_A_const_242.GetRawRoot__O(); var linked_1593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1592, A_arbace_repr_go_parse_decl_forms_A_fn_class); var ifn_1594 lang.IFn




	if linked_1593 == nil { ifn_1594 = lang.IFn_Cast(root_1592) } else { ifn_1594 = nil }; var arg_1595 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_152.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000200_A_New_O(dir__3); var tmp8 *jrt.Class; var fncls__1615 *jrt.Class = A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000200_A_fn_class; if fncls__1615 == nil { var fncls__1615d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000200_A_fn_class = fncls__1615d; tmp8 = fncls__1615d } else { tmp8 = fncls__1615 }; arg_1595 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), files__6); if linked_1593 == nil { ours__7 = ifn_1594.Invoke_O__O(arg_1595) } else { ours__7 = linked_1593.(*A_arbace_repr_go_parse_decl_forms_A).Invoke_O_O__O(root_1592, arg_1595) }
//line :359:1
	var digest__8 any; var root_1616 any = A_arbace_repr_go_parse_A_const_242.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1616, A_arbace_repr_go_parse_decl_forms_A_fn_class); var ifn_1618 lang.IFn





	if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any; var root_1620 any = A_arbace_repr_go_parse_A_const_244.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_go_repl.A_arbace_go_repl_digest_forms_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = p__2; if linked_1621 == nil { arg_1619 = ifn_1622.Invoke_O__O(arg_1623) } else { arg_1619 = linked_1621.(*aot_arbace_go_repl.A_arbace_go_repl_digest_forms_A).Invoke_O_O__O(root_1620, arg_1623) }; if linked_1617 == nil { digest__8 = ifn_1618.Invoke_O__O(arg_1619) } else { digest__8 = linked_1617.(*A_arbace_repr_go_parse_decl_forms_A).Invoke_O_O__O(root_1616, arg_1619) }
//line :359:1
	arg_1556 = lang.Tuple_Create_O_O_O__IPersistentVector(p__2, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ours__7)).Ref(), jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(ours__7, digest__8)).Ref()); if linked_1553 == nil { ifn_1554.Invoke_O_O__O(arg_1555, arg_1556) } else { linked_1553.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1552, arg_1555, arg_1556) }; i__1050000193__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000193__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000198_A_New() *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000198_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000198_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000198_A) Ctor() {}
//line :362:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000198_A) Invoke_O_O__O(self, p1__1050000189_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1574 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1576 lang.IFn; if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any = p1__1050000189_SHARP___1; if linked_1575 == nil { and__1927000168__auto____2 = ifn_1576.Invoke_O__O(arg_1577) } else { and__1927000168__auto____2 = linked_1575.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1574, arg_1577) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_repr_go_parse_A_const_239; var tmp2 any; var root_1578 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1578, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1580 lang.IFn; if linked_1579 == nil { ifn_1580 = lang.IFn_Cast(root_1578) } else { ifn_1580 = nil }; var arg_1581 any = p1__1050000189_SHARP___1; if linked_1579 == nil { tmp2 = ifn_1580.Invoke_O__O(arg_1581) } else { tmp2 = linked_1579.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1578, arg_1581) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }
//line :362:1
func A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000203_A_New() *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000203_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000203_A{}; t.Ctor(); return t }
//line :362:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000203_A) Ctor() {}
//line :362:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000203_A) Invoke_O_O__O(self, p1__1050000189_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_1673 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1675 lang.IFn; if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any = p1__1050000189_SHARP___1; if linked_1674 == nil { and__1927000168__auto____2 = ifn_1675.Invoke_O__O(arg_1676) } else { and__1927000168__auto____2 = linked_1674.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1673, arg_1676) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_repr_go_parse_A_const_239; var tmp2 any; var root_1677 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1677, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1679 lang.IFn; if linked_1678 == nil { ifn_1679 = lang.IFn_Cast(root_1677) } else { ifn_1679 = nil }; var arg_1680 any = p1__1050000189_SHARP___1; if linked_1678 == nil { tmp2 = ifn_1679.Invoke_O__O(arg_1680) } else { tmp2 = linked_1678.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1677, arg_1680) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }

func A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000200_A_New_O(p0 any) *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000200_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000200_A{}; t.Ctor_O(p0); return t }
//line :364:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000200_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :364:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000200_A) Invoke_O_O__O(self, p1__1050000190_SHARP___1 any) any { var root_1601 any = A_arbace_repr_go_parse_A_const_14.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, aot_arbace_go_check.A_arbace_go_check_read_string_forms_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_15.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_72, nil); var tmp3 any = t.F_dir; var tmp4 any; var root_1609 any = A_arbace_repr_go_parse_A_const_42.GetRawRoot__O(); var linked_1610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1609, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1611 lang.IFn; if linked_1610 == nil { ifn_1611 = lang.IFn_Cast(root_1609) } else { ifn_1611 = nil }; var arg_1612 any = p1__1050000190_SHARP___1; var arg_1613 any = A_arbace_repr_go_parse_A_const_243; var arg_1614 any = Lit_120; if linked_1610 == nil { tmp4 = ifn_1611.Invoke_O_O_O__O(arg_1612, arg_1613, arg_1614) } else { tmp4 = linked_1610.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1609, arg_1612, arg_1613, arg_1614) }; arg_1604 = tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref()); if linked_1602 == nil { return ifn_1603.Invoke_O__O(arg_1604) } else { return linked_1602.(*aot_arbace_go_check.A_arbace_go_check_read_string_forms_A).Invoke_O_O__O(root_1601, arg_1604) } }
//line :364:1
func A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000205_A_New_O(p0 any) *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000205_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000205_A{}; t.Ctor_O(p0); return t }
//line :364:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000205_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :364:1
func (t *A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000205_A) Invoke_O_O__O(self, p1__1050000190_SHARP___1 any) any { var root_1700 any = A_arbace_repr_go_parse_A_const_14.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_go_check.A_arbace_go_check_read_string_forms_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_15.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_72, nil); var tmp3 any = t.F_dir; var tmp4 any; var root_1708 any = A_arbace_repr_go_parse_A_const_42.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any = p1__1050000190_SHARP___1; var arg_1712 any = A_arbace_repr_go_parse_A_const_243; var arg_1713 any = Lit_120; if linked_1709 == nil { tmp4 = ifn_1710.Invoke_O_O_O__O(arg_1711, arg_1712, arg_1713) } else { tmp4 = linked_1709.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_1708, arg_1711, arg_1712, arg_1713) }; arg_1703 = tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, tmp4)).Ref()); if linked_1701 == nil { return ifn_1702.Invoke_O__O(arg_1703) } else { return linked_1701.(*aot_arbace_go_check.A_arbace_go_check_read_string_forms_A).Invoke_O_O__O(root_1700, arg_1703) } }














func A_arbace_repr_go_parse_native_dump_A_New() *A_arbace_repr_go_parse_native_dump_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_native_dump_A{}; t.Ctor(); return t }
//line :379:1
func (t *A_arbace_repr_go_parse_native_dump_A) Ctor() {}
//line :379:1
func (t *A_arbace_repr_go_parse_native_dump_A) Invoke_O_O_O__O(self, goroot_forms__0, j__1 any) any { var dir__3 any = A_arbace_repr_go_parse_A_const_246.Invoke_O__O(j__1); var lang__4 any; var root_1729 any = A_arbace_repr_go_parse_A_const_247.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_1731 lang.IFn; if






	linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = j__1; var arg_1733 any = A_arbace_repr_go_parse_A_const_248; if linked_1730 == nil { lang__4 = ifn_1731.Invoke_O_O__O(arg_1732, arg_1733) } else { lang__4 = linked_1730.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_1729, arg_1732, arg_1733) }; var rs__5 any; var iter__1927001039__auto____5 any; var tmp1 any = /*line :379:1*/A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_A_New_O_O(dir__3, goroot_forms__0); var tmp2 *jrt.Class; var fncls__1818 *jrt.Class = A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_A_fn_class; if







	fncls__1818 == nil { var fncls__1818d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_A_fn_class = fncls__1818d; tmp2 = fncls__1818d } else { tmp2 = fncls__1818 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); rs__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_repr_go_parse_A_const_189.Invoke_O__O(j__1)); var temp__1927000408__auto____6 any; var root_1819 any = /*line :379:1*/A_arbace_repr_go_parse_A_const_138.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1821 lang.IFn; if










	linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any; var tmp3 any = A_arbace_repr_go_parse_native_dump_fn__1050000223_A_New(); var tmp4 *jrt.Class; var fncls__1824 *jrt.Class = A_arbace_repr_go_parse_native_dump_fn__1050000223_A_fn_class; if fncls__1824 == nil { var fncls__1824d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_repr_go_parse_native_dump_fn__1050000223_A_fn_class = fncls__1824d; tmp4 = fncls__1824d } else { tmp4 = fncls__1824 }; arg_1822 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1823 any = rs__5; if linked_1820 == nil { temp__1927000408__auto____6 = ifn_1821.Invoke_O_O__O(arg_1822, arg_1823) } else { temp__1927000408__auto____6 = linked_1820.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1819, arg_1822, arg_1823) }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var e__7 any = temp__1927000408__auto____6; var tmp5 any = A_arbace_repr_go_parse_A_const_226; var tmp6 any = A_arbace_repr_go_parse_A_const_226.Invoke_O__O(e__7); var tmp7 any = A_arbace_repr_go_parse_A_const_201; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, A_arbace_repr_go_parse_A_const_201.Invoke_O__O(e__7))) } else { var warns__7 any; var root_1825 any = A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_1826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1825, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1827 lang.IFn

		if linked_1826 == nil { ifn_1827 = lang.IFn_Cast(root_1825) } else { ifn_1827 = nil }; var arg_1828 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_152.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_230, rs__5); if linked_1826 == nil { warns__7 = ifn_1827.Invoke_O__O(arg_1828) } else { warns__7 = linked_1826.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1825, arg_1828) }
//line :390:1
		var nm__8 any; var or__1927000174__auto____8 any; var root_1834 any = A_arbace_repr_go_parse_A_const_138.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1834, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1836 lang.IFn




		if linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; var arg_1837 any; var tmp8 any = A_arbace_repr_go_parse_native_dump_fn__1050000225_A_New(); var tmp9 *jrt.Class; var fncls__1852 *jrt.Class = A_arbace_repr_go_parse_native_dump_fn__1050000225_A_fn_class; if fncls__1852 == nil { var fncls__1852d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_repr_go_parse_native_dump_fn__1050000225_A_fn_class = fncls__1852d; tmp9 = fncls__1852d } else { tmp9 = fncls__1852 }; arg_1837 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_1838 any = rs__5; if linked_1835 == nil { or__1927000174__auto____8 = ifn_1836.Invoke_O_O__O(arg_1837, arg_1838) } else { or__1927000174__auto____8 = linked_1835.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1834, arg_1837, arg_1838) }; if jrt.J2g_Truth(or__1927000174__auto____8) { nm__8 = or__1927000174__auto____8 } else { nm__8 = Lit_11 }
//line :390:1
		var G__1050000227__9_ any; var root_1853 any = A_arbace_repr_go_parse_A_const_251.GetRawRoot__O(); var linked_1854 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1853, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_1855 lang.IFn





		if linked_1854 == nil { ifn_1855 = lang.IFn_Cast(root_1853) } else { ifn_1855 = nil }; var arg_1856 any = A_arbace_repr_go_parse_A_const_252; var arg_1857 any = A_arbace_repr_go_parse_A_const_253.Invoke_O__O(j__1); if linked_1854 == nil { G__1050000227__9_ = ifn_1855.Invoke_O_O__O(arg_1856, arg_1857) } else { G__1050000227__9_ = linked_1854.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_1853, arg_1856, arg_1857) }
//line :390:1
		var G__1050000227__10_ any





		if jrt.J2g_Truth(jrt.Boolean_TRUE.Ref()) {
			var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_196.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_parse_A_const_73; var tmp12 any = A_arbace_repr_go_parse_A_const_189; var tmp13 any; var root_1868 any = A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_1869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1868, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1870 lang.IFn
			if linked_1869 == nil { ifn_1870 = lang.IFn_Cast(root_1868) } else { ifn_1870 = nil }; var arg_1871 any; var iter__1927001039__auto____10 any; var tmp14 any = A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_A_New_O(lang__4); var tmp15 *jrt.Class; var fncls__1986 *jrt.Class = A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_A_fn_class; if fncls__1986 == nil { var fncls__1986d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_A_fn_class = fncls__1986d; tmp15 = fncls__1986d } else { tmp15 = fncls__1986 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); arg_1871 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(rs__5); if linked_1869 == nil { tmp13 = ifn_1870.Invoke_O__O(arg_1871) } else { tmp13 = linked_1869.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1868, arg_1871) }
//line :397:1
			var tmp16 any = tmp13; var tmp17 any = A_arbace_repr_go_parse_A_const_229; var tmp18 any; var root_1987 any = A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1987, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1989 lang.IFn





			if linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; var arg_1990 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_152.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_229, rs__5); if linked_1988 == nil { tmp18 = ifn_1989.Invoke_O__O(arg_1990) } else { tmp18 = linked_1988.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1987, arg_1990) }
//line :397:1
			G__1050000227__10_ = tmp10.Invoke_O_O_O_O_O_O_O__O(G__1050000227__9_, tmp11, nm__8, tmp12, tmp16, tmp17, tmp18) } else {
//line :396:1
				G__1050000227__10_ = G__1050000227__9_ }
//line :390:1
		var G__1050000227__11_ any; var tmp19 any; var root_1996 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_1997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1996, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1998 lang.IFn













		if linked_1997 == nil { ifn_1998 = lang.IFn_Cast(root_1996) } else { ifn_1998 = nil }; var arg_1999 any = warns__7; if linked_1997 == nil { tmp19 = ifn_1998.Invoke_O__O(arg_1999) } else { tmp19 = linked_1997.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1996, arg_1999) }
//line :396:1
		if jrt.J2g_Truth(tmp19) {







			var root_2000 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2000, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2002 lang.IFn; if linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any = G__1050000227__10_; var arg_2004 any = A_arbace_repr_go_parse_A_const_230; var arg_2005 any = warns__7; if linked_2001 == nil { G__1050000227__11_ = ifn_2002.Invoke_O_O_O__O(arg_2003, arg_2004, arg_2005) } else { G__1050000227__11_ = linked_2001.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2000, arg_2003, arg_2004, arg_2005) } } else {
//line :396:1
				G__1050000227__11_ = G__1050000227__10_ }; if jrt.J2g_Truth(jrt.Boolean_TRUE.Ref()) {








					var root_2006 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_2007 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2006, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2008 lang.IFn; if linked_2007 == nil { ifn_2008 = lang.IFn_Cast(root_2006) } else { ifn_2008 = nil }; var arg_2009 any = G__1050000227__11_; var arg_2010 any = A_arbace_repr_go_parse_A_const_256; var arg_2011 any; var tmp20 any = A_arbace_repr_go_parse_A_const_231; var tmp21 any; var root_2012 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_2013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2012, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2014 lang.IFn; if linked_2013 == nil { ifn_2014 = lang.IFn_Cast(root_2012) } else { ifn_2014 = nil }; var arg_2015 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_2016 any; var root_2017 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_2018 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2017, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2019 lang.IFn; if linked_2018 == nil { ifn_2019 = lang.IFn_Cast(root_2017) } else { ifn_2019 = nil }; var arg_2020 any = A_arbace_repr_go_parse_A_const_231; var arg_2021 any = rs__5; if linked_2018 == nil { arg_2016 = ifn_2019.Invoke_O_O__O(arg_2020, arg_2021) } else { arg_2016 = linked_2018.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2017, arg_2020, arg_2021) }; if linked_2013 == nil { tmp21 = ifn_2014.Invoke_O_O__O(arg_2015, arg_2016) } else { tmp21 = linked_2013.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_2012, arg_2015, arg_2016) }; var tmp22 any = tmp21; var tmp23 any = A_arbace_repr_go_parse_A_const_232; var tmp24 any; var root_2022 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_2023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2022, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2024 lang.IFn
					if linked_2023 == nil { ifn_2024 = lang.IFn_Cast(root_2022) } else { ifn_2024 = nil }; var arg_2025 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_2026 any; var root_2027 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2027, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2029 lang.IFn; if linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any = A_arbace_repr_go_parse_A_const_232; var arg_2031 any = rs__5; if linked_2028 == nil { arg_2026 = ifn_2029.Invoke_O_O__O(arg_2030, arg_2031) } else { arg_2026 = linked_2028.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2027, arg_2030, arg_2031) }; if linked_2023 == nil { tmp24 = ifn_2024.Invoke_O_O__O(arg_2025, arg_2026) } else { tmp24 = linked_2023.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_2022, arg_2025, arg_2026) }
//line :405:1
					var tmp25 any = tmp24; var tmp26 any = A_arbace_repr_go_parse_A_const_259; var tmp27 any; var root_2032 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_2034 lang.IFn

					if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_2036 any; var root_2037 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2037, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2039 lang.IFn; if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any; var tmp28 any = A_arbace_repr_go_parse_native_dump_fn__1050000240_A_New(); var tmp29 *jrt.Class; var fncls__2042 *jrt.Class = A_arbace_repr_go_parse_native_dump_fn__1050000240_A_fn_class; if fncls__2042 == nil { var fncls__2042d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_repr_go_parse_native_dump_fn__1050000240_A_fn_class = fncls__2042d; tmp29 = fncls__2042d } else { tmp29 = fncls__2042 }; arg_2040 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_2041 any = rs__5; if linked_2038 == nil { arg_2036 = ifn_2039.Invoke_O_O__O(arg_2040, arg_2041) } else { arg_2036 = linked_2038.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2037, arg_2040, arg_2041) }; if linked_2033 == nil { tmp27 = ifn_2034.Invoke_O_O__O(arg_2035, arg_2036) } else { tmp27 = linked_2033.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_2032, arg_2035, arg_2036) }
//line :405:1
					arg_2011 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp22, tmp23, tmp25, tmp26, tmp27)); if linked_2007 == nil { return ifn_2008.Invoke_O_O_O__O(arg_2009, arg_2010, arg_2011) } else { return linked_2007.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2006, arg_2009, arg_2010, arg_2011) } } else {
//line :396:1
						return G__1050000227__11_ } } }
//line :387:1
func A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_A{}; t.Ctor_O_O(p0, p1); return t }
//line :387:1
func (t *A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_A) Ctor_O_O(c__dir, c__goroot_forms any) { t.F_dir = c__dir; t.F_goroot_forms = c__goroot_forms }
//line :387:1
func (t *A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_A) Invoke_O_O__O(self, s__1050000214__1 any) any { var tmp1 any = A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_A_New_O_O_O_O(t.F_dir, s__1050000214__1, self, t.F_goroot_forms); var tmp2 *jrt.Class; var fncls__1817 *jrt.Class = A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_A_fn_class; if fncls__1817 == nil { var fncls__1817d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_A_fn_class = fncls__1817d; tmp2 = fncls__1817d } else { tmp2 = fncls__1817 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :387:1
func A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :387:1
func (t *A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_A) Ctor_O_O_O_O(c__dir, c__s__1050000214, c__iter__1050000213, c__goroot_forms any) { t.F_dir = c__dir; t.F_s__1050000214 = c__s__1050000214; t.F_iter__1050000213 = c__iter__1050000213; t.F_goroot_forms = c__goroot_forms }
//line :387:1
func (t *A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_A) Invoke_O__O(self any) any { { var s__1050000214__1 any; var t_ any = t.F_s__1050000214; t.F_s__1050000214 = nil; s__1050000214__1 = t_; for { var temp__1927000414__auto____2 any; var root_1734 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_1735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1734, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1736 lang.IFn; if linked_1735 == nil { ifn_1736 = lang.IFn_Cast(root_1734) } else { ifn_1736 = nil }; var arg_1737 any = s__1050000214__1; if linked_1735 == nil { temp__1927000414__auto____2 = ifn_1736.Invoke_O__O(arg_1737) } else { temp__1927000414__auto____2 = linked_1735.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1734, arg_1737) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000214__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1738 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = s__1050000214__3; if linked_1739 == nil { tmp1 = ifn_1740.Invoke_O__O(arg_1741) } else { tmp1 = linked_1739.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1738, arg_1741) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1742 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = s__1050000214__3; if linked_1743 == nil { c__1927001037__auto____4 = ifn_1744.Invoke_O__O(arg_1745) } else { c__1927001037__auto____4 = linked_1743.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1742, arg_1745) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000216__6 any; var root_1746 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1748 lang.IFn; if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1747 == nil { b__1050000216__6 = ifn_1748.Invoke_O__O(arg_1749) } else { b__1050000216__6 = linked_1747.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1746, arg_1749) }; var tmp2 any = A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_fn__1050000219_A_New_O_O_I_O_O(t.F_dir, t.F_goroot_forms, size__1927001038__auto____5, b__1050000216__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1768 *jrt.Class = A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_fn__1050000219_A_fn_class; if fncls__1768 == nil { var fncls__1768d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_fn__1050000219_A_fn_class = fncls__1768d; tmp3 = fncls__1768d } else { tmp3 = fncls__1768 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1769 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1771 lang.IFn; if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any; var root_1774 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1776 lang.IFn; if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any = b__1050000216__6; if linked_1775 == nil { arg_1772 = ifn_1776.Invoke_O__O(arg_1777) } else { arg_1772 = linked_1775.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1774, arg_1777) }; var arg_1773 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000213); var tmp5 any; var root_1778 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1780 lang.IFn; if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; var arg_1781 any = s__1050000214__3; if linked_1779 == nil { tmp5 = ifn_1780.Invoke_O__O(arg_1781) } else { tmp5 = linked_1779.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1778, arg_1781) }; arg_1773 = tmp4.Invoke_O__O(tmp5); if linked_1770 == nil { return ifn_1771.Invoke_O_O__O(arg_1772, arg_1773) } else { return linked_1770.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1769, arg_1772, arg_1773) } } else { var root_1782 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_1783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1782, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1784 lang.IFn; if linked_1783 == nil { ifn_1784 = lang.IFn_Cast(root_1782) } else { ifn_1784 = nil }; var arg_1785 any; var root_1787 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = b__1050000216__6; if linked_1788 == nil { arg_1785 = ifn_1789.Invoke_O__O(arg_1790) } else { arg_1785 = linked_1788.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1787, arg_1790) }; var arg_1786 any; if linked_1783 == nil { return ifn_1784.Invoke_O_O__O(arg_1785, arg_1786) } else { return linked_1783.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1782, arg_1785, arg_1786) } } } else { var f__4 any; var root_1791 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = s__1050000214__3; if linked_1792 == nil { f__4 = ifn_1793.Invoke_O__O(arg_1794) } else { f__4 = linked_1792.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1791, arg_1794) }; var root_1795 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1795, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1797 lang.IFn; if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any; var path__5 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, t.F_dir, nil, f__4)).Ref(); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_196.GetRawRoot__O()); var tmp7 any; var root_1808 any = A_arbace_repr_go_parse_A_const_249.GetRawRoot__O(); var linked_1809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1808, A_arbace_repr_go_parse_parse_file_A_fn_class); var ifn_1810 lang.IFn

	if linked_1809 == nil { ifn_1810 = lang.IFn_Cast(root_1808) } else { ifn_1810 = nil }; var arg_1811 any = t.F_goroot_forms; var arg_1812 any = path__5; if linked_1809 == nil { tmp7 = ifn_1810.Invoke_O_O__O(arg_1811, arg_1812) } else { tmp7 = linked_1809.(*A_arbace_repr_go_parse_parse_file_A).Invoke_O_O_O__O(root_1808, arg_1811, arg_1812) }; arg_1798 = tmp6.Invoke_O_O_O_O_O__O(tmp7, A_arbace_repr_go_parse_A_const_201, f__4, A_arbace_repr_go_parse_A_const_184, path__5)
//line :387:1
	var arg_1799 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1050000213); var tmp9 any; var root_1813 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = s__1050000214__3; if linked_1814 == nil { tmp9 = ifn_1815.Invoke_O__O(arg_1816) } else { tmp9 = linked_1814.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1813, arg_1816) }; arg_1799 = tmp8.Invoke_O__O(tmp9); if linked_1796 == nil { return ifn_1797.Invoke_O_O__O(arg_1798, arg_1799) } else { return linked_1796.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1795, arg_1798, arg_1799) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :387:1
func A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_fn__1050000219_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_fn__1050000219_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_fn__1050000219_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :387:1
func (t *A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_fn__1050000219_A) Ctor_O_O_I_O_O(c__dir, c__goroot_forms any, c__size__1927001038__auto__ int32, c__b__1050000216, c__c__1927001037__auto__ any) { t.F_dir = c__dir; t.F_goroot_forms = c__goroot_forms; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1050000216 = c__b__1050000216; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :387:1
func (t *A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_fn__1050000219_A) Invoke_O__O(self any) any { { var i__1050000215__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000215__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000215__1)); var root_1750 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_1751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1750, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1752 lang.IFn; if linked_1751 == nil { ifn_1752 = lang.IFn_Cast(root_1750) } else { ifn_1752 = nil }; var arg_1753 any = t.F_b__1050000216; var arg_1754 any; var path__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, t.F_dir, nil, f__2)).Ref(); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_196.GetRawRoot__O()); var tmp3 any; var root_1763 any = A_arbace_repr_go_parse_A_const_249.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1763, A_arbace_repr_go_parse_parse_file_A_fn_class); var ifn_1765 lang.IFn

	if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any = t.F_goroot_forms; var arg_1767 any = path__3; if linked_1764 == nil { tmp3 = ifn_1765.Invoke_O_O__O(arg_1766, arg_1767) } else { tmp3 = linked_1764.(*A_arbace_repr_go_parse_parse_file_A).Invoke_O_O_O__O(root_1763, arg_1766, arg_1767) }; arg_1754 = tmp2.Invoke_O_O_O_O_O__O(tmp3, A_arbace_repr_go_parse_A_const_201, f__2, A_arbace_repr_go_parse_A_const_184, path__3)
//line :387:1
	if linked_1751 == nil { ifn_1752.Invoke_O_O__O(arg_1753, arg_1754) } else { linked_1751.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1750, arg_1753, arg_1754) }; i__1050000215__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000215__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_repr_go_parse_native_dump_fn__1050000223_A_New() *A_arbace_repr_go_parse_native_dump_fn__1050000223_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_native_dump_fn__1050000223_A{}; t.Ctor(); return t }
//line :390:1
func (t *A_arbace_repr_go_parse_native_dump_fn__1050000223_A) Ctor() {}
//line :390:1
func (t *A_arbace_repr_go_parse_native_dump_fn__1050000223_A) Invoke_O_O__O(self, p1__1050000210_SHARP___1 any) any { if jrt.J2g_Truth(A_arbace_repr_go_parse_A_const_226.Invoke_O__O(p1__1050000210_SHARP___1)) { return p1__1050000210_SHARP___1 } else { return nil } }




func A_arbace_repr_go_parse_native_dump_fn__1050000225_A_New() *A_arbace_repr_go_parse_native_dump_fn__1050000225_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_native_dump_fn__1050000225_A{}; t.Ctor(); return t }
//line :395:1
func (t *A_arbace_repr_go_parse_native_dump_fn__1050000225_A) Ctor() {}
//line :395:1
func (t *A_arbace_repr_go_parse_native_dump_fn__1050000225_A) Invoke_O_O__O(self, p1__1050000211_SHARP___1 any) any { var n__2 any; var tmp1 *lang.Keyword = A_arbace_repr_go_parse_A_const_73; var tmp2 any; var root_1839 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_1840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1839, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1841 lang.IFn; if linked_1840 == nil { ifn_1841 = lang.IFn_Cast(root_1839) } else { ifn_1841 = nil }; var arg_1842 any; var tmp3 *lang.Keyword = A_arbace_repr_go_parse_A_const_73; var tmp4 any; var root_1843 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_1844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1843, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1845 lang.IFn; if linked_1844 == nil { ifn_1845 = lang.IFn_Cast(root_1843) } else { ifn_1845 = nil }; var arg_1846 any = A_arbace_repr_go_parse_A_const_227.Invoke_O__O(p1__1050000211_SHARP___1); if linked_1844 == nil { tmp4 = ifn_1845.Invoke_O__O(arg_1846) } else { tmp4 = linked_1844.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1843, arg_1846) }; arg_1842 = tmp3.Invoke_O__O(tmp4); if linked_1840 == nil { tmp2 = ifn_1841.Invoke_O__O(arg_1842) } else { tmp2 = linked_1840.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1839, arg_1842) }; n__2 = tmp1.Invoke_O__O(tmp2); var tmp5 any; var root_1847 any = A_arbace_repr_go_parse_A_const_250.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1849 lang.IFn; if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any = Lit_138; var arg_1851 any = n__2; if linked_1848 == nil { tmp5 = ifn_1849.Invoke_O_O__O(arg_1850, arg_1851) } else { tmp5 = linked_1848.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1847, arg_1850, arg_1851) }; if jrt.J2g_Truth(tmp5) { return n__2 } else { return nil } }


func A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_A_New_O(p0 any) *A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_A{}; t.Ctor_O(p0); return t }
//line :398:1
func (t *A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_A) Ctor_O(c__lang any) { t.F_lang = c__lang }
//line :398:1
func (t *A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_A) Invoke_O_O__O(self, s__1050000229__1 any) any { var tmp1 any = A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_A_New_O_O_O(t.F_lang, s__1050000229__1, self); var tmp2 *jrt.Class; var fncls__1985 *jrt.Class = A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_A_fn_class; if fncls__1985 == nil { var fncls__1985d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_A_fn_class = fncls__1985d; tmp2 = fncls__1985d } else { tmp2 = fncls__1985 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :398:1
func A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :398:1
func (t *A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_A) Ctor_O_O_O(c__lang, c__s__1050000229, c__iter__1050000228 any) { t.F_lang = c__lang; t.F_s__1050000229 = c__s__1050000229; t.F_iter__1050000228 = c__iter__1050000228 }
//line :398:1
func (t *A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_A) Invoke_O__O(self any) any { { var s__1050000229__1 any; var t_ any = t.F_s__1050000229; t.F_s__1050000229 = nil; s__1050000229__1 = t_; for { var temp__1927000414__auto____2 any; var root_1872 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1874 lang.IFn; if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = s__1050000229__1; if linked_1873 == nil { temp__1927000414__auto____2 = ifn_1874.Invoke_O__O(arg_1875) } else { temp__1927000414__auto____2 = linked_1873.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1872, arg_1875) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000229__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1876 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1878 lang.IFn; if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any = s__1050000229__3; if linked_1877 == nil { tmp1 = ifn_1878.Invoke_O__O(arg_1879) } else { tmp1 = linked_1877.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1876, arg_1879) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1880 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1882 lang.IFn; if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = s__1050000229__3; if linked_1881 == nil { c__1927001037__auto____4 = ifn_1882.Invoke_O__O(arg_1883) } else { c__1927001037__auto____4 = linked_1881.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1880, arg_1883) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000231__6 any; var root_1884 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_1885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1884, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1886 lang.IFn; if linked_1885 == nil { ifn_1886 = lang.IFn_Cast(root_1884) } else { ifn_1886 = nil }; var arg_1887 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1885 == nil { b__1050000231__6 = ifn_1886.Invoke_O__O(arg_1887) } else { b__1050000231__6 = linked_1885.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1884, arg_1887) }; var tmp2 any = A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_fn__1050000234_A_New_O_O_I_O(t.F_lang, b__1050000231__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1921 *jrt.Class = A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_fn__1050000234_A_fn_class; if fncls__1921 == nil { var fncls__1921d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_fn__1050000234_A_fn_class = fncls__1921d; tmp3 = fncls__1921d } else { tmp3 = fncls__1921 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1922 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_1923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1922, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1924 lang.IFn; if linked_1923 == nil { ifn_1924 = lang.IFn_Cast(root_1922) } else { ifn_1924 = nil }; var arg_1925 any; var root_1927 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1927, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1929 lang.IFn; if linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = b__1050000231__6; if linked_1928 == nil { arg_1925 = ifn_1929.Invoke_O__O(arg_1930) } else { arg_1925 = linked_1928.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1927, arg_1930) }; var arg_1926 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000228); var tmp5 any; var root_1931 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_1932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1931, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1933 lang.IFn; if linked_1932 == nil { ifn_1933 = lang.IFn_Cast(root_1931) } else { ifn_1933 = nil }; var arg_1934 any = s__1050000229__3; if linked_1932 == nil { tmp5 = ifn_1933.Invoke_O__O(arg_1934) } else { tmp5 = linked_1932.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1931, arg_1934) }; arg_1926 = tmp4.Invoke_O__O(tmp5); if linked_1923 == nil { return ifn_1924.Invoke_O_O__O(arg_1925, arg_1926) } else { return linked_1923.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1922, arg_1925, arg_1926) } } else { var root_1935 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_1936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1935, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1937 lang.IFn; if linked_1936 == nil { ifn_1937 = lang.IFn_Cast(root_1935) } else { ifn_1937 = nil }; var arg_1938 any; var root_1940 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_1941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1940, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1942 lang.IFn; if linked_1941 == nil { ifn_1942 = lang.IFn_Cast(root_1940) } else { ifn_1942 = nil }; var arg_1943 any = b__1050000231__6; if linked_1941 == nil { arg_1938 = ifn_1942.Invoke_O__O(arg_1943) } else { arg_1938 = linked_1941.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1940, arg_1943) }; var arg_1939 any; if linked_1936 == nil { return ifn_1937.Invoke_O_O__O(arg_1938, arg_1939) } else { return linked_1936.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1935, arg_1938, arg_1939) } } } else { var r__4 any; var root_1944 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_1945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1944, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1946 lang.IFn; if linked_1945 == nil { ifn_1946 = lang.IFn_Cast(root_1944) } else { ifn_1946 = nil }; var arg_1947 any = s__1050000229__3; if linked_1945 == nil { r__4 = ifn_1946.Invoke_O__O(arg_1947) } else { r__4 = linked_1945.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1944, arg_1947) }; var v__5 any; var root_1948 any = A_arbace_repr_go_parse_A_const_254.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, A_arbace_repr_go_parse_file_go_version_A_fn_class); var ifn_1950 lang.IFn
															if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var arg_1951 any; var tmp6 *lang.Keyword = A_arbace_repr_go_parse_A_const_255; var tmp7 any; var root_1953 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_1954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1953, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1955 lang.IFn; if linked_1954 == nil { ifn_1955 = lang.IFn_Cast(root_1953) } else { ifn_1955 = nil }; var arg_1956 any = A_arbace_repr_go_parse_A_const_227.Invoke_O__O(r__4); if linked_1954 == nil { tmp7 = ifn_1955.Invoke_O__O(arg_1956) } else { tmp7 = linked_1954.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1953, arg_1956) }; arg_1951 = tmp6.Invoke_O__O(tmp7); var arg_1952 any = t.F_lang; if linked_1949 == nil { v__5 = ifn_1950.Invoke_O_O__O(arg_1951, arg_1952) } else { v__5 = linked_1949.(*A_arbace_repr_go_parse_file_go_version_A).Invoke_O_O_O__O(root_1948, arg_1951, arg_1952) }
//line :398:1
	var root_1957 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_1958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1957, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1959 lang.IFn; if linked_1958 == nil { ifn_1959 = lang.IFn_Cast(root_1957) } else { ifn_1959 = nil }; var arg_1960 any; var tmp8 any = A_arbace_repr_go_parse_A_const_201; var G__1050000237__6_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, A_arbace_repr_go_parse_A_const_201.Invoke_O__O(r__4))); var G__1050000237__7_ any; var tmp9 any; var root_1962 any = A_arbace_repr_go_parse_A_const_250.GetRawRoot__O(); var linked_1963 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1962, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1964 lang.IFn


	if linked_1963 == nil { ifn_1964 = lang.IFn_Cast(root_1962) } else { ifn_1964 = nil }; var arg_1965 any = v__5; var arg_1966 any = t.F_lang; if linked_1963 == nil { tmp9 = ifn_1964.Invoke_O_O__O(arg_1965, arg_1966) } else { tmp9 = linked_1963.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1962, arg_1965, arg_1966) }
//line :400:1
	if jrt.J2g_Truth(tmp9) {
		var root_1967 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_1968 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1967, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1969 lang.IFn; if linked_1968 == nil { ifn_1969 = lang.IFn_Cast(root_1967) } else { ifn_1969 = nil }; var arg_1970 any = G__1050000237__6_; var arg_1971 any = A_arbace_repr_go_parse_A_const_255; var arg_1972 any = v__5; if linked_1968 == nil { G__1050000237__7_ = ifn_1969.Invoke_O_O_O__O(arg_1970, arg_1971, arg_1972) } else { G__1050000237__7_ = linked_1968.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1967, arg_1970, arg_1971, arg_1972) } } else {
//line :400:1
			G__1050000237__7_ = G__1050000237__6_ }; if jrt.J2g_Truth(jrt.Boolean_TRUE.Ref()) {

				var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_196.GetRawRoot__O()); var tmp11 any = A_arbace_repr_go_parse_A_const_227; var tmp12 any = A_arbace_repr_go_parse_A_const_227.Invoke_O__O(r__4); var tmp13 any = A_arbace_repr_go_parse_A_const_228; arg_1960 = tmp10.Invoke_O_O_O_O_O__O(G__1050000237__7_, tmp11, tmp12, tmp13, A_arbace_repr_go_parse_A_const_228.Invoke_O__O(r__4)) } else {
//line :400:1
					arg_1960 = G__1050000237__7_ }
//line :398:1
	var arg_1961 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1050000228); var tmp15 any; var root_1981 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_1982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1981, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1983 lang.IFn; if linked_1982 == nil { ifn_1983 = lang.IFn_Cast(root_1981) } else { ifn_1983 = nil }; var arg_1984 any = s__1050000229__3; if linked_1982 == nil { tmp15 = ifn_1983.Invoke_O__O(arg_1984) } else { tmp15 = linked_1982.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1981, arg_1984) }; arg_1961 = tmp14.Invoke_O__O(tmp15); if linked_1958 == nil { return ifn_1959.Invoke_O_O__O(arg_1960, arg_1961) } else { return linked_1958.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1957, arg_1960, arg_1961) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :398:1
func A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_fn__1050000234_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_fn__1050000234_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_fn__1050000234_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :398:1
func (t *A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_fn__1050000234_A) Ctor_O_O_I_O(c__lang, c__b__1050000231 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_lang = c__lang; t.F_b__1050000231 = c__b__1050000231; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :398:1
func (t *A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_fn__1050000234_A) Invoke_O__O(self any) any { { var i__1050000230__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000230__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var r__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000230__1)); var v__3 any; var root_1888 any = A_arbace_repr_go_parse_A_const_254.GetRawRoot__O(); var linked_1889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1888, A_arbace_repr_go_parse_file_go_version_A_fn_class); var ifn_1890 lang.IFn
																	if linked_1889 == nil { ifn_1890 = lang.IFn_Cast(root_1888) } else { ifn_1890 = nil }; var arg_1891 any; var tmp2 *lang.Keyword = A_arbace_repr_go_parse_A_const_255; var tmp3 any; var root_1893 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any = A_arbace_repr_go_parse_A_const_227.Invoke_O__O(r__2); if linked_1894 == nil { tmp3 = ifn_1895.Invoke_O__O(arg_1896) } else { tmp3 = linked_1894.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1893, arg_1896) }; arg_1891 = tmp2.Invoke_O__O(tmp3); var arg_1892 any = t.F_lang; if linked_1889 == nil { v__3 = ifn_1890.Invoke_O_O__O(arg_1891, arg_1892) } else { v__3 = linked_1889.(*A_arbace_repr_go_parse_file_go_version_A).Invoke_O_O_O__O(root_1888, arg_1891, arg_1892) }
//line :398:1
	var root_1897 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1899 lang.IFn; if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any = t.F_b__1050000231; var arg_1901 any; var tmp4 any = A_arbace_repr_go_parse_A_const_201; var G__1050000235__4_ any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, A_arbace_repr_go_parse_A_const_201.Invoke_O__O(r__2))); var G__1050000235__5_ any; var tmp5 any; var root_1902 any = A_arbace_repr_go_parse_A_const_250.GetRawRoot__O(); var linked_1903 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1902, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1904 lang.IFn


	if linked_1903 == nil { ifn_1904 = lang.IFn_Cast(root_1902) } else { ifn_1904 = nil }; var arg_1905 any = v__3; var arg_1906 any = t.F_lang; if linked_1903 == nil { tmp5 = ifn_1904.Invoke_O_O__O(arg_1905, arg_1906) } else { tmp5 = linked_1903.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1902, arg_1905, arg_1906) }
//line :400:1
	if jrt.J2g_Truth(tmp5) {
		var root_1907 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1907, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1909 lang.IFn; if linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = G__1050000235__4_; var arg_1911 any = A_arbace_repr_go_parse_A_const_255; var arg_1912 any = v__3; if linked_1908 == nil { G__1050000235__5_ = ifn_1909.Invoke_O_O_O__O(arg_1910, arg_1911, arg_1912) } else { G__1050000235__5_ = linked_1908.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1907, arg_1910, arg_1911, arg_1912) } } else {
//line :400:1
			G__1050000235__5_ = G__1050000235__4_ }; if jrt.J2g_Truth(jrt.Boolean_TRUE.Ref()) {

				var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_196.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_parse_A_const_227; var tmp8 any = A_arbace_repr_go_parse_A_const_227.Invoke_O__O(r__2); var tmp9 any = A_arbace_repr_go_parse_A_const_228; arg_1901 = tmp6.Invoke_O_O_O_O_O__O(G__1050000235__5_, tmp7, tmp8, tmp9, A_arbace_repr_go_parse_A_const_228.Invoke_O__O(r__2)) } else {
//line :400:1
					arg_1901 = G__1050000235__5_ }
//line :398:1
	if linked_1898 == nil { ifn_1899.Invoke_O_O__O(arg_1900, arg_1901) } else { linked_1898.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1897, arg_1900, arg_1901) }; i__1050000230__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000230__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_repr_go_parse_native_dump_fn__1050000240_A_New() *A_arbace_repr_go_parse_native_dump_fn__1050000240_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_native_dump_fn__1050000240_A{}; t.Ctor(); return t }
//line :407:1
func (t *A_arbace_repr_go_parse_native_dump_fn__1050000240_A) Ctor() {}
//line :407:1
func (t *A_arbace_repr_go_parse_native_dump_fn__1050000240_A) Invoke_O_O__O(self, p1__1050000212_SHARP___1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(jrt.File_New_String(jrt.String_Cast(A_arbace_repr_go_parse_A_const_184.Invoke_O__O(p1__1050000212_SHARP___1))).Length__J()).Ref() }



func A_arbace_repr_go_parse_tree_of_A_New() *A_arbace_repr_go_parse_tree_of_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_tree_of_A{}; t.Ctor(); return t }
//line :411:1
func (t *A_arbace_repr_go_parse_tree_of_A) Ctor() {}
//line :411:1
func (t *A_arbace_repr_go_parse_tree_of_A) Invoke_O_O__O(self, d__0 any) any {




	var root_2043 any = A_arbace_repr_go_parse_A_const_251.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2043, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_2045 lang.IFn; if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; var arg_2046 any; var root_2048 any = A_arbace_repr_go_parse_A_const_260.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2050 lang.IFn; if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any = d__0; var arg_2052 any = A_arbace_repr_go_parse_A_const_261.GetRawRoot__O(); if linked_2049 == nil { arg_2046 = ifn_2050.Invoke_O_O__O(arg_2051, arg_2052) } else { arg_2046 = linked_2049.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2048, arg_2051, arg_2052) }; var arg_2047 any; var tmp1 any = A_arbace_repr_go_parse_A_const_73; var tmp2 any = A_arbace_repr_go_parse_A_const_73.Invoke_O__O(d__0); var tmp3 any = A_arbace_repr_go_parse_A_const_189; var tmp4 any; var root_2053 any = A_arbace_repr_go_parse_A_const_234.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2055 lang.IFn

	if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2056 any; var tmp5 any = A_arbace_repr_go_parse_tree_of_fn__1050000244_A_New(); var tmp6 *jrt.Class; var fncls__2063 *jrt.Class = A_arbace_repr_go_parse_tree_of_fn__1050000244_A_fn_class; if fncls__2063 == nil { var fncls__2063d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_183, false); A_arbace_repr_go_parse_tree_of_fn__1050000244_A_fn_class = fncls__2063d; tmp6 = fncls__2063d } else { tmp6 = fncls__2063 }; arg_2056 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_2057 any = A_arbace_repr_go_parse_A_const_189.Invoke_O__O(d__0); if linked_2054 == nil { tmp4 = ifn_2055.Invoke_O_O__O(arg_2056, arg_2057) } else { tmp4 = linked_2054.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2053, arg_2056, arg_2057) }
//line :416:1
	var tmp7 any = tmp4; var tmp8 any = A_arbace_repr_go_parse_A_const_229; var tmp9 any = A_arbace_repr_go_parse_A_const_229.Invoke_O__O(d__0); var tmp10 any = A_arbace_repr_go_parse_A_const_230; arg_2047 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp7, tmp8, tmp9, tmp10, A_arbace_repr_go_parse_A_const_230.Invoke_O__O(d__0))); if linked_2044 == nil { return ifn_2045.Invoke_O_O__O(arg_2046, arg_2047) } else { return linked_2044.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_2043, arg_2046, arg_2047)
	} }
func A_arbace_repr_go_parse_tree_of_fn__1050000244_A_New() *A_arbace_repr_go_parse_tree_of_fn__1050000244_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_tree_of_fn__1050000244_A{}; t.Ctor(); return t }
//line :418:1
func (t *A_arbace_repr_go_parse_tree_of_fn__1050000244_A) Ctor() {}
//line :418:1
func (t *A_arbace_repr_go_parse_tree_of_fn__1050000244_A) Invoke_O_O__O(self, p1__1050000243_SHARP___1 any) any { var root_2058 any = A_arbace_repr_go_parse_A_const_260.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2060 lang.IFn; if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any = p1__1050000243_SHARP___1; var arg_2062 any = A_arbace_repr_go_parse_A_const_262; if linked_2059 == nil { return ifn_2060.Invoke_O_O__O(arg_2061, arg_2062) } else { return linked_2059.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2058, arg_2061, arg_2062) } }



func A_arbace_repr_go_parse_kind_of_A_New() *A_arbace_repr_go_parse_kind_of_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_kind_of_A{}; t.Ctor(); return t }
//line :422:1
func (t *A_arbace_repr_go_parse_kind_of_A) Ctor() {}
//line :422:1
func (t *A_arbace_repr_go_parse_kind_of_A) Invoke_O_O__O(self, x__0 any) any {
	if lang.Util_Identical_O_O__Z_NoInit(x__0, nil) { return A_arbace_repr_go_parse_A_const_263 } else { var tmp1 any; var root_2064 any = A_arbace_repr_go_parse_A_const_21.GetRawRoot__O(); var linked_2065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2064, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_2066 lang.IFn

		if linked_2065 == nil { ifn_2066 = lang.IFn_Cast(root_2064) } else { ifn_2066 = nil }; var arg_2067 any = x__0; if linked_2065 == nil { tmp1 = ifn_2066.Invoke_O__O(arg_2067) } else { tmp1 = linked_2065.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_2064, arg_2067) }
//line :423:1
		if jrt.J2g_Truth(tmp1) { return A_arbace_repr_go_parse_A_const_62 } else { var tmp2 any; var root_2068 any = A_arbace_repr_go_parse_A_const_264.GetRawRoot__O(); var linked_2069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2068, aot_arbace_core.A_arbace_core_keyword_QMARK__A_fn_class); var ifn_2070 lang.IFn


			if linked_2069 == nil { ifn_2070 = lang.IFn_Cast(root_2068) } else { ifn_2070 = nil }; var arg_2071 any = x__0; if linked_2069 == nil { tmp2 = ifn_2070.Invoke_O__O(arg_2071) } else { tmp2 = linked_2069.(*aot_arbace_core.A_arbace_core_keyword_QMARK__A).Invoke_O_O__O(root_2068, arg_2071) }
//line :423:1
			if jrt.J2g_Truth(tmp2) { return A_arbace_repr_go_parse_A_const_265 } else { var tmp3 any; var root_2072 any = A_arbace_repr_go_parse_A_const_266.GetRawRoot__O(); var linked_2073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2072, aot_arbace_core.A_arbace_core_boolean_QMARK__A_fn_class); var ifn_2074 lang.IFn



				if linked_2073 == nil { ifn_2074 = lang.IFn_Cast(root_2072) } else { ifn_2074 = nil }; var arg_2075 any = x__0; if linked_2073 == nil { tmp3 = ifn_2074.Invoke_O__O(arg_2075) } else { tmp3 = linked_2073.(*aot_arbace_core.A_arbace_core_boolean_QMARK__A).Invoke_O_O__O(root_2072, arg_2075) }
//line :423:1
				if jrt.J2g_Truth(tmp3) { return A_arbace_repr_go_parse_A_const_267 } else { var tmp4 any; var root_2076 any = A_arbace_repr_go_parse_A_const_268.GetRawRoot__O(); var linked_2077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2076, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_2078 lang.IFn




					if linked_2077 == nil { ifn_2078 = lang.IFn_Cast(root_2076) } else { ifn_2078 = nil }; var arg_2079 any = x__0; if linked_2077 == nil { tmp4 = ifn_2078.Invoke_O__O(arg_2079) } else { tmp4 = linked_2077.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_2076, arg_2079) }
//line :423:1
					if jrt.J2g_Truth(tmp4) { return A_arbace_repr_go_parse_A_const_269 } else { var tmp5 any; var root_2080 any = A_arbace_repr_go_parse_A_const_235.GetRawRoot__O(); var linked_2081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2080, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_2082 lang.IFn





						if linked_2081 == nil { ifn_2082 = lang.IFn_Cast(root_2080) } else { ifn_2082 = nil }; var arg_2083 any = x__0; if linked_2081 == nil { tmp5 = ifn_2082.Invoke_O__O(arg_2083) } else { tmp5 = linked_2081.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_2080, arg_2083) }
//line :423:1
						if jrt.J2g_Truth(tmp5) { return A_arbace_repr_go_parse_A_const_270 } else { var tmp6 any; var root_2084 any = A_arbace_repr_go_parse_A_const_32.GetRawRoot__O(); var linked_2085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2084, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_2086 lang.IFn






							if linked_2085 == nil { ifn_2086 = lang.IFn_Cast(root_2084) } else { ifn_2086 = nil }; var arg_2087 any = x__0; if linked_2085 == nil { tmp6 = ifn_2086.Invoke_O__O(arg_2087) } else { tmp6 = linked_2085.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_2084, arg_2087) }
//line :423:1
							if jrt.J2g_Truth(tmp6) { return A_arbace_repr_go_parse_A_const_271 } else { var tmp7 any; var root_2088 any = A_arbace_repr_go_parse_A_const_18.GetRawRoot__O(); var linked_2089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2088, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_2090 lang.IFn







								if linked_2089 == nil { ifn_2090 = lang.IFn_Cast(root_2088) } else { ifn_2090 = nil }; var arg_2091 any = x__0; if linked_2089 == nil { tmp7 = ifn_2090.Invoke_O__O(arg_2091) } else { tmp7 = linked_2089.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_2088, arg_2091) }
//line :423:1
								if jrt.J2g_Truth(tmp7) { return A_arbace_repr_go_parse_A_const_272 } else { if A_arbace_repr_go_parse_A_const_68 != nil {








									var root_2092 any = A_arbace_repr_go_parse_A_const_273.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_2094 lang.IFn; if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = x__0; if linked_2093 == nil { return ifn_2094.Invoke_O__O(arg_2095) } else { return linked_2093.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_2092, arg_2095) } } else {
//line :423:1
										return nil
									}
								}
							}
						}
					}
				}
			}
		}
	}
}
func A_arbace_repr_go_parse_diff_A_New() *A_arbace_repr_go_parse_diff_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_diff_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_repr_go_parse_diff_A) Ctor() {}
//line :434:1
func (t *A_arbace_repr_go_parse_diff_A) Invoke_O_O_O_O__O(self, a__0, b__1, path__2 any) any { var ka__4 any; var root_2096 any = A_arbace_repr_go_parse_A_const_274.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2096, A_arbace_repr_go_parse_kind_of_A_fn_class); var ifn_2098 lang.IFn; if




	linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any = a__0; if linked_2097 == nil { ka__4 = ifn_2098.Invoke_O__O(arg_2099) } else { ka__4 = linked_2097.(*A_arbace_repr_go_parse_kind_of_A).Invoke_O_O__O(root_2096, arg_2099) }; var kb__5 any; var root_2100 any = /*line :434:1*/A_arbace_repr_go_parse_A_const_274.GetRawRoot__O(); var linked_2101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2100, A_arbace_repr_go_parse_kind_of_A_fn_class); var ifn_2102 lang.IFn; if




	linked_2101 == nil { ifn_2102 = lang.IFn_Cast(root_2100) } else { ifn_2102 = nil }; var arg_2103 any = b__1; if linked_2101 == nil { kb__5 = ifn_2102.Invoke_O__O(arg_2103) } else { kb__5 = linked_2101.(*A_arbace_repr_go_parse_kind_of_A).Invoke_O_O__O(root_2100, arg_2103) }; var tmp1 any; var root_2104 any =
	A_arbace_repr_go_parse_A_const_250.GetRawRoot__O(); var linked_2105 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2104, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2106 lang.IFn; if
	linked_2105 == nil { ifn_2106 = lang.IFn_Cast(root_2104) } else { ifn_2106 = nil }; var arg_2107 any = ka__4; var arg_2108 any = kb__5; if linked_2105 == nil { tmp1 = ifn_2106.Invoke_O_O__O(arg_2107, arg_2108) } else { tmp1 = linked_2105.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2104, arg_2107, arg_2108) }; if /*line :440:1*/ jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O_O__IPersistentVector(path__2, a__0, b__1) } else { if lang.Util_Equiv_O_O__Z_NoInit(ka__4, A_arbace_repr_go_parse_A_const_270) { var or__1927000174__auto____6 any; var root_2109 any = A_arbace_repr_go_parse_A_const_138.GetRawRoot__O(); var linked_2110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2109, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2111 lang.IFn

		if linked_2110 == nil { ifn_2111 = lang.IFn_Cast(root_2109) } else { ifn_2111 = nil }; var arg_2112 any; var tmp2 any = A_arbace_repr_go_parse_diff_fn__1050000248_A_New_O_O_O(a__0, b__1, path__2); var tmp3 *jrt.Class; var fncls__2129 *jrt.Class = A_arbace_repr_go_parse_diff_fn__1050000248_A_fn_class; if fncls__2129 == nil { var fncls__2129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_repr_go_parse_diff_fn__1050000248_A_fn_class = fncls__2129d; tmp3 = fncls__2129d } else { tmp3 = fncls__2129 }; arg_2112 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_2113 any; var root_2130 any = A_arbace_repr_go_parse_A_const_156.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_2132 lang.IFn
		if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any; var root_2134 any = A_arbace_repr_go_parse_A_const_35.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2134, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2136 lang.IFn; if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any; var root_2139 any = A_arbace_repr_go_parse_A_const_276.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = a__0; if linked_2140 == nil { arg_2137 = ifn_2141.Invoke_O__O(arg_2142) } else { arg_2137 = linked_2140.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2139, arg_2142) }; var arg_2138 any; var root_2143 any = A_arbace_repr_go_parse_A_const_276.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2143, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = b__1; if linked_2144 == nil { arg_2138 = ifn_2145.Invoke_O__O(arg_2146) } else { arg_2138 = linked_2144.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2143, arg_2146) }; if linked_2135 == nil { arg_2133 = ifn_2136.Invoke_O_O__O(arg_2137, arg_2138) } else { arg_2133 = linked_2135.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2134, arg_2137, arg_2138) }; if linked_2131 == nil { arg_2113 = ifn_2132.Invoke_O__O(arg_2133) } else { arg_2113 = linked_2131.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_2130, arg_2133) }
//line :442:1
		if linked_2110 == nil { or__1927000174__auto____6 = ifn_2111.Invoke_O_O__O(arg_2112, arg_2113) } else { or__1927000174__auto____6 = linked_2110.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2109, arg_2112, arg_2113) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {

			var root_2147 any = A_arbace_repr_go_parse_A_const_138.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2149 lang.IFn; if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any; var tmp4 any = A_arbace_repr_go_parse_diff_fn__1050000251_A_New_O_O(b__1, path__2); var tmp5 *jrt.Class; var fncls__2163 *jrt.Class = A_arbace_repr_go_parse_diff_fn__1050000251_A_fn_class; if fncls__2163 == nil { var fncls__2163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_repr_go_parse_diff_fn__1050000251_A_fn_class = fncls__2163d; tmp5 = fncls__2163d } else { tmp5 = fncls__2163 }; arg_2150 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_2151 any = a__0; if linked_2148 == nil { return ifn_2149.Invoke_O_O__O(arg_2150, arg_2151) } else { return linked_2148.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2147, arg_2150, arg_2151) } } } else {
//line :440:1
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_parse_A_const_278).Invoke_O__O(ka__4)) { var or__1927000174__auto____6_2 any; var tmp6 any; var root_2164 any = A_arbace_repr_go_parse_A_const_250.GetRawRoot__O(); var linked_2165 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2164, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2166 lang.IFn




					if linked_2165 == nil { ifn_2166 = lang.IFn_Cast(root_2164) } else { ifn_2166 = nil }; var arg_2167 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(a__0)).Ref(); var arg_2168 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(b__1)).Ref(); if linked_2165 == nil { tmp6 = ifn_2166.Invoke_O_O__O(arg_2167, arg_2168) } else { tmp6 = linked_2165.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2164, arg_2167, arg_2168) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_2201 any = A_arbace_repr_go_parse_A_const_12.GetRawRoot__O(); var linked_2202 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2201, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2203 lang.IFn; if linked_2202 == nil { ifn_2203 = lang.IFn_Cast(root_2201) } else { ifn_2203 = nil }; var arg_2204 any = path__2; var arg_2205 any = A_arbace_repr_go_parse_A_const_282; if linked_2202 == nil { tmp7 = ifn_2203.Invoke_O_O__O(arg_2204, arg_2205) } else { tmp7 = linked_2202.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2201, arg_2204, arg_2205) }; or__1927000174__auto____6_2 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp7, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(a__0)).Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(b__1)).Ref()) } else { or__1927000174__auto____6_2 = nil }; if jrt.J2g_Truth(or__1927000174__auto____6_2) { return or__1927000174__auto____6_2 } else {
						var root_2169 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_2170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2169, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2171 lang.IFn; if linked_2170 == nil { ifn_2171 = lang.IFn_Cast(root_2169) } else { ifn_2171 = nil }; var arg_2172 any; var root_2173 any = A_arbace_repr_go_parse_A_const_279.GetRawRoot__O(); var linked_2174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2173, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2175 lang.IFn; if linked_2174 == nil { ifn_2175 = lang.IFn_Cast(root_2173) } else { ifn_2175 = nil }; var arg_2176 any = A_arbace_repr_go_parse_A_const_280.GetRawRoot__O(); var arg_2177 any; var root_2178 any = A_arbace_repr_go_parse_A_const_281.GetRawRoot__O(); var linked_2179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2178, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2180 lang.IFn; if linked_2179 == nil { ifn_2180 = lang.IFn_Cast(root_2178) } else { ifn_2180 = nil }; var arg_2181 any; var tmp8 any = A_arbace_repr_go_parse_diff_fn__1050000257_A_New_O(path__2); var tmp9 *jrt.Class; var fncls__2194 *jrt.Class = A_arbace_repr_go_parse_diff_fn__1050000257_A_fn_class; if fncls__2194 == nil { var fncls__2194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_repr_go_parse_diff_fn__1050000257_A_fn_class = fncls__2194d; tmp9 = fncls__2194d } else { tmp9 = fncls__2194 }; arg_2181 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_2182 any; var root_2195 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2195, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = A_arbace_repr_go_parse_A_const_220.GetRawRoot__O(); var arg_2199 any = a__0; var arg_2200 any = b__1; if linked_2196 == nil { arg_2182 = ifn_2197.Invoke_O_O_O__O(arg_2198, arg_2199, arg_2200) } else { arg_2182 = linked_2196.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O_O__O(root_2195, arg_2198, arg_2199, arg_2200) }; if linked_2179 == nil { arg_2177 = ifn_2180.Invoke_O_O__O(arg_2181, arg_2182) } else { arg_2177 = linked_2179.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2178, arg_2181, arg_2182) }; if linked_2174 == nil { arg_2172 = ifn_2175.Invoke_O_O__O(arg_2176, arg_2177) } else { arg_2172 = linked_2174.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2173, arg_2176, arg_2177) }; if linked_2170 == nil { return ifn_2171.Invoke_O__O(arg_2172) } else { return linked_2170.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2169, arg_2172) } } } else {
//line :440:1
							if lang.Util_Equiv_O_O__Z_NoInit(a__0, b__1) { return nil } else { if A_arbace_repr_go_parse_A_const_68 != nil { return lang.Tuple_Create_O_O_O__IPersistentVector(path__2, a__0, b__1) } else { return nil } } } } } }

func A_arbace_repr_go_parse_diff_fn__1050000248_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_parse_diff_fn__1050000248_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_diff_fn__1050000248_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :442:1
func (t *A_arbace_repr_go_parse_diff_fn__1050000248_A) Ctor_O_O_O(c__a, c__b, c__path any) { t.F_a = c__a; t.F_b = c__b; t.F_path = c__path }
//line :442:1
func (t *A_arbace_repr_go_parse_diff_fn__1050000248_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_2114 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_2115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2114, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2116 lang.IFn; if linked_2115 == nil { ifn_2116 = lang.IFn_Cast(root_2114) } else { ifn_2116 = nil }; var arg_2117 any = t.F_a; var arg_2118 any = k__1; if linked_2115 == nil { and__1927000168__auto____2 = ifn_2116.Invoke_O_O__O(arg_2117, arg_2118) } else { and__1927000168__auto____2 = linked_2115.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2114, arg_2117, arg_2118) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_2119 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_2120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2119, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2121 lang.IFn; if linked_2120 == nil { ifn_2121 = lang.IFn_Cast(root_2119) } else { ifn_2121 = nil }; var arg_2122 any = t.F_b; var arg_2123 any = k__1; if linked_2120 == nil { tmp1 = ifn_2121.Invoke_O_O__O(arg_2122, arg_2123) } else { tmp1 = linked_2120.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2119, arg_2122, arg_2123) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { return nil } else { var tmp2 any; var root_2124 any = A_arbace_repr_go_parse_A_const_12.GetRawRoot__O(); var linked_2125 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2124, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2126 lang.IFn; if linked_2125 == nil { ifn_2126 = lang.IFn_Cast(root_2124) } else { ifn_2126 = nil }; var arg_2127 any = t.F_path; var arg_2128 any = k__1; if linked_2125 == nil { tmp2 = ifn_2126.Invoke_O_O__O(arg_2127, arg_2128) } else { tmp2 = linked_2125.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2124, arg_2127, arg_2128) }; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, lang.RT_Get_O_O_O__O_NoInit(t.F_a, k__1, A_arbace_repr_go_parse_A_const_275), lang.RT_Get_O_O_O__O_NoInit(t.F_b, k__1, A_arbace_repr_go_parse_A_const_275)) } }

func A_arbace_repr_go_parse_diff_fn__1050000251_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_diff_fn__1050000251_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_diff_fn__1050000251_A{}; t.Ctor_O_O(p0, p1); return t }
//line :444:1
func (t *A_arbace_repr_go_parse_diff_fn__1050000251_A) Ctor_O_O(c__b, c__path any) { t.F_b = c__b; t.F_path = c__path }
//line :444:1
func (t *A_arbace_repr_go_parse_diff_fn__1050000251_A) Invoke_O_O__O(self, p__1050000250__1 any) any { var vec__1050000252__2 any = p__1050000250__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000252__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000252__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2152 any = A_arbace_repr_go_parse_A_const_277.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2152, A_arbace_repr_go_parse_diff_A_fn_class); var ifn_2154 lang.IFn; if linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any = v__4; var arg_2156 any = lang.RT_Get_O_O__O_NoInit(t.F_b, k__3); var arg_2157 any; var root_2158 any = A_arbace_repr_go_parse_A_const_12.GetRawRoot__O(); var linked_2159 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2158, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2160 lang.IFn; if linked_2159 == nil { ifn_2160 = lang.IFn_Cast(root_2158) } else { ifn_2160 = nil }; var arg_2161 any = t.F_path; var arg_2162 any = k__3; if linked_2159 == nil { arg_2157 = ifn_2160.Invoke_O_O__O(arg_2161, arg_2162) } else { arg_2157 = linked_2159.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2158, arg_2161, arg_2162) }; if linked_2153 == nil { return ifn_2154.Invoke_O_O_O__O(arg_2155, arg_2156, arg_2157) } else { return linked_2153.(*A_arbace_repr_go_parse_diff_A).Invoke_O_O_O_O__O(root_2152, arg_2155, arg_2156, arg_2157) } }

func A_arbace_repr_go_parse_diff_fn__1050000257_A_New_O(p0 any) *A_arbace_repr_go_parse_diff_fn__1050000257_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_diff_fn__1050000257_A{}; t.Ctor_O(p0); return t }
//line :446:1
func (t *A_arbace_repr_go_parse_diff_fn__1050000257_A) Ctor_O(c__path any) { t.F_path = c__path }
//line :446:1
func (t *A_arbace_repr_go_parse_diff_fn__1050000257_A) Invoke_O_O_O__O(self, i__1, p__1050000256__2 any) any { var vec__1050000258__3 any = p__1050000256__2; var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000258__3, lang.RT_IntCast_J__I_NoInit(0), nil); var y__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000258__3, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2183 any = A_arbace_repr_go_parse_A_const_277.GetRawRoot__O(); var linked_2184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2183, A_arbace_repr_go_parse_diff_A_fn_class); var ifn_2185 lang.IFn; if linked_2184 == nil { ifn_2185 = lang.IFn_Cast(root_2183) } else { ifn_2185 = nil }; var arg_2186 any = x__4; var arg_2187 any = y__5; var arg_2188 any; var root_2189 any = A_arbace_repr_go_parse_A_const_12.GetRawRoot__O(); var linked_2190 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2189, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_2191 lang.IFn; if linked_2190 == nil { ifn_2191 = lang.IFn_Cast(root_2189) } else { ifn_2191 = nil }; var arg_2192 any = t.F_path; var arg_2193 any = i__1; if linked_2190 == nil { arg_2188 = ifn_2191.Invoke_O_O__O(arg_2192, arg_2193) } else { arg_2188 = linked_2190.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_2189, arg_2192, arg_2193) }; if linked_2184 == nil { return ifn_2185.Invoke_O_O_O__O(arg_2186, arg_2187, arg_2188) } else { return linked_2184.(*A_arbace_repr_go_parse_diff_A).Invoke_O_O_O_O__O(root_2183, arg_2186, arg_2187, arg_2188) } }



func A_arbace_repr_go_parse_short_str_A_New() *A_arbace_repr_go_parse_short_str_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_short_str_A{}; t.Ctor(); return t }
//line :450:1
func (t *A_arbace_repr_go_parse_short_str_A) Ctor() {}
//line :450:1
func (t *A_arbace_repr_go_parse_short_str_A) Invoke_O_O__O(self, x__0 any) any { var s__2 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_70.GetRawRoot__O()).Invoke_O__O(x__0); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(s__2)), 300) { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_177); var tmp2 any; var root_2210 any = A_arbace_repr_go_parse_A_const_283.GetRawRoot__O(); var linked_2211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2210, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2212 lang.IFn; if linked_2211 == nil { ifn_2212 = lang.IFn_Cast(root_2210) } else { ifn_2212 = nil }; var arg_2213 any = s__2; var arg_2214 any = A_arbace_repr_go_parse_A_const_151; var arg_2215 any = A_arbace_repr_go_parse_A_const_284; if linked_2211 == nil { tmp2 = ifn_2212.Invoke_O_O_O__O(arg_2213, arg_2214, arg_2215) } else { tmp2 = linked_2211.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_2210, arg_2213, arg_2214, arg_2215) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref() } else { return s__2 } }

func A_arbace_repr_go_parse_file_at_A_New() *A_arbace_repr_go_parse_file_at_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_file_at_A{}; t.Ctor(); return t }
//line :452:1
func (t *A_arbace_repr_go_parse_file_at_A) Ctor() {}
//line :452:1
func (t *A_arbace_repr_go_parse_file_at_A) Invoke_O_O_O__O(self, d__0, path__1 any) any {


	var tmp1 any = A_arbace_repr_go_parse_A_const_189; var tmp2 any; var root_2216 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2216, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2218 lang.IFn; if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any = path__1; if linked_2217 == nil { tmp2 = ifn_2218.Invoke_O__O(arg_2219) } else { tmp2 = linked_2217.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2216, arg_2219) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) {
		var root_2220 any = A_arbace_repr_go_parse_A_const_247.GetRawRoot__O(); var linked_2221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2220, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2222 lang.IFn; if linked_2221 == nil { ifn_2222 = lang.IFn_Cast(root_2220) } else { ifn_2222 = nil }; var arg_2223 any = d__0; var arg_2224 any; var tmp3 any = A_arbace_repr_go_parse_A_const_189; var tmp4 any; var root_2225 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_2226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2225, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2227 lang.IFn; if linked_2226 == nil { ifn_2227 = lang.IFn_Cast(root_2225) } else { ifn_2227 = nil }; var arg_2228 any = path__1; if linked_2226 == nil { tmp4 = ifn_2227.Invoke_O__O(arg_2228) } else { tmp4 = linked_2226.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2225, arg_2228) }; arg_2224 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp3, tmp4, A_arbace_repr_go_parse_A_const_201); if linked_2221 == nil { return ifn_2222.Invoke_O_O__O(arg_2223, arg_2224) } else { return linked_2221.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2220, arg_2223, arg_2224) } } else {
//line :455:1
			return nil
		}
}
func A_arbace_repr_go_parse_job_keys_A_New() *A_arbace_repr_go_parse_job_keys_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_job_keys_A{}; t.Ctor(); return t }
//line :458:1
func (t *A_arbace_repr_go_parse_job_keys_A) Ctor() {}
//line :458:1
func (t *A_arbace_repr_go_parse_job_keys_A) Invoke_O_O__O(self, j__0 any) any { var root_2229 any = A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_2230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2229, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2231 lang.IFn; if linked_2230 == nil { ifn_2231 = lang.IFn_Cast(root_2229) } else { ifn_2231 = nil }; var arg_2232 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_A_New_O(j__0); var tmp2 *jrt.Class; var fncls__2301 *jrt.Class = A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_A_fn_class; if fncls__2301 == nil { var fncls__2301d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_A_fn_class = fncls__2301d; tmp2 = fncls__2301d } else { tmp2 = fncls__2301 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_2232 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(A_arbace_repr_go_parse_A_const_189.Invoke_O__O(j__0)); if linked_2230 == nil { return ifn_2231.Invoke_O__O(arg_2232) } else { return linked_2230.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2229, arg_2232) } }
//line :458:1
func A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_A_New_O(p0 any) *A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_A{}; t.Ctor_O(p0); return t }
//line :458:1
func (t *A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_A) Ctor_O(c__j any) { t.F_j = c__j }
//line :458:1
func (t *A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_A) Invoke_O_O__O(self, s__1050000266__1 any) any { var tmp1 any = A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_A_New_O_O_O(t.F_j, s__1050000266__1, self); var tmp2 *jrt.Class; var fncls__2300 *jrt.Class = A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_A_fn_class; if fncls__2300 == nil { var fncls__2300d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_A_fn_class = fncls__2300d; tmp2 = fncls__2300d } else { tmp2 = fncls__2300 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :458:1
func A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :458:1
func (t *A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_A) Ctor_O_O_O(c__j, c__s__1050000266, c__iter__1050000265 any) { t.F_j = c__j; t.F_s__1050000266 = c__s__1050000266; t.F_iter__1050000265 = c__iter__1050000265 }
//line :458:1
func (t *A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_A) Invoke_O__O(self any) any { { var s__1050000266__1 any; var t_ any = t.F_s__1050000266; t.F_s__1050000266 = nil; s__1050000266__1 = t_; for { var temp__1927000414__auto____2 any; var root_2233 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_2234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2233, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2235 lang.IFn; if linked_2234 == nil { ifn_2235 = lang.IFn_Cast(root_2233) } else { ifn_2235 = nil }; var arg_2236 any = s__1050000266__1; if linked_2234 == nil { temp__1927000414__auto____2 = ifn_2235.Invoke_O__O(arg_2236) } else { temp__1927000414__auto____2 = linked_2234.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2233, arg_2236) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000266__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2237 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2237, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2239 lang.IFn; if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any = s__1050000266__3; if linked_2238 == nil { tmp1 = ifn_2239.Invoke_O__O(arg_2240) } else { tmp1 = linked_2238.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2237, arg_2240) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2241 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_2242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2241, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2243 lang.IFn; if linked_2242 == nil { ifn_2243 = lang.IFn_Cast(root_2241) } else { ifn_2243 = nil }; var arg_2244 any = s__1050000266__3; if linked_2242 == nil { c__1927001037__auto____4 = ifn_2243.Invoke_O__O(arg_2244) } else { c__1927001037__auto____4 = linked_2242.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2241, arg_2244) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000268__6 any; var root_2245 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_2246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2245, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2247 lang.IFn; if linked_2246 == nil { ifn_2247 = lang.IFn_Cast(root_2245) } else { ifn_2247 = nil }; var arg_2248 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2246 == nil { b__1050000268__6 = ifn_2247.Invoke_O__O(arg_2248) } else { b__1050000268__6 = linked_2246.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2245, arg_2248) }; var tmp2 any = A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_fn__1050000271_A_New_O_O_I_O(t.F_j, b__1050000268__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2259 *jrt.Class = A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_fn__1050000271_A_fn_class; if fncls__2259 == nil { var fncls__2259d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_fn__1050000271_A_fn_class = fncls__2259d; tmp3 = fncls__2259d } else { tmp3 = fncls__2259 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2260 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_2261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2260, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2262 lang.IFn; if linked_2261 == nil { ifn_2262 = lang.IFn_Cast(root_2260) } else { ifn_2262 = nil }; var arg_2263 any; var root_2265 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_2266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2265, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2267 lang.IFn; if linked_2266 == nil { ifn_2267 = lang.IFn_Cast(root_2265) } else { ifn_2267 = nil }; var arg_2268 any = b__1050000268__6; if linked_2266 == nil { arg_2263 = ifn_2267.Invoke_O__O(arg_2268) } else { arg_2263 = linked_2266.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2265, arg_2268) }; var arg_2264 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000265); var tmp5 any; var root_2269 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_2270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2269, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2271 lang.IFn; if linked_2270 == nil { ifn_2271 = lang.IFn_Cast(root_2269) } else { ifn_2271 = nil }; var arg_2272 any = s__1050000266__3; if linked_2270 == nil { tmp5 = ifn_2271.Invoke_O__O(arg_2272) } else { tmp5 = linked_2270.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2269, arg_2272) }; arg_2264 = tmp4.Invoke_O__O(tmp5); if linked_2261 == nil { return ifn_2262.Invoke_O_O__O(arg_2263, arg_2264) } else { return linked_2261.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2260, arg_2263, arg_2264) } } else { var root_2273 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_2274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2273, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2275 lang.IFn; if linked_2274 == nil { ifn_2275 = lang.IFn_Cast(root_2273) } else { ifn_2275 = nil }; var arg_2276 any; var root_2278 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_2279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2278, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2280 lang.IFn; if linked_2279 == nil { ifn_2280 = lang.IFn_Cast(root_2278) } else { ifn_2280 = nil }; var arg_2281 any = b__1050000268__6; if linked_2279 == nil { arg_2276 = ifn_2280.Invoke_O__O(arg_2281) } else { arg_2276 = linked_2279.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2278, arg_2281) }; var arg_2277 any; if linked_2274 == nil { return ifn_2275.Invoke_O_O__O(arg_2276, arg_2277) } else { return linked_2274.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2273, arg_2276, arg_2277) } } } else { var f__4 any; var root_2282 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_2283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2282, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2284 lang.IFn; if linked_2283 == nil { ifn_2284 = lang.IFn_Cast(root_2282) } else { ifn_2284 = nil }; var arg_2285 any = s__1050000266__3; if linked_2283 == nil { f__4 = ifn_2284.Invoke_O__O(arg_2285) } else { f__4 = linked_2283.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2282, arg_2285) }; var root_2286 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_2287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2286, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2288 lang.IFn; if linked_2287 == nil { ifn_2288 = lang.IFn_Cast(root_2286) } else { ifn_2288 = nil }; var arg_2289 any; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_72, nil); var tmp7 any; var root_2291 any = A_arbace_repr_go_parse_A_const_247.GetRawRoot__O(); var linked_2292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2291, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2293 lang.IFn; if linked_2292 == nil { ifn_2293 = lang.IFn_Cast(root_2291) } else { ifn_2293 = nil }; var arg_2294 any = t.F_j; var arg_2295 any = A_arbace_repr_go_parse_A_const_286; if linked_2292 == nil { tmp7 = ifn_2293.Invoke_O_O__O(arg_2294, arg_2295) } else { tmp7 = linked_2292.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2291, arg_2294, arg_2295) }; arg_2289 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, f__4)).Ref(); var arg_2290 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1050000265); var tmp9 any; var root_2296 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_2297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2296, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2298 lang.IFn; if linked_2297 == nil { ifn_2298 = lang.IFn_Cast(root_2296) } else { ifn_2298 = nil }; var arg_2299 any = s__1050000266__3; if linked_2297 == nil { tmp9 = ifn_2298.Invoke_O__O(arg_2299) } else { tmp9 = linked_2297.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2296, arg_2299) }; arg_2290 = tmp8.Invoke_O__O(tmp9); if linked_2287 == nil { return ifn_2288.Invoke_O_O__O(arg_2289, arg_2290) } else { return linked_2287.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2286, arg_2289, arg_2290) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :458:1
func A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_fn__1050000271_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_fn__1050000271_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_fn__1050000271_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :458:1
func (t *A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_fn__1050000271_A) Ctor_O_O_I_O(c__j, c__b__1050000268 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_j = c__j; t.F_b__1050000268 = c__b__1050000268; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :458:1
func (t *A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_fn__1050000271_A) Invoke_O__O(self any) any { { var i__1050000267__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000267__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000267__1)); var root_2249 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_2250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2249, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2251 lang.IFn; if linked_2250 == nil { ifn_2251 = lang.IFn_Cast(root_2249) } else { ifn_2251 = nil }; var arg_2252 any = t.F_b__1050000268; var arg_2253 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_72, nil); var tmp3 any; var root_2254 any = A_arbace_repr_go_parse_A_const_247.GetRawRoot__O(); var linked_2255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2254, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2256 lang.IFn; if linked_2255 == nil { ifn_2256 = lang.IFn_Cast(root_2254) } else { ifn_2256 = nil }; var arg_2257 any = t.F_j; var arg_2258 any = A_arbace_repr_go_parse_A_const_285; if linked_2255 == nil { tmp3 = ifn_2256.Invoke_O_O__O(arg_2257, arg_2258) } else { tmp3 = linked_2255.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2254, arg_2257, arg_2258) }; arg_2253 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, f__2)).Ref(); if linked_2250 == nil { ifn_2251.Invoke_O_O__O(arg_2252, arg_2253) } else { linked_2250.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2249, arg_2252, arg_2253) }; i__1050000267__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000267__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_parse_check_job_A_New() *A_arbace_repr_go_parse_check_job_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_job_A{}; t.Ctor(); return t }
//line :460:1
func (t *A_arbace_repr_go_parse_check_job_A) Ctor() {}
//line :460:1
func (t *A_arbace_repr_go_parse_check_job_A) Invoke_O_O_O_O_O__O(self, goroot_forms__0, j__1, path__2, write__3 any) any { var tmp1 any; tmp39 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var t0__7 int64 = jrt.System_NanoTime__J(); var d__8 any








	if jrt.J2g_Truth(path__2) { var root_2302 any = A_arbace_repr_go_parse_A_const_287.GetRawRoot__O(); var linked_2303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2302, aot_arbace_repr_go_read.A_arbace_repr_go_read_read_dump_A_fn_class); var ifn_2304 lang.IFn; if linked_2303 == nil { ifn_2304 = lang.IFn_Cast(root_2302) } else { ifn_2304 = nil }; var arg_2305 any = path__2; if linked_2303 == nil { d__8 = ifn_2304.Invoke_O__O(arg_2305) } else { d__8 = linked_2303.(*aot_arbace_repr_go_read.A_arbace_repr_go_read_read_dump_A).Invoke_O_O__O(root_2302, arg_2305) } } else { d__8 = nil }
//line :460:1
	var t1__9 int64 = jrt.System_NanoTime__J(); var n__10 any; var root_2306 any = A_arbace_repr_go_parse_A_const_288.GetRawRoot__O(); var linked_2307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2306, A_arbace_repr_go_parse_native_dump_A_fn_class); var ifn_2308 lang.IFn










	if linked_2307 == nil { ifn_2308 = lang.IFn_Cast(root_2306) } else { ifn_2308 = nil }; var arg_2309 any = goroot_forms__0; var arg_2310 any = j__1; if linked_2307 == nil { n__10 = ifn_2308.Invoke_O_O__O(arg_2309, arg_2310) } else { n__10 = linked_2307.(*A_arbace_repr_go_parse_native_dump_A).Invoke_O_O_O__O(root_2306, arg_2309, arg_2310) }
//line :460:1
	var t2__11 int64 = jrt.System_NanoTime__J(); var base__12 any; var tmp2 any = A_arbace_repr_go_parse_A_const_78; var tmp3 any = A_arbace_repr_go_parse_A_const_78.Invoke_O__O(j__1); var tmp4 any = A_arbace_repr_go_parse_A_const_184; var tmp5 any = A_arbace_repr_go_parse_A_const_289; var tmp6 any; var root_2311 any = A_arbace_repr_go_parse_A_const_247.GetRawRoot__O(); var linked_2312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2311, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2313 lang.IFn












	if linked_2312 == nil { ifn_2313 = lang.IFn_Cast(root_2311) } else { ifn_2313 = nil }; var arg_2314 any = j__1; var arg_2315 any = A_arbace_repr_go_parse_A_const_290; if linked_2312 == nil { tmp6 = ifn_2313.Invoke_O_O__O(arg_2314, arg_2315) } else { tmp6 = linked_2312.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2311, arg_2314, arg_2315) }
//line :460:1
	var tmp7 any = tmp6; var tmp8 any = A_arbace_repr_go_parse_A_const_189; var tmp9 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_parse_A_const_189.Invoke_O__O(j__1))).Ref(); var tmp10 any = A_arbace_repr_go_parse_A_const_291; var tmp11 any; var root_2316 any = A_arbace_repr_go_parse_A_const_292.GetRawRoot__O(); var linked_2317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2316, A_arbace_repr_go_parse_job_keys_A_fn_class); var ifn_2318 lang.IFn












	if linked_2317 == nil { ifn_2318 = lang.IFn_Cast(root_2316) } else { ifn_2318 = nil }; var arg_2319 any = j__1; if linked_2317 == nil { tmp11 = ifn_2318.Invoke_O__O(arg_2319) } else { tmp11 = linked_2317.(*A_arbace_repr_go_parse_job_keys_A).Invoke_O_O__O(root_2316, arg_2319) }
//line :460:1
	base__12 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, path__2, tmp5, tmp7, tmp8, tmp9, tmp10, tmp11))













	var tmp12 any; var and__1927000168__auto____13 any = write__3; if jrt.J2g_Truth(and__1927000168__auto____13) { var root_2419 any = A_arbace_repr_go_parse_A_const_75.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2421 lang.IFn; if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any = A_arbace_repr_go_parse_A_const_226.Invoke_O__O(n__10); if linked_2420 == nil { tmp12 = ifn_2421.Invoke_O__O(arg_2422) } else { tmp12 = linked_2420.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2419, arg_2422) } } else { tmp12 = and__1927000168__auto____13 }; if jrt.J2g_Truth(tmp12) { lang.IFn_Cast(write__3).Invoke_O__O(n__10) }
	var tmp13 any; var and__1927000168__auto____13_2 any = A_arbace_repr_go_parse_A_const_226.Invoke_O__O(n__10)
	if jrt.J2g_Truth(and__1927000168__auto____13_2) { tmp13 = d__8 } else { tmp13 = and__1927000168__auto____13_2 }
//line :475:1
	if jrt.J2g_Truth(tmp13) {
		var root_2320 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_2321 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2320, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2322 lang.IFn; if linked_2321 == nil { ifn_2322 = lang.IFn_Cast(root_2320) } else { ifn_2322 = nil }; var arg_2323 any = base__12; var arg_2324 any = A_arbace_repr_go_parse_A_const_293; var arg_2325 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_96, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_parse_A_const_201.Invoke_O__O(n__10), nil, A_arbace_repr_go_parse_A_const_226.Invoke_O__O(n__10))).Ref(); if linked_2321 == nil { tmp1 = ifn_2322.Invoke_O_O_O__O(arg_2323, arg_2324, arg_2325) } else { tmp1 = linked_2321.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2320, arg_2323, arg_2324, arg_2325) } } else {
//line :475:1
			if jrt.J2g_Truth(A_arbace_repr_go_parse_A_const_226.Invoke_O__O(n__10)) {

				var root_2326 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_2327 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2326, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2328 lang.IFn; if linked_2327 == nil { ifn_2328 = lang.IFn_Cast(root_2326) } else { ifn_2328 = nil }; var arg_2329 any = base__12; var arg_2330 any = A_arbace_repr_go_parse_A_const_294; var arg_2331 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_96, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_parse_A_const_201.Invoke_O__O(n__10), nil, A_arbace_repr_go_parse_A_const_226.Invoke_O__O(n__10))).Ref(); if linked_2327 == nil { tmp1 = ifn_2328.Invoke_O_O_O__O(arg_2329, arg_2330, arg_2331) } else { tmp1 = linked_2327.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2326, arg_2329, arg_2330, arg_2331) } } else {
//line :475:1
					if lang.Util_Identical_O_O__Z_NoInit(d__8, nil) {


						var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_196.GetRawRoot__O()); var tmp15 any = A_arbace_repr_go_parse_A_const_295; var tmp16 any = jrt.Boolean_TRUE.Ref(); var tmp17 any = A_arbace_repr_go_parse_A_const_66; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_152.GetRawRoot__O()); var tmp19 any; var root_2347 any = A_arbace_repr_go_parse_A_const_159.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2347, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_2349 lang.IFn; if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any = A_arbace_repr_go_parse_A_const_296.GetRawRoot__O(); var arg_2351 any = A_arbace_repr_go_parse_A_const_227; if linked_2348 == nil { tmp19 = ifn_2349.Invoke_O_O__O(arg_2350, arg_2351) } else { tmp19 = linked_2348.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_2347, arg_2350, arg_2351) }; var tmp20 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp18.Invoke_O_O__O(tmp19, A_arbace_repr_go_parse_A_const_189.Invoke_O__O(n__10)))).Ref(); var tmp21 any = A_arbace_repr_go_parse_A_const_256; tmp1 = tmp14.Invoke_O_O_O_O_O_O_O__O(base__12, tmp15, tmp16, tmp17, tmp20, tmp21, A_arbace_repr_go_parse_A_const_256.Invoke_O__O(n__10)) } else {
//line :475:1
							if A_arbace_repr_go_parse_A_const_68 != nil { var df__13 any; var root_2352 any = A_arbace_repr_go_parse_A_const_277.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, A_arbace_repr_go_parse_diff_A_fn_class); var ifn_2354 lang.IFn




								if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any; var root_2358 any = A_arbace_repr_go_parse_A_const_297.GetRawRoot__O(); var linked_2359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2358, A_arbace_repr_go_parse_tree_of_A_fn_class); var ifn_2360 lang.IFn; if linked_2359 == nil { ifn_2360 = lang.IFn_Cast(root_2358) } else { ifn_2360 = nil }; var arg_2361 any = d__8; if linked_2359 == nil { arg_2355 = ifn_2360.Invoke_O__O(arg_2361) } else { arg_2355 = linked_2359.(*A_arbace_repr_go_parse_tree_of_A).Invoke_O_O__O(root_2358, arg_2361) }; var arg_2356 any; var root_2362 any = A_arbace_repr_go_parse_A_const_297.GetRawRoot__O(); var linked_2363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2362, A_arbace_repr_go_parse_tree_of_A_fn_class); var ifn_2364 lang.IFn; if linked_2363 == nil { ifn_2364 = lang.IFn_Cast(root_2362) } else { ifn_2364 = nil }; var arg_2365 any = n__10; if linked_2363 == nil { arg_2356 = ifn_2364.Invoke_O__O(arg_2365) } else { arg_2356 = linked_2363.(*A_arbace_repr_go_parse_tree_of_A).Invoke_O_O__O(root_2362, arg_2365) }; var arg_2357 any = lang.PersistentVector_EMPTY.Ref(); if linked_2353 == nil { df__13 = ifn_2354.Invoke_O_O_O__O(arg_2355, arg_2356, arg_2357) } else { df__13 = linked_2353.(*A_arbace_repr_go_parse_diff_A).Invoke_O_O_O_O__O(root_2352, arg_2355, arg_2356, arg_2357) }
//line :475:1
								var G__1050000276__14_ any; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_196.GetRawRoot__O()); var tmp23 any = A_arbace_repr_go_parse_A_const_66; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_152.GetRawRoot__O()); var tmp25 any; var root_2383 any = A_arbace_repr_go_parse_A_const_159.GetRawRoot__O(); var linked_2384 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2383, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_2385 lang.IFn





								if linked_2384 == nil { ifn_2385 = lang.IFn_Cast(root_2383) } else { ifn_2385 = nil }; var arg_2386 any = A_arbace_repr_go_parse_A_const_296.GetRawRoot__O(); var arg_2387 any = A_arbace_repr_go_parse_A_const_227; if linked_2384 == nil { tmp25 = ifn_2385.Invoke_O_O__O(arg_2386, arg_2387) } else { tmp25 = linked_2384.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_2383, arg_2386, arg_2387) }; var tmp26 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp24.Invoke_O_O__O(tmp25, A_arbace_repr_go_parse_A_const_189.Invoke_O__O(n__10)))).Ref(); var tmp27 any = A_arbace_repr_go_parse_A_const_298; var tmp28 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(t1__9, t0__7), 1000000.0)).Ref(); var tmp29 any = A_arbace_repr_go_parse_A_const_299; var tmp30 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(t2__11, t1__9), 1000000.0)).Ref(); var tmp31 any = A_arbace_repr_go_parse_A_const_256; G__1050000276__14_ = tmp22.Invoke_O_O_O_O_O_O_O_O_O__O(base__12, tmp23, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, A_arbace_repr_go_parse_A_const_256.Invoke_O__O(n__10)); if jrt.J2g_Truth(df__13) {


									var root_2388 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_2389 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2388, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2390 lang.IFn; if linked_2389 == nil { ifn_2390 = lang.IFn_Cast(root_2388) } else { ifn_2390 = nil }; var arg_2391 any = G__1050000276__14_; var arg_2392 any = A_arbace_repr_go_parse_A_const_300; var arg_2393 any; var tmp32 any; var root_2394 any = A_arbace_repr_go_parse_A_const_301.GetRawRoot__O(); var linked_2395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2394, A_arbace_repr_go_parse_file_at_A_fn_class); var ifn_2396 lang.IFn; if linked_2395 == nil { ifn_2396 = lang.IFn_Cast(root_2394) } else { ifn_2396 = nil }; var arg_2397 any = d__8; var arg_2398 any; var root_2399 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_2400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2399, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2401 lang.IFn; if linked_2400 == nil { ifn_2401 = lang.IFn_Cast(root_2399) } else { ifn_2401 = nil }; var arg_2402 any = df__13; if linked_2400 == nil { arg_2398 = ifn_2401.Invoke_O__O(arg_2402) } else { arg_2398 = linked_2400.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2399, arg_2402) }; if linked_2395 == nil { tmp32 = ifn_2396.Invoke_O_O__O(arg_2397, arg_2398) } else { tmp32 = linked_2395.(*A_arbace_repr_go_parse_file_at_A).Invoke_O_O_O__O(root_2394, arg_2397, arg_2398) }; var tmp33 any = tmp32; var tmp34 any; var root_2403 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2403, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2405 lang.IFn; if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any = df__13; if linked_2404 == nil { tmp34 = ifn_2405.Invoke_O__O(arg_2406) } else { tmp34 = linked_2404.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2403, arg_2406) }; var tmp35 any = tmp34; var tmp36 any; var root_2407 any = A_arbace_repr_go_parse_A_const_302.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2407, A_arbace_repr_go_parse_short_str_A_fn_class); var ifn_2409 lang.IFn; if linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any; var root_2411 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_2412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2411, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2413 lang.IFn; if linked_2412 == nil { ifn_2413 = lang.IFn_Cast(root_2411) } else { ifn_2413 = nil }; var arg_2414 any = df__13; if linked_2412 == nil { arg_2410 = ifn_2413.Invoke_O__O(arg_2414) } else { arg_2410 = linked_2412.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2411, arg_2414) }; if linked_2408 == nil { tmp36 = ifn_2409.Invoke_O__O(arg_2410) } else { tmp36 = linked_2408.(*A_arbace_repr_go_parse_short_str_A).Invoke_O_O__O(root_2407, arg_2410) }; var tmp37 any = tmp36; var tmp38 any; var root_2415 any = A_arbace_repr_go_parse_A_const_302.GetRawRoot__O(); var linked_2416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2415, A_arbace_repr_go_parse_short_str_A_fn_class); var ifn_2417 lang.IFn; if linked_2416 == nil { ifn_2417 = lang.IFn_Cast(root_2415) } else { ifn_2417 = nil }; var arg_2418 any = lang.RT_Nth_O_I__O_NoInit(df__13, lang.RT_IntCast_J__I_NoInit(2)); if linked_2416 == nil { tmp38 = ifn_2417.Invoke_O__O(arg_2418) } else { tmp38 = linked_2416.(*A_arbace_repr_go_parse_short_str_A).Invoke_O_O__O(root_2415, arg_2418) }; arg_2393 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp33, tmp35, tmp37, tmp38); if linked_2389 == nil { tmp1 = ifn_2390.Invoke_O_O_O__O(arg_2391, arg_2392, arg_2393) } else { tmp1 = linked_2389.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2388, arg_2391, arg_2392, arg_2393) } } else {
//line :481:1
										tmp1 = G__1050000276__14_ } } else {
//line :475:1
											tmp1 = nil } } } } }; return nil }(); if /*line :460:1*/ tmp39 != nil { if true { var e__7 jrt.Throwable_I = tmp39; var tmp40 any = A_arbace_repr_go_parse_A_const_78; var tmp41 any = A_arbace_repr_go_parse_A_const_78.Invoke_O__O(j__1); var tmp42 any = A_arbace_repr_go_parse_A_const_184; var tmp43 any = A_arbace_repr_go_parse_A_const_291; var tmp44 any; var root_2423 any = A_arbace_repr_go_parse_A_const_292.GetRawRoot__O(); var linked_2424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2423, A_arbace_repr_go_parse_job_keys_A_fn_class); var ifn_2425 lang.IFn

























												if linked_2424 == nil { ifn_2425 = lang.IFn_Cast(root_2423) } else { ifn_2425 = nil }; var arg_2426 any = j__1; if linked_2424 == nil { tmp44 = ifn_2425.Invoke_O__O(arg_2426) } else { tmp44 = linked_2424.(*A_arbace_repr_go_parse_job_keys_A).Invoke_O_O__O(root_2423, arg_2426) }
//line :460:1
												var tmp45 any = tmp44; var tmp46 any = A_arbace_repr_go_parse_A_const_293; var tmp47 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_96, nil); var tmp48 any; var root_2427 any = A_arbace_repr_go_parse_A_const_273.GetRawRoot__O(); var linked_2428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2427, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_2429 lang.IFn

























												if linked_2428 == nil { ifn_2429 = lang.IFn_Cast(root_2427) } else { ifn_2429 = nil }; var arg_2430 any = e__7; if linked_2428 == nil { tmp48 = ifn_2429.Invoke_O__O(arg_2430) } else { tmp48 = linked_2428.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_2427, arg_2430) }
//line :460:1
												tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp41, tmp42, path__2, tmp43, tmp45, tmp46, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp47, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp48)).GetName__String().Ref(), nil, e__7.GetMessage__String().Ref())).Ref())) } }; return tmp1 }





























func A_arbace_repr_go_parse_write_native_BANG__A_New() *A_arbace_repr_go_parse_write_native_BANG__A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_write_native_BANG__A{}; t.Ctor(); return t }
//line :490:1
func (t *A_arbace_repr_go_parse_write_native_BANG__A) Ctor() {}
//line :490:1
func (t *A_arbace_repr_go_parse_write_native_BANG__A) Invoke_O_O_O_O__O(self, n__0, out__1, rel__2 any) any { var f__4 any = jrt.File_New_String_String(jrt.String_Cast(out__1), jrt.String_Cast(rel__2));




	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(f__4)).GetParentFile__File()).Mkdirs__Z()); var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_repr_go_parse_A_const_303.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_192, nil, Lit_141); var tmp3 any; var root_2449 any = A_arbace_repr_go_parse_A_const_305.GetRawRoot__O(); var linked_2450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2449, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2451 lang.IFn; if
	linked_2450 == nil { ifn_2451 = lang.IFn_Cast(root_2449) } else { ifn_2451 = nil }; var arg_2452 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_240.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_repr_go_parse_A_const_306, nil, A_arbace_repr_go_parse_A_const_307, nil, A_arbace_repr_go_parse_A_const_308, jrt.Boolean_FALSE.Ref()); if linked_2450 == nil { ifn_2451.Invoke_O__O(arg_2452) } else { linked_2450.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2449, arg_2452) }; var tmp4 any = A_arbace_repr_go_parse_write_native_BANG__fn__1050000278_A_New_O(n__0); var tmp5 *jrt.Class; var fncls__2448 *jrt.Class = A_arbace_repr_go_parse_write_native_BANG__fn__1050000278_A_fn_class; if fncls__2448 == nil { var fncls__2448d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_193, false); A_arbace_repr_go_parse_write_native_BANG__fn__1050000278_A_fn_class = fncls__2448d; tmp5 = fncls__2448d } else { tmp5 = fncls__2448 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O(); return /*line :496:1*/ tmp1.Invoke_O_O__O(f__4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3, nil)).Ref()) }
func A_arbace_repr_go_parse_write_native_BANG__fn__1050000278_A_New_O(p0 any) *A_arbace_repr_go_parse_write_native_BANG__fn__1050000278_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_write_native_BANG__fn__1050000278_A{}; t.Ctor_O(p0); return t }
//line :497:1
func (t *A_arbace_repr_go_parse_write_native_BANG__fn__1050000278_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :497:1
func (t *A_arbace_repr_go_parse_write_native_BANG__fn__1050000278_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_70.GetRawRoot__O()); var tmp3 any; var root_2440 any = A_arbace_repr_go_parse_A_const_217.GetRawRoot__O(); var linked_2441 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2440, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_2442 lang.IFn; if linked_2441 == nil { ifn_2442 = lang.IFn_Cast(root_2440) } else { ifn_2442 = nil }; var arg_2443 any; var t_ any = t.F_n; t.F_n = nil; arg_2443 = t_; var arg_2444 any = A_arbace_repr_go_parse_A_const_256; if linked_2441 == nil { tmp3 = ifn_2442.Invoke_O_O__O(arg_2443, arg_2444) } else { tmp3 = linked_2441.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_2440, arg_2443, arg_2444) }; tmp1 = tmp2.Invoke_O__O(tmp3) }
//line :497:1
	return nil }(); var root_2445 any = A_arbace_repr_go_parse_A_const_304.GetRawRoot__O(); var linked_2446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2445, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2447 lang.IFn; if linked_2446 == nil { ifn_2447 = lang.IFn_Cast(root_2445) } else { ifn_2447 = nil }; if linked_2446 == nil { ifn_2447.Invoke__O() } else { linked_2446.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2445) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }



func A_arbace_repr_go_parse_read_spec_A_New() *A_arbace_repr_go_parse_read_spec_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_read_spec_A{}; t.Ctor(); return t }
//line :501:1
func (t *A_arbace_repr_go_parse_read_spec_A) Ctor() {}
//line :501:1
func (t *A_arbace_repr_go_parse_read_spec_A) Invoke_O_O__O(self, f__0 any) any {
	var root_2473 any = A_arbace_repr_go_parse_A_const_305.GetRawRoot__O(); var linked_2474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2473, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2475 lang.IFn; if linked_2474 == nil { ifn_2475 = lang.IFn_Cast(root_2473) } else { ifn_2475 = nil }; var arg_2476 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_240.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_310, jrt.Boolean_FALSE.Ref()); if linked_2474 == nil { ifn_2475.Invoke_O__O(arg_2476) } else { linked_2474.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2473, arg_2476) }
//line :501:1
	var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
		{ var root_2462 any = A_arbace_repr_go_parse_A_const_309.GetRawRoot__O(); var linked_2463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2462, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_2464 lang.IFn; if linked_2463 == nil { ifn_2464 = lang.IFn_Cast(root_2462) } else { ifn_2464 = nil }; var arg_2465 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_15.GetRawRoot__O()).Invoke_O__O(f__0); if linked_2463 == nil { tmp1 = ifn_2464.Invoke_O__O(arg_2465) } else { tmp1 = linked_2463.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_2462, arg_2465) } }
//line :501:1
		return nil }(); var root_2470 any = A_arbace_repr_go_parse_A_const_304.GetRawRoot__O(); var linked_2471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2470, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2472 lang.IFn
	if linked_2471 == nil { ifn_2472 = lang.IFn_Cast(root_2470) } else { ifn_2472 = nil }; if linked_2471 == nil { ifn_2472.Invoke__O() } else { linked_2471.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2470) }
//line :501:1
	if tmp2 != nil { panic(tmp2) }; return tmp1
}

func A_arbace_repr_go_parse_spec_jobs_A_New() *A_arbace_repr_go_parse_spec_jobs_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_spec_jobs_A{}; t.Ctor(); return t }
//line :504:1
func (t *A_arbace_repr_go_parse_spec_jobs_A) Ctor() {}
//line :504:1
func (t *A_arbace_repr_go_parse_spec_jobs_A) Invoke_O_O__O(self, spec__0 any) any { var t0__2 int64 = jrt.System_NanoTime__J(); var all__3 any; var root_2482 any = A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_2483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2482, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2484 lang.IFn; if



	linked_2483 == nil { ifn_2484 = lang.IFn_Cast(root_2482) } else { ifn_2484 = nil }; var arg_2485 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_152.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_parse_spec_jobs_fn__1050000282_A_New(); var tmp3 *jrt.Class; var fncls__2570 *jrt.Class = A_arbace_repr_go_parse_spec_jobs_fn__1050000282_A_fn_class; if fncls__2570 == nil { var fncls__2570d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_178, false); A_arbace_repr_go_parse_spec_jobs_fn__1050000282_A_fn_class = fncls__2570d; tmp3 = fncls__2570d } else { tmp3 = fncls__2570 }; arg_2485 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), A_arbace_repr_go_parse_A_const_314.Invoke_O__O(spec__0)); if linked_2483 == nil { all__3 = ifn_2484.Invoke_O__O(arg_2485) } else { all__3 = linked_2483.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2482, arg_2485) }; var tmp4 any; var root_2571 any = /*line :504:1*/A_arbace_repr_go_parse_A_const_315.GetRawRoot__O(); var linked_2572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2571, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_2573 lang.IFn; if







	linked_2572 == nil { ifn_2573 = lang.IFn_Cast(root_2571) } else { ifn_2573 = nil }; var arg_2574 any = A_arbace_repr_go_parse_A_const_189; var arg_2575 any = all__3; if linked_2572 == nil { tmp4 = ifn_2573.Invoke_O_O__O(arg_2574, arg_2575) } else { tmp4 = linked_2572.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_2571, arg_2574, arg_2575) }; var tmp5 any = tmp4; var tmp6 any; var root_2576 any = /*line :504:1*/A_arbace_repr_go_parse_A_const_315.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_2578 lang.IFn; if







	linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any = A_arbace_repr_go_parse_A_const_316; var arg_2580 any = all__3; if linked_2577 == nil { tmp6 = ifn_2578.Invoke_O_O__O(arg_2579, arg_2580) } else { tmp6 = linked_2577.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_2576, arg_2579, arg_2580) }; return /*line :504:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__2), 1000000.0)).Ref()) }



func A_arbace_repr_go_parse_spec_jobs_fn__1050000282_A_New() *A_arbace_repr_go_parse_spec_jobs_fn__1050000282_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_spec_jobs_fn__1050000282_A{}; t.Ctor(); return t }
//line :508:1
func (t *A_arbace_repr_go_parse_spec_jobs_fn__1050000282_A) Ctor() {}
//line :508:1
func (t *A_arbace_repr_go_parse_spec_jobs_fn__1050000282_A) Invoke_O_O__O(self, l__1 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_A_New_O(l__1); var tmp2 *jrt.Class; var fncls__2565 *jrt.Class = A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_A_fn_class; if
												fncls__2565 == nil { var fncls__2565d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_179, false); A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_A_fn_class = fncls__2565d; tmp2 = fncls__2565d } else { tmp2 = fncls__2565 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_2566 any = A_arbace_repr_go_parse_A_const_313.GetRawRoot__O(); var linked_2567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2566, aot_arbace_repr_go_load.A_arbace_repr_go_load_jobs_A_fn_class); var ifn_2568 lang.IFn; if linked_2567 == nil { ifn_2568 = lang.IFn_Cast(root_2566) } else { ifn_2568 = nil }; var arg_2569 any = l__1; if linked_2567 == nil { tmp4 = ifn_2568.Invoke_O__O(arg_2569) } else { tmp4 = linked_2567.(*aot_arbace_repr_go_load.A_arbace_repr_go_load_jobs_A).Invoke_O_O__O(root_2566, arg_2569) }; return tmp3.Invoke_O__O(tmp4) }
//line :509:1
func A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_A_New_O(p0 any) *A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_A{}; t.Ctor_O(p0); return t }
//line :509:1
func (t *A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_A) Ctor_O(c__l any) { t.F_l = c__l }
//line :509:1
func (t *A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_A) Invoke_O_O__O(self, s__1050000284__1 any) any { var tmp1 any = A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_A_New_O_O_O(s__1050000284__1, t.F_l, self); var tmp2 *jrt.Class; var fncls__2564 *jrt.Class = A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_A_fn_class; if fncls__2564 == nil { var fncls__2564d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_180, false); A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_A_fn_class = fncls__2564d; tmp2 = fncls__2564d } else { tmp2 = fncls__2564 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :509:1
func A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :509:1
func (t *A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_A) Ctor_O_O_O(c__s__1050000284, c__l, c__iter__1050000283 any) { t.F_s__1050000284 = c__s__1050000284; t.F_l = c__l; t.F_iter__1050000283 = c__iter__1050000283 }
//line :509:1
func (t *A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_A) Invoke_O__O(self any) any { { var s__1050000284__1 any; var t_ any = t.F_s__1050000284; t.F_s__1050000284 = nil; s__1050000284__1 = t_; for { var temp__1927000414__auto____2 any; var root_2491 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_2492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2491, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2493 lang.IFn; if linked_2492 == nil { ifn_2493 = lang.IFn_Cast(root_2491) } else { ifn_2493 = nil }; var arg_2494 any = s__1050000284__1; if linked_2492 == nil { temp__1927000414__auto____2 = ifn_2493.Invoke_O__O(arg_2494) } else { temp__1927000414__auto____2 = linked_2492.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2491, arg_2494) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000284__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2495 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_2496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2495, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2497 lang.IFn; if linked_2496 == nil { ifn_2497 = lang.IFn_Cast(root_2495) } else { ifn_2497 = nil }; var arg_2498 any = s__1050000284__3; if linked_2496 == nil { tmp1 = ifn_2497.Invoke_O__O(arg_2498) } else { tmp1 = linked_2496.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2495, arg_2498) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2499 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_2500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2499, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2501 lang.IFn; if linked_2500 == nil { ifn_2501 = lang.IFn_Cast(root_2499) } else { ifn_2501 = nil }; var arg_2502 any = s__1050000284__3; if linked_2500 == nil { c__1927001037__auto____4 = ifn_2501.Invoke_O__O(arg_2502) } else { c__1927001037__auto____4 = linked_2500.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2499, arg_2502) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000286__6 any; var root_2503 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_2504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2503, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2505 lang.IFn; if linked_2504 == nil { ifn_2505 = lang.IFn_Cast(root_2503) } else { ifn_2505 = nil }; var arg_2506 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2504 == nil { b__1050000286__6 = ifn_2505.Invoke_O__O(arg_2506) } else { b__1050000286__6 = linked_2504.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2503, arg_2506) }; var tmp2 any = A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_fn__1050000289_A_New_O_O_I_O(t.F_l, b__1050000286__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2520 *jrt.Class = A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_fn__1050000289_A_fn_class; if fncls__2520 == nil { var fncls__2520d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_181, false); A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_fn__1050000289_A_fn_class = fncls__2520d; tmp3 = fncls__2520d } else { tmp3 = fncls__2520 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2521 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_2522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2521, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2523 lang.IFn; if linked_2522 == nil { ifn_2523 = lang.IFn_Cast(root_2521) } else { ifn_2523 = nil }; var arg_2524 any; var root_2526 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_2527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2526, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2528 lang.IFn; if linked_2527 == nil { ifn_2528 = lang.IFn_Cast(root_2526) } else { ifn_2528 = nil }; var arg_2529 any = b__1050000286__6; if linked_2527 == nil { arg_2524 = ifn_2528.Invoke_O__O(arg_2529) } else { arg_2524 = linked_2527.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2526, arg_2529) }; var arg_2525 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000283); var tmp5 any; var root_2530 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_2531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2530, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2532 lang.IFn; if linked_2531 == nil { ifn_2532 = lang.IFn_Cast(root_2530) } else { ifn_2532 = nil }; var arg_2533 any = s__1050000284__3; if linked_2531 == nil { tmp5 = ifn_2532.Invoke_O__O(arg_2533) } else { tmp5 = linked_2531.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2530, arg_2533) }; arg_2525 = tmp4.Invoke_O__O(tmp5); if linked_2522 == nil { return ifn_2523.Invoke_O_O__O(arg_2524, arg_2525) } else { return linked_2522.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2521, arg_2524, arg_2525) } } else { var root_2534 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_2535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2534, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2536 lang.IFn; if linked_2535 == nil { ifn_2536 = lang.IFn_Cast(root_2534) } else { ifn_2536 = nil }; var arg_2537 any; var root_2539 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_2540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2539, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2541 lang.IFn; if linked_2540 == nil { ifn_2541 = lang.IFn_Cast(root_2539) } else { ifn_2541 = nil }; var arg_2542 any = b__1050000286__6; if linked_2540 == nil { arg_2537 = ifn_2541.Invoke_O__O(arg_2542) } else { arg_2537 = linked_2540.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2539, arg_2542) }; var arg_2538 any; if linked_2535 == nil { return ifn_2536.Invoke_O_O__O(arg_2537, arg_2538) } else { return linked_2535.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2534, arg_2537, arg_2538) } } } else { var j__4 any; var root_2543 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_2544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2543, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2545 lang.IFn; if linked_2544 == nil { ifn_2545 = lang.IFn_Cast(root_2543) } else { ifn_2545 = nil }; var arg_2546 any = s__1050000284__3; if linked_2544 == nil { j__4 = ifn_2545.Invoke_O__O(arg_2546) } else { j__4 = linked_2544.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2543, arg_2546) }; var root_2547 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_2548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2547, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2549 lang.IFn; if linked_2548 == nil { ifn_2549 = lang.IFn_Cast(root_2547) } else { ifn_2549 = nil }; var arg_2550 any; var G__1050000292__5_ any = j__4
																	if jrt.J2g_Truth(A_arbace_repr_go_parse_A_const_311.Invoke_O__O(t.F_l)) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_196.GetRawRoot__O()); var tmp7 any = A_arbace_repr_go_parse_A_const_78; var tmp8 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_parse_A_const_311.Invoke_O__O(t.F_l), nil, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(j__4))).Ref(); var tmp9 any = A_arbace_repr_go_parse_A_const_312; arg_2550 = tmp6.Invoke_O_O_O_O_O__O(G__1050000292__5_, tmp7, tmp8, tmp9, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(j__4)) } else { arg_2550 = G__1050000292__5_ }
//line :509:1
	var arg_2551 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1050000283); var tmp11 any; var root_2560 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2560, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2562 lang.IFn; if linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; var arg_2563 any = s__1050000284__3; if linked_2561 == nil { tmp11 = ifn_2562.Invoke_O__O(arg_2563) } else { tmp11 = linked_2561.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2560, arg_2563) }; arg_2551 = tmp10.Invoke_O__O(tmp11); if linked_2548 == nil { return ifn_2549.Invoke_O_O__O(arg_2550, arg_2551) } else { return linked_2548.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2547, arg_2550, arg_2551) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :509:1
func A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_fn__1050000289_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_fn__1050000289_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_fn__1050000289_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :509:1
func (t *A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_fn__1050000289_A) Ctor_O_O_I_O(c__l, c__b__1050000286 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_l = c__l; t.F_b__1050000286 = c__b__1050000286; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :509:1
func (t *A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_fn__1050000289_A) Invoke_O__O(self any) any { { var i__1050000285__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000285__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000285__1)); var root_2507 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_2508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2507, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2509 lang.IFn; if linked_2508 == nil { ifn_2509 = lang.IFn_Cast(root_2507) } else { ifn_2509 = nil }; var arg_2510 any = t.F_b__1050000286; var arg_2511 any; var G__1050000290__3_ any = j__2
																			if jrt.J2g_Truth(A_arbace_repr_go_parse_A_const_311.Invoke_O__O(t.F_l)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_196.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_parse_A_const_78; var tmp4 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_parse_A_const_311.Invoke_O__O(t.F_l), nil, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(j__2))).Ref(); var tmp5 any = A_arbace_repr_go_parse_A_const_312; arg_2511 = tmp2.Invoke_O_O_O_O_O__O(G__1050000290__3_, tmp3, tmp4, tmp5, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(j__2)) } else { arg_2511 = G__1050000290__3_ }
//line :509:1
	if linked_2508 == nil { ifn_2509.Invoke_O_O__O(arg_2510, arg_2511) } else { linked_2508.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2507, arg_2510, arg_2511) }; i__1050000285__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000285__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_repr_go_parse_helper_results_A_New() *A_arbace_repr_go_parse_helper_results_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_helper_results_A{}; t.Ctor(); return t }
//line :514:1
func (t *A_arbace_repr_go_parse_helper_results_A) Ctor() {}
//line :514:1
func (t *A_arbace_repr_go_parse_helper_results_A) Invoke_O_O__O(self, tsv__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = tsv__0; if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_New_String(jrt.String_Cast(tsv__0)).IsFile__Z()).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {
		var root_2581 any = A_arbace_repr_go_parse_A_const_236.GetRawRoot__O(); var linked_2582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2581, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2583 lang.IFn; if linked_2582 == nil { ifn_2583 = lang.IFn_Cast(root_2581) } else { ifn_2583 = nil }; var arg_2584 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2585 any; var iter__1927001039__auto____2 any; var tmp2 any = A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_A_New(); var tmp3 *jrt.Class; var fncls__2658 *jrt.Class = A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_A_fn_class; if fncls__2658 == nil { var fncls__2658d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_A_fn_class = fncls__2658d; tmp3 = fncls__2658d } else { tmp3 = fncls__2658 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp5 any; var root_2659 any = A_arbace_repr_go_parse_A_const_319.GetRawRoot__O(); var linked_2660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2659, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_2661 lang.IFn; if linked_2660 == nil { ifn_2661 = lang.IFn_Cast(root_2659) } else { ifn_2661 = nil }; var arg_2662 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_15.GetRawRoot__O()).Invoke_O__O(tsv__0); if linked_2660 == nil { tmp5 = ifn_2661.Invoke_O__O(arg_2662) } else { tmp5 = linked_2660.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_2659, arg_2662) }; arg_2585 = tmp4.Invoke_O__O(tmp5); if linked_2582 == nil { return ifn_2583.Invoke_O_O__O(arg_2584, arg_2585) } else { return linked_2582.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2581, arg_2584, arg_2585) } } else {
//line :517:1
			return lang.PersistentArrayMap_EMPTY.Ref() } }
func A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_A_New() *A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_A{}; t.Ctor(); return t }
//line :518:1
func (t *A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_A) Ctor() {}
//line :518:1
func (t *A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_A) Invoke_O_O__O(self, s__1050000298__1 any) any { var tmp1 any = A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_A_New_O_O(s__1050000298__1, self); var tmp2 *jrt.Class; var fncls__2657 *jrt.Class = A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_A_fn_class; if fncls__2657 == nil { var fncls__2657d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_A_fn_class = fncls__2657d; tmp2 = fncls__2657d } else { tmp2 = fncls__2657 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :518:1
func A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_A{}; t.Ctor_O_O(p0, p1); return t }
//line :518:1
func (t *A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_A) Ctor_O_O(c__s__1050000298, c__iter__1050000297 any) { t.F_s__1050000298 = c__s__1050000298; t.F_iter__1050000297 = c__iter__1050000297 }
//line :518:1
func (t *A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_A) Invoke_O__O(self any) any { { var s__1050000298__1 any; var t_ any = t.F_s__1050000298; t.F_s__1050000298 = nil; s__1050000298__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2586 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_2587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2586, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2588 lang.IFn; if linked_2587 == nil { ifn_2588 = lang.IFn_Cast(root_2586) } else { ifn_2588 = nil }; var arg_2589 any = s__1050000298__1; if linked_2587 == nil { temp__1927000414__auto____2 = ifn_2588.Invoke_O__O(arg_2589) } else { temp__1927000414__auto____2 = linked_2587.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2586, arg_2589) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000298__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2590 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_2591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2590, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2592 lang.IFn; if linked_2591 == nil { ifn_2592 = lang.IFn_Cast(root_2590) } else { ifn_2592 = nil }; var arg_2593 any = s__1050000298__3; if linked_2591 == nil { tmp1 = ifn_2592.Invoke_O__O(arg_2593) } else { tmp1 = linked_2591.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2590, arg_2593) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2594 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_2595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2594, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2596 lang.IFn; if linked_2595 == nil { ifn_2596 = lang.IFn_Cast(root_2594) } else { ifn_2596 = nil }; var arg_2597 any = s__1050000298__3; if linked_2595 == nil { c__1927001037__auto____4 = ifn_2596.Invoke_O__O(arg_2597) } else { c__1927001037__auto____4 = linked_2595.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2594, arg_2597) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000300__6 any; var root_2598 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_2599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2598, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2600 lang.IFn; if linked_2599 == nil { ifn_2600 = lang.IFn_Cast(root_2598) } else { ifn_2600 = nil }; var arg_2601 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2599 == nil { b__1050000300__6 = ifn_2600.Invoke_O__O(arg_2601) } else { b__1050000300__6 = linked_2599.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2598, arg_2601) }; var tmp2 any = A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_fn__1050000303_A_New_O_I_O(b__1050000300__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2612 *jrt.Class = A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_fn__1050000303_A_fn_class; if fncls__2612 == nil { var fncls__2612d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_fn__1050000303_A_fn_class = fncls__2612d; tmp3 = fncls__2612d } else { tmp3 = fncls__2612 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2613 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_2614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2613, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2615 lang.IFn; if linked_2614 == nil { ifn_2615 = lang.IFn_Cast(root_2613) } else { ifn_2615 = nil }; var arg_2616 any; var root_2618 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_2619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2618, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2620 lang.IFn; if linked_2619 == nil { ifn_2620 = lang.IFn_Cast(root_2618) } else { ifn_2620 = nil }; var arg_2621 any = b__1050000300__6; if linked_2619 == nil { arg_2616 = ifn_2620.Invoke_O__O(arg_2621) } else { arg_2616 = linked_2619.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2618, arg_2621) }; var arg_2617 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000297); var tmp5 any; var root_2622 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_2623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2622, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2624 lang.IFn; if linked_2623 == nil { ifn_2624 = lang.IFn_Cast(root_2622) } else { ifn_2624 = nil }; var arg_2625 any = s__1050000298__3; if linked_2623 == nil { tmp5 = ifn_2624.Invoke_O__O(arg_2625) } else { tmp5 = linked_2623.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2622, arg_2625) }; arg_2617 = tmp4.Invoke_O__O(tmp5); if linked_2614 == nil { return ifn_2615.Invoke_O_O__O(arg_2616, arg_2617) } else { return linked_2614.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2613, arg_2616, arg_2617) } } else { var root_2626 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_2627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2626, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2628 lang.IFn; if linked_2627 == nil { ifn_2628 = lang.IFn_Cast(root_2626) } else { ifn_2628 = nil }; var arg_2629 any; var root_2631 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_2632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2631, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2633 lang.IFn; if linked_2632 == nil { ifn_2633 = lang.IFn_Cast(root_2631) } else { ifn_2633 = nil }; var arg_2634 any = b__1050000300__6; if linked_2632 == nil { arg_2629 = ifn_2633.Invoke_O__O(arg_2634) } else { arg_2629 = linked_2632.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2631, arg_2634) }; var arg_2630 any; if linked_2627 == nil { return ifn_2628.Invoke_O_O__O(arg_2629, arg_2630) } else { return linked_2627.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2626, arg_2629, arg_2630) } } } else { var l__4 any; var root_2635 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_2636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2635, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2637 lang.IFn; if linked_2636 == nil { ifn_2637 = lang.IFn_Cast(root_2635) } else { ifn_2637 = nil }; var arg_2638 any = s__1050000298__3; if linked_2636 == nil { l__4 = ifn_2637.Invoke_O__O(arg_2638) } else { l__4 = linked_2636.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2635, arg_2638) }; var vec__1050000308__5 any; var root_2639 any = A_arbace_repr_go_parse_A_const_317.GetRawRoot__O(); var linked_2640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2639, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2641 lang.IFn
															if linked_2640 == nil { ifn_2641 = lang.IFn_Cast(root_2639) } else { ifn_2641 = nil }; var arg_2642 any = l__4; var arg_2643 any = A_arbace_repr_go_parse_A_const_318; if linked_2640 == nil { vec__1050000308__5 = ifn_2641.Invoke_O_O__O(arg_2642, arg_2643) } else { vec__1050000308__5 = linked_2640.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2639, arg_2642, arg_2643) }
//line :518:1
	var st__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000308__5, lang.RT_IntCast_J__I_NoInit(0), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000308__5, lang.RT_IntCast_J__I_NoInit(1), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000308__5, lang.RT_IntCast_J__I_NoInit(2), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000308__5, lang.RT_IntCast_J__I_NoInit(3), nil); var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000308__5, lang.RT_IntCast_J__I_NoInit(4), nil); var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000308__5, lang.RT_IntCast_J__I_NoInit(5), nil); var msg__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000308__5, lang.RT_IntCast_J__I_NoInit(6), nil); _ = ___8; _ = ___9; _ = ___10; _ = ___11; if jrt.J2g_Truth(k__7) { var root_2644 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_2645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2644, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2646 lang.IFn; if linked_2645 == nil { ifn_2646 = lang.IFn_Cast(root_2644) } else { ifn_2646 = nil }; var arg_2647 any = lang.Tuple_Create_O_O__IPersistentVector(k__7, lang.Tuple_Create_O_O__IPersistentVector(st__6, msg__12)); var arg_2648 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1050000297); var tmp7 any; var root_2649 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_2650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2649, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2651 lang.IFn; if linked_2650 == nil { ifn_2651 = lang.IFn_Cast(root_2649) } else { ifn_2651 = nil }; var arg_2652 any = s__1050000298__3; if linked_2650 == nil { tmp7 = ifn_2651.Invoke_O__O(arg_2652) } else { tmp7 = linked_2650.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2649, arg_2652) }; arg_2648 = tmp6.Invoke_O__O(tmp7); if linked_2645 == nil { return ifn_2646.Invoke_O_O__O(arg_2647, arg_2648) } else { return linked_2645.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2644, arg_2647, arg_2648) } } else { var tmp8 any; var root_2653 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_2654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2653, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2655 lang.IFn; if linked_2654 == nil { ifn_2655 = lang.IFn_Cast(root_2653) } else { ifn_2655 = nil }; var arg_2656 any = s__1050000298__3; if linked_2654 == nil { tmp8 = ifn_2655.Invoke_O__O(arg_2656) } else { tmp8 = linked_2654.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2653, arg_2656) }; s__1050000298__1 = tmp8; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :518:1
func A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_fn__1050000303_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_fn__1050000303_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_fn__1050000303_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :518:1
func (t *A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_fn__1050000303_A) Ctor_O_I_O(c__b__1050000300 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1050000300 = c__b__1050000300; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :518:1
func (t *A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_fn__1050000303_A) Invoke_O__O(self any) any { { var i__1050000299__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000299__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var l__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000299__1)); var vec__1050000304__3 any; var root_2602 any = A_arbace_repr_go_parse_A_const_317.GetRawRoot__O(); var linked_2603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2602, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2604 lang.IFn
																	if linked_2603 == nil { ifn_2604 = lang.IFn_Cast(root_2602) } else { ifn_2604 = nil }; var arg_2605 any = l__2; var arg_2606 any = A_arbace_repr_go_parse_A_const_318; if linked_2603 == nil { vec__1050000304__3 = ifn_2604.Invoke_O_O__O(arg_2605, arg_2606) } else { vec__1050000304__3 = linked_2603.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2602, arg_2605, arg_2606) }
//line :518:1
	var st__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000304__3, lang.RT_IntCast_J__I_NoInit(0), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000304__3, lang.RT_IntCast_J__I_NoInit(1), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000304__3, lang.RT_IntCast_J__I_NoInit(2), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000304__3, lang.RT_IntCast_J__I_NoInit(3), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000304__3, lang.RT_IntCast_J__I_NoInit(4), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000304__3, lang.RT_IntCast_J__I_NoInit(5), nil); var msg__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000304__3, lang.RT_IntCast_J__I_NoInit(6), nil); _ = ___6; _ = ___7; _ = ___8; _ = ___9; if jrt.J2g_Truth(k__5) { var root_2607 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_2608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2607, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2609 lang.IFn; if linked_2608 == nil { ifn_2609 = lang.IFn_Cast(root_2607) } else { ifn_2609 = nil }; var arg_2610 any = t.F_b__1050000300; var arg_2611 any = lang.Tuple_Create_O_O__IPersistentVector(k__5, lang.Tuple_Create_O_O__IPersistentVector(st__4, msg__10)); if linked_2608 == nil { ifn_2609.Invoke_O_O__O(arg_2610, arg_2611) } else { linked_2608.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2607, arg_2610, arg_2611) }; i__1050000299__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000299__1); continue L1 } else { i__1050000299__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000299__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_repr_go_parse_helper_header_A_New() *A_arbace_repr_go_parse_helper_header_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_helper_header_A{}; t.Ctor(); return t }
//line :524:1
func (t *A_arbace_repr_go_parse_helper_header_A) Ctor() {}
//line :524:1
func (t *A_arbace_repr_go_parse_helper_header_A) Invoke_O_O__O(self, path__0 any) any { var s__2 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_15.GetRawRoot__O()).Invoke_O__O(path__0); var i__3 int32 = jrt.NN(jrt.String_Cast(s__2)).IndexOf_String__I(Lit_126); var root_2684 any = A_arbace_repr_go_parse_A_const_305.GetRawRoot__O(); var linked_2685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2684, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2686 lang.IFn; if




	linked_2685 == nil { ifn_2686 = lang.IFn_Cast(root_2684) } else { ifn_2686 = nil }; var arg_2687 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_240.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_310, jrt.Boolean_FALSE.Ref()); if linked_2685 == nil { ifn_2686.Invoke_O__O(arg_2687) } else { linked_2685.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2684, arg_2687) }; var tmp1 any; tmp4 := /*line :524:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





		{ var root_2671 any = A_arbace_repr_go_parse_A_const_309.GetRawRoot__O(); var linked_2672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2671, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_2673 lang.IFn; if linked_2672 == nil { ifn_2673 = lang.IFn_Cast(root_2671) } else { ifn_2673 = nil }; var arg_2674 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_127); var tmp3 any; var root_2675 any = A_arbace_repr_go_parse_A_const_283.GetRawRoot__O(); var linked_2676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2675, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2677 lang.IFn; if linked_2676 == nil { ifn_2677 = lang.IFn_Cast(root_2675) } else { ifn_2677 = nil }; var arg_2678 any = s__2; var arg_2679 any = jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.String_Cast(s__2)).IndexOf_String__I(Lit_128)).Ref(); var arg_2680 any; if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__3)) { arg_2680 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(s__2)).Ref() } else { arg_2680 = jrt.Integer_ValueOf_I__Integer_NoInit(i__3).Ref() }; if linked_2676 == nil { tmp3 = ifn_2677.Invoke_O_O_O__O(arg_2678, arg_2679, arg_2680) } else { tmp3 = linked_2676.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_2675, arg_2678, arg_2679, arg_2680) }; arg_2674 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref(); if linked_2672 == nil { tmp1 = ifn_2673.Invoke_O__O(arg_2674) } else { tmp1 = linked_2672.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_2671, arg_2674) } }
//line :524:1
		return nil }(); var root_2681 any = A_arbace_repr_go_parse_A_const_304.GetRawRoot__O(); var linked_2682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2681, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2683 lang.IFn; if




	linked_2682 == nil { ifn_2683 = lang.IFn_Cast(root_2681) } else { ifn_2683 = nil }; if linked_2682 == nil { ifn_2683.Invoke__O() } else { linked_2682.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2681) }; if /*line :524:1*/ tmp4 != nil { panic(tmp4) }; return tmp1 }







func A_arbace_repr_go_parse_check_header_A_New() *A_arbace_repr_go_parse_check_header_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_header_A{}; t.Ctor(); return t }
//line :532:1
func (t *A_arbace_repr_go_parse_check_header_A) Ctor() {}
//line :532:1
func (t *A_arbace_repr_go_parse_check_header_A) Invoke_O_O_O__O(self, j__0, path__1 any) any { var base__3 any; var tmp1 any = A_arbace_repr_go_parse_A_const_78; var tmp2 any = A_arbace_repr_go_parse_A_const_78.Invoke_O__O(j__0); var tmp3 any = A_arbace_repr_go_parse_A_const_184; var tmp4 any = A_arbace_repr_go_parse_A_const_289; var tmp5 any; var root_2693 any = A_arbace_repr_go_parse_A_const_247.GetRawRoot__O(); var linked_2694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2693, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_2695 lang.IFn; if


	linked_2694 == nil { ifn_2695 = lang.IFn_Cast(root_2693) } else { ifn_2695 = nil }; var arg_2696 any = j__0; var arg_2697 any = A_arbace_repr_go_parse_A_const_320; if linked_2694 == nil { tmp5 = ifn_2695.Invoke_O_O__O(arg_2696, arg_2697) } else { tmp5 = linked_2694.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_2693, arg_2696, arg_2697) }; var tmp6 any = tmp5; var tmp7 any = A_arbace_repr_go_parse_A_const_189; var tmp8 any = /*line :532:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_parse_A_const_189.Invoke_O__O(j__0))).Ref(); var tmp9 any = A_arbace_repr_go_parse_A_const_291; var tmp10 any; var root_2698 any = A_arbace_repr_go_parse_A_const_292.GetRawRoot__O(); var linked_2699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2698, A_arbace_repr_go_parse_job_keys_A_fn_class); var ifn_2700 lang.IFn; if


	linked_2699 == nil { ifn_2700 = lang.IFn_Cast(root_2698) } else { ifn_2700 = nil }; var arg_2701 any = j__0; if linked_2699 == nil { tmp10 = ifn_2700.Invoke_O__O(arg_2701) } else { tmp10 = linked_2699.(*A_arbace_repr_go_parse_job_keys_A).Invoke_O_O__O(root_2698, arg_2701) }; base__3 = /*line :532:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, path__1, tmp4, tmp6, tmp7, tmp8, tmp9, tmp10)); var tmp11 any; tmp17 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




		if lang.Util_Identical_O_O__Z_NoInit(path__1, nil) {
			var root_2702 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_2703 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2702, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2704 lang.IFn; if linked_2703 == nil { ifn_2704 = lang.IFn_Cast(root_2702) } else { ifn_2704 = nil }; var arg_2705 any = base__3; var arg_2706 any = A_arbace_repr_go_parse_A_const_295; var arg_2707 any = jrt.Boolean_TRUE.Ref(); if linked_2703 == nil { tmp11 = ifn_2704.Invoke_O_O_O__O(arg_2705, arg_2706, arg_2707) } else { tmp11 = linked_2703.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2702, arg_2705, arg_2706, arg_2707) } } else {
//line :537:1
				var df__6 any; var root_2708 any = A_arbace_repr_go_parse_A_const_277.GetRawRoot__O(); var linked_2709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2708, A_arbace_repr_go_parse_diff_A_fn_class); var ifn_2710 lang.IFn

				if linked_2709 == nil { ifn_2710 = lang.IFn_Cast(root_2708) } else { ifn_2710 = nil }; var arg_2711 any; var root_2714 any = A_arbace_repr_go_parse_A_const_260.GetRawRoot__O(); var linked_2715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2714, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2716 lang.IFn; if linked_2715 == nil { ifn_2716 = lang.IFn_Cast(root_2714) } else { ifn_2716 = nil }; var arg_2717 any; var root_2719 any = A_arbace_repr_go_parse_A_const_321.GetRawRoot__O(); var linked_2720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2719, A_arbace_repr_go_parse_helper_header_A_fn_class); var ifn_2721 lang.IFn; if linked_2720 == nil { ifn_2721 = lang.IFn_Cast(root_2719) } else { ifn_2721 = nil }; var arg_2722 any = path__1; if linked_2720 == nil { arg_2717 = ifn_2721.Invoke_O__O(arg_2722) } else { arg_2717 = linked_2720.(*A_arbace_repr_go_parse_helper_header_A).Invoke_O_O__O(root_2719, arg_2722) }; var arg_2718 any = A_arbace_repr_go_parse_A_const_261.GetRawRoot__O(); if linked_2715 == nil { arg_2711 = ifn_2716.Invoke_O_O__O(arg_2717, arg_2718) } else { arg_2711 = linked_2715.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2714, arg_2717, arg_2718) }; var arg_2712 any; var root_2723 any = A_arbace_repr_go_parse_A_const_260.GetRawRoot__O(); var linked_2724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2723, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_2725 lang.IFn; if linked_2724 == nil { ifn_2725 = lang.IFn_Cast(root_2723) } else { ifn_2725 = nil }; var arg_2726 any = A_arbace_repr_go_parse_A_const_253.Invoke_O__O(j__0); var arg_2727 any = A_arbace_repr_go_parse_A_const_261.GetRawRoot__O(); if linked_2724 == nil { arg_2712 = ifn_2725.Invoke_O_O__O(arg_2726, arg_2727) } else { arg_2712 = linked_2724.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_2723, arg_2726, arg_2727) }; var arg_2713 any = lang.PersistentVector_EMPTY.Ref(); if linked_2709 == nil { df__6 = ifn_2710.Invoke_O_O_O__O(arg_2711, arg_2712, arg_2713) } else { df__6 = linked_2709.(*A_arbace_repr_go_parse_diff_A).Invoke_O_O_O_O__O(root_2708, arg_2711, arg_2712, arg_2713) }
//line :537:1
				var G__1050000315__7_ any; var root_2728 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_2729 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2728, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2730 lang.IFn


				if linked_2729 == nil { ifn_2730 = lang.IFn_Cast(root_2728) } else { ifn_2730 = nil }; var arg_2731 any = base__3; var arg_2732 any = A_arbace_repr_go_parse_A_const_66; var arg_2733 any = A_arbace_repr_go_parse_A_const_151; if linked_2729 == nil { G__1050000315__7_ = ifn_2730.Invoke_O_O_O__O(arg_2731, arg_2732, arg_2733) } else { G__1050000315__7_ = linked_2729.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2728, arg_2731, arg_2732, arg_2733) }; if jrt.J2g_Truth(df__6) {
					var root_2734 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_2735 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2734, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2736 lang.IFn; if linked_2735 == nil { ifn_2736 = lang.IFn_Cast(root_2734) } else { ifn_2736 = nil }; var arg_2737 any = G__1050000315__7_; var arg_2738 any = A_arbace_repr_go_parse_A_const_300; var arg_2739 any; var tmp12 any; var root_2740 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_2741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2740, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2742 lang.IFn; if linked_2741 == nil { ifn_2742 = lang.IFn_Cast(root_2740) } else { ifn_2742 = nil }; var arg_2743 any = df__6; if linked_2741 == nil { tmp12 = ifn_2742.Invoke_O__O(arg_2743) } else { tmp12 = linked_2741.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2740, arg_2743) }; var tmp13 any = tmp12; var tmp14 any; var root_2744 any = A_arbace_repr_go_parse_A_const_302.GetRawRoot__O(); var linked_2745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2744, A_arbace_repr_go_parse_short_str_A_fn_class); var ifn_2746 lang.IFn; if linked_2745 == nil { ifn_2746 = lang.IFn_Cast(root_2744) } else { ifn_2746 = nil }; var arg_2747 any; var root_2748 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_2749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2748, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2750 lang.IFn; if linked_2749 == nil { ifn_2750 = lang.IFn_Cast(root_2748) } else { ifn_2750 = nil }; var arg_2751 any = df__6; if linked_2749 == nil { arg_2747 = ifn_2750.Invoke_O__O(arg_2751) } else { arg_2747 = linked_2749.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2748, arg_2751) }; if linked_2745 == nil { tmp14 = ifn_2746.Invoke_O__O(arg_2747) } else { tmp14 = linked_2745.(*A_arbace_repr_go_parse_short_str_A).Invoke_O_O__O(root_2744, arg_2747) }; var tmp15 any = tmp14; var tmp16 any; var root_2752 any = A_arbace_repr_go_parse_A_const_302.GetRawRoot__O(); var linked_2753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2752, A_arbace_repr_go_parse_short_str_A_fn_class); var ifn_2754 lang.IFn; if linked_2753 == nil { ifn_2754 = lang.IFn_Cast(root_2752) } else { ifn_2754 = nil }; var arg_2755 any = lang.RT_Nth_O_I__O_NoInit(df__6, lang.RT_IntCast_J__I_NoInit(2)); if linked_2753 == nil { tmp16 = ifn_2754.Invoke_O__O(arg_2755) } else { tmp16 = linked_2753.(*A_arbace_repr_go_parse_short_str_A).Invoke_O_O__O(root_2752, arg_2755) }; arg_2739 = lang.Tuple_Create_O_O_O_O__IPersistentVector(nil, tmp13, tmp15, tmp16); if linked_2735 == nil { tmp11 = ifn_2736.Invoke_O_O_O__O(arg_2737, arg_2738, arg_2739) } else { tmp11 = linked_2735.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2734, arg_2737, arg_2738, arg_2739) } } else {
//line :540:1
						tmp11 = G__1050000315__7_ } }
//line :532:1
		return nil }(); if tmp17 != nil { if true { var e__6 jrt.Throwable_I = tmp17; var root_2756 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_2757 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2756, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2758 lang.IFn










			if linked_2757 == nil { ifn_2758 = lang.IFn_Cast(root_2756) } else { ifn_2758 = nil }; var arg_2759 any = base__3; var arg_2760 any = A_arbace_repr_go_parse_A_const_293; var arg_2761 any; var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_96, nil); var tmp19 any; var root_2762 any = A_arbace_repr_go_parse_A_const_273.GetRawRoot__O(); var linked_2763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2762, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_2764 lang.IFn; if linked_2763 == nil { ifn_2764 = lang.IFn_Cast(root_2762) } else { ifn_2764 = nil }; var arg_2765 any = e__6; if linked_2763 == nil { tmp19 = ifn_2764.Invoke_O__O(arg_2765) } else { tmp19 = linked_2763.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_2762, arg_2765) }; arg_2761 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.Class_Cast(tmp19)).GetName__String().Ref(), nil, e__6.GetMessage__String().Ref())).Ref(); if linked_2757 == nil { tmp11 = ifn_2758.Invoke_O_O_O__O(arg_2759, arg_2760, arg_2761) } else { tmp11 = linked_2757.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2756, arg_2759, arg_2760, arg_2761) } } }; return tmp11 }

func A_arbace_repr_go_parse_check_corpus_A_New() *A_arbace_repr_go_parse_check_corpus_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_A{}; t.Ctor(); return t }
//line :545:1
func (t *A_arbace_repr_go_parse_check_corpus_A) Ctor() {}
//line :545:1
func (t *A_arbace_repr_go_parse_check_corpus_A) Invoke_O_O_O_O_O_O_O__O(self, goroot_forms__0, spec__1, pool__2, out__3, known__4, headers__5 any) any { var t0__7 int64 = jrt.System_NanoTime__J(); var nm__8 any = A_arbace_repr_go_parse_A_const_73.Invoke_O__O(spec__1); var dumps__9 any; var root_2766 any = A_arbace_repr_go_parse_A_const_42.GetRawRoot__O(); var linked_2767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2766, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2768 lang.IFn; if





	linked_2767 == nil { ifn_2768 = lang.IFn_Cast(root_2766) } else { ifn_2768 = nil }; var arg_2769 any = A_arbace_repr_go_parse_A_const_322.Invoke_O__O(spec__1); var arg_2770 any = A_arbace_repr_go_parse_A_const_323; var arg_2771 any = Lit_11; if linked_2767 == nil { dumps__9 = ifn_2768.Invoke_O_O_O__O(arg_2769, arg_2770, arg_2771) } else { dumps__9 = linked_2767.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2766, arg_2769, arg_2770, arg_2771) }; var vec__1050000325__10 any; var root_2772 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_324.GetRawRoot__O(); var linked_2773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2772, A_arbace_repr_go_parse_spec_jobs_A_fn_class); var ifn_2774 lang.IFn; if






	linked_2773 == nil { ifn_2774 = lang.IFn_Cast(root_2772) } else { ifn_2774 = nil }; var arg_2775 any = spec__1; if linked_2773 == nil { vec__1050000325__10 = ifn_2774.Invoke_O__O(arg_2775) } else { vec__1050000325__10 = linked_2773.(*A_arbace_repr_go_parse_spec_jobs_A).Invoke_O_O__O(root_2772, arg_2775) }; var js__11 any = /*line :545:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1050000325__10, lang.RT_IntCast_J__I_NoInit(0), nil); var results__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000325__10, lang.RT_IntCast_J__I_NoInit(1), nil); var load_ms__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000325__10, lang.RT_IntCast_J__I_NoInit(2), nil); var helper__14 any; var root_2776 any = A_arbace_repr_go_parse_A_const_236.GetRawRoot__O(); var linked_2777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2776, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_2778 lang.IFn; if







	linked_2777 == nil { ifn_2778 = lang.IFn_Cast(root_2776) } else { ifn_2778 = nil }; var arg_2779 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_2780 any; var iter__1927001039__auto____14 any; var tmp1 any = A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_A_New_O(dumps__9); var tmp2 *jrt.Class; var fncls__2861 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_A_fn_class; if fncls__2861 == nil { var fncls__2861d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_A_fn_class = fncls__2861d; tmp2 = fncls__2861d } else { tmp2 = fncls__2861 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____14); var tmp4 any; var root_2862 any = A_arbace_repr_go_parse_A_const_326.GetRawRoot__O(); var linked_2863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2862, aot_arbace_repr_go_read.A_arbace_repr_go_read_dump_files_A_fn_class); var ifn_2864 lang.IFn; if linked_2863 == nil { ifn_2864 = lang.IFn_Cast(root_2862) } else { ifn_2864 = nil }; var arg_2865 any = lang.Tuple_Create_O__IPersistentVector(dumps__9); if linked_2863 == nil { tmp4 = ifn_2864.Invoke_O__O(arg_2865) } else { tmp4 = linked_2863.(*aot_arbace_repr_go_read.A_arbace_repr_go_read_dump_files_A).Invoke_O_O__O(root_2862, arg_2865) }; arg_2780 = tmp3.Invoke_O__O(tmp4); if linked_2777 == nil { helper__14 = ifn_2778.Invoke_O_O__O(arg_2779, arg_2780) } else { helper__14 = linked_2777.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_2776, arg_2779, arg_2780) }; var hres__15 any; var root_2866 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_327.GetRawRoot__O(); var linked_2867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2866, A_arbace_repr_go_parse_helper_results_A_fn_class); var ifn_2868 lang.IFn; if









	linked_2867 == nil { ifn_2868 = lang.IFn_Cast(root_2866) } else { ifn_2868 = nil }; var arg_2869 any = A_arbace_repr_go_parse_A_const_328.Invoke_O__O(spec__1); if linked_2867 == nil { hres__15 = ifn_2868.Invoke_O__O(arg_2869) } else { hres__15 = linked_2867.(*A_arbace_repr_go_parse_helper_results_A).Invoke_O_O__O(root_2866, arg_2869) }; var jkeys__16 any; var root_2870 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_36.GetRawRoot__O(); var linked_2871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2870, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2872 lang.IFn; if










	linked_2871 == nil { ifn_2872 = lang.IFn_Cast(root_2870) } else { ifn_2872 = nil }; var arg_2873 any; var root_2874 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_2875 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2874, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2876 lang.IFn; if linked_2875 == nil { ifn_2876 = lang.IFn_Cast(root_2874) } else { ifn_2876 = nil }; var arg_2877 any = A_arbace_repr_go_parse_A_const_78; var arg_2878 any = js__11; if linked_2875 == nil { arg_2873 = ifn_2876.Invoke_O_O__O(arg_2877, arg_2878) } else { arg_2873 = linked_2875.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2874, arg_2877, arg_2878) }; if linked_2871 == nil { jkeys__16 = ifn_2872.Invoke_O__O(arg_2873) } else { jkeys__16 = linked_2871.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2870, arg_2873) }; var futs__17 any; var root_2879 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_234.GetRawRoot__O(); var linked_2880 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2879, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2881 lang.IFn; if











	linked_2880 == nil { ifn_2881 = lang.IFn_Cast(root_2879) } else { ifn_2881 = nil }; var arg_2882 any; var tmp5 any = A_arbace_repr_go_parse_check_corpus_fn__1050000338_A_New_O_O_O_O_O_O(headers__5, helper__14, out__3, nm__8, pool__2, goroot_forms__0); var tmp6 *jrt.Class; var fncls__2904 *jrt.Class = A_arbace_repr_go_parse_check_corpus_fn__1050000338_A_fn_class; if fncls__2904 == nil { var fncls__2904d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_repr_go_parse_check_corpus_fn__1050000338_A_fn_class = fncls__2904d; tmp6 = fncls__2904d } else { tmp6 = fncls__2904 }; arg_2882 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_2883 any = js__11; if linked_2880 == nil { futs__17 = ifn_2881.Invoke_O_O__O(arg_2882, arg_2883) } else { futs__17 = linked_2880.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2879, arg_2882, arg_2883) }; var rs__18 any; var root_2905 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_234.GetRawRoot__O(); var linked_2906 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2905, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2907 lang.IFn; if


















	linked_2906 == nil { ifn_2907 = lang.IFn_Cast(root_2905) } else { ifn_2907 = nil }; var arg_2908 any; var tmp7 any = A_arbace_repr_go_parse_check_corpus_fn__1050000344_A_New(); var tmp8 *jrt.Class; var fncls__2910 *jrt.Class = A_arbace_repr_go_parse_check_corpus_fn__1050000344_A_fn_class; if fncls__2910 == nil { var fncls__2910d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_repr_go_parse_check_corpus_fn__1050000344_A_fn_class = fncls__2910d; tmp8 = fncls__2910d } else { tmp8 = fncls__2910 }; arg_2908 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_2909 any = futs__17; if linked_2906 == nil { rs__18 = ifn_2907.Invoke_O_O__O(arg_2908, arg_2909) } else { rs__18 = linked_2906.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2905, arg_2908, arg_2909) }; var missing__19 any; var root_2911 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_2912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2911, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2913 lang.IFn; if



















	linked_2912 == nil { ifn_2913 = lang.IFn_Cast(root_2911) } else { ifn_2913 = nil }; var arg_2914 any; var iter__1927001039__auto____19 any; var tmp9 any = A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_A_New_O_O(results__12, jkeys__16); var tmp10 *jrt.Class; var fncls__2997 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_A_fn_class; if fncls__2997 == nil { var fncls__2997d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_A_fn_class = fncls__2997d; tmp10 = fncls__2997d } else { tmp10 = fncls__2997 }; iter__1927001039__auto____19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp11 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____19); var tmp12 any; var root_2998 any = A_arbace_repr_go_parse_A_const_334.GetRawRoot__O(); var linked_2999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2998, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_3000 lang.IFn; if linked_2999 == nil { ifn_3000 = lang.IFn_Cast(root_2998) } else { ifn_3000 = nil }; var arg_3001 any = helper__14; if linked_2999 == nil { tmp12 = ifn_3000.Invoke_O__O(arg_3001) } else { tmp12 = linked_2999.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_2998, arg_3001) }; arg_2914 = tmp11.Invoke_O__O(tmp12); if linked_2912 == nil { missing__19 = ifn_2913.Invoke_O__O(arg_2914) } else { missing__19 = linked_2912.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2911, arg_2914) }; var extra__20 any; var root_3002 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_3003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3002, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3004 lang.IFn; if























	linked_3003 == nil { ifn_3004 = lang.IFn_Cast(root_3002) } else { ifn_3004 = nil }; var arg_3005 any = A_arbace_repr_go_parse_A_const_295; var arg_3006 any = rs__18; if linked_3003 == nil { extra__20 = ifn_3004.Invoke_O_O__O(arg_3005, arg_3006) } else { extra__20 = linked_3003.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3002, arg_3005, arg_3006) }; var helper_failed_QMARK___21 any; var tmp13 any = /*line :545:1*/A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_A_New_O_O(hres__15, js__11); var tmp14 *jrt.Class; var fncls__3017 *jrt.Class = A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_A_fn_class; if
























	fncls__3017 == nil { var fncls__3017d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_A_fn_class = fncls__3017d; tmp14 = fncls__3017d } else { tmp14 = fncls__3017 }; helper_failed_QMARK___21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var known_QMARK___22 any; var tmp15 any = /*line :545:1*/A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_A_New_O(known__4); var tmp16 *jrt.Class; var fncls__3039 *jrt.Class = A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_A_fn_class; if

























	fncls__3039 == nil { var fncls__3039d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_A_fn_class = fncls__3039d; tmp16 = fncls__3039d } else { tmp16 = fncls__3039 }; known_QMARK___22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var fails__23 any; var root_3040 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_3041 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3040, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3042 lang.IFn; if


























	linked_3041 == nil { ifn_3042 = lang.IFn_Cast(root_3040) } else { ifn_3042 = nil }; var arg_3043 any = A_arbace_repr_go_parse_A_const_293; var arg_3044 any = rs__18; if linked_3041 == nil { fails__23 = ifn_3042.Invoke_O_O__O(arg_3043, arg_3044) } else { fails__23 = linked_3041.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3040, arg_3043, arg_3044) }; var differ__24 any; var root_3045 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_3046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3045, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3047 lang.IFn; if



























	linked_3046 == nil { ifn_3047 = lang.IFn_Cast(root_3045) } else { ifn_3047 = nil }; var arg_3048 any = A_arbace_repr_go_parse_A_const_300; var arg_3049 any = rs__18; if linked_3046 == nil { differ__24 = ifn_3047.Invoke_O_O__O(arg_3048, arg_3049) } else { differ__24 = linked_3046.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3045, arg_3048, arg_3049) }; var bad_extra__25 any; var root_3050 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_20.GetRawRoot__O(); var linked_3051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3050, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3052 lang.IFn; if




























	linked_3051 == nil { ifn_3052 = lang.IFn_Cast(root_3050) } else { ifn_3052 = nil }; var arg_3053 any = helper_failed_QMARK___21; var arg_3054 any = extra__20; if linked_3051 == nil { bad_extra__25 = ifn_3052.Invoke_O_O__O(arg_3053, arg_3054) } else { bad_extra__25 = linked_3051.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3050, arg_3053, arg_3054) }; var unknown__26 any; var root_3055 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_20.GetRawRoot__O(); var linked_3056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3055, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3057 lang.IFn; if





























	linked_3056 == nil { ifn_3057 = lang.IFn_Cast(root_3055) } else { ifn_3057 = nil }; var arg_3058 any = known_QMARK___22; var arg_3059 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_35.GetRawRoot__O()).Invoke_O_O_O_O__O(fails__23, differ__24, missing__19, bad_extra__25); if linked_3056 == nil { unknown__26 = ifn_3057.Invoke_O_O__O(arg_3058, arg_3059) } else { unknown__26 = linked_3056.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3055, arg_3058, arg_3059) }; var ok__27 any; var root_3067 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_3068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3067, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3069 lang.IFn; if






























	linked_3068 == nil { ifn_3069 = lang.IFn_Cast(root_3067) } else { ifn_3069 = nil }; var arg_3070 any; var tmp17 any = A_arbace_repr_go_parse_check_corpus_fn__1050000374_A_New(); var tmp18 *jrt.Class; var fncls__3076 *jrt.Class = A_arbace_repr_go_parse_check_corpus_fn__1050000374_A_fn_class; if fncls__3076 == nil { var fncls__3076d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_repr_go_parse_check_corpus_fn__1050000374_A_fn_class = fncls__3076d; tmp18 = fncls__3076d } else { tmp18 = fncls__3076 }; arg_3070 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_3071 any = rs__18; if linked_3068 == nil { ok__27 = ifn_3069.Invoke_O_O__O(arg_3070, arg_3071) } else { ok__27 = linked_3068.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3067, arg_3070, arg_3071) }; var sum__28 any; var tmp19 any = /*line :545:1*/A_arbace_repr_go_parse_check_corpus_sum__1050000376_A_New_O(ok__27); var tmp20 *jrt.Class; var fncls__3093 *jrt.Class = A_arbace_repr_go_parse_check_corpus_sum__1050000376_A_fn_class; if































	fncls__3093 == nil { var fncls__3093d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_repr_go_parse_check_corpus_sum__1050000376_A_fn_class = fncls__3093d; tmp20 = fncls__3093d } else { tmp20 = fncls__3093 }; sum__28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); var seq_1050000380__29 any; var root_3389 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3389, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3391 lang.IFn; if
































	linked_3390 == nil { ifn_3391 = lang.IFn_Cast(root_3389) } else { ifn_3391 = nil }; var arg_3392 any = fails__23; if linked_3390 == nil { seq_1050000380__29 = ifn_3391.Invoke_O__O(arg_3392) } else { seq_1050000380__29 = linked_3390.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3389, arg_3392) }; var chunk_1050000381__30 any; var count_1050000382__31 int64 = 0; var i_1050000383__32 int64 = 0; L1:
//line :545:1
	for {
































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1050000383__32, count_1050000382__31) { var r__33 any = lang.Indexed_Cast(chunk_1050000381__30).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1050000383__32)); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp22 *jrt.String; if jrt.J2g_Truth(lang.IFn_Cast(known_QMARK___22).Invoke_O__O(r__33)) { tmp22 = Lit_52 } else { tmp22 = Lit_53 }; tmp21.Invoke_O_O_O_O__O(tmp22.Ref(), nm__8, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__33), A_arbace_repr_go_parse_A_const_293.Invoke_O__O(r__33)); seq_1050000380__29, chunk_1050000381__30, count_1050000382__31, i_1050000383__32 = seq_1050000380__29, chunk_1050000381__30, count_1050000382__31, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1050000383__32); continue L1 } else { var temp__1927000414__auto____33 any; var root_3393 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3393, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3395 lang.IFn; if linked_3394 == nil { ifn_3395 = lang.IFn_Cast(root_3393) } else { ifn_3395 = nil }; var arg_3396 any = seq_1050000380__29; if linked_3394 == nil { temp__1927000414__auto____33 = ifn_3395.Invoke_O__O(arg_3396) } else { temp__1927000414__auto____33 = linked_3394.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3393, arg_3396) }; if jrt.J2g_Truth(temp__1927000414__auto____33) { var seq_1050000380__34 any = temp__1927000414__auto____33; var tmp23 any; var root_3397 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_3398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3397, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3399 lang.IFn; if linked_3398 == nil { ifn_3399 = lang.IFn_Cast(root_3397) } else { ifn_3399 = nil }; var arg_3400 any = seq_1050000380__34; if linked_3398 == nil { tmp23 = ifn_3399.Invoke_O__O(arg_3400) } else { tmp23 = linked_3398.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3397, arg_3400) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____35 any; var root_3401 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_3402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3401, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3403 lang.IFn; if linked_3402 == nil { ifn_3403 = lang.IFn_Cast(root_3401) } else { ifn_3403 = nil }; var arg_3404 any = seq_1050000380__34; if linked_3402 == nil { c__1927000678__auto____35 = ifn_3403.Invoke_O__O(arg_3404) } else { c__1927000678__auto____35 = linked_3402.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3401, arg_3404) }; var tmp24 any; var root_3548 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_3549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3548, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3550 lang.IFn; if linked_3549 == nil { ifn_3550 = lang.IFn_Cast(root_3548) } else { ifn_3550 = nil }; var arg_3551 any = seq_1050000380__34; if linked_3549 == nil { tmp24 = ifn_3550.Invoke_O__O(arg_3551) } else { tmp24 = linked_3549.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3548, arg_3551) }; seq_1050000380__29, chunk_1050000381__30, count_1050000382__31, i_1050000383__32 = tmp24, c__1927000678__auto____35, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____35))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var r__35 any; var root_3405 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3405, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3407 lang.IFn; if linked_3406 == nil { ifn_3407 = lang.IFn_Cast(root_3405) } else { ifn_3407 = nil }; var arg_3408 any = seq_1050000380__34; if linked_3406 == nil { r__35 = ifn_3407.Invoke_O__O(arg_3408) } else { r__35 = linked_3406.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3405, arg_3408) }; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp26 *jrt.String; if jrt.J2g_Truth(lang.IFn_Cast(known_QMARK___22).Invoke_O__O(r__35)) { tmp26 = Lit_52 } else { tmp26 = Lit_53 }; tmp25.Invoke_O_O_O_O__O(tmp26.Ref(), nm__8, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__35), A_arbace_repr_go_parse_A_const_293.Invoke_O__O(r__35)); var tmp27 any; var root_3559 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_3560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3559, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3561 lang.IFn; if linked_3560 == nil { ifn_3561 = lang.IFn_Cast(root_3559) } else { ifn_3561 = nil }; var arg_3562 any = seq_1050000380__34; if linked_3560 == nil { tmp27 = ifn_3561.Invoke_O__O(arg_3562) } else { tmp27 = linked_3560.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3559, arg_3562) }; seq_1050000380__29, chunk_1050000381__30, count_1050000382__31, i_1050000383__32 = tmp27, nil, 0, 0; continue L1 } } }
//line :545:1
		break L1 }; var seq_1050000384__29 any; var root_3409 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3409, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3411 lang.IFn; if

































	linked_3410 == nil { ifn_3411 = lang.IFn_Cast(root_3409) } else { ifn_3411 = nil }; var arg_3412 any = differ__24; if linked_3410 == nil { seq_1050000384__29 = ifn_3411.Invoke_O__O(arg_3412) } else { seq_1050000384__29 = linked_3410.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3409, arg_3412) }; var chunk_1050000385__30 any; var count_1050000386__31 int64 = 0; var i_1050000387__32 int64 = 0; L2:
//line :545:1
	for {

































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1050000387__32, count_1050000386__31) { var r__33_2 any = lang.Indexed_Cast(chunk_1050000385__30).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1050000387__32)); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp29 *jrt.String; if jrt.J2g_Truth(lang.IFn_Cast(known_QMARK___22).Invoke_O__O(r__33_2)) { tmp29 = Lit_54 } else { tmp29 = Lit_55 }; tmp28.Invoke_O_O_O_O__O(tmp29.Ref(), nm__8, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__33_2), lang.IFn_Cast(A_arbace_repr_go_parse_A_const_70.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_parse_A_const_300.Invoke_O__O(r__33_2))); seq_1050000384__29, chunk_1050000385__30, count_1050000386__31, i_1050000387__32 = seq_1050000384__29, chunk_1050000385__30, count_1050000386__31, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1050000387__32); continue L2 } else { var temp__1927000414__auto____33_2 any; var root_3413 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3413, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3415 lang.IFn; if linked_3414 == nil { ifn_3415 = lang.IFn_Cast(root_3413) } else { ifn_3415 = nil }; var arg_3416 any = seq_1050000384__29; if linked_3414 == nil { temp__1927000414__auto____33_2 = ifn_3415.Invoke_O__O(arg_3416) } else { temp__1927000414__auto____33_2 = linked_3414.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3413, arg_3416) }; if jrt.J2g_Truth(temp__1927000414__auto____33_2) { var seq_1050000384__34 any = temp__1927000414__auto____33_2; var tmp30 any; var root_3417 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_3418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3417, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3419 lang.IFn; if linked_3418 == nil { ifn_3419 = lang.IFn_Cast(root_3417) } else { ifn_3419 = nil }; var arg_3420 any = seq_1050000384__34; if linked_3418 == nil { tmp30 = ifn_3419.Invoke_O__O(arg_3420) } else { tmp30 = linked_3418.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3417, arg_3420) }; if jrt.J2g_Truth(tmp30) { var c__1927000678__auto____35_2 any; var root_3421 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_3422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3421, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3423 lang.IFn; if linked_3422 == nil { ifn_3423 = lang.IFn_Cast(root_3421) } else { ifn_3423 = nil }; var arg_3424 any = seq_1050000384__34; if linked_3422 == nil { c__1927000678__auto____35_2 = ifn_3423.Invoke_O__O(arg_3424) } else { c__1927000678__auto____35_2 = linked_3422.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3421, arg_3424) }; var tmp31 any; var root_3574 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_3575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3574, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3576 lang.IFn; if linked_3575 == nil { ifn_3576 = lang.IFn_Cast(root_3574) } else { ifn_3576 = nil }; var arg_3577 any = seq_1050000384__34; if linked_3575 == nil { tmp31 = ifn_3576.Invoke_O__O(arg_3577) } else { tmp31 = linked_3575.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3574, arg_3577) }; seq_1050000384__29, chunk_1050000385__30, count_1050000386__31, i_1050000387__32 = tmp31, c__1927000678__auto____35_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____35_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var r__35_2 any; var root_3425 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3425, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3427 lang.IFn; if linked_3426 == nil { ifn_3427 = lang.IFn_Cast(root_3425) } else { ifn_3427 = nil }; var arg_3428 any = seq_1050000384__34; if linked_3426 == nil { r__35_2 = ifn_3427.Invoke_O__O(arg_3428) } else { r__35_2 = linked_3426.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3425, arg_3428) }; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp33 *jrt.String; if jrt.J2g_Truth(lang.IFn_Cast(known_QMARK___22).Invoke_O__O(r__35_2)) { tmp33 = Lit_54 } else { tmp33 = Lit_55 }; tmp32.Invoke_O_O_O_O__O(tmp33.Ref(), nm__8, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__35_2), lang.IFn_Cast(A_arbace_repr_go_parse_A_const_70.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_parse_A_const_300.Invoke_O__O(r__35_2))); var tmp34 any; var root_3589 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_3590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3589, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3591 lang.IFn; if linked_3590 == nil { ifn_3591 = lang.IFn_Cast(root_3589) } else { ifn_3591 = nil }; var arg_3592 any = seq_1050000384__34; if linked_3590 == nil { tmp34 = ifn_3591.Invoke_O__O(arg_3592) } else { tmp34 = linked_3590.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3589, arg_3592) }; seq_1050000384__29, chunk_1050000385__30, count_1050000386__31, i_1050000387__32 = tmp34, nil, 0, 0; continue L2 } } }
//line :545:1
		break L2 }; var seq_1050000388__29 any; var root_3429 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3429, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3431 lang.IFn; if


































	linked_3430 == nil { ifn_3431 = lang.IFn_Cast(root_3429) } else { ifn_3431 = nil }; var arg_3432 any = missing__19; if linked_3430 == nil { seq_1050000388__29 = ifn_3431.Invoke_O__O(arg_3432) } else { seq_1050000388__29 = linked_3430.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3429, arg_3432) }; var chunk_1050000389__30 any; var count_1050000390__31 int64 = 0; var i_1050000391__32 int64 = 0; L3:
//line :545:1
	for {


































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1050000391__32, count_1050000390__31) { var r__33_3 any = lang.Indexed_Cast(chunk_1050000389__30).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1050000391__32)); var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp36 *jrt.String; if jrt.J2g_Truth(lang.IFn_Cast(known_QMARK___22).Invoke_O__O(r__33_3)) { tmp36 = Lit_56 } else { tmp36 = Lit_57 }; tmp35.Invoke_O_O_O_O__O(tmp36.Ref(), nm__8, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__33_3), A_arbace_repr_go_parse_A_const_333.Invoke_O__O(r__33_3)); seq_1050000388__29, chunk_1050000389__30, count_1050000390__31, i_1050000391__32 = seq_1050000388__29, chunk_1050000389__30, count_1050000390__31, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1050000391__32); continue L3 } else { var temp__1927000414__auto____33_3 any; var root_3433 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3433, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3435 lang.IFn; if linked_3434 == nil { ifn_3435 = lang.IFn_Cast(root_3433) } else { ifn_3435 = nil }; var arg_3436 any = seq_1050000388__29; if linked_3434 == nil { temp__1927000414__auto____33_3 = ifn_3435.Invoke_O__O(arg_3436) } else { temp__1927000414__auto____33_3 = linked_3434.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3433, arg_3436) }; if jrt.J2g_Truth(temp__1927000414__auto____33_3) { var seq_1050000388__34 any = temp__1927000414__auto____33_3; var tmp37 any; var root_3437 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_3438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3437, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3439 lang.IFn; if linked_3438 == nil { ifn_3439 = lang.IFn_Cast(root_3437) } else { ifn_3439 = nil }; var arg_3440 any = seq_1050000388__34; if linked_3438 == nil { tmp37 = ifn_3439.Invoke_O__O(arg_3440) } else { tmp37 = linked_3438.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3437, arg_3440) }; if jrt.J2g_Truth(tmp37) { var c__1927000678__auto____35_3 any; var root_3441 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_3442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3441, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3443 lang.IFn; if linked_3442 == nil { ifn_3443 = lang.IFn_Cast(root_3441) } else { ifn_3443 = nil }; var arg_3444 any = seq_1050000388__34; if linked_3442 == nil { c__1927000678__auto____35_3 = ifn_3443.Invoke_O__O(arg_3444) } else { c__1927000678__auto____35_3 = linked_3442.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3441, arg_3444) }; var tmp38 any; var root_3600 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_3601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3600, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3602 lang.IFn; if linked_3601 == nil { ifn_3602 = lang.IFn_Cast(root_3600) } else { ifn_3602 = nil }; var arg_3603 any = seq_1050000388__34; if linked_3601 == nil { tmp38 = ifn_3602.Invoke_O__O(arg_3603) } else { tmp38 = linked_3601.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3600, arg_3603) }; seq_1050000388__29, chunk_1050000389__30, count_1050000390__31, i_1050000391__32 = tmp38, c__1927000678__auto____35_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____35_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var r__35_3 any; var root_3445 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3445, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3447 lang.IFn; if linked_3446 == nil { ifn_3447 = lang.IFn_Cast(root_3445) } else { ifn_3447 = nil }; var arg_3448 any = seq_1050000388__34; if linked_3446 == nil { r__35_3 = ifn_3447.Invoke_O__O(arg_3448) } else { r__35_3 = linked_3446.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3445, arg_3448) }; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp40 *jrt.String; if jrt.J2g_Truth(lang.IFn_Cast(known_QMARK___22).Invoke_O__O(r__35_3)) { tmp40 = Lit_56 } else { tmp40 = Lit_57 }; tmp39.Invoke_O_O_O_O__O(tmp40.Ref(), nm__8, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__35_3), A_arbace_repr_go_parse_A_const_333.Invoke_O__O(r__35_3)); var tmp41 any; var root_3611 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_3612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3611, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3613 lang.IFn; if linked_3612 == nil { ifn_3613 = lang.IFn_Cast(root_3611) } else { ifn_3613 = nil }; var arg_3614 any = seq_1050000388__34; if linked_3612 == nil { tmp41 = ifn_3613.Invoke_O__O(arg_3614) } else { tmp41 = linked_3612.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3611, arg_3614) }; seq_1050000388__29, chunk_1050000389__30, count_1050000390__31, i_1050000391__32 = tmp41, nil, 0, 0; continue L3 } } }
//line :545:1
		break L3 }; var seq_1050000392__29 any; var root_3449 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3449, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3451 lang.IFn; if



































	linked_3450 == nil { ifn_3451 = lang.IFn_Cast(root_3449) } else { ifn_3451 = nil }; var arg_3452 any = bad_extra__25; if linked_3450 == nil { seq_1050000392__29 = ifn_3451.Invoke_O__O(arg_3452) } else { seq_1050000392__29 = linked_3450.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3449, arg_3452) }; var chunk_1050000393__30 any; var count_1050000394__31 int64 = 0; var i_1050000395__32 int64 = 0; L4:
//line :545:1
	for {



































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1050000395__32, count_1050000394__31) { var r__33_4 any = lang.Indexed_Cast(chunk_1050000393__30).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1050000395__32)); var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp43 *jrt.String; if jrt.J2g_Truth(lang.IFn_Cast(known_QMARK___22).Invoke_O__O(r__33_4)) { tmp43 = Lit_58 } else { tmp43 = Lit_59 }; tmp42.Invoke_O_O_O_O__O(tmp43.Ref(), nm__8, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__33_4), Lit_60); seq_1050000392__29, chunk_1050000393__30, count_1050000394__31, i_1050000395__32 = seq_1050000392__29, chunk_1050000393__30, count_1050000394__31, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1050000395__32); continue L4 } else { var temp__1927000414__auto____33_4 any; var root_3453 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3453, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3455 lang.IFn; if linked_3454 == nil { ifn_3455 = lang.IFn_Cast(root_3453) } else { ifn_3455 = nil }; var arg_3456 any = seq_1050000392__29; if linked_3454 == nil { temp__1927000414__auto____33_4 = ifn_3455.Invoke_O__O(arg_3456) } else { temp__1927000414__auto____33_4 = linked_3454.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3453, arg_3456) }; if jrt.J2g_Truth(temp__1927000414__auto____33_4) { var seq_1050000392__34 any = temp__1927000414__auto____33_4; var tmp44 any; var root_3457 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_3458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3457, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3459 lang.IFn; if linked_3458 == nil { ifn_3459 = lang.IFn_Cast(root_3457) } else { ifn_3459 = nil }; var arg_3460 any = seq_1050000392__34; if linked_3458 == nil { tmp44 = ifn_3459.Invoke_O__O(arg_3460) } else { tmp44 = linked_3458.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3457, arg_3460) }; if jrt.J2g_Truth(tmp44) { var c__1927000678__auto____35_4 any; var root_3461 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_3462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3461, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3463 lang.IFn; if linked_3462 == nil { ifn_3463 = lang.IFn_Cast(root_3461) } else { ifn_3463 = nil }; var arg_3464 any = seq_1050000392__34; if linked_3462 == nil { c__1927000678__auto____35_4 = ifn_3463.Invoke_O__O(arg_3464) } else { c__1927000678__auto____35_4 = linked_3462.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3461, arg_3464) }; var tmp45 any; var root_3622 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_3623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3622, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3624 lang.IFn; if linked_3623 == nil { ifn_3624 = lang.IFn_Cast(root_3622) } else { ifn_3624 = nil }; var arg_3625 any = seq_1050000392__34; if linked_3623 == nil { tmp45 = ifn_3624.Invoke_O__O(arg_3625) } else { tmp45 = linked_3623.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3622, arg_3625) }; seq_1050000392__29, chunk_1050000393__30, count_1050000394__31, i_1050000395__32 = tmp45, c__1927000678__auto____35_4, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____35_4))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var r__35_4 any; var root_3465 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3465, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3467 lang.IFn; if linked_3466 == nil { ifn_3467 = lang.IFn_Cast(root_3465) } else { ifn_3467 = nil }; var arg_3468 any = seq_1050000392__34; if linked_3466 == nil { r__35_4 = ifn_3467.Invoke_O__O(arg_3468) } else { r__35_4 = linked_3466.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3465, arg_3468) }; var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp47 *jrt.String; if jrt.J2g_Truth(lang.IFn_Cast(known_QMARK___22).Invoke_O__O(r__35_4)) { tmp47 = Lit_58 } else { tmp47 = Lit_59 }; tmp46.Invoke_O_O_O_O__O(tmp47.Ref(), nm__8, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__35_4), Lit_60); var tmp48 any; var root_3633 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_3634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3633, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3635 lang.IFn; if linked_3634 == nil { ifn_3635 = lang.IFn_Cast(root_3633) } else { ifn_3635 = nil }; var arg_3636 any = seq_1050000392__34; if linked_3634 == nil { tmp48 = ifn_3635.Invoke_O__O(arg_3636) } else { tmp48 = linked_3634.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3633, arg_3636) }; seq_1050000392__29, chunk_1050000393__30, count_1050000394__31, i_1050000395__32 = tmp48, nil, 0, 0; continue L4 } } }
//line :545:1
		break L4 }; var tmp49 lang.IFn =




































	lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_346.GetRawRoot__O()); var tmp51 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_61, nil, Lit_62); var tmp52 *jrt.String; if jrt.J2g_Truth(headers__5) { tmp52 = Lit_63 } else { tmp52 = Lit_64 }; var tmp53 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp51, jrt.RefArrayOf(jrt.Object_class, nil, tmp52.Ref(), nil)).Ref(); var tmp54 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(ok__27)), int64(lang.RT_Count_O__I_NoInit(differ__24)))).Ref(); var tmp55 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(helper__14)).Ref(); var tmp56 any; var root_3495 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_3496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3495, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3497 lang.IFn; if

	linked_3496 == nil { ifn_3497 = lang.IFn_Cast(root_3495) } else { ifn_3497 = nil }; var arg_3498 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_3499 any; var root_3500 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_3501 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3500, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3502 lang.IFn; if linked_3501 == nil { ifn_3502 = lang.IFn_Cast(root_3500) } else { ifn_3502 = nil }; var arg_3503 any = A_arbace_repr_go_parse_A_const_189; var arg_3504 any = ok__27; if linked_3501 == nil { arg_3499 = ifn_3502.Invoke_O_O__O(arg_3503, arg_3504) } else { arg_3499 = linked_3501.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3500, arg_3503, arg_3504) }; if linked_3496 == nil { tmp56 = ifn_3497.Invoke_O_O__O(arg_3498, arg_3499) } else { tmp56 = linked_3496.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3495, arg_3498, arg_3499) }; var tmp57 any = tmp56; var tmp58 any; var root_3505 any = /*line :582:1*/A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_3506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3505, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3507 lang.IFn; if

	linked_3506 == nil { ifn_3507 = lang.IFn_Cast(root_3505) } else { ifn_3507 = nil }; var arg_3508 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_3509 any; var root_3510 any = A_arbace_repr_go_parse_A_const_279.GetRawRoot__O(); var linked_3511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3510, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3512 lang.IFn; if linked_3511 == nil { ifn_3512 = lang.IFn_Cast(root_3510) } else { ifn_3512 = nil }; var arg_3513 any = A_arbace_repr_go_parse_A_const_66; var arg_3514 any = ok__27; if linked_3511 == nil { arg_3509 = ifn_3512.Invoke_O_O__O(arg_3513, arg_3514) } else { arg_3509 = linked_3511.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3510, arg_3513, arg_3514) }; if linked_3506 == nil { tmp58 = ifn_3507.Invoke_O_O__O(arg_3508, arg_3509) } else { tmp58 = linked_3506.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3505, arg_3508, arg_3509) }; var tmp59 any = tmp58; var tmp60 any = /*line :582:1*/jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(lang.IFn_Cast(sum__28).Invoke_O__O(A_arbace_repr_go_parse_A_const_259), 1000000.0)).Ref(); var tmp61 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(differ__24)).Ref(); var tmp62 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(fails__23)).Ref(); var tmp63 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(missing__19)).Ref(); var tmp64 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(extra__20)).Ref(); var tmp65 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(extra__20)), int64(lang.RT_Count_O__I_NoInit(bad_extra__25)))).Ref(); var tmp66 any; var root_3515 any = A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_3516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3515, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3517 lang.IFn; if



	linked_3516 == nil { ifn_3517 = lang.IFn_Cast(root_3515) } else { ifn_3517 = nil }; var arg_3518 any = A_arbace_repr_go_parse_A_const_294; var arg_3519 any = rs__18; if linked_3516 == nil { tmp66 = ifn_3517.Invoke_O_O__O(arg_3518, arg_3519) } else { tmp66 = linked_3516.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3515, arg_3518, arg_3519) }; var tmp67 any = /*line :582:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp66)).Ref(); var tmp68 any; var root_3520 any = A_arbace_repr_go_parse_A_const_20.GetRawRoot__O(); var linked_3521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3520, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3522 lang.IFn; if



	linked_3521 == nil { ifn_3522 = lang.IFn_Cast(root_3520) } else { ifn_3522 = nil }; var arg_3523 any; var tmp69 any = A_arbace_repr_go_parse_check_corpus_fn__1050000396_A_New_O(helper__14); var tmp70 *jrt.Class; var fncls__3530 *jrt.Class = A_arbace_repr_go_parse_check_corpus_fn__1050000396_A_fn_class; if fncls__3530 == nil { var fncls__3530d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_repr_go_parse_check_corpus_fn__1050000396_A_fn_class = fncls__3530d; tmp70 = fncls__3530d } else { tmp70 = fncls__3530 }; arg_3523 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp69, tmp70, nil); var arg_3524 any = results__12; if linked_3521 == nil { tmp68 = ifn_3522.Invoke_O_O__O(arg_3523, arg_3524) } else { tmp68 = linked_3521.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3520, arg_3523, arg_3524) }; var tmp71 any = /*line :582:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp68)).Ref(); var tmp72 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(unknown__26)).Ref(); var tmp73 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(load_ms__13, 1000.0)).Ref(); var tmp74 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(lang.IFn_Cast(sum__28).Invoke_O__O(A_arbace_repr_go_parse_A_const_231), 1000.0)).Ref(); var tmp75 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(lang.IFn_Cast(sum__28).Invoke_O__O(A_arbace_repr_go_parse_A_const_232), 1000.0)).Ref(); var tmp76 any; var root_3531 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_3532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3531, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3533 lang.IFn; if




	linked_3532 == nil { ifn_3533 = lang.IFn_Cast(root_3531) } else { ifn_3533 = nil }; var arg_3534 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_3535 any; var root_3536 any = A_arbace_repr_go_parse_A_const_279.GetRawRoot__O(); var linked_3537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3536, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3538 lang.IFn; if linked_3537 == nil { ifn_3538 = lang.IFn_Cast(root_3536) } else { ifn_3538 = nil }; var arg_3539 any = A_arbace_repr_go_parse_A_const_298; var arg_3540 any = ok__27; if linked_3537 == nil { arg_3535 = ifn_3538.Invoke_O_O__O(arg_3539, arg_3540) } else { arg_3535 = linked_3537.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3536, arg_3539, arg_3540) }; if linked_3532 == nil { tmp76 = ifn_3533.Invoke_O_O__O(arg_3534, arg_3535) } else { tmp76 = linked_3532.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3531, arg_3534, arg_3535) }; /*line :582:1*/tmp49.Invoke_O__O(tmp50.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(tmp53, nm__8, tmp54, tmp55, tmp57, tmp59, tmp60, tmp61, tmp62, tmp63, tmp64, tmp65, tmp67, tmp71, tmp72, tmp73, tmp74, tmp75, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(tmp76, 1000.0)).Ref())); var tmp77 any = A_arbace_repr_go_parse_A_const_335; var tmp78 any = A_arbace_repr_go_parse_A_const_322; var tmp79 any = /*line :545:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(helper__14)).Ref(); var tmp80 any = A_arbace_repr_go_parse_A_const_336; var tmp81 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(js__11)).Ref(); var tmp82 any = A_arbace_repr_go_parse_A_const_337; var tmp83 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(results__12)).Ref(); var tmp84 any = A_arbace_repr_go_parse_A_const_338; var tmp85 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(ok__27)), int64(lang.RT_Count_O__I_NoInit(differ__24)))).Ref(); var tmp86 any = A_arbace_repr_go_parse_A_const_189; var tmp87 any; var root_3094 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_3095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3094, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3096 lang.IFn; if











































	linked_3095 == nil { ifn_3096 = lang.IFn_Cast(root_3094) } else { ifn_3096 = nil }; var arg_3097 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_3098 any; var root_3099 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_3100 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3099, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3101 lang.IFn; if linked_3100 == nil { ifn_3101 = lang.IFn_Cast(root_3099) } else { ifn_3101 = nil }; var arg_3102 any = A_arbace_repr_go_parse_A_const_189; var arg_3103 any = ok__27; if linked_3100 == nil { arg_3098 = ifn_3101.Invoke_O_O__O(arg_3102, arg_3103) } else { arg_3098 = linked_3100.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3099, arg_3102, arg_3103) }; if linked_3095 == nil { tmp87 = ifn_3096.Invoke_O_O__O(arg_3097, arg_3098) } else { tmp87 = linked_3095.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3094, arg_3097, arg_3098) }; var tmp88 any = tmp87; var tmp89 any = A_arbace_repr_go_parse_A_const_66; var tmp90 any; var root_3104 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_3105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3104, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3106 lang.IFn; if












































	linked_3105 == nil { ifn_3106 = lang.IFn_Cast(root_3104) } else { ifn_3106 = nil }; var arg_3107 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_3108 any; var root_3109 any = A_arbace_repr_go_parse_A_const_279.GetRawRoot__O(); var linked_3110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3109, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3111 lang.IFn; if linked_3110 == nil { ifn_3111 = lang.IFn_Cast(root_3109) } else { ifn_3111 = nil }; var arg_3112 any = A_arbace_repr_go_parse_A_const_66; var arg_3113 any = ok__27; if linked_3110 == nil { arg_3108 = ifn_3111.Invoke_O_O__O(arg_3112, arg_3113) } else { arg_3108 = linked_3110.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3109, arg_3112, arg_3113) }; if linked_3105 == nil { tmp90 = ifn_3106.Invoke_O_O__O(arg_3107, arg_3108) } else { tmp90 = linked_3105.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3104, arg_3107, arg_3108) }; var tmp91 any = tmp90; var tmp92 any = A_arbace_repr_go_parse_A_const_259; var tmp93 any = /*line :545:1*/lang.IFn_Cast(sum__28).Invoke_O__O(A_arbace_repr_go_parse_A_const_259); var tmp94 any = A_arbace_repr_go_parse_A_const_339; var tmp95 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(load_ms__13, 1000.0)).Ref(); var tmp96 any = A_arbace_repr_go_parse_A_const_340; var tmp97 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(lang.IFn_Cast(sum__28).Invoke_O__O(A_arbace_repr_go_parse_A_const_231), 1000.0)).Ref(); var tmp98 any = A_arbace_repr_go_parse_A_const_341; var tmp99 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(lang.IFn_Cast(sum__28).Invoke_O__O(A_arbace_repr_go_parse_A_const_232), 1000.0)).Ref(); var tmp100 any = A_arbace_repr_go_parse_A_const_342; var tmp101 any; var root_3114 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_3115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3114, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3116 lang.IFn; if














































	linked_3115 == nil { ifn_3116 = lang.IFn_Cast(root_3114) } else { ifn_3116 = nil }; var arg_3117 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_3118 any; var root_3119 any = A_arbace_repr_go_parse_A_const_279.GetRawRoot__O(); var linked_3120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3119, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3121 lang.IFn; if linked_3120 == nil { ifn_3121 = lang.IFn_Cast(root_3119) } else { ifn_3121 = nil }; var arg_3122 any = A_arbace_repr_go_parse_A_const_298; var arg_3123 any = ok__27; if linked_3120 == nil { arg_3118 = ifn_3121.Invoke_O_O__O(arg_3122, arg_3123) } else { arg_3118 = linked_3120.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3119, arg_3122, arg_3123) }; if linked_3115 == nil { tmp101 = ifn_3116.Invoke_O_O__O(arg_3117, arg_3118) } else { tmp101 = linked_3115.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3114, arg_3117, arg_3118) }; var tmp102 any = /*line :545:1*/jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(tmp101, 1000.0)).Ref(); var tmp103 any = A_arbace_repr_go_parse_A_const_343; var tmp104 any; var root_3124 any = A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_3125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3124, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3126 lang.IFn; if















































	linked_3125 == nil { ifn_3126 = lang.IFn_Cast(root_3124) } else { ifn_3126 = nil }; var arg_3127 any; var iter__1927001039__auto____29 any; var tmp105 any = A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_A_New(); var tmp106 *jrt.Class; var fncls__3186 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_A_fn_class; if fncls__3186 == nil { var fncls__3186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_A_fn_class = fncls__3186d; tmp106 = fncls__3186d } else { tmp106 = fncls__3186 }; iter__1927001039__auto____29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp105, tmp106, nil); arg_3127 = lang.IFn_Cast(iter__1927001039__auto____29).Invoke_O__O(differ__24); if linked_3125 == nil { tmp104 = ifn_3126.Invoke_O__O(arg_3127) } else { tmp104 = linked_3125.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3124, arg_3127) }; var tmp107 any = tmp104; var tmp108 any = A_arbace_repr_go_parse_A_const_293; var tmp109 any; var root_3187 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_3188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3187, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3189 lang.IFn; if















































	linked_3188 == nil { ifn_3189 = lang.IFn_Cast(root_3187) } else { ifn_3189 = nil }; var arg_3190 any; var iter__1927001039__auto____29_2 any; var tmp110 any = A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_A_New(); var tmp111 *jrt.Class; var fncls__3249 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_A_fn_class; if fncls__3249 == nil { var fncls__3249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_A_fn_class = fncls__3249d; tmp111 = fncls__3249d } else { tmp111 = fncls__3249 }; iter__1927001039__auto____29_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp110, tmp111, nil); arg_3190 = lang.IFn_Cast(iter__1927001039__auto____29_2).Invoke_O__O(fails__23); if linked_3188 == nil { tmp109 = ifn_3189.Invoke_O__O(arg_3190) } else { tmp109 = linked_3188.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3187, arg_3190) }; var tmp112 any = tmp109; var tmp113 any = A_arbace_repr_go_parse_A_const_333; var tmp114 any; var root_3250 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_3251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3250, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3252 lang.IFn; if
















































	linked_3251 == nil { ifn_3252 = lang.IFn_Cast(root_3250) } else { ifn_3252 = nil }; var arg_3253 any; var iter__1927001039__auto____29_3 any; var tmp115 any = A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_A_New(); var tmp116 *jrt.Class; var fncls__3312 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_A_fn_class; if fncls__3312 == nil { var fncls__3312d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_A_fn_class = fncls__3312d; tmp116 = fncls__3312d } else { tmp116 = fncls__3312 }; iter__1927001039__auto____29_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp115, tmp116, nil); arg_3253 = lang.IFn_Cast(iter__1927001039__auto____29_3).Invoke_O__O(missing__19); if linked_3251 == nil { tmp114 = ifn_3252.Invoke_O__O(arg_3253) } else { tmp114 = linked_3251.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3250, arg_3253) }; var tmp117 any = tmp114; var tmp118 any = A_arbace_repr_go_parse_A_const_295; var tmp119 any; var root_3313 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_3314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3313, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_3315 lang.IFn; if

















































	linked_3314 == nil { ifn_3315 = lang.IFn_Cast(root_3313) } else { ifn_3315 = nil }; var arg_3316 any; var iter__1927001039__auto____29_4 any; var tmp120 any = A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_A_New_O_O(hres__15, helper_failed_QMARK___21); var tmp121 *jrt.Class; var fncls__3383 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_A_fn_class; if fncls__3383 == nil { var fncls__3383d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_A_fn_class = fncls__3383d; tmp121 = fncls__3383d } else { tmp121 = fncls__3383 }; iter__1927001039__auto____29_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp120, tmp121, nil); arg_3316 = lang.IFn_Cast(iter__1927001039__auto____29_4).Invoke_O__O(extra__20); if linked_3314 == nil { tmp119 = ifn_3315.Invoke_O__O(arg_3316) } else { tmp119 = linked_3314.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_3313, arg_3316) }; var tmp122 any = tmp119; var tmp123 any = A_arbace_repr_go_parse_A_const_294; var tmp124 any; var root_3384 any = /*line :545:1*/A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_3385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3384, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3386 lang.IFn; if


















































	linked_3385 == nil { ifn_3386 = lang.IFn_Cast(root_3384) } else { ifn_3386 = nil }; var arg_3387 any = A_arbace_repr_go_parse_A_const_294; var arg_3388 any = rs__18; if linked_3385 == nil { tmp124 = ifn_3386.Invoke_O_O__O(arg_3387, arg_3388) } else { tmp124 = linked_3385.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3384, arg_3387, arg_3388) }; var tmp125 any = /*line :545:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp124)).Ref(); var tmp126 any = A_arbace_repr_go_parse_A_const_69; var tmp127 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(unknown__26)).Ref(); var tmp128 any = A_arbace_repr_go_parse_A_const_344; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp77, nm__8, tmp78, tmp79, tmp80, tmp81, tmp82, tmp83, tmp84, tmp85, tmp86, tmp88, tmp89, tmp91, tmp92, tmp93, tmp94, tmp95, tmp96, tmp97, tmp98, tmp99, tmp100, tmp102, tmp103, tmp107, tmp108, tmp112, tmp113, tmp117, tmp118, tmp122, tmp123, tmp125, tmp126, tmp127, tmp128, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__7), 1.0e9)).Ref())) }







func A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_A_New_O(p0 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_A{}; t.Ctor_O(p0); return t }
//line :553:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_A) Ctor_O(c__dumps any) { t.F_dumps = c__dumps }
//line :553:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_A) Invoke_O_O__O(self, s__1050000329__1 any) any { var tmp1 any = A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_A_New_O_O_O(t.F_dumps, s__1050000329__1, self); var tmp2 *jrt.Class; var fncls__2860 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_A_fn_class; if fncls__2860 == nil { var fncls__2860d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_A_fn_class = fncls__2860d; tmp2 = fncls__2860d } else { tmp2 = fncls__2860 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :553:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :553:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_A) Ctor_O_O_O(c__dumps, c__s__1050000329, c__iter__1050000328 any) { t.F_dumps = c__dumps; t.F_s__1050000329 = c__s__1050000329; t.F_iter__1050000328 = c__iter__1050000328 }
//line :553:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_A) Invoke_O__O(self any) any { { var s__1050000329__1 any; var t_ any = t.F_s__1050000329; t.F_s__1050000329 = nil; s__1050000329__1 = t_; for { var temp__1927000414__auto____2 any; var root_2781 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_2782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2781, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2783 lang.IFn; if linked_2782 == nil { ifn_2783 = lang.IFn_Cast(root_2781) } else { ifn_2783 = nil }; var arg_2784 any = s__1050000329__1; if linked_2782 == nil { temp__1927000414__auto____2 = ifn_2783.Invoke_O__O(arg_2784) } else { temp__1927000414__auto____2 = linked_2782.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2781, arg_2784) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000329__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2785 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_2786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2785, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2787 lang.IFn; if linked_2786 == nil { ifn_2787 = lang.IFn_Cast(root_2785) } else { ifn_2787 = nil }; var arg_2788 any = s__1050000329__3; if linked_2786 == nil { tmp1 = ifn_2787.Invoke_O__O(arg_2788) } else { tmp1 = linked_2786.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2785, arg_2788) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2789 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_2790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2789, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2791 lang.IFn; if linked_2790 == nil { ifn_2791 = lang.IFn_Cast(root_2789) } else { ifn_2791 = nil }; var arg_2792 any = s__1050000329__3; if linked_2790 == nil { c__1927001037__auto____4 = ifn_2791.Invoke_O__O(arg_2792) } else { c__1927001037__auto____4 = linked_2790.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2789, arg_2792) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000331__6 any; var root_2793 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_2794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2793, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2795 lang.IFn; if linked_2794 == nil { ifn_2795 = lang.IFn_Cast(root_2793) } else { ifn_2795 = nil }; var arg_2796 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2794 == nil { b__1050000331__6 = ifn_2795.Invoke_O__O(arg_2796) } else { b__1050000331__6 = linked_2794.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2793, arg_2796) }; var tmp2 any = A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_fn__1050000334_A_New_O_O_I_O(t.F_dumps, b__1050000331__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2813 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_fn__1050000334_A_fn_class; if fncls__2813 == nil { var fncls__2813d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_fn__1050000334_A_fn_class = fncls__2813d; tmp3 = fncls__2813d } else { tmp3 = fncls__2813 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2814 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_2815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2814, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2816 lang.IFn; if linked_2815 == nil { ifn_2816 = lang.IFn_Cast(root_2814) } else { ifn_2816 = nil }; var arg_2817 any; var root_2819 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_2820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2819, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2821 lang.IFn; if linked_2820 == nil { ifn_2821 = lang.IFn_Cast(root_2819) } else { ifn_2821 = nil }; var arg_2822 any = b__1050000331__6; if linked_2820 == nil { arg_2817 = ifn_2821.Invoke_O__O(arg_2822) } else { arg_2817 = linked_2820.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2819, arg_2822) }; var arg_2818 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000328); var tmp5 any; var root_2823 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_2824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2823, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2825 lang.IFn; if linked_2824 == nil { ifn_2825 = lang.IFn_Cast(root_2823) } else { ifn_2825 = nil }; var arg_2826 any = s__1050000329__3; if linked_2824 == nil { tmp5 = ifn_2825.Invoke_O__O(arg_2826) } else { tmp5 = linked_2824.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2823, arg_2826) }; arg_2818 = tmp4.Invoke_O__O(tmp5); if linked_2815 == nil { return ifn_2816.Invoke_O_O__O(arg_2817, arg_2818) } else { return linked_2815.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2814, arg_2817, arg_2818) } } else { var root_2827 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_2828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2827, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2829 lang.IFn; if linked_2828 == nil { ifn_2829 = lang.IFn_Cast(root_2827) } else { ifn_2829 = nil }; var arg_2830 any; var root_2832 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_2833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2832, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2834 lang.IFn; if linked_2833 == nil { ifn_2834 = lang.IFn_Cast(root_2832) } else { ifn_2834 = nil }; var arg_2835 any = b__1050000331__6; if linked_2833 == nil { arg_2830 = ifn_2834.Invoke_O__O(arg_2835) } else { arg_2830 = linked_2833.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2832, arg_2835) }; var arg_2831 any; if linked_2828 == nil { return ifn_2829.Invoke_O_O__O(arg_2830, arg_2831) } else { return linked_2828.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2827, arg_2830, arg_2831) } } } else { var p__4 any; var root_2836 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_2837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2836, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2838 lang.IFn; if linked_2837 == nil { ifn_2838 = lang.IFn_Cast(root_2836) } else { ifn_2838 = nil }; var arg_2839 any = s__1050000329__3; if linked_2837 == nil { p__4 = ifn_2838.Invoke_O__O(arg_2839) } else { p__4 = linked_2837.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2836, arg_2839) }; var root_2840 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_2841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2840, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2842 lang.IFn; if linked_2841 == nil { ifn_2842 = lang.IFn_Cast(root_2840) } else { ifn_2842 = nil }; var arg_2843 any; var tmp6 any; var root_2845 any = A_arbace_repr_go_parse_A_const_42.GetRawRoot__O(); var linked_2846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2845, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2847 lang.IFn
															if linked_2846 == nil { ifn_2847 = lang.IFn_Cast(root_2845) } else { ifn_2847 = nil }; var arg_2848 any; var root_2851 any = A_arbace_repr_go_parse_A_const_283.GetRawRoot__O(); var linked_2852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2851, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2853 lang.IFn; if linked_2852 == nil { ifn_2853 = lang.IFn_Cast(root_2851) } else { ifn_2853 = nil }; var arg_2854 any = p__4; var arg_2855 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_dumps)))).Ref(); if linked_2852 == nil { arg_2848 = ifn_2853.Invoke_O_O__O(arg_2854, arg_2855) } else { arg_2848 = linked_2852.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2851, arg_2854, arg_2855) }; var arg_2849 any = A_arbace_repr_go_parse_A_const_325; var arg_2850 any = Lit_11; if linked_2846 == nil { tmp6 = ifn_2847.Invoke_O_O_O__O(arg_2848, arg_2849, arg_2850) } else { tmp6 = linked_2846.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2845, arg_2848, arg_2849, arg_2850) }
//line :553:1
	arg_2843 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, p__4); var arg_2844 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1050000328); var tmp8 any; var root_2856 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_2857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2856, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2858 lang.IFn; if linked_2857 == nil { ifn_2858 = lang.IFn_Cast(root_2856) } else { ifn_2858 = nil }; var arg_2859 any = s__1050000329__3; if linked_2857 == nil { tmp8 = ifn_2858.Invoke_O__O(arg_2859) } else { tmp8 = linked_2857.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2856, arg_2859) }; arg_2844 = tmp7.Invoke_O__O(tmp8); if linked_2841 == nil { return ifn_2842.Invoke_O_O__O(arg_2843, arg_2844) } else { return linked_2841.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2840, arg_2843, arg_2844) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :553:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_fn__1050000334_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_fn__1050000334_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_fn__1050000334_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :553:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_fn__1050000334_A) Ctor_O_O_I_O(c__dumps, c__b__1050000331 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_dumps = c__dumps; t.F_b__1050000331 = c__b__1050000331; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :553:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_fn__1050000334_A) Invoke_O__O(self any) any { { var i__1050000330__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000330__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var p__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000330__1)); var root_2797 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_2798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2797, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2799 lang.IFn; if linked_2798 == nil { ifn_2799 = lang.IFn_Cast(root_2797) } else { ifn_2799 = nil }; var arg_2800 any = t.F_b__1050000331; var arg_2801 any; var tmp2 any; var root_2802 any = A_arbace_repr_go_parse_A_const_42.GetRawRoot__O(); var linked_2803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2802, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_2804 lang.IFn
																	if linked_2803 == nil { ifn_2804 = lang.IFn_Cast(root_2802) } else { ifn_2804 = nil }; var arg_2805 any; var root_2808 any = A_arbace_repr_go_parse_A_const_283.GetRawRoot__O(); var linked_2809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2808, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2810 lang.IFn; if linked_2809 == nil { ifn_2810 = lang.IFn_Cast(root_2808) } else { ifn_2810 = nil }; var arg_2811 any = p__2; var arg_2812 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_dumps)))).Ref(); if linked_2809 == nil { arg_2805 = ifn_2810.Invoke_O_O__O(arg_2811, arg_2812) } else { arg_2805 = linked_2809.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_2808, arg_2811, arg_2812) }; var arg_2806 any = A_arbace_repr_go_parse_A_const_325; var arg_2807 any = Lit_11; if linked_2803 == nil { tmp2 = ifn_2804.Invoke_O_O_O__O(arg_2805, arg_2806, arg_2807) } else { tmp2 = linked_2803.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_2802, arg_2805, arg_2806, arg_2807) }
//line :553:1
	arg_2801 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, p__2); if linked_2798 == nil { ifn_2799.Invoke_O_O__O(arg_2800, arg_2801) } else { linked_2798.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2797, arg_2800, arg_2801) }; i__1050000330__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000330__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_repr_go_parse_check_corpus_fn__1050000338_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_go_parse_check_corpus_fn__1050000338_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_fn__1050000338_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :557:1
func (t *A_arbace_repr_go_parse_check_corpus_fn__1050000338_A) Ctor_O_O_O_O_O_O(c__headers, c__helper, c__out, c__nm, c__pool, c__goroot_forms any) { t.F_headers = c__headers; t.F_helper = c__helper; t.F_out = c__out; t.F_nm = c__nm; t.F_pool = c__pool; t.F_goroot_forms = c__goroot_forms }
//line :557:1
func (t *A_arbace_repr_go_parse_check_corpus_fn__1050000338_A) Invoke_O_O__O(self, j__1 any) any {
	var tmp1 jrt.ExecutorService = jrt.ExecutorService_Cast(t.F_pool); var tmp2 any = A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_A_New_O_O_O_O_O_O(t.F_headers, t.F_helper, j__1, t.F_out, t.F_nm, t.F_goroot_forms); var tmp3 *jrt.Class; var fncls__2903 *jrt.Class = A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_A_fn_class
	if fncls__2903 == nil { var fncls__2903d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_A_fn_class = fncls__2903d; tmp3 = fncls__2903d } else { tmp3 = fncls__2903 }
//line :558:1
	return tmp1.Submit_Callable__Future(jrt.Callable_Cast(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).WithMeta_IPersistentMap__IObj(lang.IPersistentMap_Cast(A_arbace_repr_go_parse_A_const_332)))) }
func A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :559:1
func (t *A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_A) Ctor_O_O_O_O_O_O(c__headers, c__helper, c__j, c__out, c__nm, c__goroot_forms any) { t.F_headers = c__headers; t.F_helper = c__helper; t.F_j = c__j; t.F_out = c__out; t.F_nm = c__nm; t.F_goroot_forms = c__goroot_forms }
//line :559:1
func (t *A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_A) Invoke_O__O(self any) any { if jrt.J2g_Truth(t.F_headers) {
													var root_2884 any = A_arbace_repr_go_parse_A_const_329.GetRawRoot__O(); var linked_2885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2884, A_arbace_repr_go_parse_check_header_A_fn_class); var ifn_2886 lang.IFn; if linked_2885 == nil { ifn_2886 = lang.IFn_Cast(root_2884) } else { ifn_2886 = nil }; var arg_2887 any = t.F_j; var tmp1 any = t.F_helper; var arg_2888 any = lang.RT_Get_O_O__O_NoInit(tmp1, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(t.F_j)); if linked_2885 == nil { return ifn_2886.Invoke_O_O__O(arg_2887, arg_2888) } else { return linked_2885.(*A_arbace_repr_go_parse_check_header_A).Invoke_O_O_O__O(root_2884, arg_2887, arg_2888) } } else {
														var root_2889 any = A_arbace_repr_go_parse_A_const_330.GetRawRoot__O(); var linked_2890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2889, A_arbace_repr_go_parse_check_job_A_fn_class); var ifn_2891 lang.IFn; if linked_2890 == nil { ifn_2891 = lang.IFn_Cast(root_2889) } else { ifn_2891 = nil }; var arg_2892 any = t.F_goroot_forms; var arg_2893 any = t.F_j; var tmp2 any = t.F_helper; var arg_2894 any = lang.RT_Get_O_O__O_NoInit(tmp2, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(t.F_j)); var arg_2895 any
														if jrt.J2g_Truth(t.F_out) { var tmp3 any = A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_fn__1050000340_A_New_O_O_O(t.F_j, t.F_out, t.F_nm); var tmp4 *jrt.Class; var fncls__2902 *jrt.Class = A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_fn__1050000340_A_fn_class; if fncls__2902 == nil { var fncls__2902d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_fn__1050000340_A_fn_class = fncls__2902d; tmp4 = fncls__2902d } else { tmp4 = fncls__2902 }; arg_2895 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) } else { arg_2895 = nil }
//line :561:1
		if linked_2890 == nil { return ifn_2891.Invoke_O_O_O_O__O(arg_2892, arg_2893, arg_2894, arg_2895) } else { return linked_2890.(*A_arbace_repr_go_parse_check_job_A).Invoke_O_O_O_O_O__O(root_2889, arg_2892, arg_2893, arg_2894, arg_2895) } } }
func A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_fn__1050000340_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_fn__1050000340_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_fn__1050000340_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :562:1
func (t *A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_fn__1050000340_A) Ctor_O_O_O(c__j, c__out, c__nm any) { t.F_j = c__j; t.F_out = c__out; t.F_nm = c__nm }
//line :562:1
func (t *A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_fn__1050000340_A) Invoke_O_O__O(self, p1__1050000317_SHARP___1 any) any { var root_2896 any = A_arbace_repr_go_parse_A_const_331.GetRawRoot__O(); var linked_2897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2896, A_arbace_repr_go_parse_write_native_BANG__A_fn_class); var ifn_2898 lang.IFn; if linked_2897 == nil { ifn_2898 = lang.IFn_Cast(root_2896) } else { ifn_2898 = nil }; var arg_2899 any = p1__1050000317_SHARP___1; var arg_2900 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, t.F_out, nil, t.F_nm)).Ref(); var arg_2901 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_73), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(t.F_j), nil)).Ref(); if linked_2897 == nil { return ifn_2898.Invoke_O_O_O__O(arg_2899, arg_2900, arg_2901) } else { return linked_2897.(*A_arbace_repr_go_parse_write_native_BANG__A).Invoke_O_O_O_O__O(root_2896, arg_2899, arg_2900, arg_2901) } }

func A_arbace_repr_go_parse_check_corpus_fn__1050000344_A_New() *A_arbace_repr_go_parse_check_corpus_fn__1050000344_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_fn__1050000344_A{}; t.Ctor(); return t }
//line :564:1
func (t *A_arbace_repr_go_parse_check_corpus_fn__1050000344_A) Ctor() {}
//line :564:1
func (t *A_arbace_repr_go_parse_check_corpus_fn__1050000344_A) Invoke_O_O__O(self, p1__1050000318_SHARP___1 any) any { return jrt.Future_Cast(p1__1050000318_SHARP___1).Get__O() }
func A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_A{}; t.Ctor_O_O(p0, p1); return t }
//line :565:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_A) Ctor_O_O(c__results, c__jkeys any) { t.F_results = c__results; t.F_jkeys = c__jkeys }
//line :565:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_A) Invoke_O_O__O(self, s__1050000347__1 any) any { var tmp1 any = A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_A_New_O_O_O_O(t.F_results, t.F_jkeys, s__1050000347__1, self); var tmp2 *jrt.Class; var fncls__2996 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_A_fn_class; if fncls__2996 == nil { var fncls__2996d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_A_fn_class = fncls__2996d; tmp2 = fncls__2996d } else { tmp2 = fncls__2996 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :565:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :565:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_A) Ctor_O_O_O_O(c__results, c__jkeys, c__s__1050000347, c__iter__1050000346 any) { t.F_results = c__results; t.F_jkeys = c__jkeys; t.F_s__1050000347 = c__s__1050000347; t.F_iter__1050000346 = c__iter__1050000346 }
//line :565:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_A) Invoke_O__O(self any) any { { var s__1050000347__1 any; var t_ any = t.F_s__1050000347; t.F_s__1050000347 = nil; s__1050000347__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2915 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_2916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2915, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2917 lang.IFn; if linked_2916 == nil { ifn_2917 = lang.IFn_Cast(root_2915) } else { ifn_2917 = nil }; var arg_2918 any = s__1050000347__1; if linked_2916 == nil { temp__1927000414__auto____2 = ifn_2917.Invoke_O__O(arg_2918) } else { temp__1927000414__auto____2 = linked_2916.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2915, arg_2918) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000347__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2919 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_2920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2919, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2921 lang.IFn; if linked_2920 == nil { ifn_2921 = lang.IFn_Cast(root_2919) } else { ifn_2921 = nil }; var arg_2922 any = s__1050000347__3; if linked_2920 == nil { tmp1 = ifn_2921.Invoke_O__O(arg_2922) } else { tmp1 = linked_2920.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2919, arg_2922) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2923 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_2924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2923, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2925 lang.IFn; if linked_2924 == nil { ifn_2925 = lang.IFn_Cast(root_2923) } else { ifn_2925 = nil }; var arg_2926 any = s__1050000347__3; if linked_2924 == nil { c__1927001037__auto____4 = ifn_2925.Invoke_O__O(arg_2926) } else { c__1927001037__auto____4 = linked_2924.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2923, arg_2926) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000349__6 any; var root_2927 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_2928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2927, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2929 lang.IFn; if linked_2928 == nil { ifn_2929 = lang.IFn_Cast(root_2927) } else { ifn_2929 = nil }; var arg_2930 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2928 == nil { b__1050000349__6 = ifn_2929.Invoke_O__O(arg_2930) } else { b__1050000349__6 = linked_2928.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2927, arg_2930) }; var tmp2 any = A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_A_New_O_O_I_O_O(t.F_results, t.F_jkeys, size__1927001038__auto____5, b__1050000349__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2946 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_A_fn_class; if fncls__2946 == nil { var fncls__2946d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_A_fn_class = fncls__2946d; tmp3 = fncls__2946d } else { tmp3 = fncls__2946 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2947 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_2948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2947, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2949 lang.IFn; if linked_2948 == nil { ifn_2949 = lang.IFn_Cast(root_2947) } else { ifn_2949 = nil }; var arg_2950 any; var root_2952 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_2953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2952, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2954 lang.IFn; if linked_2953 == nil { ifn_2954 = lang.IFn_Cast(root_2952) } else { ifn_2954 = nil }; var arg_2955 any = b__1050000349__6; if linked_2953 == nil { arg_2950 = ifn_2954.Invoke_O__O(arg_2955) } else { arg_2950 = linked_2953.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2952, arg_2955) }; var arg_2951 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000346); var tmp5 any; var root_2956 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_2957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2956, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2958 lang.IFn; if linked_2957 == nil { ifn_2958 = lang.IFn_Cast(root_2956) } else { ifn_2958 = nil }; var arg_2959 any = s__1050000347__3; if linked_2957 == nil { tmp5 = ifn_2958.Invoke_O__O(arg_2959) } else { tmp5 = linked_2957.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2956, arg_2959) }; arg_2951 = tmp4.Invoke_O__O(tmp5); if linked_2948 == nil { return ifn_2949.Invoke_O_O__O(arg_2950, arg_2951) } else { return linked_2948.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2947, arg_2950, arg_2951) } } else { var root_2960 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_2961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2960, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2962 lang.IFn; if linked_2961 == nil { ifn_2962 = lang.IFn_Cast(root_2960) } else { ifn_2962 = nil }; var arg_2963 any; var root_2965 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_2966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2965, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2967 lang.IFn; if linked_2966 == nil { ifn_2967 = lang.IFn_Cast(root_2965) } else { ifn_2967 = nil }; var arg_2968 any = b__1050000349__6; if linked_2966 == nil { arg_2963 = ifn_2967.Invoke_O__O(arg_2968) } else { arg_2963 = linked_2966.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2965, arg_2968) }; var arg_2964 any; if linked_2961 == nil { return ifn_2962.Invoke_O_O__O(arg_2963, arg_2964) } else { return linked_2961.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2960, arg_2963, arg_2964) } } } else { var vec__1050000359__4 any; var root_2969 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_2970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2969, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2971 lang.IFn; if linked_2970 == nil { ifn_2971 = lang.IFn_Cast(root_2969) } else { ifn_2971 = nil }; var arg_2972 any = s__1050000347__3; if linked_2970 == nil { vec__1050000359__4 = ifn_2971.Invoke_O__O(arg_2972) } else { vec__1050000359__4 = linked_2970.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2969, arg_2972) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000359__4, lang.RT_IntCast_J__I_NoInit(0), nil); var p__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000359__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_2973 any = A_arbace_repr_go_parse_A_const_75.GetRawRoot__O(); var linked_2974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2973, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2975 lang.IFn; if linked_2974 == nil { ifn_2975 = lang.IFn_Cast(root_2973) } else { ifn_2975 = nil }; var arg_2976 any = lang.IFn_Cast(t.F_jkeys).Invoke_O__O(k__5); if linked_2974 == nil { tmp6 = ifn_2975.Invoke_O__O(arg_2976) } else { tmp6 = linked_2974.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2973, arg_2976) }; if jrt.J2g_Truth(tmp6) { var root_2977 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_2978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2977, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2979 lang.IFn; if linked_2978 == nil { ifn_2979 = lang.IFn_Cast(root_2977) } else { ifn_2979 = nil }; var arg_2980 any; var tmp7 any = A_arbace_repr_go_parse_A_const_78; var tmp8 any = A_arbace_repr_go_parse_A_const_184; var tmp9 any = A_arbace_repr_go_parse_A_const_333; var tmp10 *jrt.String; var temp__1927000408__auto____7 any; var root_2982 any = A_arbace_repr_go_parse_A_const_138.GetRawRoot__O(); var linked_2983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2982, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2984 lang.IFn
															if linked_2983 == nil { ifn_2984 = lang.IFn_Cast(root_2982) } else { ifn_2984 = nil }; var arg_2985 any; var tmp11 any = A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000362_A_New_O(k__5); var tmp12 *jrt.Class; var fncls__2987 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000362_A_fn_class; if fncls__2987 == nil { var fncls__2987d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000362_A_fn_class = fncls__2987d; tmp12 = fncls__2987d } else { tmp12 = fncls__2987 }; arg_2985 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_2986 any = t.F_results; if linked_2983 == nil { temp__1927000408__auto____7 = ifn_2984.Invoke_O_O__O(arg_2985, arg_2986) } else { temp__1927000408__auto____7 = linked_2983.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2982, arg_2985, arg_2986) }; if jrt.J2g_Truth(temp__1927000408__auto____7) { var r__8 any = temp__1927000408__auto____7
																tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_81, nil, Lit_82, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_go_parse_A_const_316.Invoke_O__O(r__8), nil, A_arbace_repr_go_parse_A_const_203.Invoke_O__O(r__8))) } else {
//line :566:1
			tmp10 = Lit_83 }
//line :565:1
	arg_2980 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, k__5, tmp8, p__6, tmp9, tmp10.Ref())); var arg_2981 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__1050000346); var tmp14 any; var root_2988 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_2989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2988, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2990 lang.IFn; if linked_2989 == nil { ifn_2990 = lang.IFn_Cast(root_2988) } else { ifn_2990 = nil }; var arg_2991 any = s__1050000347__3; if linked_2989 == nil { tmp14 = ifn_2990.Invoke_O__O(arg_2991) } else { tmp14 = linked_2989.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2988, arg_2991) }; arg_2981 = tmp13.Invoke_O__O(tmp14); if linked_2978 == nil { return ifn_2979.Invoke_O_O__O(arg_2980, arg_2981) } else { return linked_2978.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2977, arg_2980, arg_2981) } } else { var tmp15 any; var root_2992 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_2993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2992, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2994 lang.IFn; if linked_2993 == nil { ifn_2994 = lang.IFn_Cast(root_2992) } else { ifn_2994 = nil }; var arg_2995 any = s__1050000347__3; if linked_2993 == nil { tmp15 = ifn_2994.Invoke_O__O(arg_2995) } else { tmp15 = linked_2993.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2992, arg_2995) }; s__1050000347__1 = tmp15; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :565:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :565:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_A) Ctor_O_O_I_O_O(c__results, c__jkeys any, c__size__1927001038__auto__ int32, c__b__1050000349, c__c__1927001037__auto__ any) { t.F_results = c__results; t.F_jkeys = c__jkeys; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1050000349 = c__b__1050000349; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :565:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_A) Invoke_O__O(self any) any { { var i__1050000348__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000348__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1050000353__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000348__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000353__2, lang.RT_IntCast_J__I_NoInit(0), nil); var p__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000353__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_2931 any = A_arbace_repr_go_parse_A_const_75.GetRawRoot__O(); var linked_2932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2931, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2933 lang.IFn; if linked_2932 == nil { ifn_2933 = lang.IFn_Cast(root_2931) } else { ifn_2933 = nil }; var arg_2934 any = lang.IFn_Cast(t.F_jkeys).Invoke_O__O(k__3); if linked_2932 == nil { tmp2 = ifn_2933.Invoke_O__O(arg_2934) } else { tmp2 = linked_2932.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2931, arg_2934) }; if jrt.J2g_Truth(tmp2) { var root_2935 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_2936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2935, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2937 lang.IFn; if linked_2936 == nil { ifn_2937 = lang.IFn_Cast(root_2935) } else { ifn_2937 = nil }; var arg_2938 any = t.F_b__1050000349; var arg_2939 any; var tmp3 any = A_arbace_repr_go_parse_A_const_78; var tmp4 any = A_arbace_repr_go_parse_A_const_184; var tmp5 any = A_arbace_repr_go_parse_A_const_333; var tmp6 *jrt.String; var temp__1927000408__auto____5 any; var root_2940 any = A_arbace_repr_go_parse_A_const_138.GetRawRoot__O(); var linked_2941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2940, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2942 lang.IFn
																	if linked_2941 == nil { ifn_2942 = lang.IFn_Cast(root_2940) } else { ifn_2942 = nil }; var arg_2943 any; var tmp7 any = A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_fn__1050000356_A_New_O(k__3); var tmp8 *jrt.Class; var fncls__2945 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_fn__1050000356_A_fn_class; if fncls__2945 == nil { var fncls__2945d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_fn__1050000356_A_fn_class = fncls__2945d; tmp8 = fncls__2945d } else { tmp8 = fncls__2945 }; arg_2943 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_2944 any = t.F_results; if linked_2941 == nil { temp__1927000408__auto____5 = ifn_2942.Invoke_O_O__O(arg_2943, arg_2944) } else { temp__1927000408__auto____5 = linked_2941.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2940, arg_2943, arg_2944) }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var r__6 any = temp__1927000408__auto____5
																		tmp6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_81, nil, Lit_82, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_repr_go_parse_A_const_316.Invoke_O__O(r__6), nil, A_arbace_repr_go_parse_A_const_203.Invoke_O__O(r__6))) } else {
//line :566:1
			tmp6 = Lit_83 }
//line :565:1
	arg_2939 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, k__3, tmp4, p__4, tmp5, tmp6.Ref())); if linked_2936 == nil { ifn_2937.Invoke_O_O__O(arg_2938, arg_2939) } else { linked_2936.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2935, arg_2938, arg_2939) }; i__1050000348__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000348__1); continue L1 } else { i__1050000348__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000348__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_fn__1050000356_A_New_O(p0 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_fn__1050000356_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_fn__1050000356_A{}; t.Ctor_O(p0); return t }
//line :566:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_fn__1050000356_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :566:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_fn__1050000356_A) Invoke_O_O__O(self, p1__1050000319_SHARP___1 any) any { var tmp1 any = t.F_k; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(p1__1050000319_SHARP___1)) { return p1__1050000319_SHARP___1 } else { return nil } }
//line :566:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000362_A_New_O(p0 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000362_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000362_A{}; t.Ctor_O(p0); return t }
//line :566:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000362_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :566:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000362_A) Invoke_O_O__O(self, p1__1050000319_SHARP___1 any) any { var tmp1 any = t.F_k; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(p1__1050000319_SHARP___1)) { return p1__1050000319_SHARP___1 } else { return nil } }



func A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_A{}; t.Ctor_O_O(p0, p1); return t }
//line :570:1
func (t *A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_A) Ctor_O_O(c__hres, c__js any) { t.F_hres = c__hres; t.F_js = c__js }
//line :570:1
func (t *A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_A) Invoke_O_O__O(self, r__1 any) any { var tmp1 any; var root_3007 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3007, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3009 lang.IFn; if linked_3008 == nil { ifn_3009 = lang.IFn_Cast(root_3007) } else { ifn_3009 = nil }; var arg_3010 any; var tmp2 any = t.F_hres; var tmp3 any; var or__1927000174__auto____2 any; var tmp4 *lang.Keyword = A_arbace_repr_go_parse_A_const_312; var tmp5 any; var root_3011 any = A_arbace_repr_go_parse_A_const_138.GetRawRoot__O(); var linked_3012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3011, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3013 lang.IFn; if linked_3012 == nil { ifn_3013 = lang.IFn_Cast(root_3011) } else { ifn_3013 = nil }; var arg_3014 any; var tmp6 any = A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_fn__1050000367_A_New_O(r__1); var tmp7 *jrt.Class; var fncls__3016 *jrt.Class = A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_fn__1050000367_A_fn_class; if fncls__3016 == nil { var fncls__3016d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_fn__1050000367_A_fn_class = fncls__3016d; tmp7 = fncls__3016d } else { tmp7 = fncls__3016 }; arg_3014 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_3015 any = t.F_js; if linked_3012 == nil { tmp5 = ifn_3013.Invoke_O_O__O(arg_3014, arg_3015) } else { tmp5 = linked_3012.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3011, arg_3014, arg_3015) }; or__1927000174__auto____2 = tmp4.Invoke_O__O(tmp5); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp3 = or__1927000174__auto____2 } else { tmp3 = A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__1) }; arg_3010 = lang.RT_Get_O_O__O_NoInit(tmp2, tmp3); if linked_3008 == nil { tmp1 = ifn_3009.Invoke_O__O(arg_3010) } else { tmp1 = linked_3008.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3007, arg_3010) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_74, tmp1)).Ref() }
//line :570:1
func A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_fn__1050000367_A_New_O(p0 any) *A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_fn__1050000367_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_fn__1050000367_A{}; t.Ctor_O(p0); return t }
//line :570:1
func (t *A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_fn__1050000367_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :570:1
func (t *A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_fn__1050000367_A) Invoke_O_O__O(self, p1__1050000320_SHARP___1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_repr_go_parse_A_const_78.Invoke_O__O(t.F_r), A_arbace_repr_go_parse_A_const_78.Invoke_O__O(p1__1050000320_SHARP___1)) { return p1__1050000320_SHARP___1 } else { return nil } }
func A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_A_New_O(p0 any) *A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_A{}; t.Ctor_O(p0); return t }
//line :571:1
func (t *A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_A) Ctor_O(c__known any) { t.F_known = c__known }
//line :571:1
func (t *A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_A) Invoke_O_O__O(self, r__1 any) any { var or__1927000174__auto____2 any; var root_3018 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_3019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3018, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3020 lang.IFn; if linked_3019 == nil { ifn_3020 = lang.IFn_Cast(root_3018) } else { ifn_3020 = nil }; var arg_3021 any = t.F_known; var arg_3022 any = A_arbace_repr_go_parse_A_const_289.Invoke_O__O(r__1); if linked_3019 == nil { or__1927000174__auto____2 = ifn_3020.Invoke_O_O__O(arg_3021, arg_3022) } else { or__1927000174__auto____2 = linked_3019.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3018, arg_3021, arg_3022) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_3023 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_3024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3023, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3025 lang.IFn; if linked_3024 == nil { ifn_3025 = lang.IFn_Cast(root_3023) } else { ifn_3025 = nil }; var arg_3026 any = t.F_known; var arg_3027 any = A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__1); if linked_3024 == nil { or__1927000174__auto____3 = ifn_3025.Invoke_O_O__O(arg_3026, arg_3027) } else { or__1927000174__auto____3 = linked_3024.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3023, arg_3026, arg_3027) }; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var root_3028 any = A_arbace_repr_go_parse_A_const_138.GetRawRoot__O(); var linked_3029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3028, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_3030 lang.IFn; if linked_3029 == nil { ifn_3030 = lang.IFn_Cast(root_3028) } else { ifn_3030 = nil }; var arg_3031 any; var tmp1 any = A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_fn__1050000371_A_New_O(t.F_known); var tmp2 *jrt.Class; var fncls__3038 *jrt.Class = A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_fn__1050000371_A_fn_class; if fncls__3038 == nil { var fncls__3038d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_fn__1050000371_A_fn_class = fncls__3038d; tmp2 = fncls__3038d } else { tmp2 = fncls__3038 }; arg_3031 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_3032 any = A_arbace_repr_go_parse_A_const_291.Invoke_O__O(r__1); if linked_3029 == nil { return ifn_3030.Invoke_O_O__O(arg_3031, arg_3032) } else { return linked_3029.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_3028, arg_3031, arg_3032) } } } }
//line :571:1
func A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_fn__1050000371_A_New_O(p0 any) *A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_fn__1050000371_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_fn__1050000371_A{}; t.Ctor_O(p0); return t }
//line :571:1
func (t *A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_fn__1050000371_A) Ctor_O(c__known any) { t.F_known = c__known }
//line :571:1
func (t *A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_fn__1050000371_A) Invoke_O_O__O(self, p1__1050000321_SHARP___1 any) any { var root_3033 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_3034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3033, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3035 lang.IFn; if linked_3034 == nil { ifn_3035 = lang.IFn_Cast(root_3033) } else { ifn_3035 = nil }; var arg_3036 any = t.F_known; var arg_3037 any = p1__1050000321_SHARP___1; if linked_3034 == nil { return ifn_3035.Invoke_O_O__O(arg_3036, arg_3037) } else { return linked_3034.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3033, arg_3036, arg_3037) } }




func A_arbace_repr_go_parse_check_corpus_fn__1050000374_A_New() *A_arbace_repr_go_parse_check_corpus_fn__1050000374_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_fn__1050000374_A{}; t.Ctor(); return t }
//line :576:1
func (t *A_arbace_repr_go_parse_check_corpus_fn__1050000374_A) Ctor() {}
//line :576:1
func (t *A_arbace_repr_go_parse_check_corpus_fn__1050000374_A) Invoke_O_O__O(self, p1__1050000322_SHARP___1 any) any { var and__1927000168__auto____2 any = A_arbace_repr_go_parse_A_const_66.Invoke_O__O(p1__1050000322_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { var root_3072 any = A_arbace_repr_go_parse_A_const_75.GetRawRoot__O(); var linked_3073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3072, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3074 lang.IFn; if linked_3073 == nil { ifn_3074 = lang.IFn_Cast(root_3072) } else { ifn_3074 = nil }; var arg_3075 any = A_arbace_repr_go_parse_A_const_295.Invoke_O__O(p1__1050000322_SHARP___1); if linked_3073 == nil { return ifn_3074.Invoke_O__O(arg_3075) } else { return linked_3073.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3072, arg_3075) } } else { return and__1927000168__auto____2 } }
func A_arbace_repr_go_parse_check_corpus_sum__1050000376_A_New_O(p0 any) *A_arbace_repr_go_parse_check_corpus_sum__1050000376_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_sum__1050000376_A{}; t.Ctor_O(p0); return t }
//line :577:1
func (t *A_arbace_repr_go_parse_check_corpus_sum__1050000376_A) Ctor_O(c__ok any) { t.F_ok = c__ok }
//line :577:1
func (t *A_arbace_repr_go_parse_check_corpus_sum__1050000376_A) Invoke_O_O__O(self, k__1 any) any { var root_3077 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_3078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3077, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3079 lang.IFn; if linked_3078 == nil { ifn_3079 = lang.IFn_Cast(root_3077) } else { ifn_3079 = nil }; var arg_3080 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_3081 any; var root_3082 any = A_arbace_repr_go_parse_A_const_279.GetRawRoot__O(); var linked_3083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3082, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3084 lang.IFn; if linked_3083 == nil { ifn_3084 = lang.IFn_Cast(root_3082) } else { ifn_3084 = nil }; var arg_3085 any; var tmp1 any = A_arbace_repr_go_parse_check_corpus_sum__1050000376_fn__1050000377_A_New_O(k__1); var tmp2 *jrt.Class; var fncls__3092 *jrt.Class = A_arbace_repr_go_parse_check_corpus_sum__1050000376_fn__1050000377_A_fn_class; if fncls__3092 == nil { var fncls__3092d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_repr_go_parse_check_corpus_sum__1050000376_fn__1050000377_A_fn_class = fncls__3092d; tmp2 = fncls__3092d } else { tmp2 = fncls__3092 }; arg_3085 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_3086 any = t.F_ok; if linked_3083 == nil { arg_3081 = ifn_3084.Invoke_O_O__O(arg_3085, arg_3086) } else { arg_3081 = linked_3083.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3082, arg_3085, arg_3086) }; if linked_3078 == nil { return ifn_3079.Invoke_O_O__O(arg_3080, arg_3081) } else { return linked_3078.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3077, arg_3080, arg_3081) } }
//line :577:1
func A_arbace_repr_go_parse_check_corpus_sum__1050000376_fn__1050000377_A_New_O(p0 any) *A_arbace_repr_go_parse_check_corpus_sum__1050000376_fn__1050000377_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_sum__1050000376_fn__1050000377_A{}; t.Ctor_O(p0); return t }
//line :577:1
func (t *A_arbace_repr_go_parse_check_corpus_sum__1050000376_fn__1050000377_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :577:1
func (t *A_arbace_repr_go_parse_check_corpus_sum__1050000376_fn__1050000377_A) Invoke_O_O__O(self, p1__1050000323_SHARP___1 any) any { var root_3087 any = A_arbace_repr_go_parse_A_const_247.GetRawRoot__O(); var linked_3088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3087, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3089 lang.IFn; if linked_3088 == nil { ifn_3089 = lang.IFn_Cast(root_3087) } else { ifn_3089 = nil }; var arg_3090 any = p1__1050000323_SHARP___1; var arg_3091 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_parse_A_const_256, t.F_k); if linked_3088 == nil { return ifn_3089.Invoke_O_O__O(arg_3090, arg_3091) } else { return linked_3088.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3087, arg_3090, arg_3091) } }








func A_arbace_repr_go_parse_check_corpus_fn__1050000396_A_New_O(p0 any) *A_arbace_repr_go_parse_check_corpus_fn__1050000396_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_fn__1050000396_A{}; t.Ctor_O(p0); return t }
//line :586:1
func (t *A_arbace_repr_go_parse_check_corpus_fn__1050000396_A) Ctor_O(c__helper any) { t.F_helper = c__helper }
//line :586:1
func (t *A_arbace_repr_go_parse_check_corpus_fn__1050000396_A) Invoke_O_O__O(self, p1__1050000324_SHARP___1 any) any { var root_3525 any = A_arbace_repr_go_parse_A_const_51.GetRawRoot__O(); var linked_3526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3525, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3527 lang.IFn; if linked_3526 == nil { ifn_3527 = lang.IFn_Cast(root_3525) } else { ifn_3527 = nil }; var arg_3528 any = t.F_helper; var arg_3529 any = A_arbace_repr_go_parse_A_const_78.Invoke_O__O(p1__1050000324_SHARP___1); if linked_3526 == nil { return ifn_3527.Invoke_O_O__O(arg_3528, arg_3529) } else { return linked_3526.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3525, arg_3528, arg_3529) } }






func A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_A_New() *A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_A{}; t.Ctor(); return t }
//line :593:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_A) Ctor() {}
//line :593:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_A) Invoke_O_O__O(self, s__1050000399__1 any) any { var tmp1 any = A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_A_New_O_O(s__1050000399__1, self); var tmp2 *jrt.Class; var fncls__3185 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_A_fn_class; if fncls__3185 == nil { var fncls__3185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_A_fn_class = fncls__3185d; tmp2 = fncls__3185d } else { tmp2 = fncls__3185 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :593:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_A{}; t.Ctor_O_O(p0, p1); return t }
//line :593:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_A) Ctor_O_O(c__s__1050000399, c__iter__1050000398 any) { t.F_s__1050000399 = c__s__1050000399; t.F_iter__1050000398 = c__iter__1050000398 }
//line :593:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_A) Invoke_O__O(self any) any { { var s__1050000399__1 any; var t_ any = t.F_s__1050000399; t.F_s__1050000399 = nil; s__1050000399__1 = t_; for { var temp__1927000414__auto____2 any; var root_3128 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3128, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3130 lang.IFn; if linked_3129 == nil { ifn_3130 = lang.IFn_Cast(root_3128) } else { ifn_3130 = nil }; var arg_3131 any = s__1050000399__1; if linked_3129 == nil { temp__1927000414__auto____2 = ifn_3130.Invoke_O__O(arg_3131) } else { temp__1927000414__auto____2 = linked_3129.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3128, arg_3131) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000399__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3132 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_3133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3132, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3134 lang.IFn; if linked_3133 == nil { ifn_3134 = lang.IFn_Cast(root_3132) } else { ifn_3134 = nil }; var arg_3135 any = s__1050000399__3; if linked_3133 == nil { tmp1 = ifn_3134.Invoke_O__O(arg_3135) } else { tmp1 = linked_3133.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3132, arg_3135) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3136 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_3137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3136, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3138 lang.IFn; if linked_3137 == nil { ifn_3138 = lang.IFn_Cast(root_3136) } else { ifn_3138 = nil }; var arg_3139 any = s__1050000399__3; if linked_3137 == nil { c__1927001037__auto____4 = ifn_3138.Invoke_O__O(arg_3139) } else { c__1927001037__auto____4 = linked_3137.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3136, arg_3139) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000401__6 any; var root_3140 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_3141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3140, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3142 lang.IFn; if linked_3141 == nil { ifn_3142 = lang.IFn_Cast(root_3140) } else { ifn_3142 = nil }; var arg_3143 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3141 == nil { b__1050000401__6 = ifn_3142.Invoke_O__O(arg_3143) } else { b__1050000401__6 = linked_3141.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3140, arg_3143) }; var tmp2 any = A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_fn__1050000404_A_New_O_I_O(b__1050000401__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3149 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_fn__1050000404_A_fn_class; if fncls__3149 == nil { var fncls__3149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_fn__1050000404_A_fn_class = fncls__3149d; tmp3 = fncls__3149d } else { tmp3 = fncls__3149 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3150 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_3151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3150, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3152 lang.IFn; if linked_3151 == nil { ifn_3152 = lang.IFn_Cast(root_3150) } else { ifn_3152 = nil }; var arg_3153 any; var root_3155 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_3156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3155, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3157 lang.IFn; if linked_3156 == nil { ifn_3157 = lang.IFn_Cast(root_3155) } else { ifn_3157 = nil }; var arg_3158 any = b__1050000401__6; if linked_3156 == nil { arg_3153 = ifn_3157.Invoke_O__O(arg_3158) } else { arg_3153 = linked_3156.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3155, arg_3158) }; var arg_3154 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000398); var tmp5 any; var root_3159 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_3160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3159, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3161 lang.IFn; if linked_3160 == nil { ifn_3161 = lang.IFn_Cast(root_3159) } else { ifn_3161 = nil }; var arg_3162 any = s__1050000399__3; if linked_3160 == nil { tmp5 = ifn_3161.Invoke_O__O(arg_3162) } else { tmp5 = linked_3160.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3159, arg_3162) }; arg_3154 = tmp4.Invoke_O__O(tmp5); if linked_3151 == nil { return ifn_3152.Invoke_O_O__O(arg_3153, arg_3154) } else { return linked_3151.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3150, arg_3153, arg_3154) } } else { var root_3163 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_3164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3163, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3165 lang.IFn; if linked_3164 == nil { ifn_3165 = lang.IFn_Cast(root_3163) } else { ifn_3165 = nil }; var arg_3166 any; var root_3168 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_3169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3168, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3170 lang.IFn; if linked_3169 == nil { ifn_3170 = lang.IFn_Cast(root_3168) } else { ifn_3170 = nil }; var arg_3171 any = b__1050000401__6; if linked_3169 == nil { arg_3166 = ifn_3170.Invoke_O__O(arg_3171) } else { arg_3166 = linked_3169.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3168, arg_3171) }; var arg_3167 any; if linked_3164 == nil { return ifn_3165.Invoke_O_O__O(arg_3166, arg_3167) } else { return linked_3164.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3163, arg_3166, arg_3167) } } } else { var r__4 any; var root_3172 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3172, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3174 lang.IFn; if linked_3173 == nil { ifn_3174 = lang.IFn_Cast(root_3172) } else { ifn_3174 = nil }; var arg_3175 any = s__1050000399__3; if linked_3173 == nil { r__4 = ifn_3174.Invoke_O__O(arg_3175) } else { r__4 = linked_3173.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3172, arg_3175) }; var root_3176 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_3177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3176, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3178 lang.IFn; if linked_3177 == nil { ifn_3178 = lang.IFn_Cast(root_3176) } else { ifn_3178 = nil }; var arg_3179 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__4), A_arbace_repr_go_parse_A_const_300.Invoke_O__O(r__4)); var arg_3180 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1050000398); var tmp7 any; var root_3181 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_3182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3181, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3183 lang.IFn; if linked_3182 == nil { ifn_3183 = lang.IFn_Cast(root_3181) } else { ifn_3183 = nil }; var arg_3184 any = s__1050000399__3; if linked_3182 == nil { tmp7 = ifn_3183.Invoke_O__O(arg_3184) } else { tmp7 = linked_3182.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3181, arg_3184) }; arg_3180 = tmp6.Invoke_O__O(tmp7); if linked_3177 == nil { return ifn_3178.Invoke_O_O__O(arg_3179, arg_3180) } else { return linked_3177.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3176, arg_3179, arg_3180) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :593:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_fn__1050000404_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_fn__1050000404_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_fn__1050000404_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :593:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_fn__1050000404_A) Ctor_O_I_O(c__b__1050000401 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1050000401 = c__b__1050000401; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :593:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_fn__1050000404_A) Invoke_O__O(self any) any { { var i__1050000400__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000400__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var r__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000400__1)); var root_3144 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_3145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3144, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3146 lang.IFn; if linked_3145 == nil { ifn_3146 = lang.IFn_Cast(root_3144) } else { ifn_3146 = nil }; var arg_3147 any = t.F_b__1050000401; var arg_3148 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__2), A_arbace_repr_go_parse_A_const_300.Invoke_O__O(r__2)); if linked_3145 == nil { ifn_3146.Invoke_O_O__O(arg_3147, arg_3148) } else { linked_3145.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3144, arg_3147, arg_3148) }; i__1050000400__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000400__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :593:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_A_New() *A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_A{}; t.Ctor(); return t }
//line :593:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_A) Ctor() {}
//line :593:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_A) Invoke_O_O__O(self, s__1050000409__1 any) any { var tmp1 any = A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_A_New_O_O(s__1050000409__1, self); var tmp2 *jrt.Class; var fncls__3248 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_A_fn_class; if fncls__3248 == nil { var fncls__3248d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_A_fn_class = fncls__3248d; tmp2 = fncls__3248d } else { tmp2 = fncls__3248 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :593:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_A{}; t.Ctor_O_O(p0, p1); return t }
//line :593:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_A) Ctor_O_O(c__s__1050000409, c__iter__1050000408 any) { t.F_s__1050000409 = c__s__1050000409; t.F_iter__1050000408 = c__iter__1050000408 }
//line :593:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_A) Invoke_O__O(self any) any { { var s__1050000409__1 any; var t_ any = t.F_s__1050000409; t.F_s__1050000409 = nil; s__1050000409__1 = t_; for { var temp__1927000414__auto____2 any; var root_3191 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3191, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3193 lang.IFn; if linked_3192 == nil { ifn_3193 = lang.IFn_Cast(root_3191) } else { ifn_3193 = nil }; var arg_3194 any = s__1050000409__1; if linked_3192 == nil { temp__1927000414__auto____2 = ifn_3193.Invoke_O__O(arg_3194) } else { temp__1927000414__auto____2 = linked_3192.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3191, arg_3194) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000409__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3195 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_3196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3195, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3197 lang.IFn; if linked_3196 == nil { ifn_3197 = lang.IFn_Cast(root_3195) } else { ifn_3197 = nil }; var arg_3198 any = s__1050000409__3; if linked_3196 == nil { tmp1 = ifn_3197.Invoke_O__O(arg_3198) } else { tmp1 = linked_3196.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3195, arg_3198) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3199 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_3200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3199, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3201 lang.IFn; if linked_3200 == nil { ifn_3201 = lang.IFn_Cast(root_3199) } else { ifn_3201 = nil }; var arg_3202 any = s__1050000409__3; if linked_3200 == nil { c__1927001037__auto____4 = ifn_3201.Invoke_O__O(arg_3202) } else { c__1927001037__auto____4 = linked_3200.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3199, arg_3202) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000411__6 any; var root_3203 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_3204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3203, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3205 lang.IFn; if linked_3204 == nil { ifn_3205 = lang.IFn_Cast(root_3203) } else { ifn_3205 = nil }; var arg_3206 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3204 == nil { b__1050000411__6 = ifn_3205.Invoke_O__O(arg_3206) } else { b__1050000411__6 = linked_3204.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3203, arg_3206) }; var tmp2 any = A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_fn__1050000414_A_New_O_I_O(b__1050000411__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3212 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_fn__1050000414_A_fn_class; if fncls__3212 == nil { var fncls__3212d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_fn__1050000414_A_fn_class = fncls__3212d; tmp3 = fncls__3212d } else { tmp3 = fncls__3212 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3213 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_3214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3213, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3215 lang.IFn; if linked_3214 == nil { ifn_3215 = lang.IFn_Cast(root_3213) } else { ifn_3215 = nil }; var arg_3216 any; var root_3218 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_3219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3218, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3220 lang.IFn; if linked_3219 == nil { ifn_3220 = lang.IFn_Cast(root_3218) } else { ifn_3220 = nil }; var arg_3221 any = b__1050000411__6; if linked_3219 == nil { arg_3216 = ifn_3220.Invoke_O__O(arg_3221) } else { arg_3216 = linked_3219.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3218, arg_3221) }; var arg_3217 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000408); var tmp5 any; var root_3222 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_3223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3222, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3224 lang.IFn; if linked_3223 == nil { ifn_3224 = lang.IFn_Cast(root_3222) } else { ifn_3224 = nil }; var arg_3225 any = s__1050000409__3; if linked_3223 == nil { tmp5 = ifn_3224.Invoke_O__O(arg_3225) } else { tmp5 = linked_3223.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3222, arg_3225) }; arg_3217 = tmp4.Invoke_O__O(tmp5); if linked_3214 == nil { return ifn_3215.Invoke_O_O__O(arg_3216, arg_3217) } else { return linked_3214.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3213, arg_3216, arg_3217) } } else { var root_3226 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_3227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3226, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3228 lang.IFn; if linked_3227 == nil { ifn_3228 = lang.IFn_Cast(root_3226) } else { ifn_3228 = nil }; var arg_3229 any; var root_3231 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_3232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3231, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3233 lang.IFn; if linked_3232 == nil { ifn_3233 = lang.IFn_Cast(root_3231) } else { ifn_3233 = nil }; var arg_3234 any = b__1050000411__6; if linked_3232 == nil { arg_3229 = ifn_3233.Invoke_O__O(arg_3234) } else { arg_3229 = linked_3232.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3231, arg_3234) }; var arg_3230 any; if linked_3227 == nil { return ifn_3228.Invoke_O_O__O(arg_3229, arg_3230) } else { return linked_3227.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3226, arg_3229, arg_3230) } } } else { var r__4 any; var root_3235 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3235, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3237 lang.IFn; if linked_3236 == nil { ifn_3237 = lang.IFn_Cast(root_3235) } else { ifn_3237 = nil }; var arg_3238 any = s__1050000409__3; if linked_3236 == nil { r__4 = ifn_3237.Invoke_O__O(arg_3238) } else { r__4 = linked_3236.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3235, arg_3238) }; var root_3239 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_3240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3239, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3241 lang.IFn; if linked_3240 == nil { ifn_3241 = lang.IFn_Cast(root_3239) } else { ifn_3241 = nil }; var arg_3242 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__4), A_arbace_repr_go_parse_A_const_293.Invoke_O__O(r__4)); var arg_3243 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1050000408); var tmp7 any; var root_3244 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_3245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3244, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3246 lang.IFn; if linked_3245 == nil { ifn_3246 = lang.IFn_Cast(root_3244) } else { ifn_3246 = nil }; var arg_3247 any = s__1050000409__3; if linked_3245 == nil { tmp7 = ifn_3246.Invoke_O__O(arg_3247) } else { tmp7 = linked_3245.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3244, arg_3247) }; arg_3243 = tmp6.Invoke_O__O(tmp7); if linked_3240 == nil { return ifn_3241.Invoke_O_O__O(arg_3242, arg_3243) } else { return linked_3240.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3239, arg_3242, arg_3243) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :593:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_fn__1050000414_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_fn__1050000414_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_fn__1050000414_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :593:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_fn__1050000414_A) Ctor_O_I_O(c__b__1050000411 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1050000411 = c__b__1050000411; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :593:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_fn__1050000414_A) Invoke_O__O(self any) any { { var i__1050000410__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000410__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var r__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000410__1)); var root_3207 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_3208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3207, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3209 lang.IFn; if linked_3208 == nil { ifn_3209 = lang.IFn_Cast(root_3207) } else { ifn_3209 = nil }; var arg_3210 any = t.F_b__1050000411; var arg_3211 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__2), A_arbace_repr_go_parse_A_const_293.Invoke_O__O(r__2)); if linked_3208 == nil { ifn_3209.Invoke_O_O__O(arg_3210, arg_3211) } else { linked_3208.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3207, arg_3210, arg_3211) }; i__1050000410__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000410__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_A_New() *A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_A{}; t.Ctor(); return t }
//line :594:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_A) Ctor() {}
//line :594:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_A) Invoke_O_O__O(self, s__1050000419__1 any) any { var tmp1 any = A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_A_New_O_O(s__1050000419__1, self); var tmp2 *jrt.Class; var fncls__3311 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_A_fn_class; if fncls__3311 == nil { var fncls__3311d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_A_fn_class = fncls__3311d; tmp2 = fncls__3311d } else { tmp2 = fncls__3311 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :594:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_A{}; t.Ctor_O_O(p0, p1); return t }
//line :594:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_A) Ctor_O_O(c__s__1050000419, c__iter__1050000418 any) { t.F_s__1050000419 = c__s__1050000419; t.F_iter__1050000418 = c__iter__1050000418 }
//line :594:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_A) Invoke_O__O(self any) any { { var s__1050000419__1 any; var t_ any = t.F_s__1050000419; t.F_s__1050000419 = nil; s__1050000419__1 = t_; for { var temp__1927000414__auto____2 any; var root_3254 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3254, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3256 lang.IFn; if linked_3255 == nil { ifn_3256 = lang.IFn_Cast(root_3254) } else { ifn_3256 = nil }; var arg_3257 any = s__1050000419__1; if linked_3255 == nil { temp__1927000414__auto____2 = ifn_3256.Invoke_O__O(arg_3257) } else { temp__1927000414__auto____2 = linked_3255.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3254, arg_3257) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000419__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3258 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_3259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3258, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3260 lang.IFn; if linked_3259 == nil { ifn_3260 = lang.IFn_Cast(root_3258) } else { ifn_3260 = nil }; var arg_3261 any = s__1050000419__3; if linked_3259 == nil { tmp1 = ifn_3260.Invoke_O__O(arg_3261) } else { tmp1 = linked_3259.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3258, arg_3261) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3262 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_3263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3262, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3264 lang.IFn; if linked_3263 == nil { ifn_3264 = lang.IFn_Cast(root_3262) } else { ifn_3264 = nil }; var arg_3265 any = s__1050000419__3; if linked_3263 == nil { c__1927001037__auto____4 = ifn_3264.Invoke_O__O(arg_3265) } else { c__1927001037__auto____4 = linked_3263.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3262, arg_3265) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000421__6 any; var root_3266 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_3267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3266, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3268 lang.IFn; if linked_3267 == nil { ifn_3268 = lang.IFn_Cast(root_3266) } else { ifn_3268 = nil }; var arg_3269 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3267 == nil { b__1050000421__6 = ifn_3268.Invoke_O__O(arg_3269) } else { b__1050000421__6 = linked_3267.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3266, arg_3269) }; var tmp2 any = A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_fn__1050000424_A_New_O_I_O(b__1050000421__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3275 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_fn__1050000424_A_fn_class; if fncls__3275 == nil { var fncls__3275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_fn__1050000424_A_fn_class = fncls__3275d; tmp3 = fncls__3275d } else { tmp3 = fncls__3275 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3276 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_3277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3276, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3278 lang.IFn; if linked_3277 == nil { ifn_3278 = lang.IFn_Cast(root_3276) } else { ifn_3278 = nil }; var arg_3279 any; var root_3281 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_3282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3281, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3283 lang.IFn; if linked_3282 == nil { ifn_3283 = lang.IFn_Cast(root_3281) } else { ifn_3283 = nil }; var arg_3284 any = b__1050000421__6; if linked_3282 == nil { arg_3279 = ifn_3283.Invoke_O__O(arg_3284) } else { arg_3279 = linked_3282.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3281, arg_3284) }; var arg_3280 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000418); var tmp5 any; var root_3285 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_3286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3285, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3287 lang.IFn; if linked_3286 == nil { ifn_3287 = lang.IFn_Cast(root_3285) } else { ifn_3287 = nil }; var arg_3288 any = s__1050000419__3; if linked_3286 == nil { tmp5 = ifn_3287.Invoke_O__O(arg_3288) } else { tmp5 = linked_3286.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3285, arg_3288) }; arg_3280 = tmp4.Invoke_O__O(tmp5); if linked_3277 == nil { return ifn_3278.Invoke_O_O__O(arg_3279, arg_3280) } else { return linked_3277.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3276, arg_3279, arg_3280) } } else { var root_3289 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_3290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3289, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3291 lang.IFn; if linked_3290 == nil { ifn_3291 = lang.IFn_Cast(root_3289) } else { ifn_3291 = nil }; var arg_3292 any; var root_3294 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_3295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3294, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3296 lang.IFn; if linked_3295 == nil { ifn_3296 = lang.IFn_Cast(root_3294) } else { ifn_3296 = nil }; var arg_3297 any = b__1050000421__6; if linked_3295 == nil { arg_3292 = ifn_3296.Invoke_O__O(arg_3297) } else { arg_3292 = linked_3295.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3294, arg_3297) }; var arg_3293 any; if linked_3290 == nil { return ifn_3291.Invoke_O_O__O(arg_3292, arg_3293) } else { return linked_3290.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3289, arg_3292, arg_3293) } } } else { var r__4 any; var root_3298 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3298, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3300 lang.IFn; if linked_3299 == nil { ifn_3300 = lang.IFn_Cast(root_3298) } else { ifn_3300 = nil }; var arg_3301 any = s__1050000419__3; if linked_3299 == nil { r__4 = ifn_3300.Invoke_O__O(arg_3301) } else { r__4 = linked_3299.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3298, arg_3301) }; var root_3302 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_3303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3302, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3304 lang.IFn; if linked_3303 == nil { ifn_3304 = lang.IFn_Cast(root_3302) } else { ifn_3304 = nil }; var arg_3305 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__4), A_arbace_repr_go_parse_A_const_333.Invoke_O__O(r__4)); var arg_3306 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1050000418); var tmp7 any; var root_3307 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_3308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3307, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3309 lang.IFn; if linked_3308 == nil { ifn_3309 = lang.IFn_Cast(root_3307) } else { ifn_3309 = nil }; var arg_3310 any = s__1050000419__3; if linked_3308 == nil { tmp7 = ifn_3309.Invoke_O__O(arg_3310) } else { tmp7 = linked_3308.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3307, arg_3310) }; arg_3306 = tmp6.Invoke_O__O(tmp7); if linked_3303 == nil { return ifn_3304.Invoke_O_O__O(arg_3305, arg_3306) } else { return linked_3303.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3302, arg_3305, arg_3306) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :594:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_fn__1050000424_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_fn__1050000424_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_fn__1050000424_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :594:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_fn__1050000424_A) Ctor_O_I_O(c__b__1050000421 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1050000421 = c__b__1050000421; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :594:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_fn__1050000424_A) Invoke_O__O(self any) any { { var i__1050000420__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000420__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var r__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000420__1)); var root_3270 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_3271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3270, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3272 lang.IFn; if linked_3271 == nil { ifn_3272 = lang.IFn_Cast(root_3270) } else { ifn_3272 = nil }; var arg_3273 any = t.F_b__1050000421; var arg_3274 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__2), A_arbace_repr_go_parse_A_const_333.Invoke_O__O(r__2)); if linked_3271 == nil { ifn_3272.Invoke_O_O__O(arg_3273, arg_3274) } else { linked_3271.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3270, arg_3273, arg_3274) }; i__1050000420__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000420__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_A{}; t.Ctor_O_O(p0, p1); return t }
//line :595:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_A) Ctor_O_O(c__hres, c__helper_failed_QMARK_ any) { t.F_hres = c__hres; t.F_helper_failed_QMARK_ = c__helper_failed_QMARK_ }
//line :595:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_A) Invoke_O_O__O(self, s__1050000429__1 any) any { var tmp1 any = A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_A_New_O_O_O_O(t.F_hres, s__1050000429__1, self, t.F_helper_failed_QMARK_); var tmp2 *jrt.Class; var fncls__3382 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_A_fn_class; if fncls__3382 == nil { var fncls__3382d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_A_fn_class = fncls__3382d; tmp2 = fncls__3382d } else { tmp2 = fncls__3382 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :595:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :595:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_A) Ctor_O_O_O_O(c__hres, c__s__1050000429, c__iter__1050000428, c__helper_failed_QMARK_ any) { t.F_hres = c__hres; t.F_s__1050000429 = c__s__1050000429; t.F_iter__1050000428 = c__iter__1050000428; t.F_helper_failed_QMARK_ = c__helper_failed_QMARK_ }
//line :595:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_A) Invoke_O__O(self any) any { { var s__1050000429__1 any; var t_ any = t.F_s__1050000429; t.F_s__1050000429 = nil; s__1050000429__1 = t_; for { var temp__1927000414__auto____2 any; var root_3317 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3317, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3319 lang.IFn; if linked_3318 == nil { ifn_3319 = lang.IFn_Cast(root_3317) } else { ifn_3319 = nil }; var arg_3320 any = s__1050000429__1; if linked_3318 == nil { temp__1927000414__auto____2 = ifn_3319.Invoke_O__O(arg_3320) } else { temp__1927000414__auto____2 = linked_3318.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3317, arg_3320) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000429__3 any = temp__1927000414__auto____2; var tmp1 any; var root_3321 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_3322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3321, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3323 lang.IFn; if linked_3322 == nil { ifn_3323 = lang.IFn_Cast(root_3321) } else { ifn_3323 = nil }; var arg_3324 any = s__1050000429__3; if linked_3322 == nil { tmp1 = ifn_3323.Invoke_O__O(arg_3324) } else { tmp1 = linked_3322.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3321, arg_3324) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_3325 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_3326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3325, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3327 lang.IFn; if linked_3326 == nil { ifn_3327 = lang.IFn_Cast(root_3325) } else { ifn_3327 = nil }; var arg_3328 any = s__1050000429__3; if linked_3326 == nil { c__1927001037__auto____4 = ifn_3327.Invoke_O__O(arg_3328) } else { c__1927001037__auto____4 = linked_3326.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3325, arg_3328) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000431__6 any; var root_3329 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_3330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3329, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_3331 lang.IFn; if linked_3330 == nil { ifn_3331 = lang.IFn_Cast(root_3329) } else { ifn_3331 = nil }; var arg_3332 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_3330 == nil { b__1050000431__6 = ifn_3331.Invoke_O__O(arg_3332) } else { b__1050000431__6 = linked_3330.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_3329, arg_3332) }; var tmp2 any = A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_fn__1050000434_A_New_O_O_I_O_O(t.F_hres, b__1050000431__6, size__1927001038__auto____5, t.F_helper_failed_QMARK_, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__3342 *jrt.Class = A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_fn__1050000434_A_fn_class; if fncls__3342 == nil { var fncls__3342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_fn__1050000434_A_fn_class = fncls__3342d; tmp3 = fncls__3342d } else { tmp3 = fncls__3342 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_3343 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_3344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3343, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3345 lang.IFn; if linked_3344 == nil { ifn_3345 = lang.IFn_Cast(root_3343) } else { ifn_3345 = nil }; var arg_3346 any; var root_3348 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_3349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3348, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3350 lang.IFn; if linked_3349 == nil { ifn_3350 = lang.IFn_Cast(root_3348) } else { ifn_3350 = nil }; var arg_3351 any = b__1050000431__6; if linked_3349 == nil { arg_3346 = ifn_3350.Invoke_O__O(arg_3351) } else { arg_3346 = linked_3349.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3348, arg_3351) }; var arg_3347 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000428); var tmp5 any; var root_3352 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_3353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3352, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3354 lang.IFn; if linked_3353 == nil { ifn_3354 = lang.IFn_Cast(root_3352) } else { ifn_3354 = nil }; var arg_3355 any = s__1050000429__3; if linked_3353 == nil { tmp5 = ifn_3354.Invoke_O__O(arg_3355) } else { tmp5 = linked_3353.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3352, arg_3355) }; arg_3347 = tmp4.Invoke_O__O(tmp5); if linked_3344 == nil { return ifn_3345.Invoke_O_O__O(arg_3346, arg_3347) } else { return linked_3344.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3343, arg_3346, arg_3347) } } else { var root_3356 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_3357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3356, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_3358 lang.IFn; if linked_3357 == nil { ifn_3358 = lang.IFn_Cast(root_3356) } else { ifn_3358 = nil }; var arg_3359 any; var root_3361 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_3362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3361, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_3363 lang.IFn; if linked_3362 == nil { ifn_3363 = lang.IFn_Cast(root_3361) } else { ifn_3363 = nil }; var arg_3364 any = b__1050000431__6; if linked_3362 == nil { arg_3359 = ifn_3363.Invoke_O__O(arg_3364) } else { arg_3359 = linked_3362.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_3361, arg_3364) }; var arg_3360 any; if linked_3357 == nil { return ifn_3358.Invoke_O_O__O(arg_3359, arg_3360) } else { return linked_3357.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_3356, arg_3359, arg_3360) } } } else { var r__4 any; var root_3365 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3365, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3367 lang.IFn; if linked_3366 == nil { ifn_3367 = lang.IFn_Cast(root_3365) } else { ifn_3367 = nil }; var arg_3368 any = s__1050000429__3; if linked_3366 == nil { r__4 = ifn_3367.Invoke_O__O(arg_3368) } else { r__4 = linked_3366.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3365, arg_3368) }; var root_3369 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_3370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3369, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_3371 lang.IFn; if linked_3370 == nil { ifn_3371 = lang.IFn_Cast(root_3369) } else { ifn_3371 = nil }; var arg_3372 any; var tmp6 any = A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__4); var tmp7 any; if jrt.J2g_Truth(lang.IFn_Cast(t.F_helper_failed_QMARK_).Invoke_O__O(r__4)) { var root_3374 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_3375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3374, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3376 lang.IFn; if linked_3375 == nil { ifn_3376 = lang.IFn_Cast(root_3374) } else { ifn_3376 = nil }; var tmp8 any = t.F_hres; var arg_3377 any = lang.RT_Get_O_O__O_NoInit(tmp8, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__4)); if linked_3375 == nil { tmp7 = ifn_3376.Invoke_O__O(arg_3377) } else { tmp7 = linked_3375.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3374, arg_3377) } } else { tmp7 = Lit_93 }; arg_3372 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7); var arg_3373 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1050000428); var tmp10 any; var root_3378 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_3379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3378, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3380 lang.IFn; if linked_3379 == nil { ifn_3380 = lang.IFn_Cast(root_3378) } else { ifn_3380 = nil }; var arg_3381 any = s__1050000429__3; if linked_3379 == nil { tmp10 = ifn_3380.Invoke_O__O(arg_3381) } else { tmp10 = linked_3379.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3378, arg_3381) }; arg_3373 = tmp9.Invoke_O__O(tmp10); if linked_3370 == nil { return ifn_3371.Invoke_O_O__O(arg_3372, arg_3373) } else { return linked_3370.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_3369, arg_3372, arg_3373) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :595:1
func A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_fn__1050000434_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_fn__1050000434_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_fn__1050000434_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :595:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_fn__1050000434_A) Ctor_O_O_I_O_O(c__hres, c__b__1050000431 any, c__size__1927001038__auto__ int32, c__helper_failed_QMARK_, c__c__1927001037__auto__ any) { t.F_hres = c__hres; t.F_b__1050000431 = c__b__1050000431; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_helper_failed_QMARK_ = c__helper_failed_QMARK_; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :595:1
func (t *A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_fn__1050000434_A) Invoke_O__O(self any) any { { var i__1050000430__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000430__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var r__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000430__1)); var root_3333 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_3334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3333, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_3335 lang.IFn; if linked_3334 == nil { ifn_3335 = lang.IFn_Cast(root_3333) } else { ifn_3335 = nil }; var arg_3336 any = t.F_b__1050000431; var arg_3337 any; var tmp2 any = A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__2); var tmp3 any; if jrt.J2g_Truth(lang.IFn_Cast(t.F_helper_failed_QMARK_).Invoke_O__O(r__2)) { var root_3338 any = A_arbace_repr_go_parse_A_const_34.GetRawRoot__O(); var linked_3339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3338, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3340 lang.IFn; if linked_3339 == nil { ifn_3340 = lang.IFn_Cast(root_3338) } else { ifn_3340 = nil }; var tmp4 any = t.F_hres; var arg_3341 any = lang.RT_Get_O_O__O_NoInit(tmp4, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__2)); if linked_3339 == nil { tmp3 = ifn_3340.Invoke_O__O(arg_3341) } else { tmp3 = linked_3339.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3338, arg_3341) } } else { tmp3 = Lit_93 }; arg_3337 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_3334 == nil { ifn_3335.Invoke_O_O__O(arg_3336, arg_3337) } else { linked_3334.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_3333, arg_3336, arg_3337) }; i__1050000430__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000430__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_repr_go_parse_read_corpus_A_New() *A_arbace_repr_go_parse_read_corpus_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_read_corpus_A{}; t.Ctor(); return t }
//line :599:1
func (t *A_arbace_repr_go_parse_read_corpus_A) Ctor() {}
//line :599:1
func (t *A_arbace_repr_go_parse_read_corpus_A) Invoke_O_O_O_O_O__O(self, goroot_forms__0, spec__1, pool__2, out__3 any) any { var t0__5 int64 = jrt.System_NanoTime__J(); var nm__6 any = A_arbace_repr_go_parse_A_const_73.Invoke_O__O(spec__1); var vec__1050000446__7 any; var root_3637 any = A_arbace_repr_go_parse_A_const_324.GetRawRoot__O(); var linked_3638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3637, A_arbace_repr_go_parse_spec_jobs_A_fn_class); var ifn_3639 lang.IFn; if




	linked_3638 == nil { ifn_3639 = lang.IFn_Cast(root_3637) } else { ifn_3639 = nil }; var arg_3640 any = spec__1; if linked_3638 == nil { vec__1050000446__7 = ifn_3639.Invoke_O__O(arg_3640) } else { vec__1050000446__7 = linked_3638.(*A_arbace_repr_go_parse_spec_jobs_A).Invoke_O_O__O(root_3637, arg_3640) }; var js__8 any = /*line :599:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1050000446__7, lang.RT_IntCast_J__I_NoInit(0), nil); var results__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000446__7, lang.RT_IntCast_J__I_NoInit(1), nil); var load_ms__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000446__7, lang.RT_IntCast_J__I_NoInit(2), nil); var futs__11 any; var root_3641 any = A_arbace_repr_go_parse_A_const_234.GetRawRoot__O(); var linked_3642 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3641, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_3643 lang.IFn; if





	linked_3642 == nil { ifn_3643 = lang.IFn_Cast(root_3641) } else { ifn_3643 = nil }; var arg_3644 any; var tmp1 any = A_arbace_repr_go_parse_read_corpus_fn__1050000449_A_New_O_O_O_O(out__3, pool__2, goroot_forms__0, nm__6); var tmp2 *jrt.Class; var fncls__3661 *jrt.Class = A_arbace_repr_go_parse_read_corpus_fn__1050000449_A_fn_class; if fncls__3661 == nil { var fncls__3661d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_repr_go_parse_read_corpus_fn__1050000449_A_fn_class = fncls__3661d; tmp2 = fncls__3661d } else { tmp2 = fncls__3661 }; arg_3644 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_3645 any = js__8; if linked_3642 == nil { futs__11 = ifn_3643.Invoke_O_O__O(arg_3644, arg_3645) } else { futs__11 = linked_3642.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_3641, arg_3644, arg_3645) }; var rs__12 any; var root_3662 any = /*line :599:1*/A_arbace_repr_go_parse_A_const_234.GetRawRoot__O(); var linked_3663 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3662, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_3664 lang.IFn; if










	linked_3663 == nil { ifn_3664 = lang.IFn_Cast(root_3662) } else { ifn_3664 = nil }; var arg_3665 any; var tmp3 any = A_arbace_repr_go_parse_read_corpus_fn__1050000455_A_New(); var tmp4 *jrt.Class; var fncls__3667 *jrt.Class = A_arbace_repr_go_parse_read_corpus_fn__1050000455_A_fn_class; if fncls__3667 == nil { var fncls__3667d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_162, false); A_arbace_repr_go_parse_read_corpus_fn__1050000455_A_fn_class = fncls__3667d; tmp4 = fncls__3667d } else { tmp4 = fncls__3667 }; arg_3665 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_3666 any = futs__11; if linked_3663 == nil { rs__12 = ifn_3664.Invoke_O_O__O(arg_3665, arg_3666) } else { rs__12 = linked_3663.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_3662, arg_3665, arg_3666) }; var ok__13 any; var root_3668 any = /*line :599:1*/A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_3669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3668, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3670 lang.IFn; if











	linked_3669 == nil { ifn_3670 = lang.IFn_Cast(root_3668) } else { ifn_3670 = nil }; var arg_3671 any = A_arbace_repr_go_parse_A_const_66; var arg_3672 any = rs__12; if linked_3669 == nil { ok__13 = ifn_3670.Invoke_O_O__O(arg_3671, arg_3672) } else { ok__13 = linked_3669.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3668, arg_3671, arg_3672) }; var sum__14 any; var tmp5 any = /*line :599:1*/A_arbace_repr_go_parse_read_corpus_sum__1050000457_A_New_O(ok__13); var tmp6 *jrt.Class; var fncls__3689 *jrt.Class = A_arbace_repr_go_parse_read_corpus_sum__1050000457_A_fn_class; if












	fncls__3689 == nil { var fncls__3689d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_repr_go_parse_read_corpus_sum__1050000457_A_fn_class = fncls__3689d; tmp6 = fncls__3689d } else { tmp6 = fncls__3689 }; sum__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var seq_1050000461__15 any; var root_3701 any = /*line :599:1*/A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3701, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3703 lang.IFn; if













	linked_3702 == nil { ifn_3703 = lang.IFn_Cast(root_3701) } else { ifn_3703 = nil }; var arg_3704 any; var root_3705 any = A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_3706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3705, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3707 lang.IFn; if linked_3706 == nil { ifn_3707 = lang.IFn_Cast(root_3705) } else { ifn_3707 = nil }; var arg_3708 any; var tmp7 any = A_arbace_repr_go_parse_read_corpus_fn__1050000465_A_New(); var tmp8 *jrt.Class; var fncls__3710 *jrt.Class = A_arbace_repr_go_parse_read_corpus_fn__1050000465_A_fn_class; if fncls__3710 == nil { var fncls__3710d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_164, false); A_arbace_repr_go_parse_read_corpus_fn__1050000465_A_fn_class = fncls__3710d; tmp8 = fncls__3710d } else { tmp8 = fncls__3710 }; arg_3708 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_3709 any = rs__12; if linked_3706 == nil { arg_3704 = ifn_3707.Invoke_O_O__O(arg_3708, arg_3709) } else { arg_3704 = linked_3706.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3705, arg_3708, arg_3709) }; if linked_3702 == nil { seq_1050000461__15 = ifn_3703.Invoke_O__O(arg_3704) } else { seq_1050000461__15 = linked_3702.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3701, arg_3704) }; var chunk_1050000462__16 any; var count_1050000463__17 int64 = 0; var i_1050000464__18 int64 = 0; L1:
//line :599:1
	for {













		if lang.Numbers_Lt_J_J__Z_NoInit(i_1050000464__18, count_1050000463__17) { var r__19 any = lang.Indexed_Cast(chunk_1050000462__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1050000464__18)); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp10 any = A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__19); var tmp11 any; var or__1927000174__auto____20 any = A_arbace_repr_go_parse_A_const_294.Invoke_O__O(r__19); if jrt.J2g_Truth(or__1927000174__auto____20) { tmp11 = or__1927000174__auto____20 } else { tmp11 = A_arbace_repr_go_parse_A_const_293.Invoke_O__O(r__19) }; tmp9.Invoke_O_O_O_O__O(Lit_165, nm__6, tmp10, tmp11); seq_1050000461__15, chunk_1050000462__16, count_1050000463__17, i_1050000464__18 = seq_1050000461__15, chunk_1050000462__16, count_1050000463__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1050000464__18); continue L1 } else { var temp__1927000414__auto____19 any; var root_3711 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3711, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3713 lang.IFn; if linked_3712 == nil { ifn_3713 = lang.IFn_Cast(root_3711) } else { ifn_3713 = nil }; var arg_3714 any = seq_1050000461__15; if linked_3712 == nil { temp__1927000414__auto____19 = ifn_3713.Invoke_O__O(arg_3714) } else { temp__1927000414__auto____19 = linked_3712.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3711, arg_3714) }; if jrt.J2g_Truth(temp__1927000414__auto____19) { var seq_1050000461__20 any = temp__1927000414__auto____19; var tmp12 any; var root_3715 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_3716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3715, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3717 lang.IFn; if linked_3716 == nil { ifn_3717 = lang.IFn_Cast(root_3715) } else { ifn_3717 = nil }; var arg_3718 any = seq_1050000461__20; if linked_3716 == nil { tmp12 = ifn_3717.Invoke_O__O(arg_3718) } else { tmp12 = linked_3716.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3715, arg_3718) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____21 any; var root_3719 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_3720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3719, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3721 lang.IFn; if linked_3720 == nil { ifn_3721 = lang.IFn_Cast(root_3719) } else { ifn_3721 = nil }; var arg_3722 any = seq_1050000461__20; if linked_3720 == nil { c__1927000678__auto____21 = ifn_3721.Invoke_O__O(arg_3722) } else { c__1927000678__auto____21 = linked_3720.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3719, arg_3722) }; var tmp13 any; var root_3811 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_3812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3811, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3813 lang.IFn; if linked_3812 == nil { ifn_3813 = lang.IFn_Cast(root_3811) } else { ifn_3813 = nil }; var arg_3814 any = seq_1050000461__20; if linked_3812 == nil { tmp13 = ifn_3813.Invoke_O__O(arg_3814) } else { tmp13 = linked_3812.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3811, arg_3814) }; seq_1050000461__15, chunk_1050000462__16, count_1050000463__17, i_1050000464__18 = tmp13, c__1927000678__auto____21, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var r__21 any; var root_3723 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3723, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3725 lang.IFn; if linked_3724 == nil { ifn_3725 = lang.IFn_Cast(root_3723) } else { ifn_3725 = nil }; var arg_3726 any = seq_1050000461__20; if linked_3724 == nil { r__21 = ifn_3725.Invoke_O__O(arg_3726) } else { r__21 = linked_3724.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3723, arg_3726) }; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp15 any = A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__21); var tmp16 any; var or__1927000174__auto____22 any = A_arbace_repr_go_parse_A_const_294.Invoke_O__O(r__21); if jrt.J2g_Truth(or__1927000174__auto____22) { tmp16 = or__1927000174__auto____22 } else { tmp16 = A_arbace_repr_go_parse_A_const_293.Invoke_O__O(r__21) }; tmp14.Invoke_O_O_O_O__O(Lit_165, nm__6, tmp15, tmp16); var tmp17 any; var root_3822 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_3823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3822, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3824 lang.IFn; if linked_3823 == nil { ifn_3824 = lang.IFn_Cast(root_3822) } else { ifn_3824 = nil }; var arg_3825 any = seq_1050000461__20; if linked_3823 == nil { tmp17 = ifn_3824.Invoke_O__O(arg_3825) } else { tmp17 = linked_3823.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3822, arg_3825) }; seq_1050000461__15, chunk_1050000462__16, count_1050000463__17, i_1050000464__18 = tmp17, nil, 0, 0; continue L1 } } }
//line :599:1
		break L1 }; var seq_1050000467__15 any; var root_3727 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3727, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3729 lang.IFn; if














	linked_3728 == nil { ifn_3729 = lang.IFn_Cast(root_3727) } else { ifn_3729 = nil }; var arg_3730 any = results__9; if linked_3728 == nil { seq_1050000467__15 = ifn_3729.Invoke_O__O(arg_3730) } else { seq_1050000467__15 = linked_3728.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3727, arg_3730) }; var chunk_1050000468__16 any; var count_1050000469__17 int64 = 0; var i_1050000470__18 int64 = 0; L2:
//line :599:1
	for {














		if lang.Numbers_Lt_J_J__Z_NoInit(i_1050000470__18, count_1050000469__17) { var r__19_2 any = lang.Indexed_Cast(chunk_1050000468__16).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1050000470__18)); if lang.Util_Equiv_O_O__Z_NoInit(Lit_74, A_arbace_repr_go_parse_A_const_316.Invoke_O__O(r__19_2)) { lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_53, nm__6, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__19_2), A_arbace_repr_go_parse_A_const_203.Invoke_O__O(r__19_2)); seq_1050000467__15, chunk_1050000468__16, count_1050000469__17, i_1050000470__18 = seq_1050000467__15, chunk_1050000468__16, count_1050000469__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1050000470__18); continue L2 } else { seq_1050000467__15, chunk_1050000468__16, count_1050000469__17, i_1050000470__18 = seq_1050000467__15, chunk_1050000468__16, count_1050000469__17, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1050000470__18); continue L2 } } else { var temp__1927000414__auto____19_2 any; var root_3731 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3731, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3733 lang.IFn; if linked_3732 == nil { ifn_3733 = lang.IFn_Cast(root_3731) } else { ifn_3733 = nil }; var arg_3734 any = seq_1050000467__15; if linked_3732 == nil { temp__1927000414__auto____19_2 = ifn_3733.Invoke_O__O(arg_3734) } else { temp__1927000414__auto____19_2 = linked_3732.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3731, arg_3734) }; if jrt.J2g_Truth(temp__1927000414__auto____19_2) { var seq_1050000467__20 any = temp__1927000414__auto____19_2; var tmp18 any; var root_3735 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_3736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3735, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_3737 lang.IFn; if linked_3736 == nil { ifn_3737 = lang.IFn_Cast(root_3735) } else { ifn_3737 = nil }; var arg_3738 any = seq_1050000467__20; if linked_3736 == nil { tmp18 = ifn_3737.Invoke_O__O(arg_3738) } else { tmp18 = linked_3736.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_3735, arg_3738) }; if jrt.J2g_Truth(tmp18) { var c__1927000678__auto____21_2 any; var root_3739 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_3740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3739, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_3741 lang.IFn; if linked_3740 == nil { ifn_3741 = lang.IFn_Cast(root_3739) } else { ifn_3741 = nil }; var arg_3742 any = seq_1050000467__20; if linked_3740 == nil { c__1927000678__auto____21_2 = ifn_3741.Invoke_O__O(arg_3742) } else { c__1927000678__auto____21_2 = linked_3740.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_3739, arg_3742) }; var tmp19 any; var root_3833 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_3834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3833, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_3835 lang.IFn; if linked_3834 == nil { ifn_3835 = lang.IFn_Cast(root_3833) } else { ifn_3835 = nil }; var arg_3836 any = seq_1050000467__20; if linked_3834 == nil { tmp19 = ifn_3835.Invoke_O__O(arg_3836) } else { tmp19 = linked_3834.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_3833, arg_3836) }; seq_1050000467__15, chunk_1050000468__16, count_1050000469__17, i_1050000470__18 = tmp19, c__1927000678__auto____21_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____21_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var r__21_2 any; var root_3743 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3743, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3745 lang.IFn; if linked_3744 == nil { ifn_3745 = lang.IFn_Cast(root_3743) } else { ifn_3745 = nil }; var arg_3746 any = seq_1050000467__20; if linked_3744 == nil { r__21_2 = ifn_3745.Invoke_O__O(arg_3746) } else { r__21_2 = linked_3744.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3743, arg_3746) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_74, A_arbace_repr_go_parse_A_const_316.Invoke_O__O(r__21_2)) { lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()).Invoke_O_O_O_O__O(Lit_53, nm__6, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(r__21_2), A_arbace_repr_go_parse_A_const_203.Invoke_O__O(r__21_2)); var tmp20 any; var root_3844 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_3845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3844, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3846 lang.IFn; if linked_3845 == nil { ifn_3846 = lang.IFn_Cast(root_3844) } else { ifn_3846 = nil }; var arg_3847 any = seq_1050000467__20; if linked_3845 == nil { tmp20 = ifn_3846.Invoke_O__O(arg_3847) } else { tmp20 = linked_3845.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3844, arg_3847) }; seq_1050000467__15, chunk_1050000468__16, count_1050000469__17, i_1050000470__18 = tmp20, nil, 0, 0; continue L2 } else { var tmp21 any; var root_3848 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_3849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3848, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3850 lang.IFn; if linked_3849 == nil { ifn_3850 = lang.IFn_Cast(root_3848) } else { ifn_3850 = nil }; var arg_3851 any = seq_1050000467__20; if linked_3849 == nil { tmp21 = ifn_3850.Invoke_O__O(arg_3851) } else { tmp21 = linked_3849.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3848, arg_3851) }; seq_1050000467__15, chunk_1050000468__16, count_1050000469__17, i_1050000470__18 = tmp21, nil, 0, 0; continue L2 } } } }
//line :599:1
		break L2 }; var tmp22 lang.IFn =















	lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_346.GetRawRoot__O()); var tmp24 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ok__13)).Ref(); var tmp25 any; var root_3767 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_3768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3767, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3769 lang.IFn; if
	linked_3768 == nil { ifn_3769 = lang.IFn_Cast(root_3767) } else { ifn_3769 = nil }; var arg_3770 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_3771 any; var root_3772 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_3773 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3772, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3774 lang.IFn; if linked_3773 == nil { ifn_3774 = lang.IFn_Cast(root_3772) } else { ifn_3774 = nil }; var arg_3775 any = A_arbace_repr_go_parse_A_const_189; var arg_3776 any = ok__13; if linked_3773 == nil { arg_3771 = ifn_3774.Invoke_O_O__O(arg_3775, arg_3776) } else { arg_3771 = linked_3773.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3772, arg_3775, arg_3776) }; if linked_3768 == nil { tmp25 = ifn_3769.Invoke_O_O__O(arg_3770, arg_3771) } else { tmp25 = linked_3768.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3767, arg_3770, arg_3771) }; var tmp26 any = tmp25; var tmp27 any; var root_3777 any = /*line :615:1*/A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_3778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3777, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3779 lang.IFn; if
	linked_3778 == nil { ifn_3779 = lang.IFn_Cast(root_3777) } else { ifn_3779 = nil }; var arg_3780 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_3781 any; var root_3782 any = A_arbace_repr_go_parse_A_const_279.GetRawRoot__O(); var linked_3783 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3782, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3784 lang.IFn; if linked_3783 == nil { ifn_3784 = lang.IFn_Cast(root_3782) } else { ifn_3784 = nil }; var arg_3785 any = A_arbace_repr_go_parse_A_const_66; var arg_3786 any = ok__13; if linked_3783 == nil { arg_3781 = ifn_3784.Invoke_O_O__O(arg_3785, arg_3786) } else { arg_3781 = linked_3783.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3782, arg_3785, arg_3786) }; if linked_3778 == nil { tmp27 = ifn_3779.Invoke_O_O__O(arg_3780, arg_3781) } else { tmp27 = linked_3778.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3777, arg_3780, arg_3781) }; var tmp28 any = tmp27; var tmp29 any = /*line :615:1*/jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(lang.IFn_Cast(sum__14).Invoke_O__O(A_arbace_repr_go_parse_A_const_259), 1000000.0)).Ref(); var tmp30 any; var root_3787 any = A_arbace_repr_go_parse_A_const_20.GetRawRoot__O(); var linked_3788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3787, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3789 lang.IFn; if

	linked_3788 == nil { ifn_3789 = lang.IFn_Cast(root_3787) } else { ifn_3789 = nil }; var arg_3790 any = A_arbace_repr_go_parse_A_const_66; var arg_3791 any = rs__12; if linked_3788 == nil { tmp30 = ifn_3789.Invoke_O_O__O(arg_3790, arg_3791) } else { tmp30 = linked_3788.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3787, arg_3790, arg_3791) }; var tmp31 any = /*line :615:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp30)).Ref(); var tmp32 any; var root_3792 any = A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_3793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3792, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3794 lang.IFn; if

	linked_3793 == nil { ifn_3794 = lang.IFn_Cast(root_3792) } else { ifn_3794 = nil }; var arg_3795 any; var tmp33 any = A_arbace_repr_go_parse_read_corpus_fn__1050000471_A_New(); var tmp34 *jrt.Class; var fncls__3797 *jrt.Class = A_arbace_repr_go_parse_read_corpus_fn__1050000471_A_fn_class; if fncls__3797 == nil { var fncls__3797d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_167, false); A_arbace_repr_go_parse_read_corpus_fn__1050000471_A_fn_class = fncls__3797d; tmp34 = fncls__3797d } else { tmp34 = fncls__3797 }; arg_3795 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil); var arg_3796 any = results__9; if linked_3793 == nil { tmp32 = ifn_3794.Invoke_O_O__O(arg_3795, arg_3796) } else { tmp32 = linked_3793.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3792, arg_3795, arg_3796) }; var tmp35 any = /*line :615:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp32)).Ref(); var tmp36 any; var root_3798 any = A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_3799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3798, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3800 lang.IFn; if


	linked_3799 == nil { ifn_3800 = lang.IFn_Cast(root_3798) } else { ifn_3800 = nil }; var arg_3801 any; var tmp37 any = A_arbace_repr_go_parse_read_corpus_fn__1050000473_A_New(); var tmp38 *jrt.Class; var fncls__3803 *jrt.Class = A_arbace_repr_go_parse_read_corpus_fn__1050000473_A_fn_class; if fncls__3803 == nil { var fncls__3803d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_168, false); A_arbace_repr_go_parse_read_corpus_fn__1050000473_A_fn_class = fncls__3803d; tmp38 = fncls__3803d } else { tmp38 = fncls__3803 }; arg_3801 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil); var arg_3802 any = results__9; if linked_3799 == nil { tmp36 = ifn_3800.Invoke_O_O__O(arg_3801, arg_3802) } else { tmp36 = linked_3799.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3798, arg_3801, arg_3802) }; /*line :615:1*/tmp22.Invoke_O__O(tmp23.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O__O(Lit_166, nm__6, tmp24, tmp26, tmp28, tmp29, tmp31, tmp35, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp36)).Ref(), jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(load_ms__10, 1000.0)).Ref(), jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(lang.IFn_Cast(sum__14).Invoke_O__O(A_arbace_repr_go_parse_A_const_231), 1000.0)).Ref(), jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(lang.IFn_Cast(sum__14).Invoke_O__O(A_arbace_repr_go_parse_A_const_232), 1000.0)).Ref(), jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_J_D__D_NoInit(lang.Numbers_Minus_J_J__J_NoInit(jrt.System_NanoTime__J(), t0__5), 1.0e9)).Ref())); var tmp39 any = A_arbace_repr_go_parse_A_const_335; var tmp40 any = A_arbace_repr_go_parse_A_const_322; var tmp41 any = /*line :599:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ok__13)).Ref(); var tmp42 any = A_arbace_repr_go_parse_A_const_294; var tmp43 any; var root_3690 any = A_arbace_repr_go_parse_A_const_20.GetRawRoot__O(); var linked_3691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3690, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_3692 lang.IFn; if




















	linked_3691 == nil { ifn_3692 = lang.IFn_Cast(root_3690) } else { ifn_3692 = nil }; var arg_3693 any = A_arbace_repr_go_parse_A_const_66; var arg_3694 any = rs__12; if linked_3691 == nil { tmp43 = ifn_3692.Invoke_O_O__O(arg_3693, arg_3694) } else { tmp43 = linked_3691.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_3690, arg_3693, arg_3694) }; var tmp44 any = /*line :599:1*/jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp43)).Ref(); var tmp45 any = A_arbace_repr_go_parse_A_const_337; var tmp46 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(results__9)).Ref(); var tmp47 any = A_arbace_repr_go_parse_A_const_339; var tmp48 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(load_ms__10, 1000.0)).Ref(); var tmp49 any = A_arbace_repr_go_parse_A_const_340; var tmp50 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(lang.IFn_Cast(sum__14).Invoke_O__O(A_arbace_repr_go_parse_A_const_231), 1000.0)).Ref(); var tmp51 any = A_arbace_repr_go_parse_A_const_341; var tmp52 any = jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(lang.IFn_Cast(sum__14).Invoke_O__O(A_arbace_repr_go_parse_A_const_232), 1000.0)).Ref(); var tmp53 any = A_arbace_repr_go_parse_A_const_69; var tmp54 any; var root_3695 any = A_arbace_repr_go_parse_A_const_38.GetRawRoot__O(); var linked_3696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3695, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_3697 lang.IFn; if






















	linked_3696 == nil { ifn_3697 = lang.IFn_Cast(root_3695) } else { ifn_3697 = nil }; var arg_3698 any; var tmp55 any = A_arbace_repr_go_parse_read_corpus_fn__1050000475_A_New(); var tmp56 *jrt.Class; var fncls__3700 *jrt.Class = A_arbace_repr_go_parse_read_corpus_fn__1050000475_A_fn_class; if fncls__3700 == nil { var fncls__3700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_169, false); A_arbace_repr_go_parse_read_corpus_fn__1050000475_A_fn_class = fncls__3700d; tmp56 = fncls__3700d } else { tmp56 = fncls__3700 }; arg_3698 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp55, tmp56, nil); var arg_3699 any = results__9; if linked_3696 == nil { tmp54 = ifn_3697.Invoke_O_O__O(arg_3698, arg_3699) } else { tmp54 = linked_3696.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_3695, arg_3698, arg_3699) }; return /*line :599:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp39, nm__6, tmp40, tmp41, tmp42, tmp44, tmp45, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, tmp52, tmp53, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp54)).Ref())) }





func A_arbace_repr_go_parse_read_corpus_fn__1050000449_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_parse_read_corpus_fn__1050000449_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_read_corpus_fn__1050000449_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :605:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000449_A) Ctor_O_O_O_O(c__out, c__pool, c__goroot_forms, c__nm any) { t.F_out = c__out; t.F_pool = c__pool; t.F_goroot_forms = c__goroot_forms; t.F_nm = c__nm }
//line :605:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000449_A) Invoke_O_O__O(self, j__1 any) any {
	var tmp1 jrt.ExecutorService = jrt.ExecutorService_Cast(t.F_pool); var tmp2 any = A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_A_New_O_O_O_O(j__1, t.F_out, t.F_goroot_forms, t.F_nm); var tmp3 *jrt.Class; var fncls__3660 *jrt.Class = A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_A_fn_class
	if fncls__3660 == nil { var fncls__3660d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_170, false); A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_A_fn_class = fncls__3660d; tmp3 = fncls__3660d } else { tmp3 = fncls__3660 }
//line :606:1
	return tmp1.Submit_Callable__Future(jrt.Callable_Cast(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).WithMeta_IPersistentMap__IObj(lang.IPersistentMap_Cast(A_arbace_repr_go_parse_A_const_347)))) }
func A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :607:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_A) Ctor_O_O_O_O(c__j, c__out, c__goroot_forms, c__nm any) { t.F_j = c__j; t.F_out = c__out; t.F_goroot_forms = c__goroot_forms; t.F_nm = c__nm }
//line :607:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_A) Invoke_O__O(self any) any { var root_3646 any = A_arbace_repr_go_parse_A_const_330.GetRawRoot__O(); var linked_3647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3646, A_arbace_repr_go_parse_check_job_A_fn_class); var ifn_3648 lang.IFn; if linked_3647 == nil { ifn_3648 = lang.IFn_Cast(root_3646) } else { ifn_3648 = nil }; var arg_3649 any = t.F_goroot_forms; var arg_3650 any = t.F_j; var arg_3651 any; var arg_3652 any; if
													jrt.J2g_Truth(t.F_out) { var tmp1 any = A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_fn__1050000451_A_New_O_O_O(t.F_j, t.F_out, t.F_nm); var tmp2 *jrt.Class; var fncls__3659 *jrt.Class = A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_fn__1050000451_A_fn_class; if fncls__3659 == nil { var fncls__3659d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_171, false); A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_fn__1050000451_A_fn_class = fncls__3659d; tmp2 = fncls__3659d } else { tmp2 = fncls__3659 }; arg_3652 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) } else { arg_3652 = nil }; if /*line :607:1*/ linked_3647 == nil { return ifn_3648.Invoke_O_O_O_O__O(arg_3649, arg_3650, arg_3651, arg_3652) } else { return linked_3647.(*A_arbace_repr_go_parse_check_job_A).Invoke_O_O_O_O_O__O(root_3646, arg_3649, arg_3650, arg_3651, arg_3652) } }
func A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_fn__1050000451_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_fn__1050000451_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_fn__1050000451_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :608:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_fn__1050000451_A) Ctor_O_O_O(c__j, c__out, c__nm any) { t.F_j = c__j; t.F_out = c__out; t.F_nm = c__nm }
//line :608:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_fn__1050000451_A) Invoke_O_O__O(self, p1__1050000439_SHARP___1 any) any { var root_3653 any = A_arbace_repr_go_parse_A_const_331.GetRawRoot__O(); var linked_3654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3653, A_arbace_repr_go_parse_write_native_BANG__A_fn_class); var ifn_3655 lang.IFn; if linked_3654 == nil { ifn_3655 = lang.IFn_Cast(root_3653) } else { ifn_3655 = nil }; var arg_3656 any = p1__1050000439_SHARP___1; var arg_3657 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_72, nil), jrt.RefArrayOf(jrt.Object_class, t.F_out, nil, t.F_nm)).Ref(); var arg_3658 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_73), jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_parse_A_const_78.Invoke_O__O(t.F_j), nil)).Ref(); if linked_3654 == nil { return ifn_3655.Invoke_O_O_O__O(arg_3656, arg_3657, arg_3658) } else { return linked_3654.(*A_arbace_repr_go_parse_write_native_BANG__A).Invoke_O_O_O_O__O(root_3653, arg_3656, arg_3657, arg_3658) } }

func A_arbace_repr_go_parse_read_corpus_fn__1050000455_A_New() *A_arbace_repr_go_parse_read_corpus_fn__1050000455_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_read_corpus_fn__1050000455_A{}; t.Ctor(); return t }
//line :610:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000455_A) Ctor() {}
//line :610:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000455_A) Invoke_O_O__O(self, p1__1050000440_SHARP___1 any) any { return jrt.Future_Cast(p1__1050000440_SHARP___1).Get__O() }

func A_arbace_repr_go_parse_read_corpus_sum__1050000457_A_New_O(p0 any) *A_arbace_repr_go_parse_read_corpus_sum__1050000457_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_read_corpus_sum__1050000457_A{}; t.Ctor_O(p0); return t }
//line :612:1
func (t *A_arbace_repr_go_parse_read_corpus_sum__1050000457_A) Ctor_O(c__ok any) { t.F_ok = c__ok }
//line :612:1
func (t *A_arbace_repr_go_parse_read_corpus_sum__1050000457_A) Invoke_O_O__O(self, k__1 any) any { var root_3673 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_3674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3673, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_3675 lang.IFn; if linked_3674 == nil { ifn_3675 = lang.IFn_Cast(root_3673) } else { ifn_3675 = nil }; var arg_3676 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_3677 any; var root_3678 any = A_arbace_repr_go_parse_A_const_279.GetRawRoot__O(); var linked_3679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3678, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_3680 lang.IFn; if linked_3679 == nil { ifn_3680 = lang.IFn_Cast(root_3678) } else { ifn_3680 = nil }; var arg_3681 any; var tmp1 any = A_arbace_repr_go_parse_read_corpus_sum__1050000457_fn__1050000458_A_New_O(k__1); var tmp2 *jrt.Class; var fncls__3688 *jrt.Class = A_arbace_repr_go_parse_read_corpus_sum__1050000457_fn__1050000458_A_fn_class; if fncls__3688 == nil { var fncls__3688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_173, false); A_arbace_repr_go_parse_read_corpus_sum__1050000457_fn__1050000458_A_fn_class = fncls__3688d; tmp2 = fncls__3688d } else { tmp2 = fncls__3688 }; arg_3681 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_3682 any = t.F_ok; if linked_3679 == nil { arg_3677 = ifn_3680.Invoke_O_O__O(arg_3681, arg_3682) } else { arg_3677 = linked_3679.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_3678, arg_3681, arg_3682) }; if linked_3674 == nil { return ifn_3675.Invoke_O_O__O(arg_3676, arg_3677) } else { return linked_3674.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_3673, arg_3676, arg_3677) } }
//line :612:1
func A_arbace_repr_go_parse_read_corpus_sum__1050000457_fn__1050000458_A_New_O(p0 any) *A_arbace_repr_go_parse_read_corpus_sum__1050000457_fn__1050000458_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_read_corpus_sum__1050000457_fn__1050000458_A{}; t.Ctor_O(p0); return t }
//line :612:1
func (t *A_arbace_repr_go_parse_read_corpus_sum__1050000457_fn__1050000458_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :612:1
func (t *A_arbace_repr_go_parse_read_corpus_sum__1050000457_fn__1050000458_A) Invoke_O_O__O(self, p1__1050000441_SHARP___1 any) any { var root_3683 any = A_arbace_repr_go_parse_A_const_247.GetRawRoot__O(); var linked_3684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3683, aot_arbace_core.A_arbace_core_get_in_A_fn_class); var ifn_3685 lang.IFn; if linked_3684 == nil { ifn_3685 = lang.IFn_Cast(root_3683) } else { ifn_3685 = nil }; var arg_3686 any = p1__1050000441_SHARP___1; var arg_3687 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_repr_go_parse_A_const_256, t.F_k); if linked_3684 == nil { return ifn_3685.Invoke_O_O__O(arg_3686, arg_3687) } else { return linked_3684.(*aot_arbace_core.A_arbace_core_get_in_A).Invoke_O_O_O__O(root_3683, arg_3686, arg_3687) } }
func A_arbace_repr_go_parse_read_corpus_fn__1050000465_A_New() *A_arbace_repr_go_parse_read_corpus_fn__1050000465_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_read_corpus_fn__1050000465_A{}; t.Ctor(); return t }
//line :613:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000465_A) Ctor() {}
//line :613:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000465_A) Invoke_O_O__O(self, p1__1050000442_SHARP___1 any) any { var or__1927000174__auto____2 any = A_arbace_repr_go_parse_A_const_294.Invoke_O__O(p1__1050000442_SHARP___1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return A_arbace_repr_go_parse_A_const_293.Invoke_O__O(p1__1050000442_SHARP___1) } }



func A_arbace_repr_go_parse_read_corpus_fn__1050000471_A_New() *A_arbace_repr_go_parse_read_corpus_fn__1050000471_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_read_corpus_fn__1050000471_A{}; t.Ctor(); return t }
//line :617:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000471_A) Ctor() {}
//line :617:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000471_A) Invoke_O_O__O(self, p1__1050000443_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_172, A_arbace_repr_go_parse_A_const_316.Invoke_O__O(p1__1050000443_SHARP___1))).Ref() }
func A_arbace_repr_go_parse_read_corpus_fn__1050000473_A_New() *A_arbace_repr_go_parse_read_corpus_fn__1050000473_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_read_corpus_fn__1050000473_A{}; t.Ctor(); return t }
//line :618:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000473_A) Ctor() {}
//line :618:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000473_A) Invoke_O_O__O(self, p1__1050000444_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_74, A_arbace_repr_go_parse_A_const_316.Invoke_O__O(p1__1050000444_SHARP___1))).Ref() }



func A_arbace_repr_go_parse_read_corpus_fn__1050000475_A_New() *A_arbace_repr_go_parse_read_corpus_fn__1050000475_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_read_corpus_fn__1050000475_A{}; t.Ctor(); return t }
//line :622:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000475_A) Ctor() {}
//line :622:1
func (t *A_arbace_repr_go_parse_read_corpus_fn__1050000475_A) Invoke_O_O__O(self, p1__1050000445_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_74, A_arbace_repr_go_parse_A_const_316.Invoke_O__O(p1__1050000445_SHARP___1))).Ref() }

func A_arbace_repr_go_parse__main_A_New() *A_arbace_repr_go_parse__main_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse__main_A{}; t.Ctor(); return t }
//line :624:1
func (t *A_arbace_repr_go_parse__main_A) Ctor() {}
//line :624:1
func (t *A_arbace_repr_go_parse__main_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1050000479__2 any = args__0; var seq__1050000480__3 any; var root_3852 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3852, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3854 lang.IFn; if














	linked_3853 == nil { ifn_3854 = lang.IFn_Cast(root_3852) } else { ifn_3854 = nil }; var arg_3855 any = vec__1050000479__2; if linked_3853 == nil { seq__1050000480__3 = ifn_3854.Invoke_O__O(arg_3855) } else { seq__1050000480__3 = linked_3853.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3852, arg_3855) }; var first__1050000481__4 any; var root_3856 any = /*line :624:1*/A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3856, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3858 lang.IFn; if














	linked_3857 == nil { ifn_3858 = lang.IFn_Cast(root_3856) } else { ifn_3858 = nil }; var arg_3859 any = seq__1050000480__3; if linked_3857 == nil { first__1050000481__4 = ifn_3858.Invoke_O__O(arg_3859) } else { first__1050000481__4 = linked_3857.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3856, arg_3859) }; var seq__1050000480__5 any; var root_3860 any = /*line :624:1*/A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_3861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3860, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3862 lang.IFn; if














	linked_3861 == nil { ifn_3862 = lang.IFn_Cast(root_3860) } else { ifn_3862 = nil }; var arg_3863 any = seq__1050000480__3; if linked_3861 == nil { seq__1050000480__5 = ifn_3862.Invoke_O__O(arg_3863) } else { seq__1050000480__5 = linked_3861.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3860, arg_3863) }; var cmd__6 any = first__1050000481__4; var args__7 any = seq__1050000480__5; var ___8 any; _ = ___8; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_parse_A_const_348).Invoke_O__O(cmd__6)) { ___8 = nil } else {
		var root_4200 any = A_arbace_repr_go_parse_A_const_305.GetRawRoot__O(); var linked_4201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4200, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4202 lang.IFn; if linked_4201 == nil { ifn_4202 = lang.IFn_Cast(root_4200) } else { ifn_4202 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_240.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_parse_A_const_360; var arg_4203 any = tmp1.Invoke_O_O__O(tmp2, A_arbace_repr_go_parse_A_const_361.Get__O()); if linked_4201 == nil { ifn_4202.Invoke_O__O(arg_4203) } else { linked_4201.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4200, arg_4203) }; var tmp3 any = A_arbace_repr_go_parse__main_fn__1050000487_A_New(); var tmp4 *jrt.Class; var fncls__4199 *jrt.Class = A_arbace_repr_go_parse__main_fn__1050000487_A_fn_class; if fncls__4199 == nil { var fncls__4199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_repr_go_parse__main_fn__1050000487_A_fn_class = fncls__4199d; tmp4 = fncls__4199d } else { tmp4 = fncls__4199 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
		jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)); ___8 = nil }; var vec__1050000482__9 any; var opts__9 any = A_arbace_repr_go_parse_A_const_349; var G__1050000492__10_ any = args__7; var vec__1050000493__11 any = G__1050000492__10_; var seq__1050000494__12 any; var root_3864 any = /*line :624:1*/A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3864, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3866 lang.IFn; if


















	linked_3865 == nil { ifn_3866 = lang.IFn_Cast(root_3864) } else { ifn_3866 = nil }; var arg_3867 any = vec__1050000493__11; if linked_3865 == nil { seq__1050000494__12 = ifn_3866.Invoke_O__O(arg_3867) } else { seq__1050000494__12 = linked_3865.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3864, arg_3867) }; var first__1050000495__13 any; var root_3868 any = /*line :624:1*/A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3868, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3870 lang.IFn; if


















	linked_3869 == nil { ifn_3870 = lang.IFn_Cast(root_3868) } else { ifn_3870 = nil }; var arg_3871 any = seq__1050000494__12; if linked_3869 == nil { first__1050000495__13 = ifn_3870.Invoke_O__O(arg_3871) } else { first__1050000495__13 = linked_3869.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3868, arg_3871) }; var seq__1050000494__14 any; var root_3872 any = /*line :624:1*/A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_3873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3872, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3874 lang.IFn; if


















	linked_3873 == nil { ifn_3874 = lang.IFn_Cast(root_3872) } else { ifn_3874 = nil }; var arg_3875 any = seq__1050000494__12; if linked_3873 == nil { seq__1050000494__14 = ifn_3874.Invoke_O__O(arg_3875) } else { seq__1050000494__14 = linked_3873.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3872, arg_3875) }; var a__15 any = first__1050000495__13; var more__16 any = seq__1050000494__14; var args__17 any = vec__1050000493__11; var tmp5 any = /*line :624:1*/A_arbace_repr_go_parse__main_fn__1050000496_A_New_O_O(G__1050000492__10_, opts__9); var tmp6 *jrt.Class; var fncls__3969 *jrt.Class = A_arbace_repr_go_parse__main_fn__1050000496_A_fn_class; _ = a__15; _ = more__16; _ = args__17; if


















	fncls__3969 == nil { var fncls__3969d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_repr_go_parse__main_fn__1050000496_A_fn_class = fncls__3969d; tmp6 = fncls__3969d } else { tmp6 = fncls__3969 }; vec__1050000482__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); var opts__10 any = /*line :624:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1050000482__9, lang.RT_IntCast_J__I_NoInit(0), nil); var specs__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000482__9, lang.RT_IntCast_J__I_NoInit(1), nil); var known__12 any; var temp__1927000414__auto____12 any = A_arbace_repr_go_parse_A_const_352.Invoke_O__O(opts__10); if




























	jrt.J2g_Truth(temp__1927000414__auto____12) { var k__13 any = temp__1927000414__auto____12
		if jrt.File_New_String(jrt.String_Cast(k__13)).IsFile__Z() {
			var root_4209 any = A_arbace_repr_go_parse_A_const_305.GetRawRoot__O(); var linked_4210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4209, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4211 lang.IFn; if linked_4210 == nil { ifn_4211 = lang.IFn_Cast(root_4209) } else { ifn_4211 = nil }; var arg_4212 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_240.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_310, jrt.Boolean_FALSE.Ref()); if linked_4210 == nil { ifn_4211.Invoke_O__O(arg_4212) } else { linked_4210.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4209, arg_4212) }; var tmp7 any = A_arbace_repr_go_parse__main_fn__1050000502_A_New_O(k__13); var tmp8 *jrt.Class; var fncls__3981 *jrt.Class = A_arbace_repr_go_parse__main_fn__1050000502_A_fn_class; if fncls__3981 == nil { var fncls__3981d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_repr_go_parse__main_fn__1050000502_A_fn_class = fncls__3981d; tmp8 = fncls__3981d } else { tmp8 = fncls__3981 }; known__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O() } else {
//line :654:1
				known__12 = nil } } else {
//line :653:1
					known__12 = nil }; var map__1050000485__13 any; if


	jrt.J2g_Truth(A_arbace_repr_go_parse_A_const_353.Invoke_O__O(opts__10)) { map__1050000485__13 = A_arbace_repr_go_parse_A_const_355 } else { var root_3982 any = A_arbace_repr_go_parse_A_const_225.GetRawRoot__O(); var linked_3983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3982, A_arbace_repr_go_parse_load_BANG__A_fn_class); var ifn_3984 lang.IFn; if linked_3983 == nil { ifn_3984 = lang.IFn_Cast(root_3982) } else { ifn_3984 = nil }; var arg_3985 any = A_arbace_repr_go_parse_A_const_354.Invoke_O__O(opts__10); if linked_3983 == nil { map__1050000485__13 = ifn_3984.Invoke_O__O(arg_3985) } else { map__1050000485__13 = linked_3983.(*A_arbace_repr_go_parse_load_BANG__A).Invoke_O_O__O(root_3982, arg_3985) } }; var map__1050000485__14 any; if /*line :639:1*/ lang.ISeq_InstanceOf(map__1050000485__13) { var tmp9 any; var root_3986 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_3987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3986, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3988 lang.IFn; if linked_3987 == nil { ifn_3988 = lang.IFn_Cast(root_3986) } else { ifn_3988 = nil }; var arg_3989 any = map__1050000485__13; if linked_3987 == nil { tmp9 = ifn_3988.Invoke_O__O(arg_3989) } else { tmp9 = linked_3987.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3986, arg_3989) }; if jrt.J2g_Truth(tmp9) { var tmp10 any; var root_3990 any = A_arbace_repr_go_parse_A_const_83.GetRawRoot__O(); var linked_3991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3990, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_3992 lang.IFn; if linked_3991 == nil { ifn_3992 = lang.IFn_Cast(root_3990) } else { ifn_3992 = nil }; var arg_3993 any = map__1050000485__13; if linked_3991 == nil { tmp10 = ifn_3992.Invoke_O__O(arg_3993) } else { tmp10 = linked_3991.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_3990, arg_3993) }; map__1050000485__14 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp10, jrt.Object_class.ArrayClass())).Ref() } else { var tmp11 any; var root_3994 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3994, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3996 lang.IFn; if linked_3995 == nil { ifn_3996 = lang.IFn_Cast(root_3994) } else { ifn_3996 = nil }; var arg_3997 any = map__1050000485__13; if linked_3995 == nil { tmp11 = ifn_3996.Invoke_O__O(arg_3997) } else { tmp11 = linked_3995.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3994, arg_3997) }; if jrt.J2g_Truth(tmp11) { var root_3998 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3998, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4000 lang.IFn; if linked_3999 == nil { ifn_4000 = lang.IFn_Cast(root_3998) } else { ifn_4000 = nil }; var arg_4001 any = map__1050000485__13; if linked_3999 == nil { map__1050000485__14 = ifn_4000.Invoke_O__O(arg_4001) } else { map__1050000485__14 = linked_3999.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3998, arg_4001) } } else { map__1050000485__14 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1050000485__14 = map__1050000485__13 }; var ms__15 any = /*line :624:1*/lang.RT_Get_O_O__O_NoInit(map__1050000485__14, A_arbace_repr_go_parse_A_const_216); var ___16 any; _ = ___16; if
































	jrt.J2g_Truth(A_arbace_repr_go_parse_A_const_353.Invoke_O__O(opts__10)) { ___16 = nil } else {
		___16 = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_parse_A_const_346.GetRawRoot__O()).Invoke_O_O__O(Lit_4, jrt.Double_ValueOf_D__Double_NoInit(lang.Numbers_Divide_O_D__D_NoInit(ms__15, 1000.0)).Ref())) }; var fc__17 any; if
	jrt.J2g_Truth(A_arbace_repr_go_parse_A_const_353.Invoke_O__O(opts__10)) { fc__17 = lang.PersistentVector_EMPTY.Ref() } else { var root_4011 any = A_arbace_repr_go_parse_A_const_356.GetRawRoot__O(); var linked_4012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4011, A_arbace_repr_go_parse_forms_check_A_fn_class); var ifn_4013 lang.IFn; if linked_4012 == nil { ifn_4013 = lang.IFn_Cast(root_4011) } else { ifn_4013 = nil }; var arg_4014 any = A_arbace_repr_go_parse_A_const_354.Invoke_O__O(opts__10); if linked_4012 == nil { fc__17 = ifn_4013.Invoke_O__O(arg_4014) } else { fc__17 = linked_4012.(*A_arbace_repr_go_parse_forms_check_A).Invoke_O_O__O(root_4011, arg_4014) } }; var ___18 any; var tmp12 any = /*line :624:1*/A_arbace_repr_go_parse__main_fn__1050000508_A_New_O(fc__17); var tmp13 *jrt.Class; var fncls__4065 *jrt.Class = A_arbace_repr_go_parse__main_fn__1050000508_A_fn_class; _ = ___18; if



































	fncls__4065 == nil { var fncls__4065d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_repr_go_parse__main_fn__1050000508_A_fn_class = fncls__4065d; tmp13 = fncls__4065d } else { tmp13 = fncls__4065 }; ___18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil).Invoke__O(); var forms_bad__19 int32; var tmp14 any; var root_4066 any = /*line :624:1*/A_arbace_repr_go_parse_A_const_20.GetRawRoot__O(); var linked_4067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4066, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_4068 lang.IFn; if





































	linked_4067 == nil { ifn_4068 = lang.IFn_Cast(root_4066) } else { ifn_4068 = nil }; var arg_4069 any; var tmp15 any = A_arbace_repr_go_parse__main_fn__1050000516_A_New(); var tmp16 *jrt.Class; var fncls__4071 *jrt.Class = A_arbace_repr_go_parse__main_fn__1050000516_A_fn_class; if fncls__4071 == nil { var fncls__4071d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_repr_go_parse__main_fn__1050000516_A_fn_class = fncls__4071d; tmp16 = fncls__4071d } else { tmp16 = fncls__4071 }; arg_4069 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var arg_4070 any = fc__17; if linked_4067 == nil { tmp14 = ifn_4068.Invoke_O_O__O(arg_4069, arg_4070) } else { tmp14 = linked_4067.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_4066, arg_4069, arg_4070) }; forms_bad__19 = lang.RT_Count_O__I_NoInit(tmp14); var pool__20 any = /*line :624:1*/jrt.Executors_NewFixedThreadPool_I__ExecutorService(lang.RT_IntCast_O__I_NoInit(A_arbace_repr_go_parse_A_const_336.Invoke_O__O(opts__10))); var results__21 any; var root_4072 any = A_arbace_repr_go_parse_A_const_71.GetRawRoot__O(); var linked_4073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4072, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_4074 lang.IFn; if







































	linked_4073 == nil { ifn_4074 = lang.IFn_Cast(root_4072) } else { ifn_4074 = nil }; var arg_4075 any; var iter__1927001039__auto____21 any; var tmp17 any = A_arbace_repr_go_parse__main_iter__1050000518__1050000522_A_New_O_O_O_O(pool__20, cmd__6, opts__10, known__12); var tmp18 *jrt.Class; var fncls__4174 *jrt.Class = A_arbace_repr_go_parse__main_iter__1050000518__1050000522_A_fn_class; if fncls__4174 == nil { var fncls__4174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_repr_go_parse__main_iter__1050000518__1050000522_A_fn_class = fncls__4174d; tmp18 = fncls__4174d } else { tmp18 = fncls__4174 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); arg_4075 = lang.IFn_Cast(iter__1927001039__auto____21).Invoke_O__O(specs__11); if linked_4073 == nil { results__21 = ifn_4074.Invoke_O__O(arg_4075) } else { results__21 = linked_4073.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_4072, arg_4075) }; var unknown__22 any; var na_4175 int64 = /*line :624:1*/int64(forms_bad__19); var na_4176 any; var root_4177 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_4178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4177, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_4179 lang.IFn; if












































	linked_4178 == nil { ifn_4179 = lang.IFn_Cast(root_4177) } else { ifn_4179 = nil }; var arg_4180 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_4181 any; var root_4182 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_4183 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4182, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_4184 lang.IFn; if linked_4183 == nil { ifn_4184 = lang.IFn_Cast(root_4182) } else { ifn_4184 = nil }; var arg_4185 any = A_arbace_repr_go_parse_A_const_69; var arg_4186 any = results__21; if linked_4183 == nil { arg_4181 = ifn_4184.Invoke_O_O__O(arg_4185, arg_4186) } else { arg_4181 = linked_4183.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_4182, arg_4185, arg_4186) }; if linked_4178 == nil { na_4176 = ifn_4179.Invoke_O_O__O(arg_4180, arg_4181) } else { na_4176 = linked_4178.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_4177, arg_4180, arg_4181) }; if jrt.Long_InstanceOf(na_4176) { var n0_4187 int64 = na_4175; var n1_4188 int64 = jrt.NN(jrt.Long_Cast(na_4176)).LongValue__J(); var nr_4189 int64 = n0_4187 + n1_4188; if (n0_4187^nr_4189)&(n1_4188^nr_4189) >= 0 { unknown__22 = jrt.Long_ValueOf_J__Long_NoInit(nr_4189).Ref() } else { unknown__22 = lang.Numbers_Add_J_O__Number_NoInit(na_4175, na_4176) } } else { unknown__22 = lang.Numbers_Add_J_O__Number_NoInit(na_4175, na_4176) };
	jrt.ExecutorService_Cast(pool__20).Shutdown__V();
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.ExecutorService_Cast(pool__20).AwaitTermination_J_TimeUnit__Z(1, jrt.TimeUnit_MINUTES)); var tmp19 bool; var and__1927000168__auto____23 bool =
	lang.Util_Equiv_O_O__Z_NoInit(cmd__6, Lit_8); if and__1927000168__auto____23 { tmp19 = lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(results__21)), 1) } else { tmp19 = and__1927000168__auto____23 }; if tmp19 {
		var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_346.GetRawRoot__O()); var tmp22 *jrt.String; if jrt.J2g_Truth(A_arbace_repr_go_parse_A_const_353.Invoke_O__O(opts__10)) { tmp22 = Lit_9 } else { tmp22 = Lit_10 }; var tmp23 any = tmp22.Ref(); var tmp24 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(results__21)).Ref(); var tmp25 any; var root_4232 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_4233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4232, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_4234 lang.IFn


		if linked_4233 == nil { ifn_4234 = lang.IFn_Cast(root_4232) } else { ifn_4234 = nil }; var arg_4235 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_4236 any; var root_4237 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_4238 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4237, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_4239 lang.IFn; if linked_4238 == nil { ifn_4239 = lang.IFn_Cast(root_4237) } else { ifn_4239 = nil }; var arg_4240 any = A_arbace_repr_go_parse_A_const_338; var arg_4241 any = results__21; if linked_4238 == nil { arg_4236 = ifn_4239.Invoke_O_O__O(arg_4240, arg_4241) } else { arg_4236 = linked_4238.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_4237, arg_4240, arg_4241) }; if linked_4233 == nil { tmp25 = ifn_4234.Invoke_O_O__O(arg_4235, arg_4236) } else { tmp25 = linked_4233.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_4232, arg_4235, arg_4236) }
//line :673:1
		var tmp26 any = tmp25; var tmp27 any; var root_4242 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_4243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4242, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_4244 lang.IFn


		if linked_4243 == nil { ifn_4244 = lang.IFn_Cast(root_4242) } else { ifn_4244 = nil }; var arg_4245 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_4246 any; var root_4247 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_4248 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4247, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_4249 lang.IFn; if linked_4248 == nil { ifn_4249 = lang.IFn_Cast(root_4247) } else { ifn_4249 = nil }; var arg_4250 any = A_arbace_repr_go_parse_A_const_322; var arg_4251 any = results__21; if linked_4248 == nil { arg_4246 = ifn_4249.Invoke_O_O__O(arg_4250, arg_4251) } else { arg_4246 = linked_4248.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_4247, arg_4250, arg_4251) }; if linked_4243 == nil { tmp27 = ifn_4244.Invoke_O_O__O(arg_4245, arg_4246) } else { tmp27 = linked_4243.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_4242, arg_4245, arg_4246) }
//line :673:1
		var tmp28 any = tmp27; var tmp29 any; var root_4252 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_4253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4252, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_4254 lang.IFn



		if linked_4253 == nil { ifn_4254 = lang.IFn_Cast(root_4252) } else { ifn_4254 = nil }; var arg_4255 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_4256 any; var root_4257 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_4258 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4257, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_4259 lang.IFn; if linked_4258 == nil { ifn_4259 = lang.IFn_Cast(root_4257) } else { ifn_4259 = nil }; var arg_4260 any = A_arbace_repr_go_parse_A_const_189; var arg_4261 any = results__21; if linked_4258 == nil { arg_4256 = ifn_4259.Invoke_O_O__O(arg_4260, arg_4261) } else { arg_4256 = linked_4258.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_4257, arg_4260, arg_4261) }; if linked_4253 == nil { tmp29 = ifn_4254.Invoke_O_O__O(arg_4255, arg_4256) } else { tmp29 = linked_4253.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_4252, arg_4255, arg_4256) }
//line :673:1
		var tmp30 any = tmp29; var tmp31 any



		if jrt.J2g_Truth(A_arbace_repr_go_parse_A_const_353.Invoke_O__O(opts__10)) { tmp31 = Lit_11 } else { var root_4262 any = A_arbace_repr_go_parse_A_const_257.GetRawRoot__O(); var linked_4263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4262, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_4264 lang.IFn; if linked_4263 == nil { ifn_4264 = lang.IFn_Cast(root_4262) } else { ifn_4264 = nil }; var arg_4265 any = A_arbace_repr_go_parse_A_const_258.GetRawRoot__O(); var arg_4266 any; var root_4267 any = A_arbace_repr_go_parse_A_const_158.GetRawRoot__O(); var linked_4268 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4267, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_4269 lang.IFn; if linked_4268 == nil { ifn_4269 = lang.IFn_Cast(root_4267) } else { ifn_4269 = nil }; var arg_4270 any = A_arbace_repr_go_parse_A_const_66; var arg_4271 any = results__21; if linked_4268 == nil { arg_4266 = ifn_4269.Invoke_O_O__O(arg_4270, arg_4271) } else { arg_4266 = linked_4268.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_4267, arg_4270, arg_4271) }; if linked_4263 == nil { tmp31 = ifn_4264.Invoke_O_O__O(arg_4265, arg_4266) } else { tmp31 = linked_4263.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O__O(root_4262, arg_4265, arg_4266) } }
//line :673:1
		tmp20.Invoke_O__O(tmp21.Invoke_O_O_O_O_O_O_O__O(tmp23, tmp24, tmp26, tmp28, tmp30, tmp31, unknown__22)) }; var temp__1927000414__auto____23 any = /*line :624:1*/A_arbace_repr_go_parse_A_const_351.Invoke_O__O(opts__10); if





















































	jrt.J2g_Truth(temp__1927000414__auto____23) { var rf__24 any = temp__1927000414__auto____23; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_303.GetRawRoot__O()); var tmp33 any; var s__1927001093__auto____25 any = jrt.StringWriter_New(); var root_4302 any = A_arbace_repr_go_parse_A_const_305.GetRawRoot__O(); var linked_4303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4302, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4304 lang.IFn
		if linked_4303 == nil { ifn_4304 = lang.IFn_Cast(root_4302) } else { ifn_4304 = nil }; var arg_4305 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_240.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_360, s__1927001093__auto____25); if linked_4303 == nil { ifn_4304.Invoke_O__O(arg_4305) } else { linked_4303.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4302, arg_4305) }; var tmp34 any = A_arbace_repr_go_parse__main_fn__1050000528_A_New_O_O_O(results__21, fc__17, s__1927001093__auto____25); var tmp35 *jrt.Class; var fncls__4301 *jrt.Class = A_arbace_repr_go_parse__main_fn__1050000528_A_fn_class; if fncls__4301 == nil { var fncls__4301d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_repr_go_parse__main_fn__1050000528_A_fn_class = fncls__4301d; tmp35 = fncls__4301d } else { tmp35 = fncls__4301 }; tmp33 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil).Invoke__O(); tmp32.Invoke_O_O__O(rf__24, tmp33) }; var root_4311 any =
	A_arbace_repr_go_parse_A_const_364.GetRawRoot__O(); var linked_4312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4311, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_4313 lang.IFn; if linked_4312 == nil { ifn_4313 = lang.IFn_Cast(root_4311) } else { ifn_4313 = nil }; if linked_4312 == nil { ifn_4313.Invoke__O() } else { linked_4312.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_4311) }; var tmp36 int64; var tmp37 bool; var na_4190 any = unknown__22; if
	jrt.Long_InstanceOf(na_4190) { var n0_4191 int64 = jrt.NN(jrt.Long_Cast(na_4190)).LongValue__J(); tmp37 = n0_4191 > 0 } else { if jrt.Double_InstanceOf(na_4190) { var n0_4191_2 float64 = jrt.NN(jrt.Double_Cast(na_4190)).DoubleValue__D(); tmp37 = n0_4191_2 > 0.0 } else { tmp37 = lang.Numbers_IsPos_O__Z_NoInit(na_4190) } }; if tmp37 { tmp36 = 1 } else { tmp36 = 0 }; jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(tmp36)); return nil }
//line :641:1
func A_arbace_repr_go_parse__main_fn__1050000487_A_New() *A_arbace_repr_go_parse__main_fn__1050000487_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse__main_fn__1050000487_A{}; t.Ctor(); return t }
//line :641:1
func (t *A_arbace_repr_go_parse__main_fn__1050000487_A) Ctor() {}
//line :641:1
func (t *A_arbace_repr_go_parse__main_fn__1050000487_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()).Invoke_O__O(Lit_13); return nil }(); var root_4196 any = A_arbace_repr_go_parse_A_const_304.GetRawRoot__O(); var linked_4197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4196, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4198 lang.IFn; if linked_4197 == nil { ifn_4198 = lang.IFn_Cast(root_4196) } else { ifn_4198 = nil }; if linked_4197 == nil { ifn_4198.Invoke__O() } else { linked_4197.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4196) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }

func A_arbace_repr_go_parse__main_fn__1050000496_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse__main_fn__1050000496_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse__main_fn__1050000496_A{}; t.Ctor_O_O(p0, p1); return t }
//line :643:1
func (t *A_arbace_repr_go_parse__main_fn__1050000496_A) Ctor_O_O(c__G__1050000492, c__opts any) { t.F_G__1050000492 = c__G__1050000492; t.F_opts = c__opts }
//line :643:1
func (t *A_arbace_repr_go_parse__main_fn__1050000496_A) Invoke_O__O(self any) any { { var opts__1 any; var t_ any = t.F_opts; t.F_opts = nil; opts__1 = t_; var G__1050000492__2_ any; var t__2 any = t.F_G__1050000492; t.F_G__1050000492 = nil; G__1050000492__2_ = t__2; L1: for { var opts__3 any = opts__1; var vec__1050000497__4 any = G__1050000492__2_; var seq__1050000498__5 any; var root_3876 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_3877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3876, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3878 lang.IFn; if linked_3877 == nil { ifn_3878 = lang.IFn_Cast(root_3876) } else { ifn_3878 = nil }; var arg_3879 any = vec__1050000497__4; if linked_3877 == nil { seq__1050000498__5 = ifn_3878.Invoke_O__O(arg_3879) } else { seq__1050000498__5 = linked_3877.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3876, arg_3879) }; var first__1050000499__6 any; var root_3880 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3880, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3882 lang.IFn; if linked_3881 == nil { ifn_3882 = lang.IFn_Cast(root_3880) } else { ifn_3882 = nil }; var arg_3883 any = seq__1050000498__5; if linked_3881 == nil { first__1050000499__6 = ifn_3882.Invoke_O__O(arg_3883) } else { first__1050000499__6 = linked_3881.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3880, arg_3883) }; var seq__1050000498__7 any; var root_3884 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_3885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3884, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_3886 lang.IFn; if linked_3885 == nil { ifn_3886 = lang.IFn_Cast(root_3884) } else { ifn_3886 = nil }; var arg_3887 any = seq__1050000498__5; if linked_3885 == nil { seq__1050000498__7 = ifn_3886.Invoke_O__O(arg_3887) } else { seq__1050000498__7 = linked_3885.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_3884, arg_3887) }; var a__8 any = first__1050000499__6
											var more__9 any = seq__1050000498__7; var args__10 any = vec__1050000497__4; var G__1050000500__11_ any = a__8
											switch lang.Util_Hash_O__I_NoInit(G__1050000500__11_) >> 16 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1050000500__11_, Lit_14) {





		var tmp1 any; var root_3889 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_3890 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3889, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3891 lang.IFn; if linked_3890 == nil { ifn_3891 = lang.IFn_Cast(root_3889) } else { ifn_3891 = nil }; var arg_3892 any = opts__3; var arg_3893 any = A_arbace_repr_go_parse_A_const_350; var arg_3894 any; var root_3895 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3895, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3897 lang.IFn; if linked_3896 == nil { ifn_3897 = lang.IFn_Cast(root_3895) } else { ifn_3897 = nil }; var arg_3898 any = more__9; if linked_3896 == nil { arg_3894 = ifn_3897.Invoke_O__O(arg_3898) } else { arg_3894 = linked_3896.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3895, arg_3898) }; if linked_3890 == nil { tmp1 = ifn_3891.Invoke_O_O_O__O(arg_3892, arg_3893, arg_3894) } else { tmp1 = linked_3890.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3889, arg_3892, arg_3893, arg_3894) }; var tmp2 any = tmp1; var tmp3 any; var root_3899 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_3900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3899, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3901 lang.IFn; if linked_3900 == nil { ifn_3901 = lang.IFn_Cast(root_3899) } else { ifn_3901 = nil }; var arg_3902 any = more__9; if linked_3900 == nil { tmp3 = ifn_3901.Invoke_O__O(arg_3902) } else { tmp3 = linked_3900.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3899, arg_3902) }; opts__1, G__1050000492__2_ = tmp2, tmp3; continue L1 }
//line :645:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1050000500__11_, Lit_15) {




		var tmp4 any; var root_3903 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_3904 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3903, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3905 lang.IFn; if linked_3904 == nil { ifn_3905 = lang.IFn_Cast(root_3903) } else { ifn_3905 = nil }; var arg_3906 any = opts__3; var arg_3907 any = A_arbace_repr_go_parse_A_const_351; var arg_3908 any; var root_3909 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3909, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3911 lang.IFn; if linked_3910 == nil { ifn_3911 = lang.IFn_Cast(root_3909) } else { ifn_3911 = nil }; var arg_3912 any = more__9; if linked_3910 == nil { arg_3908 = ifn_3911.Invoke_O__O(arg_3912) } else { arg_3908 = linked_3910.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3909, arg_3912) }; if linked_3904 == nil { tmp4 = ifn_3905.Invoke_O_O_O__O(arg_3906, arg_3907, arg_3908) } else { tmp4 = linked_3904.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3903, arg_3906, arg_3907, arg_3908) }; var tmp5 any = tmp4; var tmp6 any; var root_3913 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_3914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3913, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3915 lang.IFn; if linked_3914 == nil { ifn_3915 = lang.IFn_Cast(root_3913) } else { ifn_3915 = nil }; var arg_3916 any = more__9; if linked_3914 == nil { tmp6 = ifn_3915.Invoke_O__O(arg_3916) } else { tmp6 = linked_3914.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3913, arg_3916) }; opts__1, G__1050000492__2_ = tmp5, tmp6; continue L1 }
//line :645:1
	case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1050000500__11_, Lit_16) {



		var tmp7 any; var root_3917 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_3918 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3917, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3919 lang.IFn; if linked_3918 == nil { ifn_3919 = lang.IFn_Cast(root_3917) } else { ifn_3919 = nil }; var arg_3920 any = opts__3; var arg_3921 any = A_arbace_repr_go_parse_A_const_352; var arg_3922 any; var root_3923 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3923, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3925 lang.IFn; if linked_3924 == nil { ifn_3925 = lang.IFn_Cast(root_3923) } else { ifn_3925 = nil }; var arg_3926 any = more__9; if linked_3924 == nil { arg_3922 = ifn_3925.Invoke_O__O(arg_3926) } else { arg_3922 = linked_3924.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3923, arg_3926) }; if linked_3918 == nil { tmp7 = ifn_3919.Invoke_O_O_O__O(arg_3920, arg_3921, arg_3922) } else { tmp7 = linked_3918.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3917, arg_3920, arg_3921, arg_3922) }; var tmp8 any = tmp7; var tmp9 any; var root_3927 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_3928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3927, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3929 lang.IFn; if linked_3928 == nil { ifn_3929 = lang.IFn_Cast(root_3927) } else { ifn_3929 = nil }; var arg_3930 any = more__9; if linked_3928 == nil { tmp9 = ifn_3929.Invoke_O__O(arg_3930) } else { tmp9 = linked_3928.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3927, arg_3930) }; opts__1, G__1050000492__2_ = tmp8, tmp9; continue L1 }
//line :645:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1050000500__11_, Lit_17) {
		var tmp10 any; var root_3931 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_3932 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3931, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3933 lang.IFn; if linked_3932 == nil { ifn_3933 = lang.IFn_Cast(root_3931) } else { ifn_3933 = nil }; var arg_3934 any = opts__3; var arg_3935 any = A_arbace_repr_go_parse_A_const_353; var arg_3936 any = jrt.Boolean_TRUE.Ref(); if linked_3932 == nil { tmp10 = ifn_3933.Invoke_O_O_O__O(arg_3934, arg_3935, arg_3936) } else { tmp10 = linked_3932.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3931, arg_3934, arg_3935, arg_3936) }; opts__1, G__1050000492__2_ = tmp10, more__9; continue L1 }
//line :645:1
	case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1050000500__11_, Lit_18) {


		var tmp11 any; var root_3937 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_3938 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3937, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3939 lang.IFn; if linked_3938 == nil { ifn_3939 = lang.IFn_Cast(root_3937) } else { ifn_3939 = nil }; var arg_3940 any = opts__3; var arg_3941 any = A_arbace_repr_go_parse_A_const_354; var arg_3942 any; var root_3943 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3943, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3945 lang.IFn; if linked_3944 == nil { ifn_3945 = lang.IFn_Cast(root_3943) } else { ifn_3945 = nil }; var arg_3946 any = more__9; if linked_3944 == nil { arg_3942 = ifn_3945.Invoke_O__O(arg_3946) } else { arg_3942 = linked_3944.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3943, arg_3946) }; if linked_3938 == nil { tmp11 = ifn_3939.Invoke_O_O_O__O(arg_3940, arg_3941, arg_3942) } else { tmp11 = linked_3938.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3937, arg_3940, arg_3941, arg_3942) }; var tmp12 any = tmp11; var tmp13 any; var root_3947 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_3948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3947, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3949 lang.IFn; if linked_3948 == nil { ifn_3949 = lang.IFn_Cast(root_3947) } else { ifn_3949 = nil }; var arg_3950 any = more__9; if linked_3948 == nil { tmp13 = ifn_3949.Invoke_O__O(arg_3950) } else { tmp13 = linked_3948.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3947, arg_3950) }; opts__1, G__1050000492__2_ = tmp12, tmp13; continue L1 }
//line :645:1
	case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1050000500__11_, Lit_19) {

		var tmp14 any; var root_3951 any = A_arbace_repr_go_parse_A_const_196.GetRawRoot__O(); var linked_3952 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3951, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3953 lang.IFn; if linked_3952 == nil { ifn_3953 = lang.IFn_Cast(root_3951) } else { ifn_3953 = nil }; var arg_3954 any = opts__3; var arg_3955 any = A_arbace_repr_go_parse_A_const_336; var arg_3956 any; var root_3957 any = A_arbace_repr_go_parse_A_const_223.GetRawRoot__O(); var linked_3958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3957, aot_arbace_core.A_arbace_core_parse_long_A_fn_class); var ifn_3959 lang.IFn; if linked_3958 == nil { ifn_3959 = lang.IFn_Cast(root_3957) } else { ifn_3959 = nil }; var arg_3960 any; var root_3961 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_3962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3961, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3963 lang.IFn; if linked_3962 == nil { ifn_3963 = lang.IFn_Cast(root_3961) } else { ifn_3963 = nil }; var arg_3964 any = more__9; if linked_3962 == nil { arg_3960 = ifn_3963.Invoke_O__O(arg_3964) } else { arg_3960 = linked_3962.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3961, arg_3964) }; if linked_3958 == nil { arg_3956 = ifn_3959.Invoke_O__O(arg_3960) } else { arg_3956 = linked_3958.(*aot_arbace_core.A_arbace_core_parse_long_A).Invoke_O_O__O(root_3957, arg_3960) }; if linked_3952 == nil { tmp14 = ifn_3953.Invoke_O_O_O__O(arg_3954, arg_3955, arg_3956) } else { tmp14 = linked_3952.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3951, arg_3954, arg_3955, arg_3956) }; var tmp15 any = tmp14; var tmp16 any; var root_3965 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_3966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3965, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3967 lang.IFn; if linked_3966 == nil { ifn_3967 = lang.IFn_Cast(root_3965) } else { ifn_3967 = nil }; var arg_3968 any = more__9; if linked_3966 == nil { tmp16 = ifn_3967.Invoke_O__O(arg_3968) } else { tmp16 = linked_3966.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3965, arg_3968) }; opts__1, G__1050000492__2_ = tmp15, tmp16; continue L1 }
//line :645:1
	default:}; return lang.Tuple_Create_O_O__IPersistentVector(opts__3, args__10) } }; /*line :643:1*/panic("j2g: unreachable") }











func A_arbace_repr_go_parse__main_fn__1050000502_A_New_O(p0 any) *A_arbace_repr_go_parse__main_fn__1050000502_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse__main_fn__1050000502_A{}; t.Ctor_O(p0); return t }
//line :655:1
func (t *A_arbace_repr_go_parse__main_fn__1050000502_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :655:1
func (t *A_arbace_repr_go_parse__main_fn__1050000502_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_3970 any = A_arbace_repr_go_parse_A_const_309.GetRawRoot__O(); var linked_3971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3970, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_3972 lang.IFn; if linked_3971 == nil { ifn_3972 = lang.IFn_Cast(root_3970) } else { ifn_3972 = nil }; var arg_3973 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_15.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_k; t.F_k = nil; tmp3 = t_; arg_3973 = tmp2.Invoke_O__O(tmp3); if linked_3971 == nil { tmp1 = ifn_3972.Invoke_O__O(arg_3973) } else { tmp1 = linked_3971.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_3970, arg_3973) } }; return nil }(); var root_3978 any = A_arbace_repr_go_parse_A_const_304.GetRawRoot__O(); var linked_3979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3978, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3980 lang.IFn; if linked_3979 == nil { ifn_3980 = lang.IFn_Cast(root_3978) } else { ifn_3980 = nil }; if linked_3979 == nil { ifn_3980.Invoke__O() } else { linked_3979.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3978) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }




func A_arbace_repr_go_parse__main_fn__1050000508_A_New_O(p0 any) *A_arbace_repr_go_parse__main_fn__1050000508_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse__main_fn__1050000508_A{}; t.Ctor_O(p0); return t }
//line :660:1
func (t *A_arbace_repr_go_parse__main_fn__1050000508_A) Ctor_O(c__fc any) { t.F_fc = c__fc }
//line :660:1
func (t *A_arbace_repr_go_parse__main_fn__1050000508_A) Invoke_O__O(self any) any { { var seq_1050000504__1 any; var root_4015 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_4016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4015, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4017 lang.IFn; if linked_4016 == nil { ifn_4017 = lang.IFn_Cast(root_4015) } else { ifn_4017 = nil }; var arg_4018 any; var t_ any = t.F_fc; t.F_fc = nil; arg_4018 = t_; if linked_4016 == nil { seq_1050000504__1 = ifn_4017.Invoke_O__O(arg_4018) } else { seq_1050000504__1 = linked_4016.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4015, arg_4018) }; var chunk_1050000505__2 any; var count_1050000506__3 int64 = 0; var i_1050000507__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1050000507__4, count_1050000506__3) { var vec__1050000509__5 any = lang.Indexed_Cast(chunk_1050000505__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1050000507__4)); var p__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000509__5, lang.RT_IntCast_J__I_NoInit(0), nil); var n__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000509__5, lang.RT_IntCast_J__I_NoInit(1), nil); var eq__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000509__5, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_346.GetRawRoot__O()); var tmp3 *jrt.String
											if jrt.J2g_Truth(eq__8) { tmp3 = Lit_21 } else { tmp3 = Lit_22 }; tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O__O(Lit_20, p__6, n__7, tmp3.Ref()))
//line :660:1
	seq_1050000504__1, chunk_1050000505__2, count_1050000506__3, i_1050000507__4 = seq_1050000504__1, chunk_1050000505__2, count_1050000506__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1050000507__4); continue L1 } else { var temp__1927000414__auto____5 any; var root_4019 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_4020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4019, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4021 lang.IFn; if linked_4020 == nil { ifn_4021 = lang.IFn_Cast(root_4019) } else { ifn_4021 = nil }; var arg_4022 any = seq_1050000504__1; if linked_4020 == nil { temp__1927000414__auto____5 = ifn_4021.Invoke_O__O(arg_4022) } else { temp__1927000414__auto____5 = linked_4020.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4019, arg_4022) }; if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1050000504__6 any = temp__1927000414__auto____5; var tmp4 any; var root_4023 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_4024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4023, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4025 lang.IFn; if linked_4024 == nil { ifn_4025 = lang.IFn_Cast(root_4023) } else { ifn_4025 = nil }; var arg_4026 any = seq_1050000504__6; if linked_4024 == nil { tmp4 = ifn_4025.Invoke_O__O(arg_4026) } else { tmp4 = linked_4024.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4023, arg_4026) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____7 any; var root_4027 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_4028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4027, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4029 lang.IFn; if linked_4028 == nil { ifn_4029 = lang.IFn_Cast(root_4027) } else { ifn_4029 = nil }; var arg_4030 any = seq_1050000504__6; if linked_4028 == nil { c__1927000678__auto____7 = ifn_4029.Invoke_O__O(arg_4030) } else { c__1927000678__auto____7 = linked_4028.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4027, arg_4030) }; var tmp5 any; var root_4046 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_4047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4046, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4048 lang.IFn; if linked_4047 == nil { ifn_4048 = lang.IFn_Cast(root_4046) } else { ifn_4048 = nil }; var arg_4049 any = seq_1050000504__6; if linked_4047 == nil { tmp5 = ifn_4048.Invoke_O__O(arg_4049) } else { tmp5 = linked_4047.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4046, arg_4049) }; seq_1050000504__1, chunk_1050000505__2, count_1050000506__3, i_1050000507__4 = tmp5, c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1050000512__7 any; var root_4031 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_4032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4031, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4033 lang.IFn; if linked_4032 == nil { ifn_4033 = lang.IFn_Cast(root_4031) } else { ifn_4033 = nil }; var arg_4034 any = seq_1050000504__6; if linked_4032 == nil { vec__1050000512__7 = ifn_4033.Invoke_O__O(arg_4034) } else { vec__1050000512__7 = linked_4032.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4031, arg_4034) }; var p__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000512__7, lang.RT_IntCast_J__I_NoInit(0), nil); var n__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000512__7, lang.RT_IntCast_J__I_NoInit(1), nil); var eq__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1050000512__7, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_345.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_346.GetRawRoot__O()); var tmp8 *jrt.String
		if jrt.J2g_Truth(eq__10) { tmp8 = Lit_21 } else { tmp8 = Lit_22 }; tmp6.Invoke_O__O(tmp7.Invoke_O_O_O_O__O(Lit_20, p__8, n__9, tmp8.Ref()))
//line :660:1
		var tmp9 any; var root_4061 any = A_arbace_repr_go_parse_A_const_82.GetRawRoot__O(); var linked_4062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4061, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_4063 lang.IFn; if linked_4062 == nil { ifn_4063 = lang.IFn_Cast(root_4061) } else { ifn_4063 = nil }; var arg_4064 any = seq_1050000504__6; if linked_4062 == nil { tmp9 = ifn_4063.Invoke_O__O(arg_4064) } else { tmp9 = linked_4062.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_4061, arg_4064) }; seq_1050000504__1, chunk_1050000505__2, count_1050000506__3, i_1050000507__4 = tmp9, nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_parse__main_fn__1050000516_A_New() *A_arbace_repr_go_parse__main_fn__1050000516_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse__main_fn__1050000516_A{}; t.Ctor(); return t }
//line :662:1
func (t *A_arbace_repr_go_parse__main_fn__1050000516_A) Ctor() {}
//line :662:1
func (t *A_arbace_repr_go_parse__main_fn__1050000516_A) Invoke_O_O__O(self, p1__1050000478_SHARP___1 any) any { return lang.RT_Nth_O_I__O_NoInit(p1__1050000478_SHARP___1, lang.RT_IntCast_J__I_NoInit(2)) }

func A_arbace_repr_go_parse__main_iter__1050000518__1050000522_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_repr_go_parse__main_iter__1050000518__1050000522_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse__main_iter__1050000518__1050000522_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :664:1
func (t *A_arbace_repr_go_parse__main_iter__1050000518__1050000522_A) Ctor_O_O_O_O(c__pool, c__cmd, c__opts, c__known any) { t.F_pool = c__pool; t.F_cmd = c__cmd; t.F_opts = c__opts; t.F_known = c__known }
//line :664:1
func (t *A_arbace_repr_go_parse__main_iter__1050000518__1050000522_A) Invoke_O_O__O(self, s__1050000519__1 any) any { var tmp1 any = A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_A_New_O_O_O_O_O_O(t.F_pool, t.F_cmd, t.F_opts, t.F_known, s__1050000519__1, self); var tmp2 *jrt.Class; var fncls__4173 *jrt.Class = A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_A_fn_class; if fncls__4173 == nil { var fncls__4173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_A_fn_class = fncls__4173d; tmp2 = fncls__4173d } else { tmp2 = fncls__4173 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :664:1
func A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :664:1
func (t *A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_A) Ctor_O_O_O_O_O_O(c__pool, c__cmd, c__opts, c__known, c__s__1050000519, c__iter__1050000518 any) { t.F_pool = c__pool; t.F_cmd = c__cmd; t.F_opts = c__opts; t.F_known = c__known; t.F_s__1050000519 = c__s__1050000519; t.F_iter__1050000518 = c__iter__1050000518 }
//line :664:1
func (t *A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_A) Invoke_O__O(self any) any { { var s__1050000519__1 any; var t_ any = t.F_s__1050000519; t.F_s__1050000519 = nil; s__1050000519__1 = t_; for { var temp__1927000414__auto____2 any; var root_4076 any = A_arbace_repr_go_parse_A_const_16.GetRawRoot__O(); var linked_4077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4076, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_4078 lang.IFn; if linked_4077 == nil { ifn_4078 = lang.IFn_Cast(root_4076) } else { ifn_4078 = nil }; var arg_4079 any = s__1050000519__1; if linked_4077 == nil { temp__1927000414__auto____2 = ifn_4078.Invoke_O__O(arg_4079) } else { temp__1927000414__auto____2 = linked_4077.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_4076, arg_4079) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1050000519__3 any = temp__1927000414__auto____2; var tmp1 any; var root_4080 any = A_arbace_repr_go_parse_A_const_23.GetRawRoot__O(); var linked_4081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4080, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_4082 lang.IFn; if linked_4081 == nil { ifn_4082 = lang.IFn_Cast(root_4080) } else { ifn_4082 = nil }; var arg_4083 any = s__1050000519__3; if linked_4081 == nil { tmp1 = ifn_4082.Invoke_O__O(arg_4083) } else { tmp1 = linked_4081.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_4080, arg_4083) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_4084 any = A_arbace_repr_go_parse_A_const_24.GetRawRoot__O(); var linked_4085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4084, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_4086 lang.IFn; if linked_4085 == nil { ifn_4086 = lang.IFn_Cast(root_4084) } else { ifn_4086 = nil }; var arg_4087 any = s__1050000519__3; if linked_4085 == nil { c__1927001037__auto____4 = ifn_4086.Invoke_O__O(arg_4087) } else { c__1927001037__auto____4 = linked_4085.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_4084, arg_4087) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1050000521__6 any; var root_4088 any = A_arbace_repr_go_parse_A_const_25.GetRawRoot__O(); var linked_4089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4088, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_4090 lang.IFn; if linked_4089 == nil { ifn_4090 = lang.IFn_Cast(root_4088) } else { ifn_4090 = nil }; var arg_4091 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_4089 == nil { b__1050000521__6 = ifn_4090.Invoke_O__O(arg_4091) } else { b__1050000521__6 = linked_4089.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_4088, arg_4091) }; var tmp2 any = A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_fn__1050000524_A_New_O_O_O_O_O_I_O(t.F_pool, t.F_cmd, t.F_opts, t.F_known, b__1050000521__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__4117 *jrt.Class = A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_fn__1050000524_A_fn_class; if fncls__4117 == nil { var fncls__4117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_fn__1050000524_A_fn_class = fncls__4117d; tmp3 = fncls__4117d } else { tmp3 = fncls__4117 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_4118 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_4119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4118, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4120 lang.IFn; if linked_4119 == nil { ifn_4120 = lang.IFn_Cast(root_4118) } else { ifn_4120 = nil }; var arg_4121 any; var root_4123 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_4124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4123, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4125 lang.IFn; if linked_4124 == nil { ifn_4125 = lang.IFn_Cast(root_4123) } else { ifn_4125 = nil }; var arg_4126 any = b__1050000521__6; if linked_4124 == nil { arg_4121 = ifn_4125.Invoke_O__O(arg_4126) } else { arg_4121 = linked_4124.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4123, arg_4126) }; var arg_4122 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1050000518); var tmp5 any; var root_4127 any = A_arbace_repr_go_parse_A_const_29.GetRawRoot__O(); var linked_4128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4127, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_4129 lang.IFn; if linked_4128 == nil { ifn_4129 = lang.IFn_Cast(root_4127) } else { ifn_4129 = nil }; var arg_4130 any = s__1050000519__3; if linked_4128 == nil { tmp5 = ifn_4129.Invoke_O__O(arg_4130) } else { tmp5 = linked_4128.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_4127, arg_4130) }; arg_4122 = tmp4.Invoke_O__O(tmp5); if linked_4119 == nil { return ifn_4120.Invoke_O_O__O(arg_4121, arg_4122) } else { return linked_4119.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4118, arg_4121, arg_4122) } } else { var root_4131 any = A_arbace_repr_go_parse_A_const_27.GetRawRoot__O(); var linked_4132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4131, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_4133 lang.IFn; if linked_4132 == nil { ifn_4133 = lang.IFn_Cast(root_4131) } else { ifn_4133 = nil }; var arg_4134 any; var root_4136 any = A_arbace_repr_go_parse_A_const_28.GetRawRoot__O(); var linked_4137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4136, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_4138 lang.IFn; if linked_4137 == nil { ifn_4138 = lang.IFn_Cast(root_4136) } else { ifn_4138 = nil }; var arg_4139 any = b__1050000521__6; if linked_4137 == nil { arg_4134 = ifn_4138.Invoke_O__O(arg_4139) } else { arg_4134 = linked_4137.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_4136, arg_4139) }; var arg_4135 any; if linked_4132 == nil { return ifn_4133.Invoke_O_O__O(arg_4134, arg_4135) } else { return linked_4132.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_4131, arg_4134, arg_4135) } } } else { var sf__4 any; var root_4140 any = A_arbace_repr_go_parse_A_const_17.GetRawRoot__O(); var linked_4141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4140, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_4142 lang.IFn; if linked_4141 == nil { ifn_4142 = lang.IFn_Cast(root_4140) } else { ifn_4142 = nil }; var arg_4143 any = s__1050000519__3; if linked_4141 == nil { sf__4 = ifn_4142.Invoke_O__O(arg_4143) } else { sf__4 = linked_4141.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_4140, arg_4143) }; var root_4144 any = A_arbace_repr_go_parse_A_const_30.GetRawRoot__O(); var linked_4145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4144, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_4146 lang.IFn; if linked_4145 == nil { ifn_4146 = lang.IFn_Cast(root_4144) } else { ifn_4146 = nil }; var arg_4147 any; var spec__5 any; var root_4149 any = A_arbace_repr_go_parse_A_const_357.GetRawRoot__O(); var linked_4150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4149, A_arbace_repr_go_parse_read_spec_A_fn_class); var ifn_4151 lang.IFn
														if linked_4150 == nil { ifn_4151 = lang.IFn_Cast(root_4149) } else { ifn_4151 = nil }; var arg_4152 any = sf__4; if linked_4150 == nil { spec__5 = ifn_4151.Invoke_O__O(arg_4152) } else { spec__5 = linked_4150.(*A_arbace_repr_go_parse_read_spec_A).Invoke_O_O__O(root_4149, arg_4152) }
														if lang.Util_Equiv_O_O__Z_NoInit(t.F_cmd, Lit_8) {
															var root_4153 any = A_arbace_repr_go_parse_A_const_358.GetRawRoot__O(); var linked_4154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4153, A_arbace_repr_go_parse_check_corpus_A_fn_class); var ifn_4155 lang.IFn; if linked_4154 == nil { ifn_4155 = lang.IFn_Cast(root_4153) } else { ifn_4155 = nil }; var arg_4156 any = A_arbace_repr_go_parse_A_const_354.Invoke_O__O(t.F_opts); var arg_4157 any = spec__5; var arg_4158 any = t.F_pool; var arg_4159 any = A_arbace_repr_go_parse_A_const_350.Invoke_O__O(t.F_opts); var arg_4160 any; var or__1927000174__auto____6 any = t.F_known; if jrt.J2g_Truth(or__1927000174__auto____6) { arg_4160 = or__1927000174__auto____6 } else { arg_4160 = lang.PersistentArrayMap_EMPTY.Ref() }; var arg_4161 any = A_arbace_repr_go_parse_A_const_353.Invoke_O__O(t.F_opts); if linked_4154 == nil { arg_4147 = ifn_4155.Invoke_O_O_O_O_O_O__O(arg_4156, arg_4157, arg_4158, arg_4159, arg_4160, arg_4161) } else { arg_4147 = linked_4154.(*A_arbace_repr_go_parse_check_corpus_A).Invoke_O_O_O_O_O_O_O__O(root_4153, arg_4156, arg_4157, arg_4158, arg_4159, arg_4160, arg_4161) } } else {
																var root_4162 any = A_arbace_repr_go_parse_A_const_359.GetRawRoot__O(); var linked_4163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4162, A_arbace_repr_go_parse_read_corpus_A_fn_class); var ifn_4164 lang.IFn; if linked_4163 == nil { ifn_4164 = lang.IFn_Cast(root_4162) } else { ifn_4164 = nil }; var arg_4165 any = A_arbace_repr_go_parse_A_const_354.Invoke_O__O(t.F_opts); var arg_4166 any = spec__5; var arg_4167 any = t.F_pool; var arg_4168 any = A_arbace_repr_go_parse_A_const_350.Invoke_O__O(t.F_opts); if linked_4163 == nil { arg_4147 = ifn_4164.Invoke_O_O_O_O__O(arg_4165, arg_4166, arg_4167, arg_4168) } else { arg_4147 = linked_4163.(*A_arbace_repr_go_parse_read_corpus_A).Invoke_O_O_O_O_O__O(root_4162, arg_4165, arg_4166, arg_4167, arg_4168) } }
//line :664:1
	var arg_4148 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1050000518); var tmp7 any; var root_4169 any = A_arbace_repr_go_parse_A_const_22.GetRawRoot__O(); var linked_4170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4169, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_4171 lang.IFn; if linked_4170 == nil { ifn_4171 = lang.IFn_Cast(root_4169) } else { ifn_4171 = nil }; var arg_4172 any = s__1050000519__3; if linked_4170 == nil { tmp7 = ifn_4171.Invoke_O__O(arg_4172) } else { tmp7 = linked_4170.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_4169, arg_4172) }; arg_4148 = tmp6.Invoke_O__O(tmp7); if linked_4145 == nil { return ifn_4146.Invoke_O_O__O(arg_4147, arg_4148) } else { return linked_4145.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_4144, arg_4147, arg_4148) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :664:1
func A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_fn__1050000524_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_fn__1050000524_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_fn__1050000524_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :664:1
func (t *A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_fn__1050000524_A) Ctor_O_O_O_O_O_I_O(c__pool, c__cmd, c__opts, c__known, c__b__1050000521 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_pool = c__pool; t.F_cmd = c__cmd; t.F_opts = c__opts; t.F_known = c__known; t.F_b__1050000521 = c__b__1050000521; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :664:1
func (t *A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_fn__1050000524_A) Invoke_O__O(self any) any { { var i__1050000520__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1050000520__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var sf__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1050000520__1)); var root_4092 any = A_arbace_repr_go_parse_A_const_26.GetRawRoot__O(); var linked_4093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4092, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_4094 lang.IFn; if linked_4093 == nil { ifn_4094 = lang.IFn_Cast(root_4092) } else { ifn_4094 = nil }; var arg_4095 any = t.F_b__1050000521; var arg_4096 any; var spec__3 any; var root_4097 any = A_arbace_repr_go_parse_A_const_357.GetRawRoot__O(); var linked_4098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4097, A_arbace_repr_go_parse_read_spec_A_fn_class); var ifn_4099 lang.IFn
																if linked_4098 == nil { ifn_4099 = lang.IFn_Cast(root_4097) } else { ifn_4099 = nil }; var arg_4100 any = sf__2; if linked_4098 == nil { spec__3 = ifn_4099.Invoke_O__O(arg_4100) } else { spec__3 = linked_4098.(*A_arbace_repr_go_parse_read_spec_A).Invoke_O_O__O(root_4097, arg_4100) }
																if lang.Util_Equiv_O_O__Z_NoInit(t.F_cmd, Lit_8) {
																	var root_4101 any = A_arbace_repr_go_parse_A_const_358.GetRawRoot__O(); var linked_4102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4101, A_arbace_repr_go_parse_check_corpus_A_fn_class); var ifn_4103 lang.IFn; if linked_4102 == nil { ifn_4103 = lang.IFn_Cast(root_4101) } else { ifn_4103 = nil }; var arg_4104 any = A_arbace_repr_go_parse_A_const_354.Invoke_O__O(t.F_opts); var arg_4105 any = spec__3; var arg_4106 any = t.F_pool; var arg_4107 any = A_arbace_repr_go_parse_A_const_350.Invoke_O__O(t.F_opts); var arg_4108 any; var or__1927000174__auto____4 any = t.F_known; if jrt.J2g_Truth(or__1927000174__auto____4) { arg_4108 = or__1927000174__auto____4 } else { arg_4108 = lang.PersistentArrayMap_EMPTY.Ref() }; var arg_4109 any = A_arbace_repr_go_parse_A_const_353.Invoke_O__O(t.F_opts); if linked_4102 == nil { arg_4096 = ifn_4103.Invoke_O_O_O_O_O_O__O(arg_4104, arg_4105, arg_4106, arg_4107, arg_4108, arg_4109) } else { arg_4096 = linked_4102.(*A_arbace_repr_go_parse_check_corpus_A).Invoke_O_O_O_O_O_O_O__O(root_4101, arg_4104, arg_4105, arg_4106, arg_4107, arg_4108, arg_4109) } } else {
																		var root_4110 any = A_arbace_repr_go_parse_A_const_359.GetRawRoot__O(); var linked_4111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4110, A_arbace_repr_go_parse_read_corpus_A_fn_class); var ifn_4112 lang.IFn; if linked_4111 == nil { ifn_4112 = lang.IFn_Cast(root_4110) } else { ifn_4112 = nil }; var arg_4113 any = A_arbace_repr_go_parse_A_const_354.Invoke_O__O(t.F_opts); var arg_4114 any = spec__3; var arg_4115 any = t.F_pool; var arg_4116 any = A_arbace_repr_go_parse_A_const_350.Invoke_O__O(t.F_opts); if linked_4111 == nil { arg_4096 = ifn_4112.Invoke_O_O_O_O__O(arg_4113, arg_4114, arg_4115, arg_4116) } else { arg_4096 = linked_4111.(*A_arbace_repr_go_parse_read_corpus_A).Invoke_O_O_O_O_O__O(root_4110, arg_4113, arg_4114, arg_4115, arg_4116) } }
//line :664:1
	if linked_4093 == nil { ifn_4094.Invoke_O_O__O(arg_4095, arg_4096) } else { linked_4093.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_4092, arg_4095, arg_4096) }; i__1050000520__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1050000520__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }














func A_arbace_repr_go_parse__main_fn__1050000528_A_New_O_O_O(p0, p1, p2 any) *A_arbace_repr_go_parse__main_fn__1050000528_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse__main_fn__1050000528_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :679:1
func (t *A_arbace_repr_go_parse__main_fn__1050000528_A) Ctor_O_O_O(c__results, c__fc, c__s__1927001093__auto__ any) { t.F_results = c__results; t.F_fc = c__fc; t.F_s__1927001093__auto__ = c__s__1927001093__auto__ }
//line :679:1
func (t *A_arbace_repr_go_parse__main_fn__1050000528_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_4292 any = A_arbace_repr_go_parse_A_const_305.GetRawRoot__O(); var linked_4293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4292, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_4294 lang.IFn; if linked_4293 == nil { ifn_4294 = lang.IFn_Cast(root_4292) } else { ifn_4294 = nil }; var arg_4295 any = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_240.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_parse_A_const_306, nil); if linked_4293 == nil { ifn_4294.Invoke_O__O(arg_4295) } else { linked_4293.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_4292, arg_4295) }; var tmp2 any = A_arbace_repr_go_parse__main_fn__1050000528_fn__1050000529_A_New_O_O(t.F_results, t.F_fc); var tmp3 *jrt.Class; var fncls__4291 *jrt.Class = A_arbace_repr_go_parse__main_fn__1050000528_fn__1050000529_A_fn_class; if fncls__4291 == nil { var fncls__4291d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_repr_go_parse__main_fn__1050000528_fn__1050000529_A_fn_class = fncls__4291d; tmp3 = fncls__4291d } else { tmp3 = fncls__4291 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); var root_4277 any = A_arbace_repr_go_parse_A_const_142.GetRawRoot__O(); var linked_4278 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4277, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_4279 lang.IFn; if linked_4278 == nil { ifn_4279 = lang.IFn_Cast(root_4277) } else { ifn_4279 = nil }; var arg_4280 any; var t_ any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; arg_4280 = t_; if linked_4278 == nil { tmp1 = ifn_4279.Invoke_O__O(arg_4280) } else { tmp1 = linked_4278.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_4277, arg_4280) } }; return nil }(); var root_4281 any = A_arbace_repr_go_parse_A_const_304.GetRawRoot__O(); var linked_4282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4281, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4283 lang.IFn; if linked_4282 == nil { ifn_4283 = lang.IFn_Cast(root_4281) } else { ifn_4283 = nil }; if linked_4282 == nil { ifn_4283.Invoke__O() } else { linked_4282.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4281) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :679:1
func A_arbace_repr_go_parse__main_fn__1050000528_fn__1050000529_A_New_O_O(p0, p1 any) *A_arbace_repr_go_parse__main_fn__1050000528_fn__1050000529_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse__main_fn__1050000528_fn__1050000529_A{}; t.Ctor_O_O(p0, p1); return t }
//line :679:1
func (t *A_arbace_repr_go_parse__main_fn__1050000528_fn__1050000529_A) Ctor_O_O(c__results, c__fc any) { t.F_results = c__results; t.F_fc = c__fc }
//line :679:1
func (t *A_arbace_repr_go_parse__main_fn__1050000528_fn__1050000529_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_parse_A_const_362.GetRawRoot__O()); var tmp3 any = A_arbace_repr_go_parse_A_const_354; var tmp4 any; var t_ any = t.F_fc; t.F_fc = nil; tmp4 = t_; var tmp5 any = tmp4; var tmp6 any = A_arbace_repr_go_parse_A_const_363; var tmp7 any; var t__2 any = t.F_results; t.F_results = nil; tmp7 = t__2; tmp1 = tmp2.Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp5, tmp6, tmp7))) }; return nil }(); var root_4288 any = A_arbace_repr_go_parse_A_const_304.GetRawRoot__O(); var linked_4289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_4288, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_4290 lang.IFn; if linked_4289 == nil { ifn_4290 = lang.IFn_Cast(root_4288) } else { ifn_4290 = nil }; if linked_4289 == nil { ifn_4290.Invoke__O() } else { linked_4289.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_4288) }; if tmp8 != nil { panic(tmp8) }; return tmp1 }

























































































































































































































































































































type A_arbace_repr_go_parse_A struct{ jrt.Object }

var A_arbace_repr_go_parse_A_const_pool *jrt.RefArray

var A_arbace_repr_go_parse_A_const_0 *lang.Var

var A_arbace_repr_go_parse_A_const_1 any

var A_arbace_repr_go_parse_A_const_2 *lang.Var

var A_arbace_repr_go_parse_A_const_3 any

var A_arbace_repr_go_parse_A_const_4 any

var A_arbace_repr_go_parse_A_const_5 any

var A_arbace_repr_go_parse_A_const_6 any

var A_arbace_repr_go_parse_A_const_7 any

var A_arbace_repr_go_parse_A_const_8 any

var A_arbace_repr_go_parse_A_const_9 *lang.Var

var A_arbace_repr_go_parse_A_const_10 *lang.Var

var A_arbace_repr_go_parse_A_const_11 *lang.Var

var A_arbace_repr_go_parse_A_const_12 *lang.Var

var A_arbace_repr_go_parse_A_const_13 any

var A_arbace_repr_go_parse_A_const_14 *lang.Var

var A_arbace_repr_go_parse_A_const_15 *lang.Var

var A_arbace_repr_go_parse_A_const_16 *lang.Var

var A_arbace_repr_go_parse_A_const_17 *lang.Var

var A_arbace_repr_go_parse_A_const_18 *lang.Var

var A_arbace_repr_go_parse_A_const_19 any

var A_arbace_repr_go_parse_A_const_20 *lang.Var

var A_arbace_repr_go_parse_A_const_21 *lang.Var

var A_arbace_repr_go_parse_A_const_22 *lang.Var

var A_arbace_repr_go_parse_A_const_23 *lang.Var

var A_arbace_repr_go_parse_A_const_24 *lang.Var

var A_arbace_repr_go_parse_A_const_25 *lang.Var

var A_arbace_repr_go_parse_A_const_26 *lang.Var

var A_arbace_repr_go_parse_A_const_27 *lang.Var

var A_arbace_repr_go_parse_A_const_28 *lang.Var

var A_arbace_repr_go_parse_A_const_29 *lang.Var

var A_arbace_repr_go_parse_A_const_30 *lang.Var

var A_arbace_repr_go_parse_A_const_31 *lang.Var

var A_arbace_repr_go_parse_A_const_32 *lang.Var

var A_arbace_repr_go_parse_A_const_33 *lang.Var

var A_arbace_repr_go_parse_A_const_34 *lang.Var

var A_arbace_repr_go_parse_A_const_35 *lang.Var

var A_arbace_repr_go_parse_A_const_36 *lang.Var

var A_arbace_repr_go_parse_A_const_37 any

var A_arbace_repr_go_parse_A_const_38 *lang.Var

var A_arbace_repr_go_parse_A_const_39 *lang.Keyword

var A_arbace_repr_go_parse_A_const_40 any

var A_arbace_repr_go_parse_A_const_41 *lang.Var

var A_arbace_repr_go_parse_A_const_42 *lang.Var

var A_arbace_repr_go_parse_A_const_43 any

var A_arbace_repr_go_parse_A_const_44 *lang.Var

var A_arbace_repr_go_parse_A_const_45 *lang.Var

var A_arbace_repr_go_parse_A_const_46 *lang.Var

var A_arbace_repr_go_parse_A_const_47 *lang.Var

var A_arbace_repr_go_parse_A_const_48 any

var A_arbace_repr_go_parse_A_const_49 any

var A_arbace_repr_go_parse_A_const_50 any

var A_arbace_repr_go_parse_A_const_51 *lang.Var

var A_arbace_repr_go_parse_A_const_52 any

var A_arbace_repr_go_parse_A_const_53 any

var A_arbace_repr_go_parse_A_const_54 *lang.Keyword

var A_arbace_repr_go_parse_A_const_55 any

var A_arbace_repr_go_parse_A_const_56 *lang.Keyword

var A_arbace_repr_go_parse_A_const_57 any

var A_arbace_repr_go_parse_A_const_58 *lang.Keyword

var A_arbace_repr_go_parse_A_const_59 any

var A_arbace_repr_go_parse_A_const_60 *lang.Keyword

var A_arbace_repr_go_parse_A_const_61 any

var A_arbace_repr_go_parse_A_const_62 *lang.Keyword

var A_arbace_repr_go_parse_A_const_63 any

var A_arbace_repr_go_parse_A_const_64 *lang.Keyword

var A_arbace_repr_go_parse_A_const_65 any

var A_arbace_repr_go_parse_A_const_66 *lang.Keyword

var A_arbace_repr_go_parse_A_const_67 *lang.Keyword

var A_arbace_repr_go_parse_A_const_68 *lang.Keyword

var A_arbace_repr_go_parse_A_const_69 *lang.Keyword

var A_arbace_repr_go_parse_A_const_70 *lang.Var

var A_arbace_repr_go_parse_A_const_71 *lang.Var

var A_arbace_repr_go_parse_A_const_72 any

var A_arbace_repr_go_parse_A_const_73 *lang.Keyword

var A_arbace_repr_go_parse_A_const_74 *lang.Keyword

var A_arbace_repr_go_parse_A_const_75 *lang.Var

var A_arbace_repr_go_parse_A_const_76 *lang.Var

var A_arbace_repr_go_parse_A_const_77 *lang.Var

var A_arbace_repr_go_parse_A_const_78 *lang.Keyword

var A_arbace_repr_go_parse_A_const_79 *lang.Var

var A_arbace_repr_go_parse_A_const_80 *lang.Keyword

var A_arbace_repr_go_parse_A_const_81 *lang.Var

var A_arbace_repr_go_parse_A_const_82 *lang.Var

var A_arbace_repr_go_parse_A_const_83 *lang.Var

var A_arbace_repr_go_parse_A_const_84 *lang.Var

var A_arbace_repr_go_parse_A_const_85 *lang.Var

var A_arbace_repr_go_parse_A_const_86 any

var A_arbace_repr_go_parse_A_const_87 any

var A_arbace_repr_go_parse_A_const_88 any

var A_arbace_repr_go_parse_A_const_89 any

var A_arbace_repr_go_parse_A_const_90 any

var A_arbace_repr_go_parse_A_const_91 any

var A_arbace_repr_go_parse_A_const_92 any

var A_arbace_repr_go_parse_A_const_93 any

var A_arbace_repr_go_parse_A_const_94 any

var A_arbace_repr_go_parse_A_const_95 any

var A_arbace_repr_go_parse_A_const_96 any

var A_arbace_repr_go_parse_A_const_97 any

var A_arbace_repr_go_parse_A_const_98 any

var A_arbace_repr_go_parse_A_const_99 any

var A_arbace_repr_go_parse_A_const_100 any

var A_arbace_repr_go_parse_A_const_101 any

var A_arbace_repr_go_parse_A_const_102 any

var A_arbace_repr_go_parse_A_const_103 any

var A_arbace_repr_go_parse_A_const_104 any

var A_arbace_repr_go_parse_A_const_105 any

var A_arbace_repr_go_parse_A_const_106 any

var A_arbace_repr_go_parse_A_const_107 any

var A_arbace_repr_go_parse_A_const_108 any

var A_arbace_repr_go_parse_A_const_109 any

var A_arbace_repr_go_parse_A_const_110 any

var A_arbace_repr_go_parse_A_const_111 any

var A_arbace_repr_go_parse_A_const_112 any

var A_arbace_repr_go_parse_A_const_113 any

var A_arbace_repr_go_parse_A_const_114 any

var A_arbace_repr_go_parse_A_const_115 any

var A_arbace_repr_go_parse_A_const_116 any

var A_arbace_repr_go_parse_A_const_117 *lang.Var

var A_arbace_repr_go_parse_A_const_118 any

var A_arbace_repr_go_parse_A_const_119 any

var A_arbace_repr_go_parse_A_const_120 any

var A_arbace_repr_go_parse_A_const_121 any

var A_arbace_repr_go_parse_A_const_122 any

var A_arbace_repr_go_parse_A_const_123 any

var A_arbace_repr_go_parse_A_const_124 any

var A_arbace_repr_go_parse_A_const_125 any

var A_arbace_repr_go_parse_A_const_126 any

var A_arbace_repr_go_parse_A_const_127 any

var A_arbace_repr_go_parse_A_const_128 any

var A_arbace_repr_go_parse_A_const_129 any

var A_arbace_repr_go_parse_A_const_130 any

var A_arbace_repr_go_parse_A_const_131 any

var A_arbace_repr_go_parse_A_const_132 any

var A_arbace_repr_go_parse_A_const_133 any

var A_arbace_repr_go_parse_A_const_134 any

var A_arbace_repr_go_parse_A_const_135 any

var A_arbace_repr_go_parse_A_const_136 any

var A_arbace_repr_go_parse_A_const_137 any

var A_arbace_repr_go_parse_A_const_138 *lang.Var

var A_arbace_repr_go_parse_A_const_139 any

var A_arbace_repr_go_parse_A_const_140 any

var A_arbace_repr_go_parse_A_const_141 any

var A_arbace_repr_go_parse_A_const_142 *lang.Var

var A_arbace_repr_go_parse_A_const_143 any

var A_arbace_repr_go_parse_A_const_144 any

var A_arbace_repr_go_parse_A_const_145 any

var A_arbace_repr_go_parse_A_const_146 any

var A_arbace_repr_go_parse_A_const_147 any

var A_arbace_repr_go_parse_A_const_148 any

var A_arbace_repr_go_parse_A_const_149 any

var A_arbace_repr_go_parse_A_const_150 any

var A_arbace_repr_go_parse_A_const_151 any

var A_arbace_repr_go_parse_A_const_152 *lang.Var

var A_arbace_repr_go_parse_A_const_153 *lang.Var

var A_arbace_repr_go_parse_A_const_154 any

var A_arbace_repr_go_parse_A_const_155 *lang.Var

var A_arbace_repr_go_parse_A_const_156 *lang.Var

var A_arbace_repr_go_parse_A_const_157 *lang.Var

var A_arbace_repr_go_parse_A_const_158 *lang.Var

var A_arbace_repr_go_parse_A_const_159 *lang.Var

var A_arbace_repr_go_parse_A_const_160 any

var A_arbace_repr_go_parse_A_const_161 any

var A_arbace_repr_go_parse_A_const_162 any

var A_arbace_repr_go_parse_A_const_163 any

var A_arbace_repr_go_parse_A_const_164 any

var A_arbace_repr_go_parse_A_const_165 any

var A_arbace_repr_go_parse_A_const_166 any

var A_arbace_repr_go_parse_A_const_167 any

var A_arbace_repr_go_parse_A_const_168 any

var A_arbace_repr_go_parse_A_const_169 any

var A_arbace_repr_go_parse_A_const_170 any

var A_arbace_repr_go_parse_A_const_171 any

var A_arbace_repr_go_parse_A_const_172 any

var A_arbace_repr_go_parse_A_const_173 any

var A_arbace_repr_go_parse_A_const_174 any

var A_arbace_repr_go_parse_A_const_175 any

var A_arbace_repr_go_parse_A_const_176 any

var A_arbace_repr_go_parse_A_const_177 *lang.Var

var A_arbace_repr_go_parse_A_const_178 any

var A_arbace_repr_go_parse_A_const_179 *lang.Var

var A_arbace_repr_go_parse_A_const_180 *lang.Var

var A_arbace_repr_go_parse_A_const_181 *lang.Var

var A_arbace_repr_go_parse_A_const_182 *lang.Var

var A_arbace_repr_go_parse_A_const_183 *lang.Var

var A_arbace_repr_go_parse_A_const_184 *lang.Keyword

var A_arbace_repr_go_parse_A_const_185 *lang.Keyword

var A_arbace_repr_go_parse_A_const_186 any

var A_arbace_repr_go_parse_A_const_187 *lang.Keyword

var A_arbace_repr_go_parse_A_const_188 *lang.Keyword

var A_arbace_repr_go_parse_A_const_189 *lang.Keyword

var A_arbace_repr_go_parse_A_const_190 *lang.Keyword

var A_arbace_repr_go_parse_A_const_191 *lang.Keyword

var A_arbace_repr_go_parse_A_const_192 *lang.Keyword

var A_arbace_repr_go_parse_A_const_193 *lang.Keyword

var A_arbace_repr_go_parse_A_const_194 *lang.Var

var A_arbace_repr_go_parse_A_const_195 *lang.Var

var A_arbace_repr_go_parse_A_const_196 *lang.Var

var A_arbace_repr_go_parse_A_const_197 *lang.Var

var A_arbace_repr_go_parse_A_const_198 *lang.Keyword

var A_arbace_repr_go_parse_A_const_199 *lang.Var

var A_arbace_repr_go_parse_A_const_200 *lang.Var

var A_arbace_repr_go_parse_A_const_201 *lang.Keyword

var A_arbace_repr_go_parse_A_const_202 *lang.Keyword

var A_arbace_repr_go_parse_A_const_203 *lang.Keyword

var A_arbace_repr_go_parse_A_const_204 *lang.Var

var A_arbace_repr_go_parse_A_const_205 any

var A_arbace_repr_go_parse_A_const_206 *lang.Var

var A_arbace_repr_go_parse_A_const_207 any

var A_arbace_repr_go_parse_A_const_208 *lang.Keyword

var A_arbace_repr_go_parse_A_const_209 *lang.Keyword

var A_arbace_repr_go_parse_A_const_210 *lang.Var

var A_arbace_repr_go_parse_A_const_211 *lang.Var

var A_arbace_repr_go_parse_A_const_212 any

var A_arbace_repr_go_parse_A_const_213 any

var A_arbace_repr_go_parse_A_const_214 *lang.Var

var A_arbace_repr_go_parse_A_const_215 *lang.Keyword

var A_arbace_repr_go_parse_A_const_216 *lang.Keyword

var A_arbace_repr_go_parse_A_const_217 *lang.Var

var A_arbace_repr_go_parse_A_const_218 *lang.Var

var A_arbace_repr_go_parse_A_const_219 *lang.Var

var A_arbace_repr_go_parse_A_const_220 *lang.Var

var A_arbace_repr_go_parse_A_const_221 *lang.Var

var A_arbace_repr_go_parse_A_const_222 any

var A_arbace_repr_go_parse_A_const_223 *lang.Var

var A_arbace_repr_go_parse_A_const_224 *lang.Var

var A_arbace_repr_go_parse_A_const_225 *lang.Var

var A_arbace_repr_go_parse_A_const_226 *lang.Keyword

var A_arbace_repr_go_parse_A_const_227 *lang.Keyword

var A_arbace_repr_go_parse_A_const_228 *lang.Keyword

var A_arbace_repr_go_parse_A_const_229 *lang.Keyword

var A_arbace_repr_go_parse_A_const_230 *lang.Keyword

var A_arbace_repr_go_parse_A_const_231 *lang.Keyword

var A_arbace_repr_go_parse_A_const_232 *lang.Keyword

var A_arbace_repr_go_parse_A_const_233 *lang.Var

var A_arbace_repr_go_parse_A_const_234 *lang.Var

var A_arbace_repr_go_parse_A_const_235 *lang.Var

var A_arbace_repr_go_parse_A_const_236 *lang.Var

var A_arbace_repr_go_parse_A_const_237 any

var A_arbace_repr_go_parse_A_const_238 any

var A_arbace_repr_go_parse_A_const_239 any

var A_arbace_repr_go_parse_A_const_240 *lang.Var

var A_arbace_repr_go_parse_A_const_241 *lang.Var

var A_arbace_repr_go_parse_A_const_242 *lang.Var

var A_arbace_repr_go_parse_A_const_243 any

var A_arbace_repr_go_parse_A_const_244 *lang.Var

var A_arbace_repr_go_parse_A_const_245 *lang.Var

var A_arbace_repr_go_parse_A_const_246 *lang.Keyword

var A_arbace_repr_go_parse_A_const_247 *lang.Var

var A_arbace_repr_go_parse_A_const_248 any

var A_arbace_repr_go_parse_A_const_249 *lang.Var

var A_arbace_repr_go_parse_A_const_250 *lang.Var

var A_arbace_repr_go_parse_A_const_251 *lang.Var

var A_arbace_repr_go_parse_A_const_252 any

var A_arbace_repr_go_parse_A_const_253 *lang.Keyword

var A_arbace_repr_go_parse_A_const_254 *lang.Var

var A_arbace_repr_go_parse_A_const_255 *lang.Keyword

var A_arbace_repr_go_parse_A_const_256 *lang.Keyword

var A_arbace_repr_go_parse_A_const_257 *lang.Var

var A_arbace_repr_go_parse_A_const_258 *lang.Var

var A_arbace_repr_go_parse_A_const_259 *lang.Keyword

var A_arbace_repr_go_parse_A_const_260 *lang.Var

var A_arbace_repr_go_parse_A_const_261 *lang.Var

var A_arbace_repr_go_parse_A_const_262 any

var A_arbace_repr_go_parse_A_const_263 *lang.Keyword

var A_arbace_repr_go_parse_A_const_264 *lang.Var

var A_arbace_repr_go_parse_A_const_265 *lang.Keyword

var A_arbace_repr_go_parse_A_const_266 *lang.Var

var A_arbace_repr_go_parse_A_const_267 *lang.Keyword

var A_arbace_repr_go_parse_A_const_268 *lang.Var

var A_arbace_repr_go_parse_A_const_269 *lang.Keyword

var A_arbace_repr_go_parse_A_const_270 *lang.Keyword

var A_arbace_repr_go_parse_A_const_271 *lang.Keyword

var A_arbace_repr_go_parse_A_const_272 *lang.Keyword

var A_arbace_repr_go_parse_A_const_273 *lang.Var

var A_arbace_repr_go_parse_A_const_274 *lang.Var

var A_arbace_repr_go_parse_A_const_275 *lang.Keyword

var A_arbace_repr_go_parse_A_const_276 *lang.Var

var A_arbace_repr_go_parse_A_const_277 *lang.Var

var A_arbace_repr_go_parse_A_const_278 any

var A_arbace_repr_go_parse_A_const_279 *lang.Var

var A_arbace_repr_go_parse_A_const_280 *lang.Var

var A_arbace_repr_go_parse_A_const_281 *lang.Var

var A_arbace_repr_go_parse_A_const_282 *lang.Keyword

var A_arbace_repr_go_parse_A_const_283 *lang.Var

var A_arbace_repr_go_parse_A_const_284 any

var A_arbace_repr_go_parse_A_const_285 any

var A_arbace_repr_go_parse_A_const_286 any

var A_arbace_repr_go_parse_A_const_287 *lang.Var

var A_arbace_repr_go_parse_A_const_288 *lang.Var

var A_arbace_repr_go_parse_A_const_289 *lang.Keyword

var A_arbace_repr_go_parse_A_const_290 any

var A_arbace_repr_go_parse_A_const_291 *lang.Keyword

var A_arbace_repr_go_parse_A_const_292 *lang.Var

var A_arbace_repr_go_parse_A_const_293 *lang.Keyword

var A_arbace_repr_go_parse_A_const_294 *lang.Keyword

var A_arbace_repr_go_parse_A_const_295 *lang.Keyword

var A_arbace_repr_go_parse_A_const_296 *lang.Var

var A_arbace_repr_go_parse_A_const_297 *lang.Var

var A_arbace_repr_go_parse_A_const_298 *lang.Keyword

var A_arbace_repr_go_parse_A_const_299 *lang.Keyword

var A_arbace_repr_go_parse_A_const_300 *lang.Keyword

var A_arbace_repr_go_parse_A_const_301 *lang.Var

var A_arbace_repr_go_parse_A_const_302 *lang.Var

var A_arbace_repr_go_parse_A_const_303 *lang.Var

var A_arbace_repr_go_parse_A_const_304 *lang.Var

var A_arbace_repr_go_parse_A_const_305 *lang.Var

var A_arbace_repr_go_parse_A_const_306 *lang.Var

var A_arbace_repr_go_parse_A_const_307 *lang.Var

var A_arbace_repr_go_parse_A_const_308 *lang.Var

var A_arbace_repr_go_parse_A_const_309 *lang.Var

var A_arbace_repr_go_parse_A_const_310 *lang.Var

var A_arbace_repr_go_parse_A_const_311 *lang.Keyword

var A_arbace_repr_go_parse_A_const_312 *lang.Keyword

var A_arbace_repr_go_parse_A_const_313 *lang.Var

var A_arbace_repr_go_parse_A_const_314 *lang.Keyword

var A_arbace_repr_go_parse_A_const_315 *lang.Var

var A_arbace_repr_go_parse_A_const_316 *lang.Keyword

var A_arbace_repr_go_parse_A_const_317 *lang.Var

var A_arbace_repr_go_parse_A_const_318 any

var A_arbace_repr_go_parse_A_const_319 *lang.Var

var A_arbace_repr_go_parse_A_const_320 any

var A_arbace_repr_go_parse_A_const_321 *lang.Var

var A_arbace_repr_go_parse_A_const_322 *lang.Keyword

var A_arbace_repr_go_parse_A_const_323 any

var A_arbace_repr_go_parse_A_const_324 *lang.Var

var A_arbace_repr_go_parse_A_const_325 any

var A_arbace_repr_go_parse_A_const_326 *lang.Var

var A_arbace_repr_go_parse_A_const_327 *lang.Var

var A_arbace_repr_go_parse_A_const_328 *lang.Keyword

var A_arbace_repr_go_parse_A_const_329 *lang.Var

var A_arbace_repr_go_parse_A_const_330 *lang.Var

var A_arbace_repr_go_parse_A_const_331 *lang.Var

var A_arbace_repr_go_parse_A_const_332 any

var A_arbace_repr_go_parse_A_const_333 *lang.Keyword

var A_arbace_repr_go_parse_A_const_334 *lang.Var

var A_arbace_repr_go_parse_A_const_335 *lang.Keyword

var A_arbace_repr_go_parse_A_const_336 *lang.Keyword

var A_arbace_repr_go_parse_A_const_337 *lang.Keyword

var A_arbace_repr_go_parse_A_const_338 *lang.Keyword

var A_arbace_repr_go_parse_A_const_339 *lang.Keyword

var A_arbace_repr_go_parse_A_const_340 *lang.Keyword

var A_arbace_repr_go_parse_A_const_341 *lang.Keyword

var A_arbace_repr_go_parse_A_const_342 *lang.Keyword

var A_arbace_repr_go_parse_A_const_343 *lang.Keyword

var A_arbace_repr_go_parse_A_const_344 *lang.Keyword

var A_arbace_repr_go_parse_A_const_345 *lang.Var

var A_arbace_repr_go_parse_A_const_346 *lang.Var

var A_arbace_repr_go_parse_A_const_347 any

var A_arbace_repr_go_parse_A_const_348 any

var A_arbace_repr_go_parse_A_const_349 any

var A_arbace_repr_go_parse_A_const_350 *lang.Keyword

var A_arbace_repr_go_parse_A_const_351 *lang.Keyword

var A_arbace_repr_go_parse_A_const_352 *lang.Keyword

var A_arbace_repr_go_parse_A_const_353 *lang.Keyword

var A_arbace_repr_go_parse_A_const_354 *lang.Keyword

var A_arbace_repr_go_parse_A_const_355 any

var A_arbace_repr_go_parse_A_const_356 *lang.Var

var A_arbace_repr_go_parse_A_const_357 *lang.Var

var A_arbace_repr_go_parse_A_const_358 *lang.Var

var A_arbace_repr_go_parse_A_const_359 *lang.Var

var A_arbace_repr_go_parse_A_const_360 *lang.Var

var A_arbace_repr_go_parse_A_const_361 *lang.Var

var A_arbace_repr_go_parse_A_const_362 *lang.Var

var A_arbace_repr_go_parse_A_const_363 *lang.Keyword

var A_arbace_repr_go_parse_A_const_364 *lang.Var

var A_arbace_repr_go_parse_A_init jrt.ClassInit

func A_arbace_repr_go_parse_A_Init() { if !A_arbace_repr_go_parse_A_init.Done() { A_arbace_repr_go_parse_A_init.Run(A_arbace_repr_go_parse_A_clinit) } }

func A_arbace_repr_go_parse_A_clinit() { A_arbace_repr_go_parse_A_clinit_p0(); A_arbace_repr_go_parse_A_clinit_p1(); A_arbace_repr_go_parse_A_clinit_p2(); A_arbace_repr_go_parse_A_clinit_p3(); A_arbace_repr_go_parse_A_clinit_p4(); A_arbace_repr_go_parse_A_clinit_p5(); A_arbace_repr_go_parse_A_clinit_p6(); A_arbace_repr_go_parse_A_clinit_p7(); A_arbace_repr_go_parse_A_clinit_p8(); A_arbace_repr_go_parse_A_clinit_p9(); A_arbace_repr_go_parse_A_clinit_p10(); A_arbace_repr_go_parse_A_clinit_p11(); A_arbace_repr_go_parse_A_clinit_p12(); A_arbace_repr_go_parse_A_clinit_p13(); A_arbace_repr_go_parse_A_clinit_p14(); A_arbace_repr_go_parse_A_clinit_p15(); A_arbace_repr_go_parse_A_clinit_p16(); A_arbace_repr_go_parse_A_clinit_p17(); A_arbace_repr_go_parse_A_clinit_p18(); A_arbace_repr_go_parse_A_clinit_p19(); A_arbace_repr_go_parse_A_clinit_p20(); A_arbace_repr_go_parse_A_clinit_p21(); A_arbace_repr_go_parse_A_clinit_p22(); A_arbace_repr_go_parse_A_clinit_p23(); A_arbace_repr_go_parse_A_clinit_p24(); A_arbace_repr_go_parse_A_clinit_p25(); A_arbace_repr_go_parse_A_clinit_p26(); A_arbace_repr_go_parse_A_clinit_p27(); A_arbace_repr_go_parse_A_clinit_p28() }

func A_arbace_repr_go_parse_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_parse_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 672); A_arbace_repr_go_parse_A_const_0 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[307]); A_arbace_repr_go_parse_A_const_1 = A_arbace_repr_go_parse_A_const_pool.A[308]; A_arbace_repr_go_parse_A_const_2 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[309]); A_arbace_repr_go_parse_A_const_3 = A_arbace_repr_go_parse_A_const_pool.A[310]; A_arbace_repr_go_parse_A_const_4 = A_arbace_repr_go_parse_A_const_pool.A[311]; A_arbace_repr_go_parse_A_const_5 = A_arbace_repr_go_parse_A_const_pool.A[312]; A_arbace_repr_go_parse_A_const_6 = A_arbace_repr_go_parse_A_const_pool.A[313]; A_arbace_repr_go_parse_A_const_7 = A_arbace_repr_go_parse_A_const_pool.A[314]; A_arbace_repr_go_parse_A_const_8 = A_arbace_repr_go_parse_A_const_pool.A[315]; A_arbace_repr_go_parse_A_const_9 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[316]); A_arbace_repr_go_parse_A_const_10 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[317]); A_arbace_repr_go_parse_A_const_11 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[318]); A_arbace_repr_go_parse_A_const_12 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[319]) }

func A_arbace_repr_go_parse_A_clinit_p1() { A_arbace_repr_go_parse_A_const_13 = A_arbace_repr_go_parse_A_const_pool.A[320]; A_arbace_repr_go_parse_A_const_14 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[321]); A_arbace_repr_go_parse_A_const_15 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[322]); A_arbace_repr_go_parse_A_const_16 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[323]); A_arbace_repr_go_parse_A_const_17 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[324]); A_arbace_repr_go_parse_A_const_18 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[325]); A_arbace_repr_go_parse_A_const_19 = A_arbace_repr_go_parse_A_const_pool.A[326]; A_arbace_repr_go_parse_A_const_20 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[327]); A_arbace_repr_go_parse_A_const_21 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[328]); A_arbace_repr_go_parse_A_const_22 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[329]); A_arbace_repr_go_parse_A_const_23 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[330]); A_arbace_repr_go_parse_A_const_24 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[331]) }

func A_arbace_repr_go_parse_A_clinit_p2() { A_arbace_repr_go_parse_A_const_25 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[332]); A_arbace_repr_go_parse_A_const_26 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[333]); A_arbace_repr_go_parse_A_const_27 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[334]); A_arbace_repr_go_parse_A_const_28 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[335]); A_arbace_repr_go_parse_A_const_29 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[336]); A_arbace_repr_go_parse_A_const_30 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[337]); A_arbace_repr_go_parse_A_const_31 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[338]); A_arbace_repr_go_parse_A_const_32 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[339]); A_arbace_repr_go_parse_A_const_33 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[340]); A_arbace_repr_go_parse_A_const_34 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[341]); A_arbace_repr_go_parse_A_const_35 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[342]); A_arbace_repr_go_parse_A_const_36 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[343]) }

func A_arbace_repr_go_parse_A_clinit_p3() { A_arbace_repr_go_parse_A_const_37 = A_arbace_repr_go_parse_A_const_pool.A[344]; A_arbace_repr_go_parse_A_const_38 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[345]); A_arbace_repr_go_parse_A_const_39 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[346]); A_arbace_repr_go_parse_A_const_40 = A_arbace_repr_go_parse_A_const_pool.A[347]; A_arbace_repr_go_parse_A_const_41 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[348]); A_arbace_repr_go_parse_A_const_42 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[349]); A_arbace_repr_go_parse_A_const_43 = A_arbace_repr_go_parse_A_const_pool.A[350]; A_arbace_repr_go_parse_A_const_44 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[351]); A_arbace_repr_go_parse_A_const_45 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[352]); A_arbace_repr_go_parse_A_const_46 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[353]); A_arbace_repr_go_parse_A_const_47 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[354]); A_arbace_repr_go_parse_A_const_48 = A_arbace_repr_go_parse_A_const_pool.A[355]; A_arbace_repr_go_parse_A_const_49 = A_arbace_repr_go_parse_A_const_pool.A[356] }

func A_arbace_repr_go_parse_A_clinit_p4() { A_arbace_repr_go_parse_A_const_50 = A_arbace_repr_go_parse_A_const_pool.A[357]; A_arbace_repr_go_parse_A_const_51 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[358]); A_arbace_repr_go_parse_A_const_52 = A_arbace_repr_go_parse_A_const_pool.A[359]; A_arbace_repr_go_parse_A_const_53 = A_arbace_repr_go_parse_A_const_pool.A[360]; A_arbace_repr_go_parse_A_const_54 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[361]); A_arbace_repr_go_parse_A_const_55 = A_arbace_repr_go_parse_A_const_pool.A[362]; A_arbace_repr_go_parse_A_const_56 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[363]); A_arbace_repr_go_parse_A_const_57 = A_arbace_repr_go_parse_A_const_pool.A[364]; A_arbace_repr_go_parse_A_const_58 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[365]); A_arbace_repr_go_parse_A_const_59 = A_arbace_repr_go_parse_A_const_pool.A[366]; A_arbace_repr_go_parse_A_const_60 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[367]); A_arbace_repr_go_parse_A_const_61 = A_arbace_repr_go_parse_A_const_pool.A[368]; A_arbace_repr_go_parse_A_const_62 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[369]); A_arbace_repr_go_parse_A_const_63 = A_arbace_repr_go_parse_A_const_pool.A[370] }

func A_arbace_repr_go_parse_A_clinit_p5() { A_arbace_repr_go_parse_A_const_64 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[371]); A_arbace_repr_go_parse_A_const_65 = A_arbace_repr_go_parse_A_const_pool.A[372]; A_arbace_repr_go_parse_A_const_66 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[373]); A_arbace_repr_go_parse_A_const_67 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[374]); A_arbace_repr_go_parse_A_const_68 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[375]); A_arbace_repr_go_parse_A_const_69 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[376]); A_arbace_repr_go_parse_A_const_70 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[377]); A_arbace_repr_go_parse_A_const_71 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[378]); A_arbace_repr_go_parse_A_const_72 = A_arbace_repr_go_parse_A_const_pool.A[379]; A_arbace_repr_go_parse_A_const_73 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[380]); A_arbace_repr_go_parse_A_const_74 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[381]); A_arbace_repr_go_parse_A_const_75 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[382]) }

func A_arbace_repr_go_parse_A_clinit_p6() { A_arbace_repr_go_parse_A_const_76 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[383]); A_arbace_repr_go_parse_A_const_77 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[384]); A_arbace_repr_go_parse_A_const_78 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[385]); A_arbace_repr_go_parse_A_const_79 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[386]); A_arbace_repr_go_parse_A_const_80 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[387]); A_arbace_repr_go_parse_A_const_81 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[388]); A_arbace_repr_go_parse_A_const_82 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[389]); A_arbace_repr_go_parse_A_const_83 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[390]); A_arbace_repr_go_parse_A_const_84 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[391]); A_arbace_repr_go_parse_A_const_85 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[392]); A_arbace_repr_go_parse_A_const_86 = A_arbace_repr_go_parse_A_const_pool.A[393]; A_arbace_repr_go_parse_A_const_87 = A_arbace_repr_go_parse_A_const_pool.A[394] }

func A_arbace_repr_go_parse_A_clinit_p7() { A_arbace_repr_go_parse_A_const_88 = A_arbace_repr_go_parse_A_const_pool.A[395]; A_arbace_repr_go_parse_A_const_89 = A_arbace_repr_go_parse_A_const_pool.A[396]; A_arbace_repr_go_parse_A_const_90 = A_arbace_repr_go_parse_A_const_pool.A[397]; A_arbace_repr_go_parse_A_const_91 = A_arbace_repr_go_parse_A_const_pool.A[398]; A_arbace_repr_go_parse_A_const_92 = A_arbace_repr_go_parse_A_const_pool.A[399]; A_arbace_repr_go_parse_A_const_93 = A_arbace_repr_go_parse_A_const_pool.A[400]; A_arbace_repr_go_parse_A_const_94 = A_arbace_repr_go_parse_A_const_pool.A[401]; A_arbace_repr_go_parse_A_const_95 = A_arbace_repr_go_parse_A_const_pool.A[402]; A_arbace_repr_go_parse_A_const_96 = A_arbace_repr_go_parse_A_const_pool.A[403]; A_arbace_repr_go_parse_A_const_97 = A_arbace_repr_go_parse_A_const_pool.A[404]; A_arbace_repr_go_parse_A_const_98 = A_arbace_repr_go_parse_A_const_pool.A[405]; A_arbace_repr_go_parse_A_const_99 = A_arbace_repr_go_parse_A_const_pool.A[406]; A_arbace_repr_go_parse_A_const_100 = A_arbace_repr_go_parse_A_const_pool.A[407]; A_arbace_repr_go_parse_A_const_101 = A_arbace_repr_go_parse_A_const_pool.A[408]; A_arbace_repr_go_parse_A_const_102 = A_arbace_repr_go_parse_A_const_pool.A[409]; A_arbace_repr_go_parse_A_const_103 = A_arbace_repr_go_parse_A_const_pool.A[410] }

func A_arbace_repr_go_parse_A_clinit_p8() { A_arbace_repr_go_parse_A_const_104 = A_arbace_repr_go_parse_A_const_pool.A[411]; A_arbace_repr_go_parse_A_const_105 = A_arbace_repr_go_parse_A_const_pool.A[412]; A_arbace_repr_go_parse_A_const_106 = A_arbace_repr_go_parse_A_const_pool.A[413]; A_arbace_repr_go_parse_A_const_107 = A_arbace_repr_go_parse_A_const_pool.A[414]; A_arbace_repr_go_parse_A_const_108 = A_arbace_repr_go_parse_A_const_pool.A[415]; A_arbace_repr_go_parse_A_const_109 = A_arbace_repr_go_parse_A_const_pool.A[416]; A_arbace_repr_go_parse_A_const_110 = A_arbace_repr_go_parse_A_const_pool.A[417]; A_arbace_repr_go_parse_A_const_111 = A_arbace_repr_go_parse_A_const_pool.A[418]; A_arbace_repr_go_parse_A_const_112 = A_arbace_repr_go_parse_A_const_pool.A[419]; A_arbace_repr_go_parse_A_const_113 = A_arbace_repr_go_parse_A_const_pool.A[420]; A_arbace_repr_go_parse_A_const_114 = A_arbace_repr_go_parse_A_const_pool.A[421]; A_arbace_repr_go_parse_A_const_115 = A_arbace_repr_go_parse_A_const_pool.A[422]; A_arbace_repr_go_parse_A_const_116 = A_arbace_repr_go_parse_A_const_pool.A[423]; A_arbace_repr_go_parse_A_const_117 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[424]); A_arbace_repr_go_parse_A_const_118 = A_arbace_repr_go_parse_A_const_pool.A[425] }

func A_arbace_repr_go_parse_A_clinit_p9() { A_arbace_repr_go_parse_A_const_119 = A_arbace_repr_go_parse_A_const_pool.A[426]; A_arbace_repr_go_parse_A_const_120 = A_arbace_repr_go_parse_A_const_pool.A[427]; A_arbace_repr_go_parse_A_const_121 = A_arbace_repr_go_parse_A_const_pool.A[428]; A_arbace_repr_go_parse_A_const_122 = A_arbace_repr_go_parse_A_const_pool.A[429]; A_arbace_repr_go_parse_A_const_123 = A_arbace_repr_go_parse_A_const_pool.A[430]; A_arbace_repr_go_parse_A_const_124 = A_arbace_repr_go_parse_A_const_pool.A[431]; A_arbace_repr_go_parse_A_const_125 = A_arbace_repr_go_parse_A_const_pool.A[432]; A_arbace_repr_go_parse_A_const_126 = A_arbace_repr_go_parse_A_const_pool.A[433]; A_arbace_repr_go_parse_A_const_127 = A_arbace_repr_go_parse_A_const_pool.A[434]; A_arbace_repr_go_parse_A_const_128 = A_arbace_repr_go_parse_A_const_pool.A[435]; A_arbace_repr_go_parse_A_const_129 = A_arbace_repr_go_parse_A_const_pool.A[436]; A_arbace_repr_go_parse_A_const_130 = A_arbace_repr_go_parse_A_const_pool.A[437]; A_arbace_repr_go_parse_A_const_131 = A_arbace_repr_go_parse_A_const_pool.A[438]; A_arbace_repr_go_parse_A_const_132 = A_arbace_repr_go_parse_A_const_pool.A[439]; A_arbace_repr_go_parse_A_const_133 = A_arbace_repr_go_parse_A_const_pool.A[440]; A_arbace_repr_go_parse_A_const_134 = A_arbace_repr_go_parse_A_const_pool.A[441] }

func A_arbace_repr_go_parse_A_clinit_p10() { A_arbace_repr_go_parse_A_const_135 = A_arbace_repr_go_parse_A_const_pool.A[442]; A_arbace_repr_go_parse_A_const_136 = A_arbace_repr_go_parse_A_const_pool.A[443]; A_arbace_repr_go_parse_A_const_137 = A_arbace_repr_go_parse_A_const_pool.A[444]; A_arbace_repr_go_parse_A_const_138 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[445]); A_arbace_repr_go_parse_A_const_139 = A_arbace_repr_go_parse_A_const_pool.A[446]; A_arbace_repr_go_parse_A_const_140 = A_arbace_repr_go_parse_A_const_pool.A[447]; A_arbace_repr_go_parse_A_const_141 = A_arbace_repr_go_parse_A_const_pool.A[448]; A_arbace_repr_go_parse_A_const_142 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[449]); A_arbace_repr_go_parse_A_const_143 = A_arbace_repr_go_parse_A_const_pool.A[450]; A_arbace_repr_go_parse_A_const_144 = A_arbace_repr_go_parse_A_const_pool.A[451]; A_arbace_repr_go_parse_A_const_145 = A_arbace_repr_go_parse_A_const_pool.A[452]; A_arbace_repr_go_parse_A_const_146 = A_arbace_repr_go_parse_A_const_pool.A[453]; A_arbace_repr_go_parse_A_const_147 = A_arbace_repr_go_parse_A_const_pool.A[454]; A_arbace_repr_go_parse_A_const_148 = A_arbace_repr_go_parse_A_const_pool.A[455]; A_arbace_repr_go_parse_A_const_149 = A_arbace_repr_go_parse_A_const_pool.A[456] }

func A_arbace_repr_go_parse_A_clinit_p11() { A_arbace_repr_go_parse_A_const_150 = A_arbace_repr_go_parse_A_const_pool.A[457]; A_arbace_repr_go_parse_A_const_151 = A_arbace_repr_go_parse_A_const_pool.A[458]; A_arbace_repr_go_parse_A_const_152 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[459]); A_arbace_repr_go_parse_A_const_153 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[460]); A_arbace_repr_go_parse_A_const_154 = A_arbace_repr_go_parse_A_const_pool.A[461]; A_arbace_repr_go_parse_A_const_155 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[462]); A_arbace_repr_go_parse_A_const_156 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[463]); A_arbace_repr_go_parse_A_const_157 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[464]); A_arbace_repr_go_parse_A_const_158 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[465]); A_arbace_repr_go_parse_A_const_159 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[466]); A_arbace_repr_go_parse_A_const_160 = A_arbace_repr_go_parse_A_const_pool.A[467]; A_arbace_repr_go_parse_A_const_161 = A_arbace_repr_go_parse_A_const_pool.A[468]; A_arbace_repr_go_parse_A_const_162 = A_arbace_repr_go_parse_A_const_pool.A[469] }

func A_arbace_repr_go_parse_A_clinit_p12() { A_arbace_repr_go_parse_A_const_163 = A_arbace_repr_go_parse_A_const_pool.A[470]; A_arbace_repr_go_parse_A_const_164 = A_arbace_repr_go_parse_A_const_pool.A[471]; A_arbace_repr_go_parse_A_const_165 = A_arbace_repr_go_parse_A_const_pool.A[472]; A_arbace_repr_go_parse_A_const_166 = A_arbace_repr_go_parse_A_const_pool.A[473]; A_arbace_repr_go_parse_A_const_167 = A_arbace_repr_go_parse_A_const_pool.A[474]; A_arbace_repr_go_parse_A_const_168 = A_arbace_repr_go_parse_A_const_pool.A[475]; A_arbace_repr_go_parse_A_const_169 = A_arbace_repr_go_parse_A_const_pool.A[476]; A_arbace_repr_go_parse_A_const_170 = A_arbace_repr_go_parse_A_const_pool.A[477]; A_arbace_repr_go_parse_A_const_171 = A_arbace_repr_go_parse_A_const_pool.A[478]; A_arbace_repr_go_parse_A_const_172 = A_arbace_repr_go_parse_A_const_pool.A[479]; A_arbace_repr_go_parse_A_const_173 = A_arbace_repr_go_parse_A_const_pool.A[480]; A_arbace_repr_go_parse_A_const_174 = A_arbace_repr_go_parse_A_const_pool.A[481]; A_arbace_repr_go_parse_A_const_175 = A_arbace_repr_go_parse_A_const_pool.A[482]; A_arbace_repr_go_parse_A_const_176 = A_arbace_repr_go_parse_A_const_pool.A[483]; A_arbace_repr_go_parse_A_const_177 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[484]) }

func A_arbace_repr_go_parse_A_clinit_p13() { A_arbace_repr_go_parse_A_const_178 = A_arbace_repr_go_parse_A_const_pool.A[485]; A_arbace_repr_go_parse_A_const_179 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[486]); A_arbace_repr_go_parse_A_const_180 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[487]); A_arbace_repr_go_parse_A_const_181 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[488]); A_arbace_repr_go_parse_A_const_182 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[489]); A_arbace_repr_go_parse_A_const_183 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[490]); A_arbace_repr_go_parse_A_const_184 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[491]); A_arbace_repr_go_parse_A_const_185 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[492]); A_arbace_repr_go_parse_A_const_186 = A_arbace_repr_go_parse_A_const_pool.A[493]; A_arbace_repr_go_parse_A_const_187 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[494]); A_arbace_repr_go_parse_A_const_188 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[495]); A_arbace_repr_go_parse_A_const_189 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[496]) }

func A_arbace_repr_go_parse_A_clinit_p14() { A_arbace_repr_go_parse_A_const_190 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[497]); A_arbace_repr_go_parse_A_const_191 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[498]); A_arbace_repr_go_parse_A_const_192 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[499]); A_arbace_repr_go_parse_A_const_193 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[500]); A_arbace_repr_go_parse_A_const_194 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[501]); A_arbace_repr_go_parse_A_const_195 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[502]); A_arbace_repr_go_parse_A_const_196 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[503]); A_arbace_repr_go_parse_A_const_197 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[504]); A_arbace_repr_go_parse_A_const_198 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[505]); A_arbace_repr_go_parse_A_const_199 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[506]); A_arbace_repr_go_parse_A_const_200 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[507]); A_arbace_repr_go_parse_A_const_201 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[508]) }

func A_arbace_repr_go_parse_A_clinit_p15() { A_arbace_repr_go_parse_A_const_202 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[509]); A_arbace_repr_go_parse_A_const_203 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[510]); A_arbace_repr_go_parse_A_const_204 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[511]); A_arbace_repr_go_parse_A_const_205 = A_arbace_repr_go_parse_A_const_pool.A[512]; A_arbace_repr_go_parse_A_const_206 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[513]); A_arbace_repr_go_parse_A_const_207 = A_arbace_repr_go_parse_A_const_pool.A[514]; A_arbace_repr_go_parse_A_const_208 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[515]); A_arbace_repr_go_parse_A_const_209 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[516]); A_arbace_repr_go_parse_A_const_210 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[517]); A_arbace_repr_go_parse_A_const_211 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[518]); A_arbace_repr_go_parse_A_const_212 = A_arbace_repr_go_parse_A_const_pool.A[519]; A_arbace_repr_go_parse_A_const_213 = A_arbace_repr_go_parse_A_const_pool.A[520]; A_arbace_repr_go_parse_A_const_214 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[521]) }

func A_arbace_repr_go_parse_A_clinit_p16() { A_arbace_repr_go_parse_A_const_215 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[522]); A_arbace_repr_go_parse_A_const_216 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[523]); A_arbace_repr_go_parse_A_const_217 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[524]); A_arbace_repr_go_parse_A_const_218 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[525]); A_arbace_repr_go_parse_A_const_219 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[526]); A_arbace_repr_go_parse_A_const_220 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[527]); A_arbace_repr_go_parse_A_const_221 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[528]); A_arbace_repr_go_parse_A_const_222 = A_arbace_repr_go_parse_A_const_pool.A[529]; A_arbace_repr_go_parse_A_const_223 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[530]); A_arbace_repr_go_parse_A_const_224 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[531]); A_arbace_repr_go_parse_A_const_225 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[532]); A_arbace_repr_go_parse_A_const_226 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[533]) }

func A_arbace_repr_go_parse_A_clinit_p17() { A_arbace_repr_go_parse_A_const_227 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[534]); A_arbace_repr_go_parse_A_const_228 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[535]); A_arbace_repr_go_parse_A_const_229 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[536]); A_arbace_repr_go_parse_A_const_230 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[537]); A_arbace_repr_go_parse_A_const_231 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[538]); A_arbace_repr_go_parse_A_const_232 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[539]); A_arbace_repr_go_parse_A_const_233 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[540]); A_arbace_repr_go_parse_A_const_234 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[541]); A_arbace_repr_go_parse_A_const_235 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[542]); A_arbace_repr_go_parse_A_const_236 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[543]); A_arbace_repr_go_parse_A_const_237 = A_arbace_repr_go_parse_A_const_pool.A[544]; A_arbace_repr_go_parse_A_const_238 = A_arbace_repr_go_parse_A_const_pool.A[545] }

func A_arbace_repr_go_parse_A_clinit_p18() { A_arbace_repr_go_parse_A_const_239 = A_arbace_repr_go_parse_A_const_pool.A[546]; A_arbace_repr_go_parse_A_const_240 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[547]); A_arbace_repr_go_parse_A_const_241 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[548]); A_arbace_repr_go_parse_A_const_242 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[549]); A_arbace_repr_go_parse_A_const_243 = A_arbace_repr_go_parse_A_const_pool.A[550]; A_arbace_repr_go_parse_A_const_244 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[551]); A_arbace_repr_go_parse_A_const_245 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[552]); A_arbace_repr_go_parse_A_const_246 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[553]); A_arbace_repr_go_parse_A_const_247 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[554]); A_arbace_repr_go_parse_A_const_248 = A_arbace_repr_go_parse_A_const_pool.A[555]; A_arbace_repr_go_parse_A_const_249 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[556]); A_arbace_repr_go_parse_A_const_250 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[557]) }

func A_arbace_repr_go_parse_A_clinit_p19() { A_arbace_repr_go_parse_A_const_251 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[558]); A_arbace_repr_go_parse_A_const_252 = A_arbace_repr_go_parse_A_const_pool.A[559]; A_arbace_repr_go_parse_A_const_253 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[560]); A_arbace_repr_go_parse_A_const_254 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[561]); A_arbace_repr_go_parse_A_const_255 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[562]); A_arbace_repr_go_parse_A_const_256 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[563]); A_arbace_repr_go_parse_A_const_257 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[564]); A_arbace_repr_go_parse_A_const_258 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[565]); A_arbace_repr_go_parse_A_const_259 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[566]); A_arbace_repr_go_parse_A_const_260 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[567]); A_arbace_repr_go_parse_A_const_261 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[568]); A_arbace_repr_go_parse_A_const_262 = A_arbace_repr_go_parse_A_const_pool.A[569] }

func A_arbace_repr_go_parse_A_clinit_p20() { A_arbace_repr_go_parse_A_const_263 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[570]); A_arbace_repr_go_parse_A_const_264 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[571]); A_arbace_repr_go_parse_A_const_265 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[572]); A_arbace_repr_go_parse_A_const_266 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[573]); A_arbace_repr_go_parse_A_const_267 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[574]); A_arbace_repr_go_parse_A_const_268 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[575]); A_arbace_repr_go_parse_A_const_269 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[576]); A_arbace_repr_go_parse_A_const_270 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[577]); A_arbace_repr_go_parse_A_const_271 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[578]); A_arbace_repr_go_parse_A_const_272 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[579]); A_arbace_repr_go_parse_A_const_273 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[580]); A_arbace_repr_go_parse_A_const_274 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[581]) }

func A_arbace_repr_go_parse_A_clinit_p21() { A_arbace_repr_go_parse_A_const_275 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[582]); A_arbace_repr_go_parse_A_const_276 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[583]); A_arbace_repr_go_parse_A_const_277 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[584]); A_arbace_repr_go_parse_A_const_278 = A_arbace_repr_go_parse_A_const_pool.A[585]; A_arbace_repr_go_parse_A_const_279 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[586]); A_arbace_repr_go_parse_A_const_280 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[587]); A_arbace_repr_go_parse_A_const_281 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[588]); A_arbace_repr_go_parse_A_const_282 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[589]); A_arbace_repr_go_parse_A_const_283 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[590]); A_arbace_repr_go_parse_A_const_284 = A_arbace_repr_go_parse_A_const_pool.A[591]; A_arbace_repr_go_parse_A_const_285 = A_arbace_repr_go_parse_A_const_pool.A[592]; A_arbace_repr_go_parse_A_const_286 = A_arbace_repr_go_parse_A_const_pool.A[593]; A_arbace_repr_go_parse_A_const_287 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[594]) }

func A_arbace_repr_go_parse_A_clinit_p22() { A_arbace_repr_go_parse_A_const_288 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[595]); A_arbace_repr_go_parse_A_const_289 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[596]); A_arbace_repr_go_parse_A_const_290 = A_arbace_repr_go_parse_A_const_pool.A[597]; A_arbace_repr_go_parse_A_const_291 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[598]); A_arbace_repr_go_parse_A_const_292 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[599]); A_arbace_repr_go_parse_A_const_293 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[600]); A_arbace_repr_go_parse_A_const_294 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[601]); A_arbace_repr_go_parse_A_const_295 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[602]); A_arbace_repr_go_parse_A_const_296 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[603]); A_arbace_repr_go_parse_A_const_297 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[604]); A_arbace_repr_go_parse_A_const_298 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[605]); A_arbace_repr_go_parse_A_const_299 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[606]) }

func A_arbace_repr_go_parse_A_clinit_p23() { A_arbace_repr_go_parse_A_const_300 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[607]); A_arbace_repr_go_parse_A_const_301 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[608]); A_arbace_repr_go_parse_A_const_302 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[609]); A_arbace_repr_go_parse_A_const_303 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[610]); A_arbace_repr_go_parse_A_const_304 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[611]); A_arbace_repr_go_parse_A_const_305 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[612]); A_arbace_repr_go_parse_A_const_306 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[613]); A_arbace_repr_go_parse_A_const_307 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[614]); A_arbace_repr_go_parse_A_const_308 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[615]); A_arbace_repr_go_parse_A_const_309 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[616]); A_arbace_repr_go_parse_A_const_310 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[617]); A_arbace_repr_go_parse_A_const_311 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[618]) }

func A_arbace_repr_go_parse_A_clinit_p24() { A_arbace_repr_go_parse_A_const_312 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[619]); A_arbace_repr_go_parse_A_const_313 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[620]); A_arbace_repr_go_parse_A_const_314 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[621]); A_arbace_repr_go_parse_A_const_315 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[622]); A_arbace_repr_go_parse_A_const_316 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[623]); A_arbace_repr_go_parse_A_const_317 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[624]); A_arbace_repr_go_parse_A_const_318 = A_arbace_repr_go_parse_A_const_pool.A[625]; A_arbace_repr_go_parse_A_const_319 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[626]); A_arbace_repr_go_parse_A_const_320 = A_arbace_repr_go_parse_A_const_pool.A[627]; A_arbace_repr_go_parse_A_const_321 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[628]); A_arbace_repr_go_parse_A_const_322 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[629]); A_arbace_repr_go_parse_A_const_323 = A_arbace_repr_go_parse_A_const_pool.A[630] }

func A_arbace_repr_go_parse_A_clinit_p25() { A_arbace_repr_go_parse_A_const_324 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[631]); A_arbace_repr_go_parse_A_const_325 = A_arbace_repr_go_parse_A_const_pool.A[632]; A_arbace_repr_go_parse_A_const_326 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[633]); A_arbace_repr_go_parse_A_const_327 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[634]); A_arbace_repr_go_parse_A_const_328 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[635]); A_arbace_repr_go_parse_A_const_329 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[636]); A_arbace_repr_go_parse_A_const_330 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[637]); A_arbace_repr_go_parse_A_const_331 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[638]); A_arbace_repr_go_parse_A_const_332 = A_arbace_repr_go_parse_A_const_pool.A[639]; A_arbace_repr_go_parse_A_const_333 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[640]); A_arbace_repr_go_parse_A_const_334 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[641]); A_arbace_repr_go_parse_A_const_335 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[642]) }

func A_arbace_repr_go_parse_A_clinit_p26() { A_arbace_repr_go_parse_A_const_336 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[643]); A_arbace_repr_go_parse_A_const_337 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[644]); A_arbace_repr_go_parse_A_const_338 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[645]); A_arbace_repr_go_parse_A_const_339 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[646]); A_arbace_repr_go_parse_A_const_340 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[647]); A_arbace_repr_go_parse_A_const_341 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[648]); A_arbace_repr_go_parse_A_const_342 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[649]); A_arbace_repr_go_parse_A_const_343 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[650]); A_arbace_repr_go_parse_A_const_344 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[651]); A_arbace_repr_go_parse_A_const_345 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[652]); A_arbace_repr_go_parse_A_const_346 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[653]); A_arbace_repr_go_parse_A_const_347 = A_arbace_repr_go_parse_A_const_pool.A[654] }

func A_arbace_repr_go_parse_A_clinit_p27() { A_arbace_repr_go_parse_A_const_348 = A_arbace_repr_go_parse_A_const_pool.A[655]; A_arbace_repr_go_parse_A_const_349 = A_arbace_repr_go_parse_A_const_pool.A[656]; A_arbace_repr_go_parse_A_const_350 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[657]); A_arbace_repr_go_parse_A_const_351 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[658]); A_arbace_repr_go_parse_A_const_352 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[659]); A_arbace_repr_go_parse_A_const_353 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[660]); A_arbace_repr_go_parse_A_const_354 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[661]); A_arbace_repr_go_parse_A_const_355 = A_arbace_repr_go_parse_A_const_pool.A[662]; A_arbace_repr_go_parse_A_const_356 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[663]); A_arbace_repr_go_parse_A_const_357 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[664]); A_arbace_repr_go_parse_A_const_358 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[665]); A_arbace_repr_go_parse_A_const_359 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[666]) }

func A_arbace_repr_go_parse_A_clinit_p28() { A_arbace_repr_go_parse_A_const_360 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[667]); A_arbace_repr_go_parse_A_const_361 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[668]); A_arbace_repr_go_parse_A_const_362 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[669]); A_arbace_repr_go_parse_A_const_363 = lang.Keyword_Cast(A_arbace_repr_go_parse_A_const_pool.A[670]); A_arbace_repr_go_parse_A_const_364 = lang.Var_Cast(A_arbace_repr_go_parse_A_const_pool.A[671]) }

func A_arbace_repr_go_parse_A_New() *A_arbace_repr_go_parse_A { A_arbace_repr_go_parse_A_Init(); t := &A_arbace_repr_go_parse_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_parse_A) Ctor() {}

func (t *A_arbace_repr_go_parse_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_parse_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_parse_A_class }

func (t *A_arbace_repr_go_parse_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_parse_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_parse_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_parse_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_parse_A); return ok }

func A_arbace_repr_go_parse_A_Cast(x any) *A_arbace_repr_go_parse_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_parse_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_parse_A_class)) }; return v }



type A_arbace_repr_go_parse__main_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse__main_A_fn_class *jrt.Class



type A_arbace_repr_go_parse__main_fn__1050000487_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse__main_fn__1050000487_A_fn_class *jrt.Class



type A_arbace_repr_go_parse__main_fn__1050000496_A struct{ j2g_header uint64; F_G__1050000492, F_opts any }

var A_arbace_repr_go_parse__main_fn__1050000496_A_fn_class *jrt.Class



type A_arbace_repr_go_parse__main_fn__1050000502_A struct{ j2g_header uint64; F_k any }

var A_arbace_repr_go_parse__main_fn__1050000502_A_fn_class *jrt.Class



type A_arbace_repr_go_parse__main_fn__1050000508_A struct{ j2g_header uint64; F_fc any }

var A_arbace_repr_go_parse__main_fn__1050000508_A_fn_class *jrt.Class



type A_arbace_repr_go_parse__main_fn__1050000516_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse__main_fn__1050000516_A_fn_class *jrt.Class



type A_arbace_repr_go_parse__main_fn__1050000528_A struct{ j2g_header uint64; F_results, F_fc, F_s__1927001093__auto__ any }

var A_arbace_repr_go_parse__main_fn__1050000528_A_fn_class *jrt.Class



type A_arbace_repr_go_parse__main_fn__1050000528_fn__1050000529_A struct{ j2g_header uint64; F_results, F_fc any }

var A_arbace_repr_go_parse__main_fn__1050000528_fn__1050000529_A_fn_class *jrt.Class



type A_arbace_repr_go_parse__main_iter__1050000518__1050000522_A struct{ j2g_header uint64; F_pool, F_cmd, F_opts, F_known any }

var A_arbace_repr_go_parse__main_iter__1050000518__1050000522_A_fn_class *jrt.Class



type A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_A struct{ j2g_header uint64; F_pool, F_cmd, F_opts, F_known, F_s__1050000519, F_iter__1050000518 any }

var A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_A_fn_class *jrt.Class



type A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_fn__1050000524_A struct{ j2g_header uint64; F_pool, F_cmd, F_opts, F_known, F_b__1050000521 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse__main_iter__1050000518__1050000522_fn__1050000523_fn__1050000524_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_ast_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_ast_nodes_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_A struct{ j2g_header uint64; F_s__1050000053, F_iter__1050000052 any }

var A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_fn__1050000058_A struct{ j2g_header uint64; F_b__1050000055 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_ast_nodes_iter__1050000052__1050000056_fn__1050000057_fn__1050000058_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_A struct{ j2g_header uint64; F_kind, F_nodes any }

var A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_A struct{ j2g_header uint64; F_s__1050000073, F_kind, F_nodes, F_iter__1050000072 any }

var A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_A struct{ j2g_header uint64; F_kind, F_nodes, F_b__1050000075 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_A struct{ j2g_header uint64; F_n, F_kind any }

var A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_A struct{ j2g_header uint64; F_s__1050000083, F_n, F_iter__1050000082, F_kind any }

var A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_fn__1050000088_A struct{ j2g_header uint64; F_n, F_kind, F_b__1050000085 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_fn__1050000078_iter__1050000082__1050000086_fn__1050000087_fn__1050000088_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_A struct{ j2g_header uint64; F_n, F_kind any }

var A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_A struct{ j2g_header uint64; F_n, F_s__1050000097, F_kind, F_iter__1050000096 any }

var A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_fn__1050000102_A struct{ j2g_header uint64; F_n, F_kind, F_b__1050000099 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_ast_nodes_iter__1050000072__1050000076_fn__1050000077_iter__1050000096__1050000100_fn__1050000101_fn__1050000102_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_kind__1050000070_A struct{ j2g_header uint64; F_node_type_QMARK_ any }

var A_arbace_repr_go_parse_ast_nodes_kind__1050000070_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_ast_nodes_node_type_QMARK___1050000068_A struct{ j2g_header uint64; F_ifaces, F_nodes any }

var A_arbace_repr_go_parse_ast_nodes_node_type_QMARK___1050000068_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_check_corpus_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_fn__1050000338_A struct{ j2g_header uint64; F_headers, F_helper, F_out, F_nm, F_pool, F_goroot_forms any }

var A_arbace_repr_go_parse_check_corpus_fn__1050000338_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_A struct{ j2g_header uint64; F_headers, F_helper, F_j, F_out, F_nm, F_goroot_forms any }

var A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_fn__1050000340_A struct{ j2g_header uint64; F_j, F_out, F_nm any }

var A_arbace_repr_go_parse_check_corpus_fn__1050000338_fn__1050000339_fn__1050000340_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_fn__1050000344_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_check_corpus_fn__1050000344_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_fn__1050000374_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_check_corpus_fn__1050000374_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_fn__1050000396_A struct{ j2g_header uint64; F_helper any }

var A_arbace_repr_go_parse_check_corpus_fn__1050000396_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_A struct{ j2g_header uint64; F_hres, F_js any }

var A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_fn__1050000367_A struct{ j2g_header uint64; F_r any }

var A_arbace_repr_go_parse_check_corpus_helper_failed_QMARK___1050000366_fn__1050000367_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_A struct{ j2g_header uint64; F_dumps any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_A struct{ j2g_header uint64; F_dumps, F_s__1050000329, F_iter__1050000328 any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_fn__1050000334_A struct{ j2g_header uint64; F_dumps, F_b__1050000331 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000328__1050000332_fn__1050000333_fn__1050000334_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_A struct{ j2g_header uint64; F_results, F_jkeys any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_A struct{ j2g_header uint64; F_results, F_jkeys, F_s__1050000347, F_iter__1050000346 any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_A struct{ j2g_header uint64; F_results, F_jkeys any; F_size__1927001038__auto__ int32; F_b__1050000349, F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_fn__1050000356_A struct{ j2g_header uint64; F_k any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000352_fn__1050000356_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000362_A struct{ j2g_header uint64; F_k any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000346__1050000350_fn__1050000351_fn__1050000362_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_A struct{ j2g_header uint64; F_s__1050000399, F_iter__1050000398 any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_fn__1050000404_A struct{ j2g_header uint64; F_b__1050000401 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000398__1050000402_fn__1050000403_fn__1050000404_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_A struct{ j2g_header uint64; F_s__1050000409, F_iter__1050000408 any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_fn__1050000414_A struct{ j2g_header uint64; F_b__1050000411 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000408__1050000412_fn__1050000413_fn__1050000414_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_A struct{ j2g_header uint64; F_s__1050000419, F_iter__1050000418 any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_fn__1050000424_A struct{ j2g_header uint64; F_b__1050000421 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000418__1050000422_fn__1050000423_fn__1050000424_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_A struct{ j2g_header uint64; F_hres, F_helper_failed_QMARK_ any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_A struct{ j2g_header uint64; F_hres, F_s__1050000429, F_iter__1050000428, F_helper_failed_QMARK_ any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_fn__1050000434_A struct{ j2g_header uint64; F_hres, F_b__1050000431 any; F_size__1927001038__auto__ int32; F_helper_failed_QMARK_, F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_check_corpus_iter__1050000428__1050000432_fn__1050000433_fn__1050000434_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_A struct{ j2g_header uint64; F_known any }

var A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_fn__1050000371_A struct{ j2g_header uint64; F_known any }

var A_arbace_repr_go_parse_check_corpus_known_QMARK___1050000370_fn__1050000371_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_sum__1050000376_A struct{ j2g_header uint64; F_ok any }

var A_arbace_repr_go_parse_check_corpus_sum__1050000376_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_corpus_sum__1050000376_fn__1050000377_A struct{ j2g_header uint64; F_k any }

var A_arbace_repr_go_parse_check_corpus_sum__1050000376_fn__1050000377_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_header_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_check_header_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_check_job_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_check_job_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_decl_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_decl_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_A struct{ j2g_header uint64; F_s__1050000179, F_iter__1050000178 any }

var A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_fn__1050000184_A struct{ j2g_header uint64; F_b__1050000181 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_decl_forms_iter__1050000178__1050000182_fn__1050000183_fn__1050000184_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_diff_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_diff_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_diff_fn__1050000248_A struct{ j2g_header uint64; F_a, F_b, F_path any }

var A_arbace_repr_go_parse_diff_fn__1050000248_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_diff_fn__1050000251_A struct{ j2g_header uint64; F_b, F_path any }

var A_arbace_repr_go_parse_diff_fn__1050000251_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_diff_fn__1050000257_A struct{ j2g_header uint64; F_path any }

var A_arbace_repr_go_parse_diff_fn__1050000257_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_dumper_forms_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_dumper_forms_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_A struct{ j2g_header uint64; F_s__1050000128, F_iter__1050000127 any }

var A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_fn__1050000133_A struct{ j2g_header uint64; F_b__1050000130 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_dumper_forms_iter__1050000127__1050000131_fn__1050000132_fn__1050000133_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_eval1050000004_A struct{ jrt.Object }

func A_arbace_repr_go_parse_eval1050000004_A_New() *A_arbace_repr_go_parse_eval1050000004_A { t := &A_arbace_repr_go_parse_eval1050000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_parse_eval1050000004_A) Ctor() {}

func (t *A_arbace_repr_go_parse_eval1050000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_parse_eval1050000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_parse_eval1050000004_A_class }

func (t *A_arbace_repr_go_parse_eval1050000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_parse_eval1050000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_parse_eval1050000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_parse_eval1050000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_parse_eval1050000004_A); return ok }

func A_arbace_repr_go_parse_eval1050000004_A_Cast(x any) *A_arbace_repr_go_parse_eval1050000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_parse_eval1050000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_parse_eval1050000004_A_class)) }; return v }



type A_arbace_repr_go_parse_eval1050000004_loading__1927001464__auto____1050000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_eval1050000004_loading__1927001464__auto____1050000005_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_eval1050000008_A struct{ jrt.Object }

func A_arbace_repr_go_parse_eval1050000008_A_New() *A_arbace_repr_go_parse_eval1050000008_A { t := &A_arbace_repr_go_parse_eval1050000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_parse_eval1050000008_A) Ctor() {}

func (t *A_arbace_repr_go_parse_eval1050000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_parse_eval1050000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_parse_eval1050000008_A_class }

func (t *A_arbace_repr_go_parse_eval1050000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_parse_eval1050000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_parse_eval1050000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_parse_eval1050000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_parse_eval1050000008_A); return ok }

func A_arbace_repr_go_parse_eval1050000008_A_Cast(x any) *A_arbace_repr_go_parse_eval1050000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_parse_eval1050000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_parse_eval1050000008_A_class)) }; return v }



type A_arbace_repr_go_parse_eval1050000008_fn__1050000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_eval1050000008_fn__1050000009_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_field_stmts_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_field_stmts_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_field_stmts_add__1050000113_A struct{ j2g_header uint64; F_kv any }

var A_arbace_repr_go_parse_field_stmts_add__1050000113_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_file_at_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_file_at_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_file_go_version_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_file_go_version_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_forms_check_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_forms_check_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_A struct{ j2g_header uint64; F_goroot_forms any }

var A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_A struct{ j2g_header uint64; F_s__1050000192, F_iter__1050000191, F_goroot_forms any }

var A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_A struct{ j2g_header uint64; F_b__1050000194, F_goroot_forms any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000198_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000198_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000200_A struct{ j2g_header uint64; F_dir any }

var A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000197_fn__1050000200_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000203_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000203_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000205_A struct{ j2g_header uint64; F_dir any }

var A_arbace_repr_go_parse_forms_check_iter__1050000191__1050000195_fn__1050000196_fn__1050000205_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_go_lang_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_go_lang_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_helper_header_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_helper_header_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_helper_results_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_helper_results_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_A struct{ j2g_header uint64; F_s__1050000298, F_iter__1050000297 any }

var A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_fn__1050000303_A struct{ j2g_header uint64; F_b__1050000300 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_helper_results_iter__1050000297__1050000301_fn__1050000302_fn__1050000303_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_job_keys_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_job_keys_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_A struct{ j2g_header uint64; F_j any }

var A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_A struct{ j2g_header uint64; F_j, F_s__1050000266, F_iter__1050000265 any }

var A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_fn__1050000271_A struct{ j2g_header uint64; F_j, F_b__1050000268 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_job_keys_iter__1050000265__1050000269_fn__1050000270_fn__1050000271_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_kebab_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_kebab_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_kind_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_kind_of_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_kw_var_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_kw_var_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_load_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_load_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_parse_load_BANG__fn__1050000154_A struct{ j2g_header uint64; F_init_funcs any }

var A_arbace_repr_go_parse_load_BANG__fn__1050000154_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_load_BANG__fn__1050000156_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_load_BANG__fn__1050000156_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_A struct{ j2g_header uint64; F_s__1050000141, F_iter__1050000140 any }

var A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_fn__1050000146_A struct{ j2g_header uint64; F_b__1050000143 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_load_BANG__iter__1050000140__1050000144_fn__1050000145_fn__1050000146_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_native_dump_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_native_dump_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_native_dump_fn__1050000223_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_native_dump_fn__1050000223_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_native_dump_fn__1050000225_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_native_dump_fn__1050000225_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_native_dump_fn__1050000240_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_native_dump_fn__1050000240_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_A struct{ j2g_header uint64; F_dir, F_goroot_forms any }

var A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_A struct{ j2g_header uint64; F_dir, F_s__1050000214, F_iter__1050000213, F_goroot_forms any }

var A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_fn__1050000219_A struct{ j2g_header uint64; F_dir, F_goroot_forms any; F_size__1927001038__auto__ int32; F_b__1050000216, F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_native_dump_iter__1050000213__1050000217_fn__1050000218_fn__1050000219_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_A struct{ j2g_header uint64; F_lang any }

var A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_A struct{ j2g_header uint64; F_lang, F_s__1050000229, F_iter__1050000228 any }

var A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_fn__1050000234_A struct{ j2g_header uint64; F_lang, F_b__1050000231 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_native_dump_iter__1050000228__1050000232_fn__1050000233_fn__1050000234_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_node_case_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_node_case_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_node_case_fn__1050000122_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_node_case_fn__1050000122_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_node_case_fn__1050000124_A struct{ j2g_header uint64; F_name any }

var A_arbace_repr_go_parse_node_case_fn__1050000124_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_parse_file_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_parse_file_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_read_corpus_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_read_corpus_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_read_corpus_fn__1050000449_A struct{ j2g_header uint64; F_out, F_pool, F_goroot_forms, F_nm any }

var A_arbace_repr_go_parse_read_corpus_fn__1050000449_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_A struct{ j2g_header uint64; F_j, F_out, F_goroot_forms, F_nm any }

var A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_fn__1050000451_A struct{ j2g_header uint64; F_j, F_out, F_nm any }

var A_arbace_repr_go_parse_read_corpus_fn__1050000449_fn__1050000450_fn__1050000451_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_read_corpus_fn__1050000455_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_read_corpus_fn__1050000455_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_read_corpus_fn__1050000465_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_read_corpus_fn__1050000465_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_read_corpus_fn__1050000471_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_read_corpus_fn__1050000471_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_read_corpus_fn__1050000473_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_read_corpus_fn__1050000473_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_read_corpus_fn__1050000475_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_read_corpus_fn__1050000475_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_read_corpus_sum__1050000457_A struct{ j2g_header uint64; F_ok any }

var A_arbace_repr_go_parse_read_corpus_sum__1050000457_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_read_corpus_sum__1050000457_fn__1050000458_A struct{ j2g_header uint64; F_k any }

var A_arbace_repr_go_parse_read_corpus_sum__1050000457_fn__1050000458_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_read_spec_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_read_spec_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_receiver_types_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_receiver_types_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_A struct{ j2g_header uint64; F_m any }

var A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_A struct{ j2g_header uint64; F_s__1050000041, F_m, F_iter__1050000040 any }

var A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_fn__1050000046_A struct{ j2g_header uint64; F_m, F_b__1050000043 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_receiver_types_iter__1050000040__1050000044_fn__1050000045_fn__1050000046_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_short_str_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_short_str_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_spec_jobs_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_spec_jobs_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_spec_jobs_fn__1050000282_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_spec_jobs_fn__1050000282_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_A struct{ j2g_header uint64; F_l any }

var A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_A struct{ j2g_header uint64; F_s__1050000284, F_l, F_iter__1050000283 any }

var A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_fn__1050000289_A struct{ j2g_header uint64; F_l, F_b__1050000286 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_spec_jobs_fn__1050000282_iter__1050000283__1050000287_fn__1050000288_fn__1050000289_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_strip_meta_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_strip_meta_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_strip_meta_fn__1050000172_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_strip_meta_fn__1050000172_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_tree_of_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_tree_of_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_tree_of_fn__1050000244_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_tree_of_fn__1050000244_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_type_specs_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_type_specs_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_A struct{ j2g_header uint64; F_s__1050000014, F_iter__1050000013 any }

var A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_A struct{ j2g_header uint64; F_s__1050000016, F_iter__1050000015 any }

var A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_fn__1050000023_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1050000018, F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000015__1050000021_fn__1050000022_fn__1050000023_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_A struct{ j2g_header uint64; F_s__1050000028, F_iter__1050000027 any }

var A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_fn__1050000033_A struct{ j2g_header uint64; F_b__1050000030 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_parse_type_specs_iter__1050000013__1050000019_fn__1050000020_iter__1050000027__1050000031_fn__1050000032_fn__1050000033_A_fn_class *jrt.Class



type A_arbace_repr_go_parse_write_native_BANG__A struct{ j2g_header uint64 }

var A_arbace_repr_go_parse_write_native_BANG__A_fn_class *jrt.Class



type A_arbace_repr_go_parse_write_native_BANG__fn__1050000278_A struct{ j2g_header uint64; F_n any }

var A_arbace_repr_go_parse_write_native_BANG__fn__1050000278_A_fn_class *jrt.Class
