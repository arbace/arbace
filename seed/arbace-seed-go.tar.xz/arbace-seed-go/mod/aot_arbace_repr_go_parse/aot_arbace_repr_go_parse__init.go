//line aot_arbace_repr_go_parse__init.ae:1
package aot_arbace_repr_go_parse

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_parse__init_A_Unit0__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_repr_go_parse__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_parse__init_A_const_1) }
//line :1:1
func A_arbace_repr_go_parse__init_A_Unit1__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_repr_go_parse__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_2)) }
//line :1:1
func A_arbace_repr_go_parse__init_A_Unit2__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_repr_go_parse_eval1050000004_loading__1927001464__auto____1050000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_go_parse_eval1050000004_loading__1927001464__auto____1050000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_223, false); A_arbace_repr_go_parse_eval1050000004_loading__1927001464__auto____1050000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_repr_go_parse__init_A_Unit3__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repr_go_parse__init_A_const_1)).Equals_O__Z(A_arbace_repr_go_parse__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_repr_go_parse_eval1050000008_fn__1050000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_go_parse_eval1050000008_fn__1050000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_224, false); A_arbace_repr_go_parse_eval1050000008_fn__1050000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_repr_go_parse__init_A_Load__O() any { A_arbace_repr_go_parse__init_A_Init(); jrt.StartCheck(); A_arbace_repr_go_parse__init_A_Unit0__O(); A_arbace_repr_go_parse__init_A_Unit1__O(); A_arbace_repr_go_parse__init_A_Unit2__O(); A_arbace_repr_go_parse__init_A_Unit3__O(); A_arbace_repr_go_parse__init_A_Unit4__O(); A_arbace_repr_go_parse__init_A_Unit5__O(); A_arbace_repr_go_parse__init_A_Unit6__O(); A_arbace_repr_go_parse__init_A_Unit7__O(); A_arbace_repr_go_parse__init_A_Unit8__O(); A_arbace_repr_go_parse__init_A_Unit9__O(); A_arbace_repr_go_parse__init_A_Unit10__O(); A_arbace_repr_go_parse__init_A_Unit11__O(); A_arbace_repr_go_parse__init_A_Unit12__O(); A_arbace_repr_go_parse__init_A_Unit13__O(); A_arbace_repr_go_parse__init_A_Unit14__O(); A_arbace_repr_go_parse__init_A_Unit15__O(); A_arbace_repr_go_parse__init_A_Unit16__O(); A_arbace_repr_go_parse__init_A_Unit17__O(); A_arbace_repr_go_parse__init_A_Unit18__O(); A_arbace_repr_go_parse__init_A_Unit19__O(); A_arbace_repr_go_parse__init_A_Unit20__O(); A_arbace_repr_go_parse__init_A_Unit21__O(); A_arbace_repr_go_parse__init_A_Unit22__O(); A_arbace_repr_go_parse__init_A_Unit23__O(); A_arbace_repr_go_parse__init_A_Unit24__O(); A_arbace_repr_go_parse__init_A_Unit25__O(); A_arbace_repr_go_parse__init_A_Unit26__O(); A_arbace_repr_go_parse__init_A_Unit27__O(); A_arbace_repr_go_parse__init_A_Unit28__O(); A_arbace_repr_go_parse__init_A_Unit29__O(); A_arbace_repr_go_parse__init_A_Unit30__O(); A_arbace_repr_go_parse__init_A_Unit31__O(); A_arbace_repr_go_parse__init_A_Unit32__O(); A_arbace_repr_go_parse__init_A_Unit33__O(); A_arbace_repr_go_parse__init_A_Unit34__O(); A_arbace_repr_go_parse__init_A_Unit35__O(); A_arbace_repr_go_parse__init_A_Unit36__O(); A_arbace_repr_go_parse__init_A_Unit37__O(); A_arbace_repr_go_parse__init_A_Unit38__O(); A_arbace_repr_go_parse__init_A_Unit39__O(); A_arbace_repr_go_parse__init_A_Unit40__O(); A_arbace_repr_go_parse__init_A_Unit41__O(); A_arbace_repr_go_parse__init_A_Unit42__O(); A_arbace_repr_go_parse__init_A_Unit43__O(); A_arbace_repr_go_parse__init_A_Unit44__O(); A_arbace_repr_go_parse__init_A_Unit45__O(); A_arbace_repr_go_parse__init_A_Unit46__O(); A_arbace_repr_go_parse__init_A_Unit47__O(); A_arbace_repr_go_parse__init_A_Unit48__O(); A_arbace_repr_go_parse__init_A_Unit49__O(); A_arbace_repr_go_parse__init_A_Unit50__O(); A_arbace_repr_go_parse__init_A_Unit51__O(); return nil }


































func A_arbace_repr_go_parse__init_A_Unit4__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_4; var tmp2 any = A_arbace_repr_go_parse_ast_forms_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_go_parse_ast_forms_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_225, false); A_arbace_repr_go_parse_ast_forms_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_5)); return A_arbace_repr_go_parse__init_A_const_4 }


func A_arbace_repr_go_parse__init_A_Unit5__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_6; var tmp2 any = A_arbace_repr_go_parse_type_specs_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_repr_go_parse_type_specs_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_226, false); A_arbace_repr_go_parse_type_specs_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_7)); return A_arbace_repr_go_parse__init_A_const_6 }










func A_arbace_repr_go_parse__init_A_Unit6__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(54, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_8; var tmp2 any = A_arbace_repr_go_parse_receiver_types_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_go_parse_receiver_types_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_227, false); A_arbace_repr_go_parse_receiver_types_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_9)); return A_arbace_repr_go_parse__init_A_const_8 }









func A_arbace_repr_go_parse__init_A_Unit7__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); A_arbace_repr_go_parse__init_A_const_10.BindRoot_O__V(A_arbace_repr_go_parse__init_A_const_11); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_10; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_12)); return A_arbace_repr_go_parse__init_A_const_10 }




func A_arbace_repr_go_parse__init_A_Unit8__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(69, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_13; var tmp2 any = A_arbace_repr_go_parse_kebab_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_repr_go_parse_kebab_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_228, false); A_arbace_repr_go_parse_kebab_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_14)); return A_arbace_repr_go_parse__init_A_const_13 }




func A_arbace_repr_go_parse__init_A_Unit9__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_15; var tmp2 any = A_arbace_repr_go_parse_ast_nodes_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repr_go_parse_ast_nodes_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_229, false); A_arbace_repr_go_parse_ast_nodes_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_16)); return A_arbace_repr_go_parse__init_A_const_15 }



































func A_arbace_repr_go_parse__init_A_Unit10__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(110, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_17; var tmp2 any = A_arbace_repr_go_parse_kw_var_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_repr_go_parse_kw_var_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_230, false); A_arbace_repr_go_parse_kw_var_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_18)); return A_arbace_repr_go_parse__init_A_const_17 }

func A_arbace_repr_go_parse__init_A_Unit11__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_19; var tmp2 any = A_arbace_repr_go_parse_field_stmts_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_repr_go_parse_field_stmts_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_231, false); A_arbace_repr_go_parse_field_stmts_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_20)); return A_arbace_repr_go_parse__init_A_const_19 }


























func A_arbace_repr_go_parse__init_A_Unit12__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_21; var tmp2 any = A_arbace_repr_go_parse_node_case_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_repr_go_parse_node_case_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_232, false); A_arbace_repr_go_parse_node_case_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_22)); return A_arbace_repr_go_parse__init_A_const_21 }











func A_arbace_repr_go_parse__init_A_Unit13__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(151, 1); A_arbace_repr_go_parse__init_A_const_23.BindRoot_O__V(A_arbace_repr_go_parse__init_A_const_24); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_23; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_25)); return A_arbace_repr_go_parse__init_A_const_23 }



func A_arbace_repr_go_parse__init_A_Unit14__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(155, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_26; var tmp2 any = A_arbace_repr_go_parse_dumper_forms_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_repr_go_parse_dumper_forms_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_233, false); A_arbace_repr_go_parse_dumper_forms_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_27)); return A_arbace_repr_go_parse__init_A_const_26 }




































































































































func A_arbace_repr_go_parse__init_A_Unit15__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); A_arbace_repr_go_parse__init_A_const_28.BindRoot_O__V(A_arbace_repr_go_parse__init_A_const_29); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_28; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_30)); return A_arbace_repr_go_parse__init_A_const_28 }



func A_arbace_repr_go_parse__init_A_Unit16__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(292, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_31; var tmp2 any = A_arbace_repr_go_parse_clean_meta_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_repr_go_parse_clean_meta_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_234, false); A_arbace_repr_go_parse_clean_meta_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_32)); return A_arbace_repr_go_parse__init_A_const_31 }











func A_arbace_repr_go_parse__init_A_Unit17__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(304, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_33; var tmp2 any = A_arbace_repr_go_parse_layout_text_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repr_go_parse_layout_text_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_235, false); A_arbace_repr_go_parse_layout_text_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_34)); return A_arbace_repr_go_parse__init_A_const_33 }






































func A_arbace_repr_go_parse__init_A_Unit18__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(343, 1); A_arbace_repr_go_parse__init_A_const_35.BindRoot_O__V(A_arbace_repr_go_parse__init_A_const_36); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_35; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_37)); return A_arbace_repr_go_parse__init_A_const_35 }



func A_arbace_repr_go_parse__init_A_Unit19__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(347, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_38; var tmp2 any = A_arbace_repr_go_parse_dumper_texts_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_repr_go_parse_dumper_texts_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_236, false); A_arbace_repr_go_parse_dumper_texts_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_39)); return A_arbace_repr_go_parse__init_A_const_38 }















func A_arbace_repr_go_parse__init_A_Unit20__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(363, 1); A_arbace_repr_go_parse__init_A_const_40.BindRoot_O__V(Lit_237); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_41)); return A_arbace_repr_go_parse__init_A_const_40 }

func A_arbace_repr_go_parse__init_A_Unit21__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(365, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_42; var tmp2 any; var root_15 any = A_arbace_repr_go_parse__init_A_const_43.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_15, arg_18) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_repr_go_parse__init_A_const_42; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_44)); return A_arbace_repr_go_parse__init_A_const_42 }

func A_arbace_repr_go_parse__init_A_Unit22__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(367, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_45; var tmp2 any = A_arbace_repr_go_parse_load_BANG__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_repr_go_parse_load_BANG__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_238, false); A_arbace_repr_go_parse_load_BANG__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_46)); return A_arbace_repr_go_parse__init_A_const_45 }


















func A_arbace_repr_go_parse__init_A_Unit23__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(386, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_47; var tmp2 any = A_arbace_repr_go_parse_load_text_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_repr_go_parse_load_text_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_239, false); A_arbace_repr_go_parse_load_text_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_48)); return A_arbace_repr_go_parse__init_A_const_47 }






func A_arbace_repr_go_parse__init_A_Unit24__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(393, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_49; var tmp2 any = A_arbace_repr_go_parse_go_lang_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_repr_go_parse_go_lang_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_240, false); A_arbace_repr_go_parse_go_lang_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_50)); return A_arbace_repr_go_parse__init_A_const_49 }





func A_arbace_repr_go_parse__init_A_Unit25__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(399, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_51; var tmp2 any = A_arbace_repr_go_parse_file_go_version_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_repr_go_parse_file_go_version_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_241, false); A_arbace_repr_go_parse_file_go_version_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_52)); return A_arbace_repr_go_parse__init_A_const_51 }







func A_arbace_repr_go_parse__init_A_Unit26__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(407, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_53; var tmp2 any = A_arbace_repr_go_parse_parse_file_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_repr_go_parse_parse_file_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_242, false); A_arbace_repr_go_parse_parse_file_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_54)); return A_arbace_repr_go_parse__init_A_const_53 }












func A_arbace_repr_go_parse__init_A_Unit27__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(420, 1); A_arbace_repr_go_parse__init_A_const_55.BindRoot_O__V(A_arbace_repr_go_parse__init_A_const_56); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_55; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_57)); return A_arbace_repr_go_parse__init_A_const_55 }



func A_arbace_repr_go_parse__init_A_Unit28__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(424, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_58; var tmp2 any = A_arbace_repr_go_parse_strip_meta_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_repr_go_parse_strip_meta_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_243, false); A_arbace_repr_go_parse_strip_meta_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_59)); return A_arbace_repr_go_parse__init_A_const_58 }





func A_arbace_repr_go_parse__init_A_Unit29__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(430, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_60; var tmp2 any = A_arbace_repr_go_parse_decl_forms_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_repr_go_parse_decl_forms_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_244, false); A_arbace_repr_go_parse_decl_forms_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_61)); return A_arbace_repr_go_parse__init_A_const_60 }




func A_arbace_repr_go_parse__init_A_Unit30__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(435, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_62; var tmp2 any = A_arbace_repr_go_parse_forms_check_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_repr_go_parse_forms_check_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_245, false); A_arbace_repr_go_parse_forms_check_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_63)); return A_arbace_repr_go_parse__init_A_const_62 }























func A_arbace_repr_go_parse__init_A_Unit31__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(459, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_64; var tmp2 any = A_arbace_repr_go_parse_forms_check_text_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_repr_go_parse_forms_check_text_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_246, false); A_arbace_repr_go_parse_forms_check_text_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_65)); return A_arbace_repr_go_parse__init_A_const_64 }










func A_arbace_repr_go_parse__init_A_Unit32__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(470, 1); A_arbace_repr_go_parse__init_A_const_66.BindRoot_O__V(A_arbace_repr_go_parse__init_A_const_67); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_66; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_68)); return A_arbace_repr_go_parse__init_A_const_66 }








func A_arbace_repr_go_parse__init_A_Unit33__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(479, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_69; var tmp2 any = A_arbace_repr_go_parse_native_dump_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_repr_go_parse_native_dump_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_247, false); A_arbace_repr_go_parse_native_dump_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_70)); return A_arbace_repr_go_parse__init_A_const_69 }































func A_arbace_repr_go_parse__init_A_Unit34__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(511, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_71; var tmp2 any = A_arbace_repr_go_parse_tree_of_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_repr_go_parse_tree_of_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_248, false); A_arbace_repr_go_parse_tree_of_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_72)); return A_arbace_repr_go_parse__init_A_const_71 }










func A_arbace_repr_go_parse__init_A_Unit35__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(522, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_73; var tmp2 any = A_arbace_repr_go_parse_kind_of_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_repr_go_parse_kind_of_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_249, false); A_arbace_repr_go_parse_kind_of_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_74)); return A_arbace_repr_go_parse__init_A_const_73 }











func A_arbace_repr_go_parse__init_A_Unit36__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(534, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_75; var tmp2 any = A_arbace_repr_go_parse_diff_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_repr_go_parse_diff_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_250, false); A_arbace_repr_go_parse_diff_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_76)); return A_arbace_repr_go_parse__init_A_const_75 }















func A_arbace_repr_go_parse__init_A_Unit37__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(550, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_77; var tmp2 any = A_arbace_repr_go_parse_short_str_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_repr_go_parse_short_str_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_251, false); A_arbace_repr_go_parse_short_str_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_78)); return A_arbace_repr_go_parse__init_A_const_77 }

func A_arbace_repr_go_parse__init_A_Unit38__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(552, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_79; var tmp2 any = A_arbace_repr_go_parse_file_at_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_repr_go_parse_file_at_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_252, false); A_arbace_repr_go_parse_file_at_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_80)); return A_arbace_repr_go_parse__init_A_const_79 }





func A_arbace_repr_go_parse__init_A_Unit39__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(558, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_81; var tmp2 any = A_arbace_repr_go_parse_job_keys_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_repr_go_parse_job_keys_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_253, false); A_arbace_repr_go_parse_job_keys_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_82)); return A_arbace_repr_go_parse__init_A_const_81 }

func A_arbace_repr_go_parse__init_A_Unit40__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(560, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_83; var tmp2 any = A_arbace_repr_go_parse_check_job_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_repr_go_parse_check_job_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_254, false); A_arbace_repr_go_parse_check_job_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_84)); return A_arbace_repr_go_parse__init_A_const_83 }





























func A_arbace_repr_go_parse__init_A_Unit41__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(590, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_85; var tmp2 any = A_arbace_repr_go_parse_write_native_BANG__A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_repr_go_parse_write_native_BANG__A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_255, false); A_arbace_repr_go_parse_write_native_BANG__A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_86)); return A_arbace_repr_go_parse__init_A_const_85 }










func A_arbace_repr_go_parse__init_A_Unit42__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(601, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_87; var tmp2 any = A_arbace_repr_go_parse_read_spec_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_repr_go_parse_read_spec_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_256, false); A_arbace_repr_go_parse_read_spec_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_88)); return A_arbace_repr_go_parse__init_A_const_87 }


func A_arbace_repr_go_parse__init_A_Unit43__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(604, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_89; var tmp2 any = A_arbace_repr_go_parse_spec_jobs_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_repr_go_parse_spec_jobs_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_257, false); A_arbace_repr_go_parse_spec_jobs_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_90)); return A_arbace_repr_go_parse__init_A_const_89 }









func A_arbace_repr_go_parse__init_A_Unit44__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(614, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_91; var tmp2 any = A_arbace_repr_go_parse_helper_results_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_repr_go_parse_helper_results_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_258, false); A_arbace_repr_go_parse_helper_results_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_92)); return A_arbace_repr_go_parse__init_A_const_91 }









func A_arbace_repr_go_parse__init_A_Unit45__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(624, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_93; var tmp2 any = A_arbace_repr_go_parse_helper_header_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_repr_go_parse_helper_header_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_259, false); A_arbace_repr_go_parse_helper_header_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_94)); return A_arbace_repr_go_parse__init_A_const_93 }







func A_arbace_repr_go_parse__init_A_Unit46__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(632, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_95; var tmp2 any = A_arbace_repr_go_parse_check_header_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_repr_go_parse_check_header_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_260, false); A_arbace_repr_go_parse_check_header_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_96)); return A_arbace_repr_go_parse__init_A_const_95 }












func A_arbace_repr_go_parse__init_A_Unit47__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(645, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_97; var tmp2 any = A_arbace_repr_go_parse_check_corpus_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_repr_go_parse_check_corpus_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_261, false); A_arbace_repr_go_parse_check_corpus_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_98)); return A_arbace_repr_go_parse__init_A_const_97 }





















































func A_arbace_repr_go_parse__init_A_Unit48__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(699, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_99; var tmp2 any = A_arbace_repr_go_parse_read_corpus_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_repr_go_parse_read_corpus_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_262, false); A_arbace_repr_go_parse_read_corpus_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_100)); return A_arbace_repr_go_parse__init_A_const_99 }
























func A_arbace_repr_go_parse__init_A_Unit49__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(724, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_101; var tmp2 any = A_arbace_repr_go_parse_generated_texts_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_repr_go_parse_generated_texts_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_263, false); A_arbace_repr_go_parse_generated_texts_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_102)); return A_arbace_repr_go_parse__init_A_const_101 }







func A_arbace_repr_go_parse__init_A_Unit50__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(732, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_103; var tmp2 any = A_arbace_repr_go_parse_generate_main_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_repr_go_parse_generate_main_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_264, true); A_arbace_repr_go_parse_generate_main_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_104)); return A_arbace_repr_go_parse__init_A_const_103 }

















func A_arbace_repr_go_parse__init_A_Unit51__O() any { A_arbace_repr_go_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(750, 1); var tmp1 *lang.Var = A_arbace_repr_go_parse__init_A_const_105; var tmp2 any = A_arbace_repr_go_parse__main_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_repr_go_parse__main_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_265, true); A_arbace_repr_go_parse__main_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_repr_go_parse__init_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_parse__init_A_const_106)); return A_arbace_repr_go_parse__init_A_const_105 }



type A_arbace_repr_go_parse__init_A struct{ jrt.Object }

var A_arbace_repr_go_parse__init_A_const_pool *jrt.RefArray

var A_arbace_repr_go_parse__init_A_const_0 *lang.Var

var A_arbace_repr_go_parse__init_A_const_1 any

var A_arbace_repr_go_parse__init_A_const_2 any

var A_arbace_repr_go_parse__init_A_const_3 any

var A_arbace_repr_go_parse__init_A_const_4 *lang.Var

var A_arbace_repr_go_parse__init_A_const_5 any

var A_arbace_repr_go_parse__init_A_const_6 *lang.Var

var A_arbace_repr_go_parse__init_A_const_7 any

var A_arbace_repr_go_parse__init_A_const_8 *lang.Var

var A_arbace_repr_go_parse__init_A_const_9 any

var A_arbace_repr_go_parse__init_A_const_10 *lang.Var

var A_arbace_repr_go_parse__init_A_const_11 any

var A_arbace_repr_go_parse__init_A_const_12 any

var A_arbace_repr_go_parse__init_A_const_13 *lang.Var

var A_arbace_repr_go_parse__init_A_const_14 any

var A_arbace_repr_go_parse__init_A_const_15 *lang.Var

var A_arbace_repr_go_parse__init_A_const_16 any

var A_arbace_repr_go_parse__init_A_const_17 *lang.Var

var A_arbace_repr_go_parse__init_A_const_18 any

var A_arbace_repr_go_parse__init_A_const_19 *lang.Var

var A_arbace_repr_go_parse__init_A_const_20 any

var A_arbace_repr_go_parse__init_A_const_21 *lang.Var

var A_arbace_repr_go_parse__init_A_const_22 any

var A_arbace_repr_go_parse__init_A_const_23 *lang.Var

var A_arbace_repr_go_parse__init_A_const_24 any

var A_arbace_repr_go_parse__init_A_const_25 any

var A_arbace_repr_go_parse__init_A_const_26 *lang.Var

var A_arbace_repr_go_parse__init_A_const_27 any

var A_arbace_repr_go_parse__init_A_const_28 *lang.Var

var A_arbace_repr_go_parse__init_A_const_29 any

var A_arbace_repr_go_parse__init_A_const_30 any

var A_arbace_repr_go_parse__init_A_const_31 *lang.Var

var A_arbace_repr_go_parse__init_A_const_32 any

var A_arbace_repr_go_parse__init_A_const_33 *lang.Var

var A_arbace_repr_go_parse__init_A_const_34 any

var A_arbace_repr_go_parse__init_A_const_35 *lang.Var

var A_arbace_repr_go_parse__init_A_const_36 any

var A_arbace_repr_go_parse__init_A_const_37 any

var A_arbace_repr_go_parse__init_A_const_38 *lang.Var

var A_arbace_repr_go_parse__init_A_const_39 any

var A_arbace_repr_go_parse__init_A_const_40 *lang.Var

var A_arbace_repr_go_parse__init_A_const_41 any

var A_arbace_repr_go_parse__init_A_const_42 *lang.Var

var A_arbace_repr_go_parse__init_A_const_43 *lang.Var

var A_arbace_repr_go_parse__init_A_const_44 any

var A_arbace_repr_go_parse__init_A_const_45 *lang.Var

var A_arbace_repr_go_parse__init_A_const_46 any

var A_arbace_repr_go_parse__init_A_const_47 *lang.Var

var A_arbace_repr_go_parse__init_A_const_48 any

var A_arbace_repr_go_parse__init_A_const_49 *lang.Var

var A_arbace_repr_go_parse__init_A_const_50 any

var A_arbace_repr_go_parse__init_A_const_51 *lang.Var

var A_arbace_repr_go_parse__init_A_const_52 any

var A_arbace_repr_go_parse__init_A_const_53 *lang.Var

var A_arbace_repr_go_parse__init_A_const_54 any

var A_arbace_repr_go_parse__init_A_const_55 *lang.Var

var A_arbace_repr_go_parse__init_A_const_56 any

var A_arbace_repr_go_parse__init_A_const_57 any

var A_arbace_repr_go_parse__init_A_const_58 *lang.Var

var A_arbace_repr_go_parse__init_A_const_59 any

var A_arbace_repr_go_parse__init_A_const_60 *lang.Var

var A_arbace_repr_go_parse__init_A_const_61 any

var A_arbace_repr_go_parse__init_A_const_62 *lang.Var

var A_arbace_repr_go_parse__init_A_const_63 any

var A_arbace_repr_go_parse__init_A_const_64 *lang.Var

var A_arbace_repr_go_parse__init_A_const_65 any

var A_arbace_repr_go_parse__init_A_const_66 *lang.Var

var A_arbace_repr_go_parse__init_A_const_67 any

var A_arbace_repr_go_parse__init_A_const_68 any

var A_arbace_repr_go_parse__init_A_const_69 *lang.Var

var A_arbace_repr_go_parse__init_A_const_70 any

var A_arbace_repr_go_parse__init_A_const_71 *lang.Var

var A_arbace_repr_go_parse__init_A_const_72 any

var A_arbace_repr_go_parse__init_A_const_73 *lang.Var

var A_arbace_repr_go_parse__init_A_const_74 any

var A_arbace_repr_go_parse__init_A_const_75 *lang.Var

var A_arbace_repr_go_parse__init_A_const_76 any

var A_arbace_repr_go_parse__init_A_const_77 *lang.Var

var A_arbace_repr_go_parse__init_A_const_78 any

var A_arbace_repr_go_parse__init_A_const_79 *lang.Var

var A_arbace_repr_go_parse__init_A_const_80 any

var A_arbace_repr_go_parse__init_A_const_81 *lang.Var

var A_arbace_repr_go_parse__init_A_const_82 any

var A_arbace_repr_go_parse__init_A_const_83 *lang.Var

var A_arbace_repr_go_parse__init_A_const_84 any

var A_arbace_repr_go_parse__init_A_const_85 *lang.Var

var A_arbace_repr_go_parse__init_A_const_86 any

var A_arbace_repr_go_parse__init_A_const_87 *lang.Var

var A_arbace_repr_go_parse__init_A_const_88 any

var A_arbace_repr_go_parse__init_A_const_89 *lang.Var

var A_arbace_repr_go_parse__init_A_const_90 any

var A_arbace_repr_go_parse__init_A_const_91 *lang.Var

var A_arbace_repr_go_parse__init_A_const_92 any

var A_arbace_repr_go_parse__init_A_const_93 *lang.Var

var A_arbace_repr_go_parse__init_A_const_94 any

var A_arbace_repr_go_parse__init_A_const_95 *lang.Var

var A_arbace_repr_go_parse__init_A_const_96 any

var A_arbace_repr_go_parse__init_A_const_97 *lang.Var

var A_arbace_repr_go_parse__init_A_const_98 any

var A_arbace_repr_go_parse__init_A_const_99 *lang.Var

var A_arbace_repr_go_parse__init_A_const_100 any

var A_arbace_repr_go_parse__init_A_const_101 *lang.Var

var A_arbace_repr_go_parse__init_A_const_102 any

var A_arbace_repr_go_parse__init_A_const_103 *lang.Var

var A_arbace_repr_go_parse__init_A_const_104 any

var A_arbace_repr_go_parse__init_A_const_105 *lang.Var

var A_arbace_repr_go_parse__init_A_const_106 any

var A_arbace_repr_go_parse__init_A_init jrt.ClassInit

func A_arbace_repr_go_parse__init_A_Init() { if !A_arbace_repr_go_parse__init_A_init.Done() { A_arbace_repr_go_parse__init_A_init.Run(A_arbace_repr_go_parse__init_A_clinit) } }

func A_arbace_repr_go_parse__init_A_clinit() { A_arbace_repr_go_parse__init_A_clinit_p0(); A_arbace_repr_go_parse__init_A_clinit_p1(); A_arbace_repr_go_parse__init_A_clinit_p2(); A_arbace_repr_go_parse__init_A_clinit_p3(); A_arbace_repr_go_parse__init_A_clinit_p4(); A_arbace_repr_go_parse__init_A_clinit_p5(); A_arbace_repr_go_parse__init_A_clinit_p6(); A_arbace_repr_go_parse__init_A_clinit_p7(); A_arbace_repr_go_parse__init_A_clinit_p8() }

func A_arbace_repr_go_parse__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_parse__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_222, 184); A_arbace_repr_go_parse__init_A_const_0 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[77]); A_arbace_repr_go_parse__init_A_const_1 = A_arbace_repr_go_parse__init_A_const_pool.A[78]; A_arbace_repr_go_parse__init_A_const_2 = A_arbace_repr_go_parse__init_A_const_pool.A[79]; A_arbace_repr_go_parse__init_A_const_3 = A_arbace_repr_go_parse__init_A_const_pool.A[80]; A_arbace_repr_go_parse__init_A_const_4 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[81]); A_arbace_repr_go_parse__init_A_const_5 = A_arbace_repr_go_parse__init_A_const_pool.A[82]; A_arbace_repr_go_parse__init_A_const_6 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[83]); A_arbace_repr_go_parse__init_A_const_7 = A_arbace_repr_go_parse__init_A_const_pool.A[84]; A_arbace_repr_go_parse__init_A_const_8 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[85]); A_arbace_repr_go_parse__init_A_const_9 = A_arbace_repr_go_parse__init_A_const_pool.A[86]; A_arbace_repr_go_parse__init_A_const_10 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[87]); A_arbace_repr_go_parse__init_A_const_11 = A_arbace_repr_go_parse__init_A_const_pool.A[88]; A_arbace_repr_go_parse__init_A_const_12 = A_arbace_repr_go_parse__init_A_const_pool.A[89] }

func A_arbace_repr_go_parse__init_A_clinit_p1() { A_arbace_repr_go_parse__init_A_const_13 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[90]); A_arbace_repr_go_parse__init_A_const_14 = A_arbace_repr_go_parse__init_A_const_pool.A[91]; A_arbace_repr_go_parse__init_A_const_15 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[92]); A_arbace_repr_go_parse__init_A_const_16 = A_arbace_repr_go_parse__init_A_const_pool.A[93]; A_arbace_repr_go_parse__init_A_const_17 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[94]); A_arbace_repr_go_parse__init_A_const_18 = A_arbace_repr_go_parse__init_A_const_pool.A[95]; A_arbace_repr_go_parse__init_A_const_19 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[96]); A_arbace_repr_go_parse__init_A_const_20 = A_arbace_repr_go_parse__init_A_const_pool.A[97]; A_arbace_repr_go_parse__init_A_const_21 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[98]); A_arbace_repr_go_parse__init_A_const_22 = A_arbace_repr_go_parse__init_A_const_pool.A[99]; A_arbace_repr_go_parse__init_A_const_23 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[100]); A_arbace_repr_go_parse__init_A_const_24 = A_arbace_repr_go_parse__init_A_const_pool.A[101]; A_arbace_repr_go_parse__init_A_const_25 = A_arbace_repr_go_parse__init_A_const_pool.A[102] }

func A_arbace_repr_go_parse__init_A_clinit_p2() { A_arbace_repr_go_parse__init_A_const_26 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[103]); A_arbace_repr_go_parse__init_A_const_27 = A_arbace_repr_go_parse__init_A_const_pool.A[104]; A_arbace_repr_go_parse__init_A_const_28 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[105]); A_arbace_repr_go_parse__init_A_const_29 = A_arbace_repr_go_parse__init_A_const_pool.A[106]; A_arbace_repr_go_parse__init_A_const_30 = A_arbace_repr_go_parse__init_A_const_pool.A[107]; A_arbace_repr_go_parse__init_A_const_31 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[108]); A_arbace_repr_go_parse__init_A_const_32 = A_arbace_repr_go_parse__init_A_const_pool.A[109]; A_arbace_repr_go_parse__init_A_const_33 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[110]); A_arbace_repr_go_parse__init_A_const_34 = A_arbace_repr_go_parse__init_A_const_pool.A[111]; A_arbace_repr_go_parse__init_A_const_35 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[112]); A_arbace_repr_go_parse__init_A_const_36 = A_arbace_repr_go_parse__init_A_const_pool.A[113]; A_arbace_repr_go_parse__init_A_const_37 = A_arbace_repr_go_parse__init_A_const_pool.A[114]; A_arbace_repr_go_parse__init_A_const_38 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[115]); A_arbace_repr_go_parse__init_A_const_39 = A_arbace_repr_go_parse__init_A_const_pool.A[116] }

func A_arbace_repr_go_parse__init_A_clinit_p3() { A_arbace_repr_go_parse__init_A_const_40 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[117]); A_arbace_repr_go_parse__init_A_const_41 = A_arbace_repr_go_parse__init_A_const_pool.A[118]; A_arbace_repr_go_parse__init_A_const_42 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[119]); A_arbace_repr_go_parse__init_A_const_43 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[120]); A_arbace_repr_go_parse__init_A_const_44 = A_arbace_repr_go_parse__init_A_const_pool.A[121]; A_arbace_repr_go_parse__init_A_const_45 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[122]); A_arbace_repr_go_parse__init_A_const_46 = A_arbace_repr_go_parse__init_A_const_pool.A[123]; A_arbace_repr_go_parse__init_A_const_47 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[124]); A_arbace_repr_go_parse__init_A_const_48 = A_arbace_repr_go_parse__init_A_const_pool.A[125]; A_arbace_repr_go_parse__init_A_const_49 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[126]); A_arbace_repr_go_parse__init_A_const_50 = A_arbace_repr_go_parse__init_A_const_pool.A[127]; A_arbace_repr_go_parse__init_A_const_51 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[128]); A_arbace_repr_go_parse__init_A_const_52 = A_arbace_repr_go_parse__init_A_const_pool.A[129] }

func A_arbace_repr_go_parse__init_A_clinit_p4() { A_arbace_repr_go_parse__init_A_const_53 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[130]); A_arbace_repr_go_parse__init_A_const_54 = A_arbace_repr_go_parse__init_A_const_pool.A[131]; A_arbace_repr_go_parse__init_A_const_55 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[132]); A_arbace_repr_go_parse__init_A_const_56 = A_arbace_repr_go_parse__init_A_const_pool.A[133]; A_arbace_repr_go_parse__init_A_const_57 = A_arbace_repr_go_parse__init_A_const_pool.A[134]; A_arbace_repr_go_parse__init_A_const_58 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[135]); A_arbace_repr_go_parse__init_A_const_59 = A_arbace_repr_go_parse__init_A_const_pool.A[136]; A_arbace_repr_go_parse__init_A_const_60 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[137]); A_arbace_repr_go_parse__init_A_const_61 = A_arbace_repr_go_parse__init_A_const_pool.A[138]; A_arbace_repr_go_parse__init_A_const_62 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[139]); A_arbace_repr_go_parse__init_A_const_63 = A_arbace_repr_go_parse__init_A_const_pool.A[140]; A_arbace_repr_go_parse__init_A_const_64 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[141]); A_arbace_repr_go_parse__init_A_const_65 = A_arbace_repr_go_parse__init_A_const_pool.A[142] }

func A_arbace_repr_go_parse__init_A_clinit_p5() { A_arbace_repr_go_parse__init_A_const_66 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[143]); A_arbace_repr_go_parse__init_A_const_67 = A_arbace_repr_go_parse__init_A_const_pool.A[144]; A_arbace_repr_go_parse__init_A_const_68 = A_arbace_repr_go_parse__init_A_const_pool.A[145]; A_arbace_repr_go_parse__init_A_const_69 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[146]); A_arbace_repr_go_parse__init_A_const_70 = A_arbace_repr_go_parse__init_A_const_pool.A[147]; A_arbace_repr_go_parse__init_A_const_71 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[148]); A_arbace_repr_go_parse__init_A_const_72 = A_arbace_repr_go_parse__init_A_const_pool.A[149]; A_arbace_repr_go_parse__init_A_const_73 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[150]); A_arbace_repr_go_parse__init_A_const_74 = A_arbace_repr_go_parse__init_A_const_pool.A[151]; A_arbace_repr_go_parse__init_A_const_75 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[152]); A_arbace_repr_go_parse__init_A_const_76 = A_arbace_repr_go_parse__init_A_const_pool.A[153]; A_arbace_repr_go_parse__init_A_const_77 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[154]); A_arbace_repr_go_parse__init_A_const_78 = A_arbace_repr_go_parse__init_A_const_pool.A[155] }

func A_arbace_repr_go_parse__init_A_clinit_p6() { A_arbace_repr_go_parse__init_A_const_79 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[156]); A_arbace_repr_go_parse__init_A_const_80 = A_arbace_repr_go_parse__init_A_const_pool.A[157]; A_arbace_repr_go_parse__init_A_const_81 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[158]); A_arbace_repr_go_parse__init_A_const_82 = A_arbace_repr_go_parse__init_A_const_pool.A[159]; A_arbace_repr_go_parse__init_A_const_83 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[160]); A_arbace_repr_go_parse__init_A_const_84 = A_arbace_repr_go_parse__init_A_const_pool.A[161]; A_arbace_repr_go_parse__init_A_const_85 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[162]); A_arbace_repr_go_parse__init_A_const_86 = A_arbace_repr_go_parse__init_A_const_pool.A[163]; A_arbace_repr_go_parse__init_A_const_87 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[164]); A_arbace_repr_go_parse__init_A_const_88 = A_arbace_repr_go_parse__init_A_const_pool.A[165]; A_arbace_repr_go_parse__init_A_const_89 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[166]); A_arbace_repr_go_parse__init_A_const_90 = A_arbace_repr_go_parse__init_A_const_pool.A[167]; A_arbace_repr_go_parse__init_A_const_91 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[168]) }

func A_arbace_repr_go_parse__init_A_clinit_p7() { A_arbace_repr_go_parse__init_A_const_92 = A_arbace_repr_go_parse__init_A_const_pool.A[169]; A_arbace_repr_go_parse__init_A_const_93 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[170]); A_arbace_repr_go_parse__init_A_const_94 = A_arbace_repr_go_parse__init_A_const_pool.A[171]; A_arbace_repr_go_parse__init_A_const_95 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[172]); A_arbace_repr_go_parse__init_A_const_96 = A_arbace_repr_go_parse__init_A_const_pool.A[173]; A_arbace_repr_go_parse__init_A_const_97 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[174]); A_arbace_repr_go_parse__init_A_const_98 = A_arbace_repr_go_parse__init_A_const_pool.A[175]; A_arbace_repr_go_parse__init_A_const_99 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[176]); A_arbace_repr_go_parse__init_A_const_100 = A_arbace_repr_go_parse__init_A_const_pool.A[177]; A_arbace_repr_go_parse__init_A_const_101 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[178]); A_arbace_repr_go_parse__init_A_const_102 = A_arbace_repr_go_parse__init_A_const_pool.A[179]; A_arbace_repr_go_parse__init_A_const_103 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[180]); A_arbace_repr_go_parse__init_A_const_104 = A_arbace_repr_go_parse__init_A_const_pool.A[181] }

func A_arbace_repr_go_parse__init_A_clinit_p8() { A_arbace_repr_go_parse__init_A_const_105 = lang.Var_Cast(A_arbace_repr_go_parse__init_A_const_pool.A[182]); A_arbace_repr_go_parse__init_A_const_106 = A_arbace_repr_go_parse__init_A_const_pool.A[183] }

func A_arbace_repr_go_parse__init_A_New() *A_arbace_repr_go_parse__init_A { A_arbace_repr_go_parse__init_A_Init(); t := &A_arbace_repr_go_parse__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_parse__init_A) Ctor() {}

func (t *A_arbace_repr_go_parse__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_parse__init_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_parse__init_A_class }

func (t *A_arbace_repr_go_parse__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_parse__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_parse__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_parse__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_parse__init_A); return ok }

func A_arbace_repr_go_parse__init_A_Cast(x any) *A_arbace_repr_go_parse__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_parse__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_parse__init_A_class)) }; return v }
