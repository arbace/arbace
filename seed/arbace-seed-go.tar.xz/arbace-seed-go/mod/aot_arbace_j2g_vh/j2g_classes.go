//line j2g_classes.ae:1
package aot_arbace_j2g_vh

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_j2g_vh_byte_order_arg_A_class, Name: "arbace.j2g.vh$byte_order_arg", Modifiers: 25, Simple: "byte_order_arg", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_byte_order_arg_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_class_arg_A_class, Name: "arbace.j2g.vh$class_arg", Modifiers: 25, Simple: "class_arg", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_class_arg_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_class_handles_A_class, Name: "arbace.j2g.vh$class_handles", Modifiers: 25, Simple: "class_handles", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_class_handles_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_class_handles_fn__1348000032_A_class, Name: "arbace.j2g.vh$class_handles$fn__1348000032", Modifiers: 25, Simple: "fn__1348000032", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_class_handles_fn__1348000032_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_class_handles_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_class_handles_fn__1348000044_A_class, Name: "arbace.j2g.vh$class_handles$fn__1348000044", Modifiers: 25, Simple: "fn__1348000044", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_class_handles_fn__1348000044_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_class_handles_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_class_handles_fn__1348000060_A_class, Name: "arbace.j2g.vh$class_handles$fn__1348000060", Modifiers: 25, Simple: "fn__1348000060", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_class_handles_fn__1348000060_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_class_handles_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_class_handles_fn__1348000062_A_class, Name: "arbace.j2g.vh$class_handles$fn__1348000062", Modifiers: 25, Simple: "fn__1348000062", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_class_handles_fn__1348000062_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_class_handles_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A_class, Name: "arbace.j2g.vh$eval1348000004$loading__1927001464__auto____1348000005", Modifiers: 25, Simple: "loading__1927001464__auto____1348000005", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_eval1348000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_eval1348000008_fn__1348000009_A_class, Name: "arbace.j2g.vh$eval1348000008$fn__1348000009", Modifiers: 25, Simple: "fn__1348000009", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_eval1348000008_fn__1348000009_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_eval1348000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_fence_QMARK__A_class, Name: "arbace.j2g.vh$fence_QMARK_", Modifiers: 25, Simple: "fence_QMARK_", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_fence_QMARK__A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_find_field_A_class, Name: "arbace.j2g.vh$find_field", Modifiers: 25, Simple: "find_field", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_find_field_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_find_field_fn__1348000018_A_class, Name: "arbace.j2g.vh$find_field$fn__1348000018", Modifiers: 25, Simple: "fn__1348000018", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_find_field_fn__1348000018_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_find_field_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_handle_spec_A_class, Name: "arbace.j2g.vh$handle_spec", Modifiers: 25, Simple: "handle_spec", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_handle_spec_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_class, Name: "arbace.j2g.vh$handle_spec$field_spec__1348000022", Modifiers: 25, Simple: "field_spec__1348000022", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_handle_spec_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_handles_A_class, Name: "arbace.j2g.vh$handles", Modifiers: 25, Simple: "handles", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_handles_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_class, Name: "arbace.j2g.vh$handles$iter__1348000066__1348000072", Modifiers: 25, Simple: "iter__1348000066__1348000072", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_handles_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_class, Name: "arbace.j2g.vh$handles$iter__1348000066__1348000072$fn__1348000073", Modifiers: 25, Simple: "fn__1348000073", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_class, Name: "arbace.j2g.vh$handles$iter__1348000066__1348000072$fn__1348000073$fn__1348000074", Modifiers: 25, Simple: "fn__1348000074", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_class, Name: "arbace.j2g.vh$handles$iter__1348000066__1348000072$fn__1348000073$fn__1348000082", Modifiers: 25, Simple: "fn__1348000082", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_class, Name: "arbace.j2g.vh$handles$iter__1348000066__1348000072$fn__1348000073$iter__1348000068__1348000076", Modifiers: 25, Simple: "iter__1348000068__1348000076", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_class, Name: "arbace.j2g.vh$handles$iter__1348000066__1348000072$fn__1348000073$iter__1348000068__1348000076$fn__1348000077", Modifiers: 25, Simple: "fn__1348000077", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_class, Name: "arbace.j2g.vh$handles$iter__1348000066__1348000072$fn__1348000073$iter__1348000068__1348000076$fn__1348000077$fn__1348000078", Modifiers: 25, Simple: "fn__1348000078", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_class, Name: "arbace.j2g.vh$handles$iter__1348000086__1348000090", Modifiers: 25, Simple: "iter__1348000086__1348000090", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_handles_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_class, Name: "arbace.j2g.vh$handles$iter__1348000086__1348000090$fn__1348000091", Modifiers: 25, Simple: "fn__1348000091", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_class, Name: "arbace.j2g.vh$handles$iter__1348000086__1348000090$fn__1348000091$fn__1348000092", Modifiers: 25, Simple: "fn__1348000092", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_mode_A_class, Name: "arbace.j2g.vh$mode", Modifiers: 25, Simple: "mode", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_mode_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_op_handle_A_class, Name: "arbace.j2g.vh$op_handle", Modifiers: 25, Simple: "op_handle", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_op_handle_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_static_flag_QMARK__A_class, Name: "arbace.j2g.vh$static_flag_QMARK_", Modifiers: 25, Simple: "static_flag_QMARK_", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_static_flag_QMARK__A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_j2g_vh_string_arg_A_class, Name: "arbace.j2g.vh$string_arg", Modifiers: 25, Simple: "string_arg", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_string_arg_A", Source: "vh.ae", Declaring: &A_arbace_j2g_vh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_j2g_vh_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_vh_A_New()}; return nil }

var A_arbace_j2g_vh_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_vh_A_new}

var A_arbace_j2g_vh_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.vh", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_A"})

func init() { i := A_arbace_j2g_vh_A_class.Info(); i.IsInstance = A_arbace_j2g_vh_A_InstanceOf; i.Init = A_arbace_j2g_vh_A_Init; i.Table = A_arbace_j2g_vh_A_members }

var A_arbace_j2g_vh_byte_order_arg_A_class *jrt.Class

var A_arbace_j2g_vh_class_arg_A_class *jrt.Class

var A_arbace_j2g_vh_class_handles_A_class *jrt.Class

var A_arbace_j2g_vh_class_handles_fn__1348000032_A_class *jrt.Class

var A_arbace_j2g_vh_class_handles_fn__1348000044_A_class *jrt.Class

var A_arbace_j2g_vh_class_handles_fn__1348000060_A_class *jrt.Class

var A_arbace_j2g_vh_class_handles_fn__1348000062_A_class *jrt.Class

func A_arbace_j2g_vh_eval1348000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_vh_eval1348000004_A_New()}; return nil }

var A_arbace_j2g_vh_eval1348000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_vh_eval1348000004_A_new}

var A_arbace_j2g_vh_eval1348000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.vh$eval1348000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_vh_A_class, Simple: "eval1348000004", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_eval1348000004_A"})

func init() { i := A_arbace_j2g_vh_eval1348000004_A_class.Info(); i.IsInstance = A_arbace_j2g_vh_eval1348000004_A_InstanceOf; i.Table = A_arbace_j2g_vh_eval1348000004_A_members }

var A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A_class *jrt.Class

func A_arbace_j2g_vh_eval1348000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_vh_eval1348000008_A_New()}; return nil }

var A_arbace_j2g_vh_eval1348000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_j2g_vh_eval1348000008_A_new}

var A_arbace_j2g_vh_eval1348000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.vh$eval1348000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_j2g_vh_A_class, Simple: "eval1348000008", Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh_eval1348000008_A"})

func init() { i := A_arbace_j2g_vh_eval1348000008_A_class.Info(); i.IsInstance = A_arbace_j2g_vh_eval1348000008_A_InstanceOf; i.Table = A_arbace_j2g_vh_eval1348000008_A_members }

var A_arbace_j2g_vh_eval1348000008_fn__1348000009_A_class *jrt.Class

var A_arbace_j2g_vh_fence_QMARK__A_class *jrt.Class

var A_arbace_j2g_vh_find_field_A_class *jrt.Class

var A_arbace_j2g_vh_find_field_fn__1348000018_A_class *jrt.Class

var A_arbace_j2g_vh_handle_spec_A_class *jrt.Class

var A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_class *jrt.Class

var A_arbace_j2g_vh_handles_A_class *jrt.Class

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_class *jrt.Class

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_class *jrt.Class

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_class *jrt.Class

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_class *jrt.Class

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_class *jrt.Class

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_class *jrt.Class

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_class *jrt.Class

var A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_class *jrt.Class

var A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_class *jrt.Class

var A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_class *jrt.Class

var A_arbace_j2g_vh_mode_A_class *jrt.Class

var A_arbace_j2g_vh_op_handle_A_class *jrt.Class

var A_arbace_j2g_vh_static_flag_QMARK__A_class *jrt.Class

var A_arbace_j2g_vh_string_arg_A_class *jrt.Class

func A_arbace_j2g_vh__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_j2g_vh__init_A_Load__O()}; return nil }

func A_arbace_j2g_vh__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_j2g_vh__init_A_New()}; return nil }

var A_arbace_j2g_vh__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_j2g_vh__init_A_invoke, New: A_arbace_j2g_vh__init_A_new}

var A_arbace_j2g_vh__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.j2g.vh__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_j2g_vh.A_arbace_j2g_vh__init_A", Source: "vh.ae"})

func init() { i := A_arbace_j2g_vh__init_A_class.Info(); i.IsInstance = A_arbace_j2g_vh__init_A_InstanceOf; i.Init = A_arbace_j2g_vh__init_A_Init; i.Table = A_arbace_j2g_vh__init_A_members }
