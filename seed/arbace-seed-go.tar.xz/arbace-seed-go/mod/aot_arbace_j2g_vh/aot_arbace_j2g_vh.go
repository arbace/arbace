//line aot_arbace_j2g_vh.ae:1
package aot_arbace_j2g_vh

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_access"
	"arbace/aot_arbace_j2g_reach"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A_New() *A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_vh_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_vh_A_const_7); tmp2 = lang.IFn_Cast(A_arbace_j2g_vh_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_j2g_vh_A_const_1, A_arbace_j2g_vh_A_const_2, A_arbace_j2g_vh_A_const_3, A_arbace_j2g_vh_A_const_4, A_arbace_j2g_vh_A_const_5); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_vh_eval1348000008_fn__1348000009_A_New() *A_arbace_j2g_vh_eval1348000008_fn__1348000009_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_eval1348000008_fn__1348000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_vh_eval1348000008_fn__1348000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_vh_eval1348000008_fn__1348000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_8.GetRawRoot__O()); var tmp2 any; var root_19 any = A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_j2g_vh_A_const_10; if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_19, arg_22) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_vh_A_const_11.GetRawRoot__O(), A_arbace_j2g_vh_A_const_12) }
























func A_arbace_j2g_vh_class_arg_A_New() *A_arbace_j2g_vh_class_arg_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_arg_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_j2g_vh_class_arg_A) Ctor() {}
//line :26:1
func (t *A_arbace_j2g_vh_class_arg_A) Invoke_O_O_O__O(self, node__0, env__1 any) any { var node__3 any; var root_23 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_25 lang.IFn; if



	linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = node__0; if linked_24 == nil { node__3 = ifn_25.Invoke_O__O(arg_26) } else { node__3 = linked_24.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_23, arg_26) }; var G__1348000012__4_ any = /*line :26:1*/A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__3); switch




	lang.Util_Hash_O__I_NoInit(G__1348000012__4_) >> 6 & 3 { case 0: if any(G__1348000012__4_) == any(A_arbace_j2g_vh_A_const_15) {




		var root_28 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = A_arbace_j2g_vh_A_const_17.Invoke_O__O(node__3); var arg_32 any = env__1; if linked_29 == nil { return ifn_30.Invoke_O_O__O(arg_31, arg_32) } else { return linked_29.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_28, arg_31, arg_32) } }
//line :31:1
	case 1: if any(G__1348000012__4_) == any(A_arbace_j2g_vh_A_const_18) {
		return A_arbace_j2g_vh_A_const_19.Invoke_O__O(node__3) }
//line :31:1
	case 2: if any(G__1348000012__4_) == any(A_arbace_j2g_vh_A_const_20) { var f__5 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(node__3)


		if lang.Util_Equiv_O_O__Z_NoInit(Lit_2, A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__5)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_23.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____6 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__5); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__5) }; return tmp1.Invoke_O__O(tmp2) } else { return nil } }
//line :31:1
	case 3: if any(G__1348000012__4_) == any(A_arbace_j2g_vh_A_const_24) { var tmp3 *lang.Keyword = A_arbace_j2g_vh_A_const_25; var temp__1927000414__auto____5 any = lang.RT_Get_O_O__O_NoInit(env__1, tmp3.Invoke_O__O(A_arbace_j2g_vh_A_const_26.Invoke_O__O(node__3)))



		if jrt.J2g_Truth(temp__1927000414__auto____5) { var init__6 any = temp__1927000414__auto____5; var root_33 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = init__6; var arg_37 any = env__1; if linked_34 == nil { return ifn_35.Invoke_O_O__O(arg_36, arg_37) } else { return linked_34.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_33, arg_36, arg_37) } } else { return nil } }
//line :31:1
	default:}; return nil }







func A_arbace_j2g_vh_string_arg_A_New() *A_arbace_j2g_vh_string_arg_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_string_arg_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_vh_string_arg_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_vh_string_arg_A) Invoke_O_O__O(self, node__0 any) any { var node__2 any; var root_38 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_40 lang.IFn; if
										linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = node__0; if linked_39 == nil { node__2 = ifn_40.Invoke_O__O(arg_41) } else { node__2 = linked_39.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_38, arg_41) }; var tmp1 any; var tmp2 any = A_arbace_j2g_vh_A_const_29; var and__1927000168__auto____3 bool =
										lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__2)); if and__1927000168__auto____3 { var root_42 any = A_arbace_j2g_vh_A_const_30.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = A_arbace_j2g_vh_A_const_31.Invoke_O__O(node__2); if linked_43 == nil { tmp1 = ifn_44.Invoke_O__O(arg_45) } else { tmp1 = linked_43.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_42, arg_45) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return A_arbace_j2g_vh_A_const_31.Invoke_O__O(node__2) } else { return nil } }

func A_arbace_j2g_vh_byte_order_arg_A_New() *A_arbace_j2g_vh_byte_order_arg_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_byte_order_arg_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_j2g_vh_byte_order_arg_A) Ctor() {}
//line :43:1
func (t *A_arbace_j2g_vh_byte_order_arg_A) Invoke_O_O_O__O(self, node__0, env__1 any) any { var node__3 any; var root_46 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_48 lang.IFn; if



	linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = node__0; if linked_47 == nil { node__3 = ifn_48.Invoke_O__O(arg_49) } else { node__3 = linked_47.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_46, arg_49) }; var G__1348000015__4_ any = /*line :43:1*/A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__3); switch




	lang.Util_Hash_O__I_NoInit(G__1348000015__4_) >> 0 & 1 { case 0: if any(G__1348000015__4_) == any(A_arbace_j2g_vh_A_const_20) { var f__5 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(node__3); var tmp1 any; var or__1927000174__auto____6 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__5)

		if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__5) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_1, tmp1) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_32); return tmp2.Invoke_O__O(A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__5)) } else {
//line :50:1
				return nil } }
//line :48:1
	case 1: if any(G__1348000015__4_) == any(A_arbace_j2g_vh_A_const_24) { var tmp3 *lang.Keyword = A_arbace_j2g_vh_A_const_25; var temp__1927000414__auto____5 any = lang.RT_Get_O_O__O_NoInit(env__1, tmp3.Invoke_O__O(A_arbace_j2g_vh_A_const_26.Invoke_O__O(node__3)))



		if jrt.J2g_Truth(temp__1927000414__auto____5) { var init__6 any = temp__1927000414__auto____5; var root_51 any = A_arbace_j2g_vh_A_const_33.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, A_arbace_j2g_vh_byte_order_arg_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = init__6; var arg_55 any = env__1; if linked_52 == nil { return ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { return linked_52.(*A_arbace_j2g_vh_byte_order_arg_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) } } else { return nil } }
//line :48:1
	default:}; return nil }






func A_arbace_j2g_vh_find_field_A_New() *A_arbace_j2g_vh_find_field_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_find_field_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_j2g_vh_find_field_A) Ctor() {}
//line :55:1
func (t *A_arbace_j2g_vh_find_field_A) Invoke_O_O_O__O(self, n__0, fname__1 any) any { { var c__3 any = n__0; L1: for { var temp__1927000414__auto____4 any
											var and__1927000168__auto____4 any = c__3


	if jrt.J2g_Truth(and__1927000168__auto____4) { var root_56 any = A_arbace_j2g_vh_A_const_34.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = c__3; if linked_57 == nil { temp__1927000414__auto____4 = ifn_58.Invoke_O__O(arg_59) } else { temp__1927000414__auto____4 = linked_57.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_56, arg_59) } } else { temp__1927000414__auto____4 = and__1927000168__auto____4 }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var or__1927000174__auto____6 any; var root_60 any = A_arbace_j2g_vh_A_const_35.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_62 lang.IFn
		if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var fnbody__66 any = A_arbace_j2g_vh_find_field_fn__1348000018_A_New_O(fname__1); var tmp1 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_j2g_vh_find_field_fn__1348000018_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__66); A_arbace_j2g_vh_find_field_fn__1348000018_A_fn_class = fncls__65d; tmp1 = fncls__65d } else { tmp1 = fncls__65 }; arg_63 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp1, nil); var arg_64 any = A_arbace_j2g_vh_A_const_36.Invoke_O__O(d__5); if linked_61 == nil { or__1927000174__auto____6 = ifn_62.Invoke_O_O__O(arg_63, arg_64) } else { or__1927000174__auto____6 = linked_61.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_60, arg_63, arg_64) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {
			c__3 = A_arbace_j2g_vh_A_const_37.Invoke_O__O(d__5); continue L1 } } else {
//line :59:1
				return nil } } }; /*line :55:1*/panic("j2g: unreachable") }




func A_arbace_j2g_vh_find_field_fn__1348000018_A_New_O(p0 any) *A_arbace_j2g_vh_find_field_fn__1348000018_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_find_field_fn__1348000018_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_j2g_vh_find_field_fn__1348000018_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :60:1
func (t *A_arbace_j2g_vh_find_field_fn__1348000018_A) Invoke_O_O__O(self, p1__1348000017_SHARP___1 any) any { var tmp1 any = t.F_fname; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_vh_A_const_22.Invoke_O__O(p1__1348000017_SHARP___1)) { return p1__1348000017_SHARP___1 } else { return nil } }


func A_arbace_j2g_vh_static_flag_QMARK__A_New() *A_arbace_j2g_vh_static_flag_QMARK__A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_static_flag_QMARK__A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_j2g_vh_static_flag_QMARK__A) Ctor() {}
//line :63:1
func (t *A_arbace_j2g_vh_static_flag_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var root_67 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any; var tmp1 int64; var na_71 any; var or__1927000174__auto____2 any = A_arbace_j2g_vh_A_const_39.Invoke_O__O(f__0); if jrt.J2g_Truth(or__1927000174__auto____2) { na_71 = or__1927000174__auto____2 } else { na_71 = A_arbace_j2g_vh_A_const_40 }; var na_72 int64 = 8; if jrt.Long_InstanceOf(na_71) { var n0_73 int64 = jrt.NN(jrt.Long_Cast(na_71)).LongValue__J(); var n1_74 int64 = na_72; tmp1 = n0_73 & n1_74 } else { tmp1 = lang.Numbers_And_O_J__J_NoInit(na_71, na_72) }; arg_70 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_68 == nil { return ifn_69.Invoke_O__O(arg_70) } else { return linked_68.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_67, arg_70) } }

func A_arbace_j2g_vh_handle_spec_A_New() *A_arbace_j2g_vh_handle_spec_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handle_spec_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_j2g_vh_handle_spec_A) Ctor() {}
//line :65:1
func (t *A_arbace_j2g_vh_handle_spec_A) Invoke_O_O_O_O__O(self, n__0, init__1, env__2 any) any { var init__4 any; var root_76 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_78 lang.IFn; if




	linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = init__1; if linked_77 == nil { init__4 = ifn_78.Invoke_O__O(arg_79) } else { init__4 = linked_77.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_76, arg_79) }; var field_spec__5 any; var fnbody__102 any = /*line :65:1*/A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_New(); var tmp1 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_fn_class; if





	fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, nil); A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_fn_class = fncls__101d; tmp1 = fncls__101d } else { tmp1 = fncls__101 }; field_spec__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp1, nil); var tmp2 any = A_arbace_j2g_vh_A_const_47; if





	lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(init__4)) { var map__1348000024__6 any = init__4; var map__1348000024__7 any
		if lang.ISeq_InstanceOf(map__1348000024__6) { var tmp3 any; var root_103 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = map__1348000024__6; if linked_104 == nil { tmp3 = ifn_105.Invoke_O__O(arg_106) } else { tmp3 = linked_104.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_103, arg_106) }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_107 any = A_arbace_j2g_vh_A_const_49.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = map__1348000024__6; if linked_108 == nil { tmp4 = ifn_109.Invoke_O__O(arg_110) } else { tmp4 = linked_108.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_107, arg_110) }; map__1348000024__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp4)).Ref() } else { var tmp5 any; var root_111 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = map__1348000024__6; if linked_112 == nil { tmp5 = ifn_113.Invoke_O__O(arg_114) } else { tmp5 = linked_112.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_111, arg_114) }; if jrt.J2g_Truth(tmp5) { var root_115 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = map__1348000024__6; if linked_116 == nil { map__1348000024__7 = ifn_117.Invoke_O__O(arg_118) } else { map__1348000024__7 = linked_116.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_115, arg_118) } } else { map__1348000024__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1348000024__7 = map__1348000024__6 }
//line :77:1
		var owner__8 any = lang.RT_Get_O_O__O_NoInit(map__1348000024__7, A_arbace_j2g_vh_A_const_28); var name__9 any = lang.RT_Get_O_O__O_NoInit(map__1348000024__7, A_arbace_j2g_vh_A_const_22); var args__10 any = lang.RT_Get_O_O__O_NoInit(map__1348000024__7, A_arbace_j2g_vh_A_const_52); var kind__11 any = lang.RT_Get_O_O__O_NoInit(map__1348000024__7, A_arbace_j2g_vh_A_const_46); var tmp6 bool; var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, Lit_9)


		if and__1927000168__auto____12 { var and__1927000168__auto____13 bool = lang.Util_Equiv_O_O__Z_NoInit(name__9, Lit_10); if and__1927000168__auto____13 { tmp6 = lang.Util_Equiv_J_J__Z_NoInit(3, int64(lang.RT_Count_O__I_NoInit(args__10))) } else { tmp6 = and__1927000168__auto____13 } } else { tmp6 = and__1927000168__auto____12 }
//line :79:1
		if tmp6 {

			var tmp7 lang.IFn = lang.IFn_Cast(field_spec__5); var tmp8 any; var root_165 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(0)); var arg_169 any = env__2; if linked_166 == nil { tmp8 = ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { tmp8 = linked_166.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_165, arg_168, arg_169) }; var tmp9 any = tmp8; var tmp10 any; var root_170 any = A_arbace_j2g_vh_A_const_67.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, A_arbace_j2g_vh_string_arg_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(1)); if linked_171 == nil { tmp10 = ifn_172.Invoke_O__O(arg_173) } else { tmp10 = linked_171.(*A_arbace_j2g_vh_string_arg_A).Invoke_O_O__O(root_170, arg_173) }; var tmp11 any = tmp10; var tmp12 any; var root_174 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(2)); var arg_178 any = env__2; if linked_175 == nil { tmp12 = ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { tmp12 = linked_175.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_174, arg_177, arg_178) }; return tmp7.Invoke_O_O_O__O(tmp9, tmp11, tmp12) } else {
//line :79:1
				var tmp13 bool; var and__1927000168__auto____12_2 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, Lit_11)



				if and__1927000168__auto____12_2 { var and__1927000168__auto____13_2 bool = lang.Util_Equiv_O_O__Z_NoInit(name__9, Lit_10); if and__1927000168__auto____13_2 { tmp13 = lang.Util_Equiv_O_O__Z_NoInit(kind__11, A_arbace_j2g_vh_A_const_53) } else { tmp13 = and__1927000168__auto____13_2 } } else { tmp13 = and__1927000168__auto____12_2 }
//line :79:1
				if tmp13 { var G__1348000026__12_ int32 = lang.RT_Count_O__I_NoInit(args__10)




					switch G__1348000026__12_ { case 3:

						var tmp14 lang.IFn = lang.IFn_Cast(field_spec__5); var tmp15 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil, Lit_13), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(); var tmp16 any; var root_179 any = A_arbace_j2g_vh_A_const_67.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, A_arbace_j2g_vh_string_arg_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(1)); if linked_180 == nil { tmp16 = ifn_181.Invoke_O__O(arg_182) } else { tmp16 = linked_180.(*A_arbace_j2g_vh_string_arg_A).Invoke_O_O__O(root_179, arg_182) }; var tmp17 any = tmp16; var tmp18 any; var root_183 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(2)); var arg_187 any = env__2; if linked_184 == nil { tmp18 = ifn_185.Invoke_O_O__O(arg_186, arg_187) } else { tmp18 = linked_184.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_183, arg_186, arg_187) }; return tmp14.Invoke_O_O_O__O(tmp15, tmp17, tmp18)
//line :84:1
					case 4:


						var tmp19 lang.IFn = lang.IFn_Cast(field_spec__5); var tmp20 any; var root_188 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(1)); var arg_192 any = env__2; if linked_189 == nil { tmp20 = ifn_190.Invoke_O_O__O(arg_191, arg_192) } else { tmp20 = linked_189.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_188, arg_191, arg_192) }; var tmp21 any = tmp20; var tmp22 any; var root_193 any = A_arbace_j2g_vh_A_const_67.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, A_arbace_j2g_vh_string_arg_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(2)); if linked_194 == nil { tmp22 = ifn_195.Invoke_O__O(arg_196) } else { tmp22 = linked_194.(*A_arbace_j2g_vh_string_arg_A).Invoke_O_O__O(root_193, arg_196) }; var tmp23 any = tmp22; var tmp24 any; var root_197 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(3)); var arg_201 any = env__2; if linked_198 == nil { tmp24 = ifn_199.Invoke_O_O__O(arg_200, arg_201) } else { tmp24 = linked_198.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_197, arg_200, arg_201) }; return tmp19.Invoke_O_O_O__O(tmp21, tmp23, tmp24)
//line :84:1
					default:}; return nil } else {
//line :79:1
						var tmp25 bool; var and__1927000168__auto____12_3 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, Lit_14)










						if and__1927000168__auto____12_3 { var and__1927000168__auto____13_3 bool = lang.Util_Equiv_O_O__Z_NoInit(name__9, Lit_15); if and__1927000168__auto____13_3 { var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(kind__11, A_arbace_j2g_vh_A_const_53); if and__1927000168__auto____14 {
							tmp25 = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(args__10))) } else {
//line :90:1
								tmp25 = and__1927000168__auto____14 } } else { tmp25 = and__1927000168__auto____13_3 } } else { tmp25 = and__1927000168__auto____12_3 }
//line :79:1
						if tmp25 { var d__12 any; var root_120 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_122 lang.IFn












							if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any; var root_125 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = args__10; if linked_126 == nil { arg_123 = ifn_127.Invoke_O__O(arg_128) } else { arg_123 = linked_126.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_125, arg_128) }; var arg_124 any = env__2; if linked_121 == nil { d__12 = ifn_122.Invoke_O_O__O(arg_123, arg_124) } else { d__12 = linked_121.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_120, arg_123, arg_124) }
							var tmp26 any; var and__1927000168__auto____13_4 any = d__12; if jrt.J2g_Truth(and__1927000168__auto____13_4) { var root_129 any = A_arbace_j2g_vh_A_const_54.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = d__12; if linked_130 == nil { tmp26 = ifn_131.Invoke_O__O(arg_132) } else { tmp26 = linked_130.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_129, arg_132) } } else { tmp26 = and__1927000168__auto____13_4 }; if jrt.J2g_Truth(tmp26) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_vh_A_const_46, A_arbace_j2g_vh_A_const_55, A_arbace_j2g_vh_A_const_44, d__12)) } else { return nil } } else {
//line :79:1
								var tmp27 bool; var and__1927000168__auto____12_4 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, Lit_14)



















								if and__1927000168__auto____12_4 { var and__1927000168__auto____13_5 bool = lang.Util_Equiv_O_O__Z_NoInit(name__9, Lit_16); if and__1927000168__auto____13_5 { var and__1927000168__auto____14_2 bool = lang.Util_Equiv_O_O__Z_NoInit(kind__11, A_arbace_j2g_vh_A_const_53); if and__1927000168__auto____14_2 {
									tmp27 = lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(args__10))) } else {
//line :99:1
										tmp27 = and__1927000168__auto____14_2 } } else { tmp27 = and__1927000168__auto____13_5 } } else { tmp27 = and__1927000168__auto____12_4 }
//line :79:1
								if tmp27 { var d__12_2 any; var root_133 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_135 lang.IFn





















									if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any; var root_138 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = args__10; if linked_139 == nil { arg_136 = ifn_140.Invoke_O__O(arg_141) } else { arg_136 = linked_139.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_138, arg_141) }; var arg_137 any = env__2; if linked_134 == nil { d__12_2 = ifn_135.Invoke_O_O__O(arg_136, arg_137) } else { d__12_2 = linked_134.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_133, arg_136, arg_137) }
//line :79:1
									var o__13 any; var root_142 any = A_arbace_j2g_vh_A_const_33.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_j2g_vh_byte_order_arg_A_fn_class); var ifn_144 lang.IFn






















									if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any; var root_147 any = A_arbace_j2g_vh_A_const_56.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_149 lang.IFn; if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = args__10; if linked_148 == nil { arg_145 = ifn_149.Invoke_O__O(arg_150) } else { arg_145 = linked_148.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_147, arg_150) }; var arg_146 any = env__2; if linked_143 == nil { o__13 = ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { o__13 = linked_143.(*A_arbace_j2g_vh_byte_order_arg_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) }
									var tmp28 any; var and__1927000168__auto____14_3 any = lang.IFn_Cast(A_arbace_j2g_vh_A_const_57).Invoke_O__O(d__12_2); if jrt.J2g_Truth(and__1927000168__auto____14_3) { tmp28 = o__13 } else { tmp28 = and__1927000168__auto____14_3 }; if jrt.J2g_Truth(tmp28) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_vh_A_const_46, A_arbace_j2g_vh_A_const_58, A_arbace_j2g_vh_A_const_44, d__12_2, A_arbace_j2g_vh_A_const_59, o__13)) } else { return nil } } else {
//line :79:1
										var tmp29 any; var and__1927000168__auto____12_5 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, A_arbace_j2g_vh_A_const_60.GetRawRoot__O())

























										if and__1927000168__auto____12_5 { var and__1927000168__auto____13_6 any = lang.IFn_Cast(A_arbace_j2g_vh_A_const_61).Invoke_O__O(name__9); if jrt.J2g_Truth(and__1927000168__auto____13_6) { var and__1927000168__auto____14_4 any; var root_151 any = A_arbace_j2g_vh_A_const_62.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = args__10; if linked_152 == nil { and__1927000168__auto____14_4 = ifn_153.Invoke_O__O(arg_154) } else { and__1927000168__auto____14_4 = linked_152.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_151, arg_154) }; if jrt.J2g_Truth(and__1927000168__auto____14_4) {
											var root_155 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = A_arbace_j2g_vh_A_const_64.Invoke_O__O(init__4); if linked_156 == nil { tmp29 = ifn_157.Invoke_O__O(arg_158) } else { tmp29 = linked_156.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_155, arg_158) } } else {
//line :105:1
												tmp29 = and__1927000168__auto____14_4 } } else { tmp29 = and__1927000168__auto____13_6 } } else { tmp29 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12_5).Ref() }
//line :79:1
										if jrt.J2g_Truth(tmp29) {



























											var root_159 any = A_arbace_j2g_vh_A_const_65.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, A_arbace_j2g_vh_handle_spec_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = n__0; var arg_163 any = A_arbace_j2g_vh_A_const_64.Invoke_O__O(init__4); var arg_164 any = env__2; if linked_160 == nil { return ifn_161.Invoke_O_O_O__O(arg_162, arg_163, arg_164) } else { return linked_160.(*A_arbace_j2g_vh_handle_spec_A).Invoke_O_O_O_O__O(root_159, arg_162, arg_163, arg_164) } } else {
//line :79:1
												if A_arbace_j2g_vh_A_const_66 != nil { return nil } else { return nil } } } } } } } else {
//line :77:1
													return nil } }
//line :71:1
func A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_New() *A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A) Ctor() {}
//line :71:1
func (t *A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A) Invoke_O_O_O_O__O(self, c__1, fname__2, tdesc__3 any) any {
	var tmp1 any; var and__1927000168__auto____4 any = c__1; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = fname__2; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = tdesc__3; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_80 any = A_arbace_j2g_vh_A_const_41.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = c__1; if linked_81 == nil { tmp1 = ifn_82.Invoke_O__O(arg_83) } else { tmp1 = linked_81.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_80, arg_83) } } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { var cn__4 any; var root_84 any = A_arbace_j2g_vh_A_const_42.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_86 lang.IFn
		if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = c__1; if linked_85 == nil { cn__4 = ifn_86.Invoke_O__O(arg_87) } else { cn__4 = linked_85.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_84, arg_87) }
//line :72:1
		var f__5 any; var root_88 any = A_arbace_j2g_vh_A_const_43.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, A_arbace_j2g_vh_find_field_A_fn_class); var ifn_90 lang.IFn

		if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = cn__4; var arg_92 any = fname__2; if linked_89 == nil { f__5 = ifn_90.Invoke_O_O__O(arg_91, arg_92) } else { f__5 = linked_89.(*A_arbace_j2g_vh_find_field_A).Invoke_O_O_O__O(root_88, arg_91, arg_92) }
		var tmp2 any; var and__1927000168__auto____6_2 any = f__5; if jrt.J2g_Truth(and__1927000168__auto____6_2) { var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tdesc__3, A_arbace_j2g_vh_A_const_44.Invoke_O__O(f__5)); if and__1927000168__auto____7 { var root_93 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any; var root_97 any = A_arbace_j2g_vh_A_const_45.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, A_arbace_j2g_vh_static_flag_QMARK__A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = f__5; if linked_98 == nil { arg_96 = ifn_99.Invoke_O__O(arg_100) } else { arg_96 = linked_98.(*A_arbace_j2g_vh_static_flag_QMARK__A).Invoke_O_O__O(root_97, arg_100) }; if linked_94 == nil { tmp2 = ifn_95.Invoke_O__O(arg_96) } else { tmp2 = linked_94.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_93, arg_96) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp2 = and__1927000168__auto____6_2 }; if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_j2g_vh_A_const_46; var tmp4 any = A_arbace_j2g_vh_A_const_21; var tmp5 any = A_arbace_j2g_vh_A_const_19; var tmp6 any; var or__1927000174__auto____6 any = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__5)
			if jrt.J2g_Truth(or__1927000174__auto____6) { tmp6 = or__1927000174__auto____6 } else { tmp6 = cn__4 }
//line :75:1
			return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, A_arbace_j2g_vh_A_const_22, fname__2, A_arbace_j2g_vh_A_const_44, tdesc__3, A_arbace_j2g_vh_A_const_21, f__5)) } else { return nil } } else {
//line :72:1
				return nil
			}
}




































func A_arbace_j2g_vh_class_handles_A_New() *A_arbace_j2g_vh_class_handles_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_j2g_vh_class_handles_A) Ctor() {}
//line :111:1
func (t *A_arbace_j2g_vh_class_handles_A) Invoke_O_O__O(self, n__0 any) any { var st__2 any; var root_202 any = A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_204 lang.IFn; if


	linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any; var tmp1 *lang.Keyword = A_arbace_j2g_vh_A_const_68; var tmp2 any; var root_206 any = A_arbace_j2g_vh_A_const_34.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = n__0; if linked_207 == nil { tmp2 = ifn_208.Invoke_O__O(arg_209) } else { tmp2 = linked_207.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_206, arg_209) }; arg_205 = tmp1.Invoke_O__O(tmp2); if linked_203 == nil { st__2 = ifn_204.Invoke_O__O(arg_205) } else { st__2 = linked_203.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_202, arg_205) }; var code__3 any = /*line :111:1*/A_arbace_j2g_vh_A_const_69.Invoke_O__O(st__2); var env__4 any; var root_210 any = A_arbace_j2g_vh_A_const_70.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_212 lang.IFn; if




	linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_211 == nil { env__4 = ifn_212.Invoke_O__O(arg_213) } else { env__4 = linked_211.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_210, arg_213) }; var out__5 any; var root_214 any = /*line :111:1*/A_arbace_j2g_vh_A_const_70.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_216 lang.IFn; if





	linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_215 == nil { out__5 = ifn_216.Invoke_O__O(arg_217) } else { out__5 = linked_215.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_214, arg_217) }; var seq_1348000028__6 any; var root_222 any = /*line :111:1*/A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_224 lang.IFn; if






	linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = code__3; if linked_223 == nil { seq_1348000028__6 = ifn_224.Invoke_O__O(arg_225) } else { seq_1348000028__6 = linked_223.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_222, arg_225) }; var chunk_1348000029__7 any; var count_1348000030__8 int64 = 0; var i_1348000031__9 int64 = 0; L1:
//line :111:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1348000031__9, count_1348000030__8) { var nd__10 any = lang.Indexed_Cast(chunk_1348000029__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1348000031__9)); var root_262 any = A_arbace_j2g_vh_A_const_73.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A_fn_class); var ifn_264 lang.IFn
			if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any; var fnbody__330 any = A_arbace_j2g_vh_class_handles_fn__1348000032_A_New_O(env__4); var tmp3 *jrt.Class; var fncls__329 *jrt.Class = A_arbace_j2g_vh_class_handles_fn__1348000032_A_fn_class; if fncls__329 == nil { var fncls__329d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, fnbody__330); A_arbace_j2g_vh_class_handles_fn__1348000032_A_fn_class = fncls__329d; tmp3 = fncls__329d } else { tmp3 = fncls__329 }; arg_265 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__330, tmp3, nil); var arg_266 any = nd__10; if linked_263 == nil { ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { linked_263.(*aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A).Invoke_O_O_O__O(root_262, arg_265, arg_266) }
//line :118:1
			seq_1348000028__6, chunk_1348000029__7, count_1348000030__8, i_1348000031__9 = seq_1348000028__6, chunk_1348000029__7, count_1348000030__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000031__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_226 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = seq_1348000028__6; if linked_227 == nil { temp__1927000414__auto____10 = ifn_228.Invoke_O__O(arg_229) } else { temp__1927000414__auto____10 = linked_227.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_226, arg_229) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1348000028__11 any = temp__1927000414__auto____10; var tmp4 any; var root_230 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = seq_1348000028__11; if linked_231 == nil { tmp4 = ifn_232.Invoke_O__O(arg_233) } else { tmp4 = linked_231.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_230, arg_233) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____12 any; var root_234 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = seq_1348000028__11; if linked_235 == nil { c__1927000678__auto____12 = ifn_236.Invoke_O__O(arg_237) } else { c__1927000678__auto____12 = linked_235.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_234, arg_237) }; var tmp5 any; var root_331 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = seq_1348000028__11; if linked_332 == nil { tmp5 = ifn_333.Invoke_O__O(arg_334) } else { tmp5 = linked_332.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_331, arg_334) }; seq_1348000028__6, chunk_1348000029__7, count_1348000030__8, i_1348000031__9 = tmp5, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var nd__12 any; var root_238 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = seq_1348000028__11; if linked_239 == nil { nd__12 = ifn_240.Invoke_O__O(arg_241) } else { nd__12 = linked_239.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_238, arg_241) }
				var root_335 any = A_arbace_j2g_vh_A_const_73.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A_fn_class); var ifn_337 lang.IFn; if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any; var fnbody__403 any = A_arbace_j2g_vh_class_handles_fn__1348000044_A_New_O(env__4); var tmp6 *jrt.Class; var fncls__402 *jrt.Class = A_arbace_j2g_vh_class_handles_fn__1348000044_A_fn_class; if fncls__402 == nil { var fncls__402d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, fnbody__403); A_arbace_j2g_vh_class_handles_fn__1348000044_A_fn_class = fncls__402d; tmp6 = fncls__402d } else { tmp6 = fncls__402 }; arg_338 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__403, tmp6, nil); var arg_339 any = nd__12; if linked_336 == nil { ifn_337.Invoke_O_O__O(arg_338, arg_339) } else { linked_336.(*aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A).Invoke_O_O_O__O(root_335, arg_338, arg_339) }
//line :118:1
				var tmp7 any; var root_404 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = seq_1348000028__11; if linked_405 == nil { tmp7 = ifn_406.Invoke_O__O(arg_407) } else { tmp7 = linked_405.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_404, arg_407) }; seq_1348000028__6, chunk_1348000029__7, count_1348000030__8, i_1348000031__9 = tmp7, nil, 0, 0; continue L1 } } }
//line :111:1
		break L1 }; var seq_1348000056__6 any; var root_242 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_244 lang.IFn; if












	linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = code__3; if linked_243 == nil { seq_1348000056__6 = ifn_244.Invoke_O__O(arg_245) } else { seq_1348000056__6 = linked_243.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_242, arg_245) }; var chunk_1348000057__7 any; var count_1348000058__8 int64 = 0; var i_1348000059__9 int64 = 0; L2:
//line :111:1
	for {












		if lang.Numbers_Lt_J_J__Z_NoInit(i_1348000059__9, count_1348000058__8) { var nd__10_2 any = lang.Indexed_Cast(chunk_1348000057__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1348000059__9)); var root_408 any = A_arbace_j2g_vh_A_const_73.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A_fn_class); var ifn_410 lang.IFn
			if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any; var fnbody__431 any = A_arbace_j2g_vh_class_handles_fn__1348000060_A_New_O_O_O(env__4, out__5, n__0); var tmp8 *jrt.Class; var fncls__430 *jrt.Class = A_arbace_j2g_vh_class_handles_fn__1348000060_A_fn_class; if fncls__430 == nil { var fncls__430d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__431); A_arbace_j2g_vh_class_handles_fn__1348000060_A_fn_class = fncls__430d; tmp8 = fncls__430d } else { tmp8 = fncls__430 }; arg_411 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__431, tmp8, nil); var arg_412 any = nd__10_2; if linked_409 == nil { ifn_410.Invoke_O_O__O(arg_411, arg_412) } else { linked_409.(*aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A).Invoke_O_O_O__O(root_408, arg_411, arg_412) }
//line :124:1
			seq_1348000056__6, chunk_1348000057__7, count_1348000058__8, i_1348000059__9 = seq_1348000056__6, chunk_1348000057__7, count_1348000058__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000059__9); continue L2 } else { var temp__1927000414__auto____10_2 any; var root_246 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = seq_1348000056__6; if linked_247 == nil { temp__1927000414__auto____10_2 = ifn_248.Invoke_O__O(arg_249) } else { temp__1927000414__auto____10_2 = linked_247.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_246, arg_249) }; if jrt.J2g_Truth(temp__1927000414__auto____10_2) { var seq_1348000056__11 any = temp__1927000414__auto____10_2; var tmp9 any; var root_250 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = seq_1348000056__11; if linked_251 == nil { tmp9 = ifn_252.Invoke_O__O(arg_253) } else { tmp9 = linked_251.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____12_2 any; var root_254 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1348000056__11; if linked_255 == nil { c__1927000678__auto____12_2 = ifn_256.Invoke_O__O(arg_257) } else { c__1927000678__auto____12_2 = linked_255.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_254, arg_257) }; var tmp10 any; var root_432 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = seq_1348000056__11; if linked_433 == nil { tmp10 = ifn_434.Invoke_O__O(arg_435) } else { tmp10 = linked_433.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_432, arg_435) }; seq_1348000056__6, chunk_1348000057__7, count_1348000058__8, i_1348000059__9 = tmp10, c__1927000678__auto____12_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var nd__12_2 any; var root_258 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = seq_1348000056__11; if linked_259 == nil { nd__12_2 = ifn_260.Invoke_O__O(arg_261) } else { nd__12_2 = linked_259.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_258, arg_261) }
				var root_436 any = A_arbace_j2g_vh_A_const_73.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any; var fnbody__459 any = A_arbace_j2g_vh_class_handles_fn__1348000062_A_New_O_O_O(env__4, out__5, n__0); var tmp11 *jrt.Class; var fncls__458 *jrt.Class = A_arbace_j2g_vh_class_handles_fn__1348000062_A_fn_class; if fncls__458 == nil { var fncls__458d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__459); A_arbace_j2g_vh_class_handles_fn__1348000062_A_fn_class = fncls__458d; tmp11 = fncls__458d } else { tmp11 = fncls__458 }; arg_439 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__459, tmp11, nil); var arg_440 any = nd__12_2; if linked_437 == nil { ifn_438.Invoke_O_O__O(arg_439, arg_440) } else { linked_437.(*aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A).Invoke_O_O_O__O(root_436, arg_439, arg_440) }
//line :124:1
				var tmp12 any; var root_460 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = seq_1348000056__11; if linked_461 == nil { tmp12 = ifn_462.Invoke_O__O(arg_463) } else { tmp12 = linked_461.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_460, arg_463) }; seq_1348000056__6, chunk_1348000057__7, count_1348000058__8, i_1348000059__9 = tmp12, nil, 0, 0; continue L2 } } }
//line :111:1
		break L2 }; var root_218 any =


	A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = out__5; if linked_219 == nil { return ifn_220.Invoke_O__O(arg_221) } else { return linked_219.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_218, arg_221) } }




func A_arbace_j2g_vh_class_handles_fn__1348000032_A_New_O(p0 any) *A_arbace_j2g_vh_class_handles_fn__1348000032_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_fn__1348000032_A{}; t.Ctor_O(p0); return t }
//line :119:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000032_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :119:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000032_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_74); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_j2g_vh_A_const_14.Invoke_O__O(x__1))) { var seq_1348000033__2 any; var root_267 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_269 lang.IFn
		if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = A_arbace_j2g_vh_A_const_75.Invoke_O__O(x__1); if linked_268 == nil { seq_1348000033__2 = ifn_269.Invoke_O__O(arg_270) } else { seq_1348000033__2 = linked_268.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_267, arg_270) }
//line :120:1
		var chunk_1348000034__3 any; var count_1348000035__4 int64 = 0; var i_1348000036__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1348000036__5, count_1348000035__4) { var vec__1348000037__6 any = lang.Indexed_Cast(chunk_1348000034__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1348000036__5)); var b__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000037__6, lang.RT_IntCast_J__I_NoInit(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000037__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var and__1927000168__auto____9 any; var root_271 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = b__7; if linked_272 == nil { and__1927000168__auto____9 = ifn_273.Invoke_O__O(arg_274) } else { and__1927000168__auto____9 = linked_272.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_271, arg_274) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_275 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = A_arbace_j2g_vh_A_const_76.Invoke_O__O(b__7); if linked_276 == nil { tmp2 = ifn_277.Invoke_O__O(arg_278) } else { tmp2 = linked_276.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_275, arg_278) } } else { tmp2 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp2) {
				var root_303 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_303, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_305 lang.IFn; if linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = t.F_env; var arg_307 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_308 any = A_arbace_j2g_vh_A_const_25.Invoke_O__O(b__7); var arg_309 any = init__8; if linked_304 == nil { ifn_305.Invoke_O_O_O_O__O(arg_306, arg_307, arg_308, arg_309) } else { linked_304.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_303, arg_306, arg_307, arg_308, arg_309) }
//line :121:1
				seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000036__5); continue L1 } else { seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000036__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_279 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = seq_1348000033__2; if linked_280 == nil { temp__1927000414__auto____6 = ifn_281.Invoke_O__O(arg_282) } else { temp__1927000414__auto____6 = linked_280.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_279, arg_282) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1348000033__7 any = temp__1927000414__auto____6; var tmp3 any; var root_283 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = seq_1348000033__7; if linked_284 == nil { tmp3 = ifn_285.Invoke_O__O(arg_286) } else { tmp3 = linked_284.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_283, arg_286) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_287 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = seq_1348000033__7; if linked_288 == nil { c__1927000678__auto____8 = ifn_289.Invoke_O__O(arg_290) } else { c__1927000678__auto____8 = linked_288.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_287, arg_290) }; var tmp4 any; var root_310 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = seq_1348000033__7; if linked_311 == nil { tmp4 = ifn_312.Invoke_O__O(arg_313) } else { tmp4 = linked_311.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_310, arg_313) }; seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1348000040__8 any; var root_291 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = seq_1348000033__7; if linked_292 == nil { vec__1348000040__8 = ifn_293.Invoke_O__O(arg_294) } else { vec__1348000040__8 = linked_292.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_291, arg_294) }; var b__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000040__8, lang.RT_IntCast_J__I_NoInit(0), nil); var init__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000040__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var and__1927000168__auto____11 any; var root_295 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = b__9; if linked_296 == nil { and__1927000168__auto____11 = ifn_297.Invoke_O__O(arg_298) } else { and__1927000168__auto____11 = linked_296.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_295, arg_298) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_299 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = A_arbace_j2g_vh_A_const_76.Invoke_O__O(b__9); if linked_300 == nil { tmp5 = ifn_301.Invoke_O__O(arg_302) } else { tmp5 = linked_300.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_299, arg_302) } } else { tmp5 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp5) {
					var root_314 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = t.F_env; var arg_318 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_319 any = A_arbace_j2g_vh_A_const_25.Invoke_O__O(b__9); var arg_320 any = init__10; if linked_315 == nil { ifn_316.Invoke_O_O_O_O__O(arg_317, arg_318, arg_319, arg_320) } else { linked_315.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_314, arg_317, arg_318, arg_319, arg_320) }
//line :121:1
					var tmp6 any; var root_321 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = seq_1348000033__7; if linked_322 == nil { tmp6 = ifn_323.Invoke_O__O(arg_324) } else { tmp6 = linked_322.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_321, arg_324) }; seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_325 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = seq_1348000033__7; if linked_326 == nil { tmp7 = ifn_327.Invoke_O__O(arg_328) } else { tmp7 = linked_326.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_325, arg_328) }; seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :120:1
						return nil } }
//line :119:1
	panic("j2g: unreachable") }
//line :119:1
func A_arbace_j2g_vh_class_handles_fn__1348000044_A_New_O(p0 any) *A_arbace_j2g_vh_class_handles_fn__1348000044_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_fn__1348000044_A{}; t.Ctor_O(p0); return t }
//line :119:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000044_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :119:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000044_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_80); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_j2g_vh_A_const_14.Invoke_O__O(x__1))) { var seq_1348000045__2 any; var root_340 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_342 lang.IFn
		if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = A_arbace_j2g_vh_A_const_75.Invoke_O__O(x__1); if linked_341 == nil { seq_1348000045__2 = ifn_342.Invoke_O__O(arg_343) } else { seq_1348000045__2 = linked_341.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_340, arg_343) }
//line :120:1
		var chunk_1348000046__3 any; var count_1348000047__4 int64 = 0; var i_1348000048__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1348000048__5, count_1348000047__4) { var vec__1348000049__6 any = lang.Indexed_Cast(chunk_1348000046__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1348000048__5)); var b__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000049__6, lang.RT_IntCast_J__I_NoInit(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000049__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var and__1927000168__auto____9 any; var root_344 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = b__7; if linked_345 == nil { and__1927000168__auto____9 = ifn_346.Invoke_O__O(arg_347) } else { and__1927000168__auto____9 = linked_345.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_344, arg_347) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_348 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = A_arbace_j2g_vh_A_const_76.Invoke_O__O(b__7); if linked_349 == nil { tmp2 = ifn_350.Invoke_O__O(arg_351) } else { tmp2 = linked_349.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_348, arg_351) } } else { tmp2 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp2) {
				var root_376 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = t.F_env; var arg_380 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_381 any = A_arbace_j2g_vh_A_const_25.Invoke_O__O(b__7); var arg_382 any = init__8; if linked_377 == nil { ifn_378.Invoke_O_O_O_O__O(arg_379, arg_380, arg_381, arg_382) } else { linked_377.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_376, arg_379, arg_380, arg_381, arg_382) }
//line :121:1
				seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000048__5); continue L1 } else { seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000048__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_352 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = seq_1348000045__2; if linked_353 == nil { temp__1927000414__auto____6 = ifn_354.Invoke_O__O(arg_355) } else { temp__1927000414__auto____6 = linked_353.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_352, arg_355) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1348000045__7 any = temp__1927000414__auto____6; var tmp3 any; var root_356 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = seq_1348000045__7; if linked_357 == nil { tmp3 = ifn_358.Invoke_O__O(arg_359) } else { tmp3 = linked_357.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_356, arg_359) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_360 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_360, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_362 lang.IFn; if linked_361 == nil { ifn_362 = lang.IFn_Cast(root_360) } else { ifn_362 = nil }; var arg_363 any = seq_1348000045__7; if linked_361 == nil { c__1927000678__auto____8 = ifn_362.Invoke_O__O(arg_363) } else { c__1927000678__auto____8 = linked_361.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_360, arg_363) }; var tmp4 any; var root_383 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = seq_1348000045__7; if linked_384 == nil { tmp4 = ifn_385.Invoke_O__O(arg_386) } else { tmp4 = linked_384.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_383, arg_386) }; seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1348000052__8 any; var root_364 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = seq_1348000045__7; if linked_365 == nil { vec__1348000052__8 = ifn_366.Invoke_O__O(arg_367) } else { vec__1348000052__8 = linked_365.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_364, arg_367) }; var b__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000052__8, lang.RT_IntCast_J__I_NoInit(0), nil); var init__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000052__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var and__1927000168__auto____11 any; var root_368 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = b__9; if linked_369 == nil { and__1927000168__auto____11 = ifn_370.Invoke_O__O(arg_371) } else { and__1927000168__auto____11 = linked_369.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_368, arg_371) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_372 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_374 lang.IFn; if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = A_arbace_j2g_vh_A_const_76.Invoke_O__O(b__9); if linked_373 == nil { tmp5 = ifn_374.Invoke_O__O(arg_375) } else { tmp5 = linked_373.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_372, arg_375) } } else { tmp5 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp5) {
					var root_387 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = t.F_env; var arg_391 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_392 any = A_arbace_j2g_vh_A_const_25.Invoke_O__O(b__9); var arg_393 any = init__10; if linked_388 == nil { ifn_389.Invoke_O_O_O_O__O(arg_390, arg_391, arg_392, arg_393) } else { linked_388.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_387, arg_390, arg_391, arg_392, arg_393) }
//line :121:1
					var tmp6 any; var root_394 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = seq_1348000045__7; if linked_395 == nil { tmp6 = ifn_396.Invoke_O__O(arg_397) } else { tmp6 = linked_395.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_394, arg_397) }; seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_398 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = seq_1348000045__7; if linked_399 == nil { tmp7 = ifn_400.Invoke_O__O(arg_401) } else { tmp7 = linked_399.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_398, arg_401) }; seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :120:1
						return nil } }
//line :119:1
	panic("j2g: unreachable")
}




func A_arbace_j2g_vh_class_handles_fn__1348000060_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_vh_class_handles_fn__1348000060_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_fn__1348000060_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :125:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000060_A) Ctor_O_O_O(c__env, c__out, c__n any) { t.F_env = c__env; t.F_out = c__out; t.F_n = c__n }
//line :125:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000060_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 bool; var tmp2 any = A_arbace_j2g_vh_A_const_81; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(x__1)); if and__1927000168__auto____2 { var tmp3 *lang.Keyword = A_arbace_j2g_vh_A_const_44; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_82.GetRawRoot__O(), tmp3.Invoke_O__O(A_arbace_j2g_vh_A_const_21.Invoke_O__O(x__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var f__2 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(x__1); var o__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__2)

		if jrt.J2g_Truth(or__1927000174__auto____3) { o__3 = or__1927000174__auto____3 } else { o__3 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__2) }
//line :126:1
		var temp__1927000414__auto____4 any; var root_413 any = A_arbace_j2g_vh_A_const_65.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, A_arbace_j2g_vh_handle_spec_A_fn_class); var ifn_415 lang.IFn


		if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = t.F_n; var arg_417 any = A_arbace_j2g_vh_A_const_31.Invoke_O__O(x__1); var arg_418 any; var root_419 any = A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_421 lang.IFn; if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = t.F_env; if linked_420 == nil { arg_418 = ifn_421.Invoke_O__O(arg_422) } else { arg_418 = linked_420.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_419, arg_422) }; if linked_414 == nil { temp__1927000414__auto____4 = ifn_415.Invoke_O_O_O__O(arg_416, arg_417, arg_418) } else { temp__1927000414__auto____4 = linked_414.(*A_arbace_j2g_vh_handle_spec_A).Invoke_O_O_O_O__O(root_413, arg_416, arg_417, arg_418) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var spec__5 any = temp__1927000414__auto____4; var root_423 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_424 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_423, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_425 lang.IFn
			if linked_424 == nil { ifn_425 = lang.IFn_Cast(root_423) } else { ifn_425 = nil }; var arg_426 any = t.F_out; var arg_427 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_428 any = lang.Tuple_Create_O_O__IPersistentVector(o__3, A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__2)); var arg_429 any = spec__5; if linked_424 == nil { return ifn_425.Invoke_O_O_O_O__O(arg_426, arg_427, arg_428, arg_429) } else { return linked_424.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_423, arg_426, arg_427, arg_428, arg_429) } } else {
//line :129:1
				return nil } } else {
//line :126:1
					return nil } }
//line :125:1
func A_arbace_j2g_vh_class_handles_fn__1348000062_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_vh_class_handles_fn__1348000062_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_fn__1348000062_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :125:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000062_A) Ctor_O_O_O(c__env, c__out, c__n any) { t.F_env = c__env; t.F_out = c__out; t.F_n = c__n }
//line :125:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000062_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 bool; var tmp2 any = A_arbace_j2g_vh_A_const_81; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(x__1)); if and__1927000168__auto____2 { var tmp3 *lang.Keyword = A_arbace_j2g_vh_A_const_44; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_82.GetRawRoot__O(), tmp3.Invoke_O__O(A_arbace_j2g_vh_A_const_21.Invoke_O__O(x__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var f__2 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(x__1); var o__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__2)

		if jrt.J2g_Truth(or__1927000174__auto____3) { o__3 = or__1927000174__auto____3 } else { o__3 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__2) }
//line :126:1
		var temp__1927000414__auto____4 any; var root_441 any = A_arbace_j2g_vh_A_const_65.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, A_arbace_j2g_vh_handle_spec_A_fn_class); var ifn_443 lang.IFn


		if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = t.F_n; var arg_445 any = A_arbace_j2g_vh_A_const_31.Invoke_O__O(x__1); var arg_446 any; var root_447 any = A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = t.F_env; if linked_448 == nil { arg_446 = ifn_449.Invoke_O__O(arg_450) } else { arg_446 = linked_448.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_447, arg_450) }; if linked_442 == nil { temp__1927000414__auto____4 = ifn_443.Invoke_O_O_O__O(arg_444, arg_445, arg_446) } else { temp__1927000414__auto____4 = linked_442.(*A_arbace_j2g_vh_handle_spec_A).Invoke_O_O_O_O__O(root_441, arg_444, arg_445, arg_446) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var spec__5 any = temp__1927000414__auto____4; var root_451 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_453 lang.IFn
			if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = t.F_out; var arg_455 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_456 any = lang.Tuple_Create_O_O__IPersistentVector(o__3, A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__2)); var arg_457 any = spec__5; if linked_452 == nil { return ifn_453.Invoke_O_O_O_O__O(arg_454, arg_455, arg_456, arg_457) } else { return linked_452.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_451, arg_454, arg_455, arg_456, arg_457) } } else {
//line :129:1
				return nil } } else {
//line :126:1
					return nil
				}
}





func A_arbace_j2g_vh_handles_A_New() *A_arbace_j2g_vh_handles_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_j2g_vh_handles_A) Ctor() {}
//line :134:1
func (t *A_arbace_j2g_vh_handles_A) Invoke_O_O__O(self, class_names__0 any) any { var hs__2 any; var root_464 any = A_arbace_j2g_vh_A_const_83.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_466 lang.IFn; if



	linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_468 any; var iter__1927001039__auto____2 any; var fnbody__580 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_New(); var tmp1 *jrt.Class; var fncls__579 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_fn_class; if fncls__579 == nil { var fncls__579d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_fn_class = fncls__579d; tmp1 = fncls__579d } else { tmp1 = fncls__579 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__580, tmp1, nil); arg_468 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(class_names__0); if linked_465 == nil { hs__2 = ifn_466.Invoke_O_O__O(arg_467, arg_468) } else { hs__2 = linked_465.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_464, arg_467, arg_468) }; var tmp2 any = A_arbace_j2g_vh_A_const_92; var tmp3 any = A_arbace_j2g_vh_A_const_36; var tmp4 any; var root_581 any = /*line :134:1*/A_arbace_j2g_vh_A_const_93.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_583 lang.IFn; if









	linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any; var iter__1927001039__auto____3 any; var fnbody__650 any = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_New(); var tmp5 *jrt.Class; var fncls__649 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_fn_class; if fncls__649 == nil { var fncls__649d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_fn_class = fncls__649d; tmp5 = fncls__649d } else { tmp5 = fncls__649 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__650, tmp5, nil); arg_584 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(hs__2); if linked_582 == nil { tmp4 = ifn_583.Invoke_O__O(arg_584) } else { tmp4 = linked_582.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_581, arg_584) }; return /*line :134:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, hs__2, tmp3, tmp4)) }



func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_New() *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A) Ctor() {}
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A) Invoke_O_O__O(self, s__1348000067__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__578 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_New_O_O(s__1348000067__1, self); var tmp2 *jrt.Class; var fncls__577 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_fn_class; if fncls__577 == nil { var fncls__577d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__578); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_fn_class = fncls__577d; tmp2 = fncls__577d } else { tmp2 = fncls__577 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__578, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :138:1
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_New_O_O(p0, p1 any) *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A) Ctor_O_O(c__s__1348000067, c__iter__1348000066 any) { t.F_s__1348000067 = c__s__1348000067; t.F_iter__1348000066 = c__iter__1348000066 }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A) Invoke_O__O(self any) any { { var s__1348000067__1 any; var t_ any = t.F_s__1348000067; t.F_s__1348000067 = nil; s__1348000067__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_469 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = s__1348000067__1; if linked_470 == nil { temp__1927000414__auto____2 = ifn_471.Invoke_O__O(arg_472) } else { temp__1927000414__auto____2 = linked_470.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_469, arg_472) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_473 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_475 lang.IFn; if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = xs__1927001018__auto____3; if linked_474 == nil { n__4 = ifn_475.Invoke_O__O(arg_476) } else { n__4 = linked_474.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_473, arg_476) }; var d__5 any; var root_477 any = A_arbace_j2g_vh_A_const_34.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_479 lang.IFn
														if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = n__4; if linked_478 == nil { d__5 = ifn_479.Invoke_O__O(arg_480) } else { d__5 = linked_478.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_477, arg_480) }
//line :138:1
	var tmp1 any
	var and__1927000168__auto____6 any = d__5
	if jrt.J2g_Truth(and__1927000168__auto____6) { var root_481 any = A_arbace_j2g_vh_A_const_35.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any; var fnbody__487 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_New(); var tmp2 *jrt.Class; var fncls__486 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_fn_class; if fncls__486 == nil { var fncls__486d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_fn_class = fncls__486d; tmp2 = fncls__486d } else { tmp2 = fncls__486 }; arg_484 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__487, tmp2, nil); var arg_485 any = A_arbace_j2g_vh_A_const_36.Invoke_O__O(d__5); if linked_482 == nil { tmp1 = ifn_483.Invoke_O_O__O(arg_484, arg_485) } else { tmp1 = linked_482.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_481, arg_484, arg_485) } } else { tmp1 = and__1927000168__auto____6 }
//line :138:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____6 any; var fnbody__549 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_New(); var tmp3 *jrt.Class; var fncls__548 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_fn_class; if fncls__548 == nil { var fncls__548d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_fn_class = fncls__548d; tmp3 = fncls__548d } else { tmp3 = fncls__548 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__549, tmp3, nil); var fs__1927001036__auto____7 any; var root_550 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____6); var tmp5 *lang.Compiler_AOTFn; var fnbody__559 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_New_O(n__4); var tmp6 *jrt.Class
		var fncls__558 /*line :138:1*/*jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_fn_class


		if fncls__558 == nil { var fncls__558d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__559); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_fn_class = fncls__558d; tmp6 = fncls__558d } else { tmp6 = fncls__558 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__559, tmp6, nil)
//line :138:1
		arg_553 = tmp4.Invoke_O__O(Up_Compiler_AOTFn_IFn(tmp5).Invoke__O()); if linked_551 == nil { fs__1927001036__auto____7 = ifn_552.Invoke_O__O(arg_553) } else { fs__1927001036__auto____7 = linked_551.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_550, arg_553) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_560 any = A_arbace_j2g_vh_A_const_91.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = fs__1927001036__auto____7; var arg_564 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1348000066); var tmp8 any; var root_565 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = s__1348000067__1; if linked_566 == nil { tmp8 = ifn_567.Invoke_O__O(arg_568) } else { tmp8 = linked_566.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_565, arg_568) }; arg_564 = tmp7.Invoke_O__O(tmp8); if linked_561 == nil { return ifn_562.Invoke_O_O__O(arg_563, arg_564) } else { return linked_561.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_560, arg_563, arg_564) } } else { var tmp9 any; var root_569 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = s__1348000067__1; if linked_570 == nil { tmp9 = ifn_571.Invoke_O__O(arg_572) } else { tmp9 = linked_570.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_569, arg_572) }; s__1348000067__1 = tmp9; continue L1 } } else { var tmp10 any; var root_573 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = s__1348000067__1; if linked_574 == nil { tmp10 = ifn_575.Invoke_O__O(arg_576) } else { tmp10 = linked_574.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_573, arg_576) }; s__1348000067__1 = tmp10; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :138:1
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_New() *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A) Ctor() {}
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A) Invoke_O_O__O(self, s__1348000069__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__547 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_New_O_O(self, s__1348000069__1); var tmp2 *jrt.Class; var fncls__546 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_fn_class; if fncls__546 == nil { var fncls__546d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__547); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_fn_class = fncls__546d; tmp2 = fncls__546d } else { tmp2 = fncls__546 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__547, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :138:1
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_New_O_O(p0, p1 any) *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A) Ctor_O_O(c__iter__1348000068, c__s__1348000069 any) { t.F_iter__1348000068 = c__iter__1348000068; t.F_s__1348000069 = c__s__1348000069 }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A) Invoke_O__O(self any) any { { var s__1348000069__1 any; var t_ any = t.F_s__1348000069; t.F_s__1348000069 = nil; s__1348000069__1 = t_; for { var temp__1927000414__auto____2 any; var root_488 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = s__1348000069__1; if linked_489 == nil { temp__1927000414__auto____2 = ifn_490.Invoke_O__O(arg_491) } else { temp__1927000414__auto____2 = linked_489.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_488, arg_491) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1348000069__3 any = temp__1927000414__auto____2; var tmp1 any; var root_492 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = s__1348000069__3; if linked_493 == nil { tmp1 = ifn_494.Invoke_O__O(arg_495) } else { tmp1 = linked_493.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_492, arg_495) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_496 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = s__1348000069__3; if linked_497 == nil { c__1927001037__auto____4 = ifn_498.Invoke_O__O(arg_499) } else { c__1927001037__auto____4 = linked_497.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_496, arg_499) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1348000071__6 any; var root_500 any = A_arbace_j2g_vh_A_const_84.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_501 == nil { b__1348000071__6 = ifn_502.Invoke_O__O(arg_503) } else { b__1348000071__6 = linked_501.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_500, arg_503) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__510 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_New_O_I_O(b__1348000071__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__509 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_fn_class; if fncls__509 == nil { var fncls__509d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__510); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_fn_class = fncls__509d; tmp3 = fncls__509d } else { tmp3 = fncls__509 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__510, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_511 any = A_arbace_j2g_vh_A_const_86.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any; var root_516 any = A_arbace_j2g_vh_A_const_87.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any = b__1348000071__6; if linked_517 == nil { arg_514 = ifn_518.Invoke_O__O(arg_519) } else { arg_514 = linked_517.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_516, arg_519) }; var arg_515 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1348000068); var tmp5 any; var root_520 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_520, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_522 lang.IFn; if linked_521 == nil { ifn_522 = lang.IFn_Cast(root_520) } else { ifn_522 = nil }; var arg_523 any = s__1348000069__3; if linked_521 == nil { tmp5 = ifn_522.Invoke_O__O(arg_523) } else { tmp5 = linked_521.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_520, arg_523) }; arg_515 = tmp4.Invoke_O__O(tmp5); if linked_512 == nil { return ifn_513.Invoke_O_O__O(arg_514, arg_515) } else { return linked_512.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_511, arg_514, arg_515) } } else { var root_524 any = A_arbace_j2g_vh_A_const_86.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any; var root_529 any = A_arbace_j2g_vh_A_const_87.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = b__1348000071__6; if linked_530 == nil { arg_527 = ifn_531.Invoke_O__O(arg_532) } else { arg_527 = linked_530.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_529, arg_532) }; var arg_528 any; if linked_525 == nil { return ifn_526.Invoke_O_O__O(arg_527, arg_528) } else { return linked_525.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_524, arg_527, arg_528) } } } else { var e__4 any; var root_533 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = s__1348000069__3; if linked_534 == nil { e__4 = ifn_535.Invoke_O__O(arg_536) } else { e__4 = linked_534.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_533, arg_536) }; var root_537 any = A_arbace_j2g_vh_A_const_88.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = e__4; var arg_541 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1348000068); var tmp7 any; var root_542 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = s__1348000069__3; if linked_543 == nil { tmp7 = ifn_544.Invoke_O__O(arg_545) } else { tmp7 = linked_543.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_542, arg_545) }; arg_541 = tmp6.Invoke_O__O(tmp7); if linked_538 == nil { return ifn_539.Invoke_O_O__O(arg_540, arg_541) } else { return linked_538.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_537, arg_540, arg_541) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :138:1
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A) Ctor_O_I_O(c__b__1348000071 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1348000071 = c__b__1348000071; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A) Invoke_O__O(self any) any { { var i__1348000070__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1348000070__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1348000070__1)); var root_504 any = A_arbace_j2g_vh_A_const_85.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = t.F_b__1348000071; var arg_508 any = e__2; if linked_505 == nil { ifn_506.Invoke_O_O__O(arg_507, arg_508) } else { linked_505.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_504, arg_507, arg_508) }; i__1348000070__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1348000070__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_New() *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A) Ctor() {}
//line :140:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A) Invoke_O_O__O(self, p1__1348000065_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_82.GetRawRoot__O(), A_arbace_j2g_vh_A_const_44.Invoke_O__O(p1__1348000065_SHARP___1))).Ref() }
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_New_O(p0 any) *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A{}; t.Ctor_O(p0); return t }
//line :141:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :141:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_554 any = A_arbace_j2g_vh_A_const_90.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, A_arbace_j2g_vh_class_handles_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any; var t_ any = t.F_n; t.F_n = nil; arg_557 = t_; if linked_555 == nil { tmp1 = ifn_556.Invoke_O__O(arg_557) } else { tmp1 = linked_555.(*A_arbace_j2g_vh_class_handles_A).Invoke_O_O__O(root_554, arg_557) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_New() *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A) Ctor() {}
//line :144:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A) Invoke_O_O__O(self, s__1348000087__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__648 any = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_New_O_O(s__1348000087__1, self); var tmp2 *jrt.Class; var fncls__647 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_fn_class; if fncls__647 == nil { var fncls__647d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, fnbody__648); A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_fn_class = fncls__647d; tmp2 = fncls__647d } else { tmp2 = fncls__647 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__648, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :144:1
func A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_New_O_O(p0, p1 any) *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A{}; t.Ctor_O_O(p0, p1); return t }
//line :144:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A) Ctor_O_O(c__s__1348000087, c__iter__1348000086 any) { t.F_s__1348000087 = c__s__1348000087; t.F_iter__1348000086 = c__iter__1348000086 }
//line :144:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A) Invoke_O__O(self any) any { { var s__1348000087__1 any; var t_ any = t.F_s__1348000087; t.F_s__1348000087 = nil; s__1348000087__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_585 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = s__1348000087__1; if linked_586 == nil { temp__1927000414__auto____2 = ifn_587.Invoke_O__O(arg_588) } else { temp__1927000414__auto____2 = linked_586.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_585, arg_588) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1348000087__3 any = temp__1927000414__auto____2; var tmp1 any; var root_589 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = s__1348000087__3; if linked_590 == nil { tmp1 = ifn_591.Invoke_O__O(arg_592) } else { tmp1 = linked_590.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_589, arg_592) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_593 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = s__1348000087__3; if linked_594 == nil { c__1927001037__auto____4 = ifn_595.Invoke_O__O(arg_596) } else { c__1927001037__auto____4 = linked_594.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_593, arg_596) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1348000089__6 any; var root_597 any = A_arbace_j2g_vh_A_const_84.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_598 == nil { b__1348000089__6 = ifn_599.Invoke_O__O(arg_600) } else { b__1348000089__6 = linked_598.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_597, arg_600) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__607 any = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_New_O_I_O(b__1348000089__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__606 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_fn_class; if fncls__606 == nil { var fncls__606d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__607); A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_fn_class = fncls__606d; tmp3 = fncls__606d } else { tmp3 = fncls__606 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__607, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_608 any = A_arbace_j2g_vh_A_const_86.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_610 lang.IFn; if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any; var root_613 any = A_arbace_j2g_vh_A_const_87.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_615 lang.IFn; if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any = b__1348000089__6; if linked_614 == nil { arg_611 = ifn_615.Invoke_O__O(arg_616) } else { arg_611 = linked_614.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_613, arg_616) }; var arg_612 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1348000086); var tmp5 any; var root_617 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = s__1348000087__3; if linked_618 == nil { tmp5 = ifn_619.Invoke_O__O(arg_620) } else { tmp5 = linked_618.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_617, arg_620) }; arg_612 = tmp4.Invoke_O__O(tmp5); if linked_609 == nil { return ifn_610.Invoke_O_O__O(arg_611, arg_612) } else { return linked_609.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_608, arg_611, arg_612) } } else { var root_621 any = A_arbace_j2g_vh_A_const_86.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_623 lang.IFn; if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any; var root_626 any = A_arbace_j2g_vh_A_const_87.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = b__1348000089__6; if linked_627 == nil { arg_624 = ifn_628.Invoke_O__O(arg_629) } else { arg_624 = linked_627.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_626, arg_629) }; var arg_625 any; if linked_622 == nil { return ifn_623.Invoke_O_O__O(arg_624, arg_625) } else { return linked_622.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_621, arg_624, arg_625) } } } else { var vec__1348000097__4 any; var root_630 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = s__1348000087__3; if linked_631 == nil { vec__1348000097__4 = ifn_632.Invoke_O__O(arg_633) } else { vec__1348000097__4 = linked_631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_630, arg_633) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000097__4, lang.RT_IntCast_J__I_NoInit(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000097__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any = A_arbace_j2g_vh_A_const_21; _ = ___5; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_j2g_vh_A_const_46.Invoke_O__O(s__6)) { var root_634 any = A_arbace_j2g_vh_A_const_88.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_vh_A_const_19.Invoke_O__O(s__6), A_arbace_j2g_vh_A_const_22.Invoke_O__O(s__6)); var arg_638 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1348000086); var tmp8 any; var root_639 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = s__1348000087__3; if linked_640 == nil { tmp8 = ifn_641.Invoke_O__O(arg_642) } else { tmp8 = linked_640.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_639, arg_642) }; arg_638 = tmp7.Invoke_O__O(tmp8); if linked_635 == nil { return ifn_636.Invoke_O_O__O(arg_637, arg_638) } else { return linked_635.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_634, arg_637, arg_638) } } else { var tmp9 any; var root_643 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_645 lang.IFn; if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = s__1348000087__3; if linked_644 == nil { tmp9 = ifn_645.Invoke_O__O(arg_646) } else { tmp9 = linked_644.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_643, arg_646) }; s__1348000087__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :144:1
func A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :144:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A) Ctor_O_I_O(c__b__1348000089 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1348000089 = c__b__1348000089; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :144:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A) Invoke_O__O(self any) any { { var i__1348000088__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1348000088__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1348000093__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1348000088__1)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000093__2, lang.RT_IntCast_J__I_NoInit(0), nil); var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000093__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any = A_arbace_j2g_vh_A_const_21; _ = ___3; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_46.Invoke_O__O(s__4)) { var root_601 any = A_arbace_j2g_vh_A_const_85.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_603 lang.IFn; if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any = t.F_b__1348000089; var arg_605 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_vh_A_const_19.Invoke_O__O(s__4), A_arbace_j2g_vh_A_const_22.Invoke_O__O(s__4)); if linked_602 == nil { ifn_603.Invoke_O_O__O(arg_604, arg_605) } else { linked_602.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_601, arg_604, arg_605) }; i__1348000088__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1348000088__1); continue L1 } else { i__1348000088__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1348000088__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_vh_mode_A_New() *A_arbace_j2g_vh_mode_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_mode_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_j2g_vh_mode_A) Ctor() {}
//line :151:1
func (t *A_arbace_j2g_vh_mode_A) Invoke_O_O__O(self, name__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_94).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_95 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_96).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_97 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_98).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_99 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_100).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_101 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_102).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_103 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_104).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_105 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_106).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_107 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_108).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_109 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_110).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_111 } else { if A_arbace_j2g_vh_A_const_66 != nil { return nil } else { return nil
	}
	}
	}
	}
	}
	}
	}
	}
	}
	}
}

func A_arbace_j2g_vh_fence_QMARK__A_New() *A_arbace_j2g_vh_fence_QMARK__A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_fence_QMARK__A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_j2g_vh_fence_QMARK__A) Ctor() {}
//line :167:1
func (t *A_arbace_j2g_vh_fence_QMARK__A) Invoke_O_O__O(self, node__0 any) any { var tmp1 any = A_arbace_j2g_vh_A_const_47; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__0)); if and__1927000168__auto____2 {
										var tmp2 any = A_arbace_j2g_vh_A_const_53; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_46.Invoke_O__O(node__0)); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_60.GetRawRoot__O(), A_arbace_j2g_vh_A_const_28.Invoke_O__O(node__0)); if and__1927000168__auto____4 { return lang.IFn_Cast(A_arbace_j2g_vh_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_vh_A_const_22.Invoke_O__O(node__0)) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_vh_op_handle_A_New() *A_arbace_j2g_vh_op_handle_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_op_handle_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_j2g_vh_op_handle_A) Ctor() {}
//line :170:1
func (t *A_arbace_j2g_vh_op_handle_A) Invoke_O_O_O__O(self, hs__0, node__1 any) any {



	var tmp1 any; var tmp2 any = A_arbace_j2g_vh_A_const_47; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__1)); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_60.GetRawRoot__O(), A_arbace_j2g_vh_A_const_28.Invoke_O__O(node__1)); if and__1927000168__auto____4 { var root_651 any = A_arbace_j2g_vh_A_const_113.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = A_arbace_j2g_vh_A_const_53; var arg_655 any = A_arbace_j2g_vh_A_const_46.Invoke_O__O(node__1); if linked_652 == nil { tmp1 = ifn_653.Invoke_O_O__O(arg_654, arg_655) } else { tmp1 = linked_652.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_651, arg_654, arg_655) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { var tg__3 any; var root_656 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_658 lang.IFn
		if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = A_arbace_j2g_vh_A_const_64.Invoke_O__O(node__1); if linked_657 == nil { tg__3 = ifn_658.Invoke_O__O(arg_659) } else { tg__3 = linked_657.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_656, arg_659) }
		var tmp3 any = A_arbace_j2g_vh_A_const_20; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_vh_A_const_14.Invoke_O__O(tg__3)) { var f__4 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(tg__3); var spec__5 any; var tmp4 any; var or__1927000174__auto____5 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__4)

			if jrt.J2g_Truth(or__1927000174__auto____5) { tmp4 = or__1927000174__auto____5 } else { tmp4 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__4) }; spec__5 = lang.RT_Get_O_O__O_NoInit(hs__0, lang.Tuple_Create_O_O__IPersistentVector(tmp4, A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__4)))
//line :176:1
			var m__6 any; var root_660 any = A_arbace_j2g_vh_A_const_114.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, A_arbace_j2g_vh_mode_A_fn_class); var ifn_662 lang.IFn


			if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = A_arbace_j2g_vh_A_const_22.Invoke_O__O(node__1); if linked_661 == nil { m__6 = ifn_662.Invoke_O__O(arg_663) } else { m__6 = linked_661.(*A_arbace_j2g_vh_mode_A).Invoke_O_O__O(root_660, arg_663) }
			var tmp5 any; var and__1927000168__auto____7 any = spec__5; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp5 = m__6 } else { tmp5 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp5) { var root_664 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_666 lang.IFn; if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = spec__5; var arg_668 any = A_arbace_j2g_vh_A_const_115; var arg_669 any = m__6; if linked_665 == nil { return ifn_666.Invoke_O_O_O__O(arg_667, arg_668, arg_669) } else { return linked_665.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_664, arg_667, arg_668, arg_669) } } else { return nil } } else {
//line :176:1
				return nil } } else {
//line :174:1
					return nil
				}
}




















































type A_arbace_j2g_vh_A struct{ jrt.Object }

var A_arbace_j2g_vh_A_const_pool *jrt.RefArray

var A_arbace_j2g_vh_A_const_0 *lang.Var

var A_arbace_j2g_vh_A_const_1 any

var A_arbace_j2g_vh_A_const_2 any

var A_arbace_j2g_vh_A_const_3 any

var A_arbace_j2g_vh_A_const_4 any

var A_arbace_j2g_vh_A_const_5 any

var A_arbace_j2g_vh_A_const_6 *lang.Var

var A_arbace_j2g_vh_A_const_7 any

var A_arbace_j2g_vh_A_const_8 *lang.Var

var A_arbace_j2g_vh_A_const_9 *lang.Var

var A_arbace_j2g_vh_A_const_10 *lang.Var

var A_arbace_j2g_vh_A_const_11 *lang.Var

var A_arbace_j2g_vh_A_const_12 any

var A_arbace_j2g_vh_A_const_13 *lang.Var

var A_arbace_j2g_vh_A_const_14 *lang.Keyword

var A_arbace_j2g_vh_A_const_15 *lang.Keyword

var A_arbace_j2g_vh_A_const_16 *lang.Var

var A_arbace_j2g_vh_A_const_17 *lang.Keyword

var A_arbace_j2g_vh_A_const_18 *lang.Keyword

var A_arbace_j2g_vh_A_const_19 *lang.Keyword

var A_arbace_j2g_vh_A_const_20 *lang.Keyword

var A_arbace_j2g_vh_A_const_21 *lang.Keyword

var A_arbace_j2g_vh_A_const_22 *lang.Keyword

var A_arbace_j2g_vh_A_const_23 *lang.Var

var A_arbace_j2g_vh_A_const_24 *lang.Keyword

var A_arbace_j2g_vh_A_const_25 *lang.Keyword

var A_arbace_j2g_vh_A_const_26 *lang.Keyword

var A_arbace_j2g_vh_A_const_27 *lang.Keyword

var A_arbace_j2g_vh_A_const_28 *lang.Keyword

var A_arbace_j2g_vh_A_const_29 *lang.Keyword

var A_arbace_j2g_vh_A_const_30 *lang.Var

var A_arbace_j2g_vh_A_const_31 *lang.Keyword

var A_arbace_j2g_vh_A_const_32 any

var A_arbace_j2g_vh_A_const_33 *lang.Var

var A_arbace_j2g_vh_A_const_34 *lang.Var

var A_arbace_j2g_vh_A_const_35 *lang.Var

var A_arbace_j2g_vh_A_const_36 *lang.Keyword

var A_arbace_j2g_vh_A_const_37 *lang.Keyword

var A_arbace_j2g_vh_A_const_38 *lang.Var

var A_arbace_j2g_vh_A_const_39 *lang.Keyword

var A_arbace_j2g_vh_A_const_40 any

var A_arbace_j2g_vh_A_const_41 *lang.Var

var A_arbace_j2g_vh_A_const_42 *lang.Var

var A_arbace_j2g_vh_A_const_43 *lang.Var

var A_arbace_j2g_vh_A_const_44 *lang.Keyword

var A_arbace_j2g_vh_A_const_45 *lang.Var

var A_arbace_j2g_vh_A_const_46 *lang.Keyword

var A_arbace_j2g_vh_A_const_47 *lang.Keyword

var A_arbace_j2g_vh_A_const_48 *lang.Var

var A_arbace_j2g_vh_A_const_49 *lang.Var

var A_arbace_j2g_vh_A_const_50 *lang.Var

var A_arbace_j2g_vh_A_const_51 *lang.Var

var A_arbace_j2g_vh_A_const_52 *lang.Keyword

var A_arbace_j2g_vh_A_const_53 *lang.Keyword

var A_arbace_j2g_vh_A_const_54 *lang.Var

var A_arbace_j2g_vh_A_const_55 *lang.Keyword

var A_arbace_j2g_vh_A_const_56 *lang.Var

var A_arbace_j2g_vh_A_const_57 any

var A_arbace_j2g_vh_A_const_58 *lang.Keyword

var A_arbace_j2g_vh_A_const_59 *lang.Keyword

var A_arbace_j2g_vh_A_const_60 *lang.Var

var A_arbace_j2g_vh_A_const_61 any

var A_arbace_j2g_vh_A_const_62 *lang.Var

var A_arbace_j2g_vh_A_const_63 *lang.Var

var A_arbace_j2g_vh_A_const_64 *lang.Keyword

var A_arbace_j2g_vh_A_const_65 *lang.Var

var A_arbace_j2g_vh_A_const_66 *lang.Keyword

var A_arbace_j2g_vh_A_const_67 *lang.Var

var A_arbace_j2g_vh_A_const_68 *lang.Keyword

var A_arbace_j2g_vh_A_const_69 *lang.Keyword

var A_arbace_j2g_vh_A_const_70 *lang.Var

var A_arbace_j2g_vh_A_const_71 *lang.Var

var A_arbace_j2g_vh_A_const_72 *lang.Var

var A_arbace_j2g_vh_A_const_73 *lang.Var

var A_arbace_j2g_vh_A_const_74 any

var A_arbace_j2g_vh_A_const_75 *lang.Keyword

var A_arbace_j2g_vh_A_const_76 *lang.Keyword

var A_arbace_j2g_vh_A_const_77 *lang.Var

var A_arbace_j2g_vh_A_const_78 *lang.Var

var A_arbace_j2g_vh_A_const_79 *lang.Var

var A_arbace_j2g_vh_A_const_80 any

var A_arbace_j2g_vh_A_const_81 *lang.Keyword

var A_arbace_j2g_vh_A_const_82 *lang.Var

var A_arbace_j2g_vh_A_const_83 *lang.Var

var A_arbace_j2g_vh_A_const_84 *lang.Var

var A_arbace_j2g_vh_A_const_85 *lang.Var

var A_arbace_j2g_vh_A_const_86 *lang.Var

var A_arbace_j2g_vh_A_const_87 *lang.Var

var A_arbace_j2g_vh_A_const_88 *lang.Var

var A_arbace_j2g_vh_A_const_89 *lang.Var

var A_arbace_j2g_vh_A_const_90 *lang.Var

var A_arbace_j2g_vh_A_const_91 *lang.Var

var A_arbace_j2g_vh_A_const_92 *lang.Keyword

var A_arbace_j2g_vh_A_const_93 *lang.Var

var A_arbace_j2g_vh_A_const_94 any

var A_arbace_j2g_vh_A_const_95 *lang.Keyword

var A_arbace_j2g_vh_A_const_96 any

var A_arbace_j2g_vh_A_const_97 *lang.Keyword

var A_arbace_j2g_vh_A_const_98 any

var A_arbace_j2g_vh_A_const_99 *lang.Keyword

var A_arbace_j2g_vh_A_const_100 any

var A_arbace_j2g_vh_A_const_101 *lang.Keyword

var A_arbace_j2g_vh_A_const_102 any

var A_arbace_j2g_vh_A_const_103 *lang.Keyword

var A_arbace_j2g_vh_A_const_104 any

var A_arbace_j2g_vh_A_const_105 *lang.Keyword

var A_arbace_j2g_vh_A_const_106 any

var A_arbace_j2g_vh_A_const_107 *lang.Keyword

var A_arbace_j2g_vh_A_const_108 any

var A_arbace_j2g_vh_A_const_109 *lang.Keyword

var A_arbace_j2g_vh_A_const_110 any

var A_arbace_j2g_vh_A_const_111 *lang.Keyword

var A_arbace_j2g_vh_A_const_112 *lang.Var

var A_arbace_j2g_vh_A_const_113 *lang.Var

var A_arbace_j2g_vh_A_const_114 *lang.Var

var A_arbace_j2g_vh_A_const_115 *lang.Keyword

var A_arbace_j2g_vh_A_init jrt.ClassInit

func A_arbace_j2g_vh_A_Init() { if !A_arbace_j2g_vh_A_init.Done() { A_arbace_j2g_vh_A_init.Run(A_arbace_j2g_vh_A_clinit) } }

func A_arbace_j2g_vh_A_clinit() { A_arbace_j2g_vh_A_clinit_p0(); A_arbace_j2g_vh_A_clinit_p1(); A_arbace_j2g_vh_A_clinit_p2(); A_arbace_j2g_vh_A_clinit_p3(); A_arbace_j2g_vh_A_clinit_p4(); A_arbace_j2g_vh_A_clinit_p5(); A_arbace_j2g_vh_A_clinit_p6(); A_arbace_j2g_vh_A_clinit_p7(); A_arbace_j2g_vh_A_clinit_p8(); A_arbace_j2g_vh_A_clinit_p9() }

func A_arbace_j2g_vh_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_vh_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 175); A_arbace_j2g_vh_A_const_0 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[59]); A_arbace_j2g_vh_A_const_1 = A_arbace_j2g_vh_A_const_pool.A[60]; A_arbace_j2g_vh_A_const_2 = A_arbace_j2g_vh_A_const_pool.A[61]; A_arbace_j2g_vh_A_const_3 = A_arbace_j2g_vh_A_const_pool.A[62]; A_arbace_j2g_vh_A_const_4 = A_arbace_j2g_vh_A_const_pool.A[63]; A_arbace_j2g_vh_A_const_5 = A_arbace_j2g_vh_A_const_pool.A[64]; A_arbace_j2g_vh_A_const_6 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[65]); A_arbace_j2g_vh_A_const_7 = A_arbace_j2g_vh_A_const_pool.A[66]; A_arbace_j2g_vh_A_const_8 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[67]); A_arbace_j2g_vh_A_const_9 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[68]); A_arbace_j2g_vh_A_const_10 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[69]); A_arbace_j2g_vh_A_const_11 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[70]); A_arbace_j2g_vh_A_const_12 = A_arbace_j2g_vh_A_const_pool.A[71] }

func A_arbace_j2g_vh_A_clinit_p1() { A_arbace_j2g_vh_A_const_13 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[72]); A_arbace_j2g_vh_A_const_14 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[73]); A_arbace_j2g_vh_A_const_15 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[74]); A_arbace_j2g_vh_A_const_16 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[75]); A_arbace_j2g_vh_A_const_17 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[76]); A_arbace_j2g_vh_A_const_18 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[77]); A_arbace_j2g_vh_A_const_19 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[78]); A_arbace_j2g_vh_A_const_20 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[79]); A_arbace_j2g_vh_A_const_21 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[80]); A_arbace_j2g_vh_A_const_22 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[81]); A_arbace_j2g_vh_A_const_23 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[82]); A_arbace_j2g_vh_A_const_24 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[83]) }

func A_arbace_j2g_vh_A_clinit_p2() { A_arbace_j2g_vh_A_const_25 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[84]); A_arbace_j2g_vh_A_const_26 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[85]); A_arbace_j2g_vh_A_const_27 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[86]); A_arbace_j2g_vh_A_const_28 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[87]); A_arbace_j2g_vh_A_const_29 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[88]); A_arbace_j2g_vh_A_const_30 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[89]); A_arbace_j2g_vh_A_const_31 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[90]); A_arbace_j2g_vh_A_const_32 = A_arbace_j2g_vh_A_const_pool.A[91]; A_arbace_j2g_vh_A_const_33 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[92]); A_arbace_j2g_vh_A_const_34 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[93]); A_arbace_j2g_vh_A_const_35 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[94]); A_arbace_j2g_vh_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[95]) }

func A_arbace_j2g_vh_A_clinit_p3() { A_arbace_j2g_vh_A_const_37 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[96]); A_arbace_j2g_vh_A_const_38 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[97]); A_arbace_j2g_vh_A_const_39 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[98]); A_arbace_j2g_vh_A_const_40 = A_arbace_j2g_vh_A_const_pool.A[99]; A_arbace_j2g_vh_A_const_41 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[100]); A_arbace_j2g_vh_A_const_42 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[101]); A_arbace_j2g_vh_A_const_43 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[102]); A_arbace_j2g_vh_A_const_44 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[103]); A_arbace_j2g_vh_A_const_45 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[104]); A_arbace_j2g_vh_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[105]); A_arbace_j2g_vh_A_const_47 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[106]); A_arbace_j2g_vh_A_const_48 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[107]) }

func A_arbace_j2g_vh_A_clinit_p4() { A_arbace_j2g_vh_A_const_49 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[108]); A_arbace_j2g_vh_A_const_50 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[109]); A_arbace_j2g_vh_A_const_51 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[110]); A_arbace_j2g_vh_A_const_52 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[111]); A_arbace_j2g_vh_A_const_53 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[112]); A_arbace_j2g_vh_A_const_54 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[113]); A_arbace_j2g_vh_A_const_55 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[114]); A_arbace_j2g_vh_A_const_56 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[115]); A_arbace_j2g_vh_A_const_57 = A_arbace_j2g_vh_A_const_pool.A[116]; A_arbace_j2g_vh_A_const_58 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[117]); A_arbace_j2g_vh_A_const_59 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[118]); A_arbace_j2g_vh_A_const_60 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[119]) }

func A_arbace_j2g_vh_A_clinit_p5() { A_arbace_j2g_vh_A_const_61 = A_arbace_j2g_vh_A_const_pool.A[120]; A_arbace_j2g_vh_A_const_62 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[121]); A_arbace_j2g_vh_A_const_63 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[122]); A_arbace_j2g_vh_A_const_64 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[123]); A_arbace_j2g_vh_A_const_65 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[124]); A_arbace_j2g_vh_A_const_66 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[125]); A_arbace_j2g_vh_A_const_67 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[126]); A_arbace_j2g_vh_A_const_68 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[127]); A_arbace_j2g_vh_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[128]); A_arbace_j2g_vh_A_const_70 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[129]); A_arbace_j2g_vh_A_const_71 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[130]); A_arbace_j2g_vh_A_const_72 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[131]) }

func A_arbace_j2g_vh_A_clinit_p6() { A_arbace_j2g_vh_A_const_73 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[132]); A_arbace_j2g_vh_A_const_74 = A_arbace_j2g_vh_A_const_pool.A[133]; A_arbace_j2g_vh_A_const_75 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[134]); A_arbace_j2g_vh_A_const_76 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[135]); A_arbace_j2g_vh_A_const_77 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[136]); A_arbace_j2g_vh_A_const_78 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[137]); A_arbace_j2g_vh_A_const_79 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[138]); A_arbace_j2g_vh_A_const_80 = A_arbace_j2g_vh_A_const_pool.A[139]; A_arbace_j2g_vh_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[140]); A_arbace_j2g_vh_A_const_82 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[141]); A_arbace_j2g_vh_A_const_83 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[142]); A_arbace_j2g_vh_A_const_84 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[143]) }

func A_arbace_j2g_vh_A_clinit_p7() { A_arbace_j2g_vh_A_const_85 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[144]); A_arbace_j2g_vh_A_const_86 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[145]); A_arbace_j2g_vh_A_const_87 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[146]); A_arbace_j2g_vh_A_const_88 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[147]); A_arbace_j2g_vh_A_const_89 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[148]); A_arbace_j2g_vh_A_const_90 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[149]); A_arbace_j2g_vh_A_const_91 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[150]); A_arbace_j2g_vh_A_const_92 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[151]); A_arbace_j2g_vh_A_const_93 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[152]); A_arbace_j2g_vh_A_const_94 = A_arbace_j2g_vh_A_const_pool.A[153]; A_arbace_j2g_vh_A_const_95 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[154]); A_arbace_j2g_vh_A_const_96 = A_arbace_j2g_vh_A_const_pool.A[155] }

func A_arbace_j2g_vh_A_clinit_p8() { A_arbace_j2g_vh_A_const_97 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[156]); A_arbace_j2g_vh_A_const_98 = A_arbace_j2g_vh_A_const_pool.A[157]; A_arbace_j2g_vh_A_const_99 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[158]); A_arbace_j2g_vh_A_const_100 = A_arbace_j2g_vh_A_const_pool.A[159]; A_arbace_j2g_vh_A_const_101 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[160]); A_arbace_j2g_vh_A_const_102 = A_arbace_j2g_vh_A_const_pool.A[161]; A_arbace_j2g_vh_A_const_103 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[162]); A_arbace_j2g_vh_A_const_104 = A_arbace_j2g_vh_A_const_pool.A[163]; A_arbace_j2g_vh_A_const_105 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[164]); A_arbace_j2g_vh_A_const_106 = A_arbace_j2g_vh_A_const_pool.A[165]; A_arbace_j2g_vh_A_const_107 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[166]); A_arbace_j2g_vh_A_const_108 = A_arbace_j2g_vh_A_const_pool.A[167]; A_arbace_j2g_vh_A_const_109 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[168]) }

func A_arbace_j2g_vh_A_clinit_p9() { A_arbace_j2g_vh_A_const_110 = A_arbace_j2g_vh_A_const_pool.A[169]; A_arbace_j2g_vh_A_const_111 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[170]); A_arbace_j2g_vh_A_const_112 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[171]); A_arbace_j2g_vh_A_const_113 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[172]); A_arbace_j2g_vh_A_const_114 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[173]); A_arbace_j2g_vh_A_const_115 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[174]) }

func A_arbace_j2g_vh_A_New() *A_arbace_j2g_vh_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_vh_A) Ctor() {}

func (t *A_arbace_j2g_vh_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_vh_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_vh_A_class }

func (t *A_arbace_j2g_vh_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_vh_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_vh_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_vh_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_vh_A); return ok }

func A_arbace_j2g_vh_A_Cast(x any) *A_arbace_j2g_vh_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_vh_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_vh_A_class)) }; return v }



type A_arbace_j2g_vh_byte_order_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_byte_order_arg_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_class_arg_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_class_handles_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_fn__1348000032_A struct{ j2g_header uint64; F_env any }

var A_arbace_j2g_vh_class_handles_fn__1348000032_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_fn__1348000044_A struct{ j2g_header uint64; F_env any }

var A_arbace_j2g_vh_class_handles_fn__1348000044_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_fn__1348000060_A struct{ j2g_header uint64; F_env, F_out, F_n any }

var A_arbace_j2g_vh_class_handles_fn__1348000060_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_fn__1348000062_A struct{ j2g_header uint64; F_env, F_out, F_n any }

var A_arbace_j2g_vh_class_handles_fn__1348000062_A_fn_class *jrt.Class



type A_arbace_j2g_vh_eval1348000004_A struct{ jrt.Object }

func A_arbace_j2g_vh_eval1348000004_A_New() *A_arbace_j2g_vh_eval1348000004_A { t := &A_arbace_j2g_vh_eval1348000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_vh_eval1348000004_A) Ctor() {}

func (t *A_arbace_j2g_vh_eval1348000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_vh_eval1348000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_vh_eval1348000004_A_class }

func (t *A_arbace_j2g_vh_eval1348000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_vh_eval1348000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_vh_eval1348000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_vh_eval1348000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_vh_eval1348000004_A); return ok }

func A_arbace_j2g_vh_eval1348000004_A_Cast(x any) *A_arbace_j2g_vh_eval1348000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_vh_eval1348000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_vh_eval1348000004_A_class)) }; return v }



type A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A_fn_class *jrt.Class



type A_arbace_j2g_vh_eval1348000008_A struct{ jrt.Object }

func A_arbace_j2g_vh_eval1348000008_A_New() *A_arbace_j2g_vh_eval1348000008_A { t := &A_arbace_j2g_vh_eval1348000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_vh_eval1348000008_A) Ctor() {}

func (t *A_arbace_j2g_vh_eval1348000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_vh_eval1348000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_vh_eval1348000008_A_class }

func (t *A_arbace_j2g_vh_eval1348000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_vh_eval1348000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_vh_eval1348000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_vh_eval1348000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_vh_eval1348000008_A); return ok }

func A_arbace_j2g_vh_eval1348000008_A_Cast(x any) *A_arbace_j2g_vh_eval1348000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_vh_eval1348000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_vh_eval1348000008_A_class)) }; return v }



type A_arbace_j2g_vh_eval1348000008_fn__1348000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_eval1348000008_fn__1348000009_A_fn_class *jrt.Class



type A_arbace_j2g_vh_fence_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_fence_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_vh_find_field_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_find_field_A_fn_class *jrt.Class



type A_arbace_j2g_vh_find_field_fn__1348000018_A struct{ j2g_header uint64; F_fname any }

var A_arbace_j2g_vh_find_field_fn__1348000018_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handle_spec_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handle_spec_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A struct{ j2g_header uint64; F_s__1348000067, F_iter__1348000066 any }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A struct{ j2g_header uint64; F_iter__1348000068, F_s__1348000069 any }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A struct{ j2g_header uint64; F_b__1348000071 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A struct{ j2g_header uint64; F_s__1348000087, F_iter__1348000086 any }

var A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A struct{ j2g_header uint64; F_b__1348000089 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_fn_class *jrt.Class



type A_arbace_j2g_vh_mode_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_mode_A_fn_class *jrt.Class



type A_arbace_j2g_vh_op_handle_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_op_handle_A_fn_class *jrt.Class



type A_arbace_j2g_vh_static_flag_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_static_flag_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_vh_string_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_string_arg_A_fn_class *jrt.Class
