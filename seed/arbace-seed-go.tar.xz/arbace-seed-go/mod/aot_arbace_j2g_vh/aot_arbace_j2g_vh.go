//line aot_arbace_j2g_vh.ae:1
package aot_arbace_j2g_vh

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_access"
	"arbace/aot_arbace_j2g_reach"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A_New() *A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_vh_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_vh_A_const_7); tmp2 = lang.IFn_Cast(A_arbace_j2g_vh_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_j2g_vh_A_const_1, A_arbace_j2g_vh_A_const_2, A_arbace_j2g_vh_A_const_3, A_arbace_j2g_vh_A_const_4, A_arbace_j2g_vh_A_const_5); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_vh_eval1348000008_fn__1348000009_A_New() *A_arbace_j2g_vh_eval1348000008_fn__1348000009_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_eval1348000008_fn__1348000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_vh_eval1348000008_fn__1348000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_vh_eval1348000008_fn__1348000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_8.GetRawRoot__O()); var tmp2 any; var root_19 any = A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_j2g_vh_A_const_10; if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_19, arg_22) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_vh_A_const_11.GetRawRoot__O(), A_arbace_j2g_vh_A_const_12) }
























func A_arbace_j2g_vh_class_arg_A_New() *A_arbace_j2g_vh_class_arg_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_arg_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_j2g_vh_class_arg_A) Ctor() {}
//line :26:1
func (t *A_arbace_j2g_vh_class_arg_A) Invoke_O_O_O__O(self, node__0, env__1 any) any { var node__3 any; var root_23 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_25 lang.IFn; if



	linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = node__0; if linked_24 == nil { node__3 = ifn_25.Invoke_O__O(arg_26) } else { node__3 = linked_24.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_23, arg_26) }; var G__1348000012__4_ any = /*line :26:1*/A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__3); switch




	lang.Util_Hash_O__I_NoInit(G__1348000012__4_) >> 6 & 3 { case 0: if any(G__1348000012__4_) == any(A_arbace_j2g_vh_A_const_15) {




		var root_28 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = A_arbace_j2g_vh_A_const_17.Invoke_O__O(node__3); var arg_32 any = env__1; if linked_29 == nil { return ifn_30.Invoke_O_O__O(arg_31, arg_32) } else { return linked_29.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_28, arg_31, arg_32) } }
//line :31:1
	case 1: if any(G__1348000012__4_) == any(A_arbace_j2g_vh_A_const_18) {
		return A_arbace_j2g_vh_A_const_19.Invoke_O__O(node__3) }
//line :31:1
	case 2: if any(G__1348000012__4_) == any(A_arbace_j2g_vh_A_const_20) { var f__5 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(node__3)


		if lang.Util_Equiv_O_O__Z_NoInit(Lit_2, A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__5)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_23.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____6 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__5); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__5) }; return tmp1.Invoke_O__O(tmp2) } else { return nil } }
//line :31:1
	case 3: if any(G__1348000012__4_) == any(A_arbace_j2g_vh_A_const_24) { var tmp3 *lang.Keyword = A_arbace_j2g_vh_A_const_25; var temp__1927000414__auto____5 any = lang.RT_Get_O_O__O_NoInit(env__1, tmp3.Invoke_O__O(A_arbace_j2g_vh_A_const_26.Invoke_O__O(node__3)))



		if jrt.J2g_Truth(temp__1927000414__auto____5) { var init__6 any = temp__1927000414__auto____5; var root_33 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = init__6; var arg_37 any = env__1; if linked_34 == nil { return ifn_35.Invoke_O_O__O(arg_36, arg_37) } else { return linked_34.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_33, arg_36, arg_37) } } else { return nil } }
//line :31:1
	default:}; return nil }







func A_arbace_j2g_vh_string_arg_A_New() *A_arbace_j2g_vh_string_arg_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_string_arg_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_vh_string_arg_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_vh_string_arg_A) Invoke_O_O__O(self, node__0 any) any { var node__2 any; var root_38 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_40 lang.IFn; if
										linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = node__0; if linked_39 == nil { node__2 = ifn_40.Invoke_O__O(arg_41) } else { node__2 = linked_39.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_38, arg_41) }; var tmp1 any; var tmp2 any = A_arbace_j2g_vh_A_const_29; var and__1927000168__auto____3 bool =
										lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__2)); if and__1927000168__auto____3 { var root_42 any = A_arbace_j2g_vh_A_const_30.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = A_arbace_j2g_vh_A_const_31.Invoke_O__O(node__2); if linked_43 == nil { tmp1 = ifn_44.Invoke_O__O(arg_45) } else { tmp1 = linked_43.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_42, arg_45) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return A_arbace_j2g_vh_A_const_31.Invoke_O__O(node__2) } else { return nil } }

func A_arbace_j2g_vh_byte_order_arg_A_New() *A_arbace_j2g_vh_byte_order_arg_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_byte_order_arg_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_j2g_vh_byte_order_arg_A) Ctor() {}
//line :43:1
func (t *A_arbace_j2g_vh_byte_order_arg_A) Invoke_O_O_O__O(self, node__0, env__1 any) any { var node__3 any; var root_46 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_48 lang.IFn; if



	linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = node__0; if linked_47 == nil { node__3 = ifn_48.Invoke_O__O(arg_49) } else { node__3 = linked_47.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_46, arg_49) }; var G__1348000015__4_ any = /*line :43:1*/A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__3); switch




	lang.Util_Hash_O__I_NoInit(G__1348000015__4_) >> 0 & 1 { case 0: if any(G__1348000015__4_) == any(A_arbace_j2g_vh_A_const_20) { var f__5 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(node__3); var tmp1 any; var or__1927000174__auto____6 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__5)

		if jrt.J2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__5) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_1, tmp1) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_32); return tmp2.Invoke_O__O(A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__5)) } else {
//line :50:1
				return nil } }
//line :48:1
	case 1: if any(G__1348000015__4_) == any(A_arbace_j2g_vh_A_const_24) { var tmp3 *lang.Keyword = A_arbace_j2g_vh_A_const_25; var temp__1927000414__auto____5 any = lang.RT_Get_O_O__O_NoInit(env__1, tmp3.Invoke_O__O(A_arbace_j2g_vh_A_const_26.Invoke_O__O(node__3)))



		if jrt.J2g_Truth(temp__1927000414__auto____5) { var init__6 any = temp__1927000414__auto____5; var root_51 any = A_arbace_j2g_vh_A_const_33.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, A_arbace_j2g_vh_byte_order_arg_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = init__6; var arg_55 any = env__1; if linked_52 == nil { return ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { return linked_52.(*A_arbace_j2g_vh_byte_order_arg_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) } } else { return nil } }
//line :48:1
	default:}; return nil }






func A_arbace_j2g_vh_find_field_A_New() *A_arbace_j2g_vh_find_field_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_find_field_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_j2g_vh_find_field_A) Ctor() {}
//line :55:1
func (t *A_arbace_j2g_vh_find_field_A) Invoke_O_O_O__O(self, n__0, fname__1 any) any { { var c__3 any = n__0; L1: for { var temp__1927000414__auto____4 any
											var and__1927000168__auto____4 any = c__3


	if jrt.J2g_Truth(and__1927000168__auto____4) { var root_56 any = A_arbace_j2g_vh_A_const_34.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = c__3; if linked_57 == nil { temp__1927000414__auto____4 = ifn_58.Invoke_O__O(arg_59) } else { temp__1927000414__auto____4 = linked_57.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_56, arg_59) } } else { temp__1927000414__auto____4 = and__1927000168__auto____4 }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var or__1927000174__auto____6 any; var root_60 any = A_arbace_j2g_vh_A_const_35.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_62 lang.IFn
		if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var tmp1 any = A_arbace_j2g_vh_find_field_fn__1348000018_A_New_O(fname__1); var tmp2 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_j2g_vh_find_field_fn__1348000018_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_vh_find_field_fn__1348000018_A_fn_class = fncls__65d; tmp2 = fncls__65d } else { tmp2 = fncls__65 }; arg_63 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_64 any = A_arbace_j2g_vh_A_const_36.Invoke_O__O(d__5); if linked_61 == nil { or__1927000174__auto____6 = ifn_62.Invoke_O_O__O(arg_63, arg_64) } else { or__1927000174__auto____6 = linked_61.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_60, arg_63, arg_64) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {
			c__3 = A_arbace_j2g_vh_A_const_37.Invoke_O__O(d__5); continue L1 } } else {
//line :59:1
				return nil } } }; /*line :55:1*/panic("j2g: unreachable") }




func A_arbace_j2g_vh_find_field_fn__1348000018_A_New_O(p0 any) *A_arbace_j2g_vh_find_field_fn__1348000018_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_find_field_fn__1348000018_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_j2g_vh_find_field_fn__1348000018_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :60:1
func (t *A_arbace_j2g_vh_find_field_fn__1348000018_A) Invoke_O_O__O(self, p1__1348000017_SHARP___1 any) any { var tmp1 any = t.F_fname; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_vh_A_const_22.Invoke_O__O(p1__1348000017_SHARP___1)) { return p1__1348000017_SHARP___1 } else { return nil } }


func A_arbace_j2g_vh_static_flag_QMARK__A_New() *A_arbace_j2g_vh_static_flag_QMARK__A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_static_flag_QMARK__A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_j2g_vh_static_flag_QMARK__A) Ctor() {}
//line :63:1
func (t *A_arbace_j2g_vh_static_flag_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var root_66 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any; var tmp1 int64; var na_70 any; var or__1927000174__auto____2 any = A_arbace_j2g_vh_A_const_39.Invoke_O__O(f__0); if jrt.J2g_Truth(or__1927000174__auto____2) { na_70 = or__1927000174__auto____2 } else { na_70 = A_arbace_j2g_vh_A_const_40 }; var na_71 int64 = 8; if jrt.Long_InstanceOf(na_70) { var n0_72 int64 = jrt.NN(jrt.Long_Cast(na_70)).LongValue__J(); var n1_73 int64 = na_71; tmp1 = n0_72 & n1_73 } else { tmp1 = lang.Numbers_And_O_J__J_NoInit(na_70, na_71) }; arg_69 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_67 == nil { return ifn_68.Invoke_O__O(arg_69) } else { return linked_67.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_66, arg_69) } }

func A_arbace_j2g_vh_handle_spec_A_New() *A_arbace_j2g_vh_handle_spec_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handle_spec_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_j2g_vh_handle_spec_A) Ctor() {}
//line :65:1
func (t *A_arbace_j2g_vh_handle_spec_A) Invoke_O_O_O_O__O(self, n__0, init__1, env__2 any) any { var init__4 any; var root_75 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_77 lang.IFn; if




	linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = init__1; if linked_76 == nil { init__4 = ifn_77.Invoke_O__O(arg_78) } else { init__4 = linked_76.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_75, arg_78) }; var field_spec__5 any; var tmp1 any = /*line :65:1*/A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_New(); var tmp2 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_fn_class; if





	fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_fn_class = fncls__100d; tmp2 = fncls__100d } else { tmp2 = fncls__100 }; field_spec__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 any = A_arbace_j2g_vh_A_const_47; if





	lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_vh_A_const_14.Invoke_O__O(init__4)) { var map__1348000024__6 any = init__4; var map__1348000024__7 any
		if lang.ISeq_InstanceOf(map__1348000024__6) { var tmp4 any; var root_101 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = map__1348000024__6; if linked_102 == nil { tmp4 = ifn_103.Invoke_O__O(arg_104) } else { tmp4 = linked_102.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_101, arg_104) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_105 any = A_arbace_j2g_vh_A_const_49.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = map__1348000024__6; if linked_106 == nil { tmp5 = ifn_107.Invoke_O__O(arg_108) } else { tmp5 = linked_106.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_105, arg_108) }; map__1348000024__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp5, jrt.Object_class.ArrayClass())).Ref() } else { var tmp6 any; var root_109 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = map__1348000024__6; if linked_110 == nil { tmp6 = ifn_111.Invoke_O__O(arg_112) } else { tmp6 = linked_110.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_109, arg_112) }; if jrt.J2g_Truth(tmp6) { var root_113 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = map__1348000024__6; if linked_114 == nil { map__1348000024__7 = ifn_115.Invoke_O__O(arg_116) } else { map__1348000024__7 = linked_114.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_113, arg_116) } } else { map__1348000024__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1348000024__7 = map__1348000024__6 }
//line :77:1
		var owner__8 any = lang.RT_Get_O_O__O_NoInit(map__1348000024__7, A_arbace_j2g_vh_A_const_28); var name__9 any = lang.RT_Get_O_O__O_NoInit(map__1348000024__7, A_arbace_j2g_vh_A_const_22); var args__10 any = lang.RT_Get_O_O__O_NoInit(map__1348000024__7, A_arbace_j2g_vh_A_const_52); var kind__11 any = lang.RT_Get_O_O__O_NoInit(map__1348000024__7, A_arbace_j2g_vh_A_const_46); var tmp7 bool; var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, Lit_9)


		if and__1927000168__auto____12 { var and__1927000168__auto____13 bool = lang.Util_Equiv_O_O__Z_NoInit(name__9, Lit_10); if and__1927000168__auto____13 { tmp7 = lang.Util_Equiv_J_J__Z_NoInit(3, int64(lang.RT_Count_O__I_NoInit(args__10))) } else { tmp7 = and__1927000168__auto____13 } } else { tmp7 = and__1927000168__auto____12 }
//line :79:1
		if tmp7 {

			var tmp8 lang.IFn = lang.IFn_Cast(field_spec__5); var tmp9 any; var root_163 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(0)); var arg_167 any = env__2; if linked_164 == nil { tmp9 = ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { tmp9 = linked_164.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_163, arg_166, arg_167) }; var tmp10 any = tmp9; var tmp11 any; var root_168 any = A_arbace_j2g_vh_A_const_67.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, A_arbace_j2g_vh_string_arg_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(1)); if linked_169 == nil { tmp11 = ifn_170.Invoke_O__O(arg_171) } else { tmp11 = linked_169.(*A_arbace_j2g_vh_string_arg_A).Invoke_O_O__O(root_168, arg_171) }; var tmp12 any = tmp11; var tmp13 any; var root_172 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(2)); var arg_176 any = env__2; if linked_173 == nil { tmp13 = ifn_174.Invoke_O_O__O(arg_175, arg_176) } else { tmp13 = linked_173.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_172, arg_175, arg_176) }; return tmp8.Invoke_O_O_O__O(tmp10, tmp12, tmp13) } else {
//line :79:1
				var tmp14 bool; var and__1927000168__auto____12_2 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, Lit_11)



				if and__1927000168__auto____12_2 { var and__1927000168__auto____13_2 bool = lang.Util_Equiv_O_O__Z_NoInit(name__9, Lit_10); if and__1927000168__auto____13_2 { tmp14 = lang.Util_Equiv_O_O__Z_NoInit(kind__11, A_arbace_j2g_vh_A_const_53) } else { tmp14 = and__1927000168__auto____13_2 } } else { tmp14 = and__1927000168__auto____12_2 }
//line :79:1
				if tmp14 { var G__1348000026__12_ int32 = lang.RT_Count_O__I_NoInit(args__10)




					switch G__1348000026__12_ { case 3:

						var tmp15 lang.IFn = lang.IFn_Cast(field_spec__5); var tmp16 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil, Lit_13), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(); var tmp17 any; var root_177 any = A_arbace_j2g_vh_A_const_67.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, A_arbace_j2g_vh_string_arg_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(1)); if linked_178 == nil { tmp17 = ifn_179.Invoke_O__O(arg_180) } else { tmp17 = linked_178.(*A_arbace_j2g_vh_string_arg_A).Invoke_O_O__O(root_177, arg_180) }; var tmp18 any = tmp17; var tmp19 any; var root_181 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(2)); var arg_185 any = env__2; if linked_182 == nil { tmp19 = ifn_183.Invoke_O_O__O(arg_184, arg_185) } else { tmp19 = linked_182.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_181, arg_184, arg_185) }; return tmp15.Invoke_O_O_O__O(tmp16, tmp18, tmp19)
//line :84:1
					case 4:


						var tmp20 lang.IFn = lang.IFn_Cast(field_spec__5); var tmp21 any; var root_186 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(1)); var arg_190 any = env__2; if linked_187 == nil { tmp21 = ifn_188.Invoke_O_O__O(arg_189, arg_190) } else { tmp21 = linked_187.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_186, arg_189, arg_190) }; var tmp22 any = tmp21; var tmp23 any; var root_191 any = A_arbace_j2g_vh_A_const_67.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_191, A_arbace_j2g_vh_string_arg_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(2)); if linked_192 == nil { tmp23 = ifn_193.Invoke_O__O(arg_194) } else { tmp23 = linked_192.(*A_arbace_j2g_vh_string_arg_A).Invoke_O_O__O(root_191, arg_194) }; var tmp24 any = tmp23; var tmp25 any; var root_195 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(3)); var arg_199 any = env__2; if linked_196 == nil { tmp25 = ifn_197.Invoke_O_O__O(arg_198, arg_199) } else { tmp25 = linked_196.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_195, arg_198, arg_199) }; return tmp20.Invoke_O_O_O__O(tmp22, tmp24, tmp25)
//line :84:1
					default:}; return nil } else {
//line :79:1
						var tmp26 bool; var and__1927000168__auto____12_3 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, Lit_14)










						if and__1927000168__auto____12_3 { var and__1927000168__auto____13_3 bool = lang.Util_Equiv_O_O__Z_NoInit(name__9, Lit_15); if and__1927000168__auto____13_3 { var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(kind__11, A_arbace_j2g_vh_A_const_53); if and__1927000168__auto____14 {
							tmp26 = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(args__10))) } else {
//line :90:1
								tmp26 = and__1927000168__auto____14 } } else { tmp26 = and__1927000168__auto____13_3 } } else { tmp26 = and__1927000168__auto____12_3 }
//line :79:1
						if tmp26 { var d__12 any; var root_118 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_120 lang.IFn












							if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any; var root_123 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = args__10; if linked_124 == nil { arg_121 = ifn_125.Invoke_O__O(arg_126) } else { arg_121 = linked_124.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_123, arg_126) }; var arg_122 any = env__2; if linked_119 == nil { d__12 = ifn_120.Invoke_O_O__O(arg_121, arg_122) } else { d__12 = linked_119.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_118, arg_121, arg_122) }
							var tmp27 any; var and__1927000168__auto____13_4 any = d__12; if jrt.J2g_Truth(and__1927000168__auto____13_4) { var root_127 any = A_arbace_j2g_vh_A_const_54.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = d__12; if linked_128 == nil { tmp27 = ifn_129.Invoke_O__O(arg_130) } else { tmp27 = linked_128.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_127, arg_130) } } else { tmp27 = and__1927000168__auto____13_4 }; if jrt.J2g_Truth(tmp27) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_vh_A_const_46, A_arbace_j2g_vh_A_const_55, A_arbace_j2g_vh_A_const_44, d__12)) } else { return nil } } else {
//line :79:1
								var tmp28 bool; var and__1927000168__auto____12_4 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, Lit_14)



















								if and__1927000168__auto____12_4 { var and__1927000168__auto____13_5 bool = lang.Util_Equiv_O_O__Z_NoInit(name__9, Lit_16); if and__1927000168__auto____13_5 { var and__1927000168__auto____14_2 bool = lang.Util_Equiv_O_O__Z_NoInit(kind__11, A_arbace_j2g_vh_A_const_53); if and__1927000168__auto____14_2 {
									tmp28 = lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(args__10))) } else {
//line :99:1
										tmp28 = and__1927000168__auto____14_2 } } else { tmp28 = and__1927000168__auto____13_5 } } else { tmp28 = and__1927000168__auto____12_4 }
//line :79:1
								if tmp28 { var d__12_2 any; var root_131 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_131, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_133 lang.IFn





















									if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any; var root_136 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = args__10; if linked_137 == nil { arg_134 = ifn_138.Invoke_O__O(arg_139) } else { arg_134 = linked_137.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_136, arg_139) }; var arg_135 any = env__2; if linked_132 == nil { d__12_2 = ifn_133.Invoke_O_O__O(arg_134, arg_135) } else { d__12_2 = linked_132.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_131, arg_134, arg_135) }
//line :79:1
									var o__13 any; var root_140 any = A_arbace_j2g_vh_A_const_33.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, A_arbace_j2g_vh_byte_order_arg_A_fn_class); var ifn_142 lang.IFn






















									if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any; var root_145 any = A_arbace_j2g_vh_A_const_56.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = args__10; if linked_146 == nil { arg_143 = ifn_147.Invoke_O__O(arg_148) } else { arg_143 = linked_146.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_145, arg_148) }; var arg_144 any = env__2; if linked_141 == nil { o__13 = ifn_142.Invoke_O_O__O(arg_143, arg_144) } else { o__13 = linked_141.(*A_arbace_j2g_vh_byte_order_arg_A).Invoke_O_O_O__O(root_140, arg_143, arg_144) }
									var tmp29 any; var and__1927000168__auto____14_3 any = lang.IFn_Cast(A_arbace_j2g_vh_A_const_57).Invoke_O__O(d__12_2); if jrt.J2g_Truth(and__1927000168__auto____14_3) { tmp29 = o__13 } else { tmp29 = and__1927000168__auto____14_3 }; if jrt.J2g_Truth(tmp29) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_vh_A_const_46, A_arbace_j2g_vh_A_const_58, A_arbace_j2g_vh_A_const_44, d__12_2, A_arbace_j2g_vh_A_const_59, o__13)) } else { return nil } } else {
//line :79:1
										var tmp30 any; var and__1927000168__auto____12_5 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, A_arbace_j2g_vh_A_const_60.GetRawRoot__O())

























										if and__1927000168__auto____12_5 { var and__1927000168__auto____13_6 any = lang.IFn_Cast(A_arbace_j2g_vh_A_const_61).Invoke_O__O(name__9); if jrt.J2g_Truth(and__1927000168__auto____13_6) { var and__1927000168__auto____14_4 any; var root_149 any = A_arbace_j2g_vh_A_const_62.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = args__10; if linked_150 == nil { and__1927000168__auto____14_4 = ifn_151.Invoke_O__O(arg_152) } else { and__1927000168__auto____14_4 = linked_150.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_149, arg_152) }; if jrt.J2g_Truth(and__1927000168__auto____14_4) {
											var root_153 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = A_arbace_j2g_vh_A_const_64.Invoke_O__O(init__4); if linked_154 == nil { tmp30 = ifn_155.Invoke_O__O(arg_156) } else { tmp30 = linked_154.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_153, arg_156) } } else {
//line :105:1
												tmp30 = and__1927000168__auto____14_4 } } else { tmp30 = and__1927000168__auto____13_6 } } else { tmp30 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12_5).Ref() }
//line :79:1
										if jrt.J2g_Truth(tmp30) {



























											var root_157 any = A_arbace_j2g_vh_A_const_65.GetRawRoot__O(); var linked_158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_157, A_arbace_j2g_vh_handle_spec_A_fn_class); var ifn_159 lang.IFn; if linked_158 == nil { ifn_159 = lang.IFn_Cast(root_157) } else { ifn_159 = nil }; var arg_160 any = n__0; var arg_161 any = A_arbace_j2g_vh_A_const_64.Invoke_O__O(init__4); var arg_162 any = env__2; if linked_158 == nil { return ifn_159.Invoke_O_O_O__O(arg_160, arg_161, arg_162) } else { return linked_158.(*A_arbace_j2g_vh_handle_spec_A).Invoke_O_O_O_O__O(root_157, arg_160, arg_161, arg_162) } } else {
//line :79:1
												if A_arbace_j2g_vh_A_const_66 != nil { return nil } else { return nil } } } } } } } else {
//line :77:1
													return nil } }
//line :71:1
func A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_New() *A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A) Ctor() {}
//line :71:1
func (t *A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A) Invoke_O_O_O_O__O(self, c__1, fname__2, tdesc__3 any) any {
	var tmp1 any; var and__1927000168__auto____4 any = c__1; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = fname__2; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = tdesc__3; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_79 any = A_arbace_j2g_vh_A_const_41.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = c__1; if linked_80 == nil { tmp1 = ifn_81.Invoke_O__O(arg_82) } else { tmp1 = linked_80.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_79, arg_82) } } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { var cn__4 any; var root_83 any = A_arbace_j2g_vh_A_const_42.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_85 lang.IFn
		if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = c__1; if linked_84 == nil { cn__4 = ifn_85.Invoke_O__O(arg_86) } else { cn__4 = linked_84.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_83, arg_86) }
//line :72:1
		var f__5 any; var root_87 any = A_arbace_j2g_vh_A_const_43.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, A_arbace_j2g_vh_find_field_A_fn_class); var ifn_89 lang.IFn

		if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = cn__4; var arg_91 any = fname__2; if linked_88 == nil { f__5 = ifn_89.Invoke_O_O__O(arg_90, arg_91) } else { f__5 = linked_88.(*A_arbace_j2g_vh_find_field_A).Invoke_O_O_O__O(root_87, arg_90, arg_91) }
		var tmp2 any; var and__1927000168__auto____6_2 any = f__5; if jrt.J2g_Truth(and__1927000168__auto____6_2) { var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tdesc__3, A_arbace_j2g_vh_A_const_44.Invoke_O__O(f__5)); if and__1927000168__auto____7 { var root_92 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any; var root_96 any = A_arbace_j2g_vh_A_const_45.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, A_arbace_j2g_vh_static_flag_QMARK__A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = f__5; if linked_97 == nil { arg_95 = ifn_98.Invoke_O__O(arg_99) } else { arg_95 = linked_97.(*A_arbace_j2g_vh_static_flag_QMARK__A).Invoke_O_O__O(root_96, arg_99) }; if linked_93 == nil { tmp2 = ifn_94.Invoke_O__O(arg_95) } else { tmp2 = linked_93.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_92, arg_95) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp2 = and__1927000168__auto____6_2 }; if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_j2g_vh_A_const_46; var tmp4 any = A_arbace_j2g_vh_A_const_21; var tmp5 any = A_arbace_j2g_vh_A_const_19; var tmp6 any; var or__1927000174__auto____6 any = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__5)
			if jrt.J2g_Truth(or__1927000174__auto____6) { tmp6 = or__1927000174__auto____6 } else { tmp6 = cn__4 }
//line :75:1
			return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, A_arbace_j2g_vh_A_const_22, fname__2, A_arbace_j2g_vh_A_const_44, tdesc__3, A_arbace_j2g_vh_A_const_21, f__5)) } else { return nil } } else {
//line :72:1
				return nil
			}
}




































func A_arbace_j2g_vh_class_handles_A_New() *A_arbace_j2g_vh_class_handles_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_j2g_vh_class_handles_A) Ctor() {}
//line :111:1
func (t *A_arbace_j2g_vh_class_handles_A) Invoke_O_O__O(self, n__0 any) any { var st__2 any; var root_200 any = A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_202 lang.IFn; if


	linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any; var tmp1 *lang.Keyword = A_arbace_j2g_vh_A_const_68; var tmp2 any; var root_204 any = A_arbace_j2g_vh_A_const_34.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = n__0; if linked_205 == nil { tmp2 = ifn_206.Invoke_O__O(arg_207) } else { tmp2 = linked_205.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_204, arg_207) }; arg_203 = tmp1.Invoke_O__O(tmp2); if linked_201 == nil { st__2 = ifn_202.Invoke_O__O(arg_203) } else { st__2 = linked_201.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_200, arg_203) }; var code__3 any = /*line :111:1*/A_arbace_j2g_vh_A_const_69.Invoke_O__O(st__2); var env__4 any; var root_208 any = A_arbace_j2g_vh_A_const_70.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_210 lang.IFn; if




	linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_209 == nil { env__4 = ifn_210.Invoke_O__O(arg_211) } else { env__4 = linked_209.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_208, arg_211) }; var out__5 any; var root_212 any = /*line :111:1*/A_arbace_j2g_vh_A_const_70.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_214 lang.IFn; if





	linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_213 == nil { out__5 = ifn_214.Invoke_O__O(arg_215) } else { out__5 = linked_213.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_212, arg_215) }; var seq_1348000028__6 any; var root_220 any = /*line :111:1*/A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_222 lang.IFn; if






	linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = code__3; if linked_221 == nil { seq_1348000028__6 = ifn_222.Invoke_O__O(arg_223) } else { seq_1348000028__6 = linked_221.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_220, arg_223) }; var chunk_1348000029__7 any; var count_1348000030__8 int64 = 0; var i_1348000031__9 int64 = 0; L1:
//line :111:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1348000031__9, count_1348000030__8) { var nd__10 any = lang.Indexed_Cast(chunk_1348000029__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1348000031__9)); var root_260 any = A_arbace_j2g_vh_A_const_73.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A_fn_class); var ifn_262 lang.IFn
			if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any; var tmp3 any = A_arbace_j2g_vh_class_handles_fn__1348000032_A_New_O(env__4); var tmp4 *jrt.Class; var fncls__327 *jrt.Class = A_arbace_j2g_vh_class_handles_fn__1348000032_A_fn_class; if fncls__327 == nil { var fncls__327d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_vh_class_handles_fn__1348000032_A_fn_class = fncls__327d; tmp4 = fncls__327d } else { tmp4 = fncls__327 }; arg_263 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_264 any = nd__10; if linked_261 == nil { ifn_262.Invoke_O_O__O(arg_263, arg_264) } else { linked_261.(*aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A).Invoke_O_O_O__O(root_260, arg_263, arg_264) }
//line :118:1
			seq_1348000028__6, chunk_1348000029__7, count_1348000030__8, i_1348000031__9 = seq_1348000028__6, chunk_1348000029__7, count_1348000030__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000031__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_224 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = seq_1348000028__6; if linked_225 == nil { temp__1927000414__auto____10 = ifn_226.Invoke_O__O(arg_227) } else { temp__1927000414__auto____10 = linked_225.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_224, arg_227) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1348000028__11 any = temp__1927000414__auto____10; var tmp5 any; var root_228 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = seq_1348000028__11; if linked_229 == nil { tmp5 = ifn_230.Invoke_O__O(arg_231) } else { tmp5 = linked_229.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_228, arg_231) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____12 any; var root_232 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = seq_1348000028__11; if linked_233 == nil { c__1927000678__auto____12 = ifn_234.Invoke_O__O(arg_235) } else { c__1927000678__auto____12 = linked_233.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_232, arg_235) }; var tmp6 any; var root_328 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = seq_1348000028__11; if linked_329 == nil { tmp6 = ifn_330.Invoke_O__O(arg_331) } else { tmp6 = linked_329.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_328, arg_331) }; seq_1348000028__6, chunk_1348000029__7, count_1348000030__8, i_1348000031__9 = tmp6, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var nd__12 any; var root_236 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = seq_1348000028__11; if linked_237 == nil { nd__12 = ifn_238.Invoke_O__O(arg_239) } else { nd__12 = linked_237.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_236, arg_239) }
				var root_332 any = A_arbace_j2g_vh_A_const_73.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any; var tmp7 any = A_arbace_j2g_vh_class_handles_fn__1348000044_A_New_O(env__4); var tmp8 *jrt.Class; var fncls__399 *jrt.Class = A_arbace_j2g_vh_class_handles_fn__1348000044_A_fn_class; if fncls__399 == nil { var fncls__399d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_j2g_vh_class_handles_fn__1348000044_A_fn_class = fncls__399d; tmp8 = fncls__399d } else { tmp8 = fncls__399 }; arg_335 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_336 any = nd__12; if linked_333 == nil { ifn_334.Invoke_O_O__O(arg_335, arg_336) } else { linked_333.(*aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A).Invoke_O_O_O__O(root_332, arg_335, arg_336) }
//line :118:1
				var tmp9 any; var root_400 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = seq_1348000028__11; if linked_401 == nil { tmp9 = ifn_402.Invoke_O__O(arg_403) } else { tmp9 = linked_401.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_400, arg_403) }; seq_1348000028__6, chunk_1348000029__7, count_1348000030__8, i_1348000031__9 = tmp9, nil, 0, 0; continue L1 } } }
//line :111:1
		break L1 }; var seq_1348000056__6 any; var root_240 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_242 lang.IFn; if












	linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = code__3; if linked_241 == nil { seq_1348000056__6 = ifn_242.Invoke_O__O(arg_243) } else { seq_1348000056__6 = linked_241.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_240, arg_243) }; var chunk_1348000057__7 any; var count_1348000058__8 int64 = 0; var i_1348000059__9 int64 = 0; L2:
//line :111:1
	for {












		if lang.Numbers_Lt_J_J__Z_NoInit(i_1348000059__9, count_1348000058__8) { var nd__10_2 any = lang.Indexed_Cast(chunk_1348000057__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1348000059__9)); var root_404 any = A_arbace_j2g_vh_A_const_73.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A_fn_class); var ifn_406 lang.IFn
			if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any; var tmp10 any = A_arbace_j2g_vh_class_handles_fn__1348000060_A_New_O_O_O(env__4, out__5, n__0); var tmp11 *jrt.Class; var fncls__426 *jrt.Class = A_arbace_j2g_vh_class_handles_fn__1348000060_A_fn_class; if fncls__426 == nil { var fncls__426d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_j2g_vh_class_handles_fn__1348000060_A_fn_class = fncls__426d; tmp11 = fncls__426d } else { tmp11 = fncls__426 }; arg_407 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_408 any = nd__10_2; if linked_405 == nil { ifn_406.Invoke_O_O__O(arg_407, arg_408) } else { linked_405.(*aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A).Invoke_O_O_O__O(root_404, arg_407, arg_408) }
//line :124:1
			seq_1348000056__6, chunk_1348000057__7, count_1348000058__8, i_1348000059__9 = seq_1348000056__6, chunk_1348000057__7, count_1348000058__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000059__9); continue L2 } else { var temp__1927000414__auto____10_2 any; var root_244 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = seq_1348000056__6; if linked_245 == nil { temp__1927000414__auto____10_2 = ifn_246.Invoke_O__O(arg_247) } else { temp__1927000414__auto____10_2 = linked_245.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_244, arg_247) }; if jrt.J2g_Truth(temp__1927000414__auto____10_2) { var seq_1348000056__11 any = temp__1927000414__auto____10_2; var tmp12 any; var root_248 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = seq_1348000056__11; if linked_249 == nil { tmp12 = ifn_250.Invoke_O__O(arg_251) } else { tmp12 = linked_249.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_248, arg_251) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____12_2 any; var root_252 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = seq_1348000056__11; if linked_253 == nil { c__1927000678__auto____12_2 = ifn_254.Invoke_O__O(arg_255) } else { c__1927000678__auto____12_2 = linked_253.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_252, arg_255) }; var tmp13 any; var root_427 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = seq_1348000056__11; if linked_428 == nil { tmp13 = ifn_429.Invoke_O__O(arg_430) } else { tmp13 = linked_428.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_427, arg_430) }; seq_1348000056__6, chunk_1348000057__7, count_1348000058__8, i_1348000059__9 = tmp13, c__1927000678__auto____12_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var nd__12_2 any; var root_256 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = seq_1348000056__11; if linked_257 == nil { nd__12_2 = ifn_258.Invoke_O__O(arg_259) } else { nd__12_2 = linked_257.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_256, arg_259) }
				var root_431 any = A_arbace_j2g_vh_A_const_73.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A_fn_class); var ifn_433 lang.IFn; if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any; var tmp14 any = A_arbace_j2g_vh_class_handles_fn__1348000062_A_New_O_O_O(env__4, out__5, n__0); var tmp15 *jrt.Class; var fncls__453 *jrt.Class = A_arbace_j2g_vh_class_handles_fn__1348000062_A_fn_class; if fncls__453 == nil { var fncls__453d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_j2g_vh_class_handles_fn__1348000062_A_fn_class = fncls__453d; tmp15 = fncls__453d } else { tmp15 = fncls__453 }; arg_434 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var arg_435 any = nd__12_2; if linked_432 == nil { ifn_433.Invoke_O_O__O(arg_434, arg_435) } else { linked_432.(*aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A).Invoke_O_O_O__O(root_431, arg_434, arg_435) }
//line :124:1
				var tmp16 any; var root_454 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = seq_1348000056__11; if linked_455 == nil { tmp16 = ifn_456.Invoke_O__O(arg_457) } else { tmp16 = linked_455.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_454, arg_457) }; seq_1348000056__6, chunk_1348000057__7, count_1348000058__8, i_1348000059__9 = tmp16, nil, 0, 0; continue L2 } } }
//line :111:1
		break L2 }; var root_216 any =


	A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = out__5; if linked_217 == nil { return ifn_218.Invoke_O__O(arg_219) } else { return linked_217.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_216, arg_219) } }




func A_arbace_j2g_vh_class_handles_fn__1348000032_A_New_O(p0 any) *A_arbace_j2g_vh_class_handles_fn__1348000032_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_fn__1348000032_A{}; t.Ctor_O(p0); return t }
//line :119:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000032_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :119:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000032_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_74); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_j2g_vh_A_const_14.Invoke_O__O(x__1))) { var seq_1348000033__2 any; var root_265 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_267 lang.IFn
		if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = A_arbace_j2g_vh_A_const_75.Invoke_O__O(x__1); if linked_266 == nil { seq_1348000033__2 = ifn_267.Invoke_O__O(arg_268) } else { seq_1348000033__2 = linked_266.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_265, arg_268) }
//line :120:1
		var chunk_1348000034__3 any; var count_1348000035__4 int64 = 0; var i_1348000036__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1348000036__5, count_1348000035__4) { var vec__1348000037__6 any = lang.Indexed_Cast(chunk_1348000034__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1348000036__5)); var b__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000037__6, lang.RT_IntCast_J__I_NoInit(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000037__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var and__1927000168__auto____9 any; var root_269 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = b__7; if linked_270 == nil { and__1927000168__auto____9 = ifn_271.Invoke_O__O(arg_272) } else { and__1927000168__auto____9 = linked_270.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_269, arg_272) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_273 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = A_arbace_j2g_vh_A_const_76.Invoke_O__O(b__7); if linked_274 == nil { tmp2 = ifn_275.Invoke_O__O(arg_276) } else { tmp2 = linked_274.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_273, arg_276) } } else { tmp2 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp2) {
				var root_301 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = t.F_env; var arg_305 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_306 any = A_arbace_j2g_vh_A_const_25.Invoke_O__O(b__7); var arg_307 any = init__8; if linked_302 == nil { ifn_303.Invoke_O_O_O_O__O(arg_304, arg_305, arg_306, arg_307) } else { linked_302.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_301, arg_304, arg_305, arg_306, arg_307) }
//line :121:1
				seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000036__5); continue L1 } else { seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000036__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_277 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = seq_1348000033__2; if linked_278 == nil { temp__1927000414__auto____6 = ifn_279.Invoke_O__O(arg_280) } else { temp__1927000414__auto____6 = linked_278.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_277, arg_280) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1348000033__7 any = temp__1927000414__auto____6; var tmp3 any; var root_281 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = seq_1348000033__7; if linked_282 == nil { tmp3 = ifn_283.Invoke_O__O(arg_284) } else { tmp3 = linked_282.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_281, arg_284) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_285 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = seq_1348000033__7; if linked_286 == nil { c__1927000678__auto____8 = ifn_287.Invoke_O__O(arg_288) } else { c__1927000678__auto____8 = linked_286.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_285, arg_288) }; var tmp4 any; var root_308 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_310 lang.IFn; if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = seq_1348000033__7; if linked_309 == nil { tmp4 = ifn_310.Invoke_O__O(arg_311) } else { tmp4 = linked_309.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_308, arg_311) }; seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1348000040__8 any; var root_289 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = seq_1348000033__7; if linked_290 == nil { vec__1348000040__8 = ifn_291.Invoke_O__O(arg_292) } else { vec__1348000040__8 = linked_290.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_289, arg_292) }; var b__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000040__8, lang.RT_IntCast_J__I_NoInit(0), nil); var init__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000040__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var and__1927000168__auto____11 any; var root_293 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_295 lang.IFn; if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = b__9; if linked_294 == nil { and__1927000168__auto____11 = ifn_295.Invoke_O__O(arg_296) } else { and__1927000168__auto____11 = linked_294.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_293, arg_296) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_297 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = A_arbace_j2g_vh_A_const_76.Invoke_O__O(b__9); if linked_298 == nil { tmp5 = ifn_299.Invoke_O__O(arg_300) } else { tmp5 = linked_298.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_297, arg_300) } } else { tmp5 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp5) {
					var root_312 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = t.F_env; var arg_316 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_317 any = A_arbace_j2g_vh_A_const_25.Invoke_O__O(b__9); var arg_318 any = init__10; if linked_313 == nil { ifn_314.Invoke_O_O_O_O__O(arg_315, arg_316, arg_317, arg_318) } else { linked_313.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_312, arg_315, arg_316, arg_317, arg_318) }
//line :121:1
					var tmp6 any; var root_319 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = seq_1348000033__7; if linked_320 == nil { tmp6 = ifn_321.Invoke_O__O(arg_322) } else { tmp6 = linked_320.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_319, arg_322) }; seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_323 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = seq_1348000033__7; if linked_324 == nil { tmp7 = ifn_325.Invoke_O__O(arg_326) } else { tmp7 = linked_324.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_323, arg_326) }; seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :120:1
						return nil } }
//line :119:1
	panic("j2g: unreachable") }
//line :119:1
func A_arbace_j2g_vh_class_handles_fn__1348000044_A_New_O(p0 any) *A_arbace_j2g_vh_class_handles_fn__1348000044_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_fn__1348000044_A{}; t.Ctor_O(p0); return t }
//line :119:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000044_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :119:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000044_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_80); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_j2g_vh_A_const_14.Invoke_O__O(x__1))) { var seq_1348000045__2 any; var root_337 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_339 lang.IFn
		if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = A_arbace_j2g_vh_A_const_75.Invoke_O__O(x__1); if linked_338 == nil { seq_1348000045__2 = ifn_339.Invoke_O__O(arg_340) } else { seq_1348000045__2 = linked_338.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_337, arg_340) }
//line :120:1
		var chunk_1348000046__3 any; var count_1348000047__4 int64 = 0; var i_1348000048__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1348000048__5, count_1348000047__4) { var vec__1348000049__6 any = lang.Indexed_Cast(chunk_1348000046__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1348000048__5)); var b__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000049__6, lang.RT_IntCast_J__I_NoInit(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000049__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var and__1927000168__auto____9 any; var root_341 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = b__7; if linked_342 == nil { and__1927000168__auto____9 = ifn_343.Invoke_O__O(arg_344) } else { and__1927000168__auto____9 = linked_342.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_341, arg_344) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_345 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = A_arbace_j2g_vh_A_const_76.Invoke_O__O(b__7); if linked_346 == nil { tmp2 = ifn_347.Invoke_O__O(arg_348) } else { tmp2 = linked_346.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_345, arg_348) } } else { tmp2 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp2) {
				var root_373 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_373, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any = t.F_env; var arg_377 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_378 any = A_arbace_j2g_vh_A_const_25.Invoke_O__O(b__7); var arg_379 any = init__8; if linked_374 == nil { ifn_375.Invoke_O_O_O_O__O(arg_376, arg_377, arg_378, arg_379) } else { linked_374.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_373, arg_376, arg_377, arg_378, arg_379) }
//line :121:1
				seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000048__5); continue L1 } else { seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000048__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_349 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = seq_1348000045__2; if linked_350 == nil { temp__1927000414__auto____6 = ifn_351.Invoke_O__O(arg_352) } else { temp__1927000414__auto____6 = linked_350.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_349, arg_352) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1348000045__7 any = temp__1927000414__auto____6; var tmp3 any; var root_353 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = seq_1348000045__7; if linked_354 == nil { tmp3 = ifn_355.Invoke_O__O(arg_356) } else { tmp3 = linked_354.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_353, arg_356) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_357 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = seq_1348000045__7; if linked_358 == nil { c__1927000678__auto____8 = ifn_359.Invoke_O__O(arg_360) } else { c__1927000678__auto____8 = linked_358.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_357, arg_360) }; var tmp4 any; var root_380 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = seq_1348000045__7; if linked_381 == nil { tmp4 = ifn_382.Invoke_O__O(arg_383) } else { tmp4 = linked_381.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_380, arg_383) }; seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1348000052__8 any; var root_361 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_363 lang.IFn; if linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = seq_1348000045__7; if linked_362 == nil { vec__1348000052__8 = ifn_363.Invoke_O__O(arg_364) } else { vec__1348000052__8 = linked_362.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_361, arg_364) }; var b__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000052__8, lang.RT_IntCast_J__I_NoInit(0), nil); var init__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000052__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var and__1927000168__auto____11 any; var root_365 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_367 lang.IFn; if linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = b__9; if linked_366 == nil { and__1927000168__auto____11 = ifn_367.Invoke_O__O(arg_368) } else { and__1927000168__auto____11 = linked_366.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_365, arg_368) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_369 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = A_arbace_j2g_vh_A_const_76.Invoke_O__O(b__9); if linked_370 == nil { tmp5 = ifn_371.Invoke_O__O(arg_372) } else { tmp5 = linked_370.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_369, arg_372) } } else { tmp5 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp5) {
					var root_384 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_386 lang.IFn; if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = t.F_env; var arg_388 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_389 any = A_arbace_j2g_vh_A_const_25.Invoke_O__O(b__9); var arg_390 any = init__10; if linked_385 == nil { ifn_386.Invoke_O_O_O_O__O(arg_387, arg_388, arg_389, arg_390) } else { linked_385.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_384, arg_387, arg_388, arg_389, arg_390) }
//line :121:1
					var tmp6 any; var root_391 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = seq_1348000045__7; if linked_392 == nil { tmp6 = ifn_393.Invoke_O__O(arg_394) } else { tmp6 = linked_392.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_391, arg_394) }; seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_395 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = seq_1348000045__7; if linked_396 == nil { tmp7 = ifn_397.Invoke_O__O(arg_398) } else { tmp7 = linked_396.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_395, arg_398) }; seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :120:1
						return nil } }
//line :119:1
	panic("j2g: unreachable")
}




func A_arbace_j2g_vh_class_handles_fn__1348000060_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_vh_class_handles_fn__1348000060_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_fn__1348000060_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :125:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000060_A) Ctor_O_O_O(c__env, c__out, c__n any) { t.F_env = c__env; t.F_out = c__out; t.F_n = c__n }
//line :125:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000060_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 bool; var tmp2 any = A_arbace_j2g_vh_A_const_81; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(x__1)); if and__1927000168__auto____2 { var tmp3 *lang.Keyword = A_arbace_j2g_vh_A_const_44; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_82.GetRawRoot__O(), tmp3.Invoke_O__O(A_arbace_j2g_vh_A_const_21.Invoke_O__O(x__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var f__2 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(x__1); var o__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__2)

		if jrt.J2g_Truth(or__1927000174__auto____3) { o__3 = or__1927000174__auto____3 } else { o__3 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__2) }
//line :126:1
		var temp__1927000414__auto____4 any; var root_409 any = A_arbace_j2g_vh_A_const_65.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, A_arbace_j2g_vh_handle_spec_A_fn_class); var ifn_411 lang.IFn


		if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = t.F_n; var arg_413 any = A_arbace_j2g_vh_A_const_31.Invoke_O__O(x__1); var arg_414 any; var root_415 any = A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_415, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_417 lang.IFn; if linked_416 == nil { ifn_417 = lang.IFn_Cast(root_415) } else { ifn_417 = nil }; var arg_418 any = t.F_env; if linked_416 == nil { arg_414 = ifn_417.Invoke_O__O(arg_418) } else { arg_414 = linked_416.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_415, arg_418) }; if linked_410 == nil { temp__1927000414__auto____4 = ifn_411.Invoke_O_O_O__O(arg_412, arg_413, arg_414) } else { temp__1927000414__auto____4 = linked_410.(*A_arbace_j2g_vh_handle_spec_A).Invoke_O_O_O_O__O(root_409, arg_412, arg_413, arg_414) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var spec__5 any = temp__1927000414__auto____4; var root_419 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_420 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_419, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_421 lang.IFn
			if linked_420 == nil { ifn_421 = lang.IFn_Cast(root_419) } else { ifn_421 = nil }; var arg_422 any = t.F_out; var arg_423 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_424 any = lang.Tuple_Create_O_O__IPersistentVector(o__3, A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__2)); var arg_425 any = spec__5; if linked_420 == nil { return ifn_421.Invoke_O_O_O_O__O(arg_422, arg_423, arg_424, arg_425) } else { return linked_420.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_419, arg_422, arg_423, arg_424, arg_425) } } else {
//line :129:1
				return nil } } else {
//line :126:1
					return nil } }
//line :125:1
func A_arbace_j2g_vh_class_handles_fn__1348000062_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_vh_class_handles_fn__1348000062_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_fn__1348000062_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :125:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000062_A) Ctor_O_O_O(c__env, c__out, c__n any) { t.F_env = c__env; t.F_out = c__out; t.F_n = c__n }
//line :125:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000062_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 bool; var tmp2 any = A_arbace_j2g_vh_A_const_81; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(x__1)); if and__1927000168__auto____2 { var tmp3 *lang.Keyword = A_arbace_j2g_vh_A_const_44; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_82.GetRawRoot__O(), tmp3.Invoke_O__O(A_arbace_j2g_vh_A_const_21.Invoke_O__O(x__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var f__2 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(x__1); var o__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__2)

		if jrt.J2g_Truth(or__1927000174__auto____3) { o__3 = or__1927000174__auto____3 } else { o__3 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__2) }
//line :126:1
		var temp__1927000414__auto____4 any; var root_436 any = A_arbace_j2g_vh_A_const_65.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, A_arbace_j2g_vh_handle_spec_A_fn_class); var ifn_438 lang.IFn


		if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = t.F_n; var arg_440 any = A_arbace_j2g_vh_A_const_31.Invoke_O__O(x__1); var arg_441 any; var root_442 any = A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_444 lang.IFn; if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = t.F_env; if linked_443 == nil { arg_441 = ifn_444.Invoke_O__O(arg_445) } else { arg_441 = linked_443.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_442, arg_445) }; if linked_437 == nil { temp__1927000414__auto____4 = ifn_438.Invoke_O_O_O__O(arg_439, arg_440, arg_441) } else { temp__1927000414__auto____4 = linked_437.(*A_arbace_j2g_vh_handle_spec_A).Invoke_O_O_O_O__O(root_436, arg_439, arg_440, arg_441) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var spec__5 any = temp__1927000414__auto____4; var root_446 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_448 lang.IFn
			if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = t.F_out; var arg_450 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_451 any = lang.Tuple_Create_O_O__IPersistentVector(o__3, A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__2)); var arg_452 any = spec__5; if linked_447 == nil { return ifn_448.Invoke_O_O_O_O__O(arg_449, arg_450, arg_451, arg_452) } else { return linked_447.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_446, arg_449, arg_450, arg_451, arg_452) } } else {
//line :129:1
				return nil } } else {
//line :126:1
					return nil
				}
}





func A_arbace_j2g_vh_handles_A_New() *A_arbace_j2g_vh_handles_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_j2g_vh_handles_A) Ctor() {}
//line :134:1
func (t *A_arbace_j2g_vh_handles_A) Invoke_O_O__O(self, class_names__0 any) any { var hs__2 any; var root_458 any = A_arbace_j2g_vh_A_const_83.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_460 lang.IFn; if



	linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_462 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_New(); var tmp2 *jrt.Class; var fncls__567 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_fn_class; if fncls__567 == nil { var fncls__567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_fn_class = fncls__567d; tmp2 = fncls__567d } else { tmp2 = fncls__567 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); arg_462 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(class_names__0); if linked_459 == nil { hs__2 = ifn_460.Invoke_O_O__O(arg_461, arg_462) } else { hs__2 = linked_459.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_458, arg_461, arg_462) }; var tmp3 any = A_arbace_j2g_vh_A_const_92; var tmp4 any = A_arbace_j2g_vh_A_const_36; var tmp5 any; var root_568 any = /*line :134:1*/A_arbace_j2g_vh_A_const_93.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_570 lang.IFn; if









	linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any; var iter__1927001039__auto____3 any; var tmp6 any = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_New(); var tmp7 *jrt.Class; var fncls__634 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_fn_class; if fncls__634 == nil { var fncls__634d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_fn_class = fncls__634d; tmp7 = fncls__634d } else { tmp7 = fncls__634 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); arg_571 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(hs__2); if linked_569 == nil { tmp5 = ifn_570.Invoke_O__O(arg_571) } else { tmp5 = linked_569.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_568, arg_571) }; return /*line :134:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, hs__2, tmp4, tmp5)) }



func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_New() *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A) Ctor() {}
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A) Invoke_O_O__O(self, s__1348000067__1 any) any { var tmp1 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_New_O_O(s__1348000067__1, self); var tmp2 *jrt.Class; var fncls__566 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_fn_class; if fncls__566 == nil { var fncls__566d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_fn_class = fncls__566d; tmp2 = fncls__566d } else { tmp2 = fncls__566 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :138:1
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_New_O_O(p0, p1 any) *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A) Ctor_O_O(c__s__1348000067, c__iter__1348000066 any) { t.F_s__1348000067 = c__s__1348000067; t.F_iter__1348000066 = c__iter__1348000066 }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A) Invoke_O__O(self any) any { { var s__1348000067__1 any; var t_ any = t.F_s__1348000067; t.F_s__1348000067 = nil; s__1348000067__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_463 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = s__1348000067__1; if linked_464 == nil { temp__1927000414__auto____2 = ifn_465.Invoke_O__O(arg_466) } else { temp__1927000414__auto____2 = linked_464.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_463, arg_466) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_467 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = xs__1927001018__auto____3; if linked_468 == nil { n__4 = ifn_469.Invoke_O__O(arg_470) } else { n__4 = linked_468.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_467, arg_470) }; var d__5 any; var root_471 any = A_arbace_j2g_vh_A_const_34.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_473 lang.IFn
														if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = n__4; if linked_472 == nil { d__5 = ifn_473.Invoke_O__O(arg_474) } else { d__5 = linked_472.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_471, arg_474) }
//line :138:1
	var tmp1 any
	var and__1927000168__auto____6 any = d__5
	if jrt.J2g_Truth(and__1927000168__auto____6) { var root_475 any = A_arbace_j2g_vh_A_const_35.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any; var tmp2 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_New(); var tmp3 *jrt.Class; var fncls__480 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_fn_class; if fncls__480 == nil { var fncls__480d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_fn_class = fncls__480d; tmp3 = fncls__480d } else { tmp3 = fncls__480 }; arg_478 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_479 any = A_arbace_j2g_vh_A_const_36.Invoke_O__O(d__5); if linked_476 == nil { tmp1 = ifn_477.Invoke_O_O__O(arg_478, arg_479) } else { tmp1 = linked_476.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_475, arg_478, arg_479) } } else { tmp1 = and__1927000168__auto____6 }
//line :138:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____6 any; var tmp4 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_New(); var tmp5 *jrt.Class; var fncls__539 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_fn_class; if fncls__539 == nil { var fncls__539d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_fn_class = fncls__539d; tmp5 = fncls__539d } else { tmp5 = fncls__539 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var fs__1927001036__auto____7 any; var root_540 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_542 lang.IFn; if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any; var tmp6 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____6); var tmp7 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_New_O(n__4); var tmp8 *jrt.Class
		var fncls__548 /*line :138:1*/*jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_fn_class


		if fncls__548 == nil { var fncls__548d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_fn_class = fncls__548d; tmp8 = fncls__548d } else { tmp8 = fncls__548 }
//line :138:1
		arg_543 = tmp6.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()); if linked_541 == nil { fs__1927001036__auto____7 = ifn_542.Invoke_O__O(arg_543) } else { fs__1927001036__auto____7 = linked_541.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_540, arg_543) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_549 any = A_arbace_j2g_vh_A_const_91.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = fs__1927001036__auto____7; var arg_553 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1348000066); var tmp10 any; var root_554 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = s__1348000067__1; if linked_555 == nil { tmp10 = ifn_556.Invoke_O__O(arg_557) } else { tmp10 = linked_555.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_554, arg_557) }; arg_553 = tmp9.Invoke_O__O(tmp10); if linked_550 == nil { return ifn_551.Invoke_O_O__O(arg_552, arg_553) } else { return linked_550.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_549, arg_552, arg_553) } } else { var tmp11 any; var root_558 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = s__1348000067__1; if linked_559 == nil { tmp11 = ifn_560.Invoke_O__O(arg_561) } else { tmp11 = linked_559.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_558, arg_561) }; s__1348000067__1 = tmp11; continue L1 } } else { var tmp12 any; var root_562 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = s__1348000067__1; if linked_563 == nil { tmp12 = ifn_564.Invoke_O__O(arg_565) } else { tmp12 = linked_563.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_562, arg_565) }; s__1348000067__1 = tmp12; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :138:1
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_New() *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A) Ctor() {}
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A) Invoke_O_O__O(self, s__1348000069__1 any) any { var tmp1 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_New_O_O(self, s__1348000069__1); var tmp2 *jrt.Class; var fncls__538 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_fn_class; if fncls__538 == nil { var fncls__538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_fn_class = fncls__538d; tmp2 = fncls__538d } else { tmp2 = fncls__538 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :138:1
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_New_O_O(p0, p1 any) *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A) Ctor_O_O(c__iter__1348000068, c__s__1348000069 any) { t.F_iter__1348000068 = c__iter__1348000068; t.F_s__1348000069 = c__s__1348000069 }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A) Invoke_O__O(self any) any { { var s__1348000069__1 any; var t_ any = t.F_s__1348000069; t.F_s__1348000069 = nil; s__1348000069__1 = t_; for { var temp__1927000414__auto____2 any; var root_481 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_483 lang.IFn; if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any = s__1348000069__1; if linked_482 == nil { temp__1927000414__auto____2 = ifn_483.Invoke_O__O(arg_484) } else { temp__1927000414__auto____2 = linked_482.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_481, arg_484) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1348000069__3 any = temp__1927000414__auto____2; var tmp1 any; var root_485 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = s__1348000069__3; if linked_486 == nil { tmp1 = ifn_487.Invoke_O__O(arg_488) } else { tmp1 = linked_486.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_485, arg_488) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_489 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_491 lang.IFn; if linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = s__1348000069__3; if linked_490 == nil { c__1927001037__auto____4 = ifn_491.Invoke_O__O(arg_492) } else { c__1927001037__auto____4 = linked_490.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_489, arg_492) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1348000071__6 any; var root_493 any = A_arbace_j2g_vh_A_const_84.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_495 lang.IFn; if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_494 == nil { b__1348000071__6 = ifn_495.Invoke_O__O(arg_496) } else { b__1348000071__6 = linked_494.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_493, arg_496) }; var tmp2 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_New_O_I_O(b__1348000071__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__502 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_fn_class; if fncls__502 == nil { var fncls__502d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_fn_class = fncls__502d; tmp3 = fncls__502d } else { tmp3 = fncls__502 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_503 any = A_arbace_j2g_vh_A_const_86.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any; var root_508 any = A_arbace_j2g_vh_A_const_87.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = b__1348000071__6; if linked_509 == nil { arg_506 = ifn_510.Invoke_O__O(arg_511) } else { arg_506 = linked_509.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_508, arg_511) }; var arg_507 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1348000068); var tmp5 any; var root_512 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = s__1348000069__3; if linked_513 == nil { tmp5 = ifn_514.Invoke_O__O(arg_515) } else { tmp5 = linked_513.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_512, arg_515) }; arg_507 = tmp4.Invoke_O__O(tmp5); if linked_504 == nil { return ifn_505.Invoke_O_O__O(arg_506, arg_507) } else { return linked_504.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_503, arg_506, arg_507) } } else { var root_516 any = A_arbace_j2g_vh_A_const_86.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_518 lang.IFn; if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any; var root_521 any = A_arbace_j2g_vh_A_const_87.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = b__1348000071__6; if linked_522 == nil { arg_519 = ifn_523.Invoke_O__O(arg_524) } else { arg_519 = linked_522.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_521, arg_524) }; var arg_520 any; if linked_517 == nil { return ifn_518.Invoke_O_O__O(arg_519, arg_520) } else { return linked_517.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_516, arg_519, arg_520) } } } else { var e__4 any; var root_525 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = s__1348000069__3; if linked_526 == nil { e__4 = ifn_527.Invoke_O__O(arg_528) } else { e__4 = linked_526.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_525, arg_528) }; var root_529 any = A_arbace_j2g_vh_A_const_88.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = e__4; var arg_533 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1348000068); var tmp7 any; var root_534 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = s__1348000069__3; if linked_535 == nil { tmp7 = ifn_536.Invoke_O__O(arg_537) } else { tmp7 = linked_535.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_534, arg_537) }; arg_533 = tmp6.Invoke_O__O(tmp7); if linked_530 == nil { return ifn_531.Invoke_O_O__O(arg_532, arg_533) } else { return linked_530.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_529, arg_532, arg_533) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :138:1
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A) Ctor_O_I_O(c__b__1348000071 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1348000071 = c__b__1348000071; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :138:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A) Invoke_O__O(self any) any { { var i__1348000070__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1348000070__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1348000070__1)); var root_497 any = A_arbace_j2g_vh_A_const_85.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = t.F_b__1348000071; var arg_501 any = e__2; if linked_498 == nil { ifn_499.Invoke_O_O__O(arg_500, arg_501) } else { linked_498.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_497, arg_500, arg_501) }; i__1348000070__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1348000070__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_New() *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A) Ctor() {}
//line :140:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A) Invoke_O_O__O(self, p1__1348000065_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_82.GetRawRoot__O(), A_arbace_j2g_vh_A_const_44.Invoke_O__O(p1__1348000065_SHARP___1))).Ref() }
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_New_O(p0 any) *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A{}; t.Ctor_O(p0); return t }
//line :141:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :141:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_544 any = A_arbace_j2g_vh_A_const_90.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, A_arbace_j2g_vh_class_handles_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any; var t_ any = t.F_n; t.F_n = nil; arg_547 = t_; if linked_545 == nil { tmp1 = ifn_546.Invoke_O__O(arg_547) } else { tmp1 = linked_545.(*A_arbace_j2g_vh_class_handles_A).Invoke_O_O__O(root_544, arg_547) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_New() *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A) Ctor() {}
//line :144:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A) Invoke_O_O__O(self, s__1348000087__1 any) any { var tmp1 any = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_New_O_O(s__1348000087__1, self); var tmp2 *jrt.Class; var fncls__633 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_fn_class; if fncls__633 == nil { var fncls__633d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_fn_class = fncls__633d; tmp2 = fncls__633d } else { tmp2 = fncls__633 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :144:1
func A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_New_O_O(p0, p1 any) *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A{}; t.Ctor_O_O(p0, p1); return t }
//line :144:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A) Ctor_O_O(c__s__1348000087, c__iter__1348000086 any) { t.F_s__1348000087 = c__s__1348000087; t.F_iter__1348000086 = c__iter__1348000086 }
//line :144:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A) Invoke_O__O(self any) any { { var s__1348000087__1 any; var t_ any = t.F_s__1348000087; t.F_s__1348000087 = nil; s__1348000087__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_572 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any = s__1348000087__1; if linked_573 == nil { temp__1927000414__auto____2 = ifn_574.Invoke_O__O(arg_575) } else { temp__1927000414__auto____2 = linked_573.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_572, arg_575) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1348000087__3 any = temp__1927000414__auto____2; var tmp1 any; var root_576 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_576, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_578 lang.IFn; if linked_577 == nil { ifn_578 = lang.IFn_Cast(root_576) } else { ifn_578 = nil }; var arg_579 any = s__1348000087__3; if linked_577 == nil { tmp1 = ifn_578.Invoke_O__O(arg_579) } else { tmp1 = linked_577.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_576, arg_579) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_580 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = s__1348000087__3; if linked_581 == nil { c__1927001037__auto____4 = ifn_582.Invoke_O__O(arg_583) } else { c__1927001037__auto____4 = linked_581.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_580, arg_583) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1348000089__6 any; var root_584 any = A_arbace_j2g_vh_A_const_84.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_585 == nil { b__1348000089__6 = ifn_586.Invoke_O__O(arg_587) } else { b__1348000089__6 = linked_585.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_584, arg_587) }; var tmp2 any = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_New_O_I_O(b__1348000089__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__593 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_fn_class; if fncls__593 == nil { var fncls__593d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_fn_class = fncls__593d; tmp3 = fncls__593d } else { tmp3 = fncls__593 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_594 any = A_arbace_j2g_vh_A_const_86.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any; var root_599 any = A_arbace_j2g_vh_A_const_87.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_601 lang.IFn; if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any = b__1348000089__6; if linked_600 == nil { arg_597 = ifn_601.Invoke_O__O(arg_602) } else { arg_597 = linked_600.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_599, arg_602) }; var arg_598 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1348000086); var tmp5 any; var root_603 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = s__1348000087__3; if linked_604 == nil { tmp5 = ifn_605.Invoke_O__O(arg_606) } else { tmp5 = linked_604.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_603, arg_606) }; arg_598 = tmp4.Invoke_O__O(tmp5); if linked_595 == nil { return ifn_596.Invoke_O_O__O(arg_597, arg_598) } else { return linked_595.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_594, arg_597, arg_598) } } else { var root_607 any = A_arbace_j2g_vh_A_const_86.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any; var root_612 any = A_arbace_j2g_vh_A_const_87.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = b__1348000089__6; if linked_613 == nil { arg_610 = ifn_614.Invoke_O__O(arg_615) } else { arg_610 = linked_613.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_612, arg_615) }; var arg_611 any; if linked_608 == nil { return ifn_609.Invoke_O_O__O(arg_610, arg_611) } else { return linked_608.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_607, arg_610, arg_611) } } } else { var vec__1348000097__4 any; var root_616 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = s__1348000087__3; if linked_617 == nil { vec__1348000097__4 = ifn_618.Invoke_O__O(arg_619) } else { vec__1348000097__4 = linked_617.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_616, arg_619) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000097__4, lang.RT_IntCast_J__I_NoInit(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000097__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any = A_arbace_j2g_vh_A_const_21; _ = ___5; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_j2g_vh_A_const_46.Invoke_O__O(s__6)) { var root_620 any = A_arbace_j2g_vh_A_const_88.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_vh_A_const_19.Invoke_O__O(s__6), A_arbace_j2g_vh_A_const_22.Invoke_O__O(s__6)); var arg_624 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1348000086); var tmp8 any; var root_625 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = s__1348000087__3; if linked_626 == nil { tmp8 = ifn_627.Invoke_O__O(arg_628) } else { tmp8 = linked_626.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_625, arg_628) }; arg_624 = tmp7.Invoke_O__O(tmp8); if linked_621 == nil { return ifn_622.Invoke_O_O__O(arg_623, arg_624) } else { return linked_621.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_620, arg_623, arg_624) } } else { var tmp9 any; var root_629 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_629, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_631 lang.IFn; if linked_630 == nil { ifn_631 = lang.IFn_Cast(root_629) } else { ifn_631 = nil }; var arg_632 any = s__1348000087__3; if linked_630 == nil { tmp9 = ifn_631.Invoke_O__O(arg_632) } else { tmp9 = linked_630.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_629, arg_632) }; s__1348000087__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :144:1
func A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :144:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A) Ctor_O_I_O(c__b__1348000089 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1348000089 = c__b__1348000089; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :144:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A) Invoke_O__O(self any) any { { var i__1348000088__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1348000088__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1348000093__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1348000088__1)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000093__2, lang.RT_IntCast_J__I_NoInit(0), nil); var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000093__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any = A_arbace_j2g_vh_A_const_21; _ = ___3; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_46.Invoke_O__O(s__4)) { var root_588 any = A_arbace_j2g_vh_A_const_85.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = t.F_b__1348000089; var arg_592 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_vh_A_const_19.Invoke_O__O(s__4), A_arbace_j2g_vh_A_const_22.Invoke_O__O(s__4)); if linked_589 == nil { ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { linked_589.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) }; i__1348000088__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1348000088__1); continue L1 } else { i__1348000088__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1348000088__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_vh_mode_A_New() *A_arbace_j2g_vh_mode_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_mode_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_j2g_vh_mode_A) Ctor() {}
//line :151:1
func (t *A_arbace_j2g_vh_mode_A) Invoke_O_O__O(self, name__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_94).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_95 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_96).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_97 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_98).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_99 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_100).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_101 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_102).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_103 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_104).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_105 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_106).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_107 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_108).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_109 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_110).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_111 } else { if A_arbace_j2g_vh_A_const_66 != nil { return nil } else { return nil
	}
	}
	}
	}
	}
	}
	}
	}
	}
	}
}

func A_arbace_j2g_vh_fence_QMARK__A_New() *A_arbace_j2g_vh_fence_QMARK__A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_fence_QMARK__A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_j2g_vh_fence_QMARK__A) Ctor() {}
//line :167:1
func (t *A_arbace_j2g_vh_fence_QMARK__A) Invoke_O_O__O(self, node__0 any) any { var tmp1 any = A_arbace_j2g_vh_A_const_47; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__0)); if and__1927000168__auto____2 {
										var tmp2 any = A_arbace_j2g_vh_A_const_53; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_46.Invoke_O__O(node__0)); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_60.GetRawRoot__O(), A_arbace_j2g_vh_A_const_28.Invoke_O__O(node__0)); if and__1927000168__auto____4 { return lang.IFn_Cast(A_arbace_j2g_vh_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_vh_A_const_22.Invoke_O__O(node__0)) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_vh_op_handle_A_New() *A_arbace_j2g_vh_op_handle_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_op_handle_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_j2g_vh_op_handle_A) Ctor() {}
//line :170:1
func (t *A_arbace_j2g_vh_op_handle_A) Invoke_O_O_O__O(self, hs__0, node__1 any) any {



	var tmp1 any; var tmp2 any = A_arbace_j2g_vh_A_const_47; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__1)); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_60.GetRawRoot__O(), A_arbace_j2g_vh_A_const_28.Invoke_O__O(node__1)); if and__1927000168__auto____4 { var root_635 any = A_arbace_j2g_vh_A_const_113.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = A_arbace_j2g_vh_A_const_53; var arg_639 any = A_arbace_j2g_vh_A_const_46.Invoke_O__O(node__1); if linked_636 == nil { tmp1 = ifn_637.Invoke_O_O__O(arg_638, arg_639) } else { tmp1 = linked_636.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_635, arg_638, arg_639) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { var tg__3 any; var root_640 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_642 lang.IFn
		if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = A_arbace_j2g_vh_A_const_64.Invoke_O__O(node__1); if linked_641 == nil { tg__3 = ifn_642.Invoke_O__O(arg_643) } else { tg__3 = linked_641.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_640, arg_643) }
		var tmp3 any = A_arbace_j2g_vh_A_const_20; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_vh_A_const_14.Invoke_O__O(tg__3)) { var f__4 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(tg__3); var spec__5 any; var tmp4 any; var or__1927000174__auto____5 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__4)

			if jrt.J2g_Truth(or__1927000174__auto____5) { tmp4 = or__1927000174__auto____5 } else { tmp4 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__4) }; spec__5 = lang.RT_Get_O_O__O_NoInit(hs__0, lang.Tuple_Create_O_O__IPersistentVector(tmp4, A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__4)))
//line :176:1
			var m__6 any; var root_644 any = A_arbace_j2g_vh_A_const_114.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, A_arbace_j2g_vh_mode_A_fn_class); var ifn_646 lang.IFn


			if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = A_arbace_j2g_vh_A_const_22.Invoke_O__O(node__1); if linked_645 == nil { m__6 = ifn_646.Invoke_O__O(arg_647) } else { m__6 = linked_645.(*A_arbace_j2g_vh_mode_A).Invoke_O_O__O(root_644, arg_647) }
			var tmp5 any; var and__1927000168__auto____7 any = spec__5; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp5 = m__6 } else { tmp5 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp5) { var root_648 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = spec__5; var arg_652 any = A_arbace_j2g_vh_A_const_115; var arg_653 any = m__6; if linked_649 == nil { return ifn_650.Invoke_O_O_O__O(arg_651, arg_652, arg_653) } else { return linked_649.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_648, arg_651, arg_652, arg_653) } } else { return nil } } else {
//line :176:1
				return nil } } else {
//line :174:1
					return nil
				}
}




















































type A_arbace_j2g_vh_A struct{ jrt.Object }

var A_arbace_j2g_vh_A_const_pool *jrt.RefArray

var A_arbace_j2g_vh_A_const_0 *lang.Var

var A_arbace_j2g_vh_A_const_1 any

var A_arbace_j2g_vh_A_const_2 any

var A_arbace_j2g_vh_A_const_3 any

var A_arbace_j2g_vh_A_const_4 any

var A_arbace_j2g_vh_A_const_5 any

var A_arbace_j2g_vh_A_const_6 *lang.Var

var A_arbace_j2g_vh_A_const_7 any

var A_arbace_j2g_vh_A_const_8 *lang.Var

var A_arbace_j2g_vh_A_const_9 *lang.Var

var A_arbace_j2g_vh_A_const_10 *lang.Var

var A_arbace_j2g_vh_A_const_11 *lang.Var

var A_arbace_j2g_vh_A_const_12 any

var A_arbace_j2g_vh_A_const_13 *lang.Var

var A_arbace_j2g_vh_A_const_14 *lang.Keyword

var A_arbace_j2g_vh_A_const_15 *lang.Keyword

var A_arbace_j2g_vh_A_const_16 *lang.Var

var A_arbace_j2g_vh_A_const_17 *lang.Keyword

var A_arbace_j2g_vh_A_const_18 *lang.Keyword

var A_arbace_j2g_vh_A_const_19 *lang.Keyword

var A_arbace_j2g_vh_A_const_20 *lang.Keyword

var A_arbace_j2g_vh_A_const_21 *lang.Keyword

var A_arbace_j2g_vh_A_const_22 *lang.Keyword

var A_arbace_j2g_vh_A_const_23 *lang.Var

var A_arbace_j2g_vh_A_const_24 *lang.Keyword

var A_arbace_j2g_vh_A_const_25 *lang.Keyword

var A_arbace_j2g_vh_A_const_26 *lang.Keyword

var A_arbace_j2g_vh_A_const_27 *lang.Keyword

var A_arbace_j2g_vh_A_const_28 *lang.Keyword

var A_arbace_j2g_vh_A_const_29 *lang.Keyword

var A_arbace_j2g_vh_A_const_30 *lang.Var

var A_arbace_j2g_vh_A_const_31 *lang.Keyword

var A_arbace_j2g_vh_A_const_32 any

var A_arbace_j2g_vh_A_const_33 *lang.Var

var A_arbace_j2g_vh_A_const_34 *lang.Var

var A_arbace_j2g_vh_A_const_35 *lang.Var

var A_arbace_j2g_vh_A_const_36 *lang.Keyword

var A_arbace_j2g_vh_A_const_37 *lang.Keyword

var A_arbace_j2g_vh_A_const_38 *lang.Var

var A_arbace_j2g_vh_A_const_39 *lang.Keyword

var A_arbace_j2g_vh_A_const_40 any

var A_arbace_j2g_vh_A_const_41 *lang.Var

var A_arbace_j2g_vh_A_const_42 *lang.Var

var A_arbace_j2g_vh_A_const_43 *lang.Var

var A_arbace_j2g_vh_A_const_44 *lang.Keyword

var A_arbace_j2g_vh_A_const_45 *lang.Var

var A_arbace_j2g_vh_A_const_46 *lang.Keyword

var A_arbace_j2g_vh_A_const_47 *lang.Keyword

var A_arbace_j2g_vh_A_const_48 *lang.Var

var A_arbace_j2g_vh_A_const_49 *lang.Var

var A_arbace_j2g_vh_A_const_50 *lang.Var

var A_arbace_j2g_vh_A_const_51 *lang.Var

var A_arbace_j2g_vh_A_const_52 *lang.Keyword

var A_arbace_j2g_vh_A_const_53 *lang.Keyword

var A_arbace_j2g_vh_A_const_54 *lang.Var

var A_arbace_j2g_vh_A_const_55 *lang.Keyword

var A_arbace_j2g_vh_A_const_56 *lang.Var

var A_arbace_j2g_vh_A_const_57 any

var A_arbace_j2g_vh_A_const_58 *lang.Keyword

var A_arbace_j2g_vh_A_const_59 *lang.Keyword

var A_arbace_j2g_vh_A_const_60 *lang.Var

var A_arbace_j2g_vh_A_const_61 any

var A_arbace_j2g_vh_A_const_62 *lang.Var

var A_arbace_j2g_vh_A_const_63 *lang.Var

var A_arbace_j2g_vh_A_const_64 *lang.Keyword

var A_arbace_j2g_vh_A_const_65 *lang.Var

var A_arbace_j2g_vh_A_const_66 *lang.Keyword

var A_arbace_j2g_vh_A_const_67 *lang.Var

var A_arbace_j2g_vh_A_const_68 *lang.Keyword

var A_arbace_j2g_vh_A_const_69 *lang.Keyword

var A_arbace_j2g_vh_A_const_70 *lang.Var

var A_arbace_j2g_vh_A_const_71 *lang.Var

var A_arbace_j2g_vh_A_const_72 *lang.Var

var A_arbace_j2g_vh_A_const_73 *lang.Var

var A_arbace_j2g_vh_A_const_74 any

var A_arbace_j2g_vh_A_const_75 *lang.Keyword

var A_arbace_j2g_vh_A_const_76 *lang.Keyword

var A_arbace_j2g_vh_A_const_77 *lang.Var

var A_arbace_j2g_vh_A_const_78 *lang.Var

var A_arbace_j2g_vh_A_const_79 *lang.Var

var A_arbace_j2g_vh_A_const_80 any

var A_arbace_j2g_vh_A_const_81 *lang.Keyword

var A_arbace_j2g_vh_A_const_82 *lang.Var

var A_arbace_j2g_vh_A_const_83 *lang.Var

var A_arbace_j2g_vh_A_const_84 *lang.Var

var A_arbace_j2g_vh_A_const_85 *lang.Var

var A_arbace_j2g_vh_A_const_86 *lang.Var

var A_arbace_j2g_vh_A_const_87 *lang.Var

var A_arbace_j2g_vh_A_const_88 *lang.Var

var A_arbace_j2g_vh_A_const_89 *lang.Var

var A_arbace_j2g_vh_A_const_90 *lang.Var

var A_arbace_j2g_vh_A_const_91 *lang.Var

var A_arbace_j2g_vh_A_const_92 *lang.Keyword

var A_arbace_j2g_vh_A_const_93 *lang.Var

var A_arbace_j2g_vh_A_const_94 any

var A_arbace_j2g_vh_A_const_95 *lang.Keyword

var A_arbace_j2g_vh_A_const_96 any

var A_arbace_j2g_vh_A_const_97 *lang.Keyword

var A_arbace_j2g_vh_A_const_98 any

var A_arbace_j2g_vh_A_const_99 *lang.Keyword

var A_arbace_j2g_vh_A_const_100 any

var A_arbace_j2g_vh_A_const_101 *lang.Keyword

var A_arbace_j2g_vh_A_const_102 any

var A_arbace_j2g_vh_A_const_103 *lang.Keyword

var A_arbace_j2g_vh_A_const_104 any

var A_arbace_j2g_vh_A_const_105 *lang.Keyword

var A_arbace_j2g_vh_A_const_106 any

var A_arbace_j2g_vh_A_const_107 *lang.Keyword

var A_arbace_j2g_vh_A_const_108 any

var A_arbace_j2g_vh_A_const_109 *lang.Keyword

var A_arbace_j2g_vh_A_const_110 any

var A_arbace_j2g_vh_A_const_111 *lang.Keyword

var A_arbace_j2g_vh_A_const_112 *lang.Var

var A_arbace_j2g_vh_A_const_113 *lang.Var

var A_arbace_j2g_vh_A_const_114 *lang.Var

var A_arbace_j2g_vh_A_const_115 *lang.Keyword

var A_arbace_j2g_vh_A_init jrt.ClassInit

func A_arbace_j2g_vh_A_Init() { if !A_arbace_j2g_vh_A_init.Done() { A_arbace_j2g_vh_A_init.Run(A_arbace_j2g_vh_A_clinit) } }

func A_arbace_j2g_vh_A_clinit() { A_arbace_j2g_vh_A_clinit_p0(); A_arbace_j2g_vh_A_clinit_p1(); A_arbace_j2g_vh_A_clinit_p2(); A_arbace_j2g_vh_A_clinit_p3(); A_arbace_j2g_vh_A_clinit_p4(); A_arbace_j2g_vh_A_clinit_p5(); A_arbace_j2g_vh_A_clinit_p6(); A_arbace_j2g_vh_A_clinit_p7(); A_arbace_j2g_vh_A_clinit_p8(); A_arbace_j2g_vh_A_clinit_p9() }

func A_arbace_j2g_vh_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_vh_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 175); A_arbace_j2g_vh_A_const_0 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[59]); A_arbace_j2g_vh_A_const_1 = A_arbace_j2g_vh_A_const_pool.A[60]; A_arbace_j2g_vh_A_const_2 = A_arbace_j2g_vh_A_const_pool.A[61]; A_arbace_j2g_vh_A_const_3 = A_arbace_j2g_vh_A_const_pool.A[62]; A_arbace_j2g_vh_A_const_4 = A_arbace_j2g_vh_A_const_pool.A[63]; A_arbace_j2g_vh_A_const_5 = A_arbace_j2g_vh_A_const_pool.A[64]; A_arbace_j2g_vh_A_const_6 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[65]); A_arbace_j2g_vh_A_const_7 = A_arbace_j2g_vh_A_const_pool.A[66]; A_arbace_j2g_vh_A_const_8 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[67]); A_arbace_j2g_vh_A_const_9 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[68]); A_arbace_j2g_vh_A_const_10 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[69]); A_arbace_j2g_vh_A_const_11 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[70]); A_arbace_j2g_vh_A_const_12 = A_arbace_j2g_vh_A_const_pool.A[71] }

func A_arbace_j2g_vh_A_clinit_p1() { A_arbace_j2g_vh_A_const_13 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[72]); A_arbace_j2g_vh_A_const_14 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[73]); A_arbace_j2g_vh_A_const_15 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[74]); A_arbace_j2g_vh_A_const_16 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[75]); A_arbace_j2g_vh_A_const_17 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[76]); A_arbace_j2g_vh_A_const_18 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[77]); A_arbace_j2g_vh_A_const_19 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[78]); A_arbace_j2g_vh_A_const_20 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[79]); A_arbace_j2g_vh_A_const_21 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[80]); A_arbace_j2g_vh_A_const_22 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[81]); A_arbace_j2g_vh_A_const_23 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[82]); A_arbace_j2g_vh_A_const_24 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[83]) }

func A_arbace_j2g_vh_A_clinit_p2() { A_arbace_j2g_vh_A_const_25 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[84]); A_arbace_j2g_vh_A_const_26 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[85]); A_arbace_j2g_vh_A_const_27 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[86]); A_arbace_j2g_vh_A_const_28 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[87]); A_arbace_j2g_vh_A_const_29 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[88]); A_arbace_j2g_vh_A_const_30 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[89]); A_arbace_j2g_vh_A_const_31 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[90]); A_arbace_j2g_vh_A_const_32 = A_arbace_j2g_vh_A_const_pool.A[91]; A_arbace_j2g_vh_A_const_33 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[92]); A_arbace_j2g_vh_A_const_34 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[93]); A_arbace_j2g_vh_A_const_35 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[94]); A_arbace_j2g_vh_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[95]) }

func A_arbace_j2g_vh_A_clinit_p3() { A_arbace_j2g_vh_A_const_37 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[96]); A_arbace_j2g_vh_A_const_38 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[97]); A_arbace_j2g_vh_A_const_39 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[98]); A_arbace_j2g_vh_A_const_40 = A_arbace_j2g_vh_A_const_pool.A[99]; A_arbace_j2g_vh_A_const_41 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[100]); A_arbace_j2g_vh_A_const_42 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[101]); A_arbace_j2g_vh_A_const_43 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[102]); A_arbace_j2g_vh_A_const_44 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[103]); A_arbace_j2g_vh_A_const_45 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[104]); A_arbace_j2g_vh_A_const_46 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[105]); A_arbace_j2g_vh_A_const_47 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[106]); A_arbace_j2g_vh_A_const_48 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[107]) }

func A_arbace_j2g_vh_A_clinit_p4() { A_arbace_j2g_vh_A_const_49 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[108]); A_arbace_j2g_vh_A_const_50 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[109]); A_arbace_j2g_vh_A_const_51 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[110]); A_arbace_j2g_vh_A_const_52 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[111]); A_arbace_j2g_vh_A_const_53 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[112]); A_arbace_j2g_vh_A_const_54 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[113]); A_arbace_j2g_vh_A_const_55 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[114]); A_arbace_j2g_vh_A_const_56 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[115]); A_arbace_j2g_vh_A_const_57 = A_arbace_j2g_vh_A_const_pool.A[116]; A_arbace_j2g_vh_A_const_58 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[117]); A_arbace_j2g_vh_A_const_59 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[118]); A_arbace_j2g_vh_A_const_60 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[119]) }

func A_arbace_j2g_vh_A_clinit_p5() { A_arbace_j2g_vh_A_const_61 = A_arbace_j2g_vh_A_const_pool.A[120]; A_arbace_j2g_vh_A_const_62 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[121]); A_arbace_j2g_vh_A_const_63 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[122]); A_arbace_j2g_vh_A_const_64 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[123]); A_arbace_j2g_vh_A_const_65 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[124]); A_arbace_j2g_vh_A_const_66 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[125]); A_arbace_j2g_vh_A_const_67 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[126]); A_arbace_j2g_vh_A_const_68 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[127]); A_arbace_j2g_vh_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[128]); A_arbace_j2g_vh_A_const_70 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[129]); A_arbace_j2g_vh_A_const_71 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[130]); A_arbace_j2g_vh_A_const_72 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[131]) }

func A_arbace_j2g_vh_A_clinit_p6() { A_arbace_j2g_vh_A_const_73 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[132]); A_arbace_j2g_vh_A_const_74 = A_arbace_j2g_vh_A_const_pool.A[133]; A_arbace_j2g_vh_A_const_75 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[134]); A_arbace_j2g_vh_A_const_76 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[135]); A_arbace_j2g_vh_A_const_77 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[136]); A_arbace_j2g_vh_A_const_78 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[137]); A_arbace_j2g_vh_A_const_79 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[138]); A_arbace_j2g_vh_A_const_80 = A_arbace_j2g_vh_A_const_pool.A[139]; A_arbace_j2g_vh_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[140]); A_arbace_j2g_vh_A_const_82 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[141]); A_arbace_j2g_vh_A_const_83 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[142]); A_arbace_j2g_vh_A_const_84 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[143]) }

func A_arbace_j2g_vh_A_clinit_p7() { A_arbace_j2g_vh_A_const_85 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[144]); A_arbace_j2g_vh_A_const_86 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[145]); A_arbace_j2g_vh_A_const_87 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[146]); A_arbace_j2g_vh_A_const_88 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[147]); A_arbace_j2g_vh_A_const_89 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[148]); A_arbace_j2g_vh_A_const_90 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[149]); A_arbace_j2g_vh_A_const_91 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[150]); A_arbace_j2g_vh_A_const_92 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[151]); A_arbace_j2g_vh_A_const_93 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[152]); A_arbace_j2g_vh_A_const_94 = A_arbace_j2g_vh_A_const_pool.A[153]; A_arbace_j2g_vh_A_const_95 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[154]); A_arbace_j2g_vh_A_const_96 = A_arbace_j2g_vh_A_const_pool.A[155] }

func A_arbace_j2g_vh_A_clinit_p8() { A_arbace_j2g_vh_A_const_97 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[156]); A_arbace_j2g_vh_A_const_98 = A_arbace_j2g_vh_A_const_pool.A[157]; A_arbace_j2g_vh_A_const_99 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[158]); A_arbace_j2g_vh_A_const_100 = A_arbace_j2g_vh_A_const_pool.A[159]; A_arbace_j2g_vh_A_const_101 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[160]); A_arbace_j2g_vh_A_const_102 = A_arbace_j2g_vh_A_const_pool.A[161]; A_arbace_j2g_vh_A_const_103 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[162]); A_arbace_j2g_vh_A_const_104 = A_arbace_j2g_vh_A_const_pool.A[163]; A_arbace_j2g_vh_A_const_105 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[164]); A_arbace_j2g_vh_A_const_106 = A_arbace_j2g_vh_A_const_pool.A[165]; A_arbace_j2g_vh_A_const_107 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[166]); A_arbace_j2g_vh_A_const_108 = A_arbace_j2g_vh_A_const_pool.A[167]; A_arbace_j2g_vh_A_const_109 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[168]) }

func A_arbace_j2g_vh_A_clinit_p9() { A_arbace_j2g_vh_A_const_110 = A_arbace_j2g_vh_A_const_pool.A[169]; A_arbace_j2g_vh_A_const_111 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[170]); A_arbace_j2g_vh_A_const_112 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[171]); A_arbace_j2g_vh_A_const_113 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[172]); A_arbace_j2g_vh_A_const_114 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[173]); A_arbace_j2g_vh_A_const_115 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[174]) }

func A_arbace_j2g_vh_A_New() *A_arbace_j2g_vh_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_vh_A) Ctor() {}

func (t *A_arbace_j2g_vh_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_vh_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_vh_A_class }

func (t *A_arbace_j2g_vh_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_vh_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_vh_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_vh_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_vh_A); return ok }

func A_arbace_j2g_vh_A_Cast(x any) *A_arbace_j2g_vh_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_vh_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_vh_A_class)) }; return v }



type A_arbace_j2g_vh_byte_order_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_byte_order_arg_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_class_arg_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_class_handles_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_fn__1348000032_A struct{ j2g_header uint64; F_env any }

var A_arbace_j2g_vh_class_handles_fn__1348000032_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_fn__1348000044_A struct{ j2g_header uint64; F_env any }

var A_arbace_j2g_vh_class_handles_fn__1348000044_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_fn__1348000060_A struct{ j2g_header uint64; F_env, F_out, F_n any }

var A_arbace_j2g_vh_class_handles_fn__1348000060_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_fn__1348000062_A struct{ j2g_header uint64; F_env, F_out, F_n any }

var A_arbace_j2g_vh_class_handles_fn__1348000062_A_fn_class *jrt.Class



type A_arbace_j2g_vh_eval1348000004_A struct{ jrt.Object }

func A_arbace_j2g_vh_eval1348000004_A_New() *A_arbace_j2g_vh_eval1348000004_A { t := &A_arbace_j2g_vh_eval1348000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_vh_eval1348000004_A) Ctor() {}

func (t *A_arbace_j2g_vh_eval1348000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_vh_eval1348000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_vh_eval1348000004_A_class }

func (t *A_arbace_j2g_vh_eval1348000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_vh_eval1348000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_vh_eval1348000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_vh_eval1348000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_vh_eval1348000004_A); return ok }

func A_arbace_j2g_vh_eval1348000004_A_Cast(x any) *A_arbace_j2g_vh_eval1348000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_vh_eval1348000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_vh_eval1348000004_A_class)) }; return v }



type A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A_fn_class *jrt.Class



type A_arbace_j2g_vh_eval1348000008_A struct{ jrt.Object }

func A_arbace_j2g_vh_eval1348000008_A_New() *A_arbace_j2g_vh_eval1348000008_A { t := &A_arbace_j2g_vh_eval1348000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_vh_eval1348000008_A) Ctor() {}

func (t *A_arbace_j2g_vh_eval1348000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_vh_eval1348000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_vh_eval1348000008_A_class }

func (t *A_arbace_j2g_vh_eval1348000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_vh_eval1348000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_vh_eval1348000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_vh_eval1348000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_vh_eval1348000008_A); return ok }

func A_arbace_j2g_vh_eval1348000008_A_Cast(x any) *A_arbace_j2g_vh_eval1348000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_vh_eval1348000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_vh_eval1348000008_A_class)) }; return v }



type A_arbace_j2g_vh_eval1348000008_fn__1348000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_eval1348000008_fn__1348000009_A_fn_class *jrt.Class



type A_arbace_j2g_vh_fence_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_fence_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_vh_find_field_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_find_field_A_fn_class *jrt.Class



type A_arbace_j2g_vh_find_field_fn__1348000018_A struct{ j2g_header uint64; F_fname any }

var A_arbace_j2g_vh_find_field_fn__1348000018_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handle_spec_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handle_spec_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A struct{ j2g_header uint64; F_s__1348000067, F_iter__1348000066 any }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A struct{ j2g_header uint64; F_iter__1348000068, F_s__1348000069 any }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A struct{ j2g_header uint64; F_b__1348000071 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A struct{ j2g_header uint64; F_s__1348000087, F_iter__1348000086 any }

var A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A struct{ j2g_header uint64; F_b__1348000089 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_fn_class *jrt.Class



type A_arbace_j2g_vh_mode_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_mode_A_fn_class *jrt.Class



type A_arbace_j2g_vh_op_handle_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_op_handle_A_fn_class *jrt.Class



type A_arbace_j2g_vh_static_flag_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_static_flag_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_vh_string_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_string_arg_A_fn_class *jrt.Class
