//line aot_arbace_j2g_vh.ae:1
package aot_arbace_j2g_vh

import (
	"arbace/aot_arbace_classes_analyze"
	"arbace/aot_arbace_classes_types"
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_j2g_access"
	"arbace/aot_arbace_j2g_reach"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A_New() *A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_vh_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_vh_A_const_7); tmp2 = lang.IFn_Cast(A_arbace_j2g_vh_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_j2g_vh_A_const_1, A_arbace_j2g_vh_A_const_2, A_arbace_j2g_vh_A_const_3, A_arbace_j2g_vh_A_const_4, A_arbace_j2g_vh_A_const_5); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_vh_eval1348000008_fn__1348000009_A_New() *A_arbace_j2g_vh_eval1348000008_fn__1348000009_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_eval1348000008_fn__1348000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_vh_eval1348000008_fn__1348000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_vh_eval1348000008_fn__1348000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_8.GetRawRoot__O()); var tmp2 any; var root_19 any = A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_j2g_vh_A_const_10; if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_19, arg_22) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_j2g_vh_A_const_11.GetRawRoot__O(), A_arbace_j2g_vh_A_const_12) }
























func A_arbace_j2g_vh_class_arg_A_New() *A_arbace_j2g_vh_class_arg_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_arg_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_j2g_vh_class_arg_A) Ctor() {}
//line :26:1
func (t *A_arbace_j2g_vh_class_arg_A) Invoke_O_O_O__O(self, node__0, env__1 any) any { var node__3 any; var root_23 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_25 lang.IFn; if



	linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = node__0; if linked_24 == nil { node__3 = ifn_25.Invoke_O__O(arg_26) } else { node__3 = linked_24.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_23, arg_26) }; var G__1348000012__4_ any = /*line :26:1*/A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__3); switch




	lang.Util_Hash_O__I_NoInit(G__1348000012__4_) >> 6 & 3 { case 0: if any(G__1348000012__4_) == any(A_arbace_j2g_vh_A_const_15) {




		var root_28 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = A_arbace_j2g_vh_A_const_17.Invoke_O__O(node__3); var arg_32 any = env__1; if linked_29 == nil { return ifn_30.Invoke_O_O__O(arg_31, arg_32) } else { return linked_29.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_28, arg_31, arg_32) } }
//line :31:1
	case 1: if any(G__1348000012__4_) == any(A_arbace_j2g_vh_A_const_18) {
		return A_arbace_j2g_vh_A_const_19.Invoke_O__O(node__3) }
//line :31:1
	case 2: if any(G__1348000012__4_) == any(A_arbace_j2g_vh_A_const_20) { var f__5 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(node__3)


		if lang.Util_Equiv_O_O__Z_NoInit(Lit_4, A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__5)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_23.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____6 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__5); if jrt.J2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else { tmp2 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__5) }; return tmp1.Invoke_O__O(tmp2) } else { return nil } }
//line :31:1
	case 3: if any(G__1348000012__4_) == any(A_arbace_j2g_vh_A_const_24) { var tmp3 *lang.Keyword = A_arbace_j2g_vh_A_const_25; var temp__1927000414__auto____5 any = lang.RT_Get_O_O__O_NoInit(env__1, tmp3.Invoke_O__O(A_arbace_j2g_vh_A_const_26.Invoke_O__O(node__3)))



		if jrt.J2g_Truth(temp__1927000414__auto____5) { var init__6 any = temp__1927000414__auto____5; var root_33 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = init__6; var arg_37 any = env__1; if linked_34 == nil { return ifn_35.Invoke_O_O__O(arg_36, arg_37) } else { return linked_34.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_33, arg_36, arg_37) } } else { return nil } }
//line :31:1
	default:}; return nil }







func A_arbace_j2g_vh_string_arg_A_New() *A_arbace_j2g_vh_string_arg_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_string_arg_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_j2g_vh_string_arg_A) Ctor() {}
//line :39:1
func (t *A_arbace_j2g_vh_string_arg_A) Invoke_O_O__O(self, node__0 any) any { var node__2 any; var root_38 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_40 lang.IFn; if
										linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = node__0; if linked_39 == nil { node__2 = ifn_40.Invoke_O__O(arg_41) } else { node__2 = linked_39.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_38, arg_41) }; var tmp1 any; var tmp2 any = A_arbace_j2g_vh_A_const_29; var and__1927000168__auto____3 bool =
										lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__2)); if and__1927000168__auto____3 { var root_42 any = A_arbace_j2g_vh_A_const_30.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = A_arbace_j2g_vh_A_const_31.Invoke_O__O(node__2); if linked_43 == nil { tmp1 = ifn_44.Invoke_O__O(arg_45) } else { tmp1 = linked_43.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_42, arg_45) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return A_arbace_j2g_vh_A_const_31.Invoke_O__O(node__2) } else { return nil } }

func A_arbace_j2g_vh_byte_order_arg_A_New() *A_arbace_j2g_vh_byte_order_arg_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_byte_order_arg_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_j2g_vh_byte_order_arg_A) Ctor() {}
//line :43:1
func (t *A_arbace_j2g_vh_byte_order_arg_A) Invoke_O_O_O__O(self, node__0, env__1 any) any { var node__3 any; var root_46 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_48 lang.IFn; if





	linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = node__0; if linked_47 == nil { node__3 = ifn_48.Invoke_O__O(arg_49) } else { node__3 = linked_47.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_46, arg_49) }; var G__1348000015__4_ any = /*line :43:1*/A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__3); switch






	lang.Util_Hash_O__I_NoInit(G__1348000015__4_) >> 6 & 3 { case 1: if any(G__1348000015__4_) == any(A_arbace_j2g_vh_A_const_32) {



		var tmp1 any; var and__1927000168__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_1, A_arbace_j2g_vh_A_const_28.Invoke_O__O(node__3)); if and__1927000168__auto____5 { var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_2, A_arbace_j2g_vh_A_const_22.Invoke_O__O(node__3)); if and__1927000168__auto____6 { var tmp2 any = A_arbace_j2g_vh_A_const_33; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_34.Invoke_O__O(node__3)); if and__1927000168__auto____7 {
			var root_51 any = A_arbace_j2g_vh_A_const_35.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = A_arbace_j2g_vh_A_const_36.Invoke_O__O(node__3); if linked_52 == nil { tmp1 = ifn_53.Invoke_O__O(arg_54) } else { tmp1 = linked_52.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_51, arg_54) } } else {
//line :54:1
				tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp1) { return Lit_3 } else { return nil } }
//line :50:1
	case 2: if any(G__1348000015__4_) == any(A_arbace_j2g_vh_A_const_20) { var f__5 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(node__3); var tmp3 any; var or__1927000174__auto____6 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__5)

		if jrt.J2g_Truth(or__1927000174__auto____6) { tmp3 = or__1927000174__auto____6 } else { tmp3 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__5) }; if lang.Util_Equiv_O_O__Z_NoInit(Lit_1, tmp3) {
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_37); return tmp4.Invoke_O__O(A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__5)) } else {
//line :52:1
				return nil } }
//line :50:1
	case 3: if any(G__1348000015__4_) == any(A_arbace_j2g_vh_A_const_24) { var tmp5 *lang.Keyword = A_arbace_j2g_vh_A_const_25; var temp__1927000414__auto____5 any = lang.RT_Get_O_O__O_NoInit(env__1, tmp5.Invoke_O__O(A_arbace_j2g_vh_A_const_26.Invoke_O__O(node__3)))






		if jrt.J2g_Truth(temp__1927000414__auto____5) { var init__6 any = temp__1927000414__auto____5; var root_55 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_j2g_vh_byte_order_arg_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = init__6; var arg_59 any = env__1; if linked_56 == nil { return ifn_57.Invoke_O_O__O(arg_58, arg_59) } else { return linked_56.(*A_arbace_j2g_vh_byte_order_arg_A).Invoke_O_O_O__O(root_55, arg_58, arg_59) } } else { return nil } }
//line :50:1
	default:}; return nil }









func A_arbace_j2g_vh_find_field_A_New() *A_arbace_j2g_vh_find_field_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_find_field_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_j2g_vh_find_field_A) Ctor() {}
//line :60:1
func (t *A_arbace_j2g_vh_find_field_A) Invoke_O_O_O__O(self, n__0, fname__1 any) any { { var c__3 any = n__0; L1: for { var temp__1927000414__auto____4 any
											var and__1927000168__auto____4 any = c__3


	if jrt.J2g_Truth(and__1927000168__auto____4) { var root_60 any = A_arbace_j2g_vh_A_const_39.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = c__3; if linked_61 == nil { temp__1927000414__auto____4 = ifn_62.Invoke_O__O(arg_63) } else { temp__1927000414__auto____4 = linked_61.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_60, arg_63) } } else { temp__1927000414__auto____4 = and__1927000168__auto____4 }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var d__5 any = temp__1927000414__auto____4; var or__1927000174__auto____6 any; var root_64 any = A_arbace_j2g_vh_A_const_40.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_66 lang.IFn
		if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var fnbody__70 any = A_arbace_j2g_vh_find_field_fn__1348000018_A_New_O(fname__1); var tmp1 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_vh_find_field_fn__1348000018_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__70); A_arbace_j2g_vh_find_field_fn__1348000018_A_fn_class = fncls__69d; tmp1 = fncls__69d } else { tmp1 = fncls__69 }; arg_67 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp1, nil); var arg_68 any = A_arbace_j2g_vh_A_const_41.Invoke_O__O(d__5); if linked_65 == nil { or__1927000174__auto____6 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { or__1927000174__auto____6 = linked_65.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_64, arg_67, arg_68) }; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {
			c__3 = A_arbace_j2g_vh_A_const_42.Invoke_O__O(d__5); continue L1 } } else {
//line :64:1
				return nil } } }; /*line :60:1*/panic("j2g: unreachable") }




func A_arbace_j2g_vh_find_field_fn__1348000018_A_New_O(p0 any) *A_arbace_j2g_vh_find_field_fn__1348000018_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_find_field_fn__1348000018_A{}; t.Ctor_O(p0); return t }
//line :65:1
func (t *A_arbace_j2g_vh_find_field_fn__1348000018_A) Ctor_O(c__fname any) { t.F_fname = c__fname }
//line :65:1
func (t *A_arbace_j2g_vh_find_field_fn__1348000018_A) Invoke_O_O__O(self, p1__1348000017_SHARP___1 any) any { var tmp1 any = t.F_fname; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_vh_A_const_22.Invoke_O__O(p1__1348000017_SHARP___1)) { return p1__1348000017_SHARP___1 } else { return nil } }


func A_arbace_j2g_vh_static_flag_QMARK__A_New() *A_arbace_j2g_vh_static_flag_QMARK__A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_static_flag_QMARK__A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_j2g_vh_static_flag_QMARK__A) Ctor() {}
//line :68:1
func (t *A_arbace_j2g_vh_static_flag_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var root_71 any = A_arbace_j2g_vh_A_const_43.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any; var tmp1 int64; var na_75 any; var or__1927000174__auto____2 any = A_arbace_j2g_vh_A_const_44.Invoke_O__O(f__0); if jrt.J2g_Truth(or__1927000174__auto____2) { na_75 = or__1927000174__auto____2 } else { na_75 = A_arbace_j2g_vh_A_const_45 }; var na_76 int64 = 8; if jrt.Long_InstanceOf(na_75) { var n0_77 int64 = jrt.NN(jrt.Long_Cast(na_75)).LongValue__J(); var n1_78 int64 = na_76; tmp1 = n0_77 & n1_78 } else { tmp1 = lang.Numbers_And_O_J__J_NoInit(na_75, na_76) }; arg_74 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsZero_J__Z_NoInit(tmp1)).Ref(); if linked_72 == nil { return ifn_73.Invoke_O__O(arg_74) } else { return linked_72.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_71, arg_74) } }

func A_arbace_j2g_vh_handle_spec_A_New() *A_arbace_j2g_vh_handle_spec_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handle_spec_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_j2g_vh_handle_spec_A) Ctor() {}
//line :70:1
func (t *A_arbace_j2g_vh_handle_spec_A) Invoke_O_O_O_O__O(self, n__0, init__1, env__2 any) any { var init__4 any; var root_80 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_82 lang.IFn; if




	linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = init__1; if linked_81 == nil { init__4 = ifn_82.Invoke_O__O(arg_83) } else { init__4 = linked_81.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_80, arg_83) }; var field_spec__5 any; var fnbody__106 any = /*line :70:1*/A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_New(); var tmp1 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_fn_class; if





	fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, nil); A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_fn_class = fncls__105d; tmp1 = fncls__105d } else { tmp1 = fncls__105 }; field_spec__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp1, nil); var tmp2 any = A_arbace_j2g_vh_A_const_32; if





	lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(init__4)) { var map__1348000024__6 any = init__4; var map__1348000024__7 any
		if lang.ISeq_InstanceOf(map__1348000024__6) { var tmp3 any; var root_107 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = map__1348000024__6; if linked_108 == nil { tmp3 = ifn_109.Invoke_O__O(arg_110) } else { tmp3 = linked_108.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_107, arg_110) }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_111 any = A_arbace_j2g_vh_A_const_52.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = map__1348000024__6; if linked_112 == nil { tmp4 = ifn_113.Invoke_O__O(arg_114) } else { tmp4 = linked_112.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_111, arg_114) }; map__1348000024__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp4)).Ref() } else { var tmp5 any; var root_115 any = A_arbace_j2g_vh_A_const_53.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = map__1348000024__6; if linked_116 == nil { tmp5 = ifn_117.Invoke_O__O(arg_118) } else { tmp5 = linked_116.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_115, arg_118) }; if jrt.J2g_Truth(tmp5) { var root_119 any = A_arbace_j2g_vh_A_const_54.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = map__1348000024__6; if linked_120 == nil { map__1348000024__7 = ifn_121.Invoke_O__O(arg_122) } else { map__1348000024__7 = linked_120.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_119, arg_122) } } else { map__1348000024__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1348000024__7 = map__1348000024__6 }
//line :82:1
		var owner__8 any = lang.RT_Get_O_O__O_NoInit(map__1348000024__7, A_arbace_j2g_vh_A_const_28); var name__9 any = lang.RT_Get_O_O__O_NoInit(map__1348000024__7, A_arbace_j2g_vh_A_const_22); var args__10 any = lang.RT_Get_O_O__O_NoInit(map__1348000024__7, A_arbace_j2g_vh_A_const_36); var kind__11 any = lang.RT_Get_O_O__O_NoInit(map__1348000024__7, A_arbace_j2g_vh_A_const_34); var tmp6 bool; var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, Lit_11)


		if and__1927000168__auto____12 { var and__1927000168__auto____13 bool = lang.Util_Equiv_O_O__Z_NoInit(name__9, Lit_12); if and__1927000168__auto____13 { tmp6 = lang.Util_Equiv_J_J__Z_NoInit(3, int64(lang.RT_Count_O__I_NoInit(args__10))) } else { tmp6 = and__1927000168__auto____13 } } else { tmp6 = and__1927000168__auto____12 }
//line :84:1
		if tmp6 {

			var tmp7 lang.IFn = lang.IFn_Cast(field_spec__5); var tmp8 any; var root_169 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(0)); var arg_173 any = env__2; if linked_170 == nil { tmp8 = ifn_171.Invoke_O_O__O(arg_172, arg_173) } else { tmp8 = linked_170.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_169, arg_172, arg_173) }; var tmp9 any = tmp8; var tmp10 any; var root_174 any = A_arbace_j2g_vh_A_const_67.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, A_arbace_j2g_vh_string_arg_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(1)); if linked_175 == nil { tmp10 = ifn_176.Invoke_O__O(arg_177) } else { tmp10 = linked_175.(*A_arbace_j2g_vh_string_arg_A).Invoke_O_O__O(root_174, arg_177) }; var tmp11 any = tmp10; var tmp12 any; var root_178 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(2)); var arg_182 any = env__2; if linked_179 == nil { tmp12 = ifn_180.Invoke_O_O__O(arg_181, arg_182) } else { tmp12 = linked_179.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_178, arg_181, arg_182) }; return tmp7.Invoke_O_O_O__O(tmp9, tmp11, tmp12) } else {
//line :84:1
				var tmp13 bool; var and__1927000168__auto____12_2 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, Lit_13)



				if and__1927000168__auto____12_2 { var and__1927000168__auto____13_2 bool = lang.Util_Equiv_O_O__Z_NoInit(name__9, Lit_12); if and__1927000168__auto____13_2 { tmp13 = lang.Util_Equiv_O_O__Z_NoInit(kind__11, A_arbace_j2g_vh_A_const_33) } else { tmp13 = and__1927000168__auto____13_2 } } else { tmp13 = and__1927000168__auto____12_2 }
//line :84:1
				if tmp13 { var G__1348000026__12_ int32 = lang.RT_Count_O__I_NoInit(args__10)




					switch G__1348000026__12_ { case 3:

						var tmp14 lang.IFn = lang.IFn_Cast(field_spec__5); var tmp15 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, nil, Lit_15), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref(); var tmp16 any; var root_183 any = A_arbace_j2g_vh_A_const_67.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, A_arbace_j2g_vh_string_arg_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(1)); if linked_184 == nil { tmp16 = ifn_185.Invoke_O__O(arg_186) } else { tmp16 = linked_184.(*A_arbace_j2g_vh_string_arg_A).Invoke_O_O__O(root_183, arg_186) }; var tmp17 any = tmp16; var tmp18 any; var root_187 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(2)); var arg_191 any = env__2; if linked_188 == nil { tmp18 = ifn_189.Invoke_O_O__O(arg_190, arg_191) } else { tmp18 = linked_188.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_187, arg_190, arg_191) }; return tmp14.Invoke_O_O_O__O(tmp15, tmp17, tmp18)
//line :89:1
					case 4:


						var tmp19 lang.IFn = lang.IFn_Cast(field_spec__5); var tmp20 any; var root_192 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(1)); var arg_196 any = env__2; if linked_193 == nil { tmp20 = ifn_194.Invoke_O_O__O(arg_195, arg_196) } else { tmp20 = linked_193.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_192, arg_195, arg_196) }; var tmp21 any = tmp20; var tmp22 any; var root_197 any = A_arbace_j2g_vh_A_const_67.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, A_arbace_j2g_vh_string_arg_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(2)); if linked_198 == nil { tmp22 = ifn_199.Invoke_O__O(arg_200) } else { tmp22 = linked_198.(*A_arbace_j2g_vh_string_arg_A).Invoke_O_O__O(root_197, arg_200) }; var tmp23 any = tmp22; var tmp24 any; var root_201 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(3)); var arg_205 any = env__2; if linked_202 == nil { tmp24 = ifn_203.Invoke_O_O__O(arg_204, arg_205) } else { tmp24 = linked_202.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_201, arg_204, arg_205) }; return tmp19.Invoke_O_O_O__O(tmp21, tmp23, tmp24)
//line :89:1
					default:}; return nil } else {
//line :84:1
						var tmp25 bool; var and__1927000168__auto____12_3 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, Lit_16)












						if and__1927000168__auto____12_3 { var and__1927000168__auto____13_3 bool = lang.Util_Equiv_O_O__Z_NoInit(name__9, Lit_17); if and__1927000168__auto____13_3 { var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(kind__11, A_arbace_j2g_vh_A_const_33); if and__1927000168__auto____14 {
							tmp25 = lang.Util_Equiv_J_J__Z_NoInit(5, int64(lang.RT_Count_O__I_NoInit(args__10))) } else {
//line :97:1
								tmp25 = and__1927000168__auto____14 } } else { tmp25 = and__1927000168__auto____13_3 } } else { tmp25 = and__1927000168__auto____12_3 }
//line :84:1
						if tmp25 {














							var tmp26 lang.IFn = lang.IFn_Cast(field_spec__5); var tmp27 any; var root_206 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(3)); var arg_210 any = env__2; if linked_207 == nil { tmp27 = ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { tmp27 = linked_207.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) }; var tmp28 any = tmp27; var tmp29 any; var root_211 any = A_arbace_j2g_vh_A_const_67.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, A_arbace_j2g_vh_string_arg_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(1)); if linked_212 == nil { tmp29 = ifn_213.Invoke_O__O(arg_214) } else { tmp29 = linked_212.(*A_arbace_j2g_vh_string_arg_A).Invoke_O_O__O(root_211, arg_214) }; var tmp30 any = tmp29; var tmp31 any; var root_215 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = lang.RT_Nth_O_I__O_NoInit(args__10, lang.RT_IntCast_J__I_NoInit(4)); var arg_219 any = env__2; if linked_216 == nil { tmp31 = ifn_217.Invoke_O_O__O(arg_218, arg_219) } else { tmp31 = linked_216.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_215, arg_218, arg_219) }; return tmp26.Invoke_O_O_O__O(tmp28, tmp30, tmp31) } else {
//line :84:1
								var tmp32 bool; var and__1927000168__auto____12_4 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, Lit_18)
















								if and__1927000168__auto____12_4 { var and__1927000168__auto____13_4 bool = lang.Util_Equiv_O_O__Z_NoInit(name__9, Lit_19); if and__1927000168__auto____13_4 { var and__1927000168__auto____14_2 bool = lang.Util_Equiv_O_O__Z_NoInit(kind__11, A_arbace_j2g_vh_A_const_33); if and__1927000168__auto____14_2 {
									tmp32 = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(args__10))) } else {
//line :101:1
										tmp32 = and__1927000168__auto____14_2 } } else { tmp32 = and__1927000168__auto____13_4 } } else { tmp32 = and__1927000168__auto____12_4 }
//line :84:1
								if tmp32 { var d__12 any; var root_124 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_126 lang.IFn


















									if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any; var root_129 any = A_arbace_j2g_vh_A_const_54.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = args__10; if linked_130 == nil { arg_127 = ifn_131.Invoke_O__O(arg_132) } else { arg_127 = linked_130.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_129, arg_132) }; var arg_128 any = env__2; if linked_125 == nil { d__12 = ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { d__12 = linked_125.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_124, arg_127, arg_128) }
									var tmp33 any; var and__1927000168__auto____13_5 any = d__12; if jrt.J2g_Truth(and__1927000168__auto____13_5) { var root_133 any = A_arbace_j2g_vh_A_const_55.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = d__12; if linked_134 == nil { tmp33 = ifn_135.Invoke_O__O(arg_136) } else { tmp33 = linked_134.(*aot_arbace_classes_types.A_arbace_classes_types_array_QMARK__A).Invoke_O_O__O(root_133, arg_136) } } else { tmp33 = and__1927000168__auto____13_5 }; if jrt.J2g_Truth(tmp33) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_vh_A_const_34, A_arbace_j2g_vh_A_const_56, A_arbace_j2g_vh_A_const_49, d__12)) } else { return nil } } else {
//line :84:1
										var tmp34 bool; var and__1927000168__auto____12_5 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, Lit_18)

























										if and__1927000168__auto____12_5 { var and__1927000168__auto____13_6 bool = lang.Util_Equiv_O_O__Z_NoInit(name__9, Lit_20); if and__1927000168__auto____13_6 { var and__1927000168__auto____14_3 bool = lang.Util_Equiv_O_O__Z_NoInit(kind__11, A_arbace_j2g_vh_A_const_33); if and__1927000168__auto____14_3 {
											tmp34 = lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(args__10))) } else {
//line :110:1
												tmp34 = and__1927000168__auto____14_3 } } else { tmp34 = and__1927000168__auto____13_6 } } else { tmp34 = and__1927000168__auto____12_5 }
//line :84:1
										if tmp34 { var d__12_2 any; var root_137 any = A_arbace_j2g_vh_A_const_16.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, A_arbace_j2g_vh_class_arg_A_fn_class); var ifn_139 lang.IFn



























											if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any; var root_142 any = A_arbace_j2g_vh_A_const_54.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = args__10; if linked_143 == nil { arg_140 = ifn_144.Invoke_O__O(arg_145) } else { arg_140 = linked_143.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_142, arg_145) }; var arg_141 any = env__2; if linked_138 == nil { d__12_2 = ifn_139.Invoke_O_O__O(arg_140, arg_141) } else { d__12_2 = linked_138.(*A_arbace_j2g_vh_class_arg_A).Invoke_O_O_O__O(root_137, arg_140, arg_141) }
//line :84:1
											var o__13 any; var root_146 any = A_arbace_j2g_vh_A_const_38.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, A_arbace_j2g_vh_byte_order_arg_A_fn_class); var ifn_148 lang.IFn




























											if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var root_151 any = A_arbace_j2g_vh_A_const_57.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = args__10; if linked_152 == nil { arg_149 = ifn_153.Invoke_O__O(arg_154) } else { arg_149 = linked_152.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_151, arg_154) }; var arg_150 any = env__2; if linked_147 == nil { o__13 = ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { o__13 = linked_147.(*A_arbace_j2g_vh_byte_order_arg_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) }
											var tmp35 any; var and__1927000168__auto____14_4 any = lang.IFn_Cast(A_arbace_j2g_vh_A_const_58).Invoke_O__O(d__12_2); if jrt.J2g_Truth(and__1927000168__auto____14_4) { tmp35 = o__13 } else { tmp35 = and__1927000168__auto____14_4 }; if jrt.J2g_Truth(tmp35) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_vh_A_const_34, A_arbace_j2g_vh_A_const_59, A_arbace_j2g_vh_A_const_49, d__12_2, A_arbace_j2g_vh_A_const_60, o__13)) } else { return nil } } else {
//line :84:1
												var tmp36 any; var and__1927000168__auto____12_6 bool = lang.Util_Equiv_O_O__Z_NoInit(owner__8, A_arbace_j2g_vh_A_const_61.GetRawRoot__O())































												if and__1927000168__auto____12_6 { var and__1927000168__auto____13_7 any = lang.IFn_Cast(A_arbace_j2g_vh_A_const_62).Invoke_O__O(name__9); if jrt.J2g_Truth(and__1927000168__auto____13_7) { var and__1927000168__auto____14_5 any; var root_155 any = A_arbace_j2g_vh_A_const_35.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = args__10; if linked_156 == nil { and__1927000168__auto____14_5 = ifn_157.Invoke_O__O(arg_158) } else { and__1927000168__auto____14_5 = linked_156.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_155, arg_158) }; if jrt.J2g_Truth(and__1927000168__auto____14_5) {
													var root_159 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = A_arbace_j2g_vh_A_const_64.Invoke_O__O(init__4); if linked_160 == nil { tmp36 = ifn_161.Invoke_O__O(arg_162) } else { tmp36 = linked_160.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_159, arg_162) } } else {
//line :116:1
														tmp36 = and__1927000168__auto____14_5 } } else { tmp36 = and__1927000168__auto____13_7 } } else { tmp36 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12_6).Ref() }
//line :84:1
												if jrt.J2g_Truth(tmp36) {

































													var root_163 any = A_arbace_j2g_vh_A_const_65.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, A_arbace_j2g_vh_handle_spec_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = n__0; var arg_167 any = A_arbace_j2g_vh_A_const_64.Invoke_O__O(init__4); var arg_168 any = env__2; if linked_164 == nil { return ifn_165.Invoke_O_O_O__O(arg_166, arg_167, arg_168) } else { return linked_164.(*A_arbace_j2g_vh_handle_spec_A).Invoke_O_O_O_O__O(root_163, arg_166, arg_167, arg_168) } } else {
//line :84:1
														if A_arbace_j2g_vh_A_const_66 != nil { return nil } else { return nil } } } } } } } } else {
//line :82:1
															return nil } }
//line :76:1
func A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_New() *A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A) Ctor() {}
//line :76:1
func (t *A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A) Invoke_O_O_O_O__O(self, c__1, fname__2, tdesc__3 any) any {
	var tmp1 any; var and__1927000168__auto____4 any = c__1; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = fname__2; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = tdesc__3; if jrt.J2g_Truth(and__1927000168__auto____6) { var root_84 any = A_arbace_j2g_vh_A_const_46.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = c__1; if linked_85 == nil { tmp1 = ifn_86.Invoke_O__O(arg_87) } else { tmp1 = linked_85.(*aot_arbace_classes_types.A_arbace_classes_types_class_desc_QMARK__A).Invoke_O_O__O(root_84, arg_87) } } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { var cn__4 any; var root_88 any = A_arbace_j2g_vh_A_const_47.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A_fn_class); var ifn_90 lang.IFn
		if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = c__1; if linked_89 == nil { cn__4 = ifn_90.Invoke_O__O(arg_91) } else { cn__4 = linked_89.(*aot_arbace_classes_types.A_arbace_classes_types_desc__GT_internal_A).Invoke_O_O__O(root_88, arg_91) }
//line :77:1
		var f__5 any; var root_92 any = A_arbace_j2g_vh_A_const_48.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, A_arbace_j2g_vh_find_field_A_fn_class); var ifn_94 lang.IFn

		if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = cn__4; var arg_96 any = fname__2; if linked_93 == nil { f__5 = ifn_94.Invoke_O_O__O(arg_95, arg_96) } else { f__5 = linked_93.(*A_arbace_j2g_vh_find_field_A).Invoke_O_O_O__O(root_92, arg_95, arg_96) }
		var tmp2 any; var and__1927000168__auto____6_2 any = f__5; if jrt.J2g_Truth(and__1927000168__auto____6_2) { var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(tdesc__3, A_arbace_j2g_vh_A_const_49.Invoke_O__O(f__5)); if and__1927000168__auto____7 { var root_97 any = A_arbace_j2g_vh_A_const_43.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any; var root_101 any = A_arbace_j2g_vh_A_const_50.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, A_arbace_j2g_vh_static_flag_QMARK__A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = f__5; if linked_102 == nil { arg_100 = ifn_103.Invoke_O__O(arg_104) } else { arg_100 = linked_102.(*A_arbace_j2g_vh_static_flag_QMARK__A).Invoke_O_O__O(root_101, arg_104) }; if linked_98 == nil { tmp2 = ifn_99.Invoke_O__O(arg_100) } else { tmp2 = linked_98.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_97, arg_100) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp2 = and__1927000168__auto____6_2 }; if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_j2g_vh_A_const_34; var tmp4 any = A_arbace_j2g_vh_A_const_21; var tmp5 any = A_arbace_j2g_vh_A_const_19; var tmp6 any; var or__1927000174__auto____6 any = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__5)
			if jrt.J2g_Truth(or__1927000174__auto____6) { tmp6 = or__1927000174__auto____6 } else { tmp6 = cn__4 }
//line :80:1
			return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, A_arbace_j2g_vh_A_const_22, fname__2, A_arbace_j2g_vh_A_const_49, tdesc__3, A_arbace_j2g_vh_A_const_21, f__5)) } else { return nil } } else {
//line :77:1
				return nil
			}
}










































func A_arbace_j2g_vh_class_handles_A_New() *A_arbace_j2g_vh_class_handles_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_A{}; t.Ctor(); return t }
//line :122:1
func (t *A_arbace_j2g_vh_class_handles_A) Ctor() {}
//line :122:1
func (t *A_arbace_j2g_vh_class_handles_A) Invoke_O_O__O(self, n__0 any) any { var st__2 any; var root_220 any = A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_222 lang.IFn; if


	linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any; var tmp1 *lang.Keyword = A_arbace_j2g_vh_A_const_68; var tmp2 any; var root_224 any = A_arbace_j2g_vh_A_const_39.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = n__0; if linked_225 == nil { tmp2 = ifn_226.Invoke_O__O(arg_227) } else { tmp2 = linked_225.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_224, arg_227) }; arg_223 = tmp1.Invoke_O__O(tmp2); if linked_221 == nil { st__2 = ifn_222.Invoke_O__O(arg_223) } else { st__2 = linked_221.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_220, arg_223) }; var code__3 any = /*line :122:1*/A_arbace_j2g_vh_A_const_69.Invoke_O__O(st__2); var env__4 any; var root_228 any = A_arbace_j2g_vh_A_const_70.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_230 lang.IFn; if




	linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_229 == nil { env__4 = ifn_230.Invoke_O__O(arg_231) } else { env__4 = linked_229.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_228, arg_231) }; var out__5 any; var root_232 any = /*line :122:1*/A_arbace_j2g_vh_A_const_70.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_234 lang.IFn; if





	linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_233 == nil { out__5 = ifn_234.Invoke_O__O(arg_235) } else { out__5 = linked_233.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_232, arg_235) }; var seq_1348000028__6 any; var root_240 any = /*line :122:1*/A_arbace_j2g_vh_A_const_53.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_242 lang.IFn; if






	linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = code__3; if linked_241 == nil { seq_1348000028__6 = ifn_242.Invoke_O__O(arg_243) } else { seq_1348000028__6 = linked_241.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_240, arg_243) }; var chunk_1348000029__7 any; var count_1348000030__8 int64 = 0; var i_1348000031__9 int64 = 0; L1:
//line :122:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1348000031__9, count_1348000030__8) { var nd__10 any = lang.Indexed_Cast(chunk_1348000029__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1348000031__9)); var root_280 any = A_arbace_j2g_vh_A_const_73.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A_fn_class); var ifn_282 lang.IFn
			if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any; var fnbody__348 any = A_arbace_j2g_vh_class_handles_fn__1348000032_A_New_O(env__4); var tmp3 *jrt.Class; var fncls__347 *jrt.Class = A_arbace_j2g_vh_class_handles_fn__1348000032_A_fn_class; if fncls__347 == nil { var fncls__347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__348); A_arbace_j2g_vh_class_handles_fn__1348000032_A_fn_class = fncls__347d; tmp3 = fncls__347d } else { tmp3 = fncls__347 }; arg_283 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__348, tmp3, nil); var arg_284 any = nd__10; if linked_281 == nil { ifn_282.Invoke_O_O__O(arg_283, arg_284) } else { linked_281.(*aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A).Invoke_O_O_O__O(root_280, arg_283, arg_284) }
//line :129:1
			seq_1348000028__6, chunk_1348000029__7, count_1348000030__8, i_1348000031__9 = seq_1348000028__6, chunk_1348000029__7, count_1348000030__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000031__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_244 any = A_arbace_j2g_vh_A_const_53.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = seq_1348000028__6; if linked_245 == nil { temp__1927000414__auto____10 = ifn_246.Invoke_O__O(arg_247) } else { temp__1927000414__auto____10 = linked_245.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_244, arg_247) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1348000028__11 any = temp__1927000414__auto____10; var tmp4 any; var root_248 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = seq_1348000028__11; if linked_249 == nil { tmp4 = ifn_250.Invoke_O__O(arg_251) } else { tmp4 = linked_249.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_248, arg_251) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____12 any; var root_252 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = seq_1348000028__11; if linked_253 == nil { c__1927000678__auto____12 = ifn_254.Invoke_O__O(arg_255) } else { c__1927000678__auto____12 = linked_253.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_252, arg_255) }; var tmp5 any; var root_349 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = seq_1348000028__11; if linked_350 == nil { tmp5 = ifn_351.Invoke_O__O(arg_352) } else { tmp5 = linked_350.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_349, arg_352) }; seq_1348000028__6, chunk_1348000029__7, count_1348000030__8, i_1348000031__9 = tmp5, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var nd__12 any; var root_256 any = A_arbace_j2g_vh_A_const_54.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = seq_1348000028__11; if linked_257 == nil { nd__12 = ifn_258.Invoke_O__O(arg_259) } else { nd__12 = linked_257.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_256, arg_259) }
				var root_353 any = A_arbace_j2g_vh_A_const_73.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any; var fnbody__421 any = A_arbace_j2g_vh_class_handles_fn__1348000044_A_New_O(env__4); var tmp6 *jrt.Class; var fncls__420 *jrt.Class = A_arbace_j2g_vh_class_handles_fn__1348000044_A_fn_class; if fncls__420 == nil { var fncls__420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__421); A_arbace_j2g_vh_class_handles_fn__1348000044_A_fn_class = fncls__420d; tmp6 = fncls__420d } else { tmp6 = fncls__420 }; arg_356 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__421, tmp6, nil); var arg_357 any = nd__12; if linked_354 == nil { ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { linked_354.(*aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A).Invoke_O_O_O__O(root_353, arg_356, arg_357) }
//line :129:1
				var tmp7 any; var root_422 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = seq_1348000028__11; if linked_423 == nil { tmp7 = ifn_424.Invoke_O__O(arg_425) } else { tmp7 = linked_423.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_422, arg_425) }; seq_1348000028__6, chunk_1348000029__7, count_1348000030__8, i_1348000031__9 = tmp7, nil, 0, 0; continue L1 } } }
//line :122:1
		break L1 }; var seq_1348000056__6 any; var root_260 any = A_arbace_j2g_vh_A_const_53.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_262 lang.IFn; if












	linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = code__3; if linked_261 == nil { seq_1348000056__6 = ifn_262.Invoke_O__O(arg_263) } else { seq_1348000056__6 = linked_261.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_260, arg_263) }; var chunk_1348000057__7 any; var count_1348000058__8 int64 = 0; var i_1348000059__9 int64 = 0; L2:
//line :122:1
	for {












		if lang.Numbers_Lt_J_J__Z_NoInit(i_1348000059__9, count_1348000058__8) { var nd__10_2 any = lang.Indexed_Cast(chunk_1348000057__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1348000059__9)); var root_426 any = A_arbace_j2g_vh_A_const_73.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A_fn_class); var ifn_428 lang.IFn
			if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any; var fnbody__449 any = A_arbace_j2g_vh_class_handles_fn__1348000060_A_New_O_O_O(env__4, out__5, n__0); var tmp8 *jrt.Class; var fncls__448 *jrt.Class = A_arbace_j2g_vh_class_handles_fn__1348000060_A_fn_class; if fncls__448 == nil { var fncls__448d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__449); A_arbace_j2g_vh_class_handles_fn__1348000060_A_fn_class = fncls__448d; tmp8 = fncls__448d } else { tmp8 = fncls__448 }; arg_429 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__449, tmp8, nil); var arg_430 any = nd__10_2; if linked_427 == nil { ifn_428.Invoke_O_O__O(arg_429, arg_430) } else { linked_427.(*aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A).Invoke_O_O_O__O(root_426, arg_429, arg_430) }
//line :135:1
			seq_1348000056__6, chunk_1348000057__7, count_1348000058__8, i_1348000059__9 = seq_1348000056__6, chunk_1348000057__7, count_1348000058__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000059__9); continue L2 } else { var temp__1927000414__auto____10_2 any; var root_264 any = A_arbace_j2g_vh_A_const_53.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = seq_1348000056__6; if linked_265 == nil { temp__1927000414__auto____10_2 = ifn_266.Invoke_O__O(arg_267) } else { temp__1927000414__auto____10_2 = linked_265.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_264, arg_267) }; if jrt.J2g_Truth(temp__1927000414__auto____10_2) { var seq_1348000056__11 any = temp__1927000414__auto____10_2; var tmp9 any; var root_268 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = seq_1348000056__11; if linked_269 == nil { tmp9 = ifn_270.Invoke_O__O(arg_271) } else { tmp9 = linked_269.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_268, arg_271) }; if jrt.J2g_Truth(tmp9) { var c__1927000678__auto____12_2 any; var root_272 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = seq_1348000056__11; if linked_273 == nil { c__1927000678__auto____12_2 = ifn_274.Invoke_O__O(arg_275) } else { c__1927000678__auto____12_2 = linked_273.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_272, arg_275) }; var tmp10 any; var root_450 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = seq_1348000056__11; if linked_451 == nil { tmp10 = ifn_452.Invoke_O__O(arg_453) } else { tmp10 = linked_451.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_450, arg_453) }; seq_1348000056__6, chunk_1348000057__7, count_1348000058__8, i_1348000059__9 = tmp10, c__1927000678__auto____12_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var nd__12_2 any; var root_276 any = A_arbace_j2g_vh_A_const_54.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = seq_1348000056__11; if linked_277 == nil { nd__12_2 = ifn_278.Invoke_O__O(arg_279) } else { nd__12_2 = linked_277.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_276, arg_279) }
				var root_454 any = A_arbace_j2g_vh_A_const_73.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any; var fnbody__477 any = A_arbace_j2g_vh_class_handles_fn__1348000062_A_New_O_O_O(env__4, out__5, n__0); var tmp11 *jrt.Class; var fncls__476 *jrt.Class = A_arbace_j2g_vh_class_handles_fn__1348000062_A_fn_class; if fncls__476 == nil { var fncls__476d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__477); A_arbace_j2g_vh_class_handles_fn__1348000062_A_fn_class = fncls__476d; tmp11 = fncls__476d } else { tmp11 = fncls__476 }; arg_457 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__477, tmp11, nil); var arg_458 any = nd__12_2; if linked_455 == nil { ifn_456.Invoke_O_O__O(arg_457, arg_458) } else { linked_455.(*aot_arbace_j2g_reach.A_arbace_j2g_reach_walk_nodes_A).Invoke_O_O_O__O(root_454, arg_457, arg_458) }
//line :135:1
				var tmp12 any; var root_478 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = seq_1348000056__11; if linked_479 == nil { tmp12 = ifn_480.Invoke_O__O(arg_481) } else { tmp12 = linked_479.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_478, arg_481) }; seq_1348000056__6, chunk_1348000057__7, count_1348000058__8, i_1348000059__9 = tmp12, nil, 0, 0; continue L2 } } }
//line :122:1
		break L2 }; var root_236 any =


	A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = out__5; if linked_237 == nil { return ifn_238.Invoke_O__O(arg_239) } else { return linked_237.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_236, arg_239) } }




func A_arbace_j2g_vh_class_handles_fn__1348000032_A_New_O(p0 any) *A_arbace_j2g_vh_class_handles_fn__1348000032_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_fn__1348000032_A{}; t.Ctor_O(p0); return t }
//line :130:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000032_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :130:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000032_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_74); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_j2g_vh_A_const_14.Invoke_O__O(x__1))) { var seq_1348000033__2 any; var root_285 any = A_arbace_j2g_vh_A_const_53.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_287 lang.IFn
		if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = A_arbace_j2g_vh_A_const_75.Invoke_O__O(x__1); if linked_286 == nil { seq_1348000033__2 = ifn_287.Invoke_O__O(arg_288) } else { seq_1348000033__2 = linked_286.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_285, arg_288) }
//line :131:1
		var chunk_1348000034__3 any; var count_1348000035__4 int64 = 0; var i_1348000036__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1348000036__5, count_1348000035__4) { var vec__1348000037__6 any = lang.Indexed_Cast(chunk_1348000034__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1348000036__5)); var b__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000037__6, lang.RT_IntCast_J__I_NoInit(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000037__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var and__1927000168__auto____9 any; var root_289 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_289, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_291 lang.IFn; if linked_290 == nil { ifn_291 = lang.IFn_Cast(root_289) } else { ifn_291 = nil }; var arg_292 any = b__7; if linked_290 == nil { and__1927000168__auto____9 = ifn_291.Invoke_O__O(arg_292) } else { and__1927000168__auto____9 = linked_290.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_289, arg_292) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_293 any = A_arbace_j2g_vh_A_const_43.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_295 lang.IFn; if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = A_arbace_j2g_vh_A_const_76.Invoke_O__O(b__7); if linked_294 == nil { tmp2 = ifn_295.Invoke_O__O(arg_296) } else { tmp2 = linked_294.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_293, arg_296) } } else { tmp2 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp2) {
				var root_321 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = t.F_env; var arg_325 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_326 any = A_arbace_j2g_vh_A_const_25.Invoke_O__O(b__7); var arg_327 any = init__8; if linked_322 == nil { ifn_323.Invoke_O_O_O_O__O(arg_324, arg_325, arg_326, arg_327) } else { linked_322.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_321, arg_324, arg_325, arg_326, arg_327) }
//line :132:1
				seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000036__5); continue L1 } else { seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000036__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_297 any = A_arbace_j2g_vh_A_const_53.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = seq_1348000033__2; if linked_298 == nil { temp__1927000414__auto____6 = ifn_299.Invoke_O__O(arg_300) } else { temp__1927000414__auto____6 = linked_298.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_297, arg_300) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1348000033__7 any = temp__1927000414__auto____6; var tmp3 any; var root_301 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = seq_1348000033__7; if linked_302 == nil { tmp3 = ifn_303.Invoke_O__O(arg_304) } else { tmp3 = linked_302.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_301, arg_304) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_305 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = seq_1348000033__7; if linked_306 == nil { c__1927000678__auto____8 = ifn_307.Invoke_O__O(arg_308) } else { c__1927000678__auto____8 = linked_306.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_305, arg_308) }; var tmp4 any; var root_328 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = seq_1348000033__7; if linked_329 == nil { tmp4 = ifn_330.Invoke_O__O(arg_331) } else { tmp4 = linked_329.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_328, arg_331) }; seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1348000040__8 any; var root_309 any = A_arbace_j2g_vh_A_const_54.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = seq_1348000033__7; if linked_310 == nil { vec__1348000040__8 = ifn_311.Invoke_O__O(arg_312) } else { vec__1348000040__8 = linked_310.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_309, arg_312) }; var b__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000040__8, lang.RT_IntCast_J__I_NoInit(0), nil); var init__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000040__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var and__1927000168__auto____11 any; var root_313 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = b__9; if linked_314 == nil { and__1927000168__auto____11 = ifn_315.Invoke_O__O(arg_316) } else { and__1927000168__auto____11 = linked_314.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_313, arg_316) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_317 any = A_arbace_j2g_vh_A_const_43.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = A_arbace_j2g_vh_A_const_76.Invoke_O__O(b__9); if linked_318 == nil { tmp5 = ifn_319.Invoke_O__O(arg_320) } else { tmp5 = linked_318.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_317, arg_320) } } else { tmp5 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp5) {
					var root_332 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = t.F_env; var arg_336 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_337 any = A_arbace_j2g_vh_A_const_25.Invoke_O__O(b__9); var arg_338 any = init__10; if linked_333 == nil { ifn_334.Invoke_O_O_O_O__O(arg_335, arg_336, arg_337, arg_338) } else { linked_333.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_332, arg_335, arg_336, arg_337, arg_338) }
//line :132:1
					var tmp6 any; var root_339 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = seq_1348000033__7; if linked_340 == nil { tmp6 = ifn_341.Invoke_O__O(arg_342) } else { tmp6 = linked_340.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_339, arg_342) }; seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_343 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = seq_1348000033__7; if linked_344 == nil { tmp7 = ifn_345.Invoke_O__O(arg_346) } else { tmp7 = linked_344.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_343, arg_346) }; seq_1348000033__2, chunk_1348000034__3, count_1348000035__4, i_1348000036__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :131:1
						return nil } }
//line :130:1
	panic("j2g: unreachable") }
//line :130:1
func A_arbace_j2g_vh_class_handles_fn__1348000044_A_New_O(p0 any) *A_arbace_j2g_vh_class_handles_fn__1348000044_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_fn__1348000044_A{}; t.Ctor_O(p0); return t }
//line :130:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000044_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :130:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000044_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_vh_A_const_80); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_j2g_vh_A_const_14.Invoke_O__O(x__1))) { var seq_1348000045__2 any; var root_358 any = A_arbace_j2g_vh_A_const_53.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_360 lang.IFn
		if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = A_arbace_j2g_vh_A_const_75.Invoke_O__O(x__1); if linked_359 == nil { seq_1348000045__2 = ifn_360.Invoke_O__O(arg_361) } else { seq_1348000045__2 = linked_359.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_358, arg_361) }
//line :131:1
		var chunk_1348000046__3 any; var count_1348000047__4 int64 = 0; var i_1348000048__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1348000048__5, count_1348000047__4) { var vec__1348000049__6 any = lang.Indexed_Cast(chunk_1348000046__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1348000048__5)); var b__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000049__6, lang.RT_IntCast_J__I_NoInit(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000049__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var and__1927000168__auto____9 any; var root_362 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = b__7; if linked_363 == nil { and__1927000168__auto____9 = ifn_364.Invoke_O__O(arg_365) } else { and__1927000168__auto____9 = linked_363.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_362, arg_365) }; if jrt.J2g_Truth(and__1927000168__auto____9) { var root_366 any = A_arbace_j2g_vh_A_const_43.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_j2g_vh_A_const_76.Invoke_O__O(b__7); if linked_367 == nil { tmp2 = ifn_368.Invoke_O__O(arg_369) } else { tmp2 = linked_367.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_366, arg_369) } } else { tmp2 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp2) {
				var root_394 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = t.F_env; var arg_398 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_399 any = A_arbace_j2g_vh_A_const_25.Invoke_O__O(b__7); var arg_400 any = init__8; if linked_395 == nil { ifn_396.Invoke_O_O_O_O__O(arg_397, arg_398, arg_399, arg_400) } else { linked_395.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_394, arg_397, arg_398, arg_399, arg_400) }
//line :132:1
				seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000048__5); continue L1 } else { seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1348000048__5); continue L1 } } else { var temp__1927000414__auto____6 any; var root_370 any = A_arbace_j2g_vh_A_const_53.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = seq_1348000045__2; if linked_371 == nil { temp__1927000414__auto____6 = ifn_372.Invoke_O__O(arg_373) } else { temp__1927000414__auto____6 = linked_371.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_370, arg_373) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1348000045__7 any = temp__1927000414__auto____6; var tmp3 any; var root_374 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = seq_1348000045__7; if linked_375 == nil { tmp3 = ifn_376.Invoke_O__O(arg_377) } else { tmp3 = linked_375.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_374, arg_377) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____8 any; var root_378 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = seq_1348000045__7; if linked_379 == nil { c__1927000678__auto____8 = ifn_380.Invoke_O__O(arg_381) } else { c__1927000678__auto____8 = linked_379.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_378, arg_381) }; var tmp4 any; var root_401 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = seq_1348000045__7; if linked_402 == nil { tmp4 = ifn_403.Invoke_O__O(arg_404) } else { tmp4 = linked_402.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_401, arg_404) }; seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = tmp4, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1348000052__8 any; var root_382 any = A_arbace_j2g_vh_A_const_54.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = seq_1348000045__7; if linked_383 == nil { vec__1348000052__8 = ifn_384.Invoke_O__O(arg_385) } else { vec__1348000052__8 = linked_383.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_382, arg_385) }; var b__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000052__8, lang.RT_IntCast_J__I_NoInit(0), nil); var init__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000052__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var and__1927000168__auto____11 any; var root_386 any = A_arbace_j2g_vh_A_const_63.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = b__9; if linked_387 == nil { and__1927000168__auto____11 = ifn_388.Invoke_O__O(arg_389) } else { and__1927000168__auto____11 = linked_387.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_386, arg_389) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_390 any = A_arbace_j2g_vh_A_const_43.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = A_arbace_j2g_vh_A_const_76.Invoke_O__O(b__9); if linked_391 == nil { tmp5 = ifn_392.Invoke_O__O(arg_393) } else { tmp5 = linked_391.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_390, arg_393) } } else { tmp5 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp5) {
					var root_405 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = t.F_env; var arg_409 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_410 any = A_arbace_j2g_vh_A_const_25.Invoke_O__O(b__9); var arg_411 any = init__10; if linked_406 == nil { ifn_407.Invoke_O_O_O_O__O(arg_408, arg_409, arg_410, arg_411) } else { linked_406.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_405, arg_408, arg_409, arg_410, arg_411) }
//line :132:1
					var tmp6 any; var root_412 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = seq_1348000045__7; if linked_413 == nil { tmp6 = ifn_414.Invoke_O__O(arg_415) } else { tmp6 = linked_413.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_412, arg_415) }; seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = tmp6, nil, 0, 0; continue L1 } else { var tmp7 any; var root_416 any = A_arbace_j2g_vh_A_const_51.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = seq_1348000045__7; if linked_417 == nil { tmp7 = ifn_418.Invoke_O__O(arg_419) } else { tmp7 = linked_417.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_416, arg_419) }; seq_1348000045__2, chunk_1348000046__3, count_1348000047__4, i_1348000048__5 = tmp7, nil, 0, 0; continue L1 } } } else { return nil } } } } else {
//line :131:1
						return nil } }
//line :130:1
	panic("j2g: unreachable")
}




func A_arbace_j2g_vh_class_handles_fn__1348000060_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_vh_class_handles_fn__1348000060_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_fn__1348000060_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :136:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000060_A) Ctor_O_O_O(c__env, c__out, c__n any) { t.F_env = c__env; t.F_out = c__out; t.F_n = c__n }
//line :136:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000060_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 bool; var tmp2 any = A_arbace_j2g_vh_A_const_81; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(x__1)); if and__1927000168__auto____2 { var tmp3 *lang.Keyword = A_arbace_j2g_vh_A_const_49; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_82.GetRawRoot__O(), tmp3.Invoke_O__O(A_arbace_j2g_vh_A_const_21.Invoke_O__O(x__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var f__2 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(x__1); var o__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__2)

		if jrt.J2g_Truth(or__1927000174__auto____3) { o__3 = or__1927000174__auto____3 } else { o__3 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__2) }
//line :137:1
		var temp__1927000414__auto____4 any; var root_431 any = A_arbace_j2g_vh_A_const_65.GetRawRoot__O(); var linked_432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_431, A_arbace_j2g_vh_handle_spec_A_fn_class); var ifn_433 lang.IFn


		if linked_432 == nil { ifn_433 = lang.IFn_Cast(root_431) } else { ifn_433 = nil }; var arg_434 any = t.F_n; var arg_435 any = A_arbace_j2g_vh_A_const_31.Invoke_O__O(x__1); var arg_436 any; var root_437 any = A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_439 lang.IFn; if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = t.F_env; if linked_438 == nil { arg_436 = ifn_439.Invoke_O__O(arg_440) } else { arg_436 = linked_438.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_437, arg_440) }; if linked_432 == nil { temp__1927000414__auto____4 = ifn_433.Invoke_O_O_O__O(arg_434, arg_435, arg_436) } else { temp__1927000414__auto____4 = linked_432.(*A_arbace_j2g_vh_handle_spec_A).Invoke_O_O_O_O__O(root_431, arg_434, arg_435, arg_436) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var spec__5 any = temp__1927000414__auto____4; var root_441 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_443 lang.IFn
			if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = t.F_out; var arg_445 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_446 any = lang.Tuple_Create_O_O__IPersistentVector(o__3, A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__2)); var arg_447 any = spec__5; if linked_442 == nil { return ifn_443.Invoke_O_O_O_O__O(arg_444, arg_445, arg_446, arg_447) } else { return linked_442.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_441, arg_444, arg_445, arg_446, arg_447) } } else {
//line :140:1
				return nil } } else {
//line :137:1
					return nil } }
//line :136:1
func A_arbace_j2g_vh_class_handles_fn__1348000062_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_vh_class_handles_fn__1348000062_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_class_handles_fn__1348000062_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :136:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000062_A) Ctor_O_O_O(c__env, c__out, c__n any) { t.F_env = c__env; t.F_out = c__out; t.F_n = c__n }
//line :136:1
func (t *A_arbace_j2g_vh_class_handles_fn__1348000062_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 bool; var tmp2 any = A_arbace_j2g_vh_A_const_81; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(x__1)); if and__1927000168__auto____2 { var tmp3 *lang.Keyword = A_arbace_j2g_vh_A_const_49; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_82.GetRawRoot__O(), tmp3.Invoke_O__O(A_arbace_j2g_vh_A_const_21.Invoke_O__O(x__1))) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { var f__2 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(x__1); var o__3 any; var or__1927000174__auto____3 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__2)

		if jrt.J2g_Truth(or__1927000174__auto____3) { o__3 = or__1927000174__auto____3 } else { o__3 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__2) }
//line :137:1
		var temp__1927000414__auto____4 any; var root_459 any = A_arbace_j2g_vh_A_const_65.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, A_arbace_j2g_vh_handle_spec_A_fn_class); var ifn_461 lang.IFn


		if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = t.F_n; var arg_463 any = A_arbace_j2g_vh_A_const_31.Invoke_O__O(x__1); var arg_464 any; var root_465 any = A_arbace_j2g_vh_A_const_9.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = t.F_env; if linked_466 == nil { arg_464 = ifn_467.Invoke_O__O(arg_468) } else { arg_464 = linked_466.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_465, arg_468) }; if linked_460 == nil { temp__1927000414__auto____4 = ifn_461.Invoke_O_O_O__O(arg_462, arg_463, arg_464) } else { temp__1927000414__auto____4 = linked_460.(*A_arbace_j2g_vh_handle_spec_A).Invoke_O_O_O_O__O(root_459, arg_462, arg_463, arg_464) }; if jrt.J2g_Truth(temp__1927000414__auto____4) { var spec__5 any = temp__1927000414__auto____4; var root_469 any = A_arbace_j2g_vh_A_const_77.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_471 lang.IFn
			if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = t.F_out; var arg_473 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var arg_474 any = lang.Tuple_Create_O_O__IPersistentVector(o__3, A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__2)); var arg_475 any = spec__5; if linked_470 == nil { return ifn_471.Invoke_O_O_O_O__O(arg_472, arg_473, arg_474, arg_475) } else { return linked_470.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_469, arg_472, arg_473, arg_474, arg_475) } } else {
//line :140:1
				return nil } } else {
//line :137:1
					return nil
				}
}





func A_arbace_j2g_vh_handles_A_New() *A_arbace_j2g_vh_handles_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_j2g_vh_handles_A) Ctor() {}
//line :145:1
func (t *A_arbace_j2g_vh_handles_A) Invoke_O_O__O(self, class_names__0 any) any { var hs__2 any; var root_482 any = A_arbace_j2g_vh_A_const_83.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_484 lang.IFn; if



	linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_486 any; var iter__1927001039__auto____2 any; var fnbody__598 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_New(); var tmp1 *jrt.Class; var fncls__597 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_fn_class; if fncls__597 == nil { var fncls__597d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_fn_class = fncls__597d; tmp1 = fncls__597d } else { tmp1 = fncls__597 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__598, tmp1, nil); arg_486 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(class_names__0); if linked_483 == nil { hs__2 = ifn_484.Invoke_O_O__O(arg_485, arg_486) } else { hs__2 = linked_483.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_482, arg_485, arg_486) }; var tmp2 any = A_arbace_j2g_vh_A_const_92; var tmp3 any = A_arbace_j2g_vh_A_const_41; var tmp4 any; var root_599 any = /*line :145:1*/A_arbace_j2g_vh_A_const_93.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_601 lang.IFn; if









	linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any; var iter__1927001039__auto____3 any; var fnbody__668 any = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_New(); var tmp5 *jrt.Class; var fncls__667 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_fn_class; if fncls__667 == nil { var fncls__667d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_fn_class = fncls__667d; tmp5 = fncls__667d } else { tmp5 = fncls__667 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__668, tmp5, nil); arg_602 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(hs__2); if linked_600 == nil { tmp4 = ifn_601.Invoke_O__O(arg_602) } else { tmp4 = linked_600.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_599, arg_602) }; return /*line :145:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, hs__2, tmp3, tmp4)) }



func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_New() *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A) Ctor() {}
//line :149:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A) Invoke_O_O__O(self, s__1348000067__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__596 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_New_O_O(s__1348000067__1, self); var tmp2 *jrt.Class; var fncls__595 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_fn_class; if fncls__595 == nil { var fncls__595d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__596); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_fn_class = fncls__595d; tmp2 = fncls__595d } else { tmp2 = fncls__595 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__596, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :149:1
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_New_O_O(p0, p1 any) *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A{}; t.Ctor_O_O(p0, p1); return t }
//line :149:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A) Ctor_O_O(c__s__1348000067, c__iter__1348000066 any) { t.F_s__1348000067 = c__s__1348000067; t.F_iter__1348000066 = c__iter__1348000066 }
//line :149:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A) Invoke_O__O(self any) any { { var s__1348000067__1 any; var t_ any = t.F_s__1348000067; t.F_s__1348000067 = nil; s__1348000067__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_487 any = A_arbace_j2g_vh_A_const_53.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = s__1348000067__1; if linked_488 == nil { temp__1927000414__auto____2 = ifn_489.Invoke_O__O(arg_490) } else { temp__1927000414__auto____2 = linked_488.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_487, arg_490) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var n__4 any; var root_491 any = A_arbace_j2g_vh_A_const_54.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = xs__1927001018__auto____3; if linked_492 == nil { n__4 = ifn_493.Invoke_O__O(arg_494) } else { n__4 = linked_492.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_491, arg_494) }; var d__5 any; var root_495 any = A_arbace_j2g_vh_A_const_39.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A_fn_class); var ifn_497 lang.IFn
														if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = n__4; if linked_496 == nil { d__5 = ifn_497.Invoke_O__O(arg_498) } else { d__5 = linked_496.(*aot_arbace_classes_analyze.A_arbace_classes_analyze_decl_A).Invoke_O_O__O(root_495, arg_498) }
//line :149:1
	var tmp1 any
	var and__1927000168__auto____6 any = d__5
	if jrt.J2g_Truth(and__1927000168__auto____6) { var root_499 any = A_arbace_j2g_vh_A_const_40.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any; var fnbody__505 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_New(); var tmp2 *jrt.Class; var fncls__504 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_fn_class; if fncls__504 == nil { var fncls__504d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_fn_class = fncls__504d; tmp2 = fncls__504d } else { tmp2 = fncls__504 }; arg_502 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__505, tmp2, nil); var arg_503 any = A_arbace_j2g_vh_A_const_41.Invoke_O__O(d__5); if linked_500 == nil { tmp1 = ifn_501.Invoke_O_O__O(arg_502, arg_503) } else { tmp1 = linked_500.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_499, arg_502, arg_503) } } else { tmp1 = and__1927000168__auto____6 }
//line :149:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____6 any; var fnbody__567 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_New(); var tmp3 *jrt.Class; var fncls__566 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_fn_class; if fncls__566 == nil { var fncls__566d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_fn_class = fncls__566d; tmp3 = fncls__566d } else { tmp3 = fncls__566 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__567, tmp3, nil); var fs__1927001036__auto____7 any; var root_568 any = A_arbace_j2g_vh_A_const_53.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any; var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____6); var tmp5 *lang.Compiler_AOTFn; var fnbody__577 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_New_O(n__4); var tmp6 *jrt.Class
		var fncls__576 /*line :149:1*/*jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_fn_class


		if fncls__576 == nil { var fncls__576d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__577); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_fn_class = fncls__576d; tmp6 = fncls__576d } else { tmp6 = fncls__576 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__577, tmp6, nil)
//line :149:1
		arg_571 = tmp4.Invoke_O__O(Up_Compiler_AOTFn_IFn(tmp5).Invoke__O()); if linked_569 == nil { fs__1927001036__auto____7 = ifn_570.Invoke_O__O(arg_571) } else { fs__1927001036__auto____7 = linked_569.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_568, arg_571) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_578 any = A_arbace_j2g_vh_A_const_91.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = fs__1927001036__auto____7; var arg_582 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1348000066); var tmp8 any; var root_583 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = s__1348000067__1; if linked_584 == nil { tmp8 = ifn_585.Invoke_O__O(arg_586) } else { tmp8 = linked_584.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_583, arg_586) }; arg_582 = tmp7.Invoke_O__O(tmp8); if linked_579 == nil { return ifn_580.Invoke_O_O__O(arg_581, arg_582) } else { return linked_579.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_578, arg_581, arg_582) } } else { var tmp9 any; var root_587 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = s__1348000067__1; if linked_588 == nil { tmp9 = ifn_589.Invoke_O__O(arg_590) } else { tmp9 = linked_588.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_587, arg_590) }; s__1348000067__1 = tmp9; continue L1 } } else { var tmp10 any; var root_591 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = s__1348000067__1; if linked_592 == nil { tmp10 = ifn_593.Invoke_O__O(arg_594) } else { tmp10 = linked_592.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_591, arg_594) }; s__1348000067__1 = tmp10; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :149:1
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_New() *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A) Ctor() {}
//line :149:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A) Invoke_O_O__O(self, s__1348000069__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__565 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_New_O_O(self, s__1348000069__1); var tmp2 *jrt.Class; var fncls__564 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_fn_class; if fncls__564 == nil { var fncls__564d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__565); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_fn_class = fncls__564d; tmp2 = fncls__564d } else { tmp2 = fncls__564 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__565, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :149:1
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_New_O_O(p0, p1 any) *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A{}; t.Ctor_O_O(p0, p1); return t }
//line :149:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A) Ctor_O_O(c__iter__1348000068, c__s__1348000069 any) { t.F_iter__1348000068 = c__iter__1348000068; t.F_s__1348000069 = c__s__1348000069 }
//line :149:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A) Invoke_O__O(self any) any { { var s__1348000069__1 any; var t_ any = t.F_s__1348000069; t.F_s__1348000069 = nil; s__1348000069__1 = t_; for { var temp__1927000414__auto____2 any; var root_506 any = A_arbace_j2g_vh_A_const_53.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = s__1348000069__1; if linked_507 == nil { temp__1927000414__auto____2 = ifn_508.Invoke_O__O(arg_509) } else { temp__1927000414__auto____2 = linked_507.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_506, arg_509) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1348000069__3 any = temp__1927000414__auto____2; var tmp1 any; var root_510 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = s__1348000069__3; if linked_511 == nil { tmp1 = ifn_512.Invoke_O__O(arg_513) } else { tmp1 = linked_511.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_510, arg_513) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_514 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = s__1348000069__3; if linked_515 == nil { c__1927001037__auto____4 = ifn_516.Invoke_O__O(arg_517) } else { c__1927001037__auto____4 = linked_515.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_514, arg_517) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1348000071__6 any; var root_518 any = A_arbace_j2g_vh_A_const_84.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_519 == nil { b__1348000071__6 = ifn_520.Invoke_O__O(arg_521) } else { b__1348000071__6 = linked_519.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_518, arg_521) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__528 any = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_New_O_I_O(b__1348000071__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__527 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_fn_class; if fncls__527 == nil { var fncls__527d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__528); A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_fn_class = fncls__527d; tmp3 = fncls__527d } else { tmp3 = fncls__527 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__528, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_529 any = A_arbace_j2g_vh_A_const_86.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any; var root_534 any = A_arbace_j2g_vh_A_const_87.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = b__1348000071__6; if linked_535 == nil { arg_532 = ifn_536.Invoke_O__O(arg_537) } else { arg_532 = linked_535.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_534, arg_537) }; var arg_533 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1348000068); var tmp5 any; var root_538 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = s__1348000069__3; if linked_539 == nil { tmp5 = ifn_540.Invoke_O__O(arg_541) } else { tmp5 = linked_539.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_538, arg_541) }; arg_533 = tmp4.Invoke_O__O(tmp5); if linked_530 == nil { return ifn_531.Invoke_O_O__O(arg_532, arg_533) } else { return linked_530.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_529, arg_532, arg_533) } } else { var root_542 any = A_arbace_j2g_vh_A_const_86.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any; var root_547 any = A_arbace_j2g_vh_A_const_87.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = b__1348000071__6; if linked_548 == nil { arg_545 = ifn_549.Invoke_O__O(arg_550) } else { arg_545 = linked_548.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_547, arg_550) }; var arg_546 any; if linked_543 == nil { return ifn_544.Invoke_O_O__O(arg_545, arg_546) } else { return linked_543.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_542, arg_545, arg_546) } } } else { var e__4 any; var root_551 any = A_arbace_j2g_vh_A_const_54.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = s__1348000069__3; if linked_552 == nil { e__4 = ifn_553.Invoke_O__O(arg_554) } else { e__4 = linked_552.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_551, arg_554) }; var root_555 any = A_arbace_j2g_vh_A_const_88.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = e__4; var arg_559 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1348000068); var tmp7 any; var root_560 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = s__1348000069__3; if linked_561 == nil { tmp7 = ifn_562.Invoke_O__O(arg_563) } else { tmp7 = linked_561.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_560, arg_563) }; arg_559 = tmp6.Invoke_O__O(tmp7); if linked_556 == nil { return ifn_557.Invoke_O_O__O(arg_558, arg_559) } else { return linked_556.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_555, arg_558, arg_559) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :149:1
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :149:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A) Ctor_O_I_O(c__b__1348000071 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1348000071 = c__b__1348000071; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :149:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A) Invoke_O__O(self any) any { { var i__1348000070__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1348000070__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var e__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1348000070__1)); var root_522 any = A_arbace_j2g_vh_A_const_85.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = t.F_b__1348000071; var arg_526 any = e__2; if linked_523 == nil { ifn_524.Invoke_O_O__O(arg_525, arg_526) } else { linked_523.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_522, arg_525, arg_526) }; i__1348000070__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1348000070__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_New() *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A) Ctor() {}
//line :151:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A) Invoke_O_O__O(self, p1__1348000065_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_82.GetRawRoot__O(), A_arbace_j2g_vh_A_const_49.Invoke_O__O(p1__1348000065_SHARP___1))).Ref() }
func A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_New_O(p0 any) *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A{}; t.Ctor_O(p0); return t }
//line :152:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :152:1
func (t *A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_572 any = A_arbace_j2g_vh_A_const_90.GetRawRoot__O(); var linked_573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_572, A_arbace_j2g_vh_class_handles_A_fn_class); var ifn_574 lang.IFn; if linked_573 == nil { ifn_574 = lang.IFn_Cast(root_572) } else { ifn_574 = nil }; var arg_575 any; var t_ any = t.F_n; t.F_n = nil; arg_575 = t_; if linked_573 == nil { tmp1 = ifn_574.Invoke_O__O(arg_575) } else { tmp1 = linked_573.(*A_arbace_j2g_vh_class_handles_A).Invoke_O_O__O(root_572, arg_575) } }; return nil }(); if tmp2 != nil { if true { var ___3 jrt.Throwable_I = tmp2; _ = ___3; tmp1 = nil } }; return tmp1 }


func A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_New() *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A) Ctor() {}
//line :155:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A) Invoke_O_O__O(self, s__1348000087__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__666 any = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_New_O_O(s__1348000087__1, self); var tmp2 *jrt.Class; var fncls__665 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_fn_class; if fncls__665 == nil { var fncls__665d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__666); A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_fn_class = fncls__665d; tmp2 = fncls__665d } else { tmp2 = fncls__665 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__666, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :155:1
func A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_New_O_O(p0, p1 any) *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A{}; t.Ctor_O_O(p0, p1); return t }
//line :155:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A) Ctor_O_O(c__s__1348000087, c__iter__1348000086 any) { t.F_s__1348000087 = c__s__1348000087; t.F_iter__1348000086 = c__iter__1348000086 }
//line :155:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A) Invoke_O__O(self any) any { { var s__1348000087__1 any; var t_ any = t.F_s__1348000087; t.F_s__1348000087 = nil; s__1348000087__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_603 any = A_arbace_j2g_vh_A_const_53.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = s__1348000087__1; if linked_604 == nil { temp__1927000414__auto____2 = ifn_605.Invoke_O__O(arg_606) } else { temp__1927000414__auto____2 = linked_604.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_603, arg_606) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1348000087__3 any = temp__1927000414__auto____2; var tmp1 any; var root_607 any = A_arbace_j2g_vh_A_const_71.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = s__1348000087__3; if linked_608 == nil { tmp1 = ifn_609.Invoke_O__O(arg_610) } else { tmp1 = linked_608.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_607, arg_610) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_611 any = A_arbace_j2g_vh_A_const_72.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = s__1348000087__3; if linked_612 == nil { c__1927001037__auto____4 = ifn_613.Invoke_O__O(arg_614) } else { c__1927001037__auto____4 = linked_612.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_611, arg_614) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1348000089__6 any; var root_615 any = A_arbace_j2g_vh_A_const_84.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_616 == nil { b__1348000089__6 = ifn_617.Invoke_O__O(arg_618) } else { b__1348000089__6 = linked_616.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_615, arg_618) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__625 any = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_New_O_I_O(b__1348000089__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__624 *jrt.Class = A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_fn_class; if fncls__624 == nil { var fncls__624d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__625); A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_fn_class = fncls__624d; tmp3 = fncls__624d } else { tmp3 = fncls__624 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__625, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_626 any = A_arbace_j2g_vh_A_const_86.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any; var root_631 any = A_arbace_j2g_vh_A_const_87.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = b__1348000089__6; if linked_632 == nil { arg_629 = ifn_633.Invoke_O__O(arg_634) } else { arg_629 = linked_632.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_631, arg_634) }; var arg_630 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1348000086); var tmp5 any; var root_635 any = A_arbace_j2g_vh_A_const_79.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = s__1348000087__3; if linked_636 == nil { tmp5 = ifn_637.Invoke_O__O(arg_638) } else { tmp5 = linked_636.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_635, arg_638) }; arg_630 = tmp4.Invoke_O__O(tmp5); if linked_627 == nil { return ifn_628.Invoke_O_O__O(arg_629, arg_630) } else { return linked_627.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_626, arg_629, arg_630) } } else { var root_639 any = A_arbace_j2g_vh_A_const_86.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_641 lang.IFn; if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any; var root_644 any = A_arbace_j2g_vh_A_const_87.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = b__1348000089__6; if linked_645 == nil { arg_642 = ifn_646.Invoke_O__O(arg_647) } else { arg_642 = linked_645.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_644, arg_647) }; var arg_643 any; if linked_640 == nil { return ifn_641.Invoke_O_O__O(arg_642, arg_643) } else { return linked_640.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_639, arg_642, arg_643) } } } else { var vec__1348000097__4 any; var root_648 any = A_arbace_j2g_vh_A_const_54.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = s__1348000087__3; if linked_649 == nil { vec__1348000097__4 = ifn_650.Invoke_O__O(arg_651) } else { vec__1348000097__4 = linked_649.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_648, arg_651) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000097__4, lang.RT_IntCast_J__I_NoInit(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000097__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any = A_arbace_j2g_vh_A_const_21; _ = ___5; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_j2g_vh_A_const_34.Invoke_O__O(s__6)) { var root_652 any = A_arbace_j2g_vh_A_const_88.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_vh_A_const_19.Invoke_O__O(s__6), A_arbace_j2g_vh_A_const_22.Invoke_O__O(s__6)); var arg_656 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1348000086); var tmp8 any; var root_657 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_659 lang.IFn; if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = s__1348000087__3; if linked_658 == nil { tmp8 = ifn_659.Invoke_O__O(arg_660) } else { tmp8 = linked_658.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_657, arg_660) }; arg_656 = tmp7.Invoke_O__O(tmp8); if linked_653 == nil { return ifn_654.Invoke_O_O__O(arg_655, arg_656) } else { return linked_653.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_652, arg_655, arg_656) } } else { var tmp9 any; var root_661 any = A_arbace_j2g_vh_A_const_89.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = s__1348000087__3; if linked_662 == nil { tmp9 = ifn_663.Invoke_O__O(arg_664) } else { tmp9 = linked_662.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_661, arg_664) }; s__1348000087__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :155:1
func A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :155:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A) Ctor_O_I_O(c__b__1348000089 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1348000089 = c__b__1348000089; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :155:1
func (t *A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A) Invoke_O__O(self any) any { { var i__1348000088__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1348000088__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1348000093__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1348000088__1)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000093__2, lang.RT_IntCast_J__I_NoInit(0), nil); var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1348000093__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any = A_arbace_j2g_vh_A_const_21; _ = ___3; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_34.Invoke_O__O(s__4)) { var root_619 any = A_arbace_j2g_vh_A_const_85.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = t.F_b__1348000089; var arg_623 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_vh_A_const_19.Invoke_O__O(s__4), A_arbace_j2g_vh_A_const_22.Invoke_O__O(s__4)); if linked_620 == nil { ifn_621.Invoke_O_O__O(arg_622, arg_623) } else { linked_620.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_619, arg_622, arg_623) }; i__1348000088__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1348000088__1); continue L1 } else { i__1348000088__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1348000088__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_vh_mode_A_New() *A_arbace_j2g_vh_mode_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_mode_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_j2g_vh_mode_A) Ctor() {}
//line :162:1
func (t *A_arbace_j2g_vh_mode_A) Invoke_O_O__O(self, name__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_94).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_95 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_96).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_97 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_98).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_99 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_100).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_101 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_102).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_103 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_104).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_105 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_106).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_107 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_108).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_109 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_vh_A_const_110).Invoke_O__O(name__0)) { return A_arbace_j2g_vh_A_const_111 } else { if A_arbace_j2g_vh_A_const_66 != nil { return nil } else { return nil
	}
	}
	}
	}
	}
	}
	}
	}
	}
	}
}

func A_arbace_j2g_vh_fence_QMARK__A_New() *A_arbace_j2g_vh_fence_QMARK__A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_fence_QMARK__A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_j2g_vh_fence_QMARK__A) Ctor() {}
//line :178:1
func (t *A_arbace_j2g_vh_fence_QMARK__A) Invoke_O_O__O(self, node__0 any) any { var tmp1 any = A_arbace_j2g_vh_A_const_32; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__0)); if and__1927000168__auto____2 {
										var tmp2 any = A_arbace_j2g_vh_A_const_33; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_34.Invoke_O__O(node__0)); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_61.GetRawRoot__O(), A_arbace_j2g_vh_A_const_28.Invoke_O__O(node__0)); if and__1927000168__auto____4 { return lang.IFn_Cast(A_arbace_j2g_vh_A_const_112.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_vh_A_const_22.Invoke_O__O(node__0)) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_j2g_vh_op_handle_A_New() *A_arbace_j2g_vh_op_handle_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_op_handle_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_j2g_vh_op_handle_A) Ctor() {}
//line :181:1
func (t *A_arbace_j2g_vh_op_handle_A) Invoke_O_O_O__O(self, hs__0, node__1 any) any {



	var tmp1 any; var tmp2 any = A_arbace_j2g_vh_A_const_32; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_j2g_vh_A_const_14.Invoke_O__O(node__1)); if and__1927000168__auto____3 { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_j2g_vh_A_const_61.GetRawRoot__O(), A_arbace_j2g_vh_A_const_28.Invoke_O__O(node__1)); if and__1927000168__auto____4 { var root_669 any = A_arbace_j2g_vh_A_const_113.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any = A_arbace_j2g_vh_A_const_33; var arg_673 any = A_arbace_j2g_vh_A_const_34.Invoke_O__O(node__1); if linked_670 == nil { tmp1 = ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { tmp1 = linked_670.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_669, arg_672, arg_673) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { var tg__3 any; var root_674 any = A_arbace_j2g_vh_A_const_13.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A_fn_class); var ifn_676 lang.IFn
		if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = A_arbace_j2g_vh_A_const_64.Invoke_O__O(node__1); if linked_675 == nil { tg__3 = ifn_676.Invoke_O__O(arg_677) } else { tg__3 = linked_675.(*aot_arbace_j2g_access.A_arbace_j2g_access_unaccess_A).Invoke_O_O__O(root_674, arg_677) }
		var tmp3 any = A_arbace_j2g_vh_A_const_20; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_j2g_vh_A_const_14.Invoke_O__O(tg__3)) { var f__4 any = A_arbace_j2g_vh_A_const_21.Invoke_O__O(tg__3); var spec__5 any; var tmp4 any; var or__1927000174__auto____5 any = A_arbace_j2g_vh_A_const_27.Invoke_O__O(f__4)

			if jrt.J2g_Truth(or__1927000174__auto____5) { tmp4 = or__1927000174__auto____5 } else { tmp4 = A_arbace_j2g_vh_A_const_28.Invoke_O__O(f__4) }; spec__5 = lang.RT_Get_O_O__O_NoInit(hs__0, lang.Tuple_Create_O_O__IPersistentVector(tmp4, A_arbace_j2g_vh_A_const_22.Invoke_O__O(f__4)))
//line :187:1
			var m__6 any; var root_678 any = A_arbace_j2g_vh_A_const_114.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, A_arbace_j2g_vh_mode_A_fn_class); var ifn_680 lang.IFn


			if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = A_arbace_j2g_vh_A_const_22.Invoke_O__O(node__1); if linked_679 == nil { m__6 = ifn_680.Invoke_O__O(arg_681) } else { m__6 = linked_679.(*A_arbace_j2g_vh_mode_A).Invoke_O_O__O(root_678, arg_681) }
			var tmp5 any; var and__1927000168__auto____7 any = spec__5; if jrt.J2g_Truth(and__1927000168__auto____7) { tmp5 = m__6 } else { tmp5 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp5) { var root_682 any = A_arbace_j2g_vh_A_const_78.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = spec__5; var arg_686 any = A_arbace_j2g_vh_A_const_115; var arg_687 any = m__6; if linked_683 == nil { return ifn_684.Invoke_O_O_O__O(arg_685, arg_686, arg_687) } else { return linked_683.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_682, arg_685, arg_686, arg_687) } } else { return nil } } else {
//line :187:1
				return nil } } else {
//line :185:1
					return nil
				}
}




















































type A_arbace_j2g_vh_A struct{ jrt.Object }

var A_arbace_j2g_vh_A_const_pool *jrt.RefArray

var A_arbace_j2g_vh_A_const_0 *lang.Var

var A_arbace_j2g_vh_A_const_1 any

var A_arbace_j2g_vh_A_const_2 any

var A_arbace_j2g_vh_A_const_3 any

var A_arbace_j2g_vh_A_const_4 any

var A_arbace_j2g_vh_A_const_5 any

var A_arbace_j2g_vh_A_const_6 *lang.Var

var A_arbace_j2g_vh_A_const_7 any

var A_arbace_j2g_vh_A_const_8 *lang.Var

var A_arbace_j2g_vh_A_const_9 *lang.Var

var A_arbace_j2g_vh_A_const_10 *lang.Var

var A_arbace_j2g_vh_A_const_11 *lang.Var

var A_arbace_j2g_vh_A_const_12 any

var A_arbace_j2g_vh_A_const_13 *lang.Var

var A_arbace_j2g_vh_A_const_14 *lang.Keyword

var A_arbace_j2g_vh_A_const_15 *lang.Keyword

var A_arbace_j2g_vh_A_const_16 *lang.Var

var A_arbace_j2g_vh_A_const_17 *lang.Keyword

var A_arbace_j2g_vh_A_const_18 *lang.Keyword

var A_arbace_j2g_vh_A_const_19 *lang.Keyword

var A_arbace_j2g_vh_A_const_20 *lang.Keyword

var A_arbace_j2g_vh_A_const_21 *lang.Keyword

var A_arbace_j2g_vh_A_const_22 *lang.Keyword

var A_arbace_j2g_vh_A_const_23 *lang.Var

var A_arbace_j2g_vh_A_const_24 *lang.Keyword

var A_arbace_j2g_vh_A_const_25 *lang.Keyword

var A_arbace_j2g_vh_A_const_26 *lang.Keyword

var A_arbace_j2g_vh_A_const_27 *lang.Keyword

var A_arbace_j2g_vh_A_const_28 *lang.Keyword

var A_arbace_j2g_vh_A_const_29 *lang.Keyword

var A_arbace_j2g_vh_A_const_30 *lang.Var

var A_arbace_j2g_vh_A_const_31 *lang.Keyword

var A_arbace_j2g_vh_A_const_32 *lang.Keyword

var A_arbace_j2g_vh_A_const_33 *lang.Keyword

var A_arbace_j2g_vh_A_const_34 *lang.Keyword

var A_arbace_j2g_vh_A_const_35 *lang.Var

var A_arbace_j2g_vh_A_const_36 *lang.Keyword

var A_arbace_j2g_vh_A_const_37 any

var A_arbace_j2g_vh_A_const_38 *lang.Var

var A_arbace_j2g_vh_A_const_39 *lang.Var

var A_arbace_j2g_vh_A_const_40 *lang.Var

var A_arbace_j2g_vh_A_const_41 *lang.Keyword

var A_arbace_j2g_vh_A_const_42 *lang.Keyword

var A_arbace_j2g_vh_A_const_43 *lang.Var

var A_arbace_j2g_vh_A_const_44 *lang.Keyword

var A_arbace_j2g_vh_A_const_45 any

var A_arbace_j2g_vh_A_const_46 *lang.Var

var A_arbace_j2g_vh_A_const_47 *lang.Var

var A_arbace_j2g_vh_A_const_48 *lang.Var

var A_arbace_j2g_vh_A_const_49 *lang.Keyword

var A_arbace_j2g_vh_A_const_50 *lang.Var

var A_arbace_j2g_vh_A_const_51 *lang.Var

var A_arbace_j2g_vh_A_const_52 *lang.Var

var A_arbace_j2g_vh_A_const_53 *lang.Var

var A_arbace_j2g_vh_A_const_54 *lang.Var

var A_arbace_j2g_vh_A_const_55 *lang.Var

var A_arbace_j2g_vh_A_const_56 *lang.Keyword

var A_arbace_j2g_vh_A_const_57 *lang.Var

var A_arbace_j2g_vh_A_const_58 any

var A_arbace_j2g_vh_A_const_59 *lang.Keyword

var A_arbace_j2g_vh_A_const_60 *lang.Keyword

var A_arbace_j2g_vh_A_const_61 *lang.Var

var A_arbace_j2g_vh_A_const_62 any

var A_arbace_j2g_vh_A_const_63 *lang.Var

var A_arbace_j2g_vh_A_const_64 *lang.Keyword

var A_arbace_j2g_vh_A_const_65 *lang.Var

var A_arbace_j2g_vh_A_const_66 *lang.Keyword

var A_arbace_j2g_vh_A_const_67 *lang.Var

var A_arbace_j2g_vh_A_const_68 *lang.Keyword

var A_arbace_j2g_vh_A_const_69 *lang.Keyword

var A_arbace_j2g_vh_A_const_70 *lang.Var

var A_arbace_j2g_vh_A_const_71 *lang.Var

var A_arbace_j2g_vh_A_const_72 *lang.Var

var A_arbace_j2g_vh_A_const_73 *lang.Var

var A_arbace_j2g_vh_A_const_74 any

var A_arbace_j2g_vh_A_const_75 *lang.Keyword

var A_arbace_j2g_vh_A_const_76 *lang.Keyword

var A_arbace_j2g_vh_A_const_77 *lang.Var

var A_arbace_j2g_vh_A_const_78 *lang.Var

var A_arbace_j2g_vh_A_const_79 *lang.Var

var A_arbace_j2g_vh_A_const_80 any

var A_arbace_j2g_vh_A_const_81 *lang.Keyword

var A_arbace_j2g_vh_A_const_82 *lang.Var

var A_arbace_j2g_vh_A_const_83 *lang.Var

var A_arbace_j2g_vh_A_const_84 *lang.Var

var A_arbace_j2g_vh_A_const_85 *lang.Var

var A_arbace_j2g_vh_A_const_86 *lang.Var

var A_arbace_j2g_vh_A_const_87 *lang.Var

var A_arbace_j2g_vh_A_const_88 *lang.Var

var A_arbace_j2g_vh_A_const_89 *lang.Var

var A_arbace_j2g_vh_A_const_90 *lang.Var

var A_arbace_j2g_vh_A_const_91 *lang.Var

var A_arbace_j2g_vh_A_const_92 *lang.Keyword

var A_arbace_j2g_vh_A_const_93 *lang.Var

var A_arbace_j2g_vh_A_const_94 any

var A_arbace_j2g_vh_A_const_95 *lang.Keyword

var A_arbace_j2g_vh_A_const_96 any

var A_arbace_j2g_vh_A_const_97 *lang.Keyword

var A_arbace_j2g_vh_A_const_98 any

var A_arbace_j2g_vh_A_const_99 *lang.Keyword

var A_arbace_j2g_vh_A_const_100 any

var A_arbace_j2g_vh_A_const_101 *lang.Keyword

var A_arbace_j2g_vh_A_const_102 any

var A_arbace_j2g_vh_A_const_103 *lang.Keyword

var A_arbace_j2g_vh_A_const_104 any

var A_arbace_j2g_vh_A_const_105 *lang.Keyword

var A_arbace_j2g_vh_A_const_106 any

var A_arbace_j2g_vh_A_const_107 *lang.Keyword

var A_arbace_j2g_vh_A_const_108 any

var A_arbace_j2g_vh_A_const_109 *lang.Keyword

var A_arbace_j2g_vh_A_const_110 any

var A_arbace_j2g_vh_A_const_111 *lang.Keyword

var A_arbace_j2g_vh_A_const_112 *lang.Var

var A_arbace_j2g_vh_A_const_113 *lang.Var

var A_arbace_j2g_vh_A_const_114 *lang.Var

var A_arbace_j2g_vh_A_const_115 *lang.Keyword

var A_arbace_j2g_vh_A_init jrt.ClassInit

func A_arbace_j2g_vh_A_Init() { if !A_arbace_j2g_vh_A_init.Done() { A_arbace_j2g_vh_A_init.Run(A_arbace_j2g_vh_A_clinit) } }

func A_arbace_j2g_vh_A_clinit() { A_arbace_j2g_vh_A_clinit_p0(); A_arbace_j2g_vh_A_clinit_p1(); A_arbace_j2g_vh_A_clinit_p2(); A_arbace_j2g_vh_A_clinit_p3(); A_arbace_j2g_vh_A_clinit_p4(); A_arbace_j2g_vh_A_clinit_p5(); A_arbace_j2g_vh_A_clinit_p6(); A_arbace_j2g_vh_A_clinit_p7(); A_arbace_j2g_vh_A_clinit_p8(); A_arbace_j2g_vh_A_clinit_p9() }

func A_arbace_j2g_vh_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_vh_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 175); A_arbace_j2g_vh_A_const_0 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[59]); A_arbace_j2g_vh_A_const_1 = A_arbace_j2g_vh_A_const_pool.A[60]; A_arbace_j2g_vh_A_const_2 = A_arbace_j2g_vh_A_const_pool.A[61]; A_arbace_j2g_vh_A_const_3 = A_arbace_j2g_vh_A_const_pool.A[62]; A_arbace_j2g_vh_A_const_4 = A_arbace_j2g_vh_A_const_pool.A[63]; A_arbace_j2g_vh_A_const_5 = A_arbace_j2g_vh_A_const_pool.A[64]; A_arbace_j2g_vh_A_const_6 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[65]); A_arbace_j2g_vh_A_const_7 = A_arbace_j2g_vh_A_const_pool.A[66]; A_arbace_j2g_vh_A_const_8 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[67]); A_arbace_j2g_vh_A_const_9 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[68]); A_arbace_j2g_vh_A_const_10 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[69]); A_arbace_j2g_vh_A_const_11 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[70]); A_arbace_j2g_vh_A_const_12 = A_arbace_j2g_vh_A_const_pool.A[71] }

func A_arbace_j2g_vh_A_clinit_p1() { A_arbace_j2g_vh_A_const_13 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[72]); A_arbace_j2g_vh_A_const_14 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[73]); A_arbace_j2g_vh_A_const_15 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[74]); A_arbace_j2g_vh_A_const_16 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[75]); A_arbace_j2g_vh_A_const_17 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[76]); A_arbace_j2g_vh_A_const_18 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[77]); A_arbace_j2g_vh_A_const_19 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[78]); A_arbace_j2g_vh_A_const_20 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[79]); A_arbace_j2g_vh_A_const_21 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[80]); A_arbace_j2g_vh_A_const_22 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[81]); A_arbace_j2g_vh_A_const_23 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[82]); A_arbace_j2g_vh_A_const_24 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[83]) }

func A_arbace_j2g_vh_A_clinit_p2() { A_arbace_j2g_vh_A_const_25 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[84]); A_arbace_j2g_vh_A_const_26 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[85]); A_arbace_j2g_vh_A_const_27 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[86]); A_arbace_j2g_vh_A_const_28 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[87]); A_arbace_j2g_vh_A_const_29 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[88]); A_arbace_j2g_vh_A_const_30 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[89]); A_arbace_j2g_vh_A_const_31 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[90]); A_arbace_j2g_vh_A_const_32 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[91]); A_arbace_j2g_vh_A_const_33 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[92]); A_arbace_j2g_vh_A_const_34 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[93]); A_arbace_j2g_vh_A_const_35 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[94]); A_arbace_j2g_vh_A_const_36 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[95]) }

func A_arbace_j2g_vh_A_clinit_p3() { A_arbace_j2g_vh_A_const_37 = A_arbace_j2g_vh_A_const_pool.A[96]; A_arbace_j2g_vh_A_const_38 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[97]); A_arbace_j2g_vh_A_const_39 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[98]); A_arbace_j2g_vh_A_const_40 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[99]); A_arbace_j2g_vh_A_const_41 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[100]); A_arbace_j2g_vh_A_const_42 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[101]); A_arbace_j2g_vh_A_const_43 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[102]); A_arbace_j2g_vh_A_const_44 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[103]); A_arbace_j2g_vh_A_const_45 = A_arbace_j2g_vh_A_const_pool.A[104]; A_arbace_j2g_vh_A_const_46 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[105]); A_arbace_j2g_vh_A_const_47 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[106]); A_arbace_j2g_vh_A_const_48 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[107]) }

func A_arbace_j2g_vh_A_clinit_p4() { A_arbace_j2g_vh_A_const_49 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[108]); A_arbace_j2g_vh_A_const_50 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[109]); A_arbace_j2g_vh_A_const_51 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[110]); A_arbace_j2g_vh_A_const_52 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[111]); A_arbace_j2g_vh_A_const_53 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[112]); A_arbace_j2g_vh_A_const_54 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[113]); A_arbace_j2g_vh_A_const_55 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[114]); A_arbace_j2g_vh_A_const_56 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[115]); A_arbace_j2g_vh_A_const_57 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[116]); A_arbace_j2g_vh_A_const_58 = A_arbace_j2g_vh_A_const_pool.A[117]; A_arbace_j2g_vh_A_const_59 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[118]); A_arbace_j2g_vh_A_const_60 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[119]) }

func A_arbace_j2g_vh_A_clinit_p5() { A_arbace_j2g_vh_A_const_61 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[120]); A_arbace_j2g_vh_A_const_62 = A_arbace_j2g_vh_A_const_pool.A[121]; A_arbace_j2g_vh_A_const_63 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[122]); A_arbace_j2g_vh_A_const_64 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[123]); A_arbace_j2g_vh_A_const_65 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[124]); A_arbace_j2g_vh_A_const_66 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[125]); A_arbace_j2g_vh_A_const_67 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[126]); A_arbace_j2g_vh_A_const_68 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[127]); A_arbace_j2g_vh_A_const_69 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[128]); A_arbace_j2g_vh_A_const_70 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[129]); A_arbace_j2g_vh_A_const_71 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[130]); A_arbace_j2g_vh_A_const_72 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[131]) }

func A_arbace_j2g_vh_A_clinit_p6() { A_arbace_j2g_vh_A_const_73 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[132]); A_arbace_j2g_vh_A_const_74 = A_arbace_j2g_vh_A_const_pool.A[133]; A_arbace_j2g_vh_A_const_75 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[134]); A_arbace_j2g_vh_A_const_76 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[135]); A_arbace_j2g_vh_A_const_77 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[136]); A_arbace_j2g_vh_A_const_78 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[137]); A_arbace_j2g_vh_A_const_79 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[138]); A_arbace_j2g_vh_A_const_80 = A_arbace_j2g_vh_A_const_pool.A[139]; A_arbace_j2g_vh_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[140]); A_arbace_j2g_vh_A_const_82 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[141]); A_arbace_j2g_vh_A_const_83 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[142]); A_arbace_j2g_vh_A_const_84 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[143]) }

func A_arbace_j2g_vh_A_clinit_p7() { A_arbace_j2g_vh_A_const_85 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[144]); A_arbace_j2g_vh_A_const_86 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[145]); A_arbace_j2g_vh_A_const_87 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[146]); A_arbace_j2g_vh_A_const_88 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[147]); A_arbace_j2g_vh_A_const_89 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[148]); A_arbace_j2g_vh_A_const_90 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[149]); A_arbace_j2g_vh_A_const_91 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[150]); A_arbace_j2g_vh_A_const_92 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[151]); A_arbace_j2g_vh_A_const_93 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[152]); A_arbace_j2g_vh_A_const_94 = A_arbace_j2g_vh_A_const_pool.A[153]; A_arbace_j2g_vh_A_const_95 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[154]); A_arbace_j2g_vh_A_const_96 = A_arbace_j2g_vh_A_const_pool.A[155] }

func A_arbace_j2g_vh_A_clinit_p8() { A_arbace_j2g_vh_A_const_97 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[156]); A_arbace_j2g_vh_A_const_98 = A_arbace_j2g_vh_A_const_pool.A[157]; A_arbace_j2g_vh_A_const_99 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[158]); A_arbace_j2g_vh_A_const_100 = A_arbace_j2g_vh_A_const_pool.A[159]; A_arbace_j2g_vh_A_const_101 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[160]); A_arbace_j2g_vh_A_const_102 = A_arbace_j2g_vh_A_const_pool.A[161]; A_arbace_j2g_vh_A_const_103 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[162]); A_arbace_j2g_vh_A_const_104 = A_arbace_j2g_vh_A_const_pool.A[163]; A_arbace_j2g_vh_A_const_105 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[164]); A_arbace_j2g_vh_A_const_106 = A_arbace_j2g_vh_A_const_pool.A[165]; A_arbace_j2g_vh_A_const_107 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[166]); A_arbace_j2g_vh_A_const_108 = A_arbace_j2g_vh_A_const_pool.A[167]; A_arbace_j2g_vh_A_const_109 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[168]) }

func A_arbace_j2g_vh_A_clinit_p9() { A_arbace_j2g_vh_A_const_110 = A_arbace_j2g_vh_A_const_pool.A[169]; A_arbace_j2g_vh_A_const_111 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[170]); A_arbace_j2g_vh_A_const_112 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[171]); A_arbace_j2g_vh_A_const_113 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[172]); A_arbace_j2g_vh_A_const_114 = lang.Var_Cast(A_arbace_j2g_vh_A_const_pool.A[173]); A_arbace_j2g_vh_A_const_115 = lang.Keyword_Cast(A_arbace_j2g_vh_A_const_pool.A[174]) }

func A_arbace_j2g_vh_A_New() *A_arbace_j2g_vh_A { A_arbace_j2g_vh_A_Init(); t := &A_arbace_j2g_vh_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_vh_A) Ctor() {}

func (t *A_arbace_j2g_vh_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_vh_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_vh_A_class }

func (t *A_arbace_j2g_vh_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_vh_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_vh_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_vh_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_vh_A); return ok }

func A_arbace_j2g_vh_A_Cast(x any) *A_arbace_j2g_vh_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_vh_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_vh_A_class)) }; return v }



type A_arbace_j2g_vh_byte_order_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_byte_order_arg_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_class_arg_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_class_handles_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_fn__1348000032_A struct{ j2g_header uint64; F_env any }

var A_arbace_j2g_vh_class_handles_fn__1348000032_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_fn__1348000044_A struct{ j2g_header uint64; F_env any }

var A_arbace_j2g_vh_class_handles_fn__1348000044_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_fn__1348000060_A struct{ j2g_header uint64; F_env, F_out, F_n any }

var A_arbace_j2g_vh_class_handles_fn__1348000060_A_fn_class *jrt.Class



type A_arbace_j2g_vh_class_handles_fn__1348000062_A struct{ j2g_header uint64; F_env, F_out, F_n any }

var A_arbace_j2g_vh_class_handles_fn__1348000062_A_fn_class *jrt.Class



type A_arbace_j2g_vh_eval1348000004_A struct{ jrt.Object }

func A_arbace_j2g_vh_eval1348000004_A_New() *A_arbace_j2g_vh_eval1348000004_A { t := &A_arbace_j2g_vh_eval1348000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_vh_eval1348000004_A) Ctor() {}

func (t *A_arbace_j2g_vh_eval1348000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_vh_eval1348000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_vh_eval1348000004_A_class }

func (t *A_arbace_j2g_vh_eval1348000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_vh_eval1348000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_vh_eval1348000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_vh_eval1348000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_vh_eval1348000004_A); return ok }

func A_arbace_j2g_vh_eval1348000004_A_Cast(x any) *A_arbace_j2g_vh_eval1348000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_vh_eval1348000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_vh_eval1348000004_A_class)) }; return v }



type A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_eval1348000004_loading__1927001464__auto____1348000005_A_fn_class *jrt.Class



type A_arbace_j2g_vh_eval1348000008_A struct{ jrt.Object }

func A_arbace_j2g_vh_eval1348000008_A_New() *A_arbace_j2g_vh_eval1348000008_A { t := &A_arbace_j2g_vh_eval1348000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_vh_eval1348000008_A) Ctor() {}

func (t *A_arbace_j2g_vh_eval1348000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_vh_eval1348000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_vh_eval1348000008_A_class }

func (t *A_arbace_j2g_vh_eval1348000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_vh_eval1348000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_vh_eval1348000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_vh_eval1348000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_vh_eval1348000008_A); return ok }

func A_arbace_j2g_vh_eval1348000008_A_Cast(x any) *A_arbace_j2g_vh_eval1348000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_vh_eval1348000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_vh_eval1348000008_A_class)) }; return v }



type A_arbace_j2g_vh_eval1348000008_fn__1348000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_eval1348000008_fn__1348000009_A_fn_class *jrt.Class



type A_arbace_j2g_vh_fence_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_fence_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_vh_find_field_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_find_field_A_fn_class *jrt.Class



type A_arbace_j2g_vh_find_field_fn__1348000018_A struct{ j2g_header uint64; F_fname any }

var A_arbace_j2g_vh_find_field_fn__1348000018_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handle_spec_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handle_spec_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handle_spec_field_spec__1348000022_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A struct{ j2g_header uint64; F_s__1348000067, F_iter__1348000066 any }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000074_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_fn__1348000082_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A struct{ j2g_header uint64; F_iter__1348000068, F_s__1348000069 any }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A struct{ j2g_header uint64; F_b__1348000071 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_vh_handles_iter__1348000066__1348000072_fn__1348000073_iter__1348000068__1348000076_fn__1348000077_fn__1348000078_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_handles_iter__1348000086__1348000090_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A struct{ j2g_header uint64; F_s__1348000087, F_iter__1348000086 any }

var A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_A_fn_class *jrt.Class



type A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A struct{ j2g_header uint64; F_b__1348000089 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_vh_handles_iter__1348000086__1348000090_fn__1348000091_fn__1348000092_A_fn_class *jrt.Class



type A_arbace_j2g_vh_mode_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_mode_A_fn_class *jrt.Class



type A_arbace_j2g_vh_op_handle_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_op_handle_A_fn_class *jrt.Class



type A_arbace_j2g_vh_static_flag_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_static_flag_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_vh_string_arg_A struct{ j2g_header uint64 }

var A_arbace_j2g_vh_string_arg_A_fn_class *jrt.Class
