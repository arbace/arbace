//line j2g_strings.ae:1
package aot_arbace_c2j_emit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.j2g.jrtyn3,jrtyn16,arbace.j2g.namesyn2,nmyn15,arbace.c2j.nodekn5,referyn7,defnodekn3,dockn4,selfkn3,tagkn15,runtime-classeskn12,unit-proxieskn5,poolskn4,namekn6,constskn9,const-mapkn12,const-prefixkn3,clskn4,prevyn3,newys16,java.lang.Object1,1yn14,unchecked-charys16,java.lang.Double16,longBitsToDoublekn4,elseys17,java.lang.Boolean4,TRUEys17,java.lang.Boolean5,FALSEys17,java.lang.Integer7,valueOfyn13,unchecked-intys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys19,java.lang.Character7,valueOfys14,arbace.lang.RT22,classForNameNonLoadingys18,arbace.lang.Symbol6,internkn10,param-tagsyn16,java.lang.Stringys14,arbace.lang.RT7,keywordys14,arbace.lang.RT3,varys21,arbace.lang.Namespace12,findOrCreateyn18,arbace.lang.Symbolys14,arbace.lang.RT3,mapys17,arbace.lang.Tuple6,createyn16,java.lang.Objectys14,arbace.lang.RT6,vectorys29,arbace.lang.PersistentHashSet5,EMPTYys29,arbace.lang.PersistentHashSet6,createys26,arbace.lang.PersistentList6,createyn14,java.util.Listys16,java.util.Arrays6,asListys23,java.util.regex.Pattern7,compileys14,arbace.lang.RT10,readStringyn9,.withMetayn4,castyn16,arbace.lang.IObjyn26,arbace.lang.IPersistentMapkn3,nilkn6,stringkn7,booleankn3,intkn4,longkn6,doublekn4,charkn5,classkn6,symbolkn7,keywordkn3,varkn2,nskn3,mapkn6,vectorkn3,setkn4,listkn7,patternkn4,readyn5,fieldyn10,const-poolkn6,statickn5,finalkn7,privateys24,arbace.lang.Compiler$AOT4,poolyn3,intks3,c2j2,nnyn4,agetyn15,arbace.lang.Varyn19,arbace.lang.Keywordyn15,java.lang.Classkn7,gensymskn3,idxkn6,closedyn4,thiskn4,primkn16,canEmitPrimitiveyn2,dokn14,unchecked-mathyn13,.booleanValueyn17,java.lang.Booleanyn10,.charValueyn19,java.lang.Characterys30,arbace.lang.Compiler$Evaluator7,fiAdaptys14,arbace.lang.RT16,uncheckedIntCastys14,arbace.lang.RT7,intCastyn4,longyn15,unchecked-floatyn4,.getyn11,.getRawRootkn4,lineks3,c2j4,linekn11,spec-localskn1,bkn4,formkn6,clearskn4,oncekn11,shouldClearkn12,canBeClearedkn11,bindingPrimkn5,isArgkn8,self-symkn1,lyn2,ifyn4,nil?yn4,set!kn7,dynamickn5,redefkn5,macrokn2,opkn8,restParmkn8,reqParmskn8,retClasskn6,paramskn3,retkn4,bodykn6,methodkn4,argskn1,okn5,fexprkn10,loopLocalskn12,initProvidedkn4,initkn10,isVariadickn7,methodsys14,arbace.lang.RT10,doubleCastys14,arbace.lang.RT8,longCastkn5,bindskn3,genkn3,prikn1,nkn4,passkn5,guardyn9,instance?yn14,java.lang.Longyn10,.longValuekn1,rkn1,wkn1,fkn2,idkn3,keykn6,callerkn4,rootkn4,symskn4,psigkn3,outkn4,convkn5,partskn5,smaskkn5,spassyn3,andys3,c2j4,linkyn7,.invokeyn15,arbace.lang.IFnyn11,.invokePrimyn11,.invokeSpecyn30,arbace.lang.Compiler$AOTRestFnyn26,arbace.lang.Compiler$AOTFnyn3,letys30,arbace.lang.Compiler$AOTRestFn6,linkedys26,arbace.lang.Compiler$AOTFn10,linkedFastkn2,fnkn4,kindkn10,isProtocolkn10,protocolOnkn8,onMethodyn3,notys24,arbace.lang.Compiler$AOT5,isDynkn7,classeskn7,standinkn5,funcskn9,interfacekn11,dyn-guardedkn6,targetks15,arbace.c2j.emit5,localkn10,target-symkn15,qualifyingClassyn5,some?ys21,arbace.lang.Reflector20,invokeInstanceMethodkn10,methodNameys21,arbace.lang.Reflector27,invokeInstanceMethodOfClassyn6,doubleyn13,unchecked-addyn18,unchecked-multiplyyn2,>=yn7,bit-andyn7,bit-xoryn2,==yn1,<yn2,oryn16,unchecked-divideyn18,unchecked-subtractyn2,<=yn6,bit-oryn19,unchecked-remainderyn14,bit-shift-leftyn1,>yn15,bit-shift-rightyn16,unchecked-negateyn13,unchecked-decyn13,unchecked-inckn1,jkn1,xyn1,xyn4,slowyn1,yyn1,ryn12,.doubleValueyn16,java.lang.Doublekn7,mutableys21,arbace.lang.Reflector18,invokeStaticMethodkn1,ckn5,fieldys21,arbace.lang.Reflector25,invokeNoArgInstanceMemberyn7,booleankn9,fieldNamekn12,requireFieldys21,arbace.lang.Reflector14,getStaticFieldkn4,ctorys21,arbace.lang.Reflector17,invokeConstructorkn4,metayn9,.bindRootyn8,.setMetakn9,isDynamicyn11,.setDynamickn3,valyn4,.setys21,arbace.lang.Reflector16,setInstanceFieldkn12,bindingInitskn6,isLoopkn11,loop-localskn7,bindingyn4,loopyn5,recurkn12,method-recurkn13,method-localskn12,supportsMetakn6,closeskn8,variadicys24,arbace.lang.Compiler$AOT7,fnClassyn3,trykn7,tryExpryn5,catchkn2,lbkn7,handlerkn10,catchExprskn11,finallyExpryn7,finallykn4,exprkn5,shiftkn4,maskyn11,bit-and-intyn19,bit-shift-right-intkn5,testskn5,thenskn8,testTypekn7,defaultkn9,skipCheckkn13,hash-identityyn4,whenys16,arbace.lang.Util5,equivyn5,breakyn10,identical?yn6,switchys16,arbace.lang.Util4,hashyn9,.intValueyn16,java.lang.Numberyn5,labelkn11,defaultExprys26,arbace.lang.PersistentList5,EMPTYys28,arbace.lang.PersistentVector5,EMPTYys30,arbace.lang.PersistentArrayMap5,EMPTYkn1,dkn1,zkn1,pyn6,Objectyn6,Numberyn2,t-kn8,testExprkn8,thenExprkn8,elseExprkn12,tailPositionyn8,.applyTokn9,isDeftypekn4,typekn5,exprskn1,kkn2,kwkn7,keyvalsys30,arbace.lang.Compiler$Evaluator11,monitorExityn5,throwyn19,java.lang.Throwablekn7,excExprys14,arbace.lang.RT11,arrayToListys30,arbace.lang.Compiler$Evaluator12,monitorEnteryn12,.importClassyn21,arbace.lang.Namespaceyn6,.derefys14,arbace.lang.RT10,CURRENT_NSkn5,textsys24,arbace.lang.Compiler$AOT9,strConcatys16,java.lang.String1,1ys14,arbace.lang.RT3,setkn4,keysyn11,.isInstancekn9,argLocalskn4,speckn4,objxkn13,compiledClasskn3,symkn16,volatile-mutablekn8,volatilekn22,unsynchronized-mutablekn6,publickn12,hintedFieldskn12,altCtorDropsyn11,constructoryn6,super.kn6,columnyn3,m__yn6,methodkn7,deftypekn5,superkn10,interfaceskn7,memberskn6,sourceks15,arbace.c2j.emit7,pendingyn5,this.yn8,getBasisyn29,arbace.lang.IPersistentVectoryn6,createys19,arbace.lang.Keyword6,internyn6,.valAtyn8,.withoutys14,arbace.lang.RT9,seqOrElsekn8,fn-nameskn8,onceOnlyyn4,selfyn6,meta__yn8,.-__metayn6,invokeyn10,invokeSpecyn10,invokePrimyn8,doInvokeyn8,fn-classyn6,__metayn4,metayn8,withMetayn1,mkn5,reifykn5,primskn5,specsys14,arbace.lang.RT4,consys14,arbace.lang.RT3,seqys14,arbace.lang.RT16,loadClassForNameys24,arbace.lang.Compiler$AOT2,atkn7,packageyn8,defclassks3,c2j6,sourceyn4,loadyn4,initks3,c2j4,codekn6,holderkn7,extendskn10,implementskn8,abstractv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R9,V1,R10,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.c2j.emitm2,R11,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).v11,arbace.core5,some?v15,arbace.c2j.emit10,node-cachev11,arbace.core5,assocR12,v11,arbace.core7,ex-infov13,arbace.string12,starts-with?v11,arbace.core4,subsv11,arbace.core6,symbolv11,arbace.core3,strv15,arbace.c2j.emit8,type-symv15,arbace.c2j.emit6,destubv11,arbace.core9,vary-metaR13,v15,arbace.c2j.emit10,prim-namesv15,arbace.c2j.emit10,registeredv11,arbace.core3,notv11,arbace.core5,swap!v11,arbace.core9,contains?R14,v15,arbace.c2j.emit11,registered?v11,arbace.core8,identityR15,l0,R16,v11,arbace.core4,atomR17,R18,R19,R20,R21,R22,v11,arbace.core4,namev11,arbace.core6,updatev11,arbace.core4,listR23,R24,v11,arbace.core4,mapvv15,arbace.c2j.emit10,emit-valuev11,arbace.core4,not=c92,R25,R26,V2,nTv11,arbace.core7,string?v11,arbace.core6,class?v11,arbace.core7,symbol?v11,arbace.core8,keyword?v11,arbace.core4,var?v15,arbace.c2j.emit4,failv11,arbace.core5,classv11,arbace.core4,map?v11,arbace.core7,vector?v11,arbace.core4,seq?v11,arbace.core5,list?R27,v11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsR28,R29,R30,R31,R32,R33,v15,arbace.c2j.emit11,double-formR34,v15,arbace.c2j.emit9,char-formC17,java.lang.BooleanC14,java.lang.ByteC19,java.lang.CharacterC16,java.lang.DoubleC15,java.lang.FloatC17,java.lang.IntegerC14,java.lang.LongC15,java.lang.ShortR35,v11,arbace.core9,with-metaR36,m2,R37,V2,R38,R38,v11,arbace.core9,namespaceR39,m2,R37,V2,R38,R38,R40,m2,R37,V2,R38,R38,R41,m2,R37,V1,R42,R36,m2,R37,V2,R38,R38,R43,m2,R37,V1,R24,v15,arbace.c2j.emit15,emit-list-arrayv11,arbace.core6,mapcatv11,arbace.core5,list*R44,R37,v11,arbace.core3,vecv11,arbace.core6,repeatR45,v11,arbace.core3,mapR46,m2,R37,V1,R24,v11,arbace.core6,empty?R47,R48,m2,R37,V1,R24,v11,arbace.core3,seqR49,m2,R37,V1,R50,R51,m2,R37,V1,R24,R52,m2,R37,V1,R38,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*print-dup*R53,m2,R37,V1,R38,R54,R55,R56,R55,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,R72,R73,R74,R75,v15,arbace.c2j.emit9,pool-kindv11,arbace.core6,concatv15,arbace.c2j.emit12,pool-partialc44,v15,arbace.c2j.emit12,pool-shared?c82,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv15,arbace.c2j.emit11,pool-encodev11,arbace.core10,chunk-restv11,arbace.core4,nextc77,v15,arbace.c2j.emit8,pool-strc110,c84,c70,c118,c107,c115,c112,c100,c109,c80,c86,c68,c67,c66,c90,c74,c83,c73,c99,c78,c114,c108,c121,c69,c105,c76,v11,arbace.core6,removev11,arbace.core4,run!v15,arbace.c2j.emit10,pool-partsv11,arbace.core4,intov11,arbace.core11,map-indexedR76,v15,arbace.c2j.emit6,taggedR77,m6,R78,TR79,TR80,TR81,m2,R37,V2,R38,R82,R31,v11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR76,m6,R78,TR79,TR83,TR45,R84,R77,R31,R55,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consm6,R78,TR79,TR83,Tv11,arbace.core4,restR85,R86,R87,R45,v15,arbace.c2j.emit14,runtime-class?v15,arbace.c2j.emit14,*late-classes*v15,arbace.c2j.emit11,const-fieldv15,arbace.c2j.emit10,const-typeR35,m2,R37,V1,R38,R88,v11,arbace.core4,fnilv11,arbace.core3,incR89,R90,v15,arbace.c2j.emit9,field-symR91,R92,v15,arbace.c2j.emit4,nodeR93,R94,v15,arbace.c2j.emit6,box-ofC16,java.lang.ObjectR95,v15,arbace.c2j.emit7,public?R96,R55,R97,R98,R55,R99,m2,R37,V1,R45,R55,v15,arbace.c2j.emit12,emit-unboxedv15,arbace.c2j.emit9,prim-callv15,arbace.c2j.emit9,unbox-argv15,arbace.c2j.emit4,emitv15,arbace.c2j.emit3,fi?R100,v15,arbace.c2j.emit8,constantR101,R102,m2,R37,V1,R103,R104,R23,R24,R85,R105,R106,R107,R108,R109,R32,m2,R37,V1,R103,R110,v15,arbace.c2j.emit7,closed?R111,v15,arbace.c2j.emit10,field-readR112,R113,R114,R115,R116,R117,R118,R91,v15,arbace.c2j.emit10,spec-localv11,arbace.core8,to-arrayR119,v15,arbace.c2j.emit9,local-symR120,R121,R122,v15,arbace.c2j.emit9,long-box*R123,R124,R125,R126,R127,R128,R129,v11,arbace.core4,someR130,R131,S2,s2,fns12,new-instancev11,arbace.core2,<=l1,l4,v15,arbace.c2j.emit4,psigv11,arbace.core5,rangev15,arbace.c2j.emit10,walk-nodesR132,R133,v15,arbace.c2j.emit15,intrinsic-probev11,arbace.core6,vectorR134,R135,R136,v15,arbace.c2j.emit15,long-valued-opsv11,arbace.core6,reset!R137,v11,arbace.core6,every?v11,arbace.core5,true?v11,arbace.core10,identical?R138,R139,v15,arbace.c2j.emit9,*var-fns*R140,R141,v15,arbace.c2j.emit15,site-fn-methodsv15,arbace.c2j.emit9,spec-maskR142,R143,m2,R37,V1,R45,R144,R145,R146,R147,v15,arbace.c2j.emit4,deepv15,arbace.c2j.emit9,can-prim?v15,arbace.c2j.emit10,jrt-lacks?v15,arbace.c2j.emit3,boxR148,v15,arbace.c2j.emit14,spec-intrinsicR149,R150,R151,R152,R55,R151,v15,arbace.c2j.emit9,var-valuev15,arbace.c2j.emit9,site-psigR153,v15,arbace.c2j.emit4,gsymR154,R155,R2,v15,arbace.c2j.emit9,site-specv15,arbace.c2j.emit8,prim-argv15,arbace.c2j.emit8,spec-argR156,v15,arbace.c2j.emit6,*link*R157,R158,v15,arbace.c2j.emit8,top-nameR159,R160,R161,R162,R163,R164,v11,arbace.core4,keepR165,R166,R167,R168,v15,arbace.c2j.emit14,emit-link-sitev11,arbace.core6,secondR169,R55,R170,R171,R55,R172,R55,R173,R174,R175,R170,R55,R170,R169,R169,R55,R120,R175,R170,R176,R177,R120,R121,R55,R170,R120,R121,R169,R175,R170,R120,R121,R55,R170,R120,R169,R169,R55,R121,v15,arbace.c2j.emit9,link-formR178,R179,R180,R181,v15,arbace.c2j.emit8,link-keyv15,arbace.c2j.emit8,site-keyv15,arbace.c2j.emit9,line-metaR182,R175,R120,v15,arbace.c2j.emit10,param-tagsR55,v15,arbace.c2j.emit10,typed-argsR169,R55,R170,R167,R150,R183,R184,v13,arbace.string7,replacev14,arbace.j2g.jrt4,scanv15,arbace.c2j.emit8,jrt-scanR185,R186,v16,arbace.j2g.names13,go-class-namev11,arbace.core5,applyv15,arbace.c2j.emit10,descriptorv16,arbace.j2g.names11,method-baseR187,v14,arbace.j2g.jrt14,struct-methodsv14,arbace.j2g.jrt13,iface-methodsv16,arbace.j2g.names9,impl-nameR55,R188,v15,arbace.c2j.emit19,compiled-interface?R189,R190,R191,R192,v15,arbace.c2j.emit11,method-callv15,arbace.c2j.emit20,emit-instance-methodR193,R175,R120,R167,R194,R184,R195,m2,R37,V3,R45,R38,R24,R196,v15,arbace.c2j.emit9,obj-arrayR197,R195,m2,R37,V3,R45,R38,R24,v15,arbace.c2j.emit6,*lbox*R32,m2,R37,V1,R103,R33,m2,R37,V1,R198,R175,R120,v15,arbace.c2j.emit8,long-boxR199,R200,R201,R202,R203,R203,R167,R183,R204,v15,arbace.c2j.emit8,long-minR201,R202,R203,R203,R167,R183,R167,R204,R205,R206,R204,R204,R207,R205,R199,R202,R201,R203,R208,R209,R208,R210,R200,R120,R211,R204,R212,R120,R207,R204,R213,R204,R214,v15,arbace.c2j.emit10,double-boxR199,R200,R205,R201,R199,R215,R209,R205,R204,R120,R204,R215,R216,R205,R213,v15,arbace.c2j.emit8,long-maxR217,R217,R215,R216,R204,R215,R208,d4607182418800017408,R205,d0,R213,d0,R199,d4607182418800017408,R204,d0,C19,arbace.lang.NumbersR218,R219,V1,R135,v15,arbace.c2j.emit8,long-op1R220,R221,S1,R135,S2,R135,R218,v15,arbace.c2j.emit8,long-op2R220,R222,R221,R223,R120,R121,R122,R152,R55,R151,R224,R55,R225,R150,R167,S1,R135,v11,arbace.core8,not-any?v15,arbace.c2j.emit10,double-op1v15,arbace.c2j.emit10,double-op2R175,R175,R120,R151,R175,R120,R225,R175,v15,arbace.c2j.emit12,numbers-fastv15,arbace.c2j.emit17,numbers-intrinsicv15,arbace.c2j.emit16,static-call-formR120,R121,R122,R94,R122,R226,R175,R120,R121,R206,R121,R150,R151,R120,R121,R152,R55,R151,v15,arbace.c2j.emit18,emit-static-methodR227,m2,R37,V3,R87,R38,R24,R228,R229,v15,arbace.c2j.emit9,field-ok?R55,R230,m2,R37,V3,R45,R38,R231,R232,R233,R234,m2,R37,V2,R87,R38,R235,R236,m2,R37,V2,R87,R24,R85,R237,R94,R238,R239,R240,R241,R94,R241,R239,R238,R55,R57,R242,R243,R85,R122,R122,R122,R55,R244,m2,R37,V1,R24,R245,R246,R247,R248,v15,arbace.c2j.emit17,emit-binding-initR249,R175,R250,v15,arbace.c2j.emit4,primR102,m2,R37,V1,R103,R104,R251,R252,v15,arbace.c2j.emit14,emit-fn-class!v15,arbace.c2j.emit10,emit-localR23,R253,V1,nv11,arbace.core4,keysR254,R255,R175,R87,R120,R121,R175,R87,R256,m2,R37,V2,R38,R231,R122,R23,R173,R31,R23,R174,v15,arbace.c2j.emit13,body-instancev15,arbace.c2j.emit7,fn-wrapv15,arbace.c2j.emit12,identity-setR122,R175,R94,R257,R258,R259,R260,R261,R262,R263,R264,R265,R266,R267,R268,R269,v11,arbace.core10,sorted-mapR270,R271,v11,arbace.core7,keywordR272,R273,v11,arbace.core3,setR274,R275,R276,R277,m2,R37,V2,R45,R45,R278,R276,R204,R278,R278,R276,R204,R103,R278,R278,R276,R279,R278,R276,R277,m2,R37,V2,R45,R45,R278,R280,R281,R31,R276,R280,R282,R55,R283,R150,R283,R284,R285,R198,R103,R231,R82,R28,R29,R286,R287,R288,R47,R289,R290,R291,v15,arbace.c2j.emit9,prim-chanv11,arbace.core4,castC16,java.lang.Numberd0,v15,arbace.c2j.emit4,liftR198,R103,R292,R224,R55,R293,R152,R55,R293,v15,arbace.c2j.emit11,local-placeR294,R175,R122,R295,R296,R297,R120,v15,arbace.c2j.emit11,call-staticv15,arbace.c2j.emit13,invoke-linkedR298,R169,R55,R170,R299,Mys20,arbace.lang.ArraySeq6,createm2,R37,V1,R24,R23,R24,S2,s9,instance?s5,localv15,arbace.c2j.emit8,emit-tryR300,v15,arbace.c2j.emit11,fn-instancev15,arbace.c2j.emit8,emit-defv15,arbace.c2j.emit11,emit-invokeR301,v15,arbace.c2j.emit8,box-primv15,arbace.c2j.emit19,emit-deftype-class!v15,arbace.c2j.emit10,emit-constv15,arbace.c2j.emit19,emit-instance-fieldR302,R94,v11,arbace.core7,butlastv11,arbace.core4,lastR169,R303,R304,R86,v15,arbace.c2j.emit7,emit-ifv15,arbace.c2j.emit11,emit-assignv15,arbace.c2j.emit10,emit-letfnR54,R55,R56,R55,R57,R44,R45,v15,arbace.c2j.emit9,coll-callR46,v15,arbace.c2j.emit8,emit-letv15,arbace.c2j.emit10,emit-recurR43,R305,R94,R306,v15,arbace.c2j.emit8,emit-newR307,R55,R308,R309,R310,R94,R311,v15,arbace.c2j.emit14,direct-static?v15,arbace.c2j.emit16,emit-static-callR312,R55,R313,R314,R315,R35,v15,arbace.c2j.emit17,emit-static-fieldR316,v15,arbace.c2j.emit9,emit-caseR317,R23,R318,R23,R24,R319,R320,R321,R150,R94,R321,R150,R307,R55,R308,v15,arbace.c2j.emit7,throws?R55,R283,R102,m2,R37,V1,R103,R104,R96,R55,R97,R98,R55,R99,R55,R322,v15,arbace.c2j.emit8,ret-bodyR323,R324,R249,R175,R142,R143,m2,R37,V1,R45,v15,arbace.c2j.emit12,prim-classesv11,arbace.core10,ns-resolvev11,arbace.core4,*ns*R325,R326,R327,m2,R328,TR329,m4,R330,TR79,Tv15,arbace.c2j.emit4,poolv11,arbace.core6,dissocR91,R331,R332,R333,R91,m2,R330,TML1,R334,m4,R107,i1820,R335,i26,R122,R91,R91,v11,arbace.core4,takeR336,R91,R337,m2,R330,Tv15,arbace.c2j.emit11,method-bodym2,R330,TR76,v15,arbace.c2j.emit10,field-modsR338,R339,R45,R340,v15,arbace.c2j.emit16,class-interfacesR341,R342,R343,R333,m2,R330,TR344,R31,R31,R333,m2,R330,TR344,R31,R31,R337,R345,m4,R330,TR78,TR346,R337,R347,m4,R330,TR78,TR57,v15,arbace.c2j.emit9,tag-classR348,m2,R37,V1,R38,R349,R55,v15,arbace.c2j.emit9,box-classm2,R37,V1,R38,R175,R175,R122,R350,R23,R351,R31,R31,m2,R226,TR352,R353,R354,R91,R76,R333,V1,R91,R355,R57,m2,R330,TML1,R334,m4,R107,i1899,R335,i26,V1,ML3,R122,ML2,R356,R91,m4,R107,i1900,R335,i53,R355,m4,R107,i1900,R335,i47,R122,R91,V2,R91,R354,v15,arbace.c2j.emit9,param-symV2,R91,R354,R150,R151,R167,V2,R91,R354,R337,R357,m2,R330,TR120,R172,R91,R354,R152,R55,R151,R337,R358,m2,R330,TR337,R359,m2,R330,TR337,R357,m2,R330,TR171,R91,R354,R142,R143,m2,R37,V1,R45,R337,R360,R357,m2,R330,TR91,R337,m2,R330,Tm2,R330,TR76,R361,m4,R330,TR78,TR87,R76,R362,R57,R337,R363,m2,R330,TV1,R91,R57,ML2,R356,R91,m4,R107,i1982,R335,i117,R337,R364,m2,R330,TR91,R365,R57,R56,R23,R365,R91,R366,R45,R367,v11,arbace.core9,not-emptyR368,R299,R55,R170,R106,v11,arbace.core15,get-proxy-classR85,R369,m2,R37,V2,R45,R45,R370,m2,R37,V1,R45,R23,R24,R243,R315,R41,R55,R42,m2,R37,V2,R45,R45,m2,R37,V1,R45,v11,arbace.core5,doallR276,R121,R371,m2,R37,V1,R38,R169,R55,R170,R106,v11,arbace.core12,define-proxyR85,R370,m2,R37,V1,R45,R23,R24,m2,R37,V1,R38,m2,R37,V1,R45,R337,m4,R80,TR78,TR94,R372,R31,R31,v11,arbace.core7,sort-byv11,arbace.core7,find-nsv13,arbace.string9,includes?V2,R373,s0,v15,arbace.c2j.emit11,unit-methodv15,arbace.c2j.emit7,unit-nsv15,arbace.c2j.emit17,loader-part-unitsR374,R330,R79,R375,v15,arbace.c2j.emit15,unnamed-packagev15,arbace.c2j.emit11,pool-fieldsR337,R376,m4,R330,TR78,TR94,V1,nR374,R78,R337,R377,m2,R78,TR337,R376,m2,R78,TR94,V1,nm2,R78,Tm2,R78,TV1,nv11,arbace.core13,partition-allR374,R337,R376,m4,R330,TR78,TR94,V1,nv15,arbace.c2j.emit10,class-formR378,v15,arbace.c2j.emit11,simple-nameR379,R374,m6,R330,TR78,TR79,TR374,m6,R330,TR78,TR188,TR380,R374,m6,R330,TR78,TR79,TR381,v11,arbace.core4,peekv11,arbace.core3,popv11,arbace.core8,group-byv11,arbace.core4,sortR337,m4,R330,TR382,TR91,m4,R330,TR382,T")

var Lit_1 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000380__31000384")

var Lit_2 *jrt.String = jrt.Intern("new-instance")

var Lit_3 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000380__31000384$fn__31000385")

var Lit_4 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000380__31000384$fn__31000385$fn__31000386")

var Lit_5 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form$fn__31000968")

var Lit_6 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form$mods__31000970")

var Lit_7 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$parent__31000975")

var Lit_8 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$fn__31000977")

var Lit_9 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000979__31000983")

var Lit_10 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$fn__31000989")

var Lit_11 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$children_of__31000991")

var Lit_12 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000993__31000997")

var Lit_13 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000979__31000983$fn__31000984")

var Lit_14 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000979__31000983$fn__31000984$fn__31000985")

var Lit_15 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000993__31000997$fn__31000998")

var Lit_16 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000993__31000997$fn__31000998$fn__31000999")

var Lit_17 *jrt.String = jrt.Intern("$")

var Lit_18 *jrt.String = jrt.Intern("no class for ")

var Lit_19 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000575__31000579")

var Lit_20 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000575__31000579$fn__31000580")

var Lit_21 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000575__31000579$fn__31000580$fn__31000581")

var Lit_22 *jrt.String = jrt.Intern(" implements ")

var Lit_23 *jrt.String = jrt.Intern(", made at run time")

var Lit_24 *jrt.String = jrt.Intern("const-")

var Lit_25 *jrt.String = jrt.Intern("V")

var Lit_26 *jrt.String = jrt.Intern("J")

var Lit_27 *jrt.String = jrt.Intern("I")

var Lit_28 *jrt.String = jrt.Intern("D")

var Lit_29 *jrt.String = jrt.Intern("Z")

var Lit_30 *jrt.String = jrt.Intern("C")

var Lit_31 *jrt.String = jrt.Intern("F")

var Lit_32 *jrt.String = jrt.Intern("S")

var Lit_33 *jrt.String = jrt.Intern("B")

var Lit_34 *jrt.String = jrt.Intern(".")

var Lit_35 *jrt.String = jrt.Intern("/")

var Lit_36 *jrt.String = jrt.Intern("L")

var Lit_37 *jrt.String = jrt.Intern(";")

var Lit_38 *jrt.String = jrt.Intern("compile__stub.")

var Lit_39 *jrt.String = jrt.Intern("isNeg")

var Lit_40 *jrt.String = jrt.Intern("isPos")

var Lit_41 *jrt.String = jrt.Intern("unchecked_minus")

var Lit_42 *jrt.String = jrt.Intern("unchecked_dec")

var Lit_43 *jrt.String = jrt.Intern("incP")

var Lit_44 *jrt.String = jrt.Intern("minus")

var Lit_45 *jrt.String = jrt.Intern("unchecked_inc")

var Lit_46 *jrt.String = jrt.Intern("dec")

var Lit_47 *jrt.String = jrt.Intern("inc")

var Lit_48 *jrt.String = jrt.Intern("minusP")

var Lit_49 *jrt.String = jrt.Intern("isZero")

var Lit_50 *jrt.String = jrt.Intern("decP")

var Lit_51 *jrt.String = jrt.Intern("lt")

var Lit_52 *jrt.String = jrt.Intern("addP")

var Lit_53 *jrt.String = jrt.Intern("unchecked_add")

var Lit_54 *jrt.String = jrt.Intern("unchecked_multiply")

var Lit_55 *jrt.String = jrt.Intern("gte")

var Lit_56 *jrt.String = jrt.Intern("lte")

var Lit_57 *jrt.String = jrt.Intern("add")

var Lit_58 *jrt.String = jrt.Intern("multiply")

var Lit_59 *jrt.String = jrt.Intern("multiplyP")

var Lit_60 *jrt.String = jrt.Intern("gt")

var Lit_61 *jrt.String = jrt.Intern("equiv")

var Lit_62 *jrt.String = jrt.Intern("try")

var Lit_63 *jrt.String = jrt.Intern("def")

var Lit_64 *jrt.String = jrt.Intern("invoke")

var Lit_65 *jrt.String = jrt.Intern("instance-method")

var Lit_66 *jrt.String = jrt.Intern("empty")

var Lit_67 *jrt.String = jrt.Intern("instance-field")

var Lit_68 *jrt.String = jrt.Intern("var")

var Lit_69 *jrt.String = jrt.Intern("keyword-invoke")

var Lit_70 *jrt.String = jrt.Intern("do")

var Lit_71 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000534")

var Lit_72 *jrt.String = jrt.Intern("fn")

var Lit_73 *jrt.String = jrt.Intern("if")

var Lit_74 *jrt.String = jrt.Intern("set!")

var Lit_75 *jrt.String = jrt.Intern("with-meta")

var Lit_76 *jrt.String = jrt.Intern("letfn")

var Lit_77 *jrt.String = jrt.Intern("number")

var Lit_78 *jrt.String = jrt.Intern("the-var")

var Lit_79 *jrt.String = jrt.Intern("keyword")

var Lit_80 *jrt.String = jrt.Intern("local")

var Lit_81 *jrt.String = jrt.Intern("string")

var Lit_82 *jrt.String = jrt.Intern("vector")

var Lit_83 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000536")

var Lit_84 *jrt.String = jrt.Intern("let")

var Lit_85 *jrt.String = jrt.Intern("recur")

var Lit_86 *jrt.String = jrt.Intern("constant")

var Lit_87 *jrt.String = jrt.Intern("map")

var Lit_88 *jrt.String = jrt.Intern("monitor-exit")

var Lit_89 *jrt.String = jrt.Intern("throw")

var Lit_90 *jrt.String = jrt.Intern("new")

var Lit_91 *jrt.String = jrt.Intern("nil")

var Lit_92 *jrt.String = jrt.Intern("boolean")

var Lit_93 *jrt.String = jrt.Intern("monitor-enter")

var Lit_94 *jrt.String = jrt.Intern("list")

var Lit_95 *jrt.String = jrt.Intern("import")

var Lit_96 *jrt.String = jrt.Intern("static-method")

var Lit_97 *jrt.String = jrt.Intern("static-field")

var Lit_98 *jrt.String = jrt.Intern("str-concat")

var Lit_99 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000538")

var Lit_100 *jrt.String = jrt.Intern("case")

var Lit_101 *jrt.String = jrt.Intern("set")

var Lit_102 *jrt.String = jrt.Intern("instance?")

var Lit_103 *jrt.String = jrt.Intern("no back end for ")

var Lit_104 *jrt.String = jrt.Intern(" ")

var Lit_105 *jrt.String = jrt.Intern("set! of a local that is no field")

var Lit_106 *jrt.String = jrt.Intern(".-")

var Lit_107 *jrt.String = jrt.Intern("set! of ")

var Lit_108 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$sm__31000446")

var Lit_109 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$ret__31000448")

var Lit_110 *jrt.String = jrt.Intern("case-")

var Lit_111 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$arm__31000450")

var Lit_112 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$fn__31000453")

var Lit_113 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$fn__31000459")

var Lit_114 *jrt.String = jrt.Intern("longValue")

var Lit_115 *jrt.String = jrt.Intern("doubleValue")

var Lit_116 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_117 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ftype__31000590")

var Lit_118 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fsym__31000592")

var Lit_119 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fn__31000594")

var Lit_120 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000596__31000600")

var Lit_121 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ps__31000606")

var Lit_122 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000610__31000614")

var Lit_123 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fn__31000627")

var Lit_124 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000632__31000636")

var Lit_125 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000648__31000652")

var Lit_126 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000666__31000670")

var Lit_127 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000596__31000600$fn__31000601")

var Lit_128 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000596__31000600$fn__31000601$fn__31000602")

var Lit_129 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000610__31000614$fn__31000615")

var Lit_130 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000610__31000614$fn__31000615$fn__31000616")

var Lit_131 *jrt.String = jrt.Intern("v__")

var Lit_132 *jrt.String = jrt.Intern("Value")

var Lit_133 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000632__31000636$fn__31000637")

var Lit_134 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000632__31000636$fn__31000637$fn__31000638")

var Lit_135 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000648__31000652$fn__31000653")

var Lit_136 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000648__31000652$fn__31000653$fn__31000654")

var Lit_137 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000648__31000652$fn__31000653$fn__31000660")

var Lit_138 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000648__31000652$fn__31000653$fn__31000662")

var Lit_139 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000648__31000652$fn__31000653$fn__31000654$fn__31000655")

var Lit_140 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000648__31000652$fn__31000653$fn__31000654$fn__31000657")

var Lit_141 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000666__31000670$fn__31000671")

var Lit_142 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000666__31000670$fn__31000671$fn__31000672")

var Lit_143 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ps__31000606$fn__31000607")

var Lit_144 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$fn__31000679")

var Lit_145 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000681__31000685")

var Lit_146 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000691__31000695")

var Lit_147 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000701__31000705")

var Lit_148 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$fn__31000711")

var Lit_149 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719")

var Lit_150 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000767__31000771")

var Lit_151 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000785__31000789")

var Lit_152 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000795__31000799")

var Lit_153 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000805__31000809")

var Lit_154 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000815__31000819")

var Lit_155 *jrt.String = jrt.Intern("__")

var Lit_156 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000681__31000685$fn__31000686")

var Lit_157 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000681__31000685$fn__31000686$fn__31000687")

var Lit_158 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000691__31000695$fn__31000696")

var Lit_159 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000691__31000695$fn__31000696$fn__31000697")

var Lit_160 *jrt.String = jrt.Intern("c__")

var Lit_161 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000701__31000705$fn__31000706")

var Lit_162 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000701__31000705$fn__31000706$fn__31000707")

var Lit_163 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719$fn__31000720")

var Lit_164 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719$fn__31000720$iter__31000715__31000721")

var Lit_165 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719$fn__31000720$fn__31000727")

var Lit_166 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719$fn__31000720$fn__31000733")

var Lit_167 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719$fn__31000720$fn__31000741")

var Lit_168 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719$fn__31000720$iter__31000743__31000747")

var Lit_169 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719$fn__31000720$fn__31000759")

var Lit_170 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719$fn__31000720$fn__31000761")

var Lit_171 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719$fn__31000720$fn__31000763")

var Lit_172 *jrt.String = jrt.Intern("_l")

var Lit_173 *jrt.String = jrt.Intern("_b")

var Lit_174 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719$fn__31000720$iter__31000715__31000721$fn__31000722")

var Lit_175 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719$fn__31000720$iter__31000715__31000721$fn__31000722$fn__31000723")

var Lit_176 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719$fn__31000720$iter__31000743__31000747$fn__31000748")

var Lit_177 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000713__31000719$fn__31000720$iter__31000743__31000747$fn__31000748$fn__31000749")

var Lit_178 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000767__31000771$fn__31000772")

var Lit_179 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000767__31000771$fn__31000772$fn__31000773")

var Lit_180 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000767__31000771$fn__31000772$fn__31000779")

var Lit_181 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000767__31000771$fn__31000772$fn__31000781")

var Lit_182 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000767__31000771$fn__31000772$fn__31000773$fn__31000774")

var Lit_183 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000767__31000771$fn__31000772$fn__31000773$fn__31000776")

var Lit_184 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000785__31000789$fn__31000790")

var Lit_185 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000785__31000789$fn__31000790$fn__31000791")

var Lit_186 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000795__31000799$fn__31000800")

var Lit_187 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000795__31000799$fn__31000800$fn__31000801")

var Lit_188 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTR")

var Lit_189 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTF")

var Lit_190 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000805__31000809$fn__31000810")

var Lit_191 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000805__31000809$fn__31000810$fn__31000811")

var Lit_192 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000815__31000819$fn__31000820")

var Lit_193 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000815__31000819$fn__31000820$fn__31000821")

var Lit_194 *jrt.String = jrt.Intern("target-")

var Lit_195 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke$fn__31000528")

var Lit_196 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_let$fn__31000374")

var Lit_197 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000395")

var Lit_198 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000397")

var Lit_199 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000399__31000403")

var Lit_200 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000409__31000415")

var Lit_201 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000428")

var Lit_202 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000430")

var Lit_203 *jrt.String = jrt.Intern("body-")

var Lit_204 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000399__31000403$fn__31000404")

var Lit_205 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000399__31000403$fn__31000404$fn__31000405")

var Lit_206 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000409__31000415$fn__31000416")

var Lit_207 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000409__31000415$fn__31000416$iter__31000411__31000420")

var Lit_208 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000409__31000415$fn__31000416$iter__31000411__31000420$fn__31000421")

var Lit_209 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000409__31000415$fn__31000416$iter__31000411__31000420$fn__31000421$fn__31000422")

var Lit_210 *jrt.String = jrt.Intern("root-")

var Lit_211 *jrt.String = jrt.Intern("linked-")

var Lit_212 *jrt.String = jrt.Intern("ifn-")

var Lit_213 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000257")

var Lit_214 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000259")

var Lit_215 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000261")

var Lit_216 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000263")

var Lit_217 *jrt.String = jrt.Intern("arg-")

var Lit_218 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_list_array$fn__31000036")

var Lit_219 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_recur$fn__31000377")

var Lit_220 *jrt.String = jrt.Intern("recur arg for primitive local: ")

var Lit_221 *jrt.String = jrt.Intern(" is not matching primitive")

var Lit_222 *jrt.String = jrt.Intern("__init")

var Lit_223 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$unit_methods__31000903")

var Lit_224 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000910")

var Lit_225 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000922__31000926")

var Lit_226 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000938__31000942")

var Lit_227 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000952__31000956")

var Lit_228 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000910$iter__31000911__31000915")

var Lit_229 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000910$iter__31000911__31000915$fn__31000916")

var Lit_230 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000910$iter__31000911__31000915$fn__31000916$fn__31000917")

var Lit_231 *jrt.String = jrt.Intern("unit")

var Lit_232 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000922__31000926$fn__31000927")

var Lit_233 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000922__31000926$fn__31000927$fn__31000928")

var Lit_234 *jrt.String = jrt.Intern("$part")

var Lit_235 *jrt.String = jrt.Intern("")

var Lit_236 *jrt.String = jrt.Intern("part")

var Lit_237 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000938__31000942$fn__31000943")

var Lit_238 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000938__31000942$fn__31000943$fn__31000944")

var Lit_239 *jrt.String = jrt.Intern("init")

var Lit_240 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000952__31000956$fn__31000957")

var Lit_241 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000952__31000956$fn__31000957$fn__31000958")

var Lit_242 *jrt.String = jrt.Intern("load")

var Lit_243 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$unit_methods__31000903$fn__31000904")

var Lit_244 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_call$fn__31000511")

var Lit_245 *jrt.String = jrt.Intern("getReturnType")

var Lit_246 *jrt.String = jrt.Intern("getParameterTypes")

var Lit_247 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$body__31000433")

var Lit_248 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000435__31000439")

var Lit_249 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000435__31000439$fn__31000440")

var Lit_250 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000435__31000439$fn__31000440$fn__31000441")

var Lit_251 *jrt.String = jrt.Intern("unboxed emit of ")

var Lit_252 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_unboxed$fn__31000543")

var Lit_253 *jrt.String = jrt.Intern("no unboxed back end for ")

var Lit_254 *jrt.String = jrt.Intern("TYPE")

var Lit_255 *jrt.String = jrt.Intern("a record as a constant: ")

var Lit_256 *jrt.String = jrt.Intern("a deftype as a constant: ")

var Lit_257 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value$fn__31000045")

var Lit_258 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value$fn__31000047")

var Lit_259 *jrt.String = jrt.Intern("#<")

var Lit_260 *jrt.String = jrt.Intern("can't embed unreadable object in code: ")

var Lit_261 *jrt.String = jrt.Intern("arbace.lang.Compiler$AST")

var Lit_262 *jrt.String = jrt.Intern("arbace.lang.Var")

var Lit_263 *jrt.String = jrt.Intern("arbace.lang.Keyword")

var Lit_264 *jrt.String = jrt.Intern("arbace.lang.Symbol")

var Lit_265 *jrt.String = jrt.Intern("arbace.lang.IObj")

var Lit_266 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_267 *jrt.String = jrt.Intern("arbace.lang.IPersistentVector")

var Lit_268 *jrt.String = jrt.Intern("arbace.lang.IPersistentSet")

var Lit_269 *jrt.String = jrt.Intern("arbace.lang.IPersistentList")

var Lit_270 *jrt.String = jrt.Intern("arbace.lang.ISeq")

var Lit_271 *jrt.String = jrt.Intern("arbace.lang.IType")

var Lit_272 *jrt.String = jrt.Intern("arbace.lang.IRecord")

var Lit_273 *jrt.String = jrt.Intern("arbace.lang.PersistentHashSet")

var Lit_274 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_275 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_276 *jrt.String = jrt.Intern("java.util.regex.Pattern")

var Lit_277 *jrt.String = jrt.Intern("aot: ")

var Lit_278 *jrt.String = jrt.Intern("fiMethod")

var Lit_279 *jrt.String = jrt.Intern("/go/arbace/jrt")

var Lit_280 *jrt.String = jrt.Intern("ARBACE_AOT_ROOT")

var Lit_281 *jrt.String = jrt.Intern("fn-class")

var Lit_282 *jrt.String = jrt.Intern("fncls__")

var Lit_283 *jrt.String = jrt.Intern("d")

var Lit_284 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$fn__31001005")

var Lit_285 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31001007__31001011")

var Lit_286 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31001007__31001011$fn__31001012")

var Lit_287 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31001007__31001011$fn__31001012$fn__31001013")

var Lit_288 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31001007__31001011$fn__31001012$fn__31001023")

var Lit_289 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31001007__31001011$fn__31001012$fn__31001013$fn__31001017")

var Lit_290 *jrt.String = jrt.Intern("p")

var Lit_291 *jrt.String = jrt.Intern("arbace.c2j.emit$intrinsic_probe$fn__31000305")

var Lit_292 *jrt.String = jrt.Intern("arbace.c2j.emit$invoke_linked$fn__31000277")

var Lit_293 *jrt.String = jrt.Intern("(")

var Lit_294 *jrt.String = jrt.Intern(")")

var Lit_295 *jrt.String = jrt.Intern("arbace.c2j.emit$jrt_lacks_QMARK_$fn__31000284")

var Lit_296 *jrt.String = jrt.Intern("_")

var Lit_297 *jrt.String = jrt.Intern("unknown empty collection")

var Lit_298 *jrt.String = jrt.Intern("linked")

var Lit_299 *jrt.String = jrt.Intern("arbace.c2j.emit$link_form$fn__31000270")

var Lit_300 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op1$guard__31000298")

var Lit_301 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op2$checked__31000292")

var Lit_302 *jrt.String = jrt.Intern("and")

var Lit_303 *jrt.String = jrt.Intern("xor")

var Lit_304 *jrt.String = jrt.Intern("or")

var Lit_305 *jrt.String = jrt.Intern("remainder")

var Lit_306 *jrt.String = jrt.Intern("shiftLeft")

var Lit_307 *jrt.String = jrt.Intern("quotient")

var Lit_308 *jrt.String = jrt.Intern("shiftRight")

var Lit_309 *jrt.String = jrt.Intern("fn-method")

var Lit_310 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000557__31000561")

var Lit_311 *jrt.String = jrt.Intern("a worker's body recurs to its parameters: ")

var Lit_312 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$fn__31000567")

var Lit_313 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$fn__31000569")

var Lit_314 *jrt.String = jrt.Intern("p-")

var Lit_315 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000557__31000561$fn__31000562")

var Lit_316 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000557__31000561$fn__31000562$fn__31000563")

var Lit_317 *jrt.String = jrt.Intern("a call of a method of a class made at run time: ")

var Lit_318 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000310")

var Lit_319 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000312")

var Lit_320 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000314")

var Lit_321 *jrt.String = jrt.Intern("arbace.lang.Numbers")

var Lit_322 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$lv__31000316")

var Lit_323 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$dv__31000318")

var Lit_324 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000321")

var Lit_325 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$is__31000326")

var Lit_326 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000330")

var Lit_327 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000332")

var Lit_328 *jrt.String = jrt.Intern("nr-")

var Lit_329 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000334")

var Lit_330 *jrt.String = jrt.Intern("na-")

var Lit_331 *jrt.String = jrt.Intern("n")

var Lit_332 *jrt.String = jrt.Intern("-")

var Lit_333 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$is__31000326$fn__31000327")

var Lit_334 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000338")

var Lit_335 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000342")

var Lit_336 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000344")

var Lit_337 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000338$fn__31000339")

var Lit_338 *jrt.String = jrt.Intern("arbace.c2j.emit$obj_array$fn__31000152")

var Lit_339 *jrt.String = jrt.Intern("arbace.c2j.emit$pool$fn__31000031")

var Lit_340 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$num__31000055")

var Lit_341 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$arr__31000057")

var Lit_342 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$fn__31000064")

var Lit_343 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000068")

var Lit_344 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$walk__31000070")

var Lit_345 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000076")

var Lit_346 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000084")

var Lit_347 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000090")

var Lit_348 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000096")

var Lit_349 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000105")

var Lit_350 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000110__31000114")

var Lit_351 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000110__31000114$fn__31000115")

var Lit_352 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000110__31000114$fn__31000115$fn__31000116")

var Lit_353 *jrt.String = jrt.Intern("arbace.c2j.emit$prim_arg$conv__31000251")

var Lit_354 *jrt.String = jrt.Intern("arbace.c2j.emit$psig$fn__31000165")

var Lit_355 *jrt.String = jrt.Intern("arbace.c2j.emit$psig$fn__31000167")

var Lit_356 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000021")

var Lit_357 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000023")

var Lit_358 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000023$fn__31000024")

var Lit_359 *jrt.String = jrt.Intern("cut")

var Lit_360 *jrt.String = jrt.Intern("mismatched primitive return, expected ")

var Lit_361 *jrt.String = jrt.Intern(", had ")

var Lit_362 *jrt.String = jrt.Intern("arbace.c2j.emit$ret_body$num__31000550")

var Lit_363 *jrt.String = jrt.Intern("arbace.lang.IProxy")

var Lit_364 *jrt.String = jrt.Intern("arbace.c2j.emit$site_fn_methods$fn__31000244")

var Lit_365 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000349")

var Lit_366 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000351")

var Lit_367 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000353")

var Lit_368 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000355")

var Lit_369 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000357")

var Lit_370 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000359")

var Lit_371 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$param_QMARK___31000193")

var Lit_372 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$fn__31000197")

var Lit_373 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$fn__31000232")

var Lit_374 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$fn__31000197$fn__31000229")

var Lit_375 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$param_QMARK___31000193$fn__31000194")

var Lit_376 *jrt.String = jrt.Intern("arbace.c2j.emit$typed_args$fn__31000145")

var Lit_377 *jrt.String = jrt.Intern("arbace.c2j.emit$typed_args$fn__31000145$fn__31000146")

var Lit_378 *jrt.String = jrt.Intern("uncheckedIntCast")

var Lit_379 *jrt.String = jrt.Intern("intCast")

var Lit_380 *jrt.String = jrt.Intern("uncheckedFloatCast")

var Lit_381 *jrt.String = jrt.Intern("floatCast")

var Lit_382 *jrt.String = jrt.Intern("uncheckedDoubleCast")

var Lit_383 *jrt.String = jrt.Intern("doubleCast")

var Lit_384 *jrt.String = jrt.Intern("uncheckedLongCast")

var Lit_385 *jrt.String = jrt.Intern("longCast")

var Lit_386 *jrt.String = jrt.Intern("uncheckedByteCast")

var Lit_387 *jrt.String = jrt.Intern("byteCast")

var Lit_388 *jrt.String = jrt.Intern("uncheckedShortCast")

var Lit_389 *jrt.String = jrt.Intern("shortCast")

var Lit_390 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_391 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000832__31000836")

var Lit_392 *jrt.String = jrt.Intern("a top-level fn closing over locals")

var Lit_393 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000864__31000868")

var Lit_394 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$fn__31000894")

var Lit_395 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000832__31000836$fn__31000837")

var Lit_396 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000832__31000836$fn__31000837$fn__31000838")

var Lit_397 *jrt.String = jrt.Intern("type")

var Lit_398 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000832__31000836$fn__31000837$fn__31000852")

var Lit_399 *jrt.String = jrt.Intern("an event of a class made at run time: ")

var Lit_400 *jrt.String = jrt.Intern("iface")

var Lit_401 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000832__31000836$fn__31000837$fn__31000854")

var Lit_402 *jrt.String = jrt.Intern("proxy")

var Lit_403 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000832__31000836$fn__31000837$fn__31000856")

var Lit_404 *jrt.String = jrt.Intern("imethod")

var Lit_405 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000832__31000836$fn__31000837$fn__31000858")

var Lit_406 *jrt.String = jrt.Intern("stub")

var Lit_407 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000832__31000836$fn__31000837$fn__31000860")

var Lit_408 *jrt.String = jrt.Intern("ns")

var Lit_409 *jrt.String = jrt.Intern("an event of kind ")

var Lit_410 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000832__31000836$fn__31000837$fn__31000838$fn__31000840")

var Lit_411 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000832__31000836$fn__31000837$fn__31000838$fn__31000842")

var Lit_412 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000832__31000836$fn__31000837$fn__31000838$fn__31000844")

var Lit_413 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000832__31000836$fn__31000837$fn__31000838$fn__31000846")

var Lit_414 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000832__31000836$fn__31000837$fn__31000838$fn__31000848")

var Lit_415 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000864__31000868$fn__31000869")

var Lit_416 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000864__31000868$fn__31000869$fn__31000870")

var Lit_417 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000864__31000868$fn__31000869$iter__31000882__31000886")

var Lit_418 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000864__31000868$fn__31000869$fn__31000870$iter__31000871__31000875")

var Lit_419 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000864__31000868$fn__31000869$fn__31000870$iter__31000871__31000875$fn__31000876")

var Lit_420 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000864__31000868$fn__31000869$fn__31000870$iter__31000871__31000875$fn__31000876$fn__31000877")

var Lit_421 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000864__31000868$fn__31000869$iter__31000882__31000886$fn__31000887")

var Lit_422 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000864__31000868$fn__31000869$iter__31000882__31000886$fn__31000887$fn__31000888")

var Lit_423 *jrt.String = jrt.Intern("arbace.c2j.emit$var_fns$fn__31000239")

var Lit_424 *jrt.String = jrt.Intern("arbace.c2j.emit$var_fns$fn__31000241")

var Lit_425 *jrt.String = jrt.Intern("arbace.c2j.emit$walk_nodes$w__31000170")

var Lit_426 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,xyn3,msgyn1,&yn4,datakn3,tagyn6,Stringyn5,Classyn4,voidyn6,doubleyn4,charyn4,byteyn7,booleanyn5,floatyn4,longyn5,shortyn3,intyn1,syn1,cyn3,ctxyn3,topyn1,vyn5,ctypekn8,declaredyn2,xsyn9,Characterkn4,longkn6,doublekn3,intkn6,symbolkn6,stringkn6,vectorkn4,listkn3,varkn7,keywordkn5,classkn3,nilkn3,setkn7,booleankn3,mapkn4,charkn7,patternyn13,StringBuilderyn6,sharedyn6,constskn7,dynamicyn4,baseyn1,byn2,lbyn1,eyn1,nyn1,fyn2,psyn2,esyn3,Varyn2,mnyn2,usyn5,nargsyn1,tyn1,kyn5,fnodeyn4,argsyn3,keyyn3,outyn4,convyn1,myn5,cnameyn8,variadicyn5,primsyn5,specsyn7,classesyn15,IdentityHashMapyn1,_yn24,java.lang.reflect.Methodyn8,unboxed?ys14,java.lang.Long9,MIN_VALUEys14,java.lang.Long9,MAX_VALUEyn2,opyn1,yyn4,slowyn1,ryn8,specs-fnyn2,gsyn8,targs-fnv11,arbace.core5,in-nsMyn15,arbace.c2j.emitm2,R0,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).m2,R0,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).R1,v15,arbace.c2j.emit10,node-cachem10,R2,TR3,i36,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s58,The nodes' maps by node (the back end runs on one thread).v15,arbace.c2j.emit4,nodem10,R6,L1,V1,R7,R0,s62,The analyzed node x as a map (Compiler$AST/node), nil for nil.R3,i40,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,failm10,R2,TR6,L1,V3,R8,R9,V1,R10,R3,i49,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,destubm10,R6,L1,V1,Myn1,nm2,R11,R12,R0,s74,A class name without the compile stub's prefix (Compiler.destubClassName).R3,i55,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,type-symm10,R6,L1,V1,Myn1,cm2,R11,R13,R0,s93,The Java forms type of class c: a primitive's name, a class's binary name, an array as\n  T/n.R3,i60,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,prim-namesR14,R15,R16,R17,R18,R19,R20,R21,R22,m8,R2,TR3,i71,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,taggedm12,R2,TR6,L1,V2,R23,R24,R0,s44,Symbol s with the Java forms tag of class c.R3,i75,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,registeredv11,arbace.core4,atomm10,R2,TR3,i84,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s84,Whether a class name is registered in the program (Class/forName finds it), by name.v15,arbace.c2j.emit11,registered?m10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i88,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,runtime-class?m12,R2,TR6,L1,V2,Myn1,cm2,R11,R13,R25,R0,s291,Is class c made at run time (a Dyn class: an evaluated fn's, deftype's, interface's, proxy's)\n  rather than a class of the program, or one the program does not register by name (java.sql's,\n  whose members reflection reached from a world class)? Such a class is not named in compiled\n  code.R3,i105,R4,i1,R5,s18,arbace/c2j/emit.aev11,arbace.core12,define-proxyv15,arbace.c2j.emit7,public?m10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i120,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,top-namem10,R2,TR6,L1,V1,Myn1,nm2,R11,R12,R3,i126,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,poolm12,R2,TR6,L1,V2,R25,R26,R0,s178,The constants of top-level class top (a namespace's holder, a deftype, a loader), which its\n  member classes share (SA145): an atom {:name :consts :const-map}, made on first use.R3,i128,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,const-fieldm12,R2,TR6,L1,V3,R25,R27,R28,R0,s236,The static field holding constant value v in the class being emitted, made on first use (as\n  the JVM's const__N, one per distinct object): its symbol, const-N (a munged local's name has\n  no -, so no local, name__index, can shadow it).R3,i138,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-valuem8,R29,TR3,i159,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,emit-list-arraym10,R2,TR6,L1,V2,R25,R30,R3,i161,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,char-formm10,R2,TR6,L1,V1,Myn1,cm2,R11,R31,R3,i164,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,double-formm10,R2,TR6,L1,V1,Myn1,dm2,R11,R15,R3,i170,R4,i1,R5,s18,arbace/c2j/emit.aem10,R6,L1,V2,R25,R27,R0,s72,Code making constant value v (ObjExpr.emitValue), its metadata included.R3,i175,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,pool-kindm12,R2,TR6,L1,V1,R27,R0,s58,The tag of constant v, in the order of emit-value's cases.R3,i251,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,pool-partialS16,R32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,m10,R2,TR3,i276,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s61,The kinds whose metadata is made too (emit-value's partial?).v15,arbace.c2j.emit12,pool-shared?m12,R2,TR6,L1,V1,R27,R0,s84,Is v made once in a pool and named where used: a keyword, a symbol without metadata.R3,i280,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,pool-partsm12,R2,TR6,L1,V1,R27,R0,s62,The values constant v is made of (its elements, its metadata).R3,i285,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,pool-strm10,R2,TR6,L1,V2,Myn2,sbm2,R11,R48,Myn1,sm2,R11,R12,R3,i296,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,pool-encodem12,R2,TR6,L1,V3,Myn2,sbm2,R11,R48,R49,R27,R0,s102,Appends the encoding of v to sb (Compiler$AOT/poolValue's format); shared: shared value →\n  its index.R3,i299,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,pool-fieldsm12,R2,TR6,L1,V1,R50,R0,s264,The static fields of constants consts ([sym type value alias] ...): the pool's array, decoded\n  once (Compiler$AOT/pool), then each constant's field, its element, or for one with an alias\n  (a split loader's constant an earlier part made, SA210) that part's field.R3,i347,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,const-typem10,R2,TR6,L1,V1,R27,R3,i380,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,*late-classes*m10,R51,TR3,i386,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s398,The names of the classes the Java forms compiler made while the program prepared (its\n  deftypes, fns and defclasses using the Java forms, arbace.c2j.main's java-forms-classes): in the\n  tree, but j2g may leave one out (Clojure in its body it cannot analyze, F2.4), so a constant\n  naming one is looked up where used, as a class made at run time, and the classes holding it\n  initialize without it.v15,arbace.c2j.emit8,constantm10,R2,TR6,L1,V2,R25,R27,R3,i394,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,gsymm12,R2,TR6,L1,V2,R25,R52,R0,s146,A fresh name for a temporary of the emitted code, numbered per class being emitted (the\n  output does not depend on the program's gensym counter).R3,i407,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,local-symm12,R2,TR6,L1,V1,R53,R0,s95,The Java forms local of LocalBinding lb (its node b): its name and index, unique in a\n  method.R3,i415,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,identity-setm12,R2,TR6,L1,V1,R30,R0,s259,The objects of xs as a set by identity. A fn's closes map cannot be asked containsKey: its\n  keys, LocalBindings, hash by their index (Arbace's deterministic hashCode), and FnExpr.parse\n  renumbers a direct fn's arguments after its inner fns closed over them.R3,i421,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,closed?m10,R2,TR6,L1,V2,R25,R54,R3,i430,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,field-symm10,R2,TR6,L1,V1,R53,R3,i434,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,field-readm10,R2,TR6,L1,V3,R25,R54,R53,R3,i436,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,emitm8,R29,TR3,i442,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,emit-unboxedm8,R29,TR3,i442,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,emit-fn-class!m8,R29,TR3,i442,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,emit-deftype-class!m8,R29,TR3,i442,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,emit-bodym8,R29,TR3,i442,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,jrt-lacks?m8,R29,TR3,i442,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,prim-callm8,R29,TR3,i442,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,spec-intrinsicm8,R29,TR3,i442,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-localm8,R29,TR3,i442,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,primm10,R2,TR6,L1,V1,R55,R3,i445,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,can-prim?m10,R2,TR6,L1,V1,R56,R3,i447,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,box-ofm8,R29,TR3,i449,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit3,boxm12,R2,TR6,L1,V2,R57,Myn1,cm2,R11,R13,R0,s113,Form f of type c as a boxed value (emitBoxReturn: valueOf, long's Numbers.num being\n  Long.valueOf; void as nil).R3,i451,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,unbox-argm12,R2,TR6,L1,V3,R25,R57,Myn1,pm2,R11,R13,R0,s67,Boxed form f converted to parameter type p (HostExpr.emitUnboxArg).R3,i460,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit3,fi?m12,R2,TR6,L1,V1,Myn1,pm2,R11,R13,R0,s136,Is p a functional interface a fn argument is adapted to (Clojure 1.12's FISupport, as the\n  analysis decides it: Compiler$AST/fiMethod)?R3,i479,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,typed-argsm12,R2,TR6,L1,V3,R25,R58,R59,R0,s70,The arguments es as parameters of types ps (MethodExpr.emitTypedArgs).R3,i486,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,param-tagsm10,R2,TR6,L1,V1,R58,R3,i513,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,obj-arraym10,R2,TR6,L1,V2,R25,R59,R3,i515,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,var-valuem10,R2,TR6,L1,V2,R25,Myn1,vm2,R11,R60,R3,i518,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,line-metam10,R2,TR6,L1,V2,R57,R56,R3,i522,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,spec-localm12,R2,TR6,L1,V2,R25,R54,R0,s75,The worker's long and box of parameter lb (F6, spec-mask: {:l :b}), or nil.R3,i527,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,long-box*m10,R2,TR6,L1,V1,R57,R3,i533,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,local-placem12,R2,TR6,L1,V2,R25,R56,R0,s238,Where the local of node n lives in the emitted code (the local node kind's place): {:form\n  its read and the target of its write, :clears true when its use clears it (a ^:once fn's\n  closed-over value read for the last time on its path)}.R3,i535,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,*link*m10,R51,TR3,i555,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s209,While the call sites of vars may be linked, an atom of the sites' data in the order emitted\n  (arbace.c2j.main's compile-all binds it, and resolves the sites, link-form, once every class\n  is known); else nil.v15,arbace.c2j.emit8,link-keym12,R2,TR6,L1,V1,Myn1,vm2,R11,R60,R0,s355,The key of the compiled fn var v's root is at the end of the prepare run, for a call site\n  of v: the FnExpr of an evaluated fn (Compiler$EvalFn), or the class name of a compiled one\n  (Compiler$AOTFn, Compiler$AOTRestFn: the back end's own namespaces, compiled-back-end); nil\n  when v is dynamic, ^:dynamic, ^:redef or a macro, or its root is no such fn.R3,i561,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,deepm8,R29,TR3,i575,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,psigm12,R2,TR6,L1,V1,R61,R0,s156,The primitive signature of FnMethod mn (its node): {:params [Class...] :ret Class}, each\n  long, double or Object; nil when the method has no unboxed entry.R3,i584,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,intrinsic-probem8,R29,TR3,i594,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,long-valued-opsm8,R29,TR3,i594,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,walk-nodesm12,R2,TR6,L1,V2,R55,R57,R0,s117,Calls f on the node (map) of each Expr of the tree of e, not inside the methods of nested\n  fns, reifys and deftypes.R3,i596,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,spec-maskm12,R2,TR6,L1,V1,R61,R0,s631,Futamura F6, step 2: which parameters of FnMethod mn (its node) a speculative worker takes as\n  longs: those an operation of Numbers with fast paths takes as an Object operand (F3), when the\n  method also passes one of them, or such an operation of them, to a call of a var (where a\n  worker may take it unboxed: the worker's gain; a fn whose parameters only meet operations,\n  as arbace.core's +, would pay the dispatch for nothing); nil when there are none, or when the\n  method has an unboxed entry (psig), is variadic, has more than 4 parameters, or recurs to its\n  parameters (a recur would rebind them to values of any type).R3,i612,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,*var-fns*m10,R51,TR3,i656,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s441,The fn each var's last def in the recorded units defines (an IdentityHashMap Var → FnExpr,\n  var-fns; arbace.c2j.main's compile-all binds it): the code an F6 call site's linked call\n  expects, read from the analysis alone, so that the back end decides the same whether its own\n  namespaces and arbace.core run evaluated (their roots Compiler$EvalFns) or compiled\n  (Compiler$AOTFns, compiled-back-end: the fixpoint's G2); nil when not bound.v15,arbace.c2j.emit7,var-fnsm10,R6,L1,V1,R62,R0,s161,The index *var-fns* of units us (each the recorded [kind line column lb cb expr events]): by\n  each var, the FnExpr of its last top-level def whose init is a fn.R3,i664,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,site-fn-methodsm12,R2,TR6,L1,V2,Myn1,vm2,R11,R60,R63,R0,s89,The fixed-arity method of nargs parameters (its node) of the fn var v's last def defines.R3,i679,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,site-specm12,R2,TR6,L1,V2,R27,R63,R0,s82,The worker's mask (spec-mask) of the fixed arity nargs of the fn of var v, or nil.R3,i688,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,site-psigm12,R2,TR6,L1,V2,R27,R63,R0,s76,The primitive signature of the fixed arity nargs of the fn of var v, or nil.R3,i693,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,prim-argm12,R2,TR6,L1,V4,R25,R55,Myn1,pm2,R11,R13,R64,R0,s355,Argument e of a call of an unboxed entry, for its parameter of class p: {:binds (the\n  temporary of its value, evaluated once, in order), :gen (its boxed value, as the generic call\n  passes it), :pri (its value as the entry takes it: the boxed invoke's own conversion of the\n  boxed value, RT.longCast or doubleCast, unless the argument is of p already)}.R3,i698,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,spec-argm12,R2,TR6,L1,V4,R25,R55,R65,R64,R0,s413,Argument e of a call of a worker (F6, spec-mask), for its parameter taken as a long when k:\n  {:binds (its temporary, evaluated once, in order), :gen (its boxed value, for the generic\n  call), :pass (what the worker takes: the long and the box, or nil for a box the worker makes\n  when needed; the value for a parameter not taken as a long), :guard (the test that it is a\n  Long, nil when it is one by its type)}.R3,i731,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,emit-link-sitem12,R2,TR6,L2,V4,R25,R66,R67,R68,V6,R25,R66,R67,R68,R69,R70,R0,s440,A call of var fexpr (its node fnode) with args (at most 20), linked when its root's code is\n  known (link-key): a marker (c2j/link {...}) holding the emitted root, arguments and\n  temporaries, which link-form resolves into the guarded direct call or the generic one. With\n  out, the class a consumer converts the call's value to (long, double: the code's primitive\n  return), and conv, the consumer's conversion of the generic call's value.R3,i758,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,link-formm10,R6,L2,V3,R71,R72,R73,V5,R71,R72,R73,R74,R75,R0,s1435,The code of link marker m (emit-link-site): with cname, the code class of the fn the site\n  expects (its fixed arity of the call's argument count, variadic its required count or nil),\n  the guarded direct call; without, the generic call T1 makes. The guard: the root is a\n  compiled fn (Compiler$AOTFn, or Compiler$AOTRestFn for variadic code) whose class is the code\n  class's fn class (fn-class, one Class per code: Compiler$AOT/fnClass), one pointer compare\n  (Compiler$AOTFn/linked, which answers the fn's body or nil); then the code's invoke is called\n  directly with the fn as self, as the fn's invoke would call it. The root is read once, and\n  cast to IFn before the arguments when the guard fails, as the generic call casts it.\n\n  A call of a primitive fn's arity (:psig, F6) or of an arity with a worker (:smask, F6 step 2):\n  its arguments bound first, each once (unboxed when the entry takes it so and it is of that\n  type). For a primitive fn the direct call is of the code's unboxed entry, invokePrim (prims:\n  the code's signatures by arity), its value boxed as the boxed invoke boxes it, or left unboxed\n  for a consumer converting to the return's class (:out); for a worker it is of the code's\n  invokeSpec (specs: the code's masks by arity) when the arguments it takes as longs are Longs\n  (:guard), else of its invoke. The generic call is given the boxed arguments, its value\n  converted as the consumer converts it.R3,i795,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,link-targetm10,R6,L1,V3,R65,R76,Myn8,fn-namesm2,R11,R77,R0,s184,The class name and record of the code class link key k names (link-key), given the classes\n  made (name → record) and the fns' class names by FnExpr (fn-names); nil when none was made.R3,i854,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,site-keym12,R2,TR6,L1,V1,R56,R0,s79,The link key of invoke node n (link-key) when its call may be linked, else nil.R3,i862,R4,i1,R5,s18,arbace/c2j/emit.aem12,R2,TR6,L1,V4,R25,R55,Myn1,pm2,R11,R13,R70,R0,s233,The code of e, an invoke whose value a consumer converts to primitive class p by conv (a fn\n  of the boxed value's form), when it is a call of a primitive fn's arity returning p (F6):\n  its direct call's value left unboxed; else nil.R3,i870,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit13,invoke-linkedm12,R2,TR6,L1,V3,R25,R56,R78,R0,s264,The invoke node kind's refinements of the emitted code (its emit-first): a protocol fn's\n  call, the target's own method when it implements the protocol's interface, else the protocol\n  fn (InvokeExpr.emitProto); a linked call (F5, F6); else nil, the generic call.R3,i881,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,descriptorm10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i910,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,jrt-scanm8,R2,TR3,i918,R4,i1,R5,s18,arbace/c2j/emit.aem12,R2,TR6,L1,V1,Myn1,mm2,R11,R79,R0,s255,Is method m declared by a class jrt writes by hand (not a stand-in j2g's translation\n  replaces) without it in Go? j2g would translate a direct call to a throw; the member tables\n  (reflection) have such members, so compiled code calls them by reflection.R3,i921,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,method-callm12,R2,TR6,L1,V4,R25,Myn1,mm2,R11,R79,R64,R67,R0,s69,A call of resolved method m: static (target nil) or on target form t.R3,i940,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,compiled-interface?m12,R2,TR6,L1,V2,R25,Myn1,cm2,R11,R13,R0,s86,Is class c an interface of a namespace being compiled (gen-interface's, a protocol's)?R3,i953,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit20,emit-instance-methodm10,R2,TR6,L1,V3,R25,R56,R80,R3,i958,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-minR81,m8,R2,TR3,i1001,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-maxR82,m8,R2,TR3,i1002,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,*lbox*m12,R51,TR2,TR3,i1004,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s107,While set, how the Long case's result is given (spec-intrinsic: as the long itself), in\n  place of its box.v15,arbace.c2j.emit8,long-boxm10,R2,TR6,L1,V1,R57,R3,i1009,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-boxm10,R2,TR6,L1,V1,R57,R3,i1010,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-op2m12,R2,TR6,L1,V5,R83,R7,R84,R85,R86,R0,s202,The Long case of Numbers' binary operation op on longs x, y (symbols; r the result's local):\n  a form of the operation's result type, slow where Numbers would not answer a long; nil: not\n  an intrinsic.R3,i1012,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-op2m12,R2,TR6,L1,V3,R83,R7,R84,R0,s166,The Double case (both operands Double) of Numbers' binary operation op (DoubleOps: the '\n  operations are the others, a difference the sum with the negation), or nil.R3,i1047,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-op1m12,R2,TR6,L1,V3,R83,R7,R85,R0,s70,The Long case of Numbers' unary operation op on long x, as long-op2's.R3,i1062,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-op1m12,R2,TR6,L1,V2,R83,R7,R0,s64,The Double case of Numbers' unary operation op, as double-op2's.R3,i1078,R4,i1,R5,s18,arbace/c2j/emit.aem12,R2,TR6,L1,V1,Myn1,mm2,R11,R79,R0,s124,Is Numbers' static method m one of the boxed operations with fast paths? Its signature\n  ([:o :j ...]) when it is, else nil.R3,i1090,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,numbers-fastm10,R6,L1,V4,Myn1,mm2,R11,R79,R87,R88,R89,R0,s507,The call of Numbers' static method m with its fast paths, or nil when m is not one of the\n  boxed operations above: the builder both halves of the static call share (arbace.c2j.node's\n  static-call: the evaluator's CodeOpN too, test/c2j/gen_nodes.ae). (specs-fn sig): per operand,\n  the worker's long parameter it is (F6, spec-local: a Long, no test, its long as is, its box\n  for the slow path) or nil; (gs base): a fresh temporary; (targs-fn): the operands' forms,\n  asked after the temporaries are named.R3,i1104,R4,i1,R5,s18,arbace/c2j/emit.ae")

var Lit_427 *jrt.String = jrt.Intern("arbace.c2j.emit$eval31000004$loading__1927001464__auto____31000005")

var Lit_428 *jrt.String = jrt.Intern("arbace.c2j.emit$eval31000008$fn__31000009")

var Lit_429 *jrt.String = jrt.Intern("arbace.c2j.emit$node")

var Lit_430 *jrt.String = jrt.Intern("arbace.c2j.emit$fail")

var Lit_431 *jrt.String = jrt.Intern("arbace.c2j.emit$destub")

var Lit_432 *jrt.String = jrt.Intern("arbace.c2j.emit$type_sym")

var Lit_433 *jrt.String = jrt.Intern("arbace.c2j.emit$tagged")

var Lit_434 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_")

var Lit_435 *jrt.String = jrt.Intern("arbace.c2j.emit$runtime_class_QMARK_")

var Lit_436 *jrt.String = jrt.Intern("arbace.c2j.emit$public_QMARK_")

var Lit_437 *jrt.String = jrt.Intern("arbace.c2j.emit$top_name")

var Lit_438 *jrt.String = jrt.Intern("arbace.c2j.emit$pool")

var Lit_439 *jrt.String = jrt.Intern("arbace.c2j.emit$const_field")

var Lit_440 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_list_array")

var Lit_441 *jrt.String = jrt.Intern("arbace.c2j.emit$char_form")

var Lit_442 *jrt.String = jrt.Intern("arbace.c2j.emit$double_form")

var Lit_443 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value")

var Lit_444 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_kind")

var Lit_445 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_shared_QMARK_")

var Lit_446 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_parts")

var Lit_447 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_str")

var Lit_448 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode")

var Lit_449 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields")

var Lit_450 *jrt.String = jrt.Intern("arbace.c2j.emit$const_type")

var Lit_451 *jrt.String = jrt.Intern("arbace.c2j.emit$constant")

var Lit_452 *jrt.String = jrt.Intern("arbace.c2j.emit$gsym")

var Lit_453 *jrt.String = jrt.Intern("arbace.c2j.emit$local_sym")

var Lit_454 *jrt.String = jrt.Intern("arbace.c2j.emit$identity_set")

var Lit_455 *jrt.String = jrt.Intern("arbace.c2j.emit$closed_QMARK_")

var Lit_456 *jrt.String = jrt.Intern("arbace.c2j.emit$field_sym")

var Lit_457 *jrt.String = jrt.Intern("arbace.c2j.emit$field_read")

var Lit_458 *jrt.String = jrt.Intern("arbace.c2j.emit$prim")

var Lit_459 *jrt.String = jrt.Intern("arbace.c2j.emit$can_prim_QMARK_")

var Lit_460 *jrt.String = jrt.Intern("arbace.c2j.emit$box")

var Lit_461 *jrt.String = jrt.Intern("arbace.c2j.emit$unbox_arg")

var Lit_462 *jrt.String = jrt.Intern("arbace.c2j.emit$fi_QMARK_")

var Lit_463 *jrt.String = jrt.Intern("arbace.c2j.emit$typed_args")

var Lit_464 *jrt.String = jrt.Intern("arbace.c2j.emit$param_tags")

var Lit_465 *jrt.String = jrt.Intern("arbace.c2j.emit$obj_array")

var Lit_466 *jrt.String = jrt.Intern("arbace.c2j.emit$var_value")

var Lit_467 *jrt.String = jrt.Intern("arbace.c2j.emit$line_meta")

var Lit_468 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_local")

var Lit_469 *jrt.String = jrt.Intern("arbace.c2j.emit$long_box_STAR_")

var Lit_470 *jrt.String = jrt.Intern("arbace.c2j.emit$local_place")

var Lit_471 *jrt.String = jrt.Intern("arbace.c2j.emit$link_key")

var Lit_472 *jrt.String = jrt.Intern("arbace.c2j.emit$psig")

var Lit_473 *jrt.String = jrt.Intern("arbace.c2j.emit$walk_nodes")

var Lit_474 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask")

var Lit_475 *jrt.String = jrt.Intern("arbace.c2j.emit$var_fns")

var Lit_476 *jrt.String = jrt.Intern("arbace.c2j.emit$site_fn_methods")

var Lit_477 *jrt.String = jrt.Intern("arbace.c2j.emit$site_spec")

var Lit_478 *jrt.String = jrt.Intern("arbace.c2j.emit$site_psig")

var Lit_479 *jrt.String = jrt.Intern("arbace.c2j.emit$prim_arg")

var Lit_480 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_arg")

var Lit_481 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site")

var Lit_482 *jrt.String = jrt.Intern("arbace.c2j.emit$link_form")

var Lit_483 *jrt.String = jrt.Intern("arbace.c2j.emit$link_target")

var Lit_484 *jrt.String = jrt.Intern("arbace.c2j.emit$site_key")

var Lit_485 *jrt.String = jrt.Intern("arbace.c2j.emit$prim_call")

var Lit_486 *jrt.String = jrt.Intern("arbace.c2j.emit$invoke_linked")

var Lit_487 *jrt.String = jrt.Intern("arbace.c2j.emit$descriptor")

var Lit_488 *jrt.String = jrt.Intern("arbace.c2j.emit$fn__31000281")

var Lit_489 *jrt.String = jrt.Intern("arbace.c2j.emit$jrt_lacks_QMARK_")

var Lit_490 *jrt.String = jrt.Intern("arbace.c2j.emit$method_call")

var Lit_491 *jrt.String = jrt.Intern("arbace.c2j.emit$compiled_interface_QMARK_")

var Lit_492 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_instance_method")

var Lit_493 *jrt.String = jrt.Intern("arbace.c2j.emit$long_box")

var Lit_494 *jrt.String = jrt.Intern("arbace.c2j.emit$double_box")

var Lit_495 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op2")

var Lit_496 *jrt.String = jrt.Intern("arbace.c2j.emit$double_op2")

var Lit_497 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op1")

var Lit_498 *jrt.String = jrt.Intern("arbace.c2j.emit$double_op1")

var Lit_499 *jrt.String = jrt.Intern("arbace.c2j.emit$intrinsic_probe")

var Lit_500 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast")

var Lit_501 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn3,ctxkn3,tagyn24,java.lang.reflect.Methodyn4,argsyn2,askn3,dockn4,linekn6,columnkn4,fileyn2,xsyn1,eyn1,tyn1,nyn8,unboxed?yn23,java.lang.reflect.Fieldyn4,top?yn3,symyn2,esyn2,lbyn4,inityn2,oxyn10,nil-localsyn4,bodyyn1,vkn4,kindyn5,constkn4,optskn5,exprsyn10,NumberExpryn12,ConstantExpryn10,StringExpryn11,KeywordExpryn7,NilExpryn11,BooleanExpryn9,EmptyExpryn10,TheVarExprkn5,chanskn1,okn1,jkn1,dkn5,bindskn3,symkn1,kyn6,statickn4,argsyn6,Objectys24,arbace.lang.Compiler$AST7,literalyn3,numyn7,booleanyn9,instance?yn6,Numberyn2,lvyn4,longyn2,ifyn10,.longValueyn4,castyn2,dvyn6,doubleyn12,.doubleValuekn8,templateyn11,static-caseyn2,chyn9,static-ifyn5,localkn6,fieldsyn1,byn11,shouldClearyn2,atyn5,placeyn7,clears?yn3,letyn9,get-placeyn9,set-placeyn6,IfExpryn4,testyn5,childyn8,testExpryn3,thnyn8,thenExpryn3,elsyn8,elseExpryn1,zyn10,identical?ys24,arbace.lang.Compiler$AST8,primTypeys7,Boolean4,TYPEyn3,runkn1,zyn11,static-callyn16,StaticMethodExpryn6,methodyn4,linekn5,classkn6,domainkn5,indexyn4,nil?ys16,Compiler$CodeRun2,opyn1,myn8,childrenkn7,convertyn18,.getParameterTypesyn3,intyn9,call-siteyn8,run-argsyn6,box-asyn11,call-staticyn6,invokeyn10,InvokeExpryn5,fexpryn12,tailPositionkn10,emit-firstyn13,invoke-linkedyn2,fxyn5,clearyn11,eval-staticyn3,andyn3,notyn13,.-canBeDirectyn6,.-objxyn2,ccyn1,gyn15,arbace.lang.IFnyn7,run-allyn9,eval-onlyyn4,whenys16,Compiler$CodeRun9,clearThisyn1,fyn5,many?yn8,.applyTokn10,param-tagsys16,java.lang.Object1,1yn8,array-ofyn7,.invokeyn6,spliceys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys17,java.lang.Integer7,valueOfys17,java.lang.Boolean7,valueOfys19,java.lang.Character7,valueOfys15,java.lang.Float7,valueOfys15,java.lang.Short7,valueOfys14,java.lang.Byte7,valueOfyn6,Stringyn5,Classyn2,mnyn6,paramsyn1,&yn5,entryyn4,charyn5,floatyn5,shortyn4,byteyn3,tagyn1,kyn4,kindyn6,columnyn1,_yn4,expryn6,eventsyn7,classesyn15,runtime-classesyn8,fn-namesyn5,poolsyn3,srcyn5,unitsyn1,cyn11,children-ofyn4,nameyn7,extendsyn7,methodsv15,arbace.c2j.emit17,numbers-intrinsicm12,R0,TR1,L1,V4,R2,Myn1,mm2,R3,R4,R5,R6,R7,s215,The call of Numbers' static method m on args (as: a delay of their forms, typed-args's) with\n  its fast paths, or nil (numbers-fast). An Object operand that is a worker's long parameter\n  (F6, spec-local) is a Long.R8,i1144,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit16,static-call-formm10,R1,L1,V2,Myn1,mm2,R3,R4,R5,R7,s58,The direct call of static method m on argument forms args.R8,i1157,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,call-staticm12,R0,TR1,L1,V4,R2,Myn1,mm2,R3,R4,R6,R11,R7,s182,The direct call of static method m on the arguments as (a delay of their forms, typed-args\n  of the children xs), with Numbers' fast paths (F3) when m is one of its boxed operations.R8,i1163,R9,i1,R10,s18,arbace/c2j/emit.aeS17,s4,decPs18,unchecked_multiplys8,multiplys8,quotients6,minusPs9,multiplyPs5,minuss13,unchecked_decs4,addPs4,incPs3,incs9,remainders13,unchecked_adds3,adds13,unchecked_incs3,decs15,unchecked_minusm8,R0,TR8,i1169,R9,i1,R10,s18,arbace/c2j/emit.aem12,R0,TR1,L1,V3,R2,R12,R13,R7,s487,Argument e of a worker's call for a parameter it takes as a long (F6, spec-arg), when e is an\n  operation of Numbers with fast paths whose Object operands are all the calling worker's long\n  parameters: its Long case computed as a long, not boxed (the worker boxes it if it needs to,\n  as the generic call's argument would have been boxed, once); its other case's value (Numbers'\n  own: an overflow promoted, a ratio) in temporary t, nil in the Long case. As spec-arg's\n  result, or nil.R8,i1174,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,direct-static?m12,R0,TR1,L1,V2,R2,R14,R7,s120,Does the emitted code call the method of static-method node n directly (the static-call\n  node kind), not by reflection?R8,i1207,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit18,emit-static-methodm12,R0,TR1,L1,V3,R2,R14,R15,R7,s85,A static method called by reflection (one direct-static? does not take: static-call).R8,i1215,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,field-ok?m10,R0,TR1,L1,V2,R2,Myn1,fm2,R3,R16,R8,i1225,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,emit-instance-fieldm10,R0,TR1,L1,V3,R2,R14,R15,R8,i1228,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,emit-static-fieldm10,R0,TR1,L1,V3,R2,R14,R15,R8,i1237,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-newm10,R0,TR1,L1,V2,R2,R14,R8,i1245,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-defm10,R0,TR1,L1,V3,R2,R14,R17,R8,i1254,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,emit-assignm10,R0,TR1,L1,V2,R2,R14,R8,i1272,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,coll-callm10,R0,TR1,L1,V3,R18,R19,R2,R8,i1294,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,emit-binding-initm12,R0,TR1,L1,V3,R2,R20,R21,R7,s69,A let or loop binding [sym init] of LocalBinding lb (LetExpr.doEmit).R8,i1297,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-letm10,R0,TR1,L1,V3,R2,R14,R15,R8,i1306,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-recurm10,R0,TR1,L1,V2,R2,R14,R8,i1313,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit13,body-instancem12,R0,TR1,L1,V3,R2,R22,R23,R7,s228,A new instance of fn or reify class ox (its node), its closed-over values from the current\n  method: (new C closed...) (ObjExpr.emit); letfn's own locals nil (set after). A fn's is its\n  code (SA141), which fn-wrap makes the fn.R8,i1334,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,fn-wrapm12,R0,TR1,L1,V3,R2,R22,R24,R7,s135,The fn of fn ox (its node) whose code is form body: a Compiler$AOTFn, or a\n  Compiler$AOTRestFn of the variadic arity's required count.R8,i1347,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,fn-instancem12,R0,TR1,L1,V3,R2,R22,R23,R7,s33,A new fn or reify (ox, its node).R8,i1370,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-letfnm10,R0,TR1,L1,V3,R2,R14,R15,R8,i1376,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-trym10,R0,TR1,L1,V3,R2,R14,R15,R8,i1393,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,emit-casem10,R0,TR1,L1,V3,R2,R14,R15,R8,i1402,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,liftm12,R0,TR1,L1,V3,R2,R25,R13,R7,s209,A defnode's static value v, of class t (a symbol), as the emitted code's: a primitive's\n  literal; nil, a string, a boolean, an empty collection as Java forms write them; else a\n  constant of the class's pool.R8,i1456,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,prim-chanm12,R0,TR1,L1,V1,R14,R7,s120,The channel of node n's unboxed value (its primitive type's): :j a long or int, :d a double,\n  :z a boolean, :p another.R8,i1477,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.node9,register!m10,R26,R27,R7,s127,A literal or a quoted constant (NumberExpr ... TheVarExpr): its value, made when the node is,\n  and a number's long and double.R28,m4,R29,V8,R30,R31,R32,R33,R34,R35,R36,R37,R38,V3,R39,R40,R41,R42,V4,m6,R43,R25,R44,R45,R46,V2,R47,ML2,R48,R12,m4,R8,i1489,R9,i21,m6,R43,R49,R44,R45,R46,V2,R50,ML3,R51,R52,R25,m4,R8,i1490,R9,i24,m6,R43,R53,R44,R45,R46,V2,R54,ML4,R55,R49,ML2,R56,ML3,R57,R52,R25,m4,R8,i1491,R9,i40,m4,R8,i1491,R9,i28,l0,m4,R8,i1491,R9,i20,m6,R43,R58,R44,R45,R46,V2,R59,ML4,R55,R49,ML2,R60,ML3,R57,R52,R25,m4,R8,i1492,R9,i44,m4,R8,i1492,R9,i30,d0,m4,R8,i1492,R9,i22,R61,ML8,R62,R63,R39,R25,R40,ML4,R64,R49,R53,ML2,R56,ML3,R57,R52,R25,m4,R8,i1495,R9,i38,m4,R8,i1495,R9,i26,m4,R8,i1495,R9,i8,R41,ML4,R64,R49,R58,ML2,R60,ML3,R57,R52,R25,m4,R8,i1496,R9,i40,m4,R8,i1496,R9,i26,m4,R8,i1496,R9,i8,m4,R8,i1493,R9,i3,v15,arbace.c2j.emit10,emit-constm8,R1,L1,V3,R2,R14,R15,R8,i1484,R9,i1,R10,s18,arbace/c2j/emit.aem10,R26,R65,R7,s318,A use of a local (LocalBindingExpr): its value where it lives; on its last use on its path,\n  where the half keeps it alive, cleared (locals clearing: ObjExpr.emitLocal, emitClearLocals).\n  Where it lives is each half's own (the evaluator's slots, prims and closed-over values, the\n  emitted code's locals and fields).R28,m4,R29,V0,R66,V2,R67,R68,R42,V1,m6,R43,R69,R44,R70,R46,V0,R61,ML4,R64,ML2,R71,R69,m4,R8,i1505,R9,i14,ML4,R72,V2,R13,ML3,R73,R69,R39,m4,R8,i1506,R9,i13,ML3,R74,R69,nm4,R8,i1506,R9,i32,R13,m4,R8,i1506,R9,i5,ML3,R73,R69,R63,m4,R8,i1507,R9,i5,m4,R8,i1505,R9,i3,m8,R1,L1,V3,R2,R14,R15,R8,i1498,R9,i1,R10,s18,arbace/c2j/emit.aem10,R26,R55,R7,s122,Clojure's if (IfExpr): the test's truth (a boolean's own when the test is one) chooses the\n  branch, in the channel asked.R28,m2,R29,V1,R75,R42,V4,m6,R43,R76,R44,R77,R46,V1,R78,m6,R43,R79,R44,R77,R46,V1,R80,m6,R43,R81,R44,R77,R46,V1,R82,m6,R43,R83,R44,R45,R46,V2,R50,ML3,R84,ML2,R85,R78,m4,R8,i1516,R9,i34,R86,m4,R8,i1516,R9,i22,R61,ML4,R55,ML4,R64,R83,ML3,R87,R88,R76,m4,R8,i1517,R9,i20,ML3,R87,R39,R76,m4,R8,i1517,R9,i34,m4,R8,i1517,R9,i7,ML3,R87,R63,R79,m4,R8,i1517,R9,i49,ML3,R87,R63,R81,m4,R8,i1517,R9,i62,m4,R8,i1517,R9,i3,v15,arbace.c2j.emit7,emit-ifm8,R1,L1,V3,R2,R14,R15,R8,i1509,R9,i1,R10,s18,arbace/c2j/emit.aem10,R26,R89,R7,s445,A call of a resolved static method the half calls directly (StaticMethodExpr): its\n  arguments converted to the parameters' classes and bound in order, then the call (Numbers'\n  boxed operations with F3's fast paths), its value in the channel asked (boxed as its\n  return's). The evaluator's: Numbers', RT's, Util's and Math's listed methods\n  (test/c2j/gen_nodes.ae), a switch per arity; the emitted code's: every public one\n  (direct-static?).R28,m8,R29,V1,R90,R66,V3,R91,R5,R92,R93,s6,CodeOpR94,m2,R95,ML4,R55,ML2,R96,R91,m4,R8,i1527,R9,i24,l-1,ML2,R97,R91,m4,R8,i1527,R9,i41,m4,R8,i1527,R9,i20,R42,V3,m6,R43,R98,R44,R45,R46,V2,R4,R91,m6,R43,R11,R44,R99,R46,V4,R5,l3,R100,ML2,R101,R91,m4,R8,i1529,R9,i33,m6,R43,R92,R44,R45,R46,V2,R102,R92,R61,ML4,R103,R92,V2,R6,ML3,R104,R98,R11,m4,R8,i1531,R9,i23,ML4,R105,R63,R98,ML3,R106,R98,R6,m4,R8,i1532,R9,i18,m4,R8,i1532,R9,i5,m4,R8,i1531,R9,i3,v15,arbace.c2j.emit16,emit-static-callm8,R1,L1,V3,R2,R14,R15,R8,i1519,R9,i1,R10,s18,arbace/c2j/emit.aem10,R26,R107,R7,s328,A call of a fn value (InvokeExpr): the fn, then its arguments, in order, then IFn's invoke\n  (applyTo past 20 arguments); in tail position the evaluator's frame lets go of its object\n  first (InvokeExpr.emitArgsAndCall, ObjMethod.emitClearThis). The emitted code's refinements:\n  protocol calls and linked calls (invoke-linked).R28,m8,R29,V1,R108,R66,V4,R109,R5,R92,R110,R38,V1,R39,R111,R112,R42,V4,m6,R43,R113,R44,R77,R46,V1,R109,m6,R43,R11,R44,R99,R46,V2,R5,l20,m6,R43,R92,R44,R45,R46,V2,R102,R92,m6,R43,R114,R44,R115,R46,V2,R50,ML3,R116,R110,ML2,R117,ML2,R118,ML2,R119,R120,m4,R8,i1543,R9,i69,m4,R8,i1543,R9,i54,m4,R8,i1543,R9,i49,m4,R8,i1543,R9,i31,R61,ML5,R103,R92,V4,R121,ML3,R57,R122,ML3,R87,R39,R113,m4,R8,i1544,R9,i44,m4,R8,i1544,R9,i22,R6,ML3,R123,R39,R11,m4,R8,i1544,R9,i60,ML2,R124,ML3,R125,R114,ML2,R126,R127,m4,R8,i1545,R9,i28,m4,R8,i1545,R9,i16,m4,R8,i1545,R9,i5,ML4,R64,ML2,R128,R11,m4,R8,i1546,R9,i16,ML3,R129,R121,ML2,Mys20,arbace.lang.ArraySeq6,createm2,R130,V1,R131,ML2,R132,R6,m4,R8,i1547,R9,i84,m4,R8,i1547,R9,i19,m4,R8,i1547,R9,i7,ML3,R133,R121,ML2,R134,R6,m4,R8,i1548,R9,i18,m4,R8,i1548,R9,i7,m4,R8,i1546,R9,i5,m4,R8,i1544,R9,i3,v15,arbace.c2j.emit11,emit-invokem8,R1,L1,V3,R2,R14,R15,R8,i1534,R9,i1,R10,s18,arbace/c2j/emit.aeR135,R136,R137,R138,R139,R140,R141,R142,m8,R0,TR8,i1550,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,box-primm12,R0,TR1,L1,V2,R127,R14,R7,s200,Form f of node n boxed when it is of a primitive type (emitBoxReturn: valueOf, long's\n  Numbers.num being Long.valueOf), so that emit's code is always a reference, as the bytecode's\n  emit leaves one.R8,i1556,R9,i1,R10,s18,arbace/c2j/emit.aem10,R1,L1,V2,R2,R12,R7,s59,Code for analyzed node e, its value boxed (an Expr's emit).R8,i1567,R9,i1,R10,s18,arbace/c2j/emit.aem10,R1,L1,V2,R2,R12,R7,s72,Code for analyzed node e, its value of its primitive type (emitUnboxed).R8,i1631,R9,i1,R10,s18,arbace/c2j/emit.aem12,R0,TR1,L1,V1,R127,R7,s160,Form f realized throughout (the emitters build lazy seqs; what they record, the constants\n  and the classes, must be recorded before it is read), metadata kept.R8,i1663,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,simple-namem10,R0,TR1,L1,V1,Myn6,binarym2,R3,R143,R8,i1672,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,throws?m12,R0,TR1,L1,V1,R12,R7,s86,Does node e end in a throw (a form that does not complete, which needs no conversion)?R8,i1675,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,ret-bodym12,R0,TR1,L1,V3,R2,R24,Myn3,retm2,R3,R144,R7,s148,A deftype's method body as returned in type ret (ObjMethod.emitBody): unboxed when it can be,\n  else boxed then cast or unboxed as ASM's unbox does.R8,i1684,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,method-bodym12,R0,TR1,L1,V5,R2,R145,R146,R147,V1,R148,R7,s302,The body of FnMethod or NewInstanceMethod m (its node), in the method's context: wrapped in\n  a loop over its parameters when a recur targets them. With entry, the body of a fn method's\n  unboxed entry (F6, psig): its primitive parameters taken as they are, its value of the\n  signature's return class.R8,i1714,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,param-symm10,R0,TR1,L1,V1,R20,R8,i1757,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,prim-classesR54,R59,R102,R50,R149,R150,R151,R152,m8,R0,TR8,i1763,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,tag-classm12,R0,TR1,L1,V1,R153,R7,s70,The class a field's tag names (Compiler.tagClass): Object without one.R8,i1767,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,box-classm10,R0,TR1,L1,V1,Myn1,cm2,R3,R144,R8,i1776,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit16,class-interfacesm12,R0,TR1,L1,V2,R2,R22,R7,s179,The interfaces of a deftype's or reify's class (its node ox), as the analysis made the\n  class: their names. A class of the program cannot implement an interface made at run time.R8,i1780,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,field-modsm12,R0,TR1,L1,V2,R22,R20,R7,s104,The modifiers of a deftype's field lb (ObjExpr.compile): volatile, mutable (package), or\n  public final.R8,i1791,R9,i1,R10,s18,arbace/c2j/emit.aem10,R1,L1,V2,R2,R22,R7,s202,Defines deftype ox's class (its node), a top-level class named as the deftype, once:\n  its fields, constructors, getBasis (and create for a record), and methods\n  (NewInstanceExpr.compile, emitStatics).R8,i1801,R9,i1,R10,s18,arbace/c2j/emit.aem10,R1,L1,V2,R2,R22,R7,s109,Defines the class of fn or reify ox (its node) once, in the classes being emitted; returns\n  its binary name.R8,i1869,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,unit-methodm12,R0,TR1,L1,V3,R2,R154,V7,R155,R92,R156,R157,R157,R158,R159,R7,s96,The static method unitK of a source's loader class: unit u's events made again, then its\n  code.R8,i2016,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,unit-nsm12,R0,TR1,L1,V1,V6,R155,R157,R157,R157,R157,R158,R7,s79,The namespace unit u was analyzed in: its fn's (kind 1) or its def's, else nil.R8,i2081,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,loader-part-unitsl100,m8,R8,i2092,R9,i1,R10,s18,arbace/c2j/emit.aeR7,s251,The most units a source's loader class holds itself; a source of more is split into parts of\n  as many (SA210): j2g analyzes classes in parallel, one class on one thread (arbace.core's 903\n  units were one task of 9 to 14 s, the last of the analysis).v15,arbace.c2j.emit15,unnamed-packagem10,R1,L1,V1,Myn2,nmm2,R3,R143,R7,s484,The option placing top-level class nm in Java's unnamed package when its name has no\n  package: the classes of a namespace of one segment (user: its holder user, the fns\n  user$eval1$fn__2, the loader of a source user.ae, user__init), named as the JVM names them,\n  where the Java forms would put a simple name in the package of the namespace they are read in\n  (arbace). The tree's files import them (arbace.c2j.main), so that a class of a package can name\n  them, as Java could not.R8,i2098,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,emit-sourcem10,R1,L1,V6,R160,R161,R162,R163,R164,R165,R7,s259,The Java forms of source path src (scriptbase.ae), compiled from its units: the loader\n  class SCRIPTBASE__init's form and the fn classes made, into the atom classes (fn-names: the\n  fns' class names by their FnExpr, an IdentityHashMap shared by the sources).R8,i2108,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,class-formm12,R0,TR1,L1,V4,R166,R167,R17,R163,R7,s289,The defclass form of class c (its record: a fn's, a reify's, a deftype's, an interface's, or\n  a holder of nested classes), its nested classes inside; at the top its full name and the\n  constants it shares with them (pools: top → its pool), else a static member class by its\n  simple name.R8,i2174,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,class-formsm10,R1,L1,V2,R160,R163,R7,s261,The top-level Java forms holding every class of classes (name → record), nested as their\n  binary names nest, with holder classes made for the missing levels (a namespace's fns nest\n  in a holder named as the namespace); pools: the top-level classes' constants.R8,i2210,R9,i1,R10,s18,arbace/c2j/emit.aev15,arbace.c2j.emit16,interface-recordm10,R1,L1,V3,R168,R169,R170,R7,s133,The record of an interface made by gen-interface (events iface and imethod): name, the\n  interfaces it extends, its abstract methods.R8,i2232,R9,i1,R10,s18,arbace/c2j/emit.ae")

var Lit_502 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic")

var Lit_503 *jrt.String = jrt.Intern("arbace.c2j.emit$static_call_form")

var Lit_504 *jrt.String = jrt.Intern("arbace.c2j.emit$call_static")

var Lit_505 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic")

var Lit_506 *jrt.String = jrt.Intern("arbace.c2j.emit$direct_static_QMARK_")

var Lit_507 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_method")

var Lit_508 *jrt.String = jrt.Intern("arbace.c2j.emit$field_ok_QMARK_")

var Lit_509 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_instance_field")

var Lit_510 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_field")

var Lit_511 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_new")

var Lit_512 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_def")

var Lit_513 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_assign")

var Lit_514 *jrt.String = jrt.Intern("arbace.c2j.emit$coll_call")

var Lit_515 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_binding_init")

var Lit_516 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_let")

var Lit_517 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_recur")

var Lit_518 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance")

var Lit_519 *jrt.String = jrt.Intern("arbace.c2j.emit$fn_wrap")

var Lit_520 *jrt.String = jrt.Intern("arbace.c2j.emit$fn_instance")

var Lit_521 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn")

var Lit_522 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try")

var Lit_523 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case")

var Lit_524 *jrt.String = jrt.Intern("arbace.c2j.emit$lift")

var Lit_525 *jrt.String = jrt.Intern("arbace.c2j.emit$prim_chan")

var Lit_526 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_const")

var Lit_527 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_local")

var Lit_528 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_if")

var Lit_529 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_call")

var Lit_530 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke")

var Lit_531 *jrt.String = jrt.Intern("arbace.c2j.emit$box_prim")

var Lit_532 *jrt.String = jrt.Intern("arbace.c2j.emit$emit")

var Lit_533 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_unboxed")

var Lit_534 *jrt.String = jrt.Intern("arbace.c2j.emit$deep")

var Lit_535 *jrt.String = jrt.Intern("arbace.c2j.emit$simple_name")

var Lit_536 *jrt.String = jrt.Intern("arbace.c2j.emit$throws_QMARK_")

var Lit_537 *jrt.String = jrt.Intern("arbace.c2j.emit$ret_body")

var Lit_538 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body")

var Lit_539 *jrt.String = jrt.Intern("arbace.c2j.emit$param_sym")

var Lit_540 *jrt.String = jrt.Intern("arbace.c2j.emit$tag_class")

var Lit_541 *jrt.String = jrt.Intern("arbace.c2j.emit$box_class")

var Lit_542 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces")

var Lit_543 *jrt.String = jrt.Intern("arbace.c2j.emit$field_mods")

var Lit_544 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_")

var Lit_545 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_")

var Lit_546 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method")

var Lit_547 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_ns")

var Lit_548 *jrt.String = jrt.Intern("arbace.c2j.emit$unnamed_package")

var Lit_549 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source")

var Lit_550 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form")

var Lit_551 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms")

var Lit_552 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record")
