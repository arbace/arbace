//line j2g_strings.ae:1
package aot_arbace_c2j_emit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.j2g.jrtyn3,jrtyn16,arbace.j2g.namesyn2,nmkn3,dockn4,selfkn3,tagkn15,runtime-classeskn12,unit-proxieskn5,poolskn4,namekn6,constskn9,const-mapkn12,const-prefixkn3,clskn4,prevyn3,newys16,java.lang.Object1,1yn14,unchecked-charys16,java.lang.Double16,longBitsToDoublekn4,elseys17,java.lang.Boolean4,TRUEys17,java.lang.Boolean5,FALSEys17,java.lang.Integer7,valueOfyn13,unchecked-intys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys19,java.lang.Character7,valueOfys14,arbace.lang.RT22,classForNameNonLoadingys18,arbace.lang.Symbol6,internkn10,param-tagsyn16,java.lang.Stringys14,arbace.lang.RT7,keywordys14,arbace.lang.RT3,varys21,arbace.lang.Namespace12,findOrCreateyn18,arbace.lang.Symbolys14,arbace.lang.RT3,mapys17,arbace.lang.Tuple6,createyn16,java.lang.Objectys14,arbace.lang.RT6,vectorys29,arbace.lang.PersistentHashSet5,EMPTYys29,arbace.lang.PersistentHashSet6,createys26,arbace.lang.PersistentList6,createyn14,java.util.Listys16,java.util.Arrays6,asListys23,java.util.regex.Pattern7,compileys14,arbace.lang.RT10,readStringyn9,.withMetayn4,castyn16,arbace.lang.IObjyn26,arbace.lang.IPersistentMapkn3,nilkn6,stringkn7,booleankn3,intkn4,longkn6,doublekn4,charkn5,classkn6,symbolkn7,keywordkn3,varkn2,nskn3,mapkn6,vectorkn3,setkn4,listkn7,patternkn4,readyn5,fieldyn10,const-poolkn6,statickn5,finalkn7,privateys24,arbace.lang.Compiler$AOT4,poolyn3,intks3,c2j2,nnyn4,agetyn15,arbace.lang.Varyn19,arbace.lang.Keywordyn15,java.lang.Classkn7,gensymskn3,idxkn6,closedyn4,thiskn4,primkn16,canEmitPrimitiveyn2,dokn14,unchecked-mathyn13,.booleanValueyn17,java.lang.Booleanyn10,.charValueyn19,java.lang.Characterys30,arbace.lang.Compiler$Evaluator7,fiAdaptys14,arbace.lang.RT16,uncheckedIntCastys14,arbace.lang.RT7,intCastyn4,longyn15,unchecked-floatyn4,.getyn11,.getRawRootkn4,lineks3,c2j4,linekn11,spec-localskn1,bkn4,oncekn11,shouldClearkn12,canBeClearedkn11,bindingPrimkn5,isArgkn8,self-symkn1,lyn3,letyn2,t-yn4,set!yn2,ifyn4,nil?kn7,dynamickn5,redefkn5,macrokn2,opkn8,restParmkn8,reqParmskn8,retClasskn6,paramskn3,retkn4,bodykn6,methodkn4,argskn1,okn5,fexprkn10,loopLocalskn12,initProvidedkn4,initkn10,isVariadickn7,methodsys14,arbace.lang.RT10,doubleCastys14,arbace.lang.RT8,longCastkn5,bindskn3,genkn3,prikn1,nkn4,passkn5,guardyn9,instance?yn14,java.lang.Longyn10,.longValuekn1,rkn1,wkn1,fkn2,idkn3,keykn6,callerkn4,rootkn4,symskn4,psigkn3,outkn4,convkn5,partskn5,smaskkn5,spassyn3,andys3,c2j4,linkyn7,.invokeyn15,arbace.lang.IFnyn11,.invokePrimyn11,.invokeSpecyn30,arbace.lang.Compiler$AOTRestFnyn26,arbace.lang.Compiler$AOTFnys30,arbace.lang.Compiler$AOTRestFn6,linkedys26,arbace.lang.Compiler$AOTFn10,linkedFastkn2,fnkn4,kindkn10,isProtocolkn10,protocolOnyn8,.applyToys20,arbace.lang.ArraySeq6,createkn8,onMethodyn3,notys24,arbace.lang.Compiler$AOT5,isDynkn7,classeskn7,standinkn5,funcskn9,interfacekn11,dyn-guardedkn6,targetks15,arbace.c2j.emit5,localkn10,target-symkn15,qualifyingClassyn5,some?ys21,arbace.lang.Reflector20,invokeInstanceMethodkn10,methodNameys21,arbace.lang.Reflector27,invokeInstanceMethodOfClassyn6,doubleyn13,unchecked-addyn18,unchecked-multiplyyn2,>=yn7,bit-andyn7,bit-xoryn2,==yn1,<yn2,oryn16,unchecked-divideyn18,unchecked-subtractyn2,<=yn6,bit-oryn19,unchecked-remainderyn14,bit-shift-leftyn1,>yn15,bit-shift-rightyn16,unchecked-negateyn13,unchecked-decyn13,unchecked-inckn1,jkn1,xyn1,xyn4,slowyn1,yyn1,ryn12,.doubleValueyn16,java.lang.Doublekn7,mutableys21,arbace.lang.Reflector18,invokeStaticMethodkn1,ckn5,fieldys21,arbace.lang.Reflector25,invokeNoArgInstanceMemberyn7,booleankn9,fieldNamekn12,requireFieldys21,arbace.lang.Reflector14,getStaticFieldkn4,ctorys21,arbace.lang.Reflector17,invokeConstructorkn4,metayn9,.bindRootyn8,.setMetakn9,isDynamicyn11,.setDynamickn3,valyn4,.setys21,arbace.lang.Reflector16,setInstanceFieldkn8,testExprkn8,thenExprkn8,elseExprkn12,bindingInitskn6,isLoopkn11,loop-localskn7,bindingyn4,loopyn5,recurkn12,method-recurkn13,method-localskn12,supportsMetakn6,closeskn8,variadicys24,arbace.lang.Compiler$AOT7,fnClassyn3,trykn7,tryExpryn5,catchkn2,lbkn7,handlerkn10,catchExprskn11,finallyExpryn7,finallykn4,exprkn5,shiftkn4,maskyn11,bit-and-intyn19,bit-shift-right-intkn5,testskn5,thenskn8,testTypekn7,defaultkn9,skipCheckkn13,hash-identityyn4,whenys16,arbace.lang.Util5,equivyn5,breakyn10,identical?yn6,switchys16,arbace.lang.Util4,hashyn9,.intValueyn16,java.lang.Numberyn5,labelkn11,defaultExprkn9,isDeftypekn4,typekn4,collys26,arbace.lang.PersistentList5,EMPTYys28,arbace.lang.PersistentVector5,EMPTYys30,arbace.lang.PersistentArrayMap5,EMPTYkn5,exprskn1,kkn2,kwkn3,strkn1,vkn7,keyvalsys30,arbace.lang.Compiler$Evaluator11,monitorExityn5,throwyn19,java.lang.Throwablekn7,excExprys14,arbace.lang.RT11,arrayToListys30,arbace.lang.Compiler$Evaluator12,monitorEnteryn12,.importClassyn21,arbace.lang.Namespaceyn6,.derefys14,arbace.lang.RT10,CURRENT_NSkn5,textsys24,arbace.lang.Compiler$AOT9,strConcatys16,java.lang.String1,1ys14,arbace.lang.RT3,setkn4,keysyn11,.isInstancekn9,argLocalskn4,speckn4,objxkn13,compiledClasskn3,symkn16,volatile-mutablekn8,volatilekn22,unsynchronized-mutablekn6,publickn12,hintedFieldskn12,altCtorDropsyn11,constructoryn6,super.kn6,columnyn3,m__yn6,methodkn7,deftypekn5,superkn10,interfaceskn7,memberskn6,sourceks15,arbace.c2j.emit7,pendingyn5,this.yn8,getBasisyn29,arbace.lang.IPersistentVectoryn6,createys19,arbace.lang.Keyword6,internyn6,.valAtyn8,.withoutys14,arbace.lang.RT9,seqOrElsekn8,fn-nameskn8,onceOnlyyn4,selfyn6,meta__yn8,.-__metayn6,invokeyn10,invokeSpecyn10,invokePrimyn8,doInvokeyn8,fn-classyn6,__metayn4,metayn8,withMetayn1,mkn5,reifykn5,primskn5,specsys14,arbace.lang.RT4,consys14,arbace.lang.RT3,seqys14,arbace.lang.RT16,loadClassForNameys24,arbace.lang.Compiler$AOT2,atkn7,packagekn4,formyn8,defclassks3,c2j6,sourceyn4,loadyn4,initks3,c2j4,codekn6,holderkn7,extendskn10,implementskn8,abstractv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.c2j.emitm2,R8,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).v11,arbace.core5,some?v15,arbace.c2j.emit10,node-cachev11,arbace.core5,assocR9,v11,arbace.core7,ex-infov13,arbace.string12,starts-with?v11,arbace.core4,subsv11,arbace.core6,symbolv11,arbace.core3,strv15,arbace.c2j.emit8,type-symv15,arbace.c2j.emit6,destubv11,arbace.core9,vary-metaR10,v15,arbace.c2j.emit10,prim-namesv15,arbace.c2j.emit10,registeredv11,arbace.core3,notv11,arbace.core5,swap!v11,arbace.core9,contains?R11,v15,arbace.c2j.emit11,registered?v11,arbace.core8,identityR12,l0,R13,v11,arbace.core4,atomR14,R15,R16,R17,R18,R19,v11,arbace.core4,namev11,arbace.core6,updatev11,arbace.core4,listR20,R21,v11,arbace.core4,mapvv15,arbace.c2j.emit10,emit-valuev11,arbace.core4,not=c92,R22,R23,V2,nTv11,arbace.core7,string?v11,arbace.core6,class?v11,arbace.core7,symbol?v11,arbace.core8,keyword?v11,arbace.core4,var?v15,arbace.c2j.emit4,failv11,arbace.core5,classv11,arbace.core4,map?v11,arbace.core7,vector?v11,arbace.core4,seq?v11,arbace.core5,list?R24,v11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsR25,R26,R27,R28,R29,R30,v15,arbace.c2j.emit11,double-formR31,v15,arbace.c2j.emit9,char-formC17,java.lang.BooleanC14,java.lang.ByteC19,java.lang.CharacterC16,java.lang.DoubleC15,java.lang.FloatC17,java.lang.IntegerC14,java.lang.LongC15,java.lang.ShortR32,v11,arbace.core9,with-metaR33,m2,R34,V2,R35,R35,v11,arbace.core9,namespaceR36,m2,R34,V2,R35,R35,R37,m2,R34,V2,R35,R35,R38,m2,R34,V1,R39,R33,m2,R34,V2,R35,R35,R40,m2,R34,V1,R21,v15,arbace.c2j.emit15,emit-list-arrayv11,arbace.core6,mapcatv11,arbace.core5,list*R41,R34,v11,arbace.core3,vecv11,arbace.core6,repeatR42,v11,arbace.core3,mapR43,m2,R34,V1,R21,v11,arbace.core6,empty?R44,R45,m2,R34,V1,R21,v11,arbace.core3,seqR46,m2,R34,V1,R47,R48,m2,R34,V1,R21,R49,m2,R34,V1,R35,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*print-dup*R50,m2,R34,V1,R35,R51,R52,R53,R52,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,R72,v15,arbace.c2j.emit9,pool-kindv11,arbace.core6,concatv15,arbace.c2j.emit12,pool-partialc44,v15,arbace.c2j.emit12,pool-shared?c82,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv15,arbace.c2j.emit11,pool-encodev11,arbace.core10,chunk-restv11,arbace.core4,nextc77,v15,arbace.c2j.emit8,pool-strc110,c84,c70,c118,c107,c115,c112,c100,c109,c80,c86,c68,c67,c66,c90,c74,c83,c73,c99,c78,c114,c108,c121,c69,c105,c76,v11,arbace.core6,removev11,arbace.core4,run!v15,arbace.c2j.emit10,pool-partsv11,arbace.core4,intov11,arbace.core11,map-indexedR73,v15,arbace.c2j.emit6,taggedR74,m6,R75,TR76,TR77,TR78,m2,R34,V2,R35,R79,R28,v11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR73,m6,R75,TR76,TR80,TR42,R81,R74,R28,R52,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consm6,R75,TR76,TR80,Tv11,arbace.core4,restR82,R83,R84,R42,v15,arbace.c2j.emit14,runtime-class?v15,arbace.c2j.emit14,*late-classes*v15,arbace.c2j.emit11,const-fieldv15,arbace.c2j.emit10,const-typeR32,m2,R34,V1,R35,R85,v11,arbace.core4,fnilv11,arbace.core3,incR86,R87,v15,arbace.c2j.emit9,field-symR88,R89,v15,arbace.c2j.emit4,nodeR90,R91,v15,arbace.c2j.emit6,box-ofC16,java.lang.ObjectR92,v15,arbace.c2j.emit7,public?R93,R52,R94,R95,R52,R96,m2,R34,V1,R42,R52,v15,arbace.c2j.emit12,emit-unboxedv15,arbace.c2j.emit9,prim-callv15,arbace.c2j.emit9,unbox-argv15,arbace.c2j.emit4,emitv15,arbace.c2j.emit3,fi?R97,v15,arbace.c2j.emit8,constantR98,R99,m2,R34,V1,R100,R101,R20,R21,R82,R102,R103,R104,R105,R106,R29,m2,R34,V1,R100,R107,v15,arbace.c2j.emit7,closed?v15,arbace.c2j.emit10,field-readR108,R109,R110,R111,R112,R113,R88,v15,arbace.c2j.emit10,spec-localv11,arbace.core8,to-arrayR114,v15,arbace.c2j.emit9,local-symR115,R116,R116,R117,R118,R119,R117,v15,arbace.c2j.emit9,long-box*R120,R121,R122,R123,R124,R125,R126,v11,arbace.core4,someR127,R128,S2,s2,fns12,new-instancev11,arbace.core2,<=l1,l4,v15,arbace.c2j.emit4,psigv11,arbace.core5,rangev15,arbace.c2j.emit10,walk-nodesR129,R130,v15,arbace.c2j.emit15,intrinsic-probev11,arbace.core6,vectorR131,R132,R133,v15,arbace.c2j.emit15,long-valued-opsv11,arbace.core6,reset!R134,v11,arbace.core6,every?v11,arbace.core5,true?v11,arbace.core10,identical?R135,R136,v15,arbace.c2j.emit9,*var-fns*R137,R138,v15,arbace.c2j.emit15,site-fn-methodsv15,arbace.c2j.emit9,spec-maskR139,R140,m2,R34,V1,R42,R141,R142,R143,R144,v15,arbace.c2j.emit4,deepv15,arbace.c2j.emit9,can-prim?v15,arbace.c2j.emit10,jrt-lacks?v15,arbace.c2j.emit3,boxR145,v15,arbace.c2j.emit14,spec-intrinsicR146,R147,R148,R149,R52,R148,v15,arbace.c2j.emit9,var-valuev15,arbace.c2j.emit9,site-psigR150,v15,arbace.c2j.emit4,gsymR151,R152,R2,v15,arbace.c2j.emit9,site-specv15,arbace.c2j.emit8,prim-argv15,arbace.c2j.emit8,spec-argR153,v15,arbace.c2j.emit6,*link*R154,R155,v15,arbace.c2j.emit8,top-nameR156,R157,R158,R159,R160,R161,v11,arbace.core4,keepR162,R163,R164,R165,v15,arbace.c2j.emit14,emit-link-sitev11,arbace.core6,secondR166,R52,R167,R168,R52,R169,R52,R170,R171,R115,R167,R52,R167,R166,R166,R52,R118,R115,R167,R172,R173,R118,R119,R52,R167,R118,R119,R166,R115,R167,R118,R119,R52,R167,R118,R166,R166,R52,R119,v15,arbace.c2j.emit9,link-formR174,R175,R176,R177,v15,arbace.c2j.emit8,link-keyv15,arbace.c2j.emit8,site-keyv15,arbace.c2j.emit9,line-metaR166,R52,R167,R178,R52,R167,R179,m2,R34,V1,R21,v15,arbace.c2j.emit9,obj-arrayR180,R115,R118,v15,arbace.c2j.emit10,param-tagsR52,v15,arbace.c2j.emit10,typed-argsR166,R52,R167,R164,R147,R181,R182,v13,arbace.string7,replacev14,arbace.j2g.jrt4,scanv15,arbace.c2j.emit8,jrt-scanR183,R184,v16,arbace.j2g.names13,go-class-namev11,arbace.core5,applyv15,arbace.c2j.emit10,descriptorv16,arbace.j2g.names11,method-baseR185,v14,arbace.j2g.jrt14,struct-methodsv14,arbace.j2g.jrt13,iface-methodsv16,arbace.j2g.names9,impl-nameR52,R186,v15,arbace.c2j.emit19,compiled-interface?R187,R188,R189,R190,v15,arbace.c2j.emit11,method-callv15,arbace.c2j.emit20,emit-instance-methodR191,R115,R118,R164,R192,R182,R193,m2,R34,V3,R42,R35,R21,R194,R195,R193,m2,R34,V3,R42,R35,R21,v15,arbace.c2j.emit6,*lbox*R29,m2,R34,V1,R100,R30,m2,R34,V1,R196,R115,R118,v15,arbace.c2j.emit8,long-boxR197,R198,R199,R200,R201,R201,R164,R181,R202,v15,arbace.c2j.emit8,long-minR199,R200,R201,R201,R164,R181,R164,R202,R203,R204,R202,R202,R205,R203,R197,R200,R199,R201,R206,R207,R206,R208,R198,R118,R209,R202,R210,R118,R205,R202,R211,R202,R212,v15,arbace.c2j.emit10,double-boxR197,R198,R203,R199,R197,R213,R207,R203,R202,R118,R202,R213,R214,R203,R211,v15,arbace.c2j.emit8,long-maxR215,R215,R213,R214,R202,R213,R206,d4607182418800017408,R203,d0,R211,d0,R197,d4607182418800017408,R202,d0,C19,arbace.lang.NumbersR216,R217,V1,R132,v15,arbace.c2j.emit8,long-op1R218,R219,S1,R132,S2,R132,R216,v15,arbace.c2j.emit8,long-op2R218,R220,R219,R221,R118,R119,R117,R149,R52,R148,R222,R52,R223,R147,R164,S1,R132,v11,arbace.core8,not-any?v15,arbace.c2j.emit10,double-op1v15,arbace.c2j.emit10,double-op2R115,R115,R118,R148,R115,R118,R223,R115,R118,R119,R117,R91,R117,R224,R115,R118,R119,R204,R119,R147,R148,R118,R119,R149,R52,R148,v15,arbace.c2j.emit17,numbers-intrinsicv15,arbace.c2j.emit18,emit-static-methodR225,m2,R34,V3,R84,R35,R21,R226,R227,v15,arbace.c2j.emit9,field-ok?R52,R228,m2,R34,V3,R42,R35,R229,R230,R231,R232,m2,R34,V2,R84,R35,R233,R234,m2,R34,V2,R84,R21,R82,R235,R91,R236,R237,R238,R239,R91,R239,R237,R236,R52,R54,R240,R241,R82,R117,R117,R117,R52,R242,m2,R34,V1,R21,R243,R118,R244,R245,R246,R247,R248,R249,v15,arbace.c2j.emit17,emit-binding-initR250,R115,R251,v15,arbace.c2j.emit4,primR99,m2,R34,V1,R100,R101,R252,R253,v15,arbace.c2j.emit14,emit-fn-class!v15,arbace.c2j.emit10,emit-localR20,R254,V1,nv11,arbace.core4,keysR255,R256,R115,R84,R118,R119,R115,R84,R257,m2,R34,V2,R35,R229,R117,R20,R170,R28,R20,R171,v15,arbace.c2j.emit13,body-instancev15,arbace.c2j.emit7,fn-wrapv15,arbace.c2j.emit12,identity-setR117,R115,R91,R258,R259,R260,R261,R262,R263,R264,R265,R266,R267,R268,R269,R270,v11,arbace.core10,sorted-mapR271,R272,v11,arbace.core7,keywordR273,R274,v11,arbace.core3,setR275,R276,R277,R278,m2,R34,V2,R42,R42,R279,R277,R202,R279,R279,R277,R202,R100,R279,R279,R277,R280,R279,R277,R278,m2,R34,V2,R42,R42,R279,R281,R282,R28,R277,R281,R283,R52,R284,R147,R284,R285,R286,S2,s9,instance?s5,localv15,arbace.c2j.emit8,emit-tryR287,v15,arbace.c2j.emit11,fn-instancev15,arbace.c2j.emit8,emit-defv15,arbace.c2j.emit11,emit-invokeR288,v15,arbace.c2j.emit8,box-primv15,arbace.c2j.emit19,emit-deftype-class!R289,R290,R291,R292,R44,v15,arbace.c2j.emit19,emit-instance-fieldR293,R91,v11,arbace.core7,butlastv11,arbace.core4,lastR166,R294,R295,R83,v15,arbace.c2j.emit7,emit-ifv15,arbace.c2j.emit11,emit-assignv15,arbace.c2j.emit10,emit-letfnR51,R52,R53,R52,R54,R82,R83,R296,R41,R42,v15,arbace.c2j.emit9,coll-callR43,v15,arbace.c2j.emit8,emit-letv15,arbace.c2j.emit10,emit-recurR297,R40,R298,R91,R299,v15,arbace.c2j.emit8,emit-newR300,R52,R301,R302,R25,R26,R303,R91,R304,R305,R52,R306,R307,R308,R32,v15,arbace.c2j.emit17,emit-static-fieldR309,v15,arbace.c2j.emit9,emit-caseR310,R20,R311,R20,R21,R312,R313,R314,R147,R91,R314,R147,R300,R52,R301,v15,arbace.c2j.emit7,throws?R52,R284,R99,m2,R34,V1,R100,R101,R93,R52,R94,R95,R52,R96,R52,R315,v15,arbace.c2j.emit8,ret-bodyR316,R317,R250,R115,R139,R140,m2,R34,V1,R42,v15,arbace.c2j.emit12,prim-classesv11,arbace.core10,ns-resolvev11,arbace.core4,*ns*R318,R319,R320,m2,R321,TR322,m4,R323,TR76,Tv15,arbace.c2j.emit4,poolv11,arbace.core6,dissocR88,R324,R325,R326,R88,m2,R323,TML1,R327,m4,R104,i1712,R328,i26,R117,R88,R88,v11,arbace.core4,takeR329,R88,R330,m2,R323,Tv15,arbace.c2j.emit11,method-bodym2,R323,TR73,v15,arbace.c2j.emit10,field-modsR331,R332,R42,R333,v15,arbace.c2j.emit16,class-interfacesR334,R335,R336,R326,m2,R323,TR337,R28,R28,R326,m2,R323,TR337,R28,R28,R330,R338,m4,R323,TR75,TR339,R330,R340,m4,R323,TR75,TR54,v15,arbace.c2j.emit9,tag-classR341,m2,R34,V1,R35,R342,R52,v15,arbace.c2j.emit9,box-classm2,R34,V1,R35,R115,R115,R117,R343,R20,R344,R28,R28,m2,R224,TR345,R346,R347,R88,R73,R326,V1,R88,R348,R54,m2,R323,TML1,R327,m4,R104,i1791,R328,i26,V1,ML3,R117,ML2,R349,R88,m4,R104,i1792,R328,i53,R348,m4,R104,i1792,R328,i47,R117,R88,V2,R88,R347,v15,arbace.c2j.emit9,param-symV2,R88,R347,R147,R148,R164,V2,R88,R347,R330,R350,m2,R323,TR118,R169,R88,R347,R149,R52,R148,R330,R351,m2,R323,TR330,R352,m2,R323,TR330,R350,m2,R323,TR168,R88,R347,R139,R140,m2,R34,V1,R42,R330,R353,R350,m2,R323,TR88,R330,m2,R323,Tm2,R323,TR73,R354,m4,R323,TR75,TR84,R73,R355,R54,R330,R356,m2,R323,TV1,R88,R54,ML2,R349,R88,m4,R104,i1874,R328,i117,R330,R357,m2,R323,TR88,R358,R54,R53,R20,R358,R88,R359,R42,R360,v11,arbace.core9,not-emptyR361,R178,R52,R167,R103,v11,arbace.core15,get-proxy-classR82,R362,m2,R34,V2,R42,R42,R363,m2,R34,V1,R42,R20,R21,R241,R308,R38,R52,R39,m2,R34,V2,R42,R42,m2,R34,V1,R42,v11,arbace.core5,doallR277,R119,R364,m2,R34,V1,R35,R166,R52,R167,R103,v11,arbace.core12,define-proxyR82,R363,m2,R34,V1,R42,R20,R21,m2,R34,V1,R35,m2,R34,V1,R42,R330,m4,R77,TR75,TR91,R365,R28,R28,v11,arbace.core7,sort-byv11,arbace.core7,find-nsv13,arbace.string9,includes?V2,R366,s0,v15,arbace.c2j.emit11,unit-methodv15,arbace.c2j.emit7,unit-nsv15,arbace.c2j.emit17,loader-part-unitsR367,R368,R323,R76,R369,v15,arbace.c2j.emit15,unnamed-packagev15,arbace.c2j.emit11,pool-fieldsR330,R370,m4,R323,TR75,TR91,V1,nR368,R75,R330,R371,m2,R75,TR330,R370,m2,R75,TR91,V1,nm2,R75,Tm2,R75,TV1,nv11,arbace.core13,partition-allR368,R330,R370,m4,R323,TR75,TR91,V1,nv15,arbace.c2j.emit10,class-formR372,v15,arbace.c2j.emit11,simple-nameR373,R368,m6,R323,TR75,TR76,TR368,m6,R323,TR75,TR186,TR374,R368,m6,R323,TR75,TR76,TR375,v11,arbace.core4,peekv11,arbace.core3,popv11,arbace.core8,group-byv11,arbace.core4,sortR330,m4,R323,TR376,TR88,m4,R323,TR376,T")

var Lit_1 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000377__31000381")

var Lit_2 *jrt.String = jrt.Intern("new-instance")

var Lit_3 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000377__31000381$fn__31000382")

var Lit_4 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000377__31000381$fn__31000382$fn__31000383")

var Lit_5 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form$fn__31000899")

var Lit_6 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form$mods__31000901")

var Lit_7 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$parent__31000906")

var Lit_8 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$fn__31000908")

var Lit_9 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000910__31000914")

var Lit_10 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$fn__31000920")

var Lit_11 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$children_of__31000922")

var Lit_12 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000924__31000928")

var Lit_13 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000910__31000914$fn__31000915")

var Lit_14 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000910__31000914$fn__31000915$fn__31000916")

var Lit_15 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000924__31000928$fn__31000929")

var Lit_16 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000924__31000928$fn__31000929$fn__31000930")

var Lit_17 *jrt.String = jrt.Intern("$")

var Lit_18 *jrt.String = jrt.Intern("no class for ")

var Lit_19 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000506__31000510")

var Lit_20 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000506__31000510$fn__31000511")

var Lit_21 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000506__31000510$fn__31000511$fn__31000512")

var Lit_22 *jrt.String = jrt.Intern(" implements ")

var Lit_23 *jrt.String = jrt.Intern(", made at run time")

var Lit_24 *jrt.String = jrt.Intern("const-")

var Lit_25 *jrt.String = jrt.Intern("V")

var Lit_26 *jrt.String = jrt.Intern("J")

var Lit_27 *jrt.String = jrt.Intern("I")

var Lit_28 *jrt.String = jrt.Intern("D")

var Lit_29 *jrt.String = jrt.Intern("Z")

var Lit_30 *jrt.String = jrt.Intern("C")

var Lit_31 *jrt.String = jrt.Intern("F")

var Lit_32 *jrt.String = jrt.Intern("S")

var Lit_33 *jrt.String = jrt.Intern("B")

var Lit_34 *jrt.String = jrt.Intern(".")

var Lit_35 *jrt.String = jrt.Intern("/")

var Lit_36 *jrt.String = jrt.Intern("L")

var Lit_37 *jrt.String = jrt.Intern(";")

var Lit_38 *jrt.String = jrt.Intern("compile__stub.")

var Lit_39 *jrt.String = jrt.Intern("isNeg")

var Lit_40 *jrt.String = jrt.Intern("isPos")

var Lit_41 *jrt.String = jrt.Intern("unchecked_minus")

var Lit_42 *jrt.String = jrt.Intern("unchecked_dec")

var Lit_43 *jrt.String = jrt.Intern("incP")

var Lit_44 *jrt.String = jrt.Intern("minus")

var Lit_45 *jrt.String = jrt.Intern("unchecked_inc")

var Lit_46 *jrt.String = jrt.Intern("dec")

var Lit_47 *jrt.String = jrt.Intern("inc")

var Lit_48 *jrt.String = jrt.Intern("minusP")

var Lit_49 *jrt.String = jrt.Intern("isZero")

var Lit_50 *jrt.String = jrt.Intern("decP")

var Lit_51 *jrt.String = jrt.Intern("lt")

var Lit_52 *jrt.String = jrt.Intern("addP")

var Lit_53 *jrt.String = jrt.Intern("unchecked_add")

var Lit_54 *jrt.String = jrt.Intern("unchecked_multiply")

var Lit_55 *jrt.String = jrt.Intern("gte")

var Lit_56 *jrt.String = jrt.Intern("lte")

var Lit_57 *jrt.String = jrt.Intern("add")

var Lit_58 *jrt.String = jrt.Intern("multiply")

var Lit_59 *jrt.String = jrt.Intern("multiplyP")

var Lit_60 *jrt.String = jrt.Intern("gt")

var Lit_61 *jrt.String = jrt.Intern("equiv")

var Lit_62 *jrt.String = jrt.Intern("try")

var Lit_63 *jrt.String = jrt.Intern("def")

var Lit_64 *jrt.String = jrt.Intern("invoke")

var Lit_65 *jrt.String = jrt.Intern("instance-method")

var Lit_66 *jrt.String = jrt.Intern("empty")

var Lit_67 *jrt.String = jrt.Intern("unknown empty collection")

var Lit_68 *jrt.String = jrt.Intern("instance-field")

var Lit_69 *jrt.String = jrt.Intern("var")

var Lit_70 *jrt.String = jrt.Intern("keyword-invoke")

var Lit_71 *jrt.String = jrt.Intern("do")

var Lit_72 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000465")

var Lit_73 *jrt.String = jrt.Intern("fn")

var Lit_74 *jrt.String = jrt.Intern("if")

var Lit_75 *jrt.String = jrt.Intern("set!")

var Lit_76 *jrt.String = jrt.Intern("with-meta")

var Lit_77 *jrt.String = jrt.Intern("letfn")

var Lit_78 *jrt.String = jrt.Intern("number")

var Lit_79 *jrt.String = jrt.Intern("the-var")

var Lit_80 *jrt.String = jrt.Intern("keyword")

var Lit_81 *jrt.String = jrt.Intern("local")

var Lit_82 *jrt.String = jrt.Intern("string")

var Lit_83 *jrt.String = jrt.Intern("vector")

var Lit_84 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000467")

var Lit_85 *jrt.String = jrt.Intern("let")

var Lit_86 *jrt.String = jrt.Intern("recur")

var Lit_87 *jrt.String = jrt.Intern("constant")

var Lit_88 *jrt.String = jrt.Intern("map")

var Lit_89 *jrt.String = jrt.Intern("monitor-exit")

var Lit_90 *jrt.String = jrt.Intern("throw")

var Lit_91 *jrt.String = jrt.Intern("new")

var Lit_92 *jrt.String = jrt.Intern("nil")

var Lit_93 *jrt.String = jrt.Intern("boolean")

var Lit_94 *jrt.String = jrt.Intern("monitor-enter")

var Lit_95 *jrt.String = jrt.Intern("list")

var Lit_96 *jrt.String = jrt.Intern("import")

var Lit_97 *jrt.String = jrt.Intern("static-method")

var Lit_98 *jrt.String = jrt.Intern("static-field")

var Lit_99 *jrt.String = jrt.Intern("str-concat")

var Lit_100 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000469")

var Lit_101 *jrt.String = jrt.Intern("case")

var Lit_102 *jrt.String = jrt.Intern("set")

var Lit_103 *jrt.String = jrt.Intern("instance?")

var Lit_104 *jrt.String = jrt.Intern("no back end for ")

var Lit_105 *jrt.String = jrt.Intern(" ")

var Lit_106 *jrt.String = jrt.Intern("set! of a local that is no field")

var Lit_107 *jrt.String = jrt.Intern(".-")

var Lit_108 *jrt.String = jrt.Intern("set! of ")

var Lit_109 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$sm__31000443")

var Lit_110 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$ret__31000445")

var Lit_111 *jrt.String = jrt.Intern("case-")

var Lit_112 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$arm__31000447")

var Lit_113 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$fn__31000450")

var Lit_114 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$fn__31000456")

var Lit_115 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ftype__31000521")

var Lit_116 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fsym__31000523")

var Lit_117 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fn__31000525")

var Lit_118 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000527__31000531")

var Lit_119 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ps__31000537")

var Lit_120 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000541__31000545")

var Lit_121 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fn__31000558")

var Lit_122 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000563__31000567")

var Lit_123 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000579__31000583")

var Lit_124 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000597__31000601")

var Lit_125 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000527__31000531$fn__31000532")

var Lit_126 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000527__31000531$fn__31000532$fn__31000533")

var Lit_127 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000541__31000545$fn__31000546")

var Lit_128 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000541__31000545$fn__31000546$fn__31000547")

var Lit_129 *jrt.String = jrt.Intern("v__")

var Lit_130 *jrt.String = jrt.Intern("Value")

var Lit_131 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000563__31000567$fn__31000568")

var Lit_132 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000563__31000567$fn__31000568$fn__31000569")

var Lit_133 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000579__31000583$fn__31000584")

var Lit_134 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000579__31000583$fn__31000584$fn__31000585")

var Lit_135 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000579__31000583$fn__31000584$fn__31000591")

var Lit_136 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000579__31000583$fn__31000584$fn__31000593")

var Lit_137 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000579__31000583$fn__31000584$fn__31000585$fn__31000586")

var Lit_138 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000579__31000583$fn__31000584$fn__31000585$fn__31000588")

var Lit_139 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000597__31000601$fn__31000602")

var Lit_140 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000597__31000601$fn__31000602$fn__31000603")

var Lit_141 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ps__31000537$fn__31000538")

var Lit_142 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$fn__31000610")

var Lit_143 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000612__31000616")

var Lit_144 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000622__31000626")

var Lit_145 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000632__31000636")

var Lit_146 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$fn__31000642")

var Lit_147 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650")

var Lit_148 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000698__31000702")

var Lit_149 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000716__31000720")

var Lit_150 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000726__31000730")

var Lit_151 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000736__31000740")

var Lit_152 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000746__31000750")

var Lit_153 *jrt.String = jrt.Intern("__")

var Lit_154 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000612__31000616$fn__31000617")

var Lit_155 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000612__31000616$fn__31000617$fn__31000618")

var Lit_156 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000622__31000626$fn__31000627")

var Lit_157 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000622__31000626$fn__31000627$fn__31000628")

var Lit_158 *jrt.String = jrt.Intern("c__")

var Lit_159 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000632__31000636$fn__31000637")

var Lit_160 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000632__31000636$fn__31000637$fn__31000638")

var Lit_161 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650$fn__31000651")

var Lit_162 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650$fn__31000651$iter__31000646__31000652")

var Lit_163 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650$fn__31000651$fn__31000658")

var Lit_164 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650$fn__31000651$fn__31000664")

var Lit_165 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650$fn__31000651$fn__31000672")

var Lit_166 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650$fn__31000651$iter__31000674__31000678")

var Lit_167 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650$fn__31000651$fn__31000690")

var Lit_168 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650$fn__31000651$fn__31000692")

var Lit_169 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650$fn__31000651$fn__31000694")

var Lit_170 *jrt.String = jrt.Intern("_l")

var Lit_171 *jrt.String = jrt.Intern("_b")

var Lit_172 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650$fn__31000651$iter__31000646__31000652$fn__31000653")

var Lit_173 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650$fn__31000651$iter__31000646__31000652$fn__31000653$fn__31000654")

var Lit_174 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650$fn__31000651$iter__31000674__31000678$fn__31000679")

var Lit_175 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000644__31000650$fn__31000651$iter__31000674__31000678$fn__31000679$fn__31000680")

var Lit_176 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000698__31000702$fn__31000703")

var Lit_177 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000698__31000702$fn__31000703$fn__31000704")

var Lit_178 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000698__31000702$fn__31000703$fn__31000710")

var Lit_179 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000698__31000702$fn__31000703$fn__31000712")

var Lit_180 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000698__31000702$fn__31000703$fn__31000704$fn__31000705")

var Lit_181 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000698__31000702$fn__31000703$fn__31000704$fn__31000707")

var Lit_182 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000716__31000720$fn__31000721")

var Lit_183 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000716__31000720$fn__31000721$fn__31000722")

var Lit_184 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000726__31000730$fn__31000731")

var Lit_185 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000726__31000730$fn__31000731$fn__31000732")

var Lit_186 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTR")

var Lit_187 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTF")

var Lit_188 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000736__31000740$fn__31000741")

var Lit_189 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000736__31000740$fn__31000741$fn__31000742")

var Lit_190 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000746__31000750$fn__31000751")

var Lit_191 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000746__31000750$fn__31000751$fn__31000752")

var Lit_192 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_if$br__31000366")

var Lit_193 *jrt.String = jrt.Intern("target-")

var Lit_194 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke$call__31000278")

var Lit_195 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke$fn__31000282")

var Lit_196 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke$call__31000278$fn__31000279")

var Lit_197 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_let$fn__31000371")

var Lit_198 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000392")

var Lit_199 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000394")

var Lit_200 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000396__31000400")

var Lit_201 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000406__31000412")

var Lit_202 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000425")

var Lit_203 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000427")

var Lit_204 *jrt.String = jrt.Intern("body-")

var Lit_205 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000396__31000400$fn__31000401")

var Lit_206 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000396__31000400$fn__31000401$fn__31000402")

var Lit_207 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000406__31000412$fn__31000413")

var Lit_208 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000406__31000412$fn__31000413$iter__31000408__31000417")

var Lit_209 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000406__31000412$fn__31000413$iter__31000408__31000417$fn__31000418")

var Lit_210 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000406__31000412$fn__31000413$iter__31000408__31000417$fn__31000418$fn__31000419")

var Lit_211 *jrt.String = jrt.Intern("root-")

var Lit_212 *jrt.String = jrt.Intern("linked-")

var Lit_213 *jrt.String = jrt.Intern("ifn-")

var Lit_214 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000257")

var Lit_215 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000259")

var Lit_216 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000261")

var Lit_217 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000263")

var Lit_218 *jrt.String = jrt.Intern("arg-")

var Lit_219 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_list_array$fn__31000036")

var Lit_220 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_recur$fn__31000374")

var Lit_221 *jrt.String = jrt.Intern("recur arg for primitive local: ")

var Lit_222 *jrt.String = jrt.Intern(" is not matching primitive")

var Lit_223 *jrt.String = jrt.Intern("__init")

var Lit_224 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$unit_methods__31000834")

var Lit_225 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000841")

var Lit_226 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000853__31000857")

var Lit_227 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000869__31000873")

var Lit_228 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000883__31000887")

var Lit_229 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000841$iter__31000842__31000846")

var Lit_230 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000841$iter__31000842__31000846$fn__31000847")

var Lit_231 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000841$iter__31000842__31000846$fn__31000847$fn__31000848")

var Lit_232 *jrt.String = jrt.Intern("unit")

var Lit_233 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000853__31000857$fn__31000858")

var Lit_234 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000853__31000857$fn__31000858$fn__31000859")

var Lit_235 *jrt.String = jrt.Intern("$part")

var Lit_236 *jrt.String = jrt.Intern("")

var Lit_237 *jrt.String = jrt.Intern("part")

var Lit_238 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000869__31000873$fn__31000874")

var Lit_239 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000869__31000873$fn__31000874$fn__31000875")

var Lit_240 *jrt.String = jrt.Intern("init")

var Lit_241 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000883__31000887$fn__31000888")

var Lit_242 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000883__31000887$fn__31000888$fn__31000889")

var Lit_243 *jrt.String = jrt.Intern("load")

var Lit_244 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$unit_methods__31000834$fn__31000835")

var Lit_245 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$body__31000430")

var Lit_246 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000432__31000436")

var Lit_247 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000432__31000436$fn__31000437")

var Lit_248 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000432__31000436$fn__31000437$fn__31000438")

var Lit_249 *jrt.String = jrt.Intern("unboxed emit of ")

var Lit_250 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_unboxed$fn__31000474")

var Lit_251 *jrt.String = jrt.Intern("no unboxed back end for ")

var Lit_252 *jrt.String = jrt.Intern("TYPE")

var Lit_253 *jrt.String = jrt.Intern("a record as a constant: ")

var Lit_254 *jrt.String = jrt.Intern("a deftype as a constant: ")

var Lit_255 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value$fn__31000045")

var Lit_256 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value$fn__31000047")

var Lit_257 *jrt.String = jrt.Intern("#<")

var Lit_258 *jrt.String = jrt.Intern("can't embed unreadable object in code: ")

var Lit_259 *jrt.String = jrt.Intern("arbace.lang.Compiler$AST")

var Lit_260 *jrt.String = jrt.Intern("arbace.lang.Var")

var Lit_261 *jrt.String = jrt.Intern("arbace.lang.Keyword")

var Lit_262 *jrt.String = jrt.Intern("arbace.lang.Symbol")

var Lit_263 *jrt.String = jrt.Intern("arbace.lang.IObj")

var Lit_264 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_265 *jrt.String = jrt.Intern("arbace.lang.IPersistentVector")

var Lit_266 *jrt.String = jrt.Intern("arbace.lang.IPersistentSet")

var Lit_267 *jrt.String = jrt.Intern("arbace.lang.IPersistentList")

var Lit_268 *jrt.String = jrt.Intern("arbace.lang.ISeq")

var Lit_269 *jrt.String = jrt.Intern("arbace.lang.IType")

var Lit_270 *jrt.String = jrt.Intern("arbace.lang.IRecord")

var Lit_271 *jrt.String = jrt.Intern("arbace.lang.PersistentHashSet")

var Lit_272 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_273 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_274 *jrt.String = jrt.Intern("java.util.regex.Pattern")

var Lit_275 *jrt.String = jrt.Intern("aot: ")

var Lit_276 *jrt.String = jrt.Intern("fiMethod")

var Lit_277 *jrt.String = jrt.Intern("/go/arbace/jrt")

var Lit_278 *jrt.String = jrt.Intern("ARBACE_AOT_ROOT")

var Lit_279 *jrt.String = jrt.Intern("fn-class")

var Lit_280 *jrt.String = jrt.Intern("fncls__")

var Lit_281 *jrt.String = jrt.Intern("d")

var Lit_282 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$fn__31000936")

var Lit_283 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000938__31000942")

var Lit_284 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000938__31000942$fn__31000943")

var Lit_285 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000938__31000942$fn__31000943$fn__31000944")

var Lit_286 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000938__31000942$fn__31000943$fn__31000954")

var Lit_287 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000938__31000942$fn__31000943$fn__31000944$fn__31000948")

var Lit_288 *jrt.String = jrt.Intern("p")

var Lit_289 *jrt.String = jrt.Intern("arbace.c2j.emit$intrinsic_probe$fn__31000310")

var Lit_290 *jrt.String = jrt.Intern("(")

var Lit_291 *jrt.String = jrt.Intern(")")

var Lit_292 *jrt.String = jrt.Intern("arbace.c2j.emit$jrt_lacks_QMARK_$fn__31000289")

var Lit_293 *jrt.String = jrt.Intern("_")

var Lit_294 *jrt.String = jrt.Intern("linked")

var Lit_295 *jrt.String = jrt.Intern("arbace.c2j.emit$link_form$fn__31000270")

var Lit_296 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op1$guard__31000303")

var Lit_297 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op2$checked__31000297")

var Lit_298 *jrt.String = jrt.Intern("and")

var Lit_299 *jrt.String = jrt.Intern("xor")

var Lit_300 *jrt.String = jrt.Intern("or")

var Lit_301 *jrt.String = jrt.Intern("remainder")

var Lit_302 *jrt.String = jrt.Intern("shiftLeft")

var Lit_303 *jrt.String = jrt.Intern("quotient")

var Lit_304 *jrt.String = jrt.Intern("shiftRight")

var Lit_305 *jrt.String = jrt.Intern("fn-method")

var Lit_306 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000488__31000492")

var Lit_307 *jrt.String = jrt.Intern("a worker's body recurs to its parameters: ")

var Lit_308 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$fn__31000498")

var Lit_309 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$fn__31000500")

var Lit_310 *jrt.String = jrt.Intern("p-")

var Lit_311 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000488__31000492$fn__31000493")

var Lit_312 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000488__31000492$fn__31000493$fn__31000494")

var Lit_313 *jrt.String = jrt.Intern("a call of a method of a class made at run time: ")

var Lit_314 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000315")

var Lit_315 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000317")

var Lit_316 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000319")

var Lit_317 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000321")

var Lit_318 *jrt.String = jrt.Intern("arbace.lang.Numbers")

var Lit_319 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$lv__31000323")

var Lit_320 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$dv__31000325")

var Lit_321 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000328")

var Lit_322 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$is__31000333")

var Lit_323 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000337")

var Lit_324 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000339")

var Lit_325 *jrt.String = jrt.Intern("nr-")

var Lit_326 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000341")

var Lit_327 *jrt.String = jrt.Intern("na-")

var Lit_328 *jrt.String = jrt.Intern("n")

var Lit_329 *jrt.String = jrt.Intern("-")

var Lit_330 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$is__31000333$fn__31000334")

var Lit_331 *jrt.String = jrt.Intern("arbace.c2j.emit$obj_array$fn__31000152")

var Lit_332 *jrt.String = jrt.Intern("arbace.c2j.emit$pool$fn__31000031")

var Lit_333 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$num__31000055")

var Lit_334 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$arr__31000057")

var Lit_335 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$fn__31000064")

var Lit_336 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_337 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000068")

var Lit_338 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$walk__31000070")

var Lit_339 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000076")

var Lit_340 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000084")

var Lit_341 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000090")

var Lit_342 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000096")

var Lit_343 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000105")

var Lit_344 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000110__31000114")

var Lit_345 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000110__31000114$fn__31000115")

var Lit_346 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000110__31000114$fn__31000115$fn__31000116")

var Lit_347 *jrt.String = jrt.Intern("arbace.c2j.emit$prim_arg$conv__31000251")

var Lit_348 *jrt.String = jrt.Intern("arbace.c2j.emit$psig$fn__31000165")

var Lit_349 *jrt.String = jrt.Intern("arbace.c2j.emit$psig$fn__31000167")

var Lit_350 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000021")

var Lit_351 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000023")

var Lit_352 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000023$fn__31000024")

var Lit_353 *jrt.String = jrt.Intern("cut")

var Lit_354 *jrt.String = jrt.Intern("mismatched primitive return, expected ")

var Lit_355 *jrt.String = jrt.Intern(", had ")

var Lit_356 *jrt.String = jrt.Intern("arbace.c2j.emit$ret_body$num__31000481")

var Lit_357 *jrt.String = jrt.Intern("arbace.lang.IProxy")

var Lit_358 *jrt.String = jrt.Intern("arbace.c2j.emit$site_fn_methods$fn__31000244")

var Lit_359 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000344")

var Lit_360 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000346")

var Lit_361 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000348")

var Lit_362 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000350")

var Lit_363 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000352")

var Lit_364 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000354")

var Lit_365 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$param_QMARK___31000193")

var Lit_366 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$fn__31000197")

var Lit_367 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$fn__31000232")

var Lit_368 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$fn__31000197$fn__31000229")

var Lit_369 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$param_QMARK___31000193$fn__31000194")

var Lit_370 *jrt.String = jrt.Intern("arbace.c2j.emit$typed_args$fn__31000145")

var Lit_371 *jrt.String = jrt.Intern("arbace.c2j.emit$typed_args$fn__31000145$fn__31000146")

var Lit_372 *jrt.String = jrt.Intern("uncheckedIntCast")

var Lit_373 *jrt.String = jrt.Intern("intCast")

var Lit_374 *jrt.String = jrt.Intern("uncheckedFloatCast")

var Lit_375 *jrt.String = jrt.Intern("floatCast")

var Lit_376 *jrt.String = jrt.Intern("uncheckedDoubleCast")

var Lit_377 *jrt.String = jrt.Intern("doubleCast")

var Lit_378 *jrt.String = jrt.Intern("uncheckedLongCast")

var Lit_379 *jrt.String = jrt.Intern("longCast")

var Lit_380 *jrt.String = jrt.Intern("uncheckedByteCast")

var Lit_381 *jrt.String = jrt.Intern("byteCast")

var Lit_382 *jrt.String = jrt.Intern("uncheckedShortCast")

var Lit_383 *jrt.String = jrt.Intern("shortCast")

var Lit_384 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_385 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000763__31000767")

var Lit_386 *jrt.String = jrt.Intern("a top-level fn closing over locals")

var Lit_387 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000795__31000799")

var Lit_388 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$fn__31000825")

var Lit_389 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000763__31000767$fn__31000768")

var Lit_390 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000763__31000767$fn__31000768$fn__31000769")

var Lit_391 *jrt.String = jrt.Intern("type")

var Lit_392 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000763__31000767$fn__31000768$fn__31000783")

var Lit_393 *jrt.String = jrt.Intern("an event of a class made at run time: ")

var Lit_394 *jrt.String = jrt.Intern("iface")

var Lit_395 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000763__31000767$fn__31000768$fn__31000785")

var Lit_396 *jrt.String = jrt.Intern("proxy")

var Lit_397 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000763__31000767$fn__31000768$fn__31000787")

var Lit_398 *jrt.String = jrt.Intern("imethod")

var Lit_399 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000763__31000767$fn__31000768$fn__31000789")

var Lit_400 *jrt.String = jrt.Intern("stub")

var Lit_401 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000763__31000767$fn__31000768$fn__31000791")

var Lit_402 *jrt.String = jrt.Intern("ns")

var Lit_403 *jrt.String = jrt.Intern("an event of kind ")

var Lit_404 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000763__31000767$fn__31000768$fn__31000769$fn__31000771")

var Lit_405 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000763__31000767$fn__31000768$fn__31000769$fn__31000773")

var Lit_406 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000763__31000767$fn__31000768$fn__31000769$fn__31000775")

var Lit_407 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000763__31000767$fn__31000768$fn__31000769$fn__31000777")

var Lit_408 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000763__31000767$fn__31000768$fn__31000769$fn__31000779")

var Lit_409 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000795__31000799$fn__31000800")

var Lit_410 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000795__31000799$fn__31000800$fn__31000801")

var Lit_411 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000795__31000799$fn__31000800$iter__31000813__31000817")

var Lit_412 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000795__31000799$fn__31000800$fn__31000801$iter__31000802__31000806")

var Lit_413 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000795__31000799$fn__31000800$fn__31000801$iter__31000802__31000806$fn__31000807")

var Lit_414 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000795__31000799$fn__31000800$fn__31000801$iter__31000802__31000806$fn__31000807$fn__31000808")

var Lit_415 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000795__31000799$fn__31000800$iter__31000813__31000817$fn__31000818")

var Lit_416 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000795__31000799$fn__31000800$iter__31000813__31000817$fn__31000818$fn__31000819")

var Lit_417 *jrt.String = jrt.Intern("arbace.c2j.emit$var_fns$fn__31000239")

var Lit_418 *jrt.String = jrt.Intern("arbace.c2j.emit$var_fns$fn__31000241")

var Lit_419 *jrt.String = jrt.Intern("arbace.c2j.emit$walk_nodes$w__31000170")

var Lit_420 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,xyn3,msgyn1,&yn4,datakn3,tagyn6,Stringyn5,Classyn4,voidyn6,doubleyn4,charyn4,byteyn7,booleanyn5,floatyn4,longyn5,shortyn3,intyn1,syn1,cyn3,ctxyn3,topyn1,vyn5,ctypekn8,declaredyn2,xsyn9,Characterkn4,longkn6,doublekn3,intkn6,symbolkn6,stringkn6,vectorkn4,listkn3,varkn7,keywordkn5,classkn3,nilkn3,setkn7,booleankn3,mapkn4,charkn7,patternyn13,StringBuilderyn6,sharedyn6,constskn7,dynamicyn4,baseyn1,byn2,lbyn1,eyn1,nyn1,fyn2,psyn2,esyn3,Varyn8,unboxed?yn2,mnyn2,usyn5,nargsyn1,tyn1,kyn5,fnodeyn4,argsyn3,keyyn3,outyn4,convyn1,myn5,cnameyn8,variadicyn5,primsyn5,specsyn7,classesyn15,IdentityHashMapyn24,java.lang.reflect.Methodys14,java.lang.Long9,MIN_VALUEys14,java.lang.Long9,MAX_VALUEyn2,opyn1,yyn4,slowyn1,rv11,arbace.core5,in-nsMyn15,arbace.c2j.emitm2,R0,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).m2,R0,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).R1,v15,arbace.c2j.emit10,node-cachem10,R2,TR3,i35,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s58,The nodes' maps by node (the back end runs on one thread).v15,arbace.c2j.emit4,nodem10,R6,L1,V1,R7,R0,s62,The analyzed node x as a map (Compiler$AST/node), nil for nil.R3,i39,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,failm10,R2,TR6,L1,V3,R8,R9,V1,R10,R3,i48,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,destubm10,R6,L1,V1,Myn1,nm2,R11,R12,R0,s74,A class name without the compile stub's prefix (Compiler.destubClassName).R3,i54,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,type-symm10,R6,L1,V1,Myn1,cm2,R11,R13,R0,s93,The Java forms type of class c: a primitive's name, a class's binary name, an array as\n  T/n.R3,i59,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,prim-namesR14,R15,R16,R17,R18,R19,R20,R21,R22,m8,R2,TR3,i70,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,taggedm12,R2,TR6,L1,V2,R23,R24,R0,s44,Symbol s with the Java forms tag of class c.R3,i74,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,registeredv11,arbace.core4,atomm10,R2,TR3,i83,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s84,Whether a class name is registered in the program (Class/forName finds it), by name.v15,arbace.c2j.emit11,registered?m10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i87,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,runtime-class?m12,R2,TR6,L1,V2,Myn1,cm2,R11,R13,R25,R0,s291,Is class c made at run time (a Dyn class: an evaluated fn's, deftype's, interface's, proxy's)\n  rather than a class of the program, or one the program does not register by name (java.sql's,\n  whose members reflection reached from a world class)? Such a class is not named in compiled\n  code.R3,i104,R4,i1,R5,s18,arbace/c2j/emit.aev11,arbace.core12,define-proxyv15,arbace.c2j.emit7,public?m10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i119,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,top-namem10,R2,TR6,L1,V1,Myn1,nm2,R11,R12,R3,i125,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,poolm12,R2,TR6,L1,V2,R25,R26,R0,s178,The constants of top-level class top (a namespace's holder, a deftype, a loader), which its\n  member classes share (SA145): an atom {:name :consts :const-map}, made on first use.R3,i127,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,const-fieldm12,R2,TR6,L1,V3,R25,R27,R28,R0,s236,The static field holding constant value v in the class being emitted, made on first use (as\n  the JVM's const__N, one per distinct object): its symbol, const-N (a munged local's name has\n  no -, so no local, name__index, can shadow it).R3,i137,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-valuem8,R29,TR3,i158,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,emit-list-arraym10,R2,TR6,L1,V2,R25,R30,R3,i160,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,char-formm10,R2,TR6,L1,V1,Myn1,cm2,R11,R31,R3,i163,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,double-formm10,R2,TR6,L1,V1,Myn1,dm2,R11,R15,R3,i169,R4,i1,R5,s18,arbace/c2j/emit.aem10,R6,L1,V2,R25,R27,R0,s72,Code making constant value v (ObjExpr.emitValue), its metadata included.R3,i174,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,pool-kindm12,R2,TR6,L1,V1,R27,R0,s58,The tag of constant v, in the order of emit-value's cases.R3,i250,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,pool-partialS16,R32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,m10,R2,TR3,i275,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s61,The kinds whose metadata is made too (emit-value's partial?).v15,arbace.c2j.emit12,pool-shared?m12,R2,TR6,L1,V1,R27,R0,s84,Is v made once in a pool and named where used: a keyword, a symbol without metadata.R3,i279,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,pool-partsm12,R2,TR6,L1,V1,R27,R0,s62,The values constant v is made of (its elements, its metadata).R3,i284,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,pool-strm10,R2,TR6,L1,V2,Myn2,sbm2,R11,R48,Myn1,sm2,R11,R12,R3,i295,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,pool-encodem12,R2,TR6,L1,V3,Myn2,sbm2,R11,R48,R49,R27,R0,s102,Appends the encoding of v to sb (Compiler$AOT/poolValue's format); shared: shared value →\n  its index.R3,i298,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,pool-fieldsm12,R2,TR6,L1,V1,R50,R0,s264,The static fields of constants consts ([sym type value alias] ...): the pool's array, decoded\n  once (Compiler$AOT/pool), then each constant's field, its element, or for one with an alias\n  (a split loader's constant an earlier part made, SA210) that part's field.R3,i346,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,const-typem10,R2,TR6,L1,V1,R27,R3,i379,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,*late-classes*m10,R51,TR3,i385,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s398,The names of the classes the Java forms compiler made while the program prepared (its\n  deftypes, fns and defclasses using the Java forms, arbace.c2j.main's java-forms-classes): in the\n  tree, but j2g may leave one out (Clojure in its body it cannot analyze, F2.4), so a constant\n  naming one is looked up where used, as a class made at run time, and the classes holding it\n  initialize without it.v15,arbace.c2j.emit8,constantm10,R2,TR6,L1,V2,R25,R27,R3,i393,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,gsymm12,R2,TR6,L1,V2,R25,R52,R0,s146,A fresh name for a temporary of the emitted code, numbered per class being emitted (the\n  output does not depend on the program's gensym counter).R3,i406,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,local-symm12,R2,TR6,L1,V1,R53,R0,s95,The Java forms local of LocalBinding lb (its node b): its name and index, unique in a\n  method.R3,i414,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,identity-setm12,R2,TR6,L1,V1,R30,R0,s259,The objects of xs as a set by identity. A fn's closes map cannot be asked containsKey: its\n  keys, LocalBindings, hash by their index (Arbace's deterministic hashCode), and FnExpr.parse\n  renumbers a direct fn's arguments after its inner fns closed over them.R3,i420,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,closed?m10,R2,TR6,L1,V2,R25,R54,R3,i429,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,field-symm10,R2,TR6,L1,V1,R53,R3,i433,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,field-readm10,R2,TR6,L1,V3,R25,R54,R53,R3,i435,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,emitm8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,emit-unboxedm8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,emit-fn-class!m8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,emit-deftype-class!m8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,emit-bodym8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,jrt-lacks?m8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,prim-callm8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,spec-intrinsicm8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,primm10,R2,TR6,L1,V1,R55,R3,i443,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,can-prim?m10,R2,TR6,L1,V1,R56,R3,i445,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,box-ofm8,R29,TR3,i447,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit3,boxm12,R2,TR6,L1,V2,R57,Myn1,cm2,R11,R13,R0,s113,Form f of type c as a boxed value (emitBoxReturn: valueOf, long's Numbers.num being\n  Long.valueOf; void as nil).R3,i449,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,unbox-argm12,R2,TR6,L1,V3,R25,R57,Myn1,pm2,R11,R13,R0,s67,Boxed form f converted to parameter type p (HostExpr.emitUnboxArg).R3,i458,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit3,fi?m12,R2,TR6,L1,V1,Myn1,pm2,R11,R13,R0,s136,Is p a functional interface a fn argument is adapted to (Clojure 1.12's FISupport, as the\n  analysis decides it: Compiler$AST/fiMethod)?R3,i477,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,typed-argsm12,R2,TR6,L1,V3,R25,R58,R59,R0,s70,The arguments es as parameters of types ps (MethodExpr.emitTypedArgs).R3,i484,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,param-tagsm10,R2,TR6,L1,V1,R58,R3,i511,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,obj-arraym10,R2,TR6,L1,V2,R25,R59,R3,i513,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,var-valuem10,R2,TR6,L1,V2,R25,Myn1,vm2,R11,R60,R3,i516,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,line-metam10,R2,TR6,L1,V2,R57,R56,R3,i520,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,spec-localm12,R2,TR6,L1,V2,R25,R54,R0,s75,The worker's long and box of parameter lb (F6, spec-mask: {:l :b}), or nil.R3,i525,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,long-box*m10,R2,TR6,L1,V1,R57,R3,i531,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-localm10,R2,TR6,L1,V3,R25,R56,R61,R3,i533,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,*link*m10,R51,TR3,i551,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s209,While the call sites of vars may be linked, an atom of the sites' data in the order emitted\n  (arbace.c2j.main's compile-all binds it, and resolves the sites, link-form, once every class\n  is known); else nil.v15,arbace.c2j.emit8,link-keym12,R2,TR6,L1,V1,Myn1,vm2,R11,R60,R0,s355,The key of the compiled fn var v's root is at the end of the prepare run, for a call site\n  of v: the FnExpr of an evaluated fn (Compiler$EvalFn), or the class name of a compiled one\n  (Compiler$AOTFn, Compiler$AOTRestFn: the back end's own namespaces, compiled-back-end); nil\n  when v is dynamic, ^:dynamic, ^:redef or a macro, or its root is no such fn.R3,i557,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,deepm8,R29,TR3,i571,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,psigm12,R2,TR6,L1,V1,R62,R0,s156,The primitive signature of FnMethod mn (its node): {:params [Class...] :ret Class}, each\n  long, double or Object; nil when the method has no unboxed entry.R3,i580,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,intrinsic-probem8,R29,TR3,i590,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,long-valued-opsm8,R29,TR3,i590,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,walk-nodesm12,R2,TR6,L1,V2,R55,R57,R0,s117,Calls f on the node (map) of each Expr of the tree of e, not inside the methods of nested\n  fns, reifys and deftypes.R3,i592,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,spec-maskm12,R2,TR6,L1,V1,R62,R0,s631,Futamura F6, step 2: which parameters of FnMethod mn (its node) a speculative worker takes as\n  longs: those an operation of Numbers with fast paths takes as an Object operand (F3), when the\n  method also passes one of them, or such an operation of them, to a call of a var (where a\n  worker may take it unboxed: the worker's gain; a fn whose parameters only meet operations,\n  as arbace.core's +, would pay the dispatch for nothing); nil when there are none, or when the\n  method has an unboxed entry (psig), is variadic, has more than 4 parameters, or recurs to its\n  parameters (a recur would rebind them to values of any type).R3,i608,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,*var-fns*m10,R51,TR3,i652,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s441,The fn each var's last def in the recorded units defines (an IdentityHashMap Var → FnExpr,\n  var-fns; arbace.c2j.main's compile-all binds it): the code an F6 call site's linked call\n  expects, read from the analysis alone, so that the back end decides the same whether its own\n  namespaces and arbace.core run evaluated (their roots Compiler$EvalFns) or compiled\n  (Compiler$AOTFns, compiled-back-end: the fixpoint's G2); nil when not bound.v15,arbace.c2j.emit7,var-fnsm10,R6,L1,V1,R63,R0,s161,The index *var-fns* of units us (each the recorded [kind line column lb cb expr events]): by\n  each var, the FnExpr of its last top-level def whose init is a fn.R3,i660,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,site-fn-methodsm12,R2,TR6,L1,V2,Myn1,vm2,R11,R60,R64,R0,s89,The fixed-arity method of nargs parameters (its node) of the fn var v's last def defines.R3,i675,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,site-specm12,R2,TR6,L1,V2,R27,R64,R0,s82,The worker's mask (spec-mask) of the fixed arity nargs of the fn of var v, or nil.R3,i684,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,site-psigm12,R2,TR6,L1,V2,R27,R64,R0,s76,The primitive signature of the fixed arity nargs of the fn of var v, or nil.R3,i689,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,prim-argm12,R2,TR6,L1,V4,R25,R55,Myn1,pm2,R11,R13,R65,R0,s355,Argument e of a call of an unboxed entry, for its parameter of class p: {:binds (the\n  temporary of its value, evaluated once, in order), :gen (its boxed value, as the generic call\n  passes it), :pri (its value as the entry takes it: the boxed invoke's own conversion of the\n  boxed value, RT.longCast or doubleCast, unless the argument is of p already)}.R3,i694,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,spec-argm12,R2,TR6,L1,V4,R25,R55,R66,R65,R0,s413,Argument e of a call of a worker (F6, spec-mask), for its parameter taken as a long when k:\n  {:binds (its temporary, evaluated once, in order), :gen (its boxed value, for the generic\n  call), :pass (what the worker takes: the long and the box, or nil for a box the worker makes\n  when needed; the value for a parameter not taken as a long), :guard (the test that it is a\n  Long, nil when it is one by its type)}.R3,i727,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,emit-link-sitem12,R2,TR6,L2,V4,R25,R67,R68,R69,V6,R25,R67,R68,R69,R70,R71,R0,s440,A call of var fexpr (its node fnode) with args (at most 20), linked when its root's code is\n  known (link-key): a marker (c2j/link {...}) holding the emitted root, arguments and\n  temporaries, which link-form resolves into the guarded direct call or the generic one. With\n  out, the class a consumer converts the call's value to (long, double: the code's primitive\n  return), and conv, the consumer's conversion of the generic call's value.R3,i754,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,link-formm10,R6,L2,V3,R72,R73,R74,V5,R72,R73,R74,R75,R76,R0,s1435,The code of link marker m (emit-link-site): with cname, the code class of the fn the site\n  expects (its fixed arity of the call's argument count, variadic its required count or nil),\n  the guarded direct call; without, the generic call T1 makes. The guard: the root is a\n  compiled fn (Compiler$AOTFn, or Compiler$AOTRestFn for variadic code) whose class is the code\n  class's fn class (fn-class, one Class per code: Compiler$AOT/fnClass), one pointer compare\n  (Compiler$AOTFn/linked, which answers the fn's body or nil); then the code's invoke is called\n  directly with the fn as self, as the fn's invoke would call it. The root is read once, and\n  cast to IFn before the arguments when the guard fails, as the generic call casts it.\n\n  A call of a primitive fn's arity (:psig, F6) or of an arity with a worker (:smask, F6 step 2):\n  its arguments bound first, each once (unboxed when the entry takes it so and it is of that\n  type). For a primitive fn the direct call is of the code's unboxed entry, invokePrim (prims:\n  the code's signatures by arity), its value boxed as the boxed invoke boxes it, or left unboxed\n  for a consumer converting to the return's class (:out); for a worker it is of the code's\n  invokeSpec (specs: the code's masks by arity) when the arguments it takes as longs are Longs\n  (:guard), else of its invoke. The generic call is given the boxed arguments, its value\n  converted as the consumer converts it.R3,i791,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,link-targetm10,R6,L1,V3,R66,R77,Myn8,fn-namesm2,R11,R78,R0,s184,The class name and record of the code class link key k names (link-key), given the classes\n  made (name → record) and the fns' class names by FnExpr (fn-names); nil when none was made.R3,i850,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,site-keym12,R2,TR6,L1,V1,R56,R0,s79,The link key of invoke node n (link-key) when its call may be linked, else nil.R3,i858,R4,i1,R5,s18,arbace/c2j/emit.aem12,R2,TR6,L1,V4,R25,R55,Myn1,pm2,R11,R13,R71,R0,s233,The code of e, an invoke whose value a consumer converts to primitive class p by conv (a fn\n  of the boxed value's form), when it is a call of a primitive fn's arity returning p (F6):\n  its direct call's value left unboxed; else nil.R3,i866,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,emit-invokem10,R2,TR6,L1,V2,R25,R56,R3,i877,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,descriptorm10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i911,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,jrt-scanm8,R2,TR3,i919,R4,i1,R5,s18,arbace/c2j/emit.aem12,R2,TR6,L1,V1,Myn1,mm2,R11,R79,R0,s255,Is method m declared by a class jrt writes by hand (not a stand-in j2g's translation\n  replaces) without it in Go? j2g would translate a direct call to a throw; the member tables\n  (reflection) have such members, so compiled code calls them by reflection.R3,i922,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,method-callm12,R2,TR6,L1,V4,R25,Myn1,mm2,R11,R79,R65,R68,R0,s69,A call of resolved method m: static (target nil) or on target form t.R3,i941,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,compiled-interface?m12,R2,TR6,L1,V2,R25,Myn1,cm2,R11,R13,R0,s86,Is class c an interface of a namespace being compiled (gen-interface's, a protocol's)?R3,i954,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit20,emit-instance-methodm10,R2,TR6,L1,V3,R25,R56,R61,R3,i959,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-minR80,m8,R2,TR3,i1002,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-maxR81,m8,R2,TR3,i1003,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,*lbox*m12,R51,TR2,TR3,i1005,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s107,While set, how the Long case's result is given (spec-intrinsic: as the long itself), in\n  place of its box.v15,arbace.c2j.emit8,long-boxm10,R2,TR6,L1,V1,R57,R3,i1010,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-boxm10,R2,TR6,L1,V1,R57,R3,i1011,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-op2m12,R2,TR6,L1,V5,R82,R7,R83,R84,R85,R0,s202,The Long case of Numbers' binary operation op on longs x, y (symbols; r the result's local):\n  a form of the operation's result type, slow where Numbers would not answer a long; nil: not\n  an intrinsic.R3,i1013,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-op2m12,R2,TR6,L1,V3,R82,R7,R83,R0,s166,The Double case (both operands Double) of Numbers' binary operation op (DoubleOps: the '\n  operations are the others, a difference the sum with the negation), or nil.R3,i1048,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-op1m12,R2,TR6,L1,V3,R82,R7,R84,R0,s70,The Long case of Numbers' unary operation op on long x, as long-op2's.R3,i1063,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-op1m12,R2,TR6,L1,V2,R82,R7,R0,s64,The Double case of Numbers' unary operation op, as double-op2's.R3,i1079,R4,i1,R5,s18,arbace/c2j/emit.aem12,R2,TR6,L1,V1,Myn1,mm2,R11,R79,R0,s124,Is Numbers' static method m one of the boxed operations with fast paths? Its signature\n  ([:o :j ...]) when it is, else nil.R3,i1091,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,numbers-intrinsicm12,R2,TR6,L1,V3,R25,Myn1,mm2,R11,R79,R68,R0,s257,The call of Numbers' static method m on args with its fast paths, or nil when m is not one\n  of the boxed operations above. An Object operand that is a worker's long parameter (F6,\n  spec-local) is a Long: no test, its long as is, its box for the slow path.R3,i1105,R4,i1,R5,s18,arbace/c2j/emit.aeS17,s4,decPs18,unchecked_multiplys8,multiplys8,quotients6,minusPs9,multiplyPs5,minuss13,unchecked_decs4,addPs4,incPs3,incs9,remainders13,unchecked_adds3,adds13,unchecked_incs3,decs15,unchecked_minusm8,R2,TR3,i1145,R4,i1,R5,s18,arbace/c2j/emit.ae")

var Lit_421 *jrt.String = jrt.Intern("arbace.c2j.emit$eval31000004$loading__1927001464__auto____31000005")

var Lit_422 *jrt.String = jrt.Intern("arbace.c2j.emit$eval31000008$fn__31000009")

var Lit_423 *jrt.String = jrt.Intern("arbace.c2j.emit$node")

var Lit_424 *jrt.String = jrt.Intern("arbace.c2j.emit$fail")

var Lit_425 *jrt.String = jrt.Intern("arbace.c2j.emit$destub")

var Lit_426 *jrt.String = jrt.Intern("arbace.c2j.emit$type_sym")

var Lit_427 *jrt.String = jrt.Intern("arbace.c2j.emit$tagged")

var Lit_428 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_")

var Lit_429 *jrt.String = jrt.Intern("arbace.c2j.emit$runtime_class_QMARK_")

var Lit_430 *jrt.String = jrt.Intern("arbace.c2j.emit$public_QMARK_")

var Lit_431 *jrt.String = jrt.Intern("arbace.c2j.emit$top_name")

var Lit_432 *jrt.String = jrt.Intern("arbace.c2j.emit$pool")

var Lit_433 *jrt.String = jrt.Intern("arbace.c2j.emit$const_field")

var Lit_434 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_list_array")

var Lit_435 *jrt.String = jrt.Intern("arbace.c2j.emit$char_form")

var Lit_436 *jrt.String = jrt.Intern("arbace.c2j.emit$double_form")

var Lit_437 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value")

var Lit_438 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_kind")

var Lit_439 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_shared_QMARK_")

var Lit_440 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_parts")

var Lit_441 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_str")

var Lit_442 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode")

var Lit_443 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields")

var Lit_444 *jrt.String = jrt.Intern("arbace.c2j.emit$const_type")

var Lit_445 *jrt.String = jrt.Intern("arbace.c2j.emit$constant")

var Lit_446 *jrt.String = jrt.Intern("arbace.c2j.emit$gsym")

var Lit_447 *jrt.String = jrt.Intern("arbace.c2j.emit$local_sym")

var Lit_448 *jrt.String = jrt.Intern("arbace.c2j.emit$identity_set")

var Lit_449 *jrt.String = jrt.Intern("arbace.c2j.emit$closed_QMARK_")

var Lit_450 *jrt.String = jrt.Intern("arbace.c2j.emit$field_sym")

var Lit_451 *jrt.String = jrt.Intern("arbace.c2j.emit$field_read")

var Lit_452 *jrt.String = jrt.Intern("arbace.c2j.emit$prim")

var Lit_453 *jrt.String = jrt.Intern("arbace.c2j.emit$can_prim_QMARK_")

var Lit_454 *jrt.String = jrt.Intern("arbace.c2j.emit$box")

var Lit_455 *jrt.String = jrt.Intern("arbace.c2j.emit$unbox_arg")

var Lit_456 *jrt.String = jrt.Intern("arbace.c2j.emit$fi_QMARK_")

var Lit_457 *jrt.String = jrt.Intern("arbace.c2j.emit$typed_args")

var Lit_458 *jrt.String = jrt.Intern("arbace.c2j.emit$param_tags")

var Lit_459 *jrt.String = jrt.Intern("arbace.c2j.emit$obj_array")

var Lit_460 *jrt.String = jrt.Intern("arbace.c2j.emit$var_value")

var Lit_461 *jrt.String = jrt.Intern("arbace.c2j.emit$line_meta")

var Lit_462 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_local")

var Lit_463 *jrt.String = jrt.Intern("arbace.c2j.emit$long_box_STAR_")

var Lit_464 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_local")

var Lit_465 *jrt.String = jrt.Intern("arbace.c2j.emit$link_key")

var Lit_466 *jrt.String = jrt.Intern("arbace.c2j.emit$psig")

var Lit_467 *jrt.String = jrt.Intern("arbace.c2j.emit$walk_nodes")

var Lit_468 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask")

var Lit_469 *jrt.String = jrt.Intern("arbace.c2j.emit$var_fns")

var Lit_470 *jrt.String = jrt.Intern("arbace.c2j.emit$site_fn_methods")

var Lit_471 *jrt.String = jrt.Intern("arbace.c2j.emit$site_spec")

var Lit_472 *jrt.String = jrt.Intern("arbace.c2j.emit$site_psig")

var Lit_473 *jrt.String = jrt.Intern("arbace.c2j.emit$prim_arg")

var Lit_474 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_arg")

var Lit_475 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site")

var Lit_476 *jrt.String = jrt.Intern("arbace.c2j.emit$link_form")

var Lit_477 *jrt.String = jrt.Intern("arbace.c2j.emit$link_target")

var Lit_478 *jrt.String = jrt.Intern("arbace.c2j.emit$site_key")

var Lit_479 *jrt.String = jrt.Intern("arbace.c2j.emit$prim_call")

var Lit_480 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke")

var Lit_481 *jrt.String = jrt.Intern("arbace.c2j.emit$descriptor")

var Lit_482 *jrt.String = jrt.Intern("arbace.c2j.emit$fn__31000286")

var Lit_483 *jrt.String = jrt.Intern("arbace.c2j.emit$jrt_lacks_QMARK_")

var Lit_484 *jrt.String = jrt.Intern("arbace.c2j.emit$method_call")

var Lit_485 *jrt.String = jrt.Intern("arbace.c2j.emit$compiled_interface_QMARK_")

var Lit_486 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_instance_method")

var Lit_487 *jrt.String = jrt.Intern("arbace.c2j.emit$long_box")

var Lit_488 *jrt.String = jrt.Intern("arbace.c2j.emit$double_box")

var Lit_489 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op2")

var Lit_490 *jrt.String = jrt.Intern("arbace.c2j.emit$double_op2")

var Lit_491 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op1")

var Lit_492 *jrt.String = jrt.Intern("arbace.c2j.emit$double_op1")

var Lit_493 *jrt.String = jrt.Intern("arbace.c2j.emit$intrinsic_probe")

var Lit_494 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic")

var Lit_495 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn3,ctxyn1,eyn1,tkn3,dockn4,linekn6,columnkn4,fileyn1,nyn8,unboxed?kn3,tagyn23,java.lang.reflect.Fieldyn4,top?yn3,symyn2,esyn2,lbyn4,inityn2,oxyn10,nil-localsyn4,bodyys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys17,java.lang.Integer7,valueOfys17,java.lang.Boolean7,valueOfys19,java.lang.Character7,valueOfys15,java.lang.Float7,valueOfys15,java.lang.Short7,valueOfys14,java.lang.Byte7,valueOfyn1,fyn6,Stringyn5,Classyn2,mnyn6,paramsyn1,&yn5,entryyn4,longyn6,doubleyn3,intyn7,booleanyn4,charyn5,floatyn5,shortyn4,byteyn3,tagyn1,kyn4,kindyn4,lineyn6,columnyn1,_yn4,expryn6,eventsyn7,classesyn15,runtime-classesyn8,fn-namesyn5,poolsyn3,srcyn5,unitsyn1,cyn11,children-ofyn4,nameyn7,extendsyn7,methodsm12,R0,TR1,L1,V3,R2,R3,R4,R5,s487,Argument e of a worker's call for a parameter it takes as a long (F6, spec-arg), when e is an\n  operation of Numbers with fast paths whose Object operands are all the calling worker's long\n  parameters: its Long case computed as a long, not boxed (the worker boxes it if it needs to,\n  as the generic call's argument would have been boxed, once); its other case's value (Numbers'\n  own: an overflow promoted, a ratio) in temporary t, nil in the Long case. As spec-arg's\n  result, or nil.R6,i1150,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit18,emit-static-methodm10,R0,TR1,L1,V3,R2,R9,R10,R6,i1183,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,field-ok?m10,R0,TR1,L1,V2,R2,Myn1,fm2,R11,R12,R6,i1197,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,emit-instance-fieldm10,R0,TR1,L1,V3,R2,R9,R10,R6,i1200,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,emit-static-fieldm10,R0,TR1,L1,V3,R2,R9,R10,R6,i1209,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-newm10,R0,TR1,L1,V2,R2,R9,R6,i1217,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-defm10,R0,TR1,L1,V3,R2,R9,R13,R6,i1226,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,emit-assignm10,R0,TR1,L1,V2,R2,R9,R6,i1244,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,coll-callm10,R0,TR1,L1,V3,R14,R15,R2,R6,i1266,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,emit-ifm10,R0,TR1,L1,V3,R2,R9,R10,R6,i1269,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,emit-binding-initm12,R0,TR1,L1,V3,R2,R16,R17,R5,s69,A let or loop binding [sym init] of LocalBinding lb (LetExpr.doEmit).R6,i1278,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-letm10,R0,TR1,L1,V3,R2,R9,R10,R6,i1287,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-recurm10,R0,TR1,L1,V2,R2,R9,R6,i1294,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit13,body-instancem12,R0,TR1,L1,V3,R2,R18,R19,R5,s228,A new instance of fn or reify class ox (its node), its closed-over values from the current\n  method: (new C closed...) (ObjExpr.emit); letfn's own locals nil (set after). A fn's is its\n  code (SA141), which fn-wrap makes the fn.R6,i1315,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,fn-wrapm12,R0,TR1,L1,V3,R2,R18,R20,R5,s135,The fn of fn ox (its node) whose code is form body: a Compiler$AOTFn, or a\n  Compiler$AOTRestFn of the variadic arity's required count.R6,i1328,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,fn-instancem12,R0,TR1,L1,V3,R2,R18,R19,R5,s33,A new fn or reify (ox, its node).R6,i1351,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-letfnm10,R0,TR1,L1,V3,R2,R9,R10,R6,i1357,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-trym10,R0,TR1,L1,V3,R2,R9,R10,R6,i1374,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,emit-casem10,R0,TR1,L1,V3,R2,R9,R10,R6,i1383,R7,i1,R8,s18,arbace/c2j/emit.aeR21,R22,R23,R24,R25,R26,R27,R28,m8,R0,TR6,i1430,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,box-primm12,R0,TR1,L1,V2,R29,R9,R5,s200,Form f of node n boxed when it is of a primitive type (emitBoxReturn: valueOf, long's\n  Numbers.num being Long.valueOf), so that emit's code is always a reference, as the bytecode's\n  emit leaves one.R6,i1436,R7,i1,R8,s18,arbace/c2j/emit.aem10,R1,L1,V2,R2,R3,R5,s59,Code for analyzed node e, its value boxed (an Expr's emit).R6,i1447,R7,i1,R8,s18,arbace/c2j/emit.aem10,R1,L1,V2,R2,R3,R5,s72,Code for analyzed node e, its value of its primitive type (emitUnboxed).R6,i1523,R7,i1,R8,s18,arbace/c2j/emit.aem12,R0,TR1,L1,V1,R29,R5,s160,Form f realized throughout (the emitters build lazy seqs; what they record, the constants\n  and the classes, must be recorded before it is read), metadata kept.R6,i1555,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,simple-namem10,R0,TR1,L1,V1,Myn6,binarym2,R11,R30,R6,i1564,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,throws?m12,R0,TR1,L1,V1,R3,R5,s86,Does node e end in a throw (a form that does not complete, which needs no conversion)?R6,i1567,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,ret-bodym12,R0,TR1,L1,V3,R2,R20,Myn3,retm2,R11,R31,R5,s148,A deftype's method body as returned in type ret (ObjMethod.emitBody): unboxed when it can be,\n  else boxed then cast or unboxed as ASM's unbox does.R6,i1576,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,method-bodym12,R0,TR1,L1,V5,R2,R32,R33,R34,V1,R35,R5,s302,The body of FnMethod or NewInstanceMethod m (its node), in the method's context: wrapped in\n  a loop over its parameters when a recur targets them. With entry, the body of a fn method's\n  unboxed entry (F6, psig): its primitive parameters taken as they are, its value of the\n  signature's return class.R6,i1606,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,param-symm10,R0,TR1,L1,V1,R16,R6,i1649,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,prim-classesR36,R37,R38,R39,R40,R41,R42,R43,m8,R0,TR6,i1655,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,tag-classm12,R0,TR1,L1,V1,R44,R5,s70,The class a field's tag names (Compiler.tagClass): Object without one.R6,i1659,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,box-classm10,R0,TR1,L1,V1,Myn1,cm2,R11,R31,R6,i1668,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit16,class-interfacesm12,R0,TR1,L1,V2,R2,R18,R5,s179,The interfaces of a deftype's or reify's class (its node ox), as the analysis made the\n  class: their names. A class of the program cannot implement an interface made at run time.R6,i1672,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,field-modsm12,R0,TR1,L1,V2,R18,R16,R5,s104,The modifiers of a deftype's field lb (ObjExpr.compile): volatile, mutable (package), or\n  public final.R6,i1683,R7,i1,R8,s18,arbace/c2j/emit.aem10,R1,L1,V2,R2,R18,R5,s202,Defines deftype ox's class (its node), a top-level class named as the deftype, once:\n  its fields, constructors, getBasis (and create for a record), and methods\n  (NewInstanceExpr.compile, emitStatics).R6,i1693,R7,i1,R8,s18,arbace/c2j/emit.aem10,R1,L1,V2,R2,R18,R5,s109,Defines the class of fn or reify ox (its node) once, in the classes being emitted; returns\n  its binary name.R6,i1761,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,unit-methodm12,R0,TR1,L1,V3,R2,R45,V7,R46,R47,R48,R49,R49,R50,R51,R5,s96,The static method unitK of a source's loader class: unit u's events made again, then its\n  code.R6,i1908,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,unit-nsm12,R0,TR1,L1,V1,V6,R46,R49,R49,R49,R49,R50,R5,s79,The namespace unit u was analyzed in: its fn's (kind 1) or its def's, else nil.R6,i1973,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,loader-part-unitsl100,m8,R6,i1984,R7,i1,R8,s18,arbace/c2j/emit.aeR5,s251,The most units a source's loader class holds itself; a source of more is split into parts of\n  as many (SA210): j2g analyzes classes in parallel, one class on one thread (arbace.core's 903\n  units were one task of 9 to 14 s, the last of the analysis).v15,arbace.c2j.emit15,unnamed-packagem10,R1,L1,V1,Myn2,nmm2,R11,R30,R5,s484,The option placing top-level class nm in Java's unnamed package when its name has no\n  package: the classes of a namespace of one segment (user: its holder user, the fns\n  user$eval1$fn__2, the loader of a source user.ae, user__init), named as the JVM names them,\n  where the Java forms would put a simple name in the package of the namespace they are read in\n  (arbace). The tree's files import them (arbace.c2j.main), so that a class of a package can name\n  them, as Java could not.R6,i1990,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,emit-sourcem10,R1,L1,V6,R52,R53,R54,R55,R56,R57,R5,s259,The Java forms of source path src (scriptbase.ae), compiled from its units: the loader\n  class SCRIPTBASE__init's form and the fn classes made, into the atom classes (fn-names: the\n  fns' class names by their FnExpr, an IdentityHashMap shared by the sources).R6,i2000,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,class-formm12,R0,TR1,L1,V4,R58,R59,R13,R55,R5,s289,The defclass form of class c (its record: a fn's, a reify's, a deftype's, an interface's, or\n  a holder of nested classes), its nested classes inside; at the top its full name and the\n  constants it shares with them (pools: top → its pool), else a static member class by its\n  simple name.R6,i2066,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,class-formsm10,R1,L1,V2,R52,R55,R5,s261,The top-level Java forms holding every class of classes (name → record), nested as their\n  binary names nest, with holder classes made for the missing levels (a namespace's fns nest\n  in a holder named as the namespace); pools: the top-level classes' constants.R6,i2102,R7,i1,R8,s18,arbace/c2j/emit.aev15,arbace.c2j.emit16,interface-recordm10,R1,L1,V3,R60,R61,R62,R5,s133,The record of an interface made by gen-interface (events iface and imethod): name, the\n  interfaces it extends, its abstract methods.R6,i2124,R7,i1,R8,s18,arbace/c2j/emit.ae")

var Lit_496 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic")

var Lit_497 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_method")

var Lit_498 *jrt.String = jrt.Intern("arbace.c2j.emit$field_ok_QMARK_")

var Lit_499 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_instance_field")

var Lit_500 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_field")

var Lit_501 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_new")

var Lit_502 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_def")

var Lit_503 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_assign")

var Lit_504 *jrt.String = jrt.Intern("arbace.c2j.emit$coll_call")

var Lit_505 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_if")

var Lit_506 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_binding_init")

var Lit_507 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_let")

var Lit_508 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_recur")

var Lit_509 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance")

var Lit_510 *jrt.String = jrt.Intern("arbace.c2j.emit$fn_wrap")

var Lit_511 *jrt.String = jrt.Intern("arbace.c2j.emit$fn_instance")

var Lit_512 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn")

var Lit_513 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try")

var Lit_514 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case")

var Lit_515 *jrt.String = jrt.Intern("arbace.c2j.emit$box_prim")

var Lit_516 *jrt.String = jrt.Intern("arbace.c2j.emit$emit")

var Lit_517 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_unboxed")

var Lit_518 *jrt.String = jrt.Intern("arbace.c2j.emit$deep")

var Lit_519 *jrt.String = jrt.Intern("arbace.c2j.emit$simple_name")

var Lit_520 *jrt.String = jrt.Intern("arbace.c2j.emit$throws_QMARK_")

var Lit_521 *jrt.String = jrt.Intern("arbace.c2j.emit$ret_body")

var Lit_522 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body")

var Lit_523 *jrt.String = jrt.Intern("arbace.c2j.emit$param_sym")

var Lit_524 *jrt.String = jrt.Intern("arbace.c2j.emit$tag_class")

var Lit_525 *jrt.String = jrt.Intern("arbace.c2j.emit$box_class")

var Lit_526 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces")

var Lit_527 *jrt.String = jrt.Intern("arbace.c2j.emit$field_mods")

var Lit_528 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_")

var Lit_529 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_")

var Lit_530 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method")

var Lit_531 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_ns")

var Lit_532 *jrt.String = jrt.Intern("arbace.c2j.emit$unnamed_package")

var Lit_533 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source")

var Lit_534 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form")

var Lit_535 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms")

var Lit_536 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record")
