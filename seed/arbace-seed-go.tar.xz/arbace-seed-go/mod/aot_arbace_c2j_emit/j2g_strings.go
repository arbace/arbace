//line j2g_strings.ae:1
package aot_arbace_c2j_emit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.j2g.jrtyn3,jrtyn16,arbace.j2g.namesyn2,nmkn3,dockn4,selfkn3,tagkn15,runtime-classeskn12,unit-proxieskn5,poolskn4,namekn6,constskn9,const-mapkn12,const-prefixkn3,clskn4,prevyn3,newys16,java.lang.Object1,1yn14,unchecked-charys16,java.lang.Double16,longBitsToDoublekn4,elseys17,java.lang.Boolean4,TRUEys17,java.lang.Boolean5,FALSEys17,java.lang.Integer7,valueOfyn13,unchecked-intys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys19,java.lang.Character7,valueOfys14,arbace.lang.RT22,classForNameNonLoadingys18,arbace.lang.Symbol6,internkn10,param-tagsyn16,java.lang.Stringys14,arbace.lang.RT7,keywordys14,arbace.lang.RT3,varys21,arbace.lang.Namespace12,findOrCreateyn18,arbace.lang.Symbolys14,arbace.lang.RT3,mapys17,arbace.lang.Tuple6,createyn16,java.lang.Objectys14,arbace.lang.RT6,vectorys29,arbace.lang.PersistentHashSet5,EMPTYys29,arbace.lang.PersistentHashSet6,createys26,arbace.lang.PersistentList6,createyn14,java.util.Listys16,java.util.Arrays6,asListys23,java.util.regex.Pattern7,compileys14,arbace.lang.RT10,readStringyn9,.withMetayn4,castyn16,arbace.lang.IObjyn26,arbace.lang.IPersistentMapkn3,nilkn6,stringkn7,booleankn3,intkn4,longkn6,doublekn4,charkn5,classkn6,symbolkn7,keywordkn3,varkn2,nskn3,mapkn6,vectorkn3,setkn4,listkn7,patternkn4,readyn5,fieldyn10,const-poolkn6,statickn5,finalkn7,privateys24,arbace.lang.Compiler$AOT4,poolyn3,intks3,c2j2,nnyn4,agetyn15,arbace.lang.Varyn19,arbace.lang.Keywordyn15,java.lang.Classkn7,gensymskn3,idxkn6,closedyn4,thiskn4,primkn16,canEmitPrimitiveyn2,dokn14,unchecked-mathyn13,.booleanValueyn17,java.lang.Booleanyn10,.charValueyn19,java.lang.Characterys30,arbace.lang.Compiler$Evaluator7,fiAdaptys14,arbace.lang.RT16,uncheckedIntCastys14,arbace.lang.RT7,intCastyn4,longyn15,unchecked-floatyn4,.getyn11,.getRawRootkn4,lineks3,c2j4,linekn1,bkn4,oncekn11,shouldClearkn12,canBeClearedkn11,bindingPrimkn5,isArgkn8,self-symyn3,letyn2,t-yn4,set!kn7,dynamickn5,redefkn5,macrokn2,idkn3,keykn6,callerkn4,rootkn4,argskn4,symskn1,rkn1,wkn1,fys3,c2j4,linkyn7,.invokeyn15,arbace.lang.IFnyn30,arbace.lang.Compiler$AOTRestFnyn26,arbace.lang.Compiler$AOTFnyn2,ifyn4,nil?kn2,fnkn4,kindkn5,fexprkn2,opkn10,isProtocolkn10,protocolOnyn8,.applyToys20,arbace.lang.ArraySeq6,createkn8,onMethodyn3,andyn9,instance?yn3,notys24,arbace.lang.Compiler$AOT5,isDynkn7,classeskn7,standinkn5,funcskn9,interfacekn6,methodkn11,dyn-guardedkn6,targetks15,arbace.c2j.emit5,localkn10,target-symkn15,qualifyingClassyn5,some?ys21,arbace.lang.Reflector20,invokeInstanceMethodkn10,methodNameys21,arbace.lang.Reflector27,invokeInstanceMethodOfClassyn6,doubleyn13,unchecked-addyn18,unchecked-multiplyyn2,>=yn7,bit-andyn7,bit-xoryn2,==yn1,<yn2,oryn16,unchecked-divideyn18,unchecked-subtractyn2,<=yn6,bit-oryn19,unchecked-remainderyn14,bit-shift-leftyn1,>yn15,bit-shift-rightyn16,unchecked-negateyn13,unchecked-decyn13,unchecked-inckn1,okn1,jkn1,xyn1,xyn4,slowyn1,yyn1,ryn10,.longValueyn14,java.lang.Longyn12,.doubleValueyn16,java.lang.Doubleys21,arbace.lang.Reflector18,invokeStaticMethodkn1,ckn5,fieldys21,arbace.lang.Reflector25,invokeNoArgInstanceMemberyn7,booleankn9,fieldNamekn12,requireFieldys21,arbace.lang.Reflector14,getStaticFieldkn4,ctorys21,arbace.lang.Reflector17,invokeConstructorkn12,initProvidedkn4,initkn4,metayn9,.bindRootyn8,.setMetakn9,isDynamicyn11,.setDynamickn3,valyn4,.setys21,arbace.lang.Reflector16,setInstanceFieldkn8,testExprkn8,thenExprkn8,elseExprkn12,bindingInitskn6,isLoopkn11,loop-localskn7,bindingkn4,bodyyn4,loopkn10,loopLocalsyn5,recurkn12,method-recurkn13,method-localskn12,supportsMetakn6,closeskn8,variadicys24,arbace.lang.Compiler$AOT7,fnClassyn3,trykn7,tryExpryn5,catchkn2,lbkn7,handlerkn10,catchExprskn11,finallyExpryn7,finallykn4,exprkn5,shiftkn4,maskyn11,bit-and-intyn19,bit-shift-right-intkn5,testskn5,thenskn8,testTypekn7,defaultkn9,skipCheckkn13,hash-identityyn4,whenys16,arbace.lang.Util5,equivyn5,breakyn10,identical?yn6,switchys16,arbace.lang.Util4,hashyn9,.intValueyn16,java.lang.Numberyn5,labelkn11,defaultExprkn9,isDeftypekn4,typekn4,collys26,arbace.lang.PersistentList5,EMPTYys28,arbace.lang.PersistentVector5,EMPTYys30,arbace.lang.PersistentArrayMap5,EMPTYkn5,exprskn1,kkn2,kwkn1,nkn3,strkn1,vkn7,keyvalsys30,arbace.lang.Compiler$Evaluator11,monitorExityn5,throwyn19,java.lang.Throwablekn7,excExprys14,arbace.lang.RT11,arrayToListys30,arbace.lang.Compiler$Evaluator12,monitorEnteryn12,.importClassyn21,arbace.lang.Namespaceyn6,.derefys14,arbace.lang.RT10,CURRENT_NSkn5,textsys24,arbace.lang.Compiler$AOT9,strConcatys16,java.lang.String1,1ys14,arbace.lang.RT3,setkn4,keysyn11,.isInstancekn8,reqParmskn8,restParmkn9,argLocalskn8,retClassys14,arbace.lang.RT10,doubleCastys14,arbace.lang.RT8,longCastkn13,compiledClasskn3,symkn16,volatile-mutablekn8,volatilekn22,unsynchronized-mutablekn6,publickn4,objxkn12,hintedFieldskn12,altCtorDropsyn11,constructoryn6,super.kn6,columnyn3,m__yn6,methodkn7,deftypekn5,superkn10,interfaceskn7,memberskn6,sourceks15,arbace.c2j.emit7,pendingyn5,this.yn8,getBasisyn29,arbace.lang.IPersistentVectoryn6,createys19,arbace.lang.Keyword6,internyn6,.valAtyn8,.withoutys14,arbace.lang.RT9,seqOrElsekn7,mutablekn7,methodskn8,fn-nameskn8,onceOnlyyn4,selfyn6,meta__yn8,.-__metakn10,isVariadicyn8,doInvokeyn6,invokeyn8,fn-classyn6,__metayn4,metayn8,withMetayn1,mkn5,reifyys14,arbace.lang.RT4,consys14,arbace.lang.RT3,seqys14,arbace.lang.RT16,loadClassForNameys24,arbace.lang.Compiler$AOT2,atkn7,packagekn4,formyn8,defclassks3,c2j6,sourceyn4,loadyn4,initks3,c2j4,codekn6,holderkn7,extendskn10,implementskn8,abstractv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.c2j.emitm2,R8,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).v11,arbace.core5,some?v15,arbace.c2j.emit10,node-cachev11,arbace.core5,assocR9,v11,arbace.core7,ex-infov13,arbace.string12,starts-with?v11,arbace.core4,subsv11,arbace.core6,symbolv11,arbace.core3,strv15,arbace.c2j.emit8,type-symv15,arbace.c2j.emit6,destubv11,arbace.core9,vary-metaR10,v15,arbace.c2j.emit10,prim-namesv15,arbace.c2j.emit10,registeredv11,arbace.core3,notv11,arbace.core5,swap!v11,arbace.core9,contains?R11,v15,arbace.c2j.emit11,registered?v11,arbace.core8,identityR12,l0,R13,v11,arbace.core4,atomR14,R15,R16,R17,R18,R19,v11,arbace.core4,namev11,arbace.core6,updatev11,arbace.core4,listR20,R21,v11,arbace.core4,mapvv15,arbace.c2j.emit10,emit-valuev11,arbace.core4,not=c92,R22,R23,V2,nTv11,arbace.core7,string?v11,arbace.core6,class?v11,arbace.core7,symbol?v11,arbace.core8,keyword?v11,arbace.core4,var?v15,arbace.c2j.emit4,failv11,arbace.core5,classv11,arbace.core4,map?v11,arbace.core7,vector?v11,arbace.core4,seq?v11,arbace.core5,list?R24,v11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsR25,R26,R27,R28,R29,R30,v15,arbace.c2j.emit11,double-formR31,v15,arbace.c2j.emit9,char-formC17,java.lang.BooleanC14,java.lang.ByteC19,java.lang.CharacterC16,java.lang.DoubleC15,java.lang.FloatC17,java.lang.IntegerC14,java.lang.LongC15,java.lang.ShortR32,v11,arbace.core9,with-metaR33,m2,R34,V2,R35,R35,v11,arbace.core9,namespaceR36,m2,R34,V2,R35,R35,R37,m2,R34,V2,R35,R35,R38,m2,R34,V1,R39,R33,m2,R34,V2,R35,R35,R40,m2,R34,V1,R21,v15,arbace.c2j.emit15,emit-list-arrayv11,arbace.core6,mapcatv11,arbace.core5,list*R41,R34,v11,arbace.core3,vecv11,arbace.core6,repeatR42,v11,arbace.core3,mapR43,m2,R34,V1,R21,v11,arbace.core6,empty?R44,R45,m2,R34,V1,R21,v11,arbace.core3,seqR46,m2,R34,V1,R47,R48,m2,R34,V1,R21,R49,m2,R34,V1,R35,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*print-dup*R50,m2,R34,V1,R35,R51,R52,R53,R52,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,R72,v15,arbace.c2j.emit9,pool-kindv11,arbace.core6,concatv15,arbace.c2j.emit12,pool-partialc44,v15,arbace.c2j.emit12,pool-shared?c82,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv15,arbace.c2j.emit11,pool-encodev11,arbace.core10,chunk-restv11,arbace.core4,nextc77,v15,arbace.c2j.emit8,pool-strc110,c84,c70,c118,c107,c115,c112,c100,c109,c80,c86,c68,c67,c66,c90,c74,c83,c73,c99,c78,c114,c108,c121,c69,c105,c76,v11,arbace.core6,removev11,arbace.core4,run!v15,arbace.c2j.emit10,pool-partsv11,arbace.core4,intov11,arbace.core11,map-indexedR73,v15,arbace.c2j.emit6,taggedR74,m6,R75,TR76,TR77,TR78,m2,R34,V2,R35,R79,R28,v11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR73,m6,R75,TR76,TR80,TR42,R81,R74,R28,R52,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core4,consm6,R75,TR76,TR80,Tv11,arbace.core4,restR82,R83,R84,R42,v15,arbace.c2j.emit14,runtime-class?v15,arbace.c2j.emit14,*late-classes*v15,arbace.c2j.emit11,const-fieldv15,arbace.c2j.emit10,const-typeR32,m2,R34,V1,R35,R85,v11,arbace.core4,fnilv11,arbace.core3,incR86,R87,v15,arbace.c2j.emit9,field-symR88,R89,v15,arbace.c2j.emit4,nodeR90,R91,v15,arbace.c2j.emit6,box-ofC16,java.lang.ObjectR92,v15,arbace.c2j.emit7,public?R93,R52,R94,R95,R52,R96,m2,R34,V1,R42,R52,v15,arbace.c2j.emit12,emit-unboxedv15,arbace.c2j.emit4,emitv15,arbace.c2j.emit3,fi?v15,arbace.c2j.emit9,unbox-argR97,v15,arbace.c2j.emit8,constantR98,R99,m2,R34,V1,R100,R101,R20,R21,R82,R102,R103,R104,R105,R106,v15,arbace.c2j.emit7,closed?v15,arbace.c2j.emit10,field-readR107,R108,R109,R110,R111,R112,R88,v15,arbace.c2j.emit9,local-symR113,R114,R114,R115,R116,R117,R118,v15,arbace.c2j.emit4,deepv15,arbace.c2j.emit9,var-valueR119,v15,arbace.c2j.emit6,*link*R120,R121,v15,arbace.c2j.emit8,top-nameR122,R123,R124,R125,v15,arbace.c2j.emit4,gsymR126,R127,R2,R128,v11,arbace.core6,secondv11,arbace.core8,to-arrayR129,R52,R130,R131,R132,R113,R130,R133,R134,R52,R130,R133,R129,R129,R52,R134,R135,R136,R137,R138,R139,R140,v15,arbace.c2j.emit8,link-keyR129,R52,R130,R141,R52,R130,R142,m2,R34,V1,R21,v15,arbace.c2j.emit9,obj-arrayR143,v15,arbace.c2j.emit14,emit-link-siteR113,R133,v15,arbace.c2j.emit3,boxv15,arbace.c2j.emit10,param-tagsR52,v15,arbace.c2j.emit10,typed-argsR129,R52,R130,R144,R145,R146,R147,v13,arbace.string7,replacev14,arbace.j2g.jrt4,scanv15,arbace.c2j.emit8,jrt-scanR148,R149,v16,arbace.j2g.names13,go-class-namev11,arbace.core5,applyv15,arbace.c2j.emit10,descriptorv16,arbace.j2g.names11,method-baseR150,v14,arbace.j2g.jrt14,struct-methodsv14,arbace.j2g.jrt13,iface-methodsv16,arbace.j2g.names9,impl-nameR52,R151,R152,v15,arbace.c2j.emit19,compiled-interface?R153,R154,R155,R156,v15,arbace.c2j.emit10,jrt-lacks?v15,arbace.c2j.emit11,method-callv15,arbace.c2j.emit20,emit-instance-methodR157,R113,R133,R144,R158,R147,R159,m2,R34,V3,R42,R35,R21,R160,R161,R159,m2,R34,V3,R42,R35,R21,R29,m2,R34,V1,R100,R30,m2,R34,V1,R162,R113,R133,v15,arbace.c2j.emit8,long-boxR163,R164,R165,R166,R167,R167,R144,R146,R168,v15,arbace.c2j.emit8,long-minR165,R166,R167,R167,R144,R146,R144,R168,R169,R170,R168,R168,R171,R169,R163,R166,R165,R167,R172,R173,R172,R174,R164,R133,R175,R168,R176,R133,R171,R168,R177,R168,R178,v15,arbace.c2j.emit10,double-boxR163,R164,R169,R165,R163,R179,R173,R169,R168,R133,R168,R179,R180,R169,R177,v15,arbace.c2j.emit8,long-maxR181,R181,R179,R180,R168,R179,R172,d4607182418800017408,R169,d0,R177,d0,R163,d4607182418800017408,R168,d0,C19,arbace.lang.NumbersR182,R183,R184,V1,R182,v15,arbace.c2j.emit8,long-op1R185,R186,v11,arbace.core4,someS1,R182,v11,arbace.core6,every?S2,R182,R183,v15,arbace.c2j.emit8,long-op2R185,R187,R186,R188,R189,R52,R190,R191,R52,R192,v11,arbace.core4,keepv11,arbace.core6,vectorR145,R144,v11,arbace.core5,rangel1,S1,R182,v15,arbace.c2j.emit10,double-op1v15,arbace.c2j.emit10,double-op2R113,R133,R190,R113,R133,R192,R113,v15,arbace.c2j.emit17,numbers-intrinsicv15,arbace.c2j.emit18,emit-static-methodR193,m2,R34,V3,R84,R35,R21,R194,R195,v15,arbace.c2j.emit9,field-ok?R52,R196,m2,R34,V3,R42,R35,R197,R198,R199,R200,m2,R34,V2,R84,R35,R201,R202,m2,R34,V2,R84,R21,R82,R203,R204,R205,R91,R206,R207,R208,R209,R91,R209,R207,R206,R52,R54,R210,R211,R82,R115,R115,R115,R52,R212,m2,R34,V1,R21,R213,v15,arbace.c2j.emit9,can-prim?R133,R214,R215,R216,R217,R218,R219,v15,arbace.c2j.emit17,emit-binding-initR220,R221,R113,R222,R223,v15,arbace.c2j.emit4,primR99,m2,R34,V1,R100,R101,R224,R225,v11,arbace.core6,reset!v15,arbace.c2j.emit14,emit-fn-class!v15,arbace.c2j.emit10,emit-localR20,R226,V1,nv11,arbace.core4,keysR227,R228,R113,R84,R133,R134,R113,R84,R229,m2,R34,V2,R35,R197,R115,R20,R131,R28,R20,R132,v15,arbace.c2j.emit13,body-instancev15,arbace.c2j.emit7,fn-wrapv15,arbace.c2j.emit12,identity-setR115,R113,R91,R230,R231,R232,R233,R234,R235,R236,R237,R238,R239,R240,R241,R242,v11,arbace.core10,sorted-mapR243,R244,v11,arbace.core7,keywordR245,R246,v11,arbace.core3,setR247,R248,R249,R250,m2,R34,V2,R42,R42,R251,R249,R168,R251,R251,R249,R168,R100,R251,R251,R249,R252,R251,R249,R250,m2,R34,V2,R42,R42,R251,R253,R254,R28,R249,R253,R255,R52,R256,R145,R256,R257,R258,S2,s9,instance?s5,localv15,arbace.c2j.emit8,emit-tryR259,v15,arbace.c2j.emit11,fn-instancev15,arbace.c2j.emit8,emit-defv15,arbace.c2j.emit11,emit-invokeR260,v15,arbace.c2j.emit9,line-metav15,arbace.c2j.emit8,box-primv15,arbace.c2j.emit19,emit-deftype-class!R261,R262,R263,R264,R44,v15,arbace.c2j.emit19,emit-instance-fieldR265,R91,v11,arbace.core7,butlastv11,arbace.core4,lastR129,R266,R267,R83,v15,arbace.c2j.emit7,emit-ifv15,arbace.c2j.emit11,emit-assignv15,arbace.c2j.emit10,emit-letfnR51,R52,R53,R52,R54,R268,R82,R83,R269,R41,R42,v15,arbace.c2j.emit9,coll-callR43,v15,arbace.c2j.emit8,emit-letv15,arbace.c2j.emit10,emit-recurR270,R40,R271,R91,R272,v15,arbace.c2j.emit8,emit-newR273,R52,R274,R275,R25,R26,R276,R91,R277,R278,R52,R279,R280,R281,R32,v15,arbace.c2j.emit17,emit-static-fieldR282,v15,arbace.c2j.emit9,emit-caseR283,R20,R284,R20,R21,R285,R286,R287,R145,R91,R287,R145,R273,R52,R274,v15,arbace.c2j.emit7,throws?R99,m2,R34,V1,R100,R101,R93,R52,R94,R95,R52,R96,R52,R256,R52,R288,R289,R290,R291,v15,arbace.c2j.emit8,ret-bodyR221,R113,R292,R293,m2,R34,V1,R42,v15,arbace.c2j.emit12,prim-classesv11,arbace.core10,ns-resolvev11,arbace.core4,*ns*R294,R295,R296,m2,R297,TR298,m4,R299,TR76,Tv15,arbace.c2j.emit4,poolR300,R88,R301,R302,R303,R88,m2,R299,TML1,R304,m4,R104,i1373,R305,i26,R115,R88,R88,v11,arbace.core4,takeR306,R88,R307,m2,R299,Tv15,arbace.c2j.emit11,method-bodym2,R299,TR73,v15,arbace.c2j.emit10,field-modsR308,R309,R42,R310,v15,arbace.c2j.emit16,class-interfacesR311,R312,R313,R303,m2,R299,TR314,R28,R28,R303,m2,R299,TR314,R28,R28,R307,R315,m4,R299,TR75,TR316,R307,R317,m4,R299,TR75,TR54,v15,arbace.c2j.emit9,tag-classR318,m2,R34,V1,R35,R319,R52,v15,arbace.c2j.emit9,box-classm2,R34,V1,R35,R113,R113,R115,R320,R20,R321,R28,R28,m2,R322,TR323,R324,R325,R326,R88,R73,R303,V1,R88,R327,R54,m2,R299,TML1,R304,m4,R104,i1452,R305,i26,V1,ML3,R115,ML2,R328,R88,m4,R104,i1453,R305,i53,R327,m4,R104,i1453,R305,i47,R115,R88,R329,V2,R88,R326,v15,arbace.c2j.emit9,param-symR307,R330,R331,m2,R299,TV2,R88,R326,m2,R299,TR88,R307,m2,R299,Tm2,R299,TR73,R332,m4,R299,TR75,TR84,R73,R333,R54,R307,R334,m2,R299,TV1,R88,R54,ML2,R328,R88,m4,R104,i1485,R305,i117,R307,R335,m2,R299,TR88,R336,R54,R53,R20,R336,R88,R337,R42,R141,R52,R130,R103,v11,arbace.core15,get-proxy-classR82,R338,m2,R34,V2,R42,R42,R339,m2,R34,V1,R42,R20,R21,R211,R281,R38,R52,R39,m2,R34,V2,R42,R42,m2,R34,V1,R42,v11,arbace.core5,doallR249,R134,R340,m2,R34,V1,R35,R129,R52,R130,R103,v11,arbace.core12,define-proxyR82,R339,m2,R34,V1,R42,R20,R21,m2,R34,V1,R35,m2,R34,V1,R42,R307,m4,R77,TR75,TR91,R341,R28,R28,v11,arbace.core7,sort-byv11,arbace.core7,find-nsv13,arbace.string9,includes?V2,R342,s0,v15,arbace.c2j.emit11,unit-methodv15,arbace.c2j.emit7,unit-nsv15,arbace.c2j.emit17,loader-part-unitsR343,R344,R299,R76,R345,v15,arbace.c2j.emit15,unnamed-packagev15,arbace.c2j.emit11,pool-fieldsR307,R346,m4,R299,TR75,TR91,V1,nR344,R75,R307,R347,m2,R75,TR307,R346,m2,R75,TR91,V1,nm2,R75,Tm2,R75,TV1,nv11,arbace.core13,partition-allR344,R307,R346,m4,R299,TR75,TR91,V1,nv15,arbace.c2j.emit10,class-formv11,arbace.core6,dissocR348,v15,arbace.c2j.emit11,simple-nameR349,R344,m6,R299,TR75,TR76,TR344,m6,R299,TR75,TR151,TR350,R344,m6,R299,TR75,TR76,TR351,v11,arbace.core4,peekv11,arbace.core3,popv11,arbace.core8,group-byv11,arbace.core4,sortR307,m4,R299,TR352,TR88,m4,R299,TR352,T")

var Lit_1 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000253__31000257")

var Lit_2 *jrt.String = jrt.Intern("new-instance")

var Lit_3 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000253__31000257$fn__31000258")

var Lit_4 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000253__31000257$fn__31000258$fn__31000259")

var Lit_5 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form$fn__31000705")

var Lit_6 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form$mods__31000707")

var Lit_7 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$parent__31000712")

var Lit_8 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$fn__31000714")

var Lit_9 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000716__31000720")

var Lit_10 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$fn__31000726")

var Lit_11 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$children_of__31000728")

var Lit_12 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000730__31000734")

var Lit_13 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000716__31000720$fn__31000721")

var Lit_14 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000716__31000720$fn__31000721$fn__31000722")

var Lit_15 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000730__31000734$fn__31000735")

var Lit_16 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000730__31000734$fn__31000735$fn__31000736")

var Lit_17 *jrt.String = jrt.Intern("$")

var Lit_18 *jrt.String = jrt.Intern("no class for ")

var Lit_19 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000376__31000380")

var Lit_20 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000376__31000380$fn__31000381")

var Lit_21 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000376__31000380$fn__31000381$fn__31000382")

var Lit_22 *jrt.String = jrt.Intern(" implements ")

var Lit_23 *jrt.String = jrt.Intern(", made at run time")

var Lit_24 *jrt.String = jrt.Intern("const-")

var Lit_25 *jrt.String = jrt.Intern("V")

var Lit_26 *jrt.String = jrt.Intern("J")

var Lit_27 *jrt.String = jrt.Intern("I")

var Lit_28 *jrt.String = jrt.Intern("D")

var Lit_29 *jrt.String = jrt.Intern("Z")

var Lit_30 *jrt.String = jrt.Intern("C")

var Lit_31 *jrt.String = jrt.Intern("F")

var Lit_32 *jrt.String = jrt.Intern("S")

var Lit_33 *jrt.String = jrt.Intern("B")

var Lit_34 *jrt.String = jrt.Intern(".")

var Lit_35 *jrt.String = jrt.Intern("/")

var Lit_36 *jrt.String = jrt.Intern("L")

var Lit_37 *jrt.String = jrt.Intern(";")

var Lit_38 *jrt.String = jrt.Intern("compile__stub.")

var Lit_39 *jrt.String = jrt.Intern("isNeg")

var Lit_40 *jrt.String = jrt.Intern("isPos")

var Lit_41 *jrt.String = jrt.Intern("unchecked_minus")

var Lit_42 *jrt.String = jrt.Intern("unchecked_dec")

var Lit_43 *jrt.String = jrt.Intern("incP")

var Lit_44 *jrt.String = jrt.Intern("minus")

var Lit_45 *jrt.String = jrt.Intern("unchecked_inc")

var Lit_46 *jrt.String = jrt.Intern("dec")

var Lit_47 *jrt.String = jrt.Intern("inc")

var Lit_48 *jrt.String = jrt.Intern("minusP")

var Lit_49 *jrt.String = jrt.Intern("isZero")

var Lit_50 *jrt.String = jrt.Intern("decP")

var Lit_51 *jrt.String = jrt.Intern("lt")

var Lit_52 *jrt.String = jrt.Intern("addP")

var Lit_53 *jrt.String = jrt.Intern("unchecked_add")

var Lit_54 *jrt.String = jrt.Intern("unchecked_multiply")

var Lit_55 *jrt.String = jrt.Intern("gte")

var Lit_56 *jrt.String = jrt.Intern("lte")

var Lit_57 *jrt.String = jrt.Intern("add")

var Lit_58 *jrt.String = jrt.Intern("multiply")

var Lit_59 *jrt.String = jrt.Intern("multiplyP")

var Lit_60 *jrt.String = jrt.Intern("gt")

var Lit_61 *jrt.String = jrt.Intern("equiv")

var Lit_62 *jrt.String = jrt.Intern("try")

var Lit_63 *jrt.String = jrt.Intern("def")

var Lit_64 *jrt.String = jrt.Intern("invoke")

var Lit_65 *jrt.String = jrt.Intern("instance-method")

var Lit_66 *jrt.String = jrt.Intern("empty")

var Lit_67 *jrt.String = jrt.Intern("unknown empty collection")

var Lit_68 *jrt.String = jrt.Intern("instance-field")

var Lit_69 *jrt.String = jrt.Intern("var")

var Lit_70 *jrt.String = jrt.Intern("keyword-invoke")

var Lit_71 *jrt.String = jrt.Intern("do")

var Lit_72 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000341")

var Lit_73 *jrt.String = jrt.Intern("fn")

var Lit_74 *jrt.String = jrt.Intern("if")

var Lit_75 *jrt.String = jrt.Intern("set!")

var Lit_76 *jrt.String = jrt.Intern("with-meta")

var Lit_77 *jrt.String = jrt.Intern("letfn")

var Lit_78 *jrt.String = jrt.Intern("number")

var Lit_79 *jrt.String = jrt.Intern("the-var")

var Lit_80 *jrt.String = jrt.Intern("keyword")

var Lit_81 *jrt.String = jrt.Intern("local")

var Lit_82 *jrt.String = jrt.Intern("string")

var Lit_83 *jrt.String = jrt.Intern("vector")

var Lit_84 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000343")

var Lit_85 *jrt.String = jrt.Intern("let")

var Lit_86 *jrt.String = jrt.Intern("recur")

var Lit_87 *jrt.String = jrt.Intern("constant")

var Lit_88 *jrt.String = jrt.Intern("map")

var Lit_89 *jrt.String = jrt.Intern("monitor-exit")

var Lit_90 *jrt.String = jrt.Intern("throw")

var Lit_91 *jrt.String = jrt.Intern("new")

var Lit_92 *jrt.String = jrt.Intern("nil")

var Lit_93 *jrt.String = jrt.Intern("boolean")

var Lit_94 *jrt.String = jrt.Intern("monitor-enter")

var Lit_95 *jrt.String = jrt.Intern("list")

var Lit_96 *jrt.String = jrt.Intern("import")

var Lit_97 *jrt.String = jrt.Intern("static-method")

var Lit_98 *jrt.String = jrt.Intern("static-field")

var Lit_99 *jrt.String = jrt.Intern("str-concat")

var Lit_100 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000345")

var Lit_101 *jrt.String = jrt.Intern("case")

var Lit_102 *jrt.String = jrt.Intern("set")

var Lit_103 *jrt.String = jrt.Intern("instance?")

var Lit_104 *jrt.String = jrt.Intern("no back end for ")

var Lit_105 *jrt.String = jrt.Intern(" ")

var Lit_106 *jrt.String = jrt.Intern("set! of a local that is no field")

var Lit_107 *jrt.String = jrt.Intern(".-")

var Lit_108 *jrt.String = jrt.Intern("set! of ")

var Lit_109 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$sm__31000319")

var Lit_110 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$ret__31000321")

var Lit_111 *jrt.String = jrt.Intern("case-")

var Lit_112 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$arm__31000323")

var Lit_113 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$fn__31000326")

var Lit_114 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$fn__31000332")

var Lit_115 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ftype__31000391")

var Lit_116 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fsym__31000393")

var Lit_117 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fn__31000395")

var Lit_118 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000397__31000401")

var Lit_119 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ps__31000407")

var Lit_120 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000411__31000415")

var Lit_121 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fn__31000428")

var Lit_122 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000433__31000437")

var Lit_123 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000449__31000453")

var Lit_124 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000467__31000471")

var Lit_125 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000397__31000401$fn__31000402")

var Lit_126 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000397__31000401$fn__31000402$fn__31000403")

var Lit_127 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000411__31000415$fn__31000416")

var Lit_128 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000411__31000415$fn__31000416$fn__31000417")

var Lit_129 *jrt.String = jrt.Intern("v__")

var Lit_130 *jrt.String = jrt.Intern("Value")

var Lit_131 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000433__31000437$fn__31000438")

var Lit_132 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000433__31000437$fn__31000438$fn__31000439")

var Lit_133 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000449__31000453$fn__31000454")

var Lit_134 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000449__31000453$fn__31000454$fn__31000455")

var Lit_135 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000449__31000453$fn__31000454$fn__31000461")

var Lit_136 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000449__31000453$fn__31000454$fn__31000463")

var Lit_137 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000449__31000453$fn__31000454$fn__31000455$fn__31000456")

var Lit_138 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000449__31000453$fn__31000454$fn__31000455$fn__31000458")

var Lit_139 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000467__31000471$fn__31000472")

var Lit_140 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000467__31000471$fn__31000472$fn__31000473")

var Lit_141 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ps__31000407$fn__31000408")

var Lit_142 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$fn__31000480")

var Lit_143 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000482__31000486")

var Lit_144 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000492__31000496")

var Lit_145 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000502__31000506")

var Lit_146 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$fn__31000512")

var Lit_147 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000514__31000518")

var Lit_148 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000524__31000528")

var Lit_149 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000542__31000546")

var Lit_150 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000552__31000556")

var Lit_151 *jrt.String = jrt.Intern("__")

var Lit_152 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000482__31000486$fn__31000487")

var Lit_153 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000482__31000486$fn__31000487$fn__31000488")

var Lit_154 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000492__31000496$fn__31000497")

var Lit_155 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000492__31000496$fn__31000497$fn__31000498")

var Lit_156 *jrt.String = jrt.Intern("c__")

var Lit_157 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000502__31000506$fn__31000507")

var Lit_158 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000502__31000506$fn__31000507$fn__31000508")

var Lit_159 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000514__31000518$fn__31000519")

var Lit_160 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000514__31000518$fn__31000519$fn__31000520")

var Lit_161 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000524__31000528$fn__31000529")

var Lit_162 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000524__31000528$fn__31000529$fn__31000530")

var Lit_163 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000524__31000528$fn__31000529$fn__31000536")

var Lit_164 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000524__31000528$fn__31000529$fn__31000538")

var Lit_165 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000524__31000528$fn__31000529$fn__31000530$fn__31000531")

var Lit_166 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000524__31000528$fn__31000529$fn__31000530$fn__31000533")

var Lit_167 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000542__31000546$fn__31000547")

var Lit_168 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000542__31000546$fn__31000547$fn__31000548")

var Lit_169 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000552__31000556$fn__31000557")

var Lit_170 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000552__31000556$fn__31000557$fn__31000558")

var Lit_171 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTR")

var Lit_172 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTF")

var Lit_173 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_if$br__31000242")

var Lit_174 *jrt.String = jrt.Intern("target-")

var Lit_175 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke$call__31000172")

var Lit_176 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke$fn__31000176")

var Lit_177 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke$call__31000172$fn__31000173")

var Lit_178 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_let$fn__31000247")

var Lit_179 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000268")

var Lit_180 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000270")

var Lit_181 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000272__31000276")

var Lit_182 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000282__31000288")

var Lit_183 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000301")

var Lit_184 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000303")

var Lit_185 *jrt.String = jrt.Intern("body-")

var Lit_186 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000272__31000276$fn__31000277")

var Lit_187 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000272__31000276$fn__31000277$fn__31000278")

var Lit_188 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000282__31000288$fn__31000289")

var Lit_189 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000282__31000288$fn__31000289$iter__31000284__31000293")

var Lit_190 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000282__31000288$fn__31000289$iter__31000284__31000293$fn__31000294")

var Lit_191 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000282__31000288$fn__31000289$iter__31000284__31000293$fn__31000294$fn__31000295")

var Lit_192 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000157")

var Lit_193 *jrt.String = jrt.Intern("root-")

var Lit_194 *jrt.String = jrt.Intern("linked-")

var Lit_195 *jrt.String = jrt.Intern("ifn-")

var Lit_196 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000159")

var Lit_197 *jrt.String = jrt.Intern("arg-")

var Lit_198 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_list_array$fn__31000036")

var Lit_199 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_recur$fn__31000250")

var Lit_200 *jrt.String = jrt.Intern("recur arg for primitive local: ")

var Lit_201 *jrt.String = jrt.Intern(" is not matching primitive")

var Lit_202 *jrt.String = jrt.Intern("__init")

var Lit_203 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$unit_methods__31000640")

var Lit_204 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000647")

var Lit_205 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000659__31000663")

var Lit_206 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000675__31000679")

var Lit_207 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000689__31000693")

var Lit_208 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000647$iter__31000648__31000652")

var Lit_209 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000647$iter__31000648__31000652$fn__31000653")

var Lit_210 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000647$iter__31000648__31000652$fn__31000653$fn__31000654")

var Lit_211 *jrt.String = jrt.Intern("unit")

var Lit_212 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000659__31000663$fn__31000664")

var Lit_213 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000659__31000663$fn__31000664$fn__31000665")

var Lit_214 *jrt.String = jrt.Intern("$part")

var Lit_215 *jrt.String = jrt.Intern("")

var Lit_216 *jrt.String = jrt.Intern("part")

var Lit_217 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000675__31000679$fn__31000680")

var Lit_218 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000675__31000679$fn__31000680$fn__31000681")

var Lit_219 *jrt.String = jrt.Intern("init")

var Lit_220 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000689__31000693$fn__31000694")

var Lit_221 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000689__31000693$fn__31000694$fn__31000695")

var Lit_222 *jrt.String = jrt.Intern("load")

var Lit_223 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$unit_methods__31000640$fn__31000641")

var Lit_224 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$body__31000306")

var Lit_225 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000308__31000312")

var Lit_226 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000308__31000312$fn__31000313")

var Lit_227 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000308__31000312$fn__31000313$fn__31000314")

var Lit_228 *jrt.String = jrt.Intern("unboxed emit of ")

var Lit_229 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_unboxed$fn__31000350")

var Lit_230 *jrt.String = jrt.Intern("no unboxed back end for ")

var Lit_231 *jrt.String = jrt.Intern("TYPE")

var Lit_232 *jrt.String = jrt.Intern("a record as a constant: ")

var Lit_233 *jrt.String = jrt.Intern("a deftype as a constant: ")

var Lit_234 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value$fn__31000045")

var Lit_235 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value$fn__31000047")

var Lit_236 *jrt.String = jrt.Intern("#<")

var Lit_237 *jrt.String = jrt.Intern("can't embed unreadable object in code: ")

var Lit_238 *jrt.String = jrt.Intern("arbace.lang.Compiler$AST")

var Lit_239 *jrt.String = jrt.Intern("arbace.lang.Var")

var Lit_240 *jrt.String = jrt.Intern("arbace.lang.Keyword")

var Lit_241 *jrt.String = jrt.Intern("arbace.lang.Symbol")

var Lit_242 *jrt.String = jrt.Intern("arbace.lang.IObj")

var Lit_243 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_244 *jrt.String = jrt.Intern("arbace.lang.IPersistentVector")

var Lit_245 *jrt.String = jrt.Intern("arbace.lang.IPersistentSet")

var Lit_246 *jrt.String = jrt.Intern("arbace.lang.IPersistentList")

var Lit_247 *jrt.String = jrt.Intern("arbace.lang.ISeq")

var Lit_248 *jrt.String = jrt.Intern("arbace.lang.IType")

var Lit_249 *jrt.String = jrt.Intern("arbace.lang.IRecord")

var Lit_250 *jrt.String = jrt.Intern("arbace.lang.PersistentHashSet")

var Lit_251 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_252 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_253 *jrt.String = jrt.Intern("java.util.regex.Pattern")

var Lit_254 *jrt.String = jrt.Intern("aot: ")

var Lit_255 *jrt.String = jrt.Intern("fiMethod")

var Lit_256 *jrt.String = jrt.Intern("/go/arbace/jrt")

var Lit_257 *jrt.String = jrt.Intern("ARBACE_AOT_ROOT")

var Lit_258 *jrt.String = jrt.Intern("fn-class")

var Lit_259 *jrt.String = jrt.Intern("fncls__")

var Lit_260 *jrt.String = jrt.Intern("d")

var Lit_261 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$fn__31000742")

var Lit_262 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000744__31000748")

var Lit_263 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000744__31000748$fn__31000749")

var Lit_264 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000744__31000748$fn__31000749$fn__31000750")

var Lit_265 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000744__31000748$fn__31000749$fn__31000760")

var Lit_266 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000744__31000748$fn__31000749$fn__31000750$fn__31000754")

var Lit_267 *jrt.String = jrt.Intern("p")

var Lit_268 *jrt.String = jrt.Intern("(")

var Lit_269 *jrt.String = jrt.Intern(")")

var Lit_270 *jrt.String = jrt.Intern("arbace.c2j.emit$jrt_lacks_QMARK_$fn__31000183")

var Lit_271 *jrt.String = jrt.Intern("_")

var Lit_272 *jrt.String = jrt.Intern("linked")

var Lit_273 *jrt.String = jrt.Intern("arbace.c2j.emit$link_form$fn__31000166")

var Lit_274 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op1$guard__31000197")

var Lit_275 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op2$checked__31000191")

var Lit_276 *jrt.String = jrt.Intern("and")

var Lit_277 *jrt.String = jrt.Intern("xor")

var Lit_278 *jrt.String = jrt.Intern("or")

var Lit_279 *jrt.String = jrt.Intern("remainder")

var Lit_280 *jrt.String = jrt.Intern("shiftLeft")

var Lit_281 *jrt.String = jrt.Intern("quotient")

var Lit_282 *jrt.String = jrt.Intern("shiftRight")

var Lit_283 *jrt.String = jrt.Intern("fn-method")

var Lit_284 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000358__31000362")

var Lit_285 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$fn__31000368")

var Lit_286 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$fn__31000370")

var Lit_287 *jrt.String = jrt.Intern("p-")

var Lit_288 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000358__31000362$fn__31000363")

var Lit_289 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000358__31000362$fn__31000363$fn__31000364")

var Lit_290 *jrt.String = jrt.Intern("a call of a method of a class made at run time: ")

var Lit_291 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000205")

var Lit_292 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000208")

var Lit_293 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000210")

var Lit_294 *jrt.String = jrt.Intern("arbace.lang.Numbers")

var Lit_295 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$lv__31000212")

var Lit_296 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$dv__31000214")

var Lit_297 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000217")

var Lit_298 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$is__31000222")

var Lit_299 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000226")

var Lit_300 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000228")

var Lit_301 *jrt.String = jrt.Intern("nr-")

var Lit_302 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000230")

var Lit_303 *jrt.String = jrt.Intern("na-")

var Lit_304 *jrt.String = jrt.Intern("n")

var Lit_305 *jrt.String = jrt.Intern("-")

var Lit_306 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$is__31000222$fn__31000223")

var Lit_307 *jrt.String = jrt.Intern("arbace.c2j.emit$obj_array$fn__31000149")

var Lit_308 *jrt.String = jrt.Intern("arbace.c2j.emit$pool$fn__31000031")

var Lit_309 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$num__31000055")

var Lit_310 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$arr__31000057")

var Lit_311 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$fn__31000064")

var Lit_312 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_313 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000068")

var Lit_314 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$walk__31000070")

var Lit_315 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000076")

var Lit_316 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000084")

var Lit_317 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000090")

var Lit_318 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000096")

var Lit_319 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000105")

var Lit_320 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000110__31000114")

var Lit_321 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000110__31000114$fn__31000115")

var Lit_322 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000110__31000114$fn__31000115$fn__31000116")

var Lit_323 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000021")

var Lit_324 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000023")

var Lit_325 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000023$fn__31000024")

var Lit_326 *jrt.String = jrt.Intern("cut")

var Lit_327 *jrt.String = jrt.Intern("mismatched primitive return, expected ")

var Lit_328 *jrt.String = jrt.Intern(", had ")

var Lit_329 *jrt.String = jrt.Intern("arbace.lang.IProxy")

var Lit_330 *jrt.String = jrt.Intern("arbace.c2j.emit$typed_args$fn__31000144")

var Lit_331 *jrt.String = jrt.Intern("uncheckedIntCast")

var Lit_332 *jrt.String = jrt.Intern("intCast")

var Lit_333 *jrt.String = jrt.Intern("uncheckedFloatCast")

var Lit_334 *jrt.String = jrt.Intern("floatCast")

var Lit_335 *jrt.String = jrt.Intern("uncheckedDoubleCast")

var Lit_336 *jrt.String = jrt.Intern("doubleCast")

var Lit_337 *jrt.String = jrt.Intern("uncheckedLongCast")

var Lit_338 *jrt.String = jrt.Intern("longCast")

var Lit_339 *jrt.String = jrt.Intern("uncheckedByteCast")

var Lit_340 *jrt.String = jrt.Intern("byteCast")

var Lit_341 *jrt.String = jrt.Intern("uncheckedShortCast")

var Lit_342 *jrt.String = jrt.Intern("shortCast")

var Lit_343 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_344 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000569__31000573")

var Lit_345 *jrt.String = jrt.Intern("a top-level fn closing over locals")

var Lit_346 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000601__31000605")

var Lit_347 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$fn__31000631")

var Lit_348 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000569__31000573$fn__31000574")

var Lit_349 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000569__31000573$fn__31000574$fn__31000575")

var Lit_350 *jrt.String = jrt.Intern("type")

var Lit_351 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000569__31000573$fn__31000574$fn__31000589")

var Lit_352 *jrt.String = jrt.Intern("an event of a class made at run time: ")

var Lit_353 *jrt.String = jrt.Intern("iface")

var Lit_354 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000569__31000573$fn__31000574$fn__31000591")

var Lit_355 *jrt.String = jrt.Intern("proxy")

var Lit_356 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000569__31000573$fn__31000574$fn__31000593")

var Lit_357 *jrt.String = jrt.Intern("imethod")

var Lit_358 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000569__31000573$fn__31000574$fn__31000595")

var Lit_359 *jrt.String = jrt.Intern("stub")

var Lit_360 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000569__31000573$fn__31000574$fn__31000597")

var Lit_361 *jrt.String = jrt.Intern("ns")

var Lit_362 *jrt.String = jrt.Intern("an event of kind ")

var Lit_363 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000569__31000573$fn__31000574$fn__31000575$fn__31000577")

var Lit_364 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000569__31000573$fn__31000574$fn__31000575$fn__31000579")

var Lit_365 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000569__31000573$fn__31000574$fn__31000575$fn__31000581")

var Lit_366 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000569__31000573$fn__31000574$fn__31000575$fn__31000583")

var Lit_367 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000569__31000573$fn__31000574$fn__31000575$fn__31000585")

var Lit_368 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000601__31000605$fn__31000606")

var Lit_369 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000601__31000605$fn__31000606$fn__31000607")

var Lit_370 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000601__31000605$fn__31000606$iter__31000619__31000623")

var Lit_371 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000601__31000605$fn__31000606$fn__31000607$iter__31000608__31000612")

var Lit_372 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000601__31000605$fn__31000606$fn__31000607$iter__31000608__31000612$fn__31000613")

var Lit_373 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000601__31000605$fn__31000606$fn__31000607$iter__31000608__31000612$fn__31000613$fn__31000614")

var Lit_374 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000601__31000605$fn__31000606$iter__31000619__31000623$fn__31000624")

var Lit_375 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000601__31000605$fn__31000606$iter__31000619__31000623$fn__31000624$fn__31000625")

var Lit_376 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,xyn3,msgyn1,&yn4,datakn3,tagyn6,Stringyn5,Classyn4,voidyn6,doubleyn4,charyn4,byteyn7,booleanyn5,floatyn4,longyn5,shortyn3,intyn1,syn1,cyn3,ctxyn3,topyn1,vyn5,ctypekn8,declaredyn2,xsyn9,Characterkn4,longkn6,doublekn3,intkn6,symbolkn6,stringkn6,vectorkn4,listkn3,varkn7,keywordkn5,classkn3,nilkn3,setkn7,booleankn3,mapkn4,charkn7,patternyn13,StringBuilderyn6,sharedyn6,constskn7,dynamicyn4,baseyn1,byn2,lbyn1,eyn1,nyn1,fyn2,psyn2,esyn3,Varyn8,unboxed?yn5,fnodeyn4,argsyn3,keyyn1,myn5,cnameyn8,variadicyn1,kyn7,classesyn15,IdentityHashMapyn24,java.lang.reflect.Methodyn1,tys14,java.lang.Long9,MIN_VALUEys14,java.lang.Long9,MAX_VALUEyn2,opyn1,yyn4,slowyn1,ryn23,java.lang.reflect.Fieldyn4,top?yn3,symyn4,inityn2,oxyn10,nil-localsyn4,bodyys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys17,java.lang.Integer7,valueOfys17,java.lang.Boolean7,valueOfys19,java.lang.Character7,valueOfys15,java.lang.Float7,valueOfys15,java.lang.Short7,valueOfys14,java.lang.Byte7,valueOfv11,arbace.core5,in-nsMyn15,arbace.c2j.emitm2,R0,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).m2,R0,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).R1,v15,arbace.c2j.emit10,node-cachem10,R2,TR3,i35,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s58,The nodes' maps by node (the back end runs on one thread).v15,arbace.c2j.emit4,nodem10,R6,L1,V1,R7,R0,s62,The analyzed node x as a map (Compiler$AST/node), nil for nil.R3,i39,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,failm10,R2,TR6,L1,V3,R8,R9,V1,R10,R3,i48,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,destubm10,R6,L1,V1,Myn1,nm2,R11,R12,R0,s74,A class name without the compile stub's prefix (Compiler.destubClassName).R3,i54,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,type-symm10,R6,L1,V1,Myn1,cm2,R11,R13,R0,s93,The Java forms type of class c: a primitive's name, a class's binary name, an array as\n  T/n.R3,i59,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,prim-namesR14,R15,R16,R17,R18,R19,R20,R21,R22,m8,R2,TR3,i70,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,taggedm12,R2,TR6,L1,V2,R23,R24,R0,s44,Symbol s with the Java forms tag of class c.R3,i74,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,registeredv11,arbace.core4,atomm10,R2,TR3,i83,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s84,Whether a class name is registered in the program (Class/forName finds it), by name.v15,arbace.c2j.emit11,registered?m10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i87,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,runtime-class?m12,R2,TR6,L1,V2,Myn1,cm2,R11,R13,R25,R0,s291,Is class c made at run time (a Dyn class: an evaluated fn's, deftype's, interface's, proxy's)\n  rather than a class of the program, or one the program does not register by name (java.sql's,\n  whose members reflection reached from a world class)? Such a class is not named in compiled\n  code.R3,i104,R4,i1,R5,s18,arbace/c2j/emit.aev11,arbace.core12,define-proxyv15,arbace.c2j.emit7,public?m10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i119,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,top-namem10,R2,TR6,L1,V1,Myn1,nm2,R11,R12,R3,i125,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,poolm12,R2,TR6,L1,V2,R25,R26,R0,s178,The constants of top-level class top (a namespace's holder, a deftype, a loader), which its\n  member classes share (SA145): an atom {:name :consts :const-map}, made on first use.R3,i127,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,const-fieldm12,R2,TR6,L1,V3,R25,R27,R28,R0,s236,The static field holding constant value v in the class being emitted, made on first use (as\n  the JVM's const__N, one per distinct object): its symbol, const-N (a munged local's name has\n  no -, so no local, name__index, can shadow it).R3,i137,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-valuem8,R29,TR3,i158,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,emit-list-arraym10,R2,TR6,L1,V2,R25,R30,R3,i160,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,char-formm10,R2,TR6,L1,V1,Myn1,cm2,R11,R31,R3,i163,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,double-formm10,R2,TR6,L1,V1,Myn1,dm2,R11,R15,R3,i169,R4,i1,R5,s18,arbace/c2j/emit.aem10,R6,L1,V2,R25,R27,R0,s72,Code making constant value v (ObjExpr.emitValue), its metadata included.R3,i174,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,pool-kindm12,R2,TR6,L1,V1,R27,R0,s58,The tag of constant v, in the order of emit-value's cases.R3,i250,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,pool-partialS16,R32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,m10,R2,TR3,i275,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s61,The kinds whose metadata is made too (emit-value's partial?).v15,arbace.c2j.emit12,pool-shared?m12,R2,TR6,L1,V1,R27,R0,s84,Is v made once in a pool and named where used: a keyword, a symbol without metadata.R3,i279,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,pool-partsm12,R2,TR6,L1,V1,R27,R0,s62,The values constant v is made of (its elements, its metadata).R3,i284,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,pool-strm10,R2,TR6,L1,V2,Myn2,sbm2,R11,R48,Myn1,sm2,R11,R12,R3,i295,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,pool-encodem12,R2,TR6,L1,V3,Myn2,sbm2,R11,R48,R49,R27,R0,s102,Appends the encoding of v to sb (Compiler$AOT/poolValue's format); shared: shared value →\n  its index.R3,i298,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,pool-fieldsm12,R2,TR6,L1,V1,R50,R0,s264,The static fields of constants consts ([sym type value alias] ...): the pool's array, decoded\n  once (Compiler$AOT/pool), then each constant's field, its element, or for one with an alias\n  (a split loader's constant an earlier part made, SA210) that part's field.R3,i346,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,const-typem10,R2,TR6,L1,V1,R27,R3,i379,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,*late-classes*m10,R51,TR3,i385,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s398,The names of the classes the Java forms compiler made while the program prepared (its\n  deftypes, fns and defclasses using the Java forms, arbace.c2j.main's java-forms-classes): in the\n  tree, but j2g may leave one out (Clojure in its body it cannot analyze, F2.4), so a constant\n  naming one is looked up where used, as a class made at run time, and the classes holding it\n  initialize without it.v15,arbace.c2j.emit8,constantm10,R2,TR6,L1,V2,R25,R27,R3,i393,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,gsymm12,R2,TR6,L1,V2,R25,R52,R0,s146,A fresh name for a temporary of the emitted code, numbered per class being emitted (the\n  output does not depend on the program's gensym counter).R3,i406,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,local-symm12,R2,TR6,L1,V1,R53,R0,s95,The Java forms local of LocalBinding lb (its node b): its name and index, unique in a\n  method.R3,i414,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,identity-setm12,R2,TR6,L1,V1,R30,R0,s259,The objects of xs as a set by identity. A fn's closes map cannot be asked containsKey: its\n  keys, LocalBindings, hash by their index (Arbace's deterministic hashCode), and FnExpr.parse\n  renumbers a direct fn's arguments after its inner fns closed over them.R3,i420,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,closed?m10,R2,TR6,L1,V2,R25,R54,R3,i429,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,field-symm10,R2,TR6,L1,V1,R53,R3,i433,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,field-readm10,R2,TR6,L1,V3,R25,R54,R53,R3,i435,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,emitm8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,emit-unboxedm8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,emit-fn-class!m8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,emit-deftype-class!m8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,emit-bodym8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,primm10,R2,TR6,L1,V1,R55,R3,i443,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,can-prim?m10,R2,TR6,L1,V1,R56,R3,i445,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,box-ofm8,R29,TR3,i447,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit3,boxm12,R2,TR6,L1,V2,R57,Myn1,cm2,R11,R13,R0,s113,Form f of type c as a boxed value (emitBoxReturn: valueOf, long's Numbers.num being\n  Long.valueOf; void as nil).R3,i449,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,unbox-argm12,R2,TR6,L1,V3,R25,R57,Myn1,pm2,R11,R13,R0,s67,Boxed form f converted to parameter type p (HostExpr.emitUnboxArg).R3,i458,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit3,fi?m12,R2,TR6,L1,V1,Myn1,pm2,R11,R13,R0,s136,Is p a functional interface a fn argument is adapted to (Clojure 1.12's FISupport, as the\n  analysis decides it: Compiler$AST/fiMethod)?R3,i477,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,typed-argsm12,R2,TR6,L1,V3,R25,R58,R59,R0,s70,The arguments es as parameters of types ps (MethodExpr.emitTypedArgs).R3,i484,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,param-tagsm10,R2,TR6,L1,V1,R58,R3,i508,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,obj-arraym10,R2,TR6,L1,V2,R25,R59,R3,i510,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,var-valuem10,R2,TR6,L1,V2,R25,Myn1,vm2,R11,R60,R3,i513,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,line-metam10,R2,TR6,L1,V2,R57,R56,R3,i517,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-localm10,R2,TR6,L1,V3,R25,R56,R61,R3,i522,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,*link*m10,R51,TR3,i537,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s209,While the call sites of vars may be linked, an atom of the sites' data in the order emitted\n  (arbace.c2j.main's compile-all binds it, and resolves the sites, link-form, once every class\n  is known); else nil.v15,arbace.c2j.emit8,link-keym12,R2,TR6,L1,V1,Myn1,vm2,R11,R60,R0,s355,The key of the compiled fn var v's root is at the end of the prepare run, for a call site\n  of v: the FnExpr of an evaluated fn (Compiler$EvalFn), or the class name of a compiled one\n  (Compiler$AOTFn, Compiler$AOTRestFn: the back end's own namespaces, compiled-back-end); nil\n  when v is dynamic, ^:dynamic, ^:redef or a macro, or its root is no such fn.R3,i543,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,deepm8,R29,TR3,i557,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,emit-link-sitem12,R2,TR6,L1,V4,R25,R62,R63,R64,R0,s266,A call of var fexpr (its node fnode) with args (at most 20), linked when its root's code is\n  known (link-key): a marker (c2j/link {...}) holding the emitted root, arguments and\n  temporaries, which link-form resolves into the guarded direct call or the generic one.R3,i559,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,link-formm10,R6,L1,V3,R65,R66,R67,R0,s736,The code of link marker m (emit-link-site): with cname, the code class of the fn the site\n  expects (its fixed arity of the call's argument count, variadic its required count or nil),\n  the guarded direct call; without, the generic call T1 makes. The guard: the root is a\n  compiled fn (Compiler$AOTFn, or Compiler$AOTRestFn for variadic code) whose class is the code\n  class's fn class (fn-class, one Class per code: Compiler$AOT/fnClass), one pointer compare\n  (Compiler$AOTFn/linked, which answers the fn's body or nil); then the code's invoke is called\n  directly with the fn as self, as the fn's invoke would call it. The root is read once, and\n  cast to IFn before the arguments when the guard fails, as the generic call casts it.R3,i576,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,link-targetm10,R6,L1,V3,R68,R69,Myn8,fn-namesm2,R11,R70,R0,s184,The class name and record of the code class link key k names (link-key), given the classes\n  made (name → record) and the fns' class names by FnExpr (fn-names); nil when none was made.R3,i600,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,emit-invokem10,R2,TR6,L1,V2,R25,R56,R3,i608,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,descriptorm10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i644,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,jrt-scanm8,R2,TR3,i652,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,jrt-lacks?m12,R2,TR6,L1,V1,Myn1,mm2,R11,R71,R0,s255,Is method m declared by a class jrt writes by hand (not a stand-in j2g's translation\n  replaces) without it in Go? j2g would translate a direct call to a throw; the member tables\n  (reflection) have such members, so compiled code calls them by reflection.R3,i655,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,method-callm12,R2,TR6,L1,V4,R25,Myn1,mm2,R11,R71,R72,R63,R0,s69,A call of resolved method m: static (target nil) or on target form t.R3,i674,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,compiled-interface?m12,R2,TR6,L1,V2,R25,Myn1,cm2,R11,R13,R0,s86,Is class c an interface of a namespace being compiled (gen-interface's, a protocol's)?R3,i687,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit20,emit-instance-methodm10,R2,TR6,L1,V3,R25,R56,R61,R3,i692,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-minR73,m8,R2,TR3,i735,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-maxR74,m8,R2,TR3,i736,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-boxm10,R2,TR6,L1,V1,R57,R3,i738,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-boxm10,R2,TR6,L1,V1,R57,R3,i739,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-op2m12,R2,TR6,L1,V5,R75,R7,R76,R77,R78,R0,s202,The Long case of Numbers' binary operation op on longs x, y (symbols; r the result's local):\n  a form of the operation's result type, slow where Numbers would not answer a long; nil: not\n  an intrinsic.R3,i741,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-op2m12,R2,TR6,L1,V3,R75,R7,R76,R0,s166,The Double case (both operands Double) of Numbers' binary operation op (DoubleOps: the '\n  operations are the others, a difference the sum with the negation), or nil.R3,i776,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-op1m12,R2,TR6,L1,V3,R75,R7,R77,R0,s70,The Long case of Numbers' unary operation op on long x, as long-op2's.R3,i791,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-op1m12,R2,TR6,L1,V2,R75,R7,R0,s64,The Double case of Numbers' unary operation op, as double-op2's.R3,i807,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,numbers-intrinsicm12,R2,TR6,L1,V3,R25,Myn1,mm2,R11,R71,R63,R0,s123,The call of Numbers' static method m on args with its fast paths, or nil when m is not one\n  of the boxed operations above.R3,i819,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit18,emit-static-methodm10,R2,TR6,L1,V3,R25,R56,R61,R3,i854,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,field-ok?m10,R2,TR6,L1,V2,R25,Myn1,fm2,R11,R79,R3,i868,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,emit-instance-fieldm10,R2,TR6,L1,V3,R25,R56,R61,R3,i871,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,emit-static-fieldm10,R2,TR6,L1,V3,R25,R56,R61,R3,i880,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-newm10,R2,TR6,L1,V2,R25,R56,R3,i888,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-defm10,R2,TR6,L1,V3,R25,R56,R80,R3,i897,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,emit-assignm10,R2,TR6,L1,V2,R25,R56,R3,i915,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,coll-callm10,R2,TR6,L1,V3,R81,R59,R25,R3,i937,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,emit-ifm10,R2,TR6,L1,V3,R25,R56,R61,R3,i940,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,emit-binding-initm12,R2,TR6,L1,V3,R25,R54,R82,R0,s69,A let or loop binding [sym init] of LocalBinding lb (LetExpr.doEmit).R3,i949,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-letm10,R2,TR6,L1,V3,R25,R56,R61,R3,i958,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-recurm10,R2,TR6,L1,V2,R25,R56,R3,i965,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit13,body-instancem12,R2,TR6,L1,V3,R25,R83,R84,R0,s228,A new instance of fn or reify class ox (its node), its closed-over values from the current\n  method: (new C closed...) (ObjExpr.emit); letfn's own locals nil (set after). A fn's is its\n  code (SA141), which fn-wrap makes the fn.R3,i986,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,fn-wrapm12,R2,TR6,L1,V3,R25,R83,R85,R0,s135,The fn of fn ox (its node) whose code is form body: a Compiler$AOTFn, or a\n  Compiler$AOTRestFn of the variadic arity's required count.R3,i999,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,fn-instancem12,R2,TR6,L1,V3,R25,R83,R84,R0,s33,A new fn or reify (ox, its node).R3,i1022,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-letfnm10,R2,TR6,L1,V3,R25,R56,R61,R3,i1028,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-trym10,R2,TR6,L1,V3,R25,R56,R61,R3,i1045,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,emit-casem10,R2,TR6,L1,V3,R25,R56,R61,R3,i1054,R4,i1,R5,s18,arbace/c2j/emit.aeR86,R87,R88,R89,R90,R91,R92,R93,m8,R2,TR3,i1101,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,box-primm12,R2,TR6,L1,V2,R57,R56,R0,s200,Form f of node n boxed when it is of a primitive type (emitBoxReturn: valueOf, long's\n  Numbers.num being Long.valueOf), so that emit's code is always a reference, as the bytecode's\n  emit leaves one.R3,i1107,R4,i1,R5,s18,arbace/c2j/emit.aem10,R6,L1,V2,R25,R55,R0,s59,Code for analyzed node e, its value boxed (an Expr's emit).R3,i1118,R4,i1,R5,s18,arbace/c2j/emit.aem10,R6,L1,V2,R25,R55,R0,s72,Code for analyzed node e, its value of its primitive type (emitUnboxed).R3,i1194,R4,i1,R5,s18,arbace/c2j/emit.ae")

var Lit_377 *jrt.String = jrt.Intern("arbace.c2j.emit$eval31000004$loading__1927001464__auto____31000005")

var Lit_378 *jrt.String = jrt.Intern("arbace.c2j.emit$eval31000008$fn__31000009")

var Lit_379 *jrt.String = jrt.Intern("arbace.c2j.emit$node")

var Lit_380 *jrt.String = jrt.Intern("arbace.c2j.emit$fail")

var Lit_381 *jrt.String = jrt.Intern("arbace.c2j.emit$destub")

var Lit_382 *jrt.String = jrt.Intern("arbace.c2j.emit$type_sym")

var Lit_383 *jrt.String = jrt.Intern("arbace.c2j.emit$tagged")

var Lit_384 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_")

var Lit_385 *jrt.String = jrt.Intern("arbace.c2j.emit$runtime_class_QMARK_")

var Lit_386 *jrt.String = jrt.Intern("arbace.c2j.emit$public_QMARK_")

var Lit_387 *jrt.String = jrt.Intern("arbace.c2j.emit$top_name")

var Lit_388 *jrt.String = jrt.Intern("arbace.c2j.emit$pool")

var Lit_389 *jrt.String = jrt.Intern("arbace.c2j.emit$const_field")

var Lit_390 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_list_array")

var Lit_391 *jrt.String = jrt.Intern("arbace.c2j.emit$char_form")

var Lit_392 *jrt.String = jrt.Intern("arbace.c2j.emit$double_form")

var Lit_393 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value")

var Lit_394 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_kind")

var Lit_395 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_shared_QMARK_")

var Lit_396 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_parts")

var Lit_397 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_str")

var Lit_398 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode")

var Lit_399 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields")

var Lit_400 *jrt.String = jrt.Intern("arbace.c2j.emit$const_type")

var Lit_401 *jrt.String = jrt.Intern("arbace.c2j.emit$constant")

var Lit_402 *jrt.String = jrt.Intern("arbace.c2j.emit$gsym")

var Lit_403 *jrt.String = jrt.Intern("arbace.c2j.emit$local_sym")

var Lit_404 *jrt.String = jrt.Intern("arbace.c2j.emit$identity_set")

var Lit_405 *jrt.String = jrt.Intern("arbace.c2j.emit$closed_QMARK_")

var Lit_406 *jrt.String = jrt.Intern("arbace.c2j.emit$field_sym")

var Lit_407 *jrt.String = jrt.Intern("arbace.c2j.emit$field_read")

var Lit_408 *jrt.String = jrt.Intern("arbace.c2j.emit$prim")

var Lit_409 *jrt.String = jrt.Intern("arbace.c2j.emit$can_prim_QMARK_")

var Lit_410 *jrt.String = jrt.Intern("arbace.c2j.emit$box")

var Lit_411 *jrt.String = jrt.Intern("arbace.c2j.emit$unbox_arg")

var Lit_412 *jrt.String = jrt.Intern("arbace.c2j.emit$fi_QMARK_")

var Lit_413 *jrt.String = jrt.Intern("arbace.c2j.emit$typed_args")

var Lit_414 *jrt.String = jrt.Intern("arbace.c2j.emit$param_tags")

var Lit_415 *jrt.String = jrt.Intern("arbace.c2j.emit$obj_array")

var Lit_416 *jrt.String = jrt.Intern("arbace.c2j.emit$var_value")

var Lit_417 *jrt.String = jrt.Intern("arbace.c2j.emit$line_meta")

var Lit_418 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_local")

var Lit_419 *jrt.String = jrt.Intern("arbace.c2j.emit$link_key")

var Lit_420 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site")

var Lit_421 *jrt.String = jrt.Intern("arbace.c2j.emit$link_form")

var Lit_422 *jrt.String = jrt.Intern("arbace.c2j.emit$link_target")

var Lit_423 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke")

var Lit_424 *jrt.String = jrt.Intern("arbace.c2j.emit$descriptor")

var Lit_425 *jrt.String = jrt.Intern("arbace.c2j.emit$fn__31000180")

var Lit_426 *jrt.String = jrt.Intern("arbace.c2j.emit$jrt_lacks_QMARK_")

var Lit_427 *jrt.String = jrt.Intern("arbace.c2j.emit$method_call")

var Lit_428 *jrt.String = jrt.Intern("arbace.c2j.emit$compiled_interface_QMARK_")

var Lit_429 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_instance_method")

var Lit_430 *jrt.String = jrt.Intern("arbace.c2j.emit$long_box")

var Lit_431 *jrt.String = jrt.Intern("arbace.c2j.emit$double_box")

var Lit_432 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op2")

var Lit_433 *jrt.String = jrt.Intern("arbace.c2j.emit$double_op2")

var Lit_434 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op1")

var Lit_435 *jrt.String = jrt.Intern("arbace.c2j.emit$double_op1")

var Lit_436 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic")

var Lit_437 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_method")

var Lit_438 *jrt.String = jrt.Intern("arbace.c2j.emit$field_ok_QMARK_")

var Lit_439 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_instance_field")

var Lit_440 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_field")

var Lit_441 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_new")

var Lit_442 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_def")

var Lit_443 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_assign")

var Lit_444 *jrt.String = jrt.Intern("arbace.c2j.emit$coll_call")

var Lit_445 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_if")

var Lit_446 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_binding_init")

var Lit_447 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_let")

var Lit_448 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_recur")

var Lit_449 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance")

var Lit_450 *jrt.String = jrt.Intern("arbace.c2j.emit$fn_wrap")

var Lit_451 *jrt.String = jrt.Intern("arbace.c2j.emit$fn_instance")

var Lit_452 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn")

var Lit_453 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try")

var Lit_454 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case")

var Lit_455 *jrt.String = jrt.Intern("arbace.c2j.emit$box_prim")

var Lit_456 *jrt.String = jrt.Intern("arbace.c2j.emit$emit")

var Lit_457 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_unboxed")

var Lit_458 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn1,fkn3,dockn4,linekn6,columnkn4,filekn3,tagyn6,Stringyn1,eyn3,ctxyn4,bodyyn5,Classyn2,mnyn6,paramsyn2,lbyn4,longyn6,doubleyn3,intyn7,booleanyn4,charyn5,floatyn5,shortyn4,byteyn3,tagyn2,oxyn1,kyn4,kindyn4,lineyn6,columnyn1,_yn4,expryn6,eventsyn7,classesyn15,runtime-classesyn8,fn-namesyn5,poolsyn3,srcyn5,unitsyn1,cyn11,children-ofyn4,top?yn4,nameyn7,extendsyn7,methodsm12,R0,TR1,L1,V1,R2,R3,s160,Form f realized throughout (the emitters build lazy seqs; what they record, the constants\n  and the classes, must be recorded before it is read), metadata kept.R4,i1226,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,simple-namem10,R0,TR1,L1,V1,Myn6,binarym2,R7,R8,R4,i1235,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,throws?m12,R0,TR1,L1,V1,R9,R3,s86,Does node e end in a throw (a form that does not complete, which needs no conversion)?R4,i1238,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,ret-bodym12,R0,TR1,L1,V3,R10,R11,Myn3,retm2,R7,R12,R3,s148,A deftype's method body as returned in type ret (ObjMethod.emitBody): unboxed when it can be,\n  else boxed then cast or unboxed as ASM's unbox does.R4,i1247,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,method-bodym12,R0,TR1,L1,V3,R10,R13,R14,R3,s147,The body of FnMethod or NewInstanceMethod m (its node), in the method's context: wrapped in\n  a loop over its parameters when a recur targets them.R4,i1273,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,param-symm10,R0,TR1,L1,V1,R15,R4,i1310,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,prim-classesR16,R17,R18,R19,R20,R21,R22,R23,m8,R0,TR4,i1316,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,tag-classm12,R0,TR1,L1,V1,R24,R3,s70,The class a field's tag names (Compiler.tagClass): Object without one.R4,i1320,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,box-classm10,R0,TR1,L1,V1,Myn1,cm2,R7,R12,R4,i1329,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit16,class-interfacesm12,R0,TR1,L1,V2,R10,R25,R3,s179,The interfaces of a deftype's or reify's class (its node ox), as the analysis made the\n  class: their names. A class of the program cannot implement an interface made at run time.R4,i1333,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,field-modsm12,R0,TR1,L1,V2,R25,R15,R3,s104,The modifiers of a deftype's field lb (ObjExpr.compile): volatile, mutable (package), or\n  public final.R4,i1344,R5,i1,R6,s18,arbace/c2j/emit.aem10,R1,L1,V2,R10,R25,R3,s202,Defines deftype ox's class (its node), a top-level class named as the deftype, once:\n  its fields, constructors, getBasis (and create for a record), and methods\n  (NewInstanceExpr.compile, emitStatics).R4,i1354,R5,i1,R6,s18,arbace/c2j/emit.aem10,R1,L1,V2,R10,R25,R3,s109,Defines the class of fn or reify ox (its node) once, in the classes being emitted; returns\n  its binary name.R4,i1422,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,unit-methodm12,R0,TR1,L1,V3,R10,R26,V7,R27,R28,R29,R30,R30,R31,R32,R3,s96,The static method unitK of a source's loader class: unit u's events made again, then its\n  code.R4,i1509,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,unit-nsm12,R0,TR1,L1,V1,V6,R27,R30,R30,R30,R30,R31,R3,s79,The namespace unit u was analyzed in: its fn's (kind 1) or its def's, else nil.R4,i1574,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,loader-part-unitsl100,m8,R4,i1585,R5,i1,R6,s18,arbace/c2j/emit.aeR3,s251,The most units a source's loader class holds itself; a source of more is split into parts of\n  as many (SA210): j2g analyzes classes in parallel, one class on one thread (arbace.core's 903\n  units were one task of 9 to 14 s, the last of the analysis).v15,arbace.c2j.emit15,unnamed-packagem10,R1,L1,V1,Myn2,nmm2,R7,R8,R3,s484,The option placing top-level class nm in Java's unnamed package when its name has no\n  package: the classes of a namespace of one segment (user: its holder user, the fns\n  user$eval1$fn__2, the loader of a source user.ae, user__init), named as the JVM names them,\n  where the Java forms would put a simple name in the package of the namespace they are read in\n  (arbace). The tree's files import them (arbace.c2j.main), so that a class of a package can name\n  them, as Java could not.R4,i1591,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,emit-sourcem10,R1,L1,V6,R33,R34,R35,R36,R37,R38,R3,s259,The Java forms of source path src (scriptbase.ae), compiled from its units: the loader\n  class SCRIPTBASE__init's form and the fn classes made, into the atom classes (fn-names: the\n  fns' class names by their FnExpr, an IdentityHashMap shared by the sources).R4,i1601,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,class-formm12,R0,TR1,L1,V4,R39,R40,R41,R36,R3,s289,The defclass form of class c (its record: a fn's, a reify's, a deftype's, an interface's, or\n  a holder of nested classes), its nested classes inside; at the top its full name and the\n  constants it shares with them (pools: top → its pool), else a static member class by its\n  simple name.R4,i1667,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,class-formsm10,R1,L1,V2,R33,R36,R3,s261,The top-level Java forms holding every class of classes (name → record), nested as their\n  binary names nest, with holder classes made for the missing levels (a namespace's fns nest\n  in a holder named as the namespace); pools: the top-level classes' constants.R4,i1703,R5,i1,R6,s18,arbace/c2j/emit.aev15,arbace.c2j.emit16,interface-recordm10,R1,L1,V3,R42,R43,R44,R3,s133,The record of an interface made by gen-interface (events iface and imethod): name, the\n  interfaces it extends, its abstract methods.R4,i1725,R5,i1,R6,s18,arbace/c2j/emit.ae")

var Lit_459 *jrt.String = jrt.Intern("arbace.c2j.emit$deep")

var Lit_460 *jrt.String = jrt.Intern("arbace.c2j.emit$simple_name")

var Lit_461 *jrt.String = jrt.Intern("arbace.c2j.emit$throws_QMARK_")

var Lit_462 *jrt.String = jrt.Intern("arbace.c2j.emit$ret_body")

var Lit_463 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body")

var Lit_464 *jrt.String = jrt.Intern("arbace.c2j.emit$param_sym")

var Lit_465 *jrt.String = jrt.Intern("arbace.c2j.emit$tag_class")

var Lit_466 *jrt.String = jrt.Intern("arbace.c2j.emit$box_class")

var Lit_467 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces")

var Lit_468 *jrt.String = jrt.Intern("arbace.c2j.emit$field_mods")

var Lit_469 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_")

var Lit_470 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_")

var Lit_471 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method")

var Lit_472 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_ns")

var Lit_473 *jrt.String = jrt.Intern("arbace.c2j.emit$unnamed_package")

var Lit_474 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source")

var Lit_475 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form")

var Lit_476 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms")

var Lit_477 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record")
