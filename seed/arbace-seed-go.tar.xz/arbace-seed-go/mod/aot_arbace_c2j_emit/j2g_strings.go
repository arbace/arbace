//line j2g_strings.ae:1
package aot_arbace_c2j_emit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.j2g.jrtyn3,jrtyn16,arbace.j2g.namesyn2,nmkn3,dockn4,selfkn3,tagkn15,runtime-classeskn12,unit-proxieskn5,poolskn4,namekn6,constskn9,const-mapkn12,const-prefixkn3,clskn4,prevyn3,newys16,java.lang.Object1,1yn14,unchecked-charys16,java.lang.Double16,longBitsToDoublekn4,elseys17,java.lang.Boolean4,TRUEys17,java.lang.Boolean5,FALSEys17,java.lang.Integer7,valueOfyn13,unchecked-intys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys19,java.lang.Character7,valueOfys14,arbace.lang.RT22,classForNameNonLoadingys18,arbace.lang.Symbol6,internkn10,param-tagsyn16,java.lang.Stringys14,arbace.lang.RT7,keywordys14,arbace.lang.RT3,varys21,arbace.lang.Namespace12,findOrCreateyn18,arbace.lang.Symbolys14,arbace.lang.RT3,mapys17,arbace.lang.Tuple6,createyn16,java.lang.Objectys14,arbace.lang.RT6,vectorys29,arbace.lang.PersistentHashSet5,EMPTYys29,arbace.lang.PersistentHashSet6,createys26,arbace.lang.PersistentList6,createyn14,java.util.Listys16,java.util.Arrays6,asListys23,java.util.regex.Pattern7,compileys14,arbace.lang.RT10,readStringyn9,.withMetayn4,castyn16,arbace.lang.IObjyn26,arbace.lang.IPersistentMapkn3,nilkn6,stringkn7,booleankn3,intkn4,longkn6,doublekn4,charkn5,classkn6,symbolkn7,keywordkn3,varkn2,nskn3,mapkn6,vectorkn3,setkn4,listkn7,patternkn4,readyn5,fieldkn6,statickn5,finalks3,c2j2,nnyn4,agetyn10,const-poolkn7,privateys24,arbace.lang.Compiler$AOT4,poolyn3,intyn15,arbace.lang.Varyn19,arbace.lang.Keywordyn15,java.lang.Classkn7,gensymskn3,idxkn6,closedyn4,thiskn4,primkn16,canEmitPrimitiveyn2,dokn14,unchecked-mathyn13,.booleanValueyn17,java.lang.Booleanyn10,.charValueyn19,java.lang.Characterys14,arbace.lang.RT16,uncheckedIntCastys14,arbace.lang.RT7,intCastyn4,longyn15,unchecked-floatys30,arbace.lang.Compiler$Evaluator7,fiAdaptyn4,.getyn11,.getRawRootkn4,lineks3,c2j4,linekn1,bkn4,oncekn11,shouldClearkn12,canBeClearedkn8,self-symkn11,bindingPrimyn3,letyn2,t-yn4,set!kn5,isArgkn4,argskn5,fexpryn8,.applyToyn15,arbace.lang.IFnys20,arbace.lang.ArraySeq6,createyn7,.invokekn10,isProtocolkn10,protocolOnkn8,onMethodyn2,ifyn3,andyn9,instance?yn3,notys24,arbace.lang.Compiler$AOT5,isDynkn7,classeskn7,standinkn5,funcskn9,interfacekn4,kindkn6,methodkn15,qualifyingClasskn11,dyn-guardedkn6,targetks15,arbace.c2j.emit5,localkn10,target-symyn5,some?kn10,methodNameys21,arbace.lang.Reflector20,invokeInstanceMethodys21,arbace.lang.Reflector27,invokeInstanceMethodOfClassyn6,doubleyn2,>=yn7,bit-andyn7,bit-xoryn2,==yn1,<yn2,oryn16,unchecked-divideyn13,unchecked-addyn18,unchecked-multiplyyn2,<=yn18,unchecked-subtractyn6,bit-oryn19,unchecked-remainderyn14,bit-shift-leftyn1,>yn15,bit-shift-rightyn16,unchecked-negateyn13,unchecked-decyn13,unchecked-inckn1,oyn10,.longValueyn14,java.lang.Longyn12,.doubleValueyn16,java.lang.Doublekn1,jkn1,xyn1,xyn4,slowyn1,yyn1,rys21,arbace.lang.Reflector18,invokeStaticMethodkn1,ckn5,fieldkn9,fieldNamekn12,requireFieldys21,arbace.lang.Reflector25,invokeNoArgInstanceMemberyn7,booleanys21,arbace.lang.Reflector14,getStaticFieldkn4,ctorys21,arbace.lang.Reflector17,invokeConstructorkn12,initProvidedkn4,metakn4,inityn9,.bindRootyn8,.setMetakn9,isDynamicyn11,.setDynamickn3,valkn2,opyn4,.setys21,arbace.lang.Reflector16,setInstanceFieldkn8,testExprkn8,thenExprkn8,elseExprkn6,isLoopkn12,bindingInitskn11,loop-localskn7,bindingkn4,bodyyn4,loopkn10,loopLocalskn12,method-recurkn13,method-localsyn5,recurkn6,closeskn12,supportsMetakn8,variadicyn4,nil?ys24,arbace.lang.Compiler$AOT7,fnClassyn30,arbace.lang.Compiler$AOTRestFnyn26,arbace.lang.Compiler$AOTFnyn5,catchkn2,lbkn7,handlerkn11,finallyExpryn3,trykn7,tryExprkn10,catchExprsyn7,finallykn4,exprkn5,shiftkn4,maskyn11,bit-and-intyn19,bit-shift-right-intkn5,thenskn8,testTypekn7,defaultkn13,hash-identityyn4,whenys16,arbace.lang.Util5,equivyn5,breakyn10,identical?kn5,testsys16,arbace.lang.Util4,hashkn9,skipCheckyn16,java.lang.Numberyn6,switchyn9,.intValueyn5,labelkn11,defaultExprkn9,isDeftypekn4,collys26,arbace.lang.PersistentList5,EMPTYys28,arbace.lang.PersistentVector5,EMPTYys30,arbace.lang.PersistentArrayMap5,EMPTYkn5,exprskn1,kkn2,kwkn1,nkn3,strkn1,vkn7,keyvalsys30,arbace.lang.Compiler$Evaluator11,monitorExityn5,throwyn19,java.lang.Throwablekn7,excExprys30,arbace.lang.Compiler$Evaluator12,monitorEnterys14,arbace.lang.RT11,arrayToListyn12,.importClassyn21,arbace.lang.Namespaceyn6,.derefys14,arbace.lang.RT10,CURRENT_NSkn5,textsys24,arbace.lang.Compiler$AOT9,strConcatys16,java.lang.String1,1ys14,arbace.lang.RT3,setkn4,keysyn11,.isInstancekn4,typekn8,retClasskn8,reqParmskn8,restParmkn9,argLocalsys14,arbace.lang.RT10,doubleCastys14,arbace.lang.RT8,longCastkn13,compiledClasskn3,symkn16,volatile-mutablekn8,volatilekn22,unsynchronized-mutablekn6,publickn12,hintedFieldskn12,altCtorDropsyn3,m__yn6,methodks15,arbace.c2j.emit7,pendingkn4,objxyn11,constructoryn6,super.kn6,columnyn5,this.yn8,getBasisyn29,arbace.lang.IPersistentVectorys19,arbace.lang.Keyword6,internyn6,.valAtyn6,createkn7,mutableyn8,.withoutys14,arbace.lang.RT9,seqOrElsekn7,methodskn7,deftypekn5,superkn10,interfaceskn7,memberskn6,sourcekn8,fn-namesyn4,selfkn10,isVariadicyn8,doInvokeyn6,invokekn8,onceOnlyyn6,meta__yn8,.-__metayn8,fn-classyn6,__metayn4,metayn8,withMetayn1,mkn2,fnkn5,reifyys14,arbace.lang.RT16,loadClassForNameys14,arbace.lang.RT3,seqys14,arbace.lang.RT4,consys24,arbace.lang.Compiler$AOT2,atkn7,packagekn4,formyn8,defclassks3,c2j6,sourceyn4,loadyn4,initks3,c2j4,codekn6,holderkn7,extendskn10,implementskn8,abstractv11,arbace.core5,referv11,arbace.core7,requireR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn15,arbace.c2j.emitm2,R8,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).v11,arbace.core13,*loaded-libs*v11,arbace.core5,some?v15,arbace.c2j.emit10,node-cachev11,arbace.core5,assocR9,v11,arbace.core7,ex-infov13,arbace.string12,starts-with?v11,arbace.core4,subsv11,arbace.core6,symbolv11,arbace.core3,strv15,arbace.c2j.emit8,type-symv15,arbace.c2j.emit6,destubv11,arbace.core9,vary-metaR10,v15,arbace.c2j.emit10,prim-namesv11,arbace.core3,notv15,arbace.c2j.emit10,registeredv11,arbace.core5,swap!v11,arbace.core9,contains?v11,arbace.core8,identityR11,v15,arbace.c2j.emit11,registered?R12,l0,R13,v11,arbace.core4,atomR14,R15,R16,R17,R18,R19,v11,arbace.core4,namev11,arbace.core6,updatev11,arbace.core4,listR20,R21,v11,arbace.core4,mapvv15,arbace.c2j.emit10,emit-valuev11,arbace.core4,not=c92,R22,R23,V2,nTv11,arbace.core7,string?v11,arbace.core6,class?v11,arbace.core7,symbol?v11,arbace.core8,keyword?v11,arbace.core4,var?v15,arbace.c2j.emit4,failv11,arbace.core4,map?v11,arbace.core7,vector?v11,arbace.core4,seq?v11,arbace.core5,list?R24,v11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsR25,R26,R27,R28,R29,R30,v15,arbace.c2j.emit11,double-formR31,v15,arbace.c2j.emit9,char-formC17,java.lang.BooleanC14,java.lang.ByteC19,java.lang.CharacterC16,java.lang.DoubleC15,java.lang.FloatC17,java.lang.IntegerC14,java.lang.LongC15,java.lang.ShortR32,v11,arbace.core9,with-metav11,arbace.core9,namespaceR33,m2,R34,V2,R35,R35,R36,m2,R34,V2,R35,R35,R37,m2,R34,V2,R35,R35,R38,m2,R34,V1,R39,R33,m2,R34,V2,R35,R35,v11,arbace.core5,classv15,arbace.c2j.emit15,emit-list-arrayR40,m2,R34,V1,R21,v11,arbace.core6,mapcatv11,arbace.core5,list*v11,arbace.core3,mapR41,R34,v11,arbace.core3,vecv11,arbace.core6,repeatR42,R43,m2,R34,V1,R21,v11,arbace.core6,empty?R44,R45,m2,R34,V1,R21,v11,arbace.core3,seqR46,m2,R34,V1,R47,R48,m2,R34,V1,R21,R49,m2,R34,V1,R35,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*print-dup*R50,m2,R34,V1,R35,R51,R52,R53,R52,R54,R55,R56,R57,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,R72,v15,arbace.c2j.emit9,pool-kindv11,arbace.core6,concatv15,arbace.c2j.emit12,pool-partialc44,v15,arbace.c2j.emit12,pool-shared?c82,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstv15,arbace.c2j.emit11,pool-encodev11,arbace.core10,chunk-restv11,arbace.core4,nextc77,v15,arbace.c2j.emit8,pool-strc110,c84,c70,c118,c107,c115,c112,c100,c109,c80,c86,c68,c67,c66,c90,c74,c83,c73,c99,c78,c114,c108,c121,c69,c105,c76,v11,arbace.core4,run!v15,arbace.c2j.emit10,pool-partsv11,arbace.core4,intov11,arbace.core6,removev11,arbace.core11,map-indexedv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR73,v15,arbace.c2j.emit6,taggedR42,m6,R74,TR75,TR76,TR77,R78,R28,R52,v11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkm6,R74,TR75,TR76,Tv11,arbace.core4,restR73,R78,m6,R74,TR75,TR79,TR80,m2,R34,V2,R35,R81,R28,R82,R83,R84,R42,v15,arbace.c2j.emit14,runtime-class?v15,arbace.c2j.emit11,const-fieldv15,arbace.c2j.emit14,*late-classes*R32,m2,R34,V1,R35,v15,arbace.c2j.emit10,const-typeR85,v11,arbace.core4,fnilv11,arbace.core3,incR86,R87,v15,arbace.c2j.emit9,field-symR88,R89,v15,arbace.c2j.emit4,nodeR90,R91,v15,arbace.c2j.emit6,box-ofC16,java.lang.ObjectR92,R93,R52,R94,R95,R52,R96,m2,R34,V1,R42,v15,arbace.c2j.emit7,public?R52,v15,arbace.c2j.emit12,emit-unboxedv15,arbace.c2j.emit4,emitv15,arbace.c2j.emit3,fi?v15,arbace.c2j.emit9,unbox-argR97,R98,m2,R34,V1,R99,R100,R101,v15,arbace.c2j.emit8,constantR20,R21,R82,R102,R103,R104,R105,R106,v15,arbace.c2j.emit7,closed?v15,arbace.c2j.emit10,field-readR107,R108,R109,R110,R88,v15,arbace.c2j.emit9,local-symR111,R112,R113,R113,R114,R115,R116,R117,R118,R52,R119,v15,arbace.c2j.emit9,obj-arrayR120,m2,R34,V1,R21,R121,R52,R119,R122,R123,R124,v15,arbace.c2j.emit4,gsymR112,R125,v15,arbace.c2j.emit3,boxR126,R127,R128,R129,v15,arbace.c2j.emit10,typed-argsv15,arbace.c2j.emit10,param-tagsR52,R121,R52,R119,v13,arbace.string7,replacev14,arbace.j2g.jrt4,scanR130,v16,arbace.j2g.names13,go-class-namev11,arbace.core5,applyv15,arbace.c2j.emit10,descriptorv16,arbace.j2g.names11,method-basev15,arbace.c2j.emit8,jrt-scanR131,R132,v14,arbace.j2g.jrt14,struct-methodsv14,arbace.j2g.jrt13,iface-methodsv16,arbace.j2g.names9,impl-nameR52,R133,R134,R135,v15,arbace.c2j.emit19,compiled-interface?v15,arbace.c2j.emit11,method-callv15,arbace.c2j.emit20,emit-instance-methodR136,R137,R138,R139,R140,R112,R125,R126,R141,R129,R142,R143,m2,R34,V3,R42,R35,R21,v15,arbace.c2j.emit10,jrt-lacks?R144,R143,m2,R34,V3,R42,R35,R21,R29,m2,R34,V1,R99,R30,m2,R34,V1,R145,R112,R125,v15,arbace.c2j.emit8,long-boxR146,R147,R148,R148,R126,R128,R149,v15,arbace.c2j.emit8,long-minR146,R147,R148,R148,R126,R128,R126,R149,R150,R151,R149,R149,R152,R150,R153,R153,R154,R147,R146,R148,R155,R156,R156,R157,R154,R125,R149,R158,R159,R125,R149,R152,R160,R149,R161,v15,arbace.c2j.emit10,double-boxR150,R153,R154,R146,R155,R153,R162,R150,R149,R125,R149,R150,R160,R162,R163,v15,arbace.c2j.emit8,long-maxR164,R162,R164,R163,R149,R150,d0,R160,d0,R162,R156,d4607182418800017408,R153,d4607182418800017408,R149,d0,C19,arbace.lang.NumbersV1,R165,v15,arbace.c2j.emit8,long-op1v11,arbace.core4,somev11,arbace.core6,every?v15,arbace.c2j.emit8,long-op2R166,R52,R167,R168,R52,R169,v11,arbace.core4,keepR127,R126,v15,arbace.c2j.emit10,double-op1v15,arbace.c2j.emit10,double-op2R165,R170,R171,R172,R173,S1,R165,S2,R165,R170,R172,R174,R173,R175,v11,arbace.core6,vectorv11,arbace.core5,rangel1,S1,R165,R112,R125,R167,R112,R125,R169,R112,v15,arbace.c2j.emit17,numbers-intrinsicv15,arbace.c2j.emit18,emit-static-methodR176,m2,R34,V3,R84,R35,R21,R177,R178,v15,arbace.c2j.emit9,field-ok?R52,R179,R180,R181,m2,R34,V3,R42,R35,R182,R183,m2,R34,V2,R84,R35,R184,R185,m2,R34,V2,R84,R21,R186,R187,R82,R188,R52,R54,R91,R189,R190,R191,R192,R91,R192,R190,R189,R193,R194,R195,R82,R114,R114,R114,R52,R196,m2,R34,V1,R21,R197,v15,arbace.c2j.emit9,can-prim?R125,R198,R199,R200,R201,R202,R203,v15,arbace.c2j.emit17,emit-binding-initR204,R205,R112,R206,R207,R208,v11,arbace.core6,reset!R209,v15,arbace.c2j.emit4,primR98,m2,R34,V1,R99,R100,v15,arbace.c2j.emit14,emit-fn-class!v15,arbace.c2j.emit10,emit-localv11,arbace.core4,keysR210,R20,R211,V1,nR212,R112,R84,R125,R213,R112,R84,R214,m2,R34,V2,R35,R182,R114,R20,R215,R28,R20,R216,v15,arbace.c2j.emit13,body-instancev15,arbace.c2j.emit7,fn-wrapv15,arbace.c2j.emit12,identity-setR114,R112,R91,R217,R218,R219,R220,R221,R222,R223,R224,R225,R226,R227,R228,R229,R230,v11,arbace.core7,keywordR231,R232,v11,arbace.core3,setR233,R234,R235,m2,R34,V2,R42,R42,R236,R234,R149,R236,R236,R234,R149,R99,R236,R236,R234,R237,R236,R234,R235,m2,R34,V2,R42,R42,R236,v11,arbace.core10,sorted-mapR238,R239,R28,R240,R234,R127,R241,R242,R243,R52,R241,R242,R244,R245,S2,s9,instance?s5,localv15,arbace.c2j.emit8,emit-tryR246,v15,arbace.c2j.emit11,fn-instancev15,arbace.c2j.emit8,emit-defv15,arbace.c2j.emit11,emit-invokev15,arbace.c2j.emit9,line-metav15,arbace.c2j.emit19,emit-deftype-class!R247,R248,R249,R250,R44,v15,arbace.c2j.emit19,emit-instance-fieldv15,arbace.c2j.emit9,var-valueR251,R121,R252,R83,R253,R91,v11,arbace.core7,butlastv11,arbace.core4,lastv15,arbace.c2j.emit7,emit-ifv15,arbace.c2j.emit11,emit-assignv15,arbace.c2j.emit10,emit-letfnR51,R52,R53,R52,R54,R254,R82,R83,R255,v15,arbace.c2j.emit9,coll-callv15,arbace.c2j.emit8,emit-letR41,R42,R43,v15,arbace.c2j.emit10,emit-recurR256,R40,R257,R91,R258,v15,arbace.c2j.emit8,emit-newR259,R52,R260,R261,R25,R26,R91,R262,R263,R264,R52,R265,R266,R267,R32,v15,arbace.c2j.emit17,emit-static-fieldv15,arbace.c2j.emit9,emit-caseR268,R269,R20,R270,R20,R21,R271,R272,R273,R127,R274,v15,arbace.c2j.emit8,box-primR91,R273,R127,R259,R52,R260,v15,arbace.c2j.emit4,deepv15,arbace.c2j.emit7,throws?R98,m2,R34,V1,R99,R100,R93,R52,R94,R95,R52,R96,R52,R241,R52,R275,v15,arbace.c2j.emit8,ret-bodyR276,R277,R278,R205,R112,R279,R280,m2,R34,V1,R42,v15,arbace.c2j.emit12,prim-classesv11,arbace.core10,ns-resolvev11,arbace.core4,*ns*R281,R282,R283,m2,R284,TR285,m4,R286,TR75,Tv15,arbace.c2j.emit4,poolR287,R288,R88,v11,arbace.core4,takeR289,R88,R290,v15,arbace.c2j.emit11,method-bodym2,R286,Tm2,R286,TR73,v15,arbace.c2j.emit10,field-modsR291,R292,R88,R293,ML1,R294,m4,R104,i1293,R295,i26,R114,R88,m2,R286,TR88,R293,m2,R286,TR296,R28,R28,R293,m2,R286,TR296,R28,R28,R290,R297,m4,R286,TR74,TR298,R290,v15,arbace.c2j.emit9,tag-classR299,m2,R34,V1,R35,R300,R52,v15,arbace.c2j.emit9,box-classm2,R34,V1,R35,R301,m4,R286,TR74,TR54,R112,m2,R302,TR112,R114,R303,R20,R304,R28,R28,R305,R306,R307,R42,R308,v15,arbace.c2j.emit16,class-interfacesR309,R310,R311,R73,V2,R88,R312,v15,arbace.c2j.emit9,param-symR290,R313,R314,R315,m2,R286,TV2,R88,R312,m2,R286,TR88,R290,m2,R286,Tm2,R286,Tv15,arbace.c2j.emit8,top-nameR316,R312,R88,R293,ML1,R294,m4,R104,i1372,R295,i26,m2,R286,TV1,R88,R317,R54,V1,ML3,R114,ML2,R318,R88,m4,R104,i1373,R295,i53,R317,m4,R104,i1373,R295,i47,R114,R88,R73,R84,R319,m4,R286,TR74,TR73,R320,R54,R290,ML2,R318,R88,m4,R104,i1405,R295,i117,R321,m2,R286,TV1,R88,R54,R290,R322,m2,R286,TR53,R88,R323,R54,R20,R323,R88,R324,R325,R42,v11,arbace.core5,doallR234,R213,R326,m2,R34,V1,R35,R121,R52,R119,R103,v11,arbace.core12,define-proxyR82,R327,m2,R34,V1,R42,R20,R21,m2,R34,V1,R35,m2,R34,V1,R42,R118,R52,R119,R103,v11,arbace.core15,get-proxy-classR82,R328,m2,R34,V2,R42,R42,R327,m2,R34,V1,R42,R20,R21,R195,R267,R38,R52,R39,m2,R34,V2,R42,R42,m2,R34,V1,R42,v11,arbace.core7,sort-byR290,m4,R79,TR74,TR91,R329,R28,R28,v11,arbace.core7,find-nsv13,arbace.string9,includes?V2,R330,s0,v15,arbace.c2j.emit7,unit-nsv15,arbace.c2j.emit11,unit-methodv15,arbace.c2j.emit17,loader-part-unitsR331,v15,arbace.c2j.emit15,unnamed-packagev15,arbace.c2j.emit11,pool-fieldsR332,R286,R75,R333,R290,R334,m4,R286,TR74,TV1,nR91,R332,R74,R290,R335,m2,R74,TR290,R334,m2,R74,TV1,nR91,m2,R74,Tm2,R74,TV1,nv11,arbace.core13,partition-allR332,R290,R334,m4,R286,TR74,Tv11,arbace.core8,to-arrayV1,nR91,v11,arbace.core6,dissocR336,v15,arbace.c2j.emit10,class-formv15,arbace.c2j.emit11,simple-nameR337,R332,m6,R286,TR74,TR75,TR332,m6,R286,TR74,TR133,TR338,R332,m6,R286,TR74,TR75,TR339,v11,arbace.core4,peekv11,arbace.core3,popv11,arbace.core8,group-byv11,arbace.core4,sortR290,m4,R286,TR340,TR88,m4,R286,TR340,T")

var Lit_1 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000238__31000242")

var Lit_2 *jrt.String = jrt.Intern("new-instance")

var Lit_3 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000238__31000242$fn__31000243")

var Lit_4 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000238__31000242$fn__31000243$fn__31000244")

var Lit_5 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form$fn__31000690")

var Lit_6 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form$mods__31000692")

var Lit_7 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$parent__31000697")

var Lit_8 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$fn__31000699")

var Lit_9 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000701__31000705")

var Lit_10 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$fn__31000711")

var Lit_11 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$children_of__31000713")

var Lit_12 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000715__31000719")

var Lit_13 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000701__31000705$fn__31000706")

var Lit_14 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000701__31000705$fn__31000706$fn__31000707")

var Lit_15 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000715__31000719$fn__31000720")

var Lit_16 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31000715__31000719$fn__31000720$fn__31000721")

var Lit_17 *jrt.String = jrt.Intern("$")

var Lit_18 *jrt.String = jrt.Intern("no class for ")

var Lit_19 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000361__31000365")

var Lit_20 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000361__31000365$fn__31000366")

var Lit_21 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000361__31000365$fn__31000366$fn__31000367")

var Lit_22 *jrt.String = jrt.Intern(" implements ")

var Lit_23 *jrt.String = jrt.Intern(", made at run time")

var Lit_24 *jrt.String = jrt.Intern("const-")

var Lit_25 *jrt.String = jrt.Intern("V")

var Lit_26 *jrt.String = jrt.Intern("J")

var Lit_27 *jrt.String = jrt.Intern("I")

var Lit_28 *jrt.String = jrt.Intern("D")

var Lit_29 *jrt.String = jrt.Intern("Z")

var Lit_30 *jrt.String = jrt.Intern("C")

var Lit_31 *jrt.String = jrt.Intern("F")

var Lit_32 *jrt.String = jrt.Intern("S")

var Lit_33 *jrt.String = jrt.Intern("B")

var Lit_34 *jrt.String = jrt.Intern(".")

var Lit_35 *jrt.String = jrt.Intern("/")

var Lit_36 *jrt.String = jrt.Intern("L")

var Lit_37 *jrt.String = jrt.Intern(";")

var Lit_38 *jrt.String = jrt.Intern("compile__stub.")

var Lit_39 *jrt.String = jrt.Intern("isNeg")

var Lit_40 *jrt.String = jrt.Intern("isPos")

var Lit_41 *jrt.String = jrt.Intern("unchecked_minus")

var Lit_42 *jrt.String = jrt.Intern("unchecked_dec")

var Lit_43 *jrt.String = jrt.Intern("incP")

var Lit_44 *jrt.String = jrt.Intern("minus")

var Lit_45 *jrt.String = jrt.Intern("unchecked_inc")

var Lit_46 *jrt.String = jrt.Intern("dec")

var Lit_47 *jrt.String = jrt.Intern("inc")

var Lit_48 *jrt.String = jrt.Intern("minusP")

var Lit_49 *jrt.String = jrt.Intern("isZero")

var Lit_50 *jrt.String = jrt.Intern("decP")

var Lit_51 *jrt.String = jrt.Intern("lt")

var Lit_52 *jrt.String = jrt.Intern("addP")

var Lit_53 *jrt.String = jrt.Intern("unchecked_add")

var Lit_54 *jrt.String = jrt.Intern("unchecked_multiply")

var Lit_55 *jrt.String = jrt.Intern("gte")

var Lit_56 *jrt.String = jrt.Intern("lte")

var Lit_57 *jrt.String = jrt.Intern("add")

var Lit_58 *jrt.String = jrt.Intern("multiply")

var Lit_59 *jrt.String = jrt.Intern("multiplyP")

var Lit_60 *jrt.String = jrt.Intern("gt")

var Lit_61 *jrt.String = jrt.Intern("equiv")

var Lit_62 *jrt.String = jrt.Intern("try")

var Lit_63 *jrt.String = jrt.Intern("def")

var Lit_64 *jrt.String = jrt.Intern("invoke")

var Lit_65 *jrt.String = jrt.Intern("instance-method")

var Lit_66 *jrt.String = jrt.Intern("empty")

var Lit_67 *jrt.String = jrt.Intern("unknown empty collection")

var Lit_68 *jrt.String = jrt.Intern("instance-field")

var Lit_69 *jrt.String = jrt.Intern("var")

var Lit_70 *jrt.String = jrt.Intern("keyword-invoke")

var Lit_71 *jrt.String = jrt.Intern("do")

var Lit_72 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000326")

var Lit_73 *jrt.String = jrt.Intern("fn")

var Lit_74 *jrt.String = jrt.Intern("if")

var Lit_75 *jrt.String = jrt.Intern("set!")

var Lit_76 *jrt.String = jrt.Intern("with-meta")

var Lit_77 *jrt.String = jrt.Intern("letfn")

var Lit_78 *jrt.String = jrt.Intern("number")

var Lit_79 *jrt.String = jrt.Intern("the-var")

var Lit_80 *jrt.String = jrt.Intern("keyword")

var Lit_81 *jrt.String = jrt.Intern("local")

var Lit_82 *jrt.String = jrt.Intern("string")

var Lit_83 *jrt.String = jrt.Intern("vector")

var Lit_84 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000328")

var Lit_85 *jrt.String = jrt.Intern("let")

var Lit_86 *jrt.String = jrt.Intern("recur")

var Lit_87 *jrt.String = jrt.Intern("constant")

var Lit_88 *jrt.String = jrt.Intern("map")

var Lit_89 *jrt.String = jrt.Intern("monitor-exit")

var Lit_90 *jrt.String = jrt.Intern("throw")

var Lit_91 *jrt.String = jrt.Intern("new")

var Lit_92 *jrt.String = jrt.Intern("nil")

var Lit_93 *jrt.String = jrt.Intern("boolean")

var Lit_94 *jrt.String = jrt.Intern("monitor-enter")

var Lit_95 *jrt.String = jrt.Intern("list")

var Lit_96 *jrt.String = jrt.Intern("import")

var Lit_97 *jrt.String = jrt.Intern("static-method")

var Lit_98 *jrt.String = jrt.Intern("static-field")

var Lit_99 *jrt.String = jrt.Intern("str-concat")

var Lit_100 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000330")

var Lit_101 *jrt.String = jrt.Intern("case")

var Lit_102 *jrt.String = jrt.Intern("set")

var Lit_103 *jrt.String = jrt.Intern("instance?")

var Lit_104 *jrt.String = jrt.Intern("no back end for ")

var Lit_105 *jrt.String = jrt.Intern(" ")

var Lit_106 *jrt.String = jrt.Intern("set! of a local that is no field")

var Lit_107 *jrt.String = jrt.Intern(".-")

var Lit_108 *jrt.String = jrt.Intern("set! of ")

var Lit_109 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$sm__31000304")

var Lit_110 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$ret__31000306")

var Lit_111 *jrt.String = jrt.Intern("case-")

var Lit_112 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$arm__31000308")

var Lit_113 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$fn__31000311")

var Lit_114 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$fn__31000317")

var Lit_115 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ftype__31000376")

var Lit_116 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fsym__31000378")

var Lit_117 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fn__31000380")

var Lit_118 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000382__31000386")

var Lit_119 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ps__31000392")

var Lit_120 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000396__31000400")

var Lit_121 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fn__31000413")

var Lit_122 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000418__31000422")

var Lit_123 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000434__31000438")

var Lit_124 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000452__31000456")

var Lit_125 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000382__31000386$fn__31000387")

var Lit_126 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000382__31000386$fn__31000387$fn__31000388")

var Lit_127 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000396__31000400$fn__31000401")

var Lit_128 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000396__31000400$fn__31000401$fn__31000402")

var Lit_129 *jrt.String = jrt.Intern("v__")

var Lit_130 *jrt.String = jrt.Intern("Value")

var Lit_131 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000418__31000422$fn__31000423")

var Lit_132 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000418__31000422$fn__31000423$fn__31000424")

var Lit_133 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000434__31000438$fn__31000439")

var Lit_134 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000434__31000438$fn__31000439$fn__31000440")

var Lit_135 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000434__31000438$fn__31000439$fn__31000446")

var Lit_136 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000434__31000438$fn__31000439$fn__31000448")

var Lit_137 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000434__31000438$fn__31000439$fn__31000440$fn__31000441")

var Lit_138 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000434__31000438$fn__31000439$fn__31000440$fn__31000443")

var Lit_139 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000452__31000456$fn__31000457")

var Lit_140 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000452__31000456$fn__31000457$fn__31000458")

var Lit_141 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ps__31000392$fn__31000393")

var Lit_142 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$fn__31000465")

var Lit_143 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000467__31000471")

var Lit_144 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000477__31000481")

var Lit_145 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000487__31000491")

var Lit_146 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$fn__31000497")

var Lit_147 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000499__31000503")

var Lit_148 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000509__31000513")

var Lit_149 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000527__31000531")

var Lit_150 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000537__31000541")

var Lit_151 *jrt.String = jrt.Intern("__")

var Lit_152 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000467__31000471$fn__31000472")

var Lit_153 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000467__31000471$fn__31000472$fn__31000473")

var Lit_154 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000477__31000481$fn__31000482")

var Lit_155 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000477__31000481$fn__31000482$fn__31000483")

var Lit_156 *jrt.String = jrt.Intern("c__")

var Lit_157 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000487__31000491$fn__31000492")

var Lit_158 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000487__31000491$fn__31000492$fn__31000493")

var Lit_159 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000499__31000503$fn__31000504")

var Lit_160 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000499__31000503$fn__31000504$fn__31000505")

var Lit_161 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000509__31000513$fn__31000514")

var Lit_162 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000509__31000513$fn__31000514$fn__31000515")

var Lit_163 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000509__31000513$fn__31000514$fn__31000521")

var Lit_164 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000509__31000513$fn__31000514$fn__31000523")

var Lit_165 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000509__31000513$fn__31000514$fn__31000515$fn__31000516")

var Lit_166 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000509__31000513$fn__31000514$fn__31000515$fn__31000518")

var Lit_167 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000527__31000531$fn__31000532")

var Lit_168 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000527__31000531$fn__31000532$fn__31000533")

var Lit_169 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000537__31000541$fn__31000542")

var Lit_170 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000537__31000541$fn__31000542$fn__31000543")

var Lit_171 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTR")

var Lit_172 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTF")

var Lit_173 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_if$br__31000227")

var Lit_174 *jrt.String = jrt.Intern("target-")

var Lit_175 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke$call__31000157")

var Lit_176 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke$fn__31000161")

var Lit_177 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke$call__31000157$fn__31000158")

var Lit_178 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_let$fn__31000232")

var Lit_179 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000253")

var Lit_180 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000255")

var Lit_181 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000257__31000261")

var Lit_182 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000267__31000273")

var Lit_183 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000286")

var Lit_184 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000288")

var Lit_185 *jrt.String = jrt.Intern("body-")

var Lit_186 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000257__31000261$fn__31000262")

var Lit_187 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000257__31000261$fn__31000262$fn__31000263")

var Lit_188 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000267__31000273$fn__31000274")

var Lit_189 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000267__31000273$fn__31000274$iter__31000269__31000278")

var Lit_190 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000267__31000273$fn__31000274$iter__31000269__31000278$fn__31000279")

var Lit_191 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000267__31000273$fn__31000274$iter__31000269__31000278$fn__31000279$fn__31000280")

var Lit_192 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_list_array$fn__31000036")

var Lit_193 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_recur$fn__31000235")

var Lit_194 *jrt.String = jrt.Intern("recur arg for primitive local: ")

var Lit_195 *jrt.String = jrt.Intern(" is not matching primitive")

var Lit_196 *jrt.String = jrt.Intern("__init")

var Lit_197 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$unit_methods__31000625")

var Lit_198 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000632")

var Lit_199 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000644__31000648")

var Lit_200 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000660__31000664")

var Lit_201 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000674__31000678")

var Lit_202 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000632$iter__31000633__31000637")

var Lit_203 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000632$iter__31000633__31000637$fn__31000638")

var Lit_204 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000632$iter__31000633__31000637$fn__31000638$fn__31000639")

var Lit_205 *jrt.String = jrt.Intern("unit")

var Lit_206 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000644__31000648$fn__31000649")

var Lit_207 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000644__31000648$fn__31000649$fn__31000650")

var Lit_208 *jrt.String = jrt.Intern("$part")

var Lit_209 *jrt.String = jrt.Intern("")

var Lit_210 *jrt.String = jrt.Intern("part")

var Lit_211 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000660__31000664$fn__31000665")

var Lit_212 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000660__31000664$fn__31000665$fn__31000666")

var Lit_213 *jrt.String = jrt.Intern("init")

var Lit_214 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000674__31000678$fn__31000679")

var Lit_215 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000674__31000678$fn__31000679$fn__31000680")

var Lit_216 *jrt.String = jrt.Intern("load")

var Lit_217 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$unit_methods__31000625$fn__31000626")

var Lit_218 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$body__31000291")

var Lit_219 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000293__31000297")

var Lit_220 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000293__31000297$fn__31000298")

var Lit_221 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000293__31000297$fn__31000298$fn__31000299")

var Lit_222 *jrt.String = jrt.Intern("unboxed emit of ")

var Lit_223 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_unboxed$fn__31000335")

var Lit_224 *jrt.String = jrt.Intern("no unboxed back end for ")

var Lit_225 *jrt.String = jrt.Intern("TYPE")

var Lit_226 *jrt.String = jrt.Intern("a record as a constant: ")

var Lit_227 *jrt.String = jrt.Intern("a deftype as a constant: ")

var Lit_228 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value$fn__31000045")

var Lit_229 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value$fn__31000047")

var Lit_230 *jrt.String = jrt.Intern("#<")

var Lit_231 *jrt.String = jrt.Intern("can't embed unreadable object in code: ")

var Lit_232 *jrt.String = jrt.Intern("arbace.lang.Compiler$AST")

var Lit_233 *jrt.String = jrt.Intern("arbace.lang.Var")

var Lit_234 *jrt.String = jrt.Intern("arbace.lang.Keyword")

var Lit_235 *jrt.String = jrt.Intern("arbace.lang.Symbol")

var Lit_236 *jrt.String = jrt.Intern("arbace.lang.IObj")

var Lit_237 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_238 *jrt.String = jrt.Intern("arbace.lang.IPersistentVector")

var Lit_239 *jrt.String = jrt.Intern("arbace.lang.IPersistentSet")

var Lit_240 *jrt.String = jrt.Intern("arbace.lang.IPersistentList")

var Lit_241 *jrt.String = jrt.Intern("arbace.lang.ISeq")

var Lit_242 *jrt.String = jrt.Intern("arbace.lang.IType")

var Lit_243 *jrt.String = jrt.Intern("arbace.lang.IRecord")

var Lit_244 *jrt.String = jrt.Intern("arbace.lang.PersistentHashSet")

var Lit_245 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_246 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_247 *jrt.String = jrt.Intern("java.util.regex.Pattern")

var Lit_248 *jrt.String = jrt.Intern("aot: ")

var Lit_249 *jrt.String = jrt.Intern("fiMethod")

var Lit_250 *jrt.String = jrt.Intern("/go/arbace/jrt")

var Lit_251 *jrt.String = jrt.Intern("ARBACE_AOT_ROOT")

var Lit_252 *jrt.String = jrt.Intern("fn-class")

var Lit_253 *jrt.String = jrt.Intern("fncls__")

var Lit_254 *jrt.String = jrt.Intern("d")

var Lit_255 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$fn__31000727")

var Lit_256 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000729__31000733")

var Lit_257 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000729__31000733$fn__31000734")

var Lit_258 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000729__31000733$fn__31000734$fn__31000735")

var Lit_259 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000729__31000733$fn__31000734$fn__31000745")

var Lit_260 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31000729__31000733$fn__31000734$fn__31000735$fn__31000739")

var Lit_261 *jrt.String = jrt.Intern("p")

var Lit_262 *jrt.String = jrt.Intern("(")

var Lit_263 *jrt.String = jrt.Intern(")")

var Lit_264 *jrt.String = jrt.Intern("arbace.c2j.emit$jrt_lacks_QMARK_$fn__31000168")

var Lit_265 *jrt.String = jrt.Intern("_")

var Lit_266 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op1$guard__31000182")

var Lit_267 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op2$checked__31000176")

var Lit_268 *jrt.String = jrt.Intern("and")

var Lit_269 *jrt.String = jrt.Intern("xor")

var Lit_270 *jrt.String = jrt.Intern("or")

var Lit_271 *jrt.String = jrt.Intern("remainder")

var Lit_272 *jrt.String = jrt.Intern("shiftLeft")

var Lit_273 *jrt.String = jrt.Intern("quotient")

var Lit_274 *jrt.String = jrt.Intern("shiftRight")

var Lit_275 *jrt.String = jrt.Intern("fn-method")

var Lit_276 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000343__31000347")

var Lit_277 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$fn__31000353")

var Lit_278 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$fn__31000355")

var Lit_279 *jrt.String = jrt.Intern("p-")

var Lit_280 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000343__31000347$fn__31000348")

var Lit_281 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000343__31000347$fn__31000348$fn__31000349")

var Lit_282 *jrt.String = jrt.Intern("a call of a method of a class made at run time: ")

var Lit_283 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000190")

var Lit_284 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000193")

var Lit_285 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000195")

var Lit_286 *jrt.String = jrt.Intern("arbace.lang.Numbers")

var Lit_287 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$lv__31000197")

var Lit_288 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$dv__31000199")

var Lit_289 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000202")

var Lit_290 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$is__31000207")

var Lit_291 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000211")

var Lit_292 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000213")

var Lit_293 *jrt.String = jrt.Intern("nr-")

var Lit_294 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000215")

var Lit_295 *jrt.String = jrt.Intern("na-")

var Lit_296 *jrt.String = jrt.Intern("n")

var Lit_297 *jrt.String = jrt.Intern("-")

var Lit_298 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$is__31000207$fn__31000208")

var Lit_299 *jrt.String = jrt.Intern("arbace.c2j.emit$obj_array$fn__31000149")

var Lit_300 *jrt.String = jrt.Intern("arbace.c2j.emit$pool$fn__31000031")

var Lit_301 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$num__31000055")

var Lit_302 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$arr__31000057")

var Lit_303 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$fn__31000064")

var Lit_304 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_305 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000068")

var Lit_306 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$walk__31000070")

var Lit_307 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000076")

var Lit_308 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000084")

var Lit_309 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000090")

var Lit_310 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000096")

var Lit_311 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000105")

var Lit_312 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000110__31000114")

var Lit_313 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000110__31000114$fn__31000115")

var Lit_314 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000110__31000114$fn__31000115$fn__31000116")

var Lit_315 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000021")

var Lit_316 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000023")

var Lit_317 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000023$fn__31000024")

var Lit_318 *jrt.String = jrt.Intern("cut")

var Lit_319 *jrt.String = jrt.Intern("mismatched primitive return, expected ")

var Lit_320 *jrt.String = jrt.Intern(", had ")

var Lit_321 *jrt.String = jrt.Intern("arbace.lang.IProxy")

var Lit_322 *jrt.String = jrt.Intern("arbace.c2j.emit$typed_args$fn__31000144")

var Lit_323 *jrt.String = jrt.Intern("uncheckedIntCast")

var Lit_324 *jrt.String = jrt.Intern("intCast")

var Lit_325 *jrt.String = jrt.Intern("uncheckedFloatCast")

var Lit_326 *jrt.String = jrt.Intern("floatCast")

var Lit_327 *jrt.String = jrt.Intern("uncheckedDoubleCast")

var Lit_328 *jrt.String = jrt.Intern("doubleCast")

var Lit_329 *jrt.String = jrt.Intern("uncheckedLongCast")

var Lit_330 *jrt.String = jrt.Intern("longCast")

var Lit_331 *jrt.String = jrt.Intern("uncheckedByteCast")

var Lit_332 *jrt.String = jrt.Intern("byteCast")

var Lit_333 *jrt.String = jrt.Intern("uncheckedShortCast")

var Lit_334 *jrt.String = jrt.Intern("shortCast")

var Lit_335 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_336 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000554__31000558")

var Lit_337 *jrt.String = jrt.Intern("a top-level fn closing over locals")

var Lit_338 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000586__31000590")

var Lit_339 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$fn__31000616")

var Lit_340 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000554__31000558$fn__31000559")

var Lit_341 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000554__31000558$fn__31000559$fn__31000560")

var Lit_342 *jrt.String = jrt.Intern("type")

var Lit_343 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000554__31000558$fn__31000559$fn__31000574")

var Lit_344 *jrt.String = jrt.Intern("an event of a class made at run time: ")

var Lit_345 *jrt.String = jrt.Intern("iface")

var Lit_346 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000554__31000558$fn__31000559$fn__31000576")

var Lit_347 *jrt.String = jrt.Intern("proxy")

var Lit_348 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000554__31000558$fn__31000559$fn__31000578")

var Lit_349 *jrt.String = jrt.Intern("imethod")

var Lit_350 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000554__31000558$fn__31000559$fn__31000580")

var Lit_351 *jrt.String = jrt.Intern("stub")

var Lit_352 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000554__31000558$fn__31000559$fn__31000582")

var Lit_353 *jrt.String = jrt.Intern("ns")

var Lit_354 *jrt.String = jrt.Intern("an event of kind ")

var Lit_355 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000554__31000558$fn__31000559$fn__31000560$fn__31000562")

var Lit_356 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000554__31000558$fn__31000559$fn__31000560$fn__31000564")

var Lit_357 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000554__31000558$fn__31000559$fn__31000560$fn__31000566")

var Lit_358 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000554__31000558$fn__31000559$fn__31000560$fn__31000568")

var Lit_359 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000554__31000558$fn__31000559$fn__31000560$fn__31000570")

var Lit_360 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000586__31000590$fn__31000591")

var Lit_361 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000586__31000590$fn__31000591$fn__31000592")

var Lit_362 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000586__31000590$fn__31000591$iter__31000604__31000608")

var Lit_363 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000586__31000590$fn__31000591$fn__31000592$iter__31000593__31000597")

var Lit_364 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000586__31000590$fn__31000591$fn__31000592$iter__31000593__31000597$fn__31000598")

var Lit_365 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000586__31000590$fn__31000591$fn__31000592$iter__31000593__31000597$fn__31000598$fn__31000599")

var Lit_366 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000586__31000590$fn__31000591$iter__31000604__31000608$fn__31000609")

var Lit_367 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000586__31000590$fn__31000591$iter__31000604__31000608$fn__31000609$fn__31000610")

var Lit_368 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,xyn3,msgyn1,&yn4,datakn3,tagyn6,Stringyn5,Classyn4,voidyn6,doubleyn4,charyn4,byteyn7,booleanyn5,floatyn4,longyn5,shortyn3,intyn1,syn1,cyn3,ctxyn3,topyn1,vyn5,ctypekn8,declaredyn2,xsyn9,Characterkn4,longkn6,doublekn3,intkn6,symbolkn6,stringkn6,vectorkn4,listkn3,varkn7,keywordkn5,classkn3,nilkn3,setkn7,booleankn3,mapkn4,charkn7,patternyn13,StringBuilderyn6,sharedyn6,constskn7,dynamicyn4,baseyn1,byn2,lbyn1,eyn1,nyn1,fyn2,psyn2,esyn3,Varyn8,unboxed?yn24,java.lang.reflect.Methodyn1,tyn4,argsys14,java.lang.Long9,MIN_VALUEys14,java.lang.Long9,MAX_VALUEyn2,opyn1,yyn4,slowyn1,ryn23,java.lang.reflect.Fieldyn4,top?yn3,symyn4,inityn2,oxyn10,nil-localsyn4,bodyys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys17,java.lang.Integer7,valueOfys17,java.lang.Boolean7,valueOfys19,java.lang.Character7,valueOfys15,java.lang.Float7,valueOfys15,java.lang.Short7,valueOfys14,java.lang.Byte7,valueOfyn2,mnyn6,paramsv11,arbace.core5,in-nsMyn15,arbace.c2j.emitm2,R0,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).m2,R0,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).R1,v15,arbace.c2j.emit10,node-cachem10,R2,TR3,i35,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s58,The nodes' maps by node (the back end runs on one thread).v15,arbace.c2j.emit4,nodem10,R6,L1,V1,R7,R0,s62,The analyzed node x as a map (Compiler$AST/node), nil for nil.R3,i39,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,failm10,R2,TR6,L1,V3,R8,R9,V1,R10,R3,i48,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,destubm10,R6,L1,V1,Myn1,nm2,R11,R12,R0,s74,A class name without the compile stub's prefix (Compiler.destubClassName).R3,i54,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,type-symm10,R6,L1,V1,Myn1,cm2,R11,R13,R0,s93,The Java forms type of class c: a primitive's name, a class's binary name, an array as\n  T/n.R3,i59,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,prim-namesR14,R15,R16,R17,R18,R19,R20,R21,R22,m8,R2,TR3,i70,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,taggedm12,R2,TR6,L1,V2,R23,R24,R0,s44,Symbol s with the Java forms tag of class c.R3,i74,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,registeredv11,arbace.core4,atomm10,R2,TR3,i83,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s84,Whether a class name is registered in the program (Class/forName finds it), by name.v15,arbace.c2j.emit11,registered?m10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i87,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,runtime-class?m12,R2,TR6,L1,V2,Myn1,cm2,R11,R13,R25,R0,s291,Is class c made at run time (a Dyn class: an evaluated fn's, deftype's, interface's, proxy's)\n  rather than a class of the program, or one the program does not register by name (java.sql's,\n  whose members reflection reached from a world class)? Such a class is not named in compiled\n  code.R3,i104,R4,i1,R5,s18,arbace/c2j/emit.aev11,arbace.core12,define-proxyv15,arbace.c2j.emit7,public?m10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i119,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,top-namem10,R2,TR6,L1,V1,Myn1,nm2,R11,R12,R3,i125,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,poolm12,R2,TR6,L1,V2,R25,R26,R0,s178,The constants of top-level class top (a namespace's holder, a deftype, a loader), which its\n  member classes share (SA145): an atom {:name :consts :const-map}, made on first use.R3,i127,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,const-fieldm12,R2,TR6,L1,V3,R25,R27,R28,R0,s236,The static field holding constant value v in the class being emitted, made on first use (as\n  the JVM's const__N, one per distinct object): its symbol, const-N (a munged local's name has\n  no -, so no local, name__index, can shadow it).R3,i137,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-valuem8,R29,TR3,i158,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,emit-list-arraym10,R2,TR6,L1,V2,R25,R30,R3,i160,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,char-formm10,R2,TR6,L1,V1,Myn1,cm2,R11,R31,R3,i163,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,double-formm10,R2,TR6,L1,V1,Myn1,dm2,R11,R15,R3,i169,R4,i1,R5,s18,arbace/c2j/emit.aem10,R6,L1,V2,R25,R27,R0,s72,Code making constant value v (ObjExpr.emitValue), its metadata included.R3,i174,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,pool-kindm12,R2,TR6,L1,V1,R27,R0,s58,The tag of constant v, in the order of emit-value's cases.R3,i250,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,pool-partialS16,R32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,m10,R2,TR3,i275,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s61,The kinds whose metadata is made too (emit-value's partial?).v15,arbace.c2j.emit12,pool-shared?m12,R2,TR6,L1,V1,R27,R0,s84,Is v made once in a pool and named where used: a keyword, a symbol without metadata.R3,i279,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,pool-partsm12,R2,TR6,L1,V1,R27,R0,s62,The values constant v is made of (its elements, its metadata).R3,i284,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,pool-strm10,R2,TR6,L1,V2,Myn2,sbm2,R11,R48,Myn1,sm2,R11,R12,R3,i295,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,pool-encodem12,R2,TR6,L1,V3,Myn2,sbm2,R11,R48,R49,R27,R0,s102,Appends the encoding of v to sb (Compiler$AOT/poolValue's format); shared: shared value →\n  its index.R3,i298,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,pool-fieldsm12,R2,TR6,L1,V1,R50,R0,s264,The static fields of constants consts ([sym type value alias] ...): the pool's array, decoded\n  once (Compiler$AOT/pool), then each constant's field, its element, or for one with an alias\n  (a split loader's constant an earlier part made, SA210) that part's field.R3,i346,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,const-typem10,R2,TR6,L1,V1,R27,R3,i379,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,*late-classes*m10,R51,TR3,i385,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s398,The names of the classes the Java forms compiler made while the program prepared (its\n  deftypes, fns and defclasses using the Java forms, arbace.c2j.main's java-forms-classes): in the\n  tree, but j2g may leave one out (Clojure in its body it cannot analyze, F2.4), so a constant\n  naming one is looked up where used, as a class made at run time, and the classes holding it\n  initialize without it.v15,arbace.c2j.emit8,constantm10,R2,TR6,L1,V2,R25,R27,R3,i393,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,gsymm12,R2,TR6,L1,V2,R25,R52,R0,s146,A fresh name for a temporary of the emitted code, numbered per class being emitted (the\n  output does not depend on the program's gensym counter).R3,i406,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,local-symm12,R2,TR6,L1,V1,R53,R0,s95,The Java forms local of LocalBinding lb (its node b): its name and index, unique in a\n  method.R3,i414,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,identity-setm12,R2,TR6,L1,V1,R30,R0,s259,The objects of xs as a set by identity. A fn's closes map cannot be asked containsKey: its\n  keys, LocalBindings, hash by their index (Arbace's deterministic hashCode), and FnExpr.parse\n  renumbers a direct fn's arguments after its inner fns closed over them.R3,i420,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,closed?m10,R2,TR6,L1,V2,R25,R54,R3,i429,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,field-symm10,R2,TR6,L1,V1,R53,R3,i433,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,field-readm10,R2,TR6,L1,V3,R25,R54,R53,R3,i435,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,emitm8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,emit-unboxedm8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,emit-fn-class!m8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,emit-deftype-class!m8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,emit-bodym8,R29,TR3,i441,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,primm10,R2,TR6,L1,V1,R55,R3,i443,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,can-prim?m10,R2,TR6,L1,V1,R56,R3,i445,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,box-ofm8,R29,TR3,i447,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit3,boxm12,R2,TR6,L1,V2,R57,Myn1,cm2,R11,R13,R0,s113,Form f of type c as a boxed value (emitBoxReturn: valueOf, long's Numbers.num being\n  Long.valueOf; void as nil).R3,i449,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,unbox-argm12,R2,TR6,L1,V3,R25,R57,Myn1,pm2,R11,R13,R0,s67,Boxed form f converted to parameter type p (HostExpr.emitUnboxArg).R3,i458,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit3,fi?m12,R2,TR6,L1,V1,Myn1,pm2,R11,R13,R0,s136,Is p a functional interface a fn argument is adapted to (Clojure 1.12's FISupport, as the\n  analysis decides it: Compiler$AST/fiMethod)?R3,i477,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,typed-argsm12,R2,TR6,L1,V3,R25,R58,R59,R0,s70,The arguments es as parameters of types ps (MethodExpr.emitTypedArgs).R3,i484,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,param-tagsm10,R2,TR6,L1,V1,R58,R3,i508,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,obj-arraym10,R2,TR6,L1,V2,R25,R59,R3,i510,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,var-valuem10,R2,TR6,L1,V2,R25,Myn1,vm2,R11,R60,R3,i513,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,line-metam10,R2,TR6,L1,V2,R57,R56,R3,i517,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-localm10,R2,TR6,L1,V3,R25,R56,R61,R3,i522,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,emit-invokem10,R2,TR6,L1,V2,R25,R56,R3,i534,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,descriptorm10,R2,TR6,L1,V1,Myn1,cm2,R11,R13,R3,i564,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,jrt-scanm8,R2,TR3,i572,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,jrt-lacks?m12,R2,TR6,L1,V1,Myn1,mm2,R11,R62,R0,s255,Is method m declared by a class jrt writes by hand (not a stand-in j2g's translation\n  replaces) without it in Go? j2g would translate a direct call to a throw; the member tables\n  (reflection) have such members, so compiled code calls them by reflection.R3,i575,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,method-callm12,R2,TR6,L1,V4,R25,Myn1,mm2,R11,R62,R63,R64,R0,s69,A call of resolved method m: static (target nil) or on target form t.R3,i594,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,compiled-interface?m12,R2,TR6,L1,V2,R25,Myn1,cm2,R11,R13,R0,s86,Is class c an interface of a namespace being compiled (gen-interface's, a protocol's)?R3,i607,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit20,emit-instance-methodm10,R2,TR6,L1,V3,R25,R56,R61,R3,i612,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-minR65,m8,R2,TR3,i655,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-maxR66,m8,R2,TR3,i656,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-boxm10,R2,TR6,L1,V1,R57,R3,i658,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-boxm10,R2,TR6,L1,V1,R57,R3,i659,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-op2m12,R2,TR6,L1,V5,R67,R7,R68,R69,R70,R0,s202,The Long case of Numbers' binary operation op on longs x, y (symbols; r the result's local):\n  a form of the operation's result type, slow where Numbers would not answer a long; nil: not\n  an intrinsic.R3,i661,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-op2m12,R2,TR6,L1,V3,R67,R7,R68,R0,s166,The Double case (both operands Double) of Numbers' binary operation op (DoubleOps: the '\n  operations are the others, a difference the sum with the negation), or nil.R3,i696,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-op1m12,R2,TR6,L1,V3,R67,R7,R69,R0,s70,The Long case of Numbers' unary operation op on long x, as long-op2's.R3,i711,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-op1m12,R2,TR6,L1,V2,R67,R7,R0,s64,The Double case of Numbers' unary operation op, as double-op2's.R3,i727,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,numbers-intrinsicm12,R2,TR6,L1,V3,R25,Myn1,mm2,R11,R62,R64,R0,s123,The call of Numbers' static method m on args with its fast paths, or nil when m is not one\n  of the boxed operations above.R3,i739,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit18,emit-static-methodm10,R2,TR6,L1,V3,R25,R56,R61,R3,i774,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,field-ok?m10,R2,TR6,L1,V2,R25,Myn1,fm2,R11,R71,R3,i788,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,emit-instance-fieldm10,R2,TR6,L1,V3,R25,R56,R61,R3,i791,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,emit-static-fieldm10,R2,TR6,L1,V3,R25,R56,R61,R3,i800,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-newm10,R2,TR6,L1,V2,R25,R56,R3,i808,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-defm10,R2,TR6,L1,V3,R25,R56,R72,R3,i817,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,emit-assignm10,R2,TR6,L1,V2,R25,R56,R3,i835,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,coll-callm10,R2,TR6,L1,V3,R73,R59,R25,R3,i857,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,emit-ifm10,R2,TR6,L1,V3,R25,R56,R61,R3,i860,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,emit-binding-initm12,R2,TR6,L1,V3,R25,R54,R74,R0,s69,A let or loop binding [sym init] of LocalBinding lb (LetExpr.doEmit).R3,i869,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-letm10,R2,TR6,L1,V3,R25,R56,R61,R3,i878,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-recurm10,R2,TR6,L1,V2,R25,R56,R3,i885,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit13,body-instancem12,R2,TR6,L1,V3,R25,R75,R76,R0,s228,A new instance of fn or reify class ox (its node), its closed-over values from the current\n  method: (new C closed...) (ObjExpr.emit); letfn's own locals nil (set after). A fn's is its\n  code (SA141), which fn-wrap makes the fn.R3,i906,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,fn-wrapm12,R2,TR6,L1,V3,R25,R75,R77,R0,s135,The fn of fn ox (its node) whose code is form body: a Compiler$AOTFn, or a\n  Compiler$AOTRestFn of the variadic arity's required count.R3,i919,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,fn-instancem12,R2,TR6,L1,V3,R25,R75,R76,R0,s33,A new fn or reify (ox, its node).R3,i942,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-letfnm10,R2,TR6,L1,V3,R25,R56,R61,R3,i948,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-trym10,R2,TR6,L1,V3,R25,R56,R61,R3,i965,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,emit-casem10,R2,TR6,L1,V3,R25,R56,R61,R3,i974,R4,i1,R5,s18,arbace/c2j/emit.aeR78,R79,R80,R81,R82,R83,R84,R85,m8,R2,TR3,i1021,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,box-primm12,R2,TR6,L1,V2,R57,R56,R0,s200,Form f of node n boxed when it is of a primitive type (emitBoxReturn: valueOf, long's\n  Numbers.num being Long.valueOf), so that emit's code is always a reference, as the bytecode's\n  emit leaves one.R3,i1027,R4,i1,R5,s18,arbace/c2j/emit.aem10,R6,L1,V2,R25,R55,R0,s59,Code for analyzed node e, its value boxed (an Expr's emit).R3,i1038,R4,i1,R5,s18,arbace/c2j/emit.aem10,R6,L1,V2,R25,R55,R0,s72,Code for analyzed node e, its value of its primitive type (emitUnboxed).R3,i1114,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,deepm12,R2,TR6,L1,V1,R57,R0,s160,Form f realized throughout (the emitters build lazy seqs; what they record, the constants\n  and the classes, must be recorded before it is read), metadata kept.R3,i1146,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,simple-namem10,R2,TR6,L1,V1,Myn6,binarym2,R11,R12,R3,i1155,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,throws?m12,R2,TR6,L1,V1,R55,R0,s86,Does node e end in a throw (a form that does not complete, which needs no conversion)?R3,i1158,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,ret-bodym12,R2,TR6,L1,V3,R25,R77,Myn3,retm2,R11,R13,R0,s148,A deftype's method body as returned in type ret (ObjMethod.emitBody): unboxed when it can be,\n  else boxed then cast or unboxed as ASM's unbox does.R3,i1167,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,method-bodym12,R2,TR6,L1,V3,R25,R86,R87,R0,s147,The body of FnMethod or NewInstanceMethod m (its node), in the method's context: wrapped in\n  a loop over its parameters when a recur targets them.R3,i1193,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,param-symm10,R2,TR6,L1,V1,R54,R3,i1230,R4,i1,R5,s18,arbace/c2j/emit.ae")

var Lit_369 *jrt.String = jrt.Intern("arbace.c2j.emit$eval31000004$loading__1927001464__auto____31000005")

var Lit_370 *jrt.String = jrt.Intern("arbace.c2j.emit$eval31000008$fn__31000009")

var Lit_371 *jrt.String = jrt.Intern("arbace.c2j.emit$node")

var Lit_372 *jrt.String = jrt.Intern("arbace.c2j.emit$fail")

var Lit_373 *jrt.String = jrt.Intern("arbace.c2j.emit$destub")

var Lit_374 *jrt.String = jrt.Intern("arbace.c2j.emit$type_sym")

var Lit_375 *jrt.String = jrt.Intern("arbace.c2j.emit$tagged")

var Lit_376 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_")

var Lit_377 *jrt.String = jrt.Intern("arbace.c2j.emit$runtime_class_QMARK_")

var Lit_378 *jrt.String = jrt.Intern("arbace.c2j.emit$public_QMARK_")

var Lit_379 *jrt.String = jrt.Intern("arbace.c2j.emit$top_name")

var Lit_380 *jrt.String = jrt.Intern("arbace.c2j.emit$pool")

var Lit_381 *jrt.String = jrt.Intern("arbace.c2j.emit$const_field")

var Lit_382 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_list_array")

var Lit_383 *jrt.String = jrt.Intern("arbace.c2j.emit$char_form")

var Lit_384 *jrt.String = jrt.Intern("arbace.c2j.emit$double_form")

var Lit_385 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value")

var Lit_386 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_kind")

var Lit_387 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_shared_QMARK_")

var Lit_388 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_parts")

var Lit_389 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_str")

var Lit_390 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode")

var Lit_391 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields")

var Lit_392 *jrt.String = jrt.Intern("arbace.c2j.emit$const_type")

var Lit_393 *jrt.String = jrt.Intern("arbace.c2j.emit$constant")

var Lit_394 *jrt.String = jrt.Intern("arbace.c2j.emit$gsym")

var Lit_395 *jrt.String = jrt.Intern("arbace.c2j.emit$local_sym")

var Lit_396 *jrt.String = jrt.Intern("arbace.c2j.emit$identity_set")

var Lit_397 *jrt.String = jrt.Intern("arbace.c2j.emit$closed_QMARK_")

var Lit_398 *jrt.String = jrt.Intern("arbace.c2j.emit$field_sym")

var Lit_399 *jrt.String = jrt.Intern("arbace.c2j.emit$field_read")

var Lit_400 *jrt.String = jrt.Intern("arbace.c2j.emit$prim")

var Lit_401 *jrt.String = jrt.Intern("arbace.c2j.emit$can_prim_QMARK_")

var Lit_402 *jrt.String = jrt.Intern("arbace.c2j.emit$box")

var Lit_403 *jrt.String = jrt.Intern("arbace.c2j.emit$unbox_arg")

var Lit_404 *jrt.String = jrt.Intern("arbace.c2j.emit$fi_QMARK_")

var Lit_405 *jrt.String = jrt.Intern("arbace.c2j.emit$typed_args")

var Lit_406 *jrt.String = jrt.Intern("arbace.c2j.emit$param_tags")

var Lit_407 *jrt.String = jrt.Intern("arbace.c2j.emit$obj_array")

var Lit_408 *jrt.String = jrt.Intern("arbace.c2j.emit$var_value")

var Lit_409 *jrt.String = jrt.Intern("arbace.c2j.emit$line_meta")

var Lit_410 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_local")

var Lit_411 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke")

var Lit_412 *jrt.String = jrt.Intern("arbace.c2j.emit$descriptor")

var Lit_413 *jrt.String = jrt.Intern("arbace.c2j.emit$fn__31000165")

var Lit_414 *jrt.String = jrt.Intern("arbace.c2j.emit$jrt_lacks_QMARK_")

var Lit_415 *jrt.String = jrt.Intern("arbace.c2j.emit$method_call")

var Lit_416 *jrt.String = jrt.Intern("arbace.c2j.emit$compiled_interface_QMARK_")

var Lit_417 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_instance_method")

var Lit_418 *jrt.String = jrt.Intern("arbace.c2j.emit$long_box")

var Lit_419 *jrt.String = jrt.Intern("arbace.c2j.emit$double_box")

var Lit_420 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op2")

var Lit_421 *jrt.String = jrt.Intern("arbace.c2j.emit$double_op2")

var Lit_422 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op1")

var Lit_423 *jrt.String = jrt.Intern("arbace.c2j.emit$double_op1")

var Lit_424 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic")

var Lit_425 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_method")

var Lit_426 *jrt.String = jrt.Intern("arbace.c2j.emit$field_ok_QMARK_")

var Lit_427 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_instance_field")

var Lit_428 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_field")

var Lit_429 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_new")

var Lit_430 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_def")

var Lit_431 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_assign")

var Lit_432 *jrt.String = jrt.Intern("arbace.c2j.emit$coll_call")

var Lit_433 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_if")

var Lit_434 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_binding_init")

var Lit_435 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_let")

var Lit_436 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_recur")

var Lit_437 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance")

var Lit_438 *jrt.String = jrt.Intern("arbace.c2j.emit$fn_wrap")

var Lit_439 *jrt.String = jrt.Intern("arbace.c2j.emit$fn_instance")

var Lit_440 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn")

var Lit_441 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try")

var Lit_442 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case")

var Lit_443 *jrt.String = jrt.Intern("arbace.c2j.emit$box_prim")

var Lit_444 *jrt.String = jrt.Intern("arbace.c2j.emit$emit")

var Lit_445 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_unboxed")

var Lit_446 *jrt.String = jrt.Intern("arbace.c2j.emit$deep")

var Lit_447 *jrt.String = jrt.Intern("arbace.c2j.emit$simple_name")

var Lit_448 *jrt.String = jrt.Intern("arbace.c2j.emit$throws_QMARK_")

var Lit_449 *jrt.String = jrt.Intern("arbace.c2j.emit$ret_body")

var Lit_450 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body")

var Lit_451 *jrt.String = jrt.Intern("arbace.c2j.emit$param_sym")

var Lit_452 *jrt.String = jrt.Intern("yn4,longyn6,doubleyn3,intyn7,booleanyn4,charyn5,floatyn5,shortyn4,bytekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn3,tagkn3,dockn3,tagyn5,Classyn3,ctxyn2,oxyn2,lbyn1,kyn4,kindyn4,lineyn6,columnyn1,_yn4,expryn6,eventsyn6,Stringyn7,classesyn15,runtime-classesyn8,fn-namesyn5,poolsyn3,srcyn5,unitsyn1,cyn11,children-ofyn4,top?yn4,nameyn7,extendsyn7,methodsv15,arbace.c2j.emit12,prim-classesR0,R1,R2,R3,R4,R5,R6,R7,m8,R8,TR9,i1236,R10,i1,R11,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,tag-classm12,R8,TR12,L1,V1,R13,R14,s70,The class a field's tag names (Compiler.tagClass): Object without one.R9,i1240,R10,i1,R11,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,box-classm10,R8,TR12,L1,V1,Myn1,cm2,R15,R16,R9,i1249,R10,i1,R11,s18,arbace/c2j/emit.aev15,arbace.c2j.emit16,class-interfacesm12,R8,TR12,L1,V2,R17,R18,R14,s179,The interfaces of a deftype's or reify's class (its node ox), as the analysis made the\n  class: their names. A class of the program cannot implement an interface made at run time.R9,i1253,R10,i1,R11,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,field-modsm12,R8,TR12,L1,V2,R18,R19,R14,s104,The modifiers of a deftype's field lb (ObjExpr.compile): volatile, mutable (package), or\n  public final.R9,i1264,R10,i1,R11,s18,arbace/c2j/emit.aem10,R12,L1,V2,R17,R18,R14,s202,Defines deftype ox's class (its node), a top-level class named as the deftype, once:\n  its fields, constructors, getBasis (and create for a record), and methods\n  (NewInstanceExpr.compile, emitStatics).R9,i1274,R10,i1,R11,s18,arbace/c2j/emit.aem10,R12,L1,V2,R17,R18,R14,s109,Defines the class of fn or reify ox (its node) once, in the classes being emitted; returns\n  its binary name.R9,i1342,R10,i1,R11,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,unit-methodm12,R8,TR12,L1,V3,R17,R20,V7,R21,R22,R23,R24,R24,R25,R26,R14,s96,The static method unitK of a source's loader class: unit u's events made again, then its\n  code.R9,i1429,R10,i1,R11,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,unit-nsm12,R8,TR12,L1,V1,V6,R21,R24,R24,R24,R24,R25,R14,s79,The namespace unit u was analyzed in: its fn's (kind 1) or its def's, else nil.R9,i1494,R10,i1,R11,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,loader-part-unitsl100,m8,R9,i1505,R10,i1,R11,s18,arbace/c2j/emit.aeR14,s251,The most units a source's loader class holds itself; a source of more is split into parts of\n  as many (SA210): j2g analyzes classes in parallel, one class on one thread (arbace.core's 903\n  units were one task of 9 to 14 s, the last of the analysis).v15,arbace.c2j.emit15,unnamed-packagem10,R12,L1,V1,Myn2,nmm2,R15,R27,R14,s484,The option placing top-level class nm in Java's unnamed package when its name has no\n  package: the classes of a namespace of one segment (user: its holder user, the fns\n  user$eval1$fn__2, the loader of a source user.ae, user__init), named as the JVM names them,\n  where the Java forms would put a simple name in the package of the namespace they are read in\n  (arbace). The tree's files import them (arbace.c2j.main), so that a class of a package can name\n  them, as Java could not.R9,i1511,R10,i1,R11,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,emit-sourcem10,R12,L1,V6,R28,R29,R30,R31,R32,R33,R14,s259,The Java forms of source path src (scriptbase.ae), compiled from its units: the loader\n  class SCRIPTBASE__init's form and the fn classes made, into the atom classes (fn-names: the\n  fns' class names by their FnExpr, an IdentityHashMap shared by the sources).R9,i1521,R10,i1,R11,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,class-formm12,R8,TR12,L1,V4,R34,R35,R36,R31,R14,s289,The defclass form of class c (its record: a fn's, a reify's, a deftype's, an interface's, or\n  a holder of nested classes), its nested classes inside; at the top its full name and the\n  constants it shares with them (pools: top → its pool), else a static member class by its\n  simple name.R9,i1587,R10,i1,R11,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,class-formsm10,R12,L1,V2,R28,R31,R14,s261,The top-level Java forms holding every class of classes (name → record), nested as their\n  binary names nest, with holder classes made for the missing levels (a namespace's fns nest\n  in a holder named as the namespace); pools: the top-level classes' constants.R9,i1623,R10,i1,R11,s18,arbace/c2j/emit.aev15,arbace.c2j.emit16,interface-recordm10,R12,L1,V3,R37,R38,R39,R14,s133,The record of an interface made by gen-interface (events iface and imethod): name, the\n  interfaces it extends, its abstract methods.R9,i1645,R10,i1,R11,s18,arbace/c2j/emit.ae")

var Lit_453 *jrt.String = jrt.Intern("arbace.c2j.emit$tag_class")

var Lit_454 *jrt.String = jrt.Intern("arbace.c2j.emit$box_class")

var Lit_455 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces")

var Lit_456 *jrt.String = jrt.Intern("arbace.c2j.emit$field_mods")

var Lit_457 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_")

var Lit_458 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_")

var Lit_459 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method")

var Lit_460 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_ns")

var Lit_461 *jrt.String = jrt.Intern("arbace.c2j.emit$unnamed_package")

var Lit_462 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source")

var Lit_463 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form")

var Lit_464 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms")

var Lit_465 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record")
