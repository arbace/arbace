//line j2g_strings.ae:1
package aot_arbace_c2j_emit

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.j2g.jrtyn3,jrtyn16,arbace.j2g.namesyn2,nmyn15,arbace.c2j.nodekn5,referyn7,defnodekn3,dockn4,selfkn3,tagkn15,runtime-classeskn12,unit-proxieskn5,poolskn4,namekn6,constskn9,const-mapkn12,const-prefixkn3,clskn4,prevyn3,newys16,java.lang.Object1,1yn14,unchecked-charys16,java.lang.Double16,longBitsToDoublekn4,elseys17,java.lang.Boolean4,TRUEys17,java.lang.Boolean5,FALSEys17,java.lang.Integer7,valueOfyn13,unchecked-intys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys19,java.lang.Character7,valueOfys14,arbace.lang.RT22,classForNameNonLoadingys18,arbace.lang.Symbol6,internkn10,param-tagsyn16,java.lang.Stringys14,arbace.lang.RT7,keywordys14,arbace.lang.RT3,varys21,arbace.lang.Namespace12,findOrCreateyn18,arbace.lang.Symbolys14,arbace.lang.RT10,readStringkn6,closesys14,arbace.lang.RT3,mapys17,arbace.lang.Tuple6,createyn16,java.lang.Objectys14,arbace.lang.RT6,vectorys29,arbace.lang.PersistentHashSet5,EMPTYys29,arbace.lang.PersistentHashSet6,createys26,arbace.lang.PersistentList6,createyn14,java.util.Listys16,java.util.Arrays6,asListys23,java.util.regex.Pattern7,compileyn9,.withMetayn4,castyn16,arbace.lang.IObjyn26,arbace.lang.IPersistentMapkn3,nilkn6,stringkn7,booleankn3,intkn4,longkn6,doublekn4,charkn5,classkn6,symbolkn7,keywordkn3,varkn2,nskn4,readkn3,mapkn6,vectorkn3,setkn4,listkn7,patternyn5,fieldyn10,const-poolkn6,statickn5,finalkn7,privateys24,arbace.lang.Compiler$AOT4,poolyn3,intks3,c2j2,nnyn4,agetyn15,arbace.lang.Varyn19,arbace.lang.Keywordyn15,java.lang.Classkn7,gensymskn3,idxkn6,closedyn6,this__kn8,self-symyn4,thiskn4,primkn16,canEmitPrimitiveyn2,dokn14,unchecked-mathyn13,.booleanValueyn17,java.lang.Booleanyn10,.charValueyn19,java.lang.Characterkn2,opys30,arbace.lang.Compiler$Evaluator7,fiAdaptys14,arbace.lang.RT16,uncheckedIntCastys14,arbace.lang.RT7,intCastyn4,longyn15,unchecked-floatyn4,.getyn11,.getRawRootkn4,lineks3,c2j4,linekn11,spec-localskn1,bkn4,formkn6,clearskn4,oncekn11,shouldClearkn12,canBeClearedkn11,bindingPrimkn5,isArgkn1,lyn2,ifyn4,nil?yn4,set!kn7,dynamickn5,redefkn5,macrokn8,restParmkn8,reqParmskn8,retClasskn6,paramskn3,retkn4,bodykn6,methodkn4,argskn1,okn5,fexprkn10,loopLocalskn12,initProvidedkn4,initkn10,isVariadickn7,methodsys14,arbace.lang.RT10,doubleCastys14,arbace.lang.RT8,longCastkn5,bindskn3,genkn3,prikn1,nkn4,passkn5,guardyn9,instance?yn14,java.lang.Longyn10,.longValuekn1,rkn1,wkn1,fkn2,idkn3,keykn6,callerkn4,rootkn4,symskn4,psigkn3,outkn4,convkn5,partskn5,smaskkn5,spassyn3,andys3,c2j4,linkyn7,.invokeyn15,arbace.lang.IFnyn11,.invokePrimyn11,.invokeSpecyn30,arbace.lang.Compiler$AOTRestFnyn26,arbace.lang.Compiler$AOTFnyn3,letys30,arbace.lang.Compiler$AOTRestFn6,linkedys26,arbace.lang.Compiler$AOTFn10,linkedFastkn2,fnkn4,kindkn10,isProtocolkn10,protocolOnkn8,onMethodyn3,notys24,arbace.lang.Compiler$AOT5,isDynkn7,classeskn7,standinkn5,funcskn9,interfacekn11,dyn-guardedkn6,targetks15,arbace.c2j.emit5,localkn10,target-symkn15,qualifyingClassyn5,some?ys21,arbace.lang.Reflector20,invokeInstanceMethodkn10,methodNameys21,arbace.lang.Reflector27,invokeInstanceMethodOfClassyn6,doubleyn13,unchecked-addyn18,unchecked-multiplyyn2,>=yn7,bit-andyn7,bit-xoryn2,==yn1,<yn2,oryn16,unchecked-divideyn18,unchecked-subtractyn2,<=yn6,bit-oryn19,unchecked-remainderyn14,bit-shift-leftyn1,>yn15,bit-shift-rightyn16,unchecked-negateyn13,unchecked-decyn13,unchecked-inckn1,jkn1,xyn1,xyn4,slowyn1,yyn1,ryn12,.doubleValueyn16,java.lang.Doublekn7,mutableys21,arbace.lang.Reflector18,invokeStaticMethodkn1,ckn5,fieldys21,arbace.lang.Reflector25,invokeNoArgInstanceMemberyn7,booleankn9,fieldNamekn12,requireFieldys21,arbace.lang.Reflector14,getStaticFieldkn4,ctorys21,arbace.lang.Reflector17,invokeConstructorkn4,metayn9,.bindRootyn8,.setMetakn9,isDynamicyn11,.setDynamickn3,valys21,arbace.lang.Reflector14,setStaticFieldys21,arbace.lang.Reflector16,setInstanceFieldyn4,.setkn12,bindingInitskn6,isLoopkn11,loop-localskn7,bindingyn4,loopyn5,recurkn12,method-recurkn13,method-localskn12,supportsMetakn8,variadicys24,arbace.lang.Compiler$AOT7,fnClassyn3,trykn7,tryExpryn5,catchkn2,lbkn7,handlerkn10,catchExprskn11,finallyExpryn7,finallykn4,exprkn5,shiftkn4,maskyn11,bit-and-intyn19,bit-shift-right-intkn5,testskn5,thenskn8,testTypekn7,defaultkn9,skipCheckkn13,hash-identityyn4,whenys16,arbace.lang.Util5,equivyn5,breakyn10,identical?yn6,switchys16,arbace.lang.Util4,hashyn9,.intValueyn16,java.lang.Numberyn5,labelkn11,defaultExprys26,arbace.lang.PersistentList5,EMPTYys28,arbace.lang.PersistentVector5,EMPTYys30,arbace.lang.PersistentArrayMap5,EMPTYkn1,dkn1,zkn1,pyn6,Objectyn6,Numberyn2,t-kn8,testExprkn8,thenExprkn8,elseExprkn12,tailPositionyn8,.applyTokn12,methodSymbolkn13,fieldOverloadkn9,hintedSigyn3,fn*kn4,typekn9,isDeftypekn7,keyvalsys30,arbace.lang.Compiler$Evaluator11,monitorExityn5,throwyn19,java.lang.Throwablekn7,excExprkn1,kkn2,kwkn5,exprsys30,arbace.lang.Compiler$Evaluator12,monitorEnterys14,arbace.lang.RT11,arrayToListyn12,.importClassyn21,arbace.lang.Namespaceyn6,.derefys14,arbace.lang.RT10,CURRENT_NSkn5,textsys24,arbace.lang.Compiler$AOT9,strConcatys16,java.lang.String1,1ys14,arbace.lang.RT3,setkn4,keysyn11,.isInstanceyn5,nil__kn9,argLocalskn4,speckn4,objxkn13,compiledClasskn3,symkn16,volatile-mutablekn8,volatilekn22,unsynchronized-mutablekn6,publickn8,fn-namesks15,arbace.c2j.emit7,pendingkn12,hintedFieldskn12,altCtorDropsyn11,constructoryn6,super.kn6,columnyn3,m__yn6,methodkn7,deftypekn5,superkn10,interfaceskn7,memberskn6,sourceyn5,this.yn8,getBasisyn29,arbace.lang.IPersistentVectoryn6,createys19,arbace.lang.Keyword6,internyn6,.valAtyn8,.withoutys14,arbace.lang.RT9,seqOrElsekn8,onceOnlyyn4,selfyn6,meta__yn8,.-__metayn6,invokeyn10,invokeSpecyn10,invokePrimyn8,doInvokeyn8,fn-classyn6,__metayn4,metayn8,withMetayn1,mkn5,reifykn5,primskn5,specsys14,arbace.lang.RT4,consys14,arbace.lang.RT3,seqys14,arbace.lang.RT16,loadClassForNameys24,arbace.lang.Compiler$AOT2,atkn7,packageyn8,defclassks3,c2j6,sourceyn4,loadyn4,initks3,c2j4,codekn6,holderkn7,extendskn10,implementskn8,abstractv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R9,V1,R10,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.c2j.emitm2,R11,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).v11,arbace.core5,some?v15,arbace.c2j.emit10,node-cachev11,arbace.core5,assocR12,v11,arbace.core7,ex-infov11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*print-dup*v11,arbace.core5,classv13,arbace.string12,starts-with?v11,arbace.core4,subsv11,arbace.core6,symbolv11,arbace.core3,strv15,arbace.c2j.emit8,type-symv15,arbace.c2j.emit6,destubv11,arbace.core9,vary-metaR13,v15,arbace.c2j.emit10,prim-namesv15,arbace.c2j.emit10,registeredv11,arbace.core3,notv11,arbace.core5,swap!v11,arbace.core9,contains?R14,v15,arbace.c2j.emit11,registered?v11,arbace.core8,identityv15,arbace.c2j.emit21,dynamic-class-cached?R15,l0,R16,v11,arbace.core4,atomR17,R18,R19,R20,R21,R22,v11,arbace.core4,namev11,arbace.core6,updatev11,arbace.core4,listR23,R24,v11,arbace.core4,mapvv15,arbace.c2j.emit10,emit-valuev11,arbace.core4,not=c92,R25,R26,v11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core5,mungev11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core5,firstv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core3,vecV2,nTv11,arbace.core7,string?v11,arbace.core6,class?v11,arbace.core7,symbol?v11,arbace.core8,keyword?v11,arbace.core4,var?v15,arbace.c2j.emit4,nodev11,arbace.core4,map?v11,arbace.core7,vector?v11,arbace.core4,seq?v11,arbace.core5,list?R27,v15,arbace.c2j.emit7,dup-strR28,R29,R30,R31,R32,R33,v15,arbace.c2j.emit11,double-formR34,v15,arbace.c2j.emit9,char-formC17,java.lang.BooleanC14,java.lang.ByteC19,java.lang.CharacterC16,java.lang.DoubleC15,java.lang.FloatC17,java.lang.IntegerC14,java.lang.LongC15,java.lang.ShortR35,v11,arbace.core9,with-metaR36,m2,R37,V2,R38,R38,v11,arbace.core9,namespaceR39,m2,R37,V2,R38,R38,R40,m2,R37,V2,R38,R38,R41,m2,R37,V1,R42,R36,m2,R37,V2,R38,R38,R43,m2,R37,V1,R38,v15,arbace.c2j.emit12,type-literalR44,v15,arbace.c2j.emit4,failv15,arbace.c2j.emit11,fn-instanceR45,m2,R37,V1,R24,v15,arbace.c2j.emit15,emit-list-arrayv11,arbace.core6,mapcatv11,arbace.core5,list*R46,R37,v11,arbace.core6,repeatR47,v11,arbace.core3,mapR48,m2,R37,V1,R24,v11,arbace.core6,empty?R49,R50,m2,R37,V1,R24,R51,m2,R37,V1,R52,R53,m2,R37,V1,R24,R54,m2,R37,V1,R38,R43,m2,R37,V1,R38,R55,R56,R57,R56,R58,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,R72,R73,R74,R75,R76,v15,arbace.c2j.emit9,pool-kindv11,arbace.core6,concatv15,arbace.c2j.emit12,pool-partialc44,v15,arbace.c2j.emit12,pool-shared?c82,v15,arbace.c2j.emit11,pool-encodev11,arbace.core4,nextc77,v15,arbace.c2j.emit8,pool-strc110,c84,c70,c118,c107,c115,c112,c100,c109,c80,c86,c68,c67,c66,c90,c74,c83,c73,c99,c78,c114,c108,c121,c69,c105,c76,v11,arbace.core6,removev11,arbace.core4,run!v15,arbace.c2j.emit10,pool-partsv11,arbace.core4,intov11,arbace.core11,map-indexedR77,v15,arbace.c2j.emit6,taggedR78,m6,R79,TR80,TR81,TR82,m2,R37,V2,R38,R83,R31,R77,m6,R79,TR80,TR84,TR47,R85,R78,R31,R56,m6,R79,TR80,TR84,TR86,R87,R88,R47,v15,arbace.c2j.emit15,*event-classes*v15,arbace.c2j.emit14,*late-classes*v15,arbace.c2j.emit13,dynamic-cachev15,arbace.c2j.emit15,dynamic-class?*v11,arbace.core4,somev15,arbace.c2j.emit9,holds-fn?v11,arbace.core5,coll?v15,arbace.c2j.emit14,runtime-class?v15,arbace.c2j.emit11,const-fieldv15,arbace.c2j.emit10,const-typeR35,m2,R37,V1,R38,R89,v11,arbace.core4,fnilv11,arbace.core3,incR90,R91,v15,arbace.c2j.emit9,field-symR92,R93,R92,R94,R95,R96,R97,v15,arbace.c2j.emit6,box-ofC16,java.lang.ObjectR98,v15,arbace.c2j.emit7,public?R99,R56,R100,R101,R56,R102,m2,R37,V1,R47,R56,v15,arbace.c2j.emit12,emit-unboxedv15,arbace.c2j.emit9,prim-callv15,arbace.c2j.emit9,unbox-argv15,arbace.c2j.emit4,emitv15,arbace.c2j.emit3,fi?R103,R104,v15,arbace.c2j.emit8,constantR105,R106,m2,R37,V1,R107,R108,R23,R24,R86,R109,R110,R111,R112,R113,R32,m2,R37,V1,R107,R114,v15,arbace.c2j.emit7,closed?R115,v15,arbace.c2j.emit10,field-readR116,R117,R118,R119,R120,R121,R94,v15,arbace.c2j.emit10,spec-localv11,arbace.core8,to-arrayR122,v15,arbace.c2j.emit9,local-symR123,R124,R125,v15,arbace.c2j.emit9,long-box*R126,R127,R128,R129,R130,R131,R132,R133,S2,s2,fns12,new-instancev11,arbace.core2,<=l1,l4,v15,arbace.c2j.emit4,psigv11,arbace.core5,rangev15,arbace.c2j.emit10,walk-nodesR134,R135,v15,arbace.c2j.emit15,intrinsic-probev11,arbace.core6,vectorR136,R137,R138,v15,arbace.c2j.emit15,long-valued-opsv11,arbace.core6,reset!R139,v11,arbace.core6,every?v11,arbace.core5,true?v11,arbace.core10,identical?R140,R141,v15,arbace.c2j.emit9,*var-fns*R142,R143,v15,arbace.c2j.emit15,site-fn-methodsv15,arbace.c2j.emit9,spec-maskv11,arbace.core4,*ns*R144,R145,m2,R37,V1,R47,R146,R147,R148,R149,v15,arbace.c2j.emit4,deepv15,arbace.c2j.emit9,can-prim?v15,arbace.c2j.emit10,jrt-lacks?v15,arbace.c2j.emit3,boxR150,v15,arbace.c2j.emit14,spec-intrinsicR151,R152,R153,R154,R56,R153,v15,arbace.c2j.emit9,var-valuev15,arbace.c2j.emit9,site-psigR155,v15,arbace.c2j.emit4,gsymR156,R157,R2,v15,arbace.c2j.emit9,site-specv15,arbace.c2j.emit8,prim-argv15,arbace.c2j.emit8,spec-argR158,v15,arbace.c2j.emit6,*link*R159,R160,v15,arbace.c2j.emit8,top-nameR161,R162,R163,R164,R165,R166,v11,arbace.core4,keepR167,R168,R169,R170,v15,arbace.c2j.emit14,emit-link-sitev11,arbace.core6,secondR171,R56,R172,R173,R56,R174,R56,R175,R176,R177,R172,R56,R172,R171,R171,R56,R123,R177,R172,R178,R179,R123,R124,R56,R172,R123,R124,R171,R177,R172,R123,R124,R56,R172,R123,R171,R171,R56,R124,v15,arbace.c2j.emit9,link-formR180,R181,R182,R183,v15,arbace.c2j.emit8,link-keyv15,arbace.c2j.emit8,site-keyv15,arbace.c2j.emit9,line-metaR184,R177,R123,v15,arbace.c2j.emit10,param-tagsR56,v15,arbace.c2j.emit10,typed-argsR171,R56,R172,R169,R152,R185,R186,v13,arbace.string7,replacev14,arbace.j2g.jrt4,scanv15,arbace.c2j.emit8,jrt-scanR187,R188,v16,arbace.j2g.names13,go-class-namev11,arbace.core5,applyv15,arbace.c2j.emit10,descriptorv16,arbace.j2g.names11,method-baseR189,v14,arbace.j2g.jrt14,struct-methodsv14,arbace.j2g.jrt13,iface-methodsv16,arbace.j2g.names9,impl-nameR56,R190,v15,arbace.c2j.emit19,compiled-interface?R191,R192,R193,R194,v15,arbace.c2j.emit11,method-callv15,arbace.c2j.emit20,emit-instance-methodR195,R177,R123,R169,R196,R186,R197,m2,R37,V3,R47,R38,R24,R198,v15,arbace.c2j.emit9,obj-arrayR199,R197,m2,R37,V3,R47,R38,R24,v15,arbace.c2j.emit6,*lbox*R32,m2,R37,V1,R107,R33,m2,R37,V1,R200,R177,R123,v15,arbace.c2j.emit8,long-boxR201,R202,R203,R204,R205,R205,R169,R185,R206,v15,arbace.c2j.emit8,long-minR203,R204,R205,R205,R169,R185,R169,R206,R207,R208,R206,R206,R209,R207,R201,R204,R203,R205,R210,R211,R210,R212,R202,R123,R213,R206,R214,R123,R209,R206,R215,R206,R216,v15,arbace.c2j.emit10,double-boxR201,R202,R207,R203,R201,R217,R211,R207,R206,R123,R206,R217,R218,R207,R215,v15,arbace.c2j.emit8,long-maxR219,R219,R217,R218,R206,R217,R210,d4607182418800017408,R207,d0,R215,d0,R201,d4607182418800017408,R206,d0,C19,arbace.lang.NumbersR220,R221,V1,R137,v15,arbace.c2j.emit8,long-op1R222,R223,S1,R137,S2,R137,R220,v15,arbace.c2j.emit8,long-op2R222,R224,R223,R225,R123,R124,R125,R154,R56,R153,R226,R56,R227,R152,R169,S1,R137,v11,arbace.core8,not-any?v15,arbace.c2j.emit10,double-op1v15,arbace.c2j.emit10,double-op2R177,R177,R123,R153,R177,R123,R227,R177,v15,arbace.c2j.emit12,numbers-fastv15,arbace.c2j.emit17,numbers-intrinsicv15,arbace.c2j.emit16,static-call-formR123,R124,R125,R97,R125,R228,R177,R123,R124,R208,R124,R152,R153,R123,R124,R154,R56,R153,v15,arbace.c2j.emit18,emit-static-methodR229,m2,R37,V3,R88,R38,R24,R230,R231,v15,arbace.c2j.emit9,field-ok?R56,R232,m2,R37,V3,R47,R38,R233,R234,R235,R236,m2,R37,V2,R88,R38,R237,R238,m2,R37,V2,R88,R24,R86,R239,R97,R240,R241,R242,R243,R97,R243,R241,R240,R56,R58,R244,R245,m2,R37,V3,R88,R38,R47,R125,R125,R56,R246,R247,R86,R125,m2,R37,V1,R24,R104,R248,R249,R250,R251,v15,arbace.c2j.emit17,emit-binding-initR252,R177,R253,v15,arbace.c2j.emit4,primR106,m2,R37,V1,R107,R108,R254,R255,v15,arbace.c2j.emit14,emit-fn-class!v15,arbace.c2j.emit10,emit-localR23,R256,V1,nv11,arbace.core4,keysR257,R177,R88,R123,R124,R177,R88,R258,m2,R37,V3,R38,R233,R47,R125,R177,R47,R23,R175,R31,R23,R176,v15,arbace.c2j.emit13,body-instancev15,arbace.c2j.emit7,fn-wrapv15,arbace.c2j.emit12,identity-setR125,R177,R97,R259,R260,R261,R262,R263,R264,R265,R266,R267,R268,R269,R270,R271,v11,arbace.core10,sorted-mapR272,R273,v11,arbace.core7,keywordR274,R275,v11,arbace.core3,setR276,R277,R278,R279,m2,R37,V2,R47,R47,R280,R278,R206,R280,R280,R278,R206,R107,R280,R280,R278,R281,R280,R278,R279,m2,R37,V2,R47,R47,R280,R282,R283,R31,R278,R282,R284,R56,R285,R152,R285,R286,R287,R200,R107,R233,R83,R28,R29,R288,R289,R290,R49,R291,R292,R293,v15,arbace.c2j.emit9,prim-chanv11,arbace.core4,castC16,java.lang.Numberd0,v15,arbace.c2j.emit4,liftR200,R107,R294,R226,R56,R295,R154,R56,R295,v15,arbace.c2j.emit11,local-placeR296,R177,R125,R297,R298,R299,R123,v15,arbace.c2j.emit11,call-staticv15,arbace.c2j.emit13,invoke-linkedR300,R171,R56,R172,R301,Mys20,arbace.lang.ArraySeq6,createm2,R37,V1,R24,R23,R24,R302,R303,R304,v11,arbace.core10,sorted-setv11,arbace.core6,filterV1,R94,R305,S2,s9,instance?s5,localv15,arbace.c2j.emit10,emit-constR46,R47,v15,arbace.c2j.emit9,coll-callR48,v15,arbace.c2j.emit8,emit-tryv15,arbace.c2j.emit8,emit-letR306,v15,arbace.c2j.emit8,box-primR307,v15,arbace.c2j.emit10,emit-recurv15,arbace.c2j.emit19,emit-deftype-class!v15,arbace.c2j.emit21,qualified-method-exprv15,arbace.c2j.emit8,emit-defv15,arbace.c2j.emit11,emit-invokeR45,R308,v15,arbace.c2j.emit19,emit-instance-fieldR97,R309,R310,R56,R311,R312,v15,arbace.c2j.emit8,emit-newR171,R313,R314,R87,R315,R97,v11,arbace.core7,butlastv11,arbace.core4,lastR97,R316,v15,arbace.c2j.emit7,emit-ifv15,arbace.c2j.emit11,emit-assignR317,R55,R56,R57,R56,R58,v15,arbace.c2j.emit10,emit-letfnR318,R56,R319,R320,R321,R35,v15,arbace.c2j.emit14,direct-static?v15,arbace.c2j.emit16,emit-static-callv15,arbace.c2j.emit17,emit-static-fieldR322,v15,arbace.c2j.emit9,emit-caseR323,R23,R324,R23,R24,R325,R326,R327,R152,R97,R327,R152,R310,R56,R311,v15,arbace.c2j.emit7,throws?v15,arbace.c2j.emit11,nil-valued?R97,v15,arbace.c2j.emit9,form-linev15,arbace.c2j.emit12,with-line-ofR107,R200,R56,R285,R99,R56,R100,R101,R56,R102,R106,m2,R37,V1,R107,R108,R177,R328,R328,m2,R13,R47,R56,R329,v15,arbace.c2j.emit8,ret-bodyR330,R331,R252,R177,R144,R145,m2,R37,V1,R47,v15,arbace.c2j.emit12,prim-classesv11,arbace.core10,ns-resolveR332,R333,R334,m2,R335,TR336,m4,R337,TR80,TR338,R339,v15,arbace.c2j.emit4,poolR92,R94,v11,arbace.core6,dissocR340,R341,R342,m2,R337,TML1,R343,m4,R111,i2023,R344,i26,R125,v11,arbace.core4,takeR345,R346,m2,R337,Tv15,arbace.c2j.emit11,method-bodym2,R337,TR77,v15,arbace.c2j.emit10,field-modsR347,R348,R47,R349,v15,arbace.c2j.emit16,class-interfacesR350,R351,v11,arbace.core3,keyR342,m2,R337,TR352,R31,R31,R342,m2,R337,TR352,R31,R31,R346,R353,m4,R337,TR79,TR354,R346,R355,m4,R337,TR79,TR58,v15,arbace.c2j.emit9,tag-classR356,m2,R37,V1,R38,R357,R56,v15,arbace.c2j.emit9,box-classm2,R37,V1,R38,R177,R177,R125,R358,R23,R359,R31,R31,m2,R228,Tp11,\\$(?=\\$|\\z)R360,R361,R94,R77,R342,V1,R94,R362,R58,m2,R337,TML1,R343,m4,R111,i2104,R344,i26,V1,ML3,R125,ML2,R363,R94,m4,R111,i2105,R344,i53,R362,m4,R111,i2105,R344,i47,R125,R94,V2,R94,R361,v15,arbace.c2j.emit9,param-symV2,R94,R361,R152,R153,R169,V2,R94,R361,R346,R364,m2,R337,TR123,R174,R94,R361,R154,R56,R153,R346,R365,m2,R337,TR346,R366,m2,R337,TR346,R364,m2,R337,TR173,R94,R361,R144,R145,m2,R37,V1,R47,R346,R367,R364,m2,R337,TR94,R346,m2,R337,Tm2,R337,TR77,R368,m4,R337,TR79,TR88,R77,R369,R58,R346,R370,m2,R337,TV1,R94,R58,ML2,R363,R94,m4,R111,i2187,R344,i117,R346,R371,m2,R337,TR94,R372,R58,R57,R23,R372,R94,R373,R47,R374,v11,arbace.core9,not-emptyR375,R301,R56,R172,R110,v11,arbace.core15,get-proxy-classR86,R376,m2,R37,V2,R47,R47,R377,m2,R37,V1,R47,R23,R24,R247,R321,R41,R56,R42,m2,R37,V2,R47,R47,m2,R37,V1,R47,v11,arbace.core5,doallR278,R124,R378,m2,R37,V1,R38,R171,R56,R172,R110,v11,arbace.core12,define-proxyR86,R377,m2,R37,V1,R47,R23,R24,m2,R37,V1,R38,m2,R37,V1,R47,R346,m4,R81,TR79,TR97,R379,R31,R31,v11,arbace.core7,sort-byv11,arbace.core7,find-nsv13,arbace.string9,includes?V2,R380,s0,v15,arbace.c2j.emit11,unit-methodv15,arbace.c2j.emit7,unit-nsv15,arbace.c2j.emit17,loader-part-unitsR381,R337,R80,R382,v15,arbace.c2j.emit15,unnamed-packagev15,arbace.c2j.emit11,pool-fieldsR346,R383,m4,R337,TR79,TR97,V1,nR381,R79,R346,R384,m2,R79,TR346,R383,m2,R79,TR97,V1,nm2,R79,Tm2,R79,TV1,nv11,arbace.core13,partition-allR381,R346,R383,m4,R337,TR79,TR97,V1,nv15,arbace.c2j.emit10,class-formR385,v15,arbace.c2j.emit11,simple-nameR386,R381,m6,R337,TR79,TR80,TR381,m6,R337,TR79,TR190,TR387,R381,m6,R337,TR79,TR80,TR388,v11,arbace.core4,peekv11,arbace.core3,popv11,arbace.core8,group-byv11,arbace.core10,ex-messagev11,arbace.core7,ex-datav11,arbace.core4,sortR346,m4,R337,TR389,TR94,m4,R337,TR389,T")

var Lit_1 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000392__31000396")

var Lit_2 *jrt.String = jrt.Intern("new-instance")

var Lit_3 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000392__31000396$fn__31000397")

var Lit_4 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance$iter__31000392__31000396$fn__31000397$fn__31000398")

var Lit_5 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form$fn__31001025")

var Lit_6 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form$mods__31001027")

var Lit_7 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$parent__31001032")

var Lit_8 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$fn__31001034")

var Lit_9 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31001036__31001040")

var Lit_10 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$fn__31001046")

var Lit_11 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$children_of__31001048")

var Lit_12 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31001050__31001054")

var Lit_13 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31001036__31001040$fn__31001041")

var Lit_14 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31001036__31001040$fn__31001041$fn__31001042")

var Lit_15 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31001050__31001054$fn__31001055")

var Lit_16 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31001050__31001054$fn__31001055$fn__31001056")

var Lit_17 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31001050__31001054$fn__31001055$fn__31001060")

var Lit_18 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms$iter__31001050__31001054$fn__31001055$fn__31001056$fn__31001057")

var Lit_19 *jrt.String = jrt.Intern(" (in the class ")

var Lit_20 *jrt.String = jrt.Intern(")")

var Lit_21 *jrt.String = jrt.Intern("$")

var Lit_22 *jrt.String = jrt.Intern("no class for ")

var Lit_23 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000618__31000622")

var Lit_24 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000618__31000622$fn__31000623")

var Lit_25 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces$iter__31000618__31000622$fn__31000623$fn__31000624")

var Lit_26 *jrt.String = jrt.Intern(" implements ")

var Lit_27 *jrt.String = jrt.Intern(", made at run time")

var Lit_28 *jrt.String = jrt.Intern("const-")

var Lit_29 *jrt.String = jrt.Intern("V")

var Lit_30 *jrt.String = jrt.Intern("J")

var Lit_31 *jrt.String = jrt.Intern("I")

var Lit_32 *jrt.String = jrt.Intern("D")

var Lit_33 *jrt.String = jrt.Intern("Z")

var Lit_34 *jrt.String = jrt.Intern("C")

var Lit_35 *jrt.String = jrt.Intern("F")

var Lit_36 *jrt.String = jrt.Intern("S")

var Lit_37 *jrt.String = jrt.Intern("B")

var Lit_38 *jrt.String = jrt.Intern(".")

var Lit_39 *jrt.String = jrt.Intern("/")

var Lit_40 *jrt.String = jrt.Intern("L")

var Lit_41 *jrt.String = jrt.Intern(";")

var Lit_42 *jrt.String = jrt.Intern("compile__stub.")

var Lit_43 *jrt.String = jrt.Intern("isNeg")

var Lit_44 *jrt.String = jrt.Intern("isPos")

var Lit_45 *jrt.String = jrt.Intern("unchecked_minus")

var Lit_46 *jrt.String = jrt.Intern("unchecked_dec")

var Lit_47 *jrt.String = jrt.Intern("incP")

var Lit_48 *jrt.String = jrt.Intern("minus")

var Lit_49 *jrt.String = jrt.Intern("unchecked_inc")

var Lit_50 *jrt.String = jrt.Intern("dec")

var Lit_51 *jrt.String = jrt.Intern("inc")

var Lit_52 *jrt.String = jrt.Intern("minusP")

var Lit_53 *jrt.String = jrt.Intern("isZero")

var Lit_54 *jrt.String = jrt.Intern("decP")

var Lit_55 *jrt.String = jrt.Intern("lt")

var Lit_56 *jrt.String = jrt.Intern("addP")

var Lit_57 *jrt.String = jrt.Intern("unchecked_add")

var Lit_58 *jrt.String = jrt.Intern("unchecked_multiply")

var Lit_59 *jrt.String = jrt.Intern("gte")

var Lit_60 *jrt.String = jrt.Intern("lte")

var Lit_61 *jrt.String = jrt.Intern("add")

var Lit_62 *jrt.String = jrt.Intern("multiply")

var Lit_63 *jrt.String = jrt.Intern("multiplyP")

var Lit_64 *jrt.String = jrt.Intern("gt")

var Lit_65 *jrt.String = jrt.Intern("equiv")

var Lit_66 *jrt.String = jrt.Intern("#<")

var Lit_67 *jrt.String = jrt.Intern(">")

var Lit_68 *jrt.String = jrt.Intern("arbace.lang.Compiler$AST")

var Lit_69 *jrt.String = jrt.Intern("dynamic")

var Lit_70 *jrt.String = jrt.Intern("string")

var Lit_71 *jrt.String = jrt.Intern("vector")

var Lit_72 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000573")

var Lit_73 *jrt.String = jrt.Intern("try")

var Lit_74 *jrt.String = jrt.Intern("let")

var Lit_75 *jrt.String = jrt.Intern("recur")

var Lit_76 *jrt.String = jrt.Intern("qualified-method")

var Lit_77 *jrt.String = jrt.Intern("constant")

var Lit_78 *jrt.String = jrt.Intern("def")

var Lit_79 *jrt.String = jrt.Intern("invoke")

var Lit_80 *jrt.String = jrt.Intern("instance-method")

var Lit_81 *jrt.String = jrt.Intern("empty")

var Lit_82 *jrt.String = jrt.Intern("map")

var Lit_83 *jrt.String = jrt.Intern("monitor-exit")

var Lit_84 *jrt.String = jrt.Intern("instance-field")

var Lit_85 *jrt.String = jrt.Intern("throw")

var Lit_86 *jrt.String = jrt.Intern("var")

var Lit_87 *jrt.String = jrt.Intern("keyword-invoke")

var Lit_88 *jrt.String = jrt.Intern("new")

var Lit_89 *jrt.String = jrt.Intern("nil")

var Lit_90 *jrt.String = jrt.Intern("boolean")

var Lit_91 *jrt.String = jrt.Intern("do")

var Lit_92 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000575")

var Lit_93 *jrt.String = jrt.Intern("monitor-enter")

var Lit_94 *jrt.String = jrt.Intern("fn")

var Lit_95 *jrt.String = jrt.Intern("if")

var Lit_96 *jrt.String = jrt.Intern("set!")

var Lit_97 *jrt.String = jrt.Intern("list")

var Lit_98 *jrt.String = jrt.Intern("with-meta")

var Lit_99 *jrt.String = jrt.Intern("import")

var Lit_100 *jrt.String = jrt.Intern("letfn")

var Lit_101 *jrt.String = jrt.Intern("static-method")

var Lit_102 *jrt.String = jrt.Intern("static-field")

var Lit_103 *jrt.String = jrt.Intern("str-concat")

var Lit_104 *jrt.String = jrt.Intern("arbace.c2j.emit$emit$fn__31000577")

var Lit_105 *jrt.String = jrt.Intern("case")

var Lit_106 *jrt.String = jrt.Intern("number")

var Lit_107 *jrt.String = jrt.Intern("the-var")

var Lit_108 *jrt.String = jrt.Intern("set")

var Lit_109 *jrt.String = jrt.Intern("keyword")

var Lit_110 *jrt.String = jrt.Intern("instance?")

var Lit_111 *jrt.String = jrt.Intern("local")

var Lit_112 *jrt.String = jrt.Intern("no back end for ")

var Lit_113 *jrt.String = jrt.Intern(" ")

var Lit_114 *jrt.String = jrt.Intern("set! of a local that is no field")

var Lit_115 *jrt.String = jrt.Intern(".-")

var Lit_116 *jrt.String = jrt.Intern("set! of ")

var Lit_117 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$sm__31000458")

var Lit_118 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$ret__31000460")

var Lit_119 *jrt.String = jrt.Intern("case-")

var Lit_120 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$arm__31000462")

var Lit_121 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$fn__31000465")

var Lit_122 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case$fn__31000471")

var Lit_123 *jrt.String = jrt.Intern("longValue")

var Lit_124 *jrt.String = jrt.Intern("doubleValue")

var Lit_125 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_126 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fn__31000635")

var Lit_127 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fn__31000639")

var Lit_128 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ftype__31000641")

var Lit_129 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fsym__31000643")

var Lit_130 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fn__31000645")

var Lit_131 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000647__31000651")

var Lit_132 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ps__31000657")

var Lit_133 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000661__31000665")

var Lit_134 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fn__31000678")

var Lit_135 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000683__31000687")

var Lit_136 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000699__31000703")

var Lit_137 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000717__31000721")

var Lit_138 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$fn__31000635$fn__31000636")

var Lit_139 *jrt.String = jrt.Intern("this")

var Lit_140 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000647__31000651$fn__31000652")

var Lit_141 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000647__31000651$fn__31000652$fn__31000653")

var Lit_142 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000661__31000665$fn__31000666")

var Lit_143 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000661__31000665$fn__31000666$fn__31000667")

var Lit_144 *jrt.String = jrt.Intern("v__")

var Lit_145 *jrt.String = jrt.Intern("Value")

var Lit_146 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000683__31000687$fn__31000688")

var Lit_147 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000683__31000687$fn__31000688$fn__31000689")

var Lit_148 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000699__31000703$fn__31000704")

var Lit_149 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000699__31000703$fn__31000704$fn__31000705")

var Lit_150 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000699__31000703$fn__31000704$fn__31000711")

var Lit_151 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000699__31000703$fn__31000704$fn__31000713")

var Lit_152 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000699__31000703$fn__31000704$fn__31000705$fn__31000706")

var Lit_153 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000699__31000703$fn__31000704$fn__31000705$fn__31000708")

var Lit_154 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000717__31000721$fn__31000722")

var Lit_155 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$iter__31000717__31000721$fn__31000722$fn__31000723")

var Lit_156 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_$ps__31000657$fn__31000658")

var Lit_157 *jrt.String = jrt.Intern("\\$_")

var Lit_158 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$fn__31000730")

var Lit_159 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000732__31000736")

var Lit_160 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000742__31000746")

var Lit_161 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000752__31000756")

var Lit_162 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$fn__31000762")

var Lit_163 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770")

var Lit_164 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000818__31000822")

var Lit_165 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000836__31000840")

var Lit_166 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000846__31000850")

var Lit_167 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000856__31000860")

var Lit_168 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000866__31000870")

var Lit_169 *jrt.String = jrt.Intern("__")

var Lit_170 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000732__31000736$fn__31000737")

var Lit_171 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000732__31000736$fn__31000737$fn__31000738")

var Lit_172 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000742__31000746$fn__31000747")

var Lit_173 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000742__31000746$fn__31000747$fn__31000748")

var Lit_174 *jrt.String = jrt.Intern("c__")

var Lit_175 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000752__31000756$fn__31000757")

var Lit_176 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000752__31000756$fn__31000757$fn__31000758")

var Lit_177 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770$fn__31000771")

var Lit_178 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770$fn__31000771$iter__31000766__31000772")

var Lit_179 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770$fn__31000771$fn__31000778")

var Lit_180 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770$fn__31000771$fn__31000784")

var Lit_181 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770$fn__31000771$fn__31000792")

var Lit_182 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770$fn__31000771$iter__31000794__31000798")

var Lit_183 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770$fn__31000771$fn__31000810")

var Lit_184 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770$fn__31000771$fn__31000812")

var Lit_185 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770$fn__31000771$fn__31000814")

var Lit_186 *jrt.String = jrt.Intern("_l")

var Lit_187 *jrt.String = jrt.Intern("_b")

var Lit_188 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770$fn__31000771$iter__31000766__31000772$fn__31000773")

var Lit_189 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770$fn__31000771$iter__31000766__31000772$fn__31000773$fn__31000774")

var Lit_190 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770$fn__31000771$iter__31000794__31000798$fn__31000799")

var Lit_191 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000764__31000770$fn__31000771$iter__31000794__31000798$fn__31000799$fn__31000800")

var Lit_192 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000818__31000822$fn__31000823")

var Lit_193 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000818__31000822$fn__31000823$fn__31000824")

var Lit_194 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000818__31000822$fn__31000823$fn__31000830")

var Lit_195 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000818__31000822$fn__31000823$fn__31000832")

var Lit_196 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000818__31000822$fn__31000823$fn__31000824$fn__31000825")

var Lit_197 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000818__31000822$fn__31000823$fn__31000824$fn__31000827")

var Lit_198 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000836__31000840$fn__31000841")

var Lit_199 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000836__31000840$fn__31000841$fn__31000842")

var Lit_200 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000846__31000850$fn__31000851")

var Lit_201 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000846__31000850$fn__31000851$fn__31000852")

var Lit_202 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTR")

var Lit_203 *jrt.String = jrt.Intern("arbace.lang.Compiler$AOTF")

var Lit_204 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000856__31000860$fn__31000861")

var Lit_205 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000856__31000860$fn__31000861$fn__31000862")

var Lit_206 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000866__31000870$fn__31000871")

var Lit_207 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_$iter__31000866__31000870$fn__31000871$fn__31000872")

var Lit_208 *jrt.String = jrt.Intern("target-")

var Lit_209 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke$fn__31000540")

var Lit_210 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_let$fn__31000386")

var Lit_211 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000407")

var Lit_212 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000409")

var Lit_213 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000411__31000415")

var Lit_214 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000421__31000427")

var Lit_215 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000440")

var Lit_216 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$fn__31000442")

var Lit_217 *jrt.String = jrt.Intern("body-")

var Lit_218 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000411__31000415$fn__31000416")

var Lit_219 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000411__31000415$fn__31000416$fn__31000417")

var Lit_220 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000421__31000427$fn__31000428")

var Lit_221 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000421__31000427$fn__31000428$iter__31000423__31000432")

var Lit_222 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000421__31000427$fn__31000428$iter__31000423__31000432$fn__31000433")

var Lit_223 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn$iter__31000421__31000427$fn__31000428$iter__31000423__31000432$fn__31000433$fn__31000434")

var Lit_224 *jrt.String = jrt.Intern("root-")

var Lit_225 *jrt.String = jrt.Intern("linked-")

var Lit_226 *jrt.String = jrt.Intern("ifn-")

var Lit_227 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000268")

var Lit_228 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000270")

var Lit_229 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000272")

var Lit_230 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site$fn__31000274")

var Lit_231 *jrt.String = jrt.Intern("arg-")

var Lit_232 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_list_array$fn__31000037")

var Lit_233 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_recur$fn__31000389")

var Lit_234 *jrt.String = jrt.Intern("recur arg for primitive local: ")

var Lit_235 *jrt.String = jrt.Intern(" is not matching primitive")

var Lit_236 *jrt.String = jrt.Intern("__init")

var Lit_237 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$unit_methods__31000960")

var Lit_238 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000967")

var Lit_239 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000979__31000983")

var Lit_240 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000995__31000999")

var Lit_241 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31001009__31001013")

var Lit_242 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000967$iter__31000968__31000972")

var Lit_243 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000967$iter__31000968__31000972$fn__31000973")

var Lit_244 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$calls__31000967$iter__31000968__31000972$fn__31000973$fn__31000974")

var Lit_245 *jrt.String = jrt.Intern("unit")

var Lit_246 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000979__31000983$fn__31000984")

var Lit_247 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000979__31000983$fn__31000984$fn__31000985")

var Lit_248 *jrt.String = jrt.Intern("$part")

var Lit_249 *jrt.String = jrt.Intern("")

var Lit_250 *jrt.String = jrt.Intern("part")

var Lit_251 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000995__31000999$fn__31001000")

var Lit_252 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31000995__31000999$fn__31001000$fn__31001001")

var Lit_253 *jrt.String = jrt.Intern("init")

var Lit_254 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31001009__31001013$fn__31001014")

var Lit_255 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$iter__31001009__31001013$fn__31001014$fn__31001015")

var Lit_256 *jrt.String = jrt.Intern("load")

var Lit_257 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source$unit_methods__31000960$fn__31000961")

var Lit_258 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_call$fn__31000523")

var Lit_259 *jrt.String = jrt.Intern("getReturnType")

var Lit_260 *jrt.String = jrt.Intern("getParameterTypes")

var Lit_261 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$body__31000445")

var Lit_262 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000447__31000451")

var Lit_263 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000447__31000451$fn__31000452")

var Lit_264 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try$iter__31000447__31000451$fn__31000452$fn__31000453")

var Lit_265 *jrt.String = jrt.Intern("unboxed emit of ")

var Lit_266 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_unboxed$fn__31000582")

var Lit_267 *jrt.String = jrt.Intern("no unboxed back end for ")

var Lit_268 *jrt.String = jrt.Intern("TYPE")

var Lit_269 *jrt.String = jrt.Intern("a fn closing over locals as a constant: ")

var Lit_270 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value$fn__31000057")

var Lit_271 *jrt.String = jrt.Intern("can't embed unreadable object in code: ")

var Lit_272 *jrt.String = jrt.Intern("arbace.lang.Var")

var Lit_273 *jrt.String = jrt.Intern("arbace.lang.Keyword")

var Lit_274 *jrt.String = jrt.Intern("arbace.lang.Symbol")

var Lit_275 *jrt.String = jrt.Intern("arbace.lang.IObj")

var Lit_276 *jrt.String = jrt.Intern("arbace.lang.IPersistentMap")

var Lit_277 *jrt.String = jrt.Intern("arbace.lang.IPersistentVector")

var Lit_278 *jrt.String = jrt.Intern("arbace.lang.IPersistentSet")

var Lit_279 *jrt.String = jrt.Intern("arbace.lang.IPersistentList")

var Lit_280 *jrt.String = jrt.Intern("arbace.lang.ISeq")

var Lit_281 *jrt.String = jrt.Intern("arbace.lang.IType")

var Lit_282 *jrt.String = jrt.Intern("arbace.lang.IRecord")

var Lit_283 *jrt.String = jrt.Intern("arbace.lang.PersistentHashSet")

var Lit_284 *jrt.String = jrt.Intern("arbace.lang.Namespace")

var Lit_285 *jrt.String = jrt.Intern("java.util.IdentityHashMap")

var Lit_286 *jrt.String = jrt.Intern("java.util.regex.Pattern")

var Lit_287 *jrt.String = jrt.Intern("aot: ")

var Lit_288 *jrt.String = jrt.Intern("fiMethod")

var Lit_289 *jrt.String = jrt.Intern("/go/arbace/jrt")

var Lit_290 *jrt.String = jrt.Intern("ARBACE_AOT_ROOT")

var Lit_291 *jrt.String = jrt.Intern("fn-class")

var Lit_292 *jrt.String = jrt.Intern("fncls__")

var Lit_293 *jrt.String = jrt.Intern("fnbody__")

var Lit_294 *jrt.String = jrt.Intern("d")

var Lit_295 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$fn__31001066")

var Lit_296 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31001068__31001072")

var Lit_297 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31001068__31001072$fn__31001073")

var Lit_298 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31001068__31001072$fn__31001073$fn__31001074")

var Lit_299 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31001068__31001072$fn__31001073$fn__31001084")

var Lit_300 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record$iter__31001068__31001072$fn__31001073$fn__31001074$fn__31001078")

var Lit_301 *jrt.String = jrt.Intern("p")

var Lit_302 *jrt.String = jrt.Intern("arbace.c2j.emit$intrinsic_probe$fn__31000316")

var Lit_303 *jrt.String = jrt.Intern("arbace.c2j.emit$invoke_linked$fn__31000288")

var Lit_304 *jrt.String = jrt.Intern("(")

var Lit_305 *jrt.String = jrt.Intern("arbace.c2j.emit$jrt_lacks_QMARK_$fn__31000295")

var Lit_306 *jrt.String = jrt.Intern("_")

var Lit_307 *jrt.String = jrt.Intern("unknown empty collection")

var Lit_308 *jrt.String = jrt.Intern("linked")

var Lit_309 *jrt.String = jrt.Intern("arbace.c2j.emit$link_form$fn__31000281")

var Lit_310 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op1$guard__31000309")

var Lit_311 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op2$checked__31000303")

var Lit_312 *jrt.String = jrt.Intern("and")

var Lit_313 *jrt.String = jrt.Intern("xor")

var Lit_314 *jrt.String = jrt.Intern("or")

var Lit_315 *jrt.String = jrt.Intern("remainder")

var Lit_316 *jrt.String = jrt.Intern("shiftLeft")

var Lit_317 *jrt.String = jrt.Intern("quotient")

var Lit_318 *jrt.String = jrt.Intern("shiftRight")

var Lit_319 *jrt.String = jrt.Intern("fn-method")

var Lit_320 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000600__31000604")

var Lit_321 *jrt.String = jrt.Intern("a worker's body recurs to its parameters: ")

var Lit_322 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$fn__31000610")

var Lit_323 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$fn__31000612")

var Lit_324 *jrt.String = jrt.Intern("p-")

var Lit_325 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000600__31000604$fn__31000605")

var Lit_326 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body$iter__31000600__31000604$fn__31000605$fn__31000606")

var Lit_327 *jrt.String = jrt.Intern("a call of a method of a class made at run time: ")

var Lit_328 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000321")

var Lit_329 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000323")

var Lit_330 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000325")

var Lit_331 *jrt.String = jrt.Intern("arbace.lang.Numbers")

var Lit_332 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$lv__31000327")

var Lit_333 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$dv__31000329")

var Lit_334 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000332")

var Lit_335 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$is__31000337")

var Lit_336 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000341")

var Lit_337 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000343")

var Lit_338 *jrt.String = jrt.Intern("nr-")

var Lit_339 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$fn__31000345")

var Lit_340 *jrt.String = jrt.Intern("na-")

var Lit_341 *jrt.String = jrt.Intern("n")

var Lit_342 *jrt.String = jrt.Intern("-")

var Lit_343 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast$is__31000337$fn__31000338")

var Lit_344 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000349")

var Lit_345 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000353")

var Lit_346 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000355")

var Lit_347 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic$fn__31000349$fn__31000350")

var Lit_348 *jrt.String = jrt.Intern("arbace.c2j.emit$obj_array$fn__31000163")

var Lit_349 *jrt.String = jrt.Intern("arbace.c2j.emit$pool$fn__31000032")

var Lit_350 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$num__31000065")

var Lit_351 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode$arr__31000067")

var Lit_352 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000076")

var Lit_353 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$walk__31000078")

var Lit_354 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000084")

var Lit_355 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000092")

var Lit_356 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000098")

var Lit_357 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000104")

var Lit_358 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$fn__31000113")

var Lit_359 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000118__31000122")

var Lit_360 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000118__31000122$fn__31000123")

var Lit_361 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields$iter__31000118__31000122$fn__31000123$fn__31000124")

var Lit_362 *jrt.String = jrt.Intern("arbace.c2j.emit$prim_arg$conv__31000262")

var Lit_363 *jrt.String = jrt.Intern("arbace.c2j.emit$psig$fn__31000176")

var Lit_364 *jrt.String = jrt.Intern("arbace.c2j.emit$psig$fn__31000178")

var Lit_365 *jrt.String = jrt.Intern("CTOR")

var Lit_366 *jrt.String = jrt.Intern("arbace.c2j.emit$qualified_method_expr$fn__31000549")

var Lit_367 *jrt.String = jrt.Intern("arbace.c2j.emit$qualified_method_expr$fn__31000551")

var Lit_368 *jrt.String = jrt.Intern("arbace.c2j.emit$qualified_method_expr$fn__31000553")

var Lit_369 *jrt.String = jrt.Intern("INSTANCE")

var Lit_370 *jrt.String = jrt.Intern("invoke__")

var Lit_371 *jrt.String = jrt.Intern("arbace.c2j.emit$qualified_method_expr$iter__31000555__31000559")

var Lit_372 *jrt.String = jrt.Intern("STATIC")

var Lit_373 *jrt.String = jrt.Intern("arbace.c2j.emit$qualified_method_expr$iter__31000555__31000559$fn__31000560")

var Lit_374 *jrt.String = jrt.Intern("arbace.c2j.emit$qualified_method_expr$iter__31000555__31000559$fn__31000560$fn__31000561")

var Lit_375 *jrt.String = jrt.Intern("arbace.c2j.emit$qualified_method_expr$iter__31000555__31000559$fn__31000560$fn__31000565")

var Lit_376 *jrt.String = jrt.Intern("arbace.c2j.emit$qualified_method_expr$iter__31000555__31000559$fn__31000560$fn__31000561$fn__31000562")

var Lit_377 *jrt.String = jrt.Intern("arg")

var Lit_378 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000022")

var Lit_379 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000024")

var Lit_380 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_$fn__31000024$fn__31000025")

var Lit_381 *jrt.String = jrt.Intern("cut")

var Lit_382 *jrt.String = jrt.Intern("mismatched primitive return, expected ")

var Lit_383 *jrt.String = jrt.Intern(", had ")

var Lit_384 *jrt.String = jrt.Intern("arbace.c2j.emit$ret_body$num__31000593")

var Lit_385 *jrt.String = jrt.Intern("arbace.lang.IProxy")

var Lit_386 *jrt.String = jrt.Intern("arbace.c2j.emit$site_fn_methods$fn__31000255")

var Lit_387 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000361")

var Lit_388 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000363")

var Lit_389 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000365")

var Lit_390 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000367")

var Lit_391 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000369")

var Lit_392 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic$fn__31000371")

var Lit_393 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$param_QMARK___31000204")

var Lit_394 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$fn__31000208")

var Lit_395 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$fn__31000243")

var Lit_396 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$fn__31000208$fn__31000240")

var Lit_397 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask$param_QMARK___31000204$fn__31000205")

var Lit_398 *jrt.String = jrt.Intern("arbace.c2j.emit$type_literal$iter__31000042__31000046")

var Lit_399 *jrt.String = jrt.Intern("getBasis")

var Lit_400 *jrt.String = jrt.Intern("#")

var Lit_401 *jrt.String = jrt.Intern("arbace.c2j.emit$type_literal$iter__31000042__31000046$fn__31000047")

var Lit_402 *jrt.String = jrt.Intern("arbace.c2j.emit$type_literal$iter__31000042__31000046$fn__31000047$fn__31000048")

var Lit_403 *jrt.String = jrt.Intern("arbace.c2j.emit$typed_args$fn__31000156")

var Lit_404 *jrt.String = jrt.Intern("arbace.c2j.emit$typed_args$fn__31000156$fn__31000157")

var Lit_405 *jrt.String = jrt.Intern("uncheckedIntCast")

var Lit_406 *jrt.String = jrt.Intern("intCast")

var Lit_407 *jrt.String = jrt.Intern("uncheckedFloatCast")

var Lit_408 *jrt.String = jrt.Intern("floatCast")

var Lit_409 *jrt.String = jrt.Intern("uncheckedDoubleCast")

var Lit_410 *jrt.String = jrt.Intern("doubleCast")

var Lit_411 *jrt.String = jrt.Intern("uncheckedLongCast")

var Lit_412 *jrt.String = jrt.Intern("longCast")

var Lit_413 *jrt.String = jrt.Intern("uncheckedByteCast")

var Lit_414 *jrt.String = jrt.Intern("byteCast")

var Lit_415 *jrt.String = jrt.Intern("uncheckedShortCast")

var Lit_416 *jrt.String = jrt.Intern("shortCast")

var Lit_417 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_418 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000883__31000887")

var Lit_419 *jrt.String = jrt.Intern("a top-level fn closing over locals")

var Lit_420 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$fn__31000919")

var Lit_421 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000921__31000925")

var Lit_422 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$fn__31000951")

var Lit_423 *jrt.String = jrt.Intern("type")

var Lit_424 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000883__31000887$fn__31000888")

var Lit_425 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000883__31000887$fn__31000888$fn__31000889")

var Lit_426 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000883__31000887$fn__31000888$fn__31000903")

var Lit_427 *jrt.String = jrt.Intern("an event of a class made at run time: ")

var Lit_428 *jrt.String = jrt.Intern("iface")

var Lit_429 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000883__31000887$fn__31000888$fn__31000905")

var Lit_430 *jrt.String = jrt.Intern("proxy")

var Lit_431 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000883__31000887$fn__31000888$fn__31000907")

var Lit_432 *jrt.String = jrt.Intern("imethod")

var Lit_433 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000883__31000887$fn__31000888$fn__31000909")

var Lit_434 *jrt.String = jrt.Intern("stub")

var Lit_435 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000883__31000887$fn__31000888$fn__31000911")

var Lit_436 *jrt.String = jrt.Intern("ns")

var Lit_437 *jrt.String = jrt.Intern("an event of kind ")

var Lit_438 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000883__31000887$fn__31000888$fn__31000889$fn__31000891")

var Lit_439 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000883__31000887$fn__31000888$fn__31000889$fn__31000893")

var Lit_440 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000883__31000887$fn__31000888$fn__31000889$fn__31000895")

var Lit_441 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000883__31000887$fn__31000888$fn__31000889$fn__31000897")

var Lit_442 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000883__31000887$fn__31000888$fn__31000889$fn__31000899")

var Lit_443 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000921__31000925$fn__31000926")

var Lit_444 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000921__31000925$fn__31000926$fn__31000927")

var Lit_445 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000921__31000925$fn__31000926$iter__31000939__31000943")

var Lit_446 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000921__31000925$fn__31000926$fn__31000927$iter__31000928__31000932")

var Lit_447 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000921__31000925$fn__31000926$fn__31000927$iter__31000928__31000932$fn__31000933")

var Lit_448 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000921__31000925$fn__31000926$fn__31000927$iter__31000928__31000932$fn__31000933$fn__31000934")

var Lit_449 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000921__31000925$fn__31000926$iter__31000939__31000943$fn__31000944")

var Lit_450 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method$iter__31000921__31000925$fn__31000926$iter__31000939__31000943$fn__31000944$fn__31000945")

var Lit_451 *jrt.String = jrt.Intern("arbace.c2j.emit$var_fns$fn__31000250")

var Lit_452 *jrt.String = jrt.Intern("arbace.c2j.emit$var_fns$fn__31000252")

var Lit_453 *jrt.String = jrt.Intern("arbace.c2j.emit$walk_nodes$w__31000181")

var Lit_454 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn8,arglistsyn1,xyn3,msgyn1,&yn4,datayn1,vkn3,tagyn6,Stringyn5,Classyn4,voidyn6,doubleyn4,charyn4,byteyn7,booleanyn5,floatyn4,longyn5,shortyn3,intyn1,syn1,ckn8,declaredyn3,ctxyn3,topyn5,ctypeyn2,xsyn9,Characteryn16,java.lang.Stringkn4,longkn6,doublekn3,intkn6,symbolkn6,stringkn6,vectorkn4,listkn3,varkn7,keywordkn5,classkn3,nilkn3,setkn7,booleankn3,mapkn4,charkn7,patternyn13,StringBuilderyn6,sharedyn6,constskn7,dynamicyn4,baseyn1,byn2,lbyn1,eyn1,nyn1,fyn2,psyn2,esyn3,Varyn2,mnyn2,usyn5,nargsyn1,tyn1,kyn5,fnodeyn4,argsyn3,keyyn3,outyn4,convyn1,myn5,cnameyn8,variadicyn5,primsyn5,specsyn7,classesyn15,IdentityHashMapyn1,_yn24,java.lang.reflect.Methodyn8,unboxed?ys14,java.lang.Long9,MIN_VALUEys14,java.lang.Long9,MAX_VALUEv11,arbace.core5,in-nsMyn15,arbace.c2j.emitm2,R0,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).m2,R0,s1619,Standalone S6 (doc/STANDALONE-NOTES.md, \"S6: Arbace compiled to Go\"): the back end that\n  compiles analyzed namespaces to Java forms, which j2g translates into Go like the runtime's\n  own classes.\n\n  The input is what the program records while it prepares its namespaces (ARBACE_COMPILE): for\n  each source, its units in order (a top-level form, analyzed: Compiler$Image's unit, its Expr\n  tree and the events of its analysis), read through Compiler$AST/node, which shows a node's\n  fields as a map. The output follows the JVM's bytecode back end (Compiler.clj on the branch\n  arbace-for-java-26: ObjExpr.compile, the emit methods), with Java forms in place of\n  bytecode:\n\n  - a fn (FnExpr) is a class named as the JVM names it (arbace.walk$walk), a static member\n    class of a holder class per namespace (arbace.walk), nested as its name nests; it extends\n    AFunction (RestFn when variadic), its closed-over locals are fields set by its constructor,\n    each arity an invoke method (doInvoke for the variadic one), its constants static fields;\n  - a source's top-level forms are the static methods of its loader class SCRIPTBASE__init\n    (arbace.walk__init), whose load() runs them in order; Compiler$AOT/load calls it in the\n    bindings Compiler.load makes; past loader-part-units units, in parts, static member\n    classes SCRIPTBASE__init$partP (SA210);\n  - each Expr becomes the Java forms code its emit method's bytecode is: interop on the\n    analyzer's resolved members (param-tags pin the overload), reflection where it was\n    unresolved, Clojure's boxing and conversions (emitBoxReturn, emitTypedArgs).R1,v15,arbace.c2j.emit10,node-cachem10,R2,TR3,i36,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s58,The nodes' maps by node (the back end runs on one thread).v15,arbace.c2j.emit4,nodem10,R6,L1,V1,R7,R0,s62,The analyzed node x as a map (Compiler$AST/node), nil for nil.R3,i40,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,failm10,R2,TR6,L1,V3,R8,R9,V1,R10,R3,i49,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,dup-strm12,R2,TR6,L1,V1,R11,R0,s217,v printed for the reader (*print-dup*), or \"#<CLASS>\" when print-dup has no method for it (an\n  Object a macro left in code: print-dup's own error came before c2j's \"can't embed unreadable object\";\n  queue 206's low).R3,i52,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,destubm10,R6,L1,V1,Myn1,nm2,R12,R13,R0,s74,A class name without the compile stub's prefix (Compiler.destubClassName).R3,i63,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,type-symm10,R6,L1,V1,Myn1,cm2,R12,R14,R0,s93,The Java forms type of class c: a primitive's name, a class's binary name, an array as\n  T/n.R3,i68,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,prim-namesR15,R16,R17,R18,R19,R20,R21,R22,R23,m8,R2,TR3,i79,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,taggedm12,R2,TR6,L1,V2,R24,R25,R0,s44,Symbol s with the Java forms tag of class c.R3,i83,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,registeredv11,arbace.core4,atomm10,R2,TR3,i92,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s84,Whether a class name is registered in the program (Class/forName finds it), by name.v15,arbace.c2j.emit11,registered?m10,R2,TR6,L1,V1,Myn1,cm2,R12,R14,R3,i96,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit21,dynamic-class-cached?m8,R26,TR3,i113,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,runtime-class?m12,R2,TR6,L1,V2,Myn1,cm2,R12,R14,R27,R0,s291,Is class c made at run time (a Dyn class: an evaluated fn's, deftype's, interface's, proxy's)\n  rather than a class of the program, or one the program does not register by name (java.sql's,\n  whose members reflection reached from a world class)? Such a class is not named in compiled\n  code.R3,i115,R4,i1,R5,s18,arbace/c2j/emit.aev11,arbace.core12,define-proxyv15,arbace.c2j.emit7,public?m10,R2,TR6,L1,V1,Myn1,cm2,R12,R14,R3,i131,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,top-namem10,R2,TR6,L1,V1,Myn1,nm2,R12,R13,R3,i137,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,poolm12,R2,TR6,L1,V2,R27,R28,R0,s178,The constants of top-level class top (a namespace's holder, a deftype, a loader), which its\n  member classes share (SA145): an atom {:name :consts :const-map}, made on first use.R3,i139,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,const-fieldm12,R2,TR6,L1,V3,R27,R11,R29,R0,s236,The static field holding constant value v in the class being emitted, made on first use (as\n  the JVM's const__N, one per distinct object): its symbol, const-N (a munged local's name has\n  no -, so no local, name__index, can shadow it).R3,i149,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-valuem8,R26,TR3,i170,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,fn-instancem8,R26,TR3,i170,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,emit-list-arraym10,R2,TR6,L1,V2,R27,R30,R3,i172,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,char-formm10,R2,TR6,L1,V1,Myn1,cm2,R12,R31,R3,i175,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,double-formm10,R2,TR6,L1,V1,Myn1,dm2,R12,R16,R3,i181,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,type-literalm12,R2,TR6,L1,MV1,R11,m2,R12,R32,R0,s257,The text the reader makes record or deftype v of again: a record's print-dup (#my.Rec{...}),\n  a deftype's constructor literal of its fields (#my.T[...]), as the JVM's emitValue calls Rec's\n  create and T's constructor (a literal of Clojure's suite, REAP3).R3,i186,R4,i1,R5,s18,arbace/c2j/emit.aem10,R6,L1,V2,R27,R11,R0,s72,Code making constant value v (ObjExpr.emitValue), its metadata included.R3,i199,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,pool-kindm12,R2,TR6,L1,V1,R11,R0,s58,The tag of constant v, in the order of emit-value's cases.R3,i283,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,pool-partialS16,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,R48,m10,R2,TR3,i308,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s61,The kinds whose metadata is made too (emit-value's partial?).v15,arbace.c2j.emit12,pool-shared?m12,R2,TR6,L1,V1,R11,R0,s84,Is v made once in a pool and named where used: a keyword, a symbol without metadata.R3,i312,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,pool-partsm12,R2,TR6,L1,V1,R11,R0,s62,The values constant v is made of (its elements, its metadata).R3,i317,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,pool-strm10,R2,TR6,L1,V2,Myn2,sbm2,R12,R49,Myn1,sm2,R12,R13,R3,i328,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,pool-encodem12,R2,TR6,L1,V3,Myn2,sbm2,R12,R49,R50,R11,R0,s102,Appends the encoding of v to sb (Compiler$AOT/poolValue's format); shared: shared value →\n  its index.R3,i331,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,pool-fieldsm12,R2,TR6,L1,V1,R51,R0,s264,The static fields of constants consts ([sym type value alias] ...): the pool's array, decoded\n  once (Compiler$AOT/pool), then each constant's field, its element, or for one with an alias\n  (a split loader's constant an earlier part made, SA210) that part's field.R3,i379,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,const-typem10,R2,TR6,L1,V1,R11,R3,i412,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,*late-classes*m10,R52,TR3,i418,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s398,The names of the classes the Java forms compiler made while the program prepared (its\n  deftypes, fns and defclasses using the Java forms, arbace.c2j.main's java-forms-classes): in the\n  tree, but j2g may leave one out (Clojure in its body it cannot analyze, F2.4), so a constant\n  naming one is looked up where used, as a class made at run time, and the classes holding it\n  initialize without it.v15,arbace.c2j.emit15,*event-classes*m10,R52,TR3,i426,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s143,The names of the classes the recorded units' events make (arbace.c2j.main's compile-all):\n  compiled, or made at run time again by their units.v15,arbace.c2j.emit13,dynamic-cachem8,R2,TR3,i431,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,dynamic-class?*m12,R2,TR6,L1,V1,Myn1,cm2,R12,R14,R0,s238,Was class c made at run time while the program prepared, by no recorded event (a deftype an\n  eval made while a namespace loaded: Clojure's suite's compilation.examples, REAP3)? The class\n  is made again when that code runs, not compiled.R3,i433,R4,i1,R5,s18,arbace/c2j/emit.aem10,R2,TR6,L1,V1,Myn1,cm2,R12,R14,R3,i446,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,holds-fn?m12,R2,TR6,L1,V1,R11,R0,s71,Does constant v hold an evaluated fn (in a collection or its metadata)?R3,i450,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,constantm10,R2,TR6,L1,V2,R27,R11,R3,i460,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,gsymm12,R2,TR6,L1,V2,R27,R53,R0,s146,A fresh name for a temporary of the emitted code, numbered per class being emitted (the\n  output does not depend on the program's gensym counter).R3,i477,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,local-symm12,R2,TR6,L1,V1,R54,R0,s95,The Java forms local of LocalBinding lb (its node b): its name and index, unique in a\n  method.R3,i485,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,identity-setm12,R2,TR6,L1,V1,R30,R0,s259,The objects of xs as a set by identity. A fn's closes map cannot be asked containsKey: its\n  keys, LocalBindings, hash by their index (Arbace's deterministic hashCode), and FnExpr.parse\n  renumbers a direct fn's arguments after its inner fns closed over them.R3,i491,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,closed?m10,R2,TR6,L1,V2,R27,R55,R3,i500,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,field-symm10,R2,TR6,L1,V1,R54,R3,i504,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,field-readm10,R2,TR6,L1,V3,R27,R55,R54,R3,i506,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,emitm8,R26,TR3,i513,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,emit-unboxedm8,R26,TR3,i513,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,emit-fn-class!m8,R26,TR3,i513,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,emit-deftype-class!m8,R26,TR3,i513,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,emit-bodym8,R26,TR3,i513,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,jrt-lacks?m8,R26,TR3,i513,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,prim-callm8,R26,TR3,i513,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,spec-intrinsicm8,R26,TR3,i513,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-localm8,R26,TR3,i513,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,primm10,R2,TR6,L1,V1,R56,R3,i516,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,can-prim?m10,R2,TR6,L1,V1,R57,R3,i518,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,box-ofm8,R26,TR3,i520,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit3,boxm12,R2,TR6,L1,V2,R58,Myn1,cm2,R12,R14,R0,s113,Form f of type c as a boxed value (emitBoxReturn: valueOf, long's Numbers.num being\n  Long.valueOf; void as nil).R3,i522,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,unbox-argm12,R2,TR6,L1,V3,R27,R58,Myn1,pm2,R12,R14,R0,s67,Boxed form f converted to parameter type p (HostExpr.emitUnboxArg).R3,i531,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit3,fi?m12,R2,TR6,L1,V1,Myn1,pm2,R12,R14,R0,s136,Is p a functional interface a fn argument is adapted to (Clojure 1.12's FISupport, as the\n  analysis decides it: Compiler$AST/fiMethod)?R3,i550,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,typed-argsm12,R2,TR6,L1,V3,R27,R59,R60,R0,s70,The arguments es as parameters of types ps (MethodExpr.emitTypedArgs).R3,i557,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,param-tagsm10,R2,TR6,L1,V1,R59,R3,i585,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,obj-arraym10,R2,TR6,L1,V2,R27,R60,R3,i587,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,var-valuem10,R2,TR6,L1,V2,R27,Myn1,vm2,R12,R61,R3,i590,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,line-metam10,R2,TR6,L1,V2,R58,R57,R3,i594,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,spec-localm12,R2,TR6,L1,V2,R27,R55,R0,s75,The worker's long and box of parameter lb (F6, spec-mask: {:l :b}), or nil.R3,i599,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,long-box*m10,R2,TR6,L1,V1,R58,R3,i605,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,local-placem12,R2,TR6,L1,V2,R27,R57,R0,s238,Where the local of node n lives in the emitted code (the local node kind's place): {:form\n  its read and the target of its write, :clears true when its use clears it (a ^:once fn's\n  closed-over value read for the last time on its path)}.R3,i607,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit6,*link*m10,R52,TR3,i627,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s209,While the call sites of vars may be linked, an atom of the sites' data in the order emitted\n  (arbace.c2j.main's compile-all binds it, and resolves the sites, link-form, once every class\n  is known); else nil.v15,arbace.c2j.emit8,link-keym12,R2,TR6,L1,V1,Myn1,vm2,R12,R61,R0,s355,The key of the compiled fn var v's root is at the end of the prepare run, for a call site\n  of v: the FnExpr of an evaluated fn (Compiler$EvalFn), or the class name of a compiled one\n  (Compiler$AOTFn, Compiler$AOTRestFn: the back end's own namespaces, compiled-back-end); nil\n  when v is dynamic, ^:dynamic, ^:redef or a macro, or its root is no such fn.R3,i633,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,deepm8,R26,TR3,i647,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,psigm12,R2,TR6,L1,V1,R62,R0,s156,The primitive signature of FnMethod mn (its node): {:params [Class...] :ret Class}, each\n  long, double or Object; nil when the method has no unboxed entry.R3,i656,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,intrinsic-probem8,R26,TR3,i666,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,long-valued-opsm8,R26,TR3,i666,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,walk-nodesm12,R2,TR6,L1,V2,R56,R58,R0,s117,Calls f on the node (map) of each Expr of the tree of e, not inside the methods of nested\n  fns, reifys and deftypes.R3,i668,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,spec-maskm12,R2,TR6,L1,V1,R62,R0,s631,Futamura F6, step 2: which parameters of FnMethod mn (its node) a speculative worker takes as\n  longs: those an operation of Numbers with fast paths takes as an Object operand (F3), when the\n  method also passes one of them, or such an operation of them, to a call of a var (where a\n  worker may take it unboxed: the worker's gain; a fn whose parameters only meet operations,\n  as arbace.core's +, would pay the dispatch for nothing); nil when there are none, or when the\n  method has an unboxed entry (psig), is variadic, has more than 4 parameters, or recurs to its\n  parameters (a recur would rebind them to values of any type).R3,i684,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,*var-fns*m10,R52,TR3,i728,R4,i1,R5,s18,arbace/c2j/emit.aeR0,s441,The fn each var's last def in the recorded units defines (an IdentityHashMap Var → FnExpr,\n  var-fns; arbace.c2j.main's compile-all binds it): the code an F6 call site's linked call\n  expects, read from the analysis alone, so that the back end decides the same whether its own\n  namespaces and arbace.core run evaluated (their roots Compiler$EvalFns) or compiled\n  (Compiler$AOTFns, compiled-back-end: the fixpoint's G2); nil when not bound.v15,arbace.c2j.emit7,var-fnsm10,R6,L1,V1,R63,R0,s161,The index *var-fns* of units us (each the recorded [kind line column lb cb expr events]): by\n  each var, the FnExpr of its last top-level def whose init is a fn.R3,i736,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit15,site-fn-methodsm12,R2,TR6,L1,V2,Myn1,vm2,R12,R61,R64,R0,s89,The fixed-arity method of nargs parameters (its node) of the fn var v's last def defines.R3,i751,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,site-specm12,R2,TR6,L1,V2,Myn1,vm2,R12,R61,R64,R0,s82,The worker's mask (spec-mask) of the fixed arity nargs of the fn of var v, or nil.R3,i765,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,site-psigm12,R2,TR6,L1,V2,Myn1,vm2,R12,R61,R64,R0,s76,The primitive signature of the fixed arity nargs of the fn of var v, or nil.R3,i771,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,prim-argm12,R2,TR6,L1,V4,R27,R56,Myn1,pm2,R12,R14,R65,R0,s355,Argument e of a call of an unboxed entry, for its parameter of class p: {:binds (the\n  temporary of its value, evaluated once, in order), :gen (its boxed value, as the generic call\n  passes it), :pri (its value as the entry takes it: the boxed invoke's own conversion of the\n  boxed value, RT.longCast or doubleCast, unless the argument is of p already)}.R3,i777,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,spec-argm12,R2,TR6,L1,V4,R27,R56,R66,R65,R0,s413,Argument e of a call of a worker (F6, spec-mask), for its parameter taken as a long when k:\n  {:binds (its temporary, evaluated once, in order), :gen (its boxed value, for the generic\n  call), :pass (what the worker takes: the long and the box, or nil for a box the worker makes\n  when needed; the value for a parameter not taken as a long), :guard (the test that it is a\n  Long, nil when it is one by its type)}.R3,i810,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,emit-link-sitem12,R2,TR6,L2,V4,R27,R67,R68,R69,V6,R27,R67,R68,R69,R70,R71,R0,s440,A call of var fexpr (its node fnode) with args (at most 20), linked when its root's code is\n  known (link-key): a marker (c2j/link {...}) holding the emitted root, arguments and\n  temporaries, which link-form resolves into the guarded direct call or the generic one. With\n  out, the class a consumer converts the call's value to (long, double: the code's primitive\n  return), and conv, the consumer's conversion of the generic call's value.R3,i837,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,link-formm10,R6,L2,V3,R72,R73,R74,V5,R72,R73,R74,R75,R76,R0,s1435,The code of link marker m (emit-link-site): with cname, the code class of the fn the site\n  expects (its fixed arity of the call's argument count, variadic its required count or nil),\n  the guarded direct call; without, the generic call T1 makes. The guard: the root is a\n  compiled fn (Compiler$AOTFn, or Compiler$AOTRestFn for variadic code) whose class is the code\n  class's fn class (fn-class, one Class per code: Compiler$AOT/fnClass), one pointer compare\n  (Compiler$AOTFn/linked, which answers the fn's body or nil); then the code's invoke is called\n  directly with the fn as self, as the fn's invoke would call it. The root is read once, and\n  cast to IFn before the arguments when the guard fails, as the generic call casts it.\n\n  A call of a primitive fn's arity (:psig, F6) or of an arity with a worker (:smask, F6 step 2):\n  its arguments bound first, each once (unboxed when the entry takes it so and it is of that\n  type). For a primitive fn the direct call is of the code's unboxed entry, invokePrim (prims:\n  the code's signatures by arity), its value boxed as the boxed invoke boxes it, or left unboxed\n  for a consumer converting to the return's class (:out); for a worker it is of the code's\n  invokeSpec (specs: the code's masks by arity) when the arguments it takes as longs are Longs\n  (:guard), else of its invoke. The generic call is given the boxed arguments, its value\n  converted as the consumer converts it.R3,i874,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,link-targetm10,R6,L1,V3,R66,R77,Myn8,fn-namesm2,R12,R78,R0,s184,The class name and record of the code class link key k names (link-key), given the classes\n  made (name → record) and the fns' class names by FnExpr (fn-names); nil when none was made.R3,i933,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,site-keym12,R2,TR6,L1,V1,R57,R0,s79,The link key of invoke node n (link-key) when its call may be linked, else nil.R3,i941,R4,i1,R5,s18,arbace/c2j/emit.aem12,R2,TR6,L1,V4,R27,R56,Myn1,pm2,R12,R14,R71,R0,s233,The code of e, an invoke whose value a consumer converts to primitive class p by conv (a fn\n  of the boxed value's form), when it is a call of a primitive fn's arity returning p (F6):\n  its direct call's value left unboxed; else nil.R3,i949,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit13,invoke-linkedm12,R2,TR6,L1,V3,R27,R57,R79,R0,s264,The invoke node kind's refinements of the emitted code (its emit-first): a protocol fn's\n  call, the target's own method when it implements the protocol's interface, else the protocol\n  fn (InvokeExpr.emitProto); a linked call (F5, F6); else nil, the generic call.R3,i960,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,descriptorm10,R2,TR6,L1,V1,Myn1,cm2,R12,R14,R3,i989,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,jrt-scanm8,R2,TR3,i997,R4,i1,R5,s18,arbace/c2j/emit.aem12,R2,TR6,L1,V1,Myn1,mm2,R12,R80,R0,s255,Is method m declared by a class jrt writes by hand (not a stand-in j2g's translation\n  replaces) without it in Go? j2g would translate a direct call to a throw; the member tables\n  (reflection) have such members, so compiled code calls them by reflection.R3,i1000,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,method-callm12,R2,TR6,L1,V4,R27,Myn1,mm2,R12,R80,R65,R68,R0,s69,A call of resolved method m: static (target nil) or on target form t.R3,i1019,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,compiled-interface?m12,R2,TR6,L1,V2,R27,Myn1,cm2,R12,R14,R0,s86,Is class c an interface of a namespace being compiled (gen-interface's, a protocol's)?R3,i1032,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit20,emit-instance-methodm10,R2,TR6,L1,V3,R27,R57,R81,R3,i1037,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-minR82,m8,R2,TR3,i1080,R4,i1,R5,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-maxR83,m8,R2,TR3,i1081,R4,i1,R5,s18,arbace/c2j/emit.ae")

var Lit_455 *jrt.String = jrt.Intern("arbace.c2j.emit$eval31000004$loading__1927001464__auto____31000005")

var Lit_456 *jrt.String = jrt.Intern("arbace.c2j.emit$eval31000008$fn__31000009")

var Lit_457 *jrt.String = jrt.Intern("arbace.c2j.emit$node")

var Lit_458 *jrt.String = jrt.Intern("arbace.c2j.emit$fail")

var Lit_459 *jrt.String = jrt.Intern("arbace.c2j.emit$dup_str")

var Lit_460 *jrt.String = jrt.Intern("arbace.c2j.emit$destub")

var Lit_461 *jrt.String = jrt.Intern("arbace.c2j.emit$type_sym")

var Lit_462 *jrt.String = jrt.Intern("arbace.c2j.emit$tagged")

var Lit_463 *jrt.String = jrt.Intern("arbace.c2j.emit$registered_QMARK_")

var Lit_464 *jrt.String = jrt.Intern("arbace.c2j.emit$runtime_class_QMARK_")

var Lit_465 *jrt.String = jrt.Intern("arbace.c2j.emit$public_QMARK_")

var Lit_466 *jrt.String = jrt.Intern("arbace.c2j.emit$top_name")

var Lit_467 *jrt.String = jrt.Intern("arbace.c2j.emit$pool")

var Lit_468 *jrt.String = jrt.Intern("arbace.c2j.emit$const_field")

var Lit_469 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_list_array")

var Lit_470 *jrt.String = jrt.Intern("arbace.c2j.emit$char_form")

var Lit_471 *jrt.String = jrt.Intern("arbace.c2j.emit$double_form")

var Lit_472 *jrt.String = jrt.Intern("arbace.c2j.emit$type_literal")

var Lit_473 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_value")

var Lit_474 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_kind")

var Lit_475 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_shared_QMARK_")

var Lit_476 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_parts")

var Lit_477 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_str")

var Lit_478 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_encode")

var Lit_479 *jrt.String = jrt.Intern("arbace.c2j.emit$pool_fields")

var Lit_480 *jrt.String = jrt.Intern("arbace.c2j.emit$const_type")

var Lit_481 *jrt.String = jrt.Intern("arbace.c2j.emit$dynamic_class_QMARK__STAR_")

var Lit_482 *jrt.String = jrt.Intern("arbace.c2j.emit$dynamic_class_cached_QMARK_")

var Lit_483 *jrt.String = jrt.Intern("arbace.c2j.emit$holds_fn_QMARK_")

var Lit_484 *jrt.String = jrt.Intern("arbace.c2j.emit$constant")

var Lit_485 *jrt.String = jrt.Intern("arbace.c2j.emit$gsym")

var Lit_486 *jrt.String = jrt.Intern("arbace.c2j.emit$local_sym")

var Lit_487 *jrt.String = jrt.Intern("arbace.c2j.emit$identity_set")

var Lit_488 *jrt.String = jrt.Intern("arbace.c2j.emit$closed_QMARK_")

var Lit_489 *jrt.String = jrt.Intern("arbace.c2j.emit$field_sym")

var Lit_490 *jrt.String = jrt.Intern("arbace.c2j.emit$field_read")

var Lit_491 *jrt.String = jrt.Intern("arbace.c2j.emit$prim")

var Lit_492 *jrt.String = jrt.Intern("arbace.c2j.emit$can_prim_QMARK_")

var Lit_493 *jrt.String = jrt.Intern("arbace.c2j.emit$box")

var Lit_494 *jrt.String = jrt.Intern("arbace.c2j.emit$unbox_arg")

var Lit_495 *jrt.String = jrt.Intern("arbace.c2j.emit$fi_QMARK_")

var Lit_496 *jrt.String = jrt.Intern("arbace.c2j.emit$typed_args")

var Lit_497 *jrt.String = jrt.Intern("arbace.c2j.emit$param_tags")

var Lit_498 *jrt.String = jrt.Intern("arbace.c2j.emit$obj_array")

var Lit_499 *jrt.String = jrt.Intern("arbace.c2j.emit$var_value")

var Lit_500 *jrt.String = jrt.Intern("arbace.c2j.emit$line_meta")

var Lit_501 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_local")

var Lit_502 *jrt.String = jrt.Intern("arbace.c2j.emit$long_box_STAR_")

var Lit_503 *jrt.String = jrt.Intern("arbace.c2j.emit$local_place")

var Lit_504 *jrt.String = jrt.Intern("arbace.c2j.emit$link_key")

var Lit_505 *jrt.String = jrt.Intern("arbace.c2j.emit$psig")

var Lit_506 *jrt.String = jrt.Intern("arbace.c2j.emit$walk_nodes")

var Lit_507 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_mask")

var Lit_508 *jrt.String = jrt.Intern("arbace.c2j.emit$var_fns")

var Lit_509 *jrt.String = jrt.Intern("arbace.c2j.emit$site_fn_methods")

var Lit_510 *jrt.String = jrt.Intern("arbace.c2j.emit$site_spec")

var Lit_511 *jrt.String = jrt.Intern("arbace.c2j.emit$site_psig")

var Lit_512 *jrt.String = jrt.Intern("arbace.c2j.emit$prim_arg")

var Lit_513 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_arg")

var Lit_514 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_link_site")

var Lit_515 *jrt.String = jrt.Intern("arbace.c2j.emit$link_form")

var Lit_516 *jrt.String = jrt.Intern("arbace.c2j.emit$link_target")

var Lit_517 *jrt.String = jrt.Intern("arbace.c2j.emit$site_key")

var Lit_518 *jrt.String = jrt.Intern("arbace.c2j.emit$prim_call")

var Lit_519 *jrt.String = jrt.Intern("arbace.c2j.emit$invoke_linked")

var Lit_520 *jrt.String = jrt.Intern("arbace.c2j.emit$descriptor")

var Lit_521 *jrt.String = jrt.Intern("arbace.c2j.emit$fn__31000292")

var Lit_522 *jrt.String = jrt.Intern("arbace.c2j.emit$jrt_lacks_QMARK_")

var Lit_523 *jrt.String = jrt.Intern("arbace.c2j.emit$method_call")

var Lit_524 *jrt.String = jrt.Intern("arbace.c2j.emit$compiled_interface_QMARK_")

var Lit_525 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_instance_method")

var Lit_526 *jrt.String = jrt.Intern("kn7,dynamickn7,privatekn4,linekn6,columnkn4,filekn3,dockn8,arglistsyn1,fyn2,opyn1,xyn1,yyn4,slowyn1,rkn3,tagyn24,java.lang.reflect.Methodyn8,specs-fnyn2,gsyn8,targs-fnyn3,ctxyn4,argsyn2,asyn1,tyn2,xsyn1,eyn1,nyn8,unboxed?yn23,java.lang.reflect.Fieldyn4,top?yn3,symyn2,esyn2,lbyn4,inityn2,oxyn10,nil-localsyn4,bodyyn1,vkn4,kindyn5,constkn4,optskn5,exprsyn10,NumberExpryn12,ConstantExpryn10,StringExpryn11,KeywordExpryn7,NilExpryn11,BooleanExpryn9,EmptyExpryn10,TheVarExprkn5,chanskn1,okn1,jkn1,dkn5,bindskn3,symkn1,kyn6,statickn4,argsyn6,Objectys24,arbace.lang.Compiler$AST7,literalyn3,numyn7,booleanyn9,instance?yn6,Numberyn2,lvyn4,longyn2,ifyn10,.longValueyn4,castyn2,dvyn6,doubleyn12,.doubleValuekn8,templateyn11,static-caseyn2,chyn9,static-ifyn5,localkn6,fieldsyn1,byn11,shouldClearyn2,atyn5,placeyn7,clears?yn3,letyn9,get-placeyn9,set-placeyn6,IfExpryn4,testyn5,childyn8,testExpryn3,thnyn8,thenExpryn3,elsyn8,elseExpryn1,zyn10,identical?ys24,arbace.lang.Compiler$AST8,primTypeys7,Boolean4,TYPEyn3,runkn1,zyn11,static-callyn16,StaticMethodExpryn6,methodyn4,linekn5,classkn6,domainkn5,indexyn4,nil?ys16,Compiler$CodeRun2,opyn1,myn8,childrenkn7,convertyn18,.getParameterTypesyn3,intyn9,call-siteyn8,run-argsyn6,box-asyn11,call-staticyn6,invokeyn10,InvokeExpryn5,fexpryn12,tailPositionkn10,emit-firstyn13,invoke-linkedyn2,fxyn5,clearyn11,eval-staticyn3,andyn3,notyn13,.-canBeDirectyn6,.-objxyn2,ccyn1,gyn15,arbace.lang.IFnyn7,at-lineyn7,run-allyn9,eval-onlyyn4,whenys16,Compiler$CodeRun9,clearThisyn5,many?yn8,.applyTokn10,param-tagsys16,java.lang.Object1,1yn8,array-ofyn7,.invokeyn6,spliceyn13,instance-callyn18,InstanceMethodExpryn6,targetkn9,eval-onlyyn2,txyn11,cast-targetyn13,call-instanceys14,java.lang.Long7,valueOfys16,java.lang.Double7,valueOfys17,java.lang.Integer7,valueOfys17,java.lang.Boolean7,valueOfys19,java.lang.Character7,valueOfys15,java.lang.Float7,valueOfys15,java.lang.Short7,valueOfys14,java.lang.Byte7,valueOfyn6,Stringyn1,wyn5,Classyn2,mnyn6,paramsyn1,&yn5,entryyn4,charyn5,floatyn5,shortyn4,byteyn3,tagyn1,kyn4,kindyn6,columnyn1,_yn4,expryn6,eventsyn7,classesyn15,runtime-classesyn8,fn-namesyn5,poolsyn3,srcyn5,unitsyn1,cyn11,children-ofyn4,nameyn7,extendsyn7,methodsv15,arbace.c2j.emit6,*lbox*m12,R0,TR1,TR2,i1083,R3,i1,R4,s18,arbace/c2j/emit.aeR5,s107,While set, how the Long case's result is given (spec-intrinsic: as the long itself), in\n  place of its box.v15,arbace.c2j.emit8,long-boxm10,R1,TR6,L1,V1,R7,R2,i1088,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-boxm10,R1,TR6,L1,V1,R7,R2,i1089,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-op2m12,R1,TR6,L1,V5,R8,R9,R10,R11,R12,R5,s202,The Long case of Numbers' binary operation op on longs x, y (symbols; r the result's local):\n  a form of the operation's result type, slow where Numbers would not answer a long; nil: not\n  an intrinsic.R2,i1091,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-op2m12,R1,TR6,L1,V3,R8,R9,R10,R5,s166,The Double case (both operands Double) of Numbers' binary operation op (DoubleOps: the '\n  operations are the others, a difference the sum with the negation), or nil.R2,i1126,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,long-op1m12,R1,TR6,L1,V3,R8,R9,R11,R5,s70,The Long case of Numbers' unary operation op on long x, as long-op2's.R2,i1141,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,double-op1m12,R1,TR6,L1,V2,R8,R9,R5,s64,The Double case of Numbers' unary operation op, as double-op2's.R2,i1157,R3,i1,R4,s18,arbace/c2j/emit.aem12,R1,TR6,L1,V1,Myn1,mm2,R13,R14,R5,s124,Is Numbers' static method m one of the boxed operations with fast paths? Its signature\n  ([:o :j ...]) when it is, else nil.R2,i1169,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,numbers-fastm10,R6,L1,V4,Myn1,mm2,R13,R14,R15,R16,R17,R5,s507,The call of Numbers' static method m with its fast paths, or nil when m is not one of the\n  boxed operations above: the builder both halves of the static call share (arbace.c2j.node's\n  static-call: the evaluator's CodeOpN too, test/c2j/gen_nodes.ae). (specs-fn sig): per operand,\n  the worker's long parameter it is (F6, spec-local: a Long, no test, its long as is, its box\n  for the slow path) or nil; (gs base): a fresh temporary; (targs-fn): the operands' forms,\n  asked after the temporaries are named.R2,i1183,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,numbers-intrinsicm12,R1,TR6,L1,V4,R18,Myn1,mm2,R13,R14,R19,R20,R5,s215,The call of Numbers' static method m on args (as: a delay of their forms, typed-args's) with\n  its fast paths, or nil (numbers-fast). An Object operand that is a worker's long parameter\n  (F6, spec-local) is a Long.R2,i1223,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit16,static-call-formm10,R6,L1,V2,Myn1,mm2,R13,R14,R19,R5,s58,The direct call of static method m on argument forms args.R2,i1236,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit18,instance-call-formm10,R6,L1,V3,Myn1,mm2,R13,R14,R21,R19,R5,s181,The direct (virtual) call of instance method m on target form t, of m's class, with argument\n  forms args (method-call's form; the evaluator's instance-call, test/c2j/gen_nodes.ae).R2,i1242,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,call-staticm12,R1,TR6,L1,V4,R18,Myn1,mm2,R13,R14,R20,R22,R5,s182,The direct call of static method m on the arguments as (a delay of their forms, typed-args\n  of the children xs), with Numbers' fast paths (F3) when m is one of its boxed operations.R2,i1249,R3,i1,R4,s18,arbace/c2j/emit.aeS17,s4,decPs18,unchecked_multiplys8,multiplys8,quotients6,minusPs9,multiplyPs5,minuss13,unchecked_decs4,addPs4,incPs3,incs9,remainders13,unchecked_adds3,adds13,unchecked_incs3,decs15,unchecked_minusm8,R1,TR2,i1255,R3,i1,R4,s18,arbace/c2j/emit.aem12,R1,TR6,L1,V3,R18,R23,R21,R5,s487,Argument e of a worker's call for a parameter it takes as a long (F6, spec-arg), when e is an\n  operation of Numbers with fast paths whose Object operands are all the calling worker's long\n  parameters: its Long case computed as a long, not boxed (the worker boxes it if it needs to,\n  as the generic call's argument would have been boxed, once); its other case's value (Numbers'\n  own: an overflow promoted, a ratio) in temporary t, nil in the Long case. As spec-arg's\n  result, or nil.R2,i1260,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit14,direct-static?m12,R1,TR6,L1,V2,R18,R24,R5,s120,Does the emitted code call the method of static-method node n directly (the static-call\n  node kind), not by reflection?R2,i1293,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit18,emit-static-methodm12,R1,TR6,L1,V3,R18,R24,R25,R5,s85,A static method called by reflection (one direct-static? does not take: static-call).R2,i1301,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,field-ok?m10,R1,TR6,L1,V2,R18,Myn1,fm2,R13,R26,R2,i1311,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit19,emit-instance-fieldm10,R1,TR6,L1,V3,R18,R24,R25,R2,i1314,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,emit-static-fieldm10,R1,TR6,L1,V3,R18,R24,R25,R2,i1323,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-newm10,R1,TR6,L1,V2,R18,R24,R2,i1331,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-defm10,R1,TR6,L1,V3,R18,R24,R27,R2,i1340,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,emit-assignm10,R1,TR6,L1,V2,R18,R24,R2,i1358,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,coll-callm10,R1,TR6,L1,V3,R28,R29,R18,R2,i1391,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,emit-binding-initm12,R1,TR6,L1,V3,R18,R30,R31,R5,s69,A let or loop binding [sym init] of LocalBinding lb (LetExpr.doEmit).R2,i1394,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-letm10,R1,TR6,L1,V3,R18,R24,R25,R2,i1409,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-recurm10,R1,TR6,L1,V2,R18,R24,R2,i1416,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit13,body-instancem12,R1,TR6,L1,V3,R18,R32,R33,R5,s228,A new instance of fn or reify class ox (its node), its closed-over values from the current\n  method: (new C closed...) (ObjExpr.emit); letfn's own locals nil (set after). A fn's is its\n  code (SA141), which fn-wrap makes the fn.R2,i1437,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,fn-wrapm12,R1,TR6,L1,V3,R18,R32,R34,R5,s135,The fn of fn ox (its node) whose code is form body: a Compiler$AOTFn, or a\n  Compiler$AOTRestFn of the variadic arity's required count.R2,i1450,R3,i1,R4,s18,arbace/c2j/emit.aem12,R1,TR6,L1,V3,R18,R32,R33,R5,s33,A new fn or reify (ox, its node).R2,i1477,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,emit-letfnm10,R1,TR6,L1,V3,R18,R24,R25,R2,i1483,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,emit-trym10,R1,TR6,L1,V3,R18,R24,R25,R2,i1500,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,emit-casem10,R1,TR6,L1,V3,R18,R24,R25,R2,i1509,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit4,liftm12,R1,TR6,L1,V3,R18,R35,R21,R5,s209,A defnode's static value v, of class t (a symbol), as the emitted code's: a primitive's\n  literal; nil, a string, a boolean, an empty collection as Java forms write them; else a\n  constant of the class's pool.R2,i1563,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,prim-chanm12,R1,TR6,L1,V1,R24,R5,s120,The channel of node n's unboxed value (its primitive type's): :j a long or int, :d a double,\n  :z a boolean, :p another.R2,i1584,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.node9,register!m10,R36,R37,R5,s127,A literal or a quoted constant (NumberExpr ... TheVarExpr): its value, made when the node is,\n  and a number's long and double.R38,m4,R39,V8,R40,R41,R42,R43,R44,R45,R46,R47,R48,V3,R49,R50,R51,R52,V4,m6,R53,R35,R54,R55,R56,V2,R57,ML2,R58,R23,m4,R2,i1596,R3,i21,m6,R53,R59,R54,R55,R56,V2,R60,ML3,R61,R62,R35,m4,R2,i1597,R3,i24,m6,R53,R63,R54,R55,R56,V2,R64,ML4,R65,R59,ML2,R66,ML3,R67,R62,R35,m4,R2,i1598,R3,i40,m4,R2,i1598,R3,i28,l0,m4,R2,i1598,R3,i20,m6,R53,R68,R54,R55,R56,V2,R69,ML4,R65,R59,ML2,R70,ML3,R67,R62,R35,m4,R2,i1599,R3,i44,m4,R2,i1599,R3,i30,d0,m4,R2,i1599,R3,i22,R71,ML8,R72,R73,R49,R35,R50,ML4,R74,R59,R63,ML2,R66,ML3,R67,R62,R35,m4,R2,i1602,R3,i38,m4,R2,i1602,R3,i26,m4,R2,i1602,R3,i8,R51,ML4,R74,R59,R68,ML2,R70,ML3,R67,R62,R35,m4,R2,i1603,R3,i40,m4,R2,i1603,R3,i26,m4,R2,i1603,R3,i8,m4,R2,i1600,R3,i3,v15,arbace.c2j.emit10,emit-constm8,R6,L1,V3,R18,R24,R25,R2,i1591,R3,i1,R4,s18,arbace/c2j/emit.aem10,R36,R75,R5,s318,A use of a local (LocalBindingExpr): its value where it lives; on its last use on its path,\n  where the half keeps it alive, cleared (locals clearing: ObjExpr.emitLocal, emitClearLocals).\n  Where it lives is each half's own (the evaluator's slots, prims and closed-over values, the\n  emitted code's locals and fields).R38,m4,R39,V0,R76,V2,R77,R78,R52,V1,m6,R53,R79,R54,R80,R56,V0,R71,ML4,R74,ML2,R81,R79,m4,R2,i1612,R3,i14,ML4,R82,V2,R21,ML3,R83,R79,R49,m4,R2,i1613,R3,i13,ML3,R84,R79,nm4,R2,i1613,R3,i32,R21,m4,R2,i1613,R3,i5,ML3,R83,R79,R73,m4,R2,i1614,R3,i5,m4,R2,i1612,R3,i3,m8,R6,L1,V3,R18,R24,R25,R2,i1605,R3,i1,R4,s18,arbace/c2j/emit.aem10,R36,R65,R5,s122,Clojure's if (IfExpr): the test's truth (a boolean's own when the test is one) chooses the\n  branch, in the channel asked.R38,m2,R39,V1,R85,R52,V4,m6,R53,R86,R54,R87,R56,V1,R88,m6,R53,R89,R54,R87,R56,V1,R90,m6,R53,R91,R54,R87,R56,V1,R92,m6,R53,R93,R54,R55,R56,V2,R60,ML3,R94,ML2,R95,R88,m4,R2,i1623,R3,i34,R96,m4,R2,i1623,R3,i22,R71,ML4,R65,ML4,R74,R93,ML3,R97,R98,R86,m4,R2,i1624,R3,i20,ML3,R97,R49,R86,m4,R2,i1624,R3,i34,m4,R2,i1624,R3,i7,ML3,R97,R73,R89,m4,R2,i1624,R3,i49,ML3,R97,R73,R91,m4,R2,i1624,R3,i62,m4,R2,i1624,R3,i3,v15,arbace.c2j.emit7,emit-ifm8,R6,L1,V3,R18,R24,R25,R2,i1616,R3,i1,R4,s18,arbace/c2j/emit.aem10,R36,R99,R5,s445,A call of a resolved static method the half calls directly (StaticMethodExpr): its\n  arguments converted to the parameters' classes and bound in order, then the call (Numbers'\n  boxed operations with F3's fast paths), its value in the channel asked (boxed as its\n  return's). The evaluator's: Numbers', RT's, Util's and Math's listed methods\n  (test/c2j/gen_nodes.ae), a switch per arity; the emitted code's: every public one\n  (direct-static?).R38,m8,R39,V1,R100,R76,V3,R101,R19,R102,R103,s6,CodeOpR104,m2,R105,ML4,R65,ML2,R106,R101,m4,R2,i1634,R3,i24,l-1,ML2,R107,R101,m4,R2,i1634,R3,i41,m4,R2,i1634,R3,i20,R52,V3,m6,R53,R108,R54,R55,R56,V2,R14,R101,m6,R53,R22,R54,R109,R56,V4,R19,l3,R110,ML2,R111,R101,m4,R2,i1636,R3,i33,m6,R53,R102,R54,R55,R56,V2,R112,R102,R71,ML4,R113,R102,V2,R20,ML3,R114,R108,R22,m4,R2,i1638,R3,i23,ML4,R115,R73,R108,ML3,R116,R108,R20,m4,R2,i1639,R3,i18,m4,R2,i1639,R3,i5,m4,R2,i1638,R3,i3,v15,arbace.c2j.emit16,emit-static-callm8,R6,L1,V3,R18,R24,R25,R2,i1626,R3,i1,R4,s18,arbace/c2j/emit.aem10,R36,R117,R5,s328,A call of a fn value (InvokeExpr): the fn, then its arguments, in order, then IFn's invoke\n  (applyTo past 20 arguments); in tail position the evaluator's frame lets go of its object\n  first (InvokeExpr.emitArgsAndCall, ObjMethod.emitClearThis). The emitted code's refinements:\n  protocol calls and linked calls (invoke-linked).R38,m8,R39,V1,R118,R76,V4,R119,R19,R102,R120,R48,V1,R49,R121,R122,R52,V4,m6,R53,R123,R54,R87,R56,V1,R119,m6,R53,R22,R54,R109,R56,V2,R19,l20,m6,R53,R102,R54,R55,R56,V2,R112,R102,m6,R53,R124,R54,R125,R56,V2,R60,ML3,R126,R120,ML2,R127,ML2,R128,ML2,R129,R130,m4,R2,i1650,R3,i69,m4,R2,i1650,R3,i54,m4,R2,i1650,R3,i49,m4,R2,i1650,R3,i31,R71,ML5,R113,R102,V4,R131,ML3,R67,R132,ML3,R133,R102,ML3,R97,R49,R123,m4,R2,i1651,R3,i58,m4,R2,i1651,R3,i44,m4,R2,i1651,R3,i22,R20,ML3,R134,R49,R22,m4,R2,i1651,R3,i75,ML2,R135,ML3,R136,R124,ML2,R137,R7,m4,R2,i1652,R3,i28,m4,R2,i1652,R3,i16,m4,R2,i1652,R3,i5,ML4,R74,ML2,R138,R22,m4,R2,i1653,R3,i16,ML3,R139,R131,ML2,Mys20,arbace.lang.ArraySeq6,createm2,R140,V1,R141,ML2,R142,R20,m4,R2,i1654,R3,i84,m4,R2,i1654,R3,i19,m4,R2,i1654,R3,i7,ML3,R143,R131,ML2,R144,R20,m4,R2,i1655,R3,i18,m4,R2,i1655,R3,i7,m4,R2,i1653,R3,i5,m4,R2,i1651,R3,i3,v15,arbace.c2j.emit11,emit-invokem8,R6,L1,V3,R18,R24,R25,R2,i1641,R3,i1,R4,s18,arbace/c2j/emit.aem10,R36,R145,R5,s638,A call of a resolved instance method the evaluator calls directly (InstanceMethodExpr), one of\n  the JDK's the evaluated code calls most (String's, StringBuilder's, the collections':\n  test/c2j/gen_nodes.ae): the target cast to the method's class, its arguments converted to the\n  parameters' classes and bound in order, then the call (virtual), its value in the channel asked\n  (boxed as its return's), in the compiled call's order (InstanceMethodExpr.emit). The evaluator's\n  alone (the back end compiles every resolved call, emit-instance-method); the others go through\n  the method's invoker (CodeHostInstance). (doc/go/EVAL-SPEED.md)R38,m10,R39,V1,R146,R76,V4,R101,R147,R19,R102,R103,s8,CodeCallR148,TR104,m2,R105,ML4,R65,ML2,R106,R101,m4,R2,i1666,R3,i24,l-1,ML2,R107,R101,m4,R2,i1666,R3,i41,m4,R2,i1666,R3,i20,R52,V4,m6,R53,R108,R54,R55,R56,V2,R14,R101,m6,R53,R149,R54,R87,R56,V1,R147,m6,R53,R22,R54,R109,R56,V4,R19,l3,R110,ML2,R111,R101,m4,R2,i1669,R3,i33,m6,R53,R102,R54,R55,R56,V2,R112,R102,R71,ML4,R113,R102,V4,R21,ML3,R150,R108,ML3,R97,R49,R149,m4,R2,i1671,R3,i37,m4,R2,i1671,R3,i22,R20,ML3,R114,R108,R22,m4,R2,i1671,R3,i53,ML4,R115,R73,R108,ML4,R151,R108,R21,R20,m4,R2,i1672,R3,i18,m4,R2,i1672,R3,i5,m4,R2,i1671,R3,i3,v15,arbace.c2j.emit21,qualified-method-exprm12,R1,TR6,L1,V1,R24,R5,s365,A qualified method as a value (String/.length, String/new, Math/abs: QualifiedMethodExpr)\n  as the expression the compiler emits for it: its field overload when it prefers it, else its\n  thunk (QualifiedMethodExpr.buildThunk: a fn of an arity per overload, or of its param-tags',\n  calling the method), analyzed now in the unit's namespace (Clojure's suite, REAP3).R2,i1674,R3,i1,R4,s18,arbace/c2j/emit.aeR152,R153,R154,R155,R156,R157,R158,R159,m8,R1,TR2,i1703,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,box-primm12,R1,TR6,L1,V2,R7,R24,R5,s200,Form f of node n boxed when it is of a primitive type (emitBoxReturn: valueOf, long's\n  Numbers.num being Long.valueOf), so that emit's code is always a reference, as the bytecode's\n  emit leaves one.R2,i1709,R3,i1,R4,s18,arbace/c2j/emit.aem10,R6,L1,V2,R18,R23,R5,s59,Code for analyzed node e, its value boxed (an Expr's emit).R2,i1720,R3,i1,R4,s18,arbace/c2j/emit.aem10,R6,L1,V2,R18,R23,R5,s72,Code for analyzed node e, its value of its primitive type (emitUnboxed).R2,i1788,R3,i1,R4,s18,arbace/c2j/emit.aem12,R1,TR6,L1,V1,R7,R5,s160,Form f realized throughout (the emitters build lazy seqs; what they record, the constants\n  and the classes, must be recorded before it is read), metadata kept.R2,i1822,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,simple-namem10,R1,TR6,L1,V1,Myn6,binarym2,R13,R160,R2,i1831,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,throws?m12,R1,TR6,L1,V1,R23,R5,s86,Does node e end in a throw (a form that does not complete, which needs no conversion)?R2,i1834,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,nil-valued?m12,R1,TR6,L1,V1,R24,R5,s43,Is node n nil itself, or a do ending in it?R2,i1843,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,form-linem12,R1,TR6,L1,V1,R7,R5,s79,The line of emitted form f: its own, else (a do) that of its last form, or nil.R2,i1851,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,with-line-ofm12,R1,TR6,L1,V2,R161,R7,R5,s267,Form w, a wrapper of form f (a conversion of its value), on f's line: the statement made of\n  it is the one the JVM's line table puts at f's own mark (RPS42: an unboxed field or method\n  call returned as the method's ^long, whose NPE the frame gives the call's line).R2,i1857,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit8,ret-bodym12,R1,TR6,L1,V3,R18,R34,Myn3,retm2,R13,R162,R5,s148,A deftype's method body as returned in type ret (ObjMethod.emitBody): unboxed when it can be,\n  else boxed then cast or unboxed as ASM's unbox does.R2,i1866,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,method-bodym12,R1,TR6,L1,V5,R18,R163,R164,R165,V1,R166,R5,s302,The body of FnMethod or NewInstanceMethod m (its node), in the method's context: wrapped in\n  a loop over its parameters when a recur targets them. With entry, the body of a fn method's\n  unboxed entry (F6, psig): its primitive parameters taken as they are, its value of the\n  signature's return class.R2,i1906,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,param-symm10,R1,TR6,L1,V1,R30,R2,i1949,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit12,prim-classesR64,R69,R112,R60,R167,R168,R169,R170,m8,R1,TR2,i1955,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,tag-classm12,R1,TR6,L1,V1,R171,R5,s70,The class a field's tag names (Compiler.tagClass): Object without one.R2,i1959,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit9,box-classm10,R1,TR6,L1,V1,Myn1,cm2,R13,R162,R2,i1968,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit16,class-interfacesm12,R1,TR6,L1,V2,R18,R32,R5,s179,The interfaces of a deftype's or reify's class (its node ox), as the analysis made the\n  class: their names. A class of the program cannot implement an interface made at run time.R2,i1972,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,field-modsm12,R1,TR6,L1,V2,R32,R30,R5,s104,The modifiers of a deftype's field lb (ObjExpr.compile): volatile, mutable (package), or\n  public final.R2,i1983,R3,i1,R4,s18,arbace/c2j/emit.aem10,R6,L1,V2,R18,R32,R5,s202,Defines deftype ox's class (its node), a top-level class named as the deftype, once:\n  its fields, constructors, getBasis (and create for a record), and methods\n  (NewInstanceExpr.compile, emitStatics).R2,i1993,R3,i1,R4,s18,arbace/c2j/emit.aem10,R6,L1,V2,R18,R32,R5,s109,Defines the class of fn or reify ox (its node) once, in the classes being emitted; returns\n  its binary name.R2,i2072,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,unit-methodm12,R1,TR6,L1,V3,R18,R172,V7,R173,R102,R174,R175,R175,R176,R177,R5,s96,The static method unitK of a source's loader class: unit u's events made again, then its\n  code.R2,i2221,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit7,unit-nsm12,R1,TR6,L1,V1,V6,R173,R175,R175,R175,R175,R176,R5,s79,The namespace unit u was analyzed in: its fn's (kind 1) or its def's, else nil.R2,i2296,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit17,loader-part-unitsl100,m8,R2,i2307,R3,i1,R4,s18,arbace/c2j/emit.aeR5,s251,The most units a source's loader class holds itself; a source of more is split into parts of\n  as many (SA210): j2g analyzes classes in parallel, one class on one thread (arbace.core's 903\n  units were one task of 9 to 14 s, the last of the analysis).v15,arbace.c2j.emit15,unnamed-packagem10,R6,L1,V1,Myn2,nmm2,R13,R160,R5,s484,The option placing top-level class nm in Java's unnamed package when its name has no\n  package: the classes of a namespace of one segment (user: its holder user, the fns\n  user$eval1$fn__2, the loader of a source user.ae, user__init), named as the JVM names them,\n  where the Java forms would put a simple name in the package of the namespace they are read in\n  (arbace). The tree's files import them (arbace.c2j.main), so that a class of a package can name\n  them, as Java could not.R2,i2313,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,emit-sourcem10,R6,L1,V6,R178,R179,R180,R181,R182,R183,R5,s259,The Java forms of source path src (scriptbase.ae), compiled from its units: the loader\n  class SCRIPTBASE__init's form and the fn classes made, into the atom classes (fn-names: the\n  fns' class names by their FnExpr, an IdentityHashMap shared by the sources).R2,i2323,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit10,class-formm12,R1,TR6,L1,V4,R184,R185,R27,R181,R5,s289,The defclass form of class c (its record: a fn's, a reify's, a deftype's, an interface's, or\n  a holder of nested classes), its nested classes inside; at the top its full name and the\n  constants it shares with them (pools: top → its pool), else a static member class by its\n  simple name.R2,i2389,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit11,class-formsm10,R6,L1,V2,R178,R181,R5,s261,The top-level Java forms holding every class of classes (name → record), nested as their\n  binary names nest, with holder classes made for the missing levels (a namespace's fns nest\n  in a holder named as the namespace); pools: the top-level classes' constants.R2,i2425,R3,i1,R4,s18,arbace/c2j/emit.aev15,arbace.c2j.emit16,interface-recordm10,R6,L1,V3,R186,R187,R188,R5,s133,The record of an interface made by gen-interface (events iface and imethod): name, the\n  interfaces it extends, its abstract methods.R2,i2451,R3,i1,R4,s18,arbace/c2j/emit.ae")

var Lit_527 *jrt.String = jrt.Intern("arbace.c2j.emit$long_box")

var Lit_528 *jrt.String = jrt.Intern("arbace.c2j.emit$double_box")

var Lit_529 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op2")

var Lit_530 *jrt.String = jrt.Intern("arbace.c2j.emit$double_op2")

var Lit_531 *jrt.String = jrt.Intern("arbace.c2j.emit$long_op1")

var Lit_532 *jrt.String = jrt.Intern("arbace.c2j.emit$double_op1")

var Lit_533 *jrt.String = jrt.Intern("arbace.c2j.emit$intrinsic_probe")

var Lit_534 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_fast")

var Lit_535 *jrt.String = jrt.Intern("arbace.c2j.emit$numbers_intrinsic")

var Lit_536 *jrt.String = jrt.Intern("arbace.c2j.emit$static_call_form")

var Lit_537 *jrt.String = jrt.Intern("arbace.c2j.emit$instance_call_form")

var Lit_538 *jrt.String = jrt.Intern("arbace.c2j.emit$call_static")

var Lit_539 *jrt.String = jrt.Intern("arbace.c2j.emit$spec_intrinsic")

var Lit_540 *jrt.String = jrt.Intern("arbace.c2j.emit$direct_static_QMARK_")

var Lit_541 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_method")

var Lit_542 *jrt.String = jrt.Intern("arbace.c2j.emit$field_ok_QMARK_")

var Lit_543 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_instance_field")

var Lit_544 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_field")

var Lit_545 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_new")

var Lit_546 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_def")

var Lit_547 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_assign")

var Lit_548 *jrt.String = jrt.Intern("arbace.c2j.emit$coll_call")

var Lit_549 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_binding_init")

var Lit_550 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_let")

var Lit_551 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_recur")

var Lit_552 *jrt.String = jrt.Intern("arbace.c2j.emit$body_instance")

var Lit_553 *jrt.String = jrt.Intern("arbace.c2j.emit$fn_wrap")

var Lit_554 *jrt.String = jrt.Intern("arbace.c2j.emit$fn_instance")

var Lit_555 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_letfn")

var Lit_556 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_try")

var Lit_557 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_case")

var Lit_558 *jrt.String = jrt.Intern("arbace.c2j.emit$lift")

var Lit_559 *jrt.String = jrt.Intern("arbace.c2j.emit$prim_chan")

var Lit_560 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_const")

var Lit_561 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_local")

var Lit_562 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_if")

var Lit_563 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_static_call")

var Lit_564 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_invoke")

var Lit_565 *jrt.String = jrt.Intern("arbace.c2j.emit$qualified_method_expr")

var Lit_566 *jrt.String = jrt.Intern("arbace.c2j.emit$box_prim")

var Lit_567 *jrt.String = jrt.Intern("arbace.c2j.emit$emit")

var Lit_568 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_unboxed")

var Lit_569 *jrt.String = jrt.Intern("arbace.c2j.emit$deep")

var Lit_570 *jrt.String = jrt.Intern("arbace.c2j.emit$simple_name")

var Lit_571 *jrt.String = jrt.Intern("arbace.c2j.emit$throws_QMARK_")

var Lit_572 *jrt.String = jrt.Intern("arbace.c2j.emit$nil_valued_QMARK_")

var Lit_573 *jrt.String = jrt.Intern("arbace.c2j.emit$form_line")

var Lit_574 *jrt.String = jrt.Intern("arbace.c2j.emit$with_line_of")

var Lit_575 *jrt.String = jrt.Intern("arbace.c2j.emit$ret_body")

var Lit_576 *jrt.String = jrt.Intern("arbace.c2j.emit$method_body")

var Lit_577 *jrt.String = jrt.Intern("arbace.c2j.emit$param_sym")

var Lit_578 *jrt.String = jrt.Intern("arbace.c2j.emit$tag_class")

var Lit_579 *jrt.String = jrt.Intern("arbace.c2j.emit$box_class")

var Lit_580 *jrt.String = jrt.Intern("arbace.c2j.emit$class_interfaces")

var Lit_581 *jrt.String = jrt.Intern("arbace.c2j.emit$field_mods")

var Lit_582 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_deftype_class_BANG_")

var Lit_583 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_fn_class_BANG_")

var Lit_584 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_method")

var Lit_585 *jrt.String = jrt.Intern("arbace.c2j.emit$unit_ns")

var Lit_586 *jrt.String = jrt.Intern("arbace.c2j.emit$unnamed_package")

var Lit_587 *jrt.String = jrt.Intern("arbace.c2j.emit$emit_source")

var Lit_588 *jrt.String = jrt.Intern("arbace.c2j.emit$class_form")

var Lit_589 *jrt.String = jrt.Intern("arbace.c2j.emit$class_forms")

var Lit_590 *jrt.String = jrt.Intern("arbace.c2j.emit$interface_record")
