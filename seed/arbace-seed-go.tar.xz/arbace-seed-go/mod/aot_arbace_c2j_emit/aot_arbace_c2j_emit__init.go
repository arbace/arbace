//line aot_arbace_c2j_emit__init.ae:1
package aot_arbace_c2j_emit

import (
	"arbace/aot_arbace_c2j_node"
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2j_emit__init_part0_A_Unit0__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_c2j_emit__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit__init_part0_A_const_1) }
//line :1:1
func A_arbace_c2j_emit__init_part0_A_Unit1__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_c2j_emit__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_2)) }
//line :1:1
func A_arbace_c2j_emit__init_part0_A_Unit2__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_c2j_emit_eval31000004_loading__1927001464__auto____31000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c2j_emit_eval31000004_loading__1927001464__auto____31000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_455, false, nil); A_arbace_c2j_emit_eval31000004_loading__1927001464__auto____31000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_c2j_emit__init_part0_A_Unit3__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c2j_emit__init_part0_A_const_1)).Equals_O__Z(A_arbace_c2j_emit__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_c2j_emit_eval31000008_fn__31000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c2j_emit_eval31000008_fn__31000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_456, false, nil); A_arbace_c2j_emit_eval31000008_fn__31000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :1:1
func A_arbace_c2j_emit__init_part0_A_Init__O() any { A_arbace_c2j_emit__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_c2j_emit__init_part0_A_Load__O() any { A_arbace_c2j_emit__init_part0_A_Init(); A_arbace_c2j_emit__init_part0_A_Unit0__O(); A_arbace_c2j_emit__init_part0_A_Unit1__O(); A_arbace_c2j_emit__init_part0_A_Unit2__O(); A_arbace_c2j_emit__init_part0_A_Unit3__O(); A_arbace_c2j_emit__init_part0_A_Unit4__O(); A_arbace_c2j_emit__init_part0_A_Unit5__O(); A_arbace_c2j_emit__init_part0_A_Unit6__O(); A_arbace_c2j_emit__init_part0_A_Unit7__O(); A_arbace_c2j_emit__init_part0_A_Unit8__O(); A_arbace_c2j_emit__init_part0_A_Unit9__O(); A_arbace_c2j_emit__init_part0_A_Unit10__O(); A_arbace_c2j_emit__init_part0_A_Unit11__O(); A_arbace_c2j_emit__init_part0_A_Unit12__O(); A_arbace_c2j_emit__init_part0_A_Unit13__O(); A_arbace_c2j_emit__init_part0_A_Unit14__O(); A_arbace_c2j_emit__init_part0_A_Unit15__O(); A_arbace_c2j_emit__init_part0_A_Unit16__O(); A_arbace_c2j_emit__init_part0_A_Unit17__O(); A_arbace_c2j_emit__init_part0_A_Unit18__O(); A_arbace_c2j_emit__init_part0_A_Unit19__O(); A_arbace_c2j_emit__init_part0_A_Unit20__O(); A_arbace_c2j_emit__init_part0_A_Unit21__O(); A_arbace_c2j_emit__init_part0_A_Unit22__O(); A_arbace_c2j_emit__init_part0_A_Unit23__O(); A_arbace_c2j_emit__init_part0_A_Unit24__O(); A_arbace_c2j_emit__init_part0_A_Unit25__O(); A_arbace_c2j_emit__init_part0_A_Unit26__O(); A_arbace_c2j_emit__init_part0_A_Unit27__O(); A_arbace_c2j_emit__init_part0_A_Unit28__O(); A_arbace_c2j_emit__init_part0_A_Unit29__O(); A_arbace_c2j_emit__init_part0_A_Unit30__O(); A_arbace_c2j_emit__init_part0_A_Unit31__O(); A_arbace_c2j_emit__init_part0_A_Unit32__O(); A_arbace_c2j_emit__init_part0_A_Unit33__O(); A_arbace_c2j_emit__init_part0_A_Unit34__O(); A_arbace_c2j_emit__init_part0_A_Unit35__O(); A_arbace_c2j_emit__init_part0_A_Unit36__O(); A_arbace_c2j_emit__init_part0_A_Unit37__O(); A_arbace_c2j_emit__init_part0_A_Unit38__O(); A_arbace_c2j_emit__init_part0_A_Unit39__O(); A_arbace_c2j_emit__init_part0_A_Unit40__O(); A_arbace_c2j_emit__init_part0_A_Unit41__O(); A_arbace_c2j_emit__init_part0_A_Unit42__O(); A_arbace_c2j_emit__init_part0_A_Unit43__O(); A_arbace_c2j_emit__init_part0_A_Unit44__O(); A_arbace_c2j_emit__init_part0_A_Unit45__O(); A_arbace_c2j_emit__init_part0_A_Unit46__O(); A_arbace_c2j_emit__init_part0_A_Unit47__O(); A_arbace_c2j_emit__init_part0_A_Unit48__O(); A_arbace_c2j_emit__init_part0_A_Unit49__O(); A_arbace_c2j_emit__init_part0_A_Unit50__O(); A_arbace_c2j_emit__init_part0_A_Unit51__O(); A_arbace_c2j_emit__init_part0_A_Unit52__O(); A_arbace_c2j_emit__init_part0_A_Unit53__O(); A_arbace_c2j_emit__init_part0_A_Unit54__O(); A_arbace_c2j_emit__init_part0_A_Unit55__O(); A_arbace_c2j_emit__init_part0_A_Unit56__O(); A_arbace_c2j_emit__init_part0_A_Unit57__O(); A_arbace_c2j_emit__init_part0_A_Unit58__O(); A_arbace_c2j_emit__init_part0_A_Unit59__O(); A_arbace_c2j_emit__init_part0_A_Unit60__O(); A_arbace_c2j_emit__init_part0_A_Unit61__O(); A_arbace_c2j_emit__init_part0_A_Unit62__O(); A_arbace_c2j_emit__init_part0_A_Unit63__O(); A_arbace_c2j_emit__init_part0_A_Unit64__O(); A_arbace_c2j_emit__init_part0_A_Unit65__O(); A_arbace_c2j_emit__init_part0_A_Unit66__O(); A_arbace_c2j_emit__init_part0_A_Unit67__O(); A_arbace_c2j_emit__init_part0_A_Unit68__O(); A_arbace_c2j_emit__init_part0_A_Unit69__O(); A_arbace_c2j_emit__init_part0_A_Unit70__O(); A_arbace_c2j_emit__init_part0_A_Unit71__O(); A_arbace_c2j_emit__init_part0_A_Unit72__O(); A_arbace_c2j_emit__init_part0_A_Unit73__O(); A_arbace_c2j_emit__init_part0_A_Unit74__O(); A_arbace_c2j_emit__init_part0_A_Unit75__O(); A_arbace_c2j_emit__init_part0_A_Unit76__O(); A_arbace_c2j_emit__init_part0_A_Unit77__O(); A_arbace_c2j_emit__init_part0_A_Unit78__O(); A_arbace_c2j_emit__init_part0_A_Unit79__O(); A_arbace_c2j_emit__init_part0_A_Unit80__O(); A_arbace_c2j_emit__init_part0_A_Unit81__O(); A_arbace_c2j_emit__init_part0_A_Unit82__O(); A_arbace_c2j_emit__init_part0_A_Unit83__O(); A_arbace_c2j_emit__init_part0_A_Unit84__O(); A_arbace_c2j_emit__init_part0_A_Unit85__O(); A_arbace_c2j_emit__init_part0_A_Unit86__O(); A_arbace_c2j_emit__init_part0_A_Unit87__O(); A_arbace_c2j_emit__init_part0_A_Unit88__O(); A_arbace_c2j_emit__init_part0_A_Unit89__O(); A_arbace_c2j_emit__init_part0_A_Unit90__O(); A_arbace_c2j_emit__init_part0_A_Unit91__O(); A_arbace_c2j_emit__init_part0_A_Unit92__O(); A_arbace_c2j_emit__init_part0_A_Unit93__O(); A_arbace_c2j_emit__init_part0_A_Unit94__O(); A_arbace_c2j_emit__init_part0_A_Unit95__O(); A_arbace_c2j_emit__init_part0_A_Unit96__O(); A_arbace_c2j_emit__init_part0_A_Unit97__O(); A_arbace_c2j_emit__init_part0_A_Unit98__O(); A_arbace_c2j_emit__init_part0_A_Unit99__O(); return nil }



func A_arbace_c2j_emit__init_A_Load__O() any { jrt.StartCheck(); A_arbace_c2j_emit__init_part0_A_Init__O(); A_arbace_c2j_emit__init_part1_A_Init__O(); A_arbace_c2j_emit__init_part0_A_Load__O(); A_arbace_c2j_emit__init_part1_A_Load__O(); return nil }






























func A_arbace_c2j_emit__init_part0_A_Unit4__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_4; tmp1.BindRoot_O__V(jrt.IdentityHashMap_New()); var tmp2 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_4; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_5)); return A_arbace_c2j_emit__init_part0_A_const_4 }



func A_arbace_c2j_emit__init_part0_A_Unit5__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_c2j_emit_node_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c2j_emit_node_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_457, false, nil); A_arbace_c2j_emit_node_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_7)); return A_arbace_c2j_emit__init_part0_A_const_6 }








func A_arbace_c2j_emit__init_part0_A_Unit6__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_8; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__8 any = A_arbace_c2j_emit_fail_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_c2j_emit_fail_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_458, true, nil); A_arbace_c2j_emit_fail_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__8, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_9)); return A_arbace_c2j_emit__init_part0_A_const_8 }


func A_arbace_c2j_emit__init_part0_A_Unit7__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(52, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_c2j_emit_dup_str_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c2j_emit_dup_str_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_459, false, nil); A_arbace_c2j_emit_dup_str_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_11)); return A_arbace_c2j_emit__init_part0_A_const_10 }










func A_arbace_c2j_emit__init_part0_A_Unit8__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(63, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_c2j_emit_destub_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c2j_emit_destub_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_460, false, nil); A_arbace_c2j_emit_destub_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_13)); return A_arbace_c2j_emit__init_part0_A_const_12 }




func A_arbace_c2j_emit__init_part0_A_Unit9__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(68, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_c2j_emit_type_sym_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c2j_emit_type_sym_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_461, false, nil); A_arbace_c2j_emit_type_sym_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_15)); return A_arbace_c2j_emit__init_part0_A_const_14 }










func A_arbace_c2j_emit__init_part0_A_Unit10__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(79, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_16; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, jrt.Void_TYPE.Ref(), A_arbace_c2j_emit__init_part0_A_const_17, jrt.Double_TYPE.Ref(), A_arbace_c2j_emit__init_part0_A_const_18, jrt.Character_TYPE.Ref(), A_arbace_c2j_emit__init_part0_A_const_19, jrt.Byte_TYPE.Ref(), A_arbace_c2j_emit__init_part0_A_const_20, jrt.Boolean_TYPE.Ref(), A_arbace_c2j_emit__init_part0_A_const_21, jrt.Float_TYPE.Ref(), A_arbace_c2j_emit__init_part0_A_const_22, jrt.Long_TYPE.Ref(), A_arbace_c2j_emit__init_part0_A_const_23, jrt.Short_TYPE.Ref(), A_arbace_c2j_emit__init_part0_A_const_24, jrt.Integer_TYPE.Ref(), A_arbace_c2j_emit__init_part0_A_const_25))); var tmp2 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_16; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_26)); return A_arbace_c2j_emit__init_part0_A_const_16 }



func A_arbace_c2j_emit__init_part0_A_Unit11__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_c2j_emit_tagged_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c2j_emit_tagged_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_462, false, nil); A_arbace_c2j_emit_tagged_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_28)); return A_arbace_c2j_emit__init_part0_A_const_27 }








func A_arbace_c2j_emit__init_part0_A_Unit12__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_29; var tmp2 any; var root_17 any = A_arbace_c2j_emit__init_part0_A_const_30.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_19 lang.IFn; if

	linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_17, arg_20) }; /*line :92:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_29; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_31)); return A_arbace_c2j_emit__init_part0_A_const_29 }



func A_arbace_c2j_emit__init_part0_A_Unit13__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(96, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_c2j_emit_registered_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c2j_emit_registered_QMARK__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_463, false, nil); A_arbace_c2j_emit_registered_QMARK__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_33)); return A_arbace_c2j_emit__init_part0_A_const_32 }
















func A_arbace_c2j_emit__init_part0_A_Unit14__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(113, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_34; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_35)); return A_arbace_c2j_emit__init_part0_A_const_34 }

func A_arbace_c2j_emit__init_part0_A_Unit15__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(115, 1); if lang.RT_LoadClassForName_String__Class_NoInit(Lit_385) == nil { lang.IFn_Cast(A_arbace_c2j_emit__init_part0_A_const_38.GetRawRoot__O()).Invoke_O_O_O__O(Lit_385, nil, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class))) }; var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_c2j_emit_runtime_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_c2j_emit_runtime_class_QMARK__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_464, false, nil); A_arbace_c2j_emit_runtime_class_QMARK__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_37)); return A_arbace_c2j_emit__init_part0_A_const_36 }















func A_arbace_c2j_emit__init_part0_A_Unit16__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(131, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_c2j_emit_public_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_c2j_emit_public_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_465, false, nil); A_arbace_c2j_emit_public_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_40)); return A_arbace_c2j_emit__init_part0_A_const_39 }





func A_arbace_c2j_emit__init_part0_A_Unit17__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(137, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_c2j_emit_top_name_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_c2j_emit_top_name_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_466, false, nil); A_arbace_c2j_emit_top_name_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_42)); return A_arbace_c2j_emit__init_part0_A_const_41 }

func A_arbace_c2j_emit__init_part0_A_Unit18__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(139, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_c2j_emit_pool_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_c2j_emit_pool_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_467, false, nil); A_arbace_c2j_emit_pool_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_44)); return A_arbace_c2j_emit__init_part0_A_const_43 }









func A_arbace_c2j_emit__init_part0_A_Unit19__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_c2j_emit_const_field_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_c2j_emit_const_field_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_468, false, nil); A_arbace_c2j_emit_const_field_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_46)); return A_arbace_c2j_emit__init_part0_A_const_45 }




















func A_arbace_c2j_emit__init_part0_A_Unit20__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(170, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_47; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_48)); return A_arbace_c2j_emit__init_part0_A_const_47 }
//line :170:1
func A_arbace_c2j_emit__init_part0_A_Unit21__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(170, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_49; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_50)); return A_arbace_c2j_emit__init_part0_A_const_49 }

func A_arbace_c2j_emit__init_part0_A_Unit22__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(172, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_c2j_emit_emit_list_array_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c2j_emit_emit_list_array_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_469, false, nil); A_arbace_c2j_emit_emit_list_array_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_52)); return A_arbace_c2j_emit__init_part0_A_const_51 }


func A_arbace_c2j_emit__init_part0_A_Unit23__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(175, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_c2j_emit_char_form_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_c2j_emit_char_form_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_470, false, nil); A_arbace_c2j_emit_char_form_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_54)); return A_arbace_c2j_emit__init_part0_A_const_53 }





func A_arbace_c2j_emit__init_part0_A_Unit24__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(181, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_c2j_emit_double_form_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_c2j_emit_double_form_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_471, false, nil); A_arbace_c2j_emit_double_form_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_56)); return A_arbace_c2j_emit__init_part0_A_const_55 }




func A_arbace_c2j_emit__init_part0_A_Unit25__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(186, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_c2j_emit_type_literal_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_c2j_emit_type_literal_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_472, false, nil); A_arbace_c2j_emit_type_literal_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_58)); return A_arbace_c2j_emit__init_part0_A_const_57 }












func A_arbace_c2j_emit__init_part0_A_Unit26__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(199, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_c2j_emit_emit_value_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_c2j_emit_emit_value_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_473, false, nil); A_arbace_c2j_emit_emit_value_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_59)); return A_arbace_c2j_emit__init_part0_A_const_47 }



















































































func A_arbace_c2j_emit__init_part0_A_Unit27__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(283, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_c2j_emit_pool_kind_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_c2j_emit_pool_kind_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_474, false, nil); A_arbace_c2j_emit_pool_kind_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_61)); return A_arbace_c2j_emit__init_part0_A_const_60 }
























func A_arbace_c2j_emit__init_part0_A_Unit28__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(308, 1); A_arbace_c2j_emit__init_part0_A_const_62.BindRoot_O__V(A_arbace_c2j_emit__init_part0_A_const_63); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_62; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_64)); return A_arbace_c2j_emit__init_part0_A_const_62 }



func A_arbace_c2j_emit__init_part0_A_Unit29__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(312, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_c2j_emit_pool_shared_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_c2j_emit_pool_shared_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_475, false, nil); A_arbace_c2j_emit_pool_shared_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_66)); return A_arbace_c2j_emit__init_part0_A_const_65 }




func A_arbace_c2j_emit__init_part0_A_Unit30__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(317, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_c2j_emit_pool_parts_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_c2j_emit_pool_parts_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_476, false, nil); A_arbace_c2j_emit_pool_parts_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_68)); return A_arbace_c2j_emit__init_part0_A_const_67 }










func A_arbace_c2j_emit__init_part0_A_Unit31__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(328, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_c2j_emit_pool_str_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_c2j_emit_pool_str_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_477, false, nil); A_arbace_c2j_emit_pool_str_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_70)); return A_arbace_c2j_emit__init_part0_A_const_69 }


func A_arbace_c2j_emit__init_part0_A_Unit32__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(331, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_c2j_emit_pool_encode_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_c2j_emit_pool_encode_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_478, false, nil); A_arbace_c2j_emit_pool_encode_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_72)); return A_arbace_c2j_emit__init_part0_A_const_71 }















































func A_arbace_c2j_emit__init_part0_A_Unit33__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(379, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_c2j_emit_pool_fields_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_c2j_emit_pool_fields_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_479, false, nil); A_arbace_c2j_emit_pool_fields_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_74)); return A_arbace_c2j_emit__init_part0_A_const_73 }
































func A_arbace_c2j_emit__init_part0_A_Unit34__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(412, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_c2j_emit_const_type_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_c2j_emit_const_type_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_480, false, nil); A_arbace_c2j_emit_const_type_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_76)); return A_arbace_c2j_emit__init_part0_A_const_75 }





func A_arbace_c2j_emit__init_part0_A_Unit35__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(418, 1); A_arbace_c2j_emit__init_part0_A_const_77.BindRoot_O__V(lang.PersistentHashSet_EMPTY.Ref()); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_77; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_78)); return A_arbace_c2j_emit__init_part0_A_const_77.SetDynamic_Z__Var(true).Ref() }







func A_arbace_c2j_emit__init_part0_A_Unit36__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(426, 1); A_arbace_c2j_emit__init_part0_A_const_79.BindRoot_O__V(lang.PersistentHashSet_EMPTY.Ref()); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_79; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_80)); return A_arbace_c2j_emit__init_part0_A_const_79.SetDynamic_Z__Var(true).Ref() }




func A_arbace_c2j_emit__init_part0_A_Unit37__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(431, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_81; var tmp2 any; var root_57 any = A_arbace_c2j_emit__init_part0_A_const_30.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_58 == nil { tmp2 = ifn_59.Invoke_O__O(arg_60) } else { tmp2 = linked_58.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_57, arg_60) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_81; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_82)); return A_arbace_c2j_emit__init_part0_A_const_81 }

func A_arbace_c2j_emit__init_part0_A_Unit38__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(433, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_c2j_emit_dynamic_class_QMARK__STAR__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_c2j_emit_dynamic_class_QMARK__STAR__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_481, false, nil); A_arbace_c2j_emit_dynamic_class_QMARK__STAR__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_84)); return A_arbace_c2j_emit__init_part0_A_const_83 }












func A_arbace_c2j_emit__init_part0_A_Unit39__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(446, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_c2j_emit_dynamic_class_cached_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_c2j_emit_dynamic_class_cached_QMARK__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_482, false, nil); A_arbace_c2j_emit_dynamic_class_cached_QMARK__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_85)); return A_arbace_c2j_emit__init_part0_A_const_34 }



func A_arbace_c2j_emit__init_part0_A_Unit40__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(450, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_c2j_emit_holds_fn_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_c2j_emit_holds_fn_QMARK__A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_483, false, nil); A_arbace_c2j_emit_holds_fn_QMARK__A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_87)); return A_arbace_c2j_emit__init_part0_A_const_86 }









func A_arbace_c2j_emit__init_part0_A_Unit41__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(460, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_88; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_c2j_emit_constant_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_c2j_emit_constant_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_484, false, nil); A_arbace_c2j_emit_constant_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_89)); return A_arbace_c2j_emit__init_part0_A_const_88 }
















func A_arbace_c2j_emit__init_part0_A_Unit42__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(477, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_90; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_c2j_emit_gsym_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_c2j_emit_gsym_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_485, false, nil); A_arbace_c2j_emit_gsym_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_91)); return A_arbace_c2j_emit__init_part0_A_const_90 }







func A_arbace_c2j_emit__init_part0_A_Unit43__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(485, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_92; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_c2j_emit_local_sym_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_c2j_emit_local_sym_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_486, false, nil); A_arbace_c2j_emit_local_sym_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_93)); return A_arbace_c2j_emit__init_part0_A_const_92 }





func A_arbace_c2j_emit__init_part0_A_Unit44__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(491, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_94; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_c2j_emit_identity_set_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_c2j_emit_identity_set_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_487, false, nil); A_arbace_c2j_emit_identity_set_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_95)); return A_arbace_c2j_emit__init_part0_A_const_94 }








func A_arbace_c2j_emit__init_part0_A_Unit45__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(500, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_96; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_c2j_emit_closed_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_c2j_emit_closed_QMARK__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_488, false, nil); A_arbace_c2j_emit_closed_QMARK__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_97)); return A_arbace_c2j_emit__init_part0_A_const_96 }



func A_arbace_c2j_emit__init_part0_A_Unit46__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(504, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_c2j_emit_field_sym_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_c2j_emit_field_sym_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_489, false, nil); A_arbace_c2j_emit_field_sym_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_99)); return A_arbace_c2j_emit__init_part0_A_const_98 }

func A_arbace_c2j_emit__init_part0_A_Unit47__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(506, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_c2j_emit_field_read_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_c2j_emit_field_read_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_490, false, nil); A_arbace_c2j_emit_field_read_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_101)); return A_arbace_c2j_emit__init_part0_A_const_100 }






func A_arbace_c2j_emit__init_part0_A_Unit48__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_102; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_103)); return A_arbace_c2j_emit__init_part0_A_const_102 }
//line :513:1
func A_arbace_c2j_emit__init_part0_A_Unit49__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_104; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_105)); return A_arbace_c2j_emit__init_part0_A_const_104 }
//line :513:1
func A_arbace_c2j_emit__init_part0_A_Unit50__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_106; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_107)); return A_arbace_c2j_emit__init_part0_A_const_106 }
//line :513:1
func A_arbace_c2j_emit__init_part0_A_Unit51__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_108; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_109)); return A_arbace_c2j_emit__init_part0_A_const_108 }
//line :513:1
func A_arbace_c2j_emit__init_part0_A_Unit52__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_110; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_111)); return A_arbace_c2j_emit__init_part0_A_const_110 }
//line :513:1
func A_arbace_c2j_emit__init_part0_A_Unit53__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_112; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_113)); return A_arbace_c2j_emit__init_part0_A_const_112 }
//line :513:1
func A_arbace_c2j_emit__init_part0_A_Unit54__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_114; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_115)); return A_arbace_c2j_emit__init_part0_A_const_114 }
//line :513:1
func A_arbace_c2j_emit__init_part0_A_Unit55__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_116; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_117)); return A_arbace_c2j_emit__init_part0_A_const_116 }
//line :513:1
func A_arbace_c2j_emit__init_part0_A_Unit56__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_118; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_119)); return A_arbace_c2j_emit__init_part0_A_const_118 }


func A_arbace_c2j_emit__init_part0_A_Unit57__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(516, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_120; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_c2j_emit_prim_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_c2j_emit_prim_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_491, false, nil); A_arbace_c2j_emit_prim_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_121)); return A_arbace_c2j_emit__init_part0_A_const_120 }

func A_arbace_c2j_emit__init_part0_A_Unit58__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(518, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_122; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_c2j_emit_can_prim_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_c2j_emit_can_prim_QMARK__A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_492, false, nil); A_arbace_c2j_emit_can_prim_QMARK__A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_123)); return A_arbace_c2j_emit__init_part0_A_const_122 }

func A_arbace_c2j_emit__init_part0_A_Unit59__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_124; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_125)); return A_arbace_c2j_emit__init_part0_A_const_124 }

func A_arbace_c2j_emit__init_part0_A_Unit60__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(522, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_126; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_c2j_emit_box_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_c2j_emit_box_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_493, false, nil); A_arbace_c2j_emit_box_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_127)); return A_arbace_c2j_emit__init_part0_A_const_126 }








func A_arbace_c2j_emit__init_part0_A_Unit61__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(531, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_128; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_c2j_emit_unbox_arg_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_c2j_emit_unbox_arg_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_494, false, nil); A_arbace_c2j_emit_unbox_arg_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_129)); return A_arbace_c2j_emit__init_part0_A_const_128 }


















func A_arbace_c2j_emit__init_part0_A_Unit62__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(550, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_130; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_c2j_emit_fi_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_c2j_emit_fi_QMARK__A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_495, false, nil); A_arbace_c2j_emit_fi_QMARK__A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_131)); return A_arbace_c2j_emit__init_part0_A_const_130 }






func A_arbace_c2j_emit__init_part0_A_Unit63__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(557, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_132; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_c2j_emit_typed_args_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_c2j_emit_typed_args_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_496, false, nil); A_arbace_c2j_emit_typed_args_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_133)); return A_arbace_c2j_emit__init_part0_A_const_132 }



























func A_arbace_c2j_emit__init_part0_A_Unit64__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(585, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_134; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_c2j_emit_param_tags_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_c2j_emit_param_tags_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_497, false, nil); A_arbace_c2j_emit_param_tags_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_135)); return A_arbace_c2j_emit__init_part0_A_const_134 }

func A_arbace_c2j_emit__init_part0_A_Unit65__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(587, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_136; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_c2j_emit_obj_array_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_c2j_emit_obj_array_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_498, false, nil); A_arbace_c2j_emit_obj_array_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_137)); return A_arbace_c2j_emit__init_part0_A_const_136 }


func A_arbace_c2j_emit__init_part0_A_Unit66__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(590, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_138; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_c2j_emit_var_value_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_c2j_emit_var_value_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_499, false, nil); A_arbace_c2j_emit_var_value_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_139)); return A_arbace_c2j_emit__init_part0_A_const_138 }



func A_arbace_c2j_emit__init_part0_A_Unit67__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(594, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_140; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_c2j_emit_line_meta_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_c2j_emit_line_meta_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_500, false, nil); A_arbace_c2j_emit_line_meta_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_141)); return A_arbace_c2j_emit__init_part0_A_const_140 }




func A_arbace_c2j_emit__init_part0_A_Unit68__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(599, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_142; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_c2j_emit_spec_local_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_c2j_emit_spec_local_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_501, false, nil); A_arbace_c2j_emit_spec_local_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_143)); return A_arbace_c2j_emit__init_part0_A_const_142 }





func A_arbace_c2j_emit__init_part0_A_Unit69__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(605, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_144; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_c2j_emit_long_box_STAR__A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_c2j_emit_long_box_STAR__A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_502, false, nil); A_arbace_c2j_emit_long_box_STAR__A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_145)); return A_arbace_c2j_emit__init_part0_A_const_144 }

func A_arbace_c2j_emit__init_part0_A_Unit70__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(607, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_146; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_c2j_emit_local_place_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_c2j_emit_local_place_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_503, false, nil); A_arbace_c2j_emit_local_place_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_147)); return A_arbace_c2j_emit__init_part0_A_const_146 }



















func A_arbace_c2j_emit__init_part0_A_Unit71__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(627, 1); A_arbace_c2j_emit__init_part0_A_const_148.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_148; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_149)); return A_arbace_c2j_emit__init_part0_A_const_148.SetDynamic_Z__Var(true).Ref() }





func A_arbace_c2j_emit__init_part0_A_Unit72__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(633, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_150; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_c2j_emit_link_key_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_c2j_emit_link_key_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_504, false, nil); A_arbace_c2j_emit_link_key_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_151)); return A_arbace_c2j_emit__init_part0_A_const_150 }













func A_arbace_c2j_emit__init_part0_A_Unit73__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(647, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_152; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_153)); return A_arbace_c2j_emit__init_part0_A_const_152 }








func A_arbace_c2j_emit__init_part0_A_Unit74__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(656, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_154; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_c2j_emit_psig_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_c2j_emit_psig_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_505, false, nil); A_arbace_c2j_emit_psig_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_155)); return A_arbace_c2j_emit__init_part0_A_const_154 }









func A_arbace_c2j_emit__init_part0_A_Unit75__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(666, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_156; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_157)); return A_arbace_c2j_emit__init_part0_A_const_156 }
//line :666:1
func A_arbace_c2j_emit__init_part0_A_Unit76__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(666, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_158; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_159)); return A_arbace_c2j_emit__init_part0_A_const_158 }

func A_arbace_c2j_emit__init_part0_A_Unit77__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(668, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_160; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_c2j_emit_walk_nodes_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_c2j_emit_walk_nodes_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_506, false, nil); A_arbace_c2j_emit_walk_nodes_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_160; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_161)); return A_arbace_c2j_emit__init_part0_A_const_160 }















func A_arbace_c2j_emit__init_part0_A_Unit78__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(684, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_162; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_c2j_emit_spec_mask_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_c2j_emit_spec_mask_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_507, false, nil); A_arbace_c2j_emit_spec_mask_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_163)); return A_arbace_c2j_emit__init_part0_A_const_162 }











































func A_arbace_c2j_emit__init_part0_A_Unit79__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(728, 1); A_arbace_c2j_emit__init_part0_A_const_164.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_164; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_165)); return A_arbace_c2j_emit__init_part0_A_const_164.SetDynamic_Z__Var(true).Ref() }







func A_arbace_c2j_emit__init_part0_A_Unit80__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(736, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_166; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_c2j_emit_var_fns_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_c2j_emit_var_fns_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_508, false, nil); A_arbace_c2j_emit_var_fns_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_166; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_167)); return A_arbace_c2j_emit__init_part0_A_const_166 }














func A_arbace_c2j_emit__init_part0_A_Unit81__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(751, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_168; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_c2j_emit_site_fn_methods_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_c2j_emit_site_fn_methods_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_509, false, nil); A_arbace_c2j_emit_site_fn_methods_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_168; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_169)); return A_arbace_c2j_emit__init_part0_A_const_168 }













func A_arbace_c2j_emit__init_part0_A_Unit82__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(765, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_170; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_c2j_emit_site_spec_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_c2j_emit_site_spec_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_510, false, nil); A_arbace_c2j_emit_site_spec_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_170; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_171)); return A_arbace_c2j_emit__init_part0_A_const_170 }





func A_arbace_c2j_emit__init_part0_A_Unit83__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(771, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_172; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_c2j_emit_site_psig_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_c2j_emit_site_psig_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_511, false, nil); A_arbace_c2j_emit_site_psig_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_173)); return A_arbace_c2j_emit__init_part0_A_const_172 }





func A_arbace_c2j_emit__init_part0_A_Unit84__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(777, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_174; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_c2j_emit_prim_arg_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_c2j_emit_prim_arg_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_512, false, nil); A_arbace_c2j_emit_prim_arg_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_174; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_175)); return A_arbace_c2j_emit__init_part0_A_const_174 }
































func A_arbace_c2j_emit__init_part0_A_Unit85__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(810, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_176; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_c2j_emit_spec_arg_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_c2j_emit_spec_arg_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_513, false, nil); A_arbace_c2j_emit_spec_arg_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_176; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_177)); return A_arbace_c2j_emit__init_part0_A_const_176 }


























func A_arbace_c2j_emit__init_part0_A_Unit86__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(837, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_178; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_c2j_emit_emit_link_site_A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_c2j_emit_emit_link_site_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_514, false, nil); A_arbace_c2j_emit_emit_link_site_A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_179)); return A_arbace_c2j_emit__init_part0_A_const_178 }




































func A_arbace_c2j_emit__init_part0_A_Unit87__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(874, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_180; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_c2j_emit_link_form_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_c2j_emit_link_form_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_515, false, nil); A_arbace_c2j_emit_link_form_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_181)); return A_arbace_c2j_emit__init_part0_A_const_180 }


























































func A_arbace_c2j_emit__init_part0_A_Unit88__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(933, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_182; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_c2j_emit_link_target_A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_c2j_emit_link_target_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_516, false, nil); A_arbace_c2j_emit_link_target_A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_183)); return A_arbace_c2j_emit__init_part0_A_const_182 }







func A_arbace_c2j_emit__init_part0_A_Unit89__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(941, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_184; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_c2j_emit_site_key_A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_c2j_emit_site_key_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_517, false, nil); A_arbace_c2j_emit_site_key_A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_185)); return A_arbace_c2j_emit__init_part0_A_const_184 }







func A_arbace_c2j_emit__init_part0_A_Unit90__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(949, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_c2j_emit_prim_call_A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_c2j_emit_prim_call_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_518, false, nil); A_arbace_c2j_emit_prim_call_A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_186)); return A_arbace_c2j_emit__init_part0_A_const_114 }










func A_arbace_c2j_emit__init_part0_A_Unit91__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(960, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_187; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_c2j_emit_invoke_linked_A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_c2j_emit_invoke_linked_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_519, false, nil); A_arbace_c2j_emit_invoke_linked_A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_187; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_188)); return A_arbace_c2j_emit__init_part0_A_const_187 }




























func A_arbace_c2j_emit__init_part0_A_Unit92__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(989, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_189; var tmp2 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_c2j_emit_descriptor_A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_c2j_emit_descriptor_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_520, false, nil); A_arbace_c2j_emit_descriptor_A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_189; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_190)); return A_arbace_c2j_emit__init_part0_A_const_189 }







func A_arbace_c2j_emit__init_part0_A_Unit93__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(997, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_191; var tmp2 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_c2j_emit_fn__31000292_A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_c2j_emit_fn__31000292_A_fn_class; if
							fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_521, false, nil); A_arbace_c2j_emit_fn__31000292_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp3, nil); /*line :997:1*/tmp1.BindRoot_O__V(lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp2))); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_191; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_192)); return A_arbace_c2j_emit__init_part0_A_const_191 }


func A_arbace_c2j_emit__init_part0_A_Unit94__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1000, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_c2j_emit_jrt_lacks_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_c2j_emit_jrt_lacks_QMARK__A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_522, false, nil); A_arbace_c2j_emit_jrt_lacks_QMARK__A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_193)); return A_arbace_c2j_emit__init_part0_A_const_112 }


















func A_arbace_c2j_emit__init_part0_A_Unit95__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1019, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_194; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_c2j_emit_method_call_A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_c2j_emit_method_call_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_523, false, nil); A_arbace_c2j_emit_method_call_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_194; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_195)); return A_arbace_c2j_emit__init_part0_A_const_194 }












func A_arbace_c2j_emit__init_part0_A_Unit96__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1032, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_196; var tmp2 *lang.Compiler_AOTFn; var fnbody__148 any = A_arbace_c2j_emit_compiled_interface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_c2j_emit_compiled_interface_QMARK__A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_524, false, nil); A_arbace_c2j_emit_compiled_interface_QMARK__A_fn_class = fncls__147d; tmp3 = fncls__147d } else { tmp3 = fncls__147 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__148, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_196; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_197)); return A_arbace_c2j_emit__init_part0_A_const_196 }




func A_arbace_c2j_emit__init_part0_A_Unit97__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1037, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_198; var tmp2 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_c2j_emit_emit_instance_method_A_New(); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_c2j_emit_emit_instance_method_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_525, false, nil); A_arbace_c2j_emit_emit_instance_method_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_198; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_199)); return A_arbace_c2j_emit__init_part0_A_const_198 }










































func A_arbace_c2j_emit__init_part0_A_Unit98__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1080, 1); A_arbace_c2j_emit__init_part0_A_const_200.BindRoot_O__V(A_arbace_c2j_emit__init_part0_A_const_201); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_200; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_202)); return A_arbace_c2j_emit__init_part0_A_const_200 }
func A_arbace_c2j_emit__init_part0_A_Unit99__O() any { A_arbace_c2j_emit__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1081, 1); A_arbace_c2j_emit__init_part0_A_const_203.BindRoot_O__V(A_arbace_c2j_emit__init_part0_A_const_204); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part0_A_const_203; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part0_A_const_205)); return A_arbace_c2j_emit__init_part0_A_const_203 }

func A_arbace_c2j_emit__init_part1_A_Unit100__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1083, 1); A_arbace_c2j_emit__init_part1_A_const_0.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_0; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_1)); return A_arbace_c2j_emit__init_part1_A_const_0.SetDynamic_Z__Var(true).Ref() }
//line :1083:1
func A_arbace_c2j_emit__init_part1_A_Init__O() any { A_arbace_c2j_emit__init_part1_A_Init(); return nil }
//line :1083:1
func A_arbace_c2j_emit__init_part1_A_Load__O() any { A_arbace_c2j_emit__init_part1_A_Init(); A_arbace_c2j_emit__init_part1_A_Unit100__O(); A_arbace_c2j_emit__init_part1_A_Unit101__O(); A_arbace_c2j_emit__init_part1_A_Unit102__O(); A_arbace_c2j_emit__init_part1_A_Unit103__O(); A_arbace_c2j_emit__init_part1_A_Unit104__O(); A_arbace_c2j_emit__init_part1_A_Unit105__O(); A_arbace_c2j_emit__init_part1_A_Unit106__O(); A_arbace_c2j_emit__init_part1_A_Unit107__O(); A_arbace_c2j_emit__init_part1_A_Unit108__O(); A_arbace_c2j_emit__init_part1_A_Unit109__O(); A_arbace_c2j_emit__init_part1_A_Unit110__O(); A_arbace_c2j_emit__init_part1_A_Unit111__O(); A_arbace_c2j_emit__init_part1_A_Unit112__O(); A_arbace_c2j_emit__init_part1_A_Unit113__O(); A_arbace_c2j_emit__init_part1_A_Unit114__O(); A_arbace_c2j_emit__init_part1_A_Unit115__O(); A_arbace_c2j_emit__init_part1_A_Unit116__O(); A_arbace_c2j_emit__init_part1_A_Unit117__O(); A_arbace_c2j_emit__init_part1_A_Unit118__O(); A_arbace_c2j_emit__init_part1_A_Unit119__O(); A_arbace_c2j_emit__init_part1_A_Unit120__O(); A_arbace_c2j_emit__init_part1_A_Unit121__O(); A_arbace_c2j_emit__init_part1_A_Unit122__O(); A_arbace_c2j_emit__init_part1_A_Unit123__O(); A_arbace_c2j_emit__init_part1_A_Unit124__O(); A_arbace_c2j_emit__init_part1_A_Unit125__O(); A_arbace_c2j_emit__init_part1_A_Unit126__O(); A_arbace_c2j_emit__init_part1_A_Unit127__O(); A_arbace_c2j_emit__init_part1_A_Unit128__O(); A_arbace_c2j_emit__init_part1_A_Unit129__O(); A_arbace_c2j_emit__init_part1_A_Unit130__O(); A_arbace_c2j_emit__init_part1_A_Unit131__O(); A_arbace_c2j_emit__init_part1_A_Unit132__O(); A_arbace_c2j_emit__init_part1_A_Unit133__O(); A_arbace_c2j_emit__init_part1_A_Unit134__O(); A_arbace_c2j_emit__init_part1_A_Unit135__O(); A_arbace_c2j_emit__init_part1_A_Unit136__O(); A_arbace_c2j_emit__init_part1_A_Unit137__O(); A_arbace_c2j_emit__init_part1_A_Unit138__O(); A_arbace_c2j_emit__init_part1_A_Unit139__O(); A_arbace_c2j_emit__init_part1_A_Unit140__O(); A_arbace_c2j_emit__init_part1_A_Unit141__O(); A_arbace_c2j_emit__init_part1_A_Unit142__O(); A_arbace_c2j_emit__init_part1_A_Unit143__O(); A_arbace_c2j_emit__init_part1_A_Unit144__O(); A_arbace_c2j_emit__init_part1_A_Unit145__O(); A_arbace_c2j_emit__init_part1_A_Unit146__O(); A_arbace_c2j_emit__init_part1_A_Unit147__O(); A_arbace_c2j_emit__init_part1_A_Unit148__O(); A_arbace_c2j_emit__init_part1_A_Unit149__O(); A_arbace_c2j_emit__init_part1_A_Unit150__O(); A_arbace_c2j_emit__init_part1_A_Unit151__O(); A_arbace_c2j_emit__init_part1_A_Unit152__O(); A_arbace_c2j_emit__init_part1_A_Unit153__O(); A_arbace_c2j_emit__init_part1_A_Unit154__O(); A_arbace_c2j_emit__init_part1_A_Unit155__O(); A_arbace_c2j_emit__init_part1_A_Unit156__O(); A_arbace_c2j_emit__init_part1_A_Unit157__O(); A_arbace_c2j_emit__init_part1_A_Unit158__O(); A_arbace_c2j_emit__init_part1_A_Unit159__O(); A_arbace_c2j_emit__init_part1_A_Unit160__O(); A_arbace_c2j_emit__init_part1_A_Unit161__O(); A_arbace_c2j_emit__init_part1_A_Unit162__O(); A_arbace_c2j_emit__init_part1_A_Unit163__O(); A_arbace_c2j_emit__init_part1_A_Unit164__O(); A_arbace_c2j_emit__init_part1_A_Unit165__O(); A_arbace_c2j_emit__init_part1_A_Unit166__O(); A_arbace_c2j_emit__init_part1_A_Unit167__O(); A_arbace_c2j_emit__init_part1_A_Unit168__O(); A_arbace_c2j_emit__init_part1_A_Unit169__O(); A_arbace_c2j_emit__init_part1_A_Unit170__O(); A_arbace_c2j_emit__init_part1_A_Unit171__O(); A_arbace_c2j_emit__init_part1_A_Unit172__O(); A_arbace_c2j_emit__init_part1_A_Unit173__O(); A_arbace_c2j_emit__init_part1_A_Unit174__O(); A_arbace_c2j_emit__init_part1_A_Unit175__O(); return nil }




func A_arbace_c2j_emit__init_part1_A_Unit101__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1088, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_c2j_emit_long_box_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c2j_emit_long_box_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_527, false, nil); A_arbace_c2j_emit_long_box_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_3)); return A_arbace_c2j_emit__init_part1_A_const_2 }
func A_arbace_c2j_emit__init_part1_A_Unit102__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1089, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_c2j_emit_double_box_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c2j_emit_double_box_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_528, false, nil); A_arbace_c2j_emit_double_box_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_5)); return A_arbace_c2j_emit__init_part1_A_const_4 }

func A_arbace_c2j_emit__init_part1_A_Unit103__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1091, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_c2j_emit_long_op2_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c2j_emit_long_op2_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_529, false, nil); A_arbace_c2j_emit_long_op2_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_7)); return A_arbace_c2j_emit__init_part1_A_const_6 }


































func A_arbace_c2j_emit__init_part1_A_Unit104__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1126, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_c2j_emit_double_op2_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_c2j_emit_double_op2_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_530, false, nil); A_arbace_c2j_emit_double_op2_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_9)); return A_arbace_c2j_emit__init_part1_A_const_8 }














func A_arbace_c2j_emit__init_part1_A_Unit105__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1141, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_c2j_emit_long_op1_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c2j_emit_long_op1_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_531, false, nil); A_arbace_c2j_emit_long_op1_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_11)); return A_arbace_c2j_emit__init_part1_A_const_10 }















func A_arbace_c2j_emit__init_part1_A_Unit106__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1157, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_c2j_emit_double_op1_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c2j_emit_double_op1_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_532, false, nil); A_arbace_c2j_emit_double_op1_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_13)); return A_arbace_c2j_emit__init_part1_A_const_12 }











func A_arbace_c2j_emit__init_part1_A_Unit107__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1169, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_c2j_emit_intrinsic_probe_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c2j_emit_intrinsic_probe_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_533, false, nil); A_arbace_c2j_emit_intrinsic_probe_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_15)); return A_arbace_c2j_emit__init_part1_A_const_14 }













func A_arbace_c2j_emit__init_part1_A_Unit108__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1183, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_c2j_emit_numbers_fast_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c2j_emit_numbers_fast_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_534, false, nil); A_arbace_c2j_emit_numbers_fast_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_17)); return A_arbace_c2j_emit__init_part1_A_const_16 }







































func A_arbace_c2j_emit__init_part1_A_Unit109__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1223, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_c2j_emit_numbers_intrinsic_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_c2j_emit_numbers_intrinsic_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_535, false, nil); A_arbace_c2j_emit_numbers_intrinsic_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_19)); return A_arbace_c2j_emit__init_part1_A_const_18 }












func A_arbace_c2j_emit__init_part1_A_Unit110__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1236, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_c2j_emit_static_call_form_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_c2j_emit_static_call_form_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_536, false, nil); A_arbace_c2j_emit_static_call_form_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_21)); return A_arbace_c2j_emit__init_part1_A_const_20 }





func A_arbace_c2j_emit__init_part1_A_Unit111__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1242, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_c2j_emit_instance_call_form_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c2j_emit_instance_call_form_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_537, false, nil); A_arbace_c2j_emit_instance_call_form_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_23)); return A_arbace_c2j_emit__init_part1_A_const_22 }






func A_arbace_c2j_emit__init_part1_A_Unit112__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1249, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_c2j_emit_call_static_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_c2j_emit_call_static_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_538, false, nil); A_arbace_c2j_emit_call_static_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_25)); return A_arbace_c2j_emit__init_part1_A_const_24 }





func A_arbace_c2j_emit__init_part1_A_Unit113__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1255, 1); A_arbace_c2j_emit__init_part1_A_const_26.BindRoot_O__V(A_arbace_c2j_emit__init_part1_A_const_27); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_28)); return A_arbace_c2j_emit__init_part1_A_const_26 }




func A_arbace_c2j_emit__init_part1_A_Unit114__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1260, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_c2j_emit_spec_intrinsic_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_c2j_emit_spec_intrinsic_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_539, false, nil); A_arbace_c2j_emit_spec_intrinsic_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_30)); return A_arbace_c2j_emit__init_part1_A_const_29 }
































func A_arbace_c2j_emit__init_part1_A_Unit115__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1293, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_c2j_emit_direct_static_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_c2j_emit_direct_static_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_540, false, nil); A_arbace_c2j_emit_direct_static_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_32)); return A_arbace_c2j_emit__init_part1_A_const_31 }







func A_arbace_c2j_emit__init_part1_A_Unit116__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1301, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_c2j_emit_emit_static_method_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_c2j_emit_emit_static_method_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_541, false, nil); A_arbace_c2j_emit_emit_static_method_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_34)); return A_arbace_c2j_emit__init_part1_A_const_33 }









func A_arbace_c2j_emit__init_part1_A_Unit117__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1311, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_c2j_emit_field_ok_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_c2j_emit_field_ok_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_542, false, nil); A_arbace_c2j_emit_field_ok_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_36)); return A_arbace_c2j_emit__init_part1_A_const_35 }


func A_arbace_c2j_emit__init_part1_A_Unit118__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1314, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_c2j_emit_emit_instance_field_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c2j_emit_emit_instance_field_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_543, false, nil); A_arbace_c2j_emit_emit_instance_field_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_38)); return A_arbace_c2j_emit__init_part1_A_const_37 }








func A_arbace_c2j_emit__init_part1_A_Unit119__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1323, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_c2j_emit_emit_static_field_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_c2j_emit_emit_static_field_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_544, false, nil); A_arbace_c2j_emit_emit_static_field_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_40)); return A_arbace_c2j_emit__init_part1_A_const_39 }







func A_arbace_c2j_emit__init_part1_A_Unit120__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1331, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_c2j_emit_emit_new_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_c2j_emit_emit_new_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_545, false, nil); A_arbace_c2j_emit_emit_new_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_42)); return A_arbace_c2j_emit__init_part1_A_const_41 }








func A_arbace_c2j_emit__init_part1_A_Unit121__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1340, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_c2j_emit_emit_def_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_c2j_emit_emit_def_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_546, false, nil); A_arbace_c2j_emit_emit_def_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_44)); return A_arbace_c2j_emit__init_part1_A_const_43 }

















func A_arbace_c2j_emit__init_part1_A_Unit122__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1358, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_c2j_emit_emit_assign_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_c2j_emit_emit_assign_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_547, false, nil); A_arbace_c2j_emit_emit_assign_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_46)); return A_arbace_c2j_emit__init_part1_A_const_45 }
































func A_arbace_c2j_emit__init_part1_A_Unit123__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1391, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_c2j_emit_coll_call_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_c2j_emit_coll_call_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_548, false, nil); A_arbace_c2j_emit_coll_call_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_48)); return A_arbace_c2j_emit__init_part1_A_const_47 }


func A_arbace_c2j_emit__init_part1_A_Unit124__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1394, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_c2j_emit_emit_binding_init_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_c2j_emit_emit_binding_init_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_549, false, nil); A_arbace_c2j_emit_emit_binding_init_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_50)); return A_arbace_c2j_emit__init_part1_A_const_49 }














func A_arbace_c2j_emit__init_part1_A_Unit125__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1409, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_c2j_emit_emit_let_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_c2j_emit_emit_let_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_550, false, nil); A_arbace_c2j_emit_emit_let_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_52)); return A_arbace_c2j_emit__init_part1_A_const_51 }






func A_arbace_c2j_emit__init_part1_A_Unit126__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1416, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_c2j_emit_emit_recur_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_c2j_emit_emit_recur_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_551, false, nil); A_arbace_c2j_emit_emit_recur_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_54)); return A_arbace_c2j_emit__init_part1_A_const_53 }




















func A_arbace_c2j_emit__init_part1_A_Unit127__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1437, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_c2j_emit_body_instance_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_c2j_emit_body_instance_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_552, false, nil); A_arbace_c2j_emit_body_instance_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_56)); return A_arbace_c2j_emit__init_part1_A_const_55 }












func A_arbace_c2j_emit__init_part1_A_Unit128__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1450, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_c2j_emit_fn_wrap_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_c2j_emit_fn_wrap_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_553, false, nil); A_arbace_c2j_emit_fn_wrap_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_58)); return A_arbace_c2j_emit__init_part1_A_const_57 }


























func A_arbace_c2j_emit__init_part1_A_Unit129__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1477, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_c2j_emit_fn_instance_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_c2j_emit_fn_instance_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_554, false, nil); A_arbace_c2j_emit_fn_instance_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_60)); return A_arbace_c2j_emit__init_part1_A_const_59 }





func A_arbace_c2j_emit__init_part1_A_Unit130__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1483, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_61; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_c2j_emit_emit_letfn_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_c2j_emit_emit_letfn_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_555, false, nil); A_arbace_c2j_emit_emit_letfn_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_61; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_62)); return A_arbace_c2j_emit__init_part1_A_const_61 }
















func A_arbace_c2j_emit__init_part1_A_Unit131__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1500, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_63; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_c2j_emit_emit_try_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_c2j_emit_emit_try_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_556, false, nil); A_arbace_c2j_emit_emit_try_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_64)); return A_arbace_c2j_emit__init_part1_A_const_63 }








func A_arbace_c2j_emit__init_part1_A_Unit132__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1509, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_65; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_c2j_emit_emit_case_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_c2j_emit_emit_case_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_557, false, nil); A_arbace_c2j_emit_emit_case_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_66)); return A_arbace_c2j_emit__init_part1_A_const_65 }





















































func A_arbace_c2j_emit__init_part1_A_Unit133__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1563, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_c2j_emit_lift_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_c2j_emit_lift_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_558, false, nil); A_arbace_c2j_emit_lift_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_68)); return A_arbace_c2j_emit__init_part1_A_const_67 }




















func A_arbace_c2j_emit__init_part1_A_Unit134__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1584, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_c2j_emit_prim_chan_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_c2j_emit_prim_chan_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_559, false, nil); A_arbace_c2j_emit_prim_chan_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_70)); return A_arbace_c2j_emit__init_part1_A_const_69 }






func A_arbace_c2j_emit__init_part1_A_Unit135__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1591, 1); var root_67 any = A_arbace_c2j_emit__init_part1_A_const_71.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_c2j_node.A_arbace_c2j_node_register_BANG__A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = A_arbace_c2j_emit__init_part1_A_const_72; if linked_68 == nil { return ifn_69.Invoke_O__O(arg_70) } else { return linked_68.(*aot_arbace_c2j_node.A_arbace_c2j_node_register_BANG__A).Invoke_O_O__O(root_67, arg_70) } }
//line :1591:1
func A_arbace_c2j_emit__init_part1_A_Unit136__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1591, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_c2j_emit_emit_const_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_c2j_emit_emit_const_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_560, false, nil); A_arbace_c2j_emit_emit_const_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_74)); return A_arbace_c2j_emit__init_part1_A_const_73 }













func A_arbace_c2j_emit__init_part1_A_Unit137__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1605, 1); var root_73 any = A_arbace_c2j_emit__init_part1_A_const_71.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_c2j_node.A_arbace_c2j_node_register_BANG__A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = A_arbace_c2j_emit__init_part1_A_const_75; if linked_74 == nil { return ifn_75.Invoke_O__O(arg_76) } else { return linked_74.(*aot_arbace_c2j_node.A_arbace_c2j_node_register_BANG__A).Invoke_O_O__O(root_73, arg_76) } }
//line :1605:1
func A_arbace_c2j_emit__init_part1_A_Unit138__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1605, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_c2j_emit_emit_local_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_c2j_emit_emit_local_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_561, false, nil); A_arbace_c2j_emit_emit_local_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_77)); return A_arbace_c2j_emit__init_part1_A_const_76 }










func A_arbace_c2j_emit__init_part1_A_Unit139__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1616, 1); var root_79 any = A_arbace_c2j_emit__init_part1_A_const_71.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_c2j_node.A_arbace_c2j_node_register_BANG__A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = A_arbace_c2j_emit__init_part1_A_const_78; if linked_80 == nil { return ifn_81.Invoke_O__O(arg_82) } else { return linked_80.(*aot_arbace_c2j_node.A_arbace_c2j_node_register_BANG__A).Invoke_O_O__O(root_79, arg_82) } }
//line :1616:1
func A_arbace_c2j_emit__init_part1_A_Unit140__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1616, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_c2j_emit_emit_if_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_c2j_emit_emit_if_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_562, false, nil); A_arbace_c2j_emit_emit_if_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_80)); return A_arbace_c2j_emit__init_part1_A_const_79 }









func A_arbace_c2j_emit__init_part1_A_Unit141__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1626, 1); var root_85 any = A_arbace_c2j_emit__init_part1_A_const_71.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_c2j_node.A_arbace_c2j_node_register_BANG__A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = A_arbace_c2j_emit__init_part1_A_const_81; if linked_86 == nil { return ifn_87.Invoke_O__O(arg_88) } else { return linked_86.(*aot_arbace_c2j_node.A_arbace_c2j_node_register_BANG__A).Invoke_O_O__O(root_85, arg_88) } }
//line :1626:1
func A_arbace_c2j_emit__init_part1_A_Unit142__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1626, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_c2j_emit_emit_static_call_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_c2j_emit_emit_static_call_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_563, false, nil); A_arbace_c2j_emit_emit_static_call_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_83)); return A_arbace_c2j_emit__init_part1_A_const_82 }














func A_arbace_c2j_emit__init_part1_A_Unit143__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1641, 1); var root_91 any = A_arbace_c2j_emit__init_part1_A_const_71.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_c2j_node.A_arbace_c2j_node_register_BANG__A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = A_arbace_c2j_emit__init_part1_A_const_84; if linked_92 == nil { return ifn_93.Invoke_O__O(arg_94) } else { return linked_92.(*aot_arbace_c2j_node.A_arbace_c2j_node_register_BANG__A).Invoke_O_O__O(root_91, arg_94) } }
//line :1641:1
func A_arbace_c2j_emit__init_part1_A_Unit144__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1641, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_c2j_emit_emit_invoke_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_c2j_emit_emit_invoke_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_564, false, nil); A_arbace_c2j_emit_emit_invoke_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_86)); return A_arbace_c2j_emit__init_part1_A_const_85 }















func A_arbace_c2j_emit__init_part1_A_Unit145__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1657, 1); var root_97 any = A_arbace_c2j_emit__init_part1_A_const_71.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_c2j_node.A_arbace_c2j_node_register_BANG__A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = A_arbace_c2j_emit__init_part1_A_const_87; if linked_98 == nil { return ifn_99.Invoke_O__O(arg_100) } else { return linked_98.(*aot_arbace_c2j_node.A_arbace_c2j_node_register_BANG__A).Invoke_O_O__O(root_97, arg_100) } }
//line :1657:1
func A_arbace_c2j_emit__init_part1_A_Unit146__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1657, 1); return nil }
















func A_arbace_c2j_emit__init_part1_A_Unit147__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1674, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_88; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_c2j_emit_qualified_method_expr_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_c2j_emit_qualified_method_expr_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_565, false, nil); A_arbace_c2j_emit_qualified_method_expr_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_89)); return A_arbace_c2j_emit__init_part1_A_const_88 }




























func A_arbace_c2j_emit__init_part1_A_Unit148__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1703, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_90; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, jrt.Long_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_91, jrt.Double_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_92, jrt.Integer_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_93, jrt.Boolean_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_94, jrt.Character_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_95, jrt.Float_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_96, jrt.Short_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_97, jrt.Byte_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_98))); var tmp2 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_90; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_99)); return A_arbace_c2j_emit__init_part1_A_const_90 }





func A_arbace_c2j_emit__init_part1_A_Unit149__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1709, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_c2j_emit_box_prim_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_c2j_emit_box_prim_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_566, false, nil); A_arbace_c2j_emit_box_prim_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_101)); return A_arbace_c2j_emit__init_part1_A_const_100 }










func A_arbace_c2j_emit__init_part1_A_Unit150__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1720, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_102; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_c2j_emit_emit_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_c2j_emit_emit_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_567, false, nil); A_arbace_c2j_emit_emit_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_103)); return A_arbace_c2j_emit__init_part1_A_const_102 }



































































func A_arbace_c2j_emit__init_part1_A_Unit151__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1788, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_104; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_c2j_emit_emit_unboxed_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_c2j_emit_emit_unboxed_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_568, false, nil); A_arbace_c2j_emit_emit_unboxed_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_105)); return A_arbace_c2j_emit__init_part1_A_const_104 }

































func A_arbace_c2j_emit__init_part1_A_Unit152__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1822, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_106; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_c2j_emit_deep_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_c2j_emit_deep_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_569, false, nil); A_arbace_c2j_emit_deep_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_107)); return A_arbace_c2j_emit__init_part1_A_const_106 }








func A_arbace_c2j_emit__init_part1_A_Unit153__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1831, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_108; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_c2j_emit_simple_name_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_c2j_emit_simple_name_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_570, false, nil); A_arbace_c2j_emit_simple_name_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_109)); return A_arbace_c2j_emit__init_part1_A_const_108 }


func A_arbace_c2j_emit__init_part1_A_Unit154__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1834, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_c2j_emit_throws_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_c2j_emit_throws_QMARK__A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_571, false, nil); A_arbace_c2j_emit_throws_QMARK__A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_111)); return A_arbace_c2j_emit__init_part1_A_const_110 }








func A_arbace_c2j_emit__init_part1_A_Unit155__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1843, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_112; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_c2j_emit_nil_valued_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_c2j_emit_nil_valued_QMARK__A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_572, false, nil); A_arbace_c2j_emit_nil_valued_QMARK__A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_113)); return A_arbace_c2j_emit__init_part1_A_const_112 }







func A_arbace_c2j_emit__init_part1_A_Unit156__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1851, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_114; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_c2j_emit_form_line_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_c2j_emit_form_line_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_573, false, nil); A_arbace_c2j_emit_form_line_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_115)); return A_arbace_c2j_emit__init_part1_A_const_114 }





func A_arbace_c2j_emit__init_part1_A_Unit157__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1857, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_116; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_c2j_emit_with_line_of_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_c2j_emit_with_line_of_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_574, false, nil); A_arbace_c2j_emit_with_line_of_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_117)); return A_arbace_c2j_emit__init_part1_A_const_116 }








func A_arbace_c2j_emit__init_part1_A_Unit158__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1866, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_118; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_c2j_emit_ret_body_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_c2j_emit_ret_body_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_575, false, nil); A_arbace_c2j_emit_ret_body_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_119)); return A_arbace_c2j_emit__init_part1_A_const_118 }







































func A_arbace_c2j_emit__init_part1_A_Unit159__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1906, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_120; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__124 any = A_arbace_c2j_emit_method_body_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_c2j_emit_method_body_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_576, true, nil); A_arbace_c2j_emit_method_body_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__124, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_121)); return A_arbace_c2j_emit__init_part1_A_const_120 }










































func A_arbace_c2j_emit__init_part1_A_Unit160__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1949, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_122; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_c2j_emit_param_sym_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_c2j_emit_param_sym_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_577, false, nil); A_arbace_c2j_emit_param_sym_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_123)); return A_arbace_c2j_emit__init_part1_A_const_122 }





func A_arbace_c2j_emit__init_part1_A_Unit161__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1955, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_124; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit__init_part1_A_const_125, jrt.Long_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_126, jrt.Double_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_127, jrt.Integer_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_128, jrt.Boolean_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_129, jrt.Character_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_130, jrt.Float_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_131, jrt.Short_TYPE.Ref(), A_arbace_c2j_emit__init_part1_A_const_132, jrt.Byte_TYPE.Ref()))); var tmp2 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_124; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_133)); return A_arbace_c2j_emit__init_part1_A_const_124 }



func A_arbace_c2j_emit__init_part1_A_Unit162__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1959, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_134; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_c2j_emit_tag_class_A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_c2j_emit_tag_class_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_578, false, nil); A_arbace_c2j_emit_tag_class_A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_134; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_135)); return A_arbace_c2j_emit__init_part1_A_const_134 }








func A_arbace_c2j_emit__init_part1_A_Unit163__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1968, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_136; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_c2j_emit_box_class_A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_c2j_emit_box_class_A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_579, false, nil); A_arbace_c2j_emit_box_class_A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_136; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_137)); return A_arbace_c2j_emit__init_part1_A_const_136 }



func A_arbace_c2j_emit__init_part1_A_Unit164__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1972, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_138; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_c2j_emit_class_interfaces_A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_c2j_emit_class_interfaces_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_580, false, nil); A_arbace_c2j_emit_class_interfaces_A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_139)); return A_arbace_c2j_emit__init_part1_A_const_138 }










func A_arbace_c2j_emit__init_part1_A_Unit165__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1983, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_140; var tmp2 *lang.Compiler_AOTFn; var fnbody__134 any = A_arbace_c2j_emit_field_mods_A_New(); var tmp3 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_c2j_emit_field_mods_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_581, false, nil); A_arbace_c2j_emit_field_mods_A_fn_class = fncls__133d; tmp3 = fncls__133d } else { tmp3 = fncls__133 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__134, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_141)); return A_arbace_c2j_emit__init_part1_A_const_140 }









func A_arbace_c2j_emit__init_part1_A_Unit166__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1993, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_142; var tmp2 *lang.Compiler_AOTFn; var fnbody__136 any = A_arbace_c2j_emit_emit_deftype_class_BANG__A_New(); var tmp3 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_582, false, nil); A_arbace_c2j_emit_emit_deftype_class_BANG__A_fn_class = fncls__135d; tmp3 = fncls__135d } else { tmp3 = fncls__135 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__136, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_143)); return A_arbace_c2j_emit__init_part1_A_const_142 }














































































func A_arbace_c2j_emit__init_part1_A_Unit167__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2072, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_144; var tmp2 *lang.Compiler_AOTFn; var fnbody__138 any = A_arbace_c2j_emit_emit_fn_class_BANG__A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_583, false, nil); A_arbace_c2j_emit_emit_fn_class_BANG__A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__138, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_145)); return A_arbace_c2j_emit__init_part1_A_const_144 }




















































































































































func A_arbace_c2j_emit__init_part1_A_Unit168__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2221, 1); if lang.RT_LoadClassForName_String__Class_NoInit(Lit_385) == nil { lang.IFn_Cast(A_arbace_c2j_emit__init_part1_A_const_148.GetRawRoot__O()).Invoke_O_O_O__O(Lit_385, nil, lang.RT_Seq_O__ISeq_NoInit(jrt.RefArrayOf(jrt.Object_class))) }; var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_146; var tmp2 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_c2j_emit_unit_method_A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_c2j_emit_unit_method_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_584, false, nil); A_arbace_c2j_emit_unit_method_A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_147)); return A_arbace_c2j_emit__init_part1_A_const_146 }










































































func A_arbace_c2j_emit__init_part1_A_Unit169__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2296, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_149; var tmp2 *lang.Compiler_AOTFn; var fnbody__142 any = A_arbace_c2j_emit_unit_ns_A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_c2j_emit_unit_ns_A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_585, false, nil); A_arbace_c2j_emit_unit_ns_A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_150)); return A_arbace_c2j_emit__init_part1_A_const_149 }










func A_arbace_c2j_emit__init_part1_A_Unit170__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2307, 1); A_arbace_c2j_emit__init_part1_A_const_151.BindRoot_O__V(A_arbace_c2j_emit__init_part1_A_const_152); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_151; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_153)); return A_arbace_c2j_emit__init_part1_A_const_151 }





func A_arbace_c2j_emit__init_part1_A_Unit171__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2313, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_154; var tmp2 *lang.Compiler_AOTFn; var fnbody__144 any = A_arbace_c2j_emit_unnamed_package_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_c2j_emit_unnamed_package_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_586, false, nil); A_arbace_c2j_emit_unnamed_package_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__144, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_154; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_155)); return A_arbace_c2j_emit__init_part1_A_const_154 }









func A_arbace_c2j_emit__init_part1_A_Unit172__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2323, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_156; var tmp2 *lang.Compiler_AOTFn; var fnbody__146 any = A_arbace_c2j_emit_emit_source_A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_c2j_emit_emit_source_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_587, false, nil); A_arbace_c2j_emit_emit_source_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__146, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_157)); return A_arbace_c2j_emit__init_part1_A_const_156 }

































































func A_arbace_c2j_emit__init_part1_A_Unit173__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2389, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_158; var tmp2 *lang.Compiler_AOTFn; var fnbody__148 any = A_arbace_c2j_emit_class_form_A_New(); var tmp3 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_c2j_emit_class_form_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_588, false, nil); A_arbace_c2j_emit_class_form_A_fn_class = fncls__147d; tmp3 = fncls__147d } else { tmp3 = fncls__147 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__148, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_159)); return A_arbace_c2j_emit__init_part1_A_const_158 }



































func A_arbace_c2j_emit__init_part1_A_Unit174__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2425, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_160; var tmp2 *lang.Compiler_AOTFn; var fnbody__150 any = A_arbace_c2j_emit_class_forms_A_New(); var tmp3 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_c2j_emit_class_forms_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_589, false, nil); A_arbace_c2j_emit_class_forms_A_fn_class = fncls__149d; tmp3 = fncls__149d } else { tmp3 = fncls__149 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__150, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_160; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_161)); return A_arbace_c2j_emit__init_part1_A_const_160 }

























func A_arbace_c2j_emit__init_part1_A_Unit175__O() any { A_arbace_c2j_emit__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2451, 1); var tmp1 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_162; var tmp2 *lang.Compiler_AOTFn; var fnbody__152 any = A_arbace_c2j_emit_interface_record_A_New(); var tmp3 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_c2j_emit_interface_record_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_590, false, nil); A_arbace_c2j_emit_interface_record_A_fn_class = fncls__151d; tmp3 = fncls__151d } else { tmp3 = fncls__151 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__152, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_emit__init_part1_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_emit__init_part1_A_const_163)); return A_arbace_c2j_emit__init_part1_A_const_162 }



type A_arbace_c2j_emit__init_A struct{ jrt.Object }

func A_arbace_c2j_emit__init_A_New() *A_arbace_c2j_emit__init_A { t := &A_arbace_c2j_emit__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_emit__init_A) Ctor() {}

func (t *A_arbace_c2j_emit__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_emit__init_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_emit__init_A_class }

func (t *A_arbace_c2j_emit__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_emit__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_emit__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_emit__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_emit__init_A); return ok }

func A_arbace_c2j_emit__init_A_Cast(x any) *A_arbace_c2j_emit__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_emit__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_emit__init_A_class)) }; return v }



type A_arbace_c2j_emit__init_part0_A struct{ jrt.Object }

var A_arbace_c2j_emit__init_part0_A_const_pool *jrt.RefArray

var A_arbace_c2j_emit__init_part0_A_const_0 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_1 any

var A_arbace_c2j_emit__init_part0_A_const_2 any

var A_arbace_c2j_emit__init_part0_A_const_3 any

var A_arbace_c2j_emit__init_part0_A_const_4 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_5 any

var A_arbace_c2j_emit__init_part0_A_const_6 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_7 any

var A_arbace_c2j_emit__init_part0_A_const_8 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_9 any

var A_arbace_c2j_emit__init_part0_A_const_10 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_11 any

var A_arbace_c2j_emit__init_part0_A_const_12 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_13 any

var A_arbace_c2j_emit__init_part0_A_const_14 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_15 any

var A_arbace_c2j_emit__init_part0_A_const_16 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_17 any

var A_arbace_c2j_emit__init_part0_A_const_18 any

var A_arbace_c2j_emit__init_part0_A_const_19 any

var A_arbace_c2j_emit__init_part0_A_const_20 any

var A_arbace_c2j_emit__init_part0_A_const_21 any

var A_arbace_c2j_emit__init_part0_A_const_22 any

var A_arbace_c2j_emit__init_part0_A_const_23 any

var A_arbace_c2j_emit__init_part0_A_const_24 any

var A_arbace_c2j_emit__init_part0_A_const_25 any

var A_arbace_c2j_emit__init_part0_A_const_26 any

var A_arbace_c2j_emit__init_part0_A_const_27 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_28 any

var A_arbace_c2j_emit__init_part0_A_const_29 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_30 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_31 any

var A_arbace_c2j_emit__init_part0_A_const_32 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_33 any

var A_arbace_c2j_emit__init_part0_A_const_34 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_35 any

var A_arbace_c2j_emit__init_part0_A_const_36 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_37 any

var A_arbace_c2j_emit__init_part0_A_const_38 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_39 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_40 any

var A_arbace_c2j_emit__init_part0_A_const_41 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_42 any

var A_arbace_c2j_emit__init_part0_A_const_43 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_44 any

var A_arbace_c2j_emit__init_part0_A_const_45 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_46 any

var A_arbace_c2j_emit__init_part0_A_const_47 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_48 any

var A_arbace_c2j_emit__init_part0_A_const_49 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_50 any

var A_arbace_c2j_emit__init_part0_A_const_51 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_52 any

var A_arbace_c2j_emit__init_part0_A_const_53 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_54 any

var A_arbace_c2j_emit__init_part0_A_const_55 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_56 any

var A_arbace_c2j_emit__init_part0_A_const_57 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_58 any

var A_arbace_c2j_emit__init_part0_A_const_59 any

var A_arbace_c2j_emit__init_part0_A_const_60 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_61 any

var A_arbace_c2j_emit__init_part0_A_const_62 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_63 any

var A_arbace_c2j_emit__init_part0_A_const_64 any

var A_arbace_c2j_emit__init_part0_A_const_65 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_66 any

var A_arbace_c2j_emit__init_part0_A_const_67 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_68 any

var A_arbace_c2j_emit__init_part0_A_const_69 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_70 any

var A_arbace_c2j_emit__init_part0_A_const_71 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_72 any

var A_arbace_c2j_emit__init_part0_A_const_73 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_74 any

var A_arbace_c2j_emit__init_part0_A_const_75 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_76 any

var A_arbace_c2j_emit__init_part0_A_const_77 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_78 any

var A_arbace_c2j_emit__init_part0_A_const_79 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_80 any

var A_arbace_c2j_emit__init_part0_A_const_81 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_82 any

var A_arbace_c2j_emit__init_part0_A_const_83 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_84 any

var A_arbace_c2j_emit__init_part0_A_const_85 any

var A_arbace_c2j_emit__init_part0_A_const_86 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_87 any

var A_arbace_c2j_emit__init_part0_A_const_88 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_89 any

var A_arbace_c2j_emit__init_part0_A_const_90 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_91 any

var A_arbace_c2j_emit__init_part0_A_const_92 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_93 any

var A_arbace_c2j_emit__init_part0_A_const_94 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_95 any

var A_arbace_c2j_emit__init_part0_A_const_96 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_97 any

var A_arbace_c2j_emit__init_part0_A_const_98 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_99 any

var A_arbace_c2j_emit__init_part0_A_const_100 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_101 any

var A_arbace_c2j_emit__init_part0_A_const_102 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_103 any

var A_arbace_c2j_emit__init_part0_A_const_104 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_105 any

var A_arbace_c2j_emit__init_part0_A_const_106 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_107 any

var A_arbace_c2j_emit__init_part0_A_const_108 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_109 any

var A_arbace_c2j_emit__init_part0_A_const_110 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_111 any

var A_arbace_c2j_emit__init_part0_A_const_112 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_113 any

var A_arbace_c2j_emit__init_part0_A_const_114 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_115 any

var A_arbace_c2j_emit__init_part0_A_const_116 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_117 any

var A_arbace_c2j_emit__init_part0_A_const_118 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_119 any

var A_arbace_c2j_emit__init_part0_A_const_120 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_121 any

var A_arbace_c2j_emit__init_part0_A_const_122 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_123 any

var A_arbace_c2j_emit__init_part0_A_const_124 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_125 any

var A_arbace_c2j_emit__init_part0_A_const_126 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_127 any

var A_arbace_c2j_emit__init_part0_A_const_128 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_129 any

var A_arbace_c2j_emit__init_part0_A_const_130 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_131 any

var A_arbace_c2j_emit__init_part0_A_const_132 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_133 any

var A_arbace_c2j_emit__init_part0_A_const_134 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_135 any

var A_arbace_c2j_emit__init_part0_A_const_136 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_137 any

var A_arbace_c2j_emit__init_part0_A_const_138 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_139 any

var A_arbace_c2j_emit__init_part0_A_const_140 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_141 any

var A_arbace_c2j_emit__init_part0_A_const_142 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_143 any

var A_arbace_c2j_emit__init_part0_A_const_144 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_145 any

var A_arbace_c2j_emit__init_part0_A_const_146 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_147 any

var A_arbace_c2j_emit__init_part0_A_const_148 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_149 any

var A_arbace_c2j_emit__init_part0_A_const_150 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_151 any

var A_arbace_c2j_emit__init_part0_A_const_152 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_153 any

var A_arbace_c2j_emit__init_part0_A_const_154 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_155 any

var A_arbace_c2j_emit__init_part0_A_const_156 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_157 any

var A_arbace_c2j_emit__init_part0_A_const_158 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_159 any

var A_arbace_c2j_emit__init_part0_A_const_160 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_161 any

var A_arbace_c2j_emit__init_part0_A_const_162 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_163 any

var A_arbace_c2j_emit__init_part0_A_const_164 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_165 any

var A_arbace_c2j_emit__init_part0_A_const_166 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_167 any

var A_arbace_c2j_emit__init_part0_A_const_168 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_169 any

var A_arbace_c2j_emit__init_part0_A_const_170 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_171 any

var A_arbace_c2j_emit__init_part0_A_const_172 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_173 any

var A_arbace_c2j_emit__init_part0_A_const_174 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_175 any

var A_arbace_c2j_emit__init_part0_A_const_176 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_177 any

var A_arbace_c2j_emit__init_part0_A_const_178 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_179 any

var A_arbace_c2j_emit__init_part0_A_const_180 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_181 any

var A_arbace_c2j_emit__init_part0_A_const_182 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_183 any

var A_arbace_c2j_emit__init_part0_A_const_184 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_185 any

var A_arbace_c2j_emit__init_part0_A_const_186 any

var A_arbace_c2j_emit__init_part0_A_const_187 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_188 any

var A_arbace_c2j_emit__init_part0_A_const_189 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_190 any

var A_arbace_c2j_emit__init_part0_A_const_191 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_192 any

var A_arbace_c2j_emit__init_part0_A_const_193 any

var A_arbace_c2j_emit__init_part0_A_const_194 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_195 any

var A_arbace_c2j_emit__init_part0_A_const_196 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_197 any

var A_arbace_c2j_emit__init_part0_A_const_198 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_199 any

var A_arbace_c2j_emit__init_part0_A_const_200 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_201 any

var A_arbace_c2j_emit__init_part0_A_const_202 any

var A_arbace_c2j_emit__init_part0_A_const_203 *lang.Var

var A_arbace_c2j_emit__init_part0_A_const_204 any

var A_arbace_c2j_emit__init_part0_A_const_205 any

var A_arbace_c2j_emit__init_part0_A_init jrt.ClassInit

func A_arbace_c2j_emit__init_part0_A_Init() { if !A_arbace_c2j_emit__init_part0_A_init.Done() { A_arbace_c2j_emit__init_part0_A_init.Run(A_arbace_c2j_emit__init_part0_A_clinit) } }

func A_arbace_c2j_emit__init_part0_A_clinit() { A_arbace_c2j_emit__init_part0_A_clinit_p0(); A_arbace_c2j_emit__init_part0_A_clinit_p1(); A_arbace_c2j_emit__init_part0_A_clinit_p2(); A_arbace_c2j_emit__init_part0_A_clinit_p3(); A_arbace_c2j_emit__init_part0_A_clinit_p4(); A_arbace_c2j_emit__init_part0_A_clinit_p5(); A_arbace_c2j_emit__init_part0_A_clinit_p6(); A_arbace_c2j_emit__init_part0_A_clinit_p7(); A_arbace_c2j_emit__init_part0_A_clinit_p8(); A_arbace_c2j_emit__init_part0_A_clinit_p9(); A_arbace_c2j_emit__init_part0_A_clinit_p10(); A_arbace_c2j_emit__init_part0_A_clinit_p11(); A_arbace_c2j_emit__init_part0_A_clinit_p12(); A_arbace_c2j_emit__init_part0_A_clinit_p13(); A_arbace_c2j_emit__init_part0_A_clinit_p14(); A_arbace_c2j_emit__init_part0_A_clinit_p15() }

func A_arbace_c2j_emit__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_c2j_emit__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_454, 290); A_arbace_c2j_emit__init_part0_A_const_0 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[84]); A_arbace_c2j_emit__init_part0_A_const_1 = A_arbace_c2j_emit__init_part0_A_const_pool.A[85]; A_arbace_c2j_emit__init_part0_A_const_2 = A_arbace_c2j_emit__init_part0_A_const_pool.A[86]; A_arbace_c2j_emit__init_part0_A_const_3 = A_arbace_c2j_emit__init_part0_A_const_pool.A[87]; A_arbace_c2j_emit__init_part0_A_const_4 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[88]); A_arbace_c2j_emit__init_part0_A_const_5 = A_arbace_c2j_emit__init_part0_A_const_pool.A[89]; A_arbace_c2j_emit__init_part0_A_const_6 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[90]); A_arbace_c2j_emit__init_part0_A_const_7 = A_arbace_c2j_emit__init_part0_A_const_pool.A[91]; A_arbace_c2j_emit__init_part0_A_const_8 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[92]); A_arbace_c2j_emit__init_part0_A_const_9 = A_arbace_c2j_emit__init_part0_A_const_pool.A[93]; A_arbace_c2j_emit__init_part0_A_const_10 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[94]); A_arbace_c2j_emit__init_part0_A_const_11 = A_arbace_c2j_emit__init_part0_A_const_pool.A[95]; A_arbace_c2j_emit__init_part0_A_const_12 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[96]) }

func A_arbace_c2j_emit__init_part0_A_clinit_p1() { A_arbace_c2j_emit__init_part0_A_const_13 = A_arbace_c2j_emit__init_part0_A_const_pool.A[97]; A_arbace_c2j_emit__init_part0_A_const_14 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[98]); A_arbace_c2j_emit__init_part0_A_const_15 = A_arbace_c2j_emit__init_part0_A_const_pool.A[99]; A_arbace_c2j_emit__init_part0_A_const_16 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[100]); A_arbace_c2j_emit__init_part0_A_const_17 = A_arbace_c2j_emit__init_part0_A_const_pool.A[101]; A_arbace_c2j_emit__init_part0_A_const_18 = A_arbace_c2j_emit__init_part0_A_const_pool.A[102]; A_arbace_c2j_emit__init_part0_A_const_19 = A_arbace_c2j_emit__init_part0_A_const_pool.A[103]; A_arbace_c2j_emit__init_part0_A_const_20 = A_arbace_c2j_emit__init_part0_A_const_pool.A[104]; A_arbace_c2j_emit__init_part0_A_const_21 = A_arbace_c2j_emit__init_part0_A_const_pool.A[105]; A_arbace_c2j_emit__init_part0_A_const_22 = A_arbace_c2j_emit__init_part0_A_const_pool.A[106]; A_arbace_c2j_emit__init_part0_A_const_23 = A_arbace_c2j_emit__init_part0_A_const_pool.A[107]; A_arbace_c2j_emit__init_part0_A_const_24 = A_arbace_c2j_emit__init_part0_A_const_pool.A[108]; A_arbace_c2j_emit__init_part0_A_const_25 = A_arbace_c2j_emit__init_part0_A_const_pool.A[109]; A_arbace_c2j_emit__init_part0_A_const_26 = A_arbace_c2j_emit__init_part0_A_const_pool.A[110]; A_arbace_c2j_emit__init_part0_A_const_27 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[111]) }

func A_arbace_c2j_emit__init_part0_A_clinit_p2() { A_arbace_c2j_emit__init_part0_A_const_28 = A_arbace_c2j_emit__init_part0_A_const_pool.A[112]; A_arbace_c2j_emit__init_part0_A_const_29 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[113]); A_arbace_c2j_emit__init_part0_A_const_30 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[114]); A_arbace_c2j_emit__init_part0_A_const_31 = A_arbace_c2j_emit__init_part0_A_const_pool.A[115]; A_arbace_c2j_emit__init_part0_A_const_32 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[116]); A_arbace_c2j_emit__init_part0_A_const_33 = A_arbace_c2j_emit__init_part0_A_const_pool.A[117]; A_arbace_c2j_emit__init_part0_A_const_34 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[118]); A_arbace_c2j_emit__init_part0_A_const_35 = A_arbace_c2j_emit__init_part0_A_const_pool.A[119]; A_arbace_c2j_emit__init_part0_A_const_36 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[120]); A_arbace_c2j_emit__init_part0_A_const_37 = A_arbace_c2j_emit__init_part0_A_const_pool.A[121]; A_arbace_c2j_emit__init_part0_A_const_38 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[122]); A_arbace_c2j_emit__init_part0_A_const_39 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[123]); A_arbace_c2j_emit__init_part0_A_const_40 = A_arbace_c2j_emit__init_part0_A_const_pool.A[124] }

func A_arbace_c2j_emit__init_part0_A_clinit_p3() { A_arbace_c2j_emit__init_part0_A_const_41 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[125]); A_arbace_c2j_emit__init_part0_A_const_42 = A_arbace_c2j_emit__init_part0_A_const_pool.A[126]; A_arbace_c2j_emit__init_part0_A_const_43 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[127]); A_arbace_c2j_emit__init_part0_A_const_44 = A_arbace_c2j_emit__init_part0_A_const_pool.A[128]; A_arbace_c2j_emit__init_part0_A_const_45 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[129]); A_arbace_c2j_emit__init_part0_A_const_46 = A_arbace_c2j_emit__init_part0_A_const_pool.A[130]; A_arbace_c2j_emit__init_part0_A_const_47 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[131]); A_arbace_c2j_emit__init_part0_A_const_48 = A_arbace_c2j_emit__init_part0_A_const_pool.A[132]; A_arbace_c2j_emit__init_part0_A_const_49 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[133]); A_arbace_c2j_emit__init_part0_A_const_50 = A_arbace_c2j_emit__init_part0_A_const_pool.A[134]; A_arbace_c2j_emit__init_part0_A_const_51 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[135]); A_arbace_c2j_emit__init_part0_A_const_52 = A_arbace_c2j_emit__init_part0_A_const_pool.A[136]; A_arbace_c2j_emit__init_part0_A_const_53 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[137]) }

func A_arbace_c2j_emit__init_part0_A_clinit_p4() { A_arbace_c2j_emit__init_part0_A_const_54 = A_arbace_c2j_emit__init_part0_A_const_pool.A[138]; A_arbace_c2j_emit__init_part0_A_const_55 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[139]); A_arbace_c2j_emit__init_part0_A_const_56 = A_arbace_c2j_emit__init_part0_A_const_pool.A[140]; A_arbace_c2j_emit__init_part0_A_const_57 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[141]); A_arbace_c2j_emit__init_part0_A_const_58 = A_arbace_c2j_emit__init_part0_A_const_pool.A[142]; A_arbace_c2j_emit__init_part0_A_const_59 = A_arbace_c2j_emit__init_part0_A_const_pool.A[143]; A_arbace_c2j_emit__init_part0_A_const_60 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[144]); A_arbace_c2j_emit__init_part0_A_const_61 = A_arbace_c2j_emit__init_part0_A_const_pool.A[145]; A_arbace_c2j_emit__init_part0_A_const_62 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[146]); A_arbace_c2j_emit__init_part0_A_const_63 = A_arbace_c2j_emit__init_part0_A_const_pool.A[147]; A_arbace_c2j_emit__init_part0_A_const_64 = A_arbace_c2j_emit__init_part0_A_const_pool.A[148]; A_arbace_c2j_emit__init_part0_A_const_65 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[149]); A_arbace_c2j_emit__init_part0_A_const_66 = A_arbace_c2j_emit__init_part0_A_const_pool.A[150]; A_arbace_c2j_emit__init_part0_A_const_67 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[151]) }

func A_arbace_c2j_emit__init_part0_A_clinit_p5() { A_arbace_c2j_emit__init_part0_A_const_68 = A_arbace_c2j_emit__init_part0_A_const_pool.A[152]; A_arbace_c2j_emit__init_part0_A_const_69 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[153]); A_arbace_c2j_emit__init_part0_A_const_70 = A_arbace_c2j_emit__init_part0_A_const_pool.A[154]; A_arbace_c2j_emit__init_part0_A_const_71 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[155]); A_arbace_c2j_emit__init_part0_A_const_72 = A_arbace_c2j_emit__init_part0_A_const_pool.A[156]; A_arbace_c2j_emit__init_part0_A_const_73 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[157]); A_arbace_c2j_emit__init_part0_A_const_74 = A_arbace_c2j_emit__init_part0_A_const_pool.A[158]; A_arbace_c2j_emit__init_part0_A_const_75 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[159]); A_arbace_c2j_emit__init_part0_A_const_76 = A_arbace_c2j_emit__init_part0_A_const_pool.A[160]; A_arbace_c2j_emit__init_part0_A_const_77 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[161]); A_arbace_c2j_emit__init_part0_A_const_78 = A_arbace_c2j_emit__init_part0_A_const_pool.A[162]; A_arbace_c2j_emit__init_part0_A_const_79 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[163]); A_arbace_c2j_emit__init_part0_A_const_80 = A_arbace_c2j_emit__init_part0_A_const_pool.A[164] }

func A_arbace_c2j_emit__init_part0_A_clinit_p6() { A_arbace_c2j_emit__init_part0_A_const_81 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[165]); A_arbace_c2j_emit__init_part0_A_const_82 = A_arbace_c2j_emit__init_part0_A_const_pool.A[166]; A_arbace_c2j_emit__init_part0_A_const_83 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[167]); A_arbace_c2j_emit__init_part0_A_const_84 = A_arbace_c2j_emit__init_part0_A_const_pool.A[168]; A_arbace_c2j_emit__init_part0_A_const_85 = A_arbace_c2j_emit__init_part0_A_const_pool.A[169]; A_arbace_c2j_emit__init_part0_A_const_86 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[170]); A_arbace_c2j_emit__init_part0_A_const_87 = A_arbace_c2j_emit__init_part0_A_const_pool.A[171]; A_arbace_c2j_emit__init_part0_A_const_88 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[172]); A_arbace_c2j_emit__init_part0_A_const_89 = A_arbace_c2j_emit__init_part0_A_const_pool.A[173]; A_arbace_c2j_emit__init_part0_A_const_90 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[174]); A_arbace_c2j_emit__init_part0_A_const_91 = A_arbace_c2j_emit__init_part0_A_const_pool.A[175]; A_arbace_c2j_emit__init_part0_A_const_92 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[176]); A_arbace_c2j_emit__init_part0_A_const_93 = A_arbace_c2j_emit__init_part0_A_const_pool.A[177] }

func A_arbace_c2j_emit__init_part0_A_clinit_p7() { A_arbace_c2j_emit__init_part0_A_const_94 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[178]); A_arbace_c2j_emit__init_part0_A_const_95 = A_arbace_c2j_emit__init_part0_A_const_pool.A[179]; A_arbace_c2j_emit__init_part0_A_const_96 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[180]); A_arbace_c2j_emit__init_part0_A_const_97 = A_arbace_c2j_emit__init_part0_A_const_pool.A[181]; A_arbace_c2j_emit__init_part0_A_const_98 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[182]); A_arbace_c2j_emit__init_part0_A_const_99 = A_arbace_c2j_emit__init_part0_A_const_pool.A[183]; A_arbace_c2j_emit__init_part0_A_const_100 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[184]); A_arbace_c2j_emit__init_part0_A_const_101 = A_arbace_c2j_emit__init_part0_A_const_pool.A[185]; A_arbace_c2j_emit__init_part0_A_const_102 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[186]); A_arbace_c2j_emit__init_part0_A_const_103 = A_arbace_c2j_emit__init_part0_A_const_pool.A[187]; A_arbace_c2j_emit__init_part0_A_const_104 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[188]); A_arbace_c2j_emit__init_part0_A_const_105 = A_arbace_c2j_emit__init_part0_A_const_pool.A[189]; A_arbace_c2j_emit__init_part0_A_const_106 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[190]) }

func A_arbace_c2j_emit__init_part0_A_clinit_p8() { A_arbace_c2j_emit__init_part0_A_const_107 = A_arbace_c2j_emit__init_part0_A_const_pool.A[191]; A_arbace_c2j_emit__init_part0_A_const_108 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[192]); A_arbace_c2j_emit__init_part0_A_const_109 = A_arbace_c2j_emit__init_part0_A_const_pool.A[193]; A_arbace_c2j_emit__init_part0_A_const_110 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[194]); A_arbace_c2j_emit__init_part0_A_const_111 = A_arbace_c2j_emit__init_part0_A_const_pool.A[195]; A_arbace_c2j_emit__init_part0_A_const_112 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[196]); A_arbace_c2j_emit__init_part0_A_const_113 = A_arbace_c2j_emit__init_part0_A_const_pool.A[197]; A_arbace_c2j_emit__init_part0_A_const_114 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[198]); A_arbace_c2j_emit__init_part0_A_const_115 = A_arbace_c2j_emit__init_part0_A_const_pool.A[199]; A_arbace_c2j_emit__init_part0_A_const_116 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[200]); A_arbace_c2j_emit__init_part0_A_const_117 = A_arbace_c2j_emit__init_part0_A_const_pool.A[201]; A_arbace_c2j_emit__init_part0_A_const_118 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[202]); A_arbace_c2j_emit__init_part0_A_const_119 = A_arbace_c2j_emit__init_part0_A_const_pool.A[203] }

func A_arbace_c2j_emit__init_part0_A_clinit_p9() { A_arbace_c2j_emit__init_part0_A_const_120 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[204]); A_arbace_c2j_emit__init_part0_A_const_121 = A_arbace_c2j_emit__init_part0_A_const_pool.A[205]; A_arbace_c2j_emit__init_part0_A_const_122 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[206]); A_arbace_c2j_emit__init_part0_A_const_123 = A_arbace_c2j_emit__init_part0_A_const_pool.A[207]; A_arbace_c2j_emit__init_part0_A_const_124 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[208]); A_arbace_c2j_emit__init_part0_A_const_125 = A_arbace_c2j_emit__init_part0_A_const_pool.A[209]; A_arbace_c2j_emit__init_part0_A_const_126 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[210]); A_arbace_c2j_emit__init_part0_A_const_127 = A_arbace_c2j_emit__init_part0_A_const_pool.A[211]; A_arbace_c2j_emit__init_part0_A_const_128 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[212]); A_arbace_c2j_emit__init_part0_A_const_129 = A_arbace_c2j_emit__init_part0_A_const_pool.A[213]; A_arbace_c2j_emit__init_part0_A_const_130 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[214]); A_arbace_c2j_emit__init_part0_A_const_131 = A_arbace_c2j_emit__init_part0_A_const_pool.A[215]; A_arbace_c2j_emit__init_part0_A_const_132 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[216]) }

func A_arbace_c2j_emit__init_part0_A_clinit_p10() { A_arbace_c2j_emit__init_part0_A_const_133 = A_arbace_c2j_emit__init_part0_A_const_pool.A[217]; A_arbace_c2j_emit__init_part0_A_const_134 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[218]); A_arbace_c2j_emit__init_part0_A_const_135 = A_arbace_c2j_emit__init_part0_A_const_pool.A[219]; A_arbace_c2j_emit__init_part0_A_const_136 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[220]); A_arbace_c2j_emit__init_part0_A_const_137 = A_arbace_c2j_emit__init_part0_A_const_pool.A[221]; A_arbace_c2j_emit__init_part0_A_const_138 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[222]); A_arbace_c2j_emit__init_part0_A_const_139 = A_arbace_c2j_emit__init_part0_A_const_pool.A[223]; A_arbace_c2j_emit__init_part0_A_const_140 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[224]); A_arbace_c2j_emit__init_part0_A_const_141 = A_arbace_c2j_emit__init_part0_A_const_pool.A[225]; A_arbace_c2j_emit__init_part0_A_const_142 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[226]); A_arbace_c2j_emit__init_part0_A_const_143 = A_arbace_c2j_emit__init_part0_A_const_pool.A[227]; A_arbace_c2j_emit__init_part0_A_const_144 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[228]); A_arbace_c2j_emit__init_part0_A_const_145 = A_arbace_c2j_emit__init_part0_A_const_pool.A[229] }

func A_arbace_c2j_emit__init_part0_A_clinit_p11() { A_arbace_c2j_emit__init_part0_A_const_146 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[230]); A_arbace_c2j_emit__init_part0_A_const_147 = A_arbace_c2j_emit__init_part0_A_const_pool.A[231]; A_arbace_c2j_emit__init_part0_A_const_148 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[232]); A_arbace_c2j_emit__init_part0_A_const_149 = A_arbace_c2j_emit__init_part0_A_const_pool.A[233]; A_arbace_c2j_emit__init_part0_A_const_150 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[234]); A_arbace_c2j_emit__init_part0_A_const_151 = A_arbace_c2j_emit__init_part0_A_const_pool.A[235]; A_arbace_c2j_emit__init_part0_A_const_152 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[236]); A_arbace_c2j_emit__init_part0_A_const_153 = A_arbace_c2j_emit__init_part0_A_const_pool.A[237]; A_arbace_c2j_emit__init_part0_A_const_154 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[238]); A_arbace_c2j_emit__init_part0_A_const_155 = A_arbace_c2j_emit__init_part0_A_const_pool.A[239]; A_arbace_c2j_emit__init_part0_A_const_156 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[240]); A_arbace_c2j_emit__init_part0_A_const_157 = A_arbace_c2j_emit__init_part0_A_const_pool.A[241]; A_arbace_c2j_emit__init_part0_A_const_158 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[242]) }

func A_arbace_c2j_emit__init_part0_A_clinit_p12() { A_arbace_c2j_emit__init_part0_A_const_159 = A_arbace_c2j_emit__init_part0_A_const_pool.A[243]; A_arbace_c2j_emit__init_part0_A_const_160 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[244]); A_arbace_c2j_emit__init_part0_A_const_161 = A_arbace_c2j_emit__init_part0_A_const_pool.A[245]; A_arbace_c2j_emit__init_part0_A_const_162 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[246]); A_arbace_c2j_emit__init_part0_A_const_163 = A_arbace_c2j_emit__init_part0_A_const_pool.A[247]; A_arbace_c2j_emit__init_part0_A_const_164 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[248]); A_arbace_c2j_emit__init_part0_A_const_165 = A_arbace_c2j_emit__init_part0_A_const_pool.A[249]; A_arbace_c2j_emit__init_part0_A_const_166 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[250]); A_arbace_c2j_emit__init_part0_A_const_167 = A_arbace_c2j_emit__init_part0_A_const_pool.A[251]; A_arbace_c2j_emit__init_part0_A_const_168 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[252]); A_arbace_c2j_emit__init_part0_A_const_169 = A_arbace_c2j_emit__init_part0_A_const_pool.A[253]; A_arbace_c2j_emit__init_part0_A_const_170 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[254]); A_arbace_c2j_emit__init_part0_A_const_171 = A_arbace_c2j_emit__init_part0_A_const_pool.A[255] }

func A_arbace_c2j_emit__init_part0_A_clinit_p13() { A_arbace_c2j_emit__init_part0_A_const_172 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[256]); A_arbace_c2j_emit__init_part0_A_const_173 = A_arbace_c2j_emit__init_part0_A_const_pool.A[257]; A_arbace_c2j_emit__init_part0_A_const_174 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[258]); A_arbace_c2j_emit__init_part0_A_const_175 = A_arbace_c2j_emit__init_part0_A_const_pool.A[259]; A_arbace_c2j_emit__init_part0_A_const_176 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[260]); A_arbace_c2j_emit__init_part0_A_const_177 = A_arbace_c2j_emit__init_part0_A_const_pool.A[261]; A_arbace_c2j_emit__init_part0_A_const_178 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[262]); A_arbace_c2j_emit__init_part0_A_const_179 = A_arbace_c2j_emit__init_part0_A_const_pool.A[263]; A_arbace_c2j_emit__init_part0_A_const_180 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[264]); A_arbace_c2j_emit__init_part0_A_const_181 = A_arbace_c2j_emit__init_part0_A_const_pool.A[265]; A_arbace_c2j_emit__init_part0_A_const_182 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[266]); A_arbace_c2j_emit__init_part0_A_const_183 = A_arbace_c2j_emit__init_part0_A_const_pool.A[267]; A_arbace_c2j_emit__init_part0_A_const_184 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[268]) }

func A_arbace_c2j_emit__init_part0_A_clinit_p14() { A_arbace_c2j_emit__init_part0_A_const_185 = A_arbace_c2j_emit__init_part0_A_const_pool.A[269]; A_arbace_c2j_emit__init_part0_A_const_186 = A_arbace_c2j_emit__init_part0_A_const_pool.A[270]; A_arbace_c2j_emit__init_part0_A_const_187 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[271]); A_arbace_c2j_emit__init_part0_A_const_188 = A_arbace_c2j_emit__init_part0_A_const_pool.A[272]; A_arbace_c2j_emit__init_part0_A_const_189 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[273]); A_arbace_c2j_emit__init_part0_A_const_190 = A_arbace_c2j_emit__init_part0_A_const_pool.A[274]; A_arbace_c2j_emit__init_part0_A_const_191 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[275]); A_arbace_c2j_emit__init_part0_A_const_192 = A_arbace_c2j_emit__init_part0_A_const_pool.A[276]; A_arbace_c2j_emit__init_part0_A_const_193 = A_arbace_c2j_emit__init_part0_A_const_pool.A[277]; A_arbace_c2j_emit__init_part0_A_const_194 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[278]); A_arbace_c2j_emit__init_part0_A_const_195 = A_arbace_c2j_emit__init_part0_A_const_pool.A[279]; A_arbace_c2j_emit__init_part0_A_const_196 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[280]); A_arbace_c2j_emit__init_part0_A_const_197 = A_arbace_c2j_emit__init_part0_A_const_pool.A[281]; A_arbace_c2j_emit__init_part0_A_const_198 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[282]) }

func A_arbace_c2j_emit__init_part0_A_clinit_p15() { A_arbace_c2j_emit__init_part0_A_const_199 = A_arbace_c2j_emit__init_part0_A_const_pool.A[283]; A_arbace_c2j_emit__init_part0_A_const_200 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[284]); A_arbace_c2j_emit__init_part0_A_const_201 = A_arbace_c2j_emit__init_part0_A_const_pool.A[285]; A_arbace_c2j_emit__init_part0_A_const_202 = A_arbace_c2j_emit__init_part0_A_const_pool.A[286]; A_arbace_c2j_emit__init_part0_A_const_203 = lang.Var_Cast(A_arbace_c2j_emit__init_part0_A_const_pool.A[287]); A_arbace_c2j_emit__init_part0_A_const_204 = A_arbace_c2j_emit__init_part0_A_const_pool.A[288]; A_arbace_c2j_emit__init_part0_A_const_205 = A_arbace_c2j_emit__init_part0_A_const_pool.A[289] }

func A_arbace_c2j_emit__init_part0_A_New() *A_arbace_c2j_emit__init_part0_A { A_arbace_c2j_emit__init_part0_A_Init(); t := &A_arbace_c2j_emit__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_emit__init_part0_A) Ctor() {}

func (t *A_arbace_c2j_emit__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_emit__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_emit__init_part0_A_class }

func (t *A_arbace_c2j_emit__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_emit__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_emit__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_emit__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_emit__init_part0_A); return ok }

func A_arbace_c2j_emit__init_part0_A_Cast(x any) *A_arbace_c2j_emit__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_emit__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_emit__init_part0_A_class)) }; return v }



type A_arbace_c2j_emit__init_part1_A struct{ jrt.Object }

var A_arbace_c2j_emit__init_part1_A_const_pool *jrt.RefArray

var A_arbace_c2j_emit__init_part1_A_const_0 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_1 any

var A_arbace_c2j_emit__init_part1_A_const_2 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_3 any

var A_arbace_c2j_emit__init_part1_A_const_4 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_5 any

var A_arbace_c2j_emit__init_part1_A_const_6 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_7 any

var A_arbace_c2j_emit__init_part1_A_const_8 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_9 any

var A_arbace_c2j_emit__init_part1_A_const_10 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_11 any

var A_arbace_c2j_emit__init_part1_A_const_12 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_13 any

var A_arbace_c2j_emit__init_part1_A_const_14 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_15 any

var A_arbace_c2j_emit__init_part1_A_const_16 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_17 any

var A_arbace_c2j_emit__init_part1_A_const_18 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_19 any

var A_arbace_c2j_emit__init_part1_A_const_20 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_21 any

var A_arbace_c2j_emit__init_part1_A_const_22 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_23 any

var A_arbace_c2j_emit__init_part1_A_const_24 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_25 any

var A_arbace_c2j_emit__init_part1_A_const_26 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_27 any

var A_arbace_c2j_emit__init_part1_A_const_28 any

var A_arbace_c2j_emit__init_part1_A_const_29 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_30 any

var A_arbace_c2j_emit__init_part1_A_const_31 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_32 any

var A_arbace_c2j_emit__init_part1_A_const_33 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_34 any

var A_arbace_c2j_emit__init_part1_A_const_35 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_36 any

var A_arbace_c2j_emit__init_part1_A_const_37 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_38 any

var A_arbace_c2j_emit__init_part1_A_const_39 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_40 any

var A_arbace_c2j_emit__init_part1_A_const_41 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_42 any

var A_arbace_c2j_emit__init_part1_A_const_43 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_44 any

var A_arbace_c2j_emit__init_part1_A_const_45 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_46 any

var A_arbace_c2j_emit__init_part1_A_const_47 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_48 any

var A_arbace_c2j_emit__init_part1_A_const_49 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_50 any

var A_arbace_c2j_emit__init_part1_A_const_51 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_52 any

var A_arbace_c2j_emit__init_part1_A_const_53 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_54 any

var A_arbace_c2j_emit__init_part1_A_const_55 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_56 any

var A_arbace_c2j_emit__init_part1_A_const_57 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_58 any

var A_arbace_c2j_emit__init_part1_A_const_59 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_60 any

var A_arbace_c2j_emit__init_part1_A_const_61 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_62 any

var A_arbace_c2j_emit__init_part1_A_const_63 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_64 any

var A_arbace_c2j_emit__init_part1_A_const_65 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_66 any

var A_arbace_c2j_emit__init_part1_A_const_67 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_68 any

var A_arbace_c2j_emit__init_part1_A_const_69 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_70 any

var A_arbace_c2j_emit__init_part1_A_const_71 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_72 any

var A_arbace_c2j_emit__init_part1_A_const_73 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_74 any

var A_arbace_c2j_emit__init_part1_A_const_75 any

var A_arbace_c2j_emit__init_part1_A_const_76 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_77 any

var A_arbace_c2j_emit__init_part1_A_const_78 any

var A_arbace_c2j_emit__init_part1_A_const_79 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_80 any

var A_arbace_c2j_emit__init_part1_A_const_81 any

var A_arbace_c2j_emit__init_part1_A_const_82 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_83 any

var A_arbace_c2j_emit__init_part1_A_const_84 any

var A_arbace_c2j_emit__init_part1_A_const_85 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_86 any

var A_arbace_c2j_emit__init_part1_A_const_87 any

var A_arbace_c2j_emit__init_part1_A_const_88 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_89 any

var A_arbace_c2j_emit__init_part1_A_const_90 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_91 any

var A_arbace_c2j_emit__init_part1_A_const_92 any

var A_arbace_c2j_emit__init_part1_A_const_93 any

var A_arbace_c2j_emit__init_part1_A_const_94 any

var A_arbace_c2j_emit__init_part1_A_const_95 any

var A_arbace_c2j_emit__init_part1_A_const_96 any

var A_arbace_c2j_emit__init_part1_A_const_97 any

var A_arbace_c2j_emit__init_part1_A_const_98 any

var A_arbace_c2j_emit__init_part1_A_const_99 any

var A_arbace_c2j_emit__init_part1_A_const_100 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_101 any

var A_arbace_c2j_emit__init_part1_A_const_102 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_103 any

var A_arbace_c2j_emit__init_part1_A_const_104 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_105 any

var A_arbace_c2j_emit__init_part1_A_const_106 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_107 any

var A_arbace_c2j_emit__init_part1_A_const_108 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_109 any

var A_arbace_c2j_emit__init_part1_A_const_110 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_111 any

var A_arbace_c2j_emit__init_part1_A_const_112 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_113 any

var A_arbace_c2j_emit__init_part1_A_const_114 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_115 any

var A_arbace_c2j_emit__init_part1_A_const_116 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_117 any

var A_arbace_c2j_emit__init_part1_A_const_118 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_119 any

var A_arbace_c2j_emit__init_part1_A_const_120 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_121 any

var A_arbace_c2j_emit__init_part1_A_const_122 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_123 any

var A_arbace_c2j_emit__init_part1_A_const_124 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_125 any

var A_arbace_c2j_emit__init_part1_A_const_126 any

var A_arbace_c2j_emit__init_part1_A_const_127 any

var A_arbace_c2j_emit__init_part1_A_const_128 any

var A_arbace_c2j_emit__init_part1_A_const_129 any

var A_arbace_c2j_emit__init_part1_A_const_130 any

var A_arbace_c2j_emit__init_part1_A_const_131 any

var A_arbace_c2j_emit__init_part1_A_const_132 any

var A_arbace_c2j_emit__init_part1_A_const_133 any

var A_arbace_c2j_emit__init_part1_A_const_134 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_135 any

var A_arbace_c2j_emit__init_part1_A_const_136 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_137 any

var A_arbace_c2j_emit__init_part1_A_const_138 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_139 any

var A_arbace_c2j_emit__init_part1_A_const_140 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_141 any

var A_arbace_c2j_emit__init_part1_A_const_142 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_143 any

var A_arbace_c2j_emit__init_part1_A_const_144 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_145 any

var A_arbace_c2j_emit__init_part1_A_const_146 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_147 any

var A_arbace_c2j_emit__init_part1_A_const_148 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_149 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_150 any

var A_arbace_c2j_emit__init_part1_A_const_151 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_152 any

var A_arbace_c2j_emit__init_part1_A_const_153 any

var A_arbace_c2j_emit__init_part1_A_const_154 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_155 any

var A_arbace_c2j_emit__init_part1_A_const_156 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_157 any

var A_arbace_c2j_emit__init_part1_A_const_158 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_159 any

var A_arbace_c2j_emit__init_part1_A_const_160 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_161 any

var A_arbace_c2j_emit__init_part1_A_const_162 *lang.Var

var A_arbace_c2j_emit__init_part1_A_const_163 any

var A_arbace_c2j_emit__init_part1_A_init jrt.ClassInit

func A_arbace_c2j_emit__init_part1_A_Init() { if !A_arbace_c2j_emit__init_part1_A_init.Done() { A_arbace_c2j_emit__init_part1_A_init.Run(A_arbace_c2j_emit__init_part1_A_clinit) } }

func A_arbace_c2j_emit__init_part1_A_clinit() { A_arbace_c2j_emit__init_part1_A_clinit_p0(); A_arbace_c2j_emit__init_part1_A_clinit_p1(); A_arbace_c2j_emit__init_part1_A_clinit_p2() }

func A_arbace_c2j_emit__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_c2j_emit__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_526, 341); A_arbace_c2j_emit__init_part1_A_const_0 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[189]); A_arbace_c2j_emit__init_part1_A_const_1 = A_arbace_c2j_emit__init_part1_A_const_pool.A[190]; A_arbace_c2j_emit__init_part1_A_const_2 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[191]); A_arbace_c2j_emit__init_part1_A_const_3 = A_arbace_c2j_emit__init_part1_A_const_pool.A[192]; A_arbace_c2j_emit__init_part1_A_const_4 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[193]); A_arbace_c2j_emit__init_part1_A_const_5 = A_arbace_c2j_emit__init_part1_A_const_pool.A[194]; A_arbace_c2j_emit__init_part1_A_const_6 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[195]); A_arbace_c2j_emit__init_part1_A_const_7 = A_arbace_c2j_emit__init_part1_A_const_pool.A[196]; A_arbace_c2j_emit__init_part1_A_const_8 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[197]); A_arbace_c2j_emit__init_part1_A_const_9 = A_arbace_c2j_emit__init_part1_A_const_pool.A[198]; A_arbace_c2j_emit__init_part1_A_const_10 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[199]); A_arbace_c2j_emit__init_part1_A_const_11 = A_arbace_c2j_emit__init_part1_A_const_pool.A[200] }

func A_arbace_c2j_emit__init_part1_A_clinit_p1() { A_arbace_c2j_emit__init_part1_A_const_12 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[201]); A_arbace_c2j_emit__init_part1_A_const_13 = A_arbace_c2j_emit__init_part1_A_const_pool.A[202] }

func A_arbace_c2j_emit__init_part1_A_clinit_p2() { var tmp1 *lang.Var; A_arbace_c2j_emit__init_part0_A_Init(); tmp1 = A_arbace_c2j_emit__init_part0_A_const_156; A_arbace_c2j_emit__init_part1_A_const_14 = tmp1; A_arbace_c2j_emit__init_part1_A_const_15 = A_arbace_c2j_emit__init_part1_A_const_pool.A[203]; A_arbace_c2j_emit__init_part1_A_const_16 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[204]); A_arbace_c2j_emit__init_part1_A_const_17 = A_arbace_c2j_emit__init_part1_A_const_pool.A[205]; A_arbace_c2j_emit__init_part1_A_const_18 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[206]); A_arbace_c2j_emit__init_part1_A_const_19 = A_arbace_c2j_emit__init_part1_A_const_pool.A[207]; A_arbace_c2j_emit__init_part1_A_const_20 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[208]); A_arbace_c2j_emit__init_part1_A_const_21 = A_arbace_c2j_emit__init_part1_A_const_pool.A[209]; A_arbace_c2j_emit__init_part1_A_const_22 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[210]); A_arbace_c2j_emit__init_part1_A_const_23 = A_arbace_c2j_emit__init_part1_A_const_pool.A[211]; A_arbace_c2j_emit__init_part1_A_const_24 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[212]); A_arbace_c2j_emit__init_part1_A_const_25 = A_arbace_c2j_emit__init_part1_A_const_pool.A[213]; var tmp2 *lang.Var; A_arbace_c2j_emit__init_part0_A_Init(); tmp2 = A_arbace_c2j_emit__init_part0_A_const_158; A_arbace_c2j_emit__init_part1_A_const_26 = tmp2; A_arbace_c2j_emit__init_part1_A_const_27 = A_arbace_c2j_emit__init_part1_A_const_pool.A[214]; A_arbace_c2j_emit__init_part1_A_const_28 = A_arbace_c2j_emit__init_part1_A_const_pool.A[215]; var tmp3 *lang.Var; A_arbace_c2j_emit__init_part0_A_Init(); tmp3 = A_arbace_c2j_emit__init_part0_A_const_116; A_arbace_c2j_emit__init_part1_A_const_29 = tmp3; A_arbace_c2j_emit__init_part1_A_const_30 = A_arbace_c2j_emit__init_part1_A_const_pool.A[216]; A_arbace_c2j_emit__init_part1_A_const_31 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[217]); A_arbace_c2j_emit__init_part1_A_const_32 = A_arbace_c2j_emit__init_part1_A_const_pool.A[218]; A_arbace_c2j_emit__init_part1_A_const_33 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[219]); A_arbace_c2j_emit__init_part1_A_const_34 = A_arbace_c2j_emit__init_part1_A_const_pool.A[220]; A_arbace_c2j_emit__init_part1_A_const_35 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[221]); A_arbace_c2j_emit__init_part1_A_const_36 = A_arbace_c2j_emit__init_part1_A_const_pool.A[222]; A_arbace_c2j_emit__init_part1_A_const_37 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[223]); A_arbace_c2j_emit__init_part1_A_const_38 = A_arbace_c2j_emit__init_part1_A_const_pool.A[224]; A_arbace_c2j_emit__init_part1_A_const_39 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[225]); A_arbace_c2j_emit__init_part1_A_const_40 = A_arbace_c2j_emit__init_part1_A_const_pool.A[226]; A_arbace_c2j_emit__init_part1_A_const_41 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[227]); A_arbace_c2j_emit__init_part1_A_const_42 = A_arbace_c2j_emit__init_part1_A_const_pool.A[228]; A_arbace_c2j_emit__init_part1_A_const_43 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[229]); A_arbace_c2j_emit__init_part1_A_const_44 = A_arbace_c2j_emit__init_part1_A_const_pool.A[230]; A_arbace_c2j_emit__init_part1_A_const_45 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[231]); A_arbace_c2j_emit__init_part1_A_const_46 = A_arbace_c2j_emit__init_part1_A_const_pool.A[232]; A_arbace_c2j_emit__init_part1_A_const_47 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[233]); A_arbace_c2j_emit__init_part1_A_const_48 = A_arbace_c2j_emit__init_part1_A_const_pool.A[234]; A_arbace_c2j_emit__init_part1_A_const_49 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[235]); A_arbace_c2j_emit__init_part1_A_const_50 = A_arbace_c2j_emit__init_part1_A_const_pool.A[236]; A_arbace_c2j_emit__init_part1_A_const_51 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[237]); A_arbace_c2j_emit__init_part1_A_const_52 = A_arbace_c2j_emit__init_part1_A_const_pool.A[238]; A_arbace_c2j_emit__init_part1_A_const_53 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[239]); A_arbace_c2j_emit__init_part1_A_const_54 = A_arbace_c2j_emit__init_part1_A_const_pool.A[240]; A_arbace_c2j_emit__init_part1_A_const_55 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[241]); A_arbace_c2j_emit__init_part1_A_const_56 = A_arbace_c2j_emit__init_part1_A_const_pool.A[242]; A_arbace_c2j_emit__init_part1_A_const_57 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[243]); A_arbace_c2j_emit__init_part1_A_const_58 = A_arbace_c2j_emit__init_part1_A_const_pool.A[244]; var tmp4 *lang.Var; A_arbace_c2j_emit__init_part0_A_Init(); tmp4 = A_arbace_c2j_emit__init_part0_A_const_49; A_arbace_c2j_emit__init_part1_A_const_59 = tmp4; A_arbace_c2j_emit__init_part1_A_const_60 = A_arbace_c2j_emit__init_part1_A_const_pool.A[245]; A_arbace_c2j_emit__init_part1_A_const_61 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[246]); A_arbace_c2j_emit__init_part1_A_const_62 = A_arbace_c2j_emit__init_part1_A_const_pool.A[247]; A_arbace_c2j_emit__init_part1_A_const_63 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[248]); A_arbace_c2j_emit__init_part1_A_const_64 = A_arbace_c2j_emit__init_part1_A_const_pool.A[249]; A_arbace_c2j_emit__init_part1_A_const_65 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[250]); A_arbace_c2j_emit__init_part1_A_const_66 = A_arbace_c2j_emit__init_part1_A_const_pool.A[251]; A_arbace_c2j_emit__init_part1_A_const_67 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[252]); A_arbace_c2j_emit__init_part1_A_const_68 = A_arbace_c2j_emit__init_part1_A_const_pool.A[253]; A_arbace_c2j_emit__init_part1_A_const_69 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[254]); A_arbace_c2j_emit__init_part1_A_const_70 = A_arbace_c2j_emit__init_part1_A_const_pool.A[255]; A_arbace_c2j_emit__init_part1_A_const_71 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[256]); A_arbace_c2j_emit__init_part1_A_const_72 = A_arbace_c2j_emit__init_part1_A_const_pool.A[257]; A_arbace_c2j_emit__init_part1_A_const_73 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[258]); A_arbace_c2j_emit__init_part1_A_const_74 = A_arbace_c2j_emit__init_part1_A_const_pool.A[259]; A_arbace_c2j_emit__init_part1_A_const_75 = A_arbace_c2j_emit__init_part1_A_const_pool.A[260]; var tmp5 *lang.Var; A_arbace_c2j_emit__init_part0_A_Init(); tmp5 = A_arbace_c2j_emit__init_part0_A_const_118; A_arbace_c2j_emit__init_part1_A_const_76 = tmp5; A_arbace_c2j_emit__init_part1_A_const_77 = A_arbace_c2j_emit__init_part1_A_const_pool.A[261]; A_arbace_c2j_emit__init_part1_A_const_78 = A_arbace_c2j_emit__init_part1_A_const_pool.A[262]; A_arbace_c2j_emit__init_part1_A_const_79 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[263]); A_arbace_c2j_emit__init_part1_A_const_80 = A_arbace_c2j_emit__init_part1_A_const_pool.A[264]; A_arbace_c2j_emit__init_part1_A_const_81 = A_arbace_c2j_emit__init_part1_A_const_pool.A[265]; A_arbace_c2j_emit__init_part1_A_const_82 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[266]); A_arbace_c2j_emit__init_part1_A_const_83 = A_arbace_c2j_emit__init_part1_A_const_pool.A[267]; A_arbace_c2j_emit__init_part1_A_const_84 = A_arbace_c2j_emit__init_part1_A_const_pool.A[268]; A_arbace_c2j_emit__init_part1_A_const_85 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[269]); A_arbace_c2j_emit__init_part1_A_const_86 = A_arbace_c2j_emit__init_part1_A_const_pool.A[270]; A_arbace_c2j_emit__init_part1_A_const_87 = A_arbace_c2j_emit__init_part1_A_const_pool.A[271]; A_arbace_c2j_emit__init_part1_A_const_88 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[272]); A_arbace_c2j_emit__init_part1_A_const_89 = A_arbace_c2j_emit__init_part1_A_const_pool.A[273]; var tmp6 *lang.Var; A_arbace_c2j_emit__init_part0_A_Init(); tmp6 = A_arbace_c2j_emit__init_part0_A_const_124; A_arbace_c2j_emit__init_part1_A_const_90 = tmp6; A_arbace_c2j_emit__init_part1_A_const_91 = A_arbace_c2j_emit__init_part1_A_const_pool.A[274]; A_arbace_c2j_emit__init_part1_A_const_92 = A_arbace_c2j_emit__init_part1_A_const_pool.A[275]; A_arbace_c2j_emit__init_part1_A_const_93 = A_arbace_c2j_emit__init_part1_A_const_pool.A[276]; A_arbace_c2j_emit__init_part1_A_const_94 = A_arbace_c2j_emit__init_part1_A_const_pool.A[277]; A_arbace_c2j_emit__init_part1_A_const_95 = A_arbace_c2j_emit__init_part1_A_const_pool.A[278]; A_arbace_c2j_emit__init_part1_A_const_96 = A_arbace_c2j_emit__init_part1_A_const_pool.A[279]; A_arbace_c2j_emit__init_part1_A_const_97 = A_arbace_c2j_emit__init_part1_A_const_pool.A[280]; A_arbace_c2j_emit__init_part1_A_const_98 = A_arbace_c2j_emit__init_part1_A_const_pool.A[281]; A_arbace_c2j_emit__init_part1_A_const_99 = A_arbace_c2j_emit__init_part1_A_const_pool.A[282]; A_arbace_c2j_emit__init_part1_A_const_100 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[283]); A_arbace_c2j_emit__init_part1_A_const_101 = A_arbace_c2j_emit__init_part1_A_const_pool.A[284]; var tmp7 *lang.Var; A_arbace_c2j_emit__init_part0_A_Init(); tmp7 = A_arbace_c2j_emit__init_part0_A_const_102; A_arbace_c2j_emit__init_part1_A_const_102 = tmp7; A_arbace_c2j_emit__init_part1_A_const_103 = A_arbace_c2j_emit__init_part1_A_const_pool.A[285]; var tmp8 *lang.Var; A_arbace_c2j_emit__init_part0_A_Init(); tmp8 = A_arbace_c2j_emit__init_part0_A_const_104; A_arbace_c2j_emit__init_part1_A_const_104 = tmp8; A_arbace_c2j_emit__init_part1_A_const_105 = A_arbace_c2j_emit__init_part1_A_const_pool.A[286]; var tmp9 *lang.Var; A_arbace_c2j_emit__init_part0_A_Init(); tmp9 = A_arbace_c2j_emit__init_part0_A_const_152; A_arbace_c2j_emit__init_part1_A_const_106 = tmp9; A_arbace_c2j_emit__init_part1_A_const_107 = A_arbace_c2j_emit__init_part1_A_const_pool.A[287]; A_arbace_c2j_emit__init_part1_A_const_108 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[288]); A_arbace_c2j_emit__init_part1_A_const_109 = A_arbace_c2j_emit__init_part1_A_const_pool.A[289]; A_arbace_c2j_emit__init_part1_A_const_110 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[290]); A_arbace_c2j_emit__init_part1_A_const_111 = A_arbace_c2j_emit__init_part1_A_const_pool.A[291]; A_arbace_c2j_emit__init_part1_A_const_112 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[292]); A_arbace_c2j_emit__init_part1_A_const_113 = A_arbace_c2j_emit__init_part1_A_const_pool.A[293]; A_arbace_c2j_emit__init_part1_A_const_114 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[294]); A_arbace_c2j_emit__init_part1_A_const_115 = A_arbace_c2j_emit__init_part1_A_const_pool.A[295]; A_arbace_c2j_emit__init_part1_A_const_116 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[296]); A_arbace_c2j_emit__init_part1_A_const_117 = A_arbace_c2j_emit__init_part1_A_const_pool.A[297]; A_arbace_c2j_emit__init_part1_A_const_118 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[298]); A_arbace_c2j_emit__init_part1_A_const_119 = A_arbace_c2j_emit__init_part1_A_const_pool.A[299]; A_arbace_c2j_emit__init_part1_A_const_120 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[300]); A_arbace_c2j_emit__init_part1_A_const_121 = A_arbace_c2j_emit__init_part1_A_const_pool.A[301]; A_arbace_c2j_emit__init_part1_A_const_122 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[302]); A_arbace_c2j_emit__init_part1_A_const_123 = A_arbace_c2j_emit__init_part1_A_const_pool.A[303]; A_arbace_c2j_emit__init_part1_A_const_124 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[304]); A_arbace_c2j_emit__init_part1_A_const_125 = A_arbace_c2j_emit__init_part1_A_const_pool.A[305]; A_arbace_c2j_emit__init_part1_A_const_126 = A_arbace_c2j_emit__init_part1_A_const_pool.A[306]; A_arbace_c2j_emit__init_part1_A_const_127 = A_arbace_c2j_emit__init_part1_A_const_pool.A[307]; A_arbace_c2j_emit__init_part1_A_const_128 = A_arbace_c2j_emit__init_part1_A_const_pool.A[308]; A_arbace_c2j_emit__init_part1_A_const_129 = A_arbace_c2j_emit__init_part1_A_const_pool.A[309]; A_arbace_c2j_emit__init_part1_A_const_130 = A_arbace_c2j_emit__init_part1_A_const_pool.A[310]; A_arbace_c2j_emit__init_part1_A_const_131 = A_arbace_c2j_emit__init_part1_A_const_pool.A[311]; A_arbace_c2j_emit__init_part1_A_const_132 = A_arbace_c2j_emit__init_part1_A_const_pool.A[312]; A_arbace_c2j_emit__init_part1_A_const_133 = A_arbace_c2j_emit__init_part1_A_const_pool.A[313]; A_arbace_c2j_emit__init_part1_A_const_134 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[314]); A_arbace_c2j_emit__init_part1_A_const_135 = A_arbace_c2j_emit__init_part1_A_const_pool.A[315]; A_arbace_c2j_emit__init_part1_A_const_136 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[316]); A_arbace_c2j_emit__init_part1_A_const_137 = A_arbace_c2j_emit__init_part1_A_const_pool.A[317]; A_arbace_c2j_emit__init_part1_A_const_138 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[318]); A_arbace_c2j_emit__init_part1_A_const_139 = A_arbace_c2j_emit__init_part1_A_const_pool.A[319]; A_arbace_c2j_emit__init_part1_A_const_140 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[320]); A_arbace_c2j_emit__init_part1_A_const_141 = A_arbace_c2j_emit__init_part1_A_const_pool.A[321]; var tmp10 *lang.Var; A_arbace_c2j_emit__init_part0_A_Init(); tmp10 = A_arbace_c2j_emit__init_part0_A_const_108; A_arbace_c2j_emit__init_part1_A_const_142 = tmp10; A_arbace_c2j_emit__init_part1_A_const_143 = A_arbace_c2j_emit__init_part1_A_const_pool.A[322]; var tmp11 *lang.Var; A_arbace_c2j_emit__init_part0_A_Init(); tmp11 = A_arbace_c2j_emit__init_part0_A_const_106; A_arbace_c2j_emit__init_part1_A_const_144 = tmp11; A_arbace_c2j_emit__init_part1_A_const_145 = A_arbace_c2j_emit__init_part1_A_const_pool.A[323]; A_arbace_c2j_emit__init_part1_A_const_146 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[324]); A_arbace_c2j_emit__init_part1_A_const_147 = A_arbace_c2j_emit__init_part1_A_const_pool.A[325]; var tmp12 *lang.Var; A_arbace_c2j_emit__init_part0_A_Init(); tmp12 = A_arbace_c2j_emit__init_part0_A_const_38; A_arbace_c2j_emit__init_part1_A_const_148 = tmp12; A_arbace_c2j_emit__init_part1_A_const_149 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[326]); A_arbace_c2j_emit__init_part1_A_const_150 = A_arbace_c2j_emit__init_part1_A_const_pool.A[327]; A_arbace_c2j_emit__init_part1_A_const_151 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[328]); A_arbace_c2j_emit__init_part1_A_const_152 = A_arbace_c2j_emit__init_part1_A_const_pool.A[329]; A_arbace_c2j_emit__init_part1_A_const_153 = A_arbace_c2j_emit__init_part1_A_const_pool.A[330]; A_arbace_c2j_emit__init_part1_A_const_154 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[331]); A_arbace_c2j_emit__init_part1_A_const_155 = A_arbace_c2j_emit__init_part1_A_const_pool.A[332]; A_arbace_c2j_emit__init_part1_A_const_156 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[333]); A_arbace_c2j_emit__init_part1_A_const_157 = A_arbace_c2j_emit__init_part1_A_const_pool.A[334]; A_arbace_c2j_emit__init_part1_A_const_158 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[335]); A_arbace_c2j_emit__init_part1_A_const_159 = A_arbace_c2j_emit__init_part1_A_const_pool.A[336]; A_arbace_c2j_emit__init_part1_A_const_160 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[337]); A_arbace_c2j_emit__init_part1_A_const_161 = A_arbace_c2j_emit__init_part1_A_const_pool.A[338]; A_arbace_c2j_emit__init_part1_A_const_162 = lang.Var_Cast(A_arbace_c2j_emit__init_part1_A_const_pool.A[339]); A_arbace_c2j_emit__init_part1_A_const_163 = A_arbace_c2j_emit__init_part1_A_const_pool.A[340] }

func A_arbace_c2j_emit__init_part1_A_New() *A_arbace_c2j_emit__init_part1_A { A_arbace_c2j_emit__init_part1_A_Init(); t := &A_arbace_c2j_emit__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_emit__init_part1_A) Ctor() {}

func (t *A_arbace_c2j_emit__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_emit__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_emit__init_part1_A_class }

func (t *A_arbace_c2j_emit__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_emit__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_emit__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_emit__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_emit__init_part1_A); return ok }

func A_arbace_c2j_emit__init_part1_A_Cast(x any) *A_arbace_c2j_emit__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_emit__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_emit__init_part1_A_class)) }; return v }
