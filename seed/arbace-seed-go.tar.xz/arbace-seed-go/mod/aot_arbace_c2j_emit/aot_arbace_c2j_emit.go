//line aot_arbace_c2j_emit.ae:1
package aot_arbace_c2j_emit

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2j_emit_eval31000004_loading__1927001464__auto____31000005_A_New() *A_arbace_c2j_emit_eval31000004_loading__1927001464__auto____31000005_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_eval31000004_loading__1927001464__auto____31000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_emit_eval31000004_loading__1927001464__auto____31000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_emit_eval31000004_loading__1927001464__auto____31000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c2j_emit_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_2); lang.IFn_Cast(A_arbace_c2j_emit_A_const_1.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_3, A_arbace_c2j_emit_A_const_4, A_arbace_c2j_emit_A_const_5); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_232)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_233)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_234)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_235)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_236)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_237)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_238)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_239)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_240)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_241)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_242)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_243)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_244)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_245)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_246)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_247)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c2j_emit_eval31000008_fn__31000009_A_New() *A_arbace_c2j_emit_eval31000008_fn__31000009_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_eval31000008_fn__31000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_emit_eval31000008_fn__31000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_emit_eval31000008_fn__31000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_6.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_10), A_arbace_c2j_emit_A_const_8.GetRawRoot__O(), A_arbace_c2j_emit_A_const_9) }





































func A_arbace_c2j_emit_node_A_New() *A_arbace_c2j_emit_node_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_node_A{}; t.Ctor(); return t }
//line :39:1
func (t *A_arbace_c2j_emit_node_A) Ctor() {}
//line :39:1
func (t *A_arbace_c2j_emit_node_A) Invoke_O_O__O(self, x__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_11.GetRawRoot__O()).Invoke_O__O(x__0)) { var or__1927000174__auto____2 any = jrt.NN(jrt.IdentityHashMap_Cast(A_arbace_c2j_emit_A_const_12.GetRawRoot__O())).Get_O__O(x__0)
		if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var n__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(lang.Compiler_AST_Node_O__IPersistentMap(x__0), A_arbace_c2j_emit_A_const_14, x__0)

			jrt.NN(jrt.IdentityHashMap_Cast(A_arbace_c2j_emit_A_const_12.GetRawRoot__O())).Put_O_O__O(x__0, n__3)
//line :43:1
			return n__3 } } else {
//line :42:1
				return nil
			}
}



func A_arbace_c2j_emit_fail_A_New() *A_arbace_c2j_emit_fail_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_fail_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_c2j_emit_fail_A) Ctor() {}
//line :48:1
func (t *A_arbace_c2j_emit_fail_A) DoInvoke_O_O_O__O(self, msg__0, p__31000013__1 any) any { var vec__31000014__3 any = p__31000013__1; var data__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000014__3, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_15.GetRawRoot__O()); var tmp2 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_248, nil), jrt.RefArrayOf(jrt.Object_class, nil, msg__0)).Ref(); var tmp3 any; var or__1927000174__auto____5 any = data__4; if
												jrt.J2g_Truth(or__1927000174__auto____5) { tmp3 = or__1927000174__auto____5 } else { tmp3 = lang.PersistentArrayMap_EMPTY.Ref() }; /*line :48:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1.Invoke_O_O__O(tmp2, tmp3)))) }





func A_arbace_c2j_emit_destub_A_New() *A_arbace_c2j_emit_destub_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_destub_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_c2j_emit_destub_A) Ctor() {}
//line :54:1
func (t *A_arbace_c2j_emit_destub_A) Invoke_O_O__O(self, n__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_16.GetRawRoot__O()).Invoke_O_O__O(n__0, Lit_38)) { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_17.GetRawRoot__O()).Invoke_O_O__O(n__0, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(Lit_38)).Ref()) } else { return n__0
	} }
func A_arbace_c2j_emit_type_sym_A_New() *A_arbace_c2j_emit_type_sym_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_type_sym_A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_c2j_emit_type_sym_A) Ctor() {}
//line :59:1
func (t *A_arbace_c2j_emit_type_sym_A) Invoke_O_O__O(self, c__0 any) any {



	if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() { var e__2 any = c__0; var n__3 int64 = 0; L1: for {

		if jrt.NN(jrt.Class_Cast(e__2)).IsArray__Z() {
			e__2, n__3 = jrt.NN(jrt.Class_Cast(e__2)).GetComponentType__Class().Ref(), lang.Numbers_Inc_J__J_NoInit(n__3); continue L1 } else {
				return lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(e__2)), lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(n__3).Ref())) } } } else {
					return lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref())) }
//line :59:1
	panic("j2g: unreachable")
}













func A_arbace_c2j_emit_tagged_A_New() *A_arbace_c2j_emit_tagged_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_tagged_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_c2j_emit_tagged_A) Ctor() {}
//line :74:1
func (t *A_arbace_c2j_emit_tagged_A) Invoke_O_O_O__O(self, s__0, c__1 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_22.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_13.GetRawRoot__O(); var tmp3 any = A_arbace_c2j_emit_A_const_23; var tmp4 any; if jrt.Class_InstanceOf(c__1) { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_24.GetRawRoot__O()).Invoke_O__O(c__1)
		if jrt.J2g_Truth(or__1927000174__auto____3) { tmp4 = or__1927000174__auto____3 } else { if jrt.NN(jrt.Class_Cast(c__1)).IsArray__Z() { tmp4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__1)).GetName__String().Ref()) } else { tmp4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(c__1) } } } else {
//line :79:1
			tmp4 = c__1 }; return tmp1.Invoke_O_O_O_O__O(s__0, tmp2, tmp3, tmp4)
}






func A_arbace_c2j_emit_registered_QMARK__A_New() *A_arbace_c2j_emit_registered_QMARK__A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_registered_QMARK__A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_c2j_emit_registered_QMARK__A) Ctor() {}
//line :87:1
func (t *A_arbace_c2j_emit_registered_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var c__2 any; var tmp1 any = A_arbace_c2j_emit_registered_QMARK__fn__31000021_A_New_O(c__0); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c2j_emit_registered_QMARK__fn__31000021_A_fn_class; if
											fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_315, false); A_arbace_c2j_emit_registered_QMARK__fn__31000021_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; c__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var or__1927000174__auto____3 bool = /*line :87:1*/jrt.NN(jrt.Class_Cast(c__2)).IsPrimitive__Z(); if or__1927000174__auto____3 {

		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { var n__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__2)).GetName__String().Ref()); var temp__1927000420__auto____5 any = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_26.GetRawRoot__O()), n__4)

			if lang.Util_Identical_O_O__Z_NoInit(temp__1927000420__auto____5, nil) { var r__6 any; var tmp3 any = A_arbace_c2j_emit_registered_QMARK__fn__31000023_A_New_O(n__4); var tmp4 *jrt.Class
				var fncls__3 /*line :91:1*/*jrt.Class = A_arbace_c2j_emit_registered_QMARK__fn__31000023_A_fn_class

				if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_316, false); A_arbace_c2j_emit_registered_QMARK__fn__31000023_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; r__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()







				lang.IFn_Cast(A_arbace_c2j_emit_A_const_27.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_c2j_emit_A_const_26.GetRawRoot__O(), A_arbace_c2j_emit_A_const_13.GetRawRoot__O(), n__4, r__6)
//line :91:1
				return r__6 } else { var r__6_2 any = temp__1927000420__auto____5; return r__6_2 } } }
//line :88:1
func A_arbace_c2j_emit_registered_QMARK__fn__31000021_A_New_O(p0 any) *A_arbace_c2j_emit_registered_QMARK__fn__31000021_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_registered_QMARK__fn__31000021_A{}; t.Ctor_O(p0); return t }
//line :88:1
func (t *A_arbace_c2j_emit_registered_QMARK__fn__31000021_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :88:1
func (t *A_arbace_c2j_emit_registered_QMARK__fn__31000021_A) Invoke_O__O(self any) any { { var c__1 any; var t_ any = t.F_c; t.F_c = nil; c__1 = t_; L1: for { if jrt.NN(jrt.Class_Cast(c__1)).IsArray__Z() { c__1 = jrt.NN(jrt.Class_Cast(c__1)).GetComponentType__Class().Ref(); continue L1 } else { return c__1 } } }; panic("j2g: unreachable") }




func A_arbace_c2j_emit_registered_QMARK__fn__31000023_A_New_O(p0 any) *A_arbace_c2j_emit_registered_QMARK__fn__31000023_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_registered_QMARK__fn__31000023_A{}; t.Ctor_O(p0); return t }
//line :93:1
func (t *A_arbace_c2j_emit_registered_QMARK__fn__31000023_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :93:1
func (t *A_arbace_c2j_emit_registered_QMARK__fn__31000023_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var k__3 any; var tmp2 any; var t_ any = t.F_n; t.F_n = nil; tmp2 = t_; k__3 = jrt.Class_ForName_String_Z_ClassLoader__Class(jrt.String_Cast(tmp2), jrt.NN(jrt.Boolean_FALSE).BooleanValue__Z(), nil).Ref(); var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_11.GetRawRoot__O()).Invoke_O__O(k__3)
											if jrt.J2g_Truth(and__1927000168__auto____4) {

		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_registered_QMARK__fn__31000023_fn__31000024_A_New_O(k__3); var tmp5 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_c2j_emit_registered_QMARK__fn__31000023_fn__31000024_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_317, false); A_arbace_c2j_emit_registered_QMARK__fn__31000023_fn__31000024_A_fn_class = fncls__2d; tmp5 = fncls__2d } else { tmp5 = fncls__2 }; tmp1 = tmp3.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil).Invoke__O()) } else {
//line :94:1
			tmp1 = and__1927000168__auto____4 } }; return nil }(); if /*line :93:1*/ tmp6 != nil { if true { var ___3 jrt.Throwable_I = tmp6; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }


func A_arbace_c2j_emit_registered_QMARK__fn__31000023_fn__31000024_A_New_O(p0 any) *A_arbace_c2j_emit_registered_QMARK__fn__31000023_fn__31000024_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_registered_QMARK__fn__31000023_fn__31000024_A{}; t.Ctor_O(p0); return t }
//line :96:1
func (t *A_arbace_c2j_emit_registered_QMARK__fn__31000023_fn__31000024_A) Ctor_O(c__k any) { t.F_k = c__k }
//line :96:1
func (t *A_arbace_c2j_emit_registered_QMARK__fn__31000023_fn__31000024_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *jrt.String = Lit_232; var tmp3 *jrt.String = Lit_318; var tmp4 any; var t_ any = t.F_k
													t.F_k = nil; tmp4 = t_
//line :96:1
	tmp1 = lang.Reflector_InvokeStaticMethod_String_String_O1__O(tmp2, tmp3, lang.RT_Object_array_O__O1_NoInit(lang.Tuple_Create_O__IPersistentVector(tmp4))) }; return nil }(); if tmp5 != nil { if true { var ___3 jrt.Throwable_I = tmp5; _ = ___3; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }







func A_arbace_c2j_emit_runtime_class_QMARK__A_New() *A_arbace_c2j_emit_runtime_class_QMARK__A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_runtime_class_QMARK__A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_c2j_emit_runtime_class_QMARK__A) Ctor() {}
//line :104:1
func (t *A_arbace_c2j_emit_runtime_class_QMARK__A) Invoke_O_O_O__O(self, c__0, ctx__1 any) any { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_30.Invoke_O__O(ctx__1)), lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref())); if





	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_31.GetRawRoot__O()).Invoke_O__O(c__0)); if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {




		if jrt.NN(jrt.Class_Cast(lang.IFn_Cast(A_arbace_c2j_emit_A_const_29.GetRawRoot__O()).Invoke_O__O(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_321).Ref()))).IsAssignableFrom_Class__Z(jrt.Class_Cast(c__0)) { var temp__1927000414__auto____5 any = A_arbace_c2j_emit_A_const_32.Invoke_O__O(ctx__1)
			if jrt.J2g_Truth(temp__1927000414__auto____5) { var ps__6 any = temp__1927000414__auto____5; lang.IFn_Cast(A_arbace_c2j_emit_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(ps__6, A_arbace_c2j_emit_A_const_8.GetRawRoot__O(), c__0) }
//line :115:1
			return jrt.Boolean_TRUE.Ref() } else { return nil } } } }



func A_arbace_c2j_emit_public_QMARK__A_New() *A_arbace_c2j_emit_public_QMARK__A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_public_QMARK__A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_c2j_emit_public_QMARK__A) Ctor() {}
//line :119:1
func (t *A_arbace_c2j_emit_public_QMARK__A) Invoke_O_O__O(self, c__0 any) any {
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Modifier_IsPublic_I__Z(jrt.NN(jrt.Class_Cast(c__0)).GetModifiers__I())).Ref()
}



func A_arbace_c2j_emit_top_name_A_New() *A_arbace_c2j_emit_top_name_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_top_name_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_c2j_emit_top_name_A) Ctor() {}
//line :125:1
func (t *A_arbace_c2j_emit_top_name_A) Invoke_O_O__O(self, n__0 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__0)).IndexOf_String__I(Lit_17); if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__2)) { return n__0 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_33; return tmp1.Invoke_O_O_O__O(n__0, tmp2, jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref()) } }

func A_arbace_c2j_emit_pool_A_New() *A_arbace_c2j_emit_pool_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_c2j_emit_pool_A) Ctor() {}
//line :127:1
func (t *A_arbace_c2j_emit_pool_A) Invoke_O_O_O__O(self, ctx__0, top__1 any) any { var pools__3 any = A_arbace_c2j_emit_A_const_34.Invoke_O__O(ctx__0); var or__1927000174__auto____4 any = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(pools__3), top__1); if




	jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_27.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_pool_fn__31000031_A_New_O(top__1); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_c2j_emit_pool_fn__31000031_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_300, false); A_arbace_c2j_emit_pool_fn__31000031_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O_O__O(pools__3, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)), top__1) } }
//line :133:1
func A_arbace_c2j_emit_pool_fn__31000031_A_New_O(p0 any) *A_arbace_c2j_emit_pool_fn__31000031_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_fn__31000031_A{}; t.Ctor_O(p0); return t }
//line :133:1
func (t *A_arbace_c2j_emit_pool_fn__31000031_A) Ctor_O(c__top any) { t.F_top = c__top }
//line :133:1
func (t *A_arbace_c2j_emit_pool_fn__31000031_A) Invoke_O_O__O(self, m__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(m__1, t.F_top)) { return m__1 } else {
											var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()); var tmp2 any = t.F_top; var tmp3 any = A_arbace_c2j_emit_A_const_36; var tmp4 any = t.F_top; var tmp5 any = A_arbace_c2j_emit_A_const_37; var tmp6 any = lang.PersistentVector_EMPTY.Ref(); var tmp7 any = A_arbace_c2j_emit_A_const_38; return tmp1.Invoke_O_O_O__O(m__1, tmp2, lang.IFn_Cast(A_arbace_c2j_emit_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, tmp7, jrt.IdentityHashMap_New(), A_arbace_c2j_emit_A_const_39, Lit_209)))) } }


func A_arbace_c2j_emit_const_field_A_New() *A_arbace_c2j_emit_const_field_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_const_field_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_c2j_emit_const_field_A) Ctor() {}
//line :137:1
func (t *A_arbace_c2j_emit_const_field_A) Invoke_O_O_O_O__O(self, ctx__0, v__1, ctype__2 any) any { var cls__4 any = A_arbace_c2j_emit_A_const_40.Invoke_O__O(ctx__0); var tmp1 *lang.Keyword = A_arbace_c2j_emit_A_const_38; var m__5 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(cls__4)); var tmp2 *lang.Keyword = A_arbace_c2j_emit_A_const_41; var prev__6 any = tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(cls__4)); var or__1927000174__auto____7 any = jrt.NN(jrt.IdentityHashMap_Cast(m__5)).Get_O__O(v__1); if









	jrt.J2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var tmp3 *lang.Keyword = A_arbace_c2j_emit_A_const_37; var n__8 int32 = lang.RT_Count_O__I_NoInit(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(cls__4))); var tmp4 *lang.Keyword = A_arbace_c2j_emit_A_const_39; var s__9 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(cls__4)), nil, jrt.Integer_ValueOf_I__Integer_NoInit(n__8).Ref())).Ref()); var alias__10 any




		if jrt.J2g_Truth(prev__6) { alias__10 = jrt.NN(jrt.IdentityHashMap_Cast(prev__6)).Get_O__O(v__1) } else { alias__10 = nil }
		jrt.NN(jrt.IdentityHashMap_Cast(m__5)).Put_O_O__O(v__1, s__9)
		var tmp5 any; var and__1927000168__auto____11 any = prev__6; if jrt.J2g_Truth(and__1927000168__auto____11) { tmp5 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(alias__10) } else { tmp5 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp5) { var tmp6 *lang.Keyword = A_arbace_c2j_emit_A_const_36; jrt.NN(jrt.IdentityHashMap_Cast(prev__6)).Put_O_O__O(v__1, lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(cls__4)), lang.IFn_Cast(A_arbace_c2j_emit_A_const_42.GetRawRoot__O()).Invoke_O__O(s__9))) }
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_27.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_emit_A_const_43.GetRawRoot__O(); var tmp9 any = A_arbace_c2j_emit_A_const_37; tmp7.Invoke_O_O_O_O_O__O(cls__4, tmp8, tmp9, A_arbace_c2j_emit_A_const_8.GetRawRoot__O(), lang.Tuple_Create_O_O_O_O__IPersistentVector(s__9, ctype__2, v__1, alias__10))
//line :147:1
		return s__9 } }












func A_arbace_c2j_emit_emit_list_array_A_New() *A_arbace_c2j_emit_emit_list_array_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_list_array_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_c2j_emit_emit_list_array_A) Ctor() {}
//line :160:1
func (t *A_arbace_c2j_emit_emit_list_array_A) Invoke_O_O_O__O(self, ctx__0, xs__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_45; var tmp3 any = A_arbace_c2j_emit_A_const_46; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_emit_list_array_fn__31000036_A_New_O(ctx__0); var tmp6 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c2j_emit_emit_list_array_fn__31000036_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_192, false); A_arbace_c2j_emit_emit_list_array_fn__31000036_A_fn_class = fncls__5d; tmp6 = fncls__5d } else { tmp6 = fncls__5 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), xs__1)) }
//line :161:1
func A_arbace_c2j_emit_emit_list_array_fn__31000036_A_New_O(p0 any) *A_arbace_c2j_emit_emit_list_array_fn__31000036_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_list_array_fn__31000036_A{}; t.Ctor_O(p0); return t }
//line :161:1
func (t *A_arbace_c2j_emit_emit_list_array_fn__31000036_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :161:1
func (t *A_arbace_c2j_emit_emit_list_array_fn__31000036_A) Invoke_O_O__O(self, p1__31000035_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_48.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__31000035_SHARP___1) }

func A_arbace_c2j_emit_char_form_A_New() *A_arbace_c2j_emit_char_form_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_char_form_A{}; t.Ctor(); return t }
//line :163:1
func (t *A_arbace_c2j_emit_char_form_A) Ctor() {}
//line :163:1
func (t *A_arbace_c2j_emit_char_form_A) Invoke_O_O__O(self, c__0 any) any { var i__2 int32 = lang.RT_IntCast_C__I_NoInit(jrt.NN(jrt.Character_Cast(c__0)).CharValue__C()); var tmp1 any; var and__1927000168__auto____3 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(i__2), 33); if and__1927000168__auto____3 {

	var and__1927000168__auto____4 bool = lang.Numbers_Lte_J_J__Z_NoInit(int64(i__2), 126); if and__1927000168__auto____4 { tmp1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_49.GetRawRoot__O()).Invoke_O_O__O(c__0, A_arbace_c2j_emit_A_const_50) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() }; if jrt.J2g_Truth(tmp1) { return c__0 } else {

		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_A_const_51; return tmp2.Invoke_O_O__O(tmp3, jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref()) } }

func A_arbace_c2j_emit_double_form_A_New() *A_arbace_c2j_emit_double_form_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_double_form_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_c2j_emit_double_form_A) Ctor() {}
//line :169:1
func (t *A_arbace_c2j_emit_double_form_A) Invoke_O_O__O(self, p_d__0 any) any { var d__0 float64 = lang.RT_DoubleCast_O__D_NoInit(p_d__0); var tmp1 bool; var or__1927000174__auto____2 bool = jrt.Double_IsNaN_D__Z_NoInit(d__0); if or__1927000174__auto____2 {
										tmp1 = or__1927000174__auto____2 } else { tmp1 = jrt.Double_IsInfinite_D__Z_NoInit(d__0) }; if tmp1 {
											var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_A_const_52; return tmp2.Invoke_O_O__O(tmp3, jrt.Long_ValueOf_J__Long_NoInit(jrt.Double_DoubleToRawLongBits_D__J_NoInit(d__0)).Ref()) } else {
//line :170:1
			return jrt.Double_ValueOf_D__Double_NoInit(d__0).Ref() } }



func A_arbace_c2j_emit_emit_value_A_New() *A_arbace_c2j_emit_emit_value_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_value_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_c2j_emit_emit_value_A) Ctor() {}
//line :174:1
func (t *A_arbace_c2j_emit_emit_value_A) Invoke_O_O_O__O(self, ctx__0, v__1 any) any { var vec__31000042__3 any; if



	lang.Util_Identical_O_O__Z_NoInit(v__1, nil) { vec__31000042__3 = A_arbace_c2j_emit_A_const_53 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(v__1)) { vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(v__1, jrt.Boolean_TRUE.Ref()) } else { if jrt.Boolean_InstanceOf(v__1) { var tmp1 any


		if jrt.J2g_Truth(v__1) { tmp1 = A_arbace_c2j_emit_A_const_67 } else { tmp1 = A_arbace_c2j_emit_A_const_68 }
//line :178:1
		vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp1, jrt.Boolean_TRUE.Ref()) } else { if jrt.Integer_InstanceOf(v__1) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_A_const_69; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_70; vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__1)).Ref())), jrt.Boolean_TRUE.Ref()) } else { if jrt.Long_InstanceOf(v__1) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp7 any = A_arbace_c2j_emit_A_const_71; vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp6.Invoke_O_O__O(tmp7, jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__1)).Ref()), jrt.Boolean_TRUE.Ref()) } else { if jrt.Double_InstanceOf(v__1) { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_emit_A_const_72; vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp8.Invoke_O_O__O(tmp9, lang.IFn_Cast(A_arbace_c2j_emit_A_const_73.GetRawRoot__O()).Invoke_O__O(v__1)), jrt.Boolean_TRUE.Ref()) } else { if jrt.Character_InstanceOf(v__1) { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_emit_A_const_74; vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp10.Invoke_O_O__O(tmp11, lang.IFn_Cast(A_arbace_c2j_emit_A_const_75.GetRawRoot__O()).Invoke_O__O(v__1)), jrt.Boolean_TRUE.Ref()) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(v__1)) { var tmp12 any







			if jrt.NN(jrt.Class_Cast(v__1)).IsPrimitive__Z() {
				tmp12 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Class_Cast(lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, jrt.Boolean_TYPE.Ref(), A_arbace_c2j_emit_A_const_76, jrt.Byte_TYPE.Ref(), A_arbace_c2j_emit_A_const_77, jrt.Character_TYPE.Ref(), A_arbace_c2j_emit_A_const_78, jrt.Double_TYPE.Ref(), A_arbace_c2j_emit_A_const_79, jrt.Float_TYPE.Ref(), A_arbace_c2j_emit_A_const_80, jrt.Integer_TYPE.Ref(), A_arbace_c2j_emit_A_const_81, jrt.Long_TYPE.Ref(), A_arbace_c2j_emit_A_const_82, jrt.Short_TYPE.Ref(), A_arbace_c2j_emit_A_const_83))).Invoke_O__O(v__1))).GetName__String().Ref(), Lit_225) } else {



					var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp14 any = A_arbace_c2j_emit_A_const_84; tmp12 = tmp13.Invoke_O_O__O(tmp14, lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(v__1)).GetName__String().Ref())) }
//line :178:1
			vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, jrt.Boolean_TRUE.Ref()) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_56.GetRawRoot__O()).Invoke_O__O(v__1)) { vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_87, A_arbace_c2j_emit_A_const_88), lang.IFn_Cast(A_arbace_c2j_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(v__1), lang.IFn_Cast(A_arbace_c2j_emit_A_const_42.GetRawRoot__O()).Invoke_O__O(v__1)), jrt.Boolean_TRUE.Ref()) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_57.GetRawRoot__O()).Invoke_O__O(v__1)) { vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_89, A_arbace_c2j_emit_A_const_90), lang.IFn_Cast(A_arbace_c2j_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(v__1), lang.IFn_Cast(A_arbace_c2j_emit_A_const_42.GetRawRoot__O()).Invoke_O__O(v__1)), jrt.Boolean_TRUE.Ref()) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_58.GetRawRoot__O()).Invoke_O__O(v__1)) { vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_91, A_arbace_c2j_emit_A_const_92), lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.Var_Cast(v__1).F_ns.F_name.Ref()), lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.Var_Cast(v__1).F_sym.Ref())), jrt.Boolean_TRUE.Ref()) } else { if lang.Namespace_InstanceOf(v__1) { vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_93, A_arbace_c2j_emit_A_const_94), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_95, A_arbace_c2j_emit_A_const_96), nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.Namespace_Cast(v__1).F_name.Ref()))), jrt.Boolean_FALSE.Ref()) } else { if lang.IRecord_InstanceOf(v__1) {



























				vec__31000042__3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_226, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_97.GetRawRoot__O()).Invoke_O__O(v__1))).Ref()) } else {
//line :178:1
					if lang.IType_InstanceOf(v__1) {




























						vec__31000042__3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_227, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_97.GetRawRoot__O()).Invoke_O__O(v__1))).Ref()) } else {
//line :178:1
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_60.GetRawRoot__O()).Invoke_O__O(v__1)) { vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_99, A_arbace_c2j_emit_A_const_100), lang.IFn_Cast(A_arbace_c2j_emit_A_const_98.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_29.GetRawRoot__O(), v__1))), jrt.Boolean_TRUE.Ref()) } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_61.GetRawRoot__O()).Invoke_O__O(v__1)) { var tmp15 any
































								if lang.Numbers_Lte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(v__1)), 6) {
									var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()); var tmp18 any = A_arbace_c2j_emit_A_const_104; var tmp19 any = A_arbace_c2j_emit_A_const_105; var tmp20 any = tmp17.Invoke_O_O__O(tmp18, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_107.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(v__1)).Ref(), A_arbace_c2j_emit_A_const_108))))); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp22 any = A_arbace_c2j_emit_emit_value_fn__31000045_A_New_O(ctx__0); var tmp23 *jrt.Class
									var fncls__7 /*line :212:1*/*jrt.Class = A_arbace_c2j_emit_emit_value_fn__31000045_A_fn_class

									if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_228, false); A_arbace_c2j_emit_emit_value_fn__31000045_A_fn_class = fncls__7d; tmp23 = fncls__7d } else { tmp23 = fncls__7 }
//line :212:1
									tmp15 = tmp16.Invoke_O_O__O(tmp20, tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), v__1)) } else {


										tmp15 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_109, A_arbace_c2j_emit_A_const_110), lang.IFn_Cast(A_arbace_c2j_emit_A_const_98.GetRawRoot__O()).Invoke_O_O__O(ctx__0, v__1)) }
//line :178:1
								vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp15, jrt.Boolean_TRUE.Ref()) } else { if lang.PersistentHashSet_InstanceOf(v__1) { var tmp24 any







































									if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_111.GetRawRoot__O()).Invoke_O__O(v__1)) { tmp24 = A_arbace_c2j_emit_A_const_112 } else {

										tmp24 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_113, A_arbace_c2j_emit_A_const_114), lang.IFn_Cast(A_arbace_c2j_emit_A_const_98.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(v__1))) }
//line :178:1
									vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(tmp24, jrt.Boolean_TRUE.Ref()) } else { var tmp25 any; var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_62.GetRawRoot__O()).Invoke_O__O(v__1)













































										if jrt.J2g_Truth(or__1927000174__auto____3) { tmp25 = or__1927000174__auto____3 } else { tmp25 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_63.GetRawRoot__O()).Invoke_O__O(v__1) }
//line :178:1
										if jrt.J2g_Truth(tmp25) { vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_116, A_arbace_c2j_emit_A_const_117), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_118, A_arbace_c2j_emit_A_const_119), lang.IFn_Cast(A_arbace_c2j_emit_A_const_98.GetRawRoot__O()).Invoke_O_O__O(ctx__0, v__1))), jrt.Boolean_TRUE.Ref()) } else { if jrt.Pattern_InstanceOf(v__1) { vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_120, A_arbace_c2j_emit_A_const_121), lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(v__1)), jrt.Boolean_TRUE.Ref()) } else { if A_arbace_c2j_emit_A_const_64 != nil { var s__3 any






















































											lang.IFn_Cast(A_arbace_c2j_emit_A_const_122.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_123.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_124, jrt.Boolean_TRUE.Ref())); var tmp26 any = A_arbace_c2j_emit_emit_value_fn__31000047_A_New_O(v__1); var tmp27 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_c2j_emit_emit_value_fn__31000047_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_229, false); A_arbace_c2j_emit_emit_value_fn__31000047_A_fn_class = fncls__6d; tmp27 = fncls__6d } else { tmp27 = fncls__6 }; s__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil).Invoke__O()
											var tmp28 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_111.GetRawRoot__O()).Invoke_O__O(s__3); if jrt.J2g_Truth(or__1927000174__auto____4) { tmp28 = or__1927000174__auto____4 } else { tmp28 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_16.GetRawRoot__O()).Invoke_O_O__O(s__3, Lit_230) }; if jrt.J2g_Truth(tmp28) {
												lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_231, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__3)).Ref()) }
//line :178:1
											vec__31000042__3 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_125, A_arbace_c2j_emit_A_const_126), s__3), jrt.Boolean_FALSE.Ref()) } else { vec__31000042__3 = nil } } } } } } } } } } } } } } } } } } } }; var form__4 any = /*line :174:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__31000042__3, lang.RT_IntCast_J__I_NoInit(0), nil); var partial_QMARK___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000042__3, lang.RT_IntCast_J__I_NoInit(1), nil); var m__6 any; var tmp29 any; var and__1927000168__auto____6 any = partial_QMARK___5; if






























































	jrt.J2g_Truth(and__1927000168__auto____6) { tmp29 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.IObj_InstanceOf(v__1)).Ref() } else { tmp29 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp29) { m__6 = lang.RT_Meta_O__IPersistentMap_NoInit(v__1) } else { m__6 = nil }; if
	lang.Numbers_IsPos_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(m__6))) {
		var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp31 any = A_arbace_c2j_emit_A_const_127; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp33 any = A_arbace_c2j_emit_A_const_130; var tmp34 any = A_arbace_c2j_emit_A_const_131; return tmp30.Invoke_O_O_O__O(tmp31, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_128, A_arbace_c2j_emit_A_const_129, form__4), tmp32.Invoke_O_O_O__O(tmp33, tmp34, lang.IFn_Cast(A_arbace_c2j_emit_A_const_48.GetRawRoot__O()).Invoke_O_O__O(ctx__0, m__6))) } else {
//line :238:1
			return form__4 } }
//line :214:1
func A_arbace_c2j_emit_emit_value_fn__31000045_A_New_O(p0 any) *A_arbace_c2j_emit_emit_value_fn__31000045_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_value_fn__31000045_A{}; t.Ctor_O(p0); return t }
//line :214:1
func (t *A_arbace_c2j_emit_emit_value_fn__31000045_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :214:1
func (t *A_arbace_c2j_emit_emit_value_fn__31000045_A) Invoke_O_O__O(self, p1__31000041_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_48.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__31000041_SHARP___1) }


















func A_arbace_c2j_emit_emit_value_fn__31000047_A_New_O(p0 any) *A_arbace_c2j_emit_emit_value_fn__31000047_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_value_fn__31000047_A{}; t.Ctor_O(p0); return t }
//line :233:1
func (t *A_arbace_c2j_emit_emit_value_fn__31000047_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :233:1
func (t *A_arbace_c2j_emit_emit_value_fn__31000047_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_65.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_v; t.F_v = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_c2j_emit_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }
















func A_arbace_c2j_emit_pool_kind_A_New() *A_arbace_c2j_emit_pool_kind_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_kind_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_c2j_emit_pool_kind_A) Ctor() {}
//line :250:1
func (t *A_arbace_c2j_emit_pool_kind_A) Invoke_O_O__O(self, v__0 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(v__0, nil) { return A_arbace_c2j_emit_A_const_132 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_c2j_emit_A_const_133 } else { if jrt.Boolean_InstanceOf(v__0) { return A_arbace_c2j_emit_A_const_134 } else { if jrt.Integer_InstanceOf(v__0) { return A_arbace_c2j_emit_A_const_135 } else { if jrt.Long_InstanceOf(v__0) { return A_arbace_c2j_emit_A_const_136 } else { if jrt.Double_InstanceOf(v__0) { return A_arbace_c2j_emit_A_const_137 } else { if jrt.Character_InstanceOf(v__0) { return A_arbace_c2j_emit_A_const_138 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_c2j_emit_A_const_139 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_56.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_c2j_emit_A_const_140 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_57.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_c2j_emit_A_const_141 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_58.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_c2j_emit_A_const_142 } else { if lang.Namespace_InstanceOf(v__0) { return A_arbace_c2j_emit_A_const_143 } else { if lang.IRecord_InstanceOf(v__0) {












		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_226, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_97.GetRawRoot__O()).Invoke_O__O(v__0))).Ref()) } else {
//line :253:1
			if lang.IType_InstanceOf(v__0) {













				return lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_227, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_97.GetRawRoot__O()).Invoke_O__O(v__0))).Ref()) } else {
//line :253:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_60.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_c2j_emit_A_const_144 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_61.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_c2j_emit_A_const_145 } else { if lang.PersistentHashSet_InstanceOf(v__0) { return A_arbace_c2j_emit_A_const_146 } else { var tmp1 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_62.GetRawRoot__O()).Invoke_O__O(v__0)

















						if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_63.GetRawRoot__O()).Invoke_O__O(v__0) }
//line :253:1
						if jrt.J2g_Truth(tmp1) { return A_arbace_c2j_emit_A_const_147 } else { if jrt.Pattern_InstanceOf(v__0) { return A_arbace_c2j_emit_A_const_148 } else { if A_arbace_c2j_emit_A_const_64 != nil { return A_arbace_c2j_emit_A_const_149 } else { return nil
						}
						}
						}
					}
					}
					}
				}
		}
	}
	}
	}
	}
	}
	}
	}
	}
	}
	}
	}
	}
}




func A_arbace_c2j_emit_pool_shared_QMARK__A_New() *A_arbace_c2j_emit_pool_shared_QMARK__A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_shared_QMARK__A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_c2j_emit_pool_shared_QMARK__A) Ctor() {}
//line :279:1
func (t *A_arbace_c2j_emit_pool_shared_QMARK__A) Invoke_O_O__O(self, v__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_57.GetRawRoot__O()).Invoke_O__O(v__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_56.GetRawRoot__O()).Invoke_O__O(v__0); if jrt.J2g_Truth(and__1927000168__auto____3) { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_111.GetRawRoot__O()).Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__0)) } else { return and__1927000168__auto____3 } } }

func A_arbace_c2j_emit_pool_parts_A_New() *A_arbace_c2j_emit_pool_parts_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_parts_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_c2j_emit_pool_parts_A) Ctor() {}
//line :284:1
func (t *A_arbace_c2j_emit_pool_parts_A) Invoke_O_O__O(self, v__0 any) any { var k__2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_150.GetRawRoot__O()).Invoke_O__O(v__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp2 any; var G__31000052__3_ any = k__2; L1:



switch { default: switch lang.Util_Hash_O__I_NoInit(G__31000052__3_) >> 5 & 3 { case 0: if any(G__31000052__3_) == any(A_arbace_c2j_emit_A_const_144) {
	tmp2 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_29.GetRawRoot__O(), v__0)
//line :288:1
	break L1 }; case 1: if any(G__31000052__3_) == any(A_arbace_c2j_emit_A_const_147) {

		tmp2 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(v__0)
//line :288:1
		break L1 }; case 2: if any(G__31000052__3_) == any(A_arbace_c2j_emit_A_const_145) {

			tmp2 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(v__0)
//line :288:1
			break L1 }; case 3: if any(G__31000052__3_) == any(A_arbace_c2j_emit_A_const_146) {

				tmp2 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(v__0)
//line :288:1
				break L1 }; default:}; tmp2 = nil}; var tmp3 any = tmp2; var tmp4 lang.IPersistentVector; var tmp5 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_152.GetRawRoot__O(), k__2); if



	jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.IObj_InstanceOf(v__0); if and__1927000168__auto____4 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsPos_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(lang.RT_Meta_O__IPersistentMap_NoInit(v__0))))).Ref() } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { tmp5 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp5) { tmp4 = lang.Tuple_Create_O__IPersistentVector(lang.RT_Meta_O__IPersistentMap_NoInit(v__0)) } else { tmp4 = nil }; return /*line :288:1*/ tmp1.Invoke_O_O__O(tmp3, tmp4) }






func A_arbace_c2j_emit_pool_str_A_New() *A_arbace_c2j_emit_pool_str_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_str_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_c2j_emit_pool_str_A) Ctor() {}
//line :295:1
func (t *A_arbace_c2j_emit_pool_str_A) Invoke_O_O_O__O(self, sb__0, s__1 any) any {
	return jrt.NN(jrt.NN(jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_I__StringBuilder(jrt.NN(jrt.String_Cast(s__1)).Length__I())).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_153)).Append_String__StringBuilder(jrt.String_Cast(s__1)).Ref()
}
func A_arbace_c2j_emit_pool_encode_A_New() *A_arbace_c2j_emit_pool_encode_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_encode_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_c2j_emit_pool_encode_A) Ctor() {}
//line :298:1
func (t *A_arbace_c2j_emit_pool_encode_A) Invoke_O_O_O_O__O(self, sb__0, shared__1, v__2 any) any { var temp__1927000408__auto____4 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(v__2); if



	jrt.J2g_Truth(and__1927000168__auto____4) { temp__1927000408__auto____4 = lang.RT_Get_O_O__O_NoInit(shared__1, v__2) } else { temp__1927000408__auto____4 = and__1927000168__auto____4 }; if jrt.J2g_Truth(temp__1927000408__auto____4) { var i__5 any = temp__1927000408__auto____4
		return jrt.NN(jrt.NN(jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_155)).Append_J__StringBuilder(lang.RT_LongCast_O__J_NoInit(i__5))).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_153).Ref() } else {
//line :302:1
			var k__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_150.GetRawRoot__O()).Invoke_O__O(v__2); var num__6 any; var tmp1 any = A_arbace_c2j_emit_pool_encode_num__31000055_A_New_O(sb__0); var tmp2 *jrt.Class
			var fncls__9 /*line :302:1*/*jrt.Class = A_arbace_c2j_emit_pool_encode_num__31000055_A_fn_class


			if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_301, false); A_arbace_c2j_emit_pool_encode_num__31000055_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; num__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :302:1
			var arr__7 any; var tmp3 any = A_arbace_c2j_emit_pool_encode_arr__31000057_A_New_O_O(shared__1, sb__0); var tmp4 *jrt.Class
			var fncls__10 /*line :302:1*/*jrt.Class = A_arbace_c2j_emit_pool_encode_arr__31000057_A_fn_class



			if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_302, false); A_arbace_c2j_emit_pool_encode_arr__31000057_A_fn_class = fncls__10d; tmp4 = fncls__10d } else { tmp4 = fncls__10 }; arr__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
//line :302:1
			var m__8 any; var tmp5 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_152.GetRawRoot__O(), k__5)





			if jrt.J2g_Truth(and__1927000168__auto____8) { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.IObj_InstanceOf(v__2)).Ref() } else { tmp5 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp5) { m__8 = lang.RT_Meta_O__IPersistentMap_NoInit(v__2) } else { m__8 = nil }
//line :302:1
			var m_QMARK___9 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(m__8)))







			if m_QMARK___9 { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_162) }
//line :302:1
			var G__31000063__10_ any = k__5








		L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__31000063__10_) >> 4 & 63 { case 1: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_142) {


















			jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_167)
			lang.IFn_Cast(A_arbace_c2j_emit_A_const_163.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.Var_Cast(v__2).F_ns.F_name.Ref()))
			lang.IFn_Cast(A_arbace_c2j_emit_A_const_163.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.Var_Cast(v__2).F_sym.Ref()))
//line :311:1
			break L1 }; case 2: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_132) {
				jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_164)
//line :311:1
				break L1 }; case 5: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_141) {















					jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_168)
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(v__2)) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_169); lang.IFn_Cast(A_arbace_c2j_emit_A_const_163.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(v__2)) } else { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_164) }
					lang.IFn_Cast(A_arbace_c2j_emit_A_const_163.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_42.GetRawRoot__O()).Invoke_O__O(v__2))
//line :311:1
					break L1 }; case 10: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_134) {


						var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__0); var tmp7 any; if jrt.J2g_Truth(v__2) { tmp7 = A_arbace_c2j_emit_A_const_165 } else { tmp7 = A_arbace_c2j_emit_A_const_166 }; jrt.NN(tmp6).Append_O__StringBuilder(tmp7)
//line :311:1
						break L1 }; case 12: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_148) {


























							jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_170); lang.IFn_Cast(A_arbace_c2j_emit_A_const_163.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(v__2))
//line :311:1
							break L1 }; case 15: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_137) {





								var tmp8 lang.IFn = lang.IFn_Cast(num__6); var tmp9 any = A_arbace_c2j_emit_A_const_171; tmp8.Invoke_O_O__O(tmp9, jrt.Long_ValueOf_J__Long_NoInit(jrt.Double_DoubleToRawLongBits_D__J_NoInit(lang.RT_DoubleCast_O__D_NoInit(v__2))).Ref())
//line :311:1
								break L1 }; case 16: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_144) {






















									var tmp10 lang.IFn = lang.IFn_Cast(arr__7); var tmp11 any = A_arbace_c2j_emit_A_const_172; tmp10.Invoke_O_O__O(tmp11, lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_29.GetRawRoot__O(), v__2)))
//line :311:1
									break L1 }; case 17: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_138) {






										var tmp12 lang.IFn = lang.IFn_Cast(num__6); var tmp13 any = A_arbace_c2j_emit_A_const_182; tmp12.Invoke_O_O__O(tmp13, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_C__I_NoInit(jrt.NN(jrt.Character_Cast(v__2)).CharValue__C())).Ref())
//line :311:1
										break L1 }; case 18: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_139) {







											if jrt.NN(jrt.Class_Cast(v__2)).IsPrimitive__Z() {

												jrt.NN(jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_173)).Append_O__StringBuilder(lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, jrt.Void_TYPE.Ref(), A_arbace_c2j_emit_A_const_174, jrt.Double_TYPE.Ref(), A_arbace_c2j_emit_A_const_175, jrt.Character_TYPE.Ref(), A_arbace_c2j_emit_A_const_176, jrt.Byte_TYPE.Ref(), A_arbace_c2j_emit_A_const_177, jrt.Boolean_TYPE.Ref(), A_arbace_c2j_emit_A_const_178, jrt.Float_TYPE.Ref(), A_arbace_c2j_emit_A_const_166, jrt.Long_TYPE.Ref(), A_arbace_c2j_emit_A_const_179, jrt.Short_TYPE.Ref(), A_arbace_c2j_emit_A_const_180, jrt.Integer_TYPE.Ref(), A_arbace_c2j_emit_A_const_181))).Invoke_O__O(v__2)) } else {

													jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_176); lang.IFn_Cast(A_arbace_c2j_emit_A_const_163.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(v__2)).GetName__String().Ref())) }
//line :311:1
											break L1 }; case 20: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_145) {























												var tmp14 lang.IFn = lang.IFn_Cast(arr__7); var tmp15 any = A_arbace_c2j_emit_A_const_174; tmp14.Invoke_O_O__O(tmp15, lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(v__2))
//line :311:1
												break L1 }; case 22: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_143) {





















													jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_183); lang.IFn_Cast(A_arbace_c2j_emit_A_const_163.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.Namespace_Cast(v__2).F_name.Ref()))
//line :311:1
													break L1 }; case 28: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_149) { var s__11 any



























														lang.IFn_Cast(A_arbace_c2j_emit_A_const_122.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_123.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_124, jrt.Boolean_TRUE.Ref())); var tmp16 any = A_arbace_c2j_emit_pool_encode_fn__31000064_A_New_O(v__2); var tmp17 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_c2j_emit_pool_encode_fn__31000064_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_303, false); A_arbace_c2j_emit_pool_encode_fn__31000064_A_fn_class = fncls__12d; tmp17 = fncls__12d } else { tmp17 = fncls__12 }; s__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil).Invoke__O()
														var tmp18 any; var or__1927000174__auto____12 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_111.GetRawRoot__O()).Invoke_O__O(s__11); if jrt.J2g_Truth(or__1927000174__auto____12) { tmp18 = or__1927000174__auto____12 } else { tmp18 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_16.GetRawRoot__O()).Invoke_O_O__O(s__11, Lit_230) }; if jrt.J2g_Truth(tmp18) {
															lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_231, nil), jrt.RefArrayOf(jrt.Object_class, nil, s__11)).Ref()) }
														jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_184); lang.IFn_Cast(A_arbace_c2j_emit_A_const_163.GetRawRoot__O()).Invoke_O_O__O(sb__0, s__11)
//line :311:1
														break L1 }; case 29: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_136) {




															lang.IFn_Cast(num__6).Invoke_O_O__O(A_arbace_c2j_emit_A_const_185, v__2)
//line :311:1
															break L1 }; case 36: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_140) {












																jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_186)
																if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(v__2)) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_169); lang.IFn_Cast(A_arbace_c2j_emit_A_const_163.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_86.GetRawRoot__O()).Invoke_O__O(v__2)) } else { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_164) }
																lang.IFn_Cast(A_arbace_c2j_emit_A_const_163.GetRawRoot__O()).Invoke_O_O__O(sb__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_42.GetRawRoot__O()).Invoke_O__O(v__2))
//line :311:1
																break L1 }; case 37: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_135) {



																	lang.IFn_Cast(num__6).Invoke_O_O__O(A_arbace_c2j_emit_A_const_188, v__2)
//line :311:1
																	break L1 }; case 46: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_146) {
























																		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_111.GetRawRoot__O()).Invoke_O__O(v__2)) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_187) } else { var tmp19 lang.IFn = lang.IFn_Cast(arr__7); var tmp20 any = A_arbace_c2j_emit_A_const_180; tmp19.Invoke_O_O__O(tmp20, lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(v__2))) }
//line :311:1
																		break L1 }; case 58: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_133) {

																			jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_169); lang.IFn_Cast(A_arbace_c2j_emit_A_const_163.GetRawRoot__O()).Invoke_O_O__O(sb__0, v__2)
//line :311:1
																			break L1 }; case 59: if any(G__31000063__10_) == any(A_arbace_c2j_emit_A_const_147) {

























																				var tmp21 lang.IFn = lang.IFn_Cast(arr__7); var tmp22 any = A_arbace_c2j_emit_A_const_189; tmp21.Invoke_O_O__O(tmp22, lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(v__2))
//line :311:1
																				break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_304, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__31000063__10_)))))
		}






























			if m_QMARK___9 { lang.IFn_Cast(A_arbace_c2j_emit_A_const_159.GetRawRoot__O()).Invoke_O_O_O__O(sb__0, shared__1, m__8) }
//line :302:1
			return sb__0 } }


func A_arbace_c2j_emit_pool_encode_num__31000055_A_New_O(p0 any) *A_arbace_c2j_emit_pool_encode_num__31000055_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_encode_num__31000055_A{}; t.Ctor_O(p0); return t }
//line :305:1
func (t *A_arbace_c2j_emit_pool_encode_num__31000055_A) Ctor_O(c__sb any) { t.F_sb = c__sb }
//line :305:1
func (t *A_arbace_c2j_emit_pool_encode_num__31000055_A) Invoke_O_O_O__O(self, tag__1, n__2 any) any { return jrt.NN(jrt.NN(jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(tag__1)).Append_J__StringBuilder(lang.RT_LongCast_O__J_NoInit(n__2))).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_153).Ref() }
func A_arbace_c2j_emit_pool_encode_arr__31000057_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_pool_encode_arr__31000057_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_encode_arr__31000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :306:1
func (t *A_arbace_c2j_emit_pool_encode_arr__31000057_A) Ctor_O_O(c__shared, c__sb any) { t.F_shared = c__shared; t.F_sb = c__sb }
//line :306:1
func (t *A_arbace_c2j_emit_pool_encode_arr__31000057_A) Invoke_O_O_O__O(self, tag__1, xs__2 any) any { jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(tag__1); { var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); jrt.NN(tmp1).Append_J__StringBuilder(lang.RT_LongCast_I__J_NoInit(lang.RT_Count_O__I_NoInit(xs__2))); jrt.NN(jrt.StringBuilder_Cast(t.F_sb)).Append_O__StringBuilder(A_arbace_c2j_emit_A_const_153); var seq_31000058__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(xs__2); var chunk_31000059__4 any; var count_31000060__5 int64 = 0; var i_31000061__6 int64 = 0; L1: for {
													if lang.Numbers_Lt_J_J__Z_NoInit(i_31000061__6, count_31000060__5) { var x__7 any = lang.Indexed_Cast(chunk_31000059__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_31000061__6)); lang.IFn_Cast(A_arbace_c2j_emit_A_const_159.GetRawRoot__O()).Invoke_O_O_O__O(t.F_sb, t.F_shared, x__7); seq_31000058__3, chunk_31000059__4, count_31000060__5, i_31000061__6 = seq_31000058__3, chunk_31000059__4, count_31000060__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_31000061__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(seq_31000058__3); if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_31000058__8 any = temp__1927000414__auto____7; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(seq_31000058__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(seq_31000058__8); seq_31000058__3, chunk_31000059__4, count_31000060__5, i_31000061__6 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(seq_31000058__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__9 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(seq_31000058__8); lang.IFn_Cast(A_arbace_c2j_emit_A_const_159.GetRawRoot__O()).Invoke_O_O_O__O(t.F_sb, t.F_shared, x__9); seq_31000058__3, chunk_31000059__4, count_31000060__5, i_31000061__6 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_161.GetRawRoot__O()).Invoke_O__O(seq_31000058__8), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :306:1*/panic("j2g: unreachable") }
































func A_arbace_c2j_emit_pool_encode_fn__31000064_A_New_O(p0 any) *A_arbace_c2j_emit_pool_encode_fn__31000064_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_encode_fn__31000064_A{}; t.Ctor_O(p0); return t }
//line :339:1
func (t *A_arbace_c2j_emit_pool_encode_fn__31000064_A) Ctor_O(c__v any) { t.F_v = c__v }
//line :339:1
func (t *A_arbace_c2j_emit_pool_encode_fn__31000064_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_65.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_v; t.F_v = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_c2j_emit_A_const_66.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }






func A_arbace_c2j_emit_pool_fields_A_New() *A_arbace_c2j_emit_pool_fields_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_fields_A{}; t.Ctor(); return t }
//line :346:1
func (t *A_arbace_c2j_emit_pool_fields_A) Ctor() {}
//line :346:1
func (t *A_arbace_c2j_emit_pool_fields_A) Invoke_O_O__O(self, consts__0 any) any {




	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(consts__0)) { var pooled__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_193.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_pool_fields_fn__31000068_A_New(); var tmp4 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_c2j_emit_pool_fields_fn__31000068_A_fn_class
		if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_305, false); A_arbace_c2j_emit_pool_fields_fn__31000068_A_fn_class = fncls__17d; tmp4 = fncls__17d } else { tmp4 = fncls__17 }; pooled__2 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), consts__0))
//line :351:1
		var seen__3 any = jrt.LinkedHashSet_New(); var walk__4 any; var tmp5 any = A_arbace_c2j_emit_pool_fields_walk__31000070_A_New_O(seen__3); var tmp6 *jrt.Class
		var fncls__13 /*line :351:1*/*jrt.Class = A_arbace_c2j_emit_pool_fields_walk__31000070_A_fn_class



		if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_306, false); A_arbace_c2j_emit_pool_fields_walk__31000070_A_fn_class = fncls__13d; tmp6 = fncls__13d } else { tmp6 = fncls__13 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)
//line :351:1
		var ___5 any; var tmp7 any = A_arbace_c2j_emit_pool_fields_fn__31000076_A_New_O_O(walk__4, pooled__2); var tmp8 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_c2j_emit_pool_fields_fn__31000076_A_fn_class; _ = ___5






		if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_307, false); A_arbace_c2j_emit_pool_fields_fn__31000076_A_fn_class = fncls__14d; tmp8 = fncls__14d } else { tmp8 = fncls__14 }; ___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()
//line :351:1
		var sh__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(seen__3); var shared__7 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_192.GetRawRoot__O()); var tmp10 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_194.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_pool_fields_fn__31000084_A_New(); var tmp13 *jrt.Class
		var fncls__18 /*line :351:1*/*jrt.Class = A_arbace_c2j_emit_pool_fields_fn__31000084_A_fn_class








		if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_308, false); A_arbace_c2j_emit_pool_fields_fn__31000084_A_fn_class = fncls__18d; tmp13 = fncls__18d } else { tmp13 = fncls__18 }; shared__7 = tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), sh__6))
//line :351:1
		var sb__8 any = jrt.StringBuilder_New(); var ___9 any; var tmp14 any = A_arbace_c2j_emit_pool_fields_fn__31000090_A_New_O_O(sb__8, sh__6); var tmp15 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c2j_emit_pool_fields_fn__31000090_A_fn_class; _ = ___9










		if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_309, false); A_arbace_c2j_emit_pool_fields_fn__31000090_A_fn_class = fncls__15d; tmp15 = fncls__15d } else { tmp15 = fncls__15 }; ___9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil).Invoke__O()
//line :351:1
		var base__10 int32 = lang.RT_Count_O__I_NoInit(sh__6); var ___11 any; var tmp16 any = A_arbace_c2j_emit_pool_fields_fn__31000096_A_New_O_O_O(sb__8, pooled__2, shared__7); var tmp17 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_c2j_emit_pool_fields_fn__31000096_A_fn_class; _ = ___11













		if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_310, false); A_arbace_c2j_emit_pool_fields_fn__31000096_A_fn_class = fncls__16d; tmp17 = fncls__16d } else { tmp17 = fncls__16 }; ___11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil).Invoke__O()
//line :351:1
		var n__12 int64 = lang.Numbers_Add_J_J__J_NoInit(int64(base__10), int64(lang.RT_Count_O__I_NoInit(pooled__2))); var index__13 any; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_192.GetRawRoot__O()); var tmp19 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_194.GetRawRoot__O()); var tmp21 any = A_arbace_c2j_emit_pool_fields_fn__31000105_A_New(); var tmp22 *jrt.Class
		var fncls__19 /*line :351:1*/*jrt.Class = A_arbace_c2j_emit_pool_fields_fn__31000105_A_fn_class















		if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_311, false); A_arbace_c2j_emit_pool_fields_fn__31000105_A_fn_class = fncls__19d; tmp22 = fncls__19d } else { tmp22 = fncls__19 }; index__13 = tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), pooled__2))
		var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp24 lang.IPersistentVector
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(pooled__2)) { var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp26 any = A_arbace_c2j_emit_A_const_210; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp28 any = A_arbace_c2j_emit_A_const_215; tmp24 = lang.Tuple_Create_O__IPersistentVector(tmp25.Invoke_O_O_O__O(tmp26, lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_211, A_arbace_c2j_emit_A_const_212), lang.IFn_Cast(A_arbace_c2j_emit_A_const_97.GetRawRoot__O()).Invoke_O__O(lang.RT_Object_array_O__O1_NoInit(A_arbace_c2j_emit_A_const_33).Ref())), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_213, A_arbace_c2j_emit_A_const_214), lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(sb__8), tmp27.Invoke_O_O__O(tmp28, jrt.Long_ValueOf_J__Long_NoInit(n__12).Ref())))) } else { tmp24 = nil }
//line :368:1
		var tmp29 any = tmp24; var tmp30 any; var iter__1927001039__auto____14 any; var tmp31 any = A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_A_New_O_I(index__13, base__10); var tmp32 *jrt.Class
		var fncls__32 /*line :368:1*/*jrt.Class = A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_A_fn_class




		if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_312, false); A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_A_fn_class = fncls__32d; tmp32 = fncls__32d } else { tmp32 = fncls__32 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); tmp30 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(consts__0)
//line :368:1
		return tmp23.Invoke_O_O__O(tmp29, tmp30) } else {
//line :351:1
			return nil } }
func A_arbace_c2j_emit_pool_fields_fn__31000068_A_New() *A_arbace_c2j_emit_pool_fields_fn__31000068_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_fields_fn__31000068_A{}; t.Ctor(); return t }
//line :352:1
func (t *A_arbace_c2j_emit_pool_fields_fn__31000068_A) Ctor() {}
//line :352:1
func (t *A_arbace_c2j_emit_pool_fields_fn__31000068_A) Invoke_O_O__O(self, p1__31000067_SHARP___1 any) any { return lang.RT_Nth_O_I_O__O_NoInit(p1__31000067_SHARP___1, lang.RT_IntCast_J__I_NoInit(3), nil) }


func A_arbace_c2j_emit_pool_fields_walk__31000070_A_New_O(p0 any) *A_arbace_c2j_emit_pool_fields_walk__31000070_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_fields_walk__31000070_A{}; t.Ctor_O(p0); return t }
//line :355:1
func (t *A_arbace_c2j_emit_pool_fields_walk__31000070_A) Ctor_O(c__seen any) { t.F_seen = c__seen }
//line :355:1
func (t *A_arbace_c2j_emit_pool_fields_walk__31000070_A) Invoke_O_O__O(self, v__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_154.GetRawRoot__O()).Invoke_O__O(v__1)) { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.HashSet_Cast(t.F_seen).Add_O__Z(v__1)) }
	return lang.IFn_Cast(A_arbace_c2j_emit_A_const_190.GetRawRoot__O()).Invoke_O_O__O(self, lang.IFn_Cast(A_arbace_c2j_emit_A_const_191.GetRawRoot__O()).Invoke_O__O(v__1)) }
func A_arbace_c2j_emit_pool_fields_fn__31000076_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_pool_fields_fn__31000076_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_fields_fn__31000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :358:1
func (t *A_arbace_c2j_emit_pool_fields_fn__31000076_A) Ctor_O_O(c__walk, c__pooled any) { t.F_walk = c__walk; t.F_pooled = c__pooled }
//line :358:1
func (t *A_arbace_c2j_emit_pool_fields_fn__31000076_A) Invoke_O__O(self any) any { { var seq_31000072__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_pooled; t.F_pooled = nil; tmp2 = t_; seq_31000072__1 = tmp1.Invoke_O__O(tmp2); var chunk_31000073__2 any; var count_31000074__3 int64 = 0; var i_31000075__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_31000075__4, count_31000074__3) { var vec__31000077__5 any = lang.Indexed_Cast(chunk_31000073__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_31000075__4)); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000077__5, lang.RT_IntCast_J__I_NoInit(0), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000077__5, lang.RT_IntCast_J__I_NoInit(1), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000077__5, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___6; _ = ___7; lang.IFn_Cast(t.F_walk).Invoke_O__O(v__8); seq_31000072__1, chunk_31000073__2, count_31000074__3, i_31000075__4 = seq_31000072__1, chunk_31000073__2, count_31000074__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_31000075__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(seq_31000072__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_31000072__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(seq_31000072__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(seq_31000072__6); seq_31000072__1, chunk_31000073__2, count_31000074__3, i_31000075__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(seq_31000072__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__31000080__7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(seq_31000072__6); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000080__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000080__7, lang.RT_IntCast_J__I_NoInit(1), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000080__7, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___8; _ = ___9; lang.IFn_Cast(t.F_walk).Invoke_O__O(v__10); seq_31000072__1, chunk_31000073__2, count_31000074__3, i_31000075__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_161.GetRawRoot__O()).Invoke_O__O(seq_31000072__6), nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }

func A_arbace_c2j_emit_pool_fields_fn__31000084_A_New() *A_arbace_c2j_emit_pool_fields_fn__31000084_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_fields_fn__31000084_A{}; t.Ctor(); return t }
//line :360:1
func (t *A_arbace_c2j_emit_pool_fields_fn__31000084_A) Ctor() {}
//line :360:1
func (t *A_arbace_c2j_emit_pool_fields_fn__31000084_A) Invoke_O_O_O__O(self, i__1, v__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(v__2, i__1) }

func A_arbace_c2j_emit_pool_fields_fn__31000090_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_pool_fields_fn__31000090_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_fields_fn__31000090_A{}; t.Ctor_O_O(p0, p1); return t }
//line :362:1
func (t *A_arbace_c2j_emit_pool_fields_fn__31000090_A) Ctor_O_O(c__sb, c__sh any) { t.F_sb = c__sb; t.F_sh = c__sh }
//line :362:1
func (t *A_arbace_c2j_emit_pool_fields_fn__31000090_A) Invoke_O__O(self any) any { { var seq_31000086__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_sh; t.F_sh = nil; tmp2 = t_; seq_31000086__1 = tmp1.Invoke_O__O(tmp2); var chunk_31000087__2 any; var count_31000088__3 int64 = 0; var i_31000089__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_31000089__4, count_31000088__3) { var v__5 any = lang.Indexed_Cast(chunk_31000087__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_31000089__4)); lang.IFn_Cast(A_arbace_c2j_emit_A_const_159.GetRawRoot__O()).Invoke_O_O_O__O(t.F_sb, lang.PersistentArrayMap_EMPTY.Ref(), v__5); seq_31000086__1, chunk_31000087__2, count_31000088__3, i_31000089__4 = seq_31000086__1, chunk_31000087__2, count_31000088__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_31000089__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(seq_31000086__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_31000086__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(seq_31000086__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(seq_31000086__6); seq_31000086__1, chunk_31000087__2, count_31000088__3, i_31000089__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(seq_31000086__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var v__7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(seq_31000086__6); lang.IFn_Cast(A_arbace_c2j_emit_A_const_159.GetRawRoot__O()).Invoke_O_O_O__O(t.F_sb, lang.PersistentArrayMap_EMPTY.Ref(), v__7); seq_31000086__1, chunk_31000087__2, count_31000088__3, i_31000089__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_161.GetRawRoot__O()).Invoke_O__O(seq_31000086__6), nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }


func A_arbace_c2j_emit_pool_fields_fn__31000096_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_pool_fields_fn__31000096_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_fields_fn__31000096_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :365:1
func (t *A_arbace_c2j_emit_pool_fields_fn__31000096_A) Ctor_O_O_O(c__sb, c__pooled, c__shared any) { t.F_sb = c__sb; t.F_pooled = c__pooled; t.F_shared = c__shared }
//line :365:1
func (t *A_arbace_c2j_emit_pool_fields_fn__31000096_A) Invoke_O__O(self any) any { { var seq_31000092__1 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_pooled; t.F_pooled = nil; tmp2 = t_; seq_31000092__1 = tmp1.Invoke_O__O(tmp2); var chunk_31000093__2 any; var count_31000094__3 int64 = 0; var i_31000095__4 int64 = 0; L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_31000095__4, count_31000094__3) { var vec__31000097__5 any = lang.Indexed_Cast(chunk_31000093__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_31000095__4)); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000097__5, lang.RT_IntCast_J__I_NoInit(0), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000097__5, lang.RT_IntCast_J__I_NoInit(1), nil); var v__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000097__5, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___6; _ = ___7; lang.IFn_Cast(A_arbace_c2j_emit_A_const_159.GetRawRoot__O()).Invoke_O_O_O__O(t.F_sb, t.F_shared, v__8); seq_31000092__1, chunk_31000093__2, count_31000094__3, i_31000095__4 = seq_31000092__1, chunk_31000093__2, count_31000094__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_31000095__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(seq_31000092__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_31000092__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(seq_31000092__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(seq_31000092__6); seq_31000092__1, chunk_31000093__2, count_31000094__3, i_31000095__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(seq_31000092__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__31000100__7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(seq_31000092__6); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000100__7, lang.RT_IntCast_J__I_NoInit(0), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000100__7, lang.RT_IntCast_J__I_NoInit(1), nil); var v__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000100__7, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___8; _ = ___9; lang.IFn_Cast(A_arbace_c2j_emit_A_const_159.GetRawRoot__O()).Invoke_O_O_O__O(t.F_sb, t.F_shared, v__10); seq_31000092__1, chunk_31000093__2, count_31000094__3, i_31000095__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_161.GetRawRoot__O()).Invoke_O__O(seq_31000092__6), nil, 0, 0; continue L1 } } else { return nil } } } }; panic("j2g: unreachable") }

func A_arbace_c2j_emit_pool_fields_fn__31000105_A_New() *A_arbace_c2j_emit_pool_fields_fn__31000105_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_fields_fn__31000105_A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_c2j_emit_pool_fields_fn__31000105_A) Ctor() {}
//line :367:1
func (t *A_arbace_c2j_emit_pool_fields_fn__31000105_A) Invoke_O_O_O__O(self, i__1, p__31000104__2 any) any { var vec__31000106__3 any = p__31000104__2; var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000106__3, lang.RT_IntCast_J__I_NoInit(0), nil); return lang.Tuple_Create_O_O__IPersistentVector(s__4, i__1) }





func A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_A_New_O_I(p0 any, p1 int32) *A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_A{}; t.Ctor_O_I(p0, p1); return t }
//line :373:1
func (t *A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_A) Ctor_O_I(c__index any, c__base int32) { t.F_index = c__index; t.F_base = c__base }
//line :373:1
func (t *A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_A) Invoke_O_O__O(self, s__31000111__1 any) any { var tmp1 any = A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_A_New_O_I_O_O(t.F_index, t.F_base, s__31000111__1, self); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_313, false); A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :373:1
func A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :373:1
func (t *A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_A) Ctor_O_I_O_O(c__index any, c__base int32, c__s__31000111, c__iter__31000110 any) { t.F_index = c__index; t.F_base = c__base; t.F_s__31000111 = c__s__31000111; t.F_iter__31000110 = c__iter__31000110 }
//line :373:1
func (t *A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_A) Invoke_O__O(self any) any { { var s__31000111__1 any; var t_ any = t.F_s__31000111; t.F_s__31000111 = nil; s__31000111__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000111__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000111__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000111__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000111__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000113__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_fn__31000116_A_New_O_I_I_O_O(t.F_index, t.F_base, size__1927001038__auto____5, b__31000113__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_fn__31000116_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_314, false); A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_fn__31000116_A_fn_class = fncls__25d; tmp2 = fncls__25d } else { tmp2 = fncls__25 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000110); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000113__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000111__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000113__6), nil) } } else { var vec__31000121__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000111__3); var s__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000121__4, lang.RT_IntCast_J__I_NoInit(0), nil); var t__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000121__4, lang.RT_IntCast_J__I_NoInit(1), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000121__4, lang.RT_IntCast_J__I_NoInit(2), nil); var alias__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000121__4, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_A_const_197; var tmp7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(s__5, A_arbace_c2j_emit_A_const_208), t__6); var tmp8 any; var or__1927000174__auto____9 any = alias__8; _ = ___7

	if jrt.J2g_Truth(or__1927000174__auto____9) { tmp8 = or__1927000174__auto____9 } else { var e__10 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_emit_A_const_201; var tmp11 any = A_arbace_c2j_emit_A_const_202; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_emit_A_const_203; var tmp14 jrt.Number_I; var na_26 int64 = int64(t.F_base); var na_27 any = lang.IFn_Cast(t.F_index).Invoke_O__O(s__5)
		if jrt.Long_InstanceOf(na_27) { var n0_28 int64 = na_26; var n1_29 int64 = jrt.NN(jrt.Long_Cast(na_27)).LongValue__J(); var nr_30 int64 = n0_28 + n1_29; if (n0_28^nr_30)&(n1_29^nr_30) >= 0 { tmp14 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_30)) } else { tmp14 = lang.Numbers_Add_J_O__Number_NoInit(na_26, na_27) } } else { tmp14 = lang.Numbers_Add_J_O__Number_NoInit(na_26, na_27) }; e__10 = tmp9.Invoke_O_O_O__O(tmp10, tmp11, tmp12.Invoke_O_O__O(tmp13, tmp14))
		if lang.Util_Equiv_O_O__Z_NoInit(t__6, A_arbace_c2j_emit_A_const_199) { tmp8 = e__10 } else { tmp8 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_204, t__6, e__10) } }
//line :373:1
	var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__31000110); return tmp4.Invoke_O_O__O(tmp5.Invoke_O_O_O__O(tmp6, tmp7, tmp8), tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000111__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :373:1
func A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_fn__31000116_A_New_O_I_I_O_O(p0 any, p1, p2 int32, p3, p4 any) *A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_fn__31000116_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_fn__31000116_A{}; t.Ctor_O_I_I_O_O(p0, p1, p2, p3, p4); return t }
//line :373:1
func (t *A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_fn__31000116_A) Ctor_O_I_I_O_O(c__index any, c__base, c__size__1927001038__auto__ int32, c__b__31000113, c__c__1927001037__auto__ any) { t.F_index = c__index; t.F_base = c__base; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__31000113 = c__b__31000113; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :373:1
func (t *A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_fn__31000116_A) Invoke_O__O(self any) any { { var i__31000112__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000112__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__31000117__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000112__1)); var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000117__2, lang.RT_IntCast_J__I_NoInit(0), nil); var t__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000117__2, lang.RT_IntCast_J__I_NoInit(1), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000117__2, lang.RT_IntCast_J__I_NoInit(2), nil); var alias__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000117__2, lang.RT_IntCast_J__I_NoInit(3), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000113; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_197; var tmp6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(s__3, A_arbace_c2j_emit_A_const_200), t__4); var tmp7 any; var or__1927000174__auto____7 any = alias__6; _ = ___5

	if jrt.J2g_Truth(or__1927000174__auto____7) { tmp7 = or__1927000174__auto____7 } else { var e__8 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_emit_A_const_201; var tmp10 any = A_arbace_c2j_emit_A_const_202; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_A_const_203; var tmp13 jrt.Number_I; var na_20 int64 = int64(t.F_base); var na_21 any = lang.IFn_Cast(t.F_index).Invoke_O__O(s__3)
		if jrt.Long_InstanceOf(na_21) { var n0_22 int64 = na_20; var n1_23 int64 = jrt.NN(jrt.Long_Cast(na_21)).LongValue__J(); var nr_24 int64 = n0_22 + n1_23; if (n0_22^nr_24)&(n1_23^nr_24) >= 0 { tmp13 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_24)) } else { tmp13 = lang.Numbers_Add_J_O__Number_NoInit(na_20, na_21) } } else { tmp13 = lang.Numbers_Add_J_O__Number_NoInit(na_20, na_21) }; e__8 = tmp8.Invoke_O_O_O__O(tmp9, tmp10, tmp11.Invoke_O_O__O(tmp12, tmp13))
		if lang.Util_Equiv_O_O__Z_NoInit(t__4, A_arbace_c2j_emit_A_const_199) { tmp7 = e__8 } else { tmp7 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_204, t__4, e__8) } }
//line :373:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp6, tmp7)); i__31000112__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000112__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_c2j_emit_const_type_A_New() *A_arbace_c2j_emit_const_type_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_const_type_A{}; t.Ctor(); return t }
//line :379:1
func (t *A_arbace_c2j_emit_const_type_A) Ctor() {}
//line :379:1
func (t *A_arbace_c2j_emit_const_type_A) Invoke_O_O__O(self, v__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_58.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_c2j_emit_A_const_216 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_57.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_c2j_emit_A_const_217 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(v__0)) { return A_arbace_c2j_emit_A_const_218 } else { if A_arbace_c2j_emit_A_const_64 != nil { return A_arbace_c2j_emit_A_const_219 } else { return nil
	}
	}
	}
	}
}







func A_arbace_c2j_emit_constant_A_New() *A_arbace_c2j_emit_constant_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_constant_A{}; t.Ctor(); return t }
//line :393:1
func (t *A_arbace_c2j_emit_constant_A) Ctor() {}
//line :393:1
func (t *A_arbace_c2j_emit_constant_A) Invoke_O_O_O__O(self, ctx__0, v__1 any) any {
	var tmp1 any; var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z_NoInit(v__1, nil)
	if or__1927000174__auto____3 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____3).Ref() } else { tmp1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(v__1) }
//line :394:1
	if jrt.J2g_Truth(tmp1) { return v__1 } else { var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(v__1)



		if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(v__1, ctx__0); if jrt.J2g_Truth(or__1927000174__auto____4) { tmp2 = or__1927000174__auto____4 } else { tmp2 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_222.Get__O(), lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(v__1)).GetName__String().Ref())) } } else { tmp2 = and__1927000168__auto____3 }
//line :394:1
		if jrt.J2g_Truth(tmp2) {




			return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_223, A_arbace_c2j_emit_A_const_224), lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(v__1)).GetName__String().Ref())) } else {
//line :394:1
				if A_arbace_c2j_emit_A_const_64 != nil {






					return lang.IFn_Cast(A_arbace_c2j_emit_A_const_221.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, v__1, lang.IFn_Cast(A_arbace_c2j_emit_A_const_225.GetRawRoot__O()).Invoke_O__O(v__1)) } else {
//line :394:1
						return nil
					}
			}
	}
}







func A_arbace_c2j_emit_gsym_A_New() *A_arbace_c2j_emit_gsym_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_gsym_A{}; t.Ctor(); return t }
//line :406:1
func (t *A_arbace_c2j_emit_gsym_A) Ctor() {}
//line :406:1
func (t *A_arbace_c2j_emit_gsym_A) Invoke_O_O_O__O(self, ctx__0, base__1 any) any { var cls__3 any = A_arbace_c2j_emit_A_const_40.Invoke_O__O(ctx__0); var tmp1 *lang.Keyword = A_arbace_c2j_emit_A_const_226; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_27.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_A_const_43.GetRawRoot__O(); var tmp4 any = A_arbace_c2j_emit_A_const_226; var k__4 any = tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O__O(cls__3, tmp3, tmp4, lang.IFn_Cast(A_arbace_c2j_emit_A_const_227.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_228.GetRawRoot__O(), A_arbace_c2j_emit_A_const_33))); return /*line :412:1*/ lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, base__1, k__4)).Ref()) }

func A_arbace_c2j_emit_local_sym_A_New() *A_arbace_c2j_emit_local_sym_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_local_sym_A{}; t.Ctor(); return t }
//line :414:1
func (t *A_arbace_c2j_emit_local_sym_A) Ctor() {}
//line :414:1
func (t *A_arbace_c2j_emit_local_sym_A) Invoke_O_O__O(self, b__0 any) any {



	return lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_151, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit_A_const_36.Invoke_O__O(b__0), nil, A_arbace_c2j_emit_A_const_229.Invoke_O__O(b__0))).Ref())
}
func A_arbace_c2j_emit_identity_set_A_New() *A_arbace_c2j_emit_identity_set_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_identity_set_A{}; t.Ctor(); return t }
//line :420:1
func (t *A_arbace_c2j_emit_identity_set_A) Ctor() {}
//line :420:1
func (t *A_arbace_c2j_emit_identity_set_A) Invoke_O_O__O(self, xs__0 any) any { var m__2 any = jrt.IdentityHashMap_New(); var seq_31000131__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(xs__0); var chunk_31000132__4 any; var count_31000133__5 int64 = 0; var i_31000134__6 int64 = 0; L1: for {





	if lang.Numbers_Lt_J_J__Z_NoInit(i_31000134__6, count_31000133__5) { var x__7 any = lang.Indexed_Cast(chunk_31000132__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_31000134__6)); jrt.NN(jrt.IdentityHashMap_Cast(m__2)).Put_O_O__O(x__7, jrt.Boolean_TRUE.Ref()); seq_31000131__3, chunk_31000132__4, count_31000133__5, i_31000134__6 = seq_31000131__3, chunk_31000132__4, count_31000133__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_31000134__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(seq_31000131__3); if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_31000131__8 any = temp__1927000414__auto____7; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(seq_31000131__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(seq_31000131__8); seq_31000131__3, chunk_31000132__4, count_31000133__5, i_31000134__6 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(seq_31000131__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var x__9 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(seq_31000131__8); jrt.NN(jrt.IdentityHashMap_Cast(m__2)).Put_O_O__O(x__9, jrt.Boolean_TRUE.Ref()); seq_31000131__3, chunk_31000132__4, count_31000133__5, i_31000134__6 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_161.GetRawRoot__O()).Invoke_O__O(seq_31000131__8), nil, 0, 0; continue L1 } } }
//line :420:1
	break L1 }; return m__2 }








func A_arbace_c2j_emit_closed_QMARK__A_New() *A_arbace_c2j_emit_closed_QMARK__A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_closed_QMARK__A{}; t.Ctor(); return t }
//line :429:1
func (t *A_arbace_c2j_emit_closed_QMARK__A) Ctor() {}
//line :429:1
func (t *A_arbace_c2j_emit_closed_QMARK__A) Invoke_O_O_O__O(self, ctx__0, lb__1 any) any { var temp__1927000414__auto____3 any = A_arbace_c2j_emit_A_const_230.Invoke_O__O(ctx__0); if
												jrt.J2g_Truth(temp__1927000414__auto____3) { var s__4 any = temp__1927000414__auto____3
													return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.IdentityHashMap_Cast(s__4)).ContainsKey_O__Z(lb__1)).Ref() } else {
//line :430:1
			return nil } }


func A_arbace_c2j_emit_field_sym_A_New() *A_arbace_c2j_emit_field_sym_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_field_sym_A{}; t.Ctor(); return t }
//line :433:1
func (t *A_arbace_c2j_emit_field_sym_A) Ctor() {}
//line :433:1
func (t *A_arbace_c2j_emit_field_sym_A) Invoke_O_O__O(self, b__0 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_107, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_emit_A_const_36.Invoke_O__O(b__0))).Ref()) }

func A_arbace_c2j_emit_field_read_A_New() *A_arbace_c2j_emit_field_read_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_field_read_A{}; t.Ctor(); return t }
//line :435:1
func (t *A_arbace_c2j_emit_field_read_A) Ctor() {}
//line :435:1
func (t *A_arbace_c2j_emit_field_read_A) Invoke_O_O_O_O__O(self, ctx__0, lb__1, b__2 any) any {
	return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_231.GetRawRoot__O()).Invoke_O__O(b__2), A_arbace_c2j_emit_A_const_232)
}





func A_arbace_c2j_emit_prim_A_New() *A_arbace_c2j_emit_prim_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_prim_A{}; t.Ctor(); return t }
//line :443:1
func (t *A_arbace_c2j_emit_prim_A) Ctor() {}
//line :443:1
func (t *A_arbace_c2j_emit_prim_A) Invoke_O_O__O(self, e__0 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_emit_A_const_233; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(e__0)) }

func A_arbace_c2j_emit_can_prim_QMARK__A_New() *A_arbace_c2j_emit_can_prim_QMARK__A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_can_prim_QMARK__A{}; t.Ctor(); return t }
//line :445:1
func (t *A_arbace_c2j_emit_can_prim_QMARK__A) Ctor() {}
//line :445:1
func (t *A_arbace_c2j_emit_can_prim_QMARK__A) Invoke_O_O__O(self, n__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_c2j_emit_A_const_235.Invoke_O__O(n__0))).Ref() }



func A_arbace_c2j_emit_box_A_New() *A_arbace_c2j_emit_box_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_box_A{}; t.Ctor(); return t }
//line :449:1
func (t *A_arbace_c2j_emit_box_A) Ctor() {}
//line :449:1
func (t *A_arbace_c2j_emit_box_A) Invoke_O_O_O__O(self, f__0, c__1 any) any {



	if lang.Util_Equiv_O_O__Z_NoInit(c__1, jrt.Void_TYPE.Ref()) {
		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_236, f__0, nil) } else {
//line :453:1
			if jrt.NN(jrt.Class_Cast(c__1)).IsPrimitive__Z() {

				var tmp1 any = A_arbace_c2j_emit_A_const_105; return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_237.GetRawRoot__O()).Invoke_O__O(c__1), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_24.GetRawRoot__O()).Invoke_O__O(c__1))))), f__0) } else {
//line :453:1
					if A_arbace_c2j_emit_A_const_64 != nil { return f__0 } else { return nil
					}
				}
		}
}
func A_arbace_c2j_emit_unbox_arg_A_New() *A_arbace_c2j_emit_unbox_arg_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unbox_arg_A{}; t.Ctor(); return t }
//line :458:1
func (t *A_arbace_c2j_emit_unbox_arg_A) Ctor() {}
//line :458:1
func (t *A_arbace_c2j_emit_unbox_arg_A) Invoke_O_O_O_O__O(self, ctx__0, f__1, p__2 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(p__2, A_arbace_c2j_emit_A_const_238) { return f__1 } else { if lang.Util_Equiv_O_O__Z_NoInit(p__2, jrt.Boolean_TYPE.Ref()) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_240; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_241, A_arbace_c2j_emit_A_const_242, f__1)) } else {
//line :461:1
			if lang.Util_Equiv_O_O__Z_NoInit(p__2, jrt.Character_TYPE.Ref()) {


				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_A_const_243; return tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_244, A_arbace_c2j_emit_A_const_245, f__1)) } else {
//line :461:1
					if jrt.NN(jrt.Class_Cast(p__2)).IsPrimitive__Z() { var unchecked__4 any = A_arbace_c2j_emit_A_const_239.Invoke_O__O(ctx__0); var m__5 any; var tmp5 any = jrt.Integer_TYPE.Ref(); var tmp6 *jrt.String





						if jrt.J2g_Truth(unchecked__4) { tmp6 = Lit_323 } else { tmp6 = Lit_324 }; var tmp7 any = tmp6.Ref(); var tmp8 any = jrt.Float_TYPE.Ref(); var tmp9 *jrt.String
						if jrt.J2g_Truth(unchecked__4) { tmp9 = Lit_325 } else { tmp9 = Lit_326 }
//line :467:1
						var tmp10 any = tmp9.Ref(); var tmp11 any = jrt.Double_TYPE.Ref(); var tmp12 *jrt.String

						if jrt.J2g_Truth(unchecked__4) { tmp12 = Lit_327 } else { tmp12 = Lit_328 }
//line :467:1
						var tmp13 any = tmp12.Ref(); var tmp14 any = jrt.Long_TYPE.Ref(); var tmp15 *jrt.String


						if jrt.J2g_Truth(unchecked__4) { tmp15 = Lit_329 } else { tmp15 = Lit_330 }
//line :467:1
						var tmp16 any = tmp15.Ref(); var tmp17 any = jrt.Byte_TYPE.Ref(); var tmp18 *jrt.String



						if jrt.J2g_Truth(unchecked__4) { tmp18 = Lit_331 } else { tmp18 = Lit_332 }
//line :467:1
						var tmp19 any = tmp18.Ref(); var tmp20 any = jrt.Short_TYPE.Ref(); var tmp21 *jrt.String




						if jrt.J2g_Truth(unchecked__4) { tmp21 = Lit_333 } else { tmp21 = Lit_334 }
//line :467:1
						m__5 = lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp7, tmp8, tmp10, tmp11, tmp13, tmp14, tmp16, tmp17, tmp19, tmp20, tmp21.Ref()))).Invoke_O__O(p__2)





						return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(Lit_335, m__5), A_arbace_c2j_emit_A_const_246), f__1) } else {
//line :461:1
							var tmp22 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(p__2, ctx__0)












							if jrt.J2g_Truth(or__1927000174__auto____4) { tmp22 = or__1927000174__auto____4 } else { tmp22 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_247.GetRawRoot__O()).Invoke_O__O(p__2)) }
//line :461:1
							if jrt.J2g_Truth(tmp22) { return f__1 } else { if A_arbace_c2j_emit_A_const_64 != nil {













								var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp24 any = A_arbace_c2j_emit_A_const_248; return tmp23.Invoke_O_O_O__O(tmp24, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(p__2), f__1) } else {
//line :461:1
									return nil
								}
							}
						}
				}
		}
	}
}








func A_arbace_c2j_emit_fi_QMARK__A_New() *A_arbace_c2j_emit_fi_QMARK__A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_fi_QMARK__A{}; t.Ctor(); return t }
//line :477:1
func (t *A_arbace_c2j_emit_fi_QMARK__A) Ctor() {}
//line :477:1
func (t *A_arbace_c2j_emit_fi_QMARK__A) Invoke_O_O__O(self, p__0 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.Class_Cast(p__0)).IsInterface__Z(); if and__1927000168__auto____2 {




	return lang.IFn_Cast(A_arbace_c2j_emit_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.Reflector_InvokeStaticMethod_String_String_O1__O(Lit_232, Lit_249, lang.RT_Object_array_O__O1_NoInit(lang.Tuple_Create_O__IPersistentVector(p__0)))) } else {
//line :481:1
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }


func A_arbace_c2j_emit_typed_args_A_New() *A_arbace_c2j_emit_typed_args_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_typed_args_A{}; t.Ctor(); return t }
//line :484:1
func (t *A_arbace_c2j_emit_typed_args_A) Ctor() {}
//line :484:1
func (t *A_arbace_c2j_emit_typed_args_A) Invoke_O_O_O_O__O(self, ctx__0, ps__1, es__2 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_typed_args_fn__31000144_A_New_O(ctx__0); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c2j_emit_typed_args_fn__31000144_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_322, false); A_arbace_c2j_emit_typed_args_fn__31000144_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ps__1, es__2) }
//line :487:1
func A_arbace_c2j_emit_typed_args_fn__31000144_A_New_O(p0 any) *A_arbace_c2j_emit_typed_args_fn__31000144_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_typed_args_fn__31000144_A{}; t.Ctor_O(p0); return t }
//line :487:1
func (t *A_arbace_c2j_emit_typed_args_fn__31000144_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :487:1
func (t *A_arbace_c2j_emit_typed_args_fn__31000144_A) Invoke_O_O_O__O(self, p__1, e__2 any) any { var n__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(e__2); var pc__4 any = A_arbace_c2j_emit_A_const_233.Invoke_O__O(n__3); var tmp1 any; var and__1927000168__auto____5 any = pc__4; if



	jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(pc__4, p__1)).Ref() } else { tmp1 = and__1927000168__auto____5 }; if /*line :490:1*/ jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__2) } else {
//line :490:1
			var tmp2 bool; var and__1927000168__auto____5_2 bool = lang.Util_Equiv_O_O__Z_NoInit(pc__4, jrt.Integer_TYPE.Ref())

			if and__1927000168__auto____5_2 { tmp2 = lang.Util_Equiv_O_O__Z_NoInit(p__1, jrt.Long_TYPE.Ref()) } else { tmp2 = and__1927000168__auto____5_2 }
//line :490:1
			if tmp2 {

				return lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__2) } else {
//line :490:1
					var tmp3 bool; var and__1927000168__auto____5_3 bool = lang.Util_Equiv_O_O__Z_NoInit(pc__4, jrt.Long_TYPE.Ref())


					if and__1927000168__auto____5_3 { tmp3 = lang.Util_Equiv_O_O__Z_NoInit(p__1, jrt.Integer_TYPE.Ref()) } else { tmp3 = and__1927000168__auto____5_3 }
//line :490:1
					if tmp3 {



						var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()); var tmp6 any; if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_239.Invoke_O__O(t.F_ctx)) { tmp6 = A_arbace_c2j_emit_A_const_253 } else { tmp6 = A_arbace_c2j_emit_A_const_254 }; return tmp4.Invoke_O_O__O(tmp5.Invoke_O_O__O(tmp6, A_arbace_c2j_emit_A_const_255), lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__2)) } else {
//line :490:1
							var tmp7 bool; var and__1927000168__auto____5_4 bool = lang.Util_Equiv_O_O__Z_NoInit(pc__4, jrt.Float_TYPE.Ref())






							if and__1927000168__auto____5_4 { tmp7 = lang.Util_Equiv_O_O__Z_NoInit(p__1, jrt.Double_TYPE.Ref()) } else { tmp7 = and__1927000168__auto____5_4 }
//line :490:1
							if tmp7 {






								return lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__2) } else {
//line :490:1
									var tmp8 bool; var and__1927000168__auto____5_5 bool = lang.Util_Equiv_O_O__Z_NoInit(pc__4, jrt.Double_TYPE.Ref())







									if and__1927000168__auto____5_5 { tmp8 = lang.Util_Equiv_O_O__Z_NoInit(p__1, jrt.Float_TYPE.Ref()) } else { tmp8 = and__1927000168__auto____5_5 }
//line :490:1
									if tmp8 {







										var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_emit_A_const_256; return tmp9.Invoke_O_O__O(tmp10, lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__2)) } else {
//line :490:1
											if A_arbace_c2j_emit_A_const_64 != nil { var f__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__2); var jc__6 any = A_arbace_c2j_emit_A_const_139.Invoke_O__O(n__3); var tmp11 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_251.GetRawRoot__O()).Invoke_O__O(p__1)











												if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()); var tmp13 any; var and__1927000168__auto____8 any = jc__6; if jrt.J2g_Truth(and__1927000168__auto____8) { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.Class_Cast(p__1)).IsAssignableFrom_Class__Z(jrt.Class_Cast(jc__6))).Ref() } else { tmp13 = and__1927000168__auto____8 }; tmp11 = tmp12.Invoke_O__O(tmp13) } else { tmp11 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp11) {

													var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_252.GetRawRoot__O()); var tmp15 any = t.F_ctx; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp17 any = A_arbace_c2j_emit_A_const_257; return tmp14.Invoke_O_O_O__O(tmp15, tmp16.Invoke_O_O_O__O(tmp17, lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p__1), f__5), p__1) } else {
														return lang.IFn_Cast(A_arbace_c2j_emit_A_const_252.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx, f__5, p__1) } } else {
//line :490:1
															return nil } } } } } } }

















func A_arbace_c2j_emit_param_tags_A_New() *A_arbace_c2j_emit_param_tags_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_param_tags_A{}; t.Ctor(); return t }
//line :508:1
func (t *A_arbace_c2j_emit_param_tags_A) Ctor() {}
//line :508:1
func (t *A_arbace_c2j_emit_param_tags_A) Invoke_O_O__O(self, ps__0 any) any { var tmp1 any = A_arbace_c2j_emit_A_const_105; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_20.GetRawRoot__O(), ps__0))) }

func A_arbace_c2j_emit_obj_array_A_New() *A_arbace_c2j_emit_obj_array_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_obj_array_A{}; t.Ctor(); return t }
//line :510:1
func (t *A_arbace_c2j_emit_obj_array_A) Ctor() {}
//line :510:1
func (t *A_arbace_c2j_emit_obj_array_A) Invoke_O_O_O__O(self, ctx__0, es__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_259; var tmp3 any = A_arbace_c2j_emit_A_const_260; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_obj_array_fn__31000149_A_New_O(ctx__0); var tmp6 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_c2j_emit_obj_array_fn__31000149_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_299, false); A_arbace_c2j_emit_obj_array_fn__31000149_A_fn_class = fncls__34d; tmp6 = fncls__34d } else { tmp6 = fncls__34 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), es__1)) }
//line :511:1
func A_arbace_c2j_emit_obj_array_fn__31000149_A_New_O(p0 any) *A_arbace_c2j_emit_obj_array_fn__31000149_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_obj_array_fn__31000149_A{}; t.Ctor_O(p0); return t }
//line :511:1
func (t *A_arbace_c2j_emit_obj_array_fn__31000149_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :511:1
func (t *A_arbace_c2j_emit_obj_array_fn__31000149_A) Invoke_O_O__O(self, p1__31000148_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__31000148_SHARP___1) }

func A_arbace_c2j_emit_var_value_A_New() *A_arbace_c2j_emit_var_value_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_var_value_A{}; t.Ctor(); return t }
//line :513:1
func (t *A_arbace_c2j_emit_var_value_A) Ctor() {}
//line :513:1
func (t *A_arbace_c2j_emit_var_value_A) Invoke_O_O_O__O(self, ctx__0, v__1 any) any { var c__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_221.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, v__1, A_arbace_c2j_emit_A_const_261); if

	jrt.NN(lang.Var_Cast(v__1)).IsDynamic__Z() { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_262, c__3) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_263, c__3) } }

func A_arbace_c2j_emit_line_meta_A_New() *A_arbace_c2j_emit_line_meta_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_line_meta_A{}; t.Ctor(); return t }
//line :517:1
func (t *A_arbace_c2j_emit_line_meta_A) Ctor() {}
//line :517:1
func (t *A_arbace_c2j_emit_line_meta_A) Invoke_O_O_O__O(self, f__0, n__1 any) any {
	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0); if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp2 bool; var na_35 any; var or__1927000174__auto____4 any = A_arbace_c2j_emit_A_const_264.Invoke_O__O(n__1); if jrt.J2g_Truth(or__1927000174__auto____4) { na_35 = or__1927000174__auto____4 } else { na_35 = A_arbace_c2j_emit_A_const_33 }; if jrt.Long_InstanceOf(na_35) { var n0_36 int64 = jrt.NN(jrt.Long_Cast(na_35)).LongValue__J(); tmp2 = n0_36 > 0 } else { if jrt.Double_InstanceOf(na_35) { var n0_36_2 float64 = jrt.NN(jrt.Double_Cast(na_35)).DoubleValue__D(); tmp2 = n0_36_2 > 0.0 } else { tmp2 = lang.Numbers_IsPos_O__Z_NoInit(na_35) } }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_22.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_A_const_13.GetRawRoot__O(); var tmp5 any = A_arbace_c2j_emit_A_const_265; return tmp3.Invoke_O_O_O_O__O(f__0, tmp4, tmp5, A_arbace_c2j_emit_A_const_264.Invoke_O__O(n__1)) } else {
//line :518:1
			return f__0
		}
}

func A_arbace_c2j_emit_emit_local_A_New() *A_arbace_c2j_emit_emit_local_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_local_A{}; t.Ctor(); return t }
//line :522:1
func (t *A_arbace_c2j_emit_emit_local_A) Ctor() {}
//line :522:1
func (t *A_arbace_c2j_emit_emit_local_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var lb__4 any = A_arbace_c2j_emit_A_const_266.Invoke_O__O(n__1); var b__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__4); if


	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_267.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lb__4)) { var r__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_268.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, lb__4, b__5); var tmp1 any; var and__1927000168__auto____7 any = A_arbace_c2j_emit_A_const_269.Invoke_O__O(ctx__0)


		if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = A_arbace_c2j_emit_A_const_270.Invoke_O__O(n__1); if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = A_arbace_c2j_emit_A_const_271.Invoke_O__O(b__5); if jrt.J2g_Truth(and__1927000168__auto____9) { tmp1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__5)) } else { tmp1 = and__1927000168__auto____9 } } else { tmp1 = and__1927000168__auto____8 } } else { tmp1 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp1) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_A_const_276; return tmp2.Invoke_O_O_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_c2j_emit_A_const_278, r__6), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_279, r__6, nil), A_arbace_c2j_emit_A_const_277) } else {
//line :528:1
				return r__6 } } else {
//line :525:1
					var tmp4 any; var and__1927000168__auto____6 bool; var na_37 any = A_arbace_c2j_emit_A_const_229.Invoke_O__O(b__5)





					if jrt.Long_InstanceOf(na_37) { var n0_38 int64 = jrt.NN(jrt.Long_Cast(na_37)).LongValue__J(); and__1927000168__auto____6 = n0_38 == 0 } else { if jrt.Double_InstanceOf(na_37) { var n0_38_2 float64 = jrt.NN(jrt.Double_Cast(na_37)).DoubleValue__D(); and__1927000168__auto____6 = n0_38_2 == 0.0 } else { and__1927000168__auto____6 = lang.Numbers_IsZero_O__Z_NoInit(na_37) } }; if and__1927000168__auto____6 { tmp4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_280.Invoke_O__O(b__5)) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }
//line :525:1
					if jrt.J2g_Truth(tmp4) { var or__1927000174__auto____6 any = A_arbace_c2j_emit_A_const_272.Invoke_O__O(ctx__0)





						if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { return A_arbace_c2j_emit_A_const_273 } } else {
//line :525:1
							if A_arbace_c2j_emit_A_const_64 != nil {






								return lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(b__5) } else {
//line :525:1
									return nil } } } }








func A_arbace_c2j_emit_emit_invoke_A_New() *A_arbace_c2j_emit_emit_invoke_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_invoke_A{}; t.Ctor(); return t }
//line :534:1
func (t *A_arbace_c2j_emit_emit_invoke_A) Ctor() {}
//line :534:1
func (t *A_arbace_c2j_emit_emit_invoke_A) Invoke_O_O_O__O(self, ctx__0, n__1 any) any { var args__3 any = A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__1); var fexpr__4 any = A_arbace_c2j_emit_A_const_282.Invoke_O__O(n__1); var call__5 any; var tmp1 any = A_arbace_c2j_emit_emit_invoke_call__31000157_A_New_O_O(ctx__0, args__3); var tmp2 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_c2j_emit_emit_invoke_call__31000157_A_fn_class; if


	fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_175, false); A_arbace_c2j_emit_emit_invoke_call__31000157_A_fn_class = fncls__40d; tmp2 = fncls__40d } else { tmp2 = fncls__40 }; call__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 any; var and__1927000168__auto____6 any =





	A_arbace_c2j_emit_A_const_292.Invoke_O__O(n__1); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = A_arbace_c2j_emit_A_const_293.Invoke_O__O(n__1); if jrt.J2g_Truth(and__1927000168__auto____7) { tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_293.Invoke_O__O(n__1), ctx__0)) } else { tmp3 = and__1927000168__auto____7 } } else { tmp3 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp3) { var m__6 any = A_arbace_c2j_emit_A_const_294.Invoke_O__O(n__1); var on__7 any = A_arbace_c2j_emit_A_const_293.Invoke_O__O(n__1); var t__8 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_295.GetRawRoot__O()).Invoke_O_O__O(ctx__0, Lit_174); var rest_args__9 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(args__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_296; var tmp6 any = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(t__8, A_arbace_c2j_emit_A_const_238), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(args__3))); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_emit_A_const_297; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_emit_A_const_299; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_A_const_300; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp14 any = A_arbace_c2j_emit_A_const_301; var tmp15 any = tmp9.Invoke_O_O_O__O(tmp10, tmp11.Invoke_O_O_O__O(tmp12, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(on__7), t__8), tmp13.Invoke_O_O__O(tmp14, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_302, t__8))); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp17 any = A_arbace_c2j_emit_A_const_305; var tmp18 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_298.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(on__7)), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Method_Cast(m__6)).GetName__String().Ref())).Ref()), lang.IFn_Cast(A_arbace_c2j_emit_A_const_304.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__6)).GetParameterTypes__Class1().Ref())), tmp16.Invoke_O_O_O__O(tmp17, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(on__7), t__8), lang.IFn_Cast(A_arbace_c2j_emit_A_const_303.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, jrt.NN(jrt.Method_Cast(m__6)).GetParameterTypes__Class1().Ref(), rest_args__9)), jrt.NN(jrt.Method_Cast(m__6)).GetReturnType__Class().Ref()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()); var tmp20 any = A_arbace_c2j_emit_A_const_306; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp22 any = A_arbace_c2j_emit_A_const_307; var tmp23 any = A_arbace_c2j_emit_A_const_308; var tmp24 any = tmp21.Invoke_O_O_O__O(tmp22, tmp23, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, fexpr__4)); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp26 any = A_arbace_c2j_emit_emit_invoke_fn__31000161_A_New_O(ctx__0); var tmp27 *jrt.Class
		var fncls__41 /*line :543:1*/*jrt.Class = A_arbace_c2j_emit_emit_invoke_fn__31000161_A_fn_class

















		if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_176, false); A_arbace_c2j_emit_emit_invoke_fn__31000161_A_fn_class = fncls__41d; tmp27 = fncls__41d } else { tmp27 = fncls__41 }
//line :550:1
		return tmp4.Invoke_O_O_O__O(tmp5, tmp6, tmp7.Invoke_O_O_O_O__O(tmp8, tmp15, tmp18, tmp19.Invoke_O_O_O_O__O(tmp20, tmp24, t__8, tmp25.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil), rest_args__9)))) } else {











			return lang.IFn_Cast(call__5).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, fexpr__4)) } }
//line :537:1
func A_arbace_c2j_emit_emit_invoke_call__31000157_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_invoke_call__31000157_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_invoke_call__31000157_A{}; t.Ctor_O_O(p0, p1); return t }
//line :537:1
func (t *A_arbace_c2j_emit_emit_invoke_call__31000157_A) Ctor_O_O(c__ctx, c__args any) { t.F_ctx = c__ctx; t.F_args = c__args }
//line :537:1
func (t *A_arbace_c2j_emit_emit_invoke_call__31000157_A) Invoke_O_O__O(self, f__1 any) any {
	if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_args)), 20) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_283; return tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_284, A_arbace_c2j_emit_A_const_285, f__1), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_287, A_arbace_c2j_emit_A_const_288), lang.IFn_Cast(A_arbace_c2j_emit_A_const_286.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t.F_args))) } else {


			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_A_const_289; var tmp5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_290, A_arbace_c2j_emit_A_const_291, f__1); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp7 any = A_arbace_c2j_emit_emit_invoke_call__31000157_fn__31000158_A_New_O(t.F_ctx); var tmp8 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_c2j_emit_emit_invoke_call__31000157_fn__31000158_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_177, false); A_arbace_c2j_emit_emit_invoke_call__31000157_fn__31000158_A_fn_class = fncls__39d; tmp8 = fncls__39d } else { tmp8 = fncls__39 }; return tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), t.F_args)) } }
//line :542:1
func A_arbace_c2j_emit_emit_invoke_call__31000157_fn__31000158_A_New_O(p0 any) *A_arbace_c2j_emit_emit_invoke_call__31000157_fn__31000158_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_invoke_call__31000157_fn__31000158_A{}; t.Ctor_O(p0); return t }
//line :542:1
func (t *A_arbace_c2j_emit_emit_invoke_call__31000157_fn__31000158_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :542:1
func (t *A_arbace_c2j_emit_emit_invoke_call__31000157_fn__31000158_A) Invoke_O_O__O(self, p1__31000155_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__31000155_SHARP___1) }


















func A_arbace_c2j_emit_emit_invoke_fn__31000161_A_New_O(p0 any) *A_arbace_c2j_emit_emit_invoke_fn__31000161_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_invoke_fn__31000161_A{}; t.Ctor_O(p0); return t }
//line :561:1
func (t *A_arbace_c2j_emit_emit_invoke_fn__31000161_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :561:1
func (t *A_arbace_c2j_emit_emit_invoke_fn__31000161_A) Invoke_O_O__O(self, p1__31000156_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__31000156_SHARP___1) }


func A_arbace_c2j_emit_descriptor_A_New() *A_arbace_c2j_emit_descriptor_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_descriptor_A{}; t.Ctor(); return t }
//line :564:1
func (t *A_arbace_c2j_emit_descriptor_A) Ctor() {}
//line :564:1
func (t *A_arbace_c2j_emit_descriptor_A) Invoke_O_O__O(self, c__0 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Void_TYPE.Ref()) { return Lit_25 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Long_TYPE.Ref()) { return Lit_26 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Integer_TYPE.Ref()) { return Lit_27 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Double_TYPE.Ref()) { return Lit_28 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Boolean_TYPE.Ref()) { return Lit_29 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Character_TYPE.Ref()) { return Lit_30 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Float_TYPE.Ref()) { return Lit_31 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Short_TYPE.Ref()) { return Lit_32 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Byte_TYPE.Ref()) { return Lit_33 } else { if jrt.NN(jrt.Class_Cast(c__0)).IsArray__Z() {



		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_309.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref(), Lit_34, Lit_35) } else {
//line :565:1
			if A_arbace_c2j_emit_A_const_64 != nil {




				return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_36, nil, Lit_37), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_309.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__0)).GetName__String().Ref()), Lit_34, Lit_35), nil)).Ref() } else {
//line :565:1
					return nil
				}
		}
	}
	}
	}
	}
	} } } } } }
func A_arbace_c2j_emit_fn__31000165_A_New() *A_arbace_c2j_emit_fn__31000165_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_fn__31000165_A{}; t.Ctor(); return t }
//line :573:1
func (t *A_arbace_c2j_emit_fn__31000165_A) Ctor() {}
//line :573:1
func (t *A_arbace_c2j_emit_fn__31000165_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_310.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_250); var tmp3 any; var or__1927000174__auto____3 any = jrt.System_Getenv_String__String(Lit_251).Ref(); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { tmp3 = Lit_34 }; return tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil)).Ref()) }

func A_arbace_c2j_emit_jrt_lacks_QMARK__A_New() *A_arbace_c2j_emit_jrt_lacks_QMARK__A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_jrt_lacks_QMARK__A{}; t.Ctor(); return t }
//line :575:1
func (t *A_arbace_c2j_emit_jrt_lacks_QMARK__A) Ctor() {}
//line :575:1
func (t *A_arbace_c2j_emit_jrt_lacks_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var scan__2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_316.GetRawRoot__O()); var c__3 any = jrt.NN(jrt.Method_Cast(m__0)).GetDeclaringClass__Class().Ref(); var jc__4 any = lang.RT_Get_O_O__O_NoInit(A_arbace_c2j_emit_A_const_311.Invoke_O__O(scan__2), jrt.NN(jrt.Class_Cast(c__3)).GetName__String().Ref()); var tmp1 any; var and__1927000168__auto____5 any = jc__4; if







	jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_317.Invoke_O__O(jc__4)); if jrt.J2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_49.GetRawRoot__O()).Invoke_O_O__O(c__3, A_arbace_c2j_emit_A_const_238) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { var g__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_312.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_309.GetRawRoot__O()).Invoke_O_O_O__O(jrt.NN(jrt.Class_Cast(c__3)).GetName__String().Ref(), Lit_34, Lit_35)); var desc__6 any; var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_262, nil, Lit_263, nil); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_313.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_A_const_19.GetRawRoot__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_jrt_lacks_QMARK__fn__31000168_A_New(); var tmp7 *jrt.Class
		var fncls__42 /*line :583:1*/*jrt.Class = A_arbace_c2j_emit_jrt_lacks_QMARK__fn__31000168_A_fn_class

		if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_264, false); A_arbace_c2j_emit_jrt_lacks_QMARK__fn__31000168_A_fn_class = fncls__42d; tmp7 = fncls__42d } else { tmp7 = fncls__42 }; desc__6 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), jrt.NN(jrt.Method_Cast(m__0)).GetParameterTypes__Class1().Ref())), nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_314.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__0)).GetReturnType__Class().Ref()))).Ref()
//line :583:1
		var base__7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_315.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Method_Cast(m__0)).GetName__String().Ref(), desc__6)




		if jrt.Modifier_IsStatic_I__Z(jrt.NN(jrt.Method_Cast(m__0)).GetModifiers__I()) {
			return lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_318.Invoke_O__O(scan__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_265, nil), jrt.RefArrayOf(jrt.Object_class, g__5, nil, base__7)).Ref())) } else {
//line :588:1
				var ms__8 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_192.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_319.GetRawRoot__O()).Invoke_O_O__O(scan__2, g__5), lang.IFn_Cast(A_arbace_c2j_emit_A_const_320.GetRawRoot__O()).Invoke_O_O__O(scan__2, g__5)); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()); var tmp9 any; var or__1927000174__auto____9 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(ms__8, base__7)


				if jrt.J2g_Truth(or__1927000174__auto____9) { tmp9 = or__1927000174__auto____9 } else { var or__1927000174__auto____10 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(ms__8, lang.IFn_Cast(A_arbace_c2j_emit_A_const_321.GetRawRoot__O()).Invoke_O__O(base__7)); if jrt.J2g_Truth(or__1927000174__auto____10) { tmp9 = or__1927000174__auto____10 } else {
					tmp9 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_318.Invoke_O__O(scan__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_265, nil), jrt.RefArrayOf(jrt.Object_class, g__5, nil, base__7)).Ref()) } }
//line :591:1
				return tmp8.Invoke_O__O(tmp9) } } else {
//line :583:1
					return nil } }

func A_arbace_c2j_emit_jrt_lacks_QMARK__fn__31000168_A_New() *A_arbace_c2j_emit_jrt_lacks_QMARK__fn__31000168_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_jrt_lacks_QMARK__fn__31000168_A{}; t.Ctor(); return t }
//line :585:1
func (t *A_arbace_c2j_emit_jrt_lacks_QMARK__fn__31000168_A) Ctor() {}
//line :585:1
func (t *A_arbace_c2j_emit_jrt_lacks_QMARK__fn__31000168_A) Invoke_O_O__O(self, p1__31000167_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_314.GetRawRoot__O()).Invoke_O__O(p1__31000167_SHARP___1) }








func A_arbace_c2j_emit_method_call_A_New() *A_arbace_c2j_emit_method_call_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_method_call_A{}; t.Ctor(); return t }
//line :594:1
func (t *A_arbace_c2j_emit_method_call_A) Ctor() {}
//line :594:1
func (t *A_arbace_c2j_emit_method_call_A) Invoke_O_O_O_O_O__O(self, ctx__0, m__1, t__2, args__3 any) any { var dc__5 any = jrt.NN(jrt.Method_Cast(m__1)).GetDeclaringClass__Class().Ref(); var ps__6 any = jrt.NN(jrt.Method_Cast(m__1)).GetParameterTypes__Class1().Ref(); var static_QMARK___7 bool = jrt.Modifier_IsStatic_I__Z(jrt.NN(jrt.Method_Cast(m__1)).GetModifiers__I()); var head__8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(dc__5)); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp5 *jrt.String; if static_QMARK___7 {





	tmp5 = nil } else { tmp5 = Lit_34 }; head__8 = tmp1.Invoke_O_O__O(tmp2.Invoke_O_O__O(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5.Ref(), jrt.NN(jrt.Method_Cast(m__1)).GetName__String().Ref())).Ref()), lang.IFn_Cast(A_arbace_c2j_emit_A_const_304.GetRawRoot__O()).Invoke_O__O(ps__6)); if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(dc__5, ctx__0)) { lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_282, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__1)).Ref()) }; if static_QMARK___7 {

		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()).Invoke_O_O__O(head__8, lang.IFn_Cast(A_arbace_c2j_emit_A_const_303.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, ps__6, args__3)) } else {
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp7 any = A_arbace_c2j_emit_A_const_322; return lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()).Invoke_O_O_O__O(head__8, tmp6.Invoke_O_O_O__O(tmp7, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(dc__5), t__2), lang.IFn_Cast(A_arbace_c2j_emit_A_const_303.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, ps__6, args__3)) } }

func A_arbace_c2j_emit_compiled_interface_QMARK__A_New() *A_arbace_c2j_emit_compiled_interface_QMARK__A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_compiled_interface_QMARK__A{}; t.Ctor(); return t }
//line :607:1
func (t *A_arbace_c2j_emit_compiled_interface_QMARK__A) Ctor() {}
//line :607:1
func (t *A_arbace_c2j_emit_compiled_interface_QMARK__A) Invoke_O_O_O__O(self, ctx__0, c__1 any) any {


	var tmp1 any = A_arbace_c2j_emit_A_const_323; var tmp2 *lang.Keyword = A_arbace_c2j_emit_A_const_324; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2.Invoke_O__O(lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_311.Invoke_O__O(ctx__0)), lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__1)).GetName__String().Ref()))))).Ref()
}
func A_arbace_c2j_emit_emit_instance_method_A_New() *A_arbace_c2j_emit_emit_instance_method_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_instance_method_A{}; t.Ctor(); return t }
//line :612:1
func (t *A_arbace_c2j_emit_emit_instance_method_A) Ctor() {}
//line :612:1
func (t *A_arbace_c2j_emit_emit_instance_method_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var m__4 any = A_arbace_c2j_emit_A_const_325.Invoke_O__O(n__1); var tmp1 any; var and__1927000168__auto____5 any = m__4; if





	jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_326.GetRawRoot__O()).Invoke_O_O__O(ctx__0, jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref()); if jrt.J2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_330.Invoke_O__O(n__1)) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }; if /*line :614:1*/ jrt.J2g_Truth(tmp1) { var t__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_295.GetRawRoot__O()).Invoke_O_O__O(ctx__0, Lit_174); var dc__6 any = jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref(); var n_SINGLEQUOTE___7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(n__1, A_arbace_c2j_emit_A_const_331, A_arbace_c2j_emit_A_const_332, A_arbace_c2j_emit_A_const_330, jrt.Boolean_TRUE.Ref(), A_arbace_c2j_emit_A_const_333, t__5); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_A_const_334; var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(t__5, A_arbace_c2j_emit_A_const_238), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_331.Invoke_O__O(n__1))); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_A_const_335; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_emit_A_const_336; var tmp9 any = tmp7.Invoke_O_O_O__O(tmp8, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_337, t__5), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_338, t__5)); var tmp10 any; var r__8 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_340, A_arbace_c2j_emit_A_const_341), t__5, A_arbace_c2j_emit_A_const_339.Invoke_O__O(n__1), lang.IFn_Cast(A_arbace_c2j_emit_A_const_286.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__1))); _ = dc__6












		if jrt.J2g_Truth(unboxed_QMARK___2) { tmp10 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_252.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, r__8, jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref()) } else { tmp10 = r__8 }
//line :622:1
		return tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5.Invoke_O_O_O_O__O(tmp6, tmp9, tmp10, lang.IFn_Cast(A_arbace_c2j_emit_A_const_328.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n_SINGLEQUOTE___7, unboxed_QMARK___2))) } else {
//line :614:1
			var tmp11 any
			var and__1927000168__auto____5_2 any = m__4













			if jrt.J2g_Truth(and__1927000168__auto____5_2) { var and__1927000168__auto____6_2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_247.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref()); if jrt.J2g_Truth(and__1927000168__auto____6_2) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref(), ctx__0)); if jrt.J2g_Truth(and__1927000168__auto____7) {
				tmp11 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_342.GetRawRoot__O()).Invoke_O__O(m__4)) } else {
//line :629:1
					tmp11 = and__1927000168__auto____7 } } else { tmp11 = and__1927000168__auto____6_2 } } else { tmp11 = and__1927000168__auto____5_2 }
//line :614:1
			if jrt.J2g_Truth(tmp11) { var f__5 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_327.GetRawRoot__O()); var tmp13 any
















				if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_333.Invoke_O__O(n__1)) { tmp13 = A_arbace_c2j_emit_A_const_333.Invoke_O__O(n__1) } else { tmp13 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_331.Invoke_O__O(n__1)) }; f__5 = tmp12.Invoke_O_O_O_O__O(ctx__0, m__4, tmp13, A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__1))
				if jrt.J2g_Truth(unboxed_QMARK___2) { return f__5 } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_298.GetRawRoot__O()).Invoke_O_O__O(f__5, jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref()) } } else {
//line :614:1
					var tmp14 any
					var and__1927000168__auto____5_3 any = m__4

















					if jrt.J2g_Truth(and__1927000168__auto____5_3) { tmp14 = unboxed_QMARK___2 } else { tmp14 = and__1927000168__auto____5_3 }
//line :614:1
					if jrt.J2g_Truth(tmp14) {



















						var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_emit_A_const_325; var tmp17 any = A_arbace_c2j_emit_A_const_329; return lang.IFn_Cast(A_arbace_c2j_emit_A_const_252.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_328.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, tmp15.Invoke_O_O_O_O_O__O(n__1, tmp16, nil, tmp17, jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref()), jrt.Boolean_FALSE.Ref()), jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref()) } else {
//line :614:1
							if jrt.J2g_Truth(m__4) {





















								var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()); var tmp19 any = A_arbace_c2j_emit_A_const_325; var tmp20 any = A_arbace_c2j_emit_A_const_329; return lang.IFn_Cast(A_arbace_c2j_emit_A_const_328.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, tmp18.Invoke_O_O_O_O_O__O(n__1, tmp19, nil, tmp20, jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref()), jrt.Boolean_FALSE.Ref()) } else {
//line :614:1
									if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_329.Invoke_O__O(n__1)) {























										var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp22 any = A_arbace_c2j_emit_A_const_343; return tmp21.Invoke_O_O_O_O_O__O(tmp22, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_331.Invoke_O__O(n__1)), lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_329.Invoke_O__O(n__1)), A_arbace_c2j_emit_A_const_339.Invoke_O__O(n__1), lang.IFn_Cast(A_arbace_c2j_emit_A_const_286.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__1))) } else {
//line :614:1
											if A_arbace_c2j_emit_A_const_64 != nil {


























												return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_344, A_arbace_c2j_emit_A_const_345), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_331.Invoke_O__O(n__1)), A_arbace_c2j_emit_A_const_339.Invoke_O__O(n__1), lang.IFn_Cast(A_arbace_c2j_emit_A_const_286.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__1))) } else {
//line :614:1
													return nil } } } } } } }











































func A_arbace_c2j_emit_long_box_A_New() *A_arbace_c2j_emit_long_box_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_long_box_A{}; t.Ctor(); return t }
//line :658:1
func (t *A_arbace_c2j_emit_long_box_A) Ctor() {}
//line :658:1
func (t *A_arbace_c2j_emit_long_box_A) Invoke_O_O__O(self, f__0 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_346, A_arbace_c2j_emit_A_const_347), f__0) }
func A_arbace_c2j_emit_double_box_A_New() *A_arbace_c2j_emit_double_box_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_double_box_A{}; t.Ctor(); return t }
//line :659:1
func (t *A_arbace_c2j_emit_double_box_A) Ctor() {}
//line :659:1
func (t *A_arbace_c2j_emit_double_box_A) Invoke_O_O__O(self, f__0 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_348, A_arbace_c2j_emit_A_const_349), f__0) }

func A_arbace_c2j_emit_long_op2_A_New() *A_arbace_c2j_emit_long_op2_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_long_op2_A{}; t.Ctor(); return t }
//line :661:1
func (t *A_arbace_c2j_emit_long_op2_A) Ctor() {}
//line :661:1
func (t *A_arbace_c2j_emit_long_op2_A) Invoke_O_O_O_O_O_O__O(self, op__0, x__1, y__2, slow__3, r__4 any) any { var checked__6 any; var tmp1 any = A_arbace_c2j_emit_long_op2_checked__31000176_A_New_O_O(r__4, slow__3); var tmp2 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_c2j_emit_long_op2_checked__31000176_A_fn_class; if




	fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_267, false); A_arbace_c2j_emit_long_op2_checked__31000176_A_fn_class = fncls__43d; tmp2 = fncls__43d } else { tmp2 = fncls__43 }; checked__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = /*line :661:1*/lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_A_const_353; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_A_const_354; var add_ok__7 any = tmp3.Invoke_O_O_O__O(tmp4, tmp5.Invoke_O_O_O__O(tmp6, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_355, x__1, r__4), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_356, y__2, r__4)), A_arbace_c2j_emit_A_const_33); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_emit_A_const_357; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_emit_A_const_358; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_A_const_359; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp14 any = A_arbace_c2j_emit_A_const_361; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_emit_A_const_362; var sub_ok__8 any = tmp7.Invoke_O_O_O__O(tmp8, tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O_O__O(tmp12, y__2, A_arbace_c2j_emit_A_const_360.GetRawRoot__O())), tmp13.Invoke_O_O_O__O(tmp14, tmp15.Invoke_O_O_O__O(tmp16, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_363, x__1, y__2), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_364, x__1, r__4)), A_arbace_c2j_emit_A_const_33)); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp18 any = A_arbace_c2j_emit_A_const_365; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp20 any = A_arbace_c2j_emit_A_const_366; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp22 any = A_arbace_c2j_emit_A_const_367; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp24 any = A_arbace_c2j_emit_A_const_368; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp26 any = A_arbace_c2j_emit_A_const_370; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp28 any = A_arbace_c2j_emit_A_const_372; var mul_ok__9 any = tmp17.Invoke_O_O_O__O(tmp18, tmp19.Invoke_O_O__O(tmp20, tmp21.Invoke_O_O_O__O(tmp22, tmp23.Invoke_O_O_O__O(tmp24, x__1, A_arbace_c2j_emit_A_const_360.GetRawRoot__O()), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_369, y__2, A_arbace_c2j_emit_A_const_33))), tmp25.Invoke_O_O_O__O(tmp26, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_371, y__2, A_arbace_c2j_emit_A_const_33), tmp27.Invoke_O_O_O__O(tmp28, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_373, r__4, y__2), x__1))); var G__31000178__10_ any = op__0; switch












	lang.Util_Hash_O__I_NoInit(G__31000178__10_) >> 0 & 63 { case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_51) {














		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_374, x__1, y__2) }
//line :674:1
	case 15: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_52) {
		return lang.IFn_Cast(checked__6).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_375, x__1, y__2), add_ok__7) }
//line :674:1
	case 16: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_53) {

		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_352.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_376, x__1, y__2)) }
//line :674:1
	case 21: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_54) {





		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_352.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_377, x__1, y__2)) }
//line :674:1
	case 23: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_268) {









		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_378, x__1, y__2) }
//line :674:1
	case 24: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_55) {

















		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_379, x__1, y__2) }
//line :674:1
	case 27: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_269) {











		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_380, x__1, y__2) }
//line :674:1
	case 29: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_56) {















		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_381, x__1, y__2) }
//line :674:1
	case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_41) {



		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_352.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_382, x__1, y__2)) }
//line :674:1
	case 32: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_48) {


		return lang.IFn_Cast(checked__6).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_383, x__1, y__2), sub_ok__8) }
//line :674:1
	case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_57) {
		return lang.IFn_Cast(checked__6).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_375, x__1, y__2), add_ok__7) }
//line :674:1
	case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_270) {










		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_384, x__1, y__2) }
//line :674:1
	case 36: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_58) {




		return lang.IFn_Cast(checked__6).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_385, x__1, y__2), mul_ok__9) }
//line :674:1
	case 37: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_271) {








		var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp30 any = A_arbace_c2j_emit_A_const_386; return tmp29.Invoke_O_O_O_O__O(tmp30, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_387, y__2, A_arbace_c2j_emit_A_const_33), slow__3, lang.IFn_Cast(A_arbace_c2j_emit_A_const_352.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_388, x__1, y__2))) }
//line :674:1
	case 41: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_272) {












		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_389, x__1, y__2) }
//line :674:1
	case 43: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_273) {







		var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp32 any = A_arbace_c2j_emit_A_const_390; return tmp31.Invoke_O_O_O_O__O(tmp32, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_391, y__2, A_arbace_c2j_emit_A_const_33), slow__3, lang.IFn_Cast(A_arbace_c2j_emit_A_const_352.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_392, x__1, y__2))) }
//line :674:1
	case 44: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_59) {




		return lang.IFn_Cast(checked__6).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_385, x__1, y__2), mul_ok__9) }
//line :674:1
	case 45: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_60) {
















		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_393, x__1, y__2) }
//line :674:1
	case 48: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_44) {


		return lang.IFn_Cast(checked__6).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_383, x__1, y__2), sub_ok__8) }
//line :674:1
	case 54: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_61) {


















		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_394, x__1, y__2) }
//line :674:1
	case 58: if lang.Util_Equiv_O_O__Z_NoInit(G__31000178__10_, Lit_274) {













		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_395, x__1, y__2) }
//line :674:1
	default:}; return nil }
//line :666:1
func A_arbace_c2j_emit_long_op2_checked__31000176_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_long_op2_checked__31000176_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_long_op2_checked__31000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :666:1
func (t *A_arbace_c2j_emit_long_op2_checked__31000176_A) Ctor_O_O(c__r, c__slow any) { t.F_r = c__r; t.F_slow = c__slow }
//line :666:1
func (t *A_arbace_c2j_emit_long_op2_checked__31000176_A) Invoke_O_O_O__O(self, f__1, ok__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_350; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_A_const_351; return tmp1.Invoke_O_O_O__O(tmp2, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(t.F_r, jrt.Long_TYPE.Ref()), f__1), tmp3.Invoke_O_O_O_O__O(tmp4, ok__2, lang.IFn_Cast(A_arbace_c2j_emit_A_const_352.GetRawRoot__O()).Invoke_O__O(t.F_r), t.F_slow)) }





























func A_arbace_c2j_emit_double_op2_A_New() *A_arbace_c2j_emit_double_op2_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_double_op2_A{}; t.Ctor(); return t }
//line :696:1
func (t *A_arbace_c2j_emit_double_op2_A) Ctor() {}
//line :696:1
func (t *A_arbace_c2j_emit_double_op2_A) Invoke_O_O_O_O__O(self, op__0, x__1, y__2 any) any { var G__31000180__4_ any = op__0; switch



	lang.Util_Hash_O__I_NoInit(G__31000180__4_) >> 0 & 63 { case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_51) {



		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_397, x__1, y__2) }
//line :700:1
	case 15: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_52) {
		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_398, x__1, y__2)) }
//line :700:1
	case 16: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_53) {
		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_398, x__1, y__2)) }
//line :700:1
	case 21: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_54) {


		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_399, x__1, y__2)) }
//line :700:1
	case 24: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_55) {






		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_400, x__1, y__2) }
//line :700:1
	case 29: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_56) {




		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_401, x__1, y__2) }
//line :700:1
	case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_41) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_402; return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O_O__O(tmp2, x__1, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_403, y__2))) }
//line :700:1
	case 32: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_48) {

		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_A_const_402; return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O_O_O__O(tmp4, x__1, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_403, y__2))) }
//line :700:1
	case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_57) {
		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_398, x__1, y__2)) }
//line :700:1
	case 36: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_58) {


		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_399, x__1, y__2)) }
//line :700:1
	case 44: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_59) {


		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_399, x__1, y__2)) }
//line :700:1
	case 45: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_60) {





		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_404, y__2, x__1) }
//line :700:1
	case 48: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_44) {

		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_A_const_402; return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(tmp5.Invoke_O_O_O__O(tmp6, x__1, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_403, y__2))) }
//line :700:1
	case 54: if lang.Util_Equiv_O_O__Z_NoInit(G__31000180__4_, Lit_61) {







		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_405, x__1, y__2) }
//line :700:1
	default:}; return nil }










func A_arbace_c2j_emit_long_op1_A_New() *A_arbace_c2j_emit_long_op1_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_long_op1_A{}; t.Ctor(); return t }
//line :711:1
func (t *A_arbace_c2j_emit_long_op1_A) Ctor() {}
//line :711:1
func (t *A_arbace_c2j_emit_long_op1_A) Invoke_O_O_O_O__O(self, op__0, x__1, slow__2 any) any { var guard__4 any; var tmp1 any = A_arbace_c2j_emit_long_op1_guard__31000182_A_New_O_O(x__1, slow__2); var tmp2 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_c2j_emit_long_op1_guard__31000182_A_fn_class; if


	fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_266, false); A_arbace_c2j_emit_long_op1_guard__31000182_A_fn_class = fncls__46d; tmp2 = fncls__46d } else { tmp2 = fncls__46 }; guard__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var G__31000184__5_ any = op__0; switch
	lang.Util_Hash_O__I_NoInit(G__31000184__5_) >> 11 & 31 { case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__31000184__5_, Lit_39) {








		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_408, x__1, A_arbace_c2j_emit_A_const_33) }
//line :715:1
	case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__31000184__5_, Lit_40) {







		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_409, x__1, A_arbace_c2j_emit_A_const_33) }
//line :715:1
	case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__31000184__5_, Lit_41) {





		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_352.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_410, x__1)) }
//line :715:1
	case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__31000184__5_, Lit_42) {



		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_352.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_411, x__1)) }
//line :715:1
	case 12: if lang.Util_Equiv_O_O__Z_NoInit(G__31000184__5_, Lit_43) {
		return lang.IFn_Cast(guard__4).Invoke_O_O__O(A_arbace_c2j_emit_A_const_412.GetRawRoot__O(), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_413, x__1)) }
//line :715:1
	case 13: if lang.Util_Equiv_O_O__Z_NoInit(G__31000184__5_, Lit_44) {




		return lang.IFn_Cast(guard__4).Invoke_O_O__O(A_arbace_c2j_emit_A_const_360.GetRawRoot__O(), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_414, x__1)) }
//line :715:1
	case 14: if lang.Util_Equiv_O_O__Z_NoInit(G__31000184__5_, Lit_45) {

		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_352.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_415, x__1)) }
//line :715:1
	case 16: if lang.Util_Equiv_O_O__Z_NoInit(G__31000184__5_, Lit_46) {


		return lang.IFn_Cast(guard__4).Invoke_O_O__O(A_arbace_c2j_emit_A_const_360.GetRawRoot__O(), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_416, x__1)) }
//line :715:1
	case 18: if lang.Util_Equiv_O_O__Z_NoInit(G__31000184__5_, Lit_47) {
		return lang.IFn_Cast(guard__4).Invoke_O_O__O(A_arbace_c2j_emit_A_const_412.GetRawRoot__O(), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_413, x__1)) }
//line :715:1
	case 20: if lang.Util_Equiv_O_O__Z_NoInit(G__31000184__5_, Lit_48) {




		return lang.IFn_Cast(guard__4).Invoke_O_O__O(A_arbace_c2j_emit_A_const_360.GetRawRoot__O(), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_414, x__1)) }
//line :715:1
	case 27: if lang.Util_Equiv_O_O__Z_NoInit(G__31000184__5_, Lit_49) {






		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_417, x__1, A_arbace_c2j_emit_A_const_33) }
//line :715:1
	case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__31000184__5_, Lit_50) {


		return lang.IFn_Cast(guard__4).Invoke_O_O__O(A_arbace_c2j_emit_A_const_360.GetRawRoot__O(), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_416, x__1)) }
//line :715:1
	default:}; return nil }
//line :714:1
func A_arbace_c2j_emit_long_op1_guard__31000182_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_long_op1_guard__31000182_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_long_op1_guard__31000182_A{}; t.Ctor_O_O(p0, p1); return t }
//line :714:1
func (t *A_arbace_c2j_emit_long_op1_guard__31000182_A) Ctor_O_O(c__x, c__slow any) { t.F_x = c__x; t.F_slow = c__slow }
//line :714:1
func (t *A_arbace_c2j_emit_long_op1_guard__31000182_A) Invoke_O_O_O__O(self, bad__1, f__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_406; var tmp3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_407, t.F_x, bad__1); var tmp4 any = t.F_slow; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, tmp4, lang.IFn_Cast(A_arbace_c2j_emit_A_const_352.GetRawRoot__O()).Invoke_O__O(f__2)) }












func A_arbace_c2j_emit_double_op1_A_New() *A_arbace_c2j_emit_double_op1_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_double_op1_A{}; t.Ctor(); return t }
//line :727:1
func (t *A_arbace_c2j_emit_double_op1_A) Ctor() {}
//line :727:1
func (t *A_arbace_c2j_emit_double_op1_A) Invoke_O_O_O__O(self, op__0, x__1 any) any { var G__31000186__3_ any = op__0; switch


	lang.Util_Hash_O__I_NoInit(G__31000186__3_) >> 11 & 31 { case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__31000186__3_, Lit_39) {





		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_418, x__1, A_arbace_c2j_emit_A_const_419) }
//line :730:1
	case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__31000186__3_, Lit_40) {




		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_420, x__1, A_arbace_c2j_emit_A_const_421) }
//line :730:1
	case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__31000186__3_, Lit_41) {


		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_422, x__1)) }
//line :730:1
	case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__31000186__3_, Lit_42) {

		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_423, x__1, A_arbace_c2j_emit_A_const_424)) }
//line :730:1
	case 12: if lang.Util_Equiv_O_O__Z_NoInit(G__31000186__3_, Lit_43) {
		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_425, x__1, A_arbace_c2j_emit_A_const_426)) }
//line :730:1
	case 13: if lang.Util_Equiv_O_O__Z_NoInit(G__31000186__3_, Lit_44) {


		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_422, x__1)) }
//line :730:1
	case 14: if lang.Util_Equiv_O_O__Z_NoInit(G__31000186__3_, Lit_45) {
		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_425, x__1, A_arbace_c2j_emit_A_const_426)) }
//line :730:1
	case 16: if lang.Util_Equiv_O_O__Z_NoInit(G__31000186__3_, Lit_46) {

		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_423, x__1, A_arbace_c2j_emit_A_const_424)) }
//line :730:1
	case 18: if lang.Util_Equiv_O_O__Z_NoInit(G__31000186__3_, Lit_47) {
		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_425, x__1, A_arbace_c2j_emit_A_const_426)) }
//line :730:1
	case 20: if lang.Util_Equiv_O_O__Z_NoInit(G__31000186__3_, Lit_48) {


		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_422, x__1)) }
//line :730:1
	case 27: if lang.Util_Equiv_O_O__Z_NoInit(G__31000186__3_, Lit_49) {



		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_427, x__1, A_arbace_c2j_emit_A_const_428) }
//line :730:1
	case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__31000186__3_, Lit_50) {

		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_396.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_423, x__1, A_arbace_c2j_emit_A_const_424)) }
//line :730:1
	default:}; return nil }








func A_arbace_c2j_emit_numbers_intrinsic_A_New() *A_arbace_c2j_emit_numbers_intrinsic_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_numbers_intrinsic_A{}; t.Ctor(); return t }
//line :739:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_A) Ctor() {}
//line :739:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_A) Invoke_O_O_O_O__O(self, ctx__0, m__1, args__2 any) any {



	if lang.Util_Equiv_O_O__Z_NoInit(jrt.NN(jrt.Method_Cast(m__1)).GetDeclaringClass__Class().Ref(), A_arbace_c2j_emit_A_const_429) { var ps__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__1)).GetParameterTypes__Class1().Ref()); var sig__5 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_numbers_intrinsic_fn__31000190_A_New(); var tmp3 *jrt.Class
		var fncls__54 /*line :743:1*/*jrt.Class = A_arbace_c2j_emit_numbers_intrinsic_fn__31000190_A_fn_class

		if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_283, false); A_arbace_c2j_emit_numbers_intrinsic_fn__31000190_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; sig__5 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ps__4)
//line :743:1
		var op__6 any = jrt.NN(jrt.Method_Cast(m__1)).GetName__String().Ref(); var probe__7 any; var G__31000192__7_ int32 = lang.RT_Count_O__I_NoInit(ps__4)



	L1: switch { default: switch G__31000192__7_ { case 1:
		if lang.Util_Equiv_O_O__Z_NoInit(sig__5, A_arbace_c2j_emit_A_const_430) { probe__7 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_431.GetRawRoot__O()).Invoke_O_O_O__O(op__6, A_arbace_c2j_emit_A_const_449, A_arbace_c2j_emit_A_const_450) } else { probe__7 = nil }
//line :747:1
		break L1; case 2:

		var tmp4 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_432.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_451, sig__5); if jrt.J2g_Truth(and__1927000168__auto____8) { tmp4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_433.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_452, sig__5) } else { tmp4 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp4) { probe__7 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_434.GetRawRoot__O()).Invoke_O_O_O_O_O__O(op__6, A_arbace_c2j_emit_A_const_453, A_arbace_c2j_emit_A_const_454, A_arbace_c2j_emit_A_const_455, A_arbace_c2j_emit_A_const_456) } else { probe__7 = nil }
//line :747:1
		break L1; default:}; probe__7 = nil
	}


		if jrt.J2g_Truth(probe__7) { var temps__8 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_numbers_intrinsic_fn__31000193_A_New_O(ctx__0); var tmp7 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_c2j_emit_numbers_intrinsic_fn__31000193_A_fn_class
			if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_284, false); A_arbace_c2j_emit_numbers_intrinsic_fn__31000193_A_fn_class = fncls__55d; tmp7 = fncls__55d } else { tmp7 = fncls__55 }; temps__8 = tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), ps__4)
//line :751:1
			var binds__9 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_emit_numbers_intrinsic_fn__31000195_A_New(); var tmp11 *jrt.Class
			var fncls__56 /*line :751:1*/*jrt.Class = A_arbace_c2j_emit_numbers_intrinsic_fn__31000195_A_fn_class

			if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_285, false); A_arbace_c2j_emit_numbers_intrinsic_fn__31000195_A_fn_class = fncls__56d; tmp11 = fncls__56d } else { tmp11 = fncls__56 }; binds__9 = tmp8.Invoke_O__O(tmp9.Invoke_O_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), temps__8, ps__4, lang.IFn_Cast(A_arbace_c2j_emit_A_const_303.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, ps__4, args__2)))
//line :751:1
			var slow__10 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(Lit_286, op__6), lang.IFn_Cast(A_arbace_c2j_emit_A_const_304.GetRawRoot__O()).Invoke_O__O(ps__4)), temps__8); var lv__11 any; var tmp12 any = A_arbace_c2j_emit_numbers_intrinsic_lv__31000197_A_New(); var tmp13 *jrt.Class
			var fncls__50 /*line :751:1*/*jrt.Class = A_arbace_c2j_emit_numbers_intrinsic_lv__31000197_A_fn_class



			if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_287, false); A_arbace_c2j_emit_numbers_intrinsic_lv__31000197_A_fn_class = fncls__50d; tmp13 = fncls__50d } else { tmp13 = fncls__50 }; lv__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil)
//line :751:1
			var dv__12 any; var tmp14 any = A_arbace_c2j_emit_numbers_intrinsic_dv__31000199_A_New(); var tmp15 *jrt.Class
			var fncls__51 /*line :751:1*/*jrt.Class = A_arbace_c2j_emit_numbers_intrinsic_dv__31000199_A_fn_class




			if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_288, false); A_arbace_c2j_emit_numbers_intrinsic_dv__31000199_A_fn_class = fncls__51d; tmp15 = fncls__51d } else { tmp15 = fncls__51 }; dv__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)
//line :751:1
			var objs__13 any; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_441.GetRawRoot__O()); var tmp17 any = A_arbace_c2j_emit_numbers_intrinsic_fn__31000202_A_New(); var tmp18 *jrt.Class
			var fncls__57 /*line :751:1*/*jrt.Class = A_arbace_c2j_emit_numbers_intrinsic_fn__31000202_A_fn_class





			if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_289, false); A_arbace_c2j_emit_numbers_intrinsic_fn__31000202_A_fn_class = fncls__57d; tmp18 = fncls__57d } else { tmp18 = fncls__57 }; objs__13 = tmp16.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil), lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_457.GetRawRoot__O(), temps__8, sig__5))
//line :751:1
			var is__14 any; var tmp19 any = A_arbace_c2j_emit_numbers_intrinsic_is__31000207_A_New_O(objs__13); var tmp20 *jrt.Class
			var fncls__53 /*line :751:1*/*jrt.Class = A_arbace_c2j_emit_numbers_intrinsic_is__31000207_A_fn_class






			if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_290, false); A_arbace_c2j_emit_numbers_intrinsic_is__31000207_A_fn_class = fncls__53d; tmp20 = fncls__53d } else { tmp20 = fncls__53 }; is__14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil)
//line :751:1
			var xs__15 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()); var tmp22 any = A_arbace_c2j_emit_numbers_intrinsic_fn__31000211_A_New_O(ctx__0); var tmp23 *jrt.Class
			var fncls__58 /*line :751:1*/*jrt.Class = A_arbace_c2j_emit_numbers_intrinsic_fn__31000211_A_fn_class








			if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_291, false); A_arbace_c2j_emit_numbers_intrinsic_fn__31000211_A_fn_class = fncls__58d; tmp23 = fncls__58d } else { tmp23 = fncls__58 }; xs__15 = tmp21.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil), lang.IFn_Cast(A_arbace_c2j_emit_A_const_458.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__4)).Ref()))
//line :751:1
			var lbinds__16 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()); var tmp26 any = A_arbace_c2j_emit_numbers_intrinsic_fn__31000213_A_New_O(lv__11); var tmp27 *jrt.Class
			var fncls__59 /*line :751:1*/*jrt.Class = A_arbace_c2j_emit_numbers_intrinsic_fn__31000213_A_fn_class










			if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_292, false); A_arbace_c2j_emit_numbers_intrinsic_fn__31000213_A_fn_class = fncls__59d; tmp27 = fncls__59d } else { tmp27 = fncls__59 }; lbinds__16 = tmp24.Invoke_O__O(tmp25.Invoke_O_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil), xs__15, temps__8, sig__5))
//line :751:1
			var lfast__17 any











			if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(ps__4))) { lfast__17 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_431.GetRawRoot__O()).Invoke_O_O_O__O(op__6, lang.IFn_Cast(xs__15).Invoke_O__O(A_arbace_c2j_emit_A_const_33), slow__10) } else { lfast__17 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_434.GetRawRoot__O()).Invoke_O_O_O_O_O__O(op__6, lang.IFn_Cast(xs__15).Invoke_O__O(A_arbace_c2j_emit_A_const_33), lang.IFn_Cast(xs__15).Invoke_O__O(A_arbace_c2j_emit_A_const_459), slow__10, lang.IFn_Cast(A_arbace_c2j_emit_A_const_295.GetRawRoot__O()).Invoke_O_O__O(ctx__0, Lit_293)) }
//line :751:1
			var dfast__18 any












			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_433.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_460, sig__5)) {
				if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(ps__4))) { dfast__18 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_444.GetRawRoot__O()).Invoke_O_O__O(op__6, lang.IFn_Cast(xs__15).Invoke_O__O(A_arbace_c2j_emit_A_const_33)) } else { dfast__18 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_445.GetRawRoot__O()).Invoke_O_O_O__O(op__6, lang.IFn_Cast(xs__15).Invoke_O__O(A_arbace_c2j_emit_A_const_33), lang.IFn_Cast(xs__15).Invoke_O__O(A_arbace_c2j_emit_A_const_459)) } } else {
//line :764:1
					dfast__18 = nil }
//line :751:1
			var dbinds__19 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()); var tmp30 any = A_arbace_c2j_emit_numbers_intrinsic_fn__31000215_A_New_O(dv__12); var tmp31 *jrt.Class
			var fncls__60 /*line :751:1*/*jrt.Class = A_arbace_c2j_emit_numbers_intrinsic_fn__31000215_A_fn_class














			if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_294, false); A_arbace_c2j_emit_numbers_intrinsic_fn__31000215_A_fn_class = fncls__60d; tmp31 = fncls__60d } else { tmp31 = fncls__60 }; dbinds__19 = tmp28.Invoke_O__O(tmp29.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil), xs__15, temps__8))
			var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp33 any = A_arbace_c2j_emit_A_const_461; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp35 any = A_arbace_c2j_emit_A_const_462; var tmp36 any = lang.IFn_Cast(is__14).Invoke_O__O(A_arbace_c2j_emit_A_const_463); var tmp37 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_464, lbinds__16, lfast__17); var tmp38 any


			if jrt.J2g_Truth(dfast__18) {
				var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp40 any = A_arbace_c2j_emit_A_const_465; tmp38 = tmp39.Invoke_O_O_O_O__O(tmp40, lang.IFn_Cast(is__14).Invoke_O__O(A_arbace_c2j_emit_A_const_466), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_467, dbinds__19, dfast__18), slow__10) } else {
//line :770:1
					tmp38 = slow__10 }
//line :767:1
			return tmp32.Invoke_O_O_O__O(tmp33, binds__9, tmp34.Invoke_O_O_O_O__O(tmp35, tmp36, tmp37, tmp38)) } else {
//line :751:1
				return nil } } else {
//line :743:1
					return nil
				} }
func A_arbace_c2j_emit_numbers_intrinsic_fn__31000190_A_New() *A_arbace_c2j_emit_numbers_intrinsic_fn__31000190_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_numbers_intrinsic_fn__31000190_A{}; t.Ctor(); return t }
//line :745:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000190_A) Ctor() {}
//line :745:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000190_A) Invoke_O_O__O(self, p1__31000188_SHARP___1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(p1__31000188_SHARP___1, A_arbace_c2j_emit_A_const_238) { return A_arbace_c2j_emit_A_const_446 } else { if lang.Util_Equiv_O_O__Z_NoInit(p1__31000188_SHARP___1, jrt.Long_TYPE.Ref()) { return A_arbace_c2j_emit_A_const_447 } else { if A_arbace_c2j_emit_A_const_64 != nil { return A_arbace_c2j_emit_A_const_448 } else { return nil } } } }






func A_arbace_c2j_emit_numbers_intrinsic_fn__31000193_A_New_O(p0 any) *A_arbace_c2j_emit_numbers_intrinsic_fn__31000193_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_numbers_intrinsic_fn__31000193_A{}; t.Ctor_O(p0); return t }
//line :752:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000193_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :752:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000193_A) Invoke_O_O__O(self, ___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_295.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, Lit_295) }
func A_arbace_c2j_emit_numbers_intrinsic_fn__31000195_A_New() *A_arbace_c2j_emit_numbers_intrinsic_fn__31000195_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_numbers_intrinsic_fn__31000195_A{}; t.Ctor(); return t }
//line :753:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000195_A) Ctor() {}
//line :753:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000195_A) Invoke_O_O_O_O__O(self, t__1, p__2, f__3 any) any { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(t__1, p__2), f__3) }

func A_arbace_c2j_emit_numbers_intrinsic_lv__31000197_A_New() *A_arbace_c2j_emit_numbers_intrinsic_lv__31000197_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_numbers_intrinsic_lv__31000197_A{}; t.Ctor(); return t }
//line :755:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_lv__31000197_A) Ctor() {}
//line :755:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_lv__31000197_A) Invoke_O_O__O(self, t__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_435; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_436, A_arbace_c2j_emit_A_const_437, t__1)) }
func A_arbace_c2j_emit_numbers_intrinsic_dv__31000199_A_New() *A_arbace_c2j_emit_numbers_intrinsic_dv__31000199_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_numbers_intrinsic_dv__31000199_A{}; t.Ctor(); return t }
//line :756:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_dv__31000199_A) Ctor() {}
//line :756:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_dv__31000199_A) Invoke_O_O__O(self, t__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_438; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_439, A_arbace_c2j_emit_A_const_440, t__1)) }
func A_arbace_c2j_emit_numbers_intrinsic_fn__31000202_A_New() *A_arbace_c2j_emit_numbers_intrinsic_fn__31000202_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_numbers_intrinsic_fn__31000202_A{}; t.Ctor(); return t }
//line :757:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000202_A) Ctor() {}
//line :757:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000202_A) Invoke_O_O__O(self, p__31000201__1 any) any { var vec__31000203__2 any = p__31000201__1; var t__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000203__2, lang.RT_IntCast_J__I_NoInit(0), nil); var s__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000203__2, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Util_Equiv_O_O__Z_NoInit(s__4, A_arbace_c2j_emit_A_const_446) { return t__3 } else { return nil } }
func A_arbace_c2j_emit_numbers_intrinsic_is__31000207_A_New_O(p0 any) *A_arbace_c2j_emit_numbers_intrinsic_is__31000207_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_numbers_intrinsic_is__31000207_A{}; t.Ctor_O(p0); return t }
//line :758:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_is__31000207_A) Ctor_O(c__objs any) { t.F_objs = c__objs }
//line :758:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_is__31000207_A) Invoke_O_O__O(self, c__1 any) any { var ts__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_numbers_intrinsic_is__31000207_fn__31000208_A_New_O(c__1); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_c2j_emit_numbers_intrinsic_is__31000207_fn__31000208_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_298, false); A_arbace_c2j_emit_numbers_intrinsic_is__31000207_fn__31000208_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; ts__2 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), t.F_objs); if
												jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_161.GetRawRoot__O()).Invoke_O__O(ts__2)) { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_443, ts__2) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(ts__2) } }
//line :758:1
func A_arbace_c2j_emit_numbers_intrinsic_is__31000207_fn__31000208_A_New_O(p0 any) *A_arbace_c2j_emit_numbers_intrinsic_is__31000207_fn__31000208_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_numbers_intrinsic_is__31000207_fn__31000208_A{}; t.Ctor_O(p0); return t }
//line :758:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_is__31000207_fn__31000208_A) Ctor_O(c__c any) { t.F_c = c__c }
//line :758:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_is__31000207_fn__31000208_A) Invoke_O_O__O(self, p1__31000189_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_442, t.F_c, p1__31000189_SHARP___1) }

func A_arbace_c2j_emit_numbers_intrinsic_fn__31000211_A_New_O(p0 any) *A_arbace_c2j_emit_numbers_intrinsic_fn__31000211_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_numbers_intrinsic_fn__31000211_A{}; t.Ctor_O(p0); return t }
//line :760:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000211_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :760:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000211_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_295.GetRawRoot__O()); var tmp2 any = t.F_ctx; return tmp1.Invoke_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_296, nil, Lit_297), jrt.RefArrayOf(jrt.Object_class, nil, k__1, nil)).Ref()) }

func A_arbace_c2j_emit_numbers_intrinsic_fn__31000213_A_New_O(p0 any) *A_arbace_c2j_emit_numbers_intrinsic_fn__31000213_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_numbers_intrinsic_fn__31000213_A{}; t.Ctor_O(p0); return t }
//line :762:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000213_A) Ctor_O(c__lv any) { t.F_lv = c__lv }
//line :762:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000213_A) Invoke_O_O_O_O__O(self, x__1, t__2, s__3 any) any { var tmp1 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(x__1, jrt.Long_TYPE.Ref()); var tmp2 any; if lang.Util_Equiv_O_O__Z_NoInit(s__3, A_arbace_c2j_emit_A_const_446) { tmp2 = lang.IFn_Cast(t.F_lv).Invoke_O__O(t__2) } else { tmp2 = t__2 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }



func A_arbace_c2j_emit_numbers_intrinsic_fn__31000215_A_New_O(p0 any) *A_arbace_c2j_emit_numbers_intrinsic_fn__31000215_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_numbers_intrinsic_fn__31000215_A{}; t.Ctor_O(p0); return t }
//line :766:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000215_A) Ctor_O(c__dv any) { t.F_dv = c__dv }
//line :766:1
func (t *A_arbace_c2j_emit_numbers_intrinsic_fn__31000215_A) Invoke_O_O_O__O(self, x__1, t__2 any) any { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(x__1, jrt.Double_TYPE.Ref()), lang.IFn_Cast(t.F_dv).Invoke_O__O(t__2)) }







func A_arbace_c2j_emit_emit_static_method_A_New() *A_arbace_c2j_emit_emit_static_method_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_static_method_A{}; t.Ctor(); return t }
//line :774:1
func (t *A_arbace_c2j_emit_emit_static_method_A) Ctor() {}
//line :774:1
func (t *A_arbace_c2j_emit_emit_static_method_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var m__4 any = A_arbace_c2j_emit_A_const_325.Invoke_O__O(n__1); var tmp1 any; var and__1927000168__auto____5 any = m__4; if


	jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_247.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref()); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Method_Cast(m__4)).GetDeclaringClass__Class().Ref(), ctx__0)); if jrt.J2g_Truth(and__1927000168__auto____7) {
		tmp1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_342.GetRawRoot__O()).Invoke_O__O(m__4)) } else {
//line :777:1
			tmp1 = and__1927000168__auto____7 } } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }; if /*line :776:1*/ jrt.J2g_Truth(tmp1) { var f__5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_468.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, m__4, A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__1))


				if jrt.J2g_Truth(or__1927000174__auto____5) { f__5 = or__1927000174__auto____5 } else { f__5 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_327.GetRawRoot__O()).Invoke_O_O_O_O__O(ctx__0, m__4, nil, A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__1)) }
				if jrt.J2g_Truth(unboxed_QMARK___2) { return f__5 } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_298.GetRawRoot__O()).Invoke_O_O__O(f__5, jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref()) } } else {
//line :776:1
					var tmp2 any
					var and__1927000168__auto____5_2 any = m__4



					if jrt.J2g_Truth(and__1927000168__auto____5_2) { tmp2 = unboxed_QMARK___2 } else { tmp2 = and__1927000168__auto____5_2 }
//line :776:1
					if jrt.J2g_Truth(tmp2) {





						return lang.IFn_Cast(A_arbace_c2j_emit_A_const_252.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_469.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(n__1, A_arbace_c2j_emit_A_const_325, nil), jrt.Boolean_FALSE.Ref()), jrt.NN(jrt.Method_Cast(m__4)).GetReturnType__Class().Ref()) } else {
//line :776:1
							if A_arbace_c2j_emit_A_const_64 != nil {







								return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_470, A_arbace_c2j_emit_A_const_471), lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_472.Invoke_O__O(n__1)), A_arbace_c2j_emit_A_const_339.Invoke_O__O(n__1), lang.IFn_Cast(A_arbace_c2j_emit_A_const_286.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__1))) } else {
//line :776:1
									return nil } } } }











func A_arbace_c2j_emit_field_ok_QMARK__A_New() *A_arbace_c2j_emit_field_ok_QMARK__A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_field_ok_QMARK__A{}; t.Ctor(); return t }
//line :788:1
func (t *A_arbace_c2j_emit_field_ok_QMARK__A) Ctor() {}
//line :788:1
func (t *A_arbace_c2j_emit_field_ok_QMARK__A) Invoke_O_O_O__O(self, ctx__0, f__1 any) any { var and__1927000168__auto____3 any = f__1; if
												jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_247.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__1)).GetDeclaringClass__Class().Ref()); if jrt.J2g_Truth(and__1927000168__auto____4) { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.Field_Cast(f__1)).GetDeclaringClass__Class().Ref(), ctx__0)) } else { return and__1927000168__auto____4 } } else { return and__1927000168__auto____3 } }

func A_arbace_c2j_emit_emit_instance_field_A_New() *A_arbace_c2j_emit_emit_instance_field_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_instance_field_A{}; t.Ctor(); return t }
//line :791:1
func (t *A_arbace_c2j_emit_emit_instance_field_A) Ctor() {}
//line :791:1
func (t *A_arbace_c2j_emit_emit_instance_field_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var f__4 any = A_arbace_c2j_emit_A_const_473.Invoke_O__O(n__1); if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_474.GetRawRoot__O()).Invoke_O_O__O(ctx__0, f__4)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_475; var r__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_107, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Field_Cast(f__4)).GetName__String().Ref())).Ref()), tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__4)).GetDeclaringClass__Class().Ref()), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_331.Invoke_O__O(n__1))))

		if jrt.J2g_Truth(unboxed_QMARK___2) { return r__5 } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_298.GetRawRoot__O()).Invoke_O_O__O(r__5, jrt.NN(jrt.Field_Cast(f__4)).GetType__Class().Ref()) } } else {
			return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_478, A_arbace_c2j_emit_A_const_479), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_331.Invoke_O__O(n__1)), A_arbace_c2j_emit_A_const_476.Invoke_O__O(n__1), A_arbace_c2j_emit_A_const_477.Invoke_O__O(n__1)) } }



func A_arbace_c2j_emit_emit_static_field_A_New() *A_arbace_c2j_emit_emit_static_field_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_static_field_A{}; t.Ctor(); return t }
//line :800:1
func (t *A_arbace_c2j_emit_emit_static_field_A) Ctor() {}
//line :800:1
func (t *A_arbace_c2j_emit_emit_static_field_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var f__4 any = A_arbace_c2j_emit_A_const_473.Invoke_O__O(n__1); if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_474.GetRawRoot__O()).Invoke_O_O__O(ctx__0, f__4)) { var r__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__4)).GetDeclaringClass__Class().Ref())), jrt.NN(jrt.Field_Cast(f__4)).GetName__String().Ref())

		if jrt.J2g_Truth(unboxed_QMARK___2) { return r__5 } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_298.GetRawRoot__O()).Invoke_O_O__O(r__5, jrt.NN(jrt.Field_Cast(f__4)).GetType__Class().Ref()) } } else {
			return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_480, A_arbace_c2j_emit_A_const_481), lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_472.Invoke_O__O(n__1)), A_arbace_c2j_emit_A_const_476.Invoke_O__O(n__1)) } }


func A_arbace_c2j_emit_emit_new_A_New() *A_arbace_c2j_emit_emit_new_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_new_A{}; t.Ctor(); return t }
//line :808:1
func (t *A_arbace_c2j_emit_emit_new_A) Ctor() {}
//line :808:1
func (t *A_arbace_c2j_emit_emit_new_A) Invoke_O_O_O__O(self, ctx__0, n__1 any) any { var k__3 any = A_arbace_c2j_emit_A_const_482.Invoke_O__O(n__1); var c__4 any = A_arbace_c2j_emit_A_const_472.Invoke_O__O(n__1); var tmp1 any; var and__1927000168__auto____5 any = k__3; if


	jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_247.GetRawRoot__O()).Invoke_O__O(c__4); if jrt.J2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(c__4, ctx__0)) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_34), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(c__4), nil)).Ref()), lang.IFn_Cast(A_arbace_c2j_emit_A_const_304.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Constructor_Cast(k__3)).GetParameterTypes__Class1().Ref())), lang.IFn_Cast(A_arbace_c2j_emit_A_const_303.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, jrt.NN(jrt.Constructor_Cast(k__3)).GetParameterTypes__Class1().Ref(), A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__1))) } else {

			return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_483, A_arbace_c2j_emit_A_const_484), lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(ctx__0, c__4), lang.IFn_Cast(A_arbace_c2j_emit_A_const_286.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__1))) } }


func A_arbace_c2j_emit_emit_def_A_New() *A_arbace_c2j_emit_emit_def_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_def_A{}; t.Ctor(); return t }
//line :817:1
func (t *A_arbace_c2j_emit_emit_def_A) Ctor() {}
//line :817:1
func (t *A_arbace_c2j_emit_emit_def_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, top_QMARK___2 any) any { var v__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_221.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_142.Invoke_O__O(n__1), A_arbace_c2j_emit_A_const_487); var init__5 any; if

	jrt.J2g_Truth(A_arbace_c2j_emit_A_const_485.Invoke_O__O(n__1)) { init__5 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_488.Invoke_O__O(n__1)) } else { init__5 = nil }; var meta__6 any; if
	jrt.J2g_Truth(A_arbace_c2j_emit_A_const_486.Invoke_O__O(n__1)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_489; var tmp3 any = A_arbace_c2j_emit_A_const_490; meta__6 = tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_486.Invoke_O__O(n__1))) } else { meta__6 = nil }; if
	jrt.J2g_Truth(top_QMARK___2) {


		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_491); var tmp6 lang.IPersistentVector
		if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_485.Invoke_O__O(n__1)) { tmp6 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_492, v__4, init__5)) } else { tmp6 = nil }
//line :824:1
		var tmp7 any = tmp6; var tmp8 lang.IPersistentVector

		if jrt.J2g_Truth(meta__6) { tmp8 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_493, v__4, meta__6)) } else { tmp8 = nil }
//line :824:1
		var tmp9 any = tmp8; var tmp10 any


		if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_494.Invoke_O__O(n__1)) { tmp10 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_495, v__4, jrt.Boolean_TRUE.Ref()) } else { tmp10 = v__4 }
//line :824:1
		return tmp4.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, lang.Tuple_Create_O__IPersistentVector(tmp10)) } else {




			var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp12 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_496); var tmp13 lang.IPersistentVector
			if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_494.Invoke_O__O(n__1)) { tmp13 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_497, v__4, jrt.Boolean_TRUE.Ref())) } else { tmp13 = nil }
//line :829:1
			var tmp14 any = tmp13; var tmp15 lang.IPersistentVector

			if jrt.J2g_Truth(meta__6) { tmp15 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_498, v__4, meta__6)) } else { tmp15 = nil }
//line :829:1
			var tmp16 any = tmp15; var tmp17 lang.IPersistentVector


			if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_485.Invoke_O__O(n__1)) { tmp17 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_499, v__4, init__5)) } else { tmp17 = nil }
//line :829:1
			return tmp11.Invoke_O_O_O_O_O__O(tmp12, tmp14, tmp16, tmp17, lang.Tuple_Create_O__IPersistentVector(v__4)) } }





func A_arbace_c2j_emit_emit_assign_A_New() *A_arbace_c2j_emit_emit_assign_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_assign_A{}; t.Ctor(); return t }
//line :835:1
func (t *A_arbace_c2j_emit_emit_assign_A) Ctor() {}
//line :835:1
func (t *A_arbace_c2j_emit_emit_assign_A) Invoke_O_O_O__O(self, ctx__0, n__1 any) any { var t__3 any = A_arbace_c2j_emit_A_const_331.Invoke_O__O(n__1); var tn__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(t__3); var val__5 any = A_arbace_c2j_emit_A_const_500.Invoke_O__O(n__1); var G__31000224__6_ any = A_arbace_c2j_emit_A_const_501.Invoke_O__O(tn__4); switch



	lang.Util_Hash_O__I_NoInit(G__31000224__6_) >> 21 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__31000224__6_, Lit_69) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_502; return tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_c2j_emit_A_const_221.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_142.Invoke_O__O(tn__4), A_arbace_c2j_emit_A_const_503), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, val__5)) }
//line :839:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__31000224__6_, Lit_81) { var lb__7 any = A_arbace_c2j_emit_A_const_266.Invoke_O__O(tn__4); var b__8 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__7)


		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_267.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lb__7)) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_A_const_504; var tmp5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_268.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, lb__7, b__8); var tmp6 any; if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__8)) { tmp6 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(ctx__0, val__5) } else { tmp6 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, val__5) }; return tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6) } else {
				return lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(Lit_106) } }
//line :839:1
	case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__31000224__6_, Lit_98) { var f__7 any = A_arbace_c2j_emit_A_const_473.Invoke_O__O(tn__4); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O())
		var tmp8 any = A_arbace_c2j_emit_A_const_505












		return tmp7.Invoke_O_O_O__O(tmp8, lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__7)).GetDeclaringClass__Class().Ref())), jrt.NN(jrt.Field_Cast(f__7)).GetName__String().Ref()), lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_303.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, lang.Tuple_Create_O__IPersistentVector(jrt.NN(jrt.Field_Cast(f__7)).GetType__Class().Ref()), lang.Tuple_Create_O__IPersistentVector(val__5)))) }
//line :839:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__31000224__6_, Lit_68) { var f__7_2 any = A_arbace_c2j_emit_A_const_473.Invoke_O__O(tn__4)






		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_474.GetRawRoot__O()).Invoke_O_O__O(ctx__0, f__7_2)) {
			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_emit_A_const_506; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_A_const_507; return tmp9.Invoke_O_O_O__O(tmp10, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_107, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Field_Cast(f__7_2)).GetName__String().Ref())).Ref()), tmp11.Invoke_O_O_O__O(tmp12, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Field_Cast(f__7_2)).GetDeclaringClass__Class().Ref()), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_331.Invoke_O__O(tn__4)))), lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_303.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, lang.Tuple_Create_O__IPersistentVector(jrt.NN(jrt.Field_Cast(f__7_2)).GetType__Class().Ref()), lang.Tuple_Create_O__IPersistentVector(val__5)))) } else {


				var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp14 any = A_arbace_c2j_emit_A_const_508; return tmp13.Invoke_O_O_O_O__O(tmp14, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_331.Invoke_O__O(tn__4)), A_arbace_c2j_emit_A_const_476.Invoke_O__O(tn__4), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, val__5)) } }
//line :839:1
	default:}; return /*line :855:1*/ lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_108, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_emit_A_const_501.Invoke_O__O(tn__4))).Ref()) }

func A_arbace_c2j_emit_coll_call_A_New() *A_arbace_c2j_emit_coll_call_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_coll_call_A{}; t.Ctor(); return t }
//line :857:1
func (t *A_arbace_c2j_emit_coll_call_A) Ctor() {}
//line :857:1
func (t *A_arbace_c2j_emit_coll_call_A) Invoke_O_O_O_O__O(self, sym__0, es__1, ctx__2 any) any {
	return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(sym__0, A_arbace_c2j_emit_A_const_509), lang.IFn_Cast(A_arbace_c2j_emit_A_const_286.GetRawRoot__O()).Invoke_O_O__O(ctx__2, es__1))
}
func A_arbace_c2j_emit_emit_if_A_New() *A_arbace_c2j_emit_emit_if_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_if_A{}; t.Ctor(); return t }
//line :860:1
func (t *A_arbace_c2j_emit_emit_if_A) Ctor() {}
//line :860:1
func (t *A_arbace_c2j_emit_emit_if_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var t__4 any = A_arbace_c2j_emit_A_const_510.Invoke_O__O(n__1); var tn__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(t__4); var test__6 any; var tmp1 any; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_c2j_emit_A_const_233.Invoke_O__O(tn__5), jrt.Boolean_TYPE.Ref()); if and__1927000168__auto____6 {


	tmp1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_511.GetRawRoot__O()).Invoke_O__O(tn__5) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }; if jrt.J2g_Truth(tmp1) {
		test__6 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(ctx__0, t__4) } else {
			test__6 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, t__4) }; var br__7 any; var tmp2 any = /*line :860:1*/A_arbace_c2j_emit_emit_if_br__31000227_A_New_O_O(ctx__0, unboxed_QMARK___2); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_c2j_emit_emit_if_br__31000227_A_fn_class; if





	fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_173, false); A_arbace_c2j_emit_emit_if_br__31000227_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; br__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 lang.IFn =
	lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_512; return tmp4.Invoke_O_O_O_O__O(tmp5, test__6, lang.IFn_Cast(br__7).Invoke_O__O(A_arbace_c2j_emit_A_const_513.Invoke_O__O(n__1)), lang.IFn_Cast(br__7).Invoke_O__O(A_arbace_c2j_emit_A_const_514.Invoke_O__O(n__1))) }
//line :866:1
func A_arbace_c2j_emit_emit_if_br__31000227_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_if_br__31000227_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_if_br__31000227_A{}; t.Ctor_O_O(p0, p1); return t }
//line :866:1
func (t *A_arbace_c2j_emit_emit_if_br__31000227_A) Ctor_O_O(c__ctx, c__unboxed_QMARK_ any) { t.F_ctx = c__ctx; t.F_unboxed_QMARK_ = c__unboxed_QMARK_ }
//line :866:1
func (t *A_arbace_c2j_emit_emit_if_br__31000227_A) Invoke_O_O__O(self, e__1 any) any { if jrt.J2g_Truth(t.F_unboxed_QMARK_) { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__1) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__1) } }


func A_arbace_c2j_emit_emit_binding_init_A_New() *A_arbace_c2j_emit_emit_binding_init_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_binding_init_A{}; t.Ctor(); return t }
//line :869:1
func (t *A_arbace_c2j_emit_emit_binding_init_A) Ctor() {}
//line :869:1
func (t *A_arbace_c2j_emit_emit_binding_init_A) Invoke_O_O_O_O__O(self, ctx__0, lb__1, init__2 any) any { var b__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__1); var p__5 any = A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__4); if




	jrt.J2g_Truth(p__5) { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(b__4), p__5), lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(ctx__0, init__2)) } else { return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(b__4), A_arbace_c2j_emit_A_const_238), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, init__2)) } }



func A_arbace_c2j_emit_emit_let_A_New() *A_arbace_c2j_emit_emit_let_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_let_A{}; t.Ctor(); return t }
//line :878:1
func (t *A_arbace_c2j_emit_emit_let_A) Ctor() {}
//line :878:1
func (t *A_arbace_c2j_emit_emit_let_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var bis__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_234.GetRawRoot__O(), A_arbace_c2j_emit_A_const_516.Invoke_O__O(n__1)); var ctx_SINGLEQUOTE___5 any; if

	jrt.J2g_Truth(A_arbace_c2j_emit_A_const_515.Invoke_O__O(n__1)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_517; ctx_SINGLEQUOTE___5 = tmp1.Invoke_O_O_O__O(ctx__0, tmp2, lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_518, bis__4)) } else { ctx_SINGLEQUOTE___5 = ctx__0 }; var bindings__6 any; var tmp3 lang.IFn = /*line :878:1*/lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_emit_let_fn__31000232_A_New_O(ctx__0); var tmp6 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_c2j_emit_emit_let_fn__31000232_A_fn_class; if


	fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_178, false); A_arbace_c2j_emit_emit_let_fn__31000232_A_fn_class = fncls__63d; tmp6 = fncls__63d } else { tmp6 = fncls__63 }; bindings__6 = tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), bis__4)); var body__7 any; if
	jrt.J2g_Truth(unboxed_QMARK___2) { body__7 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(ctx_SINGLEQUOTE___5, A_arbace_c2j_emit_A_const_520.Invoke_O__O(n__1)) } else { body__7 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx_SINGLEQUOTE___5, A_arbace_c2j_emit_A_const_520.Invoke_O__O(n__1)) }; var tmp7 lang.IFn =
	lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp8 any; if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_515.Invoke_O__O(n__1)) { tmp8 = A_arbace_c2j_emit_A_const_521 } else { tmp8 = A_arbace_c2j_emit_A_const_522 }; return tmp7.Invoke_O_O_O__O(tmp8, bindings__6, body__7) }
//line :881:1
func A_arbace_c2j_emit_emit_let_fn__31000232_A_New_O(p0 any) *A_arbace_c2j_emit_emit_let_fn__31000232_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_let_fn__31000232_A{}; t.Ctor_O(p0); return t }
//line :881:1
func (t *A_arbace_c2j_emit_emit_let_fn__31000232_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :881:1
func (t *A_arbace_c2j_emit_emit_let_fn__31000232_A) Invoke_O_O__O(self, p1__31000231_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_519.GetRawRoot__O()); var tmp2 any = t.F_ctx; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c2j_emit_A_const_518.Invoke_O__O(p1__31000231_SHARP___1), A_arbace_c2j_emit_A_const_488.Invoke_O__O(p1__31000231_SHARP___1)) }



func A_arbace_c2j_emit_emit_recur_A_New() *A_arbace_c2j_emit_emit_recur_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_recur_A{}; t.Ctor(); return t }
//line :885:1
func (t *A_arbace_c2j_emit_emit_recur_A) Ctor() {}
//line :885:1
func (t *A_arbace_c2j_emit_emit_recur_A) Invoke_O_O_O__O(self, ctx__0, n__1 any) any { var lls__3 any = A_arbace_c2j_emit_A_const_523.Invoke_O__O(n__1); if

	jrt.J2g_Truth(A_arbace_c2j_emit_A_const_524.Invoke_O__O(ctx__0)) {
		if lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(lls__3), A_arbace_c2j_emit_A_const_525.Invoke_O__O(ctx__0)) { lang.IFn_Cast(A_arbace_c2j_emit_A_const_526.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_524.Invoke_O__O(ctx__0), jrt.Boolean_TRUE.Ref()) } }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_527; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_emit_recur_fn__31000235_A_New_O(ctx__0); var tmp5 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_c2j_emit_emit_recur_fn__31000235_A_fn_class; if
	fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_193, false); A_arbace_c2j_emit_emit_recur_fn__31000235_A_fn_class = fncls__64d; tmp5 = fncls__64d } else { tmp5 = fncls__64 }; return /*line :889:1*/ tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lls__3, A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__1))) }
func A_arbace_c2j_emit_emit_recur_fn__31000235_A_New_O(p0 any) *A_arbace_c2j_emit_emit_recur_fn__31000235_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_recur_fn__31000235_A{}; t.Ctor_O(p0); return t }
//line :890:1
func (t *A_arbace_c2j_emit_emit_recur_fn__31000235_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :890:1
func (t *A_arbace_c2j_emit_emit_recur_fn__31000235_A) Invoke_O_O_O__O(self, lb__1, arg__2 any) any { var b__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__1); var primc__4 any = A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__3); var pc__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_528.GetRawRoot__O()).Invoke_O__O(arg__2); if



	jrt.J2g_Truth(primc__4) {
		if lang.Util_Equiv_O_O__Z_NoInit(pc__5, primc__4) {
			return lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, arg__2) } else {
//line :895:1
				var tmp1 bool; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(primc__4, jrt.Long_TYPE.Ref())

				if and__1927000168__auto____6 { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(pc__5, jrt.Integer_TYPE.Ref()) } else { tmp1 = and__1927000168__auto____6 }
//line :895:1
				if tmp1 {

					return lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, arg__2) } else {
//line :895:1
						var tmp2 bool; var and__1927000168__auto____6_2 bool = lang.Util_Equiv_O_O__Z_NoInit(primc__4, jrt.Double_TYPE.Ref())


						if and__1927000168__auto____6_2 { tmp2 = lang.Util_Equiv_O_O__Z_NoInit(pc__5, jrt.Float_TYPE.Ref()) } else { tmp2 = and__1927000168__auto____6_2 }
//line :895:1
						if tmp2 {


							return lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, arg__2) } else {
//line :895:1
								var tmp3 bool; var and__1927000168__auto____6_3 bool = lang.Util_Equiv_O_O__Z_NoInit(primc__4, jrt.Integer_TYPE.Ref())



								if and__1927000168__auto____6_3 { tmp3 = lang.Util_Equiv_O_O__Z_NoInit(pc__5, jrt.Long_TYPE.Ref()) } else { tmp3 = and__1927000168__auto____6_3 }
//line :895:1
								if tmp3 {




									return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_529, A_arbace_c2j_emit_A_const_530), lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, arg__2)) } else {
//line :895:1
										var tmp4 bool; var and__1927000168__auto____6_4 bool = lang.Util_Equiv_O_O__Z_NoInit(primc__4, jrt.Float_TYPE.Ref())





										if and__1927000168__auto____6_4 { tmp4 = lang.Util_Equiv_O_O__Z_NoInit(pc__5, jrt.Double_TYPE.Ref()) } else { tmp4 = and__1927000168__auto____6_4 }
//line :895:1
										if tmp4 {





											var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_A_const_531; return tmp5.Invoke_O_O__O(tmp6, lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, arg__2)) } else {
//line :895:1
												if A_arbace_c2j_emit_A_const_64 != nil {






													return lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_194, nil, Lit_195), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_emit_A_const_36.Invoke_O__O(b__3), nil)).Ref()) } else {
//line :895:1
														return nil } } } } } } } else {







															return lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, arg__2) } }


func A_arbace_c2j_emit_body_instance_A_New() *A_arbace_c2j_emit_body_instance_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_body_instance_A{}; t.Ctor(); return t }
//line :906:1
func (t *A_arbace_c2j_emit_body_instance_A) Ctor() {}
//line :906:1
func (t *A_arbace_c2j_emit_body_instance_A) Invoke_O_O_O_O__O(self, ctx__0, ox__1, nil_locals__2 any) any { var cname__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_532.GetRawRoot__O()).Invoke_O_O__O(ctx__0, ox__1); var args__5 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_c2j_emit_body_instance_iter__31000238__31000242_A_New_O_O(ctx__0, nil_locals__2); var tmp2 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_c2j_emit_body_instance_iter__31000238__31000242_A_fn_class; if





	fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_c2j_emit_body_instance_iter__31000238__31000242_A_fn_class = fncls__67d; tmp2 = fncls__67d } else { tmp2 = fncls__67 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); args__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_534.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_535.Invoke_O__O(ox__1))); var tmp3 lang.IFn =




	lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_A_const_536; var tmp5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(cname__4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp7 any; var tmp8 any; var and__1927000168__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_2, A_arbace_c2j_emit_A_const_501.Invoke_O__O(ox__1)); if and__1927000168__auto____6 { tmp8 = A_arbace_c2j_emit_A_const_537.Invoke_O__O(ox__1) } else { tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }; if jrt.J2g_Truth(tmp8) { tmp7 = A_arbace_c2j_emit_A_const_538 } else { tmp7 = nil }; return tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7, args__5)) }
//line :912:1
func A_arbace_c2j_emit_body_instance_iter__31000238__31000242_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_body_instance_iter__31000238__31000242_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_body_instance_iter__31000238__31000242_A{}; t.Ctor_O_O(p0, p1); return t }
//line :912:1
func (t *A_arbace_c2j_emit_body_instance_iter__31000238__31000242_A) Ctor_O_O(c__ctx, c__nil_locals any) { t.F_ctx = c__ctx; t.F_nil_locals = c__nil_locals }
//line :912:1
func (t *A_arbace_c2j_emit_body_instance_iter__31000238__31000242_A) Invoke_O_O__O(self, s__31000239__1 any) any { var tmp1 any = A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_A_New_O_O_O_O(t.F_ctx, t.F_nil_locals, s__31000239__1, self); var tmp2 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_A_fn_class = fncls__66d; tmp2 = fncls__66d } else { tmp2 = fncls__66 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :912:1
func A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :912:1
func (t *A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_A) Ctor_O_O_O_O(c__ctx, c__nil_locals, c__s__31000239, c__iter__31000238 any) { t.F_ctx = c__ctx; t.F_nil_locals = c__nil_locals; t.F_s__31000239 = c__s__31000239; t.F_iter__31000238 = c__iter__31000238 }
//line :912:1
func (t *A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_A) Invoke_O__O(self any) any { { var s__31000239__1 any; var t_ any = t.F_s__31000239; t.F_s__31000239 = nil; s__31000239__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000239__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000239__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000239__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000239__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000241__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_fn__31000244_A_New_O_O_O_I_O(t.F_ctx, t.F_nil_locals, b__31000241__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_fn__31000244_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_fn__31000244_A_fn_class = fncls__65d; tmp2 = fncls__65d } else { tmp2 = fncls__65 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000238); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000241__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000239__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000241__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000239__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp5 any
														if jrt.NN(jrt.IdentityHashMap_Cast(t.F_nil_locals)).ContainsKey_O__Z(lb__4) { tmp5 = nil } else { var b__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_533.GetRawRoot__O()); var tmp7 any = t.F_ctx


		tmp5 = tmp6.Invoke_O_O_O__O(tmp7, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit_A_const_266, lb__4, A_arbace_c2j_emit_A_const_270, jrt.Boolean_FALSE.Ref())), jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__5))).Ref()) }
//line :912:1
	var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__31000238); return tmp4.Invoke_O_O__O(tmp5, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000239__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :912:1
func A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_fn__31000244_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_fn__31000244_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_fn__31000244_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :912:1
func (t *A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_fn__31000244_A) Ctor_O_O_O_I_O(c__ctx, c__nil_locals, c__b__31000241 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ctx = c__ctx; t.F_nil_locals = c__nil_locals; t.F_b__31000241 = c__b__31000241; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :912:1
func (t *A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_fn__31000244_A) Invoke_O__O(self any) any { { var i__31000240__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000240__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000240__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000241; var tmp4 any
																if jrt.NN(jrt.IdentityHashMap_Cast(t.F_nil_locals)).ContainsKey_O__Z(lb__2) { tmp4 = nil } else { var b__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__2); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_533.GetRawRoot__O()); var tmp6 any = t.F_ctx


		tmp4 = tmp5.Invoke_O_O_O__O(tmp6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit_A_const_266, lb__2, A_arbace_c2j_emit_A_const_270, jrt.Boolean_FALSE.Ref())), jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__3))).Ref()) }
//line :912:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__31000240__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000240__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_c2j_emit_fn_wrap_A_New() *A_arbace_c2j_emit_fn_wrap_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_fn_wrap_A{}; t.Ctor(); return t }
//line :919:1
func (t *A_arbace_c2j_emit_fn_wrap_A) Ctor() {}
//line :919:1
func (t *A_arbace_c2j_emit_fn_wrap_A) Invoke_O_O_O_O__O(self, ctx__0, ox__1, body__2 any) any { var cname__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_532.GetRawRoot__O()).Invoke_O_O__O(ctx__0, ox__1); var tmp1 *lang.Keyword = A_arbace_c2j_emit_A_const_539; var k__5 any = tmp1.Invoke_O__O(lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_311.Invoke_O__O(ctx__0)), cname__4)); var f__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(cname__4, Lit_252); var c__7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_295.GetRawRoot__O()).Invoke_O_O__O(ctx__0, Lit_253); var cls__8 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_A_const_540; var tmp4 any = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(c__7, A_arbace_c2j_emit_A_const_541), f__6); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_A_const_542; var tmp7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_543, c__7); var tmp8 any; var d__8 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_254), jrt.RefArrayOf(jrt.Object_class, c__7, nil)).Ref()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_emit_A_const_544; tmp8 =












	tmp9.Invoke_O_O_O_O__O(tmp10, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(d__8, A_arbace_c2j_emit_A_const_545), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_546, A_arbace_c2j_emit_A_const_547), cname__4, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(k__5)).Ref())), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_548, f__6, d__8), d__8); cls__8 = /*line :929:1*/tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5.Invoke_O_O_O_O__O(tmp6, tmp7, tmp8, c__7)); if








	jrt.J2g_Truth(k__5) {
		var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_A_const_549; var tmp13 any = A_arbace_c2j_emit_A_const_550; return tmp11.Invoke_O_O_O_O_O_O__O(tmp12, tmp13, body__2, cls__8, nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_551, k__5)) } else {
			return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_c2j_emit_A_const_552, A_arbace_c2j_emit_A_const_553, body__2, cls__8, nil) } }

func A_arbace_c2j_emit_fn_instance_A_New() *A_arbace_c2j_emit_fn_instance_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_fn_instance_A{}; t.Ctor(); return t }
//line :942:1
func (t *A_arbace_c2j_emit_fn_instance_A) Ctor() {}
//line :942:1
func (t *A_arbace_c2j_emit_fn_instance_A) Invoke_O_O_O_O__O(self, ctx__0, ox__1, nil_locals__2 any) any { var b__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_554.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, ox__1, nil_locals__2); if



	lang.Util_Equiv_O_O__Z_NoInit(Lit_73, A_arbace_c2j_emit_A_const_501.Invoke_O__O(ox__1)) { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_555.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, ox__1, b__4) } else { return b__4 } }

func A_arbace_c2j_emit_emit_letfn_A_New() *A_arbace_c2j_emit_emit_letfn_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_letfn_A{}; t.Ctor(); return t }
//line :948:1
func (t *A_arbace_c2j_emit_emit_letfn_A) Ctor() {}
//line :948:1
func (t *A_arbace_c2j_emit_emit_letfn_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var bis__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_234.GetRawRoot__O(), A_arbace_c2j_emit_A_const_516.Invoke_O__O(n__1)); var lbs__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_556.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_518, bis__4)); var syms__6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_emit_letfn_fn__31000253_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_c2j_emit_emit_letfn_fn__31000253_A_fn_class; if


	fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_179, false); A_arbace_c2j_emit_emit_letfn_fn__31000253_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; syms__6 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), bis__4); var bsyms__7 any; var tmp4 lang.IFn = /*line :948:1*/lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_emit_letfn_fn__31000255_A_New(); var tmp6 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_c2j_emit_emit_letfn_fn__31000255_A_fn_class; if



	fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_180, false); A_arbace_c2j_emit_emit_letfn_fn__31000255_A_fn_class = fncls__77d; tmp6 = fncls__77d } else { tmp6 = fncls__77 }; bsyms__7 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), syms__6); var bodies__8 any; var iter__1927001039__auto____8 any; var tmp7 any = /*line :948:1*/A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_A_New_O_O(ctx__0, lbs__5); var tmp8 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_A_fn_class; if




	fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_181, false); A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_A_fn_class = fncls__70d; tmp8 = fncls__70d } else { tmp8 = fncls__70 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); bodies__8 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(bis__4); var sets__9 any; var iter__1927001039__auto____9 any; var tmp9 any = /*line :948:1*/A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_A_New_O_O(ctx__0, lbs__5); var tmp10 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_A_fn_class; if





	fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_182, false); A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_A_fn_class = fncls__75d; tmp10 = fncls__75d } else { tmp10 = fncls__75 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); sets__9 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_457.GetRawRoot__O(), bis__4, bsyms__7)); var tmp11 lang.IFn =





	lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_A_const_558; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_emit_emit_letfn_fn__31000286_A_New_O(ctx__0); var tmp17 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_c2j_emit_emit_letfn_fn__31000286_A_fn_class; if
	fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_183, false); A_arbace_c2j_emit_emit_letfn_fn__31000286_A_fn_class = fncls__78d; tmp17 = fncls__78d } else { tmp17 = fncls__78 }; var tmp18 any = /*line :960:1*/tmp15.Invoke_O_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil), bsyms__7, bis__4, bodies__8); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()); var tmp20 any = A_arbace_c2j_emit_emit_letfn_fn__31000288_A_New_O(ctx__0); var tmp21 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_c2j_emit_emit_letfn_fn__31000288_A_fn_class; if

	fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_184, false); A_arbace_c2j_emit_emit_letfn_fn__31000288_A_fn_class = fncls__79d; tmp21 = fncls__79d } else { tmp21 = fncls__79 }; var tmp22 any = /*line :960:1*/tmp13.Invoke_O__O(tmp14.Invoke_O_O__O(tmp18, tmp19.Invoke_O_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil), syms__6, bsyms__7, bis__4))); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp24 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_559); var tmp25 any; if


	jrt.J2g_Truth(unboxed_QMARK___2) { tmp25 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_520.Invoke_O__O(n__1)) } else { tmp25 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_520.Invoke_O__O(n__1)) }; return /*line :960:1*/ tmp11.Invoke_O_O_O__O(tmp12, tmp22, tmp23.Invoke_O_O_O__O(tmp24, sets__9, lang.Tuple_Create_O__IPersistentVector(tmp25))) }
//line :951:1
func A_arbace_c2j_emit_emit_letfn_fn__31000253_A_New() *A_arbace_c2j_emit_emit_letfn_fn__31000253_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_letfn_fn__31000253_A{}; t.Ctor(); return t }
//line :951:1
func (t *A_arbace_c2j_emit_emit_letfn_fn__31000253_A) Ctor() {}
//line :951:1
func (t *A_arbace_c2j_emit_emit_letfn_fn__31000253_A) Invoke_O_O__O(self, p1__31000251_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_518.Invoke_O__O(p1__31000251_SHARP___1))) }
func A_arbace_c2j_emit_emit_letfn_fn__31000255_A_New() *A_arbace_c2j_emit_emit_letfn_fn__31000255_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_letfn_fn__31000255_A{}; t.Ctor(); return t }
//line :952:1
func (t *A_arbace_c2j_emit_emit_letfn_fn__31000255_A) Ctor() {}
//line :952:1
func (t *A_arbace_c2j_emit_emit_letfn_fn__31000255_A) Invoke_O_O__O(self, p1__31000252_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_185, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__31000252_SHARP___1)).Ref()) }
func A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_A{}; t.Ctor_O_O(p0, p1); return t }
//line :953:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_A) Ctor_O_O(c__ctx, c__lbs any) { t.F_ctx = c__ctx; t.F_lbs = c__lbs }
//line :953:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_A) Invoke_O_O__O(self, s__31000258__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_A_New_O_O_O_O(t.F_ctx, s__31000258__1, t.F_lbs, self); var tmp2 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_186, false); A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_A_fn_class = fncls__69d; tmp2 = fncls__69d } else { tmp2 = fncls__69 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :953:1
func A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :953:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_A) Ctor_O_O_O_O(c__ctx, c__s__31000258, c__lbs, c__iter__31000257 any) { t.F_ctx = c__ctx; t.F_s__31000258 = c__s__31000258; t.F_lbs = c__lbs; t.F_iter__31000257 = c__iter__31000257 }
//line :953:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_A) Invoke_O__O(self any) any { { var s__31000258__1 any; var t_ any = t.F_s__31000258; t.F_s__31000258 = nil; s__31000258__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000258__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000258__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000258__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000258__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000260__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_fn__31000263_A_New_O_O_O_I_O(t.F_ctx, b__31000260__6, t.F_lbs, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_fn__31000263_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_187, false); A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_fn__31000263_A_fn_class = fncls__68d; tmp2 = fncls__68d } else { tmp2 = fncls__68 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000257); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000260__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000258__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000260__6), nil) } } else { var bi__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000258__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_554.GetRawRoot__O()); var tmp5 any = t.F_ctx; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__31000257); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_488.Invoke_O__O(bi__4)), t.F_lbs), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000258__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :953:1
func A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_fn__31000263_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_fn__31000263_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_fn__31000263_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :953:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_fn__31000263_A) Ctor_O_O_O_I_O(c__ctx, c__b__31000260, c__lbs any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ctx = c__ctx; t.F_b__31000260 = c__b__31000260; t.F_lbs = c__lbs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :953:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_fn__31000263_A) Invoke_O__O(self any) any { { var i__31000259__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000259__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var bi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000259__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000260; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_554.GetRawRoot__O()); var tmp5 any = t.F_ctx; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_488.Invoke_O__O(bi__2)), t.F_lbs)); i__31000259__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000259__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_A{}; t.Ctor_O_O(p0, p1); return t }
//line :954:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_A) Ctor_O_O(c__ctx, c__lbs any) { t.F_ctx = c__ctx; t.F_lbs = c__lbs }
//line :954:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_A) Invoke_O_O__O(self, s__31000268__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_A_New_O_O_O_O(t.F_ctx, s__31000268__1, t.F_lbs, self); var tmp2 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_188, false); A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_A_fn_class = fncls__74d; tmp2 = fncls__74d } else { tmp2 = fncls__74 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :954:1
func A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :954:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_A) Ctor_O_O_O_O(c__ctx, c__s__31000268, c__lbs, c__iter__31000267 any) { t.F_ctx = c__ctx; t.F_s__31000268 = c__s__31000268; t.F_lbs = c__lbs; t.F_iter__31000267 = c__iter__31000267 }
//line :954:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_A) Invoke_O__O(self any) any { { var s__31000268__1 any; var t_ any = t.F_s__31000268; t.F_s__31000268 = nil; s__31000268__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000268__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__31000275__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var bi__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000275__4, lang.RT_IntCast_J__I_NoInit(0), nil); var bs__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000275__4, lang.RT_IntCast_J__I_NoInit(1), nil); var ox__7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_488.Invoke_O__O(bi__5)); var cname__8 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_532.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, ox__7); var iterys__1927001035__auto____9 any; var tmp1 any = A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_A_New_O_O(bs__6, t.F_lbs); var tmp2 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_A_fn_class; _ = cname__8; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_189, false); A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_A_fn_class = fncls__73d; tmp2 = fncls__73d } else { tmp2 = fncls__73 }; iterys__1927001035__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____10 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____9).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_534.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_535.Invoke_O__O(ox__7)))); if jrt.J2g_Truth(fs__1927001036__auto____10) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000267); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____10, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000268__1))) } else { s__31000268__1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000268__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :954:1
func A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_A{}; t.Ctor_O_O(p0, p1); return t }
//line :954:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_A) Ctor_O_O(c__bs, c__lbs any) { t.F_bs = c__bs; t.F_lbs = c__lbs }
//line :954:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_A) Invoke_O_O__O(self, s__31000270__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_A_New_O_O_O_O(t.F_bs, s__31000270__1, t.F_lbs, self); var tmp2 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_190, false); A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_A_fn_class = fncls__72d; tmp2 = fncls__72d } else { tmp2 = fncls__72 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :954:1
func A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :954:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_A) Ctor_O_O_O_O(c__bs, c__s__31000270, c__lbs, c__iter__31000269 any) { t.F_bs = c__bs; t.F_s__31000270 = c__s__31000270; t.F_lbs = c__lbs; t.F_iter__31000269 = c__iter__31000269 }
//line :954:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_A) Invoke_O__O(self any) any { { var s__31000270__1 any; var t_ any = t.F_s__31000270; t.F_s__31000270 = nil; s__31000270__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000270__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000270__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000270__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000270__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000272__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_fn__31000280_A_New_O_O_O_I_O(t.F_bs, b__31000272__6, t.F_lbs, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_fn__31000280_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_191, false); A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_fn__31000280_A_fn_class = fncls__71d; tmp2 = fncls__71d } else { tmp2 = fncls__71 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000269); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000272__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000270__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000272__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000270__3); if jrt.NN(jrt.IdentityHashMap_Cast(t.F_lbs)).ContainsKey_O__Z(lb__4) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_557; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__31000269); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_231.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__4)), t.F_bs), lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__4))), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000270__3))) } else { s__31000270__1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000270__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :954:1
func A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_fn__31000280_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_fn__31000280_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_fn__31000280_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :954:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_fn__31000280_A) Ctor_O_O_O_I_O(c__bs, c__b__31000272, c__lbs any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_bs = c__bs; t.F_b__31000272 = c__b__31000272; t.F_lbs = c__lbs; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :954:1
func (t *A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_fn__31000280_A) Invoke_O__O(self any) any { { var i__31000271__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000271__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000271__1)); if jrt.NN(jrt.IdentityHashMap_Cast(t.F_lbs)).ContainsKey_O__Z(lb__2) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000272; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_557; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_231.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__2)), t.F_bs), lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__2)))); i__31000271__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000271__1); continue L1 } else { i__31000271__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000271__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_c2j_emit_emit_letfn_fn__31000286_A_New_O(p0 any) *A_arbace_c2j_emit_emit_letfn_fn__31000286_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_letfn_fn__31000286_A{}; t.Ctor_O(p0); return t }
//line :961:1
func (t *A_arbace_c2j_emit_emit_letfn_fn__31000286_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :961:1
func (t *A_arbace_c2j_emit_emit_letfn_fn__31000286_A) Invoke_O_O_O_O__O(self, bs__1, bi__2, b__3 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_532.GetRawRoot__O()); var tmp2 any = t.F_ctx; return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(bs__1, lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_488.Invoke_O__O(bi__2))))), b__3) }
func A_arbace_c2j_emit_emit_letfn_fn__31000288_A_New_O(p0 any) *A_arbace_c2j_emit_emit_letfn_fn__31000288_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_letfn_fn__31000288_A{}; t.Ctor_O(p0); return t }
//line :962:1
func (t *A_arbace_c2j_emit_emit_letfn_fn__31000288_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :962:1
func (t *A_arbace_c2j_emit_emit_letfn_fn__31000288_A) Invoke_O_O_O_O__O(self, s__1, bs__2, bi__3 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_555.GetRawRoot__O()); var tmp2 any = t.F_ctx; return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(s__1, A_arbace_c2j_emit_A_const_238), tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_488.Invoke_O__O(bi__3)), bs__2)) }


func A_arbace_c2j_emit_emit_try_A_New() *A_arbace_c2j_emit_emit_try_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_try_A{}; t.Ctor(); return t }
//line :965:1
func (t *A_arbace_c2j_emit_emit_try_A) Ctor() {}
//line :965:1
func (t *A_arbace_c2j_emit_emit_try_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var body__4 any; var tmp1 any = A_arbace_c2j_emit_emit_try_body__31000291_A_New_O_O(ctx__0, unboxed_QMARK___2); var tmp2 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_c2j_emit_emit_try_body__31000291_A_fn_class; if
													fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_218, false); A_arbace_c2j_emit_emit_try_body__31000291_A_fn_class = fncls__80d; tmp2 = fncls__80d } else { tmp2 = fncls__80 }; body__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn =
													lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_564; var tmp6 any = tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(body__4).Invoke_O__O(A_arbace_c2j_emit_A_const_565.Invoke_O__O(n__1))); var tmp7 any; var iter__1927001039__auto____5 any; var tmp8 any = A_arbace_c2j_emit_emit_try_iter__31000293__31000297_A_New_O(body__4); var tmp9 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_c2j_emit_emit_try_iter__31000293__31000297_A_fn_class; if
													fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_219, false); A_arbace_c2j_emit_emit_try_iter__31000293__31000297_A_fn_class = fncls__83d; tmp9 = fncls__83d } else { tmp9 = fncls__83 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); tmp7 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_c2j_emit_A_const_566.Invoke_O__O(n__1)); var tmp10 any = tmp7; var tmp11 lang.IPersistentVector; if


	jrt.J2g_Truth(A_arbace_c2j_emit_A_const_563.Invoke_O__O(n__1)) { var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_emit_A_const_567; tmp11 = lang.Tuple_Create_O__IPersistentVector(tmp12.Invoke_O_O__O(tmp13, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_563.Invoke_O__O(n__1)))) } else { tmp11 = nil }; return /*line :967:1*/ tmp3.Invoke_O_O_O__O(tmp6, tmp10, tmp11) }
//line :966:1
func A_arbace_c2j_emit_emit_try_body__31000291_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_try_body__31000291_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_try_body__31000291_A{}; t.Ctor_O_O(p0, p1); return t }
//line :966:1
func (t *A_arbace_c2j_emit_emit_try_body__31000291_A) Ctor_O_O(c__ctx, c__unboxed_QMARK_ any) { t.F_ctx = c__ctx; t.F_unboxed_QMARK_ = c__unboxed_QMARK_ }
//line :966:1
func (t *A_arbace_c2j_emit_emit_try_body__31000291_A) Invoke_O_O__O(self, e__1 any) any { if jrt.J2g_Truth(t.F_unboxed_QMARK_) { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__1) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, e__1) } }

func A_arbace_c2j_emit_emit_try_iter__31000293__31000297_A_New_O(p0 any) *A_arbace_c2j_emit_emit_try_iter__31000293__31000297_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_try_iter__31000293__31000297_A{}; t.Ctor_O(p0); return t }
//line :968:1
func (t *A_arbace_c2j_emit_emit_try_iter__31000293__31000297_A) Ctor_O(c__body any) { t.F_body = c__body }
//line :968:1
func (t *A_arbace_c2j_emit_emit_try_iter__31000293__31000297_A) Invoke_O_O__O(self, s__31000294__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_A_New_O_O_O(s__31000294__1, self, t.F_body); var tmp2 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_220, false); A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_A_fn_class = fncls__82d; tmp2 = fncls__82d } else { tmp2 = fncls__82 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :968:1
func A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :968:1
func (t *A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_A) Ctor_O_O_O(c__s__31000294, c__iter__31000293, c__body any) { t.F_s__31000294 = c__s__31000294; t.F_iter__31000293 = c__iter__31000293; t.F_body = c__body }
//line :968:1
func (t *A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_A) Invoke_O__O(self any) any { { var s__31000294__1 any; var t_ any = t.F_s__31000294; t.F_s__31000294 = nil; s__31000294__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000294__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000294__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000294__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000294__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000296__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_fn__31000299_A_New_O_I_O_O(b__31000296__6, size__1927001038__auto____5, t.F_body, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_fn__31000299_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_221, false); A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_fn__31000299_A_fn_class = fncls__81d; tmp2 = fncls__81d } else { tmp2 = fncls__81 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000293); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000296__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000294__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000296__6), nil) } } else { var c__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000294__3); var cn__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(c__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_560; var tmp6 lang.IFn = lang.IFn_Cast(t.F_body); var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__31000293); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_472.Invoke_O__O(cn__5)), lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_561.Invoke_O__O(cn__5))), tmp6.Invoke_O__O(A_arbace_c2j_emit_A_const_562.Invoke_O__O(cn__5))), tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000294__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :968:1
func A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_fn__31000299_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_fn__31000299_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_fn__31000299_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :968:1
func (t *A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_fn__31000299_A) Ctor_O_I_O_O(c__b__31000296 any, c__size__1927001038__auto__ int32, c__body, c__c__1927001037__auto__ any) { t.F_b__31000296 = c__b__31000296; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_body = c__body; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :968:1
func (t *A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_fn__31000299_A) Invoke_O__O(self any) any { { var i__31000295__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000295__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000295__1)); var cn__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(c__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000296; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_560; var tmp6 lang.IFn = lang.IFn_Cast(t.F_body); tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_472.Invoke_O__O(cn__3)), lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_561.Invoke_O__O(cn__3))), tmp6.Invoke_O__O(A_arbace_c2j_emit_A_const_562.Invoke_O__O(cn__3)))); i__31000295__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000295__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_c2j_emit_emit_case_A_New() *A_arbace_c2j_emit_emit_case_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_case_A{}; t.Ctor(); return t }
//line :974:1
func (t *A_arbace_c2j_emit_emit_case_A) Ctor() {}
//line :974:1
func (t *A_arbace_c2j_emit_emit_case_A) Invoke_O_O_O_O__O(self, ctx__0, n__1, unboxed_QMARK___2 any) any { var e__4 any = A_arbace_c2j_emit_A_const_568.Invoke_O__O(n__1); var en__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(e__4); var pt__6 any = A_arbace_c2j_emit_A_const_233.Invoke_O__O(en__5); var shift__7 any = A_arbace_c2j_emit_A_const_569.Invoke_O__O(n__1); var mask__8 any = A_arbace_c2j_emit_A_const_570.Invoke_O__O(n__1); var sm__9 any; var tmp1 any = A_arbace_c2j_emit_emit_case_sm__31000304_A_New_O_O(mask__8, shift__7); var tmp2 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_c2j_emit_emit_case_sm__31000304_A_fn_class; if




	fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_c2j_emit_emit_case_sm__31000304_A_fn_class = fncls__86d; tmp2 = fncls__86d } else { tmp2 = fncls__86 }; sm__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tests__10 any = /*line :974:1*/lang.IFn_Cast(A_arbace_c2j_emit_A_const_192.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_599.GetRawRoot__O()).Invoke__O(), A_arbace_c2j_emit_A_const_600.Invoke_O__O(n__1)); var thens__11 any = A_arbace_c2j_emit_A_const_573.Invoke_O__O(n__1); var ret__12 any; var tmp3 any = A_arbace_c2j_emit_emit_case_ret__31000306_A_New_O_O(ctx__0, unboxed_QMARK___2); var tmp4 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_c2j_emit_emit_case_ret__31000306_A_fn_class; if







	fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_c2j_emit_emit_case_ret__31000306_A_fn_class = fncls__87d; tmp4 = fncls__87d } else { tmp4 = fncls__87 }; ret__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var lbl__13 any = /*line :974:1*/lang.IFn_Cast(A_arbace_c2j_emit_A_const_574.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_295.GetRawRoot__O()).Invoke_O_O__O(ctx__0, Lit_111))); var int_test_QMARK___14 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_c2j_emit_A_const_575.Invoke_O__O(n__1), A_arbace_c2j_emit_A_const_135); var key__15 any; if










	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(int_test_QMARK___14).Ref())) {
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_A_const_601; key__15 = lang.IFn_Cast(sm__9).Invoke_O__O(tmp5.Invoke_O_O__O(tmp6, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, e__4))) } else {
//line :985:1
			if lang.Util_Identical_O_O__Z_NoInit(pt__6, nil) { key__15 = nil } else { if jrt.J2g_Truth(lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, jrt.Byte_TYPE.Ref(), jrt.Long_TYPE.Ref(), jrt.Short_TYPE.Ref(), jrt.Integer_TYPE.Ref()))).Invoke_O__O(pt__6)) {


				var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_emit_A_const_602; key__15 = lang.IFn_Cast(sm__9).Invoke_O__O(tmp7.Invoke_O_O__O(tmp8, lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(ctx__0, e__4))) } else {
//line :985:1
					if A_arbace_c2j_emit_A_const_64 != nil { key__15 = A_arbace_c2j_emit_A_const_576 } else { key__15 = nil } } } }; var skip__16 any = /*line :974:1*/lang.IFn_Cast(A_arbace_c2j_emit_A_const_577.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_603.Invoke_O__O(n__1)); var arm__17 any; var tmp9 any = A_arbace_c2j_emit_emit_case_arm__31000308_A_New_O_O_O_O_O_O_Z_O_O(e__4, mask__8, ctx__0, lbl__13, n__1, skip__16, int_test_QMARK___14, ret__12, pt__6); var tmp10 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_c2j_emit_emit_case_arm__31000308_A_fn_class; if
















	fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_c2j_emit_emit_case_arm__31000308_A_fn_class = fncls__90d; tmp10 = fncls__90d } else { tmp10 = fncls__90 }; arm__17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var sw__18 any; if


















	lang.Util_Equiv_O_O__Z_NoInit(key__15, A_arbace_c2j_emit_A_const_576) { sw__18 = nil } else { var tmp11 bool
		var and__1927000168__auto____18 bool = int_test_QMARK___14
		if and__1927000168__auto____18 { tmp11 = lang.Util_Identical_O_O__Z_NoInit(pt__6, nil) } else { tmp11 = and__1927000168__auto____18 }
//line :1010:1
		if tmp11 {


			var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_emit_A_const_604; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_emit_A_const_605; var tmp16 any = A_arbace_c2j_emit_A_const_606; var tmp17 any = tmp14.Invoke_O_O_O__O(tmp15, tmp16, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, e__4)); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp20 any = A_arbace_c2j_emit_A_const_607; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp22 any = A_arbace_c2j_emit_A_const_608; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp24 any = A_arbace_c2j_emit_A_const_609; var tmp25 any = A_arbace_c2j_emit_A_const_610; var tmp26 any = tmp19.Invoke_O_O__O(tmp20, lang.IFn_Cast(sm__9).Invoke_O__O(tmp21.Invoke_O_O__O(tmp22, tmp23.Invoke_O_O_O__O(tmp24, tmp25, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, e__4))))); var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()); var tmp28 any = A_arbace_c2j_emit_emit_case_fn__31000311_A_New_O_O(arm__17, thens__11); var tmp29 *jrt.Class
			var fncls__91 /*line :1013:1*/*jrt.Class = A_arbace_c2j_emit_emit_case_fn__31000311_A_fn_class

			if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_c2j_emit_emit_case_fn__31000311_A_fn_class = fncls__91d; tmp29 = fncls__91d } else { tmp29 = fncls__91 }
//line :1013:1
			sw__18 = tmp12.Invoke_O_O_O__O(tmp13, tmp17, tmp18.Invoke_O_O__O(tmp26, tmp27.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil), tests__10))) } else {
//line :1010:1
				if A_arbace_c2j_emit_A_const_64 != nil {






					var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp31 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_611, key__15); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()); var tmp33 any = A_arbace_c2j_emit_emit_case_fn__31000317_A_New_O_O(arm__17, thens__11); var tmp34 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_c2j_emit_emit_case_fn__31000317_A_fn_class
					if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_c2j_emit_emit_case_fn__31000317_A_fn_class = fncls__92d; tmp34 = fncls__92d } else { tmp34 = fncls__92 }
//line :1017:1
					sw__18 = tmp30.Invoke_O_O__O(tmp31, tmp32.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil), tests__10)) } else {
//line :1010:1
						sw__18 = nil } } }; var tmp35 lang.IFn =








	lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp36 any = A_arbace_c2j_emit_A_const_612; return tmp35.Invoke_O_O_O_O__O(tmp36, lbl__13, sw__18, lang.IFn_Cast(ret__12).Invoke_O__O(A_arbace_c2j_emit_A_const_613.Invoke_O__O(n__1))) }
//line :979:1
func A_arbace_c2j_emit_emit_case_sm__31000304_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_case_sm__31000304_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_case_sm__31000304_A{}; t.Ctor_O_O(p0, p1); return t }
//line :979:1
func (t *A_arbace_c2j_emit_emit_case_sm__31000304_A) Ctor_O_O(c__mask, c__shift any) { t.F_mask = c__mask; t.F_shift = c__shift }
//line :979:1
func (t *A_arbace_c2j_emit_emit_case_sm__31000304_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 bool; var na_84 any = t.F_mask; if jrt.Long_InstanceOf(na_84) { var n0_85 int64 = jrt.NN(jrt.Long_Cast(na_84)).LongValue__J(); tmp1 = n0_85 == 0 } else { if jrt.Double_InstanceOf(na_84) { var n0_85_2 float64 = jrt.NN(jrt.Double_Cast(na_84)).DoubleValue__D(); tmp1 = n0_85_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_84) } }; if tmp1 { return f__1 } else { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_A_const_571; return tmp2.Invoke_O_O_O__O(tmp3, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_572, f__1, t.F_shift), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_UncheckedIntCast_O__I_NoInit(t.F_mask)).Ref()) } }


func A_arbace_c2j_emit_emit_case_ret__31000306_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_case_ret__31000306_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_case_ret__31000306_A{}; t.Ctor_O_O(p0, p1); return t }
//line :982:1
func (t *A_arbace_c2j_emit_emit_case_ret__31000306_A) Ctor_O_O(c__ctx, c__unboxed_QMARK_ any) { t.F_ctx = c__ctx; t.F_unboxed_QMARK_ = c__unboxed_QMARK_ }
//line :982:1
func (t *A_arbace_c2j_emit_emit_case_ret__31000306_A) Invoke_O_O__O(self, x__1 any) any { if jrt.J2g_Truth(t.F_unboxed_QMARK_) { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, x__1) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, x__1) } }








func A_arbace_c2j_emit_emit_case_arm__31000308_A_New_O_O_O_O_O_O_Z_O_O(p0, p1, p2, p3, p4, p5 any, p6 bool, p7, p8 any) *A_arbace_c2j_emit_emit_case_arm__31000308_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_case_arm__31000308_A{}; t.Ctor_O_O_O_O_O_O_Z_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :991:1
func (t *A_arbace_c2j_emit_emit_case_arm__31000308_A) Ctor_O_O_O_O_O_O_Z_O_O(c__e, c__mask, c__ctx, c__lbl, c__n, c__skip any, c__int_test_QMARK_ bool, c__ret, c__pt any) { t.F_e = c__e; t.F_mask = c__mask; t.F_ctx = c__ctx; t.F_lbl = c__lbl; t.F_n = c__n; t.F_skip = c__skip; t.F_int_test_QMARK_ = c__int_test_QMARK_; t.F_ret = c__ret; t.F_pt = c__pt }
//line :991:1
func (t *A_arbace_c2j_emit_emit_case_arm__31000308_A) Invoke_O_O_O_O__O(self, i__1, t__2, th__3 any) any {
	var tmp1 bool; var and__1927000168__auto____4 bool = t.F_int_test_QMARK_
	if and__1927000168__auto____4 { tmp1 = lang.Util_Identical_O_O__Z_NoInit(t.F_pt, nil) } else { tmp1 = and__1927000168__auto____4 }
//line :992:1
	if tmp1 {

		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_A_const_579; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_582; var tmp6 any = t.F_lbl; return tmp2.Invoke_O_O_O__O(tmp3, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_580, A_arbace_c2j_emit_A_const_581), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t.F_e), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t__2)), tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3))) } else {
//line :992:1
			var tmp7 bool; var and__1927000168__auto____4_2 bool = t.F_int_test_QMARK_




			if and__1927000168__auto____4_2 { tmp7 = lang.Util_Equiv_O_O__Z_NoInit(t.F_pt, jrt.Long_TYPE.Ref()) } else { tmp7 = and__1927000168__auto____4_2 }
//line :992:1
			if tmp7 {





				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_emit_A_const_583; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_emit_A_const_584; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_emit_A_const_585; var tmp14 any = t.F_lbl; return tmp8.Invoke_O_O_O__O(tmp9, tmp10.Invoke_O_O_O__O(tmp11, lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t__2), lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t.F_e)), tmp12.Invoke_O_O_O__O(tmp13, tmp14, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3))) } else {
//line :992:1
					if t.F_int_test_QMARK_ {







						var tmp15 bool; var na_88 any = t.F_mask; if jrt.Long_InstanceOf(na_88) { var n0_89 int64 = jrt.NN(jrt.Long_Cast(na_88)).LongValue__J(); tmp15 = n0_89 == 0 } else { if jrt.Double_InstanceOf(na_88) { var n0_89_2 float64 = jrt.NN(jrt.Double_Cast(na_88)).DoubleValue__D(); tmp15 = n0_89_2 == 0.0 } else { tmp15 = lang.Numbers_IsZero_O__Z_NoInit(na_88) } }; if tmp15 {
							var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp17 any = A_arbace_c2j_emit_A_const_586; var tmp18 any = t.F_lbl; return tmp16.Invoke_O_O_O__O(tmp17, tmp18, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3)) } else {
								var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp20 any = A_arbace_c2j_emit_A_const_587; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp22 any = A_arbace_c2j_emit_A_const_588; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp24 any = A_arbace_c2j_emit_A_const_589; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp26 any = A_arbace_c2j_emit_A_const_590; var tmp27 any = t.F_lbl; return tmp19.Invoke_O_O_O__O(tmp20, tmp21.Invoke_O_O_O__O(tmp22, lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t__2), tmp23.Invoke_O_O__O(tmp24, lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t.F_e))), tmp25.Invoke_O_O_O__O(tmp26, tmp27, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3))) } } else {
//line :992:1
									if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(t.F_skip, i__1)) {










										var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp29 any = A_arbace_c2j_emit_A_const_591; var tmp30 any = t.F_lbl; return tmp28.Invoke_O_O_O__O(tmp29, tmp30, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3)) } else {
//line :992:1
											if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_c2j_emit_A_const_575.Invoke_O__O(t.F_n), A_arbace_c2j_emit_A_const_578) {












												var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp32 any = A_arbace_c2j_emit_A_const_592; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp34 any = A_arbace_c2j_emit_A_const_593; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp36 any = A_arbace_c2j_emit_A_const_594; var tmp37 any = t.F_lbl; return tmp31.Invoke_O_O_O__O(tmp32, tmp33.Invoke_O_O_O__O(tmp34, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t.F_e), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t__2)), tmp35.Invoke_O_O_O__O(tmp36, tmp37, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3))) } else {
//line :992:1
													if A_arbace_c2j_emit_A_const_64 != nil {














														var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp39 any = A_arbace_c2j_emit_A_const_595; var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp41 any = A_arbace_c2j_emit_A_const_598; var tmp42 any = t.F_lbl; return tmp38.Invoke_O_O_O__O(tmp39, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_596, A_arbace_c2j_emit_A_const_597), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t.F_e), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, t__2)), tmp40.Invoke_O_O_O__O(tmp41, tmp42, lang.IFn_Cast(t.F_ret).Invoke_O__O(th__3))) } else {
//line :992:1
															return nil
														}
												}
										}
								}
				}
		}
}















func A_arbace_c2j_emit_emit_case_fn__31000311_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_case_fn__31000311_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_case_fn__31000311_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1015:1
func (t *A_arbace_c2j_emit_emit_case_fn__31000311_A) Ctor_O_O(c__arm, c__thens any) { t.F_arm = c__arm; t.F_thens = c__thens }
//line :1015:1
func (t *A_arbace_c2j_emit_emit_case_fn__31000311_A) Invoke_O_O__O(self, p__31000310__1 any) any { var vec__31000312__2 any = p__31000310__1; var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000312__2, lang.RT_IntCast_J__I_NoInit(0), nil); var t__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000312__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_arm); return lang.Tuple_Create_O_O__IPersistentVector(i__3, tmp1.Invoke_O_O_O__O(i__3, t__4, lang.RT_Get_O_O__O_NoInit(t.F_thens, i__3))) }


func A_arbace_c2j_emit_emit_case_fn__31000317_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_case_fn__31000317_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_case_fn__31000317_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1018:1
func (t *A_arbace_c2j_emit_emit_case_fn__31000317_A) Ctor_O_O(c__arm, c__thens any) { t.F_arm = c__arm; t.F_thens = c__thens }
//line :1018:1
func (t *A_arbace_c2j_emit_emit_case_fn__31000317_A) Invoke_O_O__O(self, p__31000316__1 any) any { var vec__31000318__2 any = p__31000316__1; var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000318__2, lang.RT_IntCast_J__I_NoInit(0), nil); var t__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000318__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_arm); return lang.Tuple_Create_O_O__IPersistentVector(i__3, tmp1.Invoke_O_O_O__O(i__3, t__4, lang.RT_Get_O_O__O_NoInit(t.F_thens, i__3))) }








func A_arbace_c2j_emit_box_prim_A_New() *A_arbace_c2j_emit_box_prim_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_box_prim_A{}; t.Ctor(); return t }
//line :1027:1
func (t *A_arbace_c2j_emit_box_prim_A) Ctor() {}
//line :1027:1
func (t *A_arbace_c2j_emit_box_prim_A) Invoke_O_O_O__O(self, f__0, n__1 any) any { var p__3 any = A_arbace_c2j_emit_A_const_233.Invoke_O__O(n__1); var tmp1 any; var and__1927000168__auto____4 any = p__3; if





	jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_614); var and__1927000168__auto____5 any = tmp2.Invoke_O__O(A_arbace_c2j_emit_A_const_501.Invoke_O__O(n__1)); if jrt.J2g_Truth(and__1927000168__auto____5) {
		tmp1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_237.GetRawRoot__O()).Invoke_O__O(p__3) } else {
//line :1033:1
			tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {

				var tmp3 any = A_arbace_c2j_emit_A_const_105; return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_237.GetRawRoot__O()).Invoke_O__O(p__3), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_24.GetRawRoot__O()).Invoke_O__O(p__3))))), f__0) } else {
//line :1033:1
					return f__0 } }




func A_arbace_c2j_emit_emit_A_New() *A_arbace_c2j_emit_emit_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_A{}; t.Ctor(); return t }
//line :1038:1
func (t *A_arbace_c2j_emit_emit_A) Ctor() {}
//line :1038:1
func (t *A_arbace_c2j_emit_emit_A) Invoke_O_O_O__O(self, ctx__0, e__1 any) any { var n__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(e__1); var f__4 any; var G__31000325__4_ any = A_arbace_c2j_emit_A_const_501.Invoke_O__O(n__3); L1:



switch { default: switch lang.Util_Hash_O__I_NoInit(G__31000325__4_) >> 6 & 255 { case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_62) {


























	f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_615.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_FALSE.Ref())
//line :1042:1
	break L1 }; case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_2) {




















































		if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_616.Invoke_O__O(n__3)) {

			lang.IFn_Cast(A_arbace_c2j_emit_A_const_621.GetRawRoot__O()).Invoke_O_O__O(ctx__0, n__3)
//line :1095:1
			f__4 = nil } else {


				f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_617.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.IdentityHashMap_New()) }
//line :1042:1
		break L1 }; case 16: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_63) {















			f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_618.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_FALSE.Ref())
//line :1042:1
			break L1 }; case 17: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_64) {


















































				f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_619.GetRawRoot__O()).Invoke_O_O__O(ctx__0, n__3)
//line :1042:1
				break L1 }; case 20: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_65) {






















					f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_328.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_FALSE.Ref())
//line :1042:1
					break L1 }; case 21: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_66) { var c__5 any = A_arbace_c2j_emit_A_const_622.Invoke_O__O(n__3)








						if lang.IPersistentList_InstanceOf(c__5) { f__4 = A_arbace_c2j_emit_A_const_623 } else { if lang.IPersistentVector_InstanceOf(c__5) { f__4 = A_arbace_c2j_emit_A_const_624 } else { if lang.IPersistentMap_InstanceOf(c__5) { f__4 = A_arbace_c2j_emit_A_const_625 } else { if lang.IPersistentSet_InstanceOf(c__5) { f__4 = A_arbace_c2j_emit_A_const_626 } else { if A_arbace_c2j_emit_A_const_64 != nil {



							f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(Lit_67) } else {
//line :1051:1
								f__4 = nil } } } } }
//line :1042:1
						break L1 }; case 23: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_68) {




















							f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_627.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_FALSE.Ref())
//line :1042:1
							break L1 }; case 28: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_69) {













								f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_628.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_142.Invoke_O__O(n__3))
//line :1042:1
								break L1 }; case 35: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_70) {








































									var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_630; var tmp3 *lang.Keyword = A_arbace_c2j_emit_A_const_631; f__4 = tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_c2j_emit_A_const_221.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_633.Invoke_O__O(n__3))), A_arbace_c2j_emit_A_const_632), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_331.Invoke_O__O(n__3)))
//line :1042:1
									break L1 }; case 50: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_71) { var es__5 any = A_arbace_c2j_emit_A_const_629.Invoke_O__O(n__3)

























































										if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_111.GetRawRoot__O()).Invoke_O__O(es__5)) { f__4 = nil } else {

											var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_634); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_441.GetRawRoot__O()); var tmp7 any = A_arbace_c2j_emit_emit_fn__31000326_A_New_O(ctx__0); var tmp8 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_c2j_emit_emit_fn__31000326_A_fn_class
											if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_c2j_emit_emit_fn__31000326_A_fn_class = fncls__94d; tmp8 = fncls__94d } else { tmp8 = fncls__94 }
//line :1102:1
											f__4 = tmp4.Invoke_O_O_O__O(tmp5, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), lang.IFn_Cast(A_arbace_c2j_emit_A_const_635.GetRawRoot__O()).Invoke_O__O(es__5)), lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_636.GetRawRoot__O()).Invoke_O__O(es__5)))) }
//line :1042:1
										break L1 }; case 51: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_73) {



















































											f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_617.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.IdentityHashMap_New())
//line :1042:1
											break L1 }; case 52: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_74) {































												f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_637.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_FALSE.Ref())
//line :1042:1
												break L1 }; case 63: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_75) {
















													f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_638.GetRawRoot__O()).Invoke_O_O__O(ctx__0, n__3)
//line :1042:1
													break L1 }; case 74: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_76) {





























														var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_emit_A_const_640; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_A_const_641; var tmp13 any = A_arbace_c2j_emit_A_const_642; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_emit_A_const_643; var tmp16 any = A_arbace_c2j_emit_A_const_644; f__4 = tmp9.Invoke_O_O_O__O(tmp10, tmp11.Invoke_O_O_O__O(tmp12, tmp13, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_568.Invoke_O__O(n__3))), tmp14.Invoke_O_O_O__O(tmp15, tmp16, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_486.Invoke_O__O(n__3))))
//line :1042:1
														break L1 }; case 80: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_77) {

































































															f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_639.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_FALSE.Ref())
//line :1042:1
															break L1 }; case 109: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_78) {

																f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_645.Invoke_O__O(n__3))
//line :1042:1
																break L1 }; case 111: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_79) {














																	f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_221.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_142.Invoke_O__O(n__3), A_arbace_c2j_emit_A_const_646)
//line :1042:1
																	break L1 }; case 119: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_80) {




																		f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_221.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_631.Invoke_O__O(n__3), A_arbace_c2j_emit_A_const_647)
//line :1042:1
																		break L1 }; case 125: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_81) {
																			f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_533.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_FALSE.Ref())
//line :1042:1
																			break L1 }; case 128: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_82) {



																				f__4 = A_arbace_c2j_emit_A_const_648.Invoke_O__O(n__3)
//line :1042:1
																				break L1 }; case 133: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_83) { var args__5 any = A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__3)


































																					if lang.Numbers_Lte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(args__5)), 6) {
																						var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()); var tmp19 any = A_arbace_c2j_emit_A_const_651; var tmp20 any = A_arbace_c2j_emit_A_const_105; var tmp21 any = tmp18.Invoke_O_O__O(tmp19, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_107.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(args__5)).Ref(), A_arbace_c2j_emit_A_const_652))))); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp23 any = A_arbace_c2j_emit_emit_fn__31000328_A_New_O(ctx__0); var tmp24 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_c2j_emit_emit_fn__31000328_A_fn_class
																						if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_c2j_emit_emit_fn__31000328_A_fn_class = fncls__95d; tmp24 = fncls__95d } else { tmp24 = fncls__95 }
//line :1078:1
																						f__4 = tmp17.Invoke_O_O__O(tmp21, tmp22.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil), args__5)) } else {

																							f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_649.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_653, args__5, ctx__0) }
//line :1042:1
																					break L1 }; case 136: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_85) {
































































																						f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_650.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_FALSE.Ref())
//line :1042:1
																						break L1 }; case 140: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_86) {


































































																							f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_654.GetRawRoot__O()).Invoke_O_O__O(ctx__0, n__3)
//line :1042:1
																							break L1 }; case 142: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_87) {


																								f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_655.Invoke_O__O(n__3))
//line :1042:1
																								break L1 }; case 149: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_88) {






































																									var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_649.GetRawRoot__O()); var tmp26 any = A_arbace_c2j_emit_A_const_656; f__4 = tmp25.Invoke_O_O_O__O(tmp26, A_arbace_c2j_emit_A_const_657.Invoke_O__O(n__3), ctx__0)
//line :1042:1
																									break L1 }; case 150: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_89) {

























																										var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp28 any = A_arbace_c2j_emit_A_const_658; var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp30 any = A_arbace_c2j_emit_A_const_659; f__4 = tmp27.Invoke_O_O_O__O(tmp28, tmp29.Invoke_O_O__O(tmp30, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_331.Invoke_O__O(n__3))), nil)
//line :1042:1
																										break L1 }; case 155: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_90) {



























																											var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp32 any = A_arbace_c2j_emit_A_const_661; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp34 any = A_arbace_c2j_emit_A_const_662; var tmp35 any = A_arbace_c2j_emit_A_const_663; f__4 = tmp31.Invoke_O_O__O(tmp32, tmp33.Invoke_O_O_O__O(tmp34, tmp35, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_664.Invoke_O__O(n__3))))
//line :1042:1
																											break L1 }; case 166: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_91) {




























																												f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_660.GetRawRoot__O()).Invoke_O_O__O(ctx__0, n__3)
//line :1042:1
																												break L1 }; case 168: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_92) { f__4 = nil; break L1 }; case 176: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_93) {






																													if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_500.Invoke_O__O(n__3)) { f__4 = A_arbace_c2j_emit_A_const_665 } else { f__4 = A_arbace_c2j_emit_A_const_666 }
//line :1042:1
																													break L1 }; case 178: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_94) {
























																														var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp37 any = A_arbace_c2j_emit_A_const_667; var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp39 any = A_arbace_c2j_emit_A_const_668; f__4 = tmp36.Invoke_O_O_O__O(tmp37, tmp38.Invoke_O_O__O(tmp39, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_331.Invoke_O__O(n__3))), nil)
//line :1042:1
																														break L1 }; case 194: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_95) {
































																															var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_649.GetRawRoot__O()); var tmp41 any = A_arbace_c2j_emit_A_const_669; f__4 = tmp40.Invoke_O_O_O__O(tmp41, A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__3), ctx__0)
//line :1042:1
																															break L1 }; case 206: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_96) {


















																																var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp43 any = A_arbace_c2j_emit_A_const_670; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp45 any = A_arbace_c2j_emit_A_const_671; var tmp46 any = A_arbace_c2j_emit_A_const_672; var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp48 any = A_arbace_c2j_emit_A_const_675; f__4 = tmp42.Invoke_O_O_O__O(tmp43, tmp44.Invoke_O_O_O__O(tmp45, tmp46, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_673, A_arbace_c2j_emit_A_const_674)), tmp47.Invoke_O_O__O(tmp48, A_arbace_c2j_emit_A_const_472.Invoke_O__O(n__3)))
//line :1042:1
																																break L1 }; case 212: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_97) {























																																	f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_469.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_FALSE.Ref())
//line :1042:1
																																	break L1 }; case 227: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_98) {





















																																		f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_676.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_FALSE.Ref())
//line :1042:1
																																		break L1 }; case 232: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_99) { var texts__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_678.Invoke_O__O(n__3)); var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp50 any = A_arbace_c2j_emit_A_const_679; var tmp51 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_680, A_arbace_c2j_emit_A_const_681, texts__5); var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp53 any = A_arbace_c2j_emit_A_const_682; var tmp54 any = A_arbace_c2j_emit_A_const_683; var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()); var tmp56 any = A_arbace_c2j_emit_emit_fn__31000330_A_New_O(ctx__0); var tmp57 *jrt.Class
																																			var fncls__96 /*line :1042:1*/*jrt.Class = A_arbace_c2j_emit_emit_fn__31000330_A_fn_class













































																																			if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_c2j_emit_emit_fn__31000330_A_fn_class = fncls__96d; tmp57 = fncls__96d } else { tmp57 = fncls__96 }
//line :1085:1
																																			f__4 = tmp49.Invoke_O_O_O__O(tmp50, tmp51, tmp52.Invoke_O_O_O__O(tmp53, tmp54, tmp55.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp56, tmp57, nil), texts__5, A_arbace_c2j_emit_A_const_281.Invoke_O__O(n__3))))
//line :1042:1
																																			break L1 }; case 236: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_101) {



































































																																				f__4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_677.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_FALSE.Ref())
//line :1042:1
																																				break L1 }; case 241: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_102) {







































																																					var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_649.GetRawRoot__O()); var tmp59 any = A_arbace_c2j_emit_A_const_684; f__4 = tmp58.Invoke_O_O_O__O(tmp59, A_arbace_c2j_emit_A_const_685.Invoke_O__O(n__3), ctx__0)
//line :1042:1
																																					break L1 }; case 249: if lang.Util_Equiv_O_O__Z_NoInit(G__31000325__4_, Lit_103) { var c__5_2 any = A_arbace_c2j_emit_A_const_472.Invoke_O__O(n__3)















































																																						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(c__5_2, ctx__0)) {
																																							var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp61 any = A_arbace_c2j_emit_A_const_686; f__4 = tmp60.Invoke_O_O_O__O(tmp61, lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(ctx__0, c__5_2), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_568.Invoke_O__O(n__3))) } else {
																																								var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp63 any = A_arbace_c2j_emit_A_const_687; f__4 = tmp62.Invoke_O_O_O__O(tmp63, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(c__5_2), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_568.Invoke_O__O(n__3))) }
//line :1042:1
																																						break L1 }; default:
}



































































	var tmp64 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()); var tmp65 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_104, nil, nil); var tmp66 any = A_arbace_c2j_emit_A_const_501.Invoke_O__O(n__3); var tmp67 *jrt.String; if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_688.Invoke_O__O(n__3)) { tmp67 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_105, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_emit_A_const_688.Invoke_O__O(n__3))) } else { tmp67 = nil }; f__4 = tmp64.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp65, jrt.RefArrayOf(jrt.Object_class, nil, tmp66, tmp67.Ref())).Ref())}; return /*line :1112:1*/ lang.IFn_Cast(A_arbace_c2j_emit_A_const_620.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_689.GetRawRoot__O()).Invoke_O_O__O(f__4, n__3), n__3) }
//line :1079:1
func A_arbace_c2j_emit_emit_fn__31000328_A_New_O(p0 any) *A_arbace_c2j_emit_emit_fn__31000328_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn__31000328_A{}; t.Ctor_O(p0); return t }
//line :1079:1
func (t *A_arbace_c2j_emit_emit_fn__31000328_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1079:1
func (t *A_arbace_c2j_emit_emit_fn__31000328_A) Invoke_O_O__O(self, p1__31000324_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__31000324_SHARP___1) }








func A_arbace_c2j_emit_emit_fn__31000330_A_New_O(p0 any) *A_arbace_c2j_emit_emit_fn__31000330_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn__31000330_A{}; t.Ctor_O(p0); return t }
//line :1088:1
func (t *A_arbace_c2j_emit_emit_fn__31000330_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1088:1
func (t *A_arbace_c2j_emit_emit_fn__31000330_A) Invoke_O_O_O__O(self, t__1, a__2 any) any { if jrt.J2g_Truth(t__1) { return nil } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, a__2) } }














func A_arbace_c2j_emit_emit_fn__31000326_A_New_O(p0 any) *A_arbace_c2j_emit_emit_fn__31000326_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn__31000326_A{}; t.Ctor_O(p0); return t }
//line :1103:1
func (t *A_arbace_c2j_emit_emit_fn__31000326_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1103:1
func (t *A_arbace_c2j_emit_emit_fn__31000326_A) Invoke_O_O__O(self, x__1 any) any { var xn__2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(x__1); if
											lang.Util_Equiv_O_O__Z_NoInit(Lit_81, A_arbace_c2j_emit_A_const_501.Invoke_O__O(xn__2)) { return nil } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, x__1) } }









func A_arbace_c2j_emit_emit_unboxed_A_New() *A_arbace_c2j_emit_emit_unboxed_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_unboxed_A{}; t.Ctor(); return t }
//line :1114:1
func (t *A_arbace_c2j_emit_emit_unboxed_A) Ctor() {}
//line :1114:1
func (t *A_arbace_c2j_emit_emit_unboxed_A) Invoke_O_O_O__O(self, ctx__0, e__1 any) any { var n__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(e__1); var tmp1 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_511.GetRawRoot__O()).Invoke_O__O(n__3); if



	jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_90, A_arbace_c2j_emit_A_const_501.Invoke_O__O(n__3))).Ref() }; if jrt.J2g_Truth(tmp1) { } else { lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_222, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_emit_A_const_501.Invoke_O__O(n__3))).Ref()) }; var tmp2 lang.IFn =
	lang.IFn_Cast(A_arbace_c2j_emit_A_const_620.GetRawRoot__O()); var tmp3 any; var G__31000334__4_ any = A_arbace_c2j_emit_A_const_501.Invoke_O__O(n__3); L1:
	switch { default: switch lang.Util_Hash_O__I_NoInit(G__31000334__4_) >> 1 & 63 { case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_71) { var es__5 any = A_arbace_c2j_emit_A_const_629.Invoke_O__O(n__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_690); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp7 any = A_arbace_c2j_emit_emit_unboxed_fn__31000335_A_New_O(ctx__0); var tmp8 *jrt.Class
		var fncls__98 /*line :1120:1*/*jrt.Class = A_arbace_c2j_emit_emit_unboxed_fn__31000335_A_fn_class








		if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_223, false); A_arbace_c2j_emit_emit_unboxed_fn__31000335_A_fn_class = fncls__98d; tmp8 = fncls__98d } else { tmp8 = fncls__98 }; tmp3 = tmp4.Invoke_O_O_O__O(tmp5, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), lang.IFn_Cast(A_arbace_c2j_emit_A_const_635.GetRawRoot__O()).Invoke_O__O(es__5)), lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_636.GetRawRoot__O()).Invoke_O__O(es__5))))
//line :1120:1
		break L1 }; case 12: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_65) {


			tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_328.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_TRUE.Ref())
//line :1120:1
			break L1 }; case 13: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_85) {









				tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_650.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_TRUE.Ref())
//line :1120:1
				break L1 }; case 14: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_74) {






					tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_637.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_TRUE.Ref())
//line :1120:1
					break L1 }; case 16: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_97) {



						tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_469.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_TRUE.Ref())
//line :1120:1
						break L1 }; case 17: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_77) {










							tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_639.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_TRUE.Ref())
//line :1120:1
							break L1 }; case 22: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_86) {

















								tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_654.GetRawRoot__O()).Invoke_O_O__O(ctx__0, n__3)
//line :1120:1
								break L1 }; case 24: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_101) {












									tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_677.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_TRUE.Ref())
//line :1120:1
									break L1 }; case 29: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_62) {











										tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_615.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_TRUE.Ref())
//line :1120:1
										break L1 }; case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_68) {





											tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_627.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_TRUE.Ref())
//line :1120:1
											break L1 }; case 36: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_78) { var v__5 any = A_arbace_c2j_emit_A_const_645.Invoke_O__O(n__3)

												if jrt.Double_InstanceOf(v__5) { tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_73.GetRawRoot__O()).Invoke_O__O(v__5) } else { tmp3 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(v__5)).Ref() }
//line :1120:1
												break L1 }; case 37: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_103) { var c__5 any = A_arbace_c2j_emit_A_const_472.Invoke_O__O(n__3)














													if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(c__5, ctx__0)) {
														var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_emit_A_const_691; tmp3 = tmp9.Invoke_O_O_O__O(tmp10, lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(ctx__0, c__5), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_568.Invoke_O__O(n__3))) } else {
															var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_A_const_692; tmp3 = tmp11.Invoke_O_O_O__O(tmp12, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(c__5), lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_568.Invoke_O__O(n__3))) }
//line :1120:1
													break L1 }; case 45: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_98) {




														tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_676.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_TRUE.Ref())
//line :1120:1
														break L1 }; case 51: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_90) {


















															var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp14 any = A_arbace_c2j_emit_A_const_693; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_emit_A_const_694; var tmp17 any = A_arbace_c2j_emit_A_const_695; tmp3 = tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O_O__O(tmp16, tmp17, lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_664.Invoke_O__O(n__3))))
//line :1120:1
															break L1 }; case 53: if lang.Util_Equiv_O_O__Z_NoInit(G__31000334__4_, Lit_81) {
																tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_533.GetRawRoot__O()).Invoke_O_O_O__O(ctx__0, n__3, jrt.Boolean_TRUE.Ref())
//line :1120:1
																break L1 }; default:
	}


















		tmp3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_224, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_emit_A_const_501.Invoke_O__O(n__3))).Ref())}; return /*line :1119:1*/ tmp2.Invoke_O_O__O(tmp3, n__3) }









func A_arbace_c2j_emit_emit_unboxed_fn__31000335_A_New_O(p0 any) *A_arbace_c2j_emit_emit_unboxed_fn__31000335_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_unboxed_fn__31000335_A{}; t.Ctor_O(p0); return t }
//line :1129:1
func (t *A_arbace_c2j_emit_emit_unboxed_fn__31000335_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1129:1
func (t *A_arbace_c2j_emit_emit_unboxed_fn__31000335_A) Invoke_O_O__O(self, p1__31000333_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__31000333_SHARP___1) }
















func A_arbace_c2j_emit_deep_A_New() *A_arbace_c2j_emit_deep_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_deep_A{}; t.Ctor(); return t }
//line :1146:1
func (t *A_arbace_c2j_emit_deep_A) Ctor() {}
//line :1146:1
func (t *A_arbace_c2j_emit_deep_A) Invoke_O_O__O(self, f__0 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_62.GetRawRoot__O()).Invoke_O__O(f__0)) {
		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_313.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_44.GetRawRoot__O(), lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_696.GetRawRoot__O(), f__0)), lang.RT_Meta_O__IPersistentMap_NoInit(f__0)) } else {
//line :1150:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_61.GetRawRoot__O()).Invoke_O__O(f__0)) {

				return lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_696.GetRawRoot__O(), f__0), lang.RT_Meta_O__IPersistentMap_NoInit(f__0)) } else {
//line :1150:1
					if A_arbace_c2j_emit_A_const_64 != nil { return f__0 } else { return nil
					}
				}
		}
}
func A_arbace_c2j_emit_simple_name_A_New() *A_arbace_c2j_emit_simple_name_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_simple_name_A{}; t.Ctor(); return t }
//line :1155:1
func (t *A_arbace_c2j_emit_simple_name_A) Ctor() {}
//line :1155:1
func (t *A_arbace_c2j_emit_simple_name_A) Invoke_O_O__O(self, binary__0 any) any {
	return lang.IFn_Cast(A_arbace_c2j_emit_A_const_17.GetRawRoot__O()).Invoke_O_O__O(binary__0, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(binary__0)).LastIndexOf_String__I(Lit_17)))).Ref())
}
func A_arbace_c2j_emit_throws_QMARK__A_New() *A_arbace_c2j_emit_throws_QMARK__A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_throws_QMARK__A{}; t.Ctor(); return t }
//line :1158:1
func (t *A_arbace_c2j_emit_throws_QMARK__A) Ctor() {}
//line :1158:1
func (t *A_arbace_c2j_emit_throws_QMARK__A) Invoke_O_O__O(self, e__0 any) any { var n__2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(e__0); var G__31000340__3_ any = A_arbace_c2j_emit_A_const_501.Invoke_O__O(n__2); switch



	lang.Util_Hash_O__I_NoInit(G__31000340__3_) >> 0 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__31000340__3_, Lit_90) { return jrt.Boolean_TRUE.Ref() }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__31000340__3_, Lit_71) {

		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_697.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_636.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_629.Invoke_O__O(n__2))) }
//line :1162:1
	default:}; return jrt.Boolean_FALSE.Ref() }




func A_arbace_c2j_emit_ret_body_A_New() *A_arbace_c2j_emit_ret_body_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_ret_body_A{}; t.Ctor(); return t }
//line :1167:1
func (t *A_arbace_c2j_emit_ret_body_A) Ctor() {}
//line :1167:1
func (t *A_arbace_c2j_emit_ret_body_A) Invoke_O_O_O_O__O(self, ctx__0, body__1, ret__2 any) any { var n__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(body__1); var bc__5 any = A_arbace_c2j_emit_A_const_233.Invoke_O__O(n__4); var tmp1 any; var and__1927000168__auto____6 bool = jrt.NN(jrt.Class_Cast(ret__2)).IsPrimitive__Z(); if and__1927000168__auto____6 {





	var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_49.GetRawRoot__O()).Invoke_O_O__O(ret__2, jrt.Void_TYPE.Ref()); if jrt.J2g_Truth(and__1927000168__auto____7) { tmp1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_511.GetRawRoot__O()).Invoke_O__O(n__4) } else { tmp1 = and__1927000168__auto____7 } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }; if jrt.J2g_Truth(tmp1) {
		if lang.Util_Equiv_O_O__Z_NoInit(bc__5, ret__2) {
			return lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(ctx__0, body__1) } else {
//line :1174:1
				var tmp2 bool; var and__1927000168__auto____6_2 bool = lang.Util_Equiv_O_O__Z_NoInit(ret__2, jrt.Long_TYPE.Ref())

				if and__1927000168__auto____6_2 { tmp2 = lang.Util_Equiv_O_O__Z_NoInit(bc__5, jrt.Integer_TYPE.Ref()) } else { tmp2 = and__1927000168__auto____6_2 }
//line :1174:1
				if tmp2 {

					return lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(ctx__0, body__1) } else {
//line :1174:1
						var tmp3 bool; var and__1927000168__auto____6_3 bool = lang.Util_Equiv_O_O__Z_NoInit(ret__2, jrt.Double_TYPE.Ref())


						if and__1927000168__auto____6_3 { tmp3 = lang.Util_Equiv_O_O__Z_NoInit(bc__5, jrt.Float_TYPE.Ref()) } else { tmp3 = and__1927000168__auto____6_3 }
//line :1174:1
						if tmp3 {


							return lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(ctx__0, body__1) } else {
//line :1174:1
								var tmp4 bool; var and__1927000168__auto____6_4 bool = lang.Util_Equiv_O_O__Z_NoInit(ret__2, jrt.Integer_TYPE.Ref())



								if and__1927000168__auto____6_4 { tmp4 = lang.Util_Equiv_O_O__Z_NoInit(bc__5, jrt.Long_TYPE.Ref()) } else { tmp4 = and__1927000168__auto____6_4 }
//line :1174:1
								if tmp4 {




									return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_698, A_arbace_c2j_emit_A_const_699), lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(ctx__0, body__1)) } else {
//line :1174:1
										var tmp5 bool; var and__1927000168__auto____6_5 bool = lang.Util_Equiv_O_O__Z_NoInit(ret__2, jrt.Float_TYPE.Ref())





										if and__1927000168__auto____6_5 { tmp5 = lang.Util_Equiv_O_O__Z_NoInit(bc__5, jrt.Double_TYPE.Ref()) } else { tmp5 = and__1927000168__auto____6_5 }
//line :1174:1
										if tmp5 {





											var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp7 any = A_arbace_c2j_emit_A_const_700; return tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_c2j_emit_A_const_249.GetRawRoot__O()).Invoke_O_O__O(ctx__0, body__1)) } else {
//line :1174:1
												if A_arbace_c2j_emit_A_const_64 != nil {






													return lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_319, nil, Lit_320, nil), jrt.RefArrayOf(jrt.Object_class, nil, ret__2, nil, bc__5)).Ref()) } else {
//line :1174:1
														return nil } } } } } } } else {
//line :1173:1
															var f__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__0, body__1)









															if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_697.GetRawRoot__O()).Invoke_O__O(body__1)) { return f__6 } else { if lang.Util_Equiv_O_O__Z_NoInit(ret__2, jrt.Void_TYPE.Ref()) { return f__6 } else { if lang.Util_Equiv_O_O__Z_NoInit(ret__2, A_arbace_c2j_emit_A_const_238) { return f__6 } else { if lang.Util_Equiv_O_O__Z_NoInit(ret__2, jrt.Boolean_TYPE.Ref()) {



																var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_emit_A_const_701; return tmp8.Invoke_O_O__O(tmp9, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_702, A_arbace_c2j_emit_A_const_703, f__6)) } else {
//line :1183:1
																	if lang.Util_Equiv_O_O__Z_NoInit(ret__2, jrt.Character_TYPE.Ref()) {




																		var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_emit_A_const_704; return tmp10.Invoke_O_O__O(tmp11, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_705, A_arbace_c2j_emit_A_const_706, f__6)) } else {
//line :1183:1
																			if jrt.NN(jrt.Class_Cast(ret__2)).IsPrimitive__Z() {





																				return lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_34, nil, Lit_130), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Class_Cast(ret__2)).GetName__String().Ref(), nil)).Ref()), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_707, A_arbace_c2j_emit_A_const_708, f__6)) } else {
//line :1183:1
																					var tmp12 any; var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(ret__2, ctx__0)






																					if jrt.J2g_Truth(or__1927000174__auto____7) { tmp12 = or__1927000174__auto____7 } else { tmp12 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_247.GetRawRoot__O()).Invoke_O__O(ret__2)) }
//line :1183:1
																					if jrt.J2g_Truth(tmp12) { return f__6 } else { if A_arbace_c2j_emit_A_const_64 != nil {







																						var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp14 any = A_arbace_c2j_emit_A_const_709; return tmp13.Invoke_O_O_O__O(tmp14, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(ret__2), f__6) } else {
//line :1183:1
																							return nil } } } } } } } } } }









func A_arbace_c2j_emit_method_body_A_New() *A_arbace_c2j_emit_method_body_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_method_body_A{}; t.Ctor(); return t }
//line :1193:1
func (t *A_arbace_c2j_emit_method_body_A) Ctor() {}
//line :1193:1
func (t *A_arbace_c2j_emit_method_body_A) Invoke_O_O_O_O__O(self, ctx__0, mn__1, params__2 any) any { var rec__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_35.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_FALSE.Ref()); var locals__5 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_A_const_712.Invoke_O__O(mn__1); var tmp4 lang.IPersistentVector; if




	jrt.J2g_Truth(A_arbace_c2j_emit_A_const_713.Invoke_O__O(mn__1)) { tmp4 = lang.Tuple_Create_O__IPersistentVector(A_arbace_c2j_emit_A_const_713.Invoke_O__O(mn__1)) } else { tmp4 = nil }; var tmp5 any = tmp4; var tmp6 any; if
	jrt.J2g_Truth(A_arbace_c2j_emit_A_const_712.Invoke_O__O(mn__1)) { tmp6 = nil } else { tmp6 = A_arbace_c2j_emit_A_const_714.Invoke_O__O(mn__1) }; locals__5 = /*line :1198:1*/tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(tmp3, tmp5, tmp6)); var ctx_SINGLEQUOTE___6 any = /*line :1193:1*/lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(ctx__0, A_arbace_c2j_emit_A_const_524, rec__4, A_arbace_c2j_emit_A_const_525, locals__5, A_arbace_c2j_emit_A_const_517, locals__5); var fn_method_QMARK___7 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_275, A_arbace_c2j_emit_A_const_501.Invoke_O__O(mn__1)); var prims__8 any; if fn_method_QMARK___7 {










		var iter__1927001039__auto____8 any; var tmp7 any = A_arbace_c2j_emit_method_body_iter__31000343__31000347_A_New(); var tmp8 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_c2j_emit_method_body_iter__31000343__31000347_A_fn_class
		if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_276, false); A_arbace_c2j_emit_method_body_iter__31000343__31000347_A_fn_class = fncls__102d; tmp8 = fncls__102d } else { tmp8 = fncls__102 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); prims__8 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(locals__5) } else {
//line :1204:1
			prims__8 = nil }; var ret__9 any = /*line :1193:1*/A_arbace_c2j_emit_A_const_710.Invoke_O__O(mn__1); var body__10 any; var tmp9 any; var and__1927000168__auto____10 bool = fn_method_QMARK___7; if and__1927000168__auto____10 {



















				tmp9 = lang.IFn_Cast(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, jrt.Double_TYPE.Ref(), jrt.Long_TYPE.Ref()))).Invoke_O__O(ret__9) } else { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }; if /*line :1210:1*/ jrt.J2g_Truth(tmp9) {


					body__10 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_298.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_711.GetRawRoot__O()).Invoke_O_O_O__O(ctx_SINGLEQUOTE___6, A_arbace_c2j_emit_A_const_520.Invoke_O__O(mn__1), ret__9), ret__9) } else {
//line :1210:1
						if fn_method_QMARK___7 {



							body__10 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx_SINGLEQUOTE___6, A_arbace_c2j_emit_A_const_520.Invoke_O__O(mn__1)) } else {
//line :1210:1
								if A_arbace_c2j_emit_A_const_64 != nil {




									body__10 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_711.GetRawRoot__O()).Invoke_O_O_O__O(ctx_SINGLEQUOTE___6, A_arbace_c2j_emit_A_const_520.Invoke_O__O(mn__1), ret__9) } else {
//line :1210:1
										body__10 = nil } } }; var body__11 any; if





	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(rec__4)) {
		var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_emit_A_const_715; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()); var tmp14 any = A_arbace_c2j_emit_method_body_fn__31000353_A_New(); var tmp15 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_c2j_emit_method_body_fn__31000353_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_277, false); A_arbace_c2j_emit_method_body_fn__31000353_A_fn_class = fncls__103d; tmp15 = fncls__103d } else { tmp15 = fncls__103 }; body__11 = tmp10.Invoke_O_O_O__O(tmp11, tmp12.Invoke_O__O(tmp13.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), locals__5)), body__10) } else {
//line :1216:1
			body__11 = body__10 }; if




	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(prims__8)) {
		var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp17 any = A_arbace_c2j_emit_A_const_716; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()); var tmp20 any = A_arbace_c2j_emit_method_body_fn__31000355_A_New(); var tmp21 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_c2j_emit_method_body_fn__31000355_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_278, false); A_arbace_c2j_emit_method_body_fn__31000355_A_fn_class = fncls__104d; tmp21 = fncls__104d } else { tmp21 = fncls__104 }; return tmp16.Invoke_O_O_O__O(tmp17, tmp18.Invoke_O__O(tmp19.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil), prims__8)), body__11) } else {
//line :1221:1
			return body__11 } }
//line :1205:1
func A_arbace_c2j_emit_method_body_iter__31000343__31000347_A_New() *A_arbace_c2j_emit_method_body_iter__31000343__31000347_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_method_body_iter__31000343__31000347_A{}; t.Ctor(); return t }
//line :1205:1
func (t *A_arbace_c2j_emit_method_body_iter__31000343__31000347_A) Ctor() {}
//line :1205:1
func (t *A_arbace_c2j_emit_method_body_iter__31000343__31000347_A) Invoke_O_O__O(self, s__31000344__1 any) any { var tmp1 any = A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_A_New_O_O(s__31000344__1, self); var tmp2 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_280, false); A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_A_fn_class = fncls__101d; tmp2 = fncls__101d } else { tmp2 = fncls__101 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1205:1
func A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1205:1
func (t *A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_A) Ctor_O_O(c__s__31000344, c__iter__31000343 any) { t.F_s__31000344 = c__s__31000344; t.F_iter__31000343 = c__iter__31000343 }
//line :1205:1
func (t *A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_A) Invoke_O__O(self any) any { { var s__31000344__1 any; var t_ any = t.F_s__31000344; t.F_s__31000344 = nil; s__31000344__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000344__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000344__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000344__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000344__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000346__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_fn__31000349_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__31000346__6); var tmp2 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_fn__31000349_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_281, false); A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_fn__31000349_A_fn_class = fncls__100d; tmp2 = fncls__100d } else { tmp2 = fncls__100 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000343); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000346__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000344__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000346__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000344__3); var b__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__4); if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__5)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__31000343); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(b__5, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000344__3))) } else { s__31000344__1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000344__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :1205:1
func A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_fn__31000349_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_fn__31000349_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_fn__31000349_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :1205:1
func (t *A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_fn__31000349_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__31000346 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__31000346 = c__b__31000346 }
//line :1205:1
func (t *A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_fn__31000349_A) Invoke_O__O(self any) any { { var i__31000345__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000345__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000345__1)); var b__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__2); if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__3)) { lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()).Invoke_O_O__O(t.F_b__31000346, b__3); i__31000345__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000345__1); continue L1 } else { i__31000345__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000345__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_c2j_emit_method_body_fn__31000353_A_New() *A_arbace_c2j_emit_method_body_fn__31000353_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_method_body_fn__31000353_A{}; t.Ctor(); return t }
//line :1217:1
func (t *A_arbace_c2j_emit_method_body_fn__31000353_A) Ctor() {}
//line :1217:1
func (t *A_arbace_c2j_emit_method_body_fn__31000353_A) Invoke_O_O__O(self, lb__1 any) any { var b__2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(b__2); var tmp3 any; var or__1927000174__auto____3 any = A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__2); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { tmp3 = A_arbace_c2j_emit_A_const_238 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1.Invoke_O_O__O(tmp2, tmp3), lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(b__2)) }




func A_arbace_c2j_emit_method_body_fn__31000355_A_New() *A_arbace_c2j_emit_method_body_fn__31000355_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_method_body_fn__31000355_A{}; t.Ctor(); return t }
//line :1222:1
func (t *A_arbace_c2j_emit_method_body_fn__31000355_A) Ctor() {}
//line :1222:1
func (t *A_arbace_c2j_emit_method_body_fn__31000355_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(b__1), A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()); var tmp4 any; if
												lang.Util_Equiv_O_O__Z_NoInit(A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__1), jrt.Double_TYPE.Ref()) { tmp4 = A_arbace_c2j_emit_A_const_717 } else { tmp4 = A_arbace_c2j_emit_A_const_718 }; return /*line :1222:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2.Invoke_O_O__O(tmp3.Invoke_O_O__O(tmp4, A_arbace_c2j_emit_A_const_719), lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_279, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(b__1))).Ref()))) }







func A_arbace_c2j_emit_param_sym_A_New() *A_arbace_c2j_emit_param_sym_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_param_sym_A{}; t.Ctor(); return t }
//line :1230:1
func (t *A_arbace_c2j_emit_param_sym_A) Ctor() {}
//line :1230:1
func (t *A_arbace_c2j_emit_param_sym_A) Invoke_O_O__O(self, lb__0 any) any { var b__2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__0); if

	jrt.J2g_Truth(A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__2)) {
		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_279, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(b__2))).Ref()) } else {
			return lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(b__2) } }





func A_arbace_c2j_emit_tag_class_A_New() *A_arbace_c2j_emit_tag_class_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_tag_class_A{}; t.Ctor(); return t }
//line :1240:1
func (t *A_arbace_c2j_emit_tag_class_A) Ctor() {}
//line :1240:1
func (t *A_arbace_c2j_emit_tag_class_A) Invoke_O_O__O(self, tag__0 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(tag__0, nil) { return A_arbace_c2j_emit_A_const_238 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_720.GetRawRoot__O()).Invoke_O__O(tag__0)) {

		return lang.IFn_Cast(A_arbace_c2j_emit_A_const_720.GetRawRoot__O()).Invoke_O__O(tag__0) } else {
//line :1243:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(tag__0)) { return tag__0 } else { if A_arbace_c2j_emit_A_const_64 != nil { var c__2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_721.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_722.Get__O(), tag__0)



				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_55.GetRawRoot__O()).Invoke_O__O(c__2)) { return c__2 } else { return jrt.Class_ForName_String__Class(jrt.String_Cast(lang.IFn_Cast(A_arbace_c2j_emit_A_const_19.GetRawRoot__O()).Invoke_O__O(tag__0))).Ref() } } else {
//line :1243:1
					return nil
				}
			}
		}
	}
}
func A_arbace_c2j_emit_box_class_A_New() *A_arbace_c2j_emit_box_class_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_box_class_A{}; t.Ctor(); return t }
//line :1249:1
func (t *A_arbace_c2j_emit_box_class_A) Ctor() {}
//line :1249:1
func (t *A_arbace_c2j_emit_box_class_A) Invoke_O_O__O(self, c__0 any) any {
	return lang.IFn_Cast(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, jrt.Long_TYPE.Ref(), A_arbace_c2j_emit_A_const_82, jrt.Double_TYPE.Ref(), A_arbace_c2j_emit_A_const_79, jrt.Integer_TYPE.Ref(), A_arbace_c2j_emit_A_const_81, jrt.Boolean_TYPE.Ref(), A_arbace_c2j_emit_A_const_76, jrt.Character_TYPE.Ref(), A_arbace_c2j_emit_A_const_78, jrt.Float_TYPE.Ref(), A_arbace_c2j_emit_A_const_80, jrt.Short_TYPE.Ref(), A_arbace_c2j_emit_A_const_83, jrt.Byte_TYPE.Ref(), A_arbace_c2j_emit_A_const_77))).Invoke_O__O(c__0)
}

func A_arbace_c2j_emit_class_interfaces_A_New() *A_arbace_c2j_emit_class_interfaces_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_interfaces_A{}; t.Ctor(); return t }
//line :1253:1
func (t *A_arbace_c2j_emit_class_interfaces_A) Ctor() {}
//line :1253:1
func (t *A_arbace_c2j_emit_class_interfaces_A) Invoke_O_O_O__O(self, ctx__0, ox__1 any) any { var c__3 any = A_arbace_c2j_emit_A_const_723.Invoke_O__O(ox__1); if




	jrt.J2g_Truth(c__3) { } else { lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_emit_A_const_36.Invoke_O__O(ox__1))).Ref()) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____4 any; var tmp3 any = A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_A_New_O_O(ctx__0, ox__1); var tmp4 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_A_fn_class = fncls__107d; tmp4 = fncls__107d } else { tmp4 = fncls__107 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__3)).GetInterfaces__Class1().Ref()); return tmp1.Invoke_O__O(tmp2) }
//line :1259:1
func A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1259:1
func (t *A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_A) Ctor_O_O(c__ctx, c__ox any) { t.F_ctx = c__ctx; t.F_ox = c__ox }
//line :1259:1
func (t *A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_A) Invoke_O_O__O(self, s__31000362__1 any) any { var tmp1 any = A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_A_New_O_O_O_O(t.F_ctx, t.F_ox, s__31000362__1, self); var tmp2 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_A_fn_class = fncls__106d; tmp2 = fncls__106d } else { tmp2 = fncls__106 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1259:1
func A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1259:1
func (t *A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_A) Ctor_O_O_O_O(c__ctx, c__ox, c__s__31000362, c__iter__31000361 any) { t.F_ctx = c__ctx; t.F_ox = c__ox; t.F_s__31000362 = c__s__31000362; t.F_iter__31000361 = c__iter__31000361 }
//line :1259:1
func (t *A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_A) Invoke_O__O(self any) any { { var s__31000362__1 any; var t_ any = t.F_s__31000362; t.F_s__31000362 = nil; s__31000362__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000362__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000362__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000362__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000362__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000364__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_fn__31000367_A_New_O_O_O_I_O(t.F_ctx, t.F_ox, b__31000364__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_fn__31000367_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_fn__31000367_A_fn_class = fncls__105d; tmp2 = fncls__105d } else { tmp2 = fncls__105 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000361); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000364__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000362__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000364__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000362__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp5 any
														if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(i__4, t.F_ctx)) {
															tmp5 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_22, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit_A_const_36.Invoke_O__O(t.F_ox), nil, jrt.NN(jrt.Class_Cast(i__4)).GetName__String().Ref(), nil)).Ref()) } else {
																tmp5 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(i__4)).GetName__String().Ref())) }
//line :1259:1
	var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__31000361); return tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000362__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1259:1
func A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_fn__31000367_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_fn__31000367_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_fn__31000367_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :1259:1
func (t *A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_fn__31000367_A) Ctor_O_O_O_I_O(c__ctx, c__ox, c__b__31000364 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ctx = c__ctx; t.F_ox = c__ox; t.F_b__31000364 = c__b__31000364; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1259:1
func (t *A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_fn__31000367_A) Invoke_O__O(self any) any { { var i__31000363__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000363__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000363__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000364; var tmp4 any
																if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(i__2, t.F_ctx)) {
																	tmp4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_22, nil, Lit_23), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit_A_const_36.Invoke_O__O(t.F_ox), nil, jrt.NN(jrt.Class_Cast(i__2)).GetName__String().Ref(), nil)).Ref()) } else {
																		tmp4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(i__2)).GetName__String().Ref())) }
//line :1259:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__31000363__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000363__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_c2j_emit_field_mods_A_New() *A_arbace_c2j_emit_field_mods_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_field_mods_A{}; t.Ctor(); return t }
//line :1264:1
func (t *A_arbace_c2j_emit_field_mods_A) Ctor() {}
//line :1264:1
func (t *A_arbace_c2j_emit_field_mods_A) Invoke_O_O_O__O(self, ox__0, lb__1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_emit_A_const_724; var m__3 any = lang.RT_Meta_O__IPersistentMap_NoInit(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__1))); if




	jrt.J2g_Truth(A_arbace_c2j_emit_A_const_725.Invoke_O__O(m__3)) { return A_arbace_c2j_emit_A_const_726 } else { if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_727.Invoke_O__O(m__3)) { return lang.PersistentArrayMap_EMPTY.Ref() } else { if A_arbace_c2j_emit_A_const_64 != nil { return A_arbace_c2j_emit_A_const_728 } else { return nil } } } }




func A_arbace_c2j_emit_emit_deftype_class_BANG__A_New() *A_arbace_c2j_emit_emit_deftype_class_BANG__A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__A{}; t.Ctor(); return t }
//line :1274:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__A) Ctor() {}
//line :1274:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__A) Invoke_O_O_O__O(self, ctx__0, ox__1 any) any { var cname__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_36.Invoke_O__O(ox__1)); if





	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_311.Invoke_O__O(ctx__0)), cname__3)) { } else {
		lang.IFn_Cast(A_arbace_c2j_emit_A_const_27.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_c2j_emit_A_const_311.Invoke_O__O(ctx__0), A_arbace_c2j_emit_A_const_13.GetRawRoot__O(), cname__3, A_arbace_c2j_emit_A_const_742)
//line :1280:1
		var cls__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_729.GetRawRoot__O()).Invoke_O_O__O(ctx__0, cname__3); var fields__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_534.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_535.Invoke_O__O(ox__1))); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_40; var tmp3 any = A_arbace_c2j_emit_A_const_743; var tmp4 any = A_arbace_c2j_emit_A_const_269; var tmp5 any = jrt.Boolean_FALSE.Ref(); var tmp6 any = A_arbace_c2j_emit_A_const_230; var ctx_SINGLEQUOTE___6 any = tmp1.Invoke_O_O_O_O_O_O_O_O_O_O_O__O(ctx__0, tmp2, cls__4, tmp3, ox__1, tmp4, tmp5, tmp6, lang.IFn_Cast(A_arbace_c2j_emit_A_const_556.GetRawRoot__O()).Invoke_O__O(fields__5), A_arbace_c2j_emit_A_const_272, A_arbace_c2j_emit_A_const_744); var fbs__7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_234.GetRawRoot__O(), fields__5); var ftype__8 any; var tmp7 any = A_arbace_c2j_emit_emit_deftype_class_BANG__ftype__31000376_A_New(); var tmp8 *jrt.Class
		var fncls__108 /*line :1280:1*/*jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__ftype__31000376_A_fn_class






		if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_c2j_emit_emit_deftype_class_BANG__ftype__31000376_A_fn_class = fncls__108d; tmp8 = fncls__108d } else { tmp8 = fncls__108 }; ftype__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)
//line :1280:1
		var fsym__9 any; var tmp9 any = A_arbace_c2j_emit_emit_deftype_class_BANG__fsym__31000378_A_New(); var tmp10 *jrt.Class
		var fncls__109 /*line :1280:1*/*jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__fsym__31000378_A_fn_class







		if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_c2j_emit_emit_deftype_class_BANG__fsym__31000378_A_fn_class = fncls__109d; tmp10 = fncls__109d } else { tmp10 = fncls__109 }; fsym__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)
//line :1280:1
		var hinted__10 any = A_arbace_c2j_emit_A_const_730.Invoke_O__O(ox__1); var nh__11 int32 = lang.RT_Count_O__I_NoInit(hinted__10); var drops__12 any = A_arbace_c2j_emit_A_const_731.Invoke_O__O(ox__1); var ctor__13 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_A_const_745; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_emit_A_const_750; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp18 any = A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000380_A_New_O_O(ftype__8, fsym__9); var tmp19 *jrt.Class
		var fncls__127 /*line :1280:1*/*jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000380_A_fn_class











		if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000380_A_fn_class = fncls__127d; tmp19 = fncls__127d } else { tmp19 = fncls__127 }; var tmp20 any = tmp13.Invoke_O_O__O(tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, tmp17.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil), fbs__7))), A_arbace_c2j_emit_A_const_749); var tmp21 any = A_arbace_c2j_emit_A_const_746; var tmp22 any; var iter__1927001039__auto____13 any; var tmp23 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_A_New_O(fsym__9); var tmp24 *jrt.Class
		var fncls__126 /*line :1292:1*/*jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_A_fn_class

		if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_A_fn_class = fncls__126d; tmp24 = fncls__126d } else { tmp24 = fncls__126 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); tmp22 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(fbs__7)
//line :1292:1
		ctor__13 = tmp11.Invoke_O_O_O_O__O(tmp12, tmp20, tmp21, tmp22)
//line :1280:1
		var alt_ctors__14 any; var tmp25 bool
		var na_110 any = drops__12













		if jrt.Long_InstanceOf(na_110) { var n0_111 int64 = jrt.NN(jrt.Long_Cast(na_110)).LongValue__J(); tmp25 = n0_111 > 0 } else { if jrt.Double_InstanceOf(na_110) { var n0_111_2 float64 = jrt.NN(jrt.Double_Cast(na_110)).DoubleValue__D(); tmp25 = n0_111_2 > 0.0 } else { tmp25 = lang.Numbers_IsPos_O__Z_NoInit(na_110) } }; if tmp25 { var n__14 int32 = lang.RT_Count_O__I_NoInit(fbs__7); var ps__15 any; var tmp26 any = A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_A_New_O_O_O(fbs__7, ftype__8, fsym__9); var tmp27 *jrt.Class
			var fncls__113 /*line :1295:1*/*jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_A_fn_class

			if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_A_fn_class = fncls__113d; tmp27 = fncls__113d } else { tmp27 = fncls__113 }; ps__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil)
//line :1295:1
			var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp29 any = A_arbace_c2j_emit_A_const_751; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()); var tmp31 lang.IFn = lang.IFn_Cast(ps__15); var tmp32 jrt.Number_I; var na_128 int64 = int64(n__14)
			var na_129 any = drops__12

			if jrt.Long_InstanceOf(na_129) { var n0_130 int64 = na_128; var n1_131 int64 = jrt.NN(jrt.Long_Cast(na_129)).LongValue__J(); var nr_132 int64 = n0_130 - n1_131; var tmp33 bool; var tmp34 bool; tmp34 = !(n1_131 == -9223372036854775808); if tmp34 { tmp34 = (n0_130^n1_131)&(n0_130^nr_132) >= 0 }; tmp33 = tmp34; if tmp33 { tmp32 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_132)) } else { tmp32 = lang.Numbers_Minus_J_O__Number_NoInit(na_128, na_129) } } else { tmp32 = lang.Numbers_Minus_J_O__Number_NoInit(na_128, na_129) }
//line :1295:1
			var tmp35 any = tmp30.Invoke_O_O__O(tmp31.Invoke_O__O(tmp32), A_arbace_c2j_emit_A_const_752); var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()); var tmp37 any = A_arbace_c2j_emit_A_const_753; var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_733.GetRawRoot__O()); var tmp41 jrt.Number_I; var na_133 int64 = int64(n__14)
			var na_134 any = drops__12


			if jrt.Long_InstanceOf(na_134) { var n0_135 int64 = na_133; var n1_136 int64 = jrt.NN(jrt.Long_Cast(na_134)).LongValue__J(); var nr_137 int64 = n0_135 - n1_136; var tmp42 bool; var tmp43 bool; tmp43 = !(n1_136 == -9223372036854775808); if tmp43 { tmp43 = (n0_135^n1_136)&(n0_135^nr_137) >= 0 }; tmp42 = tmp43; if tmp42 { tmp41 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_137)) } else { tmp41 = lang.Numbers_Minus_J_O__Number_NoInit(na_133, na_134) } } else { tmp41 = lang.Numbers_Minus_J_O__Number_NoInit(na_133, na_134) }
//line :1295:1
			var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp45 any = A_arbace_c2j_emit_A_const_756; var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()); var tmp47 any = A_arbace_c2j_emit_A_const_758; alt_ctors__14 = lang.Tuple_Create_O_O__IPersistentVector(tmp28.Invoke_O_O_O__O(tmp29, tmp35, tmp36.Invoke_O_O__O(tmp37, tmp38.Invoke_O_O__O(tmp39.Invoke_O_O__O(fsym__9, tmp40.Invoke_O_O__O(tmp41, fbs__7)), lang.Tuple_Create_O_O_O_O__IPersistentVector(nil, nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_754, A_arbace_c2j_emit_A_const_33), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_755, A_arbace_c2j_emit_A_const_33))))), tmp44.Invoke_O_O_O__O(tmp45, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(ps__15).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(n__14), 2)).Ref()), A_arbace_c2j_emit_A_const_757), tmp46.Invoke_O_O__O(tmp47, lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()).Invoke_O_O__O(fsym__9, lang.IFn_Cast(A_arbace_c2j_emit_A_const_733.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(n__14), 2)).Ref(), fbs__7)), lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_759, A_arbace_c2j_emit_A_const_33), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_760, A_arbace_c2j_emit_A_const_33)))))) } else { alt_ctors__14 = nil }
//line :1280:1
		var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp49 any = A_arbace_c2j_emit_A_const_761; var basis__15 any = tmp48.Invoke_O_O_O_O__O(tmp49, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_762, A_arbace_c2j_emit_A_const_763), lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.PersistentVector_EMPTY.Ref(), A_arbace_c2j_emit_A_const_764), lang.IFn_Cast(A_arbace_c2j_emit_A_const_48.GetRawRoot__O()).Invoke_O_O__O(ctx_SINGLEQUOTE___6, hinted__10)); var create__16 any























		if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(fbs__7)), int64(nh__11)) { var m__16 any = A_arbace_c2j_emit_A_const_734; var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp51 any = A_arbace_c2j_emit_A_const_765; var tmp52 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_773, A_arbace_c2j_emit_A_const_774); var tmp53 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(m__16, A_arbace_c2j_emit_A_const_775)), lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(cname__3)); var tmp54 any; var steps__17 any; var iter__1927001039__auto____17 any; var tmp55 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_A_New_O(m__16); var tmp56 *jrt.Class
			var fncls__140 /*line :1304:1*/*jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_A_fn_class



			if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_A_fn_class = fncls__140d; tmp56 = fncls__140d } else { tmp56 = fncls__140 }; iter__1927001039__auto____17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp55, tmp56, nil); steps__17 = lang.IFn_Cast(iter__1927001039__auto____17).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_457.GetRawRoot__O(), hinted__10))









			var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp58 any = A_arbace_c2j_emit_A_const_776; var tmp59 any = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(m__16, A_arbace_c2j_emit_A_const_777), m__16); var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()); var tmp61 any = A_arbace_c2j_emit_A_const_778; var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_101.GetRawRoot__O()); var tmp64 any = A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000413_A_New(); var tmp65 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000413_A_fn_class
			if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000413_A_fn_class = fncls__141d; tmp65 = fncls__141d } else { tmp65 = fncls__141 }
//line :1318:1
			var tmp66 any = tmp62.Invoke_O__O(tmp63.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp64, tmp65, nil), steps__17)); var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp68 any; var iter__1927001039__auto____18 any; var tmp69 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_A_New_O(m__16); var tmp70 *jrt.Class
			var fncls__144 /*line :1318:1*/*jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_A_fn_class

			if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_A_fn_class = fncls__144d; tmp70 = fncls__144d } else { tmp70 = fncls__144 }; iter__1927001039__auto____18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp69, tmp70, nil); tmp68 = lang.IFn_Cast(iter__1927001039__auto____18).Invoke_O__O(steps__17)
//line :1318:1
			var tmp71 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()); var tmp72 any = A_arbace_c2j_emit_A_const_781; tmp54 = tmp57.Invoke_O_O_O__O(tmp58, tmp59, tmp60.Invoke_O_O_O__O(tmp61, tmp66, tmp67.Invoke_O_O__O(tmp68, lang.Tuple_Create_O__IPersistentVector(tmp71.Invoke_O_O_O__O(tmp72, lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(cname__3), lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_158.GetRawRoot__O(), steps__17), lang.Tuple_Create_O_O_O_O__IPersistentVector(nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_782, m__16), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_783, A_arbace_c2j_emit_A_const_33), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_784, A_arbace_c2j_emit_A_const_33))))))))
//line :1306:1
			create__16 = tmp50.Invoke_O_O_O_O__O(tmp51, tmp52, tmp53, tmp54) } else {
//line :1304:1
				create__16 = nil }
//line :1280:1
		var methods__17 any; var iter__1927001039__auto____17_2 any; var tmp73 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_A_New_O(ctx_SINGLEQUOTE___6); var tmp74 *jrt.Class
		var fncls__120 /*line :1280:1*/*jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_A_fn_class












































		if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_A_fn_class = fncls__120d; tmp74 = fncls__120d } else { tmp74 = fncls__120 }; iter__1927001039__auto____17_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp73, tmp74, nil); methods__17 = lang.IFn_Cast(iter__1927001039__auto____17_2).Invoke_O__O(A_arbace_c2j_emit_A_const_785.Invoke_O__O(ox__1))
//line :1280:1
		var fields_forms__18 any; var iter__1927001039__auto____18_2 any; var tmp75 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_A_New_O_O_O(ox__1, ftype__8, fsym__9); var tmp76 *jrt.Class
		var fncls__123 /*line :1280:1*/*jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_A_fn_class





















































		if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_A_fn_class = fncls__123d; tmp76 = fncls__123d } else { tmp76 = fncls__123 }; iter__1927001039__auto____18_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp75, tmp76, nil); fields_forms__18 = lang.IFn_Cast(iter__1927001039__auto____18_2).Invoke_O__O(fields__5)
//line :1280:1
		var members__19 any; var tmp77 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_696.GetRawRoot__O()); var tmp78 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp79 any = lang.Tuple_Create_O__IPersistentVector(ctor__13); var tmp80 any = lang.Tuple_Create_O__IPersistentVector(basis__15); var tmp81 lang.IPersistentVector























































		if jrt.J2g_Truth(create__16) { tmp81 = lang.Tuple_Create_O__IPersistentVector(create__16) } else { tmp81 = nil }; members__19 = tmp77.Invoke_O__O(tmp78.Invoke_O_O_O_O_O_O__O(fields_forms__18, tmp79, alt_ctors__14, tmp80, tmp81, methods__17))
		var tmp82 any = A_arbace_c2j_emit_A_const_36; var tmp83 any = A_arbace_c2j_emit_A_const_324; var tmp84 any = A_arbace_c2j_emit_A_const_786; var tmp85 any = A_arbace_c2j_emit_A_const_787; var tmp86 any = A_arbace_c2j_emit_A_const_788; var tmp87 any = A_arbace_c2j_emit_A_const_789; var tmp88 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_790.GetRawRoot__O()).Invoke_O_O__O(ctx__0, ox__1); var tmp89 any = A_arbace_c2j_emit_A_const_791; var tmp90 any = A_arbace_c2j_emit_A_const_264; var tmp91 any = A_arbace_c2j_emit_A_const_264.Invoke_O__O(ox__1); var tmp92 any = A_arbace_c2j_emit_A_const_792; lang.IFn_Cast(A_arbace_c2j_emit_A_const_27.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_c2j_emit_A_const_311.Invoke_O__O(ctx__0), A_arbace_c2j_emit_A_const_13.GetRawRoot__O(), cname__3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp82, cname__3, tmp83, tmp84, tmp85, tmp86, tmp87, tmp88, tmp89, members__19, tmp90, tmp91, tmp92, A_arbace_c2j_emit_A_const_792.Invoke_O__O(ctx__0)))) }; return cname__3 }
//line :1287:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__ftype__31000376_A_New() *A_arbace_c2j_emit_emit_deftype_class_BANG__ftype__31000376_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__ftype__31000376_A{}; t.Ctor(); return t }
//line :1287:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__ftype__31000376_A) Ctor() {}
//line :1287:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__ftype__31000376_A) Invoke_O_O__O(self, b__1 any) any { var or__1927000174__auto____2 any = A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__1); if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return A_arbace_c2j_emit_A_const_238 } }
func A_arbace_c2j_emit_emit_deftype_class_BANG__fsym__31000378_A_New() *A_arbace_c2j_emit_emit_deftype_class_BANG__fsym__31000378_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__fsym__31000378_A{}; t.Ctor(); return t }
//line :1288:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__fsym__31000378_A) Ctor() {}
//line :1288:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__fsym__31000378_A) Invoke_O_O__O(self, b__1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_36.Invoke_O__O(b__1)) }



func A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000380_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000380_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000380_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1292:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000380_A) Ctor_O_O(c__ftype, c__fsym any) { t.F_ftype = c__ftype; t.F_fsym = c__fsym }
//line :1292:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000380_A) Invoke_O_O__O(self, p1__31000373_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_fsym).Invoke_O__O(p1__31000373_SHARP___1), lang.IFn_Cast(t.F_ftype).Invoke_O__O(p1__31000373_SHARP___1)) }

func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_A_New_O(p0 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_A{}; t.Ctor_O(p0); return t }
//line :1294:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_A) Ctor_O(c__fsym any) { t.F_fsym = c__fsym }
//line :1294:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_A) Invoke_O_O__O(self, s__31000383__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_A_New_O_O_O(s__31000383__1, self, t.F_fsym); var tmp2 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_A_fn_class = fncls__125d; tmp2 = fncls__125d } else { tmp2 = fncls__125 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1294:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1294:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_A) Ctor_O_O_O(c__s__31000383, c__iter__31000382, c__fsym any) { t.F_s__31000383 = c__s__31000383; t.F_iter__31000382 = c__iter__31000382; t.F_fsym = c__fsym }
//line :1294:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_A) Invoke_O__O(self any) any { { var s__31000383__1 any; var t_ any = t.F_s__31000383; t.F_s__31000383 = nil; s__31000383__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000383__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000383__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000383__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000383__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000385__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_fn__31000388_A_New_O_O_I_O(t.F_fsym, b__31000385__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__124 *jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_fn__31000388_A_fn_class; if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_fn__31000388_A_fn_class = fncls__124d; tmp2 = fncls__124d } else { tmp2 = fncls__124 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000382); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000385__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000383__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000385__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000383__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_747; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__31000382); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_231.GetRawRoot__O()).Invoke_O__O(b__4), A_arbace_c2j_emit_A_const_748), lang.IFn_Cast(t.F_fsym).Invoke_O__O(b__4)), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000383__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1294:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_fn__31000388_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_fn__31000388_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_fn__31000388_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1294:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_fn__31000388_A) Ctor_O_O_I_O(c__fsym, c__b__31000385 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_fsym = c__fsym; t.F_b__31000385 = c__b__31000385; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1294:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_fn__31000388_A) Invoke_O__O(self any) any { { var i__31000384__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000384__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000384__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000385; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_747; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_231.GetRawRoot__O()).Invoke_O__O(b__2), A_arbace_c2j_emit_A_const_748), lang.IFn_Cast(t.F_fsym).Invoke_O__O(b__2))); i__31000384__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000384__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1297:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_A) Ctor_O_O_O(c__fbs, c__ftype, c__fsym any) { t.F_fbs = c__fbs; t.F_ftype = c__ftype; t.F_fsym = c__fsym }
//line :1297:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_A_const_732; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_fn__31000393_A_New_O_O(t.F_ftype, t.F_fsym); var tmp6 *jrt.Class; var fncls__112 *jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_fn__31000393_A_fn_class; if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_fn__31000393_A_fn_class = fncls__112d; tmp6 = fncls__112d } else { tmp6 = fncls__112 }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), lang.IFn_Cast(A_arbace_c2j_emit_A_const_733.GetRawRoot__O()).Invoke_O_O__O(k__1, t.F_fbs)))) }
//line :1297:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_fn__31000393_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_fn__31000393_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_fn__31000393_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1297:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_fn__31000393_A) Ctor_O_O(c__ftype, c__fsym any) { t.F_ftype = c__ftype; t.F_fsym = c__fsym }
//line :1297:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_fn__31000393_A) Invoke_O_O__O(self, p1__31000374_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_fsym).Invoke_O__O(p1__31000374_SHARP___1), lang.IFn_Cast(t.F_ftype).Invoke_O__O(p1__31000374_SHARP___1)) }










func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_A_New_O(p0 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_A{}; t.Ctor_O(p0); return t }
//line :1308:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :1308:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_A) Invoke_O_O__O(self, s__31000397__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_A_New_O_O_O(s__31000397__1, self, t.F_m); var tmp2 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_A_fn_class = fncls__139d; tmp2 = fncls__139d } else { tmp2 = fncls__139 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1308:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1308:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_A) Ctor_O_O_O(c__s__31000397, c__iter__31000396, c__m any) { t.F_s__31000397 = c__s__31000397; t.F_iter__31000396 = c__iter__31000396; t.F_m = c__m }
//line :1308:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_A) Invoke_O__O(self any) any { { var s__31000397__1 any; var t_ any = t.F_s__31000397; t.F_s__31000397 = nil; s__31000397__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000397__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000397__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000397__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000397__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000399__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_fn__31000402_A_New_I_O_O_O(size__1927001038__auto____5, b__31000399__6, t.F_m, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_fn__31000402_A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_fn__31000402_A_fn_class = fncls__138d; tmp2 = fncls__138d } else { tmp2 = fncls__138 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000396); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000399__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000397__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000399__6), nil) } } else { var vec__31000407__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000397__3); var i__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000407__4, lang.RT_IntCast_J__I_NoInit(0), nil); var f__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000407__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_767, A_arbace_c2j_emit_A_const_772), lang.IFn_Cast(A_arbace_c2j_emit_A_const_42.GetRawRoot__O()).Invoke_O__O(f__6)); var tmp4 *lang.Keyword = A_arbace_c2j_emit_A_const_23; var c__8 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_766.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__6))); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_129, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__5)).Ref()); var tmp7 any; var v__9 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_c2j_emit_A_const_769, t.F_m, k__7, nil)




	if jrt.NN(jrt.Class_Cast(c__8)).IsPrimitive__Z() {
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_emit_A_const_770; tmp7 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_34, nil, Lit_130), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Class_Cast(c__8)).GetName__String().Ref(), nil)).Ref()), tmp8.Invoke_O_O_O__O(tmp9, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_771.GetRawRoot__O()).Invoke_O__O(c__8)), v__9)) } else {
//line :1313:1
			tmp7 = v__9 }
//line :1308:1
	var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__31000396); return tmp5.Invoke_O_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp6, tmp7, k__7), tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000397__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1308:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_fn__31000402_A_New_I_O_O_O(p0 int32, p1, p2, p3 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_fn__31000402_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_fn__31000402_A{}; t.Ctor_I_O_O_O(p0, p1, p2, p3); return t }
//line :1308:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_fn__31000402_A) Ctor_I_O_O_O(c__size__1927001038__auto__ int32, c__b__31000399, c__m, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__31000399 = c__b__31000399; t.F_m = c__m; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1308:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_fn__31000402_A) Invoke_O__O(self any) any { { var i__31000398__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000398__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__31000403__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000398__1)); var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000403__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000403__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_767, A_arbace_c2j_emit_A_const_768), lang.IFn_Cast(A_arbace_c2j_emit_A_const_42.GetRawRoot__O()).Invoke_O__O(f__4)); var tmp2 *lang.Keyword = A_arbace_c2j_emit_A_const_23; var c__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_766.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(f__4))); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp4 any = t.F_b__31000399; var tmp5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_129, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__3)).Ref()); var tmp6 any; var v__7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_c2j_emit_A_const_769, t.F_m, k__5, nil)




	if jrt.NN(jrt.Class_Cast(c__6)).IsPrimitive__Z() {
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_emit_A_const_770; tmp6 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_34, nil, Lit_130), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Class_Cast(c__6)).GetName__String().Ref(), nil)).Ref()), tmp7.Invoke_O_O_O__O(tmp8, lang.IFn_Cast(A_arbace_c2j_emit_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_771.GetRawRoot__O()).Invoke_O__O(c__6)), v__7)) } else {
//line :1313:1
			tmp6 = v__7 }
//line :1308:1
	tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O_O__IPersistentVector(tmp5, tmp6, k__5)); i__31000398__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000398__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000413_A_New() *A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000413_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000413_A{}; t.Ctor(); return t }
//line :1319:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000413_A) Ctor() {}
//line :1319:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000413_A) Invoke_O_O__O(self, p__31000412__1 any) any { var vec__31000414__2 any = p__31000412__1; var v__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000414__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000414__2, lang.RT_IntCast_J__I_NoInit(1), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000414__2, lang.RT_IntCast_J__I_NoInit(2), nil); _ = ___5; return lang.Tuple_Create_O_O__IPersistentVector(v__3, x__4) }
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_A_New_O(p0 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_A{}; t.Ctor_O(p0); return t }
//line :1320:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :1320:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_A) Invoke_O_O__O(self, s__31000419__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_A_New_O_O_O(self, s__31000419__1, t.F_m); var tmp2 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_A_fn_class = fncls__143d; tmp2 = fncls__143d } else { tmp2 = fncls__143 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1320:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1320:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_A) Ctor_O_O_O(c__iter__31000418, c__s__31000419, c__m any) { t.F_iter__31000418 = c__iter__31000418; t.F_s__31000419 = c__s__31000419; t.F_m = c__m }
//line :1320:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_A) Invoke_O__O(self any) any { { var s__31000419__1 any; var t_ any = t.F_s__31000419; t.F_s__31000419 = nil; s__31000419__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000419__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000419__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000419__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000419__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000421__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_fn__31000424_A_New_I_O_O_O(size__1927001038__auto____5, t.F_m, b__31000421__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__142 *jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_fn__31000424_A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_fn__31000424_A_fn_class = fncls__142d; tmp2 = fncls__142d } else { tmp2 = fncls__142 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000418); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000421__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000419__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000421__6), nil) } } else { var vec__31000429__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000419__3); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000429__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000429__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000429__4, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_779; var tmp6 any = t.F_m; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__31000418); _ = ___5; _ = ___6; return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_780, t.F_m, k__7)), tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000419__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1320:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_fn__31000424_A_New_I_O_O_O(p0 int32, p1, p2, p3 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_fn__31000424_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_fn__31000424_A{}; t.Ctor_I_O_O_O(p0, p1, p2, p3); return t }
//line :1320:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_fn__31000424_A) Ctor_I_O_O_O(c__size__1927001038__auto__ int32, c__m, c__b__31000421, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_m = c__m; t.F_b__31000421 = c__b__31000421; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1320:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_fn__31000424_A) Invoke_O__O(self any) any { { var i__31000420__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000420__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__31000425__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000420__1)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000425__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000425__2, lang.RT_IntCast_J__I_NoInit(1), nil); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000425__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000421; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_779; var tmp6 any = t.F_m; _ = ___3; _ = ___4; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_emit_A_const_780, t.F_m, k__5))); i__31000420__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000420__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_A_New_O(p0 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_A{}; t.Ctor_O(p0); return t }
//line :1325:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_A) Ctor_O(c__ctx_SINGLEQUOTE_ any) { t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_ }
//line :1325:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_A) Invoke_O_O__O(self, s__31000435__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_A_New_O_O_O(s__31000435__1, self, t.F_ctx_SINGLEQUOTE_); var tmp2 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_A_fn_class = fncls__119d; tmp2 = fncls__119d } else { tmp2 = fncls__119 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1325:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1325:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_A) Ctor_O_O_O(c__s__31000435, c__iter__31000434, c__ctx_SINGLEQUOTE_ any) { t.F_s__31000435 = c__s__31000435; t.F_iter__31000434 = c__iter__31000434; t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_ }
//line :1325:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_A) Invoke_O__O(self any) any { { var s__31000435__1 any; var t_ any = t.F_s__31000435; t.F_s__31000435 = nil; s__31000435__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000435__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000435__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000435__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000435__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000437__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_A_New_O_I_O_O(b__31000437__6, size__1927001038__auto____5, t.F_ctx_SINGLEQUOTE_, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_A_fn_class = fncls__116d; tmp2 = fncls__116d } else { tmp2 = fncls__116 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000434); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000437__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000435__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000437__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000435__3); var mn__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(m__4); var als__6 any = A_arbace_c2j_emit_A_const_714.Invoke_O__O(mn__5); var ptypes__7 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000446_A_New(); var tmp6 *jrt.Class
															var fncls__117 /*line :1325:1*/*jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000446_A_fn_class


	if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000446_A_fn_class = fncls__117d; tmp6 = fncls__117d } else { tmp6 = fncls__117 }; ptypes__7 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), als__6)
//line :1325:1
	var ps__8 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_emit_A_const_735; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000448_A_New(); var tmp12 *jrt.Class
	var fncls__118 /*line :1325:1*/*jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000448_A_fn_class



	if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000448_A_fn_class = fncls__118d; tmp12 = fncls__118d } else { tmp12 = fncls__118 }; ps__8 = tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(tmp9, tmp10.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), als__6, ptypes__7)))
//line :1325:1
	var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_22.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_emit_A_const_736; var tmp16 any = tmp14.Invoke_O_O_O_O__O(tmp15, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_36.Invoke_O__O(mn__5)), A_arbace_c2j_emit_A_const_739), lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(ps__8, A_arbace_c2j_emit_A_const_710.Invoke_O__O(mn__5)), lang.IFn_Cast(A_arbace_c2j_emit_A_const_737.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx_SINGLEQUOTE_, mn__5, ps__8)); var tmp17 any = A_arbace_c2j_emit_A_const_13.GetRawRoot__O(); var tmp18 any = A_arbace_c2j_emit_A_const_265; var tmp19 lang.IFn = lang.IFn_Cast(t.F_iter__31000434); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(tmp13.Invoke_O_O_O_O__O(tmp16, tmp17, tmp18, A_arbace_c2j_emit_A_const_264.Invoke_O__O(mn__5)), tmp19.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000435__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1325:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :1325:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_A) Ctor_O_I_O_O(c__b__31000437 any, c__size__1927001038__auto__ int32, c__ctx_SINGLEQUOTE_, c__c__1927001037__auto__ any) { t.F_b__31000437 = c__b__31000437; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1325:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_A) Invoke_O__O(self any) any { { var i__31000436__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000436__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000436__1)); var mn__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(m__2); var als__4 any = A_arbace_c2j_emit_A_const_714.Invoke_O__O(mn__3); var ptypes__5 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000441_A_New(); var tmp4 *jrt.Class
																	var fncls__114 /*line :1325:1*/*jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000441_A_fn_class


	if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000441_A_fn_class = fncls__114d; tmp4 = fncls__114d } else { tmp4 = fncls__114 }; ptypes__5 = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), als__4)
//line :1325:1
	var ps__6 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp7 any = A_arbace_c2j_emit_A_const_735; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000443_A_New(); var tmp10 *jrt.Class
	var fncls__115 /*line :1325:1*/*jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000443_A_fn_class



	if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000443_A_fn_class = fncls__115d; tmp10 = fncls__115d } else { tmp10 = fncls__115 }; ps__6 = tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), als__4, ptypes__5)))
//line :1325:1
	var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp12 any = t.F_b__31000437; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_22.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_emit_A_const_736; var tmp16 any = tmp14.Invoke_O_O_O_O__O(tmp15, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_36.Invoke_O__O(mn__3)), A_arbace_c2j_emit_A_const_738), lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(ps__6, A_arbace_c2j_emit_A_const_710.Invoke_O__O(mn__3)), lang.IFn_Cast(A_arbace_c2j_emit_A_const_737.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx_SINGLEQUOTE_, mn__3, ps__6)); var tmp17 any = A_arbace_c2j_emit_A_const_13.GetRawRoot__O(); var tmp18 any = A_arbace_c2j_emit_A_const_265; tmp11.Invoke_O_O__O(tmp12, tmp13.Invoke_O_O_O_O__O(tmp16, tmp17, tmp18, A_arbace_c2j_emit_A_const_264.Invoke_O__O(mn__3))); i__31000436__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000436__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000441_A_New() *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000441_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000441_A{}; t.Ctor(); return t }
//line :1328:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000441_A) Ctor() {}
//line :1328:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000441_A) Invoke_O_O__O(self, p1__31000375_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_emit_A_const_472; var tmp2 *lang.Keyword = A_arbace_c2j_emit_A_const_488; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(p1__31000375_SHARP___1)))) }
//line :1328:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000446_A_New() *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000446_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000446_A{}; t.Ctor(); return t }
//line :1328:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000446_A) Ctor() {}
//line :1328:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000446_A) Invoke_O_O__O(self, p1__31000375_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_emit_A_const_472; var tmp2 *lang.Keyword = A_arbace_c2j_emit_A_const_488; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(p1__31000375_SHARP___1)))) }
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000443_A_New() *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000443_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000443_A{}; t.Ctor(); return t }
//line :1329:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000443_A) Ctor() {}
//line :1329:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000443_A) Invoke_O_O_O__O(self, lb__1, c__2 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__1)), c__2) }
//line :1329:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000448_A_New() *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000448_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000448_A{}; t.Ctor(); return t }
//line :1329:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000448_A) Ctor() {}
//line :1329:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000448_A) Invoke_O_O_O__O(self, lb__1, c__2 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__1)), c__2) }




func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1334:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_A) Ctor_O_O_O(c__ox, c__ftype, c__fsym any) { t.F_ox = c__ox; t.F_ftype = c__ftype; t.F_fsym = c__fsym }
//line :1334:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_A) Invoke_O_O__O(self, s__31000453__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_A_New_O_O_O_O_O(t.F_ox, s__31000453__1, self, t.F_ftype, t.F_fsym); var tmp2 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_A_fn_class = fncls__122d; tmp2 = fncls__122d } else { tmp2 = fncls__122 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1334:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1334:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_A) Ctor_O_O_O_O_O(c__ox, c__s__31000453, c__iter__31000452, c__ftype, c__fsym any) { t.F_ox = c__ox; t.F_s__31000453 = c__s__31000453; t.F_iter__31000452 = c__iter__31000452; t.F_ftype = c__ftype; t.F_fsym = c__fsym }
//line :1334:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_A) Invoke_O__O(self any) any { { var s__31000453__1 any; var t_ any = t.F_s__31000453; t.F_s__31000453 = nil; s__31000453__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000453__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000453__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000453__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000453__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000455__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_fn__31000458_A_New_O_O_O_I_O_O(t.F_ox, t.F_ftype, t.F_fsym, size__1927001038__auto____5, c__1927001037__auto____4, b__31000455__6); var tmp2 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_fn__31000458_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_fn__31000458_A_fn_class = fncls__121d; tmp2 = fncls__121d } else { tmp2 = fncls__121 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000452); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000455__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000453__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000455__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000453__3); var b__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_740; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__31000452); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_fsym).Invoke_O__O(b__5), lang.IFn_Cast(A_arbace_c2j_emit_A_const_741.GetRawRoot__O()).Invoke_O_O__O(t.F_ox, lb__4)), lang.IFn_Cast(t.F_ftype).Invoke_O__O(b__5))), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000453__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1334:1
func A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_fn__31000458_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_fn__31000458_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_fn__31000458_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :1334:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_fn__31000458_A) Ctor_O_O_O_I_O_O(c__ox, c__ftype, c__fsym any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__31000455 any) { t.F_ox = c__ox; t.F_ftype = c__ftype; t.F_fsym = c__fsym; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__31000455 = c__b__31000455 }
//line :1334:1
func (t *A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_fn__31000458_A) Invoke_O__O(self any) any { { var i__31000454__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000454__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000454__1)); var b__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000455; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_740; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_fsym).Invoke_O__O(b__3), lang.IFn_Cast(A_arbace_c2j_emit_A_const_741.GetRawRoot__O()).Invoke_O_O__O(t.F_ox, lb__2)), lang.IFn_Cast(t.F_ftype).Invoke_O__O(b__3)))); i__31000454__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000454__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_c2j_emit_emit_fn_class_BANG__A_New() *A_arbace_c2j_emit_emit_fn_class_BANG__A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__A{}; t.Ctor(); return t }
//line :1342:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__A) Ctor() {}
//line :1342:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__A) Invoke_O_O_O__O(self, ctx__0, ox__1 any) any { var named__3 any = A_arbace_c2j_emit_A_const_793.Invoke_O__O(ctx__0); var known__4 any = jrt.NN(jrt.IdentityHashMap_Cast(named__3)).Get_O__O(A_arbace_c2j_emit_A_const_14.Invoke_O__O(ox__1)); var base__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_36.Invoke_O__O(ox__1)); var cname__6 any; var or__1927000174__auto____6 any = known__4; if









	jrt.J2g_Truth(or__1927000174__auto____6) { cname__6 = or__1927000174__auto____6 } else {
		var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000465_A_New_O_O(ctx__0, base__5); var tmp2 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000465_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000465_A_fn_class = fncls__145d; tmp2 = fncls__145d } else { tmp2 = fncls__145 }; cname__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }; if


	jrt.J2g_Truth(known__4) { } else {
		jrt.NN(jrt.IdentityHashMap_Cast(named__3)).Put_O_O__O(A_arbace_c2j_emit_A_const_14.Invoke_O__O(ox__1), cname__6)
		lang.IFn_Cast(A_arbace_c2j_emit_A_const_27.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_c2j_emit_A_const_311.Invoke_O__O(ctx__0), A_arbace_c2j_emit_A_const_13.GetRawRoot__O(), cname__6, A_arbace_c2j_emit_A_const_742)
//line :1356:1
		var cls__7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_729.GetRawRoot__O()).Invoke_O_O__O(ctx__0, lang.IFn_Cast(A_arbace_c2j_emit_A_const_808.GetRawRoot__O()).Invoke_O__O(cname__6)); var fn_QMARK___8 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_73, A_arbace_c2j_emit_A_const_501.Invoke_O__O(ox__1)); var ctx_SINGLEQUOTE___9 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_A_const_40; var tmp5 any = A_arbace_c2j_emit_A_const_743; var tmp6 any = A_arbace_c2j_emit_A_const_269; var tmp7 any = A_arbace_c2j_emit_A_const_809.Invoke_O__O(ox__1); var tmp8 any = A_arbace_c2j_emit_A_const_230; var tmp9 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_556.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_534.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_535.Invoke_O__O(ox__1))); var tmp10 any = A_arbace_c2j_emit_A_const_272; var tmp11 any





		if fn_QMARK___8 { tmp11 = A_arbace_c2j_emit_A_const_810 } else { tmp11 = A_arbace_c2j_emit_A_const_811 }
//line :1361:1
		ctx_SINGLEQUOTE___9 = tmp3.Invoke_O_O_O_O_O_O_O_O_O_O_O__O(ctx__0, tmp4, cls__7, tmp5, ox__1, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11)
//line :1356:1
		var closes__10 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_534.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_535.Invoke_O__O(ox__1)); var meta_QMARK___11 any; var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(fn_QMARK___8).Ref())








		if jrt.J2g_Truth(and__1927000168__auto____11) { meta_QMARK___11 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_c2j_emit_A_const_537.Invoke_O__O(ox__1))).Ref() } else { meta_QMARK___11 = and__1927000168__auto____11 }
//line :1356:1
		var fields__12 any; var iter__1927001039__auto____12 any; var tmp12 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_A_New(); var tmp13 *jrt.Class
		var fncls__148 /*line :1356:1*/*jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_A_fn_class









		if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_A_fn_class = fncls__148d; tmp13 = fncls__148d } else { tmp13 = fncls__148 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); fields__12 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(closes__10)
//line :1356:1
		var ctor__13 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_emit_A_const_812; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp19 any = A_arbace_c2j_emit_A_const_815; var tmp20 lang.IPersistentVector











		if jrt.J2g_Truth(meta_QMARK___11) { tmp20 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_816, A_arbace_c2j_emit_A_const_817)) } else { tmp20 = nil }; var tmp21 any = tmp20; var tmp22 any; var iter__1927001039__auto____13 any; var tmp23 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_A_New(); var tmp24 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_A_fn_class
		if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_A_fn_class = fncls__161d; tmp24 = fncls__161d } else { tmp24 = fncls__161 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); tmp22 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(closes__10)
//line :1368:1
		var tmp25 any = tmp16.Invoke_O_O__O(tmp17.Invoke_O__O(tmp18.Invoke_O_O_O__O(tmp19, tmp21, tmp22)), A_arbace_c2j_emit_A_const_814); var tmp26 any = A_arbace_c2j_emit_A_const_813; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp28 any




		if jrt.J2g_Truth(meta_QMARK___11) { tmp28 = A_arbace_c2j_emit_A_const_818 } else { tmp28 = nil }
//line :1368:1
		var tmp29 any = tmp28; var tmp30 any; var iter__1927001039__auto____13_2 any; var tmp31 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_A_New(); var tmp32 *jrt.Class
		var fncls__164 /*line :1368:1*/*jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_A_fn_class





		if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_A_fn_class = fncls__164d; tmp32 = fncls__164d } else { tmp32 = fncls__164 }; iter__1927001039__auto____13_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); tmp30 = lang.IFn_Cast(iter__1927001039__auto____13_2).Invoke_O__O(closes__10)
//line :1368:1
		ctor__13 = tmp14.Invoke_O_O_O_O__O(tmp15, tmp25, tmp26, tmp27.Invoke_O_O__O(tmp29, tmp30))
//line :1356:1
		var variadic__14 any; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_432.GetRawRoot__O()); var tmp34 any = A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000497_A_New(); var tmp35 *jrt.Class
		var fncls__165 /*line :1356:1*/*jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000497_A_fn_class



















		if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000497_A_fn_class = fncls__165d; tmp35 = fncls__165d } else { tmp35 = fncls__165 }; var tmp36 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil); var tmp37 any; if fn_QMARK___8 { tmp37 = A_arbace_c2j_emit_A_const_785.Invoke_O__O(ox__1) } else { tmp37 = nil }; variadic__14 = tmp33.Invoke_O_O__O(tmp36, tmp37)
//line :1356:1
		var methods__15 any





















		if fn_QMARK___8 { var iter__1927001039__auto____15 any; var tmp38 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_A_New_O(ctx_SINGLEQUOTE___9); var tmp39 *jrt.Class
			var fncls__151 /*line :1378:1*/*jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_A_fn_class


			if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_A_fn_class = fncls__151d; tmp39 = fncls__151d } else { tmp39 = fncls__151 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil); methods__15 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(A_arbace_c2j_emit_A_const_785.Invoke_O__O(ox__1)) } else {
//line :1378:1
				var iter__1927001039__auto____15_2 any; var tmp40 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_A_New_O(ctx_SINGLEQUOTE___9); var tmp41 *jrt.Class
				var fncls__158 /*line :1378:1*/*jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_A_fn_class











				if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_A_fn_class = fncls__158d; tmp41 = fncls__158d } else { tmp41 = fncls__158 }; iter__1927001039__auto____15_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); methods__15 = lang.IFn_Cast(iter__1927001039__auto____15_2).Invoke_O__O(A_arbace_c2j_emit_A_const_785.Invoke_O__O(ox__1)) }
//line :1356:1
		var extra__16 any; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp43 lang.IPersistentVector









































		if fn_QMARK___8 { var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp45 any = A_arbace_c2j_emit_A_const_821; tmp43 = lang.Tuple_Create_O__IPersistentVector(tmp44.Invoke_O_O__O(tmp45, lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_823, A_arbace_c2j_emit_A_const_824), A_arbace_c2j_emit_A_const_822))) } else { tmp43 = nil }
//line :1397:1
		var tmp46 any = tmp43; var tmp47 lang.IPersistentVector





		if jrt.J2g_Truth(meta_QMARK___11) { var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp49 any = A_arbace_c2j_emit_A_const_825; var tmp50 any = tmp48.Invoke_O_O__O(tmp49, lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_826, A_arbace_c2j_emit_A_const_827)); var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp52 any = A_arbace_c2j_emit_A_const_828; var tmp53 any = tmp51.Invoke_O_O_O_O__O(tmp52, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_830, A_arbace_c2j_emit_A_const_831), lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_832, A_arbace_c2j_emit_A_const_833), A_arbace_c2j_emit_A_const_829); var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp55 any = A_arbace_c2j_emit_A_const_834; var tmp56 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_835, A_arbace_c2j_emit_A_const_836); var tmp57 any = A_arbace_c2j_emit_A_const_838; var tmp58 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp57, lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_839, A_arbace_c2j_emit_A_const_840)), A_arbace_c2j_emit_A_const_837); var tmp59 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_102.GetRawRoot__O()); var tmp60 any = A_arbace_c2j_emit_A_const_841; var tmp61 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(cname__6); var tmp62 any = A_arbace_c2j_emit_A_const_842; var tmp63 any; var iter__1927001039__auto____16 any; var tmp64 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_A_New(); var tmp65 *jrt.Class
			var fncls__168 /*line :1403:1*/*jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_A_fn_class




			if fncls__168 == nil { var fncls__168d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_A_fn_class = fncls__168d; tmp65 = fncls__168d } else { tmp65 = fncls__168 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp64, tmp65, nil); tmp63 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(closes__10)
//line :1403:1
			tmp47 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp50, tmp53, tmp54.Invoke_O_O_O_O__O(tmp55, tmp56, tmp58, tmp59.Invoke_O_O_O_O__O(tmp60, tmp61, tmp62, tmp63))) } else { tmp47 = nil }
//line :1397:1
		extra__16 = tmp42.Invoke_O_O__O(tmp46, tmp47)
//line :1356:1
		var interfaces__17 any




















































		if fn_QMARK___8 {
			var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp67 any; var iter__1927001039__auto____17 any; var tmp68 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_A_New(); var tmp69 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_A_fn_class; if fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_A_fn_class = fncls__171d; tmp69 = fncls__171d } else { tmp69 = fncls__171 }; iter__1927001039__auto____17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp68, tmp69, nil); tmp67 = lang.IFn_Cast(iter__1927001039__auto____17).Invoke_O__O(A_arbace_c2j_emit_A_const_785.Invoke_O__O(ox__1)); interfaces__17 = tmp66.Invoke_O__O(tmp67) } else {


				interfaces__17 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_790.GetRawRoot__O()).Invoke_O_O__O(ctx__0, ox__1) }
//line :1356:1
		var members__18 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_696.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()).Invoke_O_O_O_O__O(fields__12, lang.Tuple_Create_O__IPersistentVector(ctor__13), methods__15, extra__16)); var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_27.GetRawRoot__O()); var tmp71 any = A_arbace_c2j_emit_A_const_311.Invoke_O__O(ctx__0); var tmp72 any = A_arbace_c2j_emit_A_const_13.GetRawRoot__O(); var tmp73 any = A_arbace_c2j_emit_A_const_36; var tmp74 any = A_arbace_c2j_emit_A_const_791; var tmp75 any = A_arbace_c2j_emit_A_const_792; var tmp76 any = A_arbace_c2j_emit_A_const_792.Invoke_O__O(ctx__0); var tmp77 any = A_arbace_c2j_emit_A_const_324; var tmp78 *lang.Keyword






























































		if fn_QMARK___8 { tmp78 = A_arbace_c2j_emit_A_const_844 } else { tmp78 = A_arbace_c2j_emit_A_const_845 }
//line :1415:1
		var tmp79 any = tmp78.Ref(); var tmp80 any = A_arbace_c2j_emit_A_const_787; var tmp81 any = A_arbace_c2j_emit_A_const_846; var tmp82 any = A_arbace_c2j_emit_A_const_789; var tmp83 any = A_arbace_c2j_emit_A_const_539; var tmp84 *jrt.Integer






		if jrt.J2g_Truth(variadic__14) { tmp84 = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_c2j_emit_A_const_712.Invoke_O__O(variadic__14))) } else { tmp84 = nil }
//line :1415:1
		var tmp85 any = tmp84.Ref(); var tmp86 any = A_arbace_c2j_emit_A_const_264; tmp70.Invoke_O_O_O_O__O(tmp71, tmp72, cname__6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp73, cname__6, tmp74, members__18, tmp75, tmp76, tmp77, tmp79, tmp80, tmp81, tmp82, interfaces__17, tmp83, tmp85, tmp86, A_arbace_c2j_emit_A_const_264.Invoke_O__O(ox__1)))) }; return cname__6 }
//line :1353:1
func A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000465_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000465_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000465_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1353:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000465_A) Ctor_O_O(c__ctx, c__base any) { t.F_ctx = c__ctx; t.F_base = c__base }
//line :1353:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000465_A) Invoke_O__O(self any) any { { var k__1 int64 = 0; L1: for { var c__2 any
												if lang.Numbers_IsZero_J__Z_NoInit(k__1) { c__2 = t.F_base } else { var tmp1 any = t.F_base; c__2 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_151, nil), jrt.RefArrayOf(jrt.Object_class, tmp1, nil, jrt.Long_ValueOf_J__Long_NoInit(k__1).Ref())).Ref() }
												if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_311.Invoke_O__O(t.F_ctx)), c__2)) { k__1 = lang.Numbers_Inc_J__J_NoInit(k__1); continue L1 } else { return c__2 } } }; /*line :1353:1*/panic("j2g: unreachable") }












func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_A_New() *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_A{}; t.Ctor(); return t }
//line :1366:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_A) Ctor() {}
//line :1366:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_A) Invoke_O_O__O(self, s__31000468__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_A_New_O_O(s__31000468__1, self); var tmp2 *jrt.Class; var fncls__147 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_A_fn_class; if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_A_fn_class = fncls__147d; tmp2 = fncls__147d } else { tmp2 = fncls__147 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1366:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1366:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_A) Ctor_O_O(c__s__31000468, c__iter__31000467 any) { t.F_s__31000468 = c__s__31000468; t.F_iter__31000467 = c__iter__31000467 }
//line :1366:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_A) Invoke_O__O(self any) any { { var s__31000468__1 any; var t_ any = t.F_s__31000468; t.F_s__31000468 = nil; s__31000468__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000468__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000468__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000468__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000468__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000470__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_fn__31000473_A_New_O_I_O(b__31000470__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__146 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_fn__31000473_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_fn__31000473_A_fn_class = fncls__146d; tmp2 = fncls__146d } else { tmp2 = fncls__146 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000467); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000470__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000468__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000470__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000468__3); var b__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_A_const_794; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_36.Invoke_O__O(b__5)); var tmp9 any; var or__1927000174__auto____6 any = A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__5)
															if jrt.J2g_Truth(or__1927000174__auto____6) { tmp9 = or__1927000174__auto____6 } else { tmp9 = A_arbace_c2j_emit_A_const_238 }
//line :1366:1
	var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__31000467); return tmp4.Invoke_O_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(tmp8, tmp9)), tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000468__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1366:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_fn__31000473_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_fn__31000473_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_fn__31000473_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1366:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_fn__31000473_A) Ctor_O_I_O(c__b__31000470 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__31000470 = c__b__31000470; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1366:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_fn__31000473_A) Invoke_O__O(self any) any { { var i__31000469__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000469__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000469__1)); var b__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000470; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_794; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()); var tmp7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_36.Invoke_O__O(b__3)); var tmp8 any; var or__1927000174__auto____4 any = A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__3)
																if jrt.J2g_Truth(or__1927000174__auto____4) { tmp8 = or__1927000174__auto____4 } else { tmp8 = A_arbace_c2j_emit_A_const_238 }
//line :1366:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8))); i__31000469__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000469__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_A_New() *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_A{}; t.Ctor(); return t }
//line :1369:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_A) Ctor() {}
//line :1369:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_A) Invoke_O_O__O(self, s__31000478__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_A_New_O_O(s__31000478__1, self); var tmp2 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_A_fn_class = fncls__160d; tmp2 = fncls__160d } else { tmp2 = fncls__160 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1369:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1369:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_A) Ctor_O_O(c__s__31000478, c__iter__31000477 any) { t.F_s__31000478 = c__s__31000478; t.F_iter__31000477 = c__iter__31000477 }
//line :1369:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_A) Invoke_O__O(self any) any { { var s__31000478__1 any; var t_ any = t.F_s__31000478; t.F_s__31000478 = nil; s__31000478__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000478__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000478__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000478__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000478__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000480__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_fn__31000483_A_New_O_I_O(b__31000480__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_fn__31000483_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_fn__31000483_A_fn_class = fncls__159d; tmp2 = fncls__159d } else { tmp2 = fncls__159 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000477); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000480__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000478__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000480__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000478__3); var b__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_156, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_emit_A_const_36.Invoke_O__O(b__5))).Ref()); var tmp7 any; var or__1927000174__auto____6 any = A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__5)
															if jrt.J2g_Truth(or__1927000174__auto____6) { tmp7 = or__1927000174__auto____6 } else { tmp7 = A_arbace_c2j_emit_A_const_238 }
//line :1369:1
	var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__31000477); return tmp4.Invoke_O_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000478__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1369:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_fn__31000483_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_fn__31000483_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_fn__31000483_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1369:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_fn__31000483_A) Ctor_O_I_O(c__b__31000480 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__31000480 = c__b__31000480; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1369:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_fn__31000483_A) Invoke_O__O(self any) any { { var i__31000479__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000479__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000479__1)); var b__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000480; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_156, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_emit_A_const_36.Invoke_O__O(b__3))).Ref()); var tmp6 any; var or__1927000174__auto____4 any = A_arbace_c2j_emit_A_const_275.Invoke_O__O(b__3)
																if jrt.J2g_Truth(or__1927000174__auto____4) { tmp6 = or__1927000174__auto____4 } else { tmp6 = A_arbace_c2j_emit_A_const_238 }
//line :1369:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, tmp6)); i__31000479__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000479__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_A_New() *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_A{}; t.Ctor(); return t }
//line :1374:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_A) Ctor() {}
//line :1374:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_A) Invoke_O_O__O(self, s__31000488__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_A_New_O_O(s__31000488__1, self); var tmp2 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_A_fn_class = fncls__163d; tmp2 = fncls__163d } else { tmp2 = fncls__163 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1374:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1374:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_A) Ctor_O_O(c__s__31000488, c__iter__31000487 any) { t.F_s__31000488 = c__s__31000488; t.F_iter__31000487 = c__iter__31000487 }
//line :1374:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_A) Invoke_O__O(self any) any { { var s__31000488__1 any; var t_ any = t.F_s__31000488; t.F_s__31000488 = nil; s__31000488__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000488__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000488__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000488__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000488__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000490__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_fn__31000493_A_New_O_I_O(b__31000490__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__162 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_fn__31000493_A_fn_class; if fncls__162 == nil { var fncls__162d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_fn__31000493_A_fn_class = fncls__162d; tmp2 = fncls__162d } else { tmp2 = fncls__162 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000487); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000490__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000488__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000490__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000488__3); var b__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_819; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__31000487); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_231.GetRawRoot__O()).Invoke_O__O(b__5), A_arbace_c2j_emit_A_const_820), lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_156, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_emit_A_const_36.Invoke_O__O(b__5))).Ref())), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000488__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1374:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_fn__31000493_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_fn__31000493_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_fn__31000493_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1374:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_fn__31000493_A) Ctor_O_I_O(c__b__31000490 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__31000490 = c__b__31000490; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1374:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_fn__31000493_A) Invoke_O__O(self any) any { { var i__31000489__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000489__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000489__1)); var b__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000490; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_819; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_231.GetRawRoot__O()).Invoke_O__O(b__3), A_arbace_c2j_emit_A_const_820), lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_156, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_emit_A_const_36.Invoke_O__O(b__3))).Ref()))); i__31000489__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000489__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000497_A_New() *A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000497_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000497_A{}; t.Ctor(); return t }
//line :1376:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000497_A) Ctor() {}
//line :1376:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000497_A) Invoke_O_O__O(self, p1__31000463_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_emit_A_const_798; if jrt.J2g_Truth(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(p1__31000463_SHARP___1))) { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(p1__31000463_SHARP___1) } else { return nil } }




func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_A_New_O(p0 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_A{}; t.Ctor_O(p0); return t }
//line :1381:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_A) Ctor_O(c__ctx_SINGLEQUOTE_ any) { t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_ }
//line :1381:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_A) Invoke_O_O__O(self, s__31000500__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_A_New_O_O_O(s__31000500__1, self, t.F_ctx_SINGLEQUOTE_); var tmp2 *jrt.Class; var fncls__150 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_A_fn_class; if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_159, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_A_fn_class = fncls__150d; tmp2 = fncls__150d } else { tmp2 = fncls__150 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1381:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1381:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_A) Ctor_O_O_O(c__s__31000500, c__iter__31000499, c__ctx_SINGLEQUOTE_ any) { t.F_s__31000500 = c__s__31000500; t.F_iter__31000499 = c__iter__31000499; t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_ }
//line :1381:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_A) Invoke_O__O(self any) any { { var s__31000500__1 any; var t_ any = t.F_s__31000500; t.F_s__31000500 = nil; s__31000500__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000500__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000500__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000500__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000500__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000502__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_fn__31000505_A_New_O_O_I_O(b__31000502__6, t.F_ctx_SINGLEQUOTE_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_fn__31000505_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_160, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_fn__31000505_A_fn_class = fncls__149d; tmp2 = fncls__149d } else { tmp2 = fncls__149 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000499); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000502__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000500__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000502__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000500__3); var mn__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(m__4); var req__6 any = A_arbace_c2j_emit_A_const_712.Invoke_O__O(mn__5); var ps__7 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_A_const_802; var tmp7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_796.GetRawRoot__O(), req__6); var tmp8 lang.IPersistentVector



	if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_713.Invoke_O__O(mn__5)) { tmp8 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_796.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_713.Invoke_O__O(mn__5))) } else { tmp8 = nil }
//line :1384:1
	ps__7 = tmp4.Invoke_O__O(tmp5.Invoke_O_O_O__O(tmp6, tmp7, tmp8))
//line :1381:1
	var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_22.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_A_const_797; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()); var tmp14 any





	if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_798.Invoke_O__O(mn__5)) { tmp14 = A_arbace_c2j_emit_A_const_799 } else { tmp14 = A_arbace_c2j_emit_A_const_800 }
//line :1381:1
	var tmp15 any = tmp11.Invoke_O_O_O_O__O(tmp12, tmp13.Invoke_O_O__O(tmp14, A_arbace_c2j_emit_A_const_803), ps__7, lang.IFn_Cast(A_arbace_c2j_emit_A_const_737.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx_SINGLEQUOTE_, mn__5, ps__7)); var tmp16 any = A_arbace_c2j_emit_A_const_13.GetRawRoot__O(); var tmp17 any = A_arbace_c2j_emit_A_const_265; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__31000499); return tmp9.Invoke_O_O__O(tmp10.Invoke_O_O_O_O__O(tmp15, tmp16, tmp17, A_arbace_c2j_emit_A_const_264.Invoke_O__O(mn__5)), tmp18.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000500__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1381:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_fn__31000505_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_fn__31000505_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_fn__31000505_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1381:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_fn__31000505_A) Ctor_O_O_I_O(c__b__31000502, c__ctx_SINGLEQUOTE_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__31000502 = c__b__31000502; t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1381:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_fn__31000505_A) Invoke_O__O(self any) any { { var i__31000501__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000501__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000501__1)); var mn__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(m__2); var req__4 any = A_arbace_c2j_emit_A_const_712.Invoke_O__O(mn__3); var ps__5 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_A_const_795; var tmp5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_796.GetRawRoot__O(), req__4); var tmp6 lang.IPersistentVector



	if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_713.Invoke_O__O(mn__3)) { tmp6 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_emit_A_const_796.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_713.Invoke_O__O(mn__3))) } else { tmp6 = nil }
//line :1384:1
	ps__5 = tmp2.Invoke_O__O(tmp3.Invoke_O_O_O__O(tmp4, tmp5, tmp6))
//line :1381:1
	var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp8 any = t.F_b__31000502; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_22.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_emit_A_const_797; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()); var tmp13 any





	if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_798.Invoke_O__O(mn__3)) { tmp13 = A_arbace_c2j_emit_A_const_799 } else { tmp13 = A_arbace_c2j_emit_A_const_800 }
//line :1381:1
	var tmp14 any = tmp10.Invoke_O_O_O_O__O(tmp11, tmp12.Invoke_O_O__O(tmp13, A_arbace_c2j_emit_A_const_801), ps__5, lang.IFn_Cast(A_arbace_c2j_emit_A_const_737.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx_SINGLEQUOTE_, mn__3, ps__5)); var tmp15 any = A_arbace_c2j_emit_A_const_13.GetRawRoot__O(); var tmp16 any = A_arbace_c2j_emit_A_const_265; tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O_O_O_O__O(tmp14, tmp15, tmp16, A_arbace_c2j_emit_A_const_264.Invoke_O__O(mn__3))); i__31000501__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000501__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_A_New_O(p0 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_A{}; t.Ctor_O(p0); return t }
//line :1390:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_A) Ctor_O(c__ctx_SINGLEQUOTE_ any) { t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_ }
//line :1390:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_A) Invoke_O_O__O(self, s__31000510__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_A_New_O_O_O(self, s__31000510__1, t.F_ctx_SINGLEQUOTE_); var tmp2 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_A_fn_class = fncls__157d; tmp2 = fncls__157d } else { tmp2 = fncls__157 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1390:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1390:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_A) Ctor_O_O_O(c__iter__31000509, c__s__31000510, c__ctx_SINGLEQUOTE_ any) { t.F_iter__31000509 = c__iter__31000509; t.F_s__31000510 = c__s__31000510; t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_ }
//line :1390:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_A) Invoke_O__O(self any) any { { var s__31000510__1 any; var t_ any = t.F_s__31000510; t.F_s__31000510 = nil; s__31000510__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000510__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000510__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000510__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000510__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000512__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_A_New_O_O_I_O(b__31000512__6, t.F_ctx_SINGLEQUOTE_, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__154 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_A_fn_class; if fncls__154 == nil { var fncls__154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_162, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_A_fn_class = fncls__154d; tmp2 = fncls__154d } else { tmp2 = fncls__154 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000509); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000512__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000510__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000512__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000510__3); var mn__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(m__4); var als__6 any = A_arbace_c2j_emit_A_const_714.Invoke_O__O(mn__5); var ptypes__7 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000521_A_New(); var tmp6 *jrt.Class
															var fncls__155 /*line :1390:1*/*jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000521_A_fn_class


	if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000521_A_fn_class = fncls__155d; tmp6 = fncls__155d } else { tmp6 = fncls__155 }; ptypes__7 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), als__6)
//line :1390:1
	var ps__8 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_emit_A_const_804; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000523_A_New(); var tmp12 *jrt.Class
	var fncls__156 /*line :1390:1*/*jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000523_A_fn_class



	if fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_164, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000523_A_fn_class = fncls__156d; tmp12 = fncls__156d } else { tmp12 = fncls__156 }; ps__8 = tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(tmp9, tmp10.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), als__6, ptypes__7)))
//line :1390:1
	var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp14 any = A_arbace_c2j_emit_A_const_805; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__31000509); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(tmp13.Invoke_O_O_O_O__O(tmp14, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_36.Invoke_O__O(mn__5)), A_arbace_c2j_emit_A_const_807), lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(ps__8, A_arbace_c2j_emit_A_const_710.Invoke_O__O(mn__5)), lang.IFn_Cast(A_arbace_c2j_emit_A_const_737.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx_SINGLEQUOTE_, mn__5, ps__8)), tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000510__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1390:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1390:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_A) Ctor_O_O_I_O(c__b__31000512, c__ctx_SINGLEQUOTE_ any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__31000512 = c__b__31000512; t.F_ctx_SINGLEQUOTE_ = c__ctx_SINGLEQUOTE_; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1390:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_A) Invoke_O__O(self any) any { { var i__31000511__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000511__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000511__1)); var mn__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(m__2); var als__4 any = A_arbace_c2j_emit_A_const_714.Invoke_O__O(mn__3); var ptypes__5 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000516_A_New(); var tmp4 *jrt.Class
																var fncls__152 /*line :1390:1*/*jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000516_A_fn_class


	if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_165, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000516_A_fn_class = fncls__152d; tmp4 = fncls__152d } else { tmp4 = fncls__152 }; ptypes__5 = tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), als__4)
//line :1390:1
	var ps__6 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp7 any = A_arbace_c2j_emit_A_const_804; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000518_A_New(); var tmp10 *jrt.Class
	var fncls__153 /*line :1390:1*/*jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000518_A_fn_class



	if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_166, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000518_A_fn_class = fncls__153d; tmp10 = fncls__153d } else { tmp10 = fncls__153 }; ps__6 = tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), als__4, ptypes__5)))
//line :1390:1
	var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp12 any = t.F_b__31000512; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp14 any = A_arbace_c2j_emit_A_const_805; tmp11.Invoke_O_O__O(tmp12, tmp13.Invoke_O_O_O_O__O(tmp14, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_36.Invoke_O__O(mn__3)), A_arbace_c2j_emit_A_const_806), lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(ps__6, A_arbace_c2j_emit_A_const_710.Invoke_O__O(mn__3)), lang.IFn_Cast(A_arbace_c2j_emit_A_const_737.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx_SINGLEQUOTE_, mn__3, ps__6))); i__31000511__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000511__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000516_A_New() *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000516_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000516_A{}; t.Ctor(); return t }
//line :1393:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000516_A) Ctor() {}
//line :1393:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000516_A) Invoke_O_O__O(self, p1__31000464_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_emit_A_const_472; var tmp2 *lang.Keyword = A_arbace_c2j_emit_A_const_488; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(p1__31000464_SHARP___1)))) }
//line :1393:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000521_A_New() *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000521_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000521_A{}; t.Ctor(); return t }
//line :1393:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000521_A) Ctor() {}
//line :1393:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000521_A) Invoke_O_O__O(self, p1__31000464_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_emit_A_const_472; var tmp2 *lang.Keyword = A_arbace_c2j_emit_A_const_488; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(p1__31000464_SHARP___1)))) }
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000518_A_New() *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000518_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000518_A{}; t.Ctor(); return t }
//line :1394:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000518_A) Ctor() {}
//line :1394:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000518_A) Invoke_O_O_O__O(self, lb__1, c__2 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__1)), c__2) }
//line :1394:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000523_A_New() *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000523_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000523_A{}; t.Ctor(); return t }
//line :1394:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000523_A) Ctor() {}
//line :1394:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000523_A) Invoke_O_O_O__O(self, lb__1, c__2 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_274.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__1)), c__2) }













func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_A_New() *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_A{}; t.Ctor(); return t }
//line :1408:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_A) Ctor() {}
//line :1408:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_A) Invoke_O_O__O(self, s__31000528__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_A_New_O_O(self, s__31000528__1); var tmp2 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_167, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_A_fn_class = fncls__167d; tmp2 = fncls__167d } else { tmp2 = fncls__167 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1408:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1408:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_A) Ctor_O_O(c__iter__31000527, c__s__31000528 any) { t.F_iter__31000527 = c__iter__31000527; t.F_s__31000528 = c__s__31000528 }
//line :1408:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_A) Invoke_O__O(self any) any { { var s__31000528__1 any; var t_ any = t.F_s__31000528; t.F_s__31000528 = nil; s__31000528__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000528__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000528__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000528__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000528__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000530__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_fn__31000533_A_New_I_O_O(size__1927001038__auto____5, b__31000530__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__166 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_fn__31000533_A_fn_class; if fncls__166 == nil { var fncls__166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_168, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_fn__31000533_A_fn_class = fncls__166d; tmp2 = fncls__166d } else { tmp2 = fncls__166 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000527); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000530__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000528__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000530__6), nil) } } else { var lb__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000528__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__31000527); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_231.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__4)), A_arbace_c2j_emit_A_const_843), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000528__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1408:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_fn__31000533_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_fn__31000533_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_fn__31000533_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :1408:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_fn__31000533_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__31000530, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__31000530 = c__b__31000530; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1408:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_fn__31000533_A) Invoke_O__O(self any) any { { var i__31000529__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000529__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var lb__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000529__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000530; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_231.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lb__2)), A_arbace_c2j_emit_A_const_843)); i__31000529__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000529__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_A_New() *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_A{}; t.Ctor(); return t }
//line :1410:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_A) Ctor() {}
//line :1410:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_A) Invoke_O_O__O(self, s__31000538__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_A_New_O_O(s__31000538__1, self); var tmp2 *jrt.Class; var fncls__170 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_A_fn_class; if fncls__170 == nil { var fncls__170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_169, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_A_fn_class = fncls__170d; tmp2 = fncls__170d } else { tmp2 = fncls__170 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1410:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1410:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_A) Ctor_O_O(c__s__31000538, c__iter__31000537 any) { t.F_s__31000538 = c__s__31000538; t.F_iter__31000537 = c__iter__31000537 }
//line :1410:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_A) Invoke_O__O(self any) any { { var s__31000538__1 any; var t_ any = t.F_s__31000538; t.F_s__31000538 = nil; s__31000538__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000538__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000538__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000538__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000538__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000540__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_fn__31000543_A_New_O_I_O(b__31000540__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_fn__31000543_A_fn_class; if fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_170, false); A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_fn__31000543_A_fn_class = fncls__169d; tmp2 = fncls__169d } else { tmp2 = fncls__169 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000537); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000540__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000538__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000540__6), nil) } } else { var m__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000538__3); var mn__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(m__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp7 *jrt.String
															if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_798.Invoke_O__O(mn__5)) { tmp7 = Lit_171 } else { tmp7 = Lit_172 }
//line :1410:1
	var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__31000537); return tmp4.Invoke_O_O__O(tmp5.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_c2j_emit_A_const_712.Invoke_O__O(mn__5))).Ref())).Ref()), tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000538__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1410:1
func A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_fn__31000543_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_fn__31000543_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_fn__31000543_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1410:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_fn__31000543_A) Ctor_O_I_O(c__b__31000540 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__31000540 = c__b__31000540; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1410:1
func (t *A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_fn__31000543_A) Invoke_O__O(self any) any { { var i__31000539__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000539__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000539__1)); var mn__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(m__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000540; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp6 *jrt.String
																if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_798.Invoke_O__O(mn__3)) { tmp6 = Lit_171 } else { tmp6 = Lit_172 }
//line :1410:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6.Ref(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_c2j_emit_A_const_712.Invoke_O__O(mn__3))).Ref())).Ref())); i__31000539__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000539__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


















func A_arbace_c2j_emit_unit_method_A_New() *A_arbace_c2j_emit_unit_method_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_A{}; t.Ctor(); return t }
//line :1429:1
func (t *A_arbace_c2j_emit_unit_method_A) Ctor() {}
//line :1429:1
func (t *A_arbace_c2j_emit_unit_method_A) Invoke_O_O_O_O__O(self, ctx__0, k__1, p__31000550__2 any) any { var vec__31000551__4 any = p__31000550__2; var kind__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000551__4, lang.RT_IntCast_J__I_NoInit(0), nil); var line__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000551__4, lang.RT_IntCast_J__I_NoInit(1), nil); var column__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000551__4, lang.RT_IntCast_J__I_NoInit(2), nil); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000551__4, lang.RT_IntCast_J__I_NoInit(3), nil); var ___9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000551__4, lang.RT_IntCast_J__I_NoInit(4), nil); var expr__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000551__4, lang.RT_IntCast_J__I_NoInit(5), nil); var events__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000551__4, lang.RT_IntCast_J__I_NoInit(6), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_32; var ctx__12 any = tmp1.Invoke_O_O_O__O(ctx__0, tmp2, lang.IFn_Cast(A_arbace_c2j_emit_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.PersistentHashSet_EMPTY.Ref())); var ns_events__13 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_441.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_A_const_29.GetRawRoot__O(); var tmp5 any; var iter__1927001039__auto____13 any; var tmp6 any = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_A_New_O(ctx__12); var tmp7 *jrt.Class; var fncls__195 *jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_A_fn_class; _ = ___8; _ = ___9; if




	fncls__195 == nil { var fncls__195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_336, false); A_arbace_c2j_emit_unit_method_iter__31000554__31000558_A_fn_class = fncls__195d; tmp7 = fncls__195d } else { tmp7 = fncls__195 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); tmp5 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(events__11); ns_events__13 = tmp3.Invoke_O_O__O(tmp4, tmp5); var n__14 any = /*line :1429:1*/lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(expr__10); var code__15 any; if





























	lang.Util_Equiv_O_J__Z_NoInit(kind__5, 1) { var m__15 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_785.Invoke_O__O(n__14))); var ctx_SINGLEQUOTE___16 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(ctx__12, A_arbace_c2j_emit_A_const_743, n__14, A_arbace_c2j_emit_A_const_269, jrt.Boolean_FALSE.Ref(), A_arbace_c2j_emit_A_const_230, nil)



		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_535.Invoke_O__O(n__14))) { lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(Lit_337) }
		code__15 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx_SINGLEQUOTE___16, A_arbace_c2j_emit_A_const_520.Invoke_O__O(m__15)) } else {
			if lang.Util_Equiv_O_O__Z_NoInit(Lit_63, A_arbace_c2j_emit_A_const_501.Invoke_O__O(n__14)) {
				code__15 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_618.GetRawRoot__O()).Invoke_O_O_O__O(ctx__12, n__14, jrt.Boolean_TRUE.Ref()) } else {
					code__15 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_250.GetRawRoot__O()).Invoke_O_O__O(ctx__12, expr__10) } }; var ns_events__16 any = /*line :1429:1*/lang.IFn_Cast(A_arbace_c2j_emit_A_const_847.GetRawRoot__O()).Invoke_O__O(ns_events__13); var code__17 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_696.GetRawRoot__O()).Invoke_O__O(code__15); var proxies__18 any; var iter__1927001039__auto____18 any; var tmp8 any = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_A_New_O(ctx__12); var tmp9 *jrt.Class; var fncls__180 *jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_A_fn_class; if













































	fncls__180 == nil { var fncls__180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_338, false); A_arbace_c2j_emit_unit_method_iter__31000586__31000590_A_fn_class = fncls__180d; tmp9 = fncls__180d } else { tmp9 = fncls__180 }; iter__1927001039__auto____18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp10 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____18); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_883.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_unit_method_fn__31000616_A_New(); var tmp13 *jrt.Class; var fncls__196 *jrt.Class = A_arbace_c2j_emit_unit_method_fn__31000616_A_fn_class; if fncls__196 == nil { var fncls__196d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_339, false); A_arbace_c2j_emit_unit_method_fn__31000616_A_fn_class = fncls__196d; tmp13 = fncls__196d } else { tmp13 = fncls__196 }; proxies__18 = tmp10.Invoke_O__O(tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_32.Invoke_O__O(ctx__12)))); var tmp14 lang.IFn =










	lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_emit_A_const_884; var tmp16 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_205, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__1)).Ref()), A_arbace_c2j_emit_A_const_885); var tmp17 any = lang.PersistentVector_EMPTY.Ref(); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp19 any = A_arbace_c2j_emit_A_const_886; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp21 any = A_arbace_c2j_emit_A_const_887; return lang.IFn_Cast(A_arbace_c2j_emit_A_const_22.GetRawRoot__O()).Invoke_O_O_O_O__O(tmp14.Invoke_O_O_O_O__O(tmp15, tmp16, tmp17, lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()).Invoke_O_O_O_O__O(tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O_O_O__O(tmp21, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_888, line__6), lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_889, column__7))), ns_events__16, lang.IFn_Cast(A_arbace_c2j_emit_A_const_847.GetRawRoot__O()).Invoke_O__O(proxies__18), lang.Tuple_Create_O__IPersistentVector(code__17))), A_arbace_c2j_emit_A_const_13.GetRawRoot__O(), A_arbace_c2j_emit_A_const_265, line__6) }
//line :1434:1
func A_arbace_c2j_emit_unit_method_iter__31000554__31000558_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000554__31000558_A{}; t.Ctor_O(p0); return t }
//line :1434:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1434:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_A) Invoke_O_O__O(self, s__31000555__1 any) any { var tmp1 any = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_A_New_O_O_O(s__31000555__1, self, t.F_ctx); var tmp2 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_A_fn_class; if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_340, false); A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_A_fn_class = fncls__194d; tmp2 = fncls__194d } else { tmp2 = fncls__194 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1434:1
func A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1434:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_A) Ctor_O_O_O(c__s__31000555, c__iter__31000554, c__ctx any) { t.F_s__31000555 = c__s__31000555; t.F_iter__31000554 = c__iter__31000554; t.F_ctx = c__ctx }
//line :1434:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_A) Invoke_O__O(self any) any { { var s__31000555__1 any; var t_ any = t.F_s__31000555; t.F_s__31000555 = nil; s__31000555__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000555__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000555__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000555__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000555__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000557__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_A_New_O_O_I_O(b__31000557__6, t.F_ctx, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__187 *jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_A_fn_class; if fncls__187 == nil { var fncls__187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_341, false); A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_A_fn_class = fncls__187d; tmp2 = fncls__187d } else { tmp2 = fncls__187 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000554); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000557__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000555__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000557__6), nil) } } else { var ev__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000555__3); var ev__5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(ev__4); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp5 any; var G__31000573__6_ any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(ev__5)

L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__31000573__6_) >> 5 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__31000573__6_, Lit_342) { var temp__1927000408__auto____7 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ev__5, lang.RT_IntCast_J__I_NoInit(1)))




	if jrt.J2g_Truth(and__1927000168__auto____7) { temp__1927000408__auto____7 = lang.RT_Nth_O_I__O_NoInit(ev__5, lang.RT_IntCast_J__I_NoInit(1)) } else { temp__1927000408__auto____7 = and__1927000168__auto____7 }; if jrt.J2g_Truth(temp__1927000408__auto____7) { var n__8 any = temp__1927000408__auto____7; var temp__1927000408__auto____9 any; var tmp6 any = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000574_A_New_O(n__8); var tmp7 *jrt.Class
		var fncls__189 /*line :1441:1*/*jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000574_A_fn_class


		if fncls__189 == nil { var fncls__189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_343, false); A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000574_A_fn_class = fncls__189d; tmp7 = fncls__189d } else { tmp7 = fncls__189 }; temp__1927000408__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O(); if jrt.J2g_Truth(temp__1927000408__auto____9) { var c__10 any = temp__1927000408__auto____9
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(c__10, t.F_ctx)) {
				tmp5 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_344, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__8)).Ref()) } else {
//line :1445:1
					tmp5 = nil } } else {
//line :1444:1
						tmp5 = nil } } else {
//line :1441:1
							tmp5 = nil }
//line :1436:1
	break L2 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__31000573__6_, Lit_345) { var temp__1927000408__auto____7_2 any; var and__1927000168__auto____7_2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ev__5, lang.RT_IntCast_J__I_NoInit(1)))




		if jrt.J2g_Truth(and__1927000168__auto____7_2) { temp__1927000408__auto____7_2 = lang.RT_Nth_O_I__O_NoInit(ev__5, lang.RT_IntCast_J__I_NoInit(1)) } else { temp__1927000408__auto____7_2 = and__1927000168__auto____7_2 }; if jrt.J2g_Truth(temp__1927000408__auto____7_2) { var n__8_2 any = temp__1927000408__auto____7_2; var temp__1927000408__auto____9_2 any; var tmp8 any = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000576_A_New_O(n__8_2); var tmp9 *jrt.Class
			var fncls__190 /*line :1441:1*/*jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000576_A_fn_class


			if fncls__190 == nil { var fncls__190d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_346, false); A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000576_A_fn_class = fncls__190d; tmp9 = fncls__190d } else { tmp9 = fncls__190 }; temp__1927000408__auto____9_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O(); if jrt.J2g_Truth(temp__1927000408__auto____9_2) { var c__10_2 any = temp__1927000408__auto____9_2
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(c__10_2, t.F_ctx)) {
					tmp5 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_344, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__8_2)).Ref()) } else {
//line :1445:1
						tmp5 = nil } } else {
//line :1444:1
							tmp5 = nil } } else {
//line :1441:1
								tmp5 = nil }
//line :1436:1
		break L2 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__31000573__6_, Lit_347) {














			var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_emit_A_const_864; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_emit_A_const_865; var tmp14 any = A_arbace_c2j_emit_A_const_866; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_emit_A_const_867; var tmp17 any = tmp12.Invoke_O_O_O__O(tmp13, tmp14, tmp15.Invoke_O_O__O(tmp16, lang.IFn_Cast(A_arbace_c2j_emit_A_const_221.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx, A_arbace_c2j_emit_A_const_868, A_arbace_c2j_emit_A_const_869))); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp19 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_870, A_arbace_c2j_emit_A_const_881); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()); var tmp21 any = t.F_ctx; var tmp22 any = tmp20.Invoke_O_O__O(tmp21, lang.RT_Nth_O_I__O_NoInit(ev__5, lang.RT_IntCast_J__I_NoInit(2))); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp24 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_872, A_arbace_c2j_emit_A_const_882); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp26 any = A_arbace_c2j_emit_A_const_874; var tmp27 any = A_arbace_c2j_emit_A_const_875; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()); var tmp29 any = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000578_A_New_O(t.F_ctx); var tmp30 *jrt.Class
			var fncls__192 /*line :1451:1*/*jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000578_A_fn_class




			if fncls__192 == nil { var fncls__192d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_348, false); A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000578_A_fn_class = fncls__192d; tmp30 = fncls__192d } else { tmp30 = fncls__192 }
//line :1451:1
			tmp5 = tmp10.Invoke_O_O_O__O(tmp11, tmp17, tmp18.Invoke_O_O_O__O(tmp19, tmp22, tmp23.Invoke_O_O__O(tmp24, tmp25.Invoke_O_O_O__O(tmp26, tmp27, tmp28.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil), lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ev__5, lang.RT_IntCast_J__I_NoInit(3))))))))
//line :1436:1
			break L2 }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__31000573__6_, Lit_349) { var temp__1927000408__auto____7_3 any; var and__1927000168__auto____7_3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ev__5, lang.RT_IntCast_J__I_NoInit(1)))




				if jrt.J2g_Truth(and__1927000168__auto____7_3) { temp__1927000408__auto____7_3 = lang.RT_Nth_O_I__O_NoInit(ev__5, lang.RT_IntCast_J__I_NoInit(1)) } else { temp__1927000408__auto____7_3 = and__1927000168__auto____7_3 }; if jrt.J2g_Truth(temp__1927000408__auto____7_3) { var n__8_3 any = temp__1927000408__auto____7_3; var temp__1927000408__auto____9_3 any; var tmp31 any = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000580_A_New_O(n__8_3); var tmp32 *jrt.Class
					var fncls__191 /*line :1441:1*/*jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000580_A_fn_class


					if fncls__191 == nil { var fncls__191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_350, false); A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000580_A_fn_class = fncls__191d; tmp32 = fncls__191d } else { tmp32 = fncls__191 }; temp__1927000408__auto____9_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil).Invoke__O(); if jrt.J2g_Truth(temp__1927000408__auto____9_3) { var c__10_3 any = temp__1927000408__auto____9_3
						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(c__10_3, t.F_ctx)) {
							tmp5 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_344, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__8_3)).Ref()) } else {
//line :1445:1
								tmp5 = nil } } else {
//line :1444:1
									tmp5 = nil } } else {
//line :1441:1
										tmp5 = nil }
//line :1436:1
				break L2 }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__31000573__6_, Lit_351) { var temp__1927000408__auto____7_4 any; var and__1927000168__auto____7_4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ev__5, lang.RT_IntCast_J__I_NoInit(1)))




					if jrt.J2g_Truth(and__1927000168__auto____7_4) { temp__1927000408__auto____7_4 = lang.RT_Nth_O_I__O_NoInit(ev__5, lang.RT_IntCast_J__I_NoInit(1)) } else { temp__1927000408__auto____7_4 = and__1927000168__auto____7_4 }; if jrt.J2g_Truth(temp__1927000408__auto____7_4) { var n__8_4 any = temp__1927000408__auto____7_4; var temp__1927000408__auto____9_4 any; var tmp33 any = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000582_A_New_O(n__8_4); var tmp34 *jrt.Class
						var fncls__193 /*line :1441:1*/*jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000582_A_fn_class


						if fncls__193 == nil { var fncls__193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_352, false); A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000582_A_fn_class = fncls__193d; tmp34 = fncls__193d } else { tmp34 = fncls__193 }; temp__1927000408__auto____9_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil).Invoke__O(); if jrt.J2g_Truth(temp__1927000408__auto____9_4) { var c__10_4 any = temp__1927000408__auto____9_4
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(c__10_4, t.F_ctx)) {
								tmp5 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_344, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__8_4)).Ref()) } else {
//line :1445:1
									tmp5 = nil } } else {
//line :1444:1
										tmp5 = nil } } else {
//line :1441:1
											tmp5 = nil }
//line :1436:1
					break L2 }; case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__31000573__6_, Lit_353) {
						var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp36 any = A_arbace_c2j_emit_A_const_876; var tmp37 any = A_arbace_c2j_emit_A_const_877; var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp39 any = A_arbace_c2j_emit_A_const_878; var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp41 any = A_arbace_c2j_emit_A_const_879; var tmp42 any = A_arbace_c2j_emit_A_const_880; var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()); var tmp44 any = t.F_ctx; tmp5 = tmp35.Invoke_O_O_O__O(tmp36, tmp37, tmp38.Invoke_O_O__O(tmp39, tmp40.Invoke_O_O_O__O(tmp41, tmp42, tmp43.Invoke_O_O__O(tmp44, lang.RT_Nth_O_I__O_NoInit(ev__5, lang.RT_IntCast_J__I_NoInit(2))))))
//line :1436:1
						break L2 }; default:
}



















	tmp5 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_354, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(ev__5))).Ref())}
//line :1434:1
	var tmp45 lang.IFn = lang.IFn_Cast(t.F_iter__31000554); return tmp4.Invoke_O_O__O(tmp5, tmp45.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000555__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1434:1
func A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1434:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_A) Ctor_O_O_I_O(c__b__31000557, c__ctx any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__31000557 = c__b__31000557; t.F_ctx = c__ctx; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1434:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_A) Invoke_O__O(self any) any { { var i__31000556__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000556__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ev__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000556__1)); var ev__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(ev__2); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000557; var tmp4 any; var G__31000561__4_ any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(ev__3)

L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__31000561__4_) >> 5 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__31000561__4_, Lit_342) { var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ev__3, lang.RT_IntCast_J__I_NoInit(1)))




	if jrt.J2g_Truth(and__1927000168__auto____5) { temp__1927000408__auto____5 = lang.RT_Nth_O_I__O_NoInit(ev__3, lang.RT_IntCast_J__I_NoInit(1)) } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var n__6 any = temp__1927000408__auto____5; var temp__1927000408__auto____7 any; var tmp5 any = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000562_A_New_O(n__6); var tmp6 *jrt.Class
		var fncls__182 /*line :1441:1*/*jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000562_A_fn_class


		if fncls__182 == nil { var fncls__182d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_355, false); A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000562_A_fn_class = fncls__182d; tmp6 = fncls__182d } else { tmp6 = fncls__182 }; temp__1927000408__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O(); if jrt.J2g_Truth(temp__1927000408__auto____7) { var c__8 any = temp__1927000408__auto____7
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(c__8, t.F_ctx)) {
				tmp4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_344, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__6)).Ref()) } else {
//line :1445:1
					tmp4 = nil } } else {
//line :1444:1
						tmp4 = nil } } else {
//line :1441:1
							tmp4 = nil }
//line :1436:1
	break L2 }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__31000561__4_, Lit_345) { var temp__1927000408__auto____5_2 any; var and__1927000168__auto____5_2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ev__3, lang.RT_IntCast_J__I_NoInit(1)))




		if jrt.J2g_Truth(and__1927000168__auto____5_2) { temp__1927000408__auto____5_2 = lang.RT_Nth_O_I__O_NoInit(ev__3, lang.RT_IntCast_J__I_NoInit(1)) } else { temp__1927000408__auto____5_2 = and__1927000168__auto____5_2 }; if jrt.J2g_Truth(temp__1927000408__auto____5_2) { var n__6_2 any = temp__1927000408__auto____5_2; var temp__1927000408__auto____7_2 any; var tmp7 any = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000564_A_New_O(n__6_2); var tmp8 *jrt.Class
			var fncls__183 /*line :1441:1*/*jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000564_A_fn_class


			if fncls__183 == nil { var fncls__183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_356, false); A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000564_A_fn_class = fncls__183d; tmp8 = fncls__183d } else { tmp8 = fncls__183 }; temp__1927000408__auto____7_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O(); if jrt.J2g_Truth(temp__1927000408__auto____7_2) { var c__8_2 any = temp__1927000408__auto____7_2
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(c__8_2, t.F_ctx)) {
					tmp4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_344, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__6_2)).Ref()) } else {
//line :1445:1
						tmp4 = nil } } else {
//line :1444:1
							tmp4 = nil } } else {
//line :1441:1
								tmp4 = nil }
//line :1436:1
		break L2 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__31000561__4_, Lit_347) {














			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_emit_A_const_864; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_A_const_865; var tmp13 any = A_arbace_c2j_emit_A_const_866; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_emit_A_const_867; var tmp16 any = tmp11.Invoke_O_O_O__O(tmp12, tmp13, tmp14.Invoke_O_O__O(tmp15, lang.IFn_Cast(A_arbace_c2j_emit_A_const_221.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx, A_arbace_c2j_emit_A_const_868, A_arbace_c2j_emit_A_const_869))); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp18 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_870, A_arbace_c2j_emit_A_const_871); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()); var tmp20 any = t.F_ctx; var tmp21 any = tmp19.Invoke_O_O__O(tmp20, lang.RT_Nth_O_I__O_NoInit(ev__3, lang.RT_IntCast_J__I_NoInit(2))); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp23 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_872, A_arbace_c2j_emit_A_const_873); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp25 any = A_arbace_c2j_emit_A_const_874; var tmp26 any = A_arbace_c2j_emit_A_const_875; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()); var tmp28 any = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000566_A_New_O(t.F_ctx); var tmp29 *jrt.Class
			var fncls__185 /*line :1451:1*/*jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000566_A_fn_class




			if fncls__185 == nil { var fncls__185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_357, false); A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000566_A_fn_class = fncls__185d; tmp29 = fncls__185d } else { tmp29 = fncls__185 }
//line :1451:1
			tmp4 = tmp9.Invoke_O_O_O__O(tmp10, tmp16, tmp17.Invoke_O_O_O__O(tmp18, tmp21, tmp22.Invoke_O_O__O(tmp23, tmp24.Invoke_O_O_O__O(tmp25, tmp26, tmp27.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil), lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ev__3, lang.RT_IntCast_J__I_NoInit(3))))))))
//line :1436:1
			break L2 }; case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__31000561__4_, Lit_349) { var temp__1927000408__auto____5_3 any; var and__1927000168__auto____5_3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ev__3, lang.RT_IntCast_J__I_NoInit(1)))




				if jrt.J2g_Truth(and__1927000168__auto____5_3) { temp__1927000408__auto____5_3 = lang.RT_Nth_O_I__O_NoInit(ev__3, lang.RT_IntCast_J__I_NoInit(1)) } else { temp__1927000408__auto____5_3 = and__1927000168__auto____5_3 }; if jrt.J2g_Truth(temp__1927000408__auto____5_3) { var n__6_3 any = temp__1927000408__auto____5_3; var temp__1927000408__auto____7_3 any; var tmp30 any = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000568_A_New_O(n__6_3); var tmp31 *jrt.Class
					var fncls__184 /*line :1441:1*/*jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000568_A_fn_class


					if fncls__184 == nil { var fncls__184d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_358, false); A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000568_A_fn_class = fncls__184d; tmp31 = fncls__184d } else { tmp31 = fncls__184 }; temp__1927000408__auto____7_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil).Invoke__O(); if jrt.J2g_Truth(temp__1927000408__auto____7_3) { var c__8_3 any = temp__1927000408__auto____7_3
						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(c__8_3, t.F_ctx)) {
							tmp4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_344, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__6_3)).Ref()) } else {
//line :1445:1
								tmp4 = nil } } else {
//line :1444:1
									tmp4 = nil } } else {
//line :1441:1
										tmp4 = nil }
//line :1436:1
				break L2 }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__31000561__4_, Lit_351) { var temp__1927000408__auto____5_4 any; var and__1927000168__auto____5_4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(ev__3, lang.RT_IntCast_J__I_NoInit(1)))




					if jrt.J2g_Truth(and__1927000168__auto____5_4) { temp__1927000408__auto____5_4 = lang.RT_Nth_O_I__O_NoInit(ev__3, lang.RT_IntCast_J__I_NoInit(1)) } else { temp__1927000408__auto____5_4 = and__1927000168__auto____5_4 }; if jrt.J2g_Truth(temp__1927000408__auto____5_4) { var n__6_4 any = temp__1927000408__auto____5_4; var temp__1927000408__auto____7_4 any; var tmp32 any = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000570_A_New_O(n__6_4); var tmp33 *jrt.Class
						var fncls__186 /*line :1441:1*/*jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000570_A_fn_class


						if fncls__186 == nil { var fncls__186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_359, false); A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000570_A_fn_class = fncls__186d; tmp33 = fncls__186d } else { tmp33 = fncls__186 }; temp__1927000408__auto____7_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil).Invoke__O(); if jrt.J2g_Truth(temp__1927000408__auto____7_4) { var c__8_4 any = temp__1927000408__auto____7_4
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_220.GetRawRoot__O()).Invoke_O_O__O(c__8_4, t.F_ctx)) {
								tmp4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_344, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__6_4)).Ref()) } else {
//line :1445:1
									tmp4 = nil } } else {
//line :1444:1
										tmp4 = nil } } else {
//line :1441:1
											tmp4 = nil }
//line :1436:1
					break L2 }; case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__31000561__4_, Lit_353) {
						var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp35 any = A_arbace_c2j_emit_A_const_876; var tmp36 any = A_arbace_c2j_emit_A_const_877; var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp38 any = A_arbace_c2j_emit_A_const_878; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp40 any = A_arbace_c2j_emit_A_const_879; var tmp41 any = A_arbace_c2j_emit_A_const_880; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()); var tmp43 any = t.F_ctx; tmp4 = tmp34.Invoke_O_O_O__O(tmp35, tmp36, tmp37.Invoke_O_O__O(tmp38, tmp39.Invoke_O_O_O__O(tmp40, tmp41, tmp42.Invoke_O_O__O(tmp43, lang.RT_Nth_O_I__O_NoInit(ev__3, lang.RT_IntCast_J__I_NoInit(2))))))
//line :1436:1
						break L2 }; default:
}



















	tmp4 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_354, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(ev__3))).Ref())}
//line :1434:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__31000556__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000556__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000562_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000562_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000562_A{}; t.Ctor_O(p0); return t }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000562_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000562_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = jrt.Class_ForName_String__Class(jrt.String_Cast(tmp2.Invoke_O__O(tmp3))).Ref() }; return nil }(); if tmp4 != nil { if jrt.Exception_InstanceOf(tmp4) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp4); _ = ___3; tmp1 = nil } else { panic(tmp4) } }; return tmp1 }
//line :1444:1
func A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000564_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000564_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000564_A{}; t.Ctor_O(p0); return t }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000564_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000564_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = jrt.Class_ForName_String__Class(jrt.String_Cast(tmp2.Invoke_O__O(tmp3))).Ref() }; return nil }(); if tmp4 != nil { if jrt.Exception_InstanceOf(tmp4) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp4); _ = ___3; tmp1 = nil } else { panic(tmp4) } }; return tmp1 }
//line :1444:1
func A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000568_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000568_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000568_A{}; t.Ctor_O(p0); return t }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000568_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000568_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = jrt.Class_ForName_String__Class(jrt.String_Cast(tmp2.Invoke_O__O(tmp3))).Ref() }; return nil }(); if tmp4 != nil { if jrt.Exception_InstanceOf(tmp4) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp4); _ = ___3; tmp1 = nil } else { panic(tmp4) } }; return tmp1 }
//line :1444:1
func A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000570_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000570_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000570_A{}; t.Ctor_O(p0); return t }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000570_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000570_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = jrt.Class_ForName_String__Class(jrt.String_Cast(tmp2.Invoke_O__O(tmp3))).Ref() }; return nil }(); if tmp4 != nil { if jrt.Exception_InstanceOf(tmp4) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp4); _ = ___3; tmp1 = nil } else { panic(tmp4) } }; return tmp1 }
//line :1444:1
func A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000574_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000574_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000574_A{}; t.Ctor_O(p0); return t }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000574_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000574_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = jrt.Class_ForName_String__Class(jrt.String_Cast(tmp2.Invoke_O__O(tmp3))).Ref() }; return nil }(); if tmp4 != nil { if jrt.Exception_InstanceOf(tmp4) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp4); _ = ___3; tmp1 = nil } else { panic(tmp4) } }; return tmp1 }
//line :1444:1
func A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000576_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000576_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000576_A{}; t.Ctor_O(p0); return t }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000576_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000576_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = jrt.Class_ForName_String__Class(jrt.String_Cast(tmp2.Invoke_O__O(tmp3))).Ref() }; return nil }(); if tmp4 != nil { if jrt.Exception_InstanceOf(tmp4) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp4); _ = ___3; tmp1 = nil } else { panic(tmp4) } }; return tmp1 }
//line :1444:1
func A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000580_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000580_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000580_A{}; t.Ctor_O(p0); return t }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000580_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000580_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = jrt.Class_ForName_String__Class(jrt.String_Cast(tmp2.Invoke_O__O(tmp3))).Ref() }; return nil }(); if tmp4 != nil { if jrt.Exception_InstanceOf(tmp4) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp4); _ = ___3; tmp1 = nil } else { panic(tmp4) } }; return tmp1 }
//line :1444:1
func A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000582_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000582_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000582_A{}; t.Ctor_O(p0); return t }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000582_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :1444:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000582_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_n; t.F_n = nil; tmp3 = t_; tmp1 = jrt.Class_ForName_String__Class(jrt.String_Cast(tmp2.Invoke_O__O(tmp3))).Ref() }; return nil }(); if tmp4 != nil { if jrt.Exception_InstanceOf(tmp4) { var ___3 jrt.Exception_I = jrt.Exception_Cast(tmp4); _ = ___3; tmp1 = nil } else { panic(tmp4) } }; return tmp1 }











func A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000566_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000566_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000566_A{}; t.Ctor_O(p0); return t }
//line :1456:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000566_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1456:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000566_A) Invoke_O_O__O(self, p1__31000548_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__31000548_SHARP___1) }
//line :1456:1
func A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000578_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000578_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000578_A{}; t.Ctor_O(p0); return t }
//line :1456:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000578_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1456:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000578_A) Invoke_O_O__O(self, p1__31000548_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, p1__31000548_SHARP___1) }


















func A_arbace_c2j_emit_unit_method_fn__31000616_A_New() *A_arbace_c2j_emit_unit_method_fn__31000616_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_fn__31000616_A{}; t.Ctor(); return t }
//line :1475:1
func (t *A_arbace_c2j_emit_unit_method_fn__31000616_A) Ctor() {}
//line :1475:1
func (t *A_arbace_c2j_emit_unit_method_fn__31000616_A) Invoke_O_O__O(self, p1__31000549_SHARP___1 any) any { return jrt.NN(jrt.Class_Cast(p1__31000549_SHARP___1)).GetName__String().Ref() }
//line :1475:1
func A_arbace_c2j_emit_unit_method_iter__31000586__31000590_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000586__31000590_A{}; t.Ctor_O(p0); return t }
//line :1475:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1475:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_A) Invoke_O_O__O(self, s__31000587__1 any) any { var tmp1 any = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_A_New_O_O_O(s__31000587__1, self, t.F_ctx); var tmp2 *jrt.Class; var fncls__179 *jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_A_fn_class; if fncls__179 == nil { var fncls__179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_360, false); A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_A_fn_class = fncls__179d; tmp2 = fncls__179d } else { tmp2 = fncls__179 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1475:1
func A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1475:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_A) Ctor_O_O_O(c__s__31000587, c__iter__31000586, c__ctx any) { t.F_s__31000587 = c__s__31000587; t.F_iter__31000586 = c__iter__31000586; t.F_ctx = c__ctx }
//line :1475:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_A) Invoke_O__O(self any) any { { var s__31000587__1 any; var t_ any = t.F_s__31000587; t.F_s__31000587 = nil; s__31000587__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000587__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000587__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000587__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000587__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000589__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_A_New_O_O_I_O(b__31000589__6, t.F_ctx, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__175 *jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_A_fn_class; if fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_361, false); A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_A_fn_class = fncls__175d; tmp2 = fncls__175d } else { tmp2 = fncls__175 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000586); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000589__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000587__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000589__6), nil) } } else { var c__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000587__3); var pname__5 any = jrt.NN(jrt.Class_Cast(c__4)).GetName__String().Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_A_const_848; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_emit_A_const_849; var tmp9 any = tmp7.Invoke_O_O__O(tmp8, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_850, A_arbace_c2j_emit_A_const_862), pname__5)); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_emit_A_const_852; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_emit_A_const_853; var tmp14 any = A_arbace_c2j_emit_A_const_854; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_emit_A_const_855; var tmp17 any = tmp12.Invoke_O_O_O__O(tmp13, tmp14, tmp15.Invoke_O_O__O(tmp16, lang.IFn_Cast(A_arbace_c2j_emit_A_const_221.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx, A_arbace_c2j_emit_A_const_856, A_arbace_c2j_emit_A_const_857))); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()); var tmp19 any = t.F_ctx; var tmp20 any = tmp18.Invoke_O_O__O(tmp19, jrt.NN(jrt.Class_Cast(c__4)).GetSuperclass__Class().Ref()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp22 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_858, A_arbace_c2j_emit_A_const_863); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp24 any = A_arbace_c2j_emit_A_const_860; var tmp25 any = A_arbace_c2j_emit_A_const_861; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp27 any; var iter__1927001039__auto____6 any; var tmp28 any = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_A_New_O(t.F_ctx); var tmp29 *jrt.Class
														var fncls__178 /*line :1475:1*/*jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_A_fn_class








	if fncls__178 == nil { var fncls__178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_362, false); A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_A_fn_class = fncls__178d; tmp29 = fncls__178d } else { tmp29 = fncls__178 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); tmp27 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__4)).GetInterfaces__Class1().Ref())
//line :1475:1
	var tmp30 lang.IFn = lang.IFn_Cast(t.F_iter__31000586); return tmp4.Invoke_O_O__O(tmp5.Invoke_O_O_O__O(tmp6, tmp9, tmp10.Invoke_O_O_O_O_O__O(tmp11, tmp17, pname__5, tmp20, tmp21.Invoke_O_O__O(tmp22, tmp23.Invoke_O_O_O__O(tmp24, tmp25, tmp26.Invoke_O__O(tmp27))))), tmp30.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000587__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1475:1
func A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1475:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_A) Ctor_O_O_I_O(c__b__31000589, c__ctx any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__31000589 = c__b__31000589; t.F_ctx = c__ctx; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1475:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_A) Invoke_O__O(self any) any { { var i__31000588__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000588__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000588__1)); var pname__3 any = jrt.NN(jrt.Class_Cast(c__2)).GetName__String().Ref(); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000589; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_848; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp7 any = A_arbace_c2j_emit_A_const_849; var tmp8 any = tmp6.Invoke_O_O__O(tmp7, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_850, A_arbace_c2j_emit_A_const_851), pname__3)); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_emit_A_const_852; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_A_const_853; var tmp13 any = A_arbace_c2j_emit_A_const_854; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_emit_A_const_855; var tmp16 any = tmp11.Invoke_O_O_O__O(tmp12, tmp13, tmp14.Invoke_O_O__O(tmp15, lang.IFn_Cast(A_arbace_c2j_emit_A_const_221.GetRawRoot__O()).Invoke_O_O_O__O(t.F_ctx, A_arbace_c2j_emit_A_const_856, A_arbace_c2j_emit_A_const_857))); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()); var tmp18 any = t.F_ctx; var tmp19 any = tmp17.Invoke_O_O__O(tmp18, jrt.NN(jrt.Class_Cast(c__2)).GetSuperclass__Class().Ref()); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp21 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_858, A_arbace_c2j_emit_A_const_859); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp23 any = A_arbace_c2j_emit_A_const_860; var tmp24 any = A_arbace_c2j_emit_A_const_861; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp26 any; var iter__1927001039__auto____4 any; var tmp27 any = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_A_New_O(t.F_ctx); var tmp28 *jrt.Class
															var fncls__174 /*line :1475:1*/*jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_A_fn_class








	if fncls__174 == nil { var fncls__174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_363, false); A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_A_fn_class = fncls__174d; tmp28 = fncls__174d } else { tmp28 = fncls__174 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); tmp26 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(jrt.NN(jrt.Class_Cast(c__2)).GetInterfaces__Class1().Ref())
//line :1475:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp8, tmp9.Invoke_O_O_O_O_O__O(tmp10, tmp16, pname__3, tmp19, tmp20.Invoke_O_O__O(tmp21, tmp22.Invoke_O_O_O__O(tmp23, tmp24, tmp25.Invoke_O__O(tmp26)))))); i__31000588__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000588__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_A{}; t.Ctor_O(p0); return t }
//line :1484:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1484:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_A) Invoke_O_O__O(self, s__31000594__1 any) any { var tmp1 any = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_A_New_O_O_O(s__31000594__1, self, t.F_ctx); var tmp2 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_A_fn_class; if fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_364, false); A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_A_fn_class = fncls__173d; tmp2 = fncls__173d } else { tmp2 = fncls__173 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1484:1
func A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1484:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_A) Ctor_O_O_O(c__s__31000594, c__iter__31000593, c__ctx any) { t.F_s__31000594 = c__s__31000594; t.F_iter__31000593 = c__iter__31000593; t.F_ctx = c__ctx }
//line :1484:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_A) Invoke_O__O(self any) any { { var s__31000594__1 any; var t_ any = t.F_s__31000594; t.F_s__31000594 = nil; s__31000594__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000594__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000594__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000594__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000594__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000596__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_fn__31000599_A_New_O_O_I_O(t.F_ctx, b__31000596__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__172 *jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_fn__31000599_A_fn_class; if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_365, false); A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_fn__31000599_A_fn_class = fncls__172d; tmp2 = fncls__172d } else { tmp2 = fncls__172 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000593); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000596__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000594__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000596__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000594__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_49.GetRawRoot__O()).Invoke_O_O__O(i__4, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_321).Ref())) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__31000593); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, i__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000594__3))) } else { s__31000594__1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000594__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :1484:1
func A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_fn__31000599_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_fn__31000599_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_fn__31000599_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1484:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_fn__31000599_A) Ctor_O_O_I_O(c__ctx, c__b__31000596 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_ctx = c__ctx; t.F_b__31000596 = c__b__31000596; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1484:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_fn__31000599_A) Invoke_O__O(self any) any { { var i__31000595__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000595__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000595__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_49.GetRawRoot__O()).Invoke_O_O__O(i__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_321).Ref())) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000596; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, i__2)); i__31000595__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000595__1); continue L1 } else { i__31000595__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000595__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :1484:1
func A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_A_New_O(p0 any) *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_A{}; t.Ctor_O(p0); return t }
//line :1484:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :1484:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_A) Invoke_O_O__O(self, s__31000605__1 any) any { var tmp1 any = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_A_New_O_O_O(self, s__31000605__1, t.F_ctx); var tmp2 *jrt.Class; var fncls__177 *jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_A_fn_class; if fncls__177 == nil { var fncls__177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_366, false); A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_A_fn_class = fncls__177d; tmp2 = fncls__177d } else { tmp2 = fncls__177 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1484:1
func A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1484:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_A) Ctor_O_O_O(c__iter__31000604, c__s__31000605, c__ctx any) { t.F_iter__31000604 = c__iter__31000604; t.F_s__31000605 = c__s__31000605; t.F_ctx = c__ctx }
//line :1484:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_A) Invoke_O__O(self any) any { { var s__31000605__1 any; var t_ any = t.F_s__31000605; t.F_s__31000605 = nil; s__31000605__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000605__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000605__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000605__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000605__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000607__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_fn__31000610_A_New_O_O_I_O(b__31000607__6, t.F_ctx, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__176 *jrt.Class = A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_fn__31000610_A_fn_class; if fncls__176 == nil { var fncls__176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_367, false); A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_fn__31000610_A_fn_class = fncls__176d; tmp2 = fncls__176d } else { tmp2 = fncls__176 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000604); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000607__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000605__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000607__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000605__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_49.GetRawRoot__O()).Invoke_O_O__O(i__4, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_321).Ref())) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__31000604); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, i__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000605__3))) } else { s__31000605__1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000605__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :1484:1
func A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_fn__31000610_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_fn__31000610_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_fn__31000610_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1484:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_fn__31000610_A) Ctor_O_O_I_O(c__b__31000607, c__ctx any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__31000607 = c__b__31000607; t.F_ctx = c__ctx; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1484:1
func (t *A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_fn__31000610_A) Invoke_O__O(self any) any { { var i__31000606__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000606__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000606__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_49.GetRawRoot__O()).Invoke_O_O__O(i__2, lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_321).Ref())) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000607; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_c2j_emit_A_const_258.GetRawRoot__O()).Invoke_O_O__O(t.F_ctx, i__2)); i__31000606__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000606__1); continue L1 } else { i__31000606__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000606__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }









func A_arbace_c2j_emit_unit_ns_A_New() *A_arbace_c2j_emit_unit_ns_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unit_ns_A{}; t.Ctor(); return t }
//line :1494:1
func (t *A_arbace_c2j_emit_unit_ns_A) Ctor() {}
//line :1494:1
func (t *A_arbace_c2j_emit_unit_ns_A) Invoke_O_O__O(self, p__31000619__0 any) any { var vec__31000620__2 any = p__31000619__0; var kind__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000620__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ___4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000620__2, lang.RT_IntCast_J__I_NoInit(1), nil); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000620__2, lang.RT_IntCast_J__I_NoInit(2), nil); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000620__2, lang.RT_IntCast_J__I_NoInit(3), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000620__2, lang.RT_IntCast_J__I_NoInit(4), nil); var expr__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000620__2, lang.RT_IntCast_J__I_NoInit(5), nil); var n__9 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_234.GetRawRoot__O()).Invoke_O__O(expr__8); _ = ___4; _ = ___5; _ = ___6; _ = ___7; if



	lang.Util_Equiv_O_J__Z_NoInit(kind__3, 1) { var nm__10 any = A_arbace_c2j_emit_A_const_36.Invoke_O__O(n__9); var i__11 int32 = jrt.NN(jrt.String_Cast(nm__10)).IndexOf_String__I(Lit_17); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_890.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()); var tmp3 any


		if lang.Numbers_IsNeg_J__Z_NoInit(int64(i__11)) { tmp3 = nm__10 } else { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_33; tmp3 = tmp4.Invoke_O_O_O__O(nm__10, tmp5, jrt.Integer_ValueOf_I__Integer_NoInit(i__11).Ref()) }; return tmp1.Invoke_O__O(tmp2.Invoke_O__O(lang.Compiler_Demunge_String__String_NoInit(jrt.String_Cast(tmp3)).Ref())) } else {
//line :1498:1
			if lang.Util_Equiv_O_O__Z_NoInit(Lit_63, A_arbace_c2j_emit_A_const_501.Invoke_O__O(n__9)) {



				return lang.Var_Cast(A_arbace_c2j_emit_A_const_142.Invoke_O__O(n__9)).F_ns.Ref() } else {
//line :1498:1
					if A_arbace_c2j_emit_A_const_64 != nil { return nil } else { return nil } } } }












func A_arbace_c2j_emit_unnamed_package_A_New() *A_arbace_c2j_emit_unnamed_package_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_unnamed_package_A{}; t.Ctor(); return t }
//line :1511:1
func (t *A_arbace_c2j_emit_unnamed_package_A) Ctor() {}
//line :1511:1
func (t *A_arbace_c2j_emit_unnamed_package_A) Invoke_O_O__O(self, nm__0 any) any {







	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_891.GetRawRoot__O()).Invoke_O_O__O(nm__0, Lit_34)) { return nil } else { return A_arbace_c2j_emit_A_const_892
	} }
func A_arbace_c2j_emit_emit_source_A_New() *A_arbace_c2j_emit_emit_source_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_A{}; t.Ctor(); return t }
//line :1521:1
func (t *A_arbace_c2j_emit_emit_source_A) Ctor() {}
//line :1521:1
func (t *A_arbace_c2j_emit_emit_source_A) Invoke_O_O_O_O_O_O_O__O(self, classes__0, runtime_classes__1, fn_names__2, pools__3, src__4, units__5 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_33; var base__7 any = tmp1.Invoke_O_O_O__O(src__4, tmp2, jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.String_Cast(src__4)).LastIndexOf_String__I(Lit_34)).Ref()); var lname__8 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_196), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_c2j_emit_A_const_309.GetRawRoot__O()).Invoke_O_O_O__O(base__7, Lit_35, Lit_34), nil)).Ref(); var file__9 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_17.GetRawRoot__O()).Invoke_O_O__O(src__4, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(src__4)).LastIndexOf_String__I(Lit_35)))).Ref()); var ctx__10 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit_A_const_311, classes__0, A_arbace_c2j_emit_A_const_30, runtime_classes__1, A_arbace_c2j_emit_A_const_793, fn_names__2, A_arbace_c2j_emit_A_const_34, pools__3, A_arbace_c2j_emit_A_const_792, file__9)); var unit_methods__11 any; var tmp3 any = A_arbace_c2j_emit_emit_source_unit_methods__31000625_A_New_O_O(units__5, ctx__10); var tmp4 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_c2j_emit_emit_source_unit_methods__31000625_A_fn_class; if











	fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_197, false); A_arbace_c2j_emit_emit_source_unit_methods__31000625_A_fn_class = fncls__198d; tmp4 = fncls__198d } else { tmp4 = fncls__198 }; unit_methods__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var calls__12 any; var tmp5 any = /*line :1521:1*/A_arbace_c2j_emit_emit_source_calls__31000632_A_New(); var tmp6 *jrt.Class; var fncls__202 *jrt.Class = A_arbace_c2j_emit_emit_source_calls__31000632_A_fn_class; if



















	fncls__202 == nil { var fncls__202d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_198, false); A_arbace_c2j_emit_emit_source_calls__31000632_A_fn_class = fncls__202d; tmp6 = fncls__202d } else { tmp6 = fncls__202 }; calls__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var n__13 int32 = /*line :1521:1*/lang.RT_Count_O__I_NoInit(units__5); var tmp7 bool; var na_203 int64 = int64(n__13); var na_204 any = A_arbace_c2j_emit_A_const_895.GetRawRoot__O(); if





















	jrt.Long_InstanceOf(na_204) { var n0_205 int64 = na_203; var n1_206 int64 = jrt.NN(jrt.Long_Cast(na_204)).LongValue__J(); tmp7 = n0_205 <= n1_206 } else { tmp7 = lang.Numbers_Lte_J_O__Z_NoInit(na_203, na_204) }; if tmp7 { var cls__14 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_729.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit_A_const_34, pools__3)), lname__8); var ms__15 any = lang.IFn_Cast(unit_methods__11).Invoke_O_O__O(cls__14, lang.IFn_Cast(A_arbace_c2j_emit_A_const_458.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(n__13).Ref())); var tmp8 any = A_arbace_c2j_emit_A_const_36; var tmp9 any = A_arbace_c2j_emit_A_const_896; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_emit_A_const_899; var tmp12 *lang.Keyword = A_arbace_c2j_emit_A_const_37; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp14 any = A_arbace_c2j_emit_A_const_903; var tmp15 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_904, A_arbace_c2j_emit_A_const_905); var tmp16 any = lang.PersistentVector_EMPTY.Ref(); return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, lname__8, tmp9, lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()).Invoke_O_O_O_O_O__O(tmp10.Invoke_O_O__O(tmp11, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lname__8), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit_A_const_900, jrt.Boolean_TRUE.Ref(), A_arbace_c2j_emit_A_const_901, jrt.Boolean_TRUE.Ref(), A_arbace_c2j_emit_A_const_902, file__9)))), lang.IFn_Cast(A_arbace_c2j_emit_A_const_897.GetRawRoot__O()).Invoke_O__O(lname__8), lang.IFn_Cast(A_arbace_c2j_emit_A_const_898.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(cls__14))), ms__15, lang.Tuple_Create_O__IPersistentVector(tmp13.Invoke_O_O_O_O__O(tmp14, tmp15, tmp16, lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_907), lang.IFn_Cast(calls__12).Invoke_O_O__O(lname__8, lang.IFn_Cast(A_arbace_c2j_emit_A_const_458.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(n__13).Ref())), A_arbace_c2j_emit_A_const_906)))))) } else { var prev__14 any = jrt.IdentityHashMap_New(); var parts__15 any; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp18 any; var iter__1927001039__auto____15 any; var tmp19 any = A_arbace_c2j_emit_emit_source_iter__31000644__31000648_A_New_O_O_O_O_O(prev__14, calls__12, unit_methods__11, lname__8, file__9); var tmp20 *jrt.Class
		var fncls__210 /*line :1543:1*/*jrt.Class = A_arbace_c2j_emit_emit_source_iter__31000644__31000648_A_fn_class
















		if fncls__210 == nil { var fncls__210d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_199, false); A_arbace_c2j_emit_emit_source_iter__31000644__31000648_A_fn_class = fncls__210d; tmp20 = fncls__210d } else { tmp20 = fncls__210 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); tmp18 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_194.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_457.GetRawRoot__O(), lang.IFn_Cast(A_arbace_c2j_emit_A_const_921.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_895.GetRawRoot__O(), lang.IFn_Cast(A_arbace_c2j_emit_A_const_458.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(n__13).Ref())))); parts__15 = tmp17.Invoke_O__O(tmp18)
//line :1543:1
		var tmp21 any = A_arbace_c2j_emit_A_const_36; var tmp22 any = A_arbace_c2j_emit_A_const_896; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp25 any = A_arbace_c2j_emit_A_const_922; var tmp26 any = tmp24.Invoke_O_O__O(tmp25, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lname__8), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit_A_const_900, jrt.Boolean_TRUE.Ref(), A_arbace_c2j_emit_A_const_901, jrt.Boolean_TRUE.Ref(), A_arbace_c2j_emit_A_const_902, file__9)))); var tmp27 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_897.GetRawRoot__O()).Invoke_O__O(lname__8); var tmp28 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_896, parts__15); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp30 any = A_arbace_c2j_emit_A_const_923; var tmp31 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_924, A_arbace_c2j_emit_A_const_925); var tmp32 any = lang.PersistentVector_EMPTY.Ref(); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp34 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_928); var tmp35 any; var iter__1927001039__auto____16 any; var tmp36 any = A_arbace_c2j_emit_emit_source_iter__31000660__31000664_A_New(); var tmp37 *jrt.Class
		var fncls__213 /*line :1543:1*/*jrt.Class = A_arbace_c2j_emit_emit_source_iter__31000660__31000664_A_fn_class




































		if fncls__213 == nil { var fncls__213d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_200, false); A_arbace_c2j_emit_emit_source_iter__31000660__31000664_A_fn_class = fncls__213d; tmp37 = fncls__213d } else { tmp37 = fncls__213 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil); tmp35 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(parts__15)
//line :1543:1
		var tmp38 any = tmp35; var tmp39 any; var iter__1927001039__auto____16_2 any; var tmp40 any = A_arbace_c2j_emit_emit_source_iter__31000674__31000678_A_New(); var tmp41 *jrt.Class
		var fncls__216 /*line :1543:1*/*jrt.Class = A_arbace_c2j_emit_emit_source_iter__31000674__31000678_A_fn_class





































		if fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_201, false); A_arbace_c2j_emit_emit_source_iter__31000674__31000678_A_fn_class = fncls__216d; tmp41 = fncls__216d } else { tmp41 = fncls__216 }; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); tmp39 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(parts__15)
//line :1543:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp21, lname__8, tmp22, tmp23.Invoke_O_O_O_O__O(tmp26, tmp27, tmp28, lang.Tuple_Create_O__IPersistentVector(tmp29.Invoke_O_O_O_O__O(tmp30, tmp31, tmp32, tmp33.Invoke_O_O_O_O__O(tmp34, tmp38, tmp39, A_arbace_c2j_emit_A_const_927)))))) } }
//line :1533:1
func A_arbace_c2j_emit_emit_source_unit_methods__31000625_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_source_unit_methods__31000625_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_unit_methods__31000625_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1533:1
func (t *A_arbace_c2j_emit_emit_source_unit_methods__31000625_A) Ctor_O_O(c__units, c__ctx any) { t.F_units = c__units; t.F_ctx = c__ctx }
//line :1533:1
func (t *A_arbace_c2j_emit_emit_source_unit_methods__31000625_A) Invoke_O_O_O__O(self, cls__1, ks__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_emit_source_unit_methods__31000625_fn__31000626_A_New_O_O_O(t.F_units, cls__1, t.F_ctx); var tmp3 *jrt.Class; var fncls__197 *jrt.Class = A_arbace_c2j_emit_emit_source_unit_methods__31000625_fn__31000626_A_fn_class; if fncls__197 == nil { var fncls__197d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_217, false); A_arbace_c2j_emit_emit_source_unit_methods__31000625_fn__31000626_A_fn_class = fncls__197d; tmp3 = fncls__197d } else { tmp3 = fncls__197 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), ks__2) }
//line :1534:1
func A_arbace_c2j_emit_emit_source_unit_methods__31000625_fn__31000626_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_emit_source_unit_methods__31000625_fn__31000626_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_unit_methods__31000625_fn__31000626_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1534:1
func (t *A_arbace_c2j_emit_emit_source_unit_methods__31000625_fn__31000626_A) Ctor_O_O_O(c__units, c__cls, c__ctx any) { t.F_units = c__units; t.F_cls = c__cls; t.F_ctx = c__ctx }
//line :1534:1
func (t *A_arbace_c2j_emit_emit_source_unit_methods__31000625_fn__31000626_A) Invoke_O_O__O(self, k__1 any) any { var tmp1 any = t.F_units; var vec__31000627__2 any = lang.RT_Nth_O_I__O_NoInit(tmp1, lang.RT_IntCast_O__I_NoInit(k__1)); var u__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000627__2, lang.RT_IntCast_J__I_NoInit(0), nil); var um__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000627__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_122.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_123.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_emit_A_const_722; var tmp5 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_893.GetRawRoot__O()).Invoke_O__O(u__3); if



	jrt.J2g_Truth(or__1927000174__auto____5) { tmp5 = or__1927000174__auto____5 } else { tmp5 = A_arbace_c2j_emit_A_const_722.Get__O() }; tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(tmp4, tmp5)); var tmp6 any; tmp7 := /*line :1534:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)




		tmp6 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_696.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_894.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O_O__O(t.F_ctx, A_arbace_c2j_emit_A_const_40, t.F_cls, A_arbace_c2j_emit_A_const_239, um__4), k__1, u__3))
//line :1534:1
		return nil }();



	lang.IFn_Cast(A_arbace_c2j_emit_A_const_66.GetRawRoot__O()).Invoke__O(); if /*line :1534:1*/ tmp7 != nil { panic(tmp7) }; return tmp6 }






func A_arbace_c2j_emit_emit_source_calls__31000632_A_New() *A_arbace_c2j_emit_emit_source_calls__31000632_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_calls__31000632_A{}; t.Ctor(); return t }
//line :1541:1
func (t *A_arbace_c2j_emit_emit_source_calls__31000632_A) Ctor() {}
//line :1541:1
func (t *A_arbace_c2j_emit_emit_source_calls__31000632_A) Invoke_O_O_O__O(self, cname__1, ks__2 any) any { var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_A_New_O(cname__1); var tmp2 *jrt.Class; var fncls__201 *jrt.Class = A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_A_fn_class; if fncls__201 == nil { var fncls__201d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_202, false); A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_A_fn_class = fncls__201d; tmp2 = fncls__201d } else { tmp2 = fncls__201 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(ks__2) }
//line :1541:1
func A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_A_New_O(p0 any) *A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_A{}; t.Ctor_O(p0); return t }
//line :1541:1
func (t *A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_A) Ctor_O(c__cname any) { t.F_cname = c__cname }
//line :1541:1
func (t *A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_A) Invoke_O_O__O(self, s__31000634__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_A_New_O_O_O(t.F_cname, s__31000634__1, self); var tmp2 *jrt.Class; var fncls__200 *jrt.Class = A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_A_fn_class; if fncls__200 == nil { var fncls__200d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_203, false); A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_A_fn_class = fncls__200d; tmp2 = fncls__200d } else { tmp2 = fncls__200 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1541:1
func A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1541:1
func (t *A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_A) Ctor_O_O_O(c__cname, c__s__31000634, c__iter__31000633 any) { t.F_cname = c__cname; t.F_s__31000634 = c__s__31000634; t.F_iter__31000633 = c__iter__31000633 }
//line :1541:1
func (t *A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_A) Invoke_O__O(self any) any { { var s__31000634__1 any; var t_ any = t.F_s__31000634; t.F_s__31000634 = nil; s__31000634__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000634__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000634__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000634__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000634__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000636__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_fn__31000639_A_New_O_O_I_O(b__31000636__6, t.F_cname, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__199 *jrt.Class = A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_fn__31000639_A_fn_class; if fncls__199 == nil { var fncls__199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_204, false); A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_fn__31000639_A_fn_class = fncls__199d; tmp2 = fncls__199d } else { tmp2 = fncls__199 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000633); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000636__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000634__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000636__6), nil) } } else { var k__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000634__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()); var tmp5 any = t.F_cname; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__31000633); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_205, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__4)).Ref())), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000634__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1541:1
func A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_fn__31000639_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_fn__31000639_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_fn__31000639_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1541:1
func (t *A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_fn__31000639_A) Ctor_O_O_I_O(c__b__31000636, c__cname any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__31000636 = c__b__31000636; t.F_cname = c__cname; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1541:1
func (t *A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_fn__31000639_A) Invoke_O__O(self any) any { { var i__31000635__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000635__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000635__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000636; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()); var tmp5 any = t.F_cname; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_205, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__2)).Ref()))); i__31000635__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000635__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


















func A_arbace_c2j_emit_emit_source_iter__31000644__31000648_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_c2j_emit_emit_source_iter__31000644__31000648_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_iter__31000644__31000648_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1560:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000644__31000648_A) Ctor_O_O_O_O_O(c__prev, c__calls, c__unit_methods, c__lname, c__file any) { t.F_prev = c__prev; t.F_calls = c__calls; t.F_unit_methods = c__unit_methods; t.F_lname = c__lname; t.F_file = c__file }
//line :1560:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000644__31000648_A) Invoke_O_O__O(self, s__31000645__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_A_New_O_O_O_O_O_O_O(t.F_prev, t.F_calls, t.F_unit_methods, t.F_lname, t.F_file, s__31000645__1, self); var tmp2 *jrt.Class; var fncls__209 *jrt.Class = A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_A_fn_class; if fncls__209 == nil { var fncls__209d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_206, false); A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_A_fn_class = fncls__209d; tmp2 = fncls__209d } else { tmp2 = fncls__209 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1560:1
func A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :1560:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_A) Ctor_O_O_O_O_O_O_O(c__prev, c__calls, c__unit_methods, c__lname, c__file, c__s__31000645, c__iter__31000644 any) { t.F_prev = c__prev; t.F_calls = c__calls; t.F_unit_methods = c__unit_methods; t.F_lname = c__lname; t.F_file = c__file; t.F_s__31000645 = c__s__31000645; t.F_iter__31000644 = c__iter__31000644 }
//line :1560:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_A) Invoke_O__O(self any) any { { var s__31000645__1 any; var t_ any = t.F_s__31000645; t.F_s__31000645 = nil; s__31000645__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000645__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000645__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000645__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000645__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000647__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_fn__31000650_A_New_O_O_O_O_O_O_I_O(b__31000647__6, t.F_prev, t.F_calls, t.F_unit_methods, t.F_lname, t.F_file, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__208 *jrt.Class = A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_fn__31000650_A_fn_class; if fncls__208 == nil { var fncls__208d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_207, false); A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_fn__31000650_A_fn_class = fncls__208d; tmp2 = fncls__208d } else { tmp2 = fncls__208 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000644); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000647__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000645__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000647__6), nil) } } else { var vec__31000655__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000645__3); var p__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000655__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ks__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000655__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp5 lang.IPersistentMap; var pname__7 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_208, nil), jrt.RefArrayOf(jrt.Object_class, t.F_lname, nil, p__5)).Ref(); var tmp6 any = A_arbace_c2j_emit_A_const_36; var tmp7 any = A_arbace_c2j_emit_A_const_37; var tmp8 any = lang.PersistentVector_EMPTY.Ref(); var tmp9 any = A_arbace_c2j_emit_A_const_38; var cls__8 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, pname__7, tmp7, tmp8, tmp9, jrt.IdentityHashMap_New(), A_arbace_c2j_emit_A_const_39, Lit_209, A_arbace_c2j_emit_A_const_41, t.F_prev))); var ms__9 any = lang.IFn_Cast(t.F_unit_methods).Invoke_O_O__O(cls__8, ks__6); var tmp10 any = A_arbace_c2j_emit_A_const_36; var tmp11 any = A_arbace_c2j_emit_A_const_896; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_22.GetRawRoot__O()); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp14 any = A_arbace_c2j_emit_A_const_908; var tmp15 *lang.Keyword = A_arbace_c2j_emit_A_const_37; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp17 any = A_arbace_c2j_emit_A_const_910; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp19 any = A_arbace_c2j_emit_A_const_913; var tmp20 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_914, A_arbace_c2j_emit_A_const_919); var tmp21 any = lang.PersistentVector_EMPTY.Ref(); var tmp22 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()).Invoke_O_O_O_O__O(tmp13.Invoke_O_O__O(tmp14, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_210, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__5)).Ref()), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit_A_const_909, jrt.Boolean_TRUE.Ref(), A_arbace_c2j_emit_A_const_901, jrt.Boolean_TRUE.Ref(), A_arbace_c2j_emit_A_const_902, t.F_file)))), lang.IFn_Cast(A_arbace_c2j_emit_A_const_898.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(cls__8))), ms__9, lang.Tuple_Create_O_O__IPersistentVector(tmp16.Invoke_O_O_O_O__O(tmp17, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_911, A_arbace_c2j_emit_A_const_918), lang.PersistentVector_EMPTY.Ref(), nil), tmp18.Invoke_O_O_O_O__O(tmp19, tmp20, tmp21, lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_917), lang.IFn_Cast(t.F_calls).Invoke_O_O__O(pname__7, ks__6), A_arbace_c2j_emit_A_const_920)))); var tmp23 any = A_arbace_c2j_emit_A_const_13.GetRawRoot__O(); var tmp24 any = A_arbace_c2j_emit_A_const_265; var tmp25 *lang.Keyword = A_arbace_c2j_emit_A_const_265; tmp5 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, pname__7, tmp11, tmp12.Invoke_O_O_O_O__O(tmp22, tmp23, tmp24, tmp25.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(ms__9)))))); var tmp26 lang.IFn = lang.IFn_Cast(t.F_iter__31000644); return tmp4.Invoke_O_O__O(tmp5, tmp26.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000645__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1560:1
func A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_fn__31000650_A_New_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5 any, p6 int32, p7 any) *A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_fn__31000650_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_fn__31000650_A{}; t.Ctor_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :1560:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_fn__31000650_A) Ctor_O_O_O_O_O_O_I_O(c__b__31000647, c__prev, c__calls, c__unit_methods, c__lname, c__file any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__31000647 = c__b__31000647; t.F_prev = c__prev; t.F_calls = c__calls; t.F_unit_methods = c__unit_methods; t.F_lname = c__lname; t.F_file = c__file; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1560:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_fn__31000650_A) Invoke_O__O(self any) any { { var i__31000646__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000646__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__31000651__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000646__1)); var p__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000651__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ks__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000651__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000647; var tmp4 lang.IPersistentMap; var pname__5 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_208, nil), jrt.RefArrayOf(jrt.Object_class, t.F_lname, nil, p__3)).Ref(); var tmp5 any = A_arbace_c2j_emit_A_const_36; var tmp6 any = A_arbace_c2j_emit_A_const_37; var tmp7 any = lang.PersistentVector_EMPTY.Ref(); var tmp8 any = A_arbace_c2j_emit_A_const_38; var cls__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, pname__5, tmp6, tmp7, tmp8, jrt.IdentityHashMap_New(), A_arbace_c2j_emit_A_const_39, Lit_209, A_arbace_c2j_emit_A_const_41, t.F_prev))); var ms__7 any = lang.IFn_Cast(t.F_unit_methods).Invoke_O_O__O(cls__6, ks__4); var tmp9 any = A_arbace_c2j_emit_A_const_36; var tmp10 any = A_arbace_c2j_emit_A_const_896; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_22.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_emit_A_const_908; var tmp14 *lang.Keyword = A_arbace_c2j_emit_A_const_37; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_emit_A_const_910; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp18 any = A_arbace_c2j_emit_A_const_913; var tmp19 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_914, A_arbace_c2j_emit_A_const_915); var tmp20 any = lang.PersistentVector_EMPTY.Ref(); var tmp21 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()).Invoke_O_O_O_O__O(tmp12.Invoke_O_O__O(tmp13, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_210, nil), jrt.RefArrayOf(jrt.Object_class, nil, p__3)).Ref()), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit_A_const_909, jrt.Boolean_TRUE.Ref(), A_arbace_c2j_emit_A_const_901, jrt.Boolean_TRUE.Ref(), A_arbace_c2j_emit_A_const_902, t.F_file)))), lang.IFn_Cast(A_arbace_c2j_emit_A_const_898.GetRawRoot__O()).Invoke_O__O(tmp14.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(cls__6))), ms__7, lang.Tuple_Create_O_O__IPersistentVector(tmp15.Invoke_O_O_O_O__O(tmp16, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_emit_A_const_911, A_arbace_c2j_emit_A_const_912), lang.PersistentVector_EMPTY.Ref(), nil), tmp17.Invoke_O_O_O_O__O(tmp18, tmp19, tmp20, lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_917), lang.IFn_Cast(t.F_calls).Invoke_O_O__O(pname__5, ks__4), A_arbace_c2j_emit_A_const_916)))); var tmp22 any = A_arbace_c2j_emit_A_const_13.GetRawRoot__O(); var tmp23 any = A_arbace_c2j_emit_A_const_265; var tmp24 *lang.Keyword = A_arbace_c2j_emit_A_const_265; tmp4 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, pname__5, tmp10, tmp11.Invoke_O_O_O_O__O(tmp21, tmp22, tmp23, tmp24.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(ms__7)))))); tmp2.Invoke_O_O__O(tmp3, tmp4); i__31000646__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000646__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



















func A_arbace_c2j_emit_emit_source_iter__31000660__31000664_A_New() *A_arbace_c2j_emit_emit_source_iter__31000660__31000664_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_iter__31000660__31000664_A{}; t.Ctor(); return t }
//line :1580:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000660__31000664_A) Ctor() {}
//line :1580:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000660__31000664_A) Invoke_O_O__O(self, s__31000661__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_A_New_O_O(s__31000661__1, self); var tmp2 *jrt.Class; var fncls__212 *jrt.Class = A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_A_fn_class; if fncls__212 == nil { var fncls__212d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_211, false); A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_A_fn_class = fncls__212d; tmp2 = fncls__212d } else { tmp2 = fncls__212 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1580:1
func A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1580:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_A) Ctor_O_O(c__s__31000661, c__iter__31000660 any) { t.F_s__31000661 = c__s__31000661; t.F_iter__31000660 = c__iter__31000660 }
//line :1580:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_A) Invoke_O__O(self any) any { { var s__31000661__1 any; var t_ any = t.F_s__31000661; t.F_s__31000661 = nil; s__31000661__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000661__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000661__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000661__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000661__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000663__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_fn__31000666_A_New_I_O_O(size__1927001038__auto____5, b__31000663__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__211 *jrt.Class = A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_fn__31000666_A_fn_class; if fncls__211 == nil { var fncls__211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_212, false); A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_fn__31000666_A_fn_class = fncls__211d; tmp2 = fncls__211d } else { tmp2 = fncls__211 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000660); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000663__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000661__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000663__6), nil) } } else { var map__31000670__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000661__3); var map__31000670__5 any; if lang.ISeq_InstanceOf(map__31000670__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_161.GetRawRoot__O()).Invoke_O__O(map__31000670__4)) { map__31000670__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_c2j_emit_A_const_926.GetRawRoot__O()).Invoke_O__O(map__31000670__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(map__31000670__4)) { map__31000670__5 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(map__31000670__4) } else { map__31000670__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__31000670__5 = map__31000670__4 }; var pn__6 any = lang.RT_Get_O_O__O_NoInit(map__31000670__5, A_arbace_c2j_emit_A_const_36); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__31000660); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(pn__6, Lit_213)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000661__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1580:1
func A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_fn__31000666_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_fn__31000666_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_fn__31000666_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :1580:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_fn__31000666_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__31000663, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__31000663 = c__b__31000663; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1580:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_fn__31000666_A) Invoke_O__O(self any) any { { var i__31000662__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000662__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__31000667__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000662__1)); var map__31000667__3 any; if lang.ISeq_InstanceOf(map__31000667__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_161.GetRawRoot__O()).Invoke_O__O(map__31000667__2)) { map__31000667__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_c2j_emit_A_const_926.GetRawRoot__O()).Invoke_O__O(map__31000667__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(map__31000667__2)) { map__31000667__3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(map__31000667__2) } else { map__31000667__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__31000667__3 = map__31000667__2 }; var pn__4 any = lang.RT_Get_O_O__O_NoInit(map__31000667__3, A_arbace_c2j_emit_A_const_36); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000663; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(pn__4, Lit_213))); i__31000662__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000662__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_c2j_emit_emit_source_iter__31000674__31000678_A_New() *A_arbace_c2j_emit_emit_source_iter__31000674__31000678_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_iter__31000674__31000678_A{}; t.Ctor(); return t }
//line :1581:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000674__31000678_A) Ctor() {}
//line :1581:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000674__31000678_A) Invoke_O_O__O(self, s__31000675__1 any) any { var tmp1 any = A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_A_New_O_O(s__31000675__1, self); var tmp2 *jrt.Class; var fncls__215 *jrt.Class = A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_A_fn_class; if fncls__215 == nil { var fncls__215d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_214, false); A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_A_fn_class = fncls__215d; tmp2 = fncls__215d } else { tmp2 = fncls__215 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1581:1
func A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1581:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_A) Ctor_O_O(c__s__31000675, c__iter__31000674 any) { t.F_s__31000675 = c__s__31000675; t.F_iter__31000674 = c__iter__31000674 }
//line :1581:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_A) Invoke_O__O(self any) any { { var s__31000675__1 any; var t_ any = t.F_s__31000675; t.F_s__31000675 = nil; s__31000675__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000675__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000675__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000675__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000675__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000677__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_fn__31000680_A_New_O_I_O(b__31000677__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__214 *jrt.Class = A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_fn__31000680_A_fn_class; if fncls__214 == nil { var fncls__214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_215, false); A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_fn__31000680_A_fn_class = fncls__214d; tmp2 = fncls__214d } else { tmp2 = fncls__214 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000674); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000677__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000675__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000677__6), nil) } } else { var map__31000684__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000675__3); var map__31000684__5 any; if lang.ISeq_InstanceOf(map__31000684__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_161.GetRawRoot__O()).Invoke_O__O(map__31000684__4)) { map__31000684__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_c2j_emit_A_const_926.GetRawRoot__O()).Invoke_O__O(map__31000684__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(map__31000684__4)) { map__31000684__5 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(map__31000684__4) } else { map__31000684__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__31000684__5 = map__31000684__4 }; var pn__6 any = lang.RT_Get_O_O__O_NoInit(map__31000684__5, A_arbace_c2j_emit_A_const_36); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__31000674); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(pn__6, Lit_216)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000675__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1581:1
func A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_fn__31000680_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_fn__31000680_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_fn__31000680_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1581:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_fn__31000680_A) Ctor_O_I_O(c__b__31000677 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__31000677 = c__b__31000677; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1581:1
func (t *A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_fn__31000680_A) Invoke_O__O(self any) any { { var i__31000676__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000676__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__31000681__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000676__1)); var map__31000681__3 any; if lang.ISeq_InstanceOf(map__31000681__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_161.GetRawRoot__O()).Invoke_O__O(map__31000681__2)) { map__31000681__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_c2j_emit_A_const_926.GetRawRoot__O()).Invoke_O__O(map__31000681__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(map__31000681__2)) { map__31000681__3 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(map__31000681__2) } else { map__31000681__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__31000681__3 = map__31000681__2 }; var pn__4 any = lang.RT_Get_O_O__O_NoInit(map__31000681__3, A_arbace_c2j_emit_A_const_36); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000677; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O_O__O(pn__4, Lit_216))); i__31000676__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000676__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_c2j_emit_class_form_A_New() *A_arbace_c2j_emit_class_form_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_form_A{}; t.Ctor(); return t }
//line :1587:1
func (t *A_arbace_c2j_emit_class_form_A) Ctor() {}
//line :1587:1
func (t *A_arbace_c2j_emit_class_form_A) Invoke_O_O_O_O_O__O(self, c__0, children_of__1, top_QMARK___2, pools__3 any) any { var nm__5 any = A_arbace_c2j_emit_A_const_36.Invoke_O__O(c__0); var nested__6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_class_form_fn__31000690_A_New_O_O(pools__3, children_of__1); var tmp3 *jrt.Class; var fncls__218 *jrt.Class = A_arbace_c2j_emit_class_form_fn__31000690_A_fn_class; if






	fncls__218 == nil { var fncls__218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_c2j_emit_class_form_fn__31000690_A_fn_class = fncls__218d; tmp3 = fncls__218d } else { tmp3 = fncls__218 }; nested__6 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(children_of__1).Invoke_O__O(nm__5)); var mods__7 any; var tmp4 any = /*line :1587:1*/A_arbace_c2j_emit_class_form_mods__31000692_A_New_O_O(c__0, top_QMARK___2); var tmp5 *jrt.Class; var fncls__217 *jrt.Class = A_arbace_c2j_emit_class_form_mods__31000692_A_fn_class; if









	fncls__217 == nil { var fncls__217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_c2j_emit_class_form_mods__31000692_A_fn_class = fncls__217d; tmp5 = fncls__217d } else { tmp5 = fncls__217 }; mods__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var head__8 any; if



	jrt.J2g_Truth(top_QMARK___2) { head__8 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(nm__5) } else { head__8 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_932.GetRawRoot__O()).Invoke_O__O(nm__5)) }; var tmp6 any = A_arbace_c2j_emit_A_const_40; var tmp7 any = /*line :1587:1*/lang.IFn_Cast(A_arbace_c2j_emit_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.PersistentArrayMap_EMPTY.Ref()); var tmp8 any = A_arbace_c2j_emit_A_const_30; var ctx__9 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, lang.IFn_Cast(A_arbace_c2j_emit_A_const_35.GetRawRoot__O()).Invoke_O__O(lang.PersistentHashSet_EMPTY.Ref()))); var consts__10 any; _ = ctx__9; if















	jrt.J2g_Truth(top_QMARK___2) { var temp__1927000414__auto____10 any = lang.RT_Get_O_O__O_NoInit(pools__3, nm__5); if jrt.J2g_Truth(temp__1927000414__auto____10) { var p__11 any = temp__1927000414__auto____10; var tmp9 *lang.Keyword = A_arbace_c2j_emit_A_const_37; consts__10 = tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_7.GetRawRoot__O()).Invoke_O__O(p__11)) } else { consts__10 = nil } } else { consts__10 = nil }; var const_forms__11 any = /*line :1587:1*/lang.IFn_Cast(A_arbace_c2j_emit_A_const_898.GetRawRoot__O()).Invoke_O__O(consts__10); var pkg__12 any; if

















	jrt.J2g_Truth(top_QMARK___2) { pkg__12 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_897.GetRawRoot__O()).Invoke_O__O(nm__5) } else { pkg__12 = nil }; var tmp10 lang.IFn =
	lang.IFn_Cast(A_arbace_c2j_emit_A_const_22.GetRawRoot__O()); var tmp11 any; var G__31000695__13_ any = A_arbace_c2j_emit_A_const_324.Invoke_O__O(c__0); L1:
	switch { default: switch lang.Util_Hash_O__I_NoInit(G__31000695__13_) >> 1 & 1 { case 0: if any(G__31000695__13_) == any(A_arbace_c2j_emit_A_const_933) {
		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_emit_A_const_934; tmp11 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()).Invoke_O_O_O_O__O(tmp12.Invoke_O_O__O(tmp13, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(head__8, lang.IFn_Cast(mods__7).Invoke_O__O(A_arbace_c2j_emit_A_const_935))), pkg__12, const_forms__11, nested__6)
//line :1607:1
		break L1 }; case 1: if any(G__31000695__13_) == any(A_arbace_c2j_emit_A_const_323) {

			var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_emit_A_const_936; var tmp17 any = tmp15.Invoke_O_O__O(tmp16, lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(head__8, lang.IFn_Cast(mods__7).Invoke_O__O(A_arbace_c2j_emit_A_const_937))); var tmp18 lang.IPersistentVector

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_938.Invoke_O__O(c__0))) { var tmp19 any = A_arbace_c2j_emit_A_const_938; tmp18 = lang.Tuple_Create_O_O__IPersistentVector(tmp19, A_arbace_c2j_emit_A_const_938.Invoke_O__O(c__0)) } else { tmp18 = nil }
//line :1609:1
			tmp11 = tmp14.Invoke_O_O_O_O_O__O(tmp17, pkg__12, tmp18, A_arbace_c2j_emit_A_const_791.Invoke_O__O(c__0), nested__6)
//line :1607:1
			break L1 }; default:
	}





		var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_151.GetRawRoot__O()); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp22 any = A_arbace_c2j_emit_A_const_939; var tmp23 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(head__8, lang.IFn_Cast(mods__7).Invoke_O__O(A_arbace_c2j_emit_A_const_940)); var tmp24 any = A_arbace_c2j_emit_A_const_938; var tmp25 any = tmp21.Invoke_O_O_O_O__O(tmp22, tmp23, tmp24, A_arbace_c2j_emit_A_const_787.Invoke_O__O(c__0)); var tmp26 lang.IPersistentVector


		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_emit_A_const_789.Invoke_O__O(c__0))) { var tmp27 any = A_arbace_c2j_emit_A_const_941; tmp26 = lang.Tuple_Create_O_O__IPersistentVector(tmp27, A_arbace_c2j_emit_A_const_789.Invoke_O__O(c__0)) } else { tmp26 = nil }
//line :1614:1
		tmp11 = tmp20.Invoke_O_O_O_O_O_O__O(tmp25, pkg__12, tmp26, const_forms__11, A_arbace_c2j_emit_A_const_791.Invoke_O__O(c__0), nested__6)}; var tmp28 any = tmp11; var tmp29 any = /*line :1606:1*/A_arbace_c2j_emit_A_const_13.GetRawRoot__O(); var tmp30 any = A_arbace_c2j_emit_A_const_265; return tmp10.Invoke_O_O_O_O__O(tmp28, tmp29, tmp30, A_arbace_c2j_emit_A_const_264.Invoke_O__O(c__0)) }
//line :1594:1
func A_arbace_c2j_emit_class_form_fn__31000690_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_class_form_fn__31000690_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_form_fn__31000690_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1594:1
func (t *A_arbace_c2j_emit_class_form_fn__31000690_A) Ctor_O_O(c__pools, c__children_of any) { t.F_pools = c__pools; t.F_children_of = c__children_of }
//line :1594:1
func (t *A_arbace_c2j_emit_class_form_fn__31000690_A) Invoke_O_O__O(self, p1__31000689_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_931.GetRawRoot__O()).Invoke_O_O_O_O__O(p1__31000689_SHARP___1, t.F_children_of, jrt.Boolean_FALSE.Ref(), t.F_pools) }


func A_arbace_c2j_emit_class_form_mods__31000692_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_class_form_mods__31000692_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_form_mods__31000692_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1597:1
func (t *A_arbace_c2j_emit_class_form_mods__31000692_A) Ctor_O_O(c__c, c__top_QMARK_ any) { t.F_c = c__c; t.F_top_QMARK_ = c__top_QMARK_ }
//line :1597:1
func (t *A_arbace_c2j_emit_class_form_mods__31000692_A) Invoke_O_O__O(self, m__1 any) any { var G__31000693__2_ any; if jrt.J2g_Truth(t.F_top_QMARK_) { G__31000693__2_ = lang.IFn_Cast(A_arbace_c2j_emit_A_const_929.GetRawRoot__O()).Invoke_O_O__O(m__1, A_arbace_c2j_emit_A_const_909) } else { G__31000693__2_ = m__1 }; var G__31000693__3_ any; if jrt.J2g_Truth(A_arbace_c2j_emit_A_const_792.Invoke_O__O(t.F_c)) {
												var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_902; G__31000693__3_ = tmp1.Invoke_O_O_O__O(G__31000693__2_, tmp2, A_arbace_c2j_emit_A_const_792.Invoke_O__O(t.F_c)) } else {
//line :1597:1
		G__31000693__3_ = G__31000693__2_ }; var tmp3 any = A_arbace_c2j_emit_A_const_844; if lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_c2j_emit_A_const_324.Invoke_O__O(t.F_c)) {


			return lang.IFn_Cast(A_arbace_c2j_emit_A_const_13.GetRawRoot__O()).Invoke_O_O_O__O(G__31000693__3_, A_arbace_c2j_emit_A_const_930, jrt.Boolean_TRUE.Ref()) } else {
//line :1597:1
				return G__31000693__3_ } }

























func A_arbace_c2j_emit_class_forms_A_New() *A_arbace_c2j_emit_class_forms_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_forms_A{}; t.Ctor(); return t }
//line :1623:1
func (t *A_arbace_c2j_emit_class_forms_A) Ctor() {}
//line :1623:1
func (t *A_arbace_c2j_emit_class_forms_A) Invoke_O_O_O__O(self, classes__0, pools__1 any) any { var names__3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_577.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_534.GetRawRoot__O()).Invoke_O__O(classes__0)); var parent__4 any; var tmp1 any = A_arbace_c2j_emit_class_forms_parent__31000697_A_New(); var tmp2 *jrt.Class; var fncls__220 *jrt.Class = A_arbace_c2j_emit_class_forms_parent__31000697_A_fn_class; if





	fncls__220 == nil { var fncls__220d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_c2j_emit_class_forms_parent__31000697_A_fn_class = fncls__220d; tmp2 = fncls__220d } else { tmp2 = fncls__220 }; parent__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var all__5 any; var tmp3 any = /*line :1623:1*/A_arbace_c2j_emit_class_forms_fn__31000699_A_New_O_O(names__3, parent__4); var tmp4 *jrt.Class; var fncls__221 *jrt.Class = A_arbace_c2j_emit_class_forms_fn__31000699_A_fn_class; if






	fncls__221 == nil { var fncls__221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_c2j_emit_class_forms_fn__31000699_A_fn_class = fncls__221d; tmp4 = fncls__221d } else { tmp4 = fncls__221 }; all__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); var recs__6 any; var tmp5 lang.IFn = /*line :1623:1*/lang.IFn_Cast(A_arbace_c2j_emit_A_const_192.GetRawRoot__O()); var tmp6 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp7 any; var iter__1927001039__auto____6 any; var tmp8 any = A_arbace_c2j_emit_class_forms_iter__31000701__31000705_A_New_O(classes__0); var tmp9 *jrt.Class; var fncls__228 *jrt.Class = A_arbace_c2j_emit_class_forms_iter__31000701__31000705_A_fn_class; if













	fncls__228 == nil { var fncls__228d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_c2j_emit_class_forms_iter__31000701__31000705_A_fn_class = fncls__228d; tmp9 = fncls__228d } else { tmp9 = fncls__228 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); tmp7 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(all__5); recs__6 = tmp5.Invoke_O_O__O(tmp6, tmp7); var kids__7 any; var tmp10 lang.IFn = /*line :1623:1*/lang.IFn_Cast(A_arbace_c2j_emit_A_const_944.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_883.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_class_forms_fn__31000711_A_New_O(recs__6); var tmp13 *jrt.Class; var fncls__229 *jrt.Class = A_arbace_c2j_emit_class_forms_fn__31000711_A_fn_class; if
















	fncls__229 == nil { var fncls__229d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_c2j_emit_class_forms_fn__31000711_A_fn_class = fncls__229d; tmp13 = fncls__229d } else { tmp13 = fncls__229 }; kids__7 = tmp10.Invoke_O_O__O(parent__4, tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), all__5)); var children_of__8 any; var tmp14 any = /*line :1623:1*/A_arbace_c2j_emit_class_forms_children_of__31000713_A_New_O_O(kids__7, recs__6); var tmp15 *jrt.Class; var fncls__222 *jrt.Class = A_arbace_c2j_emit_class_forms_children_of__31000713_A_fn_class; if

















	fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_c2j_emit_class_forms_children_of__31000713_A_fn_class = fncls__222d; tmp15 = fncls__222d } else { tmp15 = fncls__222 }; children_of__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var iter__1927001039__auto____9 any; var tmp16 any = /*line :1623:1*/A_arbace_c2j_emit_class_forms_iter__31000715__31000719_A_New_O_O_O(children_of__8, pools__1, recs__6); var tmp17 *jrt.Class; var fncls__225 *jrt.Class = A_arbace_c2j_emit_class_forms_iter__31000715__31000719_A_fn_class; if


















	fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_c2j_emit_class_forms_iter__31000715__31000719_A_fn_class = fncls__225d; tmp17 = fncls__225d } else { tmp17 = fncls__225 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); return lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_945.GetRawRoot__O()).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(kids__7, nil))) }
//line :1629:1
func A_arbace_c2j_emit_class_forms_parent__31000697_A_New() *A_arbace_c2j_emit_class_forms_parent__31000697_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_forms_parent__31000697_A{}; t.Ctor(); return t }
//line :1629:1
func (t *A_arbace_c2j_emit_class_forms_parent__31000697_A) Ctor() {}
//line :1629:1
func (t *A_arbace_c2j_emit_class_forms_parent__31000697_A) Invoke_O_O__O(self, n__1 any) any { var i__2 int32 = jrt.NN(jrt.String_Cast(n__1)).LastIndexOf_String__I(Lit_17); if lang.Numbers_IsPos_J__Z_NoInit(int64(i__2)) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_17.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_emit_A_const_33; return tmp1.Invoke_O_O_O__O(n__1, tmp2, jrt.Integer_ValueOf_I__Integer_NoInit(i__2).Ref()) } else { return nil } }
func A_arbace_c2j_emit_class_forms_fn__31000699_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_class_forms_fn__31000699_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_forms_fn__31000699_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1630:1
func (t *A_arbace_c2j_emit_class_forms_fn__31000699_A) Ctor_O_O(c__names, c__parent any) { t.F_names = c__names; t.F_parent = c__parent }
//line :1630:1
func (t *A_arbace_c2j_emit_class_forms_fn__31000699_A) Invoke_O__O(self any) any { { var todo__1 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()).Invoke_O__O(t.F_names); var acc__2 any; var t_ any = t.F_names; t.F_names = nil; acc__2 = t_; L1: for { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_942.GetRawRoot__O()).Invoke_O__O(todo__1)
											if jrt.J2g_Truth(temp__1927000408__auto____3) { var n__4 any = temp__1927000408__auto____3; var p__5 any = lang.IFn_Cast(t.F_parent).Invoke_O__O(n__4); var tmp1 any
												var and__1927000168__auto____6 any = p__5
												if jrt.J2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_28.GetRawRoot__O()).Invoke_O_O__O(acc__2, p__5)) } else { tmp1 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp1) {
													todo__1, acc__2 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_943.GetRawRoot__O()).Invoke_O__O(todo__1), p__5), lang.IFn_Cast(A_arbace_c2j_emit_A_const_8.GetRawRoot__O()).Invoke_O_O__O(acc__2, p__5); continue L1 } else {
														todo__1, acc__2 = lang.IFn_Cast(A_arbace_c2j_emit_A_const_943.GetRawRoot__O()).Invoke_O__O(todo__1), acc__2; continue L1 } } else {
//line :1631:1
					return acc__2 } } }; /*line :1630:1*/panic("j2g: unreachable") }






func A_arbace_c2j_emit_class_forms_iter__31000701__31000705_A_New_O(p0 any) *A_arbace_c2j_emit_class_forms_iter__31000701__31000705_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_forms_iter__31000701__31000705_A{}; t.Ctor_O(p0); return t }
//line :1637:1
func (t *A_arbace_c2j_emit_class_forms_iter__31000701__31000705_A) Ctor_O(c__classes any) { t.F_classes = c__classes }
//line :1637:1
func (t *A_arbace_c2j_emit_class_forms_iter__31000701__31000705_A) Invoke_O_O__O(self, s__31000702__1 any) any { var tmp1 any = A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_A_New_O_O_O(t.F_classes, s__31000702__1, self); var tmp2 *jrt.Class; var fncls__227 *jrt.Class = A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_A_fn_class; if fncls__227 == nil { var fncls__227d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_A_fn_class = fncls__227d; tmp2 = fncls__227d } else { tmp2 = fncls__227 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1637:1
func A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1637:1
func (t *A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_A) Ctor_O_O_O(c__classes, c__s__31000702, c__iter__31000701 any) { t.F_classes = c__classes; t.F_s__31000702 = c__s__31000702; t.F_iter__31000701 = c__iter__31000701 }
//line :1637:1
func (t *A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_A) Invoke_O__O(self any) any { { var s__31000702__1 any; var t_ any = t.F_s__31000702; t.F_s__31000702 = nil; s__31000702__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000702__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000702__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000702__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000702__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000704__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_fn__31000707_A_New_O_O_I_O(t.F_classes, b__31000704__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__226 *jrt.Class = A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_fn__31000707_A_fn_class; if fncls__226 == nil { var fncls__226d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_fn__31000707_A_fn_class = fncls__226d; tmp2 = fncls__226d } else { tmp2 = fncls__226 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000701); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000704__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000702__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000704__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000702__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp5 any; var or__1927000174__auto____5 any = lang.RT_Get_O_O__O_NoInit(t.F_classes, n__4); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp5 = or__1927000174__auto____5 } else { tmp5 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit_A_const_36, n__4, A_arbace_c2j_emit_A_const_324, A_arbace_c2j_emit_A_const_933)) }; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__31000701); return tmp4.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__4, tmp5), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000702__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1637:1
func A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_fn__31000707_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_fn__31000707_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_fn__31000707_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1637:1
func (t *A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_fn__31000707_A) Ctor_O_O_I_O(c__classes, c__b__31000704 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_classes = c__classes; t.F_b__31000704 = c__b__31000704; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1637:1
func (t *A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_fn__31000707_A) Invoke_O__O(self any) any { { var i__31000703__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000703__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000703__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000704; var tmp4 any; var or__1927000174__auto____3 any = lang.RT_Get_O_O__O_NoInit(t.F_classes, n__2); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp4 = or__1927000174__auto____3 } else { tmp4 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_emit_A_const_36, n__2, A_arbace_c2j_emit_A_const_324, A_arbace_c2j_emit_A_const_933)) }; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__2, tmp4)); i__31000703__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000703__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_c2j_emit_class_forms_fn__31000711_A_New_O(p0 any) *A_arbace_c2j_emit_class_forms_fn__31000711_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_forms_fn__31000711_A{}; t.Ctor_O(p0); return t }
//line :1640:1
func (t *A_arbace_c2j_emit_class_forms_fn__31000711_A) Ctor_O(c__recs any) { t.F_recs = c__recs }
//line :1640:1
func (t *A_arbace_c2j_emit_class_forms_fn__31000711_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 any; var tmp2 *lang.Keyword = A_arbace_c2j_emit_A_const_264; var or__1927000174__auto____2 any = tmp2.Invoke_O__O(lang.IFn_Cast(t.F_recs).Invoke_O__O(n__1)); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { tmp1 = A_arbace_c2j_emit_A_const_33 }; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, n__1) }
func A_arbace_c2j_emit_class_forms_children_of__31000713_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_class_forms_children_of__31000713_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_forms_children_of__31000713_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1641:1
func (t *A_arbace_c2j_emit_class_forms_children_of__31000713_A) Ctor_O_O(c__kids, c__recs any) { t.F_kids = c__kids; t.F_recs = c__recs }
//line :1641:1
func (t *A_arbace_c2j_emit_class_forms_children_of__31000713_A) Invoke_O_O__O(self, n__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_103.GetRawRoot__O()); var tmp2 any = t.F_recs; return tmp1.Invoke_O_O__O(tmp2, lang.RT_Get_O_O__O_NoInit(t.F_kids, n__1)) }
func A_arbace_c2j_emit_class_forms_iter__31000715__31000719_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_emit_class_forms_iter__31000715__31000719_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_forms_iter__31000715__31000719_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1642:1
func (t *A_arbace_c2j_emit_class_forms_iter__31000715__31000719_A) Ctor_O_O_O(c__children_of, c__pools, c__recs any) { t.F_children_of = c__children_of; t.F_pools = c__pools; t.F_recs = c__recs }
//line :1642:1
func (t *A_arbace_c2j_emit_class_forms_iter__31000715__31000719_A) Invoke_O_O__O(self, s__31000716__1 any) any { var tmp1 any = A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_A_New_O_O_O_O_O(self, t.F_children_of, t.F_pools, s__31000716__1, t.F_recs); var tmp2 *jrt.Class; var fncls__224 *jrt.Class = A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_A_fn_class; if fncls__224 == nil { var fncls__224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_A_fn_class = fncls__224d; tmp2 = fncls__224d } else { tmp2 = fncls__224 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1642:1
func A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1642:1
func (t *A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_A) Ctor_O_O_O_O_O(c__iter__31000715, c__children_of, c__pools, c__s__31000716, c__recs any) { t.F_iter__31000715 = c__iter__31000715; t.F_children_of = c__children_of; t.F_pools = c__pools; t.F_s__31000716 = c__s__31000716; t.F_recs = c__recs }
//line :1642:1
func (t *A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_A) Invoke_O__O(self any) any { { var s__31000716__1 any; var t_ any = t.F_s__31000716; t.F_s__31000716 = nil; s__31000716__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000716__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000716__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000716__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000716__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000718__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_fn__31000721_A_New_O_O_O_I_O_O(b__31000718__6, t.F_children_of, t.F_pools, size__1927001038__auto____5, t.F_recs, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__223 *jrt.Class = A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_fn__31000721_A_fn_class; if fncls__223 == nil { var fncls__223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_fn__31000721_A_fn_class = fncls__223d; tmp2 = fncls__223d } else { tmp2 = fncls__223 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000715); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000718__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000716__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000718__6), nil) } } else { var top__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000716__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__31000715); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_931.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(t.F_recs).Invoke_O__O(top__4), t.F_children_of, jrt.Boolean_TRUE.Ref(), t.F_pools), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000716__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1642:1
func A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_fn__31000721_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_fn__31000721_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_fn__31000721_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :1642:1
func (t *A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_fn__31000721_A) Ctor_O_O_O_I_O_O(c__b__31000718, c__children_of, c__pools any, c__size__1927001038__auto__ int32, c__recs, c__c__1927001037__auto__ any) { t.F_b__31000718 = c__b__31000718; t.F_children_of = c__children_of; t.F_pools = c__pools; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_recs = c__recs; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1642:1
func (t *A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_fn__31000721_A) Invoke_O__O(self any) any { { var i__31000717__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000717__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var top__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000717__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000718; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_c2j_emit_A_const_931.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(t.F_recs).Invoke_O__O(top__2), t.F_children_of, jrt.Boolean_TRUE.Ref(), t.F_pools)); i__31000717__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000717__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_c2j_emit_interface_record_A_New() *A_arbace_c2j_emit_interface_record_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_interface_record_A{}; t.Ctor(); return t }
//line :1645:1
func (t *A_arbace_c2j_emit_interface_record_A) Ctor() {}
//line :1645:1
func (t *A_arbace_c2j_emit_interface_record_A) Invoke_O_O_O_O__O(self, name__0, extends__1, methods__2 any) any { var tmp1 any = A_arbace_c2j_emit_A_const_36; var tmp2 any = A_arbace_c2j_emit_A_const_324; var tmp3 any = A_arbace_c2j_emit_A_const_323; var tmp4 any = A_arbace_c2j_emit_A_const_938; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_47.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_interface_record_fn__31000727_A_New(); var tmp7 *jrt.Class; var fncls__235 *jrt.Class = A_arbace_c2j_emit_interface_record_fn__31000727_A_fn_class; if




	fncls__235 == nil { var fncls__235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_255, false); A_arbace_c2j_emit_interface_record_fn__31000727_A_fn_class = fncls__235d; tmp7 = fncls__235d } else { tmp7 = fncls__235 }; var tmp8 any = /*line :1645:1*/tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), extends__1); var tmp9 any = A_arbace_c2j_emit_A_const_791; var tmp10 any; var iter__1927001039__auto____4 any; var tmp11 any = A_arbace_c2j_emit_interface_record_iter__31000729__31000733_A_New(); var tmp12 *jrt.Class; var fncls__234 *jrt.Class = A_arbace_c2j_emit_interface_record_iter__31000729__31000733_A_fn_class; if





	fncls__234 == nil { var fncls__234d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_256, false); A_arbace_c2j_emit_interface_record_iter__31000729__31000733_A_fn_class = fncls__234d; tmp12 = fncls__234d } else { tmp12 = fncls__234 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(methods__2); return /*line :1645:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, name__0, tmp2, tmp3, tmp4, tmp8, tmp9, tmp10)) }




func A_arbace_c2j_emit_interface_record_fn__31000727_A_New() *A_arbace_c2j_emit_interface_record_fn__31000727_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_interface_record_fn__31000727_A{}; t.Ctor(); return t }
//line :1650:1
func (t *A_arbace_c2j_emit_interface_record_fn__31000727_A) Ctor() {}
//line :1650:1
func (t *A_arbace_c2j_emit_interface_record_fn__31000727_A) Invoke_O_O__O(self, p1__31000726_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_21.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.Class_Cast(p1__31000726_SHARP___1)).GetName__String().Ref())) }
func A_arbace_c2j_emit_interface_record_iter__31000729__31000733_A_New() *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_interface_record_iter__31000729__31000733_A{}; t.Ctor(); return t }
//line :1651:1
func (t *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_A) Ctor() {}
//line :1651:1
func (t *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_A) Invoke_O_O__O(self, s__31000730__1 any) any { var tmp1 any = A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_A_New_O_O(self, s__31000730__1); var tmp2 *jrt.Class; var fncls__233 *jrt.Class = A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_A_fn_class; if fncls__233 == nil { var fncls__233d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_257, false); A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_A_fn_class = fncls__233d; tmp2 = fncls__233d } else { tmp2 = fncls__233 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1651:1
func A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_A_New_O_O(p0, p1 any) *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1651:1
func (t *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_A) Ctor_O_O(c__iter__31000729, c__s__31000730 any) { t.F_iter__31000729 = c__iter__31000729; t.F_s__31000730 = c__s__31000730 }
//line :1651:1
func (t *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_A) Invoke_O__O(self any) any { { var s__31000730__1 any; var t_ any = t.F_s__31000730; t.F_s__31000730 = nil; s__31000730__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_115.GetRawRoot__O()).Invoke_O__O(s__31000730__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__31000730__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2j_emit_A_const_156.GetRawRoot__O()).Invoke_O__O(s__31000730__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_157.GetRawRoot__O()).Invoke_O__O(s__31000730__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__31000732__6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_195.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_A_New_O_I_O(b__31000732__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__231 *jrt.Class = A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_A_fn_class; if fncls__231 == nil { var fncls__231d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_258, false); A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_A_fn_class = fncls__231d; tmp2 = fncls__231d } else { tmp2 = fncls__231 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__31000729); return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000732__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_160.GetRawRoot__O()).Invoke_O__O(s__31000730__3))) } else { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_205.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_207.GetRawRoot__O()).Invoke_O__O(b__31000732__6), nil) } } else { var vec__31000742__4 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_158.GetRawRoot__O()).Invoke_O__O(s__31000730__3); var mname__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000742__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000742__4, lang.RT_IntCast_J__I_NoInit(1), nil); var ret__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000742__4, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_emit_A_const_946; var tmp7 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(mname__5), A_arbace_c2j_emit_A_const_949); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_emit_A_const_948; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_194.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000745_A_New(); var tmp14 *jrt.Class
														var fncls__232 /*line :1651:1*/*jrt.Class = A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000745_A_fn_class

	if fncls__232 == nil { var fncls__232d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_259, false); A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000745_A_fn_class = fncls__232d; tmp14 = fncls__232d } else { tmp14 = fncls__232 }
//line :1651:1
	var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__31000729); return tmp4.Invoke_O_O__O(tmp5.Invoke_O_O_O__O(tmp6, tmp7, tmp8.Invoke_O_O__O(tmp9.Invoke_O__O(tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), ps__6))), ret__7)), tmp15.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_209.GetRawRoot__O()).Invoke_O__O(s__31000730__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1651:1
func A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :1651:1
func (t *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_A) Ctor_O_I_O(c__b__31000732 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__31000732 = c__b__31000732; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1651:1
func (t *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_A) Invoke_O__O(self any) any { { var i__31000731__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__31000731__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__31000736__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__31000731__1)); var mname__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000736__2, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000736__2, lang.RT_IntCast_J__I_NoInit(1), nil); var ret__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__31000736__2, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_196.GetRawRoot__O()); var tmp3 any = t.F_b__31000732; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_44.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_emit_A_const_946; var tmp6 any = lang.IFn_Cast(A_arbace_c2j_emit_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(mname__3), A_arbace_c2j_emit_A_const_947); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_106.GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_206.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_emit_A_const_948; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_emit_A_const_194.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_fn__31000739_A_New(); var tmp13 *jrt.Class
																var fncls__230 /*line :1651:1*/*jrt.Class = A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_fn__31000739_A_fn_class

	if fncls__230 == nil { var fncls__230d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_260, false); A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_fn__31000739_A_fn_class = fncls__230d; tmp13 = fncls__230d } else { tmp13 = fncls__230 }
//line :1651:1
	tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp6, tmp7.Invoke_O_O__O(tmp8.Invoke_O__O(tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), ps__4))), ret__5))); i__31000731__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__31000731__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_fn__31000739_A_New() *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_fn__31000739_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_fn__31000739_A{}; t.Ctor(); return t }
//line :1653:1
func (t *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_fn__31000739_A) Ctor() {}
//line :1653:1
func (t *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_fn__31000739_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_261, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__1)).Ref()), p__2) }
//line :1653:1
func A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000745_A_New() *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000745_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000745_A{}; t.Ctor(); return t }
//line :1653:1
func (t *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000745_A) Ctor() {}
//line :1653:1
func (t *A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000745_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { return lang.IFn_Cast(A_arbace_c2j_emit_A_const_198.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2j_emit_A_const_18.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_261, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__1)).Ref()), p__2) }















































































































































































































































































































































type A_arbace_c2j_emit_A struct{ jrt.Object }

var A_arbace_c2j_emit_A_const_pool *jrt.RefArray

var A_arbace_c2j_emit_A_const_0 *lang.Var

var A_arbace_c2j_emit_A_const_1 *lang.Var

var A_arbace_c2j_emit_A_const_2 any

var A_arbace_c2j_emit_A_const_3 any

var A_arbace_c2j_emit_A_const_4 any

var A_arbace_c2j_emit_A_const_5 any

var A_arbace_c2j_emit_A_const_6 *lang.Var

var A_arbace_c2j_emit_A_const_7 *lang.Var

var A_arbace_c2j_emit_A_const_8 *lang.Var

var A_arbace_c2j_emit_A_const_9 any

var A_arbace_c2j_emit_A_const_10 *lang.Var

var A_arbace_c2j_emit_A_const_11 *lang.Var

var A_arbace_c2j_emit_A_const_12 *lang.Var

var A_arbace_c2j_emit_A_const_13 *lang.Var

var A_arbace_c2j_emit_A_const_14 *lang.Keyword

var A_arbace_c2j_emit_A_const_15 *lang.Var

var A_arbace_c2j_emit_A_const_16 *lang.Var

var A_arbace_c2j_emit_A_const_17 *lang.Var

var A_arbace_c2j_emit_A_const_18 *lang.Var

var A_arbace_c2j_emit_A_const_19 *lang.Var

var A_arbace_c2j_emit_A_const_20 *lang.Var

var A_arbace_c2j_emit_A_const_21 *lang.Var

var A_arbace_c2j_emit_A_const_22 *lang.Var

var A_arbace_c2j_emit_A_const_23 *lang.Keyword

var A_arbace_c2j_emit_A_const_24 *lang.Var

var A_arbace_c2j_emit_A_const_25 *lang.Var

var A_arbace_c2j_emit_A_const_26 *lang.Var

var A_arbace_c2j_emit_A_const_27 *lang.Var

var A_arbace_c2j_emit_A_const_28 *lang.Var

var A_arbace_c2j_emit_A_const_29 *lang.Var

var A_arbace_c2j_emit_A_const_30 *lang.Keyword

var A_arbace_c2j_emit_A_const_31 *lang.Var

var A_arbace_c2j_emit_A_const_32 *lang.Keyword

var A_arbace_c2j_emit_A_const_33 any

var A_arbace_c2j_emit_A_const_34 *lang.Keyword

var A_arbace_c2j_emit_A_const_35 *lang.Var

var A_arbace_c2j_emit_A_const_36 *lang.Keyword

var A_arbace_c2j_emit_A_const_37 *lang.Keyword

var A_arbace_c2j_emit_A_const_38 *lang.Keyword

var A_arbace_c2j_emit_A_const_39 *lang.Keyword

var A_arbace_c2j_emit_A_const_40 *lang.Keyword

var A_arbace_c2j_emit_A_const_41 *lang.Keyword

var A_arbace_c2j_emit_A_const_42 *lang.Var

var A_arbace_c2j_emit_A_const_43 *lang.Var

var A_arbace_c2j_emit_A_const_44 *lang.Var

var A_arbace_c2j_emit_A_const_45 any

var A_arbace_c2j_emit_A_const_46 any

var A_arbace_c2j_emit_A_const_47 *lang.Var

var A_arbace_c2j_emit_A_const_48 *lang.Var

var A_arbace_c2j_emit_A_const_49 *lang.Var

var A_arbace_c2j_emit_A_const_50 any

var A_arbace_c2j_emit_A_const_51 any

var A_arbace_c2j_emit_A_const_52 any

var A_arbace_c2j_emit_A_const_53 any

var A_arbace_c2j_emit_A_const_54 *lang.Var

var A_arbace_c2j_emit_A_const_55 *lang.Var

var A_arbace_c2j_emit_A_const_56 *lang.Var

var A_arbace_c2j_emit_A_const_57 *lang.Var

var A_arbace_c2j_emit_A_const_58 *lang.Var

var A_arbace_c2j_emit_A_const_59 *lang.Var

var A_arbace_c2j_emit_A_const_60 *lang.Var

var A_arbace_c2j_emit_A_const_61 *lang.Var

var A_arbace_c2j_emit_A_const_62 *lang.Var

var A_arbace_c2j_emit_A_const_63 *lang.Var

var A_arbace_c2j_emit_A_const_64 *lang.Keyword

var A_arbace_c2j_emit_A_const_65 *lang.Var

var A_arbace_c2j_emit_A_const_66 *lang.Var

var A_arbace_c2j_emit_A_const_67 any

var A_arbace_c2j_emit_A_const_68 any

var A_arbace_c2j_emit_A_const_69 any

var A_arbace_c2j_emit_A_const_70 any

var A_arbace_c2j_emit_A_const_71 any

var A_arbace_c2j_emit_A_const_72 any

var A_arbace_c2j_emit_A_const_73 *lang.Var

var A_arbace_c2j_emit_A_const_74 any

var A_arbace_c2j_emit_A_const_75 *lang.Var

var A_arbace_c2j_emit_A_const_76 *jrt.Class

var A_arbace_c2j_emit_A_const_77 *jrt.Class

var A_arbace_c2j_emit_A_const_78 *jrt.Class

var A_arbace_c2j_emit_A_const_79 *jrt.Class

var A_arbace_c2j_emit_A_const_80 *jrt.Class

var A_arbace_c2j_emit_A_const_81 *jrt.Class

var A_arbace_c2j_emit_A_const_82 *jrt.Class

var A_arbace_c2j_emit_A_const_83 *jrt.Class

var A_arbace_c2j_emit_A_const_84 any

var A_arbace_c2j_emit_A_const_85 *lang.Var

var A_arbace_c2j_emit_A_const_86 *lang.Var

var A_arbace_c2j_emit_A_const_87 any

var A_arbace_c2j_emit_A_const_88 any

var A_arbace_c2j_emit_A_const_89 any

var A_arbace_c2j_emit_A_const_90 any

var A_arbace_c2j_emit_A_const_91 any

var A_arbace_c2j_emit_A_const_92 any

var A_arbace_c2j_emit_A_const_93 any

var A_arbace_c2j_emit_A_const_94 any

var A_arbace_c2j_emit_A_const_95 any

var A_arbace_c2j_emit_A_const_96 any

var A_arbace_c2j_emit_A_const_97 *lang.Var

var A_arbace_c2j_emit_A_const_98 *lang.Var

var A_arbace_c2j_emit_A_const_99 any

var A_arbace_c2j_emit_A_const_100 any

var A_arbace_c2j_emit_A_const_101 *lang.Var

var A_arbace_c2j_emit_A_const_102 *lang.Var

var A_arbace_c2j_emit_A_const_103 *lang.Var

var A_arbace_c2j_emit_A_const_104 any

var A_arbace_c2j_emit_A_const_105 *lang.Keyword

var A_arbace_c2j_emit_A_const_106 *lang.Var

var A_arbace_c2j_emit_A_const_107 *lang.Var

var A_arbace_c2j_emit_A_const_108 any

var A_arbace_c2j_emit_A_const_109 any

var A_arbace_c2j_emit_A_const_110 any

var A_arbace_c2j_emit_A_const_111 *lang.Var

var A_arbace_c2j_emit_A_const_112 any

var A_arbace_c2j_emit_A_const_113 any

var A_arbace_c2j_emit_A_const_114 any

var A_arbace_c2j_emit_A_const_115 *lang.Var

var A_arbace_c2j_emit_A_const_116 any

var A_arbace_c2j_emit_A_const_117 any

var A_arbace_c2j_emit_A_const_118 any

var A_arbace_c2j_emit_A_const_119 any

var A_arbace_c2j_emit_A_const_120 any

var A_arbace_c2j_emit_A_const_121 any

var A_arbace_c2j_emit_A_const_122 *lang.Var

var A_arbace_c2j_emit_A_const_123 *lang.Var

var A_arbace_c2j_emit_A_const_124 *lang.Var

var A_arbace_c2j_emit_A_const_125 any

var A_arbace_c2j_emit_A_const_126 any

var A_arbace_c2j_emit_A_const_127 any

var A_arbace_c2j_emit_A_const_128 any

var A_arbace_c2j_emit_A_const_129 any

var A_arbace_c2j_emit_A_const_130 any

var A_arbace_c2j_emit_A_const_131 any

var A_arbace_c2j_emit_A_const_132 *lang.Keyword

var A_arbace_c2j_emit_A_const_133 *lang.Keyword

var A_arbace_c2j_emit_A_const_134 *lang.Keyword

var A_arbace_c2j_emit_A_const_135 *lang.Keyword

var A_arbace_c2j_emit_A_const_136 *lang.Keyword

var A_arbace_c2j_emit_A_const_137 *lang.Keyword

var A_arbace_c2j_emit_A_const_138 *lang.Keyword

var A_arbace_c2j_emit_A_const_139 *lang.Keyword

var A_arbace_c2j_emit_A_const_140 *lang.Keyword

var A_arbace_c2j_emit_A_const_141 *lang.Keyword

var A_arbace_c2j_emit_A_const_142 *lang.Keyword

var A_arbace_c2j_emit_A_const_143 *lang.Keyword

var A_arbace_c2j_emit_A_const_144 *lang.Keyword

var A_arbace_c2j_emit_A_const_145 *lang.Keyword

var A_arbace_c2j_emit_A_const_146 *lang.Keyword

var A_arbace_c2j_emit_A_const_147 *lang.Keyword

var A_arbace_c2j_emit_A_const_148 *lang.Keyword

var A_arbace_c2j_emit_A_const_149 *lang.Keyword

var A_arbace_c2j_emit_A_const_150 *lang.Var

var A_arbace_c2j_emit_A_const_151 *lang.Var

var A_arbace_c2j_emit_A_const_152 *lang.Var

var A_arbace_c2j_emit_A_const_153 any

var A_arbace_c2j_emit_A_const_154 *lang.Var

var A_arbace_c2j_emit_A_const_155 any

var A_arbace_c2j_emit_A_const_156 *lang.Var

var A_arbace_c2j_emit_A_const_157 *lang.Var

var A_arbace_c2j_emit_A_const_158 *lang.Var

var A_arbace_c2j_emit_A_const_159 *lang.Var

var A_arbace_c2j_emit_A_const_160 *lang.Var

var A_arbace_c2j_emit_A_const_161 *lang.Var

var A_arbace_c2j_emit_A_const_162 any

var A_arbace_c2j_emit_A_const_163 *lang.Var

var A_arbace_c2j_emit_A_const_164 any

var A_arbace_c2j_emit_A_const_165 any

var A_arbace_c2j_emit_A_const_166 any

var A_arbace_c2j_emit_A_const_167 any

var A_arbace_c2j_emit_A_const_168 any

var A_arbace_c2j_emit_A_const_169 any

var A_arbace_c2j_emit_A_const_170 any

var A_arbace_c2j_emit_A_const_171 any

var A_arbace_c2j_emit_A_const_172 any

var A_arbace_c2j_emit_A_const_173 any

var A_arbace_c2j_emit_A_const_174 any

var A_arbace_c2j_emit_A_const_175 any

var A_arbace_c2j_emit_A_const_176 any

var A_arbace_c2j_emit_A_const_177 any

var A_arbace_c2j_emit_A_const_178 any

var A_arbace_c2j_emit_A_const_179 any

var A_arbace_c2j_emit_A_const_180 any

var A_arbace_c2j_emit_A_const_181 any

var A_arbace_c2j_emit_A_const_182 any

var A_arbace_c2j_emit_A_const_183 any

var A_arbace_c2j_emit_A_const_184 any

var A_arbace_c2j_emit_A_const_185 any

var A_arbace_c2j_emit_A_const_186 any

var A_arbace_c2j_emit_A_const_187 any

var A_arbace_c2j_emit_A_const_188 any

var A_arbace_c2j_emit_A_const_189 any

var A_arbace_c2j_emit_A_const_190 *lang.Var

var A_arbace_c2j_emit_A_const_191 *lang.Var

var A_arbace_c2j_emit_A_const_192 *lang.Var

var A_arbace_c2j_emit_A_const_193 *lang.Var

var A_arbace_c2j_emit_A_const_194 *lang.Var

var A_arbace_c2j_emit_A_const_195 *lang.Var

var A_arbace_c2j_emit_A_const_196 *lang.Var

var A_arbace_c2j_emit_A_const_197 any

var A_arbace_c2j_emit_A_const_198 *lang.Var

var A_arbace_c2j_emit_A_const_199 any

var A_arbace_c2j_emit_A_const_200 any

var A_arbace_c2j_emit_A_const_201 any

var A_arbace_c2j_emit_A_const_202 any

var A_arbace_c2j_emit_A_const_203 any

var A_arbace_c2j_emit_A_const_204 any

var A_arbace_c2j_emit_A_const_205 *lang.Var

var A_arbace_c2j_emit_A_const_206 *lang.Var

var A_arbace_c2j_emit_A_const_207 *lang.Var

var A_arbace_c2j_emit_A_const_208 any

var A_arbace_c2j_emit_A_const_209 *lang.Var

var A_arbace_c2j_emit_A_const_210 any

var A_arbace_c2j_emit_A_const_211 any

var A_arbace_c2j_emit_A_const_212 any

var A_arbace_c2j_emit_A_const_213 any

var A_arbace_c2j_emit_A_const_214 any

var A_arbace_c2j_emit_A_const_215 any

var A_arbace_c2j_emit_A_const_216 any

var A_arbace_c2j_emit_A_const_217 any

var A_arbace_c2j_emit_A_const_218 any

var A_arbace_c2j_emit_A_const_219 any

var A_arbace_c2j_emit_A_const_220 *lang.Var

var A_arbace_c2j_emit_A_const_221 *lang.Var

var A_arbace_c2j_emit_A_const_222 *lang.Var

var A_arbace_c2j_emit_A_const_223 any

var A_arbace_c2j_emit_A_const_224 any

var A_arbace_c2j_emit_A_const_225 *lang.Var

var A_arbace_c2j_emit_A_const_226 *lang.Keyword

var A_arbace_c2j_emit_A_const_227 *lang.Var

var A_arbace_c2j_emit_A_const_228 *lang.Var

var A_arbace_c2j_emit_A_const_229 *lang.Keyword

var A_arbace_c2j_emit_A_const_230 *lang.Keyword

var A_arbace_c2j_emit_A_const_231 *lang.Var

var A_arbace_c2j_emit_A_const_232 any

var A_arbace_c2j_emit_A_const_233 *lang.Keyword

var A_arbace_c2j_emit_A_const_234 *lang.Var

var A_arbace_c2j_emit_A_const_235 *lang.Keyword

var A_arbace_c2j_emit_A_const_236 any

var A_arbace_c2j_emit_A_const_237 *lang.Var

var A_arbace_c2j_emit_A_const_238 *jrt.Class

var A_arbace_c2j_emit_A_const_239 *lang.Keyword

var A_arbace_c2j_emit_A_const_240 any

var A_arbace_c2j_emit_A_const_241 any

var A_arbace_c2j_emit_A_const_242 any

var A_arbace_c2j_emit_A_const_243 any

var A_arbace_c2j_emit_A_const_244 any

var A_arbace_c2j_emit_A_const_245 any

var A_arbace_c2j_emit_A_const_246 any

var A_arbace_c2j_emit_A_const_247 *lang.Var

var A_arbace_c2j_emit_A_const_248 any

var A_arbace_c2j_emit_A_const_249 *lang.Var

var A_arbace_c2j_emit_A_const_250 *lang.Var

var A_arbace_c2j_emit_A_const_251 *lang.Var

var A_arbace_c2j_emit_A_const_252 *lang.Var

var A_arbace_c2j_emit_A_const_253 any

var A_arbace_c2j_emit_A_const_254 any

var A_arbace_c2j_emit_A_const_255 any

var A_arbace_c2j_emit_A_const_256 any

var A_arbace_c2j_emit_A_const_257 any

var A_arbace_c2j_emit_A_const_258 *lang.Var

var A_arbace_c2j_emit_A_const_259 any

var A_arbace_c2j_emit_A_const_260 any

var A_arbace_c2j_emit_A_const_261 any

var A_arbace_c2j_emit_A_const_262 any

var A_arbace_c2j_emit_A_const_263 any

var A_arbace_c2j_emit_A_const_264 *lang.Keyword

var A_arbace_c2j_emit_A_const_265 *lang.Keyword

var A_arbace_c2j_emit_A_const_266 *lang.Keyword

var A_arbace_c2j_emit_A_const_267 *lang.Var

var A_arbace_c2j_emit_A_const_268 *lang.Var

var A_arbace_c2j_emit_A_const_269 *lang.Keyword

var A_arbace_c2j_emit_A_const_270 *lang.Keyword

var A_arbace_c2j_emit_A_const_271 *lang.Keyword

var A_arbace_c2j_emit_A_const_272 *lang.Keyword

var A_arbace_c2j_emit_A_const_273 any

var A_arbace_c2j_emit_A_const_274 *lang.Var

var A_arbace_c2j_emit_A_const_275 *lang.Keyword

var A_arbace_c2j_emit_A_const_276 any

var A_arbace_c2j_emit_A_const_277 any

var A_arbace_c2j_emit_A_const_278 any

var A_arbace_c2j_emit_A_const_279 any

var A_arbace_c2j_emit_A_const_280 *lang.Keyword

var A_arbace_c2j_emit_A_const_281 *lang.Keyword

var A_arbace_c2j_emit_A_const_282 *lang.Keyword

var A_arbace_c2j_emit_A_const_283 any

var A_arbace_c2j_emit_A_const_284 any

var A_arbace_c2j_emit_A_const_285 any

var A_arbace_c2j_emit_A_const_286 *lang.Var

var A_arbace_c2j_emit_A_const_287 any

var A_arbace_c2j_emit_A_const_288 any

var A_arbace_c2j_emit_A_const_289 any

var A_arbace_c2j_emit_A_const_290 any

var A_arbace_c2j_emit_A_const_291 any

var A_arbace_c2j_emit_A_const_292 *lang.Keyword

var A_arbace_c2j_emit_A_const_293 *lang.Keyword

var A_arbace_c2j_emit_A_const_294 *lang.Keyword

var A_arbace_c2j_emit_A_const_295 *lang.Var

var A_arbace_c2j_emit_A_const_296 any

var A_arbace_c2j_emit_A_const_297 any

var A_arbace_c2j_emit_A_const_298 *lang.Var

var A_arbace_c2j_emit_A_const_299 any

var A_arbace_c2j_emit_A_const_300 any

var A_arbace_c2j_emit_A_const_301 any

var A_arbace_c2j_emit_A_const_302 any

var A_arbace_c2j_emit_A_const_303 *lang.Var

var A_arbace_c2j_emit_A_const_304 *lang.Var

var A_arbace_c2j_emit_A_const_305 any

var A_arbace_c2j_emit_A_const_306 any

var A_arbace_c2j_emit_A_const_307 any

var A_arbace_c2j_emit_A_const_308 any

var A_arbace_c2j_emit_A_const_309 *lang.Var

var A_arbace_c2j_emit_A_const_310 *lang.Var

var A_arbace_c2j_emit_A_const_311 *lang.Keyword

var A_arbace_c2j_emit_A_const_312 *lang.Var

var A_arbace_c2j_emit_A_const_313 *lang.Var

var A_arbace_c2j_emit_A_const_314 *lang.Var

var A_arbace_c2j_emit_A_const_315 *lang.Var

var A_arbace_c2j_emit_A_const_316 *lang.Var

var A_arbace_c2j_emit_A_const_317 *lang.Keyword

var A_arbace_c2j_emit_A_const_318 *lang.Keyword

var A_arbace_c2j_emit_A_const_319 *lang.Var

var A_arbace_c2j_emit_A_const_320 *lang.Var

var A_arbace_c2j_emit_A_const_321 *lang.Var

var A_arbace_c2j_emit_A_const_322 any

var A_arbace_c2j_emit_A_const_323 *lang.Keyword

var A_arbace_c2j_emit_A_const_324 *lang.Keyword

var A_arbace_c2j_emit_A_const_325 *lang.Keyword

var A_arbace_c2j_emit_A_const_326 *lang.Var

var A_arbace_c2j_emit_A_const_327 *lang.Var

var A_arbace_c2j_emit_A_const_328 *lang.Var

var A_arbace_c2j_emit_A_const_329 *lang.Keyword

var A_arbace_c2j_emit_A_const_330 *lang.Keyword

var A_arbace_c2j_emit_A_const_331 *lang.Keyword

var A_arbace_c2j_emit_A_const_332 *lang.Keyword

var A_arbace_c2j_emit_A_const_333 *lang.Keyword

var A_arbace_c2j_emit_A_const_334 any

var A_arbace_c2j_emit_A_const_335 any

var A_arbace_c2j_emit_A_const_336 any

var A_arbace_c2j_emit_A_const_337 any

var A_arbace_c2j_emit_A_const_338 any

var A_arbace_c2j_emit_A_const_339 *lang.Keyword

var A_arbace_c2j_emit_A_const_340 any

var A_arbace_c2j_emit_A_const_341 any

var A_arbace_c2j_emit_A_const_342 *lang.Var

var A_arbace_c2j_emit_A_const_343 any

var A_arbace_c2j_emit_A_const_344 any

var A_arbace_c2j_emit_A_const_345 any

var A_arbace_c2j_emit_A_const_346 any

var A_arbace_c2j_emit_A_const_347 any

var A_arbace_c2j_emit_A_const_348 any

var A_arbace_c2j_emit_A_const_349 any

var A_arbace_c2j_emit_A_const_350 any

var A_arbace_c2j_emit_A_const_351 any

var A_arbace_c2j_emit_A_const_352 *lang.Var

var A_arbace_c2j_emit_A_const_353 any

var A_arbace_c2j_emit_A_const_354 any

var A_arbace_c2j_emit_A_const_355 any

var A_arbace_c2j_emit_A_const_356 any

var A_arbace_c2j_emit_A_const_357 any

var A_arbace_c2j_emit_A_const_358 any

var A_arbace_c2j_emit_A_const_359 any

var A_arbace_c2j_emit_A_const_360 *lang.Var

var A_arbace_c2j_emit_A_const_361 any

var A_arbace_c2j_emit_A_const_362 any

var A_arbace_c2j_emit_A_const_363 any

var A_arbace_c2j_emit_A_const_364 any

var A_arbace_c2j_emit_A_const_365 any

var A_arbace_c2j_emit_A_const_366 any

var A_arbace_c2j_emit_A_const_367 any

var A_arbace_c2j_emit_A_const_368 any

var A_arbace_c2j_emit_A_const_369 any

var A_arbace_c2j_emit_A_const_370 any

var A_arbace_c2j_emit_A_const_371 any

var A_arbace_c2j_emit_A_const_372 any

var A_arbace_c2j_emit_A_const_373 any

var A_arbace_c2j_emit_A_const_374 any

var A_arbace_c2j_emit_A_const_375 any

var A_arbace_c2j_emit_A_const_376 any

var A_arbace_c2j_emit_A_const_377 any

var A_arbace_c2j_emit_A_const_378 any

var A_arbace_c2j_emit_A_const_379 any

var A_arbace_c2j_emit_A_const_380 any

var A_arbace_c2j_emit_A_const_381 any

var A_arbace_c2j_emit_A_const_382 any

var A_arbace_c2j_emit_A_const_383 any

var A_arbace_c2j_emit_A_const_384 any

var A_arbace_c2j_emit_A_const_385 any

var A_arbace_c2j_emit_A_const_386 any

var A_arbace_c2j_emit_A_const_387 any

var A_arbace_c2j_emit_A_const_388 any

var A_arbace_c2j_emit_A_const_389 any

var A_arbace_c2j_emit_A_const_390 any

var A_arbace_c2j_emit_A_const_391 any

var A_arbace_c2j_emit_A_const_392 any

var A_arbace_c2j_emit_A_const_393 any

var A_arbace_c2j_emit_A_const_394 any

var A_arbace_c2j_emit_A_const_395 any

var A_arbace_c2j_emit_A_const_396 *lang.Var

var A_arbace_c2j_emit_A_const_397 any

var A_arbace_c2j_emit_A_const_398 any

var A_arbace_c2j_emit_A_const_399 any

var A_arbace_c2j_emit_A_const_400 any

var A_arbace_c2j_emit_A_const_401 any

var A_arbace_c2j_emit_A_const_402 any

var A_arbace_c2j_emit_A_const_403 any

var A_arbace_c2j_emit_A_const_404 any

var A_arbace_c2j_emit_A_const_405 any

var A_arbace_c2j_emit_A_const_406 any

var A_arbace_c2j_emit_A_const_407 any

var A_arbace_c2j_emit_A_const_408 any

var A_arbace_c2j_emit_A_const_409 any

var A_arbace_c2j_emit_A_const_410 any

var A_arbace_c2j_emit_A_const_411 any

var A_arbace_c2j_emit_A_const_412 *lang.Var

var A_arbace_c2j_emit_A_const_413 any

var A_arbace_c2j_emit_A_const_414 any

var A_arbace_c2j_emit_A_const_415 any

var A_arbace_c2j_emit_A_const_416 any

var A_arbace_c2j_emit_A_const_417 any

var A_arbace_c2j_emit_A_const_418 any

var A_arbace_c2j_emit_A_const_419 any

var A_arbace_c2j_emit_A_const_420 any

var A_arbace_c2j_emit_A_const_421 any

var A_arbace_c2j_emit_A_const_422 any

var A_arbace_c2j_emit_A_const_423 any

var A_arbace_c2j_emit_A_const_424 any

var A_arbace_c2j_emit_A_const_425 any

var A_arbace_c2j_emit_A_const_426 any

var A_arbace_c2j_emit_A_const_427 any

var A_arbace_c2j_emit_A_const_428 any

var A_arbace_c2j_emit_A_const_429 *jrt.Class

var A_arbace_c2j_emit_A_const_430 any

var A_arbace_c2j_emit_A_const_431 *lang.Var

var A_arbace_c2j_emit_A_const_432 *lang.Var

var A_arbace_c2j_emit_A_const_433 *lang.Var

var A_arbace_c2j_emit_A_const_434 *lang.Var

var A_arbace_c2j_emit_A_const_435 any

var A_arbace_c2j_emit_A_const_436 any

var A_arbace_c2j_emit_A_const_437 any

var A_arbace_c2j_emit_A_const_438 any

var A_arbace_c2j_emit_A_const_439 any

var A_arbace_c2j_emit_A_const_440 any

var A_arbace_c2j_emit_A_const_441 *lang.Var

var A_arbace_c2j_emit_A_const_442 any

var A_arbace_c2j_emit_A_const_443 any

var A_arbace_c2j_emit_A_const_444 *lang.Var

var A_arbace_c2j_emit_A_const_445 *lang.Var

var A_arbace_c2j_emit_A_const_446 *lang.Keyword

var A_arbace_c2j_emit_A_const_447 *lang.Keyword

var A_arbace_c2j_emit_A_const_448 *lang.Keyword

var A_arbace_c2j_emit_A_const_449 any

var A_arbace_c2j_emit_A_const_450 any

var A_arbace_c2j_emit_A_const_451 any

var A_arbace_c2j_emit_A_const_452 any

var A_arbace_c2j_emit_A_const_453 any

var A_arbace_c2j_emit_A_const_454 any

var A_arbace_c2j_emit_A_const_455 any

var A_arbace_c2j_emit_A_const_456 any

var A_arbace_c2j_emit_A_const_457 *lang.Var

var A_arbace_c2j_emit_A_const_458 *lang.Var

var A_arbace_c2j_emit_A_const_459 any

var A_arbace_c2j_emit_A_const_460 any

var A_arbace_c2j_emit_A_const_461 any

var A_arbace_c2j_emit_A_const_462 any

var A_arbace_c2j_emit_A_const_463 any

var A_arbace_c2j_emit_A_const_464 any

var A_arbace_c2j_emit_A_const_465 any

var A_arbace_c2j_emit_A_const_466 any

var A_arbace_c2j_emit_A_const_467 any

var A_arbace_c2j_emit_A_const_468 *lang.Var

var A_arbace_c2j_emit_A_const_469 *lang.Var

var A_arbace_c2j_emit_A_const_470 any

var A_arbace_c2j_emit_A_const_471 any

var A_arbace_c2j_emit_A_const_472 *lang.Keyword

var A_arbace_c2j_emit_A_const_473 *lang.Keyword

var A_arbace_c2j_emit_A_const_474 *lang.Var

var A_arbace_c2j_emit_A_const_475 any

var A_arbace_c2j_emit_A_const_476 *lang.Keyword

var A_arbace_c2j_emit_A_const_477 *lang.Keyword

var A_arbace_c2j_emit_A_const_478 any

var A_arbace_c2j_emit_A_const_479 any

var A_arbace_c2j_emit_A_const_480 any

var A_arbace_c2j_emit_A_const_481 any

var A_arbace_c2j_emit_A_const_482 *lang.Keyword

var A_arbace_c2j_emit_A_const_483 any

var A_arbace_c2j_emit_A_const_484 any

var A_arbace_c2j_emit_A_const_485 *lang.Keyword

var A_arbace_c2j_emit_A_const_486 *lang.Keyword

var A_arbace_c2j_emit_A_const_487 any

var A_arbace_c2j_emit_A_const_488 *lang.Keyword

var A_arbace_c2j_emit_A_const_489 any

var A_arbace_c2j_emit_A_const_490 any

var A_arbace_c2j_emit_A_const_491 any

var A_arbace_c2j_emit_A_const_492 any

var A_arbace_c2j_emit_A_const_493 any

var A_arbace_c2j_emit_A_const_494 *lang.Keyword

var A_arbace_c2j_emit_A_const_495 any

var A_arbace_c2j_emit_A_const_496 any

var A_arbace_c2j_emit_A_const_497 any

var A_arbace_c2j_emit_A_const_498 any

var A_arbace_c2j_emit_A_const_499 any

var A_arbace_c2j_emit_A_const_500 *lang.Keyword

var A_arbace_c2j_emit_A_const_501 *lang.Keyword

var A_arbace_c2j_emit_A_const_502 any

var A_arbace_c2j_emit_A_const_503 any

var A_arbace_c2j_emit_A_const_504 any

var A_arbace_c2j_emit_A_const_505 any

var A_arbace_c2j_emit_A_const_506 any

var A_arbace_c2j_emit_A_const_507 any

var A_arbace_c2j_emit_A_const_508 any

var A_arbace_c2j_emit_A_const_509 any

var A_arbace_c2j_emit_A_const_510 *lang.Keyword

var A_arbace_c2j_emit_A_const_511 *lang.Var

var A_arbace_c2j_emit_A_const_512 any

var A_arbace_c2j_emit_A_const_513 *lang.Keyword

var A_arbace_c2j_emit_A_const_514 *lang.Keyword

var A_arbace_c2j_emit_A_const_515 *lang.Keyword

var A_arbace_c2j_emit_A_const_516 *lang.Keyword

var A_arbace_c2j_emit_A_const_517 *lang.Keyword

var A_arbace_c2j_emit_A_const_518 *lang.Keyword

var A_arbace_c2j_emit_A_const_519 *lang.Var

var A_arbace_c2j_emit_A_const_520 *lang.Keyword

var A_arbace_c2j_emit_A_const_521 any

var A_arbace_c2j_emit_A_const_522 any

var A_arbace_c2j_emit_A_const_523 *lang.Keyword

var A_arbace_c2j_emit_A_const_524 *lang.Keyword

var A_arbace_c2j_emit_A_const_525 *lang.Keyword

var A_arbace_c2j_emit_A_const_526 *lang.Var

var A_arbace_c2j_emit_A_const_527 any

var A_arbace_c2j_emit_A_const_528 *lang.Var

var A_arbace_c2j_emit_A_const_529 any

var A_arbace_c2j_emit_A_const_530 any

var A_arbace_c2j_emit_A_const_531 any

var A_arbace_c2j_emit_A_const_532 *lang.Var

var A_arbace_c2j_emit_A_const_533 *lang.Var

var A_arbace_c2j_emit_A_const_534 *lang.Var

var A_arbace_c2j_emit_A_const_535 *lang.Keyword

var A_arbace_c2j_emit_A_const_536 any

var A_arbace_c2j_emit_A_const_537 *lang.Keyword

var A_arbace_c2j_emit_A_const_538 any

var A_arbace_c2j_emit_A_const_539 *lang.Keyword

var A_arbace_c2j_emit_A_const_540 any

var A_arbace_c2j_emit_A_const_541 any

var A_arbace_c2j_emit_A_const_542 any

var A_arbace_c2j_emit_A_const_543 any

var A_arbace_c2j_emit_A_const_544 any

var A_arbace_c2j_emit_A_const_545 any

var A_arbace_c2j_emit_A_const_546 any

var A_arbace_c2j_emit_A_const_547 any

var A_arbace_c2j_emit_A_const_548 any

var A_arbace_c2j_emit_A_const_549 any

var A_arbace_c2j_emit_A_const_550 any

var A_arbace_c2j_emit_A_const_551 any

var A_arbace_c2j_emit_A_const_552 any

var A_arbace_c2j_emit_A_const_553 any

var A_arbace_c2j_emit_A_const_554 *lang.Var

var A_arbace_c2j_emit_A_const_555 *lang.Var

var A_arbace_c2j_emit_A_const_556 *lang.Var

var A_arbace_c2j_emit_A_const_557 any

var A_arbace_c2j_emit_A_const_558 any

var A_arbace_c2j_emit_A_const_559 any

var A_arbace_c2j_emit_A_const_560 any

var A_arbace_c2j_emit_A_const_561 *lang.Keyword

var A_arbace_c2j_emit_A_const_562 *lang.Keyword

var A_arbace_c2j_emit_A_const_563 *lang.Keyword

var A_arbace_c2j_emit_A_const_564 any

var A_arbace_c2j_emit_A_const_565 *lang.Keyword

var A_arbace_c2j_emit_A_const_566 *lang.Keyword

var A_arbace_c2j_emit_A_const_567 any

var A_arbace_c2j_emit_A_const_568 *lang.Keyword

var A_arbace_c2j_emit_A_const_569 *lang.Keyword

var A_arbace_c2j_emit_A_const_570 *lang.Keyword

var A_arbace_c2j_emit_A_const_571 any

var A_arbace_c2j_emit_A_const_572 any

var A_arbace_c2j_emit_A_const_573 *lang.Keyword

var A_arbace_c2j_emit_A_const_574 *lang.Var

var A_arbace_c2j_emit_A_const_575 *lang.Keyword

var A_arbace_c2j_emit_A_const_576 *lang.Keyword

var A_arbace_c2j_emit_A_const_577 *lang.Var

var A_arbace_c2j_emit_A_const_578 *lang.Keyword

var A_arbace_c2j_emit_A_const_579 any

var A_arbace_c2j_emit_A_const_580 any

var A_arbace_c2j_emit_A_const_581 any

var A_arbace_c2j_emit_A_const_582 any

var A_arbace_c2j_emit_A_const_583 any

var A_arbace_c2j_emit_A_const_584 any

var A_arbace_c2j_emit_A_const_585 any

var A_arbace_c2j_emit_A_const_586 any

var A_arbace_c2j_emit_A_const_587 any

var A_arbace_c2j_emit_A_const_588 any

var A_arbace_c2j_emit_A_const_589 any

var A_arbace_c2j_emit_A_const_590 any

var A_arbace_c2j_emit_A_const_591 any

var A_arbace_c2j_emit_A_const_592 any

var A_arbace_c2j_emit_A_const_593 any

var A_arbace_c2j_emit_A_const_594 any

var A_arbace_c2j_emit_A_const_595 any

var A_arbace_c2j_emit_A_const_596 any

var A_arbace_c2j_emit_A_const_597 any

var A_arbace_c2j_emit_A_const_598 any

var A_arbace_c2j_emit_A_const_599 *lang.Var

var A_arbace_c2j_emit_A_const_600 *lang.Keyword

var A_arbace_c2j_emit_A_const_601 any

var A_arbace_c2j_emit_A_const_602 any

var A_arbace_c2j_emit_A_const_603 *lang.Keyword

var A_arbace_c2j_emit_A_const_604 any

var A_arbace_c2j_emit_A_const_605 any

var A_arbace_c2j_emit_A_const_606 any

var A_arbace_c2j_emit_A_const_607 any

var A_arbace_c2j_emit_A_const_608 any

var A_arbace_c2j_emit_A_const_609 any

var A_arbace_c2j_emit_A_const_610 any

var A_arbace_c2j_emit_A_const_611 any

var A_arbace_c2j_emit_A_const_612 any

var A_arbace_c2j_emit_A_const_613 *lang.Keyword

var A_arbace_c2j_emit_A_const_614 any

var A_arbace_c2j_emit_A_const_615 *lang.Var

var A_arbace_c2j_emit_A_const_616 *lang.Keyword

var A_arbace_c2j_emit_A_const_617 *lang.Var

var A_arbace_c2j_emit_A_const_618 *lang.Var

var A_arbace_c2j_emit_A_const_619 *lang.Var

var A_arbace_c2j_emit_A_const_620 *lang.Var

var A_arbace_c2j_emit_A_const_621 *lang.Var

var A_arbace_c2j_emit_A_const_622 *lang.Keyword

var A_arbace_c2j_emit_A_const_623 any

var A_arbace_c2j_emit_A_const_624 any

var A_arbace_c2j_emit_A_const_625 any

var A_arbace_c2j_emit_A_const_626 any

var A_arbace_c2j_emit_A_const_627 *lang.Var

var A_arbace_c2j_emit_A_const_628 *lang.Var

var A_arbace_c2j_emit_A_const_629 *lang.Keyword

var A_arbace_c2j_emit_A_const_630 any

var A_arbace_c2j_emit_A_const_631 *lang.Keyword

var A_arbace_c2j_emit_A_const_632 any

var A_arbace_c2j_emit_A_const_633 *lang.Keyword

var A_arbace_c2j_emit_A_const_634 any

var A_arbace_c2j_emit_A_const_635 *lang.Var

var A_arbace_c2j_emit_A_const_636 *lang.Var

var A_arbace_c2j_emit_A_const_637 *lang.Var

var A_arbace_c2j_emit_A_const_638 *lang.Var

var A_arbace_c2j_emit_A_const_639 *lang.Var

var A_arbace_c2j_emit_A_const_640 any

var A_arbace_c2j_emit_A_const_641 any

var A_arbace_c2j_emit_A_const_642 any

var A_arbace_c2j_emit_A_const_643 any

var A_arbace_c2j_emit_A_const_644 any

var A_arbace_c2j_emit_A_const_645 *lang.Keyword

var A_arbace_c2j_emit_A_const_646 any

var A_arbace_c2j_emit_A_const_647 any

var A_arbace_c2j_emit_A_const_648 *lang.Keyword

var A_arbace_c2j_emit_A_const_649 *lang.Var

var A_arbace_c2j_emit_A_const_650 *lang.Var

var A_arbace_c2j_emit_A_const_651 any

var A_arbace_c2j_emit_A_const_652 any

var A_arbace_c2j_emit_A_const_653 any

var A_arbace_c2j_emit_A_const_654 *lang.Var

var A_arbace_c2j_emit_A_const_655 *lang.Keyword

var A_arbace_c2j_emit_A_const_656 any

var A_arbace_c2j_emit_A_const_657 *lang.Keyword

var A_arbace_c2j_emit_A_const_658 any

var A_arbace_c2j_emit_A_const_659 any

var A_arbace_c2j_emit_A_const_660 *lang.Var

var A_arbace_c2j_emit_A_const_661 any

var A_arbace_c2j_emit_A_const_662 any

var A_arbace_c2j_emit_A_const_663 any

var A_arbace_c2j_emit_A_const_664 *lang.Keyword

var A_arbace_c2j_emit_A_const_665 any

var A_arbace_c2j_emit_A_const_666 any

var A_arbace_c2j_emit_A_const_667 any

var A_arbace_c2j_emit_A_const_668 any

var A_arbace_c2j_emit_A_const_669 any

var A_arbace_c2j_emit_A_const_670 any

var A_arbace_c2j_emit_A_const_671 any

var A_arbace_c2j_emit_A_const_672 any

var A_arbace_c2j_emit_A_const_673 any

var A_arbace_c2j_emit_A_const_674 any

var A_arbace_c2j_emit_A_const_675 any

var A_arbace_c2j_emit_A_const_676 *lang.Var

var A_arbace_c2j_emit_A_const_677 *lang.Var

var A_arbace_c2j_emit_A_const_678 *lang.Keyword

var A_arbace_c2j_emit_A_const_679 any

var A_arbace_c2j_emit_A_const_680 any

var A_arbace_c2j_emit_A_const_681 any

var A_arbace_c2j_emit_A_const_682 any

var A_arbace_c2j_emit_A_const_683 any

var A_arbace_c2j_emit_A_const_684 any

var A_arbace_c2j_emit_A_const_685 *lang.Keyword

var A_arbace_c2j_emit_A_const_686 any

var A_arbace_c2j_emit_A_const_687 any

var A_arbace_c2j_emit_A_const_688 *lang.Keyword

var A_arbace_c2j_emit_A_const_689 *lang.Var

var A_arbace_c2j_emit_A_const_690 any

var A_arbace_c2j_emit_A_const_691 any

var A_arbace_c2j_emit_A_const_692 any

var A_arbace_c2j_emit_A_const_693 any

var A_arbace_c2j_emit_A_const_694 any

var A_arbace_c2j_emit_A_const_695 any

var A_arbace_c2j_emit_A_const_696 *lang.Var

var A_arbace_c2j_emit_A_const_697 *lang.Var

var A_arbace_c2j_emit_A_const_698 any

var A_arbace_c2j_emit_A_const_699 any

var A_arbace_c2j_emit_A_const_700 any

var A_arbace_c2j_emit_A_const_701 any

var A_arbace_c2j_emit_A_const_702 any

var A_arbace_c2j_emit_A_const_703 any

var A_arbace_c2j_emit_A_const_704 any

var A_arbace_c2j_emit_A_const_705 any

var A_arbace_c2j_emit_A_const_706 any

var A_arbace_c2j_emit_A_const_707 any

var A_arbace_c2j_emit_A_const_708 any

var A_arbace_c2j_emit_A_const_709 any

var A_arbace_c2j_emit_A_const_710 *lang.Keyword

var A_arbace_c2j_emit_A_const_711 *lang.Var

var A_arbace_c2j_emit_A_const_712 *lang.Keyword

var A_arbace_c2j_emit_A_const_713 *lang.Keyword

var A_arbace_c2j_emit_A_const_714 *lang.Keyword

var A_arbace_c2j_emit_A_const_715 any

var A_arbace_c2j_emit_A_const_716 any

var A_arbace_c2j_emit_A_const_717 any

var A_arbace_c2j_emit_A_const_718 any

var A_arbace_c2j_emit_A_const_719 any

var A_arbace_c2j_emit_A_const_720 *lang.Var

var A_arbace_c2j_emit_A_const_721 *lang.Var

var A_arbace_c2j_emit_A_const_722 *lang.Var

var A_arbace_c2j_emit_A_const_723 *lang.Keyword

var A_arbace_c2j_emit_A_const_724 *lang.Keyword

var A_arbace_c2j_emit_A_const_725 *lang.Keyword

var A_arbace_c2j_emit_A_const_726 any

var A_arbace_c2j_emit_A_const_727 *lang.Keyword

var A_arbace_c2j_emit_A_const_728 any

var A_arbace_c2j_emit_A_const_729 *lang.Var

var A_arbace_c2j_emit_A_const_730 *lang.Keyword

var A_arbace_c2j_emit_A_const_731 *lang.Keyword

var A_arbace_c2j_emit_A_const_732 any

var A_arbace_c2j_emit_A_const_733 *lang.Var

var A_arbace_c2j_emit_A_const_734 any

var A_arbace_c2j_emit_A_const_735 any

var A_arbace_c2j_emit_A_const_736 any

var A_arbace_c2j_emit_A_const_737 *lang.Var

var A_arbace_c2j_emit_A_const_738 any

var A_arbace_c2j_emit_A_const_739 any

var A_arbace_c2j_emit_A_const_740 any

var A_arbace_c2j_emit_A_const_741 *lang.Var

var A_arbace_c2j_emit_A_const_742 *lang.Keyword

var A_arbace_c2j_emit_A_const_743 *lang.Keyword

var A_arbace_c2j_emit_A_const_744 any

var A_arbace_c2j_emit_A_const_745 any

var A_arbace_c2j_emit_A_const_746 any

var A_arbace_c2j_emit_A_const_747 any

var A_arbace_c2j_emit_A_const_748 any

var A_arbace_c2j_emit_A_const_749 any

var A_arbace_c2j_emit_A_const_750 any

var A_arbace_c2j_emit_A_const_751 any

var A_arbace_c2j_emit_A_const_752 any

var A_arbace_c2j_emit_A_const_753 any

var A_arbace_c2j_emit_A_const_754 any

var A_arbace_c2j_emit_A_const_755 any

var A_arbace_c2j_emit_A_const_756 any

var A_arbace_c2j_emit_A_const_757 any

var A_arbace_c2j_emit_A_const_758 any

var A_arbace_c2j_emit_A_const_759 any

var A_arbace_c2j_emit_A_const_760 any

var A_arbace_c2j_emit_A_const_761 any

var A_arbace_c2j_emit_A_const_762 any

var A_arbace_c2j_emit_A_const_763 any

var A_arbace_c2j_emit_A_const_764 any

var A_arbace_c2j_emit_A_const_765 any

var A_arbace_c2j_emit_A_const_766 *lang.Var

var A_arbace_c2j_emit_A_const_767 any

var A_arbace_c2j_emit_A_const_768 any

var A_arbace_c2j_emit_A_const_769 any

var A_arbace_c2j_emit_A_const_770 any

var A_arbace_c2j_emit_A_const_771 *lang.Var

var A_arbace_c2j_emit_A_const_772 any

var A_arbace_c2j_emit_A_const_773 any

var A_arbace_c2j_emit_A_const_774 any

var A_arbace_c2j_emit_A_const_775 any

var A_arbace_c2j_emit_A_const_776 any

var A_arbace_c2j_emit_A_const_777 any

var A_arbace_c2j_emit_A_const_778 any

var A_arbace_c2j_emit_A_const_779 any

var A_arbace_c2j_emit_A_const_780 any

var A_arbace_c2j_emit_A_const_781 any

var A_arbace_c2j_emit_A_const_782 any

var A_arbace_c2j_emit_A_const_783 any

var A_arbace_c2j_emit_A_const_784 any

var A_arbace_c2j_emit_A_const_785 *lang.Keyword

var A_arbace_c2j_emit_A_const_786 *lang.Keyword

var A_arbace_c2j_emit_A_const_787 *lang.Keyword

var A_arbace_c2j_emit_A_const_788 any

var A_arbace_c2j_emit_A_const_789 *lang.Keyword

var A_arbace_c2j_emit_A_const_790 *lang.Var

var A_arbace_c2j_emit_A_const_791 *lang.Keyword

var A_arbace_c2j_emit_A_const_792 *lang.Keyword

var A_arbace_c2j_emit_A_const_793 *lang.Keyword

var A_arbace_c2j_emit_A_const_794 any

var A_arbace_c2j_emit_A_const_795 any

var A_arbace_c2j_emit_A_const_796 *lang.Var

var A_arbace_c2j_emit_A_const_797 any

var A_arbace_c2j_emit_A_const_798 *lang.Keyword

var A_arbace_c2j_emit_A_const_799 any

var A_arbace_c2j_emit_A_const_800 any

var A_arbace_c2j_emit_A_const_801 any

var A_arbace_c2j_emit_A_const_802 any

var A_arbace_c2j_emit_A_const_803 any

var A_arbace_c2j_emit_A_const_804 any

var A_arbace_c2j_emit_A_const_805 any

var A_arbace_c2j_emit_A_const_806 any

var A_arbace_c2j_emit_A_const_807 any

var A_arbace_c2j_emit_A_const_808 *lang.Var

var A_arbace_c2j_emit_A_const_809 *lang.Keyword

var A_arbace_c2j_emit_A_const_810 any

var A_arbace_c2j_emit_A_const_811 any

var A_arbace_c2j_emit_A_const_812 any

var A_arbace_c2j_emit_A_const_813 any

var A_arbace_c2j_emit_A_const_814 any

var A_arbace_c2j_emit_A_const_815 any

var A_arbace_c2j_emit_A_const_816 any

var A_arbace_c2j_emit_A_const_817 any

var A_arbace_c2j_emit_A_const_818 any

var A_arbace_c2j_emit_A_const_819 any

var A_arbace_c2j_emit_A_const_820 any

var A_arbace_c2j_emit_A_const_821 any

var A_arbace_c2j_emit_A_const_822 any

var A_arbace_c2j_emit_A_const_823 any

var A_arbace_c2j_emit_A_const_824 any

var A_arbace_c2j_emit_A_const_825 any

var A_arbace_c2j_emit_A_const_826 any

var A_arbace_c2j_emit_A_const_827 any

var A_arbace_c2j_emit_A_const_828 any

var A_arbace_c2j_emit_A_const_829 any

var A_arbace_c2j_emit_A_const_830 any

var A_arbace_c2j_emit_A_const_831 any

var A_arbace_c2j_emit_A_const_832 any

var A_arbace_c2j_emit_A_const_833 any

var A_arbace_c2j_emit_A_const_834 any

var A_arbace_c2j_emit_A_const_835 any

var A_arbace_c2j_emit_A_const_836 any

var A_arbace_c2j_emit_A_const_837 any

var A_arbace_c2j_emit_A_const_838 any

var A_arbace_c2j_emit_A_const_839 any

var A_arbace_c2j_emit_A_const_840 any

var A_arbace_c2j_emit_A_const_841 any

var A_arbace_c2j_emit_A_const_842 any

var A_arbace_c2j_emit_A_const_843 any

var A_arbace_c2j_emit_A_const_844 *lang.Keyword

var A_arbace_c2j_emit_A_const_845 *lang.Keyword

var A_arbace_c2j_emit_A_const_846 any

var A_arbace_c2j_emit_A_const_847 *lang.Var

var A_arbace_c2j_emit_A_const_848 any

var A_arbace_c2j_emit_A_const_849 any

var A_arbace_c2j_emit_A_const_850 any

var A_arbace_c2j_emit_A_const_851 any

var A_arbace_c2j_emit_A_const_852 any

var A_arbace_c2j_emit_A_const_853 any

var A_arbace_c2j_emit_A_const_854 any

var A_arbace_c2j_emit_A_const_855 any

var A_arbace_c2j_emit_A_const_856 *lang.Var

var A_arbace_c2j_emit_A_const_857 any

var A_arbace_c2j_emit_A_const_858 any

var A_arbace_c2j_emit_A_const_859 any

var A_arbace_c2j_emit_A_const_860 any

var A_arbace_c2j_emit_A_const_861 any

var A_arbace_c2j_emit_A_const_862 any

var A_arbace_c2j_emit_A_const_863 any

var A_arbace_c2j_emit_A_const_864 any

var A_arbace_c2j_emit_A_const_865 any

var A_arbace_c2j_emit_A_const_866 any

var A_arbace_c2j_emit_A_const_867 any

var A_arbace_c2j_emit_A_const_868 *lang.Var

var A_arbace_c2j_emit_A_const_869 any

var A_arbace_c2j_emit_A_const_870 any

var A_arbace_c2j_emit_A_const_871 any

var A_arbace_c2j_emit_A_const_872 any

var A_arbace_c2j_emit_A_const_873 any

var A_arbace_c2j_emit_A_const_874 any

var A_arbace_c2j_emit_A_const_875 any

var A_arbace_c2j_emit_A_const_876 any

var A_arbace_c2j_emit_A_const_877 any

var A_arbace_c2j_emit_A_const_878 any

var A_arbace_c2j_emit_A_const_879 any

var A_arbace_c2j_emit_A_const_880 any

var A_arbace_c2j_emit_A_const_881 any

var A_arbace_c2j_emit_A_const_882 any

var A_arbace_c2j_emit_A_const_883 *lang.Var

var A_arbace_c2j_emit_A_const_884 any

var A_arbace_c2j_emit_A_const_885 any

var A_arbace_c2j_emit_A_const_886 any

var A_arbace_c2j_emit_A_const_887 any

var A_arbace_c2j_emit_A_const_888 any

var A_arbace_c2j_emit_A_const_889 any

var A_arbace_c2j_emit_A_const_890 *lang.Var

var A_arbace_c2j_emit_A_const_891 *lang.Var

var A_arbace_c2j_emit_A_const_892 any

var A_arbace_c2j_emit_A_const_893 *lang.Var

var A_arbace_c2j_emit_A_const_894 *lang.Var

var A_arbace_c2j_emit_A_const_895 *lang.Var

var A_arbace_c2j_emit_A_const_896 *lang.Keyword

var A_arbace_c2j_emit_A_const_897 *lang.Var

var A_arbace_c2j_emit_A_const_898 *lang.Var

var A_arbace_c2j_emit_A_const_899 any

var A_arbace_c2j_emit_A_const_900 *lang.Keyword

var A_arbace_c2j_emit_A_const_901 *lang.Keyword

var A_arbace_c2j_emit_A_const_902 *lang.Keyword

var A_arbace_c2j_emit_A_const_903 any

var A_arbace_c2j_emit_A_const_904 any

var A_arbace_c2j_emit_A_const_905 any

var A_arbace_c2j_emit_A_const_906 any

var A_arbace_c2j_emit_A_const_907 any

var A_arbace_c2j_emit_A_const_908 any

var A_arbace_c2j_emit_A_const_909 *lang.Keyword

var A_arbace_c2j_emit_A_const_910 any

var A_arbace_c2j_emit_A_const_911 any

var A_arbace_c2j_emit_A_const_912 any

var A_arbace_c2j_emit_A_const_913 any

var A_arbace_c2j_emit_A_const_914 any

var A_arbace_c2j_emit_A_const_915 any

var A_arbace_c2j_emit_A_const_916 any

var A_arbace_c2j_emit_A_const_917 any

var A_arbace_c2j_emit_A_const_918 any

var A_arbace_c2j_emit_A_const_919 any

var A_arbace_c2j_emit_A_const_920 any

var A_arbace_c2j_emit_A_const_921 *lang.Var

var A_arbace_c2j_emit_A_const_922 any

var A_arbace_c2j_emit_A_const_923 any

var A_arbace_c2j_emit_A_const_924 any

var A_arbace_c2j_emit_A_const_925 any

var A_arbace_c2j_emit_A_const_926 *lang.Var

var A_arbace_c2j_emit_A_const_927 any

var A_arbace_c2j_emit_A_const_928 any

var A_arbace_c2j_emit_A_const_929 *lang.Var

var A_arbace_c2j_emit_A_const_930 *lang.Keyword

var A_arbace_c2j_emit_A_const_931 *lang.Var

var A_arbace_c2j_emit_A_const_932 *lang.Var

var A_arbace_c2j_emit_A_const_933 *lang.Keyword

var A_arbace_c2j_emit_A_const_934 any

var A_arbace_c2j_emit_A_const_935 any

var A_arbace_c2j_emit_A_const_936 any

var A_arbace_c2j_emit_A_const_937 any

var A_arbace_c2j_emit_A_const_938 *lang.Keyword

var A_arbace_c2j_emit_A_const_939 any

var A_arbace_c2j_emit_A_const_940 any

var A_arbace_c2j_emit_A_const_941 *lang.Keyword

var A_arbace_c2j_emit_A_const_942 *lang.Var

var A_arbace_c2j_emit_A_const_943 *lang.Var

var A_arbace_c2j_emit_A_const_944 *lang.Var

var A_arbace_c2j_emit_A_const_945 *lang.Var

var A_arbace_c2j_emit_A_const_946 any

var A_arbace_c2j_emit_A_const_947 any

var A_arbace_c2j_emit_A_const_948 any

var A_arbace_c2j_emit_A_const_949 any

var A_arbace_c2j_emit_A_init jrt.ClassInit

func A_arbace_c2j_emit_A_Init() { if !A_arbace_c2j_emit_A_init.Done() { A_arbace_c2j_emit_A_init.Run(A_arbace_c2j_emit_A_clinit) } }

func A_arbace_c2j_emit_A_clinit() { A_arbace_c2j_emit_A_clinit_p0(); A_arbace_c2j_emit_A_clinit_p1(); A_arbace_c2j_emit_A_clinit_p2(); A_arbace_c2j_emit_A_clinit_p3(); A_arbace_c2j_emit_A_clinit_p4(); A_arbace_c2j_emit_A_clinit_p5(); A_arbace_c2j_emit_A_clinit_p6(); A_arbace_c2j_emit_A_clinit_p7(); A_arbace_c2j_emit_A_clinit_p8(); A_arbace_c2j_emit_A_clinit_p9(); A_arbace_c2j_emit_A_clinit_p10(); A_arbace_c2j_emit_A_clinit_p11(); A_arbace_c2j_emit_A_clinit_p12(); A_arbace_c2j_emit_A_clinit_p13(); A_arbace_c2j_emit_A_clinit_p14(); A_arbace_c2j_emit_A_clinit_p15(); A_arbace_c2j_emit_A_clinit_p16(); A_arbace_c2j_emit_A_clinit_p17(); A_arbace_c2j_emit_A_clinit_p18(); A_arbace_c2j_emit_A_clinit_p19(); A_arbace_c2j_emit_A_clinit_p20(); A_arbace_c2j_emit_A_clinit_p21(); A_arbace_c2j_emit_A_clinit_p22(); A_arbace_c2j_emit_A_clinit_p23(); A_arbace_c2j_emit_A_clinit_p24(); A_arbace_c2j_emit_A_clinit_p25(); A_arbace_c2j_emit_A_clinit_p26(); A_arbace_c2j_emit_A_clinit_p27(); A_arbace_c2j_emit_A_clinit_p28(); A_arbace_c2j_emit_A_clinit_p29(); A_arbace_c2j_emit_A_clinit_p30(); A_arbace_c2j_emit_A_clinit_p31(); A_arbace_c2j_emit_A_clinit_p32(); A_arbace_c2j_emit_A_clinit_p33(); A_arbace_c2j_emit_A_clinit_p34(); A_arbace_c2j_emit_A_clinit_p35(); A_arbace_c2j_emit_A_clinit_p36(); A_arbace_c2j_emit_A_clinit_p37(); A_arbace_c2j_emit_A_clinit_p38(); A_arbace_c2j_emit_A_clinit_p39(); A_arbace_c2j_emit_A_clinit_p40(); A_arbace_c2j_emit_A_clinit_p41(); A_arbace_c2j_emit_A_clinit_p42(); A_arbace_c2j_emit_A_clinit_p43(); A_arbace_c2j_emit_A_clinit_p44(); A_arbace_c2j_emit_A_clinit_p45(); A_arbace_c2j_emit_A_clinit_p46(); A_arbace_c2j_emit_A_clinit_p47(); A_arbace_c2j_emit_A_clinit_p48(); A_arbace_c2j_emit_A_clinit_p49(); A_arbace_c2j_emit_A_clinit_p50(); A_arbace_c2j_emit_A_clinit_p51(); A_arbace_c2j_emit_A_clinit_p52(); A_arbace_c2j_emit_A_clinit_p53(); A_arbace_c2j_emit_A_clinit_p54(); A_arbace_c2j_emit_A_clinit_p55(); A_arbace_c2j_emit_A_clinit_p56(); A_arbace_c2j_emit_A_clinit_p57(); A_arbace_c2j_emit_A_clinit_p58(); A_arbace_c2j_emit_A_clinit_p59(); A_arbace_c2j_emit_A_clinit_p60(); A_arbace_c2j_emit_A_clinit_p61(); A_arbace_c2j_emit_A_clinit_p62(); A_arbace_c2j_emit_A_clinit_p63(); A_arbace_c2j_emit_A_clinit_p64(); A_arbace_c2j_emit_A_clinit_p65(); A_arbace_c2j_emit_A_clinit_p66(); A_arbace_c2j_emit_A_clinit_p67(); A_arbace_c2j_emit_A_clinit_p68() }

func A_arbace_c2j_emit_A_clinit_p0() { jrt.StartCheck(); A_arbace_c2j_emit_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 1291); A_arbace_c2j_emit_A_const_0 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[341]); A_arbace_c2j_emit_A_const_1 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[342]); A_arbace_c2j_emit_A_const_2 = A_arbace_c2j_emit_A_const_pool.A[343]; A_arbace_c2j_emit_A_const_3 = A_arbace_c2j_emit_A_const_pool.A[344]; A_arbace_c2j_emit_A_const_4 = A_arbace_c2j_emit_A_const_pool.A[345]; A_arbace_c2j_emit_A_const_5 = A_arbace_c2j_emit_A_const_pool.A[346]; A_arbace_c2j_emit_A_const_6 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[347]); A_arbace_c2j_emit_A_const_7 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[348]); A_arbace_c2j_emit_A_const_8 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[349]); A_arbace_c2j_emit_A_const_9 = A_arbace_c2j_emit_A_const_pool.A[350]; A_arbace_c2j_emit_A_const_10 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[351]); A_arbace_c2j_emit_A_const_11 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[352]) }

func A_arbace_c2j_emit_A_clinit_p1() { A_arbace_c2j_emit_A_const_12 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[353]); A_arbace_c2j_emit_A_const_13 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[354]); A_arbace_c2j_emit_A_const_14 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[355]); A_arbace_c2j_emit_A_const_15 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[356]); A_arbace_c2j_emit_A_const_16 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[357]); A_arbace_c2j_emit_A_const_17 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[358]); A_arbace_c2j_emit_A_const_18 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[359]); A_arbace_c2j_emit_A_const_19 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[360]); A_arbace_c2j_emit_A_const_20 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[361]); A_arbace_c2j_emit_A_const_21 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[362]); A_arbace_c2j_emit_A_const_22 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[363]); A_arbace_c2j_emit_A_const_23 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[364]) }

func A_arbace_c2j_emit_A_clinit_p2() { A_arbace_c2j_emit_A_const_24 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[365]); A_arbace_c2j_emit_A_const_25 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[366]); A_arbace_c2j_emit_A_const_26 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[367]); A_arbace_c2j_emit_A_const_27 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[368]); A_arbace_c2j_emit_A_const_28 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[369]); A_arbace_c2j_emit_A_const_29 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[370]); A_arbace_c2j_emit_A_const_30 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[371]); A_arbace_c2j_emit_A_const_31 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[372]); A_arbace_c2j_emit_A_const_32 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[373]); A_arbace_c2j_emit_A_const_33 = A_arbace_c2j_emit_A_const_pool.A[374]; A_arbace_c2j_emit_A_const_34 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[375]); A_arbace_c2j_emit_A_const_35 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[376]) }

func A_arbace_c2j_emit_A_clinit_p3() { A_arbace_c2j_emit_A_const_36 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[377]); A_arbace_c2j_emit_A_const_37 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[378]); A_arbace_c2j_emit_A_const_38 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[379]); A_arbace_c2j_emit_A_const_39 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[380]); A_arbace_c2j_emit_A_const_40 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[381]); A_arbace_c2j_emit_A_const_41 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[382]); A_arbace_c2j_emit_A_const_42 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[383]); A_arbace_c2j_emit_A_const_43 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[384]); A_arbace_c2j_emit_A_const_44 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[385]); A_arbace_c2j_emit_A_const_45 = A_arbace_c2j_emit_A_const_pool.A[386]; A_arbace_c2j_emit_A_const_46 = A_arbace_c2j_emit_A_const_pool.A[387]; A_arbace_c2j_emit_A_const_47 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[388]) }

func A_arbace_c2j_emit_A_clinit_p4() { A_arbace_c2j_emit_A_const_48 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[389]); A_arbace_c2j_emit_A_const_49 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[390]); A_arbace_c2j_emit_A_const_50 = A_arbace_c2j_emit_A_const_pool.A[391]; A_arbace_c2j_emit_A_const_51 = A_arbace_c2j_emit_A_const_pool.A[392]; A_arbace_c2j_emit_A_const_52 = A_arbace_c2j_emit_A_const_pool.A[393]; A_arbace_c2j_emit_A_const_53 = A_arbace_c2j_emit_A_const_pool.A[394]; A_arbace_c2j_emit_A_const_54 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[395]); A_arbace_c2j_emit_A_const_55 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[396]); A_arbace_c2j_emit_A_const_56 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[397]); A_arbace_c2j_emit_A_const_57 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[398]); A_arbace_c2j_emit_A_const_58 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[399]); A_arbace_c2j_emit_A_const_59 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[400]); A_arbace_c2j_emit_A_const_60 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[401]) }

func A_arbace_c2j_emit_A_clinit_p5() { A_arbace_c2j_emit_A_const_61 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[402]); A_arbace_c2j_emit_A_const_62 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[403]); A_arbace_c2j_emit_A_const_63 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[404]); A_arbace_c2j_emit_A_const_64 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[405]); A_arbace_c2j_emit_A_const_65 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[406]); A_arbace_c2j_emit_A_const_66 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[407]); A_arbace_c2j_emit_A_const_67 = A_arbace_c2j_emit_A_const_pool.A[408]; A_arbace_c2j_emit_A_const_68 = A_arbace_c2j_emit_A_const_pool.A[409]; A_arbace_c2j_emit_A_const_69 = A_arbace_c2j_emit_A_const_pool.A[410]; A_arbace_c2j_emit_A_const_70 = A_arbace_c2j_emit_A_const_pool.A[411]; A_arbace_c2j_emit_A_const_71 = A_arbace_c2j_emit_A_const_pool.A[412]; A_arbace_c2j_emit_A_const_72 = A_arbace_c2j_emit_A_const_pool.A[413]; A_arbace_c2j_emit_A_const_73 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[414]) }

func A_arbace_c2j_emit_A_clinit_p6() { A_arbace_c2j_emit_A_const_74 = A_arbace_c2j_emit_A_const_pool.A[415]; A_arbace_c2j_emit_A_const_75 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[416]); A_arbace_c2j_emit_A_const_76 = jrt.Class_Cast(A_arbace_c2j_emit_A_const_pool.A[417]); A_arbace_c2j_emit_A_const_77 = jrt.Class_Cast(A_arbace_c2j_emit_A_const_pool.A[418]); A_arbace_c2j_emit_A_const_78 = jrt.Class_Cast(A_arbace_c2j_emit_A_const_pool.A[419]); A_arbace_c2j_emit_A_const_79 = jrt.Class_Cast(A_arbace_c2j_emit_A_const_pool.A[420]); A_arbace_c2j_emit_A_const_80 = jrt.Class_Cast(A_arbace_c2j_emit_A_const_pool.A[421]); A_arbace_c2j_emit_A_const_81 = jrt.Class_Cast(A_arbace_c2j_emit_A_const_pool.A[422]); A_arbace_c2j_emit_A_const_82 = jrt.Class_Cast(A_arbace_c2j_emit_A_const_pool.A[423]); A_arbace_c2j_emit_A_const_83 = jrt.Class_Cast(A_arbace_c2j_emit_A_const_pool.A[424]); A_arbace_c2j_emit_A_const_84 = A_arbace_c2j_emit_A_const_pool.A[425]; A_arbace_c2j_emit_A_const_85 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[426]) }

func A_arbace_c2j_emit_A_clinit_p7() { A_arbace_c2j_emit_A_const_86 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[427]); A_arbace_c2j_emit_A_const_87 = A_arbace_c2j_emit_A_const_pool.A[428]; A_arbace_c2j_emit_A_const_88 = A_arbace_c2j_emit_A_const_pool.A[429]; A_arbace_c2j_emit_A_const_89 = A_arbace_c2j_emit_A_const_pool.A[430]; A_arbace_c2j_emit_A_const_90 = A_arbace_c2j_emit_A_const_pool.A[431]; A_arbace_c2j_emit_A_const_91 = A_arbace_c2j_emit_A_const_pool.A[432]; A_arbace_c2j_emit_A_const_92 = A_arbace_c2j_emit_A_const_pool.A[433]; A_arbace_c2j_emit_A_const_93 = A_arbace_c2j_emit_A_const_pool.A[434]; A_arbace_c2j_emit_A_const_94 = A_arbace_c2j_emit_A_const_pool.A[435]; A_arbace_c2j_emit_A_const_95 = A_arbace_c2j_emit_A_const_pool.A[436]; A_arbace_c2j_emit_A_const_96 = A_arbace_c2j_emit_A_const_pool.A[437]; A_arbace_c2j_emit_A_const_97 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[438]); A_arbace_c2j_emit_A_const_98 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[439]); A_arbace_c2j_emit_A_const_99 = A_arbace_c2j_emit_A_const_pool.A[440]; A_arbace_c2j_emit_A_const_100 = A_arbace_c2j_emit_A_const_pool.A[441] }

func A_arbace_c2j_emit_A_clinit_p8() { A_arbace_c2j_emit_A_const_101 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[442]); A_arbace_c2j_emit_A_const_102 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[443]); A_arbace_c2j_emit_A_const_103 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[444]); A_arbace_c2j_emit_A_const_104 = A_arbace_c2j_emit_A_const_pool.A[445]; A_arbace_c2j_emit_A_const_105 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[446]); A_arbace_c2j_emit_A_const_106 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[447]); A_arbace_c2j_emit_A_const_107 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[448]); A_arbace_c2j_emit_A_const_108 = A_arbace_c2j_emit_A_const_pool.A[449]; A_arbace_c2j_emit_A_const_109 = A_arbace_c2j_emit_A_const_pool.A[450]; A_arbace_c2j_emit_A_const_110 = A_arbace_c2j_emit_A_const_pool.A[451]; A_arbace_c2j_emit_A_const_111 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[452]); A_arbace_c2j_emit_A_const_112 = A_arbace_c2j_emit_A_const_pool.A[453]; A_arbace_c2j_emit_A_const_113 = A_arbace_c2j_emit_A_const_pool.A[454] }

func A_arbace_c2j_emit_A_clinit_p9() { A_arbace_c2j_emit_A_const_114 = A_arbace_c2j_emit_A_const_pool.A[455]; A_arbace_c2j_emit_A_const_115 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[456]); A_arbace_c2j_emit_A_const_116 = A_arbace_c2j_emit_A_const_pool.A[457]; A_arbace_c2j_emit_A_const_117 = A_arbace_c2j_emit_A_const_pool.A[458]; A_arbace_c2j_emit_A_const_118 = A_arbace_c2j_emit_A_const_pool.A[459]; A_arbace_c2j_emit_A_const_119 = A_arbace_c2j_emit_A_const_pool.A[460]; A_arbace_c2j_emit_A_const_120 = A_arbace_c2j_emit_A_const_pool.A[461]; A_arbace_c2j_emit_A_const_121 = A_arbace_c2j_emit_A_const_pool.A[462]; A_arbace_c2j_emit_A_const_122 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[463]); A_arbace_c2j_emit_A_const_123 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[464]); A_arbace_c2j_emit_A_const_124 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[465]); A_arbace_c2j_emit_A_const_125 = A_arbace_c2j_emit_A_const_pool.A[466]; A_arbace_c2j_emit_A_const_126 = A_arbace_c2j_emit_A_const_pool.A[467]; A_arbace_c2j_emit_A_const_127 = A_arbace_c2j_emit_A_const_pool.A[468] }

func A_arbace_c2j_emit_A_clinit_p10() { A_arbace_c2j_emit_A_const_128 = A_arbace_c2j_emit_A_const_pool.A[469]; A_arbace_c2j_emit_A_const_129 = A_arbace_c2j_emit_A_const_pool.A[470]; A_arbace_c2j_emit_A_const_130 = A_arbace_c2j_emit_A_const_pool.A[471]; A_arbace_c2j_emit_A_const_131 = A_arbace_c2j_emit_A_const_pool.A[472]; A_arbace_c2j_emit_A_const_132 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[473]); A_arbace_c2j_emit_A_const_133 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[474]); A_arbace_c2j_emit_A_const_134 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[475]); A_arbace_c2j_emit_A_const_135 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[476]); A_arbace_c2j_emit_A_const_136 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[477]); A_arbace_c2j_emit_A_const_137 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[478]); A_arbace_c2j_emit_A_const_138 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[479]); A_arbace_c2j_emit_A_const_139 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[480]); A_arbace_c2j_emit_A_const_140 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[481]) }

func A_arbace_c2j_emit_A_clinit_p11() { A_arbace_c2j_emit_A_const_141 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[482]); A_arbace_c2j_emit_A_const_142 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[483]); A_arbace_c2j_emit_A_const_143 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[484]); A_arbace_c2j_emit_A_const_144 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[485]); A_arbace_c2j_emit_A_const_145 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[486]); A_arbace_c2j_emit_A_const_146 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[487]); A_arbace_c2j_emit_A_const_147 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[488]); A_arbace_c2j_emit_A_const_148 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[489]); A_arbace_c2j_emit_A_const_149 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[490]); A_arbace_c2j_emit_A_const_150 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[491]); A_arbace_c2j_emit_A_const_151 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[492]); A_arbace_c2j_emit_A_const_152 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[493]) }

func A_arbace_c2j_emit_A_clinit_p12() { A_arbace_c2j_emit_A_const_153 = A_arbace_c2j_emit_A_const_pool.A[494]; A_arbace_c2j_emit_A_const_154 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[495]); A_arbace_c2j_emit_A_const_155 = A_arbace_c2j_emit_A_const_pool.A[496]; A_arbace_c2j_emit_A_const_156 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[497]); A_arbace_c2j_emit_A_const_157 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[498]); A_arbace_c2j_emit_A_const_158 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[499]); A_arbace_c2j_emit_A_const_159 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[500]); A_arbace_c2j_emit_A_const_160 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[501]); A_arbace_c2j_emit_A_const_161 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[502]); A_arbace_c2j_emit_A_const_162 = A_arbace_c2j_emit_A_const_pool.A[503]; A_arbace_c2j_emit_A_const_163 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[504]); A_arbace_c2j_emit_A_const_164 = A_arbace_c2j_emit_A_const_pool.A[505]; A_arbace_c2j_emit_A_const_165 = A_arbace_c2j_emit_A_const_pool.A[506] }

func A_arbace_c2j_emit_A_clinit_p13() { A_arbace_c2j_emit_A_const_166 = A_arbace_c2j_emit_A_const_pool.A[507]; A_arbace_c2j_emit_A_const_167 = A_arbace_c2j_emit_A_const_pool.A[508]; A_arbace_c2j_emit_A_const_168 = A_arbace_c2j_emit_A_const_pool.A[509]; A_arbace_c2j_emit_A_const_169 = A_arbace_c2j_emit_A_const_pool.A[510]; A_arbace_c2j_emit_A_const_170 = A_arbace_c2j_emit_A_const_pool.A[511]; A_arbace_c2j_emit_A_const_171 = A_arbace_c2j_emit_A_const_pool.A[512]; A_arbace_c2j_emit_A_const_172 = A_arbace_c2j_emit_A_const_pool.A[513]; A_arbace_c2j_emit_A_const_173 = A_arbace_c2j_emit_A_const_pool.A[514]; A_arbace_c2j_emit_A_const_174 = A_arbace_c2j_emit_A_const_pool.A[515]; A_arbace_c2j_emit_A_const_175 = A_arbace_c2j_emit_A_const_pool.A[516]; A_arbace_c2j_emit_A_const_176 = A_arbace_c2j_emit_A_const_pool.A[517]; A_arbace_c2j_emit_A_const_177 = A_arbace_c2j_emit_A_const_pool.A[518]; A_arbace_c2j_emit_A_const_178 = A_arbace_c2j_emit_A_const_pool.A[519]; A_arbace_c2j_emit_A_const_179 = A_arbace_c2j_emit_A_const_pool.A[520]; A_arbace_c2j_emit_A_const_180 = A_arbace_c2j_emit_A_const_pool.A[521]; A_arbace_c2j_emit_A_const_181 = A_arbace_c2j_emit_A_const_pool.A[522] }

func A_arbace_c2j_emit_A_clinit_p14() { A_arbace_c2j_emit_A_const_182 = A_arbace_c2j_emit_A_const_pool.A[523]; A_arbace_c2j_emit_A_const_183 = A_arbace_c2j_emit_A_const_pool.A[524]; A_arbace_c2j_emit_A_const_184 = A_arbace_c2j_emit_A_const_pool.A[525]; A_arbace_c2j_emit_A_const_185 = A_arbace_c2j_emit_A_const_pool.A[526]; A_arbace_c2j_emit_A_const_186 = A_arbace_c2j_emit_A_const_pool.A[527]; A_arbace_c2j_emit_A_const_187 = A_arbace_c2j_emit_A_const_pool.A[528]; A_arbace_c2j_emit_A_const_188 = A_arbace_c2j_emit_A_const_pool.A[529]; A_arbace_c2j_emit_A_const_189 = A_arbace_c2j_emit_A_const_pool.A[530]; A_arbace_c2j_emit_A_const_190 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[531]); A_arbace_c2j_emit_A_const_191 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[532]); A_arbace_c2j_emit_A_const_192 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[533]); A_arbace_c2j_emit_A_const_193 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[534]); A_arbace_c2j_emit_A_const_194 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[535]); A_arbace_c2j_emit_A_const_195 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[536]) }

func A_arbace_c2j_emit_A_clinit_p15() { A_arbace_c2j_emit_A_const_196 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[537]); A_arbace_c2j_emit_A_const_197 = A_arbace_c2j_emit_A_const_pool.A[538]; A_arbace_c2j_emit_A_const_198 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[539]); A_arbace_c2j_emit_A_const_199 = A_arbace_c2j_emit_A_const_pool.A[540]; A_arbace_c2j_emit_A_const_200 = A_arbace_c2j_emit_A_const_pool.A[541]; A_arbace_c2j_emit_A_const_201 = A_arbace_c2j_emit_A_const_pool.A[542]; A_arbace_c2j_emit_A_const_202 = A_arbace_c2j_emit_A_const_pool.A[543]; A_arbace_c2j_emit_A_const_203 = A_arbace_c2j_emit_A_const_pool.A[544]; A_arbace_c2j_emit_A_const_204 = A_arbace_c2j_emit_A_const_pool.A[545]; A_arbace_c2j_emit_A_const_205 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[546]); A_arbace_c2j_emit_A_const_206 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[547]); A_arbace_c2j_emit_A_const_207 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[548]); A_arbace_c2j_emit_A_const_208 = A_arbace_c2j_emit_A_const_pool.A[549]; A_arbace_c2j_emit_A_const_209 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[550]) }

func A_arbace_c2j_emit_A_clinit_p16() { A_arbace_c2j_emit_A_const_210 = A_arbace_c2j_emit_A_const_pool.A[551]; A_arbace_c2j_emit_A_const_211 = A_arbace_c2j_emit_A_const_pool.A[552]; A_arbace_c2j_emit_A_const_212 = A_arbace_c2j_emit_A_const_pool.A[553]; A_arbace_c2j_emit_A_const_213 = A_arbace_c2j_emit_A_const_pool.A[554]; A_arbace_c2j_emit_A_const_214 = A_arbace_c2j_emit_A_const_pool.A[555]; A_arbace_c2j_emit_A_const_215 = A_arbace_c2j_emit_A_const_pool.A[556]; A_arbace_c2j_emit_A_const_216 = A_arbace_c2j_emit_A_const_pool.A[557]; A_arbace_c2j_emit_A_const_217 = A_arbace_c2j_emit_A_const_pool.A[558]; A_arbace_c2j_emit_A_const_218 = A_arbace_c2j_emit_A_const_pool.A[559]; A_arbace_c2j_emit_A_const_219 = A_arbace_c2j_emit_A_const_pool.A[560]; A_arbace_c2j_emit_A_const_220 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[561]); A_arbace_c2j_emit_A_const_221 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[562]); A_arbace_c2j_emit_A_const_222 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[563]); A_arbace_c2j_emit_A_const_223 = A_arbace_c2j_emit_A_const_pool.A[564]; A_arbace_c2j_emit_A_const_224 = A_arbace_c2j_emit_A_const_pool.A[565] }

func A_arbace_c2j_emit_A_clinit_p17() { A_arbace_c2j_emit_A_const_225 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[566]); A_arbace_c2j_emit_A_const_226 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[567]); A_arbace_c2j_emit_A_const_227 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[568]); A_arbace_c2j_emit_A_const_228 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[569]); A_arbace_c2j_emit_A_const_229 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[570]); A_arbace_c2j_emit_A_const_230 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[571]); A_arbace_c2j_emit_A_const_231 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[572]); A_arbace_c2j_emit_A_const_232 = A_arbace_c2j_emit_A_const_pool.A[573]; A_arbace_c2j_emit_A_const_233 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[574]); A_arbace_c2j_emit_A_const_234 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[575]); A_arbace_c2j_emit_A_const_235 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[576]); A_arbace_c2j_emit_A_const_236 = A_arbace_c2j_emit_A_const_pool.A[577] }

func A_arbace_c2j_emit_A_clinit_p18() { A_arbace_c2j_emit_A_const_237 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[578]); A_arbace_c2j_emit_A_const_238 = jrt.Class_Cast(A_arbace_c2j_emit_A_const_pool.A[579]); A_arbace_c2j_emit_A_const_239 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[580]); A_arbace_c2j_emit_A_const_240 = A_arbace_c2j_emit_A_const_pool.A[581]; A_arbace_c2j_emit_A_const_241 = A_arbace_c2j_emit_A_const_pool.A[582]; A_arbace_c2j_emit_A_const_242 = A_arbace_c2j_emit_A_const_pool.A[583]; A_arbace_c2j_emit_A_const_243 = A_arbace_c2j_emit_A_const_pool.A[584]; A_arbace_c2j_emit_A_const_244 = A_arbace_c2j_emit_A_const_pool.A[585]; A_arbace_c2j_emit_A_const_245 = A_arbace_c2j_emit_A_const_pool.A[586]; A_arbace_c2j_emit_A_const_246 = A_arbace_c2j_emit_A_const_pool.A[587]; A_arbace_c2j_emit_A_const_247 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[588]); A_arbace_c2j_emit_A_const_248 = A_arbace_c2j_emit_A_const_pool.A[589]; A_arbace_c2j_emit_A_const_249 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[590]); A_arbace_c2j_emit_A_const_250 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[591]) }

func A_arbace_c2j_emit_A_clinit_p19() { A_arbace_c2j_emit_A_const_251 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[592]); A_arbace_c2j_emit_A_const_252 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[593]); A_arbace_c2j_emit_A_const_253 = A_arbace_c2j_emit_A_const_pool.A[594]; A_arbace_c2j_emit_A_const_254 = A_arbace_c2j_emit_A_const_pool.A[595]; A_arbace_c2j_emit_A_const_255 = A_arbace_c2j_emit_A_const_pool.A[596]; A_arbace_c2j_emit_A_const_256 = A_arbace_c2j_emit_A_const_pool.A[597]; A_arbace_c2j_emit_A_const_257 = A_arbace_c2j_emit_A_const_pool.A[598]; A_arbace_c2j_emit_A_const_258 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[599]); A_arbace_c2j_emit_A_const_259 = A_arbace_c2j_emit_A_const_pool.A[600]; A_arbace_c2j_emit_A_const_260 = A_arbace_c2j_emit_A_const_pool.A[601]; A_arbace_c2j_emit_A_const_261 = A_arbace_c2j_emit_A_const_pool.A[602]; A_arbace_c2j_emit_A_const_262 = A_arbace_c2j_emit_A_const_pool.A[603]; A_arbace_c2j_emit_A_const_263 = A_arbace_c2j_emit_A_const_pool.A[604]; A_arbace_c2j_emit_A_const_264 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[605]) }

func A_arbace_c2j_emit_A_clinit_p20() { A_arbace_c2j_emit_A_const_265 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[606]); A_arbace_c2j_emit_A_const_266 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[607]); A_arbace_c2j_emit_A_const_267 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[608]); A_arbace_c2j_emit_A_const_268 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[609]); A_arbace_c2j_emit_A_const_269 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[610]); A_arbace_c2j_emit_A_const_270 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[611]); A_arbace_c2j_emit_A_const_271 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[612]); A_arbace_c2j_emit_A_const_272 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[613]); A_arbace_c2j_emit_A_const_273 = A_arbace_c2j_emit_A_const_pool.A[614]; A_arbace_c2j_emit_A_const_274 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[615]); A_arbace_c2j_emit_A_const_275 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[616]); A_arbace_c2j_emit_A_const_276 = A_arbace_c2j_emit_A_const_pool.A[617] }

func A_arbace_c2j_emit_A_clinit_p21() { A_arbace_c2j_emit_A_const_277 = A_arbace_c2j_emit_A_const_pool.A[618]; A_arbace_c2j_emit_A_const_278 = A_arbace_c2j_emit_A_const_pool.A[619]; A_arbace_c2j_emit_A_const_279 = A_arbace_c2j_emit_A_const_pool.A[620]; A_arbace_c2j_emit_A_const_280 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[621]); A_arbace_c2j_emit_A_const_281 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[622]); A_arbace_c2j_emit_A_const_282 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[623]); A_arbace_c2j_emit_A_const_283 = A_arbace_c2j_emit_A_const_pool.A[624]; A_arbace_c2j_emit_A_const_284 = A_arbace_c2j_emit_A_const_pool.A[625]; A_arbace_c2j_emit_A_const_285 = A_arbace_c2j_emit_A_const_pool.A[626]; A_arbace_c2j_emit_A_const_286 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[627]); A_arbace_c2j_emit_A_const_287 = A_arbace_c2j_emit_A_const_pool.A[628]; A_arbace_c2j_emit_A_const_288 = A_arbace_c2j_emit_A_const_pool.A[629]; A_arbace_c2j_emit_A_const_289 = A_arbace_c2j_emit_A_const_pool.A[630]; A_arbace_c2j_emit_A_const_290 = A_arbace_c2j_emit_A_const_pool.A[631] }

func A_arbace_c2j_emit_A_clinit_p22() { A_arbace_c2j_emit_A_const_291 = A_arbace_c2j_emit_A_const_pool.A[632]; A_arbace_c2j_emit_A_const_292 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[633]); A_arbace_c2j_emit_A_const_293 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[634]); A_arbace_c2j_emit_A_const_294 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[635]); A_arbace_c2j_emit_A_const_295 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[636]); A_arbace_c2j_emit_A_const_296 = A_arbace_c2j_emit_A_const_pool.A[637]; A_arbace_c2j_emit_A_const_297 = A_arbace_c2j_emit_A_const_pool.A[638]; A_arbace_c2j_emit_A_const_298 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[639]); A_arbace_c2j_emit_A_const_299 = A_arbace_c2j_emit_A_const_pool.A[640]; A_arbace_c2j_emit_A_const_300 = A_arbace_c2j_emit_A_const_pool.A[641]; A_arbace_c2j_emit_A_const_301 = A_arbace_c2j_emit_A_const_pool.A[642]; A_arbace_c2j_emit_A_const_302 = A_arbace_c2j_emit_A_const_pool.A[643]; A_arbace_c2j_emit_A_const_303 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[644]) }

func A_arbace_c2j_emit_A_clinit_p23() { A_arbace_c2j_emit_A_const_304 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[645]); A_arbace_c2j_emit_A_const_305 = A_arbace_c2j_emit_A_const_pool.A[646]; A_arbace_c2j_emit_A_const_306 = A_arbace_c2j_emit_A_const_pool.A[647]; A_arbace_c2j_emit_A_const_307 = A_arbace_c2j_emit_A_const_pool.A[648]; A_arbace_c2j_emit_A_const_308 = A_arbace_c2j_emit_A_const_pool.A[649]; A_arbace_c2j_emit_A_const_309 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[650]); A_arbace_c2j_emit_A_const_310 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[651]); A_arbace_c2j_emit_A_const_311 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[652]); A_arbace_c2j_emit_A_const_312 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[653]); A_arbace_c2j_emit_A_const_313 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[654]); A_arbace_c2j_emit_A_const_314 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[655]); A_arbace_c2j_emit_A_const_315 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[656]); A_arbace_c2j_emit_A_const_316 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[657]) }

func A_arbace_c2j_emit_A_clinit_p24() { A_arbace_c2j_emit_A_const_317 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[658]); A_arbace_c2j_emit_A_const_318 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[659]); A_arbace_c2j_emit_A_const_319 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[660]); A_arbace_c2j_emit_A_const_320 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[661]); A_arbace_c2j_emit_A_const_321 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[662]); A_arbace_c2j_emit_A_const_322 = A_arbace_c2j_emit_A_const_pool.A[663]; A_arbace_c2j_emit_A_const_323 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[664]); A_arbace_c2j_emit_A_const_324 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[665]); A_arbace_c2j_emit_A_const_325 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[666]); A_arbace_c2j_emit_A_const_326 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[667]); A_arbace_c2j_emit_A_const_327 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[668]); A_arbace_c2j_emit_A_const_328 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[669]) }

func A_arbace_c2j_emit_A_clinit_p25() { A_arbace_c2j_emit_A_const_329 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[670]); A_arbace_c2j_emit_A_const_330 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[671]); A_arbace_c2j_emit_A_const_331 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[672]); A_arbace_c2j_emit_A_const_332 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[673]); A_arbace_c2j_emit_A_const_333 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[674]); A_arbace_c2j_emit_A_const_334 = A_arbace_c2j_emit_A_const_pool.A[675]; A_arbace_c2j_emit_A_const_335 = A_arbace_c2j_emit_A_const_pool.A[676]; A_arbace_c2j_emit_A_const_336 = A_arbace_c2j_emit_A_const_pool.A[677]; A_arbace_c2j_emit_A_const_337 = A_arbace_c2j_emit_A_const_pool.A[678]; A_arbace_c2j_emit_A_const_338 = A_arbace_c2j_emit_A_const_pool.A[679]; A_arbace_c2j_emit_A_const_339 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[680]); A_arbace_c2j_emit_A_const_340 = A_arbace_c2j_emit_A_const_pool.A[681]; A_arbace_c2j_emit_A_const_341 = A_arbace_c2j_emit_A_const_pool.A[682] }

func A_arbace_c2j_emit_A_clinit_p26() { A_arbace_c2j_emit_A_const_342 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[683]); A_arbace_c2j_emit_A_const_343 = A_arbace_c2j_emit_A_const_pool.A[684]; A_arbace_c2j_emit_A_const_344 = A_arbace_c2j_emit_A_const_pool.A[685]; A_arbace_c2j_emit_A_const_345 = A_arbace_c2j_emit_A_const_pool.A[686]; A_arbace_c2j_emit_A_const_346 = A_arbace_c2j_emit_A_const_pool.A[687]; A_arbace_c2j_emit_A_const_347 = A_arbace_c2j_emit_A_const_pool.A[688]; A_arbace_c2j_emit_A_const_348 = A_arbace_c2j_emit_A_const_pool.A[689]; A_arbace_c2j_emit_A_const_349 = A_arbace_c2j_emit_A_const_pool.A[690]; A_arbace_c2j_emit_A_const_350 = A_arbace_c2j_emit_A_const_pool.A[691]; A_arbace_c2j_emit_A_const_351 = A_arbace_c2j_emit_A_const_pool.A[692]; A_arbace_c2j_emit_A_const_352 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[693]); A_arbace_c2j_emit_A_const_353 = A_arbace_c2j_emit_A_const_pool.A[694]; A_arbace_c2j_emit_A_const_354 = A_arbace_c2j_emit_A_const_pool.A[695]; A_arbace_c2j_emit_A_const_355 = A_arbace_c2j_emit_A_const_pool.A[696]; A_arbace_c2j_emit_A_const_356 = A_arbace_c2j_emit_A_const_pool.A[697] }

func A_arbace_c2j_emit_A_clinit_p27() { A_arbace_c2j_emit_A_const_357 = A_arbace_c2j_emit_A_const_pool.A[698]; A_arbace_c2j_emit_A_const_358 = A_arbace_c2j_emit_A_const_pool.A[699]; A_arbace_c2j_emit_A_const_359 = A_arbace_c2j_emit_A_const_pool.A[700]; A_arbace_c2j_emit_A_const_360 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[701]); A_arbace_c2j_emit_A_const_361 = A_arbace_c2j_emit_A_const_pool.A[702]; A_arbace_c2j_emit_A_const_362 = A_arbace_c2j_emit_A_const_pool.A[703]; A_arbace_c2j_emit_A_const_363 = A_arbace_c2j_emit_A_const_pool.A[704]; A_arbace_c2j_emit_A_const_364 = A_arbace_c2j_emit_A_const_pool.A[705]; A_arbace_c2j_emit_A_const_365 = A_arbace_c2j_emit_A_const_pool.A[706]; A_arbace_c2j_emit_A_const_366 = A_arbace_c2j_emit_A_const_pool.A[707]; A_arbace_c2j_emit_A_const_367 = A_arbace_c2j_emit_A_const_pool.A[708]; A_arbace_c2j_emit_A_const_368 = A_arbace_c2j_emit_A_const_pool.A[709]; A_arbace_c2j_emit_A_const_369 = A_arbace_c2j_emit_A_const_pool.A[710]; A_arbace_c2j_emit_A_const_370 = A_arbace_c2j_emit_A_const_pool.A[711]; A_arbace_c2j_emit_A_const_371 = A_arbace_c2j_emit_A_const_pool.A[712] }

func A_arbace_c2j_emit_A_clinit_p28() { A_arbace_c2j_emit_A_const_372 = A_arbace_c2j_emit_A_const_pool.A[713]; A_arbace_c2j_emit_A_const_373 = A_arbace_c2j_emit_A_const_pool.A[714]; A_arbace_c2j_emit_A_const_374 = A_arbace_c2j_emit_A_const_pool.A[715]; A_arbace_c2j_emit_A_const_375 = A_arbace_c2j_emit_A_const_pool.A[716]; A_arbace_c2j_emit_A_const_376 = A_arbace_c2j_emit_A_const_pool.A[717]; A_arbace_c2j_emit_A_const_377 = A_arbace_c2j_emit_A_const_pool.A[718]; A_arbace_c2j_emit_A_const_378 = A_arbace_c2j_emit_A_const_pool.A[719]; A_arbace_c2j_emit_A_const_379 = A_arbace_c2j_emit_A_const_pool.A[720]; A_arbace_c2j_emit_A_const_380 = A_arbace_c2j_emit_A_const_pool.A[721]; A_arbace_c2j_emit_A_const_381 = A_arbace_c2j_emit_A_const_pool.A[722]; A_arbace_c2j_emit_A_const_382 = A_arbace_c2j_emit_A_const_pool.A[723]; A_arbace_c2j_emit_A_const_383 = A_arbace_c2j_emit_A_const_pool.A[724]; A_arbace_c2j_emit_A_const_384 = A_arbace_c2j_emit_A_const_pool.A[725]; A_arbace_c2j_emit_A_const_385 = A_arbace_c2j_emit_A_const_pool.A[726]; A_arbace_c2j_emit_A_const_386 = A_arbace_c2j_emit_A_const_pool.A[727]; A_arbace_c2j_emit_A_const_387 = A_arbace_c2j_emit_A_const_pool.A[728] }

func A_arbace_c2j_emit_A_clinit_p29() { A_arbace_c2j_emit_A_const_388 = A_arbace_c2j_emit_A_const_pool.A[729]; A_arbace_c2j_emit_A_const_389 = A_arbace_c2j_emit_A_const_pool.A[730]; A_arbace_c2j_emit_A_const_390 = A_arbace_c2j_emit_A_const_pool.A[731]; A_arbace_c2j_emit_A_const_391 = A_arbace_c2j_emit_A_const_pool.A[732]; A_arbace_c2j_emit_A_const_392 = A_arbace_c2j_emit_A_const_pool.A[733]; A_arbace_c2j_emit_A_const_393 = A_arbace_c2j_emit_A_const_pool.A[734]; A_arbace_c2j_emit_A_const_394 = A_arbace_c2j_emit_A_const_pool.A[735]; A_arbace_c2j_emit_A_const_395 = A_arbace_c2j_emit_A_const_pool.A[736]; A_arbace_c2j_emit_A_const_396 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[737]); A_arbace_c2j_emit_A_const_397 = A_arbace_c2j_emit_A_const_pool.A[738]; A_arbace_c2j_emit_A_const_398 = A_arbace_c2j_emit_A_const_pool.A[739]; A_arbace_c2j_emit_A_const_399 = A_arbace_c2j_emit_A_const_pool.A[740]; A_arbace_c2j_emit_A_const_400 = A_arbace_c2j_emit_A_const_pool.A[741]; A_arbace_c2j_emit_A_const_401 = A_arbace_c2j_emit_A_const_pool.A[742]; A_arbace_c2j_emit_A_const_402 = A_arbace_c2j_emit_A_const_pool.A[743] }

func A_arbace_c2j_emit_A_clinit_p30() { A_arbace_c2j_emit_A_const_403 = A_arbace_c2j_emit_A_const_pool.A[744]; A_arbace_c2j_emit_A_const_404 = A_arbace_c2j_emit_A_const_pool.A[745]; A_arbace_c2j_emit_A_const_405 = A_arbace_c2j_emit_A_const_pool.A[746]; A_arbace_c2j_emit_A_const_406 = A_arbace_c2j_emit_A_const_pool.A[747]; A_arbace_c2j_emit_A_const_407 = A_arbace_c2j_emit_A_const_pool.A[748]; A_arbace_c2j_emit_A_const_408 = A_arbace_c2j_emit_A_const_pool.A[749]; A_arbace_c2j_emit_A_const_409 = A_arbace_c2j_emit_A_const_pool.A[750]; A_arbace_c2j_emit_A_const_410 = A_arbace_c2j_emit_A_const_pool.A[751]; A_arbace_c2j_emit_A_const_411 = A_arbace_c2j_emit_A_const_pool.A[752]; A_arbace_c2j_emit_A_const_412 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[753]); A_arbace_c2j_emit_A_const_413 = A_arbace_c2j_emit_A_const_pool.A[754]; A_arbace_c2j_emit_A_const_414 = A_arbace_c2j_emit_A_const_pool.A[755]; A_arbace_c2j_emit_A_const_415 = A_arbace_c2j_emit_A_const_pool.A[756]; A_arbace_c2j_emit_A_const_416 = A_arbace_c2j_emit_A_const_pool.A[757]; A_arbace_c2j_emit_A_const_417 = A_arbace_c2j_emit_A_const_pool.A[758] }

func A_arbace_c2j_emit_A_clinit_p31() { A_arbace_c2j_emit_A_const_418 = A_arbace_c2j_emit_A_const_pool.A[759]; A_arbace_c2j_emit_A_const_419 = A_arbace_c2j_emit_A_const_pool.A[760]; A_arbace_c2j_emit_A_const_420 = A_arbace_c2j_emit_A_const_pool.A[761]; A_arbace_c2j_emit_A_const_421 = A_arbace_c2j_emit_A_const_pool.A[762]; A_arbace_c2j_emit_A_const_422 = A_arbace_c2j_emit_A_const_pool.A[763]; A_arbace_c2j_emit_A_const_423 = A_arbace_c2j_emit_A_const_pool.A[764]; A_arbace_c2j_emit_A_const_424 = A_arbace_c2j_emit_A_const_pool.A[765]; A_arbace_c2j_emit_A_const_425 = A_arbace_c2j_emit_A_const_pool.A[766]; A_arbace_c2j_emit_A_const_426 = A_arbace_c2j_emit_A_const_pool.A[767]; A_arbace_c2j_emit_A_const_427 = A_arbace_c2j_emit_A_const_pool.A[768]; A_arbace_c2j_emit_A_const_428 = A_arbace_c2j_emit_A_const_pool.A[769]; A_arbace_c2j_emit_A_const_429 = jrt.Class_Cast(A_arbace_c2j_emit_A_const_pool.A[770]); A_arbace_c2j_emit_A_const_430 = A_arbace_c2j_emit_A_const_pool.A[771]; A_arbace_c2j_emit_A_const_431 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[772]); A_arbace_c2j_emit_A_const_432 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[773]) }

func A_arbace_c2j_emit_A_clinit_p32() { A_arbace_c2j_emit_A_const_433 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[774]); A_arbace_c2j_emit_A_const_434 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[775]); A_arbace_c2j_emit_A_const_435 = A_arbace_c2j_emit_A_const_pool.A[776]; A_arbace_c2j_emit_A_const_436 = A_arbace_c2j_emit_A_const_pool.A[777]; A_arbace_c2j_emit_A_const_437 = A_arbace_c2j_emit_A_const_pool.A[778]; A_arbace_c2j_emit_A_const_438 = A_arbace_c2j_emit_A_const_pool.A[779]; A_arbace_c2j_emit_A_const_439 = A_arbace_c2j_emit_A_const_pool.A[780]; A_arbace_c2j_emit_A_const_440 = A_arbace_c2j_emit_A_const_pool.A[781]; A_arbace_c2j_emit_A_const_441 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[782]); A_arbace_c2j_emit_A_const_442 = A_arbace_c2j_emit_A_const_pool.A[783]; A_arbace_c2j_emit_A_const_443 = A_arbace_c2j_emit_A_const_pool.A[784]; A_arbace_c2j_emit_A_const_444 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[785]); A_arbace_c2j_emit_A_const_445 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[786]); A_arbace_c2j_emit_A_const_446 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[787]) }

func A_arbace_c2j_emit_A_clinit_p33() { A_arbace_c2j_emit_A_const_447 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[788]); A_arbace_c2j_emit_A_const_448 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[789]); A_arbace_c2j_emit_A_const_449 = A_arbace_c2j_emit_A_const_pool.A[790]; A_arbace_c2j_emit_A_const_450 = A_arbace_c2j_emit_A_const_pool.A[791]; A_arbace_c2j_emit_A_const_451 = A_arbace_c2j_emit_A_const_pool.A[792]; A_arbace_c2j_emit_A_const_452 = A_arbace_c2j_emit_A_const_pool.A[793]; A_arbace_c2j_emit_A_const_453 = A_arbace_c2j_emit_A_const_pool.A[794]; A_arbace_c2j_emit_A_const_454 = A_arbace_c2j_emit_A_const_pool.A[795]; A_arbace_c2j_emit_A_const_455 = A_arbace_c2j_emit_A_const_pool.A[796]; A_arbace_c2j_emit_A_const_456 = A_arbace_c2j_emit_A_const_pool.A[797]; A_arbace_c2j_emit_A_const_457 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[798]); A_arbace_c2j_emit_A_const_458 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[799]); A_arbace_c2j_emit_A_const_459 = A_arbace_c2j_emit_A_const_pool.A[800]; A_arbace_c2j_emit_A_const_460 = A_arbace_c2j_emit_A_const_pool.A[801] }

func A_arbace_c2j_emit_A_clinit_p34() { A_arbace_c2j_emit_A_const_461 = A_arbace_c2j_emit_A_const_pool.A[802]; A_arbace_c2j_emit_A_const_462 = A_arbace_c2j_emit_A_const_pool.A[803]; A_arbace_c2j_emit_A_const_463 = A_arbace_c2j_emit_A_const_pool.A[804]; A_arbace_c2j_emit_A_const_464 = A_arbace_c2j_emit_A_const_pool.A[805]; A_arbace_c2j_emit_A_const_465 = A_arbace_c2j_emit_A_const_pool.A[806]; A_arbace_c2j_emit_A_const_466 = A_arbace_c2j_emit_A_const_pool.A[807]; A_arbace_c2j_emit_A_const_467 = A_arbace_c2j_emit_A_const_pool.A[808]; A_arbace_c2j_emit_A_const_468 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[809]); A_arbace_c2j_emit_A_const_469 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[810]); A_arbace_c2j_emit_A_const_470 = A_arbace_c2j_emit_A_const_pool.A[811]; A_arbace_c2j_emit_A_const_471 = A_arbace_c2j_emit_A_const_pool.A[812]; A_arbace_c2j_emit_A_const_472 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[813]); A_arbace_c2j_emit_A_const_473 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[814]); A_arbace_c2j_emit_A_const_474 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[815]) }

func A_arbace_c2j_emit_A_clinit_p35() { A_arbace_c2j_emit_A_const_475 = A_arbace_c2j_emit_A_const_pool.A[816]; A_arbace_c2j_emit_A_const_476 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[817]); A_arbace_c2j_emit_A_const_477 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[818]); A_arbace_c2j_emit_A_const_478 = A_arbace_c2j_emit_A_const_pool.A[819]; A_arbace_c2j_emit_A_const_479 = A_arbace_c2j_emit_A_const_pool.A[820]; A_arbace_c2j_emit_A_const_480 = A_arbace_c2j_emit_A_const_pool.A[821]; A_arbace_c2j_emit_A_const_481 = A_arbace_c2j_emit_A_const_pool.A[822]; A_arbace_c2j_emit_A_const_482 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[823]); A_arbace_c2j_emit_A_const_483 = A_arbace_c2j_emit_A_const_pool.A[824]; A_arbace_c2j_emit_A_const_484 = A_arbace_c2j_emit_A_const_pool.A[825]; A_arbace_c2j_emit_A_const_485 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[826]); A_arbace_c2j_emit_A_const_486 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[827]); A_arbace_c2j_emit_A_const_487 = A_arbace_c2j_emit_A_const_pool.A[828]; A_arbace_c2j_emit_A_const_488 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[829]) }

func A_arbace_c2j_emit_A_clinit_p36() { A_arbace_c2j_emit_A_const_489 = A_arbace_c2j_emit_A_const_pool.A[830]; A_arbace_c2j_emit_A_const_490 = A_arbace_c2j_emit_A_const_pool.A[831]; A_arbace_c2j_emit_A_const_491 = A_arbace_c2j_emit_A_const_pool.A[832]; A_arbace_c2j_emit_A_const_492 = A_arbace_c2j_emit_A_const_pool.A[833]; A_arbace_c2j_emit_A_const_493 = A_arbace_c2j_emit_A_const_pool.A[834]; A_arbace_c2j_emit_A_const_494 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[835]); A_arbace_c2j_emit_A_const_495 = A_arbace_c2j_emit_A_const_pool.A[836]; A_arbace_c2j_emit_A_const_496 = A_arbace_c2j_emit_A_const_pool.A[837]; A_arbace_c2j_emit_A_const_497 = A_arbace_c2j_emit_A_const_pool.A[838]; A_arbace_c2j_emit_A_const_498 = A_arbace_c2j_emit_A_const_pool.A[839]; A_arbace_c2j_emit_A_const_499 = A_arbace_c2j_emit_A_const_pool.A[840]; A_arbace_c2j_emit_A_const_500 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[841]); A_arbace_c2j_emit_A_const_501 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[842]); A_arbace_c2j_emit_A_const_502 = A_arbace_c2j_emit_A_const_pool.A[843]; A_arbace_c2j_emit_A_const_503 = A_arbace_c2j_emit_A_const_pool.A[844] }

func A_arbace_c2j_emit_A_clinit_p37() { A_arbace_c2j_emit_A_const_504 = A_arbace_c2j_emit_A_const_pool.A[845]; A_arbace_c2j_emit_A_const_505 = A_arbace_c2j_emit_A_const_pool.A[846]; A_arbace_c2j_emit_A_const_506 = A_arbace_c2j_emit_A_const_pool.A[847]; A_arbace_c2j_emit_A_const_507 = A_arbace_c2j_emit_A_const_pool.A[848]; A_arbace_c2j_emit_A_const_508 = A_arbace_c2j_emit_A_const_pool.A[849]; A_arbace_c2j_emit_A_const_509 = A_arbace_c2j_emit_A_const_pool.A[850]; A_arbace_c2j_emit_A_const_510 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[851]); A_arbace_c2j_emit_A_const_511 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[852]); A_arbace_c2j_emit_A_const_512 = A_arbace_c2j_emit_A_const_pool.A[853]; A_arbace_c2j_emit_A_const_513 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[854]); A_arbace_c2j_emit_A_const_514 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[855]); A_arbace_c2j_emit_A_const_515 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[856]); A_arbace_c2j_emit_A_const_516 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[857]) }

func A_arbace_c2j_emit_A_clinit_p38() { A_arbace_c2j_emit_A_const_517 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[858]); A_arbace_c2j_emit_A_const_518 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[859]); A_arbace_c2j_emit_A_const_519 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[860]); A_arbace_c2j_emit_A_const_520 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[861]); A_arbace_c2j_emit_A_const_521 = A_arbace_c2j_emit_A_const_pool.A[862]; A_arbace_c2j_emit_A_const_522 = A_arbace_c2j_emit_A_const_pool.A[863]; A_arbace_c2j_emit_A_const_523 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[864]); A_arbace_c2j_emit_A_const_524 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[865]); A_arbace_c2j_emit_A_const_525 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[866]); A_arbace_c2j_emit_A_const_526 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[867]); A_arbace_c2j_emit_A_const_527 = A_arbace_c2j_emit_A_const_pool.A[868]; A_arbace_c2j_emit_A_const_528 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[869]); A_arbace_c2j_emit_A_const_529 = A_arbace_c2j_emit_A_const_pool.A[870] }

func A_arbace_c2j_emit_A_clinit_p39() { A_arbace_c2j_emit_A_const_530 = A_arbace_c2j_emit_A_const_pool.A[871]; A_arbace_c2j_emit_A_const_531 = A_arbace_c2j_emit_A_const_pool.A[872]; A_arbace_c2j_emit_A_const_532 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[873]); A_arbace_c2j_emit_A_const_533 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[874]); A_arbace_c2j_emit_A_const_534 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[875]); A_arbace_c2j_emit_A_const_535 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[876]); A_arbace_c2j_emit_A_const_536 = A_arbace_c2j_emit_A_const_pool.A[877]; A_arbace_c2j_emit_A_const_537 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[878]); A_arbace_c2j_emit_A_const_538 = A_arbace_c2j_emit_A_const_pool.A[879]; A_arbace_c2j_emit_A_const_539 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[880]); A_arbace_c2j_emit_A_const_540 = A_arbace_c2j_emit_A_const_pool.A[881]; A_arbace_c2j_emit_A_const_541 = A_arbace_c2j_emit_A_const_pool.A[882]; A_arbace_c2j_emit_A_const_542 = A_arbace_c2j_emit_A_const_pool.A[883]; A_arbace_c2j_emit_A_const_543 = A_arbace_c2j_emit_A_const_pool.A[884] }

func A_arbace_c2j_emit_A_clinit_p40() { A_arbace_c2j_emit_A_const_544 = A_arbace_c2j_emit_A_const_pool.A[885]; A_arbace_c2j_emit_A_const_545 = A_arbace_c2j_emit_A_const_pool.A[886]; A_arbace_c2j_emit_A_const_546 = A_arbace_c2j_emit_A_const_pool.A[887]; A_arbace_c2j_emit_A_const_547 = A_arbace_c2j_emit_A_const_pool.A[888]; A_arbace_c2j_emit_A_const_548 = A_arbace_c2j_emit_A_const_pool.A[889]; A_arbace_c2j_emit_A_const_549 = A_arbace_c2j_emit_A_const_pool.A[890]; A_arbace_c2j_emit_A_const_550 = A_arbace_c2j_emit_A_const_pool.A[891]; A_arbace_c2j_emit_A_const_551 = A_arbace_c2j_emit_A_const_pool.A[892]; A_arbace_c2j_emit_A_const_552 = A_arbace_c2j_emit_A_const_pool.A[893]; A_arbace_c2j_emit_A_const_553 = A_arbace_c2j_emit_A_const_pool.A[894]; A_arbace_c2j_emit_A_const_554 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[895]); A_arbace_c2j_emit_A_const_555 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[896]); A_arbace_c2j_emit_A_const_556 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[897]); A_arbace_c2j_emit_A_const_557 = A_arbace_c2j_emit_A_const_pool.A[898]; A_arbace_c2j_emit_A_const_558 = A_arbace_c2j_emit_A_const_pool.A[899] }

func A_arbace_c2j_emit_A_clinit_p41() { A_arbace_c2j_emit_A_const_559 = A_arbace_c2j_emit_A_const_pool.A[900]; A_arbace_c2j_emit_A_const_560 = A_arbace_c2j_emit_A_const_pool.A[901]; A_arbace_c2j_emit_A_const_561 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[902]); A_arbace_c2j_emit_A_const_562 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[903]); A_arbace_c2j_emit_A_const_563 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[904]); A_arbace_c2j_emit_A_const_564 = A_arbace_c2j_emit_A_const_pool.A[905]; A_arbace_c2j_emit_A_const_565 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[906]); A_arbace_c2j_emit_A_const_566 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[907]); A_arbace_c2j_emit_A_const_567 = A_arbace_c2j_emit_A_const_pool.A[908]; A_arbace_c2j_emit_A_const_568 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[909]); A_arbace_c2j_emit_A_const_569 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[910]); A_arbace_c2j_emit_A_const_570 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[911]); A_arbace_c2j_emit_A_const_571 = A_arbace_c2j_emit_A_const_pool.A[912] }

func A_arbace_c2j_emit_A_clinit_p42() { A_arbace_c2j_emit_A_const_572 = A_arbace_c2j_emit_A_const_pool.A[913]; A_arbace_c2j_emit_A_const_573 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[914]); A_arbace_c2j_emit_A_const_574 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[915]); A_arbace_c2j_emit_A_const_575 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[916]); A_arbace_c2j_emit_A_const_576 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[917]); A_arbace_c2j_emit_A_const_577 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[918]); A_arbace_c2j_emit_A_const_578 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[919]); A_arbace_c2j_emit_A_const_579 = A_arbace_c2j_emit_A_const_pool.A[920]; A_arbace_c2j_emit_A_const_580 = A_arbace_c2j_emit_A_const_pool.A[921]; A_arbace_c2j_emit_A_const_581 = A_arbace_c2j_emit_A_const_pool.A[922]; A_arbace_c2j_emit_A_const_582 = A_arbace_c2j_emit_A_const_pool.A[923]; A_arbace_c2j_emit_A_const_583 = A_arbace_c2j_emit_A_const_pool.A[924]; A_arbace_c2j_emit_A_const_584 = A_arbace_c2j_emit_A_const_pool.A[925]; A_arbace_c2j_emit_A_const_585 = A_arbace_c2j_emit_A_const_pool.A[926] }

func A_arbace_c2j_emit_A_clinit_p43() { A_arbace_c2j_emit_A_const_586 = A_arbace_c2j_emit_A_const_pool.A[927]; A_arbace_c2j_emit_A_const_587 = A_arbace_c2j_emit_A_const_pool.A[928]; A_arbace_c2j_emit_A_const_588 = A_arbace_c2j_emit_A_const_pool.A[929]; A_arbace_c2j_emit_A_const_589 = A_arbace_c2j_emit_A_const_pool.A[930]; A_arbace_c2j_emit_A_const_590 = A_arbace_c2j_emit_A_const_pool.A[931]; A_arbace_c2j_emit_A_const_591 = A_arbace_c2j_emit_A_const_pool.A[932]; A_arbace_c2j_emit_A_const_592 = A_arbace_c2j_emit_A_const_pool.A[933]; A_arbace_c2j_emit_A_const_593 = A_arbace_c2j_emit_A_const_pool.A[934]; A_arbace_c2j_emit_A_const_594 = A_arbace_c2j_emit_A_const_pool.A[935]; A_arbace_c2j_emit_A_const_595 = A_arbace_c2j_emit_A_const_pool.A[936]; A_arbace_c2j_emit_A_const_596 = A_arbace_c2j_emit_A_const_pool.A[937]; A_arbace_c2j_emit_A_const_597 = A_arbace_c2j_emit_A_const_pool.A[938]; A_arbace_c2j_emit_A_const_598 = A_arbace_c2j_emit_A_const_pool.A[939]; A_arbace_c2j_emit_A_const_599 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[940]); A_arbace_c2j_emit_A_const_600 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[941]) }

func A_arbace_c2j_emit_A_clinit_p44() { A_arbace_c2j_emit_A_const_601 = A_arbace_c2j_emit_A_const_pool.A[942]; A_arbace_c2j_emit_A_const_602 = A_arbace_c2j_emit_A_const_pool.A[943]; A_arbace_c2j_emit_A_const_603 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[944]); A_arbace_c2j_emit_A_const_604 = A_arbace_c2j_emit_A_const_pool.A[945]; A_arbace_c2j_emit_A_const_605 = A_arbace_c2j_emit_A_const_pool.A[946]; A_arbace_c2j_emit_A_const_606 = A_arbace_c2j_emit_A_const_pool.A[947]; A_arbace_c2j_emit_A_const_607 = A_arbace_c2j_emit_A_const_pool.A[948]; A_arbace_c2j_emit_A_const_608 = A_arbace_c2j_emit_A_const_pool.A[949]; A_arbace_c2j_emit_A_const_609 = A_arbace_c2j_emit_A_const_pool.A[950]; A_arbace_c2j_emit_A_const_610 = A_arbace_c2j_emit_A_const_pool.A[951]; A_arbace_c2j_emit_A_const_611 = A_arbace_c2j_emit_A_const_pool.A[952]; A_arbace_c2j_emit_A_const_612 = A_arbace_c2j_emit_A_const_pool.A[953]; A_arbace_c2j_emit_A_const_613 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[954]); A_arbace_c2j_emit_A_const_614 = A_arbace_c2j_emit_A_const_pool.A[955]; A_arbace_c2j_emit_A_const_615 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[956]) }

func A_arbace_c2j_emit_A_clinit_p45() { A_arbace_c2j_emit_A_const_616 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[957]); A_arbace_c2j_emit_A_const_617 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[958]); A_arbace_c2j_emit_A_const_618 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[959]); A_arbace_c2j_emit_A_const_619 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[960]); A_arbace_c2j_emit_A_const_620 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[961]); A_arbace_c2j_emit_A_const_621 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[962]); A_arbace_c2j_emit_A_const_622 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[963]); A_arbace_c2j_emit_A_const_623 = A_arbace_c2j_emit_A_const_pool.A[964]; A_arbace_c2j_emit_A_const_624 = A_arbace_c2j_emit_A_const_pool.A[965]; A_arbace_c2j_emit_A_const_625 = A_arbace_c2j_emit_A_const_pool.A[966]; A_arbace_c2j_emit_A_const_626 = A_arbace_c2j_emit_A_const_pool.A[967]; A_arbace_c2j_emit_A_const_627 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[968]); A_arbace_c2j_emit_A_const_628 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[969]) }

func A_arbace_c2j_emit_A_clinit_p46() { A_arbace_c2j_emit_A_const_629 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[970]); A_arbace_c2j_emit_A_const_630 = A_arbace_c2j_emit_A_const_pool.A[971]; A_arbace_c2j_emit_A_const_631 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[972]); A_arbace_c2j_emit_A_const_632 = A_arbace_c2j_emit_A_const_pool.A[973]; A_arbace_c2j_emit_A_const_633 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[974]); A_arbace_c2j_emit_A_const_634 = A_arbace_c2j_emit_A_const_pool.A[975]; A_arbace_c2j_emit_A_const_635 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[976]); A_arbace_c2j_emit_A_const_636 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[977]); A_arbace_c2j_emit_A_const_637 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[978]); A_arbace_c2j_emit_A_const_638 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[979]); A_arbace_c2j_emit_A_const_639 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[980]); A_arbace_c2j_emit_A_const_640 = A_arbace_c2j_emit_A_const_pool.A[981]; A_arbace_c2j_emit_A_const_641 = A_arbace_c2j_emit_A_const_pool.A[982] }

func A_arbace_c2j_emit_A_clinit_p47() { A_arbace_c2j_emit_A_const_642 = A_arbace_c2j_emit_A_const_pool.A[983]; A_arbace_c2j_emit_A_const_643 = A_arbace_c2j_emit_A_const_pool.A[984]; A_arbace_c2j_emit_A_const_644 = A_arbace_c2j_emit_A_const_pool.A[985]; A_arbace_c2j_emit_A_const_645 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[986]); A_arbace_c2j_emit_A_const_646 = A_arbace_c2j_emit_A_const_pool.A[987]; A_arbace_c2j_emit_A_const_647 = A_arbace_c2j_emit_A_const_pool.A[988]; A_arbace_c2j_emit_A_const_648 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[989]); A_arbace_c2j_emit_A_const_649 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[990]); A_arbace_c2j_emit_A_const_650 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[991]); A_arbace_c2j_emit_A_const_651 = A_arbace_c2j_emit_A_const_pool.A[992]; A_arbace_c2j_emit_A_const_652 = A_arbace_c2j_emit_A_const_pool.A[993]; A_arbace_c2j_emit_A_const_653 = A_arbace_c2j_emit_A_const_pool.A[994]; A_arbace_c2j_emit_A_const_654 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[995]); A_arbace_c2j_emit_A_const_655 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[996]) }

func A_arbace_c2j_emit_A_clinit_p48() { A_arbace_c2j_emit_A_const_656 = A_arbace_c2j_emit_A_const_pool.A[997]; A_arbace_c2j_emit_A_const_657 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[998]); A_arbace_c2j_emit_A_const_658 = A_arbace_c2j_emit_A_const_pool.A[999]; A_arbace_c2j_emit_A_const_659 = A_arbace_c2j_emit_A_const_pool.A[1000]; A_arbace_c2j_emit_A_const_660 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1001]); A_arbace_c2j_emit_A_const_661 = A_arbace_c2j_emit_A_const_pool.A[1002]; A_arbace_c2j_emit_A_const_662 = A_arbace_c2j_emit_A_const_pool.A[1003]; A_arbace_c2j_emit_A_const_663 = A_arbace_c2j_emit_A_const_pool.A[1004]; A_arbace_c2j_emit_A_const_664 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1005]); A_arbace_c2j_emit_A_const_665 = A_arbace_c2j_emit_A_const_pool.A[1006]; A_arbace_c2j_emit_A_const_666 = A_arbace_c2j_emit_A_const_pool.A[1007]; A_arbace_c2j_emit_A_const_667 = A_arbace_c2j_emit_A_const_pool.A[1008]; A_arbace_c2j_emit_A_const_668 = A_arbace_c2j_emit_A_const_pool.A[1009]; A_arbace_c2j_emit_A_const_669 = A_arbace_c2j_emit_A_const_pool.A[1010]; A_arbace_c2j_emit_A_const_670 = A_arbace_c2j_emit_A_const_pool.A[1011] }

func A_arbace_c2j_emit_A_clinit_p49() { A_arbace_c2j_emit_A_const_671 = A_arbace_c2j_emit_A_const_pool.A[1012]; A_arbace_c2j_emit_A_const_672 = A_arbace_c2j_emit_A_const_pool.A[1013]; A_arbace_c2j_emit_A_const_673 = A_arbace_c2j_emit_A_const_pool.A[1014]; A_arbace_c2j_emit_A_const_674 = A_arbace_c2j_emit_A_const_pool.A[1015]; A_arbace_c2j_emit_A_const_675 = A_arbace_c2j_emit_A_const_pool.A[1016]; A_arbace_c2j_emit_A_const_676 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1017]); A_arbace_c2j_emit_A_const_677 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1018]); A_arbace_c2j_emit_A_const_678 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1019]); A_arbace_c2j_emit_A_const_679 = A_arbace_c2j_emit_A_const_pool.A[1020]; A_arbace_c2j_emit_A_const_680 = A_arbace_c2j_emit_A_const_pool.A[1021]; A_arbace_c2j_emit_A_const_681 = A_arbace_c2j_emit_A_const_pool.A[1022]; A_arbace_c2j_emit_A_const_682 = A_arbace_c2j_emit_A_const_pool.A[1023]; A_arbace_c2j_emit_A_const_683 = A_arbace_c2j_emit_A_const_pool.A[1024]; A_arbace_c2j_emit_A_const_684 = A_arbace_c2j_emit_A_const_pool.A[1025] }

func A_arbace_c2j_emit_A_clinit_p50() { A_arbace_c2j_emit_A_const_685 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1026]); A_arbace_c2j_emit_A_const_686 = A_arbace_c2j_emit_A_const_pool.A[1027]; A_arbace_c2j_emit_A_const_687 = A_arbace_c2j_emit_A_const_pool.A[1028]; A_arbace_c2j_emit_A_const_688 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1029]); A_arbace_c2j_emit_A_const_689 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1030]); A_arbace_c2j_emit_A_const_690 = A_arbace_c2j_emit_A_const_pool.A[1031]; A_arbace_c2j_emit_A_const_691 = A_arbace_c2j_emit_A_const_pool.A[1032]; A_arbace_c2j_emit_A_const_692 = A_arbace_c2j_emit_A_const_pool.A[1033]; A_arbace_c2j_emit_A_const_693 = A_arbace_c2j_emit_A_const_pool.A[1034]; A_arbace_c2j_emit_A_const_694 = A_arbace_c2j_emit_A_const_pool.A[1035]; A_arbace_c2j_emit_A_const_695 = A_arbace_c2j_emit_A_const_pool.A[1036]; A_arbace_c2j_emit_A_const_696 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1037]); A_arbace_c2j_emit_A_const_697 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1038]); A_arbace_c2j_emit_A_const_698 = A_arbace_c2j_emit_A_const_pool.A[1039] }

func A_arbace_c2j_emit_A_clinit_p51() { A_arbace_c2j_emit_A_const_699 = A_arbace_c2j_emit_A_const_pool.A[1040]; A_arbace_c2j_emit_A_const_700 = A_arbace_c2j_emit_A_const_pool.A[1041]; A_arbace_c2j_emit_A_const_701 = A_arbace_c2j_emit_A_const_pool.A[1042]; A_arbace_c2j_emit_A_const_702 = A_arbace_c2j_emit_A_const_pool.A[1043]; A_arbace_c2j_emit_A_const_703 = A_arbace_c2j_emit_A_const_pool.A[1044]; A_arbace_c2j_emit_A_const_704 = A_arbace_c2j_emit_A_const_pool.A[1045]; A_arbace_c2j_emit_A_const_705 = A_arbace_c2j_emit_A_const_pool.A[1046]; A_arbace_c2j_emit_A_const_706 = A_arbace_c2j_emit_A_const_pool.A[1047]; A_arbace_c2j_emit_A_const_707 = A_arbace_c2j_emit_A_const_pool.A[1048]; A_arbace_c2j_emit_A_const_708 = A_arbace_c2j_emit_A_const_pool.A[1049]; A_arbace_c2j_emit_A_const_709 = A_arbace_c2j_emit_A_const_pool.A[1050]; A_arbace_c2j_emit_A_const_710 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1051]); A_arbace_c2j_emit_A_const_711 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1052]); A_arbace_c2j_emit_A_const_712 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1053]) }

func A_arbace_c2j_emit_A_clinit_p52() { A_arbace_c2j_emit_A_const_713 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1054]); A_arbace_c2j_emit_A_const_714 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1055]); A_arbace_c2j_emit_A_const_715 = A_arbace_c2j_emit_A_const_pool.A[1056]; A_arbace_c2j_emit_A_const_716 = A_arbace_c2j_emit_A_const_pool.A[1057]; A_arbace_c2j_emit_A_const_717 = A_arbace_c2j_emit_A_const_pool.A[1058]; A_arbace_c2j_emit_A_const_718 = A_arbace_c2j_emit_A_const_pool.A[1059]; A_arbace_c2j_emit_A_const_719 = A_arbace_c2j_emit_A_const_pool.A[1060]; A_arbace_c2j_emit_A_const_720 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1061]); A_arbace_c2j_emit_A_const_721 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1062]); A_arbace_c2j_emit_A_const_722 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1063]); A_arbace_c2j_emit_A_const_723 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1064]); A_arbace_c2j_emit_A_const_724 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1065]); A_arbace_c2j_emit_A_const_725 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1066]) }

func A_arbace_c2j_emit_A_clinit_p53() { A_arbace_c2j_emit_A_const_726 = A_arbace_c2j_emit_A_const_pool.A[1067]; A_arbace_c2j_emit_A_const_727 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1068]); A_arbace_c2j_emit_A_const_728 = A_arbace_c2j_emit_A_const_pool.A[1069]; A_arbace_c2j_emit_A_const_729 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1070]); A_arbace_c2j_emit_A_const_730 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1071]); A_arbace_c2j_emit_A_const_731 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1072]); A_arbace_c2j_emit_A_const_732 = A_arbace_c2j_emit_A_const_pool.A[1073]; A_arbace_c2j_emit_A_const_733 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1074]); A_arbace_c2j_emit_A_const_734 = A_arbace_c2j_emit_A_const_pool.A[1075]; A_arbace_c2j_emit_A_const_735 = A_arbace_c2j_emit_A_const_pool.A[1076]; A_arbace_c2j_emit_A_const_736 = A_arbace_c2j_emit_A_const_pool.A[1077]; A_arbace_c2j_emit_A_const_737 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1078]); A_arbace_c2j_emit_A_const_738 = A_arbace_c2j_emit_A_const_pool.A[1079]; A_arbace_c2j_emit_A_const_739 = A_arbace_c2j_emit_A_const_pool.A[1080] }

func A_arbace_c2j_emit_A_clinit_p54() { A_arbace_c2j_emit_A_const_740 = A_arbace_c2j_emit_A_const_pool.A[1081]; A_arbace_c2j_emit_A_const_741 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1082]); A_arbace_c2j_emit_A_const_742 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1083]); A_arbace_c2j_emit_A_const_743 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1084]); A_arbace_c2j_emit_A_const_744 = A_arbace_c2j_emit_A_const_pool.A[1085]; A_arbace_c2j_emit_A_const_745 = A_arbace_c2j_emit_A_const_pool.A[1086]; A_arbace_c2j_emit_A_const_746 = A_arbace_c2j_emit_A_const_pool.A[1087]; A_arbace_c2j_emit_A_const_747 = A_arbace_c2j_emit_A_const_pool.A[1088]; A_arbace_c2j_emit_A_const_748 = A_arbace_c2j_emit_A_const_pool.A[1089]; A_arbace_c2j_emit_A_const_749 = A_arbace_c2j_emit_A_const_pool.A[1090]; A_arbace_c2j_emit_A_const_750 = A_arbace_c2j_emit_A_const_pool.A[1091]; A_arbace_c2j_emit_A_const_751 = A_arbace_c2j_emit_A_const_pool.A[1092]; A_arbace_c2j_emit_A_const_752 = A_arbace_c2j_emit_A_const_pool.A[1093]; A_arbace_c2j_emit_A_const_753 = A_arbace_c2j_emit_A_const_pool.A[1094]; A_arbace_c2j_emit_A_const_754 = A_arbace_c2j_emit_A_const_pool.A[1095] }

func A_arbace_c2j_emit_A_clinit_p55() { A_arbace_c2j_emit_A_const_755 = A_arbace_c2j_emit_A_const_pool.A[1096]; A_arbace_c2j_emit_A_const_756 = A_arbace_c2j_emit_A_const_pool.A[1097]; A_arbace_c2j_emit_A_const_757 = A_arbace_c2j_emit_A_const_pool.A[1098]; A_arbace_c2j_emit_A_const_758 = A_arbace_c2j_emit_A_const_pool.A[1099]; A_arbace_c2j_emit_A_const_759 = A_arbace_c2j_emit_A_const_pool.A[1100]; A_arbace_c2j_emit_A_const_760 = A_arbace_c2j_emit_A_const_pool.A[1101]; A_arbace_c2j_emit_A_const_761 = A_arbace_c2j_emit_A_const_pool.A[1102]; A_arbace_c2j_emit_A_const_762 = A_arbace_c2j_emit_A_const_pool.A[1103]; A_arbace_c2j_emit_A_const_763 = A_arbace_c2j_emit_A_const_pool.A[1104]; A_arbace_c2j_emit_A_const_764 = A_arbace_c2j_emit_A_const_pool.A[1105]; A_arbace_c2j_emit_A_const_765 = A_arbace_c2j_emit_A_const_pool.A[1106]; A_arbace_c2j_emit_A_const_766 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1107]); A_arbace_c2j_emit_A_const_767 = A_arbace_c2j_emit_A_const_pool.A[1108]; A_arbace_c2j_emit_A_const_768 = A_arbace_c2j_emit_A_const_pool.A[1109]; A_arbace_c2j_emit_A_const_769 = A_arbace_c2j_emit_A_const_pool.A[1110] }

func A_arbace_c2j_emit_A_clinit_p56() { A_arbace_c2j_emit_A_const_770 = A_arbace_c2j_emit_A_const_pool.A[1111]; A_arbace_c2j_emit_A_const_771 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1112]); A_arbace_c2j_emit_A_const_772 = A_arbace_c2j_emit_A_const_pool.A[1113]; A_arbace_c2j_emit_A_const_773 = A_arbace_c2j_emit_A_const_pool.A[1114]; A_arbace_c2j_emit_A_const_774 = A_arbace_c2j_emit_A_const_pool.A[1115]; A_arbace_c2j_emit_A_const_775 = A_arbace_c2j_emit_A_const_pool.A[1116]; A_arbace_c2j_emit_A_const_776 = A_arbace_c2j_emit_A_const_pool.A[1117]; A_arbace_c2j_emit_A_const_777 = A_arbace_c2j_emit_A_const_pool.A[1118]; A_arbace_c2j_emit_A_const_778 = A_arbace_c2j_emit_A_const_pool.A[1119]; A_arbace_c2j_emit_A_const_779 = A_arbace_c2j_emit_A_const_pool.A[1120]; A_arbace_c2j_emit_A_const_780 = A_arbace_c2j_emit_A_const_pool.A[1121]; A_arbace_c2j_emit_A_const_781 = A_arbace_c2j_emit_A_const_pool.A[1122]; A_arbace_c2j_emit_A_const_782 = A_arbace_c2j_emit_A_const_pool.A[1123]; A_arbace_c2j_emit_A_const_783 = A_arbace_c2j_emit_A_const_pool.A[1124]; A_arbace_c2j_emit_A_const_784 = A_arbace_c2j_emit_A_const_pool.A[1125] }

func A_arbace_c2j_emit_A_clinit_p57() { A_arbace_c2j_emit_A_const_785 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1126]); A_arbace_c2j_emit_A_const_786 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1127]); A_arbace_c2j_emit_A_const_787 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1128]); A_arbace_c2j_emit_A_const_788 = A_arbace_c2j_emit_A_const_pool.A[1129]; A_arbace_c2j_emit_A_const_789 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1130]); A_arbace_c2j_emit_A_const_790 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1131]); A_arbace_c2j_emit_A_const_791 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1132]); A_arbace_c2j_emit_A_const_792 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1133]); A_arbace_c2j_emit_A_const_793 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1134]); A_arbace_c2j_emit_A_const_794 = A_arbace_c2j_emit_A_const_pool.A[1135]; A_arbace_c2j_emit_A_const_795 = A_arbace_c2j_emit_A_const_pool.A[1136]; A_arbace_c2j_emit_A_const_796 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1137]); A_arbace_c2j_emit_A_const_797 = A_arbace_c2j_emit_A_const_pool.A[1138] }

func A_arbace_c2j_emit_A_clinit_p58() { A_arbace_c2j_emit_A_const_798 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1139]); A_arbace_c2j_emit_A_const_799 = A_arbace_c2j_emit_A_const_pool.A[1140]; A_arbace_c2j_emit_A_const_800 = A_arbace_c2j_emit_A_const_pool.A[1141]; A_arbace_c2j_emit_A_const_801 = A_arbace_c2j_emit_A_const_pool.A[1142]; A_arbace_c2j_emit_A_const_802 = A_arbace_c2j_emit_A_const_pool.A[1143]; A_arbace_c2j_emit_A_const_803 = A_arbace_c2j_emit_A_const_pool.A[1144]; A_arbace_c2j_emit_A_const_804 = A_arbace_c2j_emit_A_const_pool.A[1145]; A_arbace_c2j_emit_A_const_805 = A_arbace_c2j_emit_A_const_pool.A[1146]; A_arbace_c2j_emit_A_const_806 = A_arbace_c2j_emit_A_const_pool.A[1147]; A_arbace_c2j_emit_A_const_807 = A_arbace_c2j_emit_A_const_pool.A[1148]; A_arbace_c2j_emit_A_const_808 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1149]); A_arbace_c2j_emit_A_const_809 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1150]); A_arbace_c2j_emit_A_const_810 = A_arbace_c2j_emit_A_const_pool.A[1151]; A_arbace_c2j_emit_A_const_811 = A_arbace_c2j_emit_A_const_pool.A[1152]; A_arbace_c2j_emit_A_const_812 = A_arbace_c2j_emit_A_const_pool.A[1153] }

func A_arbace_c2j_emit_A_clinit_p59() { A_arbace_c2j_emit_A_const_813 = A_arbace_c2j_emit_A_const_pool.A[1154]; A_arbace_c2j_emit_A_const_814 = A_arbace_c2j_emit_A_const_pool.A[1155]; A_arbace_c2j_emit_A_const_815 = A_arbace_c2j_emit_A_const_pool.A[1156]; A_arbace_c2j_emit_A_const_816 = A_arbace_c2j_emit_A_const_pool.A[1157]; A_arbace_c2j_emit_A_const_817 = A_arbace_c2j_emit_A_const_pool.A[1158]; A_arbace_c2j_emit_A_const_818 = A_arbace_c2j_emit_A_const_pool.A[1159]; A_arbace_c2j_emit_A_const_819 = A_arbace_c2j_emit_A_const_pool.A[1160]; A_arbace_c2j_emit_A_const_820 = A_arbace_c2j_emit_A_const_pool.A[1161]; A_arbace_c2j_emit_A_const_821 = A_arbace_c2j_emit_A_const_pool.A[1162]; A_arbace_c2j_emit_A_const_822 = A_arbace_c2j_emit_A_const_pool.A[1163]; A_arbace_c2j_emit_A_const_823 = A_arbace_c2j_emit_A_const_pool.A[1164]; A_arbace_c2j_emit_A_const_824 = A_arbace_c2j_emit_A_const_pool.A[1165]; A_arbace_c2j_emit_A_const_825 = A_arbace_c2j_emit_A_const_pool.A[1166]; A_arbace_c2j_emit_A_const_826 = A_arbace_c2j_emit_A_const_pool.A[1167]; A_arbace_c2j_emit_A_const_827 = A_arbace_c2j_emit_A_const_pool.A[1168]; A_arbace_c2j_emit_A_const_828 = A_arbace_c2j_emit_A_const_pool.A[1169] }

func A_arbace_c2j_emit_A_clinit_p60() { A_arbace_c2j_emit_A_const_829 = A_arbace_c2j_emit_A_const_pool.A[1170]; A_arbace_c2j_emit_A_const_830 = A_arbace_c2j_emit_A_const_pool.A[1171]; A_arbace_c2j_emit_A_const_831 = A_arbace_c2j_emit_A_const_pool.A[1172]; A_arbace_c2j_emit_A_const_832 = A_arbace_c2j_emit_A_const_pool.A[1173]; A_arbace_c2j_emit_A_const_833 = A_arbace_c2j_emit_A_const_pool.A[1174]; A_arbace_c2j_emit_A_const_834 = A_arbace_c2j_emit_A_const_pool.A[1175]; A_arbace_c2j_emit_A_const_835 = A_arbace_c2j_emit_A_const_pool.A[1176]; A_arbace_c2j_emit_A_const_836 = A_arbace_c2j_emit_A_const_pool.A[1177]; A_arbace_c2j_emit_A_const_837 = A_arbace_c2j_emit_A_const_pool.A[1178]; A_arbace_c2j_emit_A_const_838 = A_arbace_c2j_emit_A_const_pool.A[1179]; A_arbace_c2j_emit_A_const_839 = A_arbace_c2j_emit_A_const_pool.A[1180]; A_arbace_c2j_emit_A_const_840 = A_arbace_c2j_emit_A_const_pool.A[1181]; A_arbace_c2j_emit_A_const_841 = A_arbace_c2j_emit_A_const_pool.A[1182]; A_arbace_c2j_emit_A_const_842 = A_arbace_c2j_emit_A_const_pool.A[1183]; A_arbace_c2j_emit_A_const_843 = A_arbace_c2j_emit_A_const_pool.A[1184] }

func A_arbace_c2j_emit_A_clinit_p61() { A_arbace_c2j_emit_A_const_844 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1185]); A_arbace_c2j_emit_A_const_845 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1186]); A_arbace_c2j_emit_A_const_846 = A_arbace_c2j_emit_A_const_pool.A[1187]; A_arbace_c2j_emit_A_const_847 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1188]); A_arbace_c2j_emit_A_const_848 = A_arbace_c2j_emit_A_const_pool.A[1189]; A_arbace_c2j_emit_A_const_849 = A_arbace_c2j_emit_A_const_pool.A[1190]; A_arbace_c2j_emit_A_const_850 = A_arbace_c2j_emit_A_const_pool.A[1191]; A_arbace_c2j_emit_A_const_851 = A_arbace_c2j_emit_A_const_pool.A[1192]; A_arbace_c2j_emit_A_const_852 = A_arbace_c2j_emit_A_const_pool.A[1193]; A_arbace_c2j_emit_A_const_853 = A_arbace_c2j_emit_A_const_pool.A[1194]; A_arbace_c2j_emit_A_const_854 = A_arbace_c2j_emit_A_const_pool.A[1195]; A_arbace_c2j_emit_A_const_855 = A_arbace_c2j_emit_A_const_pool.A[1196]; A_arbace_c2j_emit_A_const_856 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1197]); A_arbace_c2j_emit_A_const_857 = A_arbace_c2j_emit_A_const_pool.A[1198] }

func A_arbace_c2j_emit_A_clinit_p62() { A_arbace_c2j_emit_A_const_858 = A_arbace_c2j_emit_A_const_pool.A[1199]; A_arbace_c2j_emit_A_const_859 = A_arbace_c2j_emit_A_const_pool.A[1200]; A_arbace_c2j_emit_A_const_860 = A_arbace_c2j_emit_A_const_pool.A[1201]; A_arbace_c2j_emit_A_const_861 = A_arbace_c2j_emit_A_const_pool.A[1202]; A_arbace_c2j_emit_A_const_862 = A_arbace_c2j_emit_A_const_pool.A[1203]; A_arbace_c2j_emit_A_const_863 = A_arbace_c2j_emit_A_const_pool.A[1204]; A_arbace_c2j_emit_A_const_864 = A_arbace_c2j_emit_A_const_pool.A[1205]; A_arbace_c2j_emit_A_const_865 = A_arbace_c2j_emit_A_const_pool.A[1206]; A_arbace_c2j_emit_A_const_866 = A_arbace_c2j_emit_A_const_pool.A[1207]; A_arbace_c2j_emit_A_const_867 = A_arbace_c2j_emit_A_const_pool.A[1208]; A_arbace_c2j_emit_A_const_868 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1209]); A_arbace_c2j_emit_A_const_869 = A_arbace_c2j_emit_A_const_pool.A[1210]; A_arbace_c2j_emit_A_const_870 = A_arbace_c2j_emit_A_const_pool.A[1211]; A_arbace_c2j_emit_A_const_871 = A_arbace_c2j_emit_A_const_pool.A[1212]; A_arbace_c2j_emit_A_const_872 = A_arbace_c2j_emit_A_const_pool.A[1213] }

func A_arbace_c2j_emit_A_clinit_p63() { A_arbace_c2j_emit_A_const_873 = A_arbace_c2j_emit_A_const_pool.A[1214]; A_arbace_c2j_emit_A_const_874 = A_arbace_c2j_emit_A_const_pool.A[1215]; A_arbace_c2j_emit_A_const_875 = A_arbace_c2j_emit_A_const_pool.A[1216]; A_arbace_c2j_emit_A_const_876 = A_arbace_c2j_emit_A_const_pool.A[1217]; A_arbace_c2j_emit_A_const_877 = A_arbace_c2j_emit_A_const_pool.A[1218]; A_arbace_c2j_emit_A_const_878 = A_arbace_c2j_emit_A_const_pool.A[1219]; A_arbace_c2j_emit_A_const_879 = A_arbace_c2j_emit_A_const_pool.A[1220]; A_arbace_c2j_emit_A_const_880 = A_arbace_c2j_emit_A_const_pool.A[1221]; A_arbace_c2j_emit_A_const_881 = A_arbace_c2j_emit_A_const_pool.A[1222]; A_arbace_c2j_emit_A_const_882 = A_arbace_c2j_emit_A_const_pool.A[1223]; A_arbace_c2j_emit_A_const_883 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1224]); A_arbace_c2j_emit_A_const_884 = A_arbace_c2j_emit_A_const_pool.A[1225]; A_arbace_c2j_emit_A_const_885 = A_arbace_c2j_emit_A_const_pool.A[1226]; A_arbace_c2j_emit_A_const_886 = A_arbace_c2j_emit_A_const_pool.A[1227]; A_arbace_c2j_emit_A_const_887 = A_arbace_c2j_emit_A_const_pool.A[1228] }

func A_arbace_c2j_emit_A_clinit_p64() { A_arbace_c2j_emit_A_const_888 = A_arbace_c2j_emit_A_const_pool.A[1229]; A_arbace_c2j_emit_A_const_889 = A_arbace_c2j_emit_A_const_pool.A[1230]; A_arbace_c2j_emit_A_const_890 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1231]); A_arbace_c2j_emit_A_const_891 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1232]); A_arbace_c2j_emit_A_const_892 = A_arbace_c2j_emit_A_const_pool.A[1233]; A_arbace_c2j_emit_A_const_893 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1234]); A_arbace_c2j_emit_A_const_894 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1235]); A_arbace_c2j_emit_A_const_895 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1236]); A_arbace_c2j_emit_A_const_896 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1237]); A_arbace_c2j_emit_A_const_897 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1238]); A_arbace_c2j_emit_A_const_898 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1239]); A_arbace_c2j_emit_A_const_899 = A_arbace_c2j_emit_A_const_pool.A[1240]; A_arbace_c2j_emit_A_const_900 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1241]) }

func A_arbace_c2j_emit_A_clinit_p65() { A_arbace_c2j_emit_A_const_901 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1242]); A_arbace_c2j_emit_A_const_902 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1243]); A_arbace_c2j_emit_A_const_903 = A_arbace_c2j_emit_A_const_pool.A[1244]; A_arbace_c2j_emit_A_const_904 = A_arbace_c2j_emit_A_const_pool.A[1245]; A_arbace_c2j_emit_A_const_905 = A_arbace_c2j_emit_A_const_pool.A[1246]; A_arbace_c2j_emit_A_const_906 = A_arbace_c2j_emit_A_const_pool.A[1247]; A_arbace_c2j_emit_A_const_907 = A_arbace_c2j_emit_A_const_pool.A[1248]; A_arbace_c2j_emit_A_const_908 = A_arbace_c2j_emit_A_const_pool.A[1249]; A_arbace_c2j_emit_A_const_909 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1250]); A_arbace_c2j_emit_A_const_910 = A_arbace_c2j_emit_A_const_pool.A[1251]; A_arbace_c2j_emit_A_const_911 = A_arbace_c2j_emit_A_const_pool.A[1252]; A_arbace_c2j_emit_A_const_912 = A_arbace_c2j_emit_A_const_pool.A[1253]; A_arbace_c2j_emit_A_const_913 = A_arbace_c2j_emit_A_const_pool.A[1254]; A_arbace_c2j_emit_A_const_914 = A_arbace_c2j_emit_A_const_pool.A[1255]; A_arbace_c2j_emit_A_const_915 = A_arbace_c2j_emit_A_const_pool.A[1256] }

func A_arbace_c2j_emit_A_clinit_p66() { A_arbace_c2j_emit_A_const_916 = A_arbace_c2j_emit_A_const_pool.A[1257]; A_arbace_c2j_emit_A_const_917 = A_arbace_c2j_emit_A_const_pool.A[1258]; A_arbace_c2j_emit_A_const_918 = A_arbace_c2j_emit_A_const_pool.A[1259]; A_arbace_c2j_emit_A_const_919 = A_arbace_c2j_emit_A_const_pool.A[1260]; A_arbace_c2j_emit_A_const_920 = A_arbace_c2j_emit_A_const_pool.A[1261]; A_arbace_c2j_emit_A_const_921 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1262]); A_arbace_c2j_emit_A_const_922 = A_arbace_c2j_emit_A_const_pool.A[1263]; A_arbace_c2j_emit_A_const_923 = A_arbace_c2j_emit_A_const_pool.A[1264]; A_arbace_c2j_emit_A_const_924 = A_arbace_c2j_emit_A_const_pool.A[1265]; A_arbace_c2j_emit_A_const_925 = A_arbace_c2j_emit_A_const_pool.A[1266]; A_arbace_c2j_emit_A_const_926 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1267]); A_arbace_c2j_emit_A_const_927 = A_arbace_c2j_emit_A_const_pool.A[1268]; A_arbace_c2j_emit_A_const_928 = A_arbace_c2j_emit_A_const_pool.A[1269]; A_arbace_c2j_emit_A_const_929 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1270]) }

func A_arbace_c2j_emit_A_clinit_p67() { A_arbace_c2j_emit_A_const_930 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1271]); A_arbace_c2j_emit_A_const_931 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1272]); A_arbace_c2j_emit_A_const_932 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1273]); A_arbace_c2j_emit_A_const_933 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1274]); A_arbace_c2j_emit_A_const_934 = A_arbace_c2j_emit_A_const_pool.A[1275]; A_arbace_c2j_emit_A_const_935 = A_arbace_c2j_emit_A_const_pool.A[1276]; A_arbace_c2j_emit_A_const_936 = A_arbace_c2j_emit_A_const_pool.A[1277]; A_arbace_c2j_emit_A_const_937 = A_arbace_c2j_emit_A_const_pool.A[1278]; A_arbace_c2j_emit_A_const_938 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1279]); A_arbace_c2j_emit_A_const_939 = A_arbace_c2j_emit_A_const_pool.A[1280]; A_arbace_c2j_emit_A_const_940 = A_arbace_c2j_emit_A_const_pool.A[1281]; A_arbace_c2j_emit_A_const_941 = lang.Keyword_Cast(A_arbace_c2j_emit_A_const_pool.A[1282]); A_arbace_c2j_emit_A_const_942 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1283]) }

func A_arbace_c2j_emit_A_clinit_p68() { A_arbace_c2j_emit_A_const_943 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1284]); A_arbace_c2j_emit_A_const_944 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1285]); A_arbace_c2j_emit_A_const_945 = lang.Var_Cast(A_arbace_c2j_emit_A_const_pool.A[1286]); A_arbace_c2j_emit_A_const_946 = A_arbace_c2j_emit_A_const_pool.A[1287]; A_arbace_c2j_emit_A_const_947 = A_arbace_c2j_emit_A_const_pool.A[1288]; A_arbace_c2j_emit_A_const_948 = A_arbace_c2j_emit_A_const_pool.A[1289]; A_arbace_c2j_emit_A_const_949 = A_arbace_c2j_emit_A_const_pool.A[1290] }

func A_arbace_c2j_emit_A_New() *A_arbace_c2j_emit_A { A_arbace_c2j_emit_A_Init(); t := &A_arbace_c2j_emit_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_emit_A) Ctor() {}

func (t *A_arbace_c2j_emit_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_emit_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_emit_A_class }

func (t *A_arbace_c2j_emit_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_emit_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_emit_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_emit_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_emit_A); return ok }

func A_arbace_c2j_emit_A_Cast(x any) *A_arbace_c2j_emit_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_emit_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_emit_A_class)) }; return v }



type A_arbace_c2j_emit_body_instance_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_body_instance_A_fn_class *jrt.Class



type A_arbace_c2j_emit_body_instance_iter__31000238__31000242_A struct{ j2g_header uint64; F_ctx, F_nil_locals any }

var A_arbace_c2j_emit_body_instance_iter__31000238__31000242_A_fn_class *jrt.Class



type A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_A struct{ j2g_header uint64; F_ctx, F_nil_locals, F_s__31000239, F_iter__31000238 any }

var A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_A_fn_class *jrt.Class



type A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_fn__31000244_A struct{ j2g_header uint64; F_ctx, F_nil_locals, F_b__31000241 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_body_instance_iter__31000238__31000242_fn__31000243_fn__31000244_A_fn_class *jrt.Class



type A_arbace_c2j_emit_box_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_box_A_fn_class *jrt.Class



type A_arbace_c2j_emit_box_class_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_box_class_A_fn_class *jrt.Class



type A_arbace_c2j_emit_box_prim_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_box_prim_A_fn_class *jrt.Class



type A_arbace_c2j_emit_can_prim_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_can_prim_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_emit_char_form_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_char_form_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_form_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_class_form_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_form_fn__31000690_A struct{ j2g_header uint64; F_pools, F_children_of any }

var A_arbace_c2j_emit_class_form_fn__31000690_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_form_mods__31000692_A struct{ j2g_header uint64; F_c, F_top_QMARK_ any }

var A_arbace_c2j_emit_class_form_mods__31000692_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_forms_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_class_forms_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_forms_children_of__31000713_A struct{ j2g_header uint64; F_kids, F_recs any }

var A_arbace_c2j_emit_class_forms_children_of__31000713_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_forms_fn__31000699_A struct{ j2g_header uint64; F_names, F_parent any }

var A_arbace_c2j_emit_class_forms_fn__31000699_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_forms_fn__31000711_A struct{ j2g_header uint64; F_recs any }

var A_arbace_c2j_emit_class_forms_fn__31000711_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_forms_iter__31000701__31000705_A struct{ j2g_header uint64; F_classes any }

var A_arbace_c2j_emit_class_forms_iter__31000701__31000705_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_A struct{ j2g_header uint64; F_classes, F_s__31000702, F_iter__31000701 any }

var A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_fn__31000707_A struct{ j2g_header uint64; F_classes, F_b__31000704 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_class_forms_iter__31000701__31000705_fn__31000706_fn__31000707_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_forms_iter__31000715__31000719_A struct{ j2g_header uint64; F_children_of, F_pools, F_recs any }

var A_arbace_c2j_emit_class_forms_iter__31000715__31000719_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_A struct{ j2g_header uint64; F_iter__31000715, F_children_of, F_pools, F_s__31000716, F_recs any }

var A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_fn__31000721_A struct{ j2g_header uint64; F_b__31000718, F_children_of, F_pools any; F_size__1927001038__auto__ int32; F_recs, F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_class_forms_iter__31000715__31000719_fn__31000720_fn__31000721_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_forms_parent__31000697_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_class_forms_parent__31000697_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_interfaces_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_class_interfaces_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_A struct{ j2g_header uint64; F_ctx, F_ox any }

var A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_A struct{ j2g_header uint64; F_ctx, F_ox, F_s__31000362, F_iter__31000361 any }

var A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_A_fn_class *jrt.Class



type A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_fn__31000367_A struct{ j2g_header uint64; F_ctx, F_ox, F_b__31000364 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_class_interfaces_iter__31000361__31000365_fn__31000366_fn__31000367_A_fn_class *jrt.Class



type A_arbace_c2j_emit_closed_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_closed_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_emit_coll_call_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_coll_call_A_fn_class *jrt.Class



type A_arbace_c2j_emit_compiled_interface_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_compiled_interface_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_emit_const_field_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_const_field_A_fn_class *jrt.Class



type A_arbace_c2j_emit_const_type_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_const_type_A_fn_class *jrt.Class



type A_arbace_c2j_emit_constant_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_constant_A_fn_class *jrt.Class



type A_arbace_c2j_emit_deep_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_deep_A_fn_class *jrt.Class



type A_arbace_c2j_emit_descriptor_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_descriptor_A_fn_class *jrt.Class



type A_arbace_c2j_emit_destub_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_destub_A_fn_class *jrt.Class



type A_arbace_c2j_emit_double_box_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_double_box_A_fn_class *jrt.Class



type A_arbace_c2j_emit_double_form_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_double_form_A_fn_class *jrt.Class



type A_arbace_c2j_emit_double_op1_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_double_op1_A_fn_class *jrt.Class



type A_arbace_c2j_emit_double_op2_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_double_op2_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn__31000326_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_emit_fn__31000326_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn__31000328_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_emit_fn__31000328_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn__31000330_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_emit_fn__31000330_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_assign_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_assign_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_binding_init_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_binding_init_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_case_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_case_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_case_arm__31000308_A struct{ j2g_header uint64; F_e, F_mask, F_ctx, F_lbl, F_n, F_skip any; F_int_test_QMARK_ bool; F_ret, F_pt any }

var A_arbace_c2j_emit_emit_case_arm__31000308_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_case_fn__31000311_A struct{ j2g_header uint64; F_arm, F_thens any }

var A_arbace_c2j_emit_emit_case_fn__31000311_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_case_fn__31000317_A struct{ j2g_header uint64; F_arm, F_thens any }

var A_arbace_c2j_emit_emit_case_fn__31000317_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_case_ret__31000306_A struct{ j2g_header uint64; F_ctx, F_unboxed_QMARK_ any }

var A_arbace_c2j_emit_emit_case_ret__31000306_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_case_sm__31000304_A struct{ j2g_header uint64; F_mask, F_shift any }

var A_arbace_c2j_emit_emit_case_sm__31000304_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_def_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_def_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_deftype_class_BANG__A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000380_A struct{ j2g_header uint64; F_ftype, F_fsym any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000380_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000413_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_deftype_class_BANG__fn__31000413_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__fsym__31000378_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_deftype_class_BANG__fsym__31000378_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__ftype__31000376_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_deftype_class_BANG__ftype__31000376_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_A struct{ j2g_header uint64; F_fsym any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_A struct{ j2g_header uint64; F_s__31000383, F_iter__31000382, F_fsym any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_fn__31000388_A struct{ j2g_header uint64; F_fsym, F_b__31000385 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000382__31000386_fn__31000387_fn__31000388_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_A struct{ j2g_header uint64; F_m any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_A struct{ j2g_header uint64; F_s__31000397, F_iter__31000396, F_m any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_fn__31000402_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__31000399, F_m, F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000396__31000400_fn__31000401_fn__31000402_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_A struct{ j2g_header uint64; F_m any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_A struct{ j2g_header uint64; F_iter__31000418, F_s__31000419, F_m any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_fn__31000424_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_m, F_b__31000421, F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000418__31000422_fn__31000423_fn__31000424_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_A struct{ j2g_header uint64; F_ctx_SINGLEQUOTE_ any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_A struct{ j2g_header uint64; F_s__31000435, F_iter__31000434, F_ctx_SINGLEQUOTE_ any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_A struct{ j2g_header uint64; F_b__31000437 any; F_size__1927001038__auto__ int32; F_ctx_SINGLEQUOTE_, F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000441_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000441_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000443_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000440_fn__31000443_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000446_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000446_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000448_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000434__31000438_fn__31000439_fn__31000448_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_A struct{ j2g_header uint64; F_ox, F_ftype, F_fsym any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_A struct{ j2g_header uint64; F_ox, F_s__31000453, F_iter__31000452, F_ftype, F_fsym any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_fn__31000458_A struct{ j2g_header uint64; F_ox, F_ftype, F_fsym any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__31000455 any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__iter__31000452__31000456_fn__31000457_fn__31000458_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_A struct{ j2g_header uint64; F_fbs, F_ftype, F_fsym any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_fn__31000393_A struct{ j2g_header uint64; F_ftype, F_fsym any }

var A_arbace_c2j_emit_emit_deftype_class_BANG__ps__31000392_fn__31000393_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_fn_class_BANG__A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000465_A struct{ j2g_header uint64; F_ctx, F_base any }

var A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000465_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000497_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_fn_class_BANG__fn__31000497_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_A struct{ j2g_header uint64; F_s__31000468, F_iter__31000467 any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_fn__31000473_A struct{ j2g_header uint64; F_b__31000470 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000467__31000471_fn__31000472_fn__31000473_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_A struct{ j2g_header uint64; F_s__31000478, F_iter__31000477 any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_fn__31000483_A struct{ j2g_header uint64; F_b__31000480 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000477__31000481_fn__31000482_fn__31000483_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_A struct{ j2g_header uint64; F_s__31000488, F_iter__31000487 any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_fn__31000493_A struct{ j2g_header uint64; F_b__31000490 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000487__31000491_fn__31000492_fn__31000493_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_A struct{ j2g_header uint64; F_ctx_SINGLEQUOTE_ any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_A struct{ j2g_header uint64; F_s__31000500, F_iter__31000499, F_ctx_SINGLEQUOTE_ any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_fn__31000505_A struct{ j2g_header uint64; F_b__31000502, F_ctx_SINGLEQUOTE_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000499__31000503_fn__31000504_fn__31000505_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_A struct{ j2g_header uint64; F_ctx_SINGLEQUOTE_ any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_A struct{ j2g_header uint64; F_iter__31000509, F_s__31000510, F_ctx_SINGLEQUOTE_ any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_A struct{ j2g_header uint64; F_b__31000512, F_ctx_SINGLEQUOTE_ any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000516_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000516_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000518_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000515_fn__31000518_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000521_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000521_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000523_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000509__31000513_fn__31000514_fn__31000523_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_A struct{ j2g_header uint64; F_iter__31000527, F_s__31000528 any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_fn__31000533_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__31000530, F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000527__31000531_fn__31000532_fn__31000533_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_A struct{ j2g_header uint64; F_s__31000538, F_iter__31000537 any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_fn__31000543_A struct{ j2g_header uint64; F_b__31000540 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_fn_class_BANG__iter__31000537__31000541_fn__31000542_fn__31000543_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_if_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_if_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_if_br__31000227_A struct{ j2g_header uint64; F_ctx, F_unboxed_QMARK_ any }

var A_arbace_c2j_emit_emit_if_br__31000227_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_instance_field_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_instance_field_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_instance_method_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_instance_method_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_invoke_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_invoke_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_invoke_call__31000157_A struct{ j2g_header uint64; F_ctx, F_args any }

var A_arbace_c2j_emit_emit_invoke_call__31000157_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_invoke_call__31000157_fn__31000158_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_emit_invoke_call__31000157_fn__31000158_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_invoke_fn__31000161_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_emit_invoke_fn__31000161_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_let_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_let_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_let_fn__31000232_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_emit_let_fn__31000232_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_letfn_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_letfn_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_letfn_fn__31000253_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_letfn_fn__31000253_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_letfn_fn__31000255_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_letfn_fn__31000255_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_letfn_fn__31000286_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_emit_letfn_fn__31000286_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_letfn_fn__31000288_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_emit_letfn_fn__31000288_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_A struct{ j2g_header uint64; F_ctx, F_lbs any }

var A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_A struct{ j2g_header uint64; F_ctx, F_s__31000258, F_lbs, F_iter__31000257 any }

var A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_fn__31000263_A struct{ j2g_header uint64; F_ctx, F_b__31000260, F_lbs any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_letfn_iter__31000257__31000261_fn__31000262_fn__31000263_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_A struct{ j2g_header uint64; F_ctx, F_lbs any }

var A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_A struct{ j2g_header uint64; F_ctx, F_s__31000268, F_lbs, F_iter__31000267 any }

var A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_A struct{ j2g_header uint64; F_bs, F_lbs any }

var A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_A struct{ j2g_header uint64; F_bs, F_s__31000270, F_lbs, F_iter__31000269 any }

var A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_fn__31000280_A struct{ j2g_header uint64; F_bs, F_b__31000272, F_lbs any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_letfn_iter__31000267__31000273_fn__31000274_iter__31000269__31000278_fn__31000279_fn__31000280_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_list_array_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_list_array_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_list_array_fn__31000036_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_emit_list_array_fn__31000036_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_local_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_local_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_new_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_new_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_recur_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_recur_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_recur_fn__31000235_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_emit_recur_fn__31000235_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_source_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_calls__31000632_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_source_calls__31000632_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_A struct{ j2g_header uint64; F_cname any }

var A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_A struct{ j2g_header uint64; F_cname, F_s__31000634, F_iter__31000633 any }

var A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_fn__31000639_A struct{ j2g_header uint64; F_b__31000636, F_cname any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_source_calls__31000632_iter__31000633__31000637_fn__31000638_fn__31000639_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_iter__31000644__31000648_A struct{ j2g_header uint64; F_prev, F_calls, F_unit_methods, F_lname, F_file any }

var A_arbace_c2j_emit_emit_source_iter__31000644__31000648_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_A struct{ j2g_header uint64; F_prev, F_calls, F_unit_methods, F_lname, F_file, F_s__31000645, F_iter__31000644 any }

var A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_fn__31000650_A struct{ j2g_header uint64; F_b__31000647, F_prev, F_calls, F_unit_methods, F_lname, F_file any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_source_iter__31000644__31000648_fn__31000649_fn__31000650_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_iter__31000660__31000664_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_source_iter__31000660__31000664_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_A struct{ j2g_header uint64; F_s__31000661, F_iter__31000660 any }

var A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_fn__31000666_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__31000663, F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_source_iter__31000660__31000664_fn__31000665_fn__31000666_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_iter__31000674__31000678_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_source_iter__31000674__31000678_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_A struct{ j2g_header uint64; F_s__31000675, F_iter__31000674 any }

var A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_fn__31000680_A struct{ j2g_header uint64; F_b__31000677 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_source_iter__31000674__31000678_fn__31000679_fn__31000680_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_unit_methods__31000625_A struct{ j2g_header uint64; F_units, F_ctx any }

var A_arbace_c2j_emit_emit_source_unit_methods__31000625_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_source_unit_methods__31000625_fn__31000626_A struct{ j2g_header uint64; F_units, F_cls, F_ctx any }

var A_arbace_c2j_emit_emit_source_unit_methods__31000625_fn__31000626_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_static_field_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_static_field_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_static_method_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_static_method_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_try_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_try_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_try_body__31000291_A struct{ j2g_header uint64; F_ctx, F_unboxed_QMARK_ any }

var A_arbace_c2j_emit_emit_try_body__31000291_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_try_iter__31000293__31000297_A struct{ j2g_header uint64; F_body any }

var A_arbace_c2j_emit_emit_try_iter__31000293__31000297_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_A struct{ j2g_header uint64; F_s__31000294, F_iter__31000293, F_body any }

var A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_fn__31000299_A struct{ j2g_header uint64; F_b__31000296 any; F_size__1927001038__auto__ int32; F_body, F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_emit_try_iter__31000293__31000297_fn__31000298_fn__31000299_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_unboxed_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_unboxed_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_unboxed_fn__31000335_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_emit_unboxed_fn__31000335_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_value_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_emit_value_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_value_fn__31000045_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_emit_value_fn__31000045_A_fn_class *jrt.Class



type A_arbace_c2j_emit_emit_value_fn__31000047_A struct{ j2g_header uint64; F_v any }

var A_arbace_c2j_emit_emit_value_fn__31000047_A_fn_class *jrt.Class



type A_arbace_c2j_emit_eval31000004_A struct{ jrt.Object }

func A_arbace_c2j_emit_eval31000004_A_New() *A_arbace_c2j_emit_eval31000004_A { t := &A_arbace_c2j_emit_eval31000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_emit_eval31000004_A) Ctor() {}

func (t *A_arbace_c2j_emit_eval31000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_emit_eval31000004_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_emit_eval31000004_A_class }

func (t *A_arbace_c2j_emit_eval31000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_emit_eval31000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_emit_eval31000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_emit_eval31000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_emit_eval31000004_A); return ok }

func A_arbace_c2j_emit_eval31000004_A_Cast(x any) *A_arbace_c2j_emit_eval31000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_emit_eval31000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_emit_eval31000004_A_class)) }; return v }



type A_arbace_c2j_emit_eval31000004_loading__1927001464__auto____31000005_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_eval31000004_loading__1927001464__auto____31000005_A_fn_class *jrt.Class



type A_arbace_c2j_emit_eval31000008_A struct{ jrt.Object }

func A_arbace_c2j_emit_eval31000008_A_New() *A_arbace_c2j_emit_eval31000008_A { t := &A_arbace_c2j_emit_eval31000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_emit_eval31000008_A) Ctor() {}

func (t *A_arbace_c2j_emit_eval31000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_emit_eval31000008_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_emit_eval31000008_A_class }

func (t *A_arbace_c2j_emit_eval31000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_emit_eval31000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_emit_eval31000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_emit_eval31000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_emit_eval31000008_A); return ok }

func A_arbace_c2j_emit_eval31000008_A_Cast(x any) *A_arbace_c2j_emit_eval31000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_emit_eval31000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_emit_eval31000008_A_class)) }; return v }



type A_arbace_c2j_emit_eval31000008_fn__31000009_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_eval31000008_fn__31000009_A_fn_class *jrt.Class



type A_arbace_c2j_emit_fail_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_fail_A_fn_class *jrt.Class



type A_arbace_c2j_emit_fi_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_fi_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_emit_field_mods_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_field_mods_A_fn_class *jrt.Class



type A_arbace_c2j_emit_field_ok_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_field_ok_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_emit_field_read_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_field_read_A_fn_class *jrt.Class



type A_arbace_c2j_emit_field_sym_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_field_sym_A_fn_class *jrt.Class



type A_arbace_c2j_emit_fn__31000165_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_fn__31000165_A_fn_class *jrt.Class



type A_arbace_c2j_emit_fn_instance_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_fn_instance_A_fn_class *jrt.Class



type A_arbace_c2j_emit_fn_wrap_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_fn_wrap_A_fn_class *jrt.Class



type A_arbace_c2j_emit_gsym_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_gsym_A_fn_class *jrt.Class



type A_arbace_c2j_emit_identity_set_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_identity_set_A_fn_class *jrt.Class



type A_arbace_c2j_emit_interface_record_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_interface_record_A_fn_class *jrt.Class



type A_arbace_c2j_emit_interface_record_fn__31000727_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_interface_record_fn__31000727_A_fn_class *jrt.Class



type A_arbace_c2j_emit_interface_record_iter__31000729__31000733_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_interface_record_iter__31000729__31000733_A_fn_class *jrt.Class



type A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_A struct{ j2g_header uint64; F_iter__31000729, F_s__31000730 any }

var A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_A_fn_class *jrt.Class



type A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_A struct{ j2g_header uint64; F_b__31000732 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_A_fn_class *jrt.Class



type A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_fn__31000739_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000735_fn__31000739_A_fn_class *jrt.Class



type A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000745_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_interface_record_iter__31000729__31000733_fn__31000734_fn__31000745_A_fn_class *jrt.Class



type A_arbace_c2j_emit_jrt_lacks_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_jrt_lacks_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_emit_jrt_lacks_QMARK__fn__31000168_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_jrt_lacks_QMARK__fn__31000168_A_fn_class *jrt.Class



type A_arbace_c2j_emit_line_meta_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_line_meta_A_fn_class *jrt.Class



type A_arbace_c2j_emit_local_sym_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_local_sym_A_fn_class *jrt.Class



type A_arbace_c2j_emit_long_box_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_long_box_A_fn_class *jrt.Class



type A_arbace_c2j_emit_long_op1_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_long_op1_A_fn_class *jrt.Class



type A_arbace_c2j_emit_long_op1_guard__31000182_A struct{ j2g_header uint64; F_x, F_slow any }

var A_arbace_c2j_emit_long_op1_guard__31000182_A_fn_class *jrt.Class



type A_arbace_c2j_emit_long_op2_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_long_op2_A_fn_class *jrt.Class



type A_arbace_c2j_emit_long_op2_checked__31000176_A struct{ j2g_header uint64; F_r, F_slow any }

var A_arbace_c2j_emit_long_op2_checked__31000176_A_fn_class *jrt.Class



type A_arbace_c2j_emit_method_body_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_method_body_A_fn_class *jrt.Class



type A_arbace_c2j_emit_method_body_fn__31000353_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_method_body_fn__31000353_A_fn_class *jrt.Class



type A_arbace_c2j_emit_method_body_fn__31000355_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_method_body_fn__31000355_A_fn_class *jrt.Class



type A_arbace_c2j_emit_method_body_iter__31000343__31000347_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_method_body_iter__31000343__31000347_A_fn_class *jrt.Class



type A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_A struct{ j2g_header uint64; F_s__31000344, F_iter__31000343 any }

var A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_A_fn_class *jrt.Class



type A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_fn__31000349_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__31000346 any }

var A_arbace_c2j_emit_method_body_iter__31000343__31000347_fn__31000348_fn__31000349_A_fn_class *jrt.Class



type A_arbace_c2j_emit_method_call_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_method_call_A_fn_class *jrt.Class



type A_arbace_c2j_emit_node_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_node_A_fn_class *jrt.Class



type A_arbace_c2j_emit_numbers_intrinsic_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_numbers_intrinsic_A_fn_class *jrt.Class



type A_arbace_c2j_emit_numbers_intrinsic_dv__31000199_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_numbers_intrinsic_dv__31000199_A_fn_class *jrt.Class



type A_arbace_c2j_emit_numbers_intrinsic_fn__31000190_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_numbers_intrinsic_fn__31000190_A_fn_class *jrt.Class



type A_arbace_c2j_emit_numbers_intrinsic_fn__31000193_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_numbers_intrinsic_fn__31000193_A_fn_class *jrt.Class



type A_arbace_c2j_emit_numbers_intrinsic_fn__31000195_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_numbers_intrinsic_fn__31000195_A_fn_class *jrt.Class



type A_arbace_c2j_emit_numbers_intrinsic_fn__31000202_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_numbers_intrinsic_fn__31000202_A_fn_class *jrt.Class



type A_arbace_c2j_emit_numbers_intrinsic_fn__31000211_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_numbers_intrinsic_fn__31000211_A_fn_class *jrt.Class



type A_arbace_c2j_emit_numbers_intrinsic_fn__31000213_A struct{ j2g_header uint64; F_lv any }

var A_arbace_c2j_emit_numbers_intrinsic_fn__31000213_A_fn_class *jrt.Class



type A_arbace_c2j_emit_numbers_intrinsic_fn__31000215_A struct{ j2g_header uint64; F_dv any }

var A_arbace_c2j_emit_numbers_intrinsic_fn__31000215_A_fn_class *jrt.Class



type A_arbace_c2j_emit_numbers_intrinsic_is__31000207_A struct{ j2g_header uint64; F_objs any }

var A_arbace_c2j_emit_numbers_intrinsic_is__31000207_A_fn_class *jrt.Class



type A_arbace_c2j_emit_numbers_intrinsic_is__31000207_fn__31000208_A struct{ j2g_header uint64; F_c any }

var A_arbace_c2j_emit_numbers_intrinsic_is__31000207_fn__31000208_A_fn_class *jrt.Class



type A_arbace_c2j_emit_numbers_intrinsic_lv__31000197_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_numbers_intrinsic_lv__31000197_A_fn_class *jrt.Class



type A_arbace_c2j_emit_obj_array_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_obj_array_A_fn_class *jrt.Class



type A_arbace_c2j_emit_obj_array_fn__31000149_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_obj_array_fn__31000149_A_fn_class *jrt.Class



type A_arbace_c2j_emit_param_sym_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_param_sym_A_fn_class *jrt.Class



type A_arbace_c2j_emit_param_tags_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_param_tags_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_pool_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_fn__31000031_A struct{ j2g_header uint64; F_top any }

var A_arbace_c2j_emit_pool_fn__31000031_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_encode_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_pool_encode_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_encode_arr__31000057_A struct{ j2g_header uint64; F_shared, F_sb any }

var A_arbace_c2j_emit_pool_encode_arr__31000057_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_encode_fn__31000064_A struct{ j2g_header uint64; F_v any }

var A_arbace_c2j_emit_pool_encode_fn__31000064_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_encode_num__31000055_A struct{ j2g_header uint64; F_sb any }

var A_arbace_c2j_emit_pool_encode_num__31000055_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_fields_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_pool_fields_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_fields_fn__31000068_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_pool_fields_fn__31000068_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_fields_fn__31000076_A struct{ j2g_header uint64; F_walk, F_pooled any }

var A_arbace_c2j_emit_pool_fields_fn__31000076_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_fields_fn__31000084_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_pool_fields_fn__31000084_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_fields_fn__31000090_A struct{ j2g_header uint64; F_sb, F_sh any }

var A_arbace_c2j_emit_pool_fields_fn__31000090_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_fields_fn__31000096_A struct{ j2g_header uint64; F_sb, F_pooled, F_shared any }

var A_arbace_c2j_emit_pool_fields_fn__31000096_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_fields_fn__31000105_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_pool_fields_fn__31000105_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_A struct{ j2g_header uint64; F_index any; F_base int32 }

var A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_A struct{ j2g_header uint64; F_index any; F_base int32; F_s__31000111, F_iter__31000110 any }

var A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_fn__31000116_A struct{ j2g_header uint64; F_index any; F_base, F_size__1927001038__auto__ int32; F_b__31000113, F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_pool_fields_iter__31000110__31000114_fn__31000115_fn__31000116_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_fields_walk__31000070_A struct{ j2g_header uint64; F_seen any }

var A_arbace_c2j_emit_pool_fields_walk__31000070_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_kind_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_pool_kind_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_parts_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_pool_parts_A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_shared_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_pool_shared_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_emit_pool_str_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_pool_str_A_fn_class *jrt.Class



type A_arbace_c2j_emit_prim_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_prim_A_fn_class *jrt.Class



type A_arbace_c2j_emit_public_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_public_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_emit_registered_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_registered_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_emit_registered_QMARK__fn__31000021_A struct{ j2g_header uint64; F_c any }

var A_arbace_c2j_emit_registered_QMARK__fn__31000021_A_fn_class *jrt.Class



type A_arbace_c2j_emit_registered_QMARK__fn__31000023_A struct{ j2g_header uint64; F_n any }

var A_arbace_c2j_emit_registered_QMARK__fn__31000023_A_fn_class *jrt.Class



type A_arbace_c2j_emit_registered_QMARK__fn__31000023_fn__31000024_A struct{ j2g_header uint64; F_k any }

var A_arbace_c2j_emit_registered_QMARK__fn__31000023_fn__31000024_A_fn_class *jrt.Class



type A_arbace_c2j_emit_ret_body_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_ret_body_A_fn_class *jrt.Class



type A_arbace_c2j_emit_runtime_class_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_runtime_class_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_emit_simple_name_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_simple_name_A_fn_class *jrt.Class



type A_arbace_c2j_emit_tag_class_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_tag_class_A_fn_class *jrt.Class



type A_arbace_c2j_emit_tagged_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_tagged_A_fn_class *jrt.Class



type A_arbace_c2j_emit_throws_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_throws_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_emit_top_name_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_top_name_A_fn_class *jrt.Class



type A_arbace_c2j_emit_type_sym_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_type_sym_A_fn_class *jrt.Class



type A_arbace_c2j_emit_typed_args_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_typed_args_A_fn_class *jrt.Class



type A_arbace_c2j_emit_typed_args_fn__31000144_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_typed_args_fn__31000144_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unbox_arg_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_unbox_arg_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_unit_method_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_fn__31000616_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_unit_method_fn__31000616_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000554__31000558_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_unit_method_iter__31000554__31000558_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_A struct{ j2g_header uint64; F_s__31000555, F_iter__31000554, F_ctx any }

var A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_A struct{ j2g_header uint64; F_b__31000557, F_ctx any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000562_A struct{ j2g_header uint64; F_n any }

var A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000562_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000564_A struct{ j2g_header uint64; F_n any }

var A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000564_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000566_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000566_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000568_A struct{ j2g_header uint64; F_n any }

var A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000568_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000570_A struct{ j2g_header uint64; F_n any }

var A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000560_fn__31000570_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000574_A struct{ j2g_header uint64; F_n any }

var A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000574_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000576_A struct{ j2g_header uint64; F_n any }

var A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000576_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000578_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000578_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000580_A struct{ j2g_header uint64; F_n any }

var A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000580_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000582_A struct{ j2g_header uint64; F_n any }

var A_arbace_c2j_emit_unit_method_iter__31000554__31000558_fn__31000559_fn__31000582_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000586__31000590_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_unit_method_iter__31000586__31000590_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_A struct{ j2g_header uint64; F_s__31000587, F_iter__31000586, F_ctx any }

var A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_A struct{ j2g_header uint64; F_b__31000589, F_ctx any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_A struct{ j2g_header uint64; F_s__31000594, F_iter__31000593, F_ctx any }

var A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_fn__31000599_A struct{ j2g_header uint64; F_ctx, F_b__31000596 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_fn__31000592_iter__31000593__31000597_fn__31000598_fn__31000599_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_A struct{ j2g_header uint64; F_ctx any }

var A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_A struct{ j2g_header uint64; F_iter__31000604, F_s__31000605, F_ctx any }

var A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_fn__31000610_A struct{ j2g_header uint64; F_b__31000607, F_ctx any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_emit_unit_method_iter__31000586__31000590_fn__31000591_iter__31000604__31000608_fn__31000609_fn__31000610_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unit_ns_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_unit_ns_A_fn_class *jrt.Class



type A_arbace_c2j_emit_unnamed_package_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_unnamed_package_A_fn_class *jrt.Class



type A_arbace_c2j_emit_var_value_A struct{ j2g_header uint64 }

var A_arbace_c2j_emit_var_value_A_fn_class *jrt.Class
