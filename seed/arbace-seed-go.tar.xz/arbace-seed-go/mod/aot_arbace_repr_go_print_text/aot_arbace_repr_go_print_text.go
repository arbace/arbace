//line aot_arbace_repr_go_print_text.ae:1
package aot_arbace_repr_go_print_text

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A_New() *A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_text_A_const_1); lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_text_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A_New() *A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_repr_go_print_text_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_repr_go_print_text_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_print_text_A_const_7.GetRawRoot__O(), A_arbace_repr_go_print_text_A_const_8) }
































func A_arbace_repr_go_print_text_go_printable_QMARK__A_New() *A_arbace_repr_go_print_text_go_printable_QMARK__A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_printable_QMARK__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_repr_go_print_text_go_printable_QMARK__A) Ctor() {}
//line :34:1
func (t *A_arbace_repr_go_print_text_go_printable_QMARK__A) InvokePrim_O_J__O(self any, cp__0 int64) any { var or__1927000174__auto____2 bool = lang.Numbers_Equiv_J_J__Z_NoInit(cp__0, 32); if or__1927000174__auto____2 {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_9.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_text_A_const_10; var or__1927000174__auto____3 any = tmp1.Invoke_O_O_O__O(tmp2, jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref(), A_arbace_repr_go_print_text_A_const_11); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else {

		var root_25 any = A_arbace_repr_go_print_text_A_const_12.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = A_arbace_repr_go_print_text_A_const_13.GetRawRoot__O(); var arg_29 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_I__I_NoInit(jrt.Character_GetType_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(cp__0)))).Ref(); if linked_26 == nil { return ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { return linked_26.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_25, arg_28, arg_29) } } } }
//line :34:1
func (t *A_arbace_repr_go_print_text_go_printable_QMARK__A) Invoke_O_O__O(self, p_cp__0 any) any { return t.InvokePrim_O_J__O(self, lang.RT_LongCast_O__J_NoInit(p_cp__0)) }







func A_arbace_repr_go_print_text_hex_A_New() *A_arbace_repr_go_print_text_hex_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_hex_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_repr_go_print_text_hex_A) Ctor() {}
//line :42:1
func (t *A_arbace_repr_go_print_text_hex_A) InvokePrim_O_J_J__O(self any, n__0, width__1 int64) any { var s__3 any = jrt.Long_ToHexString_J__String_NoInit(n__0).Ref(); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_30 any = A_arbace_repr_go_print_text_A_const_14.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_32 lang.IFn; if

	linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = A_arbace_repr_go_print_text_A_const_15.GetRawRoot__O(); var arg_34 any; var root_35 any = A_arbace_repr_go_print_text_A_const_16.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(width__1, int64(lang.RT_Count_O__I_NoInit(s__3)))).Ref(); var arg_39 any = A_arbace_repr_go_print_text_A_const_17; if linked_36 == nil { arg_34 = ifn_37.Invoke_O_O__O(arg_38, arg_39) } else { arg_34 = linked_36.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_35, arg_38, arg_39) }; if linked_31 == nil { tmp2 = ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { tmp2 = linked_31.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, s__3)).Ref() }
//line :42:1
func (t *A_arbace_repr_go_print_text_hex_A) Invoke_O_O_O__O(self, p_n__0, p_width__1 any) any { return t.InvokePrim_O_J_J__O(self, lang.RT_LongCast_O__J_NoInit(p_n__0), lang.RT_LongCast_O__J_NoInit(p_width__1)) }



func A_arbace_repr_go_print_text_escape_cp_A_New() *A_arbace_repr_go_print_text_escape_cp_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_escape_cp_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_repr_go_print_text_escape_cp_A) Ctor() {}
//line :46:1
func (t *A_arbace_repr_go_print_text_escape_cp_A) InvokePrim_O_J_O__O(self any, cp__0 int64, quote__1 any) any { var G__1242000014__3_ int32 = lang.RT_IntCast_J__I_NoInit(cp__0); switch G__1242000014__3_ {


case 7: return Lit_4; case 8: return Lit_5; case 9: return Lit_6; case 10: return Lit_7; case 11: return Lit_8; case 12: return Lit_9; case 13: return Lit_10; case 92: return Lit_11; default:}; if

	lang.Numbers_Equiv_J_J__Z_NoInit(cp__0, lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(quote__1))) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, quote__1)).Ref() } else {
//line :51:1
			var tmp1 any; var root_41 any = A_arbace_repr_go_print_text_A_const_18.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_41, A_arbace_repr_go_print_text_go_printable_QMARK__A_fn_class); var ifn_43 lang.IFn

			if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 int64 = cp__0; if linked_42 == nil { tmp1 = ifn_43.Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_44).Ref()) } else { tmp1 = linked_42.(*A_arbace_repr_go_print_text_go_printable_QMARK__A).InvokePrim_O_J__O(root_41, arg_44) }
//line :51:1
			if jrt.J2g_Truth(tmp1) { return jrt.String_New_C1(jrt.Character_ToChars_I__C1_NoInit(lang.RT_IntCast_J__I_NoInit(cp__0))) } else { if lang.Numbers_Lt_J_J__Z_NoInit(cp__0, 128) {


				var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil); var tmp3 any; var root_45 any = A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_45, A_arbace_repr_go_print_text_hex_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 int64 = cp__0; if linked_46 == nil { tmp3 = ifn_47.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_48).Ref(), A_arbace_repr_go_print_text_A_const_20) } else { tmp3 = linked_46.(*A_arbace_repr_go_print_text_hex_A).InvokePrim_O_J_J__O(root_45, arg_48, 2) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
//line :51:1
					if lang.Numbers_Lte_J_J__Z_NoInit(cp__0, 65535) {



						var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp5 any; var root_50 any = A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_50, A_arbace_repr_go_print_text_hex_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 int64 = cp__0; if linked_51 == nil { tmp5 = ifn_52.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_53).Ref(), A_arbace_repr_go_print_text_A_const_21) } else { tmp5 = linked_51.(*A_arbace_repr_go_print_text_hex_A).InvokePrim_O_J_J__O(root_50, arg_53, 4) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref() } else {
//line :51:1
							if A_arbace_repr_go_print_text_A_const_22 != nil {




								var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil); var tmp7 any; var root_55 any = A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_55, A_arbace_repr_go_print_text_hex_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 int64 = cp__0; if linked_56 == nil { tmp7 = ifn_57.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_58).Ref(), A_arbace_repr_go_print_text_A_const_23) } else { tmp7 = linked_56.(*A_arbace_repr_go_print_text_hex_A).InvokePrim_O_J_J__O(root_55, arg_58, 8) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref() } else {
//line :51:1
									return nil } } } } } }
//line :46:1
func (t *A_arbace_repr_go_print_text_escape_cp_A) Invoke_O_O_O__O(self, p_cp__0, quote__1 any) any { return t.InvokePrim_O_J_O__O(self, lang.RT_LongCast_O__J_NoInit(p_cp__0), quote__1) }











func A_arbace_repr_go_print_text_code_points_A_New() *A_arbace_repr_go_print_text_code_points_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_code_points_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_repr_go_print_text_code_points_A) Ctor() {}
//line :58:1
func (t *A_arbace_repr_go_print_text_code_points_A) Invoke_O_O__O(self, s__0 any) any { { var i__2 int64 = 0; var acc__3 any; var root_60 any = A_arbace_repr_go_print_text_A_const_24.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_62 lang.IFn



	if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = lang.PersistentVector_EMPTY.Ref(); if linked_61 == nil { acc__3 = ifn_62.Invoke_O__O(arg_63) } else { acc__3 = linked_61.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_60, arg_63) }
//line :58:1
L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__2, int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())) { var cp__4 int32 = jrt.NN(jrt.String_Cast(s__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(i__2)); var tmp1 bool; var and__1927000168__auto____5 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(cp__4), 55296)

		if and__1927000168__auto____5 { tmp1 = lang.Numbers_Lte_J_J__Z_NoInit(int64(cp__4), 57343) } else { tmp1 = and__1927000168__auto____5 }; if tmp1 { var tmp2 any; var root_68 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_70 lang.IFn
			if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(s__0))).Ref(); var arg_72 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_28, s__0)); if linked_69 == nil { tmp2 = ifn_70.Invoke_O_O__O(arg_71, arg_72) } else { tmp2 = linked_69.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_68, arg_71, arg_72) }
//line :65:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp2)))
		}
		var tmp3 int64 = lang.Numbers_Add_J_J__J_NoInit(i__2, int64(jrt.Character_CharCount_I__I_NoInit(cp__4))); var tmp4 any; var root_77 any = A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = acc__3; var arg_81 any = jrt.Integer_ValueOf_I__Integer_NoInit(cp__4).Ref(); if linked_78 == nil { tmp4 = ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { tmp4 = linked_78.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_77, arg_80, arg_81) }; i__2, acc__3 = tmp3, tmp4; continue L1 } else {
			var root_64 any = A_arbace_repr_go_print_text_A_const_25.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = acc__3; if linked_65 == nil { return ifn_66.Invoke_O__O(arg_67) } else { return linked_65.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_64, arg_67) } } } }; /*line :58:1*/panic("j2g: unreachable") }











func A_arbace_repr_go_print_text_go_string_A_New() *A_arbace_repr_go_print_text_go_string_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_string_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_repr_go_print_text_go_string_A) Ctor() {}
//line :70:1
func (t *A_arbace_repr_go_print_text_go_string_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_23); var seq_1242000017__3 any; var root_82 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_84 lang.IFn; if



	linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any; var root_86 any = A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, A_arbace_repr_go_print_text_code_points_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = s__0; if linked_87 == nil { arg_85 = ifn_88.Invoke_O__O(arg_89) } else { arg_85 = linked_87.(*A_arbace_repr_go_print_text_code_points_A).Invoke_O_O__O(root_86, arg_89) }; if linked_83 == nil { seq_1242000017__3 = ifn_84.Invoke_O__O(arg_85) } else { seq_1242000017__3 = linked_83.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_82, arg_85) }; var chunk_1242000018__4 any; var count_1242000019__5 int64 = 0; var i_1242000020__6 int64 = 0; L1:
//line :70:1
	for {



		if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000020__6, count_1242000019__5) { var cp__7 any = lang.Indexed_Cast(chunk_1242000018__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000020__6)); var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp2 any; var root_106 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_106, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_108 lang.IFn
			if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = cp__7; var arg_110 any = A_arbace_repr_go_print_text_A_const_36; if linked_107 == nil { tmp2 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { tmp2 = linked_107.(*A_arbace_repr_go_print_text_escape_cp_A).InvokePrim_O_J_O__O(root_106, lang.RT_LongCast_O__J_NoInit(arg_109), arg_110) }; jrt.NN(tmp1).Append_String__StringBuilder(jrt.String_Cast(tmp2))
//line :74:1
			seq_1242000017__3, chunk_1242000018__4, count_1242000019__5, i_1242000020__6 = seq_1242000017__3, chunk_1242000018__4, count_1242000019__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000020__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_90 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = seq_1242000017__3; if linked_91 == nil { temp__1927000414__auto____7 = ifn_92.Invoke_O__O(arg_93) } else { temp__1927000414__auto____7 = linked_91.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_90, arg_93) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1242000017__8 any = temp__1927000414__auto____7; var tmp3 any; var root_94 any = A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = seq_1242000017__8; if linked_95 == nil { tmp3 = ifn_96.Invoke_O__O(arg_97) } else { tmp3 = linked_95.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_94, arg_97) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____9 any; var root_98 any = A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = seq_1242000017__8; if linked_99 == nil { c__1927000678__auto____9 = ifn_100.Invoke_O__O(arg_101) } else { c__1927000678__auto____9 = linked_99.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_98, arg_101) }; var tmp4 any; var root_111 any = A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = seq_1242000017__8; if linked_112 == nil { tmp4 = ifn_113.Invoke_O__O(arg_114) } else { tmp4 = linked_112.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_111, arg_114) }; seq_1242000017__3, chunk_1242000018__4, count_1242000019__5, i_1242000020__6 = tmp4, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var cp__9 any; var root_102 any = A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = seq_1242000017__8; if linked_103 == nil { cp__9 = ifn_104.Invoke_O__O(arg_105) } else { cp__9 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }
				var tmp5 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp6 any; var root_115 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_115, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = cp__9; var arg_119 any = A_arbace_repr_go_print_text_A_const_36; if linked_116 == nil { tmp6 = ifn_117.Invoke_O_O__O(arg_118, arg_119) } else { tmp6 = linked_116.(*A_arbace_repr_go_print_text_escape_cp_A).InvokePrim_O_J_O__O(root_115, lang.RT_LongCast_O__J_NoInit(arg_118), arg_119) }; jrt.NN(tmp5).Append_String__StringBuilder(jrt.String_Cast(tmp6))
//line :74:1
				var tmp7 any; var root_120 any = A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = seq_1242000017__8; if linked_121 == nil { tmp7 = ifn_122.Invoke_O__O(arg_123) } else { tmp7 = linked_121.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_120, arg_123) }; seq_1242000017__3, chunk_1242000018__4, count_1242000019__5, i_1242000020__6 = tmp7, nil, 0, 0; continue L1 } } }
//line :70:1
		break L1 };





	jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_23); return /*line :77:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_repr_go_print_text_raw_string_ok_QMARK__A_New() *A_arbace_repr_go_print_text_raw_string_ok_QMARK__A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_raw_string_ok_QMARK__A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_repr_go_print_text_raw_string_ok_QMARK__A) Ctor() {}
//line :79:1
func (t *A_arbace_repr_go_print_text_raw_string_ok_QMARK__A) Invoke_O_O__O(self, s__0 any) any {



	var root_124 any = A_arbace_repr_go_print_text_A_const_39.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any; var tmp1 any = A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_New(); var tmp2 *jrt.Class; var fncls__175 *jrt.Class = A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_fn_class; if fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_fn_class = fncls__175d; tmp2 = fncls__175d } else { tmp2 = fncls__175 }; arg_127 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_128 any; var root_176 any = A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, A_arbace_repr_go_print_text_code_points_A_fn_class); var ifn_178 lang.IFn

	if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = s__0; if linked_177 == nil { arg_128 = ifn_178.Invoke_O__O(arg_179) } else { arg_128 = linked_177.(*A_arbace_repr_go_print_text_code_points_A).Invoke_O_O__O(root_176, arg_179) }
//line :83:1
	if linked_125 == nil { return ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { return linked_125.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_124, arg_127, arg_128) } }
//line :83:1
func A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_New() *A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A) Ctor() {}
//line :83:1
func (t *A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A) Invoke_O_O__O(self, cp__1 any) any { if jrt.Long_InstanceOf(cp__1) { return t.InvokeSpec_O_J_O__O(self, jrt.NN(jrt.Long_Cast(cp__1)).LongValue__J(), cp__1) } else { var and__1927000168__auto____2 any; var root_129 any = A_arbace_repr_go_print_text_A_const_40.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = cp__1; var arg_133 any = A_arbace_repr_go_print_text_A_const_41; if linked_130 == nil { and__1927000168__auto____2 = ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { and__1927000168__auto____2 = linked_130.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_129, arg_132, arg_133) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_134 any = A_arbace_repr_go_print_text_A_const_40.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = cp__1; var arg_138 any = A_arbace_repr_go_print_text_A_const_42; if linked_135 == nil { and__1927000168__auto____3 = ifn_136.Invoke_O_O__O(arg_137, arg_138) } else { and__1927000168__auto____3 = linked_135.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_134, arg_137, arg_138) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool; var na_139 any = cp__1; var na_140 int64 = 9
														if jrt.Long_InstanceOf(na_139) { var n0_141 int64 = jrt.NN(jrt.Long_Cast(na_139)).LongValue__J(); var n1_142 int64 = na_140; or__1927000174__auto____4 = n0_141 == n1_142 } else { or__1927000174__auto____4 = lang.Numbers_Equiv_O_J__Z_NoInit(na_139, na_140) }; if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool; var na_144 any = cp__1; var na_145 int64 = 10; if jrt.Long_InstanceOf(na_144) { var n0_146 int64 = jrt.NN(jrt.Long_Cast(na_144)).LongValue__J(); var n1_147 int64 = na_145; or__1927000174__auto____5 = n0_146 == n1_147 } else { or__1927000174__auto____5 = lang.Numbers_Equiv_O_J__Z_NoInit(na_144, na_145) }; if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_149 any = A_arbace_repr_go_print_text_A_const_18.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_149, A_arbace_repr_go_print_text_go_printable_QMARK__A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = cp__1; if linked_150 == nil { return ifn_151.Invoke_O__O(arg_152) } else { return linked_150.(*A_arbace_repr_go_print_text_go_printable_QMARK__A).InvokePrim_O_J__O(root_149, lang.RT_LongCast_O__J_NoInit(arg_152)) } } } } else {
//line :83:1
		return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } } }
//line :83:1
func (t *A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A) InvokeSpec_O_J_O__O(self any, cp__1_l int64, cp__1_b any) any { var and__1927000168__auto____2 any; var root_153 any = A_arbace_repr_go_print_text_A_const_40.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any; if cp__1_b == nil { cp__1_b = jrt.Long_ValueOf_J__Long_NoInit(cp__1_l).Ref(); arg_156 = cp__1_b } else { arg_156 = cp__1_b }; var arg_157 any = A_arbace_repr_go_print_text_A_const_41; if linked_154 == nil { and__1927000168__auto____2 = ifn_155.Invoke_O_O__O(arg_156, arg_157) } else { and__1927000168__auto____2 = linked_154.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_153, arg_156, arg_157) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_158 any = A_arbace_repr_go_print_text_A_const_40.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any; if cp__1_b == nil { cp__1_b = jrt.Long_ValueOf_J__Long_NoInit(cp__1_l).Ref(); arg_161 = cp__1_b } else { arg_161 = cp__1_b }; var arg_162 any = A_arbace_repr_go_print_text_A_const_42; if linked_159 == nil { and__1927000168__auto____3 = ifn_160.Invoke_O_O__O(arg_161, arg_162) } else { and__1927000168__auto____3 = linked_159.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_158, arg_161, arg_162) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool; var na_163 int64 = 9; var n0_164 int64 = cp__1_l; var n1_165 int64 = na_163
																		or__1927000174__auto____4 = n0_164 == n1_165; if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool; var na_167 int64 = 10; var n0_168 int64 = cp__1_l; var n1_169 int64 = na_167; or__1927000174__auto____5 = n0_168 == n1_169; if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_171 any = A_arbace_repr_go_print_text_A_const_18.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_171, A_arbace_repr_go_print_text_go_printable_QMARK__A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any; if cp__1_b == nil { cp__1_b = jrt.Long_ValueOf_J__Long_NoInit(cp__1_l).Ref(); arg_174 = cp__1_b } else { arg_174 = cp__1_b }; if linked_172 == nil { return ifn_173.Invoke_O__O(arg_174) } else { return linked_172.(*A_arbace_repr_go_print_text_go_printable_QMARK__A).InvokePrim_O_J__O(root_171, lang.RT_LongCast_O__J_NoInit(arg_174)) } } } } else {
//line :83:1
		return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_repr_go_print_text_go_byte_string_A_New() *A_arbace_repr_go_print_text_go_byte_string_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_byte_string_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_repr_go_print_text_go_byte_string_A) Ctor() {}
//line :87:1
func (t *A_arbace_repr_go_print_text_go_byte_string_A) Invoke_O_O__O(self, parts__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_23); var seq_1242000025__3 any; var root_180 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_182 lang.IFn; if




	linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = parts__0; if linked_181 == nil { seq_1242000025__3 = ifn_182.Invoke_O__O(arg_183) } else { seq_1242000025__3 = linked_181.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_180, arg_183) }; var chunk_1242000026__4 any; var count_1242000027__5 int64 = 0; var i_1242000028__6 int64 = 0; L1:
//line :87:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000028__6, count_1242000027__5) { var p__7 any = lang.Indexed_Cast(chunk_1242000026__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000028__6)); var tmp1 any; var root_200 any = A_arbace_repr_go_print_text_A_const_43.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_202 lang.IFn

			if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = p__7; if linked_201 == nil { tmp1 = ifn_202.Invoke_O__O(arg_203) } else { tmp1 = linked_201.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_200, arg_203) }
//line :93:1
			if jrt.J2g_Truth(tmp1) { var seq_1242000029__8 any; var root_204 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_206 lang.IFn
				if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any; var root_208 any = A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_repr_go_print_text_code_points_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = p__7; if linked_209 == nil { arg_207 = ifn_210.Invoke_O__O(arg_211) } else { arg_207 = linked_209.(*A_arbace_repr_go_print_text_code_points_A).Invoke_O_O__O(root_208, arg_211) }; if linked_205 == nil { seq_1242000029__8 = ifn_206.Invoke_O__O(arg_207) } else { seq_1242000029__8 = linked_205.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_204, arg_207) }
//line :93:1
				var chunk_1242000030__9 any; var count_1242000031__10 int64 = 0; var i_1242000032__11 int64 = 0; L2: for {
					if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000032__11, count_1242000031__10) { var cp__12 any = lang.Indexed_Cast(chunk_1242000030__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000032__11)); var tmp2 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp3 any; var root_252 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_252, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = cp__12; var arg_256 any = A_arbace_repr_go_print_text_A_const_36; if linked_253 == nil { tmp3 = ifn_254.Invoke_O_O__O(arg_255, arg_256) } else { tmp3 = linked_253.(*A_arbace_repr_go_print_text_escape_cp_A).InvokePrim_O_J_O__O(root_252, lang.RT_LongCast_O__J_NoInit(arg_255), arg_256) }; jrt.NN(tmp2).Append_String__StringBuilder(jrt.String_Cast(tmp3)); seq_1242000029__8, chunk_1242000030__9, count_1242000031__10, i_1242000032__11 = seq_1242000029__8, chunk_1242000030__9, count_1242000031__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000032__11); continue L2 } else { var temp__1927000414__auto____12 any; var root_212 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = seq_1242000029__8; if linked_213 == nil { temp__1927000414__auto____12 = ifn_214.Invoke_O__O(arg_215) } else { temp__1927000414__auto____12 = linked_213.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_212, arg_215) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1242000029__13 any = temp__1927000414__auto____12; var tmp4 any; var root_216 any = A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = seq_1242000029__13; if linked_217 == nil { tmp4 = ifn_218.Invoke_O__O(arg_219) } else { tmp4 = linked_217.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_216, arg_219) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____14 any; var root_220 any = A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = seq_1242000029__13; if linked_221 == nil { c__1927000678__auto____14 = ifn_222.Invoke_O__O(arg_223) } else { c__1927000678__auto____14 = linked_221.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_220, arg_223) }; var tmp5 any; var root_257 any = A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = seq_1242000029__13; if linked_258 == nil { tmp5 = ifn_259.Invoke_O__O(arg_260) } else { tmp5 = linked_258.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_257, arg_260) }; seq_1242000029__8, chunk_1242000030__9, count_1242000031__10, i_1242000032__11 = tmp5, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var cp__14 any; var root_224 any = A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = seq_1242000029__13; if linked_225 == nil { cp__14 = ifn_226.Invoke_O__O(arg_227) } else { cp__14 = linked_225.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_224, arg_227) }; var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp7 any; var root_261 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_261, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = cp__14; var arg_265 any = A_arbace_repr_go_print_text_A_const_36; if linked_262 == nil { tmp7 = ifn_263.Invoke_O_O__O(arg_264, arg_265) } else { tmp7 = linked_262.(*A_arbace_repr_go_print_text_escape_cp_A).InvokePrim_O_J_O__O(root_261, lang.RT_LongCast_O__J_NoInit(arg_264), arg_265) }; jrt.NN(tmp6).Append_String__StringBuilder(jrt.String_Cast(tmp7)); var tmp8 any; var root_266 any = A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = seq_1242000029__13; if linked_267 == nil { tmp8 = ifn_268.Invoke_O__O(arg_269) } else { tmp8 = linked_267.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_266, arg_269) }; seq_1242000029__8, chunk_1242000030__9, count_1242000031__10, i_1242000032__11 = tmp8, nil, 0, 0; continue L2 } } }
//line :93:1
					break L2 } } else { var tmp9 any; var and__1927000168__auto____8 any; var root_228 any = A_arbace_repr_go_print_text_A_const_44.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_230 lang.IFn

						if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = p__7; if linked_229 == nil { and__1927000168__auto____8 = ifn_230.Invoke_O__O(arg_231) } else { and__1927000168__auto____8 = linked_229.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_228, arg_231) }; if jrt.J2g_Truth(and__1927000168__auto____8) { tmp9 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_45.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_text_A_const_46, p__7, A_arbace_repr_go_print_text_A_const_47) } else { tmp9 = and__1927000168__auto____8 }
//line :93:1
						if jrt.J2g_Truth(tmp9) {

							var tmp10 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil); var tmp12 any; var root_238 any = A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_238, A_arbace_repr_go_print_text_hex_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 int64 = lang.RT_LongCast_O__J_NoInit(p__7); if linked_239 == nil { tmp12 = ifn_240.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_241).Ref(), A_arbace_repr_go_print_text_A_const_20) } else { tmp12 = linked_239.(*A_arbace_repr_go_print_text_hex_A).InvokePrim_O_J_J__O(root_238, arg_241, 2) }; jrt.NN(tmp10).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12))) } else {
//line :93:1
								if A_arbace_repr_go_print_text_A_const_22 != nil { var tmp13 any; var root_243 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_245 lang.IFn


									if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(p__7))).Ref(); var arg_247 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_48, p__7)); if linked_244 == nil { tmp13 = ifn_245.Invoke_O_O__O(arg_246, arg_247) } else { tmp13 = linked_244.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_243, arg_246, arg_247) }
//line :93:1
									panic(jrt.Thrown(jrt.Throwable_Cast(tmp13))) } } }
//line :92:1
			seq_1242000025__3, chunk_1242000026__4, count_1242000027__5, i_1242000028__6 = seq_1242000025__3, chunk_1242000026__4, count_1242000027__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000028__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_184 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = seq_1242000025__3; if linked_185 == nil { temp__1927000414__auto____7 = ifn_186.Invoke_O__O(arg_187) } else { temp__1927000414__auto____7 = linked_185.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_184, arg_187) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1242000025__8 any = temp__1927000414__auto____7; var tmp14 any; var root_188 any = A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = seq_1242000025__8; if linked_189 == nil { tmp14 = ifn_190.Invoke_O__O(arg_191) } else { tmp14 = linked_189.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_188, arg_191) }; if jrt.J2g_Truth(tmp14) { var c__1927000678__auto____9 any; var root_192 any = A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = seq_1242000025__8; if linked_193 == nil { c__1927000678__auto____9 = ifn_194.Invoke_O__O(arg_195) } else { c__1927000678__auto____9 = linked_193.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_192, arg_195) }; var tmp15 any; var root_270 any = A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = seq_1242000025__8; if linked_271 == nil { tmp15 = ifn_272.Invoke_O__O(arg_273) } else { tmp15 = linked_271.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_270, arg_273) }; seq_1242000025__3, chunk_1242000026__4, count_1242000027__5, i_1242000028__6 = tmp15, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__9 any; var root_196 any = A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = seq_1242000025__8; if linked_197 == nil { p__9 = ifn_198.Invoke_O__O(arg_199) } else { p__9 = linked_197.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_196, arg_199) }
				var tmp16 any; var root_274 any = A_arbace_repr_go_print_text_A_const_43.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_276 lang.IFn
				if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = p__9; if linked_275 == nil { tmp16 = ifn_276.Invoke_O__O(arg_277) } else { tmp16 = linked_275.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_274, arg_277) }
//line :93:1
				if jrt.J2g_Truth(tmp16) { var seq_1242000033__10 any; var root_278 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_280 lang.IFn
					if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any; var root_282 any = A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, A_arbace_repr_go_print_text_code_points_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = p__9; if linked_283 == nil { arg_281 = ifn_284.Invoke_O__O(arg_285) } else { arg_281 = linked_283.(*A_arbace_repr_go_print_text_code_points_A).Invoke_O_O__O(root_282, arg_285) }; if linked_279 == nil { seq_1242000033__10 = ifn_280.Invoke_O__O(arg_281) } else { seq_1242000033__10 = linked_279.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_278, arg_281) }
//line :93:1
					var chunk_1242000034__11 any; var count_1242000035__12 int64 = 0; var i_1242000036__13 int64 = 0; L3: for {
						if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000036__13, count_1242000035__12) { var cp__14_2 any = lang.Indexed_Cast(chunk_1242000034__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000036__13)); var tmp17 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp18 any; var root_326 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_326, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = cp__14_2; var arg_330 any = A_arbace_repr_go_print_text_A_const_36; if linked_327 == nil { tmp18 = ifn_328.Invoke_O_O__O(arg_329, arg_330) } else { tmp18 = linked_327.(*A_arbace_repr_go_print_text_escape_cp_A).InvokePrim_O_J_O__O(root_326, lang.RT_LongCast_O__J_NoInit(arg_329), arg_330) }; jrt.NN(tmp17).Append_String__StringBuilder(jrt.String_Cast(tmp18)); seq_1242000033__10, chunk_1242000034__11, count_1242000035__12, i_1242000036__13 = seq_1242000033__10, chunk_1242000034__11, count_1242000035__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000036__13); continue L3 } else { var temp__1927000414__auto____14 any; var root_286 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = seq_1242000033__10; if linked_287 == nil { temp__1927000414__auto____14 = ifn_288.Invoke_O__O(arg_289) } else { temp__1927000414__auto____14 = linked_287.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_286, arg_289) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1242000033__15 any = temp__1927000414__auto____14; var tmp19 any; var root_290 any = A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = seq_1242000033__15; if linked_291 == nil { tmp19 = ifn_292.Invoke_O__O(arg_293) } else { tmp19 = linked_291.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_290, arg_293) }; if jrt.J2g_Truth(tmp19) { var c__1927000678__auto____16 any; var root_294 any = A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = seq_1242000033__15; if linked_295 == nil { c__1927000678__auto____16 = ifn_296.Invoke_O__O(arg_297) } else { c__1927000678__auto____16 = linked_295.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_294, arg_297) }; var tmp20 any; var root_331 any = A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = seq_1242000033__15; if linked_332 == nil { tmp20 = ifn_333.Invoke_O__O(arg_334) } else { tmp20 = linked_332.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_331, arg_334) }; seq_1242000033__10, chunk_1242000034__11, count_1242000035__12, i_1242000036__13 = tmp20, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var cp__16 any; var root_298 any = A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = seq_1242000033__15; if linked_299 == nil { cp__16 = ifn_300.Invoke_O__O(arg_301) } else { cp__16 = linked_299.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_298, arg_301) }; var tmp21 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp22 any; var root_335 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_335, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_337 lang.IFn; if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any = cp__16; var arg_339 any = A_arbace_repr_go_print_text_A_const_36; if linked_336 == nil { tmp22 = ifn_337.Invoke_O_O__O(arg_338, arg_339) } else { tmp22 = linked_336.(*A_arbace_repr_go_print_text_escape_cp_A).InvokePrim_O_J_O__O(root_335, lang.RT_LongCast_O__J_NoInit(arg_338), arg_339) }; jrt.NN(tmp21).Append_String__StringBuilder(jrt.String_Cast(tmp22)); var tmp23 any; var root_340 any = A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_342 lang.IFn; if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = seq_1242000033__15; if linked_341 == nil { tmp23 = ifn_342.Invoke_O__O(arg_343) } else { tmp23 = linked_341.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_340, arg_343) }; seq_1242000033__10, chunk_1242000034__11, count_1242000035__12, i_1242000036__13 = tmp23, nil, 0, 0; continue L3 } } }
//line :93:1
						break L3 } } else { var tmp24 any; var and__1927000168__auto____10 any; var root_302 any = A_arbace_repr_go_print_text_A_const_44.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_304 lang.IFn

							if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = p__9; if linked_303 == nil { and__1927000168__auto____10 = ifn_304.Invoke_O__O(arg_305) } else { and__1927000168__auto____10 = linked_303.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_302, arg_305) }; if jrt.J2g_Truth(and__1927000168__auto____10) { tmp24 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_45.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_text_A_const_46, p__9, A_arbace_repr_go_print_text_A_const_47) } else { tmp24 = and__1927000168__auto____10 }
//line :93:1
							if jrt.J2g_Truth(tmp24) {

								var tmp25 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil); var tmp27 any; var root_312 any = A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_312, A_arbace_repr_go_print_text_hex_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 int64 = lang.RT_LongCast_O__J_NoInit(p__9); if linked_313 == nil { tmp27 = ifn_314.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_315).Ref(), A_arbace_repr_go_print_text_A_const_20) } else { tmp27 = linked_313.(*A_arbace_repr_go_print_text_hex_A).InvokePrim_O_J_J__O(root_312, arg_315, 2) }; jrt.NN(tmp25).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp27))) } else {
//line :93:1
									if A_arbace_repr_go_print_text_A_const_22 != nil { var tmp28 any; var root_317 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_319 lang.IFn


										if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(p__9))).Ref(); var arg_321 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_48, p__9)); if linked_318 == nil { tmp28 = ifn_319.Invoke_O_O__O(arg_320, arg_321) } else { tmp28 = linked_318.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_317, arg_320, arg_321) }
//line :93:1
										panic(jrt.Thrown(jrt.Throwable_Cast(tmp28))) } } }
//line :92:1
				var tmp29 any; var root_344 any = A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_346 lang.IFn; if linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = seq_1242000025__8; if linked_345 == nil { tmp29 = ifn_346.Invoke_O__O(arg_347) } else { tmp29 = linked_345.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_344, arg_347) }; seq_1242000025__3, chunk_1242000026__4, count_1242000027__5, i_1242000028__6 = tmp29, nil, 0, 0; continue L1 } } }
//line :87:1
		break L1 };









	jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_23); return /*line :98:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_repr_go_print_text_go_rune_A_New() *A_arbace_repr_go_print_text_go_rune_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_rune_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_repr_go_print_text_go_rune_A) Ctor() {}
//line :100:1
func (t *A_arbace_repr_go_print_text_go_rune_A) InvokePrim_O_J__O(self any, cp__0 int64) any {


	var tmp1 bool; var or__1927000174__auto____2 bool = lang.Numbers_IsNeg_J__Z_NoInit(cp__0); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = lang.Numbers_Gt_J_J__Z_NoInit(cp__0, 1114111); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var and__1927000168__auto____4 bool = lang.Numbers_Gte_J_J__Z_NoInit(cp__0, 55296); if and__1927000168__auto____4 { tmp1 = lang.Numbers_Lte_J_J__Z_NoInit(cp__0, 57343) } else { tmp1 = and__1927000168__auto____4 } } }; if tmp1 { var tmp2 any; var root_353 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_355 lang.IFn
		if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref())).Ref(); var tmp3 any = A_arbace_repr_go_print_text_A_const_50; var arg_357 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref())); if linked_354 == nil { tmp2 = ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { tmp2 = linked_354.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_353, arg_356, arg_357) }
//line :103:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2)))
	}
	var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_32, nil, Lit_32); var tmp5 any; var root_348 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_348, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 int64 = cp__0; var arg_352 any = A_arbace_repr_go_print_text_A_const_49; if linked_349 == nil { tmp5 = ifn_350.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_351).Ref(), arg_352) } else { tmp5 = linked_349.(*A_arbace_repr_go_print_text_escape_cp_A).InvokePrim_O_J_O__O(root_348, arg_351, arg_352) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil)).Ref() }
//line :100:1
func (t *A_arbace_repr_go_print_text_go_rune_A) Invoke_O_O__O(self, p_cp__0 any) any { return t.InvokePrim_O_J__O(self, lang.RT_LongCast_O__J_NoInit(p_cp__0)) }






func A_arbace_repr_go_print_text_float_kind_A_New() *A_arbace_repr_go_print_text_float_kind_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_float_kind_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_repr_go_print_text_float_kind_A) Ctor() {}
//line :107:1
func (t *A_arbace_repr_go_print_text_float_kind_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any; var root_358 any = A_arbace_repr_go_print_text_A_const_51.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = s__0; var arg_362 any = Lit_18; if linked_359 == nil { or__1927000174__auto____2 = ifn_360.Invoke_O_O__O(arg_361, arg_362) } else { or__1927000174__auto____2 = linked_359.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_358, arg_361, arg_362) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_363 any = A_arbace_repr_go_print_text_A_const_51.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = s__0; var arg_367 any = Lit_19; if linked_364 == nil { or__1927000174__auto____3 = ifn_365.Invoke_O_O__O(arg_366, arg_367) } else { or__1927000174__auto____3 = linked_364.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_363, arg_366, arg_367) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_368 any = A_arbace_repr_go_print_text_A_const_51.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_368, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = s__0; var arg_372 any = Lit_20; if linked_369 == nil { tmp1 = ifn_370.Invoke_O_O__O(arg_371, arg_372) } else { tmp1 = linked_369.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_368, arg_371, arg_372) } } }; if jrt.J2g_Truth(tmp1) { return s__0 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_21), jrt.RefArrayOf(jrt.Object_class, s__0, nil)).Ref()
	} }
func A_arbace_repr_go_print_text_pow2_exponent_A_New() *A_arbace_repr_go_print_text_pow2_exponent_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_pow2_exponent_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_repr_go_print_text_pow2_exponent_A) Ctor() {}
//line :113:1
func (t *A_arbace_repr_go_print_text_pow2_exponent_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 bool; var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(n__0)).Signum__I())); if and__1927000168__auto____2 { tmp1 = lang.Numbers_Equiv_J_J__Z_NoInit(1, int64(jrt.NN(jrt.BigInteger_Cast(n__0)).BitCount__I())) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(n__0)).BitLength__I()))).Ref() } else { return nil
	} }
func A_arbace_repr_go_print_text_strip_2_5_A_New() *A_arbace_repr_go_print_text_strip_2_5_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_strip_2_5_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_repr_go_print_text_strip_2_5_A) Ctor() {}
//line :118:1
func (t *A_arbace_repr_go_print_text_strip_2_5_A) Invoke_O_O__O(self, n__0 any) any { { var five__2 any = jrt.BigInteger_ValueOf_J__BigInteger(5).Ref(); var n__3 any = n__0; var a__4 int64 = 0; var b__5 int64 = 0; L1: for {




	var tmp1 any; var root_373 any = A_arbace_repr_go_print_text_A_const_52.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_375 lang.IFn
	if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.BigInteger_Cast(n__3)).TestBit_I__Z(lang.RT_IntCast_J__I_NoInit(0))).Ref(); if linked_374 == nil { tmp1 = ifn_375.Invoke_O__O(arg_376) } else { tmp1 = linked_374.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_373, arg_376) }
//line :123:1
	if jrt.J2g_Truth(tmp1) {
		n__3, a__4, b__5 = jrt.NN(jrt.BigInteger_Cast(n__3)).ShiftRight_I__BigInteger(lang.RT_IntCast_J__I_NoInit(1)).Ref(), lang.Numbers_Inc_J__J_NoInit(a__4), b__5; continue L1 } else {
//line :123:1
			if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(n__3)).Mod_BigInteger__BigInteger(jrt.BigInteger_Cast(five__2))).Signum__I())) {

				n__3, a__4, b__5 = jrt.NN(jrt.BigInteger_Cast(n__3)).Divide_BigInteger__BigInteger(jrt.BigInteger_Cast(five__2)).Ref(), a__4, lang.Numbers_Inc_J__J_NoInit(b__5); continue L1 } else {
//line :123:1
					if A_arbace_repr_go_print_text_A_const_22 != nil { return lang.Tuple_Create_O_O_O__IPersistentVector(n__3, jrt.Long_ValueOf_J__Long_NoInit(a__4).Ref(), jrt.Long_ValueOf_J__Long_NoInit(b__5).Ref()) } else { return nil } } } } }; /*line :118:1*/panic("j2g: unreachable") }









func A_arbace_repr_go_print_text_go_float_A_New() *A_arbace_repr_go_print_text_go_float_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_float_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_repr_go_print_text_go_float_A) Ctor() {}
//line :128:1
func (t *A_arbace_repr_go_print_text_go_float_A) Invoke_O_O__O(self, x__0 any) any {




	if jrt.Double_InstanceOf(x__0) { var d__2 float64 = lang.RT_DoubleCast_O__D_NoInit(x__0); var tmp1 bool; var or__1927000174__auto____3 bool = jrt.Double_IsNaN_D__Z_NoInit(d__2)


		if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = jrt.Double_IsInfinite_D__Z_NoInit(d__2) }; if tmp1 { var tmp2 any; var root_444 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_446 lang.IFn
			if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Double_ValueOf_D__Double_NoInit(d__2).Ref())).Ref(); var tmp3 any = A_arbace_repr_go_print_text_A_const_61; var arg_448 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.Double_ValueOf_D__Double_NoInit(d__2).Ref())); if linked_445 == nil { tmp2 = ifn_446.Invoke_O_O__O(arg_447, arg_448) } else { tmp2 = linked_445.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_444, arg_447, arg_448) }
//line :136:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp2)))
		}
		var root_377 any = A_arbace_repr_go_print_text_A_const_53.GetRawRoot__O(); var linked_378 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_377, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_379 lang.IFn; if linked_378 == nil { ifn_379 = lang.IFn_Cast(root_377) } else { ifn_379 = nil }; var arg_380 any = jrt.Double_ToString_D__String_NoInit(d__2).Ref(); if linked_378 == nil { return ifn_379.Invoke_O__O(arg_380) } else { return linked_378.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_377, arg_380) } } else {
//line :133:1
			if jrt.BigDecimal_InstanceOf(x__0) {





				var root_381 any = A_arbace_repr_go_print_text_A_const_54.GetRawRoot__O(); var linked_382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_381, A_arbace_repr_go_print_text_float_kind_A_fn_class); var ifn_383 lang.IFn; if linked_382 == nil { ifn_383 = lang.IFn_Cast(root_381) } else { ifn_383 = nil }; var arg_384 any; var root_385 any = A_arbace_repr_go_print_text_A_const_53.GetRawRoot__O(); var linked_386 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_385, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_387 lang.IFn; if linked_386 == nil { ifn_387 = lang.IFn_Cast(root_385) } else { ifn_387 = nil }; var arg_388 any = jrt.NN(jrt.BigDecimal_Cast(x__0)).ToString__String().Ref(); if linked_386 == nil { arg_384 = ifn_387.Invoke_O__O(arg_388) } else { arg_384 = linked_386.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_385, arg_388) }; if linked_382 == nil { return ifn_383.Invoke_O__O(arg_384) } else { return linked_382.(*A_arbace_repr_go_print_text_float_kind_A).Invoke_O_O__O(root_381, arg_384) } } else {
//line :133:1
					var tmp4 any; var root_389 any = A_arbace_repr_go_print_text_A_const_55.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_391 lang.IFn






					if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = x__0; if linked_390 == nil { tmp4 = ifn_391.Invoke_O__O(arg_392) } else { tmp4 = linked_390.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_389, arg_392) }
//line :133:1
					if jrt.J2g_Truth(tmp4) { var n__2 any; var root_393 any = A_arbace_repr_go_print_text_A_const_56.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_395 lang.IFn







						if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any; var root_397 any = A_arbace_repr_go_print_text_A_const_57.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = x__0; if linked_398 == nil { arg_396 = ifn_399.Invoke_O__O(arg_400) } else { arg_396 = linked_398.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_397, arg_400) }; if linked_394 == nil { n__2 = ifn_395.Invoke_O__O(arg_396) } else { n__2 = linked_394.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_393, arg_396) }
//line :133:1
						var d__3 any; var root_401 any = A_arbace_repr_go_print_text_A_const_56.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_403 lang.IFn







						if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any; var root_405 any = A_arbace_repr_go_print_text_A_const_58.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = x__0; if linked_406 == nil { arg_404 = ifn_407.Invoke_O__O(arg_408) } else { arg_404 = linked_406.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_405, arg_408) }; if linked_402 == nil { d__3 = ifn_403.Invoke_O__O(arg_404) } else { d__3 = linked_402.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_401, arg_404) }
//line :133:1
						var vec__1242000042__4 any; var root_409 any = A_arbace_repr_go_print_text_A_const_59.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, A_arbace_repr_go_print_text_strip_2_5_A_fn_class); var ifn_411 lang.IFn








						if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = d__3; if linked_410 == nil { vec__1242000042__4 = ifn_411.Invoke_O__O(arg_412) } else { vec__1242000042__4 = linked_410.(*A_arbace_repr_go_print_text_strip_2_5_A).Invoke_O_O__O(root_409, arg_412) }
//line :133:1
						var rest__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000042__4, lang.RT_IntCast_J__I_NoInit(0), nil); var a__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000042__4, lang.RT_IntCast_J__I_NoInit(1), nil); var b__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000042__4, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp5 bool; var and__1927000168__auto____8 bool; var tmp6 *jrt.BigInteger










						jrt.BigInteger_Init(); tmp6 = jrt.BigInteger_ONE; and__1927000168__auto____8 = lang.Util_Equiv_O_O__Z_NoInit(rest__5, tmp6.Ref()); if and__1927000168__auto____8 { var na_413 any = lang.Numbers_Max_O_O__O_NoInit(a__6, b__7); var na_414 int64 = 40; if jrt.Long_InstanceOf(na_413) { var n0_415 int64 = jrt.NN(jrt.Long_Cast(na_413)).LongValue__J(); var n1_416 int64 = na_414; tmp5 = n0_415 <= n1_416 } else { tmp5 = lang.Numbers_Lte_O_J__Z_NoInit(na_413, na_414) } } else { tmp5 = and__1927000168__auto____8 }
//line :143:1
						if tmp5 {

							var root_418 any = A_arbace_repr_go_print_text_A_const_54.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, A_arbace_repr_go_print_text_float_kind_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = jrt.NN(jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(n__2)).Divide_BigDecimal__BigDecimal(jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(d__3)))).ToPlainString__String().Ref(); if linked_419 == nil { return ifn_420.Invoke_O__O(arg_421) } else { return linked_419.(*A_arbace_repr_go_print_text_float_kind_A).Invoke_O_O__O(root_418, arg_421) } } else {
//line :143:1
								var tmp7 any; var root_422 any = A_arbace_repr_go_print_text_A_const_60.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, A_arbace_repr_go_print_text_pow2_exponent_A_fn_class); var ifn_424 lang.IFn


								if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = d__3; if linked_423 == nil { tmp7 = ifn_424.Invoke_O__O(arg_425) } else { tmp7 = linked_423.(*A_arbace_repr_go_print_text_pow2_exponent_A).Invoke_O_O__O(root_422, arg_425) }
//line :143:1
								if jrt.J2g_Truth(tmp7) {



									var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27, nil); var tmp9 any = jrt.NN(jrt.BigInteger_Cast(n__2)).ToString_I__String(lang.RT_IntCast_J__I_NoInit(16)).Ref(); var tmp10 any; var root_426 any = A_arbace_repr_go_print_text_A_const_60.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, A_arbace_repr_go_print_text_pow2_exponent_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = d__3; if linked_427 == nil { tmp10 = ifn_428.Invoke_O__O(arg_429) } else { tmp10 = linked_427.(*A_arbace_repr_go_print_text_pow2_exponent_A).Invoke_O_O__O(root_426, arg_429) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil, tmp10)).Ref() } else {
//line :143:1
										if A_arbace_repr_go_print_text_A_const_22 != nil { var tmp11 any; var root_430 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_432 lang.IFn




											if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, x__0, nil)).Ref(); var arg_434 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_61, x__0)); if linked_431 == nil { tmp11 = ifn_432.Invoke_O_O__O(arg_433, arg_434) } else { tmp11 = linked_431.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_430, arg_433, arg_434) }
//line :143:1
											panic(jrt.Thrown(jrt.Throwable_Cast(tmp11))) } else { return nil } } } } else {
//line :133:1
												if A_arbace_repr_go_print_text_A_const_22 != nil { var tmp12 any; var root_435 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_437 lang.IFn















													if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_30, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(x__0))).Ref(); var arg_439 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_61, x__0)); if linked_436 == nil { tmp12 = ifn_437.Invoke_O_O__O(arg_438, arg_439) } else { tmp12 = linked_436.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_435, arg_438, arg_439) }
//line :133:1
													panic(jrt.Thrown(jrt.Throwable_Cast(tmp12))) } else { return nil
													}
											}
				}
		}
}












func A_arbace_repr_go_print_text_negative_number_QMARK__A_New() *A_arbace_repr_go_print_text_negative_number_QMARK__A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_negative_number_QMARK__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_repr_go_print_text_negative_number_QMARK__A) Ctor() {}
//line :151:1
func (t *A_arbace_repr_go_print_text_negative_number_QMARK__A) Invoke_O_O__O(self, x__0 any) any { if jrt.Long_InstanceOf(x__0) { return t.InvokeSpec_O_J_O__O(self, jrt.NN(jrt.Long_Cast(x__0)).LongValue__J(), x__0) } else {



	if jrt.Double_InstanceOf(x__0) { var or__1927000174__auto____2 bool = lang.Numbers_IsNeg_D__Z_NoInit(lang.RT_DoubleCast_O__D_NoInit(x__0))
		if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(jrt.Double_DoubleToRawLongBits_D__J_NoInit(lang.RT_DoubleCast_O__D_NoInit(x__0)), -9223372036854775808)).Ref() } } else {
//line :155:1
			var tmp1 any; var root_449 any = A_arbace_repr_go_print_text_A_const_62.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_number_QMARK__A_fn_class); var ifn_451 lang.IFn


			if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = x__0; if linked_450 == nil { tmp1 = ifn_451.Invoke_O__O(arg_452) } else { tmp1 = linked_450.(*aot_arbace_core.A_arbace_core_number_QMARK__A).Invoke_O_O__O(root_449, arg_452) }
//line :155:1
			if jrt.J2g_Truth(tmp1) {


				var tmp2 bool; var na_453 any = x__0; if jrt.Long_InstanceOf(na_453) { var n0_454 int64 = jrt.NN(jrt.Long_Cast(na_453)).LongValue__J(); tmp2 = n0_454 < 0 } else { if jrt.Double_InstanceOf(na_453) { var n0_454_2 float64 = jrt.NN(jrt.Double_Cast(na_453)).DoubleValue__D(); tmp2 = n0_454_2 < 0.0 } else { tmp2 = lang.Numbers_IsNeg_O__Z_NoInit(na_453) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } else {
//line :155:1
					if A_arbace_repr_go_print_text_A_const_22 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil } } } } }
//line :151:1
func (t *A_arbace_repr_go_print_text_negative_number_QMARK__A) InvokeSpec_O_J_O__O(self any, x__0_l int64, x__0_b any) any {



	var tmp1 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp1 = x__0_b } else { tmp1 = x__0_b }; if jrt.Double_InstanceOf(tmp1) { var or__1927000174__auto____2 bool; var tmp2 any
		if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp2 = x__0_b } else { tmp2 = x__0_b }; or__1927000174__auto____2 = lang.Numbers_IsNeg_D__Z_NoInit(lang.RT_DoubleCast_O__D_NoInit(tmp2)); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var tmp3 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); tmp3 = x__0_b } else { tmp3 = x__0_b }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(jrt.Double_DoubleToRawLongBits_D__J_NoInit(lang.RT_DoubleCast_O__D_NoInit(tmp3)), -9223372036854775808)).Ref() } } else {
//line :155:1
			var tmp4 any; var root_455 any = A_arbace_repr_go_print_text_A_const_62.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_number_QMARK__A_fn_class); var ifn_457 lang.IFn


			if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any; if x__0_b == nil { x__0_b = jrt.Long_ValueOf_J__Long_NoInit(x__0_l).Ref(); arg_458 = x__0_b } else { arg_458 = x__0_b }; if linked_456 == nil { tmp4 = ifn_457.Invoke_O__O(arg_458) } else { tmp4 = linked_456.(*aot_arbace_core.A_arbace_core_number_QMARK__A).Invoke_O_O__O(root_455, arg_458) }
//line :155:1
			if jrt.J2g_Truth(tmp4) {


				var tmp5 bool; var n0_459 int64 = x__0_l; tmp5 = n0_459 < 0; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp5).Ref() } else {
//line :155:1
					if A_arbace_repr_go_print_text_A_const_22 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
					}
				}
		}
}

func A_arbace_repr_go_print_text_go_number_A_New() *A_arbace_repr_go_print_text_go_number_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_number_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_repr_go_print_text_go_number_A) Ctor() {}
//line :161:1
func (t *A_arbace_repr_go_print_text_go_number_A) Invoke_O_O__O(self, x__0 any) any {



	if jrt.Double_InstanceOf(x__0) {
		var root_460 any = A_arbace_repr_go_print_text_A_const_63.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, A_arbace_repr_go_print_text_go_float_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Abs_D__D(lang.RT_DoubleCast_O__D_NoInit(x__0))).Ref(); if linked_461 == nil { return ifn_462.Invoke_O__O(arg_463) } else { return linked_461.(*A_arbace_repr_go_print_text_go_float_A).Invoke_O_O__O(root_460, arg_463) } } else {
//line :165:1
			var tmp1 any; var root_464 any = A_arbace_repr_go_print_text_A_const_44.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_466 lang.IFn

			if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = x__0; if linked_465 == nil { tmp1 = ifn_466.Invoke_O__O(arg_467) } else { tmp1 = linked_465.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_464, arg_467) }
//line :165:1
			if jrt.J2g_Truth(tmp1) {

				var root_468 any = A_arbace_repr_go_print_text_A_const_15.GetRawRoot__O(); var linked_469 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_468, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_470 lang.IFn; if linked_469 == nil { ifn_470 = lang.IFn_Cast(root_468) } else { ifn_470 = nil }; var arg_471 any = x__0; if linked_469 == nil { return ifn_470.Invoke_O__O(arg_471) } else { return linked_469.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_468, arg_471) } } else {
//line :165:1
					if A_arbace_repr_go_print_text_A_const_22 != nil {


						var root_472 any = A_arbace_repr_go_print_text_A_const_63.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, A_arbace_repr_go_print_text_go_float_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any = x__0; if linked_473 == nil { return ifn_474.Invoke_O__O(arg_475) } else { return linked_473.(*A_arbace_repr_go_print_text_go_float_A).Invoke_O_O__O(root_472, arg_475) } } else {
//line :165:1
							return nil
						}
				}
		}
}



func A_arbace_repr_go_print_text_escape_A_New() *A_arbace_repr_go_print_text_escape_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_escape_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_repr_go_print_text_escape_A) Ctor() {}
//line :173:1
func (t *A_arbace_repr_go_print_text_escape_A) Invoke_O_O__O(self, s__0 any) any {




	return jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.String_Cast(s__0)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_64)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_65)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_66)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_67)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_68)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_69)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_70)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_71)).CharValue__C()).Ref()
}
func A_arbace_repr_go_print_text_unescape_A_New() *A_arbace_repr_go_print_text_unescape_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_unescape_A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_repr_go_print_text_unescape_A) Ctor() {}
//line :180:1
func (t *A_arbace_repr_go_print_text_unescape_A) Invoke_O_O__O(self, s__0 any) any {



	return jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.String_Cast(s__0)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_72)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_64)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_73)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_66)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_74)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_68)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_75)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_70)).CharValue__C()).Ref()
}



func A_arbace_repr_go_print_text_cell_width_A_New() *A_arbace_repr_go_print_text_cell_width_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_cell_width_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_repr_go_print_text_cell_width_A) Ctor() {}
//line :189:1
func (t *A_arbace_repr_go_print_text_cell_width_A) Invoke_O_O__O(self, s__0 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.String_Cast(s__0)).CodePointCount_I_I__I(lang.RT_IntCast_J__I_NoInit(0), jrt.NN(jrt.String_Cast(s__0)).Length__I())).Ref() }



func A_arbace_repr_go_print_text_parse_lines_A_New() *A_arbace_repr_go_print_text_parse_lines_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_repr_go_print_text_parse_lines_A) Ctor() {}
//line :193:1
func (t *A_arbace_repr_go_print_text_parse_lines_A) Invoke_O_O__O(self, text__0 any) any {



	var root_476 any = A_arbace_repr_go_print_text_A_const_76.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var arg_479 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_New(); var tmp2 *jrt.Class; var fncls__614 *jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_fn_class; if fncls__614 == nil { var fncls__614d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_fn_class = fncls__614d; tmp2 = fncls__614d } else { tmp2 = fncls__614 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_615 any = A_arbace_repr_go_print_text_A_const_89.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = text__0; var arg_619 any = A_arbace_repr_go_print_text_A_const_90; var arg_620 any = A_arbace_repr_go_print_text_A_const_91; if linked_616 == nil { tmp4 = ifn_617.Invoke_O_O_O__O(arg_618, arg_619, arg_620) } else { tmp4 = linked_616.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_615, arg_618, arg_619, arg_620) }; arg_479 = tmp3.Invoke_O__O(tmp4); if linked_477 == nil { return ifn_478.Invoke_O__O(arg_479) } else { return linked_477.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_476, arg_479) } }
//line :197:1
func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_New() *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A) Invoke_O_O__O(self, s__1242000052__1 any) any { var tmp1 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_New_O_O(s__1242000052__1, self); var tmp2 *jrt.Class; var fncls__613 *jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_fn_class; if fncls__613 == nil { var fncls__613d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_fn_class = fncls__613d; tmp2 = fncls__613d } else { tmp2 = fncls__613 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :197:1
func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A{}; t.Ctor_O_O(p0, p1); return t }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A) Ctor_O_O(c__s__1242000052, c__iter__1242000051 any) { t.F_s__1242000052 = c__s__1242000052; t.F_iter__1242000051 = c__iter__1242000051 }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A) Invoke_O__O(self any) any { { var s__1242000052__1 any; var t_ any = t.F_s__1242000052; t.F_s__1242000052 = nil; s__1242000052__1 = t_; for { var temp__1927000414__auto____2 any; var root_480 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = s__1242000052__1; if linked_481 == nil { temp__1927000414__auto____2 = ifn_482.Invoke_O__O(arg_483) } else { temp__1927000414__auto____2 = linked_481.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_480, arg_483) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1242000052__3 any = temp__1927000414__auto____2; var tmp1 any; var root_484 any = A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = s__1242000052__3; if linked_485 == nil { tmp1 = ifn_486.Invoke_O__O(arg_487) } else { tmp1 = linked_485.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_484, arg_487) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_488 any = A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = s__1242000052__3; if linked_489 == nil { c__1927001037__auto____4 = ifn_490.Invoke_O__O(arg_491) } else { c__1927001037__auto____4 = linked_489.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_488, arg_491) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1242000054__6 any; var root_492 any = A_arbace_repr_go_print_text_A_const_77.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_493 == nil { b__1242000054__6 = ifn_494.Invoke_O__O(arg_495) } else { b__1242000054__6 = linked_493.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_492, arg_495) }; var tmp2 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_New_O_I_O(b__1242000054__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__539 *jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_fn_class; if fncls__539 == nil { var fncls__539d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_fn_class = fncls__539d; tmp3 = fncls__539d } else { tmp3 = fncls__539 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_540 any = A_arbace_repr_go_print_text_A_const_85.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_542 lang.IFn; if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any; var root_545 any = A_arbace_repr_go_print_text_A_const_86.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_547 lang.IFn; if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = b__1242000054__6; if linked_546 == nil { arg_543 = ifn_547.Invoke_O__O(arg_548) } else { arg_543 = linked_546.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_545, arg_548) }; var arg_544 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1242000051); var tmp5 any; var root_549 any = A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = s__1242000052__3; if linked_550 == nil { tmp5 = ifn_551.Invoke_O__O(arg_552) } else { tmp5 = linked_550.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_549, arg_552) }; arg_544 = tmp4.Invoke_O__O(tmp5); if linked_541 == nil { return ifn_542.Invoke_O_O__O(arg_543, arg_544) } else { return linked_541.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_540, arg_543, arg_544) } } else { var root_553 any = A_arbace_repr_go_print_text_A_const_85.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any; var root_558 any = A_arbace_repr_go_print_text_A_const_86.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = b__1242000054__6; if linked_559 == nil { arg_556 = ifn_560.Invoke_O__O(arg_561) } else { arg_556 = linked_559.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_558, arg_561) }; var arg_557 any; if linked_554 == nil { return ifn_555.Invoke_O_O__O(arg_556, arg_557) } else { return linked_554.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_553, arg_556, arg_557) } } } else { var line__4 any; var root_562 any = A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = s__1242000052__3; if linked_563 == nil { line__4 = ifn_564.Invoke_O__O(arg_565) } else { line__4 = linked_563.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_562, arg_565) }; var root_566 any = A_arbace_repr_go_print_text_A_const_87.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_568 lang.IFn; if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any; var n__5 int32 = jrt.NN(jrt.String_Cast(line__4)).Length__I(); var tmp6 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_New_I_O(n__5, line__4); var tmp7 *jrt.Class
																var fncls__608 /*line :197:1*/*jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_fn_class

	if fncls__608 == nil { var fncls__608d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_fn_class = fncls__608d; tmp7 = fncls__608d } else { tmp7 = fncls__608 }; arg_569 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :197:1
	var arg_570 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1242000051); var tmp9 any; var root_609 any = A_arbace_repr_go_print_text_A_const_88.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = s__1242000052__3; if linked_610 == nil { tmp9 = ifn_611.Invoke_O__O(arg_612) } else { tmp9 = linked_610.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_609, arg_612) }; arg_570 = tmp8.Invoke_O__O(tmp9); if linked_567 == nil { return ifn_568.Invoke_O_O__O(arg_569, arg_570) } else { return linked_567.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_566, arg_569, arg_570) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :197:1
func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A) Ctor_O_I_O(c__b__1242000054 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1242000054 = c__b__1242000054; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A) Invoke_O__O(self any) any { { var i__1242000053__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1242000053__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var line__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1242000053__1)); var root_496 any = A_arbace_repr_go_print_text_A_const_78.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_498 lang.IFn; if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = t.F_b__1242000054; var arg_500 any; var n__3 int32 = jrt.NN(jrt.String_Cast(line__2)).Length__I(); var tmp2 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_New_I_O(n__3, line__2); var tmp3 *jrt.Class
																		var fncls__538 /*line :197:1*/*jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_fn_class

	if fncls__538 == nil { var fncls__538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_fn_class = fncls__538d; tmp3 = fncls__538d } else { tmp3 = fncls__538 }; arg_500 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :197:1
	if linked_497 == nil { ifn_498.Invoke_O_O__O(arg_499, arg_500) } else { linked_497.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_496, arg_499, arg_500) }; i__1242000053__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1242000053__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_New_I_O(p0 int32, p1 any) *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A{}; t.Ctor_I_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A) Ctor_I_O(c__n int32, c__line any) { t.F_n = c__n; t.F_line = c__line }
//line :199:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var start__2 int64 = 0; var cells__3 any; var root_501 any = A_arbace_repr_go_print_text_A_const_24.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = lang.PersistentVector_EMPTY.Ref(); if linked_502 == nil { cells__3 = ifn_503.Invoke_O__O(arg_504) } else { cells__3 = linked_502.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_501, arg_504) }; L1: for {
																			if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(t.F_n)) { var tmp1 *jrt.String = jrt.String_Cast(t.F_line); var c__4 int32 = lang.RT_IntCast_C__I_NoInit(jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))); var tmp2 bool; var or__1927000174__auto____5 bool = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)

		if or__1927000174__auto____5 { tmp2 = or__1927000174__auto____5 } else { tmp2 = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 11) }; if tmp2 {
			var tmp3 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp4 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp5 any; var root_523 any = A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_525 lang.IFn
			if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = cells__3; var arg_527 any; var tmp6 bool; var and__1927000168__auto____5 bool = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9); if and__1927000168__auto____5 { tmp6 = lang.Numbers_Equiv_J_J__Z_NoInit(start__2, i__1) } else { tmp6 = and__1927000168__auto____5 }; if tmp6 { arg_527 = A_arbace_repr_go_print_text_A_const_84.GetRawRoot__O() } else { var t__5 any; var root_528 any = A_arbace_repr_go_print_text_A_const_79.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_530 lang.IFn

				if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = t.F_line; var arg_532 any = jrt.Long_ValueOf_J__Long_NoInit(start__2).Ref(); var arg_533 any = jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref(); if linked_529 == nil { t__5 = ifn_530.Invoke_O_O_O__O(arg_531, arg_532, arg_533) } else { t__5 = linked_529.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_528, arg_531, arg_532, arg_533) }
//line :204:1
				var tmp7 any = A_arbace_repr_go_print_text_A_const_80; var tmp8 any = A_arbace_repr_go_print_text_A_const_81; var tmp9 any; var root_534 any = A_arbace_repr_go_print_text_A_const_82.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, A_arbace_repr_go_print_text_cell_width_A_fn_class); var ifn_536 lang.IFn


				if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = t__5; if linked_535 == nil { tmp9 = ifn_536.Invoke_O__O(arg_537) } else { tmp9 = linked_535.(*A_arbace_repr_go_print_text_cell_width_A).Invoke_O_O__O(root_534, arg_537) }
//line :204:1
				var tmp10 any = tmp9; var tmp11 any = A_arbace_repr_go_print_text_A_const_83; arg_527 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, t__5, tmp8, tmp10, tmp11, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)).Ref())) }; if linked_524 == nil { tmp5 = ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { tmp5 = linked_524.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_523, arg_526, arg_527) }
//line :203:1
			i__1, start__2, cells__3 = tmp3, tmp4, tmp5; continue L1 } else {




				i__1, start__2, cells__3 = lang.Numbers_Inc_J__J_NoInit(i__1), start__2, cells__3; continue L1 } } else {
//line :200:1
					var t__4 any; var root_505 any = A_arbace_repr_go_print_text_A_const_79.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_507 lang.IFn








					if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = t.F_line; var arg_509 any = jrt.Long_ValueOf_J__Long_NoInit(start__2).Ref(); if linked_506 == nil { t__4 = ifn_507.Invoke_O_O__O(arg_508, arg_509) } else { t__4 = linked_506.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_505, arg_508, arg_509) }
					var root_510 any = A_arbace_repr_go_print_text_A_const_25.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_512 lang.IFn; if linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any; var root_514 any = A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = cells__3; var arg_518 any; var tmp12 any = A_arbace_repr_go_print_text_A_const_80; var tmp13 any = A_arbace_repr_go_print_text_A_const_81; var tmp14 any; var root_519 any = A_arbace_repr_go_print_text_A_const_82.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, A_arbace_repr_go_print_text_cell_width_A_fn_class); var ifn_521 lang.IFn; if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = t__4; if linked_520 == nil { tmp14 = ifn_521.Invoke_O__O(arg_522) } else { tmp14 = linked_520.(*A_arbace_repr_go_print_text_cell_width_A).Invoke_O_O__O(root_519, arg_522) }; arg_518 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, t__4, tmp13, tmp14, A_arbace_repr_go_print_text_A_const_83, jrt.Boolean_FALSE.Ref())); if linked_515 == nil { arg_513 = ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { arg_513 = linked_515.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_514, arg_517, arg_518) }; if linked_511 == nil { return ifn_512.Invoke_O__O(arg_513) } else { return linked_511.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_510, arg_513) } } } }; /*line :199:1*/panic("j2g: unreachable") }
//line :199:1
func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_New_I_O(p0 int32, p1 any) *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A{}; t.Ctor_I_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A) Ctor_I_O(c__n int32, c__line any) { t.F_n = c__n; t.F_line = c__line }
//line :199:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var start__2 int64 = 0; var cells__3 any; var root_571 any = A_arbace_repr_go_print_text_A_const_24.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = lang.PersistentVector_EMPTY.Ref(); if linked_572 == nil { cells__3 = ifn_573.Invoke_O__O(arg_574) } else { cells__3 = linked_572.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_571, arg_574) }; L1: for {
																		if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(t.F_n)) { var tmp1 *jrt.String = jrt.String_Cast(t.F_line); var c__4 int32 = lang.RT_IntCast_C__I_NoInit(jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))); var tmp2 bool; var or__1927000174__auto____5 bool = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)

		if or__1927000174__auto____5 { tmp2 = or__1927000174__auto____5 } else { tmp2 = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 11) }; if tmp2 {
			var tmp3 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp4 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp5 any; var root_593 any = A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_595 lang.IFn
			if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = cells__3; var arg_597 any; var tmp6 bool; var and__1927000168__auto____5 bool = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9); if and__1927000168__auto____5 { tmp6 = lang.Numbers_Equiv_J_J__Z_NoInit(start__2, i__1) } else { tmp6 = and__1927000168__auto____5 }; if tmp6 { arg_597 = A_arbace_repr_go_print_text_A_const_84.GetRawRoot__O() } else { var t__5 any; var root_598 any = A_arbace_repr_go_print_text_A_const_79.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_600 lang.IFn

				if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = t.F_line; var arg_602 any = jrt.Long_ValueOf_J__Long_NoInit(start__2).Ref(); var arg_603 any = jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref(); if linked_599 == nil { t__5 = ifn_600.Invoke_O_O_O__O(arg_601, arg_602, arg_603) } else { t__5 = linked_599.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_598, arg_601, arg_602, arg_603) }
//line :204:1
				var tmp7 any = A_arbace_repr_go_print_text_A_const_80; var tmp8 any = A_arbace_repr_go_print_text_A_const_81; var tmp9 any; var root_604 any = A_arbace_repr_go_print_text_A_const_82.GetRawRoot__O(); var linked_605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_604, A_arbace_repr_go_print_text_cell_width_A_fn_class); var ifn_606 lang.IFn


				if linked_605 == nil { ifn_606 = lang.IFn_Cast(root_604) } else { ifn_606 = nil }; var arg_607 any = t__5; if linked_605 == nil { tmp9 = ifn_606.Invoke_O__O(arg_607) } else { tmp9 = linked_605.(*A_arbace_repr_go_print_text_cell_width_A).Invoke_O_O__O(root_604, arg_607) }
//line :204:1
				var tmp10 any = tmp9; var tmp11 any = A_arbace_repr_go_print_text_A_const_83; arg_597 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, t__5, tmp8, tmp10, tmp11, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)).Ref())) }; if linked_594 == nil { tmp5 = ifn_595.Invoke_O_O__O(arg_596, arg_597) } else { tmp5 = linked_594.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_593, arg_596, arg_597) }
//line :203:1
			i__1, start__2, cells__3 = tmp3, tmp4, tmp5; continue L1 } else {




				i__1, start__2, cells__3 = lang.Numbers_Inc_J__J_NoInit(i__1), start__2, cells__3; continue L1 } } else {
//line :200:1
					var t__4 any; var root_575 any = A_arbace_repr_go_print_text_A_const_79.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_577 lang.IFn








					if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = t.F_line; var arg_579 any = jrt.Long_ValueOf_J__Long_NoInit(start__2).Ref(); if linked_576 == nil { t__4 = ifn_577.Invoke_O_O__O(arg_578, arg_579) } else { t__4 = linked_576.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_575, arg_578, arg_579) }
					var root_580 any = A_arbace_repr_go_print_text_A_const_25.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any; var root_584 any = A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = cells__3; var arg_588 any; var tmp12 any = A_arbace_repr_go_print_text_A_const_80; var tmp13 any = A_arbace_repr_go_print_text_A_const_81; var tmp14 any; var root_589 any = A_arbace_repr_go_print_text_A_const_82.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, A_arbace_repr_go_print_text_cell_width_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = t__4; if linked_590 == nil { tmp14 = ifn_591.Invoke_O__O(arg_592) } else { tmp14 = linked_590.(*A_arbace_repr_go_print_text_cell_width_A).Invoke_O_O__O(root_589, arg_592) }; arg_588 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, t__4, tmp13, tmp14, A_arbace_repr_go_print_text_A_const_83, jrt.Boolean_FALSE.Ref())); if linked_585 == nil { arg_583 = ifn_586.Invoke_O_O__O(arg_587, arg_588) } else { arg_583 = linked_585.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_584, arg_587, arg_588) }; if linked_581 == nil { return ifn_582.Invoke_O__O(arg_583) } else { return linked_581.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_580, arg_583) } } } }; /*line :199:1*/panic("j2g: unreachable") }












func A_arbace_repr_go_print_text_write_padding_A_New() *A_arbace_repr_go_print_text_write_padding_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_write_padding_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_repr_go_print_text_write_padding_A) Ctor() {}
//line :212:1
func (t *A_arbace_repr_go_print_text_write_padding_A) InvokePrim_O_O_J_J_O__O(self, sb__0 any, textw__1, cellw__2 int64, use_tabs__3 any) any {
	if jrt.J2g_Truth(use_tabs__3) { var cellw__5 int64 = lang.Numbers_Multiply_J_J__J_NoInit(8, lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(cellw__2, 7), 8)); var n__6 int64 = lang.Numbers_Minus_J_J__J_NoInit(cellw__5, textw__1); var n__1927000701__auto____7 int64 = lang.RT_LongCast_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(n__6, 7), 8)); var ___8 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z_NoInit(___8, n__1927000701__auto____7) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_repr_go_print_text_A_const_64); ___8 = lang.Numbers_Unchecked_inc_J__J_NoInit(___8); continue L1 } else { return nil } } } else {
//line :213:1
			var n__1927000701__auto____5 int64 = lang.RT_LongCast_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(cellw__2, textw__1)); var ___6 int64 = 0; L2: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(___6, n__1927000701__auto____5) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_repr_go_print_text_A_const_92); ___6 = lang.Numbers_Unchecked_inc_J__J_NoInit(___6); continue L2 } else { return nil } } }
//line :212:1
	panic("j2g: unreachable") }
//line :212:1
func (t *A_arbace_repr_go_print_text_write_padding_A) Invoke_O_O_O_O_O__O(self, sb__0, p_textw__1, p_cellw__2, use_tabs__3 any) any { return t.InvokePrim_O_O_J_J_O__O(self, sb__0, lang.RT_LongCast_O__J_NoInit(p_textw__1), lang.RT_LongCast_O__J_NoInit(p_cellw__2), use_tabs__3) }






func A_arbace_repr_go_print_text_write_lines_A_New() *A_arbace_repr_go_print_text_write_lines_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_write_lines_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_repr_go_print_text_write_lines_A) Ctor() {}
//line :219:1
func (t *A_arbace_repr_go_print_text_write_lines_A) Invoke_O_O_O_O_O_O__O(self, sb__0, lines__1, widths__2, line0__3, line1__4 any) any { { var seq_1242000067__6 any; var root_621 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_623 lang.IFn
																	if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any; var root_625 any = A_arbace_repr_go_print_text_A_const_93.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = line0__3; var arg_629 any = line1__4; if linked_626 == nil { arg_624 = ifn_627.Invoke_O_O__O(arg_628, arg_629) } else { arg_624 = linked_626.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_625, arg_628, arg_629) }; if linked_622 == nil { seq_1242000067__6 = ifn_623.Invoke_O__O(arg_624) } else { seq_1242000067__6 = linked_622.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_621, arg_624) }
//line :219:1
	var chunk_1242000068__7 any; var count_1242000069__8 int64 = 0; var i_1242000070__9 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000070__9, count_1242000069__8) { var i__10 any = lang.Indexed_Cast(chunk_1242000068__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000070__9)); var line__11 any = lang.RT_Nth_O_I__O_NoInit(lines__1, lang.RT_IntCast_O__I_NoInit(i__10)); var nw__12 int32 = lang.RT_Count_O__I_NoInit(widths__2); var j__13 int64 = 0; var use_tabs__14 any = jrt.Boolean_TRUE.Ref(); L2: for {



			if lang.Numbers_Lt_J_J__Z_NoInit(j__13, int64(lang.RT_Count_O__I_NoInit(line__11))) { var c__15 any = lang.RT_Nth_O_I__O_NoInit(line__11, lang.RT_IntCast_J__I_NoInit(j__13))

				if lang.Numbers_IsZero_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_print_text_A_const_80.Invoke_O__O(c__15)))) {
					if lang.Numbers_Lt_J_J__Z_NoInit(j__13, int64(nw__12)) { var root_653 any = A_arbace_repr_go_print_text_A_const_94.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_653, A_arbace_repr_go_print_text_write_padding_A_fn_class); var ifn_655 lang.IFn; if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = sb__0; var arg_657 any = A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__15); var arg_658 any = lang.RT_Nth_O_I__O_NoInit(widths__2, lang.RT_IntCast_J__I_NoInit(j__13)); var arg_659 any = use_tabs__14; if linked_654 == nil { ifn_655.Invoke_O_O_O_O__O(arg_656, arg_657, arg_658, arg_659) } else { linked_654.(*A_arbace_repr_go_print_text_write_padding_A).InvokePrim_O_O_J_J_O__O(root_653, arg_656, lang.RT_LongCast_O__J_NoInit(arg_657), lang.RT_LongCast_O__J_NoInit(arg_658), arg_659) } }
					j__13, use_tabs__14 = lang.Numbers_Inc_J__J_NoInit(j__13), use_tabs__14; continue L2 } else {
						jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_String__StringBuilder(jrt.String_Cast(A_arbace_repr_go_print_text_A_const_80.Invoke_O__O(c__15)))
						if lang.Numbers_Lt_J_J__Z_NoInit(j__13, int64(nw__12)) { var root_660 any = A_arbace_repr_go_print_text_A_const_94.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_660, A_arbace_repr_go_print_text_write_padding_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = sb__0; var arg_664 any = A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__15); var arg_665 any = lang.RT_Nth_O_I__O_NoInit(widths__2, lang.RT_IntCast_J__I_NoInit(j__13)); var arg_666 any = jrt.Boolean_FALSE.Ref(); if linked_661 == nil { ifn_662.Invoke_O_O_O_O__O(arg_663, arg_664, arg_665, arg_666) } else { linked_661.(*A_arbace_repr_go_print_text_write_padding_A).InvokePrim_O_O_J_J_O__O(root_660, arg_663, lang.RT_LongCast_O__J_NoInit(arg_664), lang.RT_LongCast_O__J_NoInit(arg_665), arg_666) } }
						j__13, use_tabs__14 = lang.Numbers_Inc_J__J_NoInit(j__13), jrt.Boolean_FALSE.Ref(); continue L2 } }
//line :220:1
			break L2
		}










			var tmp1 bool; var na_646 any; var na_648 any = i__10; if jrt.Long_InstanceOf(na_648) { var n0_649 int64 = jrt.NN(jrt.Long_Cast(na_648)).LongValue__J(); if n0_649 == 9223372036854775807 { na_646 = lang.Numbers_Inc_O__Number_NoInit(na_648) } else { na_646 = jrt.Long_ValueOf_J__Long_NoInit(n0_649 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_648) { var n0_649_2 float64 = jrt.NN(jrt.Double_Cast(na_648)).DoubleValue__D(); na_646 = jrt.Double_ValueOf_D__Double_NoInit(n0_649_2 + 1.0).Ref() } else { na_646 = lang.Numbers_Inc_O__Number_NoInit(na_648) } }; var na_647 int64 = int64(lang.RT_Count_O__I_NoInit(lines__1)); if jrt.Long_InstanceOf(na_646) { var n0_650 int64 = jrt.NN(jrt.Long_Cast(na_646)).LongValue__J(); var n1_651 int64 = na_647; tmp1 = n0_650 < n1_651 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_646, na_647) }; if tmp1 { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_repr_go_print_text_A_const_66) }
//line :220:1
			seq_1242000067__6, chunk_1242000068__7, count_1242000069__8, i_1242000070__9 = seq_1242000067__6, chunk_1242000068__7, count_1242000069__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000070__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_630 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = seq_1242000067__6; if linked_631 == nil { temp__1927000414__auto____10 = ifn_632.Invoke_O__O(arg_633) } else { temp__1927000414__auto____10 = linked_631.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_630, arg_633) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1242000067__11 any = temp__1927000414__auto____10; var tmp2 any; var root_634 any = A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = seq_1242000067__11; if linked_635 == nil { tmp2 = ifn_636.Invoke_O__O(arg_637) } else { tmp2 = linked_635.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_634, arg_637) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____12 any; var root_638 any = A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = seq_1242000067__11; if linked_639 == nil { c__1927000678__auto____12 = ifn_640.Invoke_O__O(arg_641) } else { c__1927000678__auto____12 = linked_639.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_638, arg_641) }; var tmp3 any; var root_667 any = A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = seq_1242000067__11; if linked_668 == nil { tmp3 = ifn_669.Invoke_O__O(arg_670) } else { tmp3 = linked_668.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_667, arg_670) }; seq_1242000067__6, chunk_1242000068__7, count_1242000069__8, i_1242000070__9 = tmp3, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var i__12 any; var root_642 any = A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = seq_1242000067__11; if linked_643 == nil { i__12 = ifn_644.Invoke_O__O(arg_645) } else { i__12 = linked_643.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_642, arg_645) }; var line__13 any = lang.RT_Nth_O_I__O_NoInit(lines__1, lang.RT_IntCast_O__I_NoInit(i__12)); var nw__14 int32 = lang.RT_Count_O__I_NoInit(widths__2); var j__15 int64 = 0; var use_tabs__16 any = jrt.Boolean_TRUE.Ref(); L3: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(j__15, int64(lang.RT_Count_O__I_NoInit(line__13))) { var c__17 any = lang.RT_Nth_O_I__O_NoInit(line__13, lang.RT_IntCast_J__I_NoInit(j__15))

					if lang.Numbers_IsZero_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_print_text_A_const_80.Invoke_O__O(c__17)))) {
						if lang.Numbers_Lt_J_J__Z_NoInit(j__15, int64(nw__14)) { var root_678 any = A_arbace_repr_go_print_text_A_const_94.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_678, A_arbace_repr_go_print_text_write_padding_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = sb__0; var arg_682 any = A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__17); var arg_683 any = lang.RT_Nth_O_I__O_NoInit(widths__2, lang.RT_IntCast_J__I_NoInit(j__15)); var arg_684 any = use_tabs__16; if linked_679 == nil { ifn_680.Invoke_O_O_O_O__O(arg_681, arg_682, arg_683, arg_684) } else { linked_679.(*A_arbace_repr_go_print_text_write_padding_A).InvokePrim_O_O_J_J_O__O(root_678, arg_681, lang.RT_LongCast_O__J_NoInit(arg_682), lang.RT_LongCast_O__J_NoInit(arg_683), arg_684) } }
						j__15, use_tabs__16 = lang.Numbers_Inc_J__J_NoInit(j__15), use_tabs__16; continue L3 } else {
							jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_String__StringBuilder(jrt.String_Cast(A_arbace_repr_go_print_text_A_const_80.Invoke_O__O(c__17)))
							if lang.Numbers_Lt_J_J__Z_NoInit(j__15, int64(nw__14)) { var root_685 any = A_arbace_repr_go_print_text_A_const_94.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_685, A_arbace_repr_go_print_text_write_padding_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = sb__0; var arg_689 any = A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__17); var arg_690 any = lang.RT_Nth_O_I__O_NoInit(widths__2, lang.RT_IntCast_J__I_NoInit(j__15)); var arg_691 any = jrt.Boolean_FALSE.Ref(); if linked_686 == nil { ifn_687.Invoke_O_O_O_O__O(arg_688, arg_689, arg_690, arg_691) } else { linked_686.(*A_arbace_repr_go_print_text_write_padding_A).InvokePrim_O_O_J_J_O__O(root_685, arg_688, lang.RT_LongCast_O__J_NoInit(arg_689), lang.RT_LongCast_O__J_NoInit(arg_690), arg_691) } }
							j__15, use_tabs__16 = lang.Numbers_Inc_J__J_NoInit(j__15), jrt.Boolean_FALSE.Ref(); continue L3 } }
//line :220:1
				break L3
			}










				var tmp4 bool; var na_671 any; var na_673 any = i__12; if jrt.Long_InstanceOf(na_673) { var n0_674 int64 = jrt.NN(jrt.Long_Cast(na_673)).LongValue__J(); if n0_674 == 9223372036854775807 { na_671 = lang.Numbers_Inc_O__Number_NoInit(na_673) } else { na_671 = jrt.Long_ValueOf_J__Long_NoInit(n0_674 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_673) { var n0_674_2 float64 = jrt.NN(jrt.Double_Cast(na_673)).DoubleValue__D(); na_671 = jrt.Double_ValueOf_D__Double_NoInit(n0_674_2 + 1.0).Ref() } else { na_671 = lang.Numbers_Inc_O__Number_NoInit(na_673) } }; var na_672 int64 = int64(lang.RT_Count_O__I_NoInit(lines__1)); if jrt.Long_InstanceOf(na_671) { var n0_675 int64 = jrt.NN(jrt.Long_Cast(na_671)).LongValue__J(); var n1_676 int64 = na_672; tmp4 = n0_675 < n1_676 } else { tmp4 = lang.Numbers_Lt_O_J__Z_NoInit(na_671, na_672) }; if tmp4 { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_repr_go_print_text_A_const_66) }
//line :220:1
				var tmp5 any; var root_692 any = A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_694 lang.IFn; if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = seq_1242000067__11; if linked_693 == nil { tmp5 = ifn_694.Invoke_O__O(arg_695) } else { tmp5 = linked_693.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_692, arg_695) }; seq_1242000067__6, chunk_1242000068__7, count_1242000069__8, i_1242000070__9 = tmp5, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :219:1*/panic("j2g: unreachable") }














func A_arbace_repr_go_print_text_format_block_A_New() *A_arbace_repr_go_print_text_format_block_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_format_block_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_repr_go_print_text_format_block_A) Ctor() {}
//line :234:1
func (t *A_arbace_repr_go_print_text_format_block_A) Invoke_O_O_O_O_O_O__O(self, sb__0, lines__1, widths__2, line0__3, line1__4 any) any { { var column__6 int32 = lang.RT_Count_O__I_NoInit(widths__2); var this__7 any = line0__3; var line0__8 any = line0__3; L1: for {




	var tmp1 bool; var na_696 any = this__7; var na_697 any = line1__4; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_696); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_697) }; tmp2 = tmp3; if tmp2 { var n0_698 int64 = jrt.NN(jrt.Long_Cast(na_696)).LongValue__J(); var n1_699 int64 = jrt.NN(jrt.Long_Cast(na_697)).LongValue__J(); tmp1 = n0_698 < n1_699 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_696); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_697) }; tmp4 = tmp5; if tmp4 { var n0_698_2 float64 = jrt.NN(jrt.Double_Cast(na_696)).DoubleValue__D(); var n1_699_2 float64 = jrt.NN(jrt.Double_Cast(na_697)).DoubleValue__D(); tmp1 = n0_698_2 < n1_699_2 } else { tmp1 = lang.Numbers_Lt_O_O__Z_NoInit(na_696, na_697) } }; if tmp1 { var line__9 any = lang.RT_Nth_O_I__O_NoInit(lines__1, lang.RT_IntCast_O__I_NoInit(this__7))

		if lang.Numbers_Gte_J_J__Z_NoInit(int64(column__6), lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(line__9)))) {
			var tmp6 jrt.Number_I; var na_725 any = this__7; if jrt.Long_InstanceOf(na_725) { var n0_726 int64 = jrt.NN(jrt.Long_Cast(na_725)).LongValue__J(); if n0_726 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_725) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_726 + 1)) } } else { if jrt.Double_InstanceOf(na_725) { var n0_726_2 float64 = jrt.NN(jrt.Double_Cast(na_725)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_726_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_725) } }; this__7, line0__8 = tmp6, line0__8; continue L1 } else {

				var root_727 any = A_arbace_repr_go_print_text_A_const_95.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, A_arbace_repr_go_print_text_write_lines_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = sb__0; var arg_731 any = lines__1; var arg_732 any = widths__2; var arg_733 any = line0__8; var arg_734 any = this__7; if linked_728 == nil { ifn_729.Invoke_O_O_O_O_O__O(arg_730, arg_731, arg_732, arg_733, arg_734) } else { linked_728.(*A_arbace_repr_go_print_text_write_lines_A).Invoke_O_O_O_O_O_O__O(root_727, arg_730, arg_731, arg_732, arg_733, arg_734) }
//line :241:1
				var line0__10 any = this__7; var vec__1242000072__11 any; var tmp7 any = A_arbace_repr_go_print_text_format_block_fn__1242000075_A_New_I_O_O_O(column__6, this__7, line1__4, lines__1); var tmp8 *jrt.Class
				var fncls__716 /*line :241:1*/*jrt.Class = A_arbace_repr_go_print_text_format_block_fn__1242000075_A_fn_class





				if fncls__716 == nil { var fncls__716d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_repr_go_print_text_format_block_fn__1242000075_A_fn_class = fncls__716d; tmp8 = fncls__716d } else { tmp8 = fncls__716 }; vec__1242000072__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()
//line :241:1
				var end__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000072__11, lang.RT_IntCast_J__I_NoInit(0), nil); var width__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000072__11, lang.RT_IntCast_J__I_NoInit(1), nil); var discardable__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000072__11, lang.RT_IntCast_J__I_NoInit(2), nil); var width__15 any














				if jrt.J2g_Truth(discardable__14) { width__15 = A_arbace_repr_go_print_text_A_const_46 } else { width__15 = width__13 }
				var root_735 any = A_arbace_repr_go_print_text_A_const_96.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, A_arbace_repr_go_print_text_format_block_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = sb__0; var arg_739 any = lines__1; var arg_740 any; var root_743 any = A_arbace_repr_go_print_text_A_const_7.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = widths__2; var arg_747 any = width__15; if linked_744 == nil { arg_740 = ifn_745.Invoke_O_O__O(arg_746, arg_747) } else { arg_740 = linked_744.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_743, arg_746, arg_747) }; var arg_741 any = line0__10; var arg_742 any = end__12; if linked_736 == nil { ifn_737.Invoke_O_O_O_O_O__O(arg_738, arg_739, arg_740, arg_741, arg_742) } else { linked_736.(*A_arbace_repr_go_print_text_format_block_A).Invoke_O_O_O_O_O_O__O(root_735, arg_738, arg_739, arg_740, arg_741, arg_742) }
				var tmp9 jrt.Number_I; var na_748 any = end__12; if jrt.Long_InstanceOf(na_748) { var n0_749 int64 = jrt.NN(jrt.Long_Cast(na_748)).LongValue__J(); if n0_749 == 9223372036854775807 { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_748) } else { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_749 + 1)) } } else { if jrt.Double_InstanceOf(na_748) { var n0_749_2 float64 = jrt.NN(jrt.Double_Cast(na_748)).DoubleValue__D(); tmp9 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_749_2 + 1.0)) } else { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_748) } }; this__7, line0__8 = tmp9, end__12; continue L1 } } else {
					var root_717 any = A_arbace_repr_go_print_text_A_const_95.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, A_arbace_repr_go_print_text_write_lines_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = sb__0; var arg_721 any = lines__1; var arg_722 any = widths__2; var arg_723 any = line0__8; var arg_724 any = line1__4; if linked_718 == nil { return ifn_719.Invoke_O_O_O_O_O__O(arg_720, arg_721, arg_722, arg_723, arg_724) } else { return linked_718.(*A_arbace_repr_go_print_text_write_lines_A).Invoke_O_O_O_O_O_O__O(root_717, arg_720, arg_721, arg_722, arg_723, arg_724) } } } }; /*line :234:1*/panic("j2g: unreachable") }












func A_arbace_repr_go_print_text_format_block_fn__1242000075_A_New_I_O_O_O(p0 int32, p1, p2, p3 any) *A_arbace_repr_go_print_text_format_block_fn__1242000075_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_format_block_fn__1242000075_A{}; t.Ctor_I_O_O_O(p0, p1, p2, p3); return t }
//line :247:1
func (t *A_arbace_repr_go_print_text_format_block_fn__1242000075_A) Ctor_I_O_O_O(c__column int32, c__this, c__line1, c__lines any) { t.F_column = c__column; t.F_this = c__this; t.F_line1 = c__line1; t.F_lines = c__lines }
//line :247:1
func (t *A_arbace_repr_go_print_text_format_block_fn__1242000075_A) Invoke_O__O(self any) any { { var this__1 any; var t_ any = t.F_this; t.F_this = nil; this__1 = t_; var width__2 any = lang.RT_Box_J__Number_NoInit(0); var discardable__3 any = jrt.Boolean_TRUE.Ref(); L1: for {
												var tmp1 bool; var na_701 any = this__1; var na_702 any = t.F_line1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_701); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_702) }; tmp2 = tmp3; if tmp2 { var n0_703 int64 = jrt.NN(jrt.Long_Cast(na_701)).LongValue__J(); var n1_704 int64 = jrt.NN(jrt.Long_Cast(na_702)).LongValue__J(); tmp1 = n0_703 < n1_704 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_701); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_702) }; tmp4 = tmp5; if tmp4 { var n0_703_2 float64 = jrt.NN(jrt.Double_Cast(na_701)).DoubleValue__D(); var n1_704_2 float64 = jrt.NN(jrt.Double_Cast(na_702)).DoubleValue__D(); tmp1 = n0_703_2 < n1_704_2 } else { tmp1 = lang.Numbers_Lt_O_O__Z_NoInit(na_701, na_702) } }; if tmp1 { var tmp6 any = t.F_lines; var line__4 any = lang.RT_Nth_O_I__O_NoInit(tmp6, lang.RT_IntCast_O__I_NoInit(this__1)); var tmp7 int64 = int64(t.F_column)

		if lang.Numbers_Gte_J_J__Z_NoInit(tmp7, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(line__4)))) { return lang.Tuple_Create_O_O_O__IPersistentVector(this__1, width__2, discardable__3) } else { var c__5 any = lang.RT_Nth_O_I__O_NoInit(line__4, t.F_column); var tmp8 jrt.Number_I
			var na_706 any = this__1

			if jrt.Long_InstanceOf(na_706) { var n0_707 int64 = jrt.NN(jrt.Long_Cast(na_706)).LongValue__J(); if n0_707 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_706) } else { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_707 + 1)) } } else { if jrt.Double_InstanceOf(na_706) { var n0_707_2 float64 = jrt.NN(jrt.Double_Cast(na_706)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_707_2 + 1.0)) } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_706) } }; var tmp9 any = tmp8; var tmp10 jrt.Number_I; var na_708 any = A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__5); if jrt.Long_InstanceOf(na_708) { var n0_709 int64 = jrt.NN(jrt.Long_Cast(na_708)).LongValue__J(); if n0_709 == 9223372036854775807 { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_708) } else { tmp10 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_709 + 1)) } } else { if jrt.Double_InstanceOf(na_708) { var n0_709_2 float64 = jrt.NN(jrt.Double_Cast(na_708)).DoubleValue__D(); tmp10 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_709_2 + 1.0)) } else { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_708) } }; var tmp11 any = lang.Numbers_Max_O_O__O_NoInit(width__2, tmp10); var tmp12 any; var and__1927000168__auto____6 any = discardable__3
			if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 bool; var na_710 any = A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__5); if jrt.Long_InstanceOf(na_710) { var n0_711 int64 = jrt.NN(jrt.Long_Cast(na_710)).LongValue__J(); and__1927000168__auto____7 = n0_711 == 0 } else { if jrt.Double_InstanceOf(na_710) { var n0_711_2 float64 = jrt.NN(jrt.Double_Cast(na_710)).DoubleValue__D(); and__1927000168__auto____7 = n0_711_2 == 0.0 } else { and__1927000168__auto____7 = lang.Numbers_IsZero_O__Z_NoInit(na_710) } }; if and__1927000168__auto____7 { var root_712 any = A_arbace_repr_go_print_text_A_const_52.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = A_arbace_repr_go_print_text_A_const_83.Invoke_O__O(c__5); if linked_713 == nil { tmp12 = ifn_714.Invoke_O__O(arg_715) } else { tmp12 = linked_713.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_712, arg_715) } } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp12 = and__1927000168__auto____6 }
//line :253:1
			this__1, width__2, discardable__3 = tmp9, tmp11, tmp12; continue L1 } } else {
//line :248:1
				return lang.Tuple_Create_O_O_O__IPersistentVector(this__1, width__2, discardable__3) } } }; /*line :247:1*/panic("j2g: unreachable") }













func A_arbace_repr_go_print_text_align_block_A_New() *A_arbace_repr_go_print_text_align_block_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_align_block_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_repr_go_print_text_align_block_A) Ctor() {}
//line :261:1
func (t *A_arbace_repr_go_print_text_align_block_A) Invoke_O_O__O(self, block__0 any) any { var sb__2 any = jrt.StringBuilder_New(); var lines__3 any; var root_750 any = A_arbace_repr_go_print_text_A_const_97.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, A_arbace_repr_go_print_text_parse_lines_A_fn_class); var ifn_752 lang.IFn; if



	linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = block__0; if linked_751 == nil { lines__3 = ifn_752.Invoke_O__O(arg_753) } else { lines__3 = linked_751.(*A_arbace_repr_go_print_text_parse_lines_A).Invoke_O_O__O(root_750, arg_753) }; var root_754 any =
	A_arbace_repr_go_print_text_A_const_96.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, A_arbace_repr_go_print_text_format_block_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = sb__2; var arg_758 any = lines__3; var arg_759 any = lang.PersistentVector_EMPTY.Ref(); var arg_760 any = A_arbace_repr_go_print_text_A_const_46; var arg_761 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lines__3)).Ref(); if linked_755 == nil { ifn_756.Invoke_O_O_O_O_O__O(arg_757, arg_758, arg_759, arg_760, arg_761) } else { linked_755.(*A_arbace_repr_go_print_text_format_block_A).Invoke_O_O_O_O_O_O__O(root_754, arg_757, arg_758, arg_759, arg_760, arg_761) }; return /*line :267:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_repr_go_print_text_align_A_New() *A_arbace_repr_go_print_text_align_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_align_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_repr_go_print_text_align_A) Ctor() {}
//line :269:1
func (t *A_arbace_repr_go_print_text_align_A) Invoke_O_O__O(self, text__0 any) any { var blocks__2 any; var root_762 any = A_arbace_repr_go_print_text_A_const_89.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_764 lang.IFn; if



	linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = text__0; var arg_766 any = A_arbace_repr_go_print_text_A_const_98; var arg_767 any = A_arbace_repr_go_print_text_A_const_91; if linked_763 == nil { blocks__2 = ifn_764.Invoke_O_O_O__O(arg_765, arg_766, arg_767) } else { blocks__2 = linked_763.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_762, arg_765, arg_766, arg_767) }; var n__3 int32 = /*line :269:1*/lang.RT_Count_O__I_NoInit(blocks__2); var groups__4 int64 = lang.Numbers_Multiply_J_J__J_NoInit(4, int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())); var aligned__5 any; if






	lang.Numbers_Lt_J_J__Z_NoInit(int64(n__3), 128) {
		var root_768 any = A_arbace_repr_go_print_text_A_const_99.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = A_arbace_repr_go_print_text_A_const_100.GetRawRoot__O(); var arg_772 any = blocks__2; if linked_769 == nil { aligned__5 = ifn_770.Invoke_O_O__O(arg_771, arg_772) } else { aligned__5 = linked_769.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_768, arg_771, arg_772) } } else {
			var root_773 any = A_arbace_repr_go_print_text_A_const_14.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = A_arbace_repr_go_print_text_A_const_101.GetRawRoot__O(); var arg_777 any; var root_778 any = A_arbace_repr_go_print_text_A_const_102.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any; var tmp1 any = A_arbace_repr_go_print_text_align_fn__1242000080_A_New(); var tmp2 *jrt.Class; var fncls__788 *jrt.Class = A_arbace_repr_go_print_text_align_fn__1242000080_A_fn_class; if fncls__788 == nil { var fncls__788d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_repr_go_print_text_align_fn__1242000080_A_fn_class = fncls__788d; tmp2 = fncls__788d } else { tmp2 = fncls__788 }; arg_781 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_782 any; var root_789 any = A_arbace_repr_go_print_text_A_const_104.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_partition_all_A_fn_class); var ifn_791 lang.IFn
			if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(n__3), lang.Numbers_Dec_J__J_NoInit(groups__4)), groups__4)).Ref(); var arg_793 any = blocks__2; if linked_790 == nil { arg_782 = ifn_791.Invoke_O_O__O(arg_792, arg_793) } else { arg_782 = linked_790.(*aot_arbace_core.A_arbace_core_partition_all_A).Invoke_O_O_O__O(root_789, arg_792, arg_793) }
//line :278:1
			if linked_779 == nil { arg_777 = ifn_780.Invoke_O_O__O(arg_781, arg_782) } else { arg_777 = linked_779.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_778, arg_781, arg_782) }; if linked_774 == nil { aligned__5 = ifn_775.Invoke_O_O__O(arg_776, arg_777) } else { aligned__5 = linked_774.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_773, arg_776, arg_777) } }; var root_794 any =

	A_arbace_repr_go_print_text_A_const_105.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, A_arbace_repr_go_print_text_unescape_A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any; var root_798 any = A_arbace_repr_go_print_text_A_const_106.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_798, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = Lit_2; var arg_802 any = aligned__5; if linked_799 == nil { arg_797 = ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { arg_797 = linked_799.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_798, arg_801, arg_802) }; if linked_795 == nil { return ifn_796.Invoke_O__O(arg_797) } else { return linked_795.(*A_arbace_repr_go_print_text_unescape_A).Invoke_O_O__O(root_794, arg_797) } }
//line :278:1
func A_arbace_repr_go_print_text_align_fn__1242000080_A_New() *A_arbace_repr_go_print_text_align_fn__1242000080_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_align_fn__1242000080_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_repr_go_print_text_align_fn__1242000080_A) Ctor() {}
//line :278:1
func (t *A_arbace_repr_go_print_text_align_fn__1242000080_A) Invoke_O_O__O(self, p1__1242000079_SHARP___1 any) any { var root_783 any = A_arbace_repr_go_print_text_A_const_103.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_785 lang.IFn; if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any = A_arbace_repr_go_print_text_A_const_100.GetRawRoot__O(); var arg_787 any = p1__1242000079_SHARP___1; if linked_784 == nil { return ifn_785.Invoke_O_O__O(arg_786, arg_787) } else { return linked_784.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_783, arg_786, arg_787) } }







type A_arbace_repr_go_print_text_A struct{ jrt.Object }

var A_arbace_repr_go_print_text_A_const_pool *jrt.RefArray

var A_arbace_repr_go_print_text_A_const_0 *lang.Var

var A_arbace_repr_go_print_text_A_const_1 any

var A_arbace_repr_go_print_text_A_const_2 *lang.Var

var A_arbace_repr_go_print_text_A_const_3 any

var A_arbace_repr_go_print_text_A_const_4 *lang.Var

var A_arbace_repr_go_print_text_A_const_5 *lang.Var

var A_arbace_repr_go_print_text_A_const_6 *lang.Var

var A_arbace_repr_go_print_text_A_const_7 *lang.Var

var A_arbace_repr_go_print_text_A_const_8 any

var A_arbace_repr_go_print_text_A_const_9 *lang.Var

var A_arbace_repr_go_print_text_A_const_10 any

var A_arbace_repr_go_print_text_A_const_11 any

var A_arbace_repr_go_print_text_A_const_12 *lang.Var

var A_arbace_repr_go_print_text_A_const_13 *lang.Var

var A_arbace_repr_go_print_text_A_const_14 *lang.Var

var A_arbace_repr_go_print_text_A_const_15 *lang.Var

var A_arbace_repr_go_print_text_A_const_16 *lang.Var

var A_arbace_repr_go_print_text_A_const_17 any

var A_arbace_repr_go_print_text_A_const_18 *lang.Var

var A_arbace_repr_go_print_text_A_const_19 *lang.Var

var A_arbace_repr_go_print_text_A_const_20 any

var A_arbace_repr_go_print_text_A_const_21 any

var A_arbace_repr_go_print_text_A_const_22 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_23 any

var A_arbace_repr_go_print_text_A_const_24 *lang.Var

var A_arbace_repr_go_print_text_A_const_25 *lang.Var

var A_arbace_repr_go_print_text_A_const_26 *lang.Var

var A_arbace_repr_go_print_text_A_const_27 *lang.Var

var A_arbace_repr_go_print_text_A_const_28 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_29 *lang.Var

var A_arbace_repr_go_print_text_A_const_30 *lang.Var

var A_arbace_repr_go_print_text_A_const_31 *lang.Var

var A_arbace_repr_go_print_text_A_const_32 *lang.Var

var A_arbace_repr_go_print_text_A_const_33 *lang.Var

var A_arbace_repr_go_print_text_A_const_34 *lang.Var

var A_arbace_repr_go_print_text_A_const_35 *lang.Var

var A_arbace_repr_go_print_text_A_const_36 any

var A_arbace_repr_go_print_text_A_const_37 *lang.Var

var A_arbace_repr_go_print_text_A_const_38 *lang.Var

var A_arbace_repr_go_print_text_A_const_39 *lang.Var

var A_arbace_repr_go_print_text_A_const_40 *lang.Var

var A_arbace_repr_go_print_text_A_const_41 any

var A_arbace_repr_go_print_text_A_const_42 any

var A_arbace_repr_go_print_text_A_const_43 *lang.Var

var A_arbace_repr_go_print_text_A_const_44 *lang.Var

var A_arbace_repr_go_print_text_A_const_45 *lang.Var

var A_arbace_repr_go_print_text_A_const_46 any

var A_arbace_repr_go_print_text_A_const_47 any

var A_arbace_repr_go_print_text_A_const_48 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_49 any

var A_arbace_repr_go_print_text_A_const_50 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_51 *lang.Var

var A_arbace_repr_go_print_text_A_const_52 *lang.Var

var A_arbace_repr_go_print_text_A_const_53 *lang.Var

var A_arbace_repr_go_print_text_A_const_54 *lang.Var

var A_arbace_repr_go_print_text_A_const_55 *lang.Var

var A_arbace_repr_go_print_text_A_const_56 *lang.Var

var A_arbace_repr_go_print_text_A_const_57 *lang.Var

var A_arbace_repr_go_print_text_A_const_58 *lang.Var

var A_arbace_repr_go_print_text_A_const_59 *lang.Var

var A_arbace_repr_go_print_text_A_const_60 *lang.Var

var A_arbace_repr_go_print_text_A_const_61 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_62 *lang.Var

var A_arbace_repr_go_print_text_A_const_63 *lang.Var

var A_arbace_repr_go_print_text_A_const_64 any

var A_arbace_repr_go_print_text_A_const_65 any

var A_arbace_repr_go_print_text_A_const_66 any

var A_arbace_repr_go_print_text_A_const_67 any

var A_arbace_repr_go_print_text_A_const_68 any

var A_arbace_repr_go_print_text_A_const_69 any

var A_arbace_repr_go_print_text_A_const_70 any

var A_arbace_repr_go_print_text_A_const_71 any

var A_arbace_repr_go_print_text_A_const_72 any

var A_arbace_repr_go_print_text_A_const_73 any

var A_arbace_repr_go_print_text_A_const_74 any

var A_arbace_repr_go_print_text_A_const_75 any

var A_arbace_repr_go_print_text_A_const_76 *lang.Var

var A_arbace_repr_go_print_text_A_const_77 *lang.Var

var A_arbace_repr_go_print_text_A_const_78 *lang.Var

var A_arbace_repr_go_print_text_A_const_79 *lang.Var

var A_arbace_repr_go_print_text_A_const_80 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_81 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_82 *lang.Var

var A_arbace_repr_go_print_text_A_const_83 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_84 *lang.Var

var A_arbace_repr_go_print_text_A_const_85 *lang.Var

var A_arbace_repr_go_print_text_A_const_86 *lang.Var

var A_arbace_repr_go_print_text_A_const_87 *lang.Var

var A_arbace_repr_go_print_text_A_const_88 *lang.Var

var A_arbace_repr_go_print_text_A_const_89 *lang.Var

var A_arbace_repr_go_print_text_A_const_90 any

var A_arbace_repr_go_print_text_A_const_91 any

var A_arbace_repr_go_print_text_A_const_92 any

var A_arbace_repr_go_print_text_A_const_93 *lang.Var

var A_arbace_repr_go_print_text_A_const_94 *lang.Var

var A_arbace_repr_go_print_text_A_const_95 *lang.Var

var A_arbace_repr_go_print_text_A_const_96 *lang.Var

var A_arbace_repr_go_print_text_A_const_97 *lang.Var

var A_arbace_repr_go_print_text_A_const_98 any

var A_arbace_repr_go_print_text_A_const_99 *lang.Var

var A_arbace_repr_go_print_text_A_const_100 *lang.Var

var A_arbace_repr_go_print_text_A_const_101 *lang.Var

var A_arbace_repr_go_print_text_A_const_102 *lang.Var

var A_arbace_repr_go_print_text_A_const_103 *lang.Var

var A_arbace_repr_go_print_text_A_const_104 *lang.Var

var A_arbace_repr_go_print_text_A_const_105 *lang.Var

var A_arbace_repr_go_print_text_A_const_106 *lang.Var

var A_arbace_repr_go_print_text_A_init jrt.ClassInit

func A_arbace_repr_go_print_text_A_Init() { if !A_arbace_repr_go_print_text_A_init.Done() { A_arbace_repr_go_print_text_A_init.Run(A_arbace_repr_go_print_text_A_clinit) } }

func A_arbace_repr_go_print_text_A_clinit() { A_arbace_repr_go_print_text_A_clinit_p0(); A_arbace_repr_go_print_text_A_clinit_p1(); A_arbace_repr_go_print_text_A_clinit_p2(); A_arbace_repr_go_print_text_A_clinit_p3(); A_arbace_repr_go_print_text_A_clinit_p4(); A_arbace_repr_go_print_text_A_clinit_p5(); A_arbace_repr_go_print_text_A_clinit_p6(); A_arbace_repr_go_print_text_A_clinit_p7(); A_arbace_repr_go_print_text_A_clinit_p8() }

func A_arbace_repr_go_print_text_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_print_text_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 120); A_arbace_repr_go_print_text_A_const_0 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[13]); A_arbace_repr_go_print_text_A_const_1 = A_arbace_repr_go_print_text_A_const_pool.A[14]; A_arbace_repr_go_print_text_A_const_2 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[15]); A_arbace_repr_go_print_text_A_const_3 = A_arbace_repr_go_print_text_A_const_pool.A[16]; A_arbace_repr_go_print_text_A_const_4 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[17]); A_arbace_repr_go_print_text_A_const_5 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[18]); A_arbace_repr_go_print_text_A_const_6 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[19]); A_arbace_repr_go_print_text_A_const_7 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[20]); A_arbace_repr_go_print_text_A_const_8 = A_arbace_repr_go_print_text_A_const_pool.A[21]; A_arbace_repr_go_print_text_A_const_9 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[22]); A_arbace_repr_go_print_text_A_const_10 = A_arbace_repr_go_print_text_A_const_pool.A[23]; A_arbace_repr_go_print_text_A_const_11 = A_arbace_repr_go_print_text_A_const_pool.A[24] }

func A_arbace_repr_go_print_text_A_clinit_p1() { A_arbace_repr_go_print_text_A_const_12 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[25]); A_arbace_repr_go_print_text_A_const_13 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[26]); A_arbace_repr_go_print_text_A_const_14 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[27]); A_arbace_repr_go_print_text_A_const_15 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[28]); A_arbace_repr_go_print_text_A_const_16 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[29]); A_arbace_repr_go_print_text_A_const_17 = A_arbace_repr_go_print_text_A_const_pool.A[30]; A_arbace_repr_go_print_text_A_const_18 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[31]); A_arbace_repr_go_print_text_A_const_19 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[32]); A_arbace_repr_go_print_text_A_const_20 = A_arbace_repr_go_print_text_A_const_pool.A[33]; A_arbace_repr_go_print_text_A_const_21 = A_arbace_repr_go_print_text_A_const_pool.A[34]; A_arbace_repr_go_print_text_A_const_22 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[35]); A_arbace_repr_go_print_text_A_const_23 = A_arbace_repr_go_print_text_A_const_pool.A[36]; A_arbace_repr_go_print_text_A_const_24 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[37]) }

func A_arbace_repr_go_print_text_A_clinit_p2() { A_arbace_repr_go_print_text_A_const_25 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[38]); A_arbace_repr_go_print_text_A_const_26 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[39]); A_arbace_repr_go_print_text_A_const_27 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[40]); A_arbace_repr_go_print_text_A_const_28 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[41]); A_arbace_repr_go_print_text_A_const_29 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[42]); A_arbace_repr_go_print_text_A_const_30 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[43]); A_arbace_repr_go_print_text_A_const_31 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[44]); A_arbace_repr_go_print_text_A_const_32 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[45]); A_arbace_repr_go_print_text_A_const_33 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[46]); A_arbace_repr_go_print_text_A_const_34 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[47]); A_arbace_repr_go_print_text_A_const_35 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[48]); A_arbace_repr_go_print_text_A_const_36 = A_arbace_repr_go_print_text_A_const_pool.A[49] }

func A_arbace_repr_go_print_text_A_clinit_p3() { A_arbace_repr_go_print_text_A_const_37 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[50]); A_arbace_repr_go_print_text_A_const_38 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[51]); A_arbace_repr_go_print_text_A_const_39 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[52]); A_arbace_repr_go_print_text_A_const_40 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[53]); A_arbace_repr_go_print_text_A_const_41 = A_arbace_repr_go_print_text_A_const_pool.A[54]; A_arbace_repr_go_print_text_A_const_42 = A_arbace_repr_go_print_text_A_const_pool.A[55]; A_arbace_repr_go_print_text_A_const_43 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[56]); A_arbace_repr_go_print_text_A_const_44 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[57]); A_arbace_repr_go_print_text_A_const_45 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[58]); A_arbace_repr_go_print_text_A_const_46 = A_arbace_repr_go_print_text_A_const_pool.A[59]; A_arbace_repr_go_print_text_A_const_47 = A_arbace_repr_go_print_text_A_const_pool.A[60]; A_arbace_repr_go_print_text_A_const_48 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[61]); A_arbace_repr_go_print_text_A_const_49 = A_arbace_repr_go_print_text_A_const_pool.A[62] }

func A_arbace_repr_go_print_text_A_clinit_p4() { A_arbace_repr_go_print_text_A_const_50 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[63]); A_arbace_repr_go_print_text_A_const_51 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[64]); A_arbace_repr_go_print_text_A_const_52 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[65]); A_arbace_repr_go_print_text_A_const_53 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[66]); A_arbace_repr_go_print_text_A_const_54 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[67]); A_arbace_repr_go_print_text_A_const_55 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[68]); A_arbace_repr_go_print_text_A_const_56 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[69]); A_arbace_repr_go_print_text_A_const_57 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[70]); A_arbace_repr_go_print_text_A_const_58 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[71]); A_arbace_repr_go_print_text_A_const_59 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[72]); A_arbace_repr_go_print_text_A_const_60 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[73]); A_arbace_repr_go_print_text_A_const_61 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[74]) }

func A_arbace_repr_go_print_text_A_clinit_p5() { A_arbace_repr_go_print_text_A_const_62 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[75]); A_arbace_repr_go_print_text_A_const_63 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[76]); A_arbace_repr_go_print_text_A_const_64 = A_arbace_repr_go_print_text_A_const_pool.A[77]; A_arbace_repr_go_print_text_A_const_65 = A_arbace_repr_go_print_text_A_const_pool.A[78]; A_arbace_repr_go_print_text_A_const_66 = A_arbace_repr_go_print_text_A_const_pool.A[79]; A_arbace_repr_go_print_text_A_const_67 = A_arbace_repr_go_print_text_A_const_pool.A[80]; A_arbace_repr_go_print_text_A_const_68 = A_arbace_repr_go_print_text_A_const_pool.A[81]; A_arbace_repr_go_print_text_A_const_69 = A_arbace_repr_go_print_text_A_const_pool.A[82]; A_arbace_repr_go_print_text_A_const_70 = A_arbace_repr_go_print_text_A_const_pool.A[83]; A_arbace_repr_go_print_text_A_const_71 = A_arbace_repr_go_print_text_A_const_pool.A[84]; A_arbace_repr_go_print_text_A_const_72 = A_arbace_repr_go_print_text_A_const_pool.A[85]; A_arbace_repr_go_print_text_A_const_73 = A_arbace_repr_go_print_text_A_const_pool.A[86]; A_arbace_repr_go_print_text_A_const_74 = A_arbace_repr_go_print_text_A_const_pool.A[87]; A_arbace_repr_go_print_text_A_const_75 = A_arbace_repr_go_print_text_A_const_pool.A[88]; A_arbace_repr_go_print_text_A_const_76 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[89]) }

func A_arbace_repr_go_print_text_A_clinit_p6() { A_arbace_repr_go_print_text_A_const_77 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[90]); A_arbace_repr_go_print_text_A_const_78 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[91]); A_arbace_repr_go_print_text_A_const_79 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[92]); A_arbace_repr_go_print_text_A_const_80 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[93]); A_arbace_repr_go_print_text_A_const_81 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[94]); A_arbace_repr_go_print_text_A_const_82 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[95]); A_arbace_repr_go_print_text_A_const_83 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[96]); A_arbace_repr_go_print_text_A_const_84 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[97]); A_arbace_repr_go_print_text_A_const_85 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[98]); A_arbace_repr_go_print_text_A_const_86 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[99]); A_arbace_repr_go_print_text_A_const_87 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[100]); A_arbace_repr_go_print_text_A_const_88 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[101]) }

func A_arbace_repr_go_print_text_A_clinit_p7() { A_arbace_repr_go_print_text_A_const_89 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[102]); A_arbace_repr_go_print_text_A_const_90 = A_arbace_repr_go_print_text_A_const_pool.A[103]; A_arbace_repr_go_print_text_A_const_91 = A_arbace_repr_go_print_text_A_const_pool.A[104]; A_arbace_repr_go_print_text_A_const_92 = A_arbace_repr_go_print_text_A_const_pool.A[105]; A_arbace_repr_go_print_text_A_const_93 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[106]); A_arbace_repr_go_print_text_A_const_94 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[107]); A_arbace_repr_go_print_text_A_const_95 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[108]); A_arbace_repr_go_print_text_A_const_96 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[109]); A_arbace_repr_go_print_text_A_const_97 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[110]); A_arbace_repr_go_print_text_A_const_98 = A_arbace_repr_go_print_text_A_const_pool.A[111]; A_arbace_repr_go_print_text_A_const_99 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[112]); A_arbace_repr_go_print_text_A_const_100 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[113]); A_arbace_repr_go_print_text_A_const_101 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[114]) }

func A_arbace_repr_go_print_text_A_clinit_p8() { A_arbace_repr_go_print_text_A_const_102 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[115]); A_arbace_repr_go_print_text_A_const_103 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[116]); A_arbace_repr_go_print_text_A_const_104 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[117]); A_arbace_repr_go_print_text_A_const_105 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[118]); A_arbace_repr_go_print_text_A_const_106 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[119]) }

func A_arbace_repr_go_print_text_A_New() *A_arbace_repr_go_print_text_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_text_A) Ctor() {}

func (t *A_arbace_repr_go_print_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_text_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_text_A_class }

func (t *A_arbace_repr_go_print_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_text_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_text_A); return ok }

func A_arbace_repr_go_print_text_A_Cast(x any) *A_arbace_repr_go_print_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_text_A_class)) }; return v }



type A_arbace_repr_go_print_text_align_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_align_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_align_fn__1242000080_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_align_fn__1242000080_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_align_block_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_align_block_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_cell_width_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_cell_width_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_code_points_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_code_points_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_escape_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_escape_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_escape_cp_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_escape_cp_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_eval1242000004_A struct{ jrt.Object }

func A_arbace_repr_go_print_text_eval1242000004_A_New() *A_arbace_repr_go_print_text_eval1242000004_A { t := &A_arbace_repr_go_print_text_eval1242000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) Ctor() {}

func (t *A_arbace_repr_go_print_text_eval1242000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_text_eval1242000004_A_class }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_text_eval1242000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_text_eval1242000004_A); return ok }

func A_arbace_repr_go_print_text_eval1242000004_A_Cast(x any) *A_arbace_repr_go_print_text_eval1242000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_text_eval1242000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_text_eval1242000004_A_class)) }; return v }



type A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_eval1242000008_A struct{ jrt.Object }

func A_arbace_repr_go_print_text_eval1242000008_A_New() *A_arbace_repr_go_print_text_eval1242000008_A { t := &A_arbace_repr_go_print_text_eval1242000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) Ctor() {}

func (t *A_arbace_repr_go_print_text_eval1242000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_text_eval1242000008_A_class }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_text_eval1242000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_text_eval1242000008_A); return ok }

func A_arbace_repr_go_print_text_eval1242000008_A_Cast(x any) *A_arbace_repr_go_print_text_eval1242000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_text_eval1242000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_text_eval1242000008_A_class)) }; return v }



type A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_float_kind_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_float_kind_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_format_block_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_format_block_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_format_block_fn__1242000075_A struct{ j2g_header uint64; F_column int32; F_this, F_line1, F_lines any }

var A_arbace_repr_go_print_text_format_block_fn__1242000075_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_byte_string_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_byte_string_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_float_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_float_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_number_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_number_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_printable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_printable_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_rune_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_rune_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_string_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_string_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_hex_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_hex_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_negative_number_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_negative_number_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_parse_lines_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A struct{ j2g_header uint64; F_s__1242000052, F_iter__1242000051 any }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A struct{ j2g_header uint64; F_b__1242000054 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A struct{ j2g_header uint64; F_n int32; F_line any }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A struct{ j2g_header uint64; F_n int32; F_line any }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_pow2_exponent_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_pow2_exponent_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_raw_string_ok_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_raw_string_ok_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_strip_2_5_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_strip_2_5_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_unescape_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_unescape_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_write_lines_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_write_lines_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_write_padding_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_write_padding_A_fn_class *jrt.Class
