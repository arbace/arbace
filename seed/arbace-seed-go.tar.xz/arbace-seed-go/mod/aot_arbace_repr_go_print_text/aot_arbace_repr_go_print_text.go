//line aot_arbace_repr_go_print_text.ae:1
package aot_arbace_repr_go_print_text

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A_New() *A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_text_A_const_1); lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_text_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A_New() *A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_4.GetRawRoot__O()); var tmp2 any; var root_9 any = A_arbace_repr_go_print_text_A_const_5.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = A_arbace_repr_go_print_text_A_const_6; if linked_10 == nil { tmp2 = ifn_11.Invoke_O__O(arg_12) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_9, arg_12) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_repr_go_print_text_A_const_7.GetRawRoot__O(), A_arbace_repr_go_print_text_A_const_8) }
































func A_arbace_repr_go_print_text_go_printable_QMARK__A_New() *A_arbace_repr_go_print_text_go_printable_QMARK__A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_printable_QMARK__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_repr_go_print_text_go_printable_QMARK__A) Ctor() {}
//line :34:1
func (t *A_arbace_repr_go_print_text_go_printable_QMARK__A) Invoke_O_O__O(self, p_cp__0 any) any { var cp__0 int64 = lang.RT_LongCast_O__J_NoInit(p_cp__0); var or__1927000174__auto____2 bool = lang.Numbers_Equiv_J_J__Z_NoInit(cp__0, 32); if or__1927000174__auto____2 {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_9.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_text_A_const_10; var or__1927000174__auto____3 any = tmp1.Invoke_O_O_O__O(tmp2, jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref(), A_arbace_repr_go_print_text_A_const_11); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else {

		var root_25 any = A_arbace_repr_go_print_text_A_const_12.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = A_arbace_repr_go_print_text_A_const_13.GetRawRoot__O(); var arg_29 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_I__I_NoInit(jrt.Character_GetType_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(cp__0)))).Ref(); if linked_26 == nil { return ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { return linked_26.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_25, arg_28, arg_29) } } } }

func A_arbace_repr_go_print_text_hex_A_New() *A_arbace_repr_go_print_text_hex_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_hex_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_repr_go_print_text_hex_A) Ctor() {}
//line :42:1
func (t *A_arbace_repr_go_print_text_hex_A) Invoke_O_O_O__O(self, p_n__0, p_width__1 any) any { var n__0 int64 = lang.RT_LongCast_O__J_NoInit(p_n__0); var width__1 int64 = lang.RT_LongCast_O__J_NoInit(p_width__1); var s__3 any = jrt.Long_ToHexString_J__String_NoInit(n__0).Ref(); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_35 any = A_arbace_repr_go_print_text_A_const_14.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_37 lang.IFn; if

	linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = A_arbace_repr_go_print_text_A_const_15.GetRawRoot__O(); var arg_39 any; var root_30 any = A_arbace_repr_go_print_text_A_const_16.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_repeat_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(width__1, int64(lang.RT_Count_O__I_NoInit(s__3)))).Ref(); var arg_34 any = A_arbace_repr_go_print_text_A_const_17; if linked_31 == nil { arg_39 = ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { arg_39 = linked_31.(*aot_arbace_core.A_arbace_core_repeat_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) }; if linked_36 == nil { tmp2 = ifn_37.Invoke_O_O__O(arg_38, arg_39) } else { tmp2 = linked_36.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_35, arg_38, arg_39) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, s__3)).Ref() }

func A_arbace_repr_go_print_text_escape_cp_A_New() *A_arbace_repr_go_print_text_escape_cp_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_escape_cp_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_repr_go_print_text_escape_cp_A) Ctor() {}
//line :46:1
func (t *A_arbace_repr_go_print_text_escape_cp_A) Invoke_O_O_O__O(self, p_cp__0, quote__1 any) any { var cp__0 int64 = lang.RT_LongCast_O__J_NoInit(p_cp__0); var G__1242000014__3_ int32 = lang.RT_IntCast_J__I_NoInit(cp__0); switch G__1242000014__3_ {


case 7: return Lit_4; case 8: return Lit_5; case 9: return Lit_6; case 10: return Lit_7; case 11: return Lit_8; case 12: return Lit_9; case 13: return Lit_10; case 92: return Lit_11; default:}; if

	lang.Numbers_Equiv_J_J__Z_NoInit(cp__0, lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(quote__1))) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, quote__1)).Ref() } else {
//line :51:1
			var tmp1 any; var root_41 any = A_arbace_repr_go_print_text_A_const_18.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, A_arbace_repr_go_print_text_go_printable_QMARK__A_fn_class); var ifn_43 lang.IFn

			if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref(); if linked_42 == nil { tmp1 = ifn_43.Invoke_O__O(arg_44) } else { tmp1 = linked_42.(*A_arbace_repr_go_print_text_go_printable_QMARK__A).Invoke_O_O__O(root_41, arg_44) }
//line :51:1
			if jrt.J2g_Truth(tmp1) { return jrt.String_New_C1(jrt.Character_ToChars_I__C1_NoInit(lang.RT_IntCast_J__I_NoInit(cp__0))) } else { if lang.Numbers_Lt_J_J__Z_NoInit(cp__0, 128) {


				var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil); var tmp3 any; var root_45 any = A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, A_arbace_repr_go_print_text_hex_A_fn_class); var ifn_47 lang.IFn; if linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref(); var arg_49 any = A_arbace_repr_go_print_text_A_const_20; if linked_46 == nil { tmp3 = ifn_47.Invoke_O_O__O(arg_48, arg_49) } else { tmp3 = linked_46.(*A_arbace_repr_go_print_text_hex_A).Invoke_O_O_O__O(root_45, arg_48, arg_49) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() } else {
//line :51:1
					if lang.Numbers_Lte_J_J__Z_NoInit(cp__0, 65535) {



						var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_14, nil); var tmp5 any; var root_50 any = A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, A_arbace_repr_go_print_text_hex_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref(); var arg_54 any = A_arbace_repr_go_print_text_A_const_21; if linked_51 == nil { tmp5 = ifn_52.Invoke_O_O__O(arg_53, arg_54) } else { tmp5 = linked_51.(*A_arbace_repr_go_print_text_hex_A).Invoke_O_O_O__O(root_50, arg_53, arg_54) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5)).Ref() } else {
//line :51:1
							if A_arbace_repr_go_print_text_A_const_22 != nil {




								var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_15, nil); var tmp7 any; var root_55 any = A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, A_arbace_repr_go_print_text_hex_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any = jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref(); var arg_59 any = A_arbace_repr_go_print_text_A_const_23; if linked_56 == nil { tmp7 = ifn_57.Invoke_O_O__O(arg_58, arg_59) } else { tmp7 = linked_56.(*A_arbace_repr_go_print_text_hex_A).Invoke_O_O_O__O(root_55, arg_58, arg_59) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp7)).Ref() } else {
//line :51:1
									return nil } } } } } }






func A_arbace_repr_go_print_text_code_points_A_New() *A_arbace_repr_go_print_text_code_points_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_code_points_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_repr_go_print_text_code_points_A) Ctor() {}
//line :58:1
func (t *A_arbace_repr_go_print_text_code_points_A) Invoke_O_O__O(self, s__0 any) any { { var i__2 int64 = 0; var acc__3 any; var root_60 any = A_arbace_repr_go_print_text_A_const_24.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_62 lang.IFn



	if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = lang.PersistentVector_EMPTY.Ref(); if linked_61 == nil { acc__3 = ifn_62.Invoke_O__O(arg_63) } else { acc__3 = linked_61.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_60, arg_63) }
//line :58:1
L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__2, int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())) { var cp__4 int32 = jrt.NN(jrt.String_Cast(s__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(i__2)); var tmp1 bool; var and__1927000168__auto____5 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(cp__4), 55296)

		if and__1927000168__auto____5 { tmp1 = lang.Numbers_Lte_J_J__Z_NoInit(int64(cp__4), 57343) } else { tmp1 = and__1927000168__auto____5 }; if tmp1 { var tmp2 any; var root_72 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_74 lang.IFn
			if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(s__0))).Ref(); var arg_76 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_28, s__0)); if linked_73 == nil { tmp2 = ifn_74.Invoke_O_O__O(arg_75, arg_76) } else { tmp2 = linked_73.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_72, arg_75, arg_76) }
//line :65:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp2)))
		}
		var tmp3 int64 = lang.Numbers_Add_J_J__J_NoInit(i__2, int64(jrt.Character_CharCount_I__I_NoInit(cp__4))); var tmp4 any; var root_77 any = A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = acc__3; var arg_81 any = jrt.Integer_ValueOf_I__Integer_NoInit(cp__4).Ref(); if linked_78 == nil { tmp4 = ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { tmp4 = linked_78.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_77, arg_80, arg_81) }; i__2, acc__3 = tmp3, tmp4; continue L1 } else {
			var root_64 any = A_arbace_repr_go_print_text_A_const_25.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = acc__3; if linked_65 == nil { return ifn_66.Invoke_O__O(arg_67) } else { return linked_65.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_64, arg_67) } } } }; /*line :58:1*/panic("j2g: unreachable") }











func A_arbace_repr_go_print_text_go_string_A_New() *A_arbace_repr_go_print_text_go_string_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_string_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_repr_go_print_text_go_string_A) Ctor() {}
//line :70:1
func (t *A_arbace_repr_go_print_text_go_string_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_23); var seq_1242000017__3 any; var root_86 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_88 lang.IFn; if



	linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any; var root_82 any = A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, A_arbace_repr_go_print_text_code_points_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = s__0; if linked_83 == nil { arg_89 = ifn_84.Invoke_O__O(arg_85) } else { arg_89 = linked_83.(*A_arbace_repr_go_print_text_code_points_A).Invoke_O_O__O(root_82, arg_85) }; if linked_87 == nil { seq_1242000017__3 = ifn_88.Invoke_O__O(arg_89) } else { seq_1242000017__3 = linked_87.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_86, arg_89) }; var chunk_1242000018__4 any; var count_1242000019__5 int64 = 0; var i_1242000020__6 int64 = 0; L1:
//line :70:1
	for {



		if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000020__6, count_1242000019__5) { var cp__7 any = lang.Indexed_Cast(chunk_1242000018__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000020__6)); var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp2 any; var root_106 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_108 lang.IFn
			if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = cp__7; var arg_110 any = A_arbace_repr_go_print_text_A_const_36; if linked_107 == nil { tmp2 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { tmp2 = linked_107.(*A_arbace_repr_go_print_text_escape_cp_A).Invoke_O_O_O__O(root_106, arg_109, arg_110) }; jrt.NN(tmp1).Append_String__StringBuilder(jrt.String_Cast(tmp2))
//line :74:1
			seq_1242000017__3, chunk_1242000018__4, count_1242000019__5, i_1242000020__6 = seq_1242000017__3, chunk_1242000018__4, count_1242000019__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000020__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_90 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = seq_1242000017__3; if linked_91 == nil { temp__1927000414__auto____7 = ifn_92.Invoke_O__O(arg_93) } else { temp__1927000414__auto____7 = linked_91.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_90, arg_93) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1242000017__8 any = temp__1927000414__auto____7; var tmp3 any; var root_94 any = A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = seq_1242000017__8; if linked_95 == nil { tmp3 = ifn_96.Invoke_O__O(arg_97) } else { tmp3 = linked_95.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_94, arg_97) }; if jrt.J2g_Truth(tmp3) { var c__1927000678__auto____9 any; var root_98 any = A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = seq_1242000017__8; if linked_99 == nil { c__1927000678__auto____9 = ifn_100.Invoke_O__O(arg_101) } else { c__1927000678__auto____9 = linked_99.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_98, arg_101) }; var tmp4 any; var root_111 any = A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = seq_1242000017__8; if linked_112 == nil { tmp4 = ifn_113.Invoke_O__O(arg_114) } else { tmp4 = linked_112.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_111, arg_114) }; seq_1242000017__3, chunk_1242000018__4, count_1242000019__5, i_1242000020__6 = tmp4, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var cp__9 any; var root_102 any = A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = seq_1242000017__8; if linked_103 == nil { cp__9 = ifn_104.Invoke_O__O(arg_105) } else { cp__9 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }
				var tmp5 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp6 any; var root_115 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = cp__9; var arg_119 any = A_arbace_repr_go_print_text_A_const_36; if linked_116 == nil { tmp6 = ifn_117.Invoke_O_O__O(arg_118, arg_119) } else { tmp6 = linked_116.(*A_arbace_repr_go_print_text_escape_cp_A).Invoke_O_O_O__O(root_115, arg_118, arg_119) }; jrt.NN(tmp5).Append_String__StringBuilder(jrt.String_Cast(tmp6))
//line :74:1
				var tmp7 any; var root_120 any = A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = seq_1242000017__8; if linked_121 == nil { tmp7 = ifn_122.Invoke_O__O(arg_123) } else { tmp7 = linked_121.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_120, arg_123) }; seq_1242000017__3, chunk_1242000018__4, count_1242000019__5, i_1242000020__6 = tmp7, nil, 0, 0; continue L1 } } }
//line :70:1
		break L1 };





	jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_23); return /*line :77:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_repr_go_print_text_raw_string_ok_QMARK__A_New() *A_arbace_repr_go_print_text_raw_string_ok_QMARK__A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_raw_string_ok_QMARK__A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_repr_go_print_text_raw_string_ok_QMARK__A) Ctor() {}
//line :79:1
func (t *A_arbace_repr_go_print_text_raw_string_ok_QMARK__A) Invoke_O_O__O(self, s__0 any) any {



	var root_153 any = A_arbace_repr_go_print_text_A_const_39.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any; var tmp1 any = A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_New(); var tmp2 *jrt.Class; var fncls__148 *jrt.Class = A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_fn_class = fncls__148d; tmp2 = fncls__148d } else { tmp2 = fncls__148 }; arg_156 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_157 any; var root_149 any = A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_repr_go_print_text_code_points_A_fn_class); var ifn_151 lang.IFn

	if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = s__0; if linked_150 == nil { arg_157 = ifn_151.Invoke_O__O(arg_152) } else { arg_157 = linked_150.(*A_arbace_repr_go_print_text_code_points_A).Invoke_O_O__O(root_149, arg_152) }
//line :83:1
	if linked_154 == nil { return ifn_155.Invoke_O_O__O(arg_156, arg_157) } else { return linked_154.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_153, arg_156, arg_157) } }
//line :83:1
func A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_New() *A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A) Ctor() {}
//line :83:1
func (t *A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A) Invoke_O_O__O(self, cp__1 any) any { var and__1927000168__auto____2 any; var root_124 any = A_arbace_repr_go_print_text_A_const_40.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = cp__1; var arg_128 any = A_arbace_repr_go_print_text_A_const_41; if linked_125 == nil { and__1927000168__auto____2 = ifn_126.Invoke_O_O__O(arg_127, arg_128) } else { and__1927000168__auto____2 = linked_125.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_124, arg_127, arg_128) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_129 any = A_arbace_repr_go_print_text_A_const_40.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = cp__1; var arg_133 any = A_arbace_repr_go_print_text_A_const_42; if linked_130 == nil { and__1927000168__auto____3 = ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { and__1927000168__auto____3 = linked_130.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_129, arg_132, arg_133) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool; var na_134 any = cp__1; var na_135 int64 = 9
														if jrt.Long_InstanceOf(na_134) { var n0_136 int64 = jrt.NN(jrt.Long_Cast(na_134)).LongValue__J(); var n1_137 int64 = na_135; or__1927000174__auto____4 = n0_136 == n1_137 } else { or__1927000174__auto____4 = lang.Numbers_Equiv_O_J__Z_NoInit(na_134, na_135) }; if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool; var na_139 any = cp__1; var na_140 int64 = 10; if jrt.Long_InstanceOf(na_139) { var n0_141 int64 = jrt.NN(jrt.Long_Cast(na_139)).LongValue__J(); var n1_142 int64 = na_140; or__1927000174__auto____5 = n0_141 == n1_142 } else { or__1927000174__auto____5 = lang.Numbers_Equiv_O_J__Z_NoInit(na_139, na_140) }; if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var root_144 any = A_arbace_repr_go_print_text_A_const_18.GetRawRoot__O(); var linked_145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_144, A_arbace_repr_go_print_text_go_printable_QMARK__A_fn_class); var ifn_146 lang.IFn; if linked_145 == nil { ifn_146 = lang.IFn_Cast(root_144) } else { ifn_146 = nil }; var arg_147 any = cp__1; if linked_145 == nil { return ifn_146.Invoke_O__O(arg_147) } else { return linked_145.(*A_arbace_repr_go_print_text_go_printable_QMARK__A).Invoke_O_O__O(root_144, arg_147) } } } } else {
//line :83:1
		return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_repr_go_print_text_go_byte_string_A_New() *A_arbace_repr_go_print_text_go_byte_string_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_byte_string_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_repr_go_print_text_go_byte_string_A) Ctor() {}
//line :87:1
func (t *A_arbace_repr_go_print_text_go_byte_string_A) Invoke_O_O__O(self, parts__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_23); var seq_1242000025__3 any; var root_158 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_160 lang.IFn; if




	linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = parts__0; if linked_159 == nil { seq_1242000025__3 = ifn_160.Invoke_O__O(arg_161) } else { seq_1242000025__3 = linked_159.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_158, arg_161) }; var chunk_1242000026__4 any; var count_1242000027__5 int64 = 0; var i_1242000028__6 int64 = 0; L1:
//line :87:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000028__6, count_1242000027__5) { var p__7 any = lang.Indexed_Cast(chunk_1242000026__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000028__6)); var tmp1 any; var root_178 any = A_arbace_repr_go_print_text_A_const_43.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_180 lang.IFn

			if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = p__7; if linked_179 == nil { tmp1 = ifn_180.Invoke_O__O(arg_181) } else { tmp1 = linked_179.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_178, arg_181) }
//line :93:1
			if jrt.J2g_Truth(tmp1) { var seq_1242000029__8 any; var root_186 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_188 lang.IFn
				if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any; var root_182 any = A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, A_arbace_repr_go_print_text_code_points_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = p__7; if linked_183 == nil { arg_189 = ifn_184.Invoke_O__O(arg_185) } else { arg_189 = linked_183.(*A_arbace_repr_go_print_text_code_points_A).Invoke_O_O__O(root_182, arg_185) }; if linked_187 == nil { seq_1242000029__8 = ifn_188.Invoke_O__O(arg_189) } else { seq_1242000029__8 = linked_187.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_186, arg_189) }
//line :93:1
				var chunk_1242000030__9 any; var count_1242000031__10 int64 = 0; var i_1242000032__11 int64 = 0; L2: for {
					if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000032__11, count_1242000031__10) { var cp__12 any = lang.Indexed_Cast(chunk_1242000030__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000032__11)); var tmp2 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp3 any; var root_230 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = cp__12; var arg_234 any = A_arbace_repr_go_print_text_A_const_36; if linked_231 == nil { tmp3 = ifn_232.Invoke_O_O__O(arg_233, arg_234) } else { tmp3 = linked_231.(*A_arbace_repr_go_print_text_escape_cp_A).Invoke_O_O_O__O(root_230, arg_233, arg_234) }; jrt.NN(tmp2).Append_String__StringBuilder(jrt.String_Cast(tmp3)); seq_1242000029__8, chunk_1242000030__9, count_1242000031__10, i_1242000032__11 = seq_1242000029__8, chunk_1242000030__9, count_1242000031__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000032__11); continue L2 } else { var temp__1927000414__auto____12 any; var root_190 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = seq_1242000029__8; if linked_191 == nil { temp__1927000414__auto____12 = ifn_192.Invoke_O__O(arg_193) } else { temp__1927000414__auto____12 = linked_191.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_190, arg_193) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1242000029__13 any = temp__1927000414__auto____12; var tmp4 any; var root_194 any = A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = seq_1242000029__13; if linked_195 == nil { tmp4 = ifn_196.Invoke_O__O(arg_197) } else { tmp4 = linked_195.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_194, arg_197) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____14 any; var root_198 any = A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = seq_1242000029__13; if linked_199 == nil { c__1927000678__auto____14 = ifn_200.Invoke_O__O(arg_201) } else { c__1927000678__auto____14 = linked_199.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_198, arg_201) }; var tmp5 any; var root_235 any = A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = seq_1242000029__13; if linked_236 == nil { tmp5 = ifn_237.Invoke_O__O(arg_238) } else { tmp5 = linked_236.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_235, arg_238) }; seq_1242000029__8, chunk_1242000030__9, count_1242000031__10, i_1242000032__11 = tmp5, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var cp__14 any; var root_202 any = A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = seq_1242000029__13; if linked_203 == nil { cp__14 = ifn_204.Invoke_O__O(arg_205) } else { cp__14 = linked_203.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_202, arg_205) }; var tmp6 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp7 any; var root_239 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = cp__14; var arg_243 any = A_arbace_repr_go_print_text_A_const_36; if linked_240 == nil { tmp7 = ifn_241.Invoke_O_O__O(arg_242, arg_243) } else { tmp7 = linked_240.(*A_arbace_repr_go_print_text_escape_cp_A).Invoke_O_O_O__O(root_239, arg_242, arg_243) }; jrt.NN(tmp6).Append_String__StringBuilder(jrt.String_Cast(tmp7)); var tmp8 any; var root_244 any = A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = seq_1242000029__13; if linked_245 == nil { tmp8 = ifn_246.Invoke_O__O(arg_247) } else { tmp8 = linked_245.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_244, arg_247) }; seq_1242000029__8, chunk_1242000030__9, count_1242000031__10, i_1242000032__11 = tmp8, nil, 0, 0; continue L2 } } }
//line :93:1
					break L2 } } else { var tmp9 any; var and__1927000168__auto____8 any; var root_206 any = A_arbace_repr_go_print_text_A_const_44.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_208 lang.IFn

						if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = p__7; if linked_207 == nil { and__1927000168__auto____8 = ifn_208.Invoke_O__O(arg_209) } else { and__1927000168__auto____8 = linked_207.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_206, arg_209) }; if jrt.J2g_Truth(and__1927000168__auto____8) { tmp9 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_45.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_text_A_const_46, p__7, A_arbace_repr_go_print_text_A_const_47) } else { tmp9 = and__1927000168__auto____8 }
//line :93:1
						if jrt.J2g_Truth(tmp9) {

							var tmp10 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil); var tmp12 any; var root_216 any = A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, A_arbace_repr_go_print_text_hex_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__7)).Ref(); var arg_220 any = A_arbace_repr_go_print_text_A_const_20; if linked_217 == nil { tmp12 = ifn_218.Invoke_O_O__O(arg_219, arg_220) } else { tmp12 = linked_217.(*A_arbace_repr_go_print_text_hex_A).Invoke_O_O_O__O(root_216, arg_219, arg_220) }; jrt.NN(tmp10).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12))) } else {
//line :93:1
								if A_arbace_repr_go_print_text_A_const_22 != nil { var tmp13 any; var root_225 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_227 lang.IFn


									if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(p__7))).Ref(); var arg_229 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_48, p__7)); if linked_226 == nil { tmp13 = ifn_227.Invoke_O_O__O(arg_228, arg_229) } else { tmp13 = linked_226.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_225, arg_228, arg_229) }
//line :93:1
									panic(jrt.Thrown(jrt.Throwable_Cast(tmp13))) } } }
//line :92:1
			seq_1242000025__3, chunk_1242000026__4, count_1242000027__5, i_1242000028__6 = seq_1242000025__3, chunk_1242000026__4, count_1242000027__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000028__6); continue L1 } else { var temp__1927000414__auto____7 any; var root_162 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = seq_1242000025__3; if linked_163 == nil { temp__1927000414__auto____7 = ifn_164.Invoke_O__O(arg_165) } else { temp__1927000414__auto____7 = linked_163.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_162, arg_165) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1242000025__8 any = temp__1927000414__auto____7; var tmp14 any; var root_166 any = A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = seq_1242000025__8; if linked_167 == nil { tmp14 = ifn_168.Invoke_O__O(arg_169) } else { tmp14 = linked_167.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_166, arg_169) }; if jrt.J2g_Truth(tmp14) { var c__1927000678__auto____9 any; var root_170 any = A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = seq_1242000025__8; if linked_171 == nil { c__1927000678__auto____9 = ifn_172.Invoke_O__O(arg_173) } else { c__1927000678__auto____9 = linked_171.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_170, arg_173) }; var tmp15 any; var root_248 any = A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_250 lang.IFn; if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any = seq_1242000025__8; if linked_249 == nil { tmp15 = ifn_250.Invoke_O__O(arg_251) } else { tmp15 = linked_249.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_248, arg_251) }; seq_1242000025__3, chunk_1242000026__4, count_1242000027__5, i_1242000028__6 = tmp15, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__9 any; var root_174 any = A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = seq_1242000025__8; if linked_175 == nil { p__9 = ifn_176.Invoke_O__O(arg_177) } else { p__9 = linked_175.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_174, arg_177) }
				var tmp16 any; var root_252 any = A_arbace_repr_go_print_text_A_const_43.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_254 lang.IFn
				if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = p__9; if linked_253 == nil { tmp16 = ifn_254.Invoke_O__O(arg_255) } else { tmp16 = linked_253.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_252, arg_255) }
//line :93:1
				if jrt.J2g_Truth(tmp16) { var seq_1242000033__10 any; var root_260 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_262 lang.IFn
					if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any; var root_256 any = A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, A_arbace_repr_go_print_text_code_points_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = p__9; if linked_257 == nil { arg_263 = ifn_258.Invoke_O__O(arg_259) } else { arg_263 = linked_257.(*A_arbace_repr_go_print_text_code_points_A).Invoke_O_O__O(root_256, arg_259) }; if linked_261 == nil { seq_1242000033__10 = ifn_262.Invoke_O__O(arg_263) } else { seq_1242000033__10 = linked_261.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_260, arg_263) }
//line :93:1
					var chunk_1242000034__11 any; var count_1242000035__12 int64 = 0; var i_1242000036__13 int64 = 0; L3: for {
						if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000036__13, count_1242000035__12) { var cp__14_2 any = lang.Indexed_Cast(chunk_1242000034__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000036__13)); var tmp17 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp18 any; var root_304 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = cp__14_2; var arg_308 any = A_arbace_repr_go_print_text_A_const_36; if linked_305 == nil { tmp18 = ifn_306.Invoke_O_O__O(arg_307, arg_308) } else { tmp18 = linked_305.(*A_arbace_repr_go_print_text_escape_cp_A).Invoke_O_O_O__O(root_304, arg_307, arg_308) }; jrt.NN(tmp17).Append_String__StringBuilder(jrt.String_Cast(tmp18)); seq_1242000033__10, chunk_1242000034__11, count_1242000035__12, i_1242000036__13 = seq_1242000033__10, chunk_1242000034__11, count_1242000035__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000036__13); continue L3 } else { var temp__1927000414__auto____14 any; var root_264 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_266 lang.IFn; if linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any = seq_1242000033__10; if linked_265 == nil { temp__1927000414__auto____14 = ifn_266.Invoke_O__O(arg_267) } else { temp__1927000414__auto____14 = linked_265.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_264, arg_267) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1242000033__15 any = temp__1927000414__auto____14; var tmp19 any; var root_268 any = A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = seq_1242000033__15; if linked_269 == nil { tmp19 = ifn_270.Invoke_O__O(arg_271) } else { tmp19 = linked_269.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_268, arg_271) }; if jrt.J2g_Truth(tmp19) { var c__1927000678__auto____16 any; var root_272 any = A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = seq_1242000033__15; if linked_273 == nil { c__1927000678__auto____16 = ifn_274.Invoke_O__O(arg_275) } else { c__1927000678__auto____16 = linked_273.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_272, arg_275) }; var tmp20 any; var root_309 any = A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = seq_1242000033__15; if linked_310 == nil { tmp20 = ifn_311.Invoke_O__O(arg_312) } else { tmp20 = linked_310.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_309, arg_312) }; seq_1242000033__10, chunk_1242000034__11, count_1242000035__12, i_1242000036__13 = tmp20, c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var cp__16 any; var root_276 any = A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O(); var linked_277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_276, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_278 lang.IFn; if linked_277 == nil { ifn_278 = lang.IFn_Cast(root_276) } else { ifn_278 = nil }; var arg_279 any = seq_1242000033__15; if linked_277 == nil { cp__16 = ifn_278.Invoke_O__O(arg_279) } else { cp__16 = linked_277.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_276, arg_279) }; var tmp21 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp22 any; var root_313 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = cp__16; var arg_317 any = A_arbace_repr_go_print_text_A_const_36; if linked_314 == nil { tmp22 = ifn_315.Invoke_O_O__O(arg_316, arg_317) } else { tmp22 = linked_314.(*A_arbace_repr_go_print_text_escape_cp_A).Invoke_O_O_O__O(root_313, arg_316, arg_317) }; jrt.NN(tmp21).Append_String__StringBuilder(jrt.String_Cast(tmp22)); var tmp23 any; var root_318 any = A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = seq_1242000033__15; if linked_319 == nil { tmp23 = ifn_320.Invoke_O__O(arg_321) } else { tmp23 = linked_319.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_318, arg_321) }; seq_1242000033__10, chunk_1242000034__11, count_1242000035__12, i_1242000036__13 = tmp23, nil, 0, 0; continue L3 } } }
//line :93:1
						break L3 } } else { var tmp24 any; var and__1927000168__auto____10 any; var root_280 any = A_arbace_repr_go_print_text_A_const_44.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_282 lang.IFn

							if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = p__9; if linked_281 == nil { and__1927000168__auto____10 = ifn_282.Invoke_O__O(arg_283) } else { and__1927000168__auto____10 = linked_281.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_280, arg_283) }; if jrt.J2g_Truth(and__1927000168__auto____10) { tmp24 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_45.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_text_A_const_46, p__9, A_arbace_repr_go_print_text_A_const_47) } else { tmp24 = and__1927000168__auto____10 }
//line :93:1
							if jrt.J2g_Truth(tmp24) {

								var tmp25 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__2); var tmp26 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_13, nil); var tmp27 any; var root_290 any = A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, A_arbace_repr_go_print_text_hex_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__9)).Ref(); var arg_294 any = A_arbace_repr_go_print_text_A_const_20; if linked_291 == nil { tmp27 = ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { tmp27 = linked_291.(*A_arbace_repr_go_print_text_hex_A).Invoke_O_O_O__O(root_290, arg_293, arg_294) }; jrt.NN(tmp25).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp27))) } else {
//line :93:1
									if A_arbace_repr_go_print_text_A_const_22 != nil { var tmp28 any; var root_299 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_301 lang.IFn


										if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(p__9))).Ref(); var arg_303 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_48, p__9)); if linked_300 == nil { tmp28 = ifn_301.Invoke_O_O__O(arg_302, arg_303) } else { tmp28 = linked_300.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_299, arg_302, arg_303) }
//line :93:1
										panic(jrt.Thrown(jrt.Throwable_Cast(tmp28))) } } }
//line :92:1
				var tmp29 any; var root_322 any = A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = seq_1242000025__8; if linked_323 == nil { tmp29 = ifn_324.Invoke_O__O(arg_325) } else { tmp29 = linked_323.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_322, arg_325) }; seq_1242000025__3, chunk_1242000026__4, count_1242000027__5, i_1242000028__6 = tmp29, nil, 0, 0; continue L1 } } }
//line :87:1
		break L1 };









	jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_23); return /*line :98:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_repr_go_print_text_go_rune_A_New() *A_arbace_repr_go_print_text_go_rune_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_rune_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_repr_go_print_text_go_rune_A) Ctor() {}
//line :100:1
func (t *A_arbace_repr_go_print_text_go_rune_A) Invoke_O_O__O(self, p_cp__0 any) any { var cp__0 int64 = lang.RT_LongCast_O__J_NoInit(p_cp__0); var tmp1 bool; var or__1927000174__auto____2 bool = lang.Numbers_IsNeg_J__Z_NoInit(cp__0); if or__1927000174__auto____2 {


	tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = lang.Numbers_Gt_J_J__Z_NoInit(cp__0, 1114111); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var and__1927000168__auto____4 bool = lang.Numbers_Gte_J_J__Z_NoInit(cp__0, 55296); if and__1927000168__auto____4 { tmp1 = lang.Numbers_Lte_J_J__Z_NoInit(cp__0, 57343) } else { tmp1 = and__1927000168__auto____4 } } }; if tmp1 { var tmp2 any; var root_331 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_333 lang.IFn
		if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref())).Ref(); var tmp3 any = A_arbace_repr_go_print_text_A_const_50; var arg_335 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref())); if linked_332 == nil { tmp2 = ifn_333.Invoke_O_O__O(arg_334, arg_335) } else { tmp2 = linked_332.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_331, arg_334, arg_335) }
//line :103:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp2))) }; var tmp4 /*line :105:1*/*jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_32, nil, Lit_32); var tmp5 any; var root_326 any = A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, A_arbace_repr_go_print_text_escape_cp_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref(); var arg_330 any = A_arbace_repr_go_print_text_A_const_49; if linked_327 == nil { tmp5 = ifn_328.Invoke_O_O__O(arg_329, arg_330) } else { tmp5 = linked_327.(*A_arbace_repr_go_print_text_escape_cp_A).Invoke_O_O_O__O(root_326, arg_329, arg_330) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, tmp5, nil)).Ref() }

func A_arbace_repr_go_print_text_float_kind_A_New() *A_arbace_repr_go_print_text_float_kind_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_float_kind_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_repr_go_print_text_float_kind_A) Ctor() {}
//line :107:1
func (t *A_arbace_repr_go_print_text_float_kind_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any; var root_336 any = A_arbace_repr_go_print_text_A_const_51.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_336, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any = s__0; var arg_340 any = Lit_18; if linked_337 == nil { or__1927000174__auto____2 = ifn_338.Invoke_O_O__O(arg_339, arg_340) } else { or__1927000174__auto____2 = linked_337.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_336, arg_339, arg_340) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any; var root_341 any = A_arbace_repr_go_print_text_A_const_51.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = s__0; var arg_345 any = Lit_19; if linked_342 == nil { or__1927000174__auto____3 = ifn_343.Invoke_O_O__O(arg_344, arg_345) } else { or__1927000174__auto____3 = linked_342.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_341, arg_344, arg_345) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { var root_346 any = A_arbace_repr_go_print_text_A_const_51.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = s__0; var arg_350 any = Lit_20; if linked_347 == nil { tmp1 = ifn_348.Invoke_O_O__O(arg_349, arg_350) } else { tmp1 = linked_347.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_346, arg_349, arg_350) } } }; if jrt.J2g_Truth(tmp1) { return s__0 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_21), jrt.RefArrayOf(jrt.Object_class, s__0, nil)).Ref()
	} }
func A_arbace_repr_go_print_text_pow2_exponent_A_New() *A_arbace_repr_go_print_text_pow2_exponent_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_pow2_exponent_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_repr_go_print_text_pow2_exponent_A) Ctor() {}
//line :113:1
func (t *A_arbace_repr_go_print_text_pow2_exponent_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 bool; var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(n__0)).Signum__I())); if and__1927000168__auto____2 { tmp1 = lang.Numbers_Equiv_J_J__Z_NoInit(1, int64(jrt.NN(jrt.BigInteger_Cast(n__0)).BitCount__I())) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(n__0)).BitLength__I()))).Ref() } else { return nil
	} }
func A_arbace_repr_go_print_text_strip_2_5_A_New() *A_arbace_repr_go_print_text_strip_2_5_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_strip_2_5_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_repr_go_print_text_strip_2_5_A) Ctor() {}
//line :118:1
func (t *A_arbace_repr_go_print_text_strip_2_5_A) Invoke_O_O__O(self, n__0 any) any { { var five__2 any = jrt.BigInteger_ValueOf_J__BigInteger(5).Ref(); var n__3 any = n__0; var a__4 int64 = 0; var b__5 int64 = 0; L1: for {




	var tmp1 any; var root_351 any = A_arbace_repr_go_print_text_A_const_52.GetRawRoot__O(); var linked_352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_351, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_353 lang.IFn
	if linked_352 == nil { ifn_353 = lang.IFn_Cast(root_351) } else { ifn_353 = nil }; var arg_354 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.BigInteger_Cast(n__3)).TestBit_I__Z(lang.RT_IntCast_J__I_NoInit(0))).Ref(); if linked_352 == nil { tmp1 = ifn_353.Invoke_O__O(arg_354) } else { tmp1 = linked_352.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_351, arg_354) }
//line :123:1
	if jrt.J2g_Truth(tmp1) {
		n__3, a__4, b__5 = jrt.NN(jrt.BigInteger_Cast(n__3)).ShiftRight_I__BigInteger(lang.RT_IntCast_J__I_NoInit(1)).Ref(), lang.Numbers_Inc_J__J_NoInit(a__4), b__5; continue L1 } else {
//line :123:1
			if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(n__3)).Mod_BigInteger__BigInteger(jrt.BigInteger_Cast(five__2))).Signum__I())) {

				n__3, a__4, b__5 = jrt.NN(jrt.BigInteger_Cast(n__3)).Divide_BigInteger__BigInteger(jrt.BigInteger_Cast(five__2)).Ref(), a__4, lang.Numbers_Inc_J__J_NoInit(b__5); continue L1 } else {
//line :123:1
					if A_arbace_repr_go_print_text_A_const_22 != nil { return lang.Tuple_Create_O_O_O__IPersistentVector(n__3, jrt.Long_ValueOf_J__Long_NoInit(a__4).Ref(), jrt.Long_ValueOf_J__Long_NoInit(b__5).Ref()) } else { return nil } } } } }; /*line :118:1*/panic("j2g: unreachable") }









func A_arbace_repr_go_print_text_go_float_A_New() *A_arbace_repr_go_print_text_go_float_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_float_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_repr_go_print_text_go_float_A) Ctor() {}
//line :128:1
func (t *A_arbace_repr_go_print_text_go_float_A) Invoke_O_O__O(self, x__0 any) any {




	if jrt.Double_InstanceOf(x__0) { var d__2 float64 = lang.RT_DoubleCast_O__D_NoInit(x__0); var tmp1 bool; var or__1927000174__auto____3 bool = jrt.Double_IsNaN_D__Z_NoInit(d__2)


		if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = jrt.Double_IsInfinite_D__Z_NoInit(d__2) }; if tmp1 { var tmp2 any; var root_422 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_424 lang.IFn
			if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Double_ValueOf_D__Double_NoInit(d__2).Ref())).Ref(); var tmp3 any = A_arbace_repr_go_print_text_A_const_61; var arg_426 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, jrt.Double_ValueOf_D__Double_NoInit(d__2).Ref())); if linked_423 == nil { tmp2 = ifn_424.Invoke_O_O__O(arg_425, arg_426) } else { tmp2 = linked_423.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_422, arg_425, arg_426) }
//line :136:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp2)))
		}
		var root_355 any = A_arbace_repr_go_print_text_A_const_53.GetRawRoot__O(); var linked_356 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_355, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_357 lang.IFn; if linked_356 == nil { ifn_357 = lang.IFn_Cast(root_355) } else { ifn_357 = nil }; var arg_358 any = jrt.Double_ToString_D__String_NoInit(d__2).Ref(); if linked_356 == nil { return ifn_357.Invoke_O__O(arg_358) } else { return linked_356.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_355, arg_358) } } else {
//line :133:1
			if jrt.BigDecimal_InstanceOf(x__0) {





				var root_363 any = A_arbace_repr_go_print_text_A_const_54.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, A_arbace_repr_go_print_text_float_kind_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any; var root_359 any = A_arbace_repr_go_print_text_A_const_53.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_string.A_arbace_string_lower_case_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = jrt.NN(jrt.BigDecimal_Cast(x__0)).ToString__String().Ref(); if linked_360 == nil { arg_366 = ifn_361.Invoke_O__O(arg_362) } else { arg_366 = linked_360.(*aot_arbace_string.A_arbace_string_lower_case_A).Invoke_O_O__O(root_359, arg_362) }; if linked_364 == nil { return ifn_365.Invoke_O__O(arg_366) } else { return linked_364.(*A_arbace_repr_go_print_text_float_kind_A).Invoke_O_O__O(root_363, arg_366) } } else {
//line :133:1
					var tmp4 any; var root_367 any = A_arbace_repr_go_print_text_A_const_55.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_ratio_QMARK__A_fn_class); var ifn_369 lang.IFn






					if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = x__0; if linked_368 == nil { tmp4 = ifn_369.Invoke_O__O(arg_370) } else { tmp4 = linked_368.(*aot_arbace_core.A_arbace_core_ratio_QMARK__A).Invoke_O_O__O(root_367, arg_370) }
//line :133:1
					if jrt.J2g_Truth(tmp4) { var n__2 any; var root_375 any = A_arbace_repr_go_print_text_A_const_56.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_377 lang.IFn







						if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any; var root_371 any = A_arbace_repr_go_print_text_A_const_57.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_numerator_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = x__0; if linked_372 == nil { arg_378 = ifn_373.Invoke_O__O(arg_374) } else { arg_378 = linked_372.(*aot_arbace_core.A_arbace_core_numerator_A).Invoke_O_O__O(root_371, arg_374) }; if linked_376 == nil { n__2 = ifn_377.Invoke_O__O(arg_378) } else { n__2 = linked_376.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_375, arg_378) }
//line :133:1
						var d__3 any; var root_383 any = A_arbace_repr_go_print_text_A_const_56.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_biginteger_A_fn_class); var ifn_385 lang.IFn







						if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any; var root_379 any = A_arbace_repr_go_print_text_A_const_58.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_denominator_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = x__0; if linked_380 == nil { arg_386 = ifn_381.Invoke_O__O(arg_382) } else { arg_386 = linked_380.(*aot_arbace_core.A_arbace_core_denominator_A).Invoke_O_O__O(root_379, arg_382) }; if linked_384 == nil { d__3 = ifn_385.Invoke_O__O(arg_386) } else { d__3 = linked_384.(*aot_arbace_core.A_arbace_core_biginteger_A).Invoke_O_O__O(root_383, arg_386) }
//line :133:1
						var vec__1242000042__4 any; var root_387 any = A_arbace_repr_go_print_text_A_const_59.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, A_arbace_repr_go_print_text_strip_2_5_A_fn_class); var ifn_389 lang.IFn








						if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = d__3; if linked_388 == nil { vec__1242000042__4 = ifn_389.Invoke_O__O(arg_390) } else { vec__1242000042__4 = linked_388.(*A_arbace_repr_go_print_text_strip_2_5_A).Invoke_O_O__O(root_387, arg_390) }
//line :133:1
						var rest__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000042__4, lang.RT_IntCast_J__I_NoInit(0), nil); var a__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000042__4, lang.RT_IntCast_J__I_NoInit(1), nil); var b__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000042__4, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp5 bool; var and__1927000168__auto____8 bool; var tmp6 *jrt.BigInteger










						jrt.BigInteger_Init(); tmp6 = jrt.BigInteger_ONE; and__1927000168__auto____8 = lang.Util_Equiv_O_O__Z_NoInit(rest__5, tmp6.Ref()); if and__1927000168__auto____8 { var na_391 any = lang.Numbers_Max_O_O__O_NoInit(a__6, b__7); var na_392 int64 = 40; if jrt.Long_InstanceOf(na_391) { var n0_393 int64 = jrt.NN(jrt.Long_Cast(na_391)).LongValue__J(); var n1_394 int64 = na_392; tmp5 = n0_393 <= n1_394 } else { tmp5 = lang.Numbers_Lte_O_J__Z_NoInit(na_391, na_392) } } else { tmp5 = and__1927000168__auto____8 }
//line :143:1
						if tmp5 {

							var root_396 any = A_arbace_repr_go_print_text_A_const_54.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, A_arbace_repr_go_print_text_float_kind_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = jrt.NN(jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(n__2)).Divide_BigDecimal__BigDecimal(jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(d__3)))).ToPlainString__String().Ref(); if linked_397 == nil { return ifn_398.Invoke_O__O(arg_399) } else { return linked_397.(*A_arbace_repr_go_print_text_float_kind_A).Invoke_O_O__O(root_396, arg_399) } } else {
//line :143:1
								var tmp7 any; var root_400 any = A_arbace_repr_go_print_text_A_const_60.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, A_arbace_repr_go_print_text_pow2_exponent_A_fn_class); var ifn_402 lang.IFn


								if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = d__3; if linked_401 == nil { tmp7 = ifn_402.Invoke_O__O(arg_403) } else { tmp7 = linked_401.(*A_arbace_repr_go_print_text_pow2_exponent_A).Invoke_O_O__O(root_400, arg_403) }
//line :143:1
								if jrt.J2g_Truth(tmp7) {



									var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27, nil); var tmp9 any = jrt.NN(jrt.BigInteger_Cast(n__2)).ToString_I__String(lang.RT_IntCast_J__I_NoInit(16)).Ref(); var tmp10 any; var root_404 any = A_arbace_repr_go_print_text_A_const_60.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, A_arbace_repr_go_print_text_pow2_exponent_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = d__3; if linked_405 == nil { tmp10 = ifn_406.Invoke_O__O(arg_407) } else { tmp10 = linked_405.(*A_arbace_repr_go_print_text_pow2_exponent_A).Invoke_O_O__O(root_404, arg_407) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, nil, tmp10)).Ref() } else {
//line :143:1
										if A_arbace_repr_go_print_text_A_const_22 != nil { var tmp11 any; var root_408 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_410 lang.IFn




											if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, x__0, nil)).Ref(); var arg_412 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_61, x__0)); if linked_409 == nil { tmp11 = ifn_410.Invoke_O_O__O(arg_411, arg_412) } else { tmp11 = linked_409.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_408, arg_411, arg_412) }
//line :143:1
											panic(jrt.Thrown(jrt.Throwable_Cast(tmp11))) } else { return nil } } } } else {
//line :133:1
												if A_arbace_repr_go_print_text_A_const_22 != nil { var tmp12 any; var root_417 any = A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_419 lang.IFn















													if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_30, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(x__0))).Ref(); var arg_421 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_61, x__0)); if linked_418 == nil { tmp12 = ifn_419.Invoke_O_O__O(arg_420, arg_421) } else { tmp12 = linked_418.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_417, arg_420, arg_421) }
//line :133:1
													panic(jrt.Thrown(jrt.Throwable_Cast(tmp12))) } else { return nil
													}
											}
				}
		}
}












func A_arbace_repr_go_print_text_negative_number_QMARK__A_New() *A_arbace_repr_go_print_text_negative_number_QMARK__A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_negative_number_QMARK__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_repr_go_print_text_negative_number_QMARK__A) Ctor() {}
//line :151:1
func (t *A_arbace_repr_go_print_text_negative_number_QMARK__A) Invoke_O_O__O(self, x__0 any) any {



	if jrt.Double_InstanceOf(x__0) { var or__1927000174__auto____2 bool = lang.Numbers_IsNeg_D__Z_NoInit(lang.RT_DoubleCast_O__D_NoInit(x__0))
		if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(jrt.Double_DoubleToRawLongBits_D__J_NoInit(lang.RT_DoubleCast_O__D_NoInit(x__0)), -9223372036854775808)).Ref() } } else {
//line :155:1
			var tmp1 any; var root_427 any = A_arbace_repr_go_print_text_A_const_62.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_number_QMARK__A_fn_class); var ifn_429 lang.IFn


			if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = x__0; if linked_428 == nil { tmp1 = ifn_429.Invoke_O__O(arg_430) } else { tmp1 = linked_428.(*aot_arbace_core.A_arbace_core_number_QMARK__A).Invoke_O_O__O(root_427, arg_430) }
//line :155:1
			if jrt.J2g_Truth(tmp1) {


				var tmp2 bool; var na_431 any = x__0; if jrt.Long_InstanceOf(na_431) { var n0_432 int64 = jrt.NN(jrt.Long_Cast(na_431)).LongValue__J(); tmp2 = n0_432 < 0 } else { if jrt.Double_InstanceOf(na_431) { var n0_432_2 float64 = jrt.NN(jrt.Double_Cast(na_431)).DoubleValue__D(); tmp2 = n0_432_2 < 0.0 } else { tmp2 = lang.Numbers_IsNeg_O__Z_NoInit(na_431) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } else {
//line :155:1
					if A_arbace_repr_go_print_text_A_const_22 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
					}
				}
		}
}

func A_arbace_repr_go_print_text_go_number_A_New() *A_arbace_repr_go_print_text_go_number_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_number_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_repr_go_print_text_go_number_A) Ctor() {}
//line :161:1
func (t *A_arbace_repr_go_print_text_go_number_A) Invoke_O_O__O(self, x__0 any) any {



	if jrt.Double_InstanceOf(x__0) {
		var root_433 any = A_arbace_repr_go_print_text_A_const_63.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, A_arbace_repr_go_print_text_go_float_A_fn_class); var ifn_435 lang.IFn; if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Abs_D__D(lang.RT_DoubleCast_O__D_NoInit(x__0))).Ref(); if linked_434 == nil { return ifn_435.Invoke_O__O(arg_436) } else { return linked_434.(*A_arbace_repr_go_print_text_go_float_A).Invoke_O_O__O(root_433, arg_436) } } else {
//line :165:1
			var tmp1 any; var root_437 any = A_arbace_repr_go_print_text_A_const_44.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_integer_QMARK__A_fn_class); var ifn_439 lang.IFn

			if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = x__0; if linked_438 == nil { tmp1 = ifn_439.Invoke_O__O(arg_440) } else { tmp1 = linked_438.(*aot_arbace_core.A_arbace_core_integer_QMARK__A).Invoke_O_O__O(root_437, arg_440) }
//line :165:1
			if jrt.J2g_Truth(tmp1) {

				var root_441 any = A_arbace_repr_go_print_text_A_const_15.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = x__0; if linked_442 == nil { return ifn_443.Invoke_O__O(arg_444) } else { return linked_442.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_441, arg_444) } } else {
//line :165:1
					if A_arbace_repr_go_print_text_A_const_22 != nil {


						var root_445 any = A_arbace_repr_go_print_text_A_const_63.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, A_arbace_repr_go_print_text_go_float_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = x__0; if linked_446 == nil { return ifn_447.Invoke_O__O(arg_448) } else { return linked_446.(*A_arbace_repr_go_print_text_go_float_A).Invoke_O_O__O(root_445, arg_448) } } else {
//line :165:1
							return nil
						}
				}
		}
}



func A_arbace_repr_go_print_text_escape_A_New() *A_arbace_repr_go_print_text_escape_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_escape_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_repr_go_print_text_escape_A) Ctor() {}
//line :173:1
func (t *A_arbace_repr_go_print_text_escape_A) Invoke_O_O__O(self, s__0 any) any {




	return jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.String_Cast(s__0)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_64)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_65)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_66)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_67)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_68)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_69)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_70)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_71)).CharValue__C()).Ref()
}
func A_arbace_repr_go_print_text_unescape_A_New() *A_arbace_repr_go_print_text_unescape_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_unescape_A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_repr_go_print_text_unescape_A) Ctor() {}
//line :180:1
func (t *A_arbace_repr_go_print_text_unescape_A) Invoke_O_O__O(self, s__0 any) any {



	return jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.String_Cast(s__0)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_72)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_64)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_73)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_66)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_74)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_68)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_75)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_70)).CharValue__C()).Ref()
}



func A_arbace_repr_go_print_text_cell_width_A_New() *A_arbace_repr_go_print_text_cell_width_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_cell_width_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_repr_go_print_text_cell_width_A) Ctor() {}
//line :189:1
func (t *A_arbace_repr_go_print_text_cell_width_A) Invoke_O_O__O(self, s__0 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.String_Cast(s__0)).CodePointCount_I_I__I(lang.RT_IntCast_J__I_NoInit(0), jrt.NN(jrt.String_Cast(s__0)).Length__I())).Ref() }



func A_arbace_repr_go_print_text_parse_lines_A_New() *A_arbace_repr_go_print_text_parse_lines_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_repr_go_print_text_parse_lines_A) Ctor() {}
//line :193:1
func (t *A_arbace_repr_go_print_text_parse_lines_A) Invoke_O_O__O(self, text__0 any) any {



	var root_590 any = A_arbace_repr_go_print_text_A_const_76.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any; var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_New(); var tmp2 *jrt.Class; var fncls__583 *jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_fn_class; if fncls__583 == nil { var fncls__583d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_fn_class = fncls__583d; tmp2 = fncls__583d } else { tmp2 = fncls__583 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 any; var root_584 any = A_arbace_repr_go_print_text_A_const_89.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = text__0; var arg_588 any = A_arbace_repr_go_print_text_A_const_90; var arg_589 any = A_arbace_repr_go_print_text_A_const_91; if linked_585 == nil { tmp4 = ifn_586.Invoke_O_O_O__O(arg_587, arg_588, arg_589) } else { tmp4 = linked_585.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_584, arg_587, arg_588, arg_589) }; arg_593 = tmp3.Invoke_O__O(tmp4); if linked_591 == nil { return ifn_592.Invoke_O__O(arg_593) } else { return linked_591.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_590, arg_593) } }
//line :197:1
func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_New() *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A) Invoke_O_O__O(self, s__1242000052__1 any) any { var tmp1 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_New_O_O(s__1242000052__1, self); var tmp2 *jrt.Class; var fncls__582 *jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_fn_class; if fncls__582 == nil { var fncls__582d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_fn_class = fncls__582d; tmp2 = fncls__582d } else { tmp2 = fncls__582 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :197:1
func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A{}; t.Ctor_O_O(p0, p1); return t }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A) Ctor_O_O(c__s__1242000052, c__iter__1242000051 any) { t.F_s__1242000052 = c__s__1242000052; t.F_iter__1242000051 = c__iter__1242000051 }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A) Invoke_O__O(self any) any { { var s__1242000052__1 any; var t_ any = t.F_s__1242000052; t.F_s__1242000052 = nil; s__1242000052__1 = t_; for { var temp__1927000414__auto____2 any; var root_449 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = s__1242000052__1; if linked_450 == nil { temp__1927000414__auto____2 = ifn_451.Invoke_O__O(arg_452) } else { temp__1927000414__auto____2 = linked_450.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_449, arg_452) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1242000052__3 any = temp__1927000414__auto____2; var tmp1 any; var root_453 any = A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = s__1242000052__3; if linked_454 == nil { tmp1 = ifn_455.Invoke_O__O(arg_456) } else { tmp1 = linked_454.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_453, arg_456) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_457 any = A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = s__1242000052__3; if linked_458 == nil { c__1927001037__auto____4 = ifn_459.Invoke_O__O(arg_460) } else { c__1927001037__auto____4 = linked_458.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_457, arg_460) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1242000054__6 any; var root_461 any = A_arbace_repr_go_print_text_A_const_77.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_462 == nil { b__1242000054__6 = ifn_463.Invoke_O__O(arg_464) } else { b__1242000054__6 = linked_462.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_461, arg_464) }; var tmp2 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_New_O_I_O(b__1242000054__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__508 *jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_fn_class; if fncls__508 == nil { var fncls__508d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_fn_class = fncls__508d; tmp3 = fncls__508d } else { tmp3 = fncls__508 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_517 any = A_arbace_repr_go_print_text_A_const_85.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any; var root_509 any = A_arbace_repr_go_print_text_A_const_86.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_511 lang.IFn; if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = b__1242000054__6; if linked_510 == nil { arg_520 = ifn_511.Invoke_O__O(arg_512) } else { arg_520 = linked_510.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_509, arg_512) }; var arg_521 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1242000051); var tmp5 any; var root_513 any = A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_515 lang.IFn; if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = s__1242000052__3; if linked_514 == nil { tmp5 = ifn_515.Invoke_O__O(arg_516) } else { tmp5 = linked_514.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_513, arg_516) }; arg_521 = tmp4.Invoke_O__O(tmp5); if linked_518 == nil { return ifn_519.Invoke_O_O__O(arg_520, arg_521) } else { return linked_518.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_517, arg_520, arg_521) } } else { var root_526 any = A_arbace_repr_go_print_text_A_const_85.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any; var root_522 any = A_arbace_repr_go_print_text_A_const_86.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = b__1242000054__6; if linked_523 == nil { arg_529 = ifn_524.Invoke_O__O(arg_525) } else { arg_529 = linked_523.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_522, arg_525) }; var arg_530 any; if linked_527 == nil { return ifn_528.Invoke_O_O__O(arg_529, arg_530) } else { return linked_527.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_526, arg_529, arg_530) } } } else { var line__4 any; var root_531 any = A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = s__1242000052__3; if linked_532 == nil { line__4 = ifn_533.Invoke_O__O(arg_534) } else { line__4 = linked_532.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_531, arg_534) }; var root_577 any = A_arbace_repr_go_print_text_A_const_87.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any; var n__5 int32 = jrt.NN(jrt.String_Cast(line__4)).Length__I(); var tmp6 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_New_I_O(n__5, line__4); var tmp7 *jrt.Class
																var fncls__572 /*line :197:1*/*jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_fn_class

	if fncls__572 == nil { var fncls__572d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_fn_class = fncls__572d; tmp7 = fncls__572d } else { tmp7 = fncls__572 }; arg_580 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :197:1
	var arg_581 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1242000051); var tmp9 any; var root_573 any = A_arbace_repr_go_print_text_A_const_88.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = s__1242000052__3; if linked_574 == nil { tmp9 = ifn_575.Invoke_O__O(arg_576) } else { tmp9 = linked_574.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_573, arg_576) }; arg_581 = tmp8.Invoke_O__O(tmp9); if linked_578 == nil { return ifn_579.Invoke_O_O__O(arg_580, arg_581) } else { return linked_578.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_577, arg_580, arg_581) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :197:1
func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A) Ctor_O_I_O(c__b__1242000054 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1242000054 = c__b__1242000054; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A) Invoke_O__O(self any) any { { var i__1242000053__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1242000053__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var line__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1242000053__1)); var root_503 any = A_arbace_repr_go_print_text_A_const_78.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = t.F_b__1242000054; var arg_507 any; var n__3 int32 = jrt.NN(jrt.String_Cast(line__2)).Length__I(); var tmp2 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_New_I_O(n__3, line__2); var tmp3 *jrt.Class
																		var fncls__502 /*line :197:1*/*jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_fn_class

	if fncls__502 == nil { var fncls__502d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_fn_class = fncls__502d; tmp3 = fncls__502d } else { tmp3 = fncls__502 }; arg_507 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()
//line :197:1
	if linked_504 == nil { ifn_505.Invoke_O_O__O(arg_506, arg_507) } else { linked_504.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_503, arg_506, arg_507) }; i__1242000053__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1242000053__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_New_I_O(p0 int32, p1 any) *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A{}; t.Ctor_I_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A) Ctor_I_O(c__n int32, c__line any) { t.F_n = c__n; t.F_line = c__line }
//line :199:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var start__2 int64 = 0; var cells__3 any; var root_465 any = A_arbace_repr_go_print_text_A_const_24.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = lang.PersistentVector_EMPTY.Ref(); if linked_466 == nil { cells__3 = ifn_467.Invoke_O__O(arg_468) } else { cells__3 = linked_466.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_465, arg_468) }; L1: for {
																			if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(t.F_n)) { var tmp1 *jrt.String = jrt.String_Cast(t.F_line); var c__4 int32 = lang.RT_IntCast_C__I_NoInit(jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))); var tmp2 bool; var or__1927000174__auto____5 bool = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)

		if or__1927000174__auto____5 { tmp2 = or__1927000174__auto____5 } else { tmp2 = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 11) }; if tmp2 {
			var tmp3 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp4 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp5 any; var root_497 any = A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_499 lang.IFn
			if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = cells__3; var arg_501 any; var tmp6 bool; var and__1927000168__auto____5 bool = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9); if and__1927000168__auto____5 { tmp6 = lang.Numbers_Equiv_J_J__Z_NoInit(start__2, i__1) } else { tmp6 = and__1927000168__auto____5 }; if tmp6 { arg_501 = A_arbace_repr_go_print_text_A_const_84.GetRawRoot__O() } else { var t__5 any; var root_487 any = A_arbace_repr_go_print_text_A_const_79.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_489 lang.IFn

				if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = t.F_line; var arg_491 any = jrt.Long_ValueOf_J__Long_NoInit(start__2).Ref(); var arg_492 any = jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref(); if linked_488 == nil { t__5 = ifn_489.Invoke_O_O_O__O(arg_490, arg_491, arg_492) } else { t__5 = linked_488.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_487, arg_490, arg_491, arg_492) }
//line :204:1
				var tmp7 any = A_arbace_repr_go_print_text_A_const_80; var tmp8 any = A_arbace_repr_go_print_text_A_const_81; var tmp9 any; var root_493 any = A_arbace_repr_go_print_text_A_const_82.GetRawRoot__O(); var linked_494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_493, A_arbace_repr_go_print_text_cell_width_A_fn_class); var ifn_495 lang.IFn


				if linked_494 == nil { ifn_495 = lang.IFn_Cast(root_493) } else { ifn_495 = nil }; var arg_496 any = t__5; if linked_494 == nil { tmp9 = ifn_495.Invoke_O__O(arg_496) } else { tmp9 = linked_494.(*A_arbace_repr_go_print_text_cell_width_A).Invoke_O_O__O(root_493, arg_496) }
//line :204:1
				var tmp10 any = tmp9; var tmp11 any = A_arbace_repr_go_print_text_A_const_83; arg_501 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, t__5, tmp8, tmp10, tmp11, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)).Ref())) }; if linked_498 == nil { tmp5 = ifn_499.Invoke_O_O__O(arg_500, arg_501) } else { tmp5 = linked_498.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_497, arg_500, arg_501) }
//line :203:1
			i__1, start__2, cells__3 = tmp3, tmp4, tmp5; continue L1 } else {




				i__1, start__2, cells__3 = lang.Numbers_Inc_J__J_NoInit(i__1), start__2, cells__3; continue L1 } } else {
//line :200:1
					var t__4 any; var root_469 any = A_arbace_repr_go_print_text_A_const_79.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_471 lang.IFn








					if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = t.F_line; var arg_473 any = jrt.Long_ValueOf_J__Long_NoInit(start__2).Ref(); if linked_470 == nil { t__4 = ifn_471.Invoke_O_O__O(arg_472, arg_473) } else { t__4 = linked_470.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_469, arg_472, arg_473) }
					var root_483 any = A_arbace_repr_go_print_text_A_const_25.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_485 lang.IFn; if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any; var root_478 any = A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = cells__3; var arg_482 any; var tmp12 any = A_arbace_repr_go_print_text_A_const_80; var tmp13 any = A_arbace_repr_go_print_text_A_const_81; var tmp14 any; var root_474 any = A_arbace_repr_go_print_text_A_const_82.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, A_arbace_repr_go_print_text_cell_width_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = t__4; if linked_475 == nil { tmp14 = ifn_476.Invoke_O__O(arg_477) } else { tmp14 = linked_475.(*A_arbace_repr_go_print_text_cell_width_A).Invoke_O_O__O(root_474, arg_477) }; arg_482 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, t__4, tmp13, tmp14, A_arbace_repr_go_print_text_A_const_83, jrt.Boolean_FALSE.Ref())); if linked_479 == nil { arg_486 = ifn_480.Invoke_O_O__O(arg_481, arg_482) } else { arg_486 = linked_479.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_478, arg_481, arg_482) }; if linked_484 == nil { return ifn_485.Invoke_O__O(arg_486) } else { return linked_484.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_483, arg_486) } } } }; /*line :199:1*/panic("j2g: unreachable") }
//line :199:1
func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_New_I_O(p0 int32, p1 any) *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A{}; t.Ctor_I_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A) Ctor_I_O(c__n int32, c__line any) { t.F_n = c__n; t.F_line = c__line }
//line :199:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var start__2 int64 = 0; var cells__3 any; var root_535 any = A_arbace_repr_go_print_text_A_const_24.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = lang.PersistentVector_EMPTY.Ref(); if linked_536 == nil { cells__3 = ifn_537.Invoke_O__O(arg_538) } else { cells__3 = linked_536.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_535, arg_538) }; L1: for {
																		if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(t.F_n)) { var tmp1 *jrt.String = jrt.String_Cast(t.F_line); var c__4 int32 = lang.RT_IntCast_C__I_NoInit(jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))); var tmp2 bool; var or__1927000174__auto____5 bool = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)

		if or__1927000174__auto____5 { tmp2 = or__1927000174__auto____5 } else { tmp2 = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 11) }; if tmp2 {
			var tmp3 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp4 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp5 any; var root_567 any = A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_569 lang.IFn
			if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = cells__3; var arg_571 any; var tmp6 bool; var and__1927000168__auto____5 bool = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9); if and__1927000168__auto____5 { tmp6 = lang.Numbers_Equiv_J_J__Z_NoInit(start__2, i__1) } else { tmp6 = and__1927000168__auto____5 }; if tmp6 { arg_571 = A_arbace_repr_go_print_text_A_const_84.GetRawRoot__O() } else { var t__5 any; var root_557 any = A_arbace_repr_go_print_text_A_const_79.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_559 lang.IFn

				if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = t.F_line; var arg_561 any = jrt.Long_ValueOf_J__Long_NoInit(start__2).Ref(); var arg_562 any = jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref(); if linked_558 == nil { t__5 = ifn_559.Invoke_O_O_O__O(arg_560, arg_561, arg_562) } else { t__5 = linked_558.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_557, arg_560, arg_561, arg_562) }
//line :204:1
				var tmp7 any = A_arbace_repr_go_print_text_A_const_80; var tmp8 any = A_arbace_repr_go_print_text_A_const_81; var tmp9 any; var root_563 any = A_arbace_repr_go_print_text_A_const_82.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, A_arbace_repr_go_print_text_cell_width_A_fn_class); var ifn_565 lang.IFn


				if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = t__5; if linked_564 == nil { tmp9 = ifn_565.Invoke_O__O(arg_566) } else { tmp9 = linked_564.(*A_arbace_repr_go_print_text_cell_width_A).Invoke_O_O__O(root_563, arg_566) }
//line :204:1
				var tmp10 any = tmp9; var tmp11 any = A_arbace_repr_go_print_text_A_const_83; arg_571 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, t__5, tmp8, tmp10, tmp11, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)).Ref())) }; if linked_568 == nil { tmp5 = ifn_569.Invoke_O_O__O(arg_570, arg_571) } else { tmp5 = linked_568.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_567, arg_570, arg_571) }
//line :203:1
			i__1, start__2, cells__3 = tmp3, tmp4, tmp5; continue L1 } else {




				i__1, start__2, cells__3 = lang.Numbers_Inc_J__J_NoInit(i__1), start__2, cells__3; continue L1 } } else {
//line :200:1
					var t__4 any; var root_539 any = A_arbace_repr_go_print_text_A_const_79.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_541 lang.IFn








					if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = t.F_line; var arg_543 any = jrt.Long_ValueOf_J__Long_NoInit(start__2).Ref(); if linked_540 == nil { t__4 = ifn_541.Invoke_O_O__O(arg_542, arg_543) } else { t__4 = linked_540.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_539, arg_542, arg_543) }
					var root_553 any = A_arbace_repr_go_print_text_A_const_25.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any; var root_548 any = A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_conj_BANG__A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = cells__3; var arg_552 any; var tmp12 any = A_arbace_repr_go_print_text_A_const_80; var tmp13 any = A_arbace_repr_go_print_text_A_const_81; var tmp14 any; var root_544 any = A_arbace_repr_go_print_text_A_const_82.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, A_arbace_repr_go_print_text_cell_width_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = t__4; if linked_545 == nil { tmp14 = ifn_546.Invoke_O__O(arg_547) } else { tmp14 = linked_545.(*A_arbace_repr_go_print_text_cell_width_A).Invoke_O_O__O(root_544, arg_547) }; arg_552 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, t__4, tmp13, tmp14, A_arbace_repr_go_print_text_A_const_83, jrt.Boolean_FALSE.Ref())); if linked_549 == nil { arg_556 = ifn_550.Invoke_O_O__O(arg_551, arg_552) } else { arg_556 = linked_549.(*aot_arbace_core.A_arbace_core_conj_BANG__A).Invoke_O_O_O__O(root_548, arg_551, arg_552) }; if linked_554 == nil { return ifn_555.Invoke_O__O(arg_556) } else { return linked_554.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_553, arg_556) } } } }; /*line :199:1*/panic("j2g: unreachable") }












func A_arbace_repr_go_print_text_write_padding_A_New() *A_arbace_repr_go_print_text_write_padding_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_write_padding_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_repr_go_print_text_write_padding_A) Ctor() {}
//line :212:1
func (t *A_arbace_repr_go_print_text_write_padding_A) Invoke_O_O_O_O_O__O(self, sb__0, p_textw__1, p_cellw__2, use_tabs__3 any) any { { var textw__1 int64 = lang.RT_LongCast_O__J_NoInit(p_textw__1); var cellw__2 int64 = lang.RT_LongCast_O__J_NoInit(p_cellw__2)
																	if jrt.J2g_Truth(use_tabs__3) { var cellw__5 int64 = lang.Numbers_Multiply_J_J__J_NoInit(8, lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(cellw__2, 7), 8)); var n__6 int64 = lang.Numbers_Minus_J_J__J_NoInit(cellw__5, textw__1); var n__1927000701__auto____7 int64 = lang.RT_LongCast_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(n__6, 7), 8)); var ___8 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z_NoInit(___8, n__1927000701__auto____7) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_repr_go_print_text_A_const_64); ___8 = lang.Numbers_Unchecked_inc_J__J_NoInit(___8); continue L1 } else { return nil } } } else {
//line :213:1
			var n__1927000701__auto____5 int64 = lang.RT_LongCast_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(cellw__2, textw__1)); var ___6 int64 = 0; L2: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(___6, n__1927000701__auto____5) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_repr_go_print_text_A_const_92); ___6 = lang.Numbers_Unchecked_inc_J__J_NoInit(___6); continue L2 } else { return nil } } } }; /*line :212:1*/panic("j2g: unreachable") }






func A_arbace_repr_go_print_text_write_lines_A_New() *A_arbace_repr_go_print_text_write_lines_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_write_lines_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_repr_go_print_text_write_lines_A) Ctor() {}
//line :219:1
func (t *A_arbace_repr_go_print_text_write_lines_A) Invoke_O_O_O_O_O_O__O(self, sb__0, lines__1, widths__2, line0__3, line1__4 any) any { { var seq_1242000067__6 any; var root_599 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_599, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_601 lang.IFn
																	if linked_600 == nil { ifn_601 = lang.IFn_Cast(root_599) } else { ifn_601 = nil }; var arg_602 any; var root_594 any = A_arbace_repr_go_print_text_A_const_93.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = line0__3; var arg_598 any = line1__4; if linked_595 == nil { arg_602 = ifn_596.Invoke_O_O__O(arg_597, arg_598) } else { arg_602 = linked_595.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_594, arg_597, arg_598) }; if linked_600 == nil { seq_1242000067__6 = ifn_601.Invoke_O__O(arg_602) } else { seq_1242000067__6 = linked_600.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_599, arg_602) }
//line :219:1
	var chunk_1242000068__7 any; var count_1242000069__8 int64 = 0; var i_1242000070__9 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000070__9, count_1242000069__8) { var i__10 any = lang.Indexed_Cast(chunk_1242000068__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000070__9)); var line__11 any = lang.RT_Nth_O_I__O_NoInit(lines__1, lang.RT_IntCast_O__I_NoInit(i__10)); var nw__12 int32 = lang.RT_Count_O__I_NoInit(widths__2); var j__13 int64 = 0; var use_tabs__14 any = jrt.Boolean_TRUE.Ref(); L2: for {



			if lang.Numbers_Lt_J_J__Z_NoInit(j__13, int64(lang.RT_Count_O__I_NoInit(line__11))) { var c__15 any = lang.RT_Nth_O_I__O_NoInit(line__11, lang.RT_IntCast_J__I_NoInit(j__13))

				if lang.Numbers_IsZero_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_print_text_A_const_80.Invoke_O__O(c__15)))) {
					if lang.Numbers_Lt_J_J__Z_NoInit(j__13, int64(nw__12)) { var root_626 any = A_arbace_repr_go_print_text_A_const_94.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, A_arbace_repr_go_print_text_write_padding_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = sb__0; var arg_630 any = A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__15); var arg_631 any = lang.RT_Nth_O_I__O_NoInit(widths__2, lang.RT_IntCast_J__I_NoInit(j__13)); var arg_632 any = use_tabs__14; if linked_627 == nil { ifn_628.Invoke_O_O_O_O__O(arg_629, arg_630, arg_631, arg_632) } else { linked_627.(*A_arbace_repr_go_print_text_write_padding_A).Invoke_O_O_O_O_O__O(root_626, arg_629, arg_630, arg_631, arg_632) } }
					j__13, use_tabs__14 = lang.Numbers_Inc_J__J_NoInit(j__13), use_tabs__14; continue L2 } else {
						jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_String__StringBuilder(jrt.String_Cast(A_arbace_repr_go_print_text_A_const_80.Invoke_O__O(c__15)))
						if lang.Numbers_Lt_J_J__Z_NoInit(j__13, int64(nw__12)) { var root_633 any = A_arbace_repr_go_print_text_A_const_94.GetRawRoot__O(); var linked_634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_633, A_arbace_repr_go_print_text_write_padding_A_fn_class); var ifn_635 lang.IFn; if linked_634 == nil { ifn_635 = lang.IFn_Cast(root_633) } else { ifn_635 = nil }; var arg_636 any = sb__0; var arg_637 any = A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__15); var arg_638 any = lang.RT_Nth_O_I__O_NoInit(widths__2, lang.RT_IntCast_J__I_NoInit(j__13)); var arg_639 any = jrt.Boolean_FALSE.Ref(); if linked_634 == nil { ifn_635.Invoke_O_O_O_O__O(arg_636, arg_637, arg_638, arg_639) } else { linked_634.(*A_arbace_repr_go_print_text_write_padding_A).Invoke_O_O_O_O_O__O(root_633, arg_636, arg_637, arg_638, arg_639) } }
						j__13, use_tabs__14 = lang.Numbers_Inc_J__J_NoInit(j__13), jrt.Boolean_FALSE.Ref(); continue L2 } }
//line :220:1
			break L2
		}










			var tmp1 bool; var na_619 any; var na_621 any = i__10; if jrt.Long_InstanceOf(na_621) { var n0_622 int64 = jrt.NN(jrt.Long_Cast(na_621)).LongValue__J(); if n0_622 == 9223372036854775807 { na_619 = lang.Numbers_Inc_O__Number_NoInit(na_621) } else { na_619 = jrt.Long_ValueOf_J__Long_NoInit(n0_622 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_621) { var n0_622_2 float64 = jrt.NN(jrt.Double_Cast(na_621)).DoubleValue__D(); na_619 = jrt.Double_ValueOf_D__Double_NoInit(n0_622_2 + 1.0).Ref() } else { na_619 = lang.Numbers_Inc_O__Number_NoInit(na_621) } }; var na_620 int64 = int64(lang.RT_Count_O__I_NoInit(lines__1)); if jrt.Long_InstanceOf(na_619) { var n0_623 int64 = jrt.NN(jrt.Long_Cast(na_619)).LongValue__J(); var n1_624 int64 = na_620; tmp1 = n0_623 < n1_624 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_619, na_620) }; if tmp1 { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_repr_go_print_text_A_const_66) }
//line :220:1
			seq_1242000067__6, chunk_1242000068__7, count_1242000069__8, i_1242000070__9 = seq_1242000067__6, chunk_1242000068__7, count_1242000069__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000070__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_603 any = A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_605 lang.IFn; if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = seq_1242000067__6; if linked_604 == nil { temp__1927000414__auto____10 = ifn_605.Invoke_O__O(arg_606) } else { temp__1927000414__auto____10 = linked_604.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_603, arg_606) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1242000067__11 any = temp__1927000414__auto____10; var tmp2 any; var root_607 any = A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = seq_1242000067__11; if linked_608 == nil { tmp2 = ifn_609.Invoke_O__O(arg_610) } else { tmp2 = linked_608.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_607, arg_610) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____12 any; var root_611 any = A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = seq_1242000067__11; if linked_612 == nil { c__1927000678__auto____12 = ifn_613.Invoke_O__O(arg_614) } else { c__1927000678__auto____12 = linked_612.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_611, arg_614) }; var tmp3 any; var root_640 any = A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_642 lang.IFn; if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = seq_1242000067__11; if linked_641 == nil { tmp3 = ifn_642.Invoke_O__O(arg_643) } else { tmp3 = linked_641.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_640, arg_643) }; seq_1242000067__6, chunk_1242000068__7, count_1242000069__8, i_1242000070__9 = tmp3, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var i__12 any; var root_615 any = A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = seq_1242000067__11; if linked_616 == nil { i__12 = ifn_617.Invoke_O__O(arg_618) } else { i__12 = linked_616.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_615, arg_618) }; var line__13 any = lang.RT_Nth_O_I__O_NoInit(lines__1, lang.RT_IntCast_O__I_NoInit(i__12)); var nw__14 int32 = lang.RT_Count_O__I_NoInit(widths__2); var j__15 int64 = 0; var use_tabs__16 any = jrt.Boolean_TRUE.Ref(); L3: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(j__15, int64(lang.RT_Count_O__I_NoInit(line__13))) { var c__17 any = lang.RT_Nth_O_I__O_NoInit(line__13, lang.RT_IntCast_J__I_NoInit(j__15))

					if lang.Numbers_IsZero_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_print_text_A_const_80.Invoke_O__O(c__17)))) {
						if lang.Numbers_Lt_J_J__Z_NoInit(j__15, int64(nw__14)) { var root_651 any = A_arbace_repr_go_print_text_A_const_94.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, A_arbace_repr_go_print_text_write_padding_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = sb__0; var arg_655 any = A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__17); var arg_656 any = lang.RT_Nth_O_I__O_NoInit(widths__2, lang.RT_IntCast_J__I_NoInit(j__15)); var arg_657 any = use_tabs__16; if linked_652 == nil { ifn_653.Invoke_O_O_O_O__O(arg_654, arg_655, arg_656, arg_657) } else { linked_652.(*A_arbace_repr_go_print_text_write_padding_A).Invoke_O_O_O_O_O__O(root_651, arg_654, arg_655, arg_656, arg_657) } }
						j__15, use_tabs__16 = lang.Numbers_Inc_J__J_NoInit(j__15), use_tabs__16; continue L3 } else {
							jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_String__StringBuilder(jrt.String_Cast(A_arbace_repr_go_print_text_A_const_80.Invoke_O__O(c__17)))
							if lang.Numbers_Lt_J_J__Z_NoInit(j__15, int64(nw__14)) { var root_658 any = A_arbace_repr_go_print_text_A_const_94.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, A_arbace_repr_go_print_text_write_padding_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = sb__0; var arg_662 any = A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__17); var arg_663 any = lang.RT_Nth_O_I__O_NoInit(widths__2, lang.RT_IntCast_J__I_NoInit(j__15)); var arg_664 any = jrt.Boolean_FALSE.Ref(); if linked_659 == nil { ifn_660.Invoke_O_O_O_O__O(arg_661, arg_662, arg_663, arg_664) } else { linked_659.(*A_arbace_repr_go_print_text_write_padding_A).Invoke_O_O_O_O_O__O(root_658, arg_661, arg_662, arg_663, arg_664) } }
							j__15, use_tabs__16 = lang.Numbers_Inc_J__J_NoInit(j__15), jrt.Boolean_FALSE.Ref(); continue L3 } }
//line :220:1
				break L3
			}










				var tmp4 bool; var na_644 any; var na_646 any = i__12; if jrt.Long_InstanceOf(na_646) { var n0_647 int64 = jrt.NN(jrt.Long_Cast(na_646)).LongValue__J(); if n0_647 == 9223372036854775807 { na_644 = lang.Numbers_Inc_O__Number_NoInit(na_646) } else { na_644 = jrt.Long_ValueOf_J__Long_NoInit(n0_647 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_646) { var n0_647_2 float64 = jrt.NN(jrt.Double_Cast(na_646)).DoubleValue__D(); na_644 = jrt.Double_ValueOf_D__Double_NoInit(n0_647_2 + 1.0).Ref() } else { na_644 = lang.Numbers_Inc_O__Number_NoInit(na_646) } }; var na_645 int64 = int64(lang.RT_Count_O__I_NoInit(lines__1)); if jrt.Long_InstanceOf(na_644) { var n0_648 int64 = jrt.NN(jrt.Long_Cast(na_644)).LongValue__J(); var n1_649 int64 = na_645; tmp4 = n0_648 < n1_649 } else { tmp4 = lang.Numbers_Lt_O_J__Z_NoInit(na_644, na_645) }; if tmp4 { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_repr_go_print_text_A_const_66) }
//line :220:1
				var tmp5 any; var root_665 any = A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = seq_1242000067__11; if linked_666 == nil { tmp5 = ifn_667.Invoke_O__O(arg_668) } else { tmp5 = linked_666.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_665, arg_668) }; seq_1242000067__6, chunk_1242000068__7, count_1242000069__8, i_1242000070__9 = tmp5, nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :219:1*/panic("j2g: unreachable") }














func A_arbace_repr_go_print_text_format_block_A_New() *A_arbace_repr_go_print_text_format_block_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_format_block_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_repr_go_print_text_format_block_A) Ctor() {}
//line :234:1
func (t *A_arbace_repr_go_print_text_format_block_A) Invoke_O_O_O_O_O_O__O(self, sb__0, lines__1, widths__2, line0__3, line1__4 any) any { { var column__6 int32 = lang.RT_Count_O__I_NoInit(widths__2); var this__7 any = line0__3; var line0__8 any = line0__3; L1: for {




	var tmp1 bool; var na_669 any = this__7; var na_670 any = line1__4; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_669); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_670) }; tmp2 = tmp3; if tmp2 { var n0_671 int64 = jrt.NN(jrt.Long_Cast(na_669)).LongValue__J(); var n1_672 int64 = jrt.NN(jrt.Long_Cast(na_670)).LongValue__J(); tmp1 = n0_671 < n1_672 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_669); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_670) }; tmp4 = tmp5; if tmp4 { var n0_671_2 float64 = jrt.NN(jrt.Double_Cast(na_669)).DoubleValue__D(); var n1_672_2 float64 = jrt.NN(jrt.Double_Cast(na_670)).DoubleValue__D(); tmp1 = n0_671_2 < n1_672_2 } else { tmp1 = lang.Numbers_Lt_O_O__Z_NoInit(na_669, na_670) } }; if tmp1 { var line__9 any = lang.RT_Nth_O_I__O_NoInit(lines__1, lang.RT_IntCast_O__I_NoInit(this__7))

		if lang.Numbers_Gte_J_J__Z_NoInit(int64(column__6), lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(line__9)))) {
			var tmp6 jrt.Number_I; var na_698 any = this__7; if jrt.Long_InstanceOf(na_698) { var n0_699 int64 = jrt.NN(jrt.Long_Cast(na_698)).LongValue__J(); if n0_699 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_698) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_699 + 1)) } } else { if jrt.Double_InstanceOf(na_698) { var n0_699_2 float64 = jrt.NN(jrt.Double_Cast(na_698)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_699_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_698) } }; this__7, line0__8 = tmp6, line0__8; continue L1 } else {

				var root_700 any = A_arbace_repr_go_print_text_A_const_95.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, A_arbace_repr_go_print_text_write_lines_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = sb__0; var arg_704 any = lines__1; var arg_705 any = widths__2; var arg_706 any = line0__8; var arg_707 any = this__7; if linked_701 == nil { ifn_702.Invoke_O_O_O_O_O__O(arg_703, arg_704, arg_705, arg_706, arg_707) } else { linked_701.(*A_arbace_repr_go_print_text_write_lines_A).Invoke_O_O_O_O_O_O__O(root_700, arg_703, arg_704, arg_705, arg_706, arg_707) }
//line :241:1
				var line0__10 any = this__7; var vec__1242000072__11 any; var tmp7 any = A_arbace_repr_go_print_text_format_block_fn__1242000075_A_New_I_O_O_O(column__6, this__7, line1__4, lines__1); var tmp8 *jrt.Class
				var fncls__689 /*line :241:1*/*jrt.Class = A_arbace_repr_go_print_text_format_block_fn__1242000075_A_fn_class





				if fncls__689 == nil { var fncls__689d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_repr_go_print_text_format_block_fn__1242000075_A_fn_class = fncls__689d; tmp8 = fncls__689d } else { tmp8 = fncls__689 }; vec__1242000072__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()
//line :241:1
				var end__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000072__11, lang.RT_IntCast_J__I_NoInit(0), nil); var width__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000072__11, lang.RT_IntCast_J__I_NoInit(1), nil); var discardable__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000072__11, lang.RT_IntCast_J__I_NoInit(2), nil); var width__15 any














				if jrt.J2g_Truth(discardable__14) { width__15 = A_arbace_repr_go_print_text_A_const_46 } else { width__15 = width__13 }
				var root_713 any = A_arbace_repr_go_print_text_A_const_96.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, A_arbace_repr_go_print_text_format_block_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = sb__0; var arg_717 any = lines__1; var arg_718 any; var root_708 any = A_arbace_repr_go_print_text_A_const_7.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any = widths__2; var arg_712 any = width__15; if linked_709 == nil { arg_718 = ifn_710.Invoke_O_O__O(arg_711, arg_712) } else { arg_718 = linked_709.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_708, arg_711, arg_712) }; var arg_719 any = line0__10; var arg_720 any = end__12; if linked_714 == nil { ifn_715.Invoke_O_O_O_O_O__O(arg_716, arg_717, arg_718, arg_719, arg_720) } else { linked_714.(*A_arbace_repr_go_print_text_format_block_A).Invoke_O_O_O_O_O_O__O(root_713, arg_716, arg_717, arg_718, arg_719, arg_720) }
				var tmp9 jrt.Number_I; var na_721 any = end__12; if jrt.Long_InstanceOf(na_721) { var n0_722 int64 = jrt.NN(jrt.Long_Cast(na_721)).LongValue__J(); if n0_722 == 9223372036854775807 { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_721) } else { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_722 + 1)) } } else { if jrt.Double_InstanceOf(na_721) { var n0_722_2 float64 = jrt.NN(jrt.Double_Cast(na_721)).DoubleValue__D(); tmp9 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_722_2 + 1.0)) } else { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_721) } }; this__7, line0__8 = tmp9, end__12; continue L1 } } else {
					var root_690 any = A_arbace_repr_go_print_text_A_const_95.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, A_arbace_repr_go_print_text_write_lines_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = sb__0; var arg_694 any = lines__1; var arg_695 any = widths__2; var arg_696 any = line0__8; var arg_697 any = line1__4; if linked_691 == nil { return ifn_692.Invoke_O_O_O_O_O__O(arg_693, arg_694, arg_695, arg_696, arg_697) } else { return linked_691.(*A_arbace_repr_go_print_text_write_lines_A).Invoke_O_O_O_O_O_O__O(root_690, arg_693, arg_694, arg_695, arg_696, arg_697) } } } }; /*line :234:1*/panic("j2g: unreachable") }












func A_arbace_repr_go_print_text_format_block_fn__1242000075_A_New_I_O_O_O(p0 int32, p1, p2, p3 any) *A_arbace_repr_go_print_text_format_block_fn__1242000075_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_format_block_fn__1242000075_A{}; t.Ctor_I_O_O_O(p0, p1, p2, p3); return t }
//line :247:1
func (t *A_arbace_repr_go_print_text_format_block_fn__1242000075_A) Ctor_I_O_O_O(c__column int32, c__this, c__line1, c__lines any) { t.F_column = c__column; t.F_this = c__this; t.F_line1 = c__line1; t.F_lines = c__lines }
//line :247:1
func (t *A_arbace_repr_go_print_text_format_block_fn__1242000075_A) Invoke_O__O(self any) any { { var this__1 any; var t_ any = t.F_this; t.F_this = nil; this__1 = t_; var width__2 any = lang.RT_Box_J__Number_NoInit(0); var discardable__3 any = jrt.Boolean_TRUE.Ref(); L1: for {
												var tmp1 bool; var na_674 any = this__1; var na_675 any = t.F_line1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_674); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_675) }; tmp2 = tmp3; if tmp2 { var n0_676 int64 = jrt.NN(jrt.Long_Cast(na_674)).LongValue__J(); var n1_677 int64 = jrt.NN(jrt.Long_Cast(na_675)).LongValue__J(); tmp1 = n0_676 < n1_677 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_674); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_675) }; tmp4 = tmp5; if tmp4 { var n0_676_2 float64 = jrt.NN(jrt.Double_Cast(na_674)).DoubleValue__D(); var n1_677_2 float64 = jrt.NN(jrt.Double_Cast(na_675)).DoubleValue__D(); tmp1 = n0_676_2 < n1_677_2 } else { tmp1 = lang.Numbers_Lt_O_O__Z_NoInit(na_674, na_675) } }; if tmp1 { var tmp6 any = t.F_lines; var line__4 any = lang.RT_Nth_O_I__O_NoInit(tmp6, lang.RT_IntCast_O__I_NoInit(this__1)); var tmp7 int64 = int64(t.F_column)

		if lang.Numbers_Gte_J_J__Z_NoInit(tmp7, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(line__4)))) { return lang.Tuple_Create_O_O_O__IPersistentVector(this__1, width__2, discardable__3) } else { var c__5 any = lang.RT_Nth_O_I__O_NoInit(line__4, t.F_column); var tmp8 jrt.Number_I
			var na_679 any = this__1

			if jrt.Long_InstanceOf(na_679) { var n0_680 int64 = jrt.NN(jrt.Long_Cast(na_679)).LongValue__J(); if n0_680 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_679) } else { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_680 + 1)) } } else { if jrt.Double_InstanceOf(na_679) { var n0_680_2 float64 = jrt.NN(jrt.Double_Cast(na_679)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_680_2 + 1.0)) } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_679) } }; var tmp9 any = tmp8; var tmp10 jrt.Number_I; var na_681 any = A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__5); if jrt.Long_InstanceOf(na_681) { var n0_682 int64 = jrt.NN(jrt.Long_Cast(na_681)).LongValue__J(); if n0_682 == 9223372036854775807 { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_681) } else { tmp10 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_682 + 1)) } } else { if jrt.Double_InstanceOf(na_681) { var n0_682_2 float64 = jrt.NN(jrt.Double_Cast(na_681)).DoubleValue__D(); tmp10 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_682_2 + 1.0)) } else { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_681) } }; var tmp11 any = lang.Numbers_Max_O_O__O_NoInit(width__2, tmp10); var tmp12 any; var and__1927000168__auto____6 any = discardable__3
			if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 bool; var na_683 any = A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__5); if jrt.Long_InstanceOf(na_683) { var n0_684 int64 = jrt.NN(jrt.Long_Cast(na_683)).LongValue__J(); and__1927000168__auto____7 = n0_684 == 0 } else { if jrt.Double_InstanceOf(na_683) { var n0_684_2 float64 = jrt.NN(jrt.Double_Cast(na_683)).DoubleValue__D(); and__1927000168__auto____7 = n0_684_2 == 0.0 } else { and__1927000168__auto____7 = lang.Numbers_IsZero_O__Z_NoInit(na_683) } }; if and__1927000168__auto____7 { var root_685 any = A_arbace_repr_go_print_text_A_const_52.GetRawRoot__O(); var linked_686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_685, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_687 lang.IFn; if linked_686 == nil { ifn_687 = lang.IFn_Cast(root_685) } else { ifn_687 = nil }; var arg_688 any = A_arbace_repr_go_print_text_A_const_83.Invoke_O__O(c__5); if linked_686 == nil { tmp12 = ifn_687.Invoke_O__O(arg_688) } else { tmp12 = linked_686.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_685, arg_688) } } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp12 = and__1927000168__auto____6 }
//line :253:1
			this__1, width__2, discardable__3 = tmp9, tmp11, tmp12; continue L1 } } else {
//line :248:1
				return lang.Tuple_Create_O_O_O__IPersistentVector(this__1, width__2, discardable__3) } } }; /*line :247:1*/panic("j2g: unreachable") }













func A_arbace_repr_go_print_text_align_block_A_New() *A_arbace_repr_go_print_text_align_block_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_align_block_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_repr_go_print_text_align_block_A) Ctor() {}
//line :261:1
func (t *A_arbace_repr_go_print_text_align_block_A) Invoke_O_O__O(self, block__0 any) any { var sb__2 any = jrt.StringBuilder_New(); var lines__3 any; var root_723 any = A_arbace_repr_go_print_text_A_const_97.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, A_arbace_repr_go_print_text_parse_lines_A_fn_class); var ifn_725 lang.IFn; if



	linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = block__0; if linked_724 == nil { lines__3 = ifn_725.Invoke_O__O(arg_726) } else { lines__3 = linked_724.(*A_arbace_repr_go_print_text_parse_lines_A).Invoke_O_O__O(root_723, arg_726) }; var root_727 any =
	A_arbace_repr_go_print_text_A_const_96.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, A_arbace_repr_go_print_text_format_block_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any = sb__2; var arg_731 any = lines__3; var arg_732 any = lang.PersistentVector_EMPTY.Ref(); var arg_733 any = A_arbace_repr_go_print_text_A_const_46; var arg_734 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lines__3)).Ref(); if linked_728 == nil { ifn_729.Invoke_O_O_O_O_O__O(arg_730, arg_731, arg_732, arg_733, arg_734) } else { linked_728.(*A_arbace_repr_go_print_text_format_block_A).Invoke_O_O_O_O_O_O__O(root_727, arg_730, arg_731, arg_732, arg_733, arg_734) }; return /*line :267:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_repr_go_print_text_align_A_New() *A_arbace_repr_go_print_text_align_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_align_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_repr_go_print_text_align_A) Ctor() {}
//line :269:1
func (t *A_arbace_repr_go_print_text_align_A) Invoke_O_O__O(self, text__0 any) any { var blocks__2 any; var root_735 any = A_arbace_repr_go_print_text_A_const_89.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_737 lang.IFn; if



	linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = text__0; var arg_739 any = A_arbace_repr_go_print_text_A_const_98; var arg_740 any = A_arbace_repr_go_print_text_A_const_91; if linked_736 == nil { blocks__2 = ifn_737.Invoke_O_O_O__O(arg_738, arg_739, arg_740) } else { blocks__2 = linked_736.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_735, arg_738, arg_739, arg_740) }; var n__3 int32 = /*line :269:1*/lang.RT_Count_O__I_NoInit(blocks__2); var groups__4 int64 = lang.Numbers_Multiply_J_J__J_NoInit(4, int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())); var aligned__5 any; if






	lang.Numbers_Lt_J_J__Z_NoInit(int64(n__3), 128) {
		var root_741 any = A_arbace_repr_go_print_text_A_const_99.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_743 lang.IFn; if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = A_arbace_repr_go_print_text_A_const_100.GetRawRoot__O(); var arg_745 any = blocks__2; if linked_742 == nil { aligned__5 = ifn_743.Invoke_O_O__O(arg_744, arg_745) } else { aligned__5 = linked_742.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_741, arg_744, arg_745) } } else {
			var root_762 any = A_arbace_repr_go_print_text_A_const_14.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_762, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_764 lang.IFn; if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = A_arbace_repr_go_print_text_A_const_101.GetRawRoot__O(); var arg_766 any; var root_757 any = A_arbace_repr_go_print_text_A_const_102.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any; var tmp1 any = A_arbace_repr_go_print_text_align_fn__1242000080_A_New(); var tmp2 *jrt.Class; var fncls__751 *jrt.Class = A_arbace_repr_go_print_text_align_fn__1242000080_A_fn_class; if fncls__751 == nil { var fncls__751d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_repr_go_print_text_align_fn__1242000080_A_fn_class = fncls__751d; tmp2 = fncls__751d } else { tmp2 = fncls__751 }; arg_760 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_761 any; var root_752 any = A_arbace_repr_go_print_text_A_const_104.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, aot_arbace_core.A_arbace_core_partition_all_A_fn_class); var ifn_754 lang.IFn
			if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(n__3), lang.Numbers_Dec_J__J_NoInit(groups__4)), groups__4)).Ref(); var arg_756 any = blocks__2; if linked_753 == nil { arg_761 = ifn_754.Invoke_O_O__O(arg_755, arg_756) } else { arg_761 = linked_753.(*aot_arbace_core.A_arbace_core_partition_all_A).Invoke_O_O_O__O(root_752, arg_755, arg_756) }
//line :278:1
			if linked_758 == nil { arg_766 = ifn_759.Invoke_O_O__O(arg_760, arg_761) } else { arg_766 = linked_758.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_757, arg_760, arg_761) }; if linked_763 == nil { aligned__5 = ifn_764.Invoke_O_O__O(arg_765, arg_766) } else { aligned__5 = linked_763.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_762, arg_765, arg_766) } }; var root_772 any =

	A_arbace_repr_go_print_text_A_const_105.GetRawRoot__O(); var linked_773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_772, A_arbace_repr_go_print_text_unescape_A_fn_class); var ifn_774 lang.IFn; if linked_773 == nil { ifn_774 = lang.IFn_Cast(root_772) } else { ifn_774 = nil }; var arg_775 any; var root_767 any = A_arbace_repr_go_print_text_A_const_106.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_769 lang.IFn; if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = Lit_2; var arg_771 any = aligned__5; if linked_768 == nil { arg_775 = ifn_769.Invoke_O_O__O(arg_770, arg_771) } else { arg_775 = linked_768.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_767, arg_770, arg_771) }; if linked_773 == nil { return ifn_774.Invoke_O__O(arg_775) } else { return linked_773.(*A_arbace_repr_go_print_text_unescape_A).Invoke_O_O__O(root_772, arg_775) } }
//line :278:1
func A_arbace_repr_go_print_text_align_fn__1242000080_A_New() *A_arbace_repr_go_print_text_align_fn__1242000080_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_align_fn__1242000080_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_repr_go_print_text_align_fn__1242000080_A) Ctor() {}
//line :278:1
func (t *A_arbace_repr_go_print_text_align_fn__1242000080_A) Invoke_O_O__O(self, p1__1242000079_SHARP___1 any) any { var root_746 any = A_arbace_repr_go_print_text_A_const_103.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = A_arbace_repr_go_print_text_A_const_100.GetRawRoot__O(); var arg_750 any = p1__1242000079_SHARP___1; if linked_747 == nil { return ifn_748.Invoke_O_O__O(arg_749, arg_750) } else { return linked_747.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_746, arg_749, arg_750) } }







type A_arbace_repr_go_print_text_A struct{ jrt.Object }

var A_arbace_repr_go_print_text_A_const_pool *jrt.RefArray

var A_arbace_repr_go_print_text_A_const_0 *lang.Var

var A_arbace_repr_go_print_text_A_const_1 any

var A_arbace_repr_go_print_text_A_const_2 *lang.Var

var A_arbace_repr_go_print_text_A_const_3 any

var A_arbace_repr_go_print_text_A_const_4 *lang.Var

var A_arbace_repr_go_print_text_A_const_5 *lang.Var

var A_arbace_repr_go_print_text_A_const_6 *lang.Var

var A_arbace_repr_go_print_text_A_const_7 *lang.Var

var A_arbace_repr_go_print_text_A_const_8 any

var A_arbace_repr_go_print_text_A_const_9 *lang.Var

var A_arbace_repr_go_print_text_A_const_10 any

var A_arbace_repr_go_print_text_A_const_11 any

var A_arbace_repr_go_print_text_A_const_12 *lang.Var

var A_arbace_repr_go_print_text_A_const_13 *lang.Var

var A_arbace_repr_go_print_text_A_const_14 *lang.Var

var A_arbace_repr_go_print_text_A_const_15 *lang.Var

var A_arbace_repr_go_print_text_A_const_16 *lang.Var

var A_arbace_repr_go_print_text_A_const_17 any

var A_arbace_repr_go_print_text_A_const_18 *lang.Var

var A_arbace_repr_go_print_text_A_const_19 *lang.Var

var A_arbace_repr_go_print_text_A_const_20 any

var A_arbace_repr_go_print_text_A_const_21 any

var A_arbace_repr_go_print_text_A_const_22 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_23 any

var A_arbace_repr_go_print_text_A_const_24 *lang.Var

var A_arbace_repr_go_print_text_A_const_25 *lang.Var

var A_arbace_repr_go_print_text_A_const_26 *lang.Var

var A_arbace_repr_go_print_text_A_const_27 *lang.Var

var A_arbace_repr_go_print_text_A_const_28 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_29 *lang.Var

var A_arbace_repr_go_print_text_A_const_30 *lang.Var

var A_arbace_repr_go_print_text_A_const_31 *lang.Var

var A_arbace_repr_go_print_text_A_const_32 *lang.Var

var A_arbace_repr_go_print_text_A_const_33 *lang.Var

var A_arbace_repr_go_print_text_A_const_34 *lang.Var

var A_arbace_repr_go_print_text_A_const_35 *lang.Var

var A_arbace_repr_go_print_text_A_const_36 any

var A_arbace_repr_go_print_text_A_const_37 *lang.Var

var A_arbace_repr_go_print_text_A_const_38 *lang.Var

var A_arbace_repr_go_print_text_A_const_39 *lang.Var

var A_arbace_repr_go_print_text_A_const_40 *lang.Var

var A_arbace_repr_go_print_text_A_const_41 any

var A_arbace_repr_go_print_text_A_const_42 any

var A_arbace_repr_go_print_text_A_const_43 *lang.Var

var A_arbace_repr_go_print_text_A_const_44 *lang.Var

var A_arbace_repr_go_print_text_A_const_45 *lang.Var

var A_arbace_repr_go_print_text_A_const_46 any

var A_arbace_repr_go_print_text_A_const_47 any

var A_arbace_repr_go_print_text_A_const_48 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_49 any

var A_arbace_repr_go_print_text_A_const_50 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_51 *lang.Var

var A_arbace_repr_go_print_text_A_const_52 *lang.Var

var A_arbace_repr_go_print_text_A_const_53 *lang.Var

var A_arbace_repr_go_print_text_A_const_54 *lang.Var

var A_arbace_repr_go_print_text_A_const_55 *lang.Var

var A_arbace_repr_go_print_text_A_const_56 *lang.Var

var A_arbace_repr_go_print_text_A_const_57 *lang.Var

var A_arbace_repr_go_print_text_A_const_58 *lang.Var

var A_arbace_repr_go_print_text_A_const_59 *lang.Var

var A_arbace_repr_go_print_text_A_const_60 *lang.Var

var A_arbace_repr_go_print_text_A_const_61 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_62 *lang.Var

var A_arbace_repr_go_print_text_A_const_63 *lang.Var

var A_arbace_repr_go_print_text_A_const_64 any

var A_arbace_repr_go_print_text_A_const_65 any

var A_arbace_repr_go_print_text_A_const_66 any

var A_arbace_repr_go_print_text_A_const_67 any

var A_arbace_repr_go_print_text_A_const_68 any

var A_arbace_repr_go_print_text_A_const_69 any

var A_arbace_repr_go_print_text_A_const_70 any

var A_arbace_repr_go_print_text_A_const_71 any

var A_arbace_repr_go_print_text_A_const_72 any

var A_arbace_repr_go_print_text_A_const_73 any

var A_arbace_repr_go_print_text_A_const_74 any

var A_arbace_repr_go_print_text_A_const_75 any

var A_arbace_repr_go_print_text_A_const_76 *lang.Var

var A_arbace_repr_go_print_text_A_const_77 *lang.Var

var A_arbace_repr_go_print_text_A_const_78 *lang.Var

var A_arbace_repr_go_print_text_A_const_79 *lang.Var

var A_arbace_repr_go_print_text_A_const_80 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_81 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_82 *lang.Var

var A_arbace_repr_go_print_text_A_const_83 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_84 *lang.Var

var A_arbace_repr_go_print_text_A_const_85 *lang.Var

var A_arbace_repr_go_print_text_A_const_86 *lang.Var

var A_arbace_repr_go_print_text_A_const_87 *lang.Var

var A_arbace_repr_go_print_text_A_const_88 *lang.Var

var A_arbace_repr_go_print_text_A_const_89 *lang.Var

var A_arbace_repr_go_print_text_A_const_90 any

var A_arbace_repr_go_print_text_A_const_91 any

var A_arbace_repr_go_print_text_A_const_92 any

var A_arbace_repr_go_print_text_A_const_93 *lang.Var

var A_arbace_repr_go_print_text_A_const_94 *lang.Var

var A_arbace_repr_go_print_text_A_const_95 *lang.Var

var A_arbace_repr_go_print_text_A_const_96 *lang.Var

var A_arbace_repr_go_print_text_A_const_97 *lang.Var

var A_arbace_repr_go_print_text_A_const_98 any

var A_arbace_repr_go_print_text_A_const_99 *lang.Var

var A_arbace_repr_go_print_text_A_const_100 *lang.Var

var A_arbace_repr_go_print_text_A_const_101 *lang.Var

var A_arbace_repr_go_print_text_A_const_102 *lang.Var

var A_arbace_repr_go_print_text_A_const_103 *lang.Var

var A_arbace_repr_go_print_text_A_const_104 *lang.Var

var A_arbace_repr_go_print_text_A_const_105 *lang.Var

var A_arbace_repr_go_print_text_A_const_106 *lang.Var

var A_arbace_repr_go_print_text_A_init jrt.ClassInit

func A_arbace_repr_go_print_text_A_Init() { if !A_arbace_repr_go_print_text_A_init.Done() { A_arbace_repr_go_print_text_A_init.Run(A_arbace_repr_go_print_text_A_clinit) } }

func A_arbace_repr_go_print_text_A_clinit() { A_arbace_repr_go_print_text_A_clinit_p0(); A_arbace_repr_go_print_text_A_clinit_p1(); A_arbace_repr_go_print_text_A_clinit_p2(); A_arbace_repr_go_print_text_A_clinit_p3(); A_arbace_repr_go_print_text_A_clinit_p4(); A_arbace_repr_go_print_text_A_clinit_p5(); A_arbace_repr_go_print_text_A_clinit_p6(); A_arbace_repr_go_print_text_A_clinit_p7(); A_arbace_repr_go_print_text_A_clinit_p8() }

func A_arbace_repr_go_print_text_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_print_text_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 120); A_arbace_repr_go_print_text_A_const_0 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[13]); A_arbace_repr_go_print_text_A_const_1 = A_arbace_repr_go_print_text_A_const_pool.A[14]; A_arbace_repr_go_print_text_A_const_2 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[15]); A_arbace_repr_go_print_text_A_const_3 = A_arbace_repr_go_print_text_A_const_pool.A[16]; A_arbace_repr_go_print_text_A_const_4 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[17]); A_arbace_repr_go_print_text_A_const_5 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[18]); A_arbace_repr_go_print_text_A_const_6 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[19]); A_arbace_repr_go_print_text_A_const_7 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[20]); A_arbace_repr_go_print_text_A_const_8 = A_arbace_repr_go_print_text_A_const_pool.A[21]; A_arbace_repr_go_print_text_A_const_9 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[22]); A_arbace_repr_go_print_text_A_const_10 = A_arbace_repr_go_print_text_A_const_pool.A[23]; A_arbace_repr_go_print_text_A_const_11 = A_arbace_repr_go_print_text_A_const_pool.A[24] }

func A_arbace_repr_go_print_text_A_clinit_p1() { A_arbace_repr_go_print_text_A_const_12 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[25]); A_arbace_repr_go_print_text_A_const_13 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[26]); A_arbace_repr_go_print_text_A_const_14 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[27]); A_arbace_repr_go_print_text_A_const_15 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[28]); A_arbace_repr_go_print_text_A_const_16 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[29]); A_arbace_repr_go_print_text_A_const_17 = A_arbace_repr_go_print_text_A_const_pool.A[30]; A_arbace_repr_go_print_text_A_const_18 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[31]); A_arbace_repr_go_print_text_A_const_19 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[32]); A_arbace_repr_go_print_text_A_const_20 = A_arbace_repr_go_print_text_A_const_pool.A[33]; A_arbace_repr_go_print_text_A_const_21 = A_arbace_repr_go_print_text_A_const_pool.A[34]; A_arbace_repr_go_print_text_A_const_22 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[35]); A_arbace_repr_go_print_text_A_const_23 = A_arbace_repr_go_print_text_A_const_pool.A[36]; A_arbace_repr_go_print_text_A_const_24 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[37]) }

func A_arbace_repr_go_print_text_A_clinit_p2() { A_arbace_repr_go_print_text_A_const_25 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[38]); A_arbace_repr_go_print_text_A_const_26 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[39]); A_arbace_repr_go_print_text_A_const_27 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[40]); A_arbace_repr_go_print_text_A_const_28 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[41]); A_arbace_repr_go_print_text_A_const_29 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[42]); A_arbace_repr_go_print_text_A_const_30 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[43]); A_arbace_repr_go_print_text_A_const_31 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[44]); A_arbace_repr_go_print_text_A_const_32 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[45]); A_arbace_repr_go_print_text_A_const_33 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[46]); A_arbace_repr_go_print_text_A_const_34 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[47]); A_arbace_repr_go_print_text_A_const_35 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[48]); A_arbace_repr_go_print_text_A_const_36 = A_arbace_repr_go_print_text_A_const_pool.A[49] }

func A_arbace_repr_go_print_text_A_clinit_p3() { A_arbace_repr_go_print_text_A_const_37 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[50]); A_arbace_repr_go_print_text_A_const_38 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[51]); A_arbace_repr_go_print_text_A_const_39 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[52]); A_arbace_repr_go_print_text_A_const_40 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[53]); A_arbace_repr_go_print_text_A_const_41 = A_arbace_repr_go_print_text_A_const_pool.A[54]; A_arbace_repr_go_print_text_A_const_42 = A_arbace_repr_go_print_text_A_const_pool.A[55]; A_arbace_repr_go_print_text_A_const_43 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[56]); A_arbace_repr_go_print_text_A_const_44 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[57]); A_arbace_repr_go_print_text_A_const_45 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[58]); A_arbace_repr_go_print_text_A_const_46 = A_arbace_repr_go_print_text_A_const_pool.A[59]; A_arbace_repr_go_print_text_A_const_47 = A_arbace_repr_go_print_text_A_const_pool.A[60]; A_arbace_repr_go_print_text_A_const_48 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[61]); A_arbace_repr_go_print_text_A_const_49 = A_arbace_repr_go_print_text_A_const_pool.A[62] }

func A_arbace_repr_go_print_text_A_clinit_p4() { A_arbace_repr_go_print_text_A_const_50 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[63]); A_arbace_repr_go_print_text_A_const_51 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[64]); A_arbace_repr_go_print_text_A_const_52 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[65]); A_arbace_repr_go_print_text_A_const_53 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[66]); A_arbace_repr_go_print_text_A_const_54 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[67]); A_arbace_repr_go_print_text_A_const_55 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[68]); A_arbace_repr_go_print_text_A_const_56 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[69]); A_arbace_repr_go_print_text_A_const_57 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[70]); A_arbace_repr_go_print_text_A_const_58 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[71]); A_arbace_repr_go_print_text_A_const_59 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[72]); A_arbace_repr_go_print_text_A_const_60 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[73]); A_arbace_repr_go_print_text_A_const_61 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[74]) }

func A_arbace_repr_go_print_text_A_clinit_p5() { A_arbace_repr_go_print_text_A_const_62 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[75]); A_arbace_repr_go_print_text_A_const_63 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[76]); A_arbace_repr_go_print_text_A_const_64 = A_arbace_repr_go_print_text_A_const_pool.A[77]; A_arbace_repr_go_print_text_A_const_65 = A_arbace_repr_go_print_text_A_const_pool.A[78]; A_arbace_repr_go_print_text_A_const_66 = A_arbace_repr_go_print_text_A_const_pool.A[79]; A_arbace_repr_go_print_text_A_const_67 = A_arbace_repr_go_print_text_A_const_pool.A[80]; A_arbace_repr_go_print_text_A_const_68 = A_arbace_repr_go_print_text_A_const_pool.A[81]; A_arbace_repr_go_print_text_A_const_69 = A_arbace_repr_go_print_text_A_const_pool.A[82]; A_arbace_repr_go_print_text_A_const_70 = A_arbace_repr_go_print_text_A_const_pool.A[83]; A_arbace_repr_go_print_text_A_const_71 = A_arbace_repr_go_print_text_A_const_pool.A[84]; A_arbace_repr_go_print_text_A_const_72 = A_arbace_repr_go_print_text_A_const_pool.A[85]; A_arbace_repr_go_print_text_A_const_73 = A_arbace_repr_go_print_text_A_const_pool.A[86]; A_arbace_repr_go_print_text_A_const_74 = A_arbace_repr_go_print_text_A_const_pool.A[87]; A_arbace_repr_go_print_text_A_const_75 = A_arbace_repr_go_print_text_A_const_pool.A[88]; A_arbace_repr_go_print_text_A_const_76 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[89]) }

func A_arbace_repr_go_print_text_A_clinit_p6() { A_arbace_repr_go_print_text_A_const_77 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[90]); A_arbace_repr_go_print_text_A_const_78 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[91]); A_arbace_repr_go_print_text_A_const_79 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[92]); A_arbace_repr_go_print_text_A_const_80 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[93]); A_arbace_repr_go_print_text_A_const_81 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[94]); A_arbace_repr_go_print_text_A_const_82 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[95]); A_arbace_repr_go_print_text_A_const_83 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[96]); A_arbace_repr_go_print_text_A_const_84 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[97]); A_arbace_repr_go_print_text_A_const_85 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[98]); A_arbace_repr_go_print_text_A_const_86 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[99]); A_arbace_repr_go_print_text_A_const_87 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[100]); A_arbace_repr_go_print_text_A_const_88 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[101]) }

func A_arbace_repr_go_print_text_A_clinit_p7() { A_arbace_repr_go_print_text_A_const_89 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[102]); A_arbace_repr_go_print_text_A_const_90 = A_arbace_repr_go_print_text_A_const_pool.A[103]; A_arbace_repr_go_print_text_A_const_91 = A_arbace_repr_go_print_text_A_const_pool.A[104]; A_arbace_repr_go_print_text_A_const_92 = A_arbace_repr_go_print_text_A_const_pool.A[105]; A_arbace_repr_go_print_text_A_const_93 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[106]); A_arbace_repr_go_print_text_A_const_94 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[107]); A_arbace_repr_go_print_text_A_const_95 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[108]); A_arbace_repr_go_print_text_A_const_96 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[109]); A_arbace_repr_go_print_text_A_const_97 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[110]); A_arbace_repr_go_print_text_A_const_98 = A_arbace_repr_go_print_text_A_const_pool.A[111]; A_arbace_repr_go_print_text_A_const_99 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[112]); A_arbace_repr_go_print_text_A_const_100 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[113]); A_arbace_repr_go_print_text_A_const_101 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[114]) }

func A_arbace_repr_go_print_text_A_clinit_p8() { A_arbace_repr_go_print_text_A_const_102 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[115]); A_arbace_repr_go_print_text_A_const_103 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[116]); A_arbace_repr_go_print_text_A_const_104 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[117]); A_arbace_repr_go_print_text_A_const_105 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[118]); A_arbace_repr_go_print_text_A_const_106 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[119]) }

func A_arbace_repr_go_print_text_A_New() *A_arbace_repr_go_print_text_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_text_A) Ctor() {}

func (t *A_arbace_repr_go_print_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_text_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_text_A_class }

func (t *A_arbace_repr_go_print_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_text_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_text_A); return ok }

func A_arbace_repr_go_print_text_A_Cast(x any) *A_arbace_repr_go_print_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_text_A_class)) }; return v }



type A_arbace_repr_go_print_text_align_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_align_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_align_fn__1242000080_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_align_fn__1242000080_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_align_block_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_align_block_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_cell_width_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_cell_width_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_code_points_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_code_points_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_escape_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_escape_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_escape_cp_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_escape_cp_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_eval1242000004_A struct{ jrt.Object }

func A_arbace_repr_go_print_text_eval1242000004_A_New() *A_arbace_repr_go_print_text_eval1242000004_A { t := &A_arbace_repr_go_print_text_eval1242000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) Ctor() {}

func (t *A_arbace_repr_go_print_text_eval1242000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_text_eval1242000004_A_class }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_text_eval1242000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_text_eval1242000004_A); return ok }

func A_arbace_repr_go_print_text_eval1242000004_A_Cast(x any) *A_arbace_repr_go_print_text_eval1242000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_text_eval1242000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_text_eval1242000004_A_class)) }; return v }



type A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_eval1242000008_A struct{ jrt.Object }

func A_arbace_repr_go_print_text_eval1242000008_A_New() *A_arbace_repr_go_print_text_eval1242000008_A { t := &A_arbace_repr_go_print_text_eval1242000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) Ctor() {}

func (t *A_arbace_repr_go_print_text_eval1242000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_text_eval1242000008_A_class }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_text_eval1242000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_text_eval1242000008_A); return ok }

func A_arbace_repr_go_print_text_eval1242000008_A_Cast(x any) *A_arbace_repr_go_print_text_eval1242000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_text_eval1242000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_text_eval1242000008_A_class)) }; return v }



type A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_float_kind_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_float_kind_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_format_block_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_format_block_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_format_block_fn__1242000075_A struct{ j2g_header uint64; F_column int32; F_this, F_line1, F_lines any }

var A_arbace_repr_go_print_text_format_block_fn__1242000075_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_byte_string_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_byte_string_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_float_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_float_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_number_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_number_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_printable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_printable_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_rune_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_rune_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_string_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_string_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_hex_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_hex_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_negative_number_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_negative_number_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_parse_lines_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A struct{ j2g_header uint64; F_s__1242000052, F_iter__1242000051 any }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A struct{ j2g_header uint64; F_b__1242000054 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A struct{ j2g_header uint64; F_n int32; F_line any }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A struct{ j2g_header uint64; F_n int32; F_line any }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_pow2_exponent_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_pow2_exponent_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_raw_string_ok_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_raw_string_ok_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_strip_2_5_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_strip_2_5_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_unescape_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_unescape_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_write_lines_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_write_lines_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_write_padding_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_write_padding_A_fn_class *jrt.Class
