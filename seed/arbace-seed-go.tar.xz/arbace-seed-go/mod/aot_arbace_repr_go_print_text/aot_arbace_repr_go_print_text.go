//line aot_arbace_repr_go_print_text.ae:1
package aot_arbace_repr_go_print_text

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A_New() *A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_text_A_const_2); lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_text_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A_New() *A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_text_A_const_8), A_arbace_repr_go_print_text_A_const_6.GetRawRoot__O(), A_arbace_repr_go_print_text_A_const_7) }
































func A_arbace_repr_go_print_text_go_printable_QMARK__A_New() *A_arbace_repr_go_print_text_go_printable_QMARK__A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_printable_QMARK__A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_repr_go_print_text_go_printable_QMARK__A) Ctor() {}
//line :34:1
func (t *A_arbace_repr_go_print_text_go_printable_QMARK__A) Invoke_O_O__O(self, p_cp__0 any) any { var cp__0 int64 = lang.RT_LongCast_O__J_NoInit(p_cp__0); var or__1927000174__auto____2 bool = lang.Numbers_Equiv_J_J__Z_NoInit(cp__0, 32); if or__1927000174__auto____2 {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_9.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_text_A_const_11; var or__1927000174__auto____3 any = tmp1.Invoke_O_O_O__O(tmp2, jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref(), A_arbace_repr_go_print_text_A_const_12); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else {

		return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_10.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_text_A_const_13.GetRawRoot__O(), jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_IntCast_I__I_NoInit(jrt.Character_GetType_I__I_NoInit(lang.RT_IntCast_J__I_NoInit(cp__0)))).Ref()) } } }

func A_arbace_repr_go_print_text_hex_A_New() *A_arbace_repr_go_print_text_hex_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_hex_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_repr_go_print_text_hex_A) Ctor() {}
//line :42:1
func (t *A_arbace_repr_go_print_text_hex_A) Invoke_O_O_O__O(self, p_n__0, p_width__1 any) any { var n__0 int64 = lang.RT_LongCast_O__J_NoInit(p_n__0); var width__1 int64 = lang.RT_LongCast_O__J_NoInit(p_width__1); var s__3 any = jrt.Long_ToHexString_J__String_NoInit(n__0).Ref(); return /*line :44:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_text_A_const_15.GetRawRoot__O(), lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_16.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(width__1, int64(lang.RT_Count_O__I_NoInit(s__3)))).Ref(), A_arbace_repr_go_print_text_A_const_17)), s__3)).Ref() }

func A_arbace_repr_go_print_text_escape_cp_A_New() *A_arbace_repr_go_print_text_escape_cp_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_escape_cp_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_repr_go_print_text_escape_cp_A) Ctor() {}
//line :46:1
func (t *A_arbace_repr_go_print_text_escape_cp_A) Invoke_O_O_O__O(self, p_cp__0, quote__1 any) any { var cp__0 int64 = lang.RT_LongCast_O__J_NoInit(p_cp__0); var G__1242000014__3_ int32 = lang.RT_IntCast_J__I_NoInit(cp__0); switch G__1242000014__3_ {


case 7: return Lit_4; case 8: return Lit_5; case 9: return Lit_6; case 10: return Lit_7; case 11: return Lit_8; case 12: return Lit_9; case 13: return Lit_10; case 92: return Lit_11; default:}; if

	lang.Numbers_Equiv_J_J__Z_NoInit(cp__0, lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(quote__1))) {
		return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, quote__1)).Ref() } else {
//line :51:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_18.GetRawRoot__O()).Invoke_O__O(jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref())) { return jrt.String_New_C1(jrt.Character_ToChars_I__C1_NoInit(lang.RT_IntCast_J__I_NoInit(cp__0))) } else { if lang.Numbers_Lt_J_J__Z_NoInit(cp__0, 128) {


				return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref(), A_arbace_repr_go_print_text_A_const_21))).Ref() } else {
//line :51:1
					if lang.Numbers_Lte_J_J__Z_NoInit(cp__0, 65535) {



						return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref(), A_arbace_repr_go_print_text_A_const_22))).Ref() } else {
//line :51:1
							if A_arbace_repr_go_print_text_A_const_20 != nil {




								return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref(), A_arbace_repr_go_print_text_A_const_23))).Ref() } else {
//line :51:1
									return nil } } } } } }






func A_arbace_repr_go_print_text_code_points_A_New() *A_arbace_repr_go_print_text_code_points_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_code_points_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_repr_go_print_text_code_points_A) Ctor() {}
//line :58:1
func (t *A_arbace_repr_go_print_text_code_points_A) Invoke_O_O__O(self, s__0 any) any { { var i__2 int64 = 0; var acc__3 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.PersistentVector_EMPTY.Ref()); L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i__2, int64(jrt.NN(jrt.String_Cast(s__0)).Length__I())) { var cp__4 int32 = jrt.NN(jrt.String_Cast(s__0)).CodePointAt_I__I(lang.RT_IntCast_J__I_NoInit(i__2)); var tmp1 bool; var and__1927000168__auto____5 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(cp__4), 55296)

		if and__1927000168__auto____5 { tmp1 = lang.Numbers_Lte_J_J__Z_NoInit(int64(cp__4), 57343) } else { tmp1 = and__1927000168__auto____5 }; if tmp1 { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(s__0))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_28, s__0))))))
		}
		i__2, acc__3 = lang.Numbers_Add_J_J__J_NoInit(i__2, int64(jrt.Character_CharCount_I__I_NoInit(cp__4))), lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O()).Invoke_O_O__O(acc__3, jrt.Integer_ValueOf_I__Integer_NoInit(cp__4).Ref()); continue L1 } else {
			return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_25.GetRawRoot__O()).Invoke_O__O(acc__3) } } }; /*line :58:1*/panic("j2g: unreachable") }











func A_arbace_repr_go_print_text_go_string_A_New() *A_arbace_repr_go_print_text_go_string_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_string_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_repr_go_print_text_go_string_A) Ctor() {}
//line :70:1
func (t *A_arbace_repr_go_print_text_go_string_A) Invoke_O_O__O(self, s__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_23); var seq_1242000017__3 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O()).Invoke_O__O(s__0)); var chunk_1242000018__4 any; var count_1242000019__5 int64 = 0; var i_1242000020__6 int64 = 0; L1: for {



	if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000020__6, count_1242000019__5) { var cp__7 any = lang.Indexed_Cast(chunk_1242000018__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000020__6))
		jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(cp__7, A_arbace_repr_go_print_text_A_const_36)))
//line :74:1
		seq_1242000017__3, chunk_1242000018__4, count_1242000019__5, i_1242000020__6 = seq_1242000017__3, chunk_1242000018__4, count_1242000019__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000020__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1242000017__3); if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1242000017__8 any = temp__1927000414__auto____7; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1242000017__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1242000017__8); seq_1242000017__3, chunk_1242000018__4, count_1242000019__5, i_1242000020__6 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1242000017__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var cp__9 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1242000017__8)
			jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(cp__9, A_arbace_repr_go_print_text_A_const_36)))
//line :74:1
			seq_1242000017__3, chunk_1242000018__4, count_1242000019__5, i_1242000020__6 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1242000017__8), nil, 0, 0; continue L1 } } }
//line :70:1
	break L1 };





	jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_23); return /*line :77:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_repr_go_print_text_raw_string_ok_QMARK__A_New() *A_arbace_repr_go_print_text_raw_string_ok_QMARK__A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_raw_string_ok_QMARK__A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_repr_go_print_text_raw_string_ok_QMARK__A) Ctor() {}
//line :79:1
func (t *A_arbace_repr_go_print_text_raw_string_ok_QMARK__A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O()).Invoke_O__O(s__0)) }
//line :83:1
func A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_New() *A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A) Ctor() {}
//line :83:1
func (t *A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A) Invoke_O_O__O(self, cp__1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(cp__1, A_arbace_repr_go_print_text_A_const_41); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(cp__1, A_arbace_repr_go_print_text_A_const_42); if jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool; var na_2 any = cp__1; var na_3 int64 = 9
														if jrt.Long_InstanceOf(na_2) { var n0_4 int64 = jrt.NN(jrt.Long_Cast(na_2)).LongValue__J(); var n1_5 int64 = na_3; or__1927000174__auto____4 = n0_4 == n1_5 } else { or__1927000174__auto____4 = lang.Numbers_Equiv_O_J__Z_NoInit(na_2, na_3) }; if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 bool; var na_7 any = cp__1; var na_8 int64 = 10; if jrt.Long_InstanceOf(na_7) { var n0_9 int64 = jrt.NN(jrt.Long_Cast(na_7)).LongValue__J(); var n1_10 int64 = na_8; or__1927000174__auto____5 = n0_9 == n1_10 } else { or__1927000174__auto____5 = lang.Numbers_Equiv_O_J__Z_NoInit(na_7, na_8) }; if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_18.GetRawRoot__O()).Invoke_O__O(cp__1) } } } else {
//line :83:1
		return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }



func A_arbace_repr_go_print_text_go_byte_string_A_New() *A_arbace_repr_go_print_text_go_byte_string_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_byte_string_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_repr_go_print_text_go_byte_string_A) Ctor() {}
//line :87:1
func (t *A_arbace_repr_go_print_text_go_byte_string_A) Invoke_O_O__O(self, parts__0 any) any { var sb__2 any = jrt.StringBuilder_New_String(Lit_23); var seq_1242000025__3 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(parts__0); var chunk_1242000026__4 any; var count_1242000027__5 int64 = 0; var i_1242000028__6 int64 = 0; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000028__6, count_1242000027__5) { var p__7 any = lang.Indexed_Cast(chunk_1242000026__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000028__6))
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_43.GetRawRoot__O()).Invoke_O__O(p__7)) { var seq_1242000029__8 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O()).Invoke_O__O(p__7)); var chunk_1242000030__9 any; var count_1242000031__10 int64 = 0; var i_1242000032__11 int64 = 0; L2: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000032__11, count_1242000031__10) { var cp__12 any = lang.Indexed_Cast(chunk_1242000030__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000032__11)); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(cp__12, A_arbace_repr_go_print_text_A_const_36))); seq_1242000029__8, chunk_1242000030__9, count_1242000031__10, i_1242000032__11 = seq_1242000029__8, chunk_1242000030__9, count_1242000031__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000032__11); continue L2 } else { var temp__1927000414__auto____12 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1242000029__8); if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1242000029__13 any = temp__1927000414__auto____12; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1242000029__13)) { var c__1927000678__auto____14 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1242000029__13); seq_1242000029__8, chunk_1242000030__9, count_1242000031__10, i_1242000032__11 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1242000029__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var cp__14 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1242000029__13); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(cp__14, A_arbace_repr_go_print_text_A_const_36))); seq_1242000029__8, chunk_1242000030__9, count_1242000031__10, i_1242000032__11 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1242000029__13), nil, 0, 0; continue L2 } } }
//line :93:1
			break L2 } } else { var tmp1 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_44.GetRawRoot__O()).Invoke_O__O(p__7)

				if jrt.J2g_Truth(and__1927000168__auto____8) { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_45.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_text_A_const_46, p__7, A_arbace_repr_go_print_text_A_const_47) } else { tmp1 = and__1927000168__auto____8 }
//line :93:1
				if jrt.J2g_Truth(tmp1) {

					jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__7)).Ref(), A_arbace_repr_go_print_text_A_const_21)))) } else {
//line :93:1
						if A_arbace_repr_go_print_text_A_const_20 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(p__7))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_48, p__7)))))) } } }
//line :92:1
		seq_1242000025__3, chunk_1242000026__4, count_1242000027__5, i_1242000028__6 = seq_1242000025__3, chunk_1242000026__4, count_1242000027__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000028__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1242000025__3); if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1242000025__8 any = temp__1927000414__auto____7; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1242000025__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1242000025__8); seq_1242000025__3, chunk_1242000026__4, count_1242000027__5, i_1242000028__6 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1242000025__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var p__9 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1242000025__8)
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_43.GetRawRoot__O()).Invoke_O__O(p__9)) { var seq_1242000033__10 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_34.GetRawRoot__O()).Invoke_O__O(p__9)); var chunk_1242000034__11 any; var count_1242000035__12 int64 = 0; var i_1242000036__13 int64 = 0; L3: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000036__13, count_1242000035__12) { var cp__14_2 any = lang.Indexed_Cast(chunk_1242000034__11).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000036__13)); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(cp__14_2, A_arbace_repr_go_print_text_A_const_36))); seq_1242000033__10, chunk_1242000034__11, count_1242000035__12, i_1242000036__13 = seq_1242000033__10, chunk_1242000034__11, count_1242000035__12, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000036__13); continue L3 } else { var temp__1927000414__auto____14 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1242000033__10); if jrt.J2g_Truth(temp__1927000414__auto____14) { var seq_1242000033__15 any = temp__1927000414__auto____14; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1242000033__15)) { var c__1927000678__auto____16 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1242000033__15); seq_1242000033__10, chunk_1242000034__11, count_1242000035__12, i_1242000036__13 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1242000033__15), c__1927000678__auto____16, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var cp__16 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1242000033__15); jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(cp__16, A_arbace_repr_go_print_text_A_const_36))); seq_1242000033__10, chunk_1242000034__11, count_1242000035__12, i_1242000036__13 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1242000033__15), nil, 0, 0; continue L3 } } }
//line :93:1
				break L3 } } else { var tmp2 any; var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_44.GetRawRoot__O()).Invoke_O__O(p__9)

					if jrt.J2g_Truth(and__1927000168__auto____10) { tmp2 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_45.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_repr_go_print_text_A_const_46, p__9, A_arbace_repr_go_print_text_A_const_47) } else { tmp2 = and__1927000168__auto____10 }
//line :93:1
					if jrt.J2g_Truth(tmp2) {

						jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_13, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_19.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(p__9)).Ref(), A_arbace_repr_go_print_text_A_const_21)))) } else {
//line :93:1
							if A_arbace_repr_go_print_text_A_const_20 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_24, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(p__9))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_48, p__9)))))) } } }
//line :92:1
			seq_1242000025__3, chunk_1242000026__4, count_1242000027__5, i_1242000028__6 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1242000025__8), nil, 0, 0; continue L1 } } }
//line :87:1
	break L1 };









	jrt.NN(jrt.StringBuilder_Cast(sb__2)).Append_String__StringBuilder(Lit_23); return /*line :98:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_repr_go_print_text_go_rune_A_New() *A_arbace_repr_go_print_text_go_rune_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_rune_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_repr_go_print_text_go_rune_A) Ctor() {}
//line :100:1
func (t *A_arbace_repr_go_print_text_go_rune_A) Invoke_O_O__O(self, p_cp__0 any) any { var cp__0 int64 = lang.RT_LongCast_O__J_NoInit(p_cp__0); var tmp1 bool; var or__1927000174__auto____2 bool = lang.Numbers_IsNeg_J__Z_NoInit(cp__0); if or__1927000174__auto____2 {


	tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = lang.Numbers_Gt_J_J__Z_NoInit(cp__0, 1114111); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var and__1927000168__auto____4 bool = lang.Numbers_Gte_J_J__Z_NoInit(cp__0, 55296); if and__1927000168__auto____4 { tmp1 = lang.Numbers_Lte_J_J__Z_NoInit(cp__0, 57343) } else { tmp1 = and__1927000168__auto____4 } } }; if tmp1 { var tmp2 any = A_arbace_repr_go_print_text_A_const_49; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_31, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref())).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref())))))) }; return /*line :105:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_32, nil, Lit_32), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(cp__0).Ref(), A_arbace_repr_go_print_text_A_const_50), nil)).Ref() }

func A_arbace_repr_go_print_text_float_kind_A_New() *A_arbace_repr_go_print_text_float_kind_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_float_kind_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_repr_go_print_text_float_kind_A) Ctor() {}
//line :107:1
func (t *A_arbace_repr_go_print_text_float_kind_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_51.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_18); if jrt.J2g_Truth(or__1927000174__auto____2) { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_51.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_19); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_51.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_20) } }; if jrt.J2g_Truth(tmp1) { return s__0 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_21), jrt.RefArrayOf(jrt.Object_class, s__0, nil)).Ref()
	} }
func A_arbace_repr_go_print_text_pow2_exponent_A_New() *A_arbace_repr_go_print_text_pow2_exponent_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_pow2_exponent_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_repr_go_print_text_pow2_exponent_A) Ctor() {}
//line :113:1
func (t *A_arbace_repr_go_print_text_pow2_exponent_A) Invoke_O_O__O(self, n__0 any) any {


	var tmp1 bool; var and__1927000168__auto____2 bool = lang.Numbers_IsPos_J__Z_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(n__0)).Signum__I())); if and__1927000168__auto____2 { tmp1 = lang.Numbers_Equiv_J_J__Z_NoInit(1, int64(jrt.NN(jrt.BigInteger_Cast(n__0)).BitCount__I())) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Dec_J__J_NoInit(int64(jrt.NN(jrt.BigInteger_Cast(n__0)).BitLength__I()))).Ref() } else { return nil
	} }
func A_arbace_repr_go_print_text_strip_2_5_A_New() *A_arbace_repr_go_print_text_strip_2_5_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_strip_2_5_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_repr_go_print_text_strip_2_5_A) Ctor() {}
//line :118:1
func (t *A_arbace_repr_go_print_text_strip_2_5_A) Invoke_O_O__O(self, n__0 any) any { { var five__2 any = jrt.BigInteger_ValueOf_J__BigInteger(5).Ref(); var n__3 any = n__0; var a__4 int64 = 0; var b__5 int64 = 0; L1: for {




	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_52.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.BigInteger_Cast(n__3)).TestBit_I__Z(lang.RT_IntCast_J__I_NoInit(0))).Ref())) {
		n__3, a__4, b__5 = jrt.NN(jrt.BigInteger_Cast(n__3)).ShiftRight_I__BigInteger(lang.RT_IntCast_J__I_NoInit(1)).Ref(), lang.Numbers_Inc_J__J_NoInit(a__4), b__5; continue L1 } else {
//line :123:1
			if lang.Numbers_IsZero_J__Z_NoInit(int64(jrt.NN(jrt.NN(jrt.BigInteger_Cast(n__3)).Mod_BigInteger__BigInteger(jrt.BigInteger_Cast(five__2))).Signum__I())) {

				n__3, a__4, b__5 = jrt.NN(jrt.BigInteger_Cast(n__3)).Divide_BigInteger__BigInteger(jrt.BigInteger_Cast(five__2)).Ref(), a__4, lang.Numbers_Inc_J__J_NoInit(b__5); continue L1 } else {
//line :123:1
					if A_arbace_repr_go_print_text_A_const_20 != nil { return lang.Tuple_Create_O_O_O__IPersistentVector(n__3, jrt.Long_ValueOf_J__Long_NoInit(a__4).Ref(), jrt.Long_ValueOf_J__Long_NoInit(b__5).Ref()) } else { return nil } } } } }; /*line :118:1*/panic("j2g: unreachable") }









func A_arbace_repr_go_print_text_go_float_A_New() *A_arbace_repr_go_print_text_go_float_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_float_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_repr_go_print_text_go_float_A) Ctor() {}
//line :128:1
func (t *A_arbace_repr_go_print_text_go_float_A) Invoke_O_O__O(self, x__0 any) any {




	if jrt.Double_InstanceOf(x__0) { var d__2 float64 = lang.RT_DoubleCast_O__D_NoInit(x__0); var tmp1 bool; var or__1927000174__auto____3 bool = jrt.Double_IsNaN_D__Z_NoInit(d__2)


		if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = jrt.Double_IsInfinite_D__Z_NoInit(d__2) }; if tmp1 { var tmp2 any = A_arbace_repr_go_print_text_A_const_59; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.Double_ValueOf_D__Double_NoInit(d__2).Ref())).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.Double_ValueOf_D__Double_NoInit(d__2).Ref()))))))
		}
		return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_53.GetRawRoot__O()).Invoke_O__O(jrt.Double_ToString_D__String_NoInit(d__2).Ref()) } else {
//line :133:1
			if jrt.BigDecimal_InstanceOf(x__0) {





				return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_54.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_53.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.BigDecimal_Cast(x__0)).ToString__String().Ref())) } else {
//line :133:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_55.GetRawRoot__O()).Invoke_O__O(x__0)) { var n__2 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_60.GetRawRoot__O()).Invoke_O__O(x__0)); var d__3 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_61.GetRawRoot__O()).Invoke_O__O(x__0)); var vec__1242000042__4 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_57.GetRawRoot__O()).Invoke_O__O(d__3); var rest__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000042__4, lang.RT_IntCast_J__I_NoInit(0), nil); var a__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000042__4, lang.RT_IntCast_J__I_NoInit(1), nil); var b__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000042__4, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp3 bool; var and__1927000168__auto____8 bool; var tmp4 *jrt.BigInteger










						jrt.BigInteger_Init(); tmp4 = jrt.BigInteger_ONE; and__1927000168__auto____8 = lang.Util_Equiv_O_O__Z_NoInit(rest__5, tmp4.Ref()); if and__1927000168__auto____8 { var na_13 any = lang.Numbers_Max_O_O__O_NoInit(a__6, b__7); var na_14 int64 = 40; if jrt.Long_InstanceOf(na_13) { var n0_15 int64 = jrt.NN(jrt.Long_Cast(na_13)).LongValue__J(); var n1_16 int64 = na_14; tmp3 = n0_15 <= n1_16 } else { tmp3 = lang.Numbers_Lte_O_J__Z_NoInit(na_13, na_14) } } else { tmp3 = and__1927000168__auto____8 }
//line :143:1
						if tmp3 {

							return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_54.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(n__2)).Divide_BigDecimal__BigDecimal(jrt.BigDecimal_New_BigInteger(jrt.BigInteger_Cast(d__3)))).ToPlainString__String().Ref()) } else {
//line :143:1
								if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_58.GetRawRoot__O()).Invoke_O__O(d__3)) {



									return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_26, nil, Lit_27, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.BigInteger_Cast(n__2)).ToString_I__String(lang.RT_IntCast_J__I_NoInit(16)).Ref(), nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_58.GetRawRoot__O()).Invoke_O__O(d__3))).Ref() } else {
//line :143:1
										if A_arbace_repr_go_print_text_A_const_20 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_28, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, nil, x__0, nil)).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_59, x__0)))))) } else { return nil } } } } else {
//line :133:1
											if A_arbace_repr_go_print_text_A_const_20 != nil { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_30, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_27.GetRawRoot__O()).Invoke_O__O(x__0))).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_repr_go_print_text_A_const_59, x__0)))))) } else { return nil
											}
										}
				}
		}
}












func A_arbace_repr_go_print_text_negative_number_QMARK__A_New() *A_arbace_repr_go_print_text_negative_number_QMARK__A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_negative_number_QMARK__A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_repr_go_print_text_negative_number_QMARK__A) Ctor() {}
//line :151:1
func (t *A_arbace_repr_go_print_text_negative_number_QMARK__A) Invoke_O_O__O(self, x__0 any) any {



	if jrt.Double_InstanceOf(x__0) { var or__1927000174__auto____2 bool = lang.Numbers_IsNeg_D__Z_NoInit(lang.RT_DoubleCast_O__D_NoInit(x__0))
		if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____2).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(jrt.Double_DoubleToRawLongBits_D__J_NoInit(lang.RT_DoubleCast_O__D_NoInit(x__0)), -9223372036854775808)).Ref() } } else {
//line :155:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_62.GetRawRoot__O()).Invoke_O__O(x__0)) {


				var tmp1 bool; var na_18 any = x__0; if jrt.Long_InstanceOf(na_18) { var n0_19 int64 = jrt.NN(jrt.Long_Cast(na_18)).LongValue__J(); tmp1 = n0_19 < 0 } else { if jrt.Double_InstanceOf(na_18) { var n0_19_2 float64 = jrt.NN(jrt.Double_Cast(na_18)).DoubleValue__D(); tmp1 = n0_19_2 < 0.0 } else { tmp1 = lang.Numbers_IsNeg_O__Z_NoInit(na_18) } }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp1).Ref() } else {
//line :155:1
					if A_arbace_repr_go_print_text_A_const_20 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
					}
				}
		}
}

func A_arbace_repr_go_print_text_go_number_A_New() *A_arbace_repr_go_print_text_go_number_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_go_number_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_repr_go_print_text_go_number_A) Ctor() {}
//line :161:1
func (t *A_arbace_repr_go_print_text_go_number_A) Invoke_O_O__O(self, x__0 any) any {



	if jrt.Double_InstanceOf(x__0) {
		return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_63.GetRawRoot__O()).Invoke_O__O(jrt.Double_ValueOf_D__Double_NoInit(jrt.Math_Abs_D__D(lang.RT_DoubleCast_O__D_NoInit(x__0))).Ref()) } else {
//line :165:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_44.GetRawRoot__O()).Invoke_O__O(x__0)) {

				return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_15.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :165:1
					if A_arbace_repr_go_print_text_A_const_20 != nil {


						return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_63.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :165:1
							return nil
						}
				}
		}
}



func A_arbace_repr_go_print_text_escape_A_New() *A_arbace_repr_go_print_text_escape_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_escape_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_repr_go_print_text_escape_A) Ctor() {}
//line :173:1
func (t *A_arbace_repr_go_print_text_escape_A) Invoke_O_O__O(self, s__0 any) any {




	return jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.String_Cast(s__0)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_64)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_65)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_66)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_67)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_68)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_69)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_70)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_71)).CharValue__C()).Ref()
}
func A_arbace_repr_go_print_text_unescape_A_New() *A_arbace_repr_go_print_text_unescape_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_unescape_A{}; t.Ctor(); return t }
//line :180:1
func (t *A_arbace_repr_go_print_text_unescape_A) Ctor() {}
//line :180:1
func (t *A_arbace_repr_go_print_text_unescape_A) Invoke_O_O__O(self, s__0 any) any {



	return jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.String_Cast(s__0)).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_72)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_64)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_73)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_66)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_74)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_68)).CharValue__C())).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_75)).CharValue__C(), jrt.NN(jrt.Character_Cast(A_arbace_repr_go_print_text_A_const_70)).CharValue__C()).Ref()
}



func A_arbace_repr_go_print_text_cell_width_A_New() *A_arbace_repr_go_print_text_cell_width_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_cell_width_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_repr_go_print_text_cell_width_A) Ctor() {}
//line :189:1
func (t *A_arbace_repr_go_print_text_cell_width_A) Invoke_O_O__O(self, s__0 any) any { return jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.String_Cast(s__0)).CodePointCount_I_I__I(lang.RT_IntCast_J__I_NoInit(0), jrt.NN(jrt.String_Cast(s__0)).Length__I())).Ref() }



func A_arbace_repr_go_print_text_parse_lines_A_New() *A_arbace_repr_go_print_text_parse_lines_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_repr_go_print_text_parse_lines_A) Ctor() {}
//line :193:1
func (t *A_arbace_repr_go_print_text_parse_lines_A) Invoke_O_O__O(self, text__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_76.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____2 any; var tmp3 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_New(); var tmp4 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_fn_class = fncls__24d; tmp4 = fncls__24d } else { tmp4 = fncls__24 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_89.GetRawRoot__O()).Invoke_O_O_O__O(text__0, A_arbace_repr_go_print_text_A_const_90, A_arbace_repr_go_print_text_A_const_91)); return tmp1.Invoke_O__O(tmp2) }
//line :197:1
func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_New() *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A) Ctor() {}
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A) Invoke_O_O__O(self, s__1242000052__1 any) any { var tmp1 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_New_O_O(s__1242000052__1, self); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :197:1
func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_New_O_O(p0, p1 any) *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A{}; t.Ctor_O_O(p0, p1); return t }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A) Ctor_O_O(c__s__1242000052, c__iter__1242000051 any) { t.F_s__1242000052 = c__s__1242000052; t.F_iter__1242000051 = c__iter__1242000051 }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A) Invoke_O__O(self any) any { { var s__1242000052__1 any; var t_ any = t.F_s__1242000052; t.F_s__1242000052 = nil; s__1242000052__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1242000052__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1242000052__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1242000052__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1242000052__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1242000054__6 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_77.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_New_O_I_O(b__1242000054__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_fn_class = fncls__21d; tmp2 = fncls__21d } else { tmp2 = fncls__21 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1242000051); return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_87.GetRawRoot__O()).Invoke_O__O(b__1242000054__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O()).Invoke_O__O(s__1242000052__3))) } else { return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_87.GetRawRoot__O()).Invoke_O__O(b__1242000054__6), nil) } } else { var line__4 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1242000052__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_86.GetRawRoot__O()); var tmp5 any; var n__5 int32 = jrt.NN(jrt.String_Cast(line__4)).Length__I(); var tmp6 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_New_I_O(n__5, line__4); var tmp7 *jrt.Class
																var fncls__22 /*line :197:1*/*jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_fn_class

	if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_fn_class = fncls__22d; tmp7 = fncls__22d } else { tmp7 = fncls__22 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
//line :197:1
	var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1242000051); return tmp4.Invoke_O_O__O(tmp5, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_88.GetRawRoot__O()).Invoke_O__O(s__1242000052__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :197:1
func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A) Ctor_O_I_O(c__b__1242000054 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1242000054 = c__b__1242000054; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :197:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A) Invoke_O__O(self any) any { { var i__1242000053__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1242000053__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var line__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1242000053__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_78.GetRawRoot__O()); var tmp3 any = t.F_b__1242000054; var tmp4 any; var n__3 int32 = jrt.NN(jrt.String_Cast(line__2)).Length__I(); var tmp5 any = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_New_I_O(n__3, line__2); var tmp6 *jrt.Class
																		var fncls__20 /*line :197:1*/*jrt.Class = A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_fn_class

	if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_fn_class = fncls__20d; tmp6 = fncls__20d } else { tmp6 = fncls__20 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()
//line :197:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__1242000053__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1242000053__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_New_I_O(p0 int32, p1 any) *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A{}; t.Ctor_I_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A) Ctor_I_O(c__n int32, c__line any) { t.F_n = c__n; t.F_line = c__line }
//line :199:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var start__2 int64 = 0; var cells__3 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.PersistentVector_EMPTY.Ref()); L1: for {
																			if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(t.F_n)) { var tmp1 *jrt.String = jrt.String_Cast(t.F_line); var c__4 int32 = lang.RT_IntCast_C__I_NoInit(jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))); var tmp2 bool; var or__1927000174__auto____5 bool = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)

		if or__1927000174__auto____5 { tmp2 = or__1927000174__auto____5 } else { tmp2 = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 11) }; if tmp2 {
			var tmp3 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp4 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O()); var tmp6 any; var tmp7 bool; var and__1927000168__auto____5 bool = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)
			if and__1927000168__auto____5 { tmp7 = lang.Numbers_Equiv_J_J__Z_NoInit(start__2, i__1) } else { tmp7 = and__1927000168__auto____5 }; if tmp7 { tmp6 = A_arbace_repr_go_print_text_A_const_80.GetRawRoot__O() } else { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_79.GetRawRoot__O()); var tmp9 any = t.F_line; var t__5 any = tmp8.Invoke_O_O_O__O(tmp9, jrt.Long_ValueOf_J__Long_NoInit(start__2).Ref(), jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref()); var tmp10 any = A_arbace_repr_go_print_text_A_const_81; var tmp11 any = A_arbace_repr_go_print_text_A_const_82; var tmp12 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_83.GetRawRoot__O()).Invoke_O__O(t__5); var tmp13 any = A_arbace_repr_go_print_text_A_const_84; tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, t__5, tmp11, tmp12, tmp13, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)).Ref())) }
//line :203:1
			i__1, start__2, cells__3 = tmp3, tmp4, tmp5.Invoke_O_O__O(cells__3, tmp6); continue L1 } else {




				i__1, start__2, cells__3 = lang.Numbers_Inc_J__J_NoInit(i__1), start__2, cells__3; continue L1 } } else {
//line :200:1
					var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_79.GetRawRoot__O()); var tmp15 any = t.F_line; var t__4 any = tmp14.Invoke_O_O__O(tmp15, jrt.Long_ValueOf_J__Long_NoInit(start__2).Ref())
					var tmp16 any = A_arbace_repr_go_print_text_A_const_81
					var tmp17 any = A_arbace_repr_go_print_text_A_const_82







					return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O()).Invoke_O_O__O(cells__3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, t__4, tmp17, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_83.GetRawRoot__O()).Invoke_O__O(t__4), A_arbace_repr_go_print_text_A_const_84, jrt.Boolean_FALSE.Ref())))) } } }; /*line :199:1*/panic("j2g: unreachable") }
//line :199:1
func A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_New_I_O(p0 int32, p1 any) *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A{}; t.Ctor_I_O(p0, p1); return t }
//line :199:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A) Ctor_I_O(c__n int32, c__line any) { t.F_n = c__n; t.F_line = c__line }
//line :199:1
func (t *A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A) Invoke_O__O(self any) any { { var i__1 int64 = 0; var start__2 int64 = 0; var cells__3 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.PersistentVector_EMPTY.Ref()); L1: for {
																		if lang.Numbers_Lt_J_J__Z_NoInit(i__1, int64(t.F_n)) { var tmp1 *jrt.String = jrt.String_Cast(t.F_line); var c__4 int32 = lang.RT_IntCast_C__I_NoInit(jrt.NN(tmp1).CharAt_I__C(lang.RT_IntCast_J__I_NoInit(i__1))); var tmp2 bool; var or__1927000174__auto____5 bool = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)

		if or__1927000174__auto____5 { tmp2 = or__1927000174__auto____5 } else { tmp2 = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 11) }; if tmp2 {
			var tmp3 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp4 int64 = lang.Numbers_Inc_J__J_NoInit(i__1); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O()); var tmp6 any; var tmp7 bool; var and__1927000168__auto____5 bool = lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)
			if and__1927000168__auto____5 { tmp7 = lang.Numbers_Equiv_J_J__Z_NoInit(start__2, i__1) } else { tmp7 = and__1927000168__auto____5 }; if tmp7 { tmp6 = A_arbace_repr_go_print_text_A_const_80.GetRawRoot__O() } else { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_79.GetRawRoot__O()); var tmp9 any = t.F_line; var t__5 any = tmp8.Invoke_O_O_O__O(tmp9, jrt.Long_ValueOf_J__Long_NoInit(start__2).Ref(), jrt.Long_ValueOf_J__Long_NoInit(i__1).Ref()); var tmp10 any = A_arbace_repr_go_print_text_A_const_81; var tmp11 any = A_arbace_repr_go_print_text_A_const_82; var tmp12 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_83.GetRawRoot__O()).Invoke_O__O(t__5); var tmp13 any = A_arbace_repr_go_print_text_A_const_84; tmp6 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, t__5, tmp11, tmp12, tmp13, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_Equiv_J_J__Z_NoInit(int64(c__4), 9)).Ref())) }
//line :203:1
			i__1, start__2, cells__3 = tmp3, tmp4, tmp5.Invoke_O_O__O(cells__3, tmp6); continue L1 } else {




				i__1, start__2, cells__3 = lang.Numbers_Inc_J__J_NoInit(i__1), start__2, cells__3; continue L1 } } else {
//line :200:1
					var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_79.GetRawRoot__O()); var tmp15 any = t.F_line; var t__4 any = tmp14.Invoke_O_O__O(tmp15, jrt.Long_ValueOf_J__Long_NoInit(start__2).Ref())
					var tmp16 any = A_arbace_repr_go_print_text_A_const_81
					var tmp17 any = A_arbace_repr_go_print_text_A_const_82







					return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_29.GetRawRoot__O()).Invoke_O_O__O(cells__3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, t__4, tmp17, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_83.GetRawRoot__O()).Invoke_O__O(t__4), A_arbace_repr_go_print_text_A_const_84, jrt.Boolean_FALSE.Ref())))) } } }; /*line :199:1*/panic("j2g: unreachable") }












func A_arbace_repr_go_print_text_write_padding_A_New() *A_arbace_repr_go_print_text_write_padding_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_write_padding_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_repr_go_print_text_write_padding_A) Ctor() {}
//line :212:1
func (t *A_arbace_repr_go_print_text_write_padding_A) Invoke_O_O_O_O_O__O(self, sb__0, p_textw__1, p_cellw__2, use_tabs__3 any) any { { var textw__1 int64 = lang.RT_LongCast_O__J_NoInit(p_textw__1); var cellw__2 int64 = lang.RT_LongCast_O__J_NoInit(p_cellw__2)
																	if jrt.J2g_Truth(use_tabs__3) { var cellw__5 int64 = lang.Numbers_Multiply_J_J__J_NoInit(8, lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(cellw__2, 7), 8)); var n__6 int64 = lang.Numbers_Minus_J_J__J_NoInit(cellw__5, textw__1); var n__1927000701__auto____7 int64 = lang.RT_LongCast_J__J_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(n__6, 7), 8)); var ___8 int64 = 0; L1: for {


		if lang.Numbers_Lt_J_J__Z_NoInit(___8, n__1927000701__auto____7) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_repr_go_print_text_A_const_64); ___8 = lang.Numbers_Unchecked_inc_J__J_NoInit(___8); continue L1 } else { return nil } } } else {
//line :213:1
			var n__1927000701__auto____5 int64 = lang.RT_LongCast_J__J_NoInit(lang.Numbers_Minus_J_J__J_NoInit(cellw__2, textw__1)); var ___6 int64 = 0; L2: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(___6, n__1927000701__auto____5) { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_repr_go_print_text_A_const_92); ___6 = lang.Numbers_Unchecked_inc_J__J_NoInit(___6); continue L2 } else { return nil } } } }; /*line :212:1*/panic("j2g: unreachable") }






func A_arbace_repr_go_print_text_write_lines_A_New() *A_arbace_repr_go_print_text_write_lines_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_write_lines_A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_repr_go_print_text_write_lines_A) Ctor() {}
//line :219:1
func (t *A_arbace_repr_go_print_text_write_lines_A) Invoke_O_O_O_O_O_O__O(self, sb__0, lines__1, widths__2, line0__3, line1__4 any) any { { var seq_1242000067__6 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_93.GetRawRoot__O()).Invoke_O_O__O(line0__3, line1__4)); var chunk_1242000068__7 any; var count_1242000069__8 int64 = 0; var i_1242000070__9 int64 = 0; L1: for {
																	if lang.Numbers_Lt_J_J__Z_NoInit(i_1242000070__9, count_1242000069__8) { var i__10 any = lang.Indexed_Cast(chunk_1242000068__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1242000070__9)); var line__11 any = lang.RT_Nth_O_I__O_NoInit(lines__1, lang.RT_IntCast_O__I_NoInit(i__10)); var nw__12 int32 = lang.RT_Count_O__I_NoInit(widths__2); var j__13 int64 = 0; var use_tabs__14 any = jrt.Boolean_TRUE.Ref(); L2: for {



		if lang.Numbers_Lt_J_J__Z_NoInit(j__13, int64(lang.RT_Count_O__I_NoInit(line__11))) { var c__15 any = lang.RT_Nth_O_I__O_NoInit(line__11, lang.RT_IntCast_J__I_NoInit(j__13))

			if lang.Numbers_IsZero_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__15)))) {
				if lang.Numbers_Lt_J_J__Z_NoInit(j__13, int64(nw__12)) { lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_94.GetRawRoot__O()).Invoke_O_O_O_O__O(sb__0, A_arbace_repr_go_print_text_A_const_82.Invoke_O__O(c__15), lang.RT_Nth_O_I__O_NoInit(widths__2, lang.RT_IntCast_J__I_NoInit(j__13)), use_tabs__14) }
				j__13, use_tabs__14 = lang.Numbers_Inc_J__J_NoInit(j__13), use_tabs__14; continue L2 } else {
					jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_String__StringBuilder(jrt.String_Cast(A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__15)))
					if lang.Numbers_Lt_J_J__Z_NoInit(j__13, int64(nw__12)) { lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_94.GetRawRoot__O()).Invoke_O_O_O_O__O(sb__0, A_arbace_repr_go_print_text_A_const_82.Invoke_O__O(c__15), lang.RT_Nth_O_I__O_NoInit(widths__2, lang.RT_IntCast_J__I_NoInit(j__13)), jrt.Boolean_FALSE.Ref()) }
					j__13, use_tabs__14 = lang.Numbers_Inc_J__J_NoInit(j__13), jrt.Boolean_FALSE.Ref(); continue L2 } }
//line :220:1
		break L2
	}










		var tmp1 bool; var na_25 any; var na_27 any = i__10; if jrt.Long_InstanceOf(na_27) { var n0_28 int64 = jrt.NN(jrt.Long_Cast(na_27)).LongValue__J(); if n0_28 == 9223372036854775807 { na_25 = lang.Numbers_Inc_O__Number_NoInit(na_27) } else { na_25 = jrt.Long_ValueOf_J__Long_NoInit(n0_28 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_27) { var n0_28_2 float64 = jrt.NN(jrt.Double_Cast(na_27)).DoubleValue__D(); na_25 = jrt.Double_ValueOf_D__Double_NoInit(n0_28_2 + 1.0).Ref() } else { na_25 = lang.Numbers_Inc_O__Number_NoInit(na_27) } }; var na_26 int64 = int64(lang.RT_Count_O__I_NoInit(lines__1)); if jrt.Long_InstanceOf(na_25) { var n0_29 int64 = jrt.NN(jrt.Long_Cast(na_25)).LongValue__J(); var n1_30 int64 = na_26; tmp1 = n0_29 < n1_30 } else { tmp1 = lang.Numbers_Lt_O_J__Z_NoInit(na_25, na_26) }; if tmp1 { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_repr_go_print_text_A_const_66) }
//line :220:1
		seq_1242000067__6, chunk_1242000068__7, count_1242000069__8, i_1242000070__9 = seq_1242000067__6, chunk_1242000068__7, count_1242000069__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1242000070__9); continue L1 } else { var temp__1927000414__auto____10 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1242000067__6); if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1242000067__11 any = temp__1927000414__auto____10; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1242000067__11)) { var c__1927000678__auto____12 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1242000067__11); seq_1242000067__6, chunk_1242000068__7, count_1242000069__8, i_1242000070__9 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_37.GetRawRoot__O()).Invoke_O__O(seq_1242000067__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var i__12 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1242000067__11); var line__13 any = lang.RT_Nth_O_I__O_NoInit(lines__1, lang.RT_IntCast_O__I_NoInit(i__12)); var nw__14 int32 = lang.RT_Count_O__I_NoInit(widths__2); var j__15 int64 = 0; var use_tabs__16 any = jrt.Boolean_TRUE.Ref(); L3: for {



			if lang.Numbers_Lt_J_J__Z_NoInit(j__15, int64(lang.RT_Count_O__I_NoInit(line__13))) { var c__17 any = lang.RT_Nth_O_I__O_NoInit(line__13, lang.RT_IntCast_J__I_NoInit(j__15))

				if lang.Numbers_IsZero_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__17)))) {
					if lang.Numbers_Lt_J_J__Z_NoInit(j__15, int64(nw__14)) { lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_94.GetRawRoot__O()).Invoke_O_O_O_O__O(sb__0, A_arbace_repr_go_print_text_A_const_82.Invoke_O__O(c__17), lang.RT_Nth_O_I__O_NoInit(widths__2, lang.RT_IntCast_J__I_NoInit(j__15)), use_tabs__16) }
					j__15, use_tabs__16 = lang.Numbers_Inc_J__J_NoInit(j__15), use_tabs__16; continue L3 } else {
						jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_String__StringBuilder(jrt.String_Cast(A_arbace_repr_go_print_text_A_const_81.Invoke_O__O(c__17)))
						if lang.Numbers_Lt_J_J__Z_NoInit(j__15, int64(nw__14)) { lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_94.GetRawRoot__O()).Invoke_O_O_O_O__O(sb__0, A_arbace_repr_go_print_text_A_const_82.Invoke_O__O(c__17), lang.RT_Nth_O_I__O_NoInit(widths__2, lang.RT_IntCast_J__I_NoInit(j__15)), jrt.Boolean_FALSE.Ref()) }
						j__15, use_tabs__16 = lang.Numbers_Inc_J__J_NoInit(j__15), jrt.Boolean_FALSE.Ref(); continue L3 } }
//line :220:1
			break L3
		}










			var tmp2 bool; var na_32 any; var na_34 any = i__12; if jrt.Long_InstanceOf(na_34) { var n0_35 int64 = jrt.NN(jrt.Long_Cast(na_34)).LongValue__J(); if n0_35 == 9223372036854775807 { na_32 = lang.Numbers_Inc_O__Number_NoInit(na_34) } else { na_32 = jrt.Long_ValueOf_J__Long_NoInit(n0_35 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_34) { var n0_35_2 float64 = jrt.NN(jrt.Double_Cast(na_34)).DoubleValue__D(); na_32 = jrt.Double_ValueOf_D__Double_NoInit(n0_35_2 + 1.0).Ref() } else { na_32 = lang.Numbers_Inc_O__Number_NoInit(na_34) } }; var na_33 int64 = int64(lang.RT_Count_O__I_NoInit(lines__1)); if jrt.Long_InstanceOf(na_32) { var n0_36 int64 = jrt.NN(jrt.Long_Cast(na_32)).LongValue__J(); var n1_37 int64 = na_33; tmp2 = n0_36 < n1_37 } else { tmp2 = lang.Numbers_Lt_O_J__Z_NoInit(na_32, na_33) }; if tmp2 { jrt.NN(jrt.StringBuilder_Cast(sb__0)).Append_O__StringBuilder(A_arbace_repr_go_print_text_A_const_66) }
//line :220:1
			seq_1242000067__6, chunk_1242000068__7, count_1242000069__8, i_1242000070__9 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_38.GetRawRoot__O()).Invoke_O__O(seq_1242000067__11), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :219:1*/panic("j2g: unreachable") }














func A_arbace_repr_go_print_text_format_block_A_New() *A_arbace_repr_go_print_text_format_block_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_format_block_A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_repr_go_print_text_format_block_A) Ctor() {}
//line :234:1
func (t *A_arbace_repr_go_print_text_format_block_A) Invoke_O_O_O_O_O_O__O(self, sb__0, lines__1, widths__2, line0__3, line1__4 any) any { { var column__6 int32 = lang.RT_Count_O__I_NoInit(widths__2); var this__7 any = line0__3; var line0__8 any = line0__3; L1: for {




	var tmp1 bool; var na_39 any = this__7; var na_40 any = line1__4; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_39); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_40) }; tmp2 = tmp3; if tmp2 { var n0_41 int64 = jrt.NN(jrt.Long_Cast(na_39)).LongValue__J(); var n1_42 int64 = jrt.NN(jrt.Long_Cast(na_40)).LongValue__J(); tmp1 = n0_41 < n1_42 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_39); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_40) }; tmp4 = tmp5; if tmp4 { var n0_41_2 float64 = jrt.NN(jrt.Double_Cast(na_39)).DoubleValue__D(); var n1_42_2 float64 = jrt.NN(jrt.Double_Cast(na_40)).DoubleValue__D(); tmp1 = n0_41_2 < n1_42_2 } else { tmp1 = lang.Numbers_Lt_O_O__Z_NoInit(na_39, na_40) } }; if tmp1 { var line__9 any = lang.RT_Nth_O_I__O_NoInit(lines__1, lang.RT_IntCast_O__I_NoInit(this__7))

		if lang.Numbers_Gte_J_J__Z_NoInit(int64(column__6), lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(line__9)))) {
			var tmp6 jrt.Number_I; var na_56 any = this__7; if jrt.Long_InstanceOf(na_56) { var n0_57 int64 = jrt.NN(jrt.Long_Cast(na_56)).LongValue__J(); if n0_57 == 9223372036854775807 { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_56) } else { tmp6 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_57 + 1)) } } else { if jrt.Double_InstanceOf(na_56) { var n0_57_2 float64 = jrt.NN(jrt.Double_Cast(na_56)).DoubleValue__D(); tmp6 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_57_2 + 1.0)) } else { tmp6 = lang.Numbers_Inc_O__Number_NoInit(na_56) } }; this__7, line0__8 = tmp6, line0__8; continue L1 } else {

				lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_95.GetRawRoot__O()).Invoke_O_O_O_O_O__O(sb__0, lines__1, widths__2, line0__8, this__7)
//line :241:1
				var line0__10 any = this__7; var vec__1242000072__11 any; var tmp7 any = A_arbace_repr_go_print_text_format_block_fn__1242000075_A_New_I_O_O_O(column__6, this__7, line1__4, lines__1); var tmp8 *jrt.Class
				var fncls__55 /*line :241:1*/*jrt.Class = A_arbace_repr_go_print_text_format_block_fn__1242000075_A_fn_class





				if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_repr_go_print_text_format_block_fn__1242000075_A_fn_class = fncls__55d; tmp8 = fncls__55d } else { tmp8 = fncls__55 }; vec__1242000072__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil).Invoke__O()
//line :241:1
				var end__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000072__11, lang.RT_IntCast_J__I_NoInit(0), nil); var width__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000072__11, lang.RT_IntCast_J__I_NoInit(1), nil); var discardable__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1242000072__11, lang.RT_IntCast_J__I_NoInit(2), nil); var width__15 any














				if jrt.J2g_Truth(discardable__14) { width__15 = A_arbace_repr_go_print_text_A_const_46 } else { width__15 = width__13 }
				lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_96.GetRawRoot__O()).Invoke_O_O_O_O_O__O(sb__0, lines__1, lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_6.GetRawRoot__O()).Invoke_O_O__O(widths__2, width__15), line0__10, end__12)
				var tmp9 jrt.Number_I; var na_58 any = end__12; if jrt.Long_InstanceOf(na_58) { var n0_59 int64 = jrt.NN(jrt.Long_Cast(na_58)).LongValue__J(); if n0_59 == 9223372036854775807 { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_58) } else { tmp9 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_59 + 1)) } } else { if jrt.Double_InstanceOf(na_58) { var n0_59_2 float64 = jrt.NN(jrt.Double_Cast(na_58)).DoubleValue__D(); tmp9 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_59_2 + 1.0)) } else { tmp9 = lang.Numbers_Inc_O__Number_NoInit(na_58) } }; this__7, line0__8 = tmp9, end__12; continue L1 } } else {
					return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_95.GetRawRoot__O()).Invoke_O_O_O_O_O__O(sb__0, lines__1, widths__2, line0__8, line1__4) } } }; /*line :234:1*/panic("j2g: unreachable") }












func A_arbace_repr_go_print_text_format_block_fn__1242000075_A_New_I_O_O_O(p0 int32, p1, p2, p3 any) *A_arbace_repr_go_print_text_format_block_fn__1242000075_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_format_block_fn__1242000075_A{}; t.Ctor_I_O_O_O(p0, p1, p2, p3); return t }
//line :247:1
func (t *A_arbace_repr_go_print_text_format_block_fn__1242000075_A) Ctor_I_O_O_O(c__column int32, c__this, c__line1, c__lines any) { t.F_column = c__column; t.F_this = c__this; t.F_line1 = c__line1; t.F_lines = c__lines }
//line :247:1
func (t *A_arbace_repr_go_print_text_format_block_fn__1242000075_A) Invoke_O__O(self any) any { { var this__1 any; var t_ any = t.F_this; t.F_this = nil; this__1 = t_; var width__2 any = lang.RT_Box_J__Number_NoInit(0); var discardable__3 any = jrt.Boolean_TRUE.Ref(); L1: for {
												var tmp1 bool; var na_44 any = this__1; var na_45 any = t.F_line1; var tmp2 bool; var tmp3 bool; tmp3 = jrt.Long_InstanceOf(na_44); if tmp3 { tmp3 = jrt.Long_InstanceOf(na_45) }; tmp2 = tmp3; if tmp2 { var n0_46 int64 = jrt.NN(jrt.Long_Cast(na_44)).LongValue__J(); var n1_47 int64 = jrt.NN(jrt.Long_Cast(na_45)).LongValue__J(); tmp1 = n0_46 < n1_47 } else { var tmp4 bool; var tmp5 bool; tmp5 = jrt.Double_InstanceOf(na_44); if tmp5 { tmp5 = jrt.Double_InstanceOf(na_45) }; tmp4 = tmp5; if tmp4 { var n0_46_2 float64 = jrt.NN(jrt.Double_Cast(na_44)).DoubleValue__D(); var n1_47_2 float64 = jrt.NN(jrt.Double_Cast(na_45)).DoubleValue__D(); tmp1 = n0_46_2 < n1_47_2 } else { tmp1 = lang.Numbers_Lt_O_O__Z_NoInit(na_44, na_45) } }; if tmp1 { var tmp6 any = t.F_lines; var line__4 any = lang.RT_Nth_O_I__O_NoInit(tmp6, lang.RT_IntCast_O__I_NoInit(this__1)); var tmp7 int64 = int64(t.F_column)

		if lang.Numbers_Gte_J_J__Z_NoInit(tmp7, lang.Numbers_Dec_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(line__4)))) { return lang.Tuple_Create_O_O_O__IPersistentVector(this__1, width__2, discardable__3) } else { var c__5 any = lang.RT_Nth_O_I__O_NoInit(line__4, t.F_column); var tmp8 jrt.Number_I
			var na_49 any = this__1

			if jrt.Long_InstanceOf(na_49) { var n0_50 int64 = jrt.NN(jrt.Long_Cast(na_49)).LongValue__J(); if n0_50 == 9223372036854775807 { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_49) } else { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_50 + 1)) } } else { if jrt.Double_InstanceOf(na_49) { var n0_50_2 float64 = jrt.NN(jrt.Double_Cast(na_49)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_50_2 + 1.0)) } else { tmp8 = lang.Numbers_Inc_O__Number_NoInit(na_49) } }; var tmp9 any = tmp8; var tmp10 jrt.Number_I; var na_51 any = A_arbace_repr_go_print_text_A_const_82.Invoke_O__O(c__5); if jrt.Long_InstanceOf(na_51) { var n0_52 int64 = jrt.NN(jrt.Long_Cast(na_51)).LongValue__J(); if n0_52 == 9223372036854775807 { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_51) } else { tmp10 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_52 + 1)) } } else { if jrt.Double_InstanceOf(na_51) { var n0_52_2 float64 = jrt.NN(jrt.Double_Cast(na_51)).DoubleValue__D(); tmp10 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_52_2 + 1.0)) } else { tmp10 = lang.Numbers_Inc_O__Number_NoInit(na_51) } }; var tmp11 any = lang.Numbers_Max_O_O__O_NoInit(width__2, tmp10); var tmp12 any; var and__1927000168__auto____6 any = discardable__3
			if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 bool; var na_53 any = A_arbace_repr_go_print_text_A_const_82.Invoke_O__O(c__5); if jrt.Long_InstanceOf(na_53) { var n0_54 int64 = jrt.NN(jrt.Long_Cast(na_53)).LongValue__J(); and__1927000168__auto____7 = n0_54 == 0 } else { if jrt.Double_InstanceOf(na_53) { var n0_54_2 float64 = jrt.NN(jrt.Double_Cast(na_53)).DoubleValue__D(); and__1927000168__auto____7 = n0_54_2 == 0.0 } else { and__1927000168__auto____7 = lang.Numbers_IsZero_O__Z_NoInit(na_53) } }; if and__1927000168__auto____7 { tmp12 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_52.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_text_A_const_84.Invoke_O__O(c__5)) } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() } } else { tmp12 = and__1927000168__auto____6 }
//line :253:1
			this__1, width__2, discardable__3 = tmp9, tmp11, tmp12; continue L1 } } else {
//line :248:1
				return lang.Tuple_Create_O_O_O__IPersistentVector(this__1, width__2, discardable__3) } } }; /*line :247:1*/panic("j2g: unreachable") }













func A_arbace_repr_go_print_text_align_block_A_New() *A_arbace_repr_go_print_text_align_block_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_align_block_A{}; t.Ctor(); return t }
//line :261:1
func (t *A_arbace_repr_go_print_text_align_block_A) Ctor() {}
//line :261:1
func (t *A_arbace_repr_go_print_text_align_block_A) Invoke_O_O__O(self, block__0 any) any { var sb__2 any = jrt.StringBuilder_New(); var lines__3 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_97.GetRawRoot__O()).Invoke_O__O(block__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_96.GetRawRoot__O()); var tmp2 any = lang.PersistentVector_EMPTY.Ref(); var tmp3 any = A_arbace_repr_go_print_text_A_const_46;




	tmp1.Invoke_O_O_O_O_O__O(sb__2, lines__3, tmp2, tmp3, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(lines__3)).Ref()); return /*line :267:1*/ jrt.NN(jrt.StringBuilder_Cast(sb__2)).ToString__String().Ref() }

func A_arbace_repr_go_print_text_align_A_New() *A_arbace_repr_go_print_text_align_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_align_A{}; t.Ctor(); return t }
//line :269:1
func (t *A_arbace_repr_go_print_text_align_A) Ctor() {}
//line :269:1
func (t *A_arbace_repr_go_print_text_align_A) Invoke_O_O__O(self, text__0 any) any { var blocks__2 any = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_89.GetRawRoot__O()).Invoke_O_O_O__O(text__0, A_arbace_repr_go_print_text_A_const_100, A_arbace_repr_go_print_text_A_const_91); var n__3 int32 = lang.RT_Count_O__I_NoInit(blocks__2); var groups__4 int64 = lang.Numbers_Multiply_J_J__J_NoInit(4, int64(jrt.NN(jrt.Runtime_GetRuntime__Runtime()).AvailableProcessors__I())); var aligned__5 any; if






	lang.Numbers_Lt_J_J__Z_NoInit(int64(n__3), 128) {
		aligned__5 = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_98.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_text_A_const_101.GetRawRoot__O(), blocks__2) } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_repr_go_print_text_A_const_102.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_103.GetRawRoot__O()); var tmp4 any = A_arbace_repr_go_print_text_align_fn__1242000080_A_New(); var tmp5 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_repr_go_print_text_align_fn__1242000080_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_repr_go_print_text_align_fn__1242000080_A_fn_class = fncls__60d; tmp5 = fncls__60d } else { tmp5 = fncls__60 }; aligned__5 = tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_105.GetRawRoot__O()).Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Quotient_J_J__J_NoInit(lang.Numbers_Add_J_J__J_NoInit(int64(n__3), lang.Numbers_Dec_J__J_NoInit(groups__4)), groups__4)).Ref(), blocks__2))) }; return /*line :280:1*/ lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_99.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_106.GetRawRoot__O()).Invoke_O_O__O(Lit_2, aligned__5)) }
//line :278:1
func A_arbace_repr_go_print_text_align_fn__1242000080_A_New() *A_arbace_repr_go_print_text_align_fn__1242000080_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_align_fn__1242000080_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_repr_go_print_text_align_fn__1242000080_A) Ctor() {}
//line :278:1
func (t *A_arbace_repr_go_print_text_align_fn__1242000080_A) Invoke_O_O__O(self, p1__1242000079_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_repr_go_print_text_A_const_104.GetRawRoot__O()).Invoke_O_O__O(A_arbace_repr_go_print_text_A_const_101.GetRawRoot__O(), p1__1242000079_SHARP___1) }







type A_arbace_repr_go_print_text_A struct{ jrt.Object }

var A_arbace_repr_go_print_text_A_const_pool *jrt.RefArray

var A_arbace_repr_go_print_text_A_const_0 *lang.Var

var A_arbace_repr_go_print_text_A_const_1 *lang.Var

var A_arbace_repr_go_print_text_A_const_2 any

var A_arbace_repr_go_print_text_A_const_3 any

var A_arbace_repr_go_print_text_A_const_4 *lang.Var

var A_arbace_repr_go_print_text_A_const_5 *lang.Var

var A_arbace_repr_go_print_text_A_const_6 *lang.Var

var A_arbace_repr_go_print_text_A_const_7 any

var A_arbace_repr_go_print_text_A_const_8 *lang.Var

var A_arbace_repr_go_print_text_A_const_9 *lang.Var

var A_arbace_repr_go_print_text_A_const_10 *lang.Var

var A_arbace_repr_go_print_text_A_const_11 any

var A_arbace_repr_go_print_text_A_const_12 any

var A_arbace_repr_go_print_text_A_const_13 *lang.Var

var A_arbace_repr_go_print_text_A_const_14 *lang.Var

var A_arbace_repr_go_print_text_A_const_15 *lang.Var

var A_arbace_repr_go_print_text_A_const_16 *lang.Var

var A_arbace_repr_go_print_text_A_const_17 any

var A_arbace_repr_go_print_text_A_const_18 *lang.Var

var A_arbace_repr_go_print_text_A_const_19 *lang.Var

var A_arbace_repr_go_print_text_A_const_20 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_21 any

var A_arbace_repr_go_print_text_A_const_22 any

var A_arbace_repr_go_print_text_A_const_23 any

var A_arbace_repr_go_print_text_A_const_24 *lang.Var

var A_arbace_repr_go_print_text_A_const_25 *lang.Var

var A_arbace_repr_go_print_text_A_const_26 *lang.Var

var A_arbace_repr_go_print_text_A_const_27 *lang.Var

var A_arbace_repr_go_print_text_A_const_28 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_29 *lang.Var

var A_arbace_repr_go_print_text_A_const_30 *lang.Var

var A_arbace_repr_go_print_text_A_const_31 *lang.Var

var A_arbace_repr_go_print_text_A_const_32 *lang.Var

var A_arbace_repr_go_print_text_A_const_33 *lang.Var

var A_arbace_repr_go_print_text_A_const_34 *lang.Var

var A_arbace_repr_go_print_text_A_const_35 *lang.Var

var A_arbace_repr_go_print_text_A_const_36 any

var A_arbace_repr_go_print_text_A_const_37 *lang.Var

var A_arbace_repr_go_print_text_A_const_38 *lang.Var

var A_arbace_repr_go_print_text_A_const_39 *lang.Var

var A_arbace_repr_go_print_text_A_const_40 *lang.Var

var A_arbace_repr_go_print_text_A_const_41 any

var A_arbace_repr_go_print_text_A_const_42 any

var A_arbace_repr_go_print_text_A_const_43 *lang.Var

var A_arbace_repr_go_print_text_A_const_44 *lang.Var

var A_arbace_repr_go_print_text_A_const_45 *lang.Var

var A_arbace_repr_go_print_text_A_const_46 any

var A_arbace_repr_go_print_text_A_const_47 any

var A_arbace_repr_go_print_text_A_const_48 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_49 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_50 any

var A_arbace_repr_go_print_text_A_const_51 *lang.Var

var A_arbace_repr_go_print_text_A_const_52 *lang.Var

var A_arbace_repr_go_print_text_A_const_53 *lang.Var

var A_arbace_repr_go_print_text_A_const_54 *lang.Var

var A_arbace_repr_go_print_text_A_const_55 *lang.Var

var A_arbace_repr_go_print_text_A_const_56 *lang.Var

var A_arbace_repr_go_print_text_A_const_57 *lang.Var

var A_arbace_repr_go_print_text_A_const_58 *lang.Var

var A_arbace_repr_go_print_text_A_const_59 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_60 *lang.Var

var A_arbace_repr_go_print_text_A_const_61 *lang.Var

var A_arbace_repr_go_print_text_A_const_62 *lang.Var

var A_arbace_repr_go_print_text_A_const_63 *lang.Var

var A_arbace_repr_go_print_text_A_const_64 any

var A_arbace_repr_go_print_text_A_const_65 any

var A_arbace_repr_go_print_text_A_const_66 any

var A_arbace_repr_go_print_text_A_const_67 any

var A_arbace_repr_go_print_text_A_const_68 any

var A_arbace_repr_go_print_text_A_const_69 any

var A_arbace_repr_go_print_text_A_const_70 any

var A_arbace_repr_go_print_text_A_const_71 any

var A_arbace_repr_go_print_text_A_const_72 any

var A_arbace_repr_go_print_text_A_const_73 any

var A_arbace_repr_go_print_text_A_const_74 any

var A_arbace_repr_go_print_text_A_const_75 any

var A_arbace_repr_go_print_text_A_const_76 *lang.Var

var A_arbace_repr_go_print_text_A_const_77 *lang.Var

var A_arbace_repr_go_print_text_A_const_78 *lang.Var

var A_arbace_repr_go_print_text_A_const_79 *lang.Var

var A_arbace_repr_go_print_text_A_const_80 *lang.Var

var A_arbace_repr_go_print_text_A_const_81 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_82 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_83 *lang.Var

var A_arbace_repr_go_print_text_A_const_84 *lang.Keyword

var A_arbace_repr_go_print_text_A_const_85 *lang.Var

var A_arbace_repr_go_print_text_A_const_86 *lang.Var

var A_arbace_repr_go_print_text_A_const_87 *lang.Var

var A_arbace_repr_go_print_text_A_const_88 *lang.Var

var A_arbace_repr_go_print_text_A_const_89 *lang.Var

var A_arbace_repr_go_print_text_A_const_90 any

var A_arbace_repr_go_print_text_A_const_91 any

var A_arbace_repr_go_print_text_A_const_92 any

var A_arbace_repr_go_print_text_A_const_93 *lang.Var

var A_arbace_repr_go_print_text_A_const_94 *lang.Var

var A_arbace_repr_go_print_text_A_const_95 *lang.Var

var A_arbace_repr_go_print_text_A_const_96 *lang.Var

var A_arbace_repr_go_print_text_A_const_97 *lang.Var

var A_arbace_repr_go_print_text_A_const_98 *lang.Var

var A_arbace_repr_go_print_text_A_const_99 *lang.Var

var A_arbace_repr_go_print_text_A_const_100 any

var A_arbace_repr_go_print_text_A_const_101 *lang.Var

var A_arbace_repr_go_print_text_A_const_102 *lang.Var

var A_arbace_repr_go_print_text_A_const_103 *lang.Var

var A_arbace_repr_go_print_text_A_const_104 *lang.Var

var A_arbace_repr_go_print_text_A_const_105 *lang.Var

var A_arbace_repr_go_print_text_A_const_106 *lang.Var

var A_arbace_repr_go_print_text_A_init jrt.ClassInit

func A_arbace_repr_go_print_text_A_Init() { if !A_arbace_repr_go_print_text_A_init.Done() { A_arbace_repr_go_print_text_A_init.Run(A_arbace_repr_go_print_text_A_clinit) } }

func A_arbace_repr_go_print_text_A_clinit() { A_arbace_repr_go_print_text_A_clinit_p0(); A_arbace_repr_go_print_text_A_clinit_p1(); A_arbace_repr_go_print_text_A_clinit_p2(); A_arbace_repr_go_print_text_A_clinit_p3(); A_arbace_repr_go_print_text_A_clinit_p4(); A_arbace_repr_go_print_text_A_clinit_p5(); A_arbace_repr_go_print_text_A_clinit_p6(); A_arbace_repr_go_print_text_A_clinit_p7(); A_arbace_repr_go_print_text_A_clinit_p8() }

func A_arbace_repr_go_print_text_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_print_text_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 120); A_arbace_repr_go_print_text_A_const_0 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[13]); A_arbace_repr_go_print_text_A_const_1 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[14]); A_arbace_repr_go_print_text_A_const_2 = A_arbace_repr_go_print_text_A_const_pool.A[15]; A_arbace_repr_go_print_text_A_const_3 = A_arbace_repr_go_print_text_A_const_pool.A[16]; A_arbace_repr_go_print_text_A_const_4 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[17]); A_arbace_repr_go_print_text_A_const_5 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[18]); A_arbace_repr_go_print_text_A_const_6 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[19]); A_arbace_repr_go_print_text_A_const_7 = A_arbace_repr_go_print_text_A_const_pool.A[20]; A_arbace_repr_go_print_text_A_const_8 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[21]); A_arbace_repr_go_print_text_A_const_9 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[22]); A_arbace_repr_go_print_text_A_const_10 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[23]); A_arbace_repr_go_print_text_A_const_11 = A_arbace_repr_go_print_text_A_const_pool.A[24] }

func A_arbace_repr_go_print_text_A_clinit_p1() { A_arbace_repr_go_print_text_A_const_12 = A_arbace_repr_go_print_text_A_const_pool.A[25]; A_arbace_repr_go_print_text_A_const_13 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[26]); A_arbace_repr_go_print_text_A_const_14 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[27]); A_arbace_repr_go_print_text_A_const_15 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[28]); A_arbace_repr_go_print_text_A_const_16 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[29]); A_arbace_repr_go_print_text_A_const_17 = A_arbace_repr_go_print_text_A_const_pool.A[30]; A_arbace_repr_go_print_text_A_const_18 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[31]); A_arbace_repr_go_print_text_A_const_19 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[32]); A_arbace_repr_go_print_text_A_const_20 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[33]); A_arbace_repr_go_print_text_A_const_21 = A_arbace_repr_go_print_text_A_const_pool.A[34]; A_arbace_repr_go_print_text_A_const_22 = A_arbace_repr_go_print_text_A_const_pool.A[35]; A_arbace_repr_go_print_text_A_const_23 = A_arbace_repr_go_print_text_A_const_pool.A[36]; A_arbace_repr_go_print_text_A_const_24 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[37]) }

func A_arbace_repr_go_print_text_A_clinit_p2() { A_arbace_repr_go_print_text_A_const_25 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[38]); A_arbace_repr_go_print_text_A_const_26 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[39]); A_arbace_repr_go_print_text_A_const_27 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[40]); A_arbace_repr_go_print_text_A_const_28 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[41]); A_arbace_repr_go_print_text_A_const_29 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[42]); A_arbace_repr_go_print_text_A_const_30 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[43]); A_arbace_repr_go_print_text_A_const_31 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[44]); A_arbace_repr_go_print_text_A_const_32 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[45]); A_arbace_repr_go_print_text_A_const_33 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[46]); A_arbace_repr_go_print_text_A_const_34 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[47]); A_arbace_repr_go_print_text_A_const_35 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[48]); A_arbace_repr_go_print_text_A_const_36 = A_arbace_repr_go_print_text_A_const_pool.A[49] }

func A_arbace_repr_go_print_text_A_clinit_p3() { A_arbace_repr_go_print_text_A_const_37 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[50]); A_arbace_repr_go_print_text_A_const_38 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[51]); A_arbace_repr_go_print_text_A_const_39 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[52]); A_arbace_repr_go_print_text_A_const_40 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[53]); A_arbace_repr_go_print_text_A_const_41 = A_arbace_repr_go_print_text_A_const_pool.A[54]; A_arbace_repr_go_print_text_A_const_42 = A_arbace_repr_go_print_text_A_const_pool.A[55]; A_arbace_repr_go_print_text_A_const_43 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[56]); A_arbace_repr_go_print_text_A_const_44 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[57]); A_arbace_repr_go_print_text_A_const_45 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[58]); A_arbace_repr_go_print_text_A_const_46 = A_arbace_repr_go_print_text_A_const_pool.A[59]; A_arbace_repr_go_print_text_A_const_47 = A_arbace_repr_go_print_text_A_const_pool.A[60]; A_arbace_repr_go_print_text_A_const_48 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[61]); A_arbace_repr_go_print_text_A_const_49 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[62]) }

func A_arbace_repr_go_print_text_A_clinit_p4() { A_arbace_repr_go_print_text_A_const_50 = A_arbace_repr_go_print_text_A_const_pool.A[63]; A_arbace_repr_go_print_text_A_const_51 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[64]); A_arbace_repr_go_print_text_A_const_52 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[65]); A_arbace_repr_go_print_text_A_const_53 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[66]); A_arbace_repr_go_print_text_A_const_54 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[67]); A_arbace_repr_go_print_text_A_const_55 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[68]); A_arbace_repr_go_print_text_A_const_56 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[69]); A_arbace_repr_go_print_text_A_const_57 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[70]); A_arbace_repr_go_print_text_A_const_58 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[71]); A_arbace_repr_go_print_text_A_const_59 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[72]); A_arbace_repr_go_print_text_A_const_60 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[73]); A_arbace_repr_go_print_text_A_const_61 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[74]) }

func A_arbace_repr_go_print_text_A_clinit_p5() { A_arbace_repr_go_print_text_A_const_62 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[75]); A_arbace_repr_go_print_text_A_const_63 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[76]); A_arbace_repr_go_print_text_A_const_64 = A_arbace_repr_go_print_text_A_const_pool.A[77]; A_arbace_repr_go_print_text_A_const_65 = A_arbace_repr_go_print_text_A_const_pool.A[78]; A_arbace_repr_go_print_text_A_const_66 = A_arbace_repr_go_print_text_A_const_pool.A[79]; A_arbace_repr_go_print_text_A_const_67 = A_arbace_repr_go_print_text_A_const_pool.A[80]; A_arbace_repr_go_print_text_A_const_68 = A_arbace_repr_go_print_text_A_const_pool.A[81]; A_arbace_repr_go_print_text_A_const_69 = A_arbace_repr_go_print_text_A_const_pool.A[82]; A_arbace_repr_go_print_text_A_const_70 = A_arbace_repr_go_print_text_A_const_pool.A[83]; A_arbace_repr_go_print_text_A_const_71 = A_arbace_repr_go_print_text_A_const_pool.A[84]; A_arbace_repr_go_print_text_A_const_72 = A_arbace_repr_go_print_text_A_const_pool.A[85]; A_arbace_repr_go_print_text_A_const_73 = A_arbace_repr_go_print_text_A_const_pool.A[86]; A_arbace_repr_go_print_text_A_const_74 = A_arbace_repr_go_print_text_A_const_pool.A[87]; A_arbace_repr_go_print_text_A_const_75 = A_arbace_repr_go_print_text_A_const_pool.A[88]; A_arbace_repr_go_print_text_A_const_76 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[89]) }

func A_arbace_repr_go_print_text_A_clinit_p6() { A_arbace_repr_go_print_text_A_const_77 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[90]); A_arbace_repr_go_print_text_A_const_78 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[91]); A_arbace_repr_go_print_text_A_const_79 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[92]); A_arbace_repr_go_print_text_A_const_80 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[93]); A_arbace_repr_go_print_text_A_const_81 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[94]); A_arbace_repr_go_print_text_A_const_82 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[95]); A_arbace_repr_go_print_text_A_const_83 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[96]); A_arbace_repr_go_print_text_A_const_84 = lang.Keyword_Cast(A_arbace_repr_go_print_text_A_const_pool.A[97]); A_arbace_repr_go_print_text_A_const_85 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[98]); A_arbace_repr_go_print_text_A_const_86 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[99]); A_arbace_repr_go_print_text_A_const_87 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[100]); A_arbace_repr_go_print_text_A_const_88 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[101]) }

func A_arbace_repr_go_print_text_A_clinit_p7() { A_arbace_repr_go_print_text_A_const_89 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[102]); A_arbace_repr_go_print_text_A_const_90 = A_arbace_repr_go_print_text_A_const_pool.A[103]; A_arbace_repr_go_print_text_A_const_91 = A_arbace_repr_go_print_text_A_const_pool.A[104]; A_arbace_repr_go_print_text_A_const_92 = A_arbace_repr_go_print_text_A_const_pool.A[105]; A_arbace_repr_go_print_text_A_const_93 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[106]); A_arbace_repr_go_print_text_A_const_94 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[107]); A_arbace_repr_go_print_text_A_const_95 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[108]); A_arbace_repr_go_print_text_A_const_96 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[109]); A_arbace_repr_go_print_text_A_const_97 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[110]); A_arbace_repr_go_print_text_A_const_98 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[111]); A_arbace_repr_go_print_text_A_const_99 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[112]); A_arbace_repr_go_print_text_A_const_100 = A_arbace_repr_go_print_text_A_const_pool.A[113]; A_arbace_repr_go_print_text_A_const_101 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[114]) }

func A_arbace_repr_go_print_text_A_clinit_p8() { A_arbace_repr_go_print_text_A_const_102 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[115]); A_arbace_repr_go_print_text_A_const_103 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[116]); A_arbace_repr_go_print_text_A_const_104 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[117]); A_arbace_repr_go_print_text_A_const_105 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[118]); A_arbace_repr_go_print_text_A_const_106 = lang.Var_Cast(A_arbace_repr_go_print_text_A_const_pool.A[119]) }

func A_arbace_repr_go_print_text_A_New() *A_arbace_repr_go_print_text_A { A_arbace_repr_go_print_text_A_Init(); t := &A_arbace_repr_go_print_text_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_text_A) Ctor() {}

func (t *A_arbace_repr_go_print_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_text_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_text_A_class }

func (t *A_arbace_repr_go_print_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_text_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_text_A); return ok }

func A_arbace_repr_go_print_text_A_Cast(x any) *A_arbace_repr_go_print_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_text_A_class)) }; return v }



type A_arbace_repr_go_print_text_align_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_align_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_align_fn__1242000080_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_align_fn__1242000080_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_align_block_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_align_block_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_cell_width_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_cell_width_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_code_points_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_code_points_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_escape_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_escape_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_escape_cp_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_escape_cp_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_eval1242000004_A struct{ jrt.Object }

func A_arbace_repr_go_print_text_eval1242000004_A_New() *A_arbace_repr_go_print_text_eval1242000004_A { t := &A_arbace_repr_go_print_text_eval1242000004_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) Ctor() {}

func (t *A_arbace_repr_go_print_text_eval1242000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_text_eval1242000004_A_class }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_text_eval1242000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_text_eval1242000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_text_eval1242000004_A); return ok }

func A_arbace_repr_go_print_text_eval1242000004_A_Cast(x any) *A_arbace_repr_go_print_text_eval1242000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_text_eval1242000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_text_eval1242000004_A_class)) }; return v }



type A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_eval1242000008_A struct{ jrt.Object }

func A_arbace_repr_go_print_text_eval1242000008_A_New() *A_arbace_repr_go_print_text_eval1242000008_A { t := &A_arbace_repr_go_print_text_eval1242000008_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) Ctor() {}

func (t *A_arbace_repr_go_print_text_eval1242000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_text_eval1242000008_A_class }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_text_eval1242000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_text_eval1242000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_text_eval1242000008_A); return ok }

func A_arbace_repr_go_print_text_eval1242000008_A_Cast(x any) *A_arbace_repr_go_print_text_eval1242000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_text_eval1242000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_text_eval1242000008_A_class)) }; return v }



type A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_float_kind_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_float_kind_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_format_block_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_format_block_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_format_block_fn__1242000075_A struct{ j2g_header uint64; F_column int32; F_this, F_line1, F_lines any }

var A_arbace_repr_go_print_text_format_block_fn__1242000075_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_byte_string_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_byte_string_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_float_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_float_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_number_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_number_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_printable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_printable_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_rune_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_rune_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_go_string_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_go_string_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_hex_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_hex_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_negative_number_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_negative_number_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_parse_lines_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A struct{ j2g_header uint64; F_s__1242000052, F_iter__1242000051 any }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A struct{ j2g_header uint64; F_b__1242000054 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A struct{ j2g_header uint64; F_n int32; F_line any }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000057_fn__1242000058_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A struct{ j2g_header uint64; F_n int32; F_line any }

var A_arbace_repr_go_print_text_parse_lines_iter__1242000051__1242000055_fn__1242000056_fn__1242000061_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_pow2_exponent_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_pow2_exponent_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_raw_string_ok_QMARK__A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_raw_string_ok_QMARK__A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_raw_string_ok_QMARK__fn__1242000022_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_strip_2_5_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_strip_2_5_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_unescape_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_unescape_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_write_lines_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_write_lines_A_fn_class *jrt.Class



type A_arbace_repr_go_print_text_write_padding_A struct{ j2g_header uint64 }

var A_arbace_repr_go_print_text_write_padding_A_fn_class *jrt.Class
