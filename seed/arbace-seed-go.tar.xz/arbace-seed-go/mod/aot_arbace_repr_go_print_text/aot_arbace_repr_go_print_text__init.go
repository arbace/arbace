//line aot_arbace_repr_go_print_text__init.ae:1
package aot_arbace_repr_go_print_text

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_print_text__init_A_Unit0__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(A_arbace_repr_go_print_text__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_print_text__init_A_const_1) }
//line :1:1
func A_arbace_repr_go_print_text__init_A_Unit1__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_repr_go_print_text__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_2)) }
//line :1:1
func A_arbace_repr_go_print_text__init_A_Unit2__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_repr_go_print_text_eval1242000004_loading__1927001464__auto____1242000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_repr_go_print_text__init_A_Unit3__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repr_go_print_text__init_A_const_1)).Equals_O__Z(A_arbace_repr_go_print_text__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_repr_go_print_text_eval1242000008_fn__1242000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_repr_go_print_text__init_A_Load__O() any { A_arbace_repr_go_print_text__init_A_Init(); A_arbace_repr_go_print_text__init_A_Unit0__O(); A_arbace_repr_go_print_text__init_A_Unit1__O(); A_arbace_repr_go_print_text__init_A_Unit2__O(); A_arbace_repr_go_print_text__init_A_Unit3__O(); A_arbace_repr_go_print_text__init_A_Unit4__O(); A_arbace_repr_go_print_text__init_A_Unit5__O(); A_arbace_repr_go_print_text__init_A_Unit6__O(); A_arbace_repr_go_print_text__init_A_Unit7__O(); A_arbace_repr_go_print_text__init_A_Unit8__O(); A_arbace_repr_go_print_text__init_A_Unit9__O(); A_arbace_repr_go_print_text__init_A_Unit10__O(); A_arbace_repr_go_print_text__init_A_Unit11__O(); A_arbace_repr_go_print_text__init_A_Unit12__O(); A_arbace_repr_go_print_text__init_A_Unit13__O(); A_arbace_repr_go_print_text__init_A_Unit14__O(); A_arbace_repr_go_print_text__init_A_Unit15__O(); A_arbace_repr_go_print_text__init_A_Unit16__O(); A_arbace_repr_go_print_text__init_A_Unit17__O(); A_arbace_repr_go_print_text__init_A_Unit18__O(); A_arbace_repr_go_print_text__init_A_Unit19__O(); A_arbace_repr_go_print_text__init_A_Unit20__O(); A_arbace_repr_go_print_text__init_A_Unit21__O(); A_arbace_repr_go_print_text__init_A_Unit22__O(); A_arbace_repr_go_print_text__init_A_Unit23__O(); A_arbace_repr_go_print_text__init_A_Unit24__O(); A_arbace_repr_go_print_text__init_A_Unit25__O(); A_arbace_repr_go_print_text__init_A_Unit26__O(); A_arbace_repr_go_print_text__init_A_Unit27__O(); A_arbace_repr_go_print_text__init_A_Unit28__O(); return nil }













func A_arbace_repr_go_print_text__init_A_Unit4__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(19, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_4; tmp1.BindRoot_O__V(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, jrt.Byte_ValueOf_B__Byte(26).Ref(), jrt.Byte_ValueOf_B__Byte(11).Ref(), jrt.Byte_ValueOf_B__Byte(28).Ref(), jrt.Byte_ValueOf_B__Byte(23).Ref(), jrt.Byte_ValueOf_B__Byte(9).Ref(), jrt.Byte_ValueOf_B__Byte(2).Ref(), jrt.Byte_ValueOf_B__Byte(24).Ref(), jrt.Byte_ValueOf_B__Byte(1).Ref(), jrt.Byte_ValueOf_B__Byte(27).Ref(), jrt.Byte_ValueOf_B__Byte(8).Ref(), jrt.Byte_ValueOf_B__Byte(3).Ref(), jrt.Byte_ValueOf_B__Byte(4).Ref(), jrt.Byte_ValueOf_B__Byte(7).Ref(), jrt.Byte_ValueOf_B__Byte(22).Ref(), jrt.Byte_ValueOf_B__Byte(21).Ref(), jrt.Byte_ValueOf_B__Byte(20).Ref(), jrt.Byte_ValueOf_B__Byte(5).Ref(), jrt.Byte_ValueOf_B__Byte(25).Ref(), jrt.Byte_ValueOf_B__Byte(29).Ref(), jrt.Byte_ValueOf_B__Byte(6).Ref(), jrt.Byte_ValueOf_B__Byte(10).Ref(), jrt.Byte_ValueOf_B__Byte(30).Ref()))); var tmp2 *lang.Var = A_arbace_repr_go_print_text__init_A_const_4; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_5)); return A_arbace_repr_go_print_text__init_A_const_4 }














func A_arbace_repr_go_print_text__init_A_Unit5__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(34, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_6; var tmp2 any = A_arbace_repr_go_print_text_go_printable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_go_print_text_go_printable_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_repr_go_print_text_go_printable_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_7)); return A_arbace_repr_go_print_text__init_A_const_6 }







func A_arbace_repr_go_print_text__init_A_Unit6__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_8; var tmp2 any = A_arbace_repr_go_print_text_hex_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_repr_go_print_text_hex_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_repr_go_print_text_hex_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_9)); return A_arbace_repr_go_print_text__init_A_const_8 }



func A_arbace_repr_go_print_text__init_A_Unit7__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_10; var tmp2 any = A_arbace_repr_go_print_text_escape_cp_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_go_print_text_escape_cp_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_repr_go_print_text_escape_cp_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_11)); return A_arbace_repr_go_print_text__init_A_const_10 }











func A_arbace_repr_go_print_text__init_A_Unit8__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_12; var tmp2 any = A_arbace_repr_go_print_text_code_points_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_repr_go_print_text_code_points_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_repr_go_print_text_code_points_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_13)); return A_arbace_repr_go_print_text__init_A_const_12 }











func A_arbace_repr_go_print_text__init_A_Unit9__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_14; var tmp2 any = A_arbace_repr_go_print_text_go_string_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repr_go_print_text_go_string_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_repr_go_print_text_go_string_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_15)); return A_arbace_repr_go_print_text__init_A_const_14 }








func A_arbace_repr_go_print_text__init_A_Unit10__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(79, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_16; var tmp2 any = A_arbace_repr_go_print_text_raw_string_ok_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_repr_go_print_text_raw_string_ok_QMARK__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_repr_go_print_text_raw_string_ok_QMARK__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_17)); return A_arbace_repr_go_print_text__init_A_const_16 }







func A_arbace_repr_go_print_text__init_A_Unit11__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(87, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_18; var tmp2 any = A_arbace_repr_go_print_text_go_byte_string_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_repr_go_print_text_go_byte_string_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_repr_go_print_text_go_byte_string_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_19)); return A_arbace_repr_go_print_text__init_A_const_18 }












func A_arbace_repr_go_print_text__init_A_Unit12__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(100, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_20; var tmp2 any = A_arbace_repr_go_print_text_go_rune_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_repr_go_print_text_go_rune_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_repr_go_print_text_go_rune_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_21)); return A_arbace_repr_go_print_text__init_A_const_20 }






func A_arbace_repr_go_print_text__init_A_Unit13__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(107, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_22; var tmp2 any = A_arbace_repr_go_print_text_float_kind_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_repr_go_print_text_float_kind_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_repr_go_print_text_float_kind_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_23)); return A_arbace_repr_go_print_text__init_A_const_22 }





func A_arbace_repr_go_print_text__init_A_Unit14__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(113, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_24; var tmp2 any = A_arbace_repr_go_print_text_pow2_exponent_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_repr_go_print_text_pow2_exponent_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_repr_go_print_text_pow2_exponent_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_25)); return A_arbace_repr_go_print_text__init_A_const_24 }




func A_arbace_repr_go_print_text__init_A_Unit15__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(118, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_26; var tmp2 any = A_arbace_repr_go_print_text_strip_2_5_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repr_go_print_text_strip_2_5_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_repr_go_print_text_strip_2_5_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_27)); return A_arbace_repr_go_print_text__init_A_const_26 }









func A_arbace_repr_go_print_text__init_A_Unit16__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(128, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_28; var tmp2 any = A_arbace_repr_go_print_text_go_float_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_repr_go_print_text_go_float_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_repr_go_print_text_go_float_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_29)); return A_arbace_repr_go_print_text__init_A_const_28 }






















func A_arbace_repr_go_print_text__init_A_Unit17__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(151, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_30; var tmp2 any = A_arbace_repr_go_print_text_negative_number_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_repr_go_print_text_negative_number_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_repr_go_print_text_negative_number_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_31)); return A_arbace_repr_go_print_text__init_A_const_30 }









func A_arbace_repr_go_print_text__init_A_Unit18__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(161, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_32; var tmp2 any = A_arbace_repr_go_print_text_go_number_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_repr_go_print_text_go_number_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_repr_go_print_text_go_number_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_33)); return A_arbace_repr_go_print_text__init_A_const_32 }











func A_arbace_repr_go_print_text__init_A_Unit19__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(173, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_34; var tmp2 any = A_arbace_repr_go_print_text_escape_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_repr_go_print_text_escape_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_repr_go_print_text_escape_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_35)); return A_arbace_repr_go_print_text__init_A_const_34 }






func A_arbace_repr_go_print_text__init_A_Unit20__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(180, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_36; var tmp2 any = A_arbace_repr_go_print_text_unescape_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_repr_go_print_text_unescape_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_repr_go_print_text_unescape_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_37)); return A_arbace_repr_go_print_text__init_A_const_36 }








func A_arbace_repr_go_print_text__init_A_Unit21__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(189, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_38; var tmp2 any = A_arbace_repr_go_print_text_cell_width_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_repr_go_print_text_cell_width_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_repr_go_print_text_cell_width_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_39)); return A_arbace_repr_go_print_text__init_A_const_38 }

func A_arbace_repr_go_print_text__init_A_Unit22__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(191, 1); A_arbace_repr_go_print_text__init_A_const_40.BindRoot_O__V(A_arbace_repr_go_print_text__init_A_const_41); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_40; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_42)); return A_arbace_repr_go_print_text__init_A_const_40 }

func A_arbace_repr_go_print_text__init_A_Unit23__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(193, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_43; var tmp2 any = A_arbace_repr_go_print_text_parse_lines_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_repr_go_print_text_parse_lines_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_repr_go_print_text_parse_lines_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_44)); return A_arbace_repr_go_print_text__init_A_const_43 }


















func A_arbace_repr_go_print_text__init_A_Unit24__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(212, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_45; var tmp2 any = A_arbace_repr_go_print_text_write_padding_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_repr_go_print_text_write_padding_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_repr_go_print_text_write_padding_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_46)); return A_arbace_repr_go_print_text__init_A_const_45 }






func A_arbace_repr_go_print_text__init_A_Unit25__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(219, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_47; var tmp2 any = A_arbace_repr_go_print_text_write_lines_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_repr_go_print_text_write_lines_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_repr_go_print_text_write_lines_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_48)); return A_arbace_repr_go_print_text__init_A_const_47 }














func A_arbace_repr_go_print_text__init_A_Unit26__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(234, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_49; var tmp2 any = A_arbace_repr_go_print_text_format_block_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_repr_go_print_text_format_block_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_repr_go_print_text_format_block_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_50)); return A_arbace_repr_go_print_text__init_A_const_49 }


























func A_arbace_repr_go_print_text__init_A_Unit27__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(261, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_51; var tmp2 any = A_arbace_repr_go_print_text_align_block_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_repr_go_print_text_align_block_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); A_arbace_repr_go_print_text_align_block_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_52)); return A_arbace_repr_go_print_text__init_A_const_51 }







func A_arbace_repr_go_print_text__init_A_Unit28__O() any { A_arbace_repr_go_print_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(269, 1); var tmp1 *lang.Var = A_arbace_repr_go_print_text__init_A_const_53; var tmp2 any = A_arbace_repr_go_print_text_align_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_repr_go_print_text_align_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); A_arbace_repr_go_print_text_align_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_print_text__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_print_text__init_A_const_54)); return A_arbace_repr_go_print_text__init_A_const_53 }



type A_arbace_repr_go_print_text__init_A struct{ jrt.Object }

var A_arbace_repr_go_print_text__init_A_const_pool *jrt.RefArray

var A_arbace_repr_go_print_text__init_A_const_0 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_1 any

var A_arbace_repr_go_print_text__init_A_const_2 any

var A_arbace_repr_go_print_text__init_A_const_3 any

var A_arbace_repr_go_print_text__init_A_const_4 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_5 any

var A_arbace_repr_go_print_text__init_A_const_6 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_7 any

var A_arbace_repr_go_print_text__init_A_const_8 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_9 any

var A_arbace_repr_go_print_text__init_A_const_10 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_11 any

var A_arbace_repr_go_print_text__init_A_const_12 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_13 any

var A_arbace_repr_go_print_text__init_A_const_14 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_15 any

var A_arbace_repr_go_print_text__init_A_const_16 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_17 any

var A_arbace_repr_go_print_text__init_A_const_18 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_19 any

var A_arbace_repr_go_print_text__init_A_const_20 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_21 any

var A_arbace_repr_go_print_text__init_A_const_22 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_23 any

var A_arbace_repr_go_print_text__init_A_const_24 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_25 any

var A_arbace_repr_go_print_text__init_A_const_26 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_27 any

var A_arbace_repr_go_print_text__init_A_const_28 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_29 any

var A_arbace_repr_go_print_text__init_A_const_30 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_31 any

var A_arbace_repr_go_print_text__init_A_const_32 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_33 any

var A_arbace_repr_go_print_text__init_A_const_34 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_35 any

var A_arbace_repr_go_print_text__init_A_const_36 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_37 any

var A_arbace_repr_go_print_text__init_A_const_38 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_39 any

var A_arbace_repr_go_print_text__init_A_const_40 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_41 any

var A_arbace_repr_go_print_text__init_A_const_42 any

var A_arbace_repr_go_print_text__init_A_const_43 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_44 any

var A_arbace_repr_go_print_text__init_A_const_45 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_46 any

var A_arbace_repr_go_print_text__init_A_const_47 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_48 any

var A_arbace_repr_go_print_text__init_A_const_49 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_50 any

var A_arbace_repr_go_print_text__init_A_const_51 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_52 any

var A_arbace_repr_go_print_text__init_A_const_53 *lang.Var

var A_arbace_repr_go_print_text__init_A_const_54 any

var A_arbace_repr_go_print_text__init_A_init jrt.ClassInit

func A_arbace_repr_go_print_text__init_A_Init() { if !A_arbace_repr_go_print_text__init_A_init.Done() { A_arbace_repr_go_print_text__init_A_init.Run(A_arbace_repr_go_print_text__init_A_clinit) } }

func A_arbace_repr_go_print_text__init_A_clinit() { A_arbace_repr_go_print_text__init_A_clinit_p0(); A_arbace_repr_go_print_text__init_A_clinit_p1(); A_arbace_repr_go_print_text__init_A_clinit_p2(); A_arbace_repr_go_print_text__init_A_clinit_p3(); A_arbace_repr_go_print_text__init_A_clinit_p4() }

func A_arbace_repr_go_print_text__init_A_clinit_p0() { A_arbace_repr_go_print_text__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_39, 80); A_arbace_repr_go_print_text__init_A_const_0 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[25]); A_arbace_repr_go_print_text__init_A_const_1 = A_arbace_repr_go_print_text__init_A_const_pool.A[26]; A_arbace_repr_go_print_text__init_A_const_2 = A_arbace_repr_go_print_text__init_A_const_pool.A[27]; A_arbace_repr_go_print_text__init_A_const_3 = A_arbace_repr_go_print_text__init_A_const_pool.A[28]; A_arbace_repr_go_print_text__init_A_const_4 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[29]); A_arbace_repr_go_print_text__init_A_const_5 = A_arbace_repr_go_print_text__init_A_const_pool.A[30]; A_arbace_repr_go_print_text__init_A_const_6 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[31]); A_arbace_repr_go_print_text__init_A_const_7 = A_arbace_repr_go_print_text__init_A_const_pool.A[32]; A_arbace_repr_go_print_text__init_A_const_8 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[33]); A_arbace_repr_go_print_text__init_A_const_9 = A_arbace_repr_go_print_text__init_A_const_pool.A[34]; A_arbace_repr_go_print_text__init_A_const_10 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[35]); A_arbace_repr_go_print_text__init_A_const_11 = A_arbace_repr_go_print_text__init_A_const_pool.A[36]; A_arbace_repr_go_print_text__init_A_const_12 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[37]) }

func A_arbace_repr_go_print_text__init_A_clinit_p1() { A_arbace_repr_go_print_text__init_A_const_13 = A_arbace_repr_go_print_text__init_A_const_pool.A[38]; A_arbace_repr_go_print_text__init_A_const_14 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[39]); A_arbace_repr_go_print_text__init_A_const_15 = A_arbace_repr_go_print_text__init_A_const_pool.A[40]; A_arbace_repr_go_print_text__init_A_const_16 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[41]); A_arbace_repr_go_print_text__init_A_const_17 = A_arbace_repr_go_print_text__init_A_const_pool.A[42]; A_arbace_repr_go_print_text__init_A_const_18 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[43]); A_arbace_repr_go_print_text__init_A_const_19 = A_arbace_repr_go_print_text__init_A_const_pool.A[44]; A_arbace_repr_go_print_text__init_A_const_20 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[45]); A_arbace_repr_go_print_text__init_A_const_21 = A_arbace_repr_go_print_text__init_A_const_pool.A[46]; A_arbace_repr_go_print_text__init_A_const_22 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[47]); A_arbace_repr_go_print_text__init_A_const_23 = A_arbace_repr_go_print_text__init_A_const_pool.A[48]; A_arbace_repr_go_print_text__init_A_const_24 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[49]); A_arbace_repr_go_print_text__init_A_const_25 = A_arbace_repr_go_print_text__init_A_const_pool.A[50] }

func A_arbace_repr_go_print_text__init_A_clinit_p2() { A_arbace_repr_go_print_text__init_A_const_26 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[51]); A_arbace_repr_go_print_text__init_A_const_27 = A_arbace_repr_go_print_text__init_A_const_pool.A[52]; A_arbace_repr_go_print_text__init_A_const_28 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[53]); A_arbace_repr_go_print_text__init_A_const_29 = A_arbace_repr_go_print_text__init_A_const_pool.A[54]; A_arbace_repr_go_print_text__init_A_const_30 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[55]); A_arbace_repr_go_print_text__init_A_const_31 = A_arbace_repr_go_print_text__init_A_const_pool.A[56]; A_arbace_repr_go_print_text__init_A_const_32 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[57]); A_arbace_repr_go_print_text__init_A_const_33 = A_arbace_repr_go_print_text__init_A_const_pool.A[58]; A_arbace_repr_go_print_text__init_A_const_34 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[59]); A_arbace_repr_go_print_text__init_A_const_35 = A_arbace_repr_go_print_text__init_A_const_pool.A[60]; A_arbace_repr_go_print_text__init_A_const_36 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[61]); A_arbace_repr_go_print_text__init_A_const_37 = A_arbace_repr_go_print_text__init_A_const_pool.A[62]; A_arbace_repr_go_print_text__init_A_const_38 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[63]) }

func A_arbace_repr_go_print_text__init_A_clinit_p3() { A_arbace_repr_go_print_text__init_A_const_39 = A_arbace_repr_go_print_text__init_A_const_pool.A[64]; A_arbace_repr_go_print_text__init_A_const_40 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[65]); A_arbace_repr_go_print_text__init_A_const_41 = A_arbace_repr_go_print_text__init_A_const_pool.A[66]; A_arbace_repr_go_print_text__init_A_const_42 = A_arbace_repr_go_print_text__init_A_const_pool.A[67]; A_arbace_repr_go_print_text__init_A_const_43 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[68]); A_arbace_repr_go_print_text__init_A_const_44 = A_arbace_repr_go_print_text__init_A_const_pool.A[69]; A_arbace_repr_go_print_text__init_A_const_45 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[70]); A_arbace_repr_go_print_text__init_A_const_46 = A_arbace_repr_go_print_text__init_A_const_pool.A[71]; A_arbace_repr_go_print_text__init_A_const_47 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[72]); A_arbace_repr_go_print_text__init_A_const_48 = A_arbace_repr_go_print_text__init_A_const_pool.A[73]; A_arbace_repr_go_print_text__init_A_const_49 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[74]); A_arbace_repr_go_print_text__init_A_const_50 = A_arbace_repr_go_print_text__init_A_const_pool.A[75]; A_arbace_repr_go_print_text__init_A_const_51 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[76]); A_arbace_repr_go_print_text__init_A_const_52 = A_arbace_repr_go_print_text__init_A_const_pool.A[77] }

func A_arbace_repr_go_print_text__init_A_clinit_p4() { A_arbace_repr_go_print_text__init_A_const_53 = lang.Var_Cast(A_arbace_repr_go_print_text__init_A_const_pool.A[78]); A_arbace_repr_go_print_text__init_A_const_54 = A_arbace_repr_go_print_text__init_A_const_pool.A[79] }

func A_arbace_repr_go_print_text__init_A_New() *A_arbace_repr_go_print_text__init_A { A_arbace_repr_go_print_text__init_A_Init(); t := &A_arbace_repr_go_print_text__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_print_text__init_A) Ctor() {}

func (t *A_arbace_repr_go_print_text__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_print_text__init_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_print_text__init_A_class }

func (t *A_arbace_repr_go_print_text__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_print_text__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_print_text__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_print_text__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_print_text__init_A); return ok }

func A_arbace_repr_go_print_text__init_A_Cast(x any) *A_arbace_repr_go_print_text__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_print_text__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_print_text__init_A_class)) }; return v }
