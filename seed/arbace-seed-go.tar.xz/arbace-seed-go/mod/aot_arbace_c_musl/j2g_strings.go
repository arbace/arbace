//line j2g_strings.ae:1
package aot_arbace_c_musl

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.repr.ckn2,asyn2,rcyn18,arbace.repr.c.hostyn4,hostyn14,arbace.c.buildyn5,buildyn13,arbace.stringyn3,strkn3,dockn7,includekn3,syskn10,predefinedkn9,trigraphskn4,elseks1,c5,attrsks1,c11,after-attrsks1,c10,decl-attrsks1,c9,gnu-attrsks1,c9,def-attrsks1,c9,end-attrsks1,c14,decl-end-attrsys1,c2,idys1,c3,varkn6,statickn4,weakkn5,aliasys1,c4,defnkn6,externkn2,fnkn1,kkn3,tagys1,c5,groupys1,c7,declareys1,c7,typedefkn5,errorkn7,refusedkn2,okkn7,messagekn5,unitskn5,formskn6,headerkn4,defskn4,refskn4,rootkn1,hkn5,indexkn7,by-namekn7,checkedys12,arbace.c.run10,check-readkn3,srckn2,rdkn10,libc-startv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn13,arbace.c.muslm2,R10,s1031,ci's libc (doc/C23-SURVEY.md §6.5, CS11 (a), CS12 (a); doc/c/SPEC.md §12.5): musl 1.2.6 as C forms, read\n  by repr/c in a configuration of Arbace's where long double is double (CS35: __SIZEOF_LONG_DOUBLE__ 8,\n  __LDBL_MANT_DIG__ 53, musl's arch/arm/bits/float.h before arch/x86_64's: LDBL_MANT_DIG 53), with musl's\n  own include path and options (-std=c99 -ffreestanding -D_XOPEN_SOURCE=700), its generic C sources (an\n  x86_64 source whose body is assembly is a native of go/arbace/ci), linked into a program as a static\n  link pulls archive members: a unit when it defines a symbol the program still needs, a weak definition\n  satisfying a reference, a strong one overriding a weak.\n\n  The release tarball (test/c/corpora.edn's :musl-1.2.6, its SHA-256 checked) is extracted and configured\n  by bin/ci musl prepare into .tmp/ci-musl/musl-1.2.6 (CI_MUSL); `read-all` reads its sources into the\n  forms cache .tmp/ci-musl/forms (CI_MUSL_FORMS: one .ae per source and its header units, the index\n  index.edn), read again from there.v13,arbace.c.musl3,envv13,arbace.c.musl9,musl-rootv18,arbace.repr.c.host11,file-configv13,arbace.c.musl7,optionsv11,arbace.core5,assocv18,arbace.repr.c.host6,configR11,R12,R13,R14,v11,arbace.core3,vecv11,arbace.core4,sortv11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core4,subsv11,arbace.core3,notv13,arbace.c.musl13,excluded-dirsv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv13,arbace.c.musl15,native-replacedv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core6,concatv11,arbace.core4,atomv11,arbace.core7,symbol?v13,arbace.string7,replacev11,arbace.core4,namep7,^__|__$v11,arbace.core7,vector?v11,arbace.core4,seq?R15,S2,s5,aliass9,__alias__v11,arbace.core7,string?v11,arbace.core6,reset!v11,arbace.core4,nextV7,R16,R17,R18,R19,R20,R21,R22,v11,arbace.core3,setR23,v11,arbace.core6,secondv11,arbace.core4,intoR24,v13,arbace.c.musl8,sym-namev13,arbace.c.musl10,attr-namesv11,arbace.core9,contains?R25,R26,R27,R28,R24,R29,R30,R31,R32,R33,v11,arbace.core4,dropl2,R28,R34,v11,arbace.core9,namespaceR34,R33,R24,R35,R28,v11,arbace.core4,spitv13,arbace.c.musl6,configv13,arbace.repr.c6,read-cR36,R37,v13,arbace.c.musl10,forms-rootR38,v13,arbace.string4,joinv11,arbace.core4,takeR39,v13,arbace.repr.c10,unit-textsv13,arbace.c.musl7,spit-mkv11,arbace.core6,pr-strv11,arbace.core3,mapv11,arbace.core3,strv11,arbace.core4,keysR40,v13,arbace.c.musl7,sourcesv11,arbace.core6,removel0,v11,arbace.core5,doallv11,arbace.core11,future-callv13,arbace.c.musl8,read-onev11,arbace.core5,swap!v11,arbace.core3,incv11,arbace.core3,modl50,v11,arbace.core7,printlnv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core5,rangev13,arbace.repr.c14,read-unit-textv11,arbace.core5,slurpv11,arbace.core11,read-stringR41,l4,v11,arbace.core6,symbolR42,v11,arbace.core10,sorted-mapv13,arbace.c.musl9,load-unitv11,arbace.core6,mapcatv11,arbace.core4,valsR43,v13,arbace.c.musl9,unit-defsR44,v13,arbace.c.musl4,refsv13,arbace.c.musl5,indexR45,R46,R47,R48,R49,v11,arbace.core8,to-arrayv13,arbace.c.musl5,rootsv11,arbace.core7,resolveR50,R51,R52,v11,arbace.core4,keepv13,arbace.string12,starts-with?l10,v13,arbace.c.musl7,closurev11,arbace.core4,mapvv13,arbace.c.musl12,checked-unitv14,arbace.c.build13,build-programR53,")

var Lit_1 *jrt.String = jrt.Intern("arbace.c.musl$attr_names$walk__1657000035")

var Lit_2 *jrt.String = jrt.Intern("")

var Lit_3 *jrt.String = jrt.Intern("arbace.c.musl$build_linked$fn__1657000243")

var Lit_4 *jrt.String = jrt.Intern("arbace.c.musl$build_linked$fn__1657000245")

var Lit_5 *jrt.String = jrt.Intern("arbace.c.musl$build_linked$fn__1657000247")

var Lit_6 *jrt.String = jrt.Intern("CI_TRACE")

var Lit_7 *jrt.String = jrt.Intern("arbace.c.musl$build_linked$fn__1657000249")

var Lit_8 *jrt.String = jrt.Intern("arbace.c.musl$build_linked$fn__1657000251")

var Lit_9 *jrt.String = jrt.Intern("__builtin_")

var Lit_10 *jrt.String = jrt.Intern("musl: linked")

var Lit_11 *jrt.String = jrt.Intern("c99")

var Lit_12 *jrt.String = jrt.Intern("/.tmp/ci-musl/ldbl53")

var Lit_13 *jrt.String = jrt.Intern("arch/x86_64")

var Lit_14 *jrt.String = jrt.Intern("arch/generic")

var Lit_15 *jrt.String = jrt.Intern("obj/src/internal")

var Lit_16 *jrt.String = jrt.Intern("src/include")

var Lit_17 *jrt.String = jrt.Intern("src/internal")

var Lit_18 *jrt.String = jrt.Intern("obj/include")

var Lit_19 *jrt.String = jrt.Intern("include")

var Lit_20 *jrt.String = jrt.Intern("#define _XOPEN_SOURCE 700\n")

var Lit_21 *jrt.String = jrt.Intern("#define __STDC_HOSTED__ 1")

var Lit_22 *jrt.String = jrt.Intern("#define __STDC_HOSTED__ 0")

var Lit_23 *jrt.String = jrt.Intern("#define __SIZEOF_LONG_DOUBLE__ 16")

var Lit_24 *jrt.String = jrt.Intern("#define __SIZEOF_LONG_DOUBLE__ 8")

var Lit_25 *jrt.String = jrt.Intern("#define __LDBL_MANT_DIG__ 64")

var Lit_26 *jrt.String = jrt.Intern("#define __LDBL_MANT_DIG__ 53")

var Lit_27 *jrt.String = jrt.Intern("#define __LDBL_DIG__ 18")

var Lit_28 *jrt.String = jrt.Intern("#define __LDBL_DIG__ 15")

var Lit_29 *jrt.String = jrt.Intern("#define __LDBL_MAX_EXP__ 16384")

var Lit_30 *jrt.String = jrt.Intern("#define __LDBL_MAX_EXP__ 1024")

var Lit_31 *jrt.String = jrt.Intern("#define __LDBL_MIN_EXP__ (-16381)")

var Lit_32 *jrt.String = jrt.Intern("#define __LDBL_MIN_EXP__ (-1021)")

var Lit_33 *jrt.String = jrt.Intern("java.io.File")

var Lit_34 *jrt.String = jrt.Intern("java.util.ArrayDeque")

var Lit_35 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_36 *jrt.String = jrt.Intern("java.util.HashSet")

var Lit_37 *jrt.String = jrt.Intern("CI_MUSL_FORMS")

var Lit_38 *jrt.String = jrt.Intern("/.tmp/ci-musl/forms")

var Lit_39 *jrt.String = jrt.Intern("/index.edn")

var Lit_40 *jrt.String = jrt.Intern("arbace.c.musl$index$iter__1657000169__1657000173")

var Lit_41 *jrt.String = jrt.Intern("arbace.c.musl$index$iter__1657000169__1657000173$fn__1657000174")

var Lit_42 *jrt.String = jrt.Intern("arbace.c.musl$index$iter__1657000169__1657000173$fn__1657000174$fn__1657000175")

var Lit_43 *jrt.String = jrt.Intern("/")

var Lit_44 *jrt.String = jrt.Intern(".ae")

var Lit_45 *jrt.String = jrt.Intern(".units")

var Lit_46 *jrt.String = jrt.Intern("arbace.c.musl$load_unit$iter__1657000152__1657000156")

var Lit_47 *jrt.String = jrt.Intern("arbace.c.musl$load_unit$iter__1657000152__1657000156$fn__1657000157")

var Lit_48 *jrt.String = jrt.Intern("arbace.c.musl$load_unit$iter__1657000152__1657000156$fn__1657000157$fn__1657000158")

var Lit_49 *jrt.String = jrt.Intern("/c/h/")

var Lit_50 *jrt.String = jrt.Intern("CI_MUSL")

var Lit_51 *jrt.String = jrt.Intern("/.tmp/ci-musl/musl-1.2.6")

var Lit_52 *jrt.String = jrt.Intern("arbace.c.musl$read_all$fn__1657000120")

var Lit_53 *jrt.String = jrt.Intern("arbace.c.musl$read_all$iter__1657000122__1657000126")

var Lit_54 *jrt.String = jrt.Intern("arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127")

var Lit_55 *jrt.String = jrt.Intern("arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000128")

var Lit_56 *jrt.String = jrt.Intern("arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000136")

var Lit_57 *jrt.String = jrt.Intern("arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000128$fn__1657000129")

var Lit_58 *jrt.String = jrt.Intern("arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000128$fn__1657000129$fn__1657000130")

var Lit_59 *jrt.String = jrt.Intern("arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000128$fn__1657000129$fn__1657000132")

var Lit_60 *jrt.String = jrt.Intern("musl: read")

var Lit_61 *jrt.String = jrt.Intern("of")

var Lit_62 *jrt.String = jrt.Intern("arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000136$fn__1657000137")

var Lit_63 *jrt.String = jrt.Intern("arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000136$fn__1657000139")

var Lit_64 *jrt.String = jrt.Intern("; ")

var Lit_65 *jrt.String = jrt.Intern(": ")

var Lit_66 *jrt.String = jrt.Intern("c/h/")

var Lit_67 *jrt.String = jrt.Intern("arbace.c.musl$refs$walk__1657000075")

var Lit_68 *jrt.String = jrt.Intern("arbace.c.musl$refs$decl__1657000081")

var Lit_69 *jrt.String = jrt.Intern("arbace.c.musl$refs$walk_meta__1657000094")

var Lit_70 *jrt.String = jrt.Intern("src")

var Lit_71 *jrt.String = jrt.Intern("arbace.c.musl$sources$iter__1657000018__1657000024")

var Lit_72 *jrt.String = jrt.Intern("malloc/mallocng")

var Lit_73 *jrt.String = jrt.Intern("arbace.c.musl$sources$iter__1657000018__1657000024$fn__1657000025")

var Lit_74 *jrt.String = jrt.Intern("arbace.c.musl$sources$iter__1657000018__1657000024$fn__1657000025$iter__1657000020__1657000026")

var Lit_75 *jrt.String = jrt.Intern("arbace.c.musl$sources$iter__1657000018__1657000024$fn__1657000025$iter__1657000020__1657000026$fn__1657000027")

var Lit_76 *jrt.String = jrt.Intern("arbace.c.musl$sources$iter__1657000018__1657000024$fn__1657000025$iter__1657000020__1657000026$fn__1657000027$fn__1657000028")

var Lit_77 *jrt.String = jrt.Intern(".c")

var Lit_78 *jrt.String = jrt.Intern("arbace.c.musl$unit_defs$decl__1657000054")

var Lit_79 *jrt.String = jrt.Intern("weak")

var Lit_80 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistskn3,tagyn6,Stringkn4,linekn6,columnkn4,fileyn16,java.lang.Stringyn1,hyn1,myn1,xyn5,formsyn7,threadsyn3,libyn9,prog-defsyn9,prog-refsyn5,unitsv11,arbace.core5,in-nsMyn13,arbace.c.muslm2,R0,s1031,ci's libc (doc/C23-SURVEY.md §6.5, CS11 (a), CS12 (a); doc/c/SPEC.md §12.5): musl 1.2.6 as C forms, read\n  by repr/c in a configuration of Arbace's where long double is double (CS35: __SIZEOF_LONG_DOUBLE__ 8,\n  __LDBL_MANT_DIG__ 53, musl's arch/arm/bits/float.h before arch/x86_64's: LDBL_MANT_DIG 53), with musl's\n  own include path and options (-std=c99 -ffreestanding -D_XOPEN_SOURCE=700), its generic C sources (an\n  x86_64 source whose body is assembly is a native of go/arbace/ci), linked into a program as a static\n  link pulls archive members: a unit when it defines a symbol the program still needs, a weak definition\n  satisfying a reference, a strong one overriding a weak.\n\n  The release tarball (test/c/corpora.edn's :musl-1.2.6, its SHA-256 checked) is extracted and configured\n  by bin/ci musl prepare into .tmp/ci-musl/musl-1.2.6 (CI_MUSL); `read-all` reads its sources into the\n  forms cache .tmp/ci-musl/forms (CI_MUSL_FORMS: one .ae per source and its header units, the index\n  index.edn), read again from there.m2,R0,s1031,ci's libc (doc/C23-SURVEY.md §6.5, CS11 (a), CS12 (a); doc/c/SPEC.md §12.5): musl 1.2.6 as C forms, read\n  by repr/c in a configuration of Arbace's where long double is double (CS35: __SIZEOF_LONG_DOUBLE__ 8,\n  __LDBL_MANT_DIG__ 53, musl's arch/arm/bits/float.h before arch/x86_64's: LDBL_MANT_DIG 53), with musl's\n  own include path and options (-std=c99 -ffreestanding -D_XOPEN_SOURCE=700), its generic C sources (an\n  x86_64 source whose body is assembly is a native of go/arbace/ci), linked into a program as a static\n  link pulls archive members: a unit when it defines a symbol the program still needs, a weak definition\n  satisfying a reference, a strong one overriding a weak.\n\n  The release tarball (test/c/corpora.edn's :musl-1.2.6, its SHA-256 checked) is extracted and configured\n  by bin/ci musl prepare into .tmp/ci-musl/musl-1.2.6 (CI_MUSL); `read-all` reads its sources into the\n  forms cache .tmp/ci-musl/forms (CI_MUSL_FORMS: one .ae per source and its header units, the index\n  index.edn), read again from there.R1,v11,arbace.core20,*warn-on-reflection*v13,arbace.c.musl3,envm10,R2,TR3,L1,V2,Myn1,km2,R4,R5,Myn1,dm2,R4,R5,R6,i23,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl9,musl-rootm8,R3,L1,MV1,Myn4,rootm2,R4,R5,m2,R4,R9,R6,i25,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl10,forms-rootm8,R3,L1,MV1,Myn4,rootm2,R4,R5,m2,R4,R9,R6,i26,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl7,optionsV2,s8,-std=c99s19,-D_XOPEN_SOURCE=700m6,R6,i28,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl6,configm10,R3,L1,V2,R10,Myn4,rootm2,R4,R5,R0,s108,repr/c's configuration for musl's sources (the reference's c99 macros, freestanding, long double as double).R6,i30,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl13,excluded-dirsS1,s8,src/ldsom8,R6,i49,R7,i1,R8,s16,arbace/c/musl.aeR0,s85,musl's source directories a static program of ci's does not link: the dynamic linker.v13,arbace.c.musl15,native-replacedS9,s20,src/setjmp/longjmp.cs30,src/thread/__set_thread_area.cs18,src/thread/clone.cs19,src/setjmp/setjmp.cs24,src/thread/__unmapself.cs20,src/signal/restore.cs22,src/signal/sigsetjmp.cs23,src/thread/syscall_cp.cs19,src/process/vfork.cm8,R6,i53,R7,i1,R8,s16,arbace/c/musl.aeR0,s393,The generic sources whose x86_64 version is assembly (src/*/x86_64/*.s) and that a generic C stub would\n  get wrong: left out, the functions natives of go/arbace/ci (setjmp, longjmp, the thread pointer, the\n  cancellable syscall's entry). The other generic versions of x86_64's assembly are kept (memcpy, the\n  long double math, which is double's, CS35; fenv, round to nearest only, CS34 (a)).v13,arbace.c.musl7,sourcesm10,R3,L1,V1,Myn4,rootm2,R4,R5,R0,s148,musl's C sources as its Makefile selects them for a static libc.a, the generic ones (src/*/*.c and\n  src/malloc/mallocng/*.c), relative to the root.R6,i62,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl10,attr-namesm12,R2,TR3,L1,V1,R11,R0,s91,The attribute names and alias targets in a declaration's metadata: [#{names} alias-target].R6,i81,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl8,sym-namem10,R2,TR3,L1,V1,R12,R6,i97,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl9,unit-defsm10,R3,L1,V1,R13,R0,s84,A unit's definitions: {name {:weak bool :alias target-or-nil}} (external ones only).R6,i99,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl4,refsm10,R3,L1,V1,R13,R0,s203,The names the code of forms may reference: every symbol in function bodies, initializers, array sizes\n  and attributes' arguments (a superset of the external names it references), not the declared names.R6,i120,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl7,spit-mkm10,R2,TR3,L1,V2,Myn4,pathm2,R4,R5,Myn1,sm2,R4,R5,R6,i147,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl8,read-onem10,R3,L1,V3,R10,Myn4,rootm2,R4,R5,Myn3,srcm2,R4,R5,R0,s53,One source read into the cache: :ok, or [:error msg].R6,i151,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl8,read-allm10,R3,L1,V3,R10,Myn4,rootm2,R4,R5,R14,R0,s97,Every source not in the cache read (in `threads` threads); the index written. Returns the errors.R6,i167,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl9,load-unitm10,R3,L1,V2,Myn4,rootm2,R4,R5,Myn3,srcm2,R4,R5,R0,s96,A cached source's read: {:forms :units} as arbace.repr.c/read-c gives (its header units' forms).R6,i187,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl5,indexm10,R3,L1,V1,Myn4,rootm2,R4,R5,R0,s94,The index of the cached sources: {src {:defs .. :refs #{..}}}, made once (index.edn) and kept.R6,i198,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl7,librarym10,R3,L1,V2,R10,Myn4,rootm2,R4,R5,R0,s87,musl as a library: {:root :index :by-name {name [src ...]} :checked (atom {src unit})}.R6,i216,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl5,rootsV2,s17,__libc_start_mains4,exitm8,R6,i226,R7,i1,R8,s16,arbace/c/musl.aeR0,s54,What every program needs of the libc: its start, exit.v13,arbace.c.musl7,closurem10,R3,L1,V3,R15,R16,R17,R0,s168,The musl sources a program of units needs: those defining a symbol the program or a linked unit\n  references and no linked unit defines (a strong definition preferred).R6,i230,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl12,checked-unitm10,R3,L1,V2,R15,Myn3,srcm2,R4,R5,R0,s68,A musl source read from the cache and checked (kept in the library).R6,i250,R7,i1,R8,s16,arbace/c/musl.aev13,arbace.c.musl12,build-linkedm10,R3,L1,V2,R15,R18,R0,s75,The node program of the program's units linked with what they need of musl.R6,i260,R7,i1,R8,s16,arbace/c/musl.ae")

var Lit_81 *jrt.String = jrt.Intern("arbace.c.musl$eval1657000004$loading__1927001464__auto____1657000005")

var Lit_82 *jrt.String = jrt.Intern("arbace.c.musl$eval1657000008$fn__1657000009")

var Lit_83 *jrt.String = jrt.Intern("arbace.c.musl$env")

var Lit_84 *jrt.String = jrt.Intern("arbace.c.musl$musl_root")

var Lit_85 *jrt.String = jrt.Intern("arbace.c.musl$forms_root")

var Lit_86 *jrt.String = jrt.Intern("arbace.c.musl$config")

var Lit_87 *jrt.String = jrt.Intern("arbace.c.musl$sources")

var Lit_88 *jrt.String = jrt.Intern("arbace.c.musl$attr_names")

var Lit_89 *jrt.String = jrt.Intern("arbace.c.musl$sym_name")

var Lit_90 *jrt.String = jrt.Intern("arbace.c.musl$unit_defs")

var Lit_91 *jrt.String = jrt.Intern("arbace.c.musl$refs")

var Lit_92 *jrt.String = jrt.Intern("arbace.c.musl$spit_mk")

var Lit_93 *jrt.String = jrt.Intern("arbace.c.musl$read_one")

var Lit_94 *jrt.String = jrt.Intern("arbace.c.musl$read_all")

var Lit_95 *jrt.String = jrt.Intern("arbace.c.musl$load_unit")

var Lit_96 *jrt.String = jrt.Intern("arbace.c.musl$index")

var Lit_97 *jrt.String = jrt.Intern("arbace.c.musl$library")

var Lit_98 *jrt.String = jrt.Intern("arbace.c.musl$closure")

var Lit_99 *jrt.String = jrt.Intern("arbace.c.musl$checked_unit")

var Lit_100 *jrt.String = jrt.Intern("arbace.c.musl$build_linked")
