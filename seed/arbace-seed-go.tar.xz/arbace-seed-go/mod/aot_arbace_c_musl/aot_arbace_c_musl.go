//line aot_arbace_c_musl.ae:1
package aot_arbace_c_musl

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_c"
	"arbace/aot_arbace_repr_c_host"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A_New() *A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c_musl_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c_musl_A_const_1); lang.IFn_Cast(A_arbace_c_musl_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_c_musl_A_const_3, A_arbace_c_musl_A_const_4, A_arbace_c_musl_A_const_5, A_arbace_c_musl_A_const_6); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_33)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_34)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_35)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_36)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c_musl_eval1657000008_fn__1657000009_A_New() *A_arbace_c_musl_eval1657000008_fn__1657000009_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_eval1657000008_fn__1657000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_musl_eval1657000008_fn__1657000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_musl_eval1657000008_fn__1657000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_7.GetRawRoot__O()); var tmp2 any; var root_18 any = A_arbace_c_musl_A_const_8.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = A_arbace_c_musl_A_const_9; if linked_19 == nil { tmp2 = ifn_20.Invoke_O__O(arg_21) } else { tmp2 = linked_19.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_18, arg_21) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c_musl_A_const_10.GetRawRoot__O(), A_arbace_c_musl_A_const_11) }





















func A_arbace_c_musl_env_A_New() *A_arbace_c_musl_env_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_env_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_c_musl_env_A) Ctor() {}
//line :23:1
func (t *A_arbace_c_musl_env_A) Invoke_O_O_O__O(self, k__0, d__1 any) any { var or__1927000174__auto____3 any = jrt.System_Getenv_String__String(jrt.String_Cast(k__0)).Ref(); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return d__1 } }

func A_arbace_c_musl_musl_root_A_New() *A_arbace_c_musl_musl_root_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_musl_root_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_c_musl_musl_root_A) Ctor() {}
//line :25:1
func (t *A_arbace_c_musl_musl_root_A) Invoke_O_O__O(self, root__0 any) any { var root_22 any = A_arbace_c_musl_A_const_12.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, A_arbace_c_musl_env_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = Lit_50; var arg_26 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_51), jrt.RefArrayOf(jrt.Object_class, root__0, nil)).Ref(); if linked_23 == nil { return ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { return linked_23.(*A_arbace_c_musl_env_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) } }
func A_arbace_c_musl_forms_root_A_New() *A_arbace_c_musl_forms_root_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_forms_root_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_c_musl_forms_root_A) Ctor() {}
//line :26:1
func (t *A_arbace_c_musl_forms_root_A) Invoke_O_O__O(self, root__0 any) any { var root_27 any = A_arbace_c_musl_A_const_12.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, A_arbace_c_musl_env_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = Lit_37; var arg_31 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, root__0, nil)).Ref(); if linked_28 == nil { return ifn_29.Invoke_O_O__O(arg_30, arg_31) } else { return linked_28.(*A_arbace_c_musl_env_A).Invoke_O_O_O__O(root_27, arg_30, arg_31) } }



func A_arbace_c_musl_config_A_New() *A_arbace_c_musl_config_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_config_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_c_musl_config_A) Ctor() {}
//line :30:1
func (t *A_arbace_c_musl_config_A) Invoke_O_O_O__O(self, h__0, root__1 any) any { var m__3 any; var root_32 any = A_arbace_c_musl_A_const_13.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, A_arbace_c_musl_musl_root_A_fn_class); var ifn_34 lang.IFn; if


	linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = root__1; if linked_33 == nil { m__3 = ifn_34.Invoke_O__O(arg_35) } else { m__3 = linked_33.(*A_arbace_c_musl_musl_root_A).Invoke_O_O__O(root_32, arg_35) }; var fc__4 any; var root_36 any = /*line :30:1*/A_arbace_c_musl_A_const_14.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A_fn_class); var ifn_38 lang.IFn; if



	linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = A_arbace_c_musl_A_const_15.GetRawRoot__O(); var arg_40 any = Lit_11; if linked_37 == nil { fc__4 = ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { fc__4 = linked_37.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A).Invoke_O_O_O__O(root_36, arg_39, arg_40) }; var tmp1 lang.IFn = /*line :30:1*/lang.IFn_Cast(A_arbace_c_musl_A_const_16.GetRawRoot__O()); var tmp2 any; var root_53 any = A_arbace_c_musl_A_const_17.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A_fn_class); var ifn_55 lang.IFn; if




	linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = h__0; var arg_57 any = fc__4; var arg_58 any = m__3; if linked_54 == nil { tmp2 = ifn_55.Invoke_O_O_O__O(arg_56, arg_57, arg_58) } else { tmp2 = linked_54.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A).Invoke_O_O_O_O__O(root_53, arg_56, arg_57, arg_58) }; var tmp3 any = tmp2; var tmp4 any = A_arbace_c_musl_A_const_18; var tmp5 any = /*line :30:1*/lang.PersistentVector_EMPTY.Ref(); var tmp6 any = A_arbace_c_musl_A_const_19; var tmp7 any = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_12), jrt.RefArrayOf(jrt.Object_class, root__1, nil)).Ref(), Lit_13, Lit_14, Lit_15, Lit_16, Lit_17, Lit_18, Lit_19)); var tmp8 any = A_arbace_c_musl_A_const_20; return lang.Tuple_Create_O_O__IPersistentVector(fc__4, tmp1.Invoke_O_O_O_O_O_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.String_Cast(lang.RT_Get_O_O__O_NoInit(A_arbace_c_musl_A_const_20.Invoke_O__O(h__0), Lit_11))).Replace_CharSequence_CharSequence__String(Lit_21, Lit_22)).Replace_CharSequence_CharSequence__String(Lit_23, Lit_24)).Replace_CharSequence_CharSequence__String(Lit_25, Lit_26)).Replace_CharSequence_CharSequence__String(Lit_27, Lit_28)).Replace_CharSequence_CharSequence__String(Lit_29, Lit_30)).Replace_CharSequence_CharSequence__String(Lit_31, Lit_32).Ref(), nil)).Ref(), A_arbace_c_musl_A_const_21, jrt.Boolean_FALSE.Ref())) }































func A_arbace_c_musl_sources_A_New() *A_arbace_c_musl_sources_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sources_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_c_musl_sources_A) Ctor() {}
//line :62:1
func (t *A_arbace_c_musl_sources_A) Invoke_O_O__O(self, root__0 any) any { var m__2 any; var tmp1 any; var root_59 any = A_arbace_c_musl_A_const_13.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, A_arbace_c_musl_musl_root_A_fn_class); var ifn_61 lang.IFn; if



	linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = root__0; if linked_60 == nil { tmp1 = ifn_61.Invoke_O__O(arg_62) } else { tmp1 = linked_60.(*A_arbace_c_musl_musl_root_A).Invoke_O_O__O(root_59, arg_62) }; m__2 = /*line :62:1*/jrt.File_New_String(jrt.String_Cast(tmp1)); var src__3 any = jrt.File_New_File_String(jrt.File_Cast(m__2), Lit_70); var root_63 any = A_arbace_c_musl_A_const_22.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_65 lang.IFn; if





	linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any; var root_67 any = A_arbace_c_musl_A_const_23.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any; var iter__1927001039__auto____4 any; var fnbody__194 any = A_arbace_c_musl_sources_iter__1657000018__1657000024_A_New_O(m__2); var tmp2 *jrt.Class; var fncls__193 *jrt.Class = A_arbace_c_musl_sources_iter__1657000018__1657000024_A_fn_class; if fncls__193 == nil { var fncls__193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, fnbody__194); A_arbace_c_musl_sources_iter__1657000018__1657000024_A_fn_class = fncls__193d; tmp2 = fncls__193d } else { tmp2 = fncls__193 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__194, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp4 any; var root_195 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = jrt.File_Cast(src__3).ListFiles__File1().Ref(); var arg_199 any = lang.Tuple_Create_O__IPersistentVector(jrt.File_New_File_String(jrt.File_Cast(src__3), Lit_72)); if linked_196 == nil { tmp4 = ifn_197.Invoke_O_O__O(arg_198, arg_199) } else { tmp4 = linked_196.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_195, arg_198, arg_199) }; arg_70 = tmp3.Invoke_O__O(tmp4); if linked_68 == nil { arg_66 = ifn_69.Invoke_O__O(arg_70) } else { arg_66 = linked_68.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_67, arg_70) }; if linked_64 == nil { return ifn_65.Invoke_O__O(arg_66) } else { return linked_64.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_63, arg_66) } }
//line :68:1
func A_arbace_c_musl_sources_iter__1657000018__1657000024_A_New_O(p0 any) *A_arbace_c_musl_sources_iter__1657000018__1657000024_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sources_iter__1657000018__1657000024_A{}; t.Ctor_O(p0); return t }
//line :68:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :68:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_A) Invoke_O_O__O(self, s__1657000019__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__192 any = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A_New_O_O_O(s__1657000019__1, self, t.F_m); var tmp2 *jrt.Class; var fncls__191 *jrt.Class = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A_fn_class; if fncls__191 == nil { var fncls__191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, fnbody__192); A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A_fn_class = fncls__191d; tmp2 = fncls__191d } else { tmp2 = fncls__191 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__192, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :68:1
func A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :68:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A) Ctor_O_O_O(c__s__1657000019, c__iter__1657000018, c__m any) { t.F_s__1657000019 = c__s__1657000019; t.F_iter__1657000018 = c__iter__1657000018; t.F_m = c__m }
//line :68:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A) Invoke_O__O(self any) any { { var s__1657000019__1 any; var t_ any = t.F_s__1657000019; t.F_s__1657000019 = nil; s__1657000019__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_71 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = s__1657000019__1; if linked_72 == nil { temp__1927000414__auto____2 = ifn_73.Invoke_O__O(arg_74) } else { temp__1927000414__auto____2 = linked_72.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_71, arg_74) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any; var root_75 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = xs__1927001018__auto____3; if linked_76 == nil { d__4 = ifn_77.Invoke_O__O(arg_78) } else { d__4 = linked_76.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_75, arg_78) }; if jrt.File_Cast(d__4).IsDirectory__Z() { var rel__5 any; var root_79 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_81 lang.IFn

	if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = jrt.File_Cast(d__4).GetPath__String().Ref(); var arg_83 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(jrt.File_Cast(t.F_m).GetPath__String().Ref())))).Ref(); if linked_80 == nil { rel__5 = ifn_81.Invoke_O_O__O(arg_82, arg_83) } else { rel__5 = linked_80.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_79, arg_82, arg_83) }
//line :68:1
	var tmp1 any; var root_84 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_86 lang.IFn


	if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = lang.IFn_Cast(A_arbace_c_musl_A_const_28.GetRawRoot__O()).Invoke_O__O(rel__5); if linked_85 == nil { tmp1 = ifn_86.Invoke_O__O(arg_87) } else { tmp1 = linked_85.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_84, arg_87) }
//line :68:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____6 any; var fnbody__165 any = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A_New_O(rel__5); var tmp2 *jrt.Class; var fncls__164 *jrt.Class = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, fnbody__165); A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A_fn_class = fncls__164d; tmp2 = fncls__164d } else { tmp2 = fncls__164 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__165, tmp2, nil); var fs__1927001036__auto____7 any; var root_166 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = lang.IFn_Cast(iterys__1927001035__auto____6).Invoke_O__O(jrt.File_Cast(d__4).ListFiles__File1().Ref()); if linked_167 == nil { fs__1927001036__auto____7 = ifn_168.Invoke_O__O(arg_169) } else { fs__1927001036__auto____7 = linked_167.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_166, arg_169) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_170 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = fs__1927001036__auto____7; var arg_174 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1657000018); var tmp4 any; var root_175 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = s__1657000019__1; if linked_176 == nil { tmp4 = ifn_177.Invoke_O__O(arg_178) } else { tmp4 = linked_176.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_175, arg_178) }; arg_174 = tmp3.Invoke_O__O(tmp4); if linked_171 == nil { return ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { return linked_171.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_170, arg_173, arg_174) } } else { var tmp5 any; var root_179 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = s__1657000019__1; if linked_180 == nil { tmp5 = ifn_181.Invoke_O__O(arg_182) } else { tmp5 = linked_180.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_179, arg_182) }; s__1657000019__1 = tmp5; continue L1 } } else { var tmp6 any; var root_183 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = s__1657000019__1; if linked_184 == nil { tmp6 = ifn_185.Invoke_O__O(arg_186) } else { tmp6 = linked_184.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_183, arg_186) }; s__1657000019__1 = tmp6; continue L1 } } else { var tmp7 any; var root_187 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = s__1657000019__1; if linked_188 == nil { tmp7 = ifn_189.Invoke_O__O(arg_190) } else { tmp7 = linked_188.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_187, arg_190) }; s__1657000019__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :68:1
func A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A_New_O(p0 any) *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A{}; t.Ctor_O(p0); return t }
//line :68:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :68:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A) Invoke_O_O__O(self, s__1657000021__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__163 any = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A_New_O_O_O(t.F_rel, s__1657000021__1, self); var tmp2 *jrt.Class; var fncls__162 *jrt.Class = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A_fn_class; if fncls__162 == nil { var fncls__162d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, fnbody__163); A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A_fn_class = fncls__162d; tmp2 = fncls__162d } else { tmp2 = fncls__162 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__163, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :68:1
func A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :68:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A) Ctor_O_O_O(c__rel, c__s__1657000021, c__iter__1657000020 any) { t.F_rel = c__rel; t.F_s__1657000021 = c__s__1657000021; t.F_iter__1657000020 = c__iter__1657000020 }
//line :68:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A) Invoke_O__O(self any) any { { var s__1657000021__1 any; var t_ any = t.F_s__1657000021; t.F_s__1657000021 = nil; s__1657000021__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_88 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = s__1657000021__1; if linked_89 == nil { temp__1927000414__auto____2 = ifn_90.Invoke_O__O(arg_91) } else { temp__1927000414__auto____2 = linked_89.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_88, arg_91) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1657000021__3 any = temp__1927000414__auto____2; var tmp1 any; var root_92 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = s__1657000021__3; if linked_93 == nil { tmp1 = ifn_94.Invoke_O__O(arg_95) } else { tmp1 = linked_93.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_92, arg_95) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_96 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = s__1657000021__3; if linked_97 == nil { c__1927001037__auto____4 = ifn_98.Invoke_O__O(arg_99) } else { c__1927001037__auto____4 = linked_97.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_96, arg_99) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1657000023__6 any; var root_100 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_101 == nil { b__1657000023__6 = ifn_102.Invoke_O__O(arg_103) } else { b__1657000023__6 = linked_101.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_100, arg_103) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A_New_O_O_I_O(b__1657000023__6, t.F_rel, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__114); A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_115 any = A_arbace_c_musl_A_const_34.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any; var root_120 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = b__1657000023__6; if linked_121 == nil { arg_118 = ifn_122.Invoke_O__O(arg_123) } else { arg_118 = linked_121.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_120, arg_123) }; var arg_119 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1657000020); var tmp5 any; var root_124 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_125 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_124, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_126 lang.IFn; if linked_125 == nil { ifn_126 = lang.IFn_Cast(root_124) } else { ifn_126 = nil }; var arg_127 any = s__1657000021__3; if linked_125 == nil { tmp5 = ifn_126.Invoke_O__O(arg_127) } else { tmp5 = linked_125.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_124, arg_127) }; arg_119 = tmp4.Invoke_O__O(tmp5); if linked_116 == nil { return ifn_117.Invoke_O_O__O(arg_118, arg_119) } else { return linked_116.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_115, arg_118, arg_119) } } else { var root_128 any = A_arbace_c_musl_A_const_34.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any; var root_133 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = b__1657000023__6; if linked_134 == nil { arg_131 = ifn_135.Invoke_O__O(arg_136) } else { arg_131 = linked_134.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_133, arg_136) }; var arg_132 any; if linked_129 == nil { return ifn_130.Invoke_O_O__O(arg_131, arg_132) } else { return linked_129.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_128, arg_131, arg_132) } } } else { var f__4 any; var root_137 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = s__1657000021__3; if linked_138 == nil { f__4 = ifn_139.Invoke_O__O(arg_140) } else { f__4 = linked_138.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_137, arg_140) }; var tmp6 bool; var and__1927000168__auto____5 bool = jrt.File_Cast(f__4).IsFile__Z()




	if and__1927000168__auto____5 { tmp6 = jrt.NN(jrt.File_Cast(f__4).GetName__String()).EndsWith_String__Z(Lit_77) } else { tmp6 = and__1927000168__auto____5 }
//line :68:1
	if tmp6 { var tmp7 any = t.F_rel; var p__5 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil), jrt.RefArrayOf(jrt.Object_class, tmp7, nil, jrt.File_Cast(f__4).GetName__String().Ref())).Ref(); var tmp8 any; var root_141 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_141, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_143 lang.IFn






		if linked_142 == nil { ifn_143 = lang.IFn_Cast(root_141) } else { ifn_143 = nil }; var arg_144 any = lang.IFn_Cast(A_arbace_c_musl_A_const_32.GetRawRoot__O()).Invoke_O__O(p__5); if linked_142 == nil { tmp8 = ifn_143.Invoke_O__O(arg_144) } else { tmp8 = linked_142.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_141, arg_144) }
//line :68:1
		if jrt.J2g_Truth(tmp8) { var root_145 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any = p__5; var arg_149 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1657000020); var tmp10 any; var root_150 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = s__1657000021__3; if linked_151 == nil { tmp10 = ifn_152.Invoke_O__O(arg_153) } else { tmp10 = linked_151.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_150, arg_153) }; arg_149 = tmp9.Invoke_O__O(tmp10); if linked_146 == nil { return ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { return linked_146.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) } } else { var tmp11 any; var root_154 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = s__1657000021__3; if linked_155 == nil { tmp11 = ifn_156.Invoke_O__O(arg_157) } else { tmp11 = linked_155.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_154, arg_157) }; s__1657000021__1 = tmp11; continue L1 } } else { var tmp12 any; var root_158 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = s__1657000021__3; if linked_159 == nil { tmp12 = ifn_160.Invoke_O__O(arg_161) } else { tmp12 = linked_159.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_158, arg_161) }; s__1657000021__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :68:1
func A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :68:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A) Ctor_O_O_I_O(c__b__1657000023, c__rel any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1657000023 = c__b__1657000023; t.F_rel = c__rel; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :68:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A) Invoke_O__O(self any) any { { var i__1657000022__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1657000022__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1657000022__1)); var tmp2 bool; var and__1927000168__auto____3 bool = jrt.File_Cast(f__2).IsFile__Z()




	if and__1927000168__auto____3 { tmp2 = jrt.NN(jrt.File_Cast(f__2).GetName__String()).EndsWith_String__Z(Lit_77) } else { tmp2 = and__1927000168__auto____3 }
//line :68:1
	if tmp2 { var tmp3 any = t.F_rel; var p__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil), jrt.RefArrayOf(jrt.Object_class, tmp3, nil, jrt.File_Cast(f__2).GetName__String().Ref())).Ref(); var tmp4 any; var root_104 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_106 lang.IFn






		if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = lang.IFn_Cast(A_arbace_c_musl_A_const_32.GetRawRoot__O()).Invoke_O__O(p__3); if linked_105 == nil { tmp4 = ifn_106.Invoke_O__O(arg_107) } else { tmp4 = linked_105.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_104, arg_107) }
//line :68:1
		if jrt.J2g_Truth(tmp4) { var root_108 any = A_arbace_c_musl_A_const_33.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = t.F_b__1657000023; var arg_112 any = p__3; if linked_109 == nil { ifn_110.Invoke_O_O__O(arg_111, arg_112) } else { linked_109.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_108, arg_111, arg_112) }; i__1657000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000022__1); continue L1 } else { i__1657000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000022__1); continue L1 } } else { i__1657000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000022__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_c_musl_attr_names_A_New() *A_arbace_c_musl_attr_names_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_attr_names_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_c_musl_attr_names_A) Ctor() {}
//line :81:1
func (t *A_arbace_c_musl_attr_names_A) Invoke_O_O__O(self, m__0 any) any { var names__2 any = jrt.HashSet_New(); var alias__3 any; var root_200 any = A_arbace_c_musl_A_const_40.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_202 lang.IFn; if


	linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any; if linked_201 == nil { alias__3 = ifn_202.Invoke_O__O(arg_203) } else { alias__3 = linked_201.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_200, arg_203) }; var body_walk__4 /*line :81:1*/*A_arbace_c_musl_attr_names_walk__1657000035_A = A_arbace_c_musl_attr_names_walk__1657000035_A_New_O_O(names__2, alias__3); var walk__4 any; var fnbody__300 any = any(body_walk__4); var tmp1 *jrt.Class; var fncls__299 *jrt.Class = A_arbace_c_musl_attr_names_walk__1657000035_A_fn_class; if fncls__299 == nil { var fncls__299d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, fnbody__300); A_arbace_c_musl_attr_names_walk__1657000035_A_fn_class = fncls__299d; tmp1 = fncls__299d } else { tmp1 = fncls__299 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__300, tmp1, nil); var seq_1657000048__5 any; var root_301 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_303 lang.IFn; if











	linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = A_arbace_c_musl_A_const_52; if linked_302 == nil { seq_1657000048__5 = ifn_303.Invoke_O__O(arg_304) } else { seq_1657000048__5 = linked_302.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_301, arg_304) }; var chunk_1657000049__6 any; var count_1657000050__7 int64 = 0; var i_1657000051__8 int64 = 0; L1:
//line :81:1
	for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000051__8, count_1657000050__7) { var k__9 any = lang.Indexed_Cast(chunk_1657000049__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000051__8))
			lang.IFn_Cast(walk__4).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(m__0, k__9))
//line :93:1
			seq_1657000048__5, chunk_1657000049__6, count_1657000050__7, i_1657000051__8 = seq_1657000048__5, chunk_1657000049__6, count_1657000050__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000051__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_305 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = seq_1657000048__5; if linked_306 == nil { temp__1927000414__auto____9 = ifn_307.Invoke_O__O(arg_308) } else { temp__1927000414__auto____9 = linked_306.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_305, arg_308) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1657000048__10 any = temp__1927000414__auto____9; var tmp2 any; var root_309 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = seq_1657000048__10; if linked_310 == nil { tmp2 = ifn_311.Invoke_O__O(arg_312) } else { tmp2 = linked_310.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_309, arg_312) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_313 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = seq_1657000048__10; if linked_314 == nil { c__1927000678__auto____11 = ifn_315.Invoke_O__O(arg_316) } else { c__1927000678__auto____11 = linked_314.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_313, arg_316) }; var tmp3 any; var root_321 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = seq_1657000048__10; if linked_322 == nil { tmp3 = ifn_323.Invoke_O__O(arg_324) } else { tmp3 = linked_322.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_321, arg_324) }; seq_1657000048__5, chunk_1657000049__6, count_1657000050__7, i_1657000051__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var k__11 any; var root_317 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = seq_1657000048__10; if linked_318 == nil { k__11 = ifn_319.Invoke_O__O(arg_320) } else { k__11 = linked_318.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_317, arg_320) }
				lang.IFn_Cast(walk__4).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(m__0, k__11))
//line :93:1
				var tmp4 any; var root_325 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = seq_1657000048__10; if linked_326 == nil { tmp4 = ifn_327.Invoke_O__O(arg_328) } else { tmp4 = linked_326.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_325, arg_328) }; seq_1657000048__5, chunk_1657000049__6, count_1657000050__7, i_1657000051__8 = tmp4, nil, 0, 0; continue L1 } } }
//line :81:1
		break L1 }; var tmp5 any; var root_329 any = A_arbace_c_musl_A_const_53.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_331 lang.IFn; if













	linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = names__2; if linked_330 == nil { tmp5 = ifn_331.Invoke_O__O(arg_332) } else { tmp5 = linked_330.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_329, arg_332) }; var tmp6 any = tmp5; var tmp7 any; var root_333 any = /*line :81:1*/A_arbace_c_musl_A_const_8.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_335 lang.IFn; if


	linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = alias__3; if linked_334 == nil { tmp7 = ifn_335.Invoke_O__O(arg_336) } else { tmp7 = linked_334.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_333, arg_336) }; return /*line :81:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) }



func A_arbace_c_musl_attr_names_walk__1657000035_A_New_O_O(p0, p1 any) *A_arbace_c_musl_attr_names_walk__1657000035_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_attr_names_walk__1657000035_A{}; t.Ctor_O_O(p0, p1); return t }
//line :85:1
func (t *A_arbace_c_musl_attr_names_walk__1657000035_A) Ctor_O_O(c__names, c__alias any) { t.F_names = c__names; t.F_alias = c__alias }
//line :85:1
func (t *A_arbace_c_musl_attr_names_walk__1657000035_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_204 any = A_arbace_c_musl_A_const_41.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_206 lang.IFn
		if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = x__1; if linked_205 == nil { tmp1 = ifn_206.Invoke_O__O(arg_207) } else { tmp1 = linked_205.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_204, arg_207) }
//line :86:1
		if jrt.J2g_Truth(tmp1) {
			var tmp2 jrt.HashSet_I = jrt.HashSet_Cast(t.F_names); var tmp3 any; var root_208 any = A_arbace_c_musl_A_const_42.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any; var root_214 any = A_arbace_c_musl_A_const_43.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = x__1; if linked_215 == nil { arg_211 = ifn_216.Invoke_O__O(arg_217) } else { arg_211 = linked_215.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_214, arg_217) }; var arg_212 any = A_arbace_c_musl_A_const_44; var arg_213 any = Lit_2; if linked_209 == nil { tmp3 = ifn_210.Invoke_O_O_O__O(arg_211, arg_212, arg_213) } else { tmp3 = linked_209.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_208, arg_211, arg_212, arg_213) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2.Add_O__Z(tmp3)).Ref() } else {
//line :86:1
				var tmp4 any; var root_218 any = A_arbace_c_musl_A_const_45.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_220 lang.IFn

				if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = x__1; if linked_219 == nil { tmp4 = ifn_220.Invoke_O__O(arg_221) } else { tmp4 = linked_219.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_218, arg_221) }
//line :86:1
				if jrt.J2g_Truth(tmp4) { var vec__1657000036__2 any = x__1; var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000036__2, lang.RT_IntCast_J__I_NoInit(0), nil); var a__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000036__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var and__1927000168__auto____5 any; var root_266 any = A_arbace_c_musl_A_const_41.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_268 lang.IFn


					if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = n__3; if linked_267 == nil { and__1927000168__auto____5 = ifn_268.Invoke_O__O(arg_269) } else { and__1927000168__auto____5 = linked_267.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_266, arg_269) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_48); var tmp7 any; var root_279 any = A_arbace_c_musl_A_const_43.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = n__3; if linked_280 == nil { tmp7 = ifn_281.Invoke_O__O(arg_282) } else { tmp7 = linked_280.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_279, arg_282) }; and__1927000168__auto____6 = tmp6.Invoke_O__O(tmp7); if jrt.J2g_Truth(and__1927000168__auto____6) { var root_270 any = A_arbace_c_musl_A_const_49.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = a__4; if linked_271 == nil { tmp5 = ifn_272.Invoke_O__O(arg_273) } else { tmp5 = linked_271.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_270, arg_273) } } else { tmp5 = and__1927000168__auto____6 } } else { tmp5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp5) { var root_274 any = A_arbace_c_musl_A_const_50.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_276 lang.IFn; if linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = t.F_alias; var arg_278 any = a__4; if linked_275 == nil { ifn_276.Invoke_O_O__O(arg_277, arg_278) } else { linked_275.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_274, arg_277, arg_278) } }
//line :86:1
					var seq_1657000039__5 any; var root_222 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_224 lang.IFn



					if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = x__1; if linked_223 == nil { seq_1657000039__5 = ifn_224.Invoke_O__O(arg_225) } else { seq_1657000039__5 = linked_223.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_222, arg_225) }
//line :86:1
					var chunk_1657000040__6 any; var count_1657000041__7 int64 = 0; var i_1657000042__8 int64 = 0; L1: for {



						if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000042__8, count_1657000041__7) { var y__9 any = lang.Indexed_Cast(chunk_1657000040__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000042__8)); lang.IFn_Cast(self).Invoke_O__O(y__9); seq_1657000039__5, chunk_1657000040__6, count_1657000041__7, i_1657000042__8 = seq_1657000039__5, chunk_1657000040__6, count_1657000041__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000042__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_226 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = seq_1657000039__5; if linked_227 == nil { temp__1927000414__auto____9 = ifn_228.Invoke_O__O(arg_229) } else { temp__1927000414__auto____9 = linked_227.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_226, arg_229) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1657000039__10 any = temp__1927000414__auto____9; var tmp8 any; var root_230 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_230, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_232 lang.IFn; if linked_231 == nil { ifn_232 = lang.IFn_Cast(root_230) } else { ifn_232 = nil }; var arg_233 any = seq_1657000039__10; if linked_231 == nil { tmp8 = ifn_232.Invoke_O__O(arg_233) } else { tmp8 = linked_231.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_230, arg_233) }; if jrt.J2g_Truth(tmp8) { var c__1927000678__auto____11 any; var root_234 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = seq_1657000039__10; if linked_235 == nil { c__1927000678__auto____11 = ifn_236.Invoke_O__O(arg_237) } else { c__1927000678__auto____11 = linked_235.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_234, arg_237) }; var tmp9 any; var root_283 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = seq_1657000039__10; if linked_284 == nil { tmp9 = ifn_285.Invoke_O__O(arg_286) } else { tmp9 = linked_284.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_283, arg_286) }; seq_1657000039__5, chunk_1657000040__6, count_1657000041__7, i_1657000042__8 = tmp9, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var y__11 any; var root_238 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = seq_1657000039__10; if linked_239 == nil { y__11 = ifn_240.Invoke_O__O(arg_241) } else { y__11 = linked_239.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_238, arg_241) }; lang.IFn_Cast(self).Invoke_O__O(y__11); var tmp10 any; var root_287 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = seq_1657000039__10; if linked_288 == nil { tmp10 = ifn_289.Invoke_O__O(arg_290) } else { tmp10 = linked_288.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_287, arg_290) }; seq_1657000039__5, chunk_1657000040__6, count_1657000041__7, i_1657000042__8 = tmp10, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :86:1
							var tmp11 any; var root_242 any = A_arbace_c_musl_A_const_46.GetRawRoot__O(); var linked_243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_242, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_244 lang.IFn




							if linked_243 == nil { ifn_244 = lang.IFn_Cast(root_242) } else { ifn_244 = nil }; var arg_245 any = x__1; if linked_243 == nil { tmp11 = ifn_244.Invoke_O__O(arg_245) } else { tmp11 = linked_243.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_242, arg_245) }
//line :86:1
							if jrt.J2g_Truth(tmp11) { var seq_1657000043__2 any; var root_246 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_248 lang.IFn




								if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = x__1; if linked_247 == nil { seq_1657000043__2 = ifn_248.Invoke_O__O(arg_249) } else { seq_1657000043__2 = linked_247.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_246, arg_249) }
//line :86:1
								var chunk_1657000044__3 any; var count_1657000045__4 int64 = 0; var i_1657000046__5 int64 = 0; L2: for {




									if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000046__5, count_1657000045__4) { var y__6 any = lang.Indexed_Cast(chunk_1657000044__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000046__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1657000043__2, chunk_1657000044__3, count_1657000045__4, i_1657000046__5 = seq_1657000043__2, chunk_1657000044__3, count_1657000045__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000046__5); continue L2 } else { var temp__1927000414__auto____6 any; var root_250 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = seq_1657000043__2; if linked_251 == nil { temp__1927000414__auto____6 = ifn_252.Invoke_O__O(arg_253) } else { temp__1927000414__auto____6 = linked_251.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_250, arg_253) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1657000043__7 any = temp__1927000414__auto____6; var tmp12 any; var root_254 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_254, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_256 lang.IFn; if linked_255 == nil { ifn_256 = lang.IFn_Cast(root_254) } else { ifn_256 = nil }; var arg_257 any = seq_1657000043__7; if linked_255 == nil { tmp12 = ifn_256.Invoke_O__O(arg_257) } else { tmp12 = linked_255.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_254, arg_257) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____8 any; var root_258 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_258, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_260 lang.IFn; if linked_259 == nil { ifn_260 = lang.IFn_Cast(root_258) } else { ifn_260 = nil }; var arg_261 any = seq_1657000043__7; if linked_259 == nil { c__1927000678__auto____8 = ifn_260.Invoke_O__O(arg_261) } else { c__1927000678__auto____8 = linked_259.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_258, arg_261) }; var tmp13 any; var root_291 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = seq_1657000043__7; if linked_292 == nil { tmp13 = ifn_293.Invoke_O__O(arg_294) } else { tmp13 = linked_292.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_291, arg_294) }; seq_1657000043__2, chunk_1657000044__3, count_1657000045__4, i_1657000046__5 = tmp13, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_262 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_262, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = seq_1657000043__7; if linked_263 == nil { y__8 = ifn_264.Invoke_O__O(arg_265) } else { y__8 = linked_263.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_262, arg_265) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp14 any; var root_295 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = seq_1657000043__7; if linked_296 == nil { tmp14 = ifn_297.Invoke_O__O(arg_298) } else { tmp14 = linked_296.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_295, arg_298) }; seq_1657000043__2, chunk_1657000044__3, count_1657000045__4, i_1657000046__5 = tmp14, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :86:1
										if A_arbace_c_musl_A_const_47 != nil { return nil } else { return nil } } } } }
//line :85:1
	panic("j2g: unreachable")
}










func A_arbace_c_musl_sym_name_A_New() *A_arbace_c_musl_sym_name_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sym_name_A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_c_musl_sym_name_A) Ctor() {}
//line :97:1
func (t *A_arbace_c_musl_sym_name_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_337 any = A_arbace_c_musl_A_const_41.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = x__0; if linked_338 == nil { tmp1 = ifn_339.Invoke_O__O(arg_340) } else { tmp1 = linked_338.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_337, arg_340) }; if jrt.J2g_Truth(tmp1) { var root_341 any = A_arbace_c_musl_A_const_43.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = x__0; if linked_342 == nil { return ifn_343.Invoke_O__O(arg_344) } else { return linked_342.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_341, arg_344) } } else { var tmp2 any; var and__1927000168__auto____2 any; var root_345 any = A_arbace_c_musl_A_const_46.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = x__0; if linked_346 == nil { and__1927000168__auto____2 = ifn_347.Invoke_O__O(arg_348) } else { and__1927000168__auto____2 = linked_346.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_345, arg_348) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp3 any = A_arbace_c_musl_A_const_54; var tmp4 any; var root_349 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = x__0; if linked_350 == nil { tmp4 = ifn_351.Invoke_O__O(arg_352) } else { tmp4 = linked_350.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_349, arg_352) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp2) { var root_353 any = A_arbace_c_musl_A_const_55.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = x__0; if linked_354 == nil { return ifn_355.Invoke_O__O(arg_356) } else { return linked_354.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_353, arg_356) } } else { return nil } } }

func A_arbace_c_musl_unit_defs_A_New() *A_arbace_c_musl_unit_defs_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_unit_defs_A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_c_musl_unit_defs_A) Ctor() {}
//line :99:1
func (t *A_arbace_c_musl_unit_defs_A) Invoke_O_O__O(self, forms__0 any) any { var out__2 any = jrt.HashMap_New(); var body_decl__3 *A_arbace_c_musl_unit_defs_decl__1657000054_A = A_arbace_c_musl_unit_defs_decl__1657000054_A_New_O(out__2); var decl__3 any; var fnbody__516 any = any(body_decl__3); var tmp1 *jrt.Class; var fncls__515 *jrt.Class = A_arbace_c_musl_unit_defs_decl__1657000054_A_fn_class; if fncls__515 == nil { var fncls__515d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__516); A_arbace_c_musl_unit_defs_decl__1657000054_A_fn_class = fncls__515d; tmp1 = fncls__515d } else { tmp1 = fncls__515 }; decl__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__516, tmp1, nil); var seq_1657000070__4 any; var root_517 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_519 lang.IFn; if

















	linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = forms__0; if linked_518 == nil { seq_1657000070__4 = ifn_519.Invoke_O__O(arg_520) } else { seq_1657000070__4 = linked_518.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_517, arg_520) }; var chunk_1657000071__5 any; var count_1657000072__6 int64 = 0; var i_1657000073__7 int64 = 0; L1:
//line :99:1
	for {

















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000073__7, count_1657000072__6) { var f__8 any = lang.Indexed_Cast(chunk_1657000071__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000073__7)); lang.IFn_Cast(decl__3).Invoke_O__O(f__8); seq_1657000070__4, chunk_1657000071__5, count_1657000072__6, i_1657000073__7 = seq_1657000070__4, chunk_1657000071__5, count_1657000072__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000073__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_521 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any = seq_1657000070__4; if linked_522 == nil { temp__1927000414__auto____8 = ifn_523.Invoke_O__O(arg_524) } else { temp__1927000414__auto____8 = linked_522.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_521, arg_524) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1657000070__9 any = temp__1927000414__auto____8; var tmp2 any; var root_525 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = seq_1657000070__9; if linked_526 == nil { tmp2 = ifn_527.Invoke_O__O(arg_528) } else { tmp2 = linked_526.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_525, arg_528) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____10 any; var root_529 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_529, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_531 lang.IFn; if linked_530 == nil { ifn_531 = lang.IFn_Cast(root_529) } else { ifn_531 = nil }; var arg_532 any = seq_1657000070__9; if linked_530 == nil { c__1927000678__auto____10 = ifn_531.Invoke_O__O(arg_532) } else { c__1927000678__auto____10 = linked_530.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_529, arg_532) }; var tmp3 any; var root_537 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = seq_1657000070__9; if linked_538 == nil { tmp3 = ifn_539.Invoke_O__O(arg_540) } else { tmp3 = linked_538.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_537, arg_540) }; seq_1657000070__4, chunk_1657000071__5, count_1657000072__6, i_1657000073__7 = tmp3, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__10 any; var root_533 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any = seq_1657000070__9; if linked_534 == nil { f__10 = ifn_535.Invoke_O__O(arg_536) } else { f__10 = linked_534.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_533, arg_536) }; lang.IFn_Cast(decl__3).Invoke_O__O(f__10); var tmp4 any; var root_541 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_541, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_543 lang.IFn; if linked_542 == nil { ifn_543 = lang.IFn_Cast(root_541) } else { ifn_543 = nil }; var arg_544 any = seq_1657000070__9; if linked_542 == nil { tmp4 = ifn_543.Invoke_O__O(arg_544) } else { tmp4 = linked_542.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_541, arg_544) }; seq_1657000070__4, chunk_1657000071__5, count_1657000072__6, i_1657000073__7 = tmp4, nil, 0, 0; continue L1 } } }
//line :99:1
		break L1 }; var root_357 any =


















	A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_361 any = out__2; if linked_358 == nil { return ifn_359.Invoke_O_O__O(arg_360, arg_361) } else { return linked_358.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_357, arg_360, arg_361) } }
//line :103:1
func A_arbace_c_musl_unit_defs_decl__1657000054_A_New_O(p0 any) *A_arbace_c_musl_unit_defs_decl__1657000054_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_unit_defs_decl__1657000054_A{}; t.Ctor_O(p0); return t }
//line :103:1
func (t *A_arbace_c_musl_unit_defs_decl__1657000054_A) Ctor_O(c__out any) { t.F_out = c__out }
//line :103:1
func (t *A_arbace_c_musl_unit_defs_decl__1657000054_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 any; var root_362 any = A_arbace_c_musl_A_const_46.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = f__1; if linked_363 == nil { tmp1 = ifn_364.Invoke_O__O(arg_365) } else { tmp1 = linked_363.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_362, arg_365) }; if jrt.J2g_Truth(tmp1) { var G__1657000055__2_ any; var root_366 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_368 lang.IFn
		if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = f__1; if linked_367 == nil { G__1657000055__2_ = ifn_368.Invoke_O__O(arg_369) } else { G__1657000055__2_ = linked_367.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_366, arg_369) }; switch lang.Util_Hash_O__I_NoInit(G__1657000055__2_) >> 1 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000055__2_, A_arbace_c_musl_A_const_57) { var nm__3 any; var root_371 any = A_arbace_c_musl_A_const_55.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_373 lang.IFn


			if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = f__1; if linked_372 == nil { nm__3 = ifn_373.Invoke_O__O(arg_374) } else { nm__3 = linked_372.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_371, arg_374) }
//line :105:1
			var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(nm__3); var n__5 any; var root_375 any = A_arbace_c_musl_A_const_58.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, A_arbace_c_musl_sym_name_A_fn_class); var ifn_377 lang.IFn


			if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = nm__3; if linked_376 == nil { n__5 = ifn_377.Invoke_O__O(arg_378) } else { n__5 = linked_376.(*A_arbace_c_musl_sym_name_A).Invoke_O_O__O(root_375, arg_378) }
//line :105:1
			var vec__1657000056__6 any; var root_379 any = A_arbace_c_musl_A_const_59.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, A_arbace_c_musl_attr_names_A_fn_class); var ifn_381 lang.IFn



			if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = m__4; if linked_380 == nil { vec__1657000056__6 = ifn_381.Invoke_O__O(arg_382) } else { vec__1657000056__6 = linked_380.(*A_arbace_c_musl_attr_names_A).Invoke_O_O__O(root_379, arg_382) }
//line :105:1
			var as__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000056__6, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000056__6, lang.RT_IntCast_J__I_NoInit(1), nil); var weak__9 any; var root_383 any = A_arbace_c_musl_A_const_60.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_385 lang.IFn




			if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = as__7; var arg_387 any = Lit_79; if linked_384 == nil { weak__9 = ifn_385.Invoke_O_O__O(arg_386, arg_387) } else { weak__9 = linked_384.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_383, arg_386, arg_387) }
			var tmp2 any; var and__1927000168__auto____10 any = n__5; if jrt.J2g_Truth(and__1927000168__auto____10) { var root_388 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_388, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_390 lang.IFn; if linked_389 == nil { ifn_390 = lang.IFn_Cast(root_388) } else { ifn_390 = nil }; var arg_391 any = A_arbace_c_musl_A_const_61.Invoke_O__O(m__4); if linked_389 == nil { tmp2 = ifn_390.Invoke_O__O(arg_391) } else { tmp2 = linked_389.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_388, arg_391) } } else { tmp2 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp2) {
				if jrt.J2g_Truth(alias__8) {
					var tmp3 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp3.Put_O_O__O(n__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_62, weak__9, A_arbace_c_musl_A_const_63, alias__8))) } else {
//line :112:1
						var tmp4 any = A_arbace_c_musl_A_const_64; var tmp5 any; var root_392 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_394 lang.IFn

						if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = f__1; if linked_393 == nil { tmp5 = ifn_394.Invoke_O__O(arg_395) } else { tmp5 = linked_393.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_392, arg_395) }
//line :112:1
						if lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) {

							var tmp6 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp6.Put_O_O__O(n__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_62, weak__9))) } else {
//line :112:1
								var tmp7 any; var and__1927000168__auto____10_2 bool; var tmp8 any = A_arbace_c_musl_A_const_65; var tmp9 any; var root_396 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_398 lang.IFn


								if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = f__1; if linked_397 == nil { tmp9 = ifn_398.Invoke_O__O(arg_399) } else { tmp9 = linked_397.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_396, arg_399) }; and__1927000168__auto____10_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9); if and__1927000168__auto____10_2 { var and__1927000168__auto____11 any; var root_400 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = A_arbace_c_musl_A_const_66.Invoke_O__O(m__4); if linked_401 == nil { and__1927000168__auto____11 = ifn_402.Invoke_O__O(arg_403) } else { and__1927000168__auto____11 = linked_401.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_400, arg_403) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_404 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var tmp10 any = A_arbace_c_musl_A_const_67; var tmp11 *lang.Keyword = A_arbace_c_musl_A_const_68; var arg_407 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp10, tmp11.Invoke_O__O(A_arbace_c_musl_A_const_69.Invoke_O__O(m__4)))).Ref(); if linked_405 == nil { tmp7 = ifn_406.Invoke_O__O(arg_407) } else { tmp7 = linked_405.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_404, arg_407) } } else { tmp7 = and__1927000168__auto____11 } } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_2).Ref() }
//line :112:1
								if jrt.J2g_Truth(tmp7) {


									var tmp12 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp12.Put_O_O__O(n__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_62, weak__9))) } else {
//line :112:1
										return nil } } } } else {
//line :111:1
											return nil } }
//line :105:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000055__2_, A_arbace_c_musl_A_const_70) { var seq_1657000059__3 any; var root_408 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_410 lang.IFn
			if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any; var root_412 any = A_arbace_c_musl_A_const_71.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_412, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_416 any = f__1; if linked_413 == nil { arg_411 = ifn_414.Invoke_O_O__O(A_arbace_c_musl_A_const_72, arg_416) } else { arg_411 = linked_413.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_412, 2, A_arbace_c_musl_A_const_72, arg_416) }; if linked_409 == nil { seq_1657000059__3 = ifn_410.Invoke_O__O(arg_411) } else { seq_1657000059__3 = linked_409.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_408, arg_411) }
//line :105:1
			var chunk_1657000060__4 any; var count_1657000061__5 int64 = 0; var i_1657000062__6 int64 = 0; L2: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000062__6, count_1657000061__5) { var d__7 any = lang.Indexed_Cast(chunk_1657000060__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000062__6)); lang.IFn_Cast(self).Invoke_O__O(d__7); seq_1657000059__3, chunk_1657000060__4, count_1657000061__5, i_1657000062__6 = seq_1657000059__3, chunk_1657000060__4, count_1657000061__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000062__6); continue L2 } else { var temp__1927000414__auto____7 any; var root_417 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = seq_1657000059__3; if linked_418 == nil { temp__1927000414__auto____7 = ifn_419.Invoke_O__O(arg_420) } else { temp__1927000414__auto____7 = linked_418.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_417, arg_420) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1657000059__8 any = temp__1927000414__auto____7; var tmp13 any; var root_421 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = seq_1657000059__8; if linked_422 == nil { tmp13 = ifn_423.Invoke_O__O(arg_424) } else { tmp13 = linked_422.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_421, arg_424) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____9 any; var root_425 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = seq_1657000059__8; if linked_426 == nil { c__1927000678__auto____9 = ifn_427.Invoke_O__O(arg_428) } else { c__1927000678__auto____9 = linked_426.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_425, arg_428) }; var tmp14 any; var root_507 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = seq_1657000059__8; if linked_508 == nil { tmp14 = ifn_509.Invoke_O__O(arg_510) } else { tmp14 = linked_508.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_507, arg_510) }; seq_1657000059__3, chunk_1657000060__4, count_1657000061__5, i_1657000062__6 = tmp14, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__9 any; var root_429 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = seq_1657000059__8; if linked_430 == nil { d__9 = ifn_431.Invoke_O__O(arg_432) } else { d__9 = linked_430.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_429, arg_432) }; lang.IFn_Cast(self).Invoke_O__O(d__9); var tmp15 any; var root_511 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = seq_1657000059__8; if linked_512 == nil { tmp15 = ifn_513.Invoke_O__O(arg_514) } else { tmp15 = linked_512.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_511, arg_514) }; seq_1657000059__3, chunk_1657000060__4, count_1657000061__5, i_1657000062__6 = tmp15, nil, 0, 0; continue L2 } } else { return nil } } } }
//line :105:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000055__2_, A_arbace_c_musl_A_const_73) { var nm__3_2 any; var root_433 any = A_arbace_c_musl_A_const_55.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_435 lang.IFn


			if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = f__1; if linked_434 == nil { nm__3_2 = ifn_435.Invoke_O__O(arg_436) } else { nm__3_2 = linked_434.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_433, arg_436) }
//line :105:1
			var m__4_2 any = lang.RT_Meta_O__IPersistentMap_NoInit(nm__3_2); var n__5_2 any; var root_437 any = A_arbace_c_musl_A_const_58.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, A_arbace_c_musl_sym_name_A_fn_class); var ifn_439 lang.IFn


			if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = nm__3_2; if linked_438 == nil { n__5_2 = ifn_439.Invoke_O__O(arg_440) } else { n__5_2 = linked_438.(*A_arbace_c_musl_sym_name_A).Invoke_O_O__O(root_437, arg_440) }
//line :105:1
			var vec__1657000063__6 any; var root_441 any = A_arbace_c_musl_A_const_59.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, A_arbace_c_musl_attr_names_A_fn_class); var ifn_443 lang.IFn



			if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = m__4_2; if linked_442 == nil { vec__1657000063__6 = ifn_443.Invoke_O__O(arg_444) } else { vec__1657000063__6 = linked_442.(*A_arbace_c_musl_attr_names_A).Invoke_O_O__O(root_441, arg_444) }
//line :105:1
			var as__7_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000063__6, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__8_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000063__6, lang.RT_IntCast_J__I_NoInit(1), nil); var weak__9_2 any; var root_445 any = A_arbace_c_musl_A_const_60.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_447 lang.IFn




			if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = as__7_2; var arg_449 any = Lit_79; if linked_446 == nil { weak__9_2 = ifn_447.Invoke_O_O__O(arg_448, arg_449) } else { weak__9_2 = linked_446.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_445, arg_448, arg_449) }
			var tmp16 any; var and__1927000168__auto____10_3 any = n__5_2; if jrt.J2g_Truth(and__1927000168__auto____10_3) { var root_450 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_450, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_452 lang.IFn; if linked_451 == nil { ifn_452 = lang.IFn_Cast(root_450) } else { ifn_452 = nil }; var arg_453 any = A_arbace_c_musl_A_const_61.Invoke_O__O(m__4_2); if linked_451 == nil { tmp16 = ifn_452.Invoke_O__O(arg_453) } else { tmp16 = linked_451.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_450, arg_453) } } else { tmp16 = and__1927000168__auto____10_3 }; if jrt.J2g_Truth(tmp16) {
				if jrt.J2g_Truth(alias__8_2) {
					var tmp17 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp17.Put_O_O__O(n__5_2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_62, weak__9_2, A_arbace_c_musl_A_const_63, alias__8_2))) } else {
//line :112:1
						var tmp18 any = A_arbace_c_musl_A_const_64; var tmp19 any; var root_454 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_456 lang.IFn

						if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = f__1; if linked_455 == nil { tmp19 = ifn_456.Invoke_O__O(arg_457) } else { tmp19 = linked_455.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_454, arg_457) }
//line :112:1
						if lang.Util_Equiv_O_O__Z_NoInit(tmp18, tmp19) {

							var tmp20 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp20.Put_O_O__O(n__5_2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_62, weak__9_2))) } else {
//line :112:1
								var tmp21 any; var and__1927000168__auto____10_4 bool; var tmp22 any = A_arbace_c_musl_A_const_65; var tmp23 any; var root_458 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_460 lang.IFn


								if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = f__1; if linked_459 == nil { tmp23 = ifn_460.Invoke_O__O(arg_461) } else { tmp23 = linked_459.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_458, arg_461) }; and__1927000168__auto____10_4 = lang.Util_Equiv_O_O__Z_NoInit(tmp22, tmp23); if and__1927000168__auto____10_4 { var and__1927000168__auto____11_2 any; var root_462 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = A_arbace_c_musl_A_const_66.Invoke_O__O(m__4_2); if linked_463 == nil { and__1927000168__auto____11_2 = ifn_464.Invoke_O__O(arg_465) } else { and__1927000168__auto____11_2 = linked_463.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_462, arg_465) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var root_466 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var tmp24 any = A_arbace_c_musl_A_const_67; var tmp25 *lang.Keyword = A_arbace_c_musl_A_const_68; var arg_469 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp24, tmp25.Invoke_O__O(A_arbace_c_musl_A_const_69.Invoke_O__O(m__4_2)))).Ref(); if linked_467 == nil { tmp21 = ifn_468.Invoke_O__O(arg_469) } else { tmp21 = linked_467.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_466, arg_469) } } else { tmp21 = and__1927000168__auto____11_2 } } else { tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_4).Ref() }
//line :112:1
								if jrt.J2g_Truth(tmp21) {


									var tmp26 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp26.Put_O_O__O(n__5_2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_62, weak__9_2))) } else {
//line :112:1
										return nil } } } } else {
//line :111:1
											return nil } }
//line :105:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000055__2_, A_arbace_c_musl_A_const_74) { var nm__3_3 any; var root_470 any = A_arbace_c_musl_A_const_55.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_472 lang.IFn


			if linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = f__1; if linked_471 == nil { nm__3_3 = ifn_472.Invoke_O__O(arg_473) } else { nm__3_3 = linked_471.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_470, arg_473) }
//line :105:1
			var m__4_3 any = lang.RT_Meta_O__IPersistentMap_NoInit(nm__3_3); var n__5_3 any; var root_474 any = A_arbace_c_musl_A_const_58.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, A_arbace_c_musl_sym_name_A_fn_class); var ifn_476 lang.IFn


			if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = nm__3_3; if linked_475 == nil { n__5_3 = ifn_476.Invoke_O__O(arg_477) } else { n__5_3 = linked_475.(*A_arbace_c_musl_sym_name_A).Invoke_O_O__O(root_474, arg_477) }
//line :105:1
			var vec__1657000066__6 any; var root_478 any = A_arbace_c_musl_A_const_59.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, A_arbace_c_musl_attr_names_A_fn_class); var ifn_480 lang.IFn



			if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any = m__4_3; if linked_479 == nil { vec__1657000066__6 = ifn_480.Invoke_O__O(arg_481) } else { vec__1657000066__6 = linked_479.(*A_arbace_c_musl_attr_names_A).Invoke_O_O__O(root_478, arg_481) }
//line :105:1
			var as__7_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000066__6, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__8_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000066__6, lang.RT_IntCast_J__I_NoInit(1), nil); var weak__9_3 any; var root_482 any = A_arbace_c_musl_A_const_60.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_484 lang.IFn




			if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = as__7_3; var arg_486 any = Lit_79; if linked_483 == nil { weak__9_3 = ifn_484.Invoke_O_O__O(arg_485, arg_486) } else { weak__9_3 = linked_483.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_482, arg_485, arg_486) }
			var tmp27 any; var and__1927000168__auto____10_5 any = n__5_3; if jrt.J2g_Truth(and__1927000168__auto____10_5) { var root_487 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_489 lang.IFn; if linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = A_arbace_c_musl_A_const_61.Invoke_O__O(m__4_3); if linked_488 == nil { tmp27 = ifn_489.Invoke_O__O(arg_490) } else { tmp27 = linked_488.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_487, arg_490) } } else { tmp27 = and__1927000168__auto____10_5 }; if jrt.J2g_Truth(tmp27) {
				if jrt.J2g_Truth(alias__8_3) {
					var tmp28 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp28.Put_O_O__O(n__5_3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_62, weak__9_3, A_arbace_c_musl_A_const_63, alias__8_3))) } else {
//line :112:1
						var tmp29 any = A_arbace_c_musl_A_const_64; var tmp30 any; var root_491 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_493 lang.IFn

						if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = f__1; if linked_492 == nil { tmp30 = ifn_493.Invoke_O__O(arg_494) } else { tmp30 = linked_492.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_491, arg_494) }
//line :112:1
						if lang.Util_Equiv_O_O__Z_NoInit(tmp29, tmp30) {

							var tmp31 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp31.Put_O_O__O(n__5_3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_62, weak__9_3))) } else {
//line :112:1
								var tmp32 any; var and__1927000168__auto____10_6 bool; var tmp33 any = A_arbace_c_musl_A_const_65; var tmp34 any; var root_495 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_497 lang.IFn


								if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = f__1; if linked_496 == nil { tmp34 = ifn_497.Invoke_O__O(arg_498) } else { tmp34 = linked_496.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_495, arg_498) }; and__1927000168__auto____10_6 = lang.Util_Equiv_O_O__Z_NoInit(tmp33, tmp34); if and__1927000168__auto____10_6 { var and__1927000168__auto____11_3 any; var root_499 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = A_arbace_c_musl_A_const_66.Invoke_O__O(m__4_3); if linked_500 == nil { and__1927000168__auto____11_3 = ifn_501.Invoke_O__O(arg_502) } else { and__1927000168__auto____11_3 = linked_500.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_499, arg_502) }; if jrt.J2g_Truth(and__1927000168__auto____11_3) { var root_503 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var tmp35 any = A_arbace_c_musl_A_const_67; var tmp36 *lang.Keyword = A_arbace_c_musl_A_const_68; var arg_506 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp35, tmp36.Invoke_O__O(A_arbace_c_musl_A_const_69.Invoke_O__O(m__4_3)))).Ref(); if linked_504 == nil { tmp32 = ifn_505.Invoke_O__O(arg_506) } else { tmp32 = linked_504.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_503, arg_506) } } else { tmp32 = and__1927000168__auto____11_3 } } else { tmp32 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_6).Ref() }
//line :112:1
								if jrt.J2g_Truth(tmp32) {


									var tmp37 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp37.Put_O_O__O(n__5_3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_62, weak__9_3))) } else {
//line :112:1
										return nil } } } } else {
//line :111:1
											return nil } }
//line :105:1
		default:}; return nil } else {
//line :104:1
			return nil
		}
}













func A_arbace_c_musl_refs_A_New() *A_arbace_c_musl_refs_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_refs_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_c_musl_refs_A) Ctor() {}
//line :120:1
func (t *A_arbace_c_musl_refs_A) Invoke_O_O__O(self, forms__0 any) any { var acc__2 any = jrt.HashSet_New(); var body_walk__3 *A_arbace_c_musl_refs_walk__1657000075_A = A_arbace_c_musl_refs_walk__1657000075_A_New_O(acc__2); var body_decl__4 *A_arbace_c_musl_refs_decl__1657000081_A = A_arbace_c_musl_refs_decl__1657000081_A_New_O_O(nil, nil); var body_walk_meta__5 *A_arbace_c_musl_refs_walk_meta__1657000094_A = A_arbace_c_musl_refs_walk_meta__1657000094_A_New_O(acc__2); var walk__3 any; var fnbody__696 any = any(body_walk__3); var tmp1 *jrt.Class; var fncls__695 *jrt.Class = A_arbace_c_musl_refs_walk__1657000075_A_fn_class; if fncls__695 == nil { var fncls__695d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, fnbody__696); A_arbace_c_musl_refs_walk__1657000075_A_fn_class = fncls__695d; tmp1 = fncls__695d } else { tmp1 = fncls__695 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__696, tmp1, nil); var decl__4 any; var fnbody__698 any = any(body_decl__4); var tmp2 *jrt.Class; var fncls__697 *jrt.Class = A_arbace_c_musl_refs_decl__1657000081_A_fn_class; if fncls__697 == nil { var fncls__697d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, fnbody__698); A_arbace_c_musl_refs_decl__1657000081_A_fn_class = fncls__697d; tmp2 = fncls__697d } else { tmp2 = fncls__697 }; decl__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__698, tmp2, nil); var walk_meta__5 any; var fnbody__700 any = any(body_walk_meta__5); var tmp3 *jrt.Class; var fncls__699 *jrt.Class = A_arbace_c_musl_refs_walk_meta__1657000094_A_fn_class; if fncls__699 == nil { var fncls__699d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, fnbody__700); A_arbace_c_musl_refs_walk_meta__1657000094_A_fn_class = fncls__699d; tmp3 = fncls__699d } else { tmp3 = fncls__699 }; walk_meta__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__700, tmp3, nil); body_decl__4.F_walk = walk__3; body_decl__4.F_walk_meta = walk_meta__5; var seq_1657000099__6 any; var root_701 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_701, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_703 lang.IFn; if




















	linked_702 == nil { ifn_703 = lang.IFn_Cast(root_701) } else { ifn_703 = nil }; var arg_704 any = forms__0; if linked_702 == nil { seq_1657000099__6 = ifn_703.Invoke_O__O(arg_704) } else { seq_1657000099__6 = linked_702.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_701, arg_704) }; var chunk_1657000100__7 any; var count_1657000101__8 int64 = 0; var i_1657000102__9 int64 = 0; L1:
//line :120:1
	for {




















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000102__9, count_1657000101__8) { var f__10 any = lang.Indexed_Cast(chunk_1657000100__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000102__9)); lang.IFn_Cast(decl__4).Invoke_O__O(f__10); seq_1657000099__6, chunk_1657000100__7, count_1657000101__8, i_1657000102__9 = seq_1657000099__6, chunk_1657000100__7, count_1657000101__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000102__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_705 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = seq_1657000099__6; if linked_706 == nil { temp__1927000414__auto____10 = ifn_707.Invoke_O__O(arg_708) } else { temp__1927000414__auto____10 = linked_706.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_705, arg_708) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1657000099__11 any = temp__1927000414__auto____10; var tmp4 any; var root_709 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = seq_1657000099__11; if linked_710 == nil { tmp4 = ifn_711.Invoke_O__O(arg_712) } else { tmp4 = linked_710.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_709, arg_712) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____12 any; var root_713 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_713, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_715 lang.IFn; if linked_714 == nil { ifn_715 = lang.IFn_Cast(root_713) } else { ifn_715 = nil }; var arg_716 any = seq_1657000099__11; if linked_714 == nil { c__1927000678__auto____12 = ifn_715.Invoke_O__O(arg_716) } else { c__1927000678__auto____12 = linked_714.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_713, arg_716) }; var tmp5 any; var root_721 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_721, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_723 lang.IFn; if linked_722 == nil { ifn_723 = lang.IFn_Cast(root_721) } else { ifn_723 = nil }; var arg_724 any = seq_1657000099__11; if linked_722 == nil { tmp5 = ifn_723.Invoke_O__O(arg_724) } else { tmp5 = linked_722.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_721, arg_724) }; seq_1657000099__6, chunk_1657000100__7, count_1657000101__8, i_1657000102__9 = tmp5, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__12 any; var root_717 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_717, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_719 lang.IFn; if linked_718 == nil { ifn_719 = lang.IFn_Cast(root_717) } else { ifn_719 = nil }; var arg_720 any = seq_1657000099__11; if linked_718 == nil { f__12 = ifn_719.Invoke_O__O(arg_720) } else { f__12 = linked_718.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_717, arg_720) }; lang.IFn_Cast(decl__4).Invoke_O__O(f__12); var tmp6 any; var root_725 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = seq_1657000099__11; if linked_726 == nil { tmp6 = ifn_727.Invoke_O__O(arg_728) } else { tmp6 = linked_726.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_725, arg_728) }; seq_1657000099__6, chunk_1657000100__7, count_1657000101__8, i_1657000102__9 = tmp6, nil, 0, 0; continue L1 } } }
//line :120:1
		break L1 }; return acc__2 }




func A_arbace_c_musl_refs_decl__1657000081_A_New_O_O(p0, p1 any) *A_arbace_c_musl_refs_decl__1657000081_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_refs_decl__1657000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :125:1
func (t *A_arbace_c_musl_refs_decl__1657000081_A) Ctor_O_O(c__walk, c__walk_meta any) { t.F_walk = c__walk; t.F_walk_meta = c__walk_meta }
//line :125:1
func (t *A_arbace_c_musl_refs_decl__1657000081_A) Invoke_O_O__O(self, f__1 any) any {





	var tmp1 any; var root_593 any = A_arbace_c_musl_A_const_46.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = f__1; if linked_594 == nil { tmp1 = ifn_595.Invoke_O__O(arg_596) } else { tmp1 = linked_594.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_593, arg_596) }; if jrt.J2g_Truth(tmp1) { var G__1657000082__2_ any; var root_597 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_599 lang.IFn
		if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = f__1; if linked_598 == nil { G__1657000082__2_ = ifn_599.Invoke_O__O(arg_600) } else { G__1657000082__2_ = linked_598.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_597, arg_600) }; switch lang.Util_Hash_O__I_NoInit(G__1657000082__2_) >> 8 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000082__2_, A_arbace_c_musl_A_const_76) {


			var tmp2 lang.IFn = lang.IFn_Cast(t.F_walk_meta); var tmp3 any; var root_647 any = A_arbace_c_musl_A_const_55.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = f__1; if linked_648 == nil { tmp3 = ifn_649.Invoke_O__O(arg_650) } else { tmp3 = linked_648.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_647, arg_650) }; return tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp3)) }
//line :132:1
		case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000082__2_, A_arbace_c_musl_A_const_77) { var seq_1657000083__3 any; var root_602 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_604 lang.IFn



			if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any; var root_606 any = A_arbace_c_musl_A_const_71.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_606, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_610 any = f__1; if linked_607 == nil { arg_605 = ifn_608.Invoke_O_O__O(A_arbace_c_musl_A_const_72, arg_610) } else { arg_605 = linked_607.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_606, 2, A_arbace_c_musl_A_const_72, arg_610) }; if linked_603 == nil { seq_1657000083__3 = ifn_604.Invoke_O__O(arg_605) } else { seq_1657000083__3 = linked_603.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_602, arg_605) }
//line :132:1
			var chunk_1657000084__4 any; var count_1657000085__5 int64 = 0; var i_1657000086__6 int64 = 0; L2: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000086__6, count_1657000085__5) { var d__7 any = lang.Indexed_Cast(chunk_1657000084__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000086__6)); lang.IFn_Cast(self).Invoke_O__O(d__7); seq_1657000083__3, chunk_1657000084__4, count_1657000085__5, i_1657000086__6 = seq_1657000083__3, chunk_1657000084__4, count_1657000085__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000086__6); continue L2 } else { var temp__1927000414__auto____7 any; var root_611 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = seq_1657000083__3; if linked_612 == nil { temp__1927000414__auto____7 = ifn_613.Invoke_O__O(arg_614) } else { temp__1927000414__auto____7 = linked_612.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_611, arg_614) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1657000083__8 any = temp__1927000414__auto____7; var tmp4 any; var root_615 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = seq_1657000083__8; if linked_616 == nil { tmp4 = ifn_617.Invoke_O__O(arg_618) } else { tmp4 = linked_616.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_615, arg_618) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____9 any; var root_619 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = seq_1657000083__8; if linked_620 == nil { c__1927000678__auto____9 = ifn_621.Invoke_O__O(arg_622) } else { c__1927000678__auto____9 = linked_620.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_619, arg_622) }; var tmp5 any; var root_651 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = seq_1657000083__8; if linked_652 == nil { tmp5 = ifn_653.Invoke_O__O(arg_654) } else { tmp5 = linked_652.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_651, arg_654) }; seq_1657000083__3, chunk_1657000084__4, count_1657000085__5, i_1657000086__6 = tmp5, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__9 any; var root_623 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_625 lang.IFn; if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = seq_1657000083__8; if linked_624 == nil { d__9 = ifn_625.Invoke_O__O(arg_626) } else { d__9 = linked_624.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_623, arg_626) }; lang.IFn_Cast(self).Invoke_O__O(d__9); var tmp6 any; var root_655 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_655, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_657 lang.IFn; if linked_656 == nil { ifn_657 = lang.IFn_Cast(root_655) } else { ifn_657 = nil }; var arg_658 any = seq_1657000083__8; if linked_656 == nil { tmp6 = ifn_657.Invoke_O__O(arg_658) } else { tmp6 = linked_656.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_655, arg_658) }; seq_1657000083__3, chunk_1657000084__4, count_1657000085__5, i_1657000086__6 = tmp6, nil, 0, 0; continue L2 } } else { return nil } } } }
//line :132:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000082__2_, A_arbace_c_musl_A_const_78) { var vec__1657000087__3 any = f__1; var seq__1657000088__4 any; var root_627 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_629 lang.IFn

			if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = vec__1657000087__3; if linked_628 == nil { seq__1657000088__4 = ifn_629.Invoke_O__O(arg_630) } else { seq__1657000088__4 = linked_628.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_627, arg_630) }
//line :132:1
			var first__1657000089__5 any; var root_631 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_633 lang.IFn

			if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = seq__1657000088__4; if linked_632 == nil { first__1657000089__5 = ifn_633.Invoke_O__O(arg_634) } else { first__1657000089__5 = linked_632.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_631, arg_634) }
//line :132:1
			var seq__1657000088__6 any; var root_635 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_637 lang.IFn

			if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = seq__1657000088__4; if linked_636 == nil { seq__1657000088__6 = ifn_637.Invoke_O__O(arg_638) } else { seq__1657000088__6 = linked_636.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_635, arg_638) }
//line :132:1
			var ___7 any = first__1657000089__5; var first__1657000089__8 any; var root_639 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_639, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_641 lang.IFn; _ = ___7

			if linked_640 == nil { ifn_641 = lang.IFn_Cast(root_639) } else { ifn_641 = nil }; var arg_642 any = seq__1657000088__6; if linked_640 == nil { first__1657000089__8 = ifn_641.Invoke_O__O(arg_642) } else { first__1657000089__8 = linked_640.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_639, arg_642) }
//line :132:1
			var seq__1657000088__9 any; var root_643 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_643, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_645 lang.IFn

			if linked_644 == nil { ifn_645 = lang.IFn_Cast(root_643) } else { ifn_645 = nil }; var arg_646 any = seq__1657000088__6; if linked_644 == nil { seq__1657000088__9 = ifn_645.Invoke_O__O(arg_646) } else { seq__1657000088__9 = linked_644.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_643, arg_646) }
//line :132:1
			var nm__10 any = first__1657000089__8
			var init__11 any = seq__1657000088__9
			lang.IFn_Cast(t.F_walk).Invoke_O__O(init__11); var tmp7 lang.IFn = lang.IFn_Cast(t.F_walk_meta); return tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__10)) }
//line :132:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000082__2_, A_arbace_c_musl_A_const_79) {


			var tmp8 lang.IFn = lang.IFn_Cast(t.F_walk_meta); var tmp9 any; var root_687 any = A_arbace_c_musl_A_const_55.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = f__1; if linked_688 == nil { tmp9 = ifn_689.Invoke_O__O(arg_690) } else { tmp9 = linked_688.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_687, arg_690) }; return tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp9)) }
//line :132:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000082__2_, A_arbace_c_musl_A_const_80) { var vec__1657000090__3 any = f__1; var seq__1657000091__4 any; var root_659 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_661 lang.IFn
			if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any = vec__1657000090__3; if linked_660 == nil { seq__1657000091__4 = ifn_661.Invoke_O__O(arg_662) } else { seq__1657000091__4 = linked_660.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_659, arg_662) }
//line :132:1
			var first__1657000092__5 any; var root_663 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_665 lang.IFn
			if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = seq__1657000091__4; if linked_664 == nil { first__1657000092__5 = ifn_665.Invoke_O__O(arg_666) } else { first__1657000092__5 = linked_664.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_663, arg_666) }
//line :132:1
			var seq__1657000091__6 any; var root_667 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_669 lang.IFn
			if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = seq__1657000091__4; if linked_668 == nil { seq__1657000091__6 = ifn_669.Invoke_O__O(arg_670) } else { seq__1657000091__6 = linked_668.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_667, arg_670) }
//line :132:1
			var ___7_2 any = first__1657000092__5; var first__1657000092__8 any; var root_671 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_673 lang.IFn; _ = ___7_2
			if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = seq__1657000091__6; if linked_672 == nil { first__1657000092__8 = ifn_673.Invoke_O__O(arg_674) } else { first__1657000092__8 = linked_672.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_671, arg_674) }
//line :132:1
			var seq__1657000091__9 any; var root_675 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_677 lang.IFn
			if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = seq__1657000091__6; if linked_676 == nil { seq__1657000091__9 = ifn_677.Invoke_O__O(arg_678) } else { seq__1657000091__9 = linked_676.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_675, arg_678) }
//line :132:1
			var nm__10_2 any = first__1657000092__8; var first__1657000092__11 any; var root_679 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_681 lang.IFn
			if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = seq__1657000091__9; if linked_680 == nil { first__1657000092__11 = ifn_681.Invoke_O__O(arg_682) } else { first__1657000092__11 = linked_680.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_679, arg_682) }
//line :132:1
			var seq__1657000091__12 any; var root_683 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_685 lang.IFn
			if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = seq__1657000091__9; if linked_684 == nil { seq__1657000091__12 = ifn_685.Invoke_O__O(arg_686) } else { seq__1657000091__12 = linked_684.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_683, arg_686) }
//line :132:1
			var ___13 any = first__1657000092__11; var body__14 any = seq__1657000091__12; _ = ___13
			lang.IFn_Cast(t.F_walk).Invoke_O__O(body__14); var tmp10 lang.IFn = lang.IFn_Cast(t.F_walk_meta); return tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__10_2)) }
//line :132:1
		default:}; return nil } else {
//line :131:1
			return nil } }
//line :125:1
func A_arbace_c_musl_refs_walk__1657000075_A_New_O(p0 any) *A_arbace_c_musl_refs_walk__1657000075_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_refs_walk__1657000075_A{}; t.Ctor_O(p0); return t }
//line :125:1
func (t *A_arbace_c_musl_refs_walk__1657000075_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :125:1
func (t *A_arbace_c_musl_refs_walk__1657000075_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_545 any = A_arbace_c_musl_A_const_41.GetRawRoot__O(); var linked_546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_545, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_547 lang.IFn
		if linked_546 == nil { ifn_547 = lang.IFn_Cast(root_545) } else { ifn_547 = nil }; var arg_548 any = x__1; if linked_546 == nil { tmp1 = ifn_547.Invoke_O__O(arg_548) } else { tmp1 = linked_546.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_545, arg_548) }
//line :126:1
		if jrt.J2g_Truth(tmp1) {
			var tmp2 any; var root_549 any = A_arbace_c_musl_A_const_75.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = x__1; if linked_550 == nil { tmp2 = ifn_551.Invoke_O__O(arg_552) } else { tmp2 = linked_550.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_549, arg_552) }; if jrt.J2g_Truth(tmp2) { return nil } else { var tmp3 jrt.HashSet_I = jrt.HashSet_Cast(t.F_acc); var tmp4 any; var root_553 any = A_arbace_c_musl_A_const_43.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = x__1; if linked_554 == nil { tmp4 = ifn_555.Invoke_O__O(arg_556) } else { tmp4 = linked_554.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_553, arg_556) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3.Add_O__Z(tmp4)).Ref() } } else {
//line :126:1
				var tmp5 any; var or__1927000174__auto____2 any; var root_557 any = A_arbace_c_musl_A_const_46.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_559 lang.IFn

				if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = x__1; if linked_558 == nil { or__1927000174__auto____2 = ifn_559.Invoke_O__O(arg_560) } else { or__1927000174__auto____2 = linked_558.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_557, arg_560) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp5 = or__1927000174__auto____2 } else { var root_561 any = A_arbace_c_musl_A_const_45.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = x__1; if linked_562 == nil { tmp5 = ifn_563.Invoke_O__O(arg_564) } else { tmp5 = linked_562.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_561, arg_564) } }
//line :126:1
				if jrt.J2g_Truth(tmp5) { var seq_1657000076__2 any; var root_565 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_567 lang.IFn

					if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = x__1; if linked_566 == nil { seq_1657000076__2 = ifn_567.Invoke_O__O(arg_568) } else { seq_1657000076__2 = linked_566.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_565, arg_568) }
//line :126:1
					var chunk_1657000077__3 any; var count_1657000078__4 int64 = 0; var i_1657000079__5 int64 = 0; L1: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000079__5, count_1657000078__4) { var y__6 any = lang.Indexed_Cast(chunk_1657000077__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000079__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1657000076__2, chunk_1657000077__3, count_1657000078__4, i_1657000079__5 = seq_1657000076__2, chunk_1657000077__3, count_1657000078__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000079__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_569 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = seq_1657000076__2; if linked_570 == nil { temp__1927000414__auto____6 = ifn_571.Invoke_O__O(arg_572) } else { temp__1927000414__auto____6 = linked_570.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_569, arg_572) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1657000076__7 any = temp__1927000414__auto____6; var tmp6 any; var root_573 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = seq_1657000076__7; if linked_574 == nil { tmp6 = ifn_575.Invoke_O__O(arg_576) } else { tmp6 = linked_574.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_573, arg_576) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____8 any; var root_577 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_579 lang.IFn; if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = seq_1657000076__7; if linked_578 == nil { c__1927000678__auto____8 = ifn_579.Invoke_O__O(arg_580) } else { c__1927000678__auto____8 = linked_578.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_577, arg_580) }; var tmp7 any; var root_585 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_585, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_587 lang.IFn; if linked_586 == nil { ifn_587 = lang.IFn_Cast(root_585) } else { ifn_587 = nil }; var arg_588 any = seq_1657000076__7; if linked_586 == nil { tmp7 = ifn_587.Invoke_O__O(arg_588) } else { tmp7 = linked_586.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_585, arg_588) }; seq_1657000076__2, chunk_1657000077__3, count_1657000078__4, i_1657000079__5 = tmp7, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var y__8 any; var root_581 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = seq_1657000076__7; if linked_582 == nil { y__8 = ifn_583.Invoke_O__O(arg_584) } else { y__8 = linked_582.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_581, arg_584) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp8 any; var root_589 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_591 lang.IFn; if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = seq_1657000076__7; if linked_590 == nil { tmp8 = ifn_591.Invoke_O__O(arg_592) } else { tmp8 = linked_590.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_589, arg_592) }; seq_1657000076__2, chunk_1657000077__3, count_1657000078__4, i_1657000079__5 = tmp8, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :126:1
							if A_arbace_c_musl_A_const_47 != nil { return nil } else { return nil } } } }
//line :125:1
	panic("j2g: unreachable") }
//line :125:1
func A_arbace_c_musl_refs_walk_meta__1657000094_A_New_O(p0 any) *A_arbace_c_musl_refs_walk_meta__1657000094_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_refs_walk_meta__1657000094_A{}; t.Ctor_O(p0); return t }
//line :125:1
func (t *A_arbace_c_musl_refs_walk_meta__1657000094_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :125:1
func (t *A_arbace_c_musl_refs_walk_meta__1657000094_A) Invoke_O_O__O(self, m__1 any) any { var vec__1657000095__2 any; var root_691 any = A_arbace_c_musl_A_const_59.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_691, A_arbace_c_musl_attr_names_A_fn_class); var ifn_693 lang.IFn; if














	linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any = m__1; if linked_692 == nil { vec__1657000095__2 = ifn_693.Invoke_O__O(arg_694) } else { vec__1657000095__2 = linked_692.(*A_arbace_c_musl_attr_names_A).Invoke_O_O__O(root_691, arg_694) }; var ___3 any = /*line :125:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1657000095__2, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000095__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___3; if














	jrt.J2g_Truth(alias__4) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.HashSet_Cast(t.F_acc).Add_O__Z(alias__4)).Ref() } else { return nil } }






func A_arbace_c_musl_spit_mk_A_New() *A_arbace_c_musl_spit_mk_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_spit_mk_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_c_musl_spit_mk_A) Ctor() {}
//line :147:1
func (t *A_arbace_c_musl_spit_mk_A) Invoke_O_O_O__O(self, path__0, s__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_New_String(jrt.String_Cast(path__0)).GetParentFile__File().Mkdirs__Z())
	return lang.IFn_Cast(A_arbace_c_musl_A_const_81.GetRawRoot__O()).Invoke_O_O__O(path__0, s__1)
}
func A_arbace_c_musl_read_one_A_New() *A_arbace_c_musl_read_one_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_one_A{}; t.Ctor(); return t }
//line :151:1
func (t *A_arbace_c_musl_read_one_A) Ctor() {}
//line :151:1
func (t *A_arbace_c_musl_read_one_A) Invoke_O_O_O_O__O(self, h__0, root__1, src__2 any) any { var vec__1657000105__4 any; var root_734 any = A_arbace_c_musl_A_const_82.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, A_arbace_c_musl_config_A_fn_class); var ifn_736 lang.IFn; if


	linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any = h__0; var arg_738 any = root__1; if linked_735 == nil { vec__1657000105__4 = ifn_736.Invoke_O_O__O(arg_737, arg_738) } else { vec__1657000105__4 = linked_735.(*A_arbace_c_musl_config_A).Invoke_O_O_O__O(root_734, arg_737, arg_738) }; var fc__5 any = /*line :151:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1657000105__4, lang.RT_IntCast_J__I_NoInit(0), nil); var cfg__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000105__4, lang.RT_IntCast_J__I_NoInit(1), nil); var rd__7 any; var root_739 any = A_arbace_c_musl_A_const_83.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_repr_c.A_arbace_repr_c_read_c_A_fn_class); var ifn_741 lang.IFn; if



	linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = cfg__6; var arg_743 any = fc__5; var arg_744 any = src__2; var arg_745 any = jrt.Boolean_FALSE.Ref(); if linked_740 == nil { rd__7 = ifn_741.Invoke_O_O_O_O__O(arg_742, arg_743, arg_744, arg_745) } else { rd__7 = linked_740.(*aot_arbace_repr_c.A_arbace_repr_c_read_c_A).Invoke_O_O_O_O_O__O(root_739, arg_742, arg_743, arg_744, arg_745) }; if
	jrt.J2g_Truth(A_arbace_c_musl_A_const_84.Invoke_O__O(rd__7)) { var tmp1 any = A_arbace_c_musl_A_const_84; var tmp2 any; var root_750 any = A_arbace_c_musl_A_const_88.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_752 lang.IFn
		if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = Lit_64; var arg_754 any; var root_755 any = A_arbace_c_musl_A_const_89.GetRawRoot__O(); var linked_756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_755, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_757 lang.IFn; if linked_756 == nil { ifn_757 = lang.IFn_Cast(root_755) } else { ifn_757 = nil }; var arg_758 any = A_arbace_c_musl_A_const_72; var arg_759 any = A_arbace_c_musl_A_const_84.Invoke_O__O(rd__7); if linked_756 == nil { arg_754 = ifn_757.Invoke_O_O__O(arg_758, arg_759) } else { arg_754 = linked_756.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_755, arg_758, arg_759) }; if linked_751 == nil { tmp2 = ifn_752.Invoke_O_O__O(arg_753, arg_754) } else { tmp2 = linked_751.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_750, arg_753, arg_754) }
//line :156:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) } else { if jrt.J2g_Truth(A_arbace_c_musl_A_const_85.Invoke_O__O(rd__7)) { var tmp3 any = A_arbace_c_musl_A_const_84; return lang.Tuple_Create_O_O__IPersistentVector(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_65, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_85.Invoke_O__O(rd__7), nil, A_arbace_c_musl_A_const_90.Invoke_O__O(rd__7))).Ref()) } else { if A_arbace_c_musl_A_const_47 != nil { var fr__8 any; var root_746 any = A_arbace_c_musl_A_const_86.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, A_arbace_c_musl_forms_root_A_fn_class); var ifn_748 lang.IFn


			if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = root__1; if linked_747 == nil { fr__8 = ifn_748.Invoke_O__O(arg_749) } else { fr__8 = linked_747.(*A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_746, arg_749) }
//line :156:1
			var seq_1657000108__9 any; var root_760 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_760, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_762 lang.IFn



			if linked_761 == nil { ifn_762 = lang.IFn_Cast(root_760) } else { ifn_762 = nil }; var arg_763 any; var root_764 any = A_arbace_c_musl_A_const_91.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_repr_c.A_arbace_repr_c_unit_texts_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any = rd__7; var arg_768 any = src__2; if linked_765 == nil { arg_763 = ifn_766.Invoke_O_O__O(arg_767, arg_768) } else { arg_763 = linked_765.(*aot_arbace_repr_c.A_arbace_repr_c_unit_texts_A).Invoke_O_O_O__O(root_764, arg_767, arg_768) }; if linked_761 == nil { seq_1657000108__9 = ifn_762.Invoke_O__O(arg_763) } else { seq_1657000108__9 = linked_761.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_760, arg_763) }
//line :156:1
			var chunk_1657000109__10 any; var count_1657000110__11 int64 = 0; var i_1657000111__12 int64 = 0; L1: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000111__12, count_1657000110__11) { var vec__1657000112__13 any = lang.Indexed_Cast(chunk_1657000109__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000111__12)); var p__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000112__13, lang.RT_IntCast_J__I_NoInit(0), nil); var t__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000112__13, lang.RT_IntCast_J__I_NoInit(1), nil); var out__16 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil), jrt.RefArrayOf(jrt.Object_class, fr__8, nil, p__14)).Ref(); var tmp4 bool; var and__1927000168__auto____17 bool = jrt.NN(jrt.String_Cast(p__14)).StartsWith_String__Z(Lit_66)

					if and__1927000168__auto____17 { tmp4 = jrt.File_New_String(jrt.String_Cast(out__16)).Exists__Z() } else { tmp4 = and__1927000168__auto____17 }; if tmp4 { } else {
						var root_807 any = A_arbace_c_musl_A_const_92.GetRawRoot__O(); var linked_808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_807, A_arbace_c_musl_spit_mk_A_fn_class); var ifn_809 lang.IFn; if linked_808 == nil { ifn_809 = lang.IFn_Cast(root_807) } else { ifn_809 = nil }; var arg_810 any = out__16; var arg_811 any = t__15; if linked_808 == nil { ifn_809.Invoke_O_O__O(arg_810, arg_811) } else { linked_808.(*A_arbace_c_musl_spit_mk_A).Invoke_O_O_O__O(root_807, arg_810, arg_811) } }
//line :160:1
					seq_1657000108__9, chunk_1657000109__10, count_1657000110__11, i_1657000111__12 = seq_1657000108__9, chunk_1657000109__10, count_1657000110__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000111__12); continue L1 } else { var temp__1927000414__auto____13 any; var root_769 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = seq_1657000108__9; if linked_770 == nil { temp__1927000414__auto____13 = ifn_771.Invoke_O__O(arg_772) } else { temp__1927000414__auto____13 = linked_770.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_769, arg_772) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1657000108__14 any = temp__1927000414__auto____13; var tmp5 any; var root_773 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_775 lang.IFn; if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = seq_1657000108__14; if linked_774 == nil { tmp5 = ifn_775.Invoke_O__O(arg_776) } else { tmp5 = linked_774.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_773, arg_776) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____15 any; var root_777 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = seq_1657000108__14; if linked_778 == nil { c__1927000678__auto____15 = ifn_779.Invoke_O__O(arg_780) } else { c__1927000678__auto____15 = linked_778.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_777, arg_780) }; var tmp6 any; var root_812 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_814 lang.IFn; if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; var arg_815 any = seq_1657000108__14; if linked_813 == nil { tmp6 = ifn_814.Invoke_O__O(arg_815) } else { tmp6 = linked_813.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_812, arg_815) }; seq_1657000108__9, chunk_1657000109__10, count_1657000110__11, i_1657000111__12 = tmp6, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1657000115__15 any; var root_781 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = seq_1657000108__14; if linked_782 == nil { vec__1657000115__15 = ifn_783.Invoke_O__O(arg_784) } else { vec__1657000115__15 = linked_782.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_781, arg_784) }; var p__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000115__15, lang.RT_IntCast_J__I_NoInit(0), nil); var t__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000115__15, lang.RT_IntCast_J__I_NoInit(1), nil); var out__18 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil), jrt.RefArrayOf(jrt.Object_class, fr__8, nil, p__16)).Ref(); var tmp7 bool; var and__1927000168__auto____19 bool = jrt.NN(jrt.String_Cast(p__16)).StartsWith_String__Z(Lit_66)

						if and__1927000168__auto____19 { tmp7 = jrt.File_New_String(jrt.String_Cast(out__18)).Exists__Z() } else { tmp7 = and__1927000168__auto____19 }; if tmp7 { } else {
							var root_816 any = A_arbace_c_musl_A_const_92.GetRawRoot__O(); var linked_817 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_816, A_arbace_c_musl_spit_mk_A_fn_class); var ifn_818 lang.IFn; if linked_817 == nil { ifn_818 = lang.IFn_Cast(root_816) } else { ifn_818 = nil }; var arg_819 any = out__18; var arg_820 any = t__17; if linked_817 == nil { ifn_818.Invoke_O_O__O(arg_819, arg_820) } else { linked_817.(*A_arbace_c_musl_spit_mk_A).Invoke_O_O_O__O(root_816, arg_819, arg_820) } }
//line :160:1
						var tmp8 any; var root_821 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_823 lang.IFn; if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any = seq_1657000108__14; if linked_822 == nil { tmp8 = ifn_823.Invoke_O__O(arg_824) } else { tmp8 = linked_822.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_821, arg_824) }; seq_1657000108__9, chunk_1657000109__10, count_1657000110__11, i_1657000111__12 = tmp8, nil, 0, 0; continue L1 } } }
//line :156:1
				break L1
			}






			var root_785 any = A_arbace_c_musl_A_const_92.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_785, A_arbace_c_musl_spit_mk_A_fn_class); var ifn_787 lang.IFn; if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, fr__8, nil, src__2, nil)).Ref(); var arg_789 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_93.GetRawRoot__O()); var tmp10 any; var root_794 any = A_arbace_c_musl_A_const_22.GetRawRoot__O(); var linked_795 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_794, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_796 lang.IFn; if linked_795 == nil { ifn_796 = lang.IFn_Cast(root_794) } else { ifn_796 = nil }; var arg_797 any; var root_798 any = A_arbace_c_musl_A_const_94.GetRawRoot__O(); var linked_799 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_798, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_800 lang.IFn; if linked_799 == nil { ifn_800 = lang.IFn_Cast(root_798) } else { ifn_800 = nil }; var arg_801 any = A_arbace_c_musl_A_const_95.GetRawRoot__O(); var arg_802 any; var root_803 any = A_arbace_c_musl_A_const_96.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = A_arbace_c_musl_A_const_97.Invoke_O__O(rd__7); if linked_804 == nil { arg_802 = ifn_805.Invoke_O__O(arg_806) } else { arg_802 = linked_804.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_803, arg_806) }; if linked_799 == nil { arg_797 = ifn_800.Invoke_O_O__O(arg_801, arg_802) } else { arg_797 = linked_799.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_798, arg_801, arg_802) }; if linked_795 == nil { tmp10 = ifn_796.Invoke_O__O(arg_797) } else { tmp10 = linked_795.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_794, arg_797) }; arg_789 = tmp9.Invoke_O__O(tmp10); if linked_786 == nil { ifn_787.Invoke_O_O__O(arg_788, arg_789) } else { linked_786.(*A_arbace_c_musl_spit_mk_A).Invoke_O_O_O__O(root_785, arg_788, arg_789) }
//line :156:1
			return A_arbace_c_musl_A_const_87 } else { return nil } } } }










func A_arbace_c_musl_read_all_A_New() *A_arbace_c_musl_read_all_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_c_musl_read_all_A) Ctor() {}
//line :167:1
func (t *A_arbace_c_musl_read_all_A) Invoke_O_O_O_O__O(self, h__0, root__1, threads__2 any) any { var srcs__4 any; var root_825 any = A_arbace_c_musl_A_const_98.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, A_arbace_c_musl_sources_A_fn_class); var ifn_827 lang.IFn; if


	linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = root__1; if linked_826 == nil { srcs__4 = ifn_827.Invoke_O__O(arg_828) } else { srcs__4 = linked_826.(*A_arbace_c_musl_sources_A).Invoke_O_O__O(root_825, arg_828) }; var fr__5 any; var root_829 any = /*line :167:1*/A_arbace_c_musl_A_const_86.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, A_arbace_c_musl_forms_root_A_fn_class); var ifn_831 lang.IFn; if



	linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any = root__1; if linked_830 == nil { fr__5 = ifn_831.Invoke_O__O(arg_832) } else { fr__5 = linked_830.(*A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_829, arg_832) }; var todo__6 any; var root_833 any = /*line :167:1*/A_arbace_c_musl_A_const_22.GetRawRoot__O(); var linked_834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_833, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_835 lang.IFn; if




	linked_834 == nil { ifn_835 = lang.IFn_Cast(root_833) } else { ifn_835 = nil }; var arg_836 any; var root_837 any = A_arbace_c_musl_A_const_99.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any; var fnbody__843 any = A_arbace_c_musl_read_all_fn__1657000120_A_New_O(fr__5); var tmp1 *jrt.Class; var fncls__842 *jrt.Class = A_arbace_c_musl_read_all_fn__1657000120_A_fn_class; if fncls__842 == nil { var fncls__842d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_52, false, fnbody__843); A_arbace_c_musl_read_all_fn__1657000120_A_fn_class = fncls__842d; tmp1 = fncls__842d } else { tmp1 = fncls__842 }; arg_840 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__843, tmp1, nil); var arg_841 any = srcs__4; if linked_838 == nil { arg_836 = ifn_839.Invoke_O_O__O(arg_840, arg_841) } else { arg_836 = linked_838.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_837, arg_840, arg_841) }; if linked_834 == nil { todo__6 = ifn_835.Invoke_O__O(arg_836) } else { todo__6 = linked_834.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_833, arg_836) }; var errs__7 any = /*line :167:1*/jrt.ConcurrentHashMap_New(); var q__8 any = jrt.ConcurrentLinkedQueue_New_Collection(jrt.Collection_Cast(todo__6)); var n__9 any; var root_844 any = A_arbace_c_musl_A_const_40.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_844, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_846 lang.IFn; if







	linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = A_arbace_c_musl_A_const_100; if linked_845 == nil { n__9 = ifn_846.Invoke_O__O(arg_847) } else { n__9 = linked_845.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_844, arg_847) }; var workers__10 any; var root_848 any = /*line :167:1*/A_arbace_c_musl_A_const_101.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_850 lang.IFn; if








	linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any; var iter__1927001039__auto____10 any; var fnbody__1031 any = A_arbace_c_musl_read_all_iter__1657000122__1657000126_A_New_O_O_O_O_O_O(todo__6, root__1, n__9, h__0, errs__7, q__8); var tmp2 *jrt.Class; var fncls__1030 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000122__1657000126_A_fn_class; if fncls__1030 == nil { var fncls__1030d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__1031); A_arbace_c_musl_read_all_iter__1657000122__1657000126_A_fn_class = fncls__1030d; tmp2 = fncls__1030d } else { tmp2 = fncls__1030 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1031, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____10); var tmp4 any; var root_1032 any = A_arbace_c_musl_A_const_114.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = threads__2; if linked_1033 == nil { tmp4 = ifn_1034.Invoke_O__O(arg_1035) } else { tmp4 = linked_1033.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1032, arg_1035) }; arg_851 = tmp3.Invoke_O__O(tmp4); if linked_849 == nil { workers__10 = ifn_850.Invoke_O__O(arg_851) } else { workers__10 = linked_849.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_848, arg_851) }; var seq_1657000144__11 any; var root_1041 any = /*line :167:1*/A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1043 lang.IFn; if
















	linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = workers__10; if linked_1042 == nil { seq_1657000144__11 = ifn_1043.Invoke_O__O(arg_1044) } else { seq_1657000144__11 = linked_1042.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1041, arg_1044) }; var chunk_1657000145__12 any; var count_1657000146__13 int64 = 0; var i_1657000147__14 int64 = 0; L1:
//line :167:1
	for {
















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000147__14, count_1657000146__13) { var w__15 any = lang.Indexed_Cast(chunk_1657000145__12).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000147__14)); var root_1061 any = A_arbace_c_musl_A_const_8.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = w__15; if linked_1062 == nil { ifn_1063.Invoke_O__O(arg_1064) } else { linked_1062.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1061, arg_1064) }; seq_1657000144__11, chunk_1657000145__12, count_1657000146__13, i_1657000147__14 = seq_1657000144__11, chunk_1657000145__12, count_1657000146__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000147__14); continue L1 } else { var temp__1927000414__auto____15 any; var root_1045 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any = seq_1657000144__11; if linked_1046 == nil { temp__1927000414__auto____15 = ifn_1047.Invoke_O__O(arg_1048) } else { temp__1927000414__auto____15 = linked_1046.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1045, arg_1048) }; if jrt.J2g_Truth(temp__1927000414__auto____15) { var seq_1657000144__16 any = temp__1927000414__auto____15; var tmp5 any; var root_1049 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_1050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1049, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1051 lang.IFn; if linked_1050 == nil { ifn_1051 = lang.IFn_Cast(root_1049) } else { ifn_1051 = nil }; var arg_1052 any = seq_1657000144__16; if linked_1050 == nil { tmp5 = ifn_1051.Invoke_O__O(arg_1052) } else { tmp5 = linked_1050.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1049, arg_1052) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____17 any; var root_1053 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; var arg_1056 any = seq_1657000144__16; if linked_1054 == nil { c__1927000678__auto____17 = ifn_1055.Invoke_O__O(arg_1056) } else { c__1927000678__auto____17 = linked_1054.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1053, arg_1056) }; var tmp6 any; var root_1065 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_1066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1065, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1067 lang.IFn; if linked_1066 == nil { ifn_1067 = lang.IFn_Cast(root_1065) } else { ifn_1067 = nil }; var arg_1068 any = seq_1657000144__16; if linked_1066 == nil { tmp6 = ifn_1067.Invoke_O__O(arg_1068) } else { tmp6 = linked_1066.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1065, arg_1068) }; seq_1657000144__11, chunk_1657000145__12, count_1657000146__13, i_1657000147__14 = tmp6, c__1927000678__auto____17, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__17 any; var root_1057 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1059 lang.IFn; if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = seq_1657000144__16; if linked_1058 == nil { w__17 = ifn_1059.Invoke_O__O(arg_1060) } else { w__17 = linked_1058.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1057, arg_1060) }; var root_1069 any = A_arbace_c_musl_A_const_8.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1071 lang.IFn; if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = w__17; if linked_1070 == nil { ifn_1071.Invoke_O__O(arg_1072) } else { linked_1070.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1069, arg_1072) }; var tmp7 any; var root_1073 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = seq_1657000144__16; if linked_1074 == nil { tmp7 = ifn_1075.Invoke_O__O(arg_1076) } else { tmp7 = linked_1074.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1073, arg_1076) }; seq_1657000144__11, chunk_1657000145__12, count_1657000146__13, i_1657000147__14 = tmp7, nil, 0, 0; continue L1 } } }
//line :167:1
		break L1 }; var root_1036 any =

















	A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_1037 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1036, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1038 lang.IFn; if linked_1037 == nil { ifn_1038 = lang.IFn_Cast(root_1036) } else { ifn_1038 = nil }; var arg_1039 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1040 any = errs__7; if linked_1037 == nil { return ifn_1038.Invoke_O_O__O(arg_1039, arg_1040) } else { return linked_1037.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1036, arg_1039, arg_1040) } }
//line :172:1
func A_arbace_c_musl_read_all_fn__1657000120_A_New_O(p0 any) *A_arbace_c_musl_read_all_fn__1657000120_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_fn__1657000120_A{}; t.Ctor_O(p0); return t }
//line :172:1
func (t *A_arbace_c_musl_read_all_fn__1657000120_A) Ctor_O(c__fr any) { t.F_fr = c__fr }
//line :172:1
func (t *A_arbace_c_musl_read_all_fn__1657000120_A) Invoke_O_O__O(self, p1__1657000119_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, t.F_fr, nil, p1__1657000119_SHARP___1, nil))).Exists__Z()).Ref() }



func A_arbace_c_musl_read_all_iter__1657000122__1657000126_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c_musl_read_all_iter__1657000122__1657000126_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000122__1657000126_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :176:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_A) Ctor_O_O_O_O_O_O(c__todo, c__root, c__n, c__h, c__errs, c__q any) { t.F_todo = c__todo; t.F_root = c__root; t.F_n = c__n; t.F_h = c__h; t.F_errs = c__errs; t.F_q = c__q }
//line :176:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_A) Invoke_O_O__O(self, s__1657000123__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1029 any = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A_New_O_O_O_O_O_O_O_O(t.F_todo, t.F_root, self, t.F_n, t.F_h, t.F_errs, t.F_q, s__1657000123__1); var tmp2 *jrt.Class; var fncls__1028 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A_fn_class; if fncls__1028 == nil { var fncls__1028d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__1029); A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A_fn_class = fncls__1028d; tmp2 = fncls__1028d } else { tmp2 = fncls__1028 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1029, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :176:1
func A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :176:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A) Ctor_O_O_O_O_O_O_O_O(c__todo, c__root, c__iter__1657000122, c__n, c__h, c__errs, c__q, c__s__1657000123 any) { t.F_todo = c__todo; t.F_root = c__root; t.F_iter__1657000122 = c__iter__1657000122; t.F_n = c__n; t.F_h = c__h; t.F_errs = c__errs; t.F_q = c__q; t.F_s__1657000123 = c__s__1657000123 }
//line :176:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A) Invoke_O__O(self any) any { { var s__1657000123__1 any; var t_ any = t.F_s__1657000123; t.F_s__1657000123 = nil; s__1657000123__1 = t_; for { var temp__1927000414__auto____2 any; var root_852 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = s__1657000123__1; if linked_853 == nil { temp__1927000414__auto____2 = ifn_854.Invoke_O__O(arg_855) } else { temp__1927000414__auto____2 = linked_853.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_852, arg_855) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1657000123__3 any = temp__1927000414__auto____2; var tmp1 any; var root_856 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = s__1657000123__3; if linked_857 == nil { tmp1 = ifn_858.Invoke_O__O(arg_859) } else { tmp1 = linked_857.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_856, arg_859) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_860 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = s__1657000123__3; if linked_861 == nil { c__1927001037__auto____4 = ifn_862.Invoke_O__O(arg_863) } else { c__1927001037__auto____4 = linked_861.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_860, arg_863) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1657000125__6 any; var root_864 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_864, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_866 lang.IFn; if linked_865 == nil { ifn_866 = lang.IFn_Cast(root_864) } else { ifn_866 = nil }; var arg_867 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_865 == nil { b__1657000125__6 = ifn_866.Invoke_O__O(arg_867) } else { b__1657000125__6 = linked_865.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_864, arg_867) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__933 any = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A_New_O_O_O_O_O_O_O_I_O(t.F_todo, t.F_root, t.F_n, t.F_h, t.F_errs, b__1657000125__6, t.F_q, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__932 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A_fn_class; if fncls__932 == nil { var fncls__932d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__933); A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A_fn_class = fncls__932d; tmp3 = fncls__932d } else { tmp3 = fncls__932 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__933, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_934 any = A_arbace_c_musl_A_const_34.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any; var root_939 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_941 lang.IFn; if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = b__1657000125__6; if linked_940 == nil { arg_937 = ifn_941.Invoke_O__O(arg_942) } else { arg_937 = linked_940.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_939, arg_942) }; var arg_938 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1657000122); var tmp5 any; var root_943 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = s__1657000123__3; if linked_944 == nil { tmp5 = ifn_945.Invoke_O__O(arg_946) } else { tmp5 = linked_944.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_943, arg_946) }; arg_938 = tmp4.Invoke_O__O(tmp5); if linked_935 == nil { return ifn_936.Invoke_O_O__O(arg_937, arg_938) } else { return linked_935.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_934, arg_937, arg_938) } } else { var root_947 any = A_arbace_c_musl_A_const_34.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_949 lang.IFn; if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any; var root_952 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = b__1657000125__6; if linked_953 == nil { arg_950 = ifn_954.Invoke_O__O(arg_955) } else { arg_950 = linked_953.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_952, arg_955) }; var arg_951 any; if linked_948 == nil { return ifn_949.Invoke_O_O__O(arg_950, arg_951) } else { return linked_948.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_947, arg_950, arg_951) } } } else { var ___4 any; var root_956 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_958 lang.IFn; _ = ___4; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = s__1657000123__3; if linked_957 == nil { ___4 = ifn_958.Invoke_O__O(arg_959) } else { ___4 = linked_957.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_956, arg_959) }; var root_960 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any; var root_965 any = A_arbace_c_musl_A_const_102.GetRawRoot__O(); var linked_966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_965, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_967 lang.IFn
														if linked_966 == nil { ifn_967 = lang.IFn_Cast(root_965) } else { ifn_967 = nil }; var arg_968 any; var fnbody__1023 any = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A_New_O_O_O_O_O_O(t.F_todo, t.F_root, t.F_n, t.F_h, t.F_errs, t.F_q); var tmp6 *jrt.Class; var fncls__1022 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A_fn_class; if fncls__1022 == nil { var fncls__1022d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__1023); A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A_fn_class = fncls__1022d; tmp6 = fncls__1022d } else { tmp6 = fncls__1022 }; arg_968 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1023, tmp6, nil); if linked_966 == nil { arg_963 = ifn_967.Invoke_O__O(arg_968) } else { arg_963 = linked_966.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_965, arg_968) }
//line :176:1
	var arg_964 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1657000122); var tmp8 any; var root_1024 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1026 lang.IFn; if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = s__1657000123__3; if linked_1025 == nil { tmp8 = ifn_1026.Invoke_O__O(arg_1027) } else { tmp8 = linked_1025.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1024, arg_1027) }; arg_964 = tmp7.Invoke_O__O(tmp8); if linked_961 == nil { return ifn_962.Invoke_O_O__O(arg_963, arg_964) } else { return linked_961.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_960, arg_963, arg_964) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :176:1
func A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A_New_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6 any, p7 int32, p8 any) *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A{}; t.Ctor_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :176:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A) Ctor_O_O_O_O_O_O_O_I_O(c__todo, c__root, c__n, c__h, c__errs, c__b__1657000125, c__q any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_todo = c__todo; t.F_root = c__root; t.F_n = c__n; t.F_h = c__h; t.F_errs = c__errs; t.F_b__1657000125 = c__b__1657000125; t.F_q = c__q; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :176:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A) Invoke_O__O(self any) any { { var i__1657000124__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1657000124__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1657000124__1)); var root_868 any = A_arbace_c_musl_A_const_33.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_870 lang.IFn; _ = ___2; if linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any = t.F_b__1657000125; var arg_872 any; var root_873 any = A_arbace_c_musl_A_const_102.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_875 lang.IFn
																if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any; var fnbody__931 any = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A_New_O_O_O_O_O_O(t.F_todo, t.F_root, t.F_n, t.F_h, t.F_errs, t.F_q); var tmp2 *jrt.Class; var fncls__930 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A_fn_class; if fncls__930 == nil { var fncls__930d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__931); A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A_fn_class = fncls__930d; tmp2 = fncls__930d } else { tmp2 = fncls__930 }; arg_876 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__931, tmp2, nil); if linked_874 == nil { arg_872 = ifn_875.Invoke_O__O(arg_876) } else { arg_872 = linked_874.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_873, arg_876) }
//line :176:1
	if linked_869 == nil { ifn_870.Invoke_O_O__O(arg_871, arg_872) } else { linked_869.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_868, arg_871, arg_872) }; i__1657000124__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000124__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :177:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A) Ctor_O_O_O_O_O_O(c__todo, c__root, c__n, c__h, c__errs, c__q any) { t.F_todo = c__todo; t.F_root = c__root; t.F_n = c__n; t.F_h = c__h; t.F_errs = c__errs; t.F_q = c__q }
//line :177:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A) Invoke_O__O(self any) any { for { L2: for { var temp__1927000414__auto____1 any = jrt.NN(jrt.ConcurrentLinkedQueue_Cast(t.F_q)).Poll__O()

	if jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var r__3 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__888 any = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000130_A_New_O_O_O(t.F_root, t.F_h, s__2); var tmp2 *jrt.Class; var fncls__887 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000130_A_fn_class
		if fncls__887 == nil { var fncls__887d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__888); A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000130_A_fn_class = fncls__887d; tmp2 = fncls__887d } else { tmp2 = fncls__887 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__888, tmp2, nil); r__3 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
		var tmp3 any; var root_889 any = A_arbace_c_musl_A_const_45.GetRawRoot__O(); var linked_890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_889, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_891 lang.IFn; if linked_890 == nil { ifn_891 = lang.IFn_Cast(root_889) } else { ifn_891 = nil }; var arg_892 any = r__3; if linked_890 == nil { tmp3 = ifn_891.Invoke_O__O(arg_892) } else { tmp3 = linked_890.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_889, arg_892) }; if jrt.J2g_Truth(tmp3) { var tmp4 *jrt.ConcurrentHashMap = jrt.ConcurrentHashMap_Cast(t.F_errs); var tmp5 any; var root_893 any = A_arbace_c_musl_A_const_55.GetRawRoot__O(); var linked_894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_893, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_895 lang.IFn; if linked_894 == nil { ifn_895 = lang.IFn_Cast(root_893) } else { ifn_895 = nil }; var arg_896 any = r__3; if linked_894 == nil { tmp5 = ifn_895.Invoke_O__O(arg_896) } else { tmp5 = linked_894.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_893, arg_896) }; jrt.NN(tmp4).Put_O_O__O(s__2, tmp5) }
//line :179:1
		var k__4 any; var root_897 any = A_arbace_c_musl_A_const_104.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_897, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_899 lang.IFn


		if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any = t.F_n; var arg_901 any = A_arbace_c_musl_A_const_105.GetRawRoot__O(); if linked_898 == nil { k__4 = ifn_899.Invoke_O_O__O(arg_900, arg_901) } else { k__4 = linked_898.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_897, arg_900, arg_901) }; var tmp6 bool; var na_902 any; var root_903 any = A_arbace_c_musl_A_const_106.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_core.A_arbace_core_mod_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = k__4; var arg_907 any = A_arbace_c_musl_A_const_107; if linked_904 == nil { na_902 = ifn_905.Invoke_O_O__O(arg_906, arg_907) } else { na_902 = linked_904.(*aot_arbace_core.A_arbace_core_mod_A).Invoke_O_O_O__O(root_903, arg_906, arg_907) }; if jrt.Long_InstanceOf(na_902) { var n0_908 int64 = jrt.NN(jrt.Long_Cast(na_902)).LongValue__J(); tmp6 = n0_908 == 0 } else { if jrt.Double_InstanceOf(na_902) { var n0_908_2 float64 = jrt.NN(jrt.Double_Cast(na_902)).DoubleValue__D(); tmp6 = n0_908_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_902) } }; if tmp6 { var root_921 any = A_arbace_c_musl_A_const_110.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_923 lang.IFn; if linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_111.GetRawRoot__O()); var tmp8 any = A_arbace_c_musl_A_const_112; var arg_924 any = tmp7.Invoke_O_O__O(tmp8, A_arbace_c_musl_A_const_113.Get__O()); if linked_922 == nil { ifn_923.Invoke_O__O(arg_924) } else { linked_922.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_921, arg_924) }; var tmp9 *lang.Compiler_AOTFn; var fnbody__920 any = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000132_A_New_O_O(t.F_todo, k__4); var tmp10 *jrt.Class; var fncls__919 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000132_A_fn_class; if fncls__919 == nil { var fncls__919d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__920); A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000132_A_fn_class = fncls__919d; tmp10 = fncls__919d } else { tmp10 = fncls__919 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__920, tmp10, nil); Up_Compiler_AOTFn_IFn(tmp9).Invoke__O() }
		continue L2 } else {
//line :179:1
			return nil } } }; /*line :177:1*/panic("j2g: unreachable") }
//line :177:1
func A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :177:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A) Ctor_O_O_O_O_O_O(c__todo, c__root, c__n, c__h, c__errs, c__q any) { t.F_todo = c__todo; t.F_root = c__root; t.F_n = c__n; t.F_h = c__h; t.F_errs = c__errs; t.F_q = c__q }
//line :177:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A) Invoke_O__O(self any) any { for { L2: for { var temp__1927000414__auto____1 any = jrt.NN(jrt.ConcurrentLinkedQueue_Cast(t.F_q)).Poll__O()

	if jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var r__3 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__980 any = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000137_A_New_O_O_O(t.F_root, t.F_h, s__2); var tmp2 *jrt.Class; var fncls__979 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000137_A_fn_class
		if fncls__979 == nil { var fncls__979d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__980); A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000137_A_fn_class = fncls__979d; tmp2 = fncls__979d } else { tmp2 = fncls__979 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__980, tmp2, nil); r__3 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
		var tmp3 any; var root_981 any = A_arbace_c_musl_A_const_45.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = r__3; if linked_982 == nil { tmp3 = ifn_983.Invoke_O__O(arg_984) } else { tmp3 = linked_982.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_981, arg_984) }; if jrt.J2g_Truth(tmp3) { var tmp4 *jrt.ConcurrentHashMap = jrt.ConcurrentHashMap_Cast(t.F_errs); var tmp5 any; var root_985 any = A_arbace_c_musl_A_const_55.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = r__3; if linked_986 == nil { tmp5 = ifn_987.Invoke_O__O(arg_988) } else { tmp5 = linked_986.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_985, arg_988) }; jrt.NN(tmp4).Put_O_O__O(s__2, tmp5) }
//line :179:1
		var k__4 any; var root_989 any = A_arbace_c_musl_A_const_104.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_991 lang.IFn


		if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = t.F_n; var arg_993 any = A_arbace_c_musl_A_const_105.GetRawRoot__O(); if linked_990 == nil { k__4 = ifn_991.Invoke_O_O__O(arg_992, arg_993) } else { k__4 = linked_990.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_989, arg_992, arg_993) }; var tmp6 bool; var na_994 any; var root_995 any = A_arbace_c_musl_A_const_106.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, aot_arbace_core.A_arbace_core_mod_A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = k__4; var arg_999 any = A_arbace_c_musl_A_const_107; if linked_996 == nil { na_994 = ifn_997.Invoke_O_O__O(arg_998, arg_999) } else { na_994 = linked_996.(*aot_arbace_core.A_arbace_core_mod_A).Invoke_O_O_O__O(root_995, arg_998, arg_999) }; if jrt.Long_InstanceOf(na_994) { var n0_1000 int64 = jrt.NN(jrt.Long_Cast(na_994)).LongValue__J(); tmp6 = n0_1000 == 0 } else { if jrt.Double_InstanceOf(na_994) { var n0_1000_2 float64 = jrt.NN(jrt.Double_Cast(na_994)).DoubleValue__D(); tmp6 = n0_1000_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_994) } }; if tmp6 { var root_1013 any = A_arbace_c_musl_A_const_110.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_111.GetRawRoot__O()); var tmp8 any = A_arbace_c_musl_A_const_112; var arg_1016 any = tmp7.Invoke_O_O__O(tmp8, A_arbace_c_musl_A_const_113.Get__O()); if linked_1014 == nil { ifn_1015.Invoke_O__O(arg_1016) } else { linked_1014.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1013, arg_1016) }; var tmp9 *lang.Compiler_AOTFn; var fnbody__1012 any = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000139_A_New_O_O(t.F_todo, k__4); var tmp10 *jrt.Class; var fncls__1011 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000139_A_fn_class; if fncls__1011 == nil { var fncls__1011d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__1012); A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000139_A_fn_class = fncls__1011d; tmp10 = fncls__1011d } else { tmp10 = fncls__1011 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1012, tmp10, nil); Up_Compiler_AOTFn_IFn(tmp9).Invoke__O() }
		continue L2 } else {
//line :179:1
			return nil } } }; /*line :177:1*/panic("j2g: unreachable") }


func A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000130_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000130_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000130_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :180:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000130_A) Ctor_O_O_O(c__root, c__h, c__s any) { t.F_root = c__root; t.F_h = c__h; t.F_s = c__s }
//line :180:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000130_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_877 any = A_arbace_c_musl_A_const_103.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, A_arbace_c_musl_read_one_A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any; var t_ any = t.F_h; t.F_h = nil; arg_880 = t_; var arg_881 any; var t__2 any = t.F_root; t.F_root = nil; arg_881 = t__2; var arg_882 any; var t__3 any = t.F_s; t.F_s = nil; arg_882 = t__3; if linked_878 == nil { tmp1 = ifn_879.Invoke_O_O_O__O(arg_880, arg_881, arg_882) } else { tmp1 = linked_878.(*A_arbace_c_musl_read_one_A).Invoke_O_O_O_O__O(root_877, arg_880, arg_881, arg_882) } }; return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 any = A_arbace_c_musl_A_const_84; var tmp4 any; var root_883 any = A_arbace_c_musl_A_const_95.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = e__3; if linked_884 == nil { tmp4 = ifn_885.Invoke_O__O(arg_886) } else { tmp4 = linked_884.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_883, arg_886) }; tmp1 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } }; return tmp1 }
//line :180:1
func A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000137_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000137_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000137_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :180:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000137_A) Ctor_O_O_O(c__root, c__h, c__s any) { t.F_root = c__root; t.F_h = c__h; t.F_s = c__s }
//line :180:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000137_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_969 any = A_arbace_c_musl_A_const_103.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, A_arbace_c_musl_read_one_A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any; var t_ any = t.F_h; t.F_h = nil; arg_972 = t_; var arg_973 any; var t__2 any = t.F_root; t.F_root = nil; arg_973 = t__2; var arg_974 any; var t__3 any = t.F_s; t.F_s = nil; arg_974 = t__3; if linked_970 == nil { tmp1 = ifn_971.Invoke_O_O_O__O(arg_972, arg_973, arg_974) } else { tmp1 = linked_970.(*A_arbace_c_musl_read_one_A).Invoke_O_O_O_O__O(root_969, arg_972, arg_973, arg_974) } }; return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 any = A_arbace_c_musl_A_const_84; var tmp4 any; var root_975 any = A_arbace_c_musl_A_const_95.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any = e__3; if linked_976 == nil { tmp4 = ifn_977.Invoke_O__O(arg_978) } else { tmp4 = linked_976.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_975, arg_978) }; tmp1 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } }; return tmp1 }

func A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000132_A_New_O_O(p0, p1 any) *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000132_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000132_A{}; t.Ctor_O_O(p0, p1); return t }
//line :182:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000132_A) Ctor_O_O(c__todo, c__k any) { t.F_todo = c__todo; t.F_k = c__k }
//line :182:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000132_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_108.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_k; t.F_k = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_todo; t.F_todo = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_60, tmp4, Lit_61, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp5)).Ref()) }; return nil }(); var root_916 any = A_arbace_c_musl_A_const_109.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; if linked_917 == nil { ifn_918.Invoke__O() } else { linked_917.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_916) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :182:1
func A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000139_A_New_O_O(p0, p1 any) *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000139_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000139_A{}; t.Ctor_O_O(p0, p1); return t }
//line :182:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000139_A) Ctor_O_O(c__todo, c__k any) { t.F_todo = c__todo; t.F_k = c__k }
//line :182:1
func (t *A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000139_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_108.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_k; t.F_k = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_todo; t.F_todo = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_60, tmp4, Lit_61, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp5)).Ref()) }; return nil }(); var root_1008 any = A_arbace_c_musl_A_const_109.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1008, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1010 lang.IFn; if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; if linked_1009 == nil { ifn_1010.Invoke__O() } else { linked_1009.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1008) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }




func A_arbace_c_musl_load_unit_A_New() *A_arbace_c_musl_load_unit_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_load_unit_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_c_musl_load_unit_A) Ctor() {}
//line :187:1
func (t *A_arbace_c_musl_load_unit_A) Invoke_O_O_O__O(self, root__0, src__1 any) any { var fr__3 any; var root_1077 any = A_arbace_c_musl_A_const_86.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, A_arbace_c_musl_forms_root_A_fn_class); var ifn_1079 lang.IFn; if


	linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = root__0; if linked_1078 == nil { fr__3 = ifn_1079.Invoke_O__O(arg_1080) } else { fr__3 = linked_1078.(*A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_1077, arg_1080) }; var vec__1657000149__4 any; var root_1081 any = /*line :187:1*/A_arbace_c_musl_A_const_115.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A_fn_class); var ifn_1083 lang.IFn; if



	linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; var arg_1084 any = lang.IFn_Cast(A_arbace_c_musl_A_const_116.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, fr__3, nil, src__1, nil)).Ref()); if linked_1082 == nil { vec__1657000149__4 = ifn_1083.Invoke_O__O(arg_1084) } else { vec__1657000149__4 = linked_1082.(*aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A).Invoke_O_O__O(root_1081, arg_1084) }; var ___5 any = /*line :187:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1657000149__4, lang.RT_IntCast_J__I_NoInit(0), nil); var forms__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000149__4, lang.RT_IntCast_J__I_NoInit(1), nil); var us__7 any; var root_1089 any = A_arbace_c_musl_A_const_117.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_1091 lang.IFn; _ = ___5; if




	linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = lang.IFn_Cast(A_arbace_c_musl_A_const_116.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, fr__3, nil, src__1, nil)).Ref()); if linked_1090 == nil { us__7 = ifn_1091.Invoke_O__O(arg_1092) } else { us__7 = linked_1090.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_1089, arg_1092) }; var tmp1 any = A_arbace_c_musl_A_const_118; var tmp2 any = A_arbace_c_musl_A_const_97; var tmp3 any; var root_1097 any = /*line :187:1*/A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1097, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1099 lang.IFn; if






	linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1101 any; var iter__1927001039__auto____8 any; var fnbody__1205 any = A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A_New_O(fr__3); var tmp4 *jrt.Class; var fncls__1204 *jrt.Class = A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A_fn_class; if fncls__1204 == nil { var fncls__1204d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__1205); A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A_fn_class = fncls__1204d; tmp4 = fncls__1204d } else { tmp4 = fncls__1204 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1205, tmp4, nil); arg_1101 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(us__7); if linked_1098 == nil { tmp3 = ifn_1099.Invoke_O_O__O(arg_1100, arg_1101) } else { tmp3 = linked_1098.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1097, arg_1100, arg_1101) }; return /*line :187:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, forms__6, tmp2, tmp3)) }






func A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A_New_O(p0 any) *A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A{}; t.Ctor_O(p0); return t }
//line :194:1
func (t *A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A) Ctor_O(c__fr any) { t.F_fr = c__fr }
//line :194:1
func (t *A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A) Invoke_O_O__O(self, s__1657000153__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1203 any = A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A_New_O_O_O(t.F_fr, s__1657000153__1, self); var tmp2 *jrt.Class; var fncls__1202 *jrt.Class = A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A_fn_class; if fncls__1202 == nil { var fncls__1202d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__1203); A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A_fn_class = fncls__1202d; tmp2 = fncls__1202d } else { tmp2 = fncls__1202 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1203, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :194:1
func A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :194:1
func (t *A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A) Ctor_O_O_O(c__fr, c__s__1657000153, c__iter__1657000152 any) { t.F_fr = c__fr; t.F_s__1657000153 = c__s__1657000153; t.F_iter__1657000152 = c__iter__1657000152 }
//line :194:1
func (t *A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A) Invoke_O__O(self any) any { { var s__1657000153__1 any; var t_ any = t.F_s__1657000153; t.F_s__1657000153 = nil; s__1657000153__1 = t_; for { var temp__1927000414__auto____2 any; var root_1102 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1104 lang.IFn; if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = s__1657000153__1; if linked_1103 == nil { temp__1927000414__auto____2 = ifn_1104.Invoke_O__O(arg_1105) } else { temp__1927000414__auto____2 = linked_1103.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1102, arg_1105) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1657000153__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1106 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1106, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1108 lang.IFn; if linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any = s__1657000153__3; if linked_1107 == nil { tmp1 = ifn_1108.Invoke_O__O(arg_1109) } else { tmp1 = linked_1107.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1106, arg_1109) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1110 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1110, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1112 lang.IFn; if linked_1111 == nil { ifn_1112 = lang.IFn_Cast(root_1110) } else { ifn_1112 = nil }; var arg_1113 any = s__1657000153__3; if linked_1111 == nil { c__1927001037__auto____4 = ifn_1112.Invoke_O__O(arg_1113) } else { c__1927001037__auto____4 = linked_1111.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1110, arg_1113) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1657000155__6 any; var root_1114 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_1115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1114, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1116 lang.IFn; if linked_1115 == nil { ifn_1116 = lang.IFn_Cast(root_1114) } else { ifn_1116 = nil }; var arg_1117 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1115 == nil { b__1657000155__6 = ifn_1116.Invoke_O__O(arg_1117) } else { b__1657000155__6 = linked_1115.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1114, arg_1117) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1145 any = A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_fn__1657000158_A_New_O_O_I_O(b__1657000155__6, t.F_fr, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1144 *jrt.Class = A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_fn__1657000158_A_fn_class; if fncls__1144 == nil { var fncls__1144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__1145); A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_fn__1657000158_A_fn_class = fncls__1144d; tmp3 = fncls__1144d } else { tmp3 = fncls__1144 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1145, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1146 any = A_arbace_c_musl_A_const_34.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any; var root_1151 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = b__1657000155__6; if linked_1152 == nil { arg_1149 = ifn_1153.Invoke_O__O(arg_1154) } else { arg_1149 = linked_1152.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1151, arg_1154) }; var arg_1150 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1657000152); var tmp5 any; var root_1155 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = s__1657000153__3; if linked_1156 == nil { tmp5 = ifn_1157.Invoke_O__O(arg_1158) } else { tmp5 = linked_1156.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1155, arg_1158) }; arg_1150 = tmp4.Invoke_O__O(tmp5); if linked_1147 == nil { return ifn_1148.Invoke_O_O__O(arg_1149, arg_1150) } else { return linked_1147.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1146, arg_1149, arg_1150) } } else { var root_1159 any = A_arbace_c_musl_A_const_34.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any; var root_1164 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1166 lang.IFn; if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = b__1657000155__6; if linked_1165 == nil { arg_1162 = ifn_1166.Invoke_O__O(arg_1167) } else { arg_1162 = linked_1165.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1164, arg_1167) }; var arg_1163 any; if linked_1160 == nil { return ifn_1161.Invoke_O_O__O(arg_1162, arg_1163) } else { return linked_1160.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1159, arg_1162, arg_1163) } } } else { var u__4 any; var root_1168 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1170 lang.IFn; if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any = s__1657000153__3; if linked_1169 == nil { u__4 = ifn_1170.Invoke_O__O(arg_1171) } else { u__4 = linked_1169.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1168, arg_1171) }; var root_1172 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1174 lang.IFn; if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any; var vec__1657000163__5 any; var root_1177 any = A_arbace_c_musl_A_const_115.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A_fn_class); var ifn_1179 lang.IFn
														if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_116.GetRawRoot__O()); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_49, nil, Lit_44); var tmp8 any = t.F_fr; var tmp9 any; var root_1185 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1187 lang.IFn; if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = u__4; var arg_1189 any = A_arbace_c_musl_A_const_119; if linked_1186 == nil { tmp9 = ifn_1187.Invoke_O_O__O(arg_1188, arg_1189) } else { tmp9 = linked_1186.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1185, arg_1188, arg_1189) }; arg_1180 = tmp6.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, nil)).Ref()); if linked_1178 == nil { vec__1657000163__5 = ifn_1179.Invoke_O__O(arg_1180) } else { vec__1657000163__5 = linked_1178.(*aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A).Invoke_O_O__O(root_1177, arg_1180) }
//line :194:1
	var hf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000163__5, lang.RT_IntCast_J__I_NoInit(0), nil); var hforms__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000163__5, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp10 any; var root_1190 any = A_arbace_c_musl_A_const_120.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1192 lang.IFn

	if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = u__4; if linked_1191 == nil { tmp10 = ifn_1192.Invoke_O__O(arg_1193) } else { tmp10 = linked_1191.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1190, arg_1193) }
//line :194:1
	var tmp11 any = tmp10; var tmp12 any = A_arbace_c_musl_A_const_118; var tmp13 any = A_arbace_c_musl_A_const_121; var tmp14 any; var root_1194 any = A_arbace_c_musl_A_const_55.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1196 lang.IFn

	if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any = hf__6; if linked_1195 == nil { tmp14 = ifn_1196.Invoke_O__O(arg_1197) } else { tmp14 = linked_1195.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1194, arg_1197) }
//line :194:1
	arg_1175 = lang.Tuple_Create_O_O__IPersistentVector(tmp11, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, hforms__7, tmp13, tmp14))); var arg_1176 any; var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__1657000152); var tmp16 any; var root_1198 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_1199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1198, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1200 lang.IFn; if linked_1199 == nil { ifn_1200 = lang.IFn_Cast(root_1198) } else { ifn_1200 = nil }; var arg_1201 any = s__1657000153__3; if linked_1199 == nil { tmp16 = ifn_1200.Invoke_O__O(arg_1201) } else { tmp16 = linked_1199.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1198, arg_1201) }; arg_1176 = tmp15.Invoke_O__O(tmp16); if linked_1173 == nil { return ifn_1174.Invoke_O_O__O(arg_1175, arg_1176) } else { return linked_1173.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1172, arg_1175, arg_1176) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :194:1
func A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_fn__1657000158_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_fn__1657000158_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_fn__1657000158_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :194:1
func (t *A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_fn__1657000158_A) Ctor_O_O_I_O(c__b__1657000155, c__fr any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1657000155 = c__b__1657000155; t.F_fr = c__fr; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :194:1
func (t *A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_fn__1657000158_A) Invoke_O__O(self any) any { { var i__1657000154__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1657000154__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1657000154__1)); var root_1118 any = A_arbace_c_musl_A_const_33.GetRawRoot__O(); var linked_1119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1118, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1120 lang.IFn; if linked_1119 == nil { ifn_1120 = lang.IFn_Cast(root_1118) } else { ifn_1120 = nil }; var arg_1121 any = t.F_b__1657000155; var arg_1122 any; var vec__1657000159__3 any; var root_1123 any = A_arbace_c_musl_A_const_115.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A_fn_class); var ifn_1125 lang.IFn
																if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_116.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_49, nil, Lit_44); var tmp4 any = t.F_fr; var tmp5 any; var root_1131 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1133 lang.IFn; if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = u__2; var arg_1135 any = A_arbace_c_musl_A_const_119; if linked_1132 == nil { tmp5 = ifn_1133.Invoke_O_O__O(arg_1134, arg_1135) } else { tmp5 = linked_1132.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1131, arg_1134, arg_1135) }; arg_1126 = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5, nil)).Ref()); if linked_1124 == nil { vec__1657000159__3 = ifn_1125.Invoke_O__O(arg_1126) } else { vec__1657000159__3 = linked_1124.(*aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A).Invoke_O_O__O(root_1123, arg_1126) }
//line :194:1
	var hf__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000159__3, lang.RT_IntCast_J__I_NoInit(0), nil); var hforms__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000159__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_1136 any = A_arbace_c_musl_A_const_120.GetRawRoot__O(); var linked_1137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1136, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1138 lang.IFn

	if linked_1137 == nil { ifn_1138 = lang.IFn_Cast(root_1136) } else { ifn_1138 = nil }; var arg_1139 any = u__2; if linked_1137 == nil { tmp6 = ifn_1138.Invoke_O__O(arg_1139) } else { tmp6 = linked_1137.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1136, arg_1139) }
//line :194:1
	var tmp7 any = tmp6; var tmp8 any = A_arbace_c_musl_A_const_118; var tmp9 any = A_arbace_c_musl_A_const_121; var tmp10 any; var root_1140 any = A_arbace_c_musl_A_const_55.GetRawRoot__O(); var linked_1141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1140, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1142 lang.IFn

	if linked_1141 == nil { ifn_1142 = lang.IFn_Cast(root_1140) } else { ifn_1142 = nil }; var arg_1143 any = hf__4; if linked_1141 == nil { tmp10 = ifn_1142.Invoke_O__O(arg_1143) } else { tmp10 = linked_1141.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1140, arg_1143) }
//line :194:1
	arg_1122 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, hforms__5, tmp9, tmp10))); if linked_1119 == nil { ifn_1120.Invoke_O_O__O(arg_1121, arg_1122) } else { linked_1119.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1118, arg_1121, arg_1122) }; i__1657000154__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000154__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_c_musl_index_A_New() *A_arbace_c_musl_index_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_index_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_c_musl_index_A) Ctor() {}
//line :198:1
func (t *A_arbace_c_musl_index_A) Invoke_O_O__O(self, root__0 any) any { var f__2 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_39); var tmp2 any; var root_1206 any = A_arbace_c_musl_A_const_86.GetRawRoot__O(); var linked_1207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1206, A_arbace_c_musl_forms_root_A_fn_class); var ifn_1208 lang.IFn; if


	linked_1207 == nil { ifn_1208 = lang.IFn_Cast(root_1206) } else { ifn_1208 = nil }; var arg_1209 any = root__0; if linked_1207 == nil { tmp2 = ifn_1208.Invoke_O__O(arg_1209) } else { tmp2 = linked_1207.(*A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_1206, arg_1209) }; f__2 = /*line :198:1*/jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil))); if



	jrt.File_Cast(f__2).Exists__Z() {
		var root_1210 any = A_arbace_c_musl_A_const_117.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any = lang.IFn_Cast(A_arbace_c_musl_A_const_116.GetRawRoot__O()).Invoke_O__O(f__2); if linked_1211 == nil { return ifn_1212.Invoke_O__O(arg_1213) } else { return linked_1211.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_1210, arg_1213) } } else {
//line :202:1
			var ix__3 any; var root_1218 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1218, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1220 lang.IFn

			if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = lang.IFn_Cast(A_arbace_c_musl_A_const_122.GetRawRoot__O()).Invoke__O(); var arg_1222 any; var iter__1927001039__auto____3 any; var fnbody__1361 any = A_arbace_c_musl_index_iter__1657000169__1657000173_A_New_O(root__0); var tmp3 *jrt.Class; var fncls__1360 *jrt.Class = A_arbace_c_musl_index_iter__1657000169__1657000173_A_fn_class
			if fncls__1360 == nil { var fncls__1360d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__1361); A_arbace_c_musl_index_iter__1657000169__1657000173_A_fn_class = fncls__1360d; tmp3 = fncls__1360d } else { tmp3 = fncls__1360 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1361, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp5 any; var root_1362 any = A_arbace_c_musl_A_const_98.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, A_arbace_c_musl_sources_A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = root__0; if linked_1363 == nil { tmp5 = ifn_1364.Invoke_O__O(arg_1365) } else { tmp5 = linked_1363.(*A_arbace_c_musl_sources_A).Invoke_O_O__O(root_1362, arg_1365) }; arg_1222 = tmp4.Invoke_O__O(tmp5)
//line :204:1
			if linked_1219 == nil { ix__3 = ifn_1220.Invoke_O_O__O(arg_1221, arg_1222) } else { ix__3 = linked_1219.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1218, arg_1221, arg_1222)
			}




			lang.IFn_Cast(A_arbace_c_musl_A_const_81.GetRawRoot__O()).Invoke_O_O__O(f__2, lang.IFn_Cast(A_arbace_c_musl_A_const_93.GetRawRoot__O()).Invoke_O__O(ix__3))
//line :202:1
			return ix__3 } }


func A_arbace_c_musl_index_iter__1657000169__1657000173_A_New_O(p0 any) *A_arbace_c_musl_index_iter__1657000169__1657000173_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_index_iter__1657000169__1657000173_A{}; t.Ctor_O(p0); return t }
//line :205:1
func (t *A_arbace_c_musl_index_iter__1657000169__1657000173_A) Ctor_O(c__root any) { t.F_root = c__root }
//line :205:1
func (t *A_arbace_c_musl_index_iter__1657000169__1657000173_A) Invoke_O_O__O(self, s__1657000170__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1359 any = A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A_New_O_O_O(t.F_root, self, s__1657000170__1); var tmp2 *jrt.Class; var fncls__1358 *jrt.Class = A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A_fn_class; if fncls__1358 == nil { var fncls__1358d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__1359); A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A_fn_class = fncls__1358d; tmp2 = fncls__1358d } else { tmp2 = fncls__1358 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1359, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :205:1
func A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :205:1
func (t *A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A) Ctor_O_O_O(c__root, c__iter__1657000169, c__s__1657000170 any) { t.F_root = c__root; t.F_iter__1657000169 = c__iter__1657000169; t.F_s__1657000170 = c__s__1657000170 }
//line :205:1
func (t *A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A) Invoke_O__O(self any) any { { var s__1657000170__1 any; var t_ any = t.F_s__1657000170; t.F_s__1657000170 = nil; s__1657000170__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1226 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any = s__1657000170__1; if linked_1227 == nil { temp__1927000414__auto____2 = ifn_1228.Invoke_O__O(arg_1229) } else { temp__1927000414__auto____2 = linked_1227.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1226, arg_1229) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1657000170__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1230 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_1231 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1230, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1232 lang.IFn; if linked_1231 == nil { ifn_1232 = lang.IFn_Cast(root_1230) } else { ifn_1232 = nil }; var arg_1233 any = s__1657000170__3; if linked_1231 == nil { tmp1 = ifn_1232.Invoke_O__O(arg_1233) } else { tmp1 = linked_1231.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1230, arg_1233) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1234 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1236 lang.IFn; if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = s__1657000170__3; if linked_1235 == nil { c__1927001037__auto____4 = ifn_1236.Invoke_O__O(arg_1237) } else { c__1927001037__auto____4 = linked_1235.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1234, arg_1237) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1657000172__6 any; var root_1238 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1240 lang.IFn; if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1239 == nil { b__1657000172__6 = ifn_1240.Invoke_O__O(arg_1241) } else { b__1657000172__6 = linked_1239.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1238, arg_1241) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1283 any = A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_fn__1657000175_A_New_O_I_O_O(t.F_root, size__1927001038__auto____5, c__1927001037__auto____4, b__1657000172__6); var tmp3 *jrt.Class; var fncls__1282 *jrt.Class = A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_fn__1657000175_A_fn_class; if fncls__1282 == nil { var fncls__1282d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__1283); A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_fn__1657000175_A_fn_class = fncls__1282d; tmp3 = fncls__1282d } else { tmp3 = fncls__1282 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1283, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1284 any = A_arbace_c_musl_A_const_34.GetRawRoot__O(); var linked_1285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1284, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1286 lang.IFn; if linked_1285 == nil { ifn_1286 = lang.IFn_Cast(root_1284) } else { ifn_1286 = nil }; var arg_1287 any; var root_1289 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = b__1657000172__6; if linked_1290 == nil { arg_1287 = ifn_1291.Invoke_O__O(arg_1292) } else { arg_1287 = linked_1290.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1289, arg_1292) }; var arg_1288 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1657000169); var tmp5 any; var root_1293 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1295 lang.IFn; if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = s__1657000170__3; if linked_1294 == nil { tmp5 = ifn_1295.Invoke_O__O(arg_1296) } else { tmp5 = linked_1294.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1293, arg_1296) }; arg_1288 = tmp4.Invoke_O__O(tmp5); if linked_1285 == nil { return ifn_1286.Invoke_O_O__O(arg_1287, arg_1288) } else { return linked_1285.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1284, arg_1287, arg_1288) } } else { var root_1297 any = A_arbace_c_musl_A_const_34.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1299 lang.IFn; if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any; var root_1302 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1304 lang.IFn; if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any = b__1657000172__6; if linked_1303 == nil { arg_1300 = ifn_1304.Invoke_O__O(arg_1305) } else { arg_1300 = linked_1303.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1302, arg_1305) }; var arg_1301 any; if linked_1298 == nil { return ifn_1299.Invoke_O_O__O(arg_1300, arg_1301) } else { return linked_1298.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1297, arg_1300, arg_1301) } } } else { var s__4 any; var root_1306 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1308 lang.IFn; if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = s__1657000170__3; if linked_1307 == nil { s__4 = ifn_1308.Invoke_O__O(arg_1309) } else { s__4 = linked_1307.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1306, arg_1309) }; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil, Lit_44); var tmp7 any; var root_1310 any = A_arbace_c_musl_A_const_86.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, A_arbace_c_musl_forms_root_A_fn_class); var ifn_1312 lang.IFn
													if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = t.F_root; if linked_1311 == nil { tmp7 = ifn_1312.Invoke_O__O(arg_1313) } else { tmp7 = linked_1311.(*A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_1310, arg_1313) }
//line :205:1
	if jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, s__4, nil))).Exists__Z() { var root_1314 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1316 lang.IFn; if linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any; var u__5 any; var root_1319 any = A_arbace_c_musl_A_const_123.GetRawRoot__O(); var linked_1320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1319, A_arbace_c_musl_load_unit_A_fn_class); var ifn_1321 lang.IFn

		if linked_1320 == nil { ifn_1321 = lang.IFn_Cast(root_1319) } else { ifn_1321 = nil }; var arg_1322 any = t.F_root; var arg_1323 any = s__4; if linked_1320 == nil { u__5 = ifn_1321.Invoke_O_O__O(arg_1322, arg_1323) } else { u__5 = linked_1320.(*A_arbace_c_musl_load_unit_A).Invoke_O_O_O__O(root_1319, arg_1322, arg_1323) }
//line :205:1
		var all__6 any; var root_1324 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1326 lang.IFn


		if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = A_arbace_c_musl_A_const_118.Invoke_O__O(u__5); var arg_1328 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_124.GetRawRoot__O()); var tmp9 any = A_arbace_c_musl_A_const_118; var tmp10 any; var root_1334 any = A_arbace_c_musl_A_const_125.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = A_arbace_c_musl_A_const_97.Invoke_O__O(u__5); if linked_1335 == nil { tmp10 = ifn_1336.Invoke_O__O(arg_1337) } else { tmp10 = linked_1335.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1334, arg_1337) }; arg_1328 = tmp8.Invoke_O_O__O(tmp9, tmp10); if linked_1325 == nil { all__6 = ifn_1326.Invoke_O_O__O(arg_1327, arg_1328) } else { all__6 = linked_1325.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1324, arg_1327, arg_1328) }
//line :205:1
		var tmp11 any = A_arbace_c_musl_A_const_126; var tmp12 any; var root_1338 any = A_arbace_c_musl_A_const_127.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, A_arbace_c_musl_unit_defs_A_fn_class); var ifn_1340 lang.IFn



		if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = A_arbace_c_musl_A_const_118.Invoke_O__O(u__5); if linked_1339 == nil { tmp12 = ifn_1340.Invoke_O__O(arg_1341) } else { tmp12 = linked_1339.(*A_arbace_c_musl_unit_defs_A).Invoke_O_O__O(root_1338, arg_1341) }
//line :205:1
		var tmp13 any = tmp12; var tmp14 any = A_arbace_c_musl_A_const_128; var tmp15 any; var root_1342 any = A_arbace_c_musl_A_const_53.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1344 lang.IFn



		if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any; var root_1346 any = A_arbace_c_musl_A_const_129.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, A_arbace_c_musl_refs_A_fn_class); var ifn_1348 lang.IFn; if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = all__6; if linked_1347 == nil { arg_1345 = ifn_1348.Invoke_O__O(arg_1349) } else { arg_1345 = linked_1347.(*A_arbace_c_musl_refs_A).Invoke_O_O__O(root_1346, arg_1349) }; if linked_1343 == nil { tmp15 = ifn_1344.Invoke_O__O(arg_1345) } else { tmp15 = linked_1343.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1342, arg_1345) }
//line :205:1
		arg_1317 = lang.Tuple_Create_O_O__IPersistentVector(s__4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp13, tmp14, tmp15))); var arg_1318 any; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__1657000169); var tmp17 any; var root_1350 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_1351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1350, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1352 lang.IFn; if linked_1351 == nil { ifn_1352 = lang.IFn_Cast(root_1350) } else { ifn_1352 = nil }; var arg_1353 any = s__1657000170__3; if linked_1351 == nil { tmp17 = ifn_1352.Invoke_O__O(arg_1353) } else { tmp17 = linked_1351.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1350, arg_1353) }; arg_1318 = tmp16.Invoke_O__O(tmp17); if linked_1315 == nil { return ifn_1316.Invoke_O_O__O(arg_1317, arg_1318) } else { return linked_1315.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1314, arg_1317, arg_1318) } } else { var tmp18 any; var root_1354 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1356 lang.IFn; if linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = s__1657000170__3; if linked_1355 == nil { tmp18 = ifn_1356.Invoke_O__O(arg_1357) } else { tmp18 = linked_1355.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1354, arg_1357) }; s__1657000170__1 = tmp18; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :205:1
func A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_fn__1657000175_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_fn__1657000175_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_fn__1657000175_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :205:1
func (t *A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_fn__1657000175_A) Ctor_O_I_O_O(c__root any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1657000172 any) { t.F_root = c__root; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1657000172 = c__b__1657000172 }
//line :205:1
func (t *A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_fn__1657000175_A) Invoke_O__O(self any) any { { var i__1657000171__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1657000171__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1657000171__1)); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil, Lit_44); var tmp3 any; var root_1242 any = A_arbace_c_musl_A_const_86.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1242, A_arbace_c_musl_forms_root_A_fn_class); var ifn_1244 lang.IFn
															if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = t.F_root; if linked_1243 == nil { tmp3 = ifn_1244.Invoke_O__O(arg_1245) } else { tmp3 = linked_1243.(*A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_1242, arg_1245) }
//line :205:1
	if jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, s__2, nil))).Exists__Z() { var root_1246 any = A_arbace_c_musl_A_const_33.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = t.F_b__1657000172; var arg_1250 any; var u__3 any; var root_1251 any = A_arbace_c_musl_A_const_123.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1251, A_arbace_c_musl_load_unit_A_fn_class); var ifn_1253 lang.IFn

		if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any = t.F_root; var arg_1255 any = s__2; if linked_1252 == nil { u__3 = ifn_1253.Invoke_O_O__O(arg_1254, arg_1255) } else { u__3 = linked_1252.(*A_arbace_c_musl_load_unit_A).Invoke_O_O_O__O(root_1251, arg_1254, arg_1255) }
//line :205:1
		var all__4 any; var root_1256 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1258 lang.IFn


		if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = A_arbace_c_musl_A_const_118.Invoke_O__O(u__3); var arg_1260 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_124.GetRawRoot__O()); var tmp5 any = A_arbace_c_musl_A_const_118; var tmp6 any; var root_1266 any = A_arbace_c_musl_A_const_125.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1266, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any = A_arbace_c_musl_A_const_97.Invoke_O__O(u__3); if linked_1267 == nil { tmp6 = ifn_1268.Invoke_O__O(arg_1269) } else { tmp6 = linked_1267.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1266, arg_1269) }; arg_1260 = tmp4.Invoke_O_O__O(tmp5, tmp6); if linked_1257 == nil { all__4 = ifn_1258.Invoke_O_O__O(arg_1259, arg_1260) } else { all__4 = linked_1257.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1256, arg_1259, arg_1260) }
//line :205:1
		var tmp7 any = A_arbace_c_musl_A_const_126; var tmp8 any; var root_1270 any = A_arbace_c_musl_A_const_127.GetRawRoot__O(); var linked_1271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1270, A_arbace_c_musl_unit_defs_A_fn_class); var ifn_1272 lang.IFn



		if linked_1271 == nil { ifn_1272 = lang.IFn_Cast(root_1270) } else { ifn_1272 = nil }; var arg_1273 any = A_arbace_c_musl_A_const_118.Invoke_O__O(u__3); if linked_1271 == nil { tmp8 = ifn_1272.Invoke_O__O(arg_1273) } else { tmp8 = linked_1271.(*A_arbace_c_musl_unit_defs_A).Invoke_O_O__O(root_1270, arg_1273) }
//line :205:1
		var tmp9 any = tmp8; var tmp10 any = A_arbace_c_musl_A_const_128; var tmp11 any; var root_1274 any = A_arbace_c_musl_A_const_53.GetRawRoot__O(); var linked_1275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1274, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1276 lang.IFn



		if linked_1275 == nil { ifn_1276 = lang.IFn_Cast(root_1274) } else { ifn_1276 = nil }; var arg_1277 any; var root_1278 any = A_arbace_c_musl_A_const_129.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, A_arbace_c_musl_refs_A_fn_class); var ifn_1280 lang.IFn; if linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any = all__4; if linked_1279 == nil { arg_1277 = ifn_1280.Invoke_O__O(arg_1281) } else { arg_1277 = linked_1279.(*A_arbace_c_musl_refs_A).Invoke_O_O__O(root_1278, arg_1281) }; if linked_1275 == nil { tmp11 = ifn_1276.Invoke_O__O(arg_1277) } else { tmp11 = linked_1275.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1274, arg_1277) }
//line :205:1
		arg_1250 = lang.Tuple_Create_O_O__IPersistentVector(s__2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, tmp10, tmp11))); if linked_1247 == nil { ifn_1248.Invoke_O_O__O(arg_1249, arg_1250) } else { linked_1247.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1246, arg_1249, arg_1250) }; i__1657000171__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000171__1); continue L1 } else { i__1657000171__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000171__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_c_musl_library_A_New() *A_arbace_c_musl_library_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_library_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_c_musl_library_A) Ctor() {}
//line :216:1
func (t *A_arbace_c_musl_library_A) Invoke_O_O_O__O(self, h__0, root__1 any) any { var ix__3 any; var root_1375 any = A_arbace_c_musl_A_const_130.GetRawRoot__O(); var linked_1376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1375, A_arbace_c_musl_index_A_fn_class); var ifn_1377 lang.IFn; if


	linked_1376 == nil { ifn_1377 = lang.IFn_Cast(root_1375) } else { ifn_1377 = nil }; var arg_1378 any = root__1; if linked_1376 == nil { ix__3 = ifn_1377.Invoke_O__O(arg_1378) } else { ix__3 = linked_1376.(*A_arbace_c_musl_index_A).Invoke_O_O__O(root_1375, arg_1378) }; var by__4 any = /*line :216:1*/jrt.HashMap_New(); var seq_1657000180__5 any; var root_1383 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1385 lang.IFn; if




	linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = ix__3; if linked_1384 == nil { seq_1657000180__5 = ifn_1385.Invoke_O__O(arg_1386) } else { seq_1657000180__5 = linked_1384.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1383, arg_1386) }; var chunk_1657000181__6 any; var count_1657000182__7 int64 = 0; var i_1657000183__8 int64 = 0; L1:
//line :216:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000183__8, count_1657000182__7) { var vec__1657000192__9 any = lang.Indexed_Cast(chunk_1657000181__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000183__8)); var s__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000192__9, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1657000195__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000192__9, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1657000195__12 any; if lang.ISeq_InstanceOf(map__1657000195__11) { var tmp1 any; var root_1387 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1389 lang.IFn; if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = map__1657000195__11; if linked_1388 == nil { tmp1 = ifn_1389.Invoke_O__O(arg_1390) } else { tmp1 = linked_1388.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1387, arg_1390) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1391 any = A_arbace_c_musl_A_const_136.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = map__1657000195__11; if linked_1392 == nil { tmp2 = ifn_1393.Invoke_O__O(arg_1394) } else { tmp2 = linked_1392.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1391, arg_1394) }; map__1657000195__12 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1395 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1395, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1397 lang.IFn; if linked_1396 == nil { ifn_1397 = lang.IFn_Cast(root_1395) } else { ifn_1397 = nil }; var arg_1398 any = map__1657000195__11; if linked_1396 == nil { tmp3 = ifn_1397.Invoke_O__O(arg_1398) } else { tmp3 = linked_1396.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1395, arg_1398) }; if jrt.J2g_Truth(tmp3) { var root_1399 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1399, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1401 lang.IFn; if linked_1400 == nil { ifn_1401 = lang.IFn_Cast(root_1399) } else { ifn_1401 = nil }; var arg_1402 any = map__1657000195__11; if linked_1400 == nil { map__1657000195__12 = ifn_1401.Invoke_O__O(arg_1402) } else { map__1657000195__12 = linked_1400.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1399, arg_1402) } } else { map__1657000195__12 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1657000195__12 = map__1657000195__11 }; var defs__13 any = lang.RT_Get_O_O__O_NoInit(map__1657000195__12, A_arbace_c_musl_A_const_126); var seq_1657000188__14 any; var root_1435 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1435, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1437 lang.IFn; if linked_1436 == nil { ifn_1437 = lang.IFn_Cast(root_1435) } else { ifn_1437 = nil }; var arg_1438 any = defs__13; if linked_1436 == nil { seq_1657000188__14 = ifn_1437.Invoke_O__O(arg_1438) } else { seq_1657000188__14 = linked_1436.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1435, arg_1438) }; var chunk_1657000189__15 any; var count_1657000190__16 int64 = 0; var i_1657000191__17 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000191__17, count_1657000190__16) { var vec__1657000197__18 any = lang.Indexed_Cast(chunk_1657000189__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000191__17)); var n__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000197__18, lang.RT_IntCast_J__I_NoInit(0), nil); var d__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000197__18, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(by__4); var tmp5 any; var root_1455 any = A_arbace_c_musl_A_const_10.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1457 lang.IFn

			if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any; var or__1927000174__auto____21 any = jrt.HashMap_Cast(by__4).Get_O__O(n__19); if jrt.J2g_Truth(or__1927000174__auto____21) { arg_1458 = or__1927000174__auto____21 } else { arg_1458 = lang.PersistentVector_EMPTY.Ref() }; var arg_1459 any = lang.Tuple_Create_O_O__IPersistentVector(s__10, A_arbace_c_musl_A_const_62.Invoke_O__O(d__20)); if linked_1456 == nil { tmp5 = ifn_1457.Invoke_O_O__O(arg_1458, arg_1459) } else { tmp5 = linked_1456.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1455, arg_1458, arg_1459) }; tmp4.Put_O_O__O(n__19, tmp5)
//line :221:1
			seq_1657000188__14, chunk_1657000189__15, count_1657000190__16, i_1657000191__17 = seq_1657000188__14, chunk_1657000189__15, count_1657000190__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000191__17); continue L2 } else { var temp__1927000414__auto____18 any; var root_1439 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1441 lang.IFn; if linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = seq_1657000188__14; if linked_1440 == nil { temp__1927000414__auto____18 = ifn_1441.Invoke_O__O(arg_1442) } else { temp__1927000414__auto____18 = linked_1440.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1439, arg_1442) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1657000188__19 any = temp__1927000414__auto____18; var tmp6 any; var root_1443 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = seq_1657000188__19; if linked_1444 == nil { tmp6 = ifn_1445.Invoke_O__O(arg_1446) } else { tmp6 = linked_1444.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1443, arg_1446) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____20 any; var root_1447 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1449 lang.IFn; if linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any = seq_1657000188__19; if linked_1448 == nil { c__1927000678__auto____20 = ifn_1449.Invoke_O__O(arg_1450) } else { c__1927000678__auto____20 = linked_1448.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1447, arg_1450) }; var tmp7 any; var root_1460 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = seq_1657000188__19; if linked_1461 == nil { tmp7 = ifn_1462.Invoke_O__O(arg_1463) } else { tmp7 = linked_1461.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1460, arg_1463) }; seq_1657000188__14, chunk_1657000189__15, count_1657000190__16, i_1657000191__17 = tmp7, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__1657000200__20 any; var root_1451 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = seq_1657000188__19; if linked_1452 == nil { vec__1657000200__20 = ifn_1453.Invoke_O__O(arg_1454) } else { vec__1657000200__20 = linked_1452.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1451, arg_1454) }; var n__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000200__20, lang.RT_IntCast_J__I_NoInit(0), nil); var d__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000200__20, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp8 jrt.HashMap_I = jrt.HashMap_Cast(by__4); var tmp9 any; var root_1464 any = A_arbace_c_musl_A_const_10.GetRawRoot__O(); var linked_1465 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1464, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1466 lang.IFn

				if linked_1465 == nil { ifn_1466 = lang.IFn_Cast(root_1464) } else { ifn_1466 = nil }; var arg_1467 any; var or__1927000174__auto____23 any = jrt.HashMap_Cast(by__4).Get_O__O(n__21); if jrt.J2g_Truth(or__1927000174__auto____23) { arg_1467 = or__1927000174__auto____23 } else { arg_1467 = lang.PersistentVector_EMPTY.Ref() }; var arg_1468 any = lang.Tuple_Create_O_O__IPersistentVector(s__10, A_arbace_c_musl_A_const_62.Invoke_O__O(d__22)); if linked_1465 == nil { tmp9 = ifn_1466.Invoke_O_O__O(arg_1467, arg_1468) } else { tmp9 = linked_1465.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1464, arg_1467, arg_1468) }; tmp8.Put_O_O__O(n__21, tmp9)
//line :221:1
				var tmp10 any; var root_1469 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = seq_1657000188__19; if linked_1470 == nil { tmp10 = ifn_1471.Invoke_O__O(arg_1472) } else { tmp10 = linked_1470.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1469, arg_1472) }; seq_1657000188__14, chunk_1657000189__15, count_1657000190__16, i_1657000191__17 = tmp10, nil, 0, 0; continue L2 } } }; break L2 }; seq_1657000180__5, chunk_1657000181__6, count_1657000182__7, i_1657000183__8 = seq_1657000180__5, chunk_1657000181__6, count_1657000182__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000183__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1403 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = seq_1657000180__5; if linked_1404 == nil { temp__1927000414__auto____9 = ifn_1405.Invoke_O__O(arg_1406) } else { temp__1927000414__auto____9 = linked_1404.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1403, arg_1406) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1657000180__10 any = temp__1927000414__auto____9; var tmp11 any; var root_1407 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_1408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1407, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1409 lang.IFn; if linked_1408 == nil { ifn_1409 = lang.IFn_Cast(root_1407) } else { ifn_1409 = nil }; var arg_1410 any = seq_1657000180__10; if linked_1408 == nil { tmp11 = ifn_1409.Invoke_O__O(arg_1410) } else { tmp11 = linked_1408.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1407, arg_1410) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____11 any; var root_1411 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1413 lang.IFn; if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any = seq_1657000180__10; if linked_1412 == nil { c__1927000678__auto____11 = ifn_1413.Invoke_O__O(arg_1414) } else { c__1927000678__auto____11 = linked_1412.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1411, arg_1414) }; var tmp12 any; var root_1473 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = seq_1657000180__10; if linked_1474 == nil { tmp12 = ifn_1475.Invoke_O__O(arg_1476) } else { tmp12 = linked_1474.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1473, arg_1476) }; seq_1657000180__5, chunk_1657000181__6, count_1657000182__7, i_1657000183__8 = tmp12, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1657000203__11 any; var root_1415 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1415, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1417 lang.IFn; if linked_1416 == nil { ifn_1417 = lang.IFn_Cast(root_1415) } else { ifn_1417 = nil }; var arg_1418 any = seq_1657000180__10; if linked_1416 == nil { vec__1657000203__11 = ifn_1417.Invoke_O__O(arg_1418) } else { vec__1657000203__11 = linked_1416.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1415, arg_1418) }; var s__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000203__11, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1657000206__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000203__11, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1657000206__14 any; if lang.ISeq_InstanceOf(map__1657000206__13) { var tmp13 any; var root_1419 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1419, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1421 lang.IFn; if linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any = map__1657000206__13; if linked_1420 == nil { tmp13 = ifn_1421.Invoke_O__O(arg_1422) } else { tmp13 = linked_1420.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1419, arg_1422) }; if jrt.J2g_Truth(tmp13) { var tmp14 any; var root_1423 any = A_arbace_c_musl_A_const_136.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any = map__1657000206__13; if linked_1424 == nil { tmp14 = ifn_1425.Invoke_O__O(arg_1426) } else { tmp14 = linked_1424.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1423, arg_1426) }; map__1657000206__14 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp14)).Ref() } else { var tmp15 any; var root_1427 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = map__1657000206__13; if linked_1428 == nil { tmp15 = ifn_1429.Invoke_O__O(arg_1430) } else { tmp15 = linked_1428.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1427, arg_1430) }; if jrt.J2g_Truth(tmp15) { var root_1431 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = map__1657000206__13; if linked_1432 == nil { map__1657000206__14 = ifn_1433.Invoke_O__O(arg_1434) } else { map__1657000206__14 = linked_1432.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1431, arg_1434) } } else { map__1657000206__14 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1657000206__14 = map__1657000206__13 }; var defs__15 any = lang.RT_Get_O_O__O_NoInit(map__1657000206__14, A_arbace_c_musl_A_const_126); var seq_1657000184__16 any; var root_1477 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any = defs__15; if linked_1478 == nil { seq_1657000184__16 = ifn_1479.Invoke_O__O(arg_1480) } else { seq_1657000184__16 = linked_1478.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1477, arg_1480) }; var chunk_1657000185__17 any; var count_1657000186__18 int64 = 0; var i_1657000187__19 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000187__19, count_1657000186__18) { var vec__1657000208__20 any = lang.Indexed_Cast(chunk_1657000185__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000187__19)); var n__21_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000208__20, lang.RT_IntCast_J__I_NoInit(0), nil); var d__22_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000208__20, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp16 jrt.HashMap_I = jrt.HashMap_Cast(by__4); var tmp17 any; var root_1497 any = A_arbace_c_musl_A_const_10.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1499 lang.IFn

					if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any; var or__1927000174__auto____23_2 any = jrt.HashMap_Cast(by__4).Get_O__O(n__21_2); if jrt.J2g_Truth(or__1927000174__auto____23_2) { arg_1500 = or__1927000174__auto____23_2 } else { arg_1500 = lang.PersistentVector_EMPTY.Ref() }; var arg_1501 any = lang.Tuple_Create_O_O__IPersistentVector(s__12, A_arbace_c_musl_A_const_62.Invoke_O__O(d__22_2)); if linked_1498 == nil { tmp17 = ifn_1499.Invoke_O_O__O(arg_1500, arg_1501) } else { tmp17 = linked_1498.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1497, arg_1500, arg_1501) }; tmp16.Put_O_O__O(n__21_2, tmp17)
//line :221:1
					seq_1657000184__16, chunk_1657000185__17, count_1657000186__18, i_1657000187__19 = seq_1657000184__16, chunk_1657000185__17, count_1657000186__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000187__19); continue L3 } else { var temp__1927000414__auto____20 any; var root_1481 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1481, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1483 lang.IFn; if linked_1482 == nil { ifn_1483 = lang.IFn_Cast(root_1481) } else { ifn_1483 = nil }; var arg_1484 any = seq_1657000184__16; if linked_1482 == nil { temp__1927000414__auto____20 = ifn_1483.Invoke_O__O(arg_1484) } else { temp__1927000414__auto____20 = linked_1482.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1481, arg_1484) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1657000184__21 any = temp__1927000414__auto____20; var tmp18 any; var root_1485 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_1486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1485, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1487 lang.IFn; if linked_1486 == nil { ifn_1487 = lang.IFn_Cast(root_1485) } else { ifn_1487 = nil }; var arg_1488 any = seq_1657000184__21; if linked_1486 == nil { tmp18 = ifn_1487.Invoke_O__O(arg_1488) } else { tmp18 = linked_1486.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1485, arg_1488) }; if jrt.J2g_Truth(tmp18) { var c__1927000678__auto____22 any; var root_1489 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1489, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = seq_1657000184__21; if linked_1490 == nil { c__1927000678__auto____22 = ifn_1491.Invoke_O__O(arg_1492) } else { c__1927000678__auto____22 = linked_1490.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1489, arg_1492) }; var tmp19 any; var root_1502 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1502, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1504 lang.IFn; if linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = seq_1657000184__21; if linked_1503 == nil { tmp19 = ifn_1504.Invoke_O__O(arg_1505) } else { tmp19 = linked_1503.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1502, arg_1505) }; seq_1657000184__16, chunk_1657000185__17, count_1657000186__18, i_1657000187__19 = tmp19, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1657000211__22 any; var root_1493 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1494 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1493, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1495 lang.IFn; if linked_1494 == nil { ifn_1495 = lang.IFn_Cast(root_1493) } else { ifn_1495 = nil }; var arg_1496 any = seq_1657000184__21; if linked_1494 == nil { vec__1657000211__22 = ifn_1495.Invoke_O__O(arg_1496) } else { vec__1657000211__22 = linked_1494.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1493, arg_1496) }; var n__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000211__22, lang.RT_IntCast_J__I_NoInit(0), nil); var d__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000211__22, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp20 jrt.HashMap_I = jrt.HashMap_Cast(by__4); var tmp21 any; var root_1506 any = A_arbace_c_musl_A_const_10.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1506, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1508 lang.IFn

						if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any; var or__1927000174__auto____25 any = jrt.HashMap_Cast(by__4).Get_O__O(n__23); if jrt.J2g_Truth(or__1927000174__auto____25) { arg_1509 = or__1927000174__auto____25 } else { arg_1509 = lang.PersistentVector_EMPTY.Ref() }; var arg_1510 any = lang.Tuple_Create_O_O__IPersistentVector(s__12, A_arbace_c_musl_A_const_62.Invoke_O__O(d__24)); if linked_1507 == nil { tmp21 = ifn_1508.Invoke_O_O__O(arg_1509, arg_1510) } else { tmp21 = linked_1507.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1506, arg_1509, arg_1510) }; tmp20.Put_O_O__O(n__23, tmp21)
//line :221:1
						var tmp22 any; var root_1511 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1513 lang.IFn; if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = seq_1657000184__21; if linked_1512 == nil { tmp22 = ifn_1513.Invoke_O__O(arg_1514) } else { tmp22 = linked_1512.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1511, arg_1514) }; seq_1657000184__16, chunk_1657000185__17, count_1657000186__18, i_1657000187__19 = tmp22, nil, 0, 0; continue L3 } } }; break L3 }; var tmp23 any; var root_1515 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_1516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1515, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1517 lang.IFn; if linked_1516 == nil { ifn_1517 = lang.IFn_Cast(root_1515) } else { ifn_1517 = nil }; var arg_1518 any = seq_1657000180__10; if linked_1516 == nil { tmp23 = ifn_1517.Invoke_O__O(arg_1518) } else { tmp23 = linked_1516.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1515, arg_1518) }; seq_1657000180__5, chunk_1657000181__6, count_1657000182__7, i_1657000183__8 = tmp23, nil, 0, 0; continue L1 } } }
//line :216:1
		break L1 }; var tmp24 any = A_arbace_c_musl_A_const_131; var tmp25 any = A_arbace_c_musl_A_const_132; var tmp26 any = A_arbace_c_musl_A_const_133; var tmp27 any = A_arbace_c_musl_A_const_134; var tmp28 any = A_arbace_c_musl_A_const_135; var tmp29 any; var root_1379 any = A_arbace_c_musl_A_const_40.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1381 lang.IFn; if







	linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1380 == nil { tmp29 = ifn_1381.Invoke_O__O(arg_1382) } else { tmp29 = linked_1380.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1379, arg_1382) }; return /*line :216:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, root__1, tmp25, h__0, tmp26, ix__3, tmp27, by__4, tmp28, tmp29)) }













func A_arbace_c_musl_closure_A_New() *A_arbace_c_musl_closure_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_closure_A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_c_musl_closure_A) Ctor() {}
//line :230:1
func (t *A_arbace_c_musl_closure_A) Invoke_O_O_O_O__O(self, lib__0, prog_defs__1, prog_refs__2 any) any { var map__1657000215__4 any = lib__0; var map__1657000215__5 any; if



	lang.ISeq_InstanceOf(map__1657000215__4) { var tmp1 any; var root_1519 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_1520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1519, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1521 lang.IFn; if linked_1520 == nil { ifn_1521 = lang.IFn_Cast(root_1519) } else { ifn_1521 = nil }; var arg_1522 any = map__1657000215__4; if linked_1520 == nil { tmp1 = ifn_1521.Invoke_O__O(arg_1522) } else { tmp1 = linked_1520.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1519, arg_1522) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1523 any = A_arbace_c_musl_A_const_136.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1525 lang.IFn; if linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any = map__1657000215__4; if linked_1524 == nil { tmp2 = ifn_1525.Invoke_O__O(arg_1526) } else { tmp2 = linked_1524.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1523, arg_1526) }; map__1657000215__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1527 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1529 lang.IFn; if linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = map__1657000215__4; if linked_1528 == nil { tmp3 = ifn_1529.Invoke_O__O(arg_1530) } else { tmp3 = linked_1528.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1527, arg_1530) }; if jrt.J2g_Truth(tmp3) { var root_1531 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1531, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1533 lang.IFn; if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = map__1657000215__4; if linked_1532 == nil { map__1657000215__5 = ifn_1533.Invoke_O__O(arg_1534) } else { map__1657000215__5 = linked_1532.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1531, arg_1534) } } else { map__1657000215__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1657000215__5 = map__1657000215__4 }; var index__6 any = /*line :230:1*/lang.RT_Get_O_O__O_NoInit(map__1657000215__5, A_arbace_c_musl_A_const_133); var by_name__7 any = lang.RT_Get_O_O__O_NoInit(map__1657000215__5, A_arbace_c_musl_A_const_134); var defined__8 any = jrt.HashSet_New_Collection(jrt.Collection_Cast(prog_defs__1)); var linked__9 any = jrt.LinkedHashSet_New(); var q__10 any = jrt.ArrayDeque_New(); var seq_1657000217__11 any; var root_1539 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1541 lang.IFn; if







	linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any; var root_1543 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = A_arbace_c_musl_A_const_137.GetRawRoot__O(); var arg_1547 any = prog_refs__2; if linked_1544 == nil { arg_1542 = ifn_1545.Invoke_O_O__O(arg_1546, arg_1547) } else { arg_1542 = linked_1544.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1543, arg_1546, arg_1547) }; if linked_1540 == nil { seq_1657000217__11 = ifn_1541.Invoke_O__O(arg_1542) } else { seq_1657000217__11 = linked_1540.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1539, arg_1542) }; var chunk_1657000218__12 any; var count_1657000219__13 int64 = 0; var i_1657000220__14 int64 = 0; L1:
//line :230:1
	for {







		if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000220__14, count_1657000219__13) { var r__15 any = lang.Indexed_Cast(chunk_1657000218__12).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000220__14)); jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayDeque_Cast(q__10)).Add_O__Z(r__15)); seq_1657000217__11, chunk_1657000218__12, count_1657000219__13, i_1657000220__14 = seq_1657000217__11, chunk_1657000218__12, count_1657000219__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000220__14); continue L1 } else { var temp__1927000414__auto____15 any; var root_1548 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1550 lang.IFn; if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any = seq_1657000217__11; if linked_1549 == nil { temp__1927000414__auto____15 = ifn_1550.Invoke_O__O(arg_1551) } else { temp__1927000414__auto____15 = linked_1549.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1548, arg_1551) }; if jrt.J2g_Truth(temp__1927000414__auto____15) { var seq_1657000217__16 any = temp__1927000414__auto____15; var tmp4 any; var root_1552 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = seq_1657000217__16; if linked_1553 == nil { tmp4 = ifn_1554.Invoke_O__O(arg_1555) } else { tmp4 = linked_1553.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1552, arg_1555) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____17 any; var root_1556 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1556, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1558 lang.IFn; if linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any = seq_1657000217__16; if linked_1557 == nil { c__1927000678__auto____17 = ifn_1558.Invoke_O__O(arg_1559) } else { c__1927000678__auto____17 = linked_1557.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1556, arg_1559) }; var tmp5 any; var root_1568 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = seq_1657000217__16; if linked_1569 == nil { tmp5 = ifn_1570.Invoke_O__O(arg_1571) } else { tmp5 = linked_1569.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1568, arg_1571) }; seq_1657000217__11, chunk_1657000218__12, count_1657000219__13, i_1657000220__14 = tmp5, c__1927000678__auto____17, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var r__17 any; var root_1560 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1562 lang.IFn; if linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any = seq_1657000217__16; if linked_1561 == nil { r__17 = ifn_1562.Invoke_O__O(arg_1563) } else { r__17 = linked_1561.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1560, arg_1563) }; jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayDeque_Cast(q__10)).Add_O__Z(r__17)); var tmp6 any; var root_1572 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1574 lang.IFn; if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = seq_1657000217__16; if linked_1573 == nil { tmp6 = ifn_1574.Invoke_O__O(arg_1575) } else { tmp6 = linked_1573.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1572, arg_1575) }; seq_1657000217__11, chunk_1657000218__12, count_1657000219__13, i_1657000220__14 = tmp6, nil, 0, 0; continue L1 } } }
//line :230:1
		break L1 }; L2: for {








			var tmp7 any; var root_1564 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1564, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1566 lang.IFn; if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayDeque_Cast(q__10)).IsEmpty__Z()).Ref(); if linked_1565 == nil { tmp7 = ifn_1566.Invoke_O__O(arg_1567) } else { tmp7 = linked_1565.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1564, arg_1567) }; if jrt.J2g_Truth(tmp7) { var n__11 any = jrt.NN(jrt.ArrayDeque_Cast(q__10)).Poll__O()

				if jrt.HashSet_Cast(defined__8).Contains_O__Z(n__11) { } else { var temp__1927000414__auto____12 any = jrt.HashMap_Cast(by_name__7).Get_O__O(n__11)
					if jrt.J2g_Truth(temp__1927000414__auto____12) { var cands__13 any = temp__1927000414__auto____12; var vec__1657000221__14 any; var or__1927000174__auto____14 any; var root_1576 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1576, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1578 lang.IFn
						if linked_1577 == nil { ifn_1578 = lang.IFn_Cast(root_1576) } else { ifn_1578 = nil }; var arg_1579 any; var root_1580 any = A_arbace_c_musl_A_const_99.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1580, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1582 lang.IFn; if linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any = A_arbace_c_musl_A_const_55.GetRawRoot__O(); var arg_1584 any = cands__13; if linked_1581 == nil { arg_1579 = ifn_1582.Invoke_O_O__O(arg_1583, arg_1584) } else { arg_1579 = linked_1581.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1580, arg_1583, arg_1584) }; if linked_1577 == nil { or__1927000174__auto____14 = ifn_1578.Invoke_O__O(arg_1579) } else { or__1927000174__auto____14 = linked_1577.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1576, arg_1579) }; if jrt.J2g_Truth(or__1927000174__auto____14) { vec__1657000221__14 = or__1927000174__auto____14 } else { var root_1585 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = cands__13; if linked_1586 == nil { vec__1657000221__14 = ifn_1587.Invoke_O__O(arg_1588) } else { vec__1657000221__14 = linked_1586.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1585, arg_1588) } }
//line :242:1
						var s__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000221__14, lang.RT_IntCast_J__I_NoInit(0), nil); var ___16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000221__14, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___16

						if jrt.HashSet_Cast(linked__9).Add_O__Z(s__15) { var map__1657000224__17 any = lang.RT_Get_O_O__O_NoInit(index__6, s__15); var map__1657000224__18 any
							if lang.ISeq_InstanceOf(map__1657000224__17) { var tmp8 any; var root_1589 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1591 lang.IFn; if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any = map__1657000224__17; if linked_1590 == nil { tmp8 = ifn_1591.Invoke_O__O(arg_1592) } else { tmp8 = linked_1590.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1589, arg_1592) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_1593 any = A_arbace_c_musl_A_const_136.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1593, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = map__1657000224__17; if linked_1594 == nil { tmp9 = ifn_1595.Invoke_O__O(arg_1596) } else { tmp9 = linked_1594.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1593, arg_1596) }; map__1657000224__18 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp9)).Ref() } else { var tmp10 any; var root_1597 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = map__1657000224__17; if linked_1598 == nil { tmp10 = ifn_1599.Invoke_O__O(arg_1600) } else { tmp10 = linked_1598.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1597, arg_1600) }; if jrt.J2g_Truth(tmp10) { var root_1601 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1601, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1603 lang.IFn; if linked_1602 == nil { ifn_1603 = lang.IFn_Cast(root_1601) } else { ifn_1603 = nil }; var arg_1604 any = map__1657000224__17; if linked_1602 == nil { map__1657000224__18 = ifn_1603.Invoke_O__O(arg_1604) } else { map__1657000224__18 = linked_1602.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1601, arg_1604) } } else { map__1657000224__18 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1657000224__18 = map__1657000224__17 }
//line :244:1
							var defs__19 any = lang.RT_Get_O_O__O_NoInit(map__1657000224__18, A_arbace_c_musl_A_const_126); var refs__20 any = lang.RT_Get_O_O__O_NoInit(map__1657000224__18, A_arbace_c_musl_A_const_128); var seq_1657000226__21 any; var root_1625 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1625, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1627 lang.IFn

							if linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any; var root_1629 any = A_arbace_c_musl_A_const_96.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1629, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any = defs__19; if linked_1630 == nil { arg_1628 = ifn_1631.Invoke_O__O(arg_1632) } else { arg_1628 = linked_1630.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1629, arg_1632) }; if linked_1626 == nil { seq_1657000226__21 = ifn_1627.Invoke_O__O(arg_1628) } else { seq_1657000226__21 = linked_1626.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1625, arg_1628) }
//line :244:1
							var chunk_1657000227__22 any; var count_1657000228__23 int64 = 0; var i_1657000229__24 int64 = 0; L3: for {

								if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000229__24, count_1657000228__23) { var d__25 any = lang.Indexed_Cast(chunk_1657000227__22).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000229__24)); jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.HashSet_Cast(defined__8).Add_O__Z(d__25)); seq_1657000226__21, chunk_1657000227__22, count_1657000228__23, i_1657000229__24 = seq_1657000226__21, chunk_1657000227__22, count_1657000228__23, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000229__24); continue L3 } else { var temp__1927000414__auto____25 any; var root_1633 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1633, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1635 lang.IFn; if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any = seq_1657000226__21; if linked_1634 == nil { temp__1927000414__auto____25 = ifn_1635.Invoke_O__O(arg_1636) } else { temp__1927000414__auto____25 = linked_1634.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1633, arg_1636) }; if jrt.J2g_Truth(temp__1927000414__auto____25) { var seq_1657000226__26 any = temp__1927000414__auto____25; var tmp11 any; var root_1637 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_1638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1637, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1639 lang.IFn; if linked_1638 == nil { ifn_1639 = lang.IFn_Cast(root_1637) } else { ifn_1639 = nil }; var arg_1640 any = seq_1657000226__26; if linked_1638 == nil { tmp11 = ifn_1639.Invoke_O__O(arg_1640) } else { tmp11 = linked_1638.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1637, arg_1640) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____27 any; var root_1641 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1643 lang.IFn; if linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = seq_1657000226__26; if linked_1642 == nil { c__1927000678__auto____27 = ifn_1643.Invoke_O__O(arg_1644) } else { c__1927000678__auto____27 = linked_1642.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1641, arg_1644) }; var tmp12 any; var root_1649 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1651 lang.IFn; if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any = seq_1657000226__26; if linked_1650 == nil { tmp12 = ifn_1651.Invoke_O__O(arg_1652) } else { tmp12 = linked_1650.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1649, arg_1652) }; seq_1657000226__21, chunk_1657000227__22, count_1657000228__23, i_1657000229__24 = tmp12, c__1927000678__auto____27, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____27))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var d__27 any; var root_1645 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1645, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1647 lang.IFn; if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any = seq_1657000226__26; if linked_1646 == nil { d__27 = ifn_1647.Invoke_O__O(arg_1648) } else { d__27 = linked_1646.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1645, arg_1648) }; jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.HashSet_Cast(defined__8).Add_O__Z(d__27)); var tmp13 any; var root_1653 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1655 lang.IFn; if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any = seq_1657000226__26; if linked_1654 == nil { tmp13 = ifn_1655.Invoke_O__O(arg_1656) } else { tmp13 = linked_1654.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1653, arg_1656) }; seq_1657000226__21, chunk_1657000227__22, count_1657000228__23, i_1657000229__24 = tmp13, nil, 0, 0; continue L3 } } }
//line :244:1
								break L3 }; var seq_1657000230__21 any; var root_1605 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1607 lang.IFn


							if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any = refs__20; if linked_1606 == nil { seq_1657000230__21 = ifn_1607.Invoke_O__O(arg_1608) } else { seq_1657000230__21 = linked_1606.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1605, arg_1608) }
//line :244:1
							var chunk_1657000231__22 any; var count_1657000232__23 int64 = 0; var i_1657000233__24 int64 = 0; L4: for {


								if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000233__24, count_1657000232__23) { var r__25 any = lang.Indexed_Cast(chunk_1657000231__22).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000233__24)); if jrt.HashSet_Cast(defined__8).Contains_O__Z(r__25) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayDeque_Cast(q__10)).Add_O__Z(r__25)) }; seq_1657000230__21, chunk_1657000231__22, count_1657000232__23, i_1657000233__24 = seq_1657000230__21, chunk_1657000231__22, count_1657000232__23, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000233__24); continue L4 } else { var temp__1927000414__auto____25_2 any; var root_1609 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_1610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1609, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1611 lang.IFn; if linked_1610 == nil { ifn_1611 = lang.IFn_Cast(root_1609) } else { ifn_1611 = nil }; var arg_1612 any = seq_1657000230__21; if linked_1610 == nil { temp__1927000414__auto____25_2 = ifn_1611.Invoke_O__O(arg_1612) } else { temp__1927000414__auto____25_2 = linked_1610.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1609, arg_1612) }; if jrt.J2g_Truth(temp__1927000414__auto____25_2) { var seq_1657000230__26 any = temp__1927000414__auto____25_2; var tmp14 any; var root_1613 any = A_arbace_c_musl_A_const_29.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1613, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1615 lang.IFn; if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any = seq_1657000230__26; if linked_1614 == nil { tmp14 = ifn_1615.Invoke_O__O(arg_1616) } else { tmp14 = linked_1614.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1613, arg_1616) }; if jrt.J2g_Truth(tmp14) { var c__1927000678__auto____27_2 any; var root_1617 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1619 lang.IFn; if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = seq_1657000230__26; if linked_1618 == nil { c__1927000678__auto____27_2 = ifn_1619.Invoke_O__O(arg_1620) } else { c__1927000678__auto____27_2 = linked_1618.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1617, arg_1620) }; var tmp15 any; var root_1657 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1657, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any = seq_1657000230__26; if linked_1658 == nil { tmp15 = ifn_1659.Invoke_O__O(arg_1660) } else { tmp15 = linked_1658.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1657, arg_1660) }; seq_1657000230__21, chunk_1657000231__22, count_1657000232__23, i_1657000233__24 = tmp15, c__1927000678__auto____27_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____27_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var r__27 any; var root_1621 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1621, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1623 lang.IFn; if linked_1622 == nil { ifn_1623 = lang.IFn_Cast(root_1621) } else { ifn_1623 = nil }; var arg_1624 any = seq_1657000230__26; if linked_1622 == nil { r__27 = ifn_1623.Invoke_O__O(arg_1624) } else { r__27 = linked_1622.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1621, arg_1624) }; if jrt.HashSet_Cast(defined__8).Contains_O__Z(r__27) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayDeque_Cast(q__10)).Add_O__Z(r__27)) }; var tmp16 any; var root_1661 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_1662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1661, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1663 lang.IFn; if linked_1662 == nil { ifn_1663 = lang.IFn_Cast(root_1661) } else { ifn_1663 = nil }; var arg_1664 any = seq_1657000230__26; if linked_1662 == nil { tmp16 = ifn_1663.Invoke_O__O(arg_1664) } else { tmp16 = linked_1662.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1661, arg_1664) }; seq_1657000230__21, chunk_1657000231__22, count_1657000232__23, i_1657000233__24 = tmp16, nil, 0, 0; continue L4 } } }
//line :244:1
								break L4 } } } }
//line :239:1
				continue L2 }
//line :230:1
			break L2 }; var root_1535 any =

















	A_arbace_c_musl_A_const_22.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = linked__9; if linked_1536 == nil { return ifn_1537.Invoke_O__O(arg_1538) } else { return linked_1536.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1535, arg_1538) } }

func A_arbace_c_musl_checked_unit_A_New() *A_arbace_c_musl_checked_unit_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_checked_unit_A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_c_musl_checked_unit_A) Ctor() {}
//line :250:1
func (t *A_arbace_c_musl_checked_unit_A) Invoke_O_O_O__O(self, lib__0, src__1 any) any { var or__1927000174__auto____3 any; var tmp1 any; var root_1665 any = A_arbace_c_musl_A_const_8.GetRawRoot__O(); var linked_1666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1665, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1667 lang.IFn; if


	linked_1666 == nil { ifn_1667 = lang.IFn_Cast(root_1665) } else { ifn_1667 = nil }; var arg_1668 any = A_arbace_c_musl_A_const_135.Invoke_O__O(lib__0); if linked_1666 == nil { tmp1 = ifn_1667.Invoke_O__O(arg_1668) } else { tmp1 = linked_1666.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1665, arg_1668) }; or__1927000174__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp1, src__1); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var rd__4 any; var root_1669 any = A_arbace_c_musl_A_const_123.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1669, A_arbace_c_musl_load_unit_A_fn_class); var ifn_1671 lang.IFn
		if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any = A_arbace_c_musl_A_const_131.Invoke_O__O(lib__0); var arg_1673 any = src__1; if linked_1670 == nil { rd__4 = ifn_1671.Invoke_O_O__O(arg_1672, arg_1673) } else { rd__4 = linked_1670.(*A_arbace_c_musl_load_unit_A).Invoke_O_O_O__O(root_1669, arg_1672, arg_1673) }
//line :253:1
		var vec__1657000235__5 any; var root_1674 any = A_arbace_c_musl_A_const_82.GetRawRoot__O(); var linked_1675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1674, A_arbace_c_musl_config_A_fn_class); var ifn_1676 lang.IFn

		if linked_1675 == nil { ifn_1676 = lang.IFn_Cast(root_1674) } else { ifn_1676 = nil }; var arg_1677 any = A_arbace_c_musl_A_const_132.Invoke_O__O(lib__0); var arg_1678 any = A_arbace_c_musl_A_const_131.Invoke_O__O(lib__0); if linked_1675 == nil { vec__1657000235__5 = ifn_1676.Invoke_O_O__O(arg_1677, arg_1678) } else { vec__1657000235__5 = linked_1675.(*A_arbace_c_musl_config_A).Invoke_O_O_O__O(root_1674, arg_1677, arg_1678) }
//line :253:1
		var fc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000235__5, lang.RT_IntCast_J__I_NoInit(0), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000235__5, lang.RT_IntCast_J__I_NoInit(1), nil); var u__8 any; var root_1679 any = A_arbace_c_musl_A_const_16.GetRawRoot__O(); var linked_1680 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1679, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1681 lang.IFn; _ = ___7


		if linked_1680 == nil { ifn_1681 = lang.IFn_Cast(root_1679) } else { ifn_1681 = nil }; var arg_1682 any; var tmp2 any; var root_1685 any = A_arbace_c_musl_A_const_138.GetRawRoot__O(); var linked_1686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1685, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_1687 lang.IFn; if linked_1686 == nil { ifn_1687 = lang.IFn_Cast(root_1685) } else { ifn_1687 = nil }; var arg_1688 any = A_arbace_c_musl_A_const_139; if linked_1686 == nil { tmp2 = ifn_1687.Invoke_O__O(arg_1688) } else { tmp2 = linked_1686.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_1685, arg_1688) }; arg_1682 = lang.IFn_Cast(tmp2).Invoke_O_O_O__O(A_arbace_c_musl_A_const_132.Invoke_O__O(lib__0), fc__6, rd__4); var arg_1683 any = A_arbace_c_musl_A_const_140; var arg_1684 any = src__1; if linked_1680 == nil { u__8 = ifn_1681.Invoke_O_O_O__O(arg_1682, arg_1683, arg_1684) } else { u__8 = linked_1680.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1679, arg_1682, arg_1683, arg_1684) }
		var root_1689 any = A_arbace_c_musl_A_const_104.GetRawRoot__O(); var linked_1690 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1689, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1691 lang.IFn; if linked_1690 == nil { ifn_1691 = lang.IFn_Cast(root_1689) } else { ifn_1691 = nil }; var arg_1692 any = A_arbace_c_musl_A_const_135.Invoke_O__O(lib__0); var arg_1693 any = A_arbace_c_musl_A_const_16.GetRawRoot__O(); var arg_1694 any = src__1; var arg_1695 any = u__8; if linked_1690 == nil { ifn_1691.Invoke_O_O_O_O__O(arg_1692, arg_1693, arg_1694, arg_1695) } else { linked_1690.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1689, arg_1692, arg_1693, arg_1694, arg_1695) }
//line :253:1
		return u__8 } }






func A_arbace_c_musl_build_linked_A_New() *A_arbace_c_musl_build_linked_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_build_linked_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_c_musl_build_linked_A) Ctor() {}
//line :260:1
func (t *A_arbace_c_musl_build_linked_A) Invoke_O_O_O__O(self, lib__0, units__1 any) any { var pdefs__3 any; var root_1696 any = A_arbace_c_musl_A_const_53.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1698 lang.IFn; if


	linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_124.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__1714 any = A_arbace_c_musl_build_linked_fn__1657000243_A_New(); var tmp3 *jrt.Class; var fncls__1713 *jrt.Class = A_arbace_c_musl_build_linked_fn__1657000243_A_fn_class; if fncls__1713 == nil { var fncls__1713d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_c_musl_build_linked_fn__1657000243_A_fn_class = fncls__1713d; tmp3 = fncls__1713d } else { tmp3 = fncls__1713 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1714, tmp3, nil); arg_1699 = tmp1.Invoke_O_O__O(tmp2.Ref(), units__1); if linked_1697 == nil { pdefs__3 = ifn_1698.Invoke_O__O(arg_1699) } else { pdefs__3 = linked_1697.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1696, arg_1699) }; var prefs__4 any; var root_1715 any = /*line :260:1*/A_arbace_c_musl_A_const_53.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1717 lang.IFn; if



	linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_124.GetRawRoot__O()); var tmp5 *lang.Compiler_AOTFn; var fnbody__1743 any = A_arbace_c_musl_build_linked_fn__1657000245_A_New(); var tmp6 *jrt.Class; var fncls__1742 *jrt.Class = A_arbace_c_musl_build_linked_fn__1657000245_A_fn_class; if fncls__1742 == nil { var fncls__1742d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_c_musl_build_linked_fn__1657000245_A_fn_class = fncls__1742d; tmp6 = fncls__1742d } else { tmp6 = fncls__1742 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1743, tmp6, nil); arg_1718 = tmp4.Invoke_O_O__O(tmp5.Ref(), units__1); if linked_1716 == nil { prefs__4 = ifn_1717.Invoke_O__O(arg_1718) } else { prefs__4 = linked_1716.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1715, arg_1718) }; var prefs__5 any; var root_1744 any = /*line :260:1*/A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1746 lang.IFn; if





	linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = prefs__4; var arg_1748 any; var root_1749 any = A_arbace_c_musl_A_const_142.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any; var fnbody__1765 any = A_arbace_c_musl_build_linked_fn__1657000247_A_New(); var tmp7 *jrt.Class; var fncls__1764 *jrt.Class = A_arbace_c_musl_build_linked_fn__1657000247_A_fn_class; if fncls__1764 == nil { var fncls__1764d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); A_arbace_c_musl_build_linked_fn__1657000247_A_fn_class = fncls__1764d; tmp7 = fncls__1764d } else { tmp7 = fncls__1764 }; arg_1752 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1765, tmp7, nil); var arg_1753 any = prefs__4; if linked_1750 == nil { arg_1748 = ifn_1751.Invoke_O_O__O(arg_1752, arg_1753) } else { arg_1748 = linked_1750.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1749, arg_1752, arg_1753) }; if linked_1745 == nil { prefs__5 = ifn_1746.Invoke_O_O__O(arg_1747, arg_1748) } else { prefs__5 = linked_1745.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1744, arg_1747, arg_1748) }; var srcs__6 any; var root_1766 any = /*line :260:1*/A_arbace_c_musl_A_const_145.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, A_arbace_c_musl_closure_A_fn_class); var ifn_1768 lang.IFn; if






	linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = lib__0; var arg_1770 any = pdefs__3; var arg_1771 any = prefs__5; if linked_1767 == nil { srcs__6 = ifn_1768.Invoke_O_O_O__O(arg_1769, arg_1770, arg_1771) } else { srcs__6 = linked_1767.(*A_arbace_c_musl_closure_A).Invoke_O_O_O_O__O(root_1766, arg_1769, arg_1770, arg_1771) }; var ___7 any; _ = ___7; if
	jrt.System_Getenv_String__String(Lit_6) != nil { var root_1810 any = A_arbace_c_musl_A_const_110.GetRawRoot__O(); var linked_1811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1810, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1812 lang.IFn; if linked_1811 == nil { ifn_1812 = lang.IFn_Cast(root_1810) } else { ifn_1812 = nil }; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_111.GetRawRoot__O()); var tmp9 any = A_arbace_c_musl_A_const_112; var arg_1813 any = tmp8.Invoke_O_O__O(tmp9, A_arbace_c_musl_A_const_113.Get__O()); if linked_1811 == nil { ifn_1812.Invoke_O__O(arg_1813) } else { linked_1811.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1810, arg_1813) }; var tmp10 *lang.Compiler_AOTFn; var fnbody__1782 any = A_arbace_c_musl_build_linked_fn__1657000249_A_New_O(srcs__6); var tmp11 *jrt.Class; var fncls__1781 *jrt.Class = A_arbace_c_musl_build_linked_fn__1657000249_A_fn_class; if fncls__1781 == nil { var fncls__1781d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__1782); A_arbace_c_musl_build_linked_fn__1657000249_A_fn_class = fncls__1781d; tmp11 = fncls__1781d } else { tmp11 = fncls__1781 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1782, tmp11, nil); ___7 = Up_Compiler_AOTFn_IFn(tmp10).Invoke__O() } else { ___7 = nil }; var mus__8 any; var root_1783 any = /*line :260:1*/A_arbace_c_musl_A_const_146.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1785 lang.IFn; if








	linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any; var fnbody__1794 any = A_arbace_c_musl_build_linked_fn__1657000251_A_New_O(lib__0); var tmp12 *jrt.Class; var fncls__1793 *jrt.Class = A_arbace_c_musl_build_linked_fn__1657000251_A_fn_class; if fncls__1793 == nil { var fncls__1793d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__1794); A_arbace_c_musl_build_linked_fn__1657000251_A_fn_class = fncls__1793d; tmp12 = fncls__1793d } else { tmp12 = fncls__1793 }; arg_1786 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1794, tmp12, nil); var arg_1787 any = srcs__6; if linked_1784 == nil { mus__8 = ifn_1785.Invoke_O_O__O(arg_1786, arg_1787) } else { mus__8 = linked_1784.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1783, arg_1786, arg_1787) }; var tmp13 lang.IFn =
	lang.IFn_Cast(A_arbace_c_musl_A_const_148.GetRawRoot__O()); var tmp14 any; var root_1801 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_1802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1801, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1803 lang.IFn; if linked_1802 == nil { ifn_1803 = lang.IFn_Cast(root_1801) } else { ifn_1803 = nil }; var arg_1804 any; var root_1806 any = A_arbace_c_musl_A_const_22.GetRawRoot__O(); var linked_1807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1806, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1808 lang.IFn; if linked_1807 == nil { ifn_1808 = lang.IFn_Cast(root_1806) } else { ifn_1808 = nil }; var arg_1809 any = units__1; if linked_1807 == nil { arg_1804 = ifn_1808.Invoke_O__O(arg_1809) } else { arg_1804 = linked_1807.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1806, arg_1809) }; var arg_1805 any = mus__8; if linked_1802 == nil { tmp14 = ifn_1803.Invoke_O_O__O(arg_1804, arg_1805) } else { tmp14 = linked_1802.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1801, arg_1804, arg_1805) }; return tmp13.Invoke_O_O_O__O(tmp14, A_arbace_c_musl_A_const_149, jrt.Boolean_TRUE.Ref()) }
//line :263:1
func A_arbace_c_musl_build_linked_fn__1657000243_A_New() *A_arbace_c_musl_build_linked_fn__1657000243_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_build_linked_fn__1657000243_A{}; t.Ctor(); return t }
//line :263:1
func (t *A_arbace_c_musl_build_linked_fn__1657000243_A) Ctor() {}
//line :263:1
func (t *A_arbace_c_musl_build_linked_fn__1657000243_A) Invoke_O_O__O(self, p1__1657000239_SHARP___1 any) any { var root_1705 any = A_arbace_c_musl_A_const_96.GetRawRoot__O(); var linked_1706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1705, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1707 lang.IFn; if linked_1706 == nil { ifn_1707 = lang.IFn_Cast(root_1705) } else { ifn_1707 = nil }; var arg_1708 any; var root_1709 any = A_arbace_c_musl_A_const_127.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1709, A_arbace_c_musl_unit_defs_A_fn_class); var ifn_1711 lang.IFn; if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var tmp1 *lang.Keyword = A_arbace_c_musl_A_const_118; var arg_1712 any = tmp1.Invoke_O__O(A_arbace_c_musl_A_const_141.Invoke_O__O(p1__1657000239_SHARP___1)); if linked_1710 == nil { arg_1708 = ifn_1711.Invoke_O__O(arg_1712) } else { arg_1708 = linked_1710.(*A_arbace_c_musl_unit_defs_A).Invoke_O_O__O(root_1709, arg_1712) }; if linked_1706 == nil { return ifn_1707.Invoke_O__O(arg_1708) } else { return linked_1706.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1705, arg_1708) } }
func A_arbace_c_musl_build_linked_fn__1657000245_A_New() *A_arbace_c_musl_build_linked_fn__1657000245_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_build_linked_fn__1657000245_A{}; t.Ctor(); return t }
//line :264:1
func (t *A_arbace_c_musl_build_linked_fn__1657000245_A) Ctor() {}
//line :264:1
func (t *A_arbace_c_musl_build_linked_fn__1657000245_A) Invoke_O_O__O(self, p1__1657000240_SHARP___1 any) any { var root_1724 any = A_arbace_c_musl_A_const_129.GetRawRoot__O(); var linked_1725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1724, A_arbace_c_musl_refs_A_fn_class); var ifn_1726 lang.IFn; if linked_1725 == nil { ifn_1726 = lang.IFn_Cast(root_1724) } else { ifn_1726 = nil }; var arg_1727 any; var root_1728 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1728, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1730 lang.IFn; if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var tmp1 *lang.Keyword = A_arbace_c_musl_A_const_118; var arg_1731 any = tmp1.Invoke_O__O(A_arbace_c_musl_A_const_141.Invoke_O__O(p1__1657000240_SHARP___1)); var arg_1732 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_124.GetRawRoot__O()); var tmp3 any = A_arbace_c_musl_A_const_118; var tmp4 any; var root_1738 any = A_arbace_c_musl_A_const_125.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1740 lang.IFn; if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var tmp5 *lang.Keyword = A_arbace_c_musl_A_const_97; var arg_1741 any = tmp5.Invoke_O__O(A_arbace_c_musl_A_const_141.Invoke_O__O(p1__1657000240_SHARP___1)); if linked_1739 == nil { tmp4 = ifn_1740.Invoke_O__O(arg_1741) } else { tmp4 = linked_1739.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1738, arg_1741) }; arg_1732 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_1729 == nil { arg_1727 = ifn_1730.Invoke_O_O__O(arg_1731, arg_1732) } else { arg_1727 = linked_1729.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1728, arg_1731, arg_1732) }; if linked_1725 == nil { return ifn_1726.Invoke_O__O(arg_1727) } else { return linked_1725.(*A_arbace_c_musl_refs_A).Invoke_O_O__O(root_1724, arg_1727) } }

func A_arbace_c_musl_build_linked_fn__1657000247_A_New() *A_arbace_c_musl_build_linked_fn__1657000247_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_build_linked_fn__1657000247_A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_c_musl_build_linked_fn__1657000247_A) Ctor() {}
//line :266:1
func (t *A_arbace_c_musl_build_linked_fn__1657000247_A) Invoke_O_O__O(self, p1__1657000241_SHARP___1 any) any { var tmp1 any; var root_1754 any = A_arbace_c_musl_A_const_143.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1754, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = p1__1657000241_SHARP___1; var arg_1758 any = Lit_9; if linked_1755 == nil { tmp1 = ifn_1756.Invoke_O_O__O(arg_1757, arg_1758) } else { tmp1 = linked_1755.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1754, arg_1757, arg_1758) }; if jrt.J2g_Truth(tmp1) { var root_1759 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1759, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1761 lang.IFn; if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any = p1__1657000241_SHARP___1; var arg_1763 any = A_arbace_c_musl_A_const_144; if linked_1760 == nil { return ifn_1761.Invoke_O_O__O(arg_1762, arg_1763) } else { return linked_1760.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1759, arg_1762, arg_1763) } } else { return nil } }

func A_arbace_c_musl_build_linked_fn__1657000249_A_New_O(p0 any) *A_arbace_c_musl_build_linked_fn__1657000249_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_build_linked_fn__1657000249_A{}; t.Ctor_O(p0); return t }
//line :268:1
func (t *A_arbace_c_musl_build_linked_fn__1657000249_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :268:1
func (t *A_arbace_c_musl_build_linked_fn__1657000249_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_108.GetRawRoot__O()); var tmp3 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(t.F_srcs)).Ref(); var tmp4 any; var t_ any = t.F_srcs; t.F_srcs = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O_O_O__O(Lit_10, tmp3, tmp4) }; return nil }(); var root_1778 any = A_arbace_c_musl_A_const_109.GetRawRoot__O(); var linked_1779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1778, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1780 lang.IFn; if linked_1779 == nil { ifn_1780 = lang.IFn_Cast(root_1778) } else { ifn_1780 = nil }; if linked_1779 == nil { ifn_1780.Invoke__O() } else { linked_1779.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1778) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }
func A_arbace_c_musl_build_linked_fn__1657000251_A_New_O(p0 any) *A_arbace_c_musl_build_linked_fn__1657000251_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_build_linked_fn__1657000251_A{}; t.Ctor_O(p0); return t }
//line :269:1
func (t *A_arbace_c_musl_build_linked_fn__1657000251_A) Ctor_O(c__lib any) { t.F_lib = c__lib }
//line :269:1
func (t *A_arbace_c_musl_build_linked_fn__1657000251_A) Invoke_O_O__O(self, p1__1657000242_SHARP___1 any) any { var root_1788 any = A_arbace_c_musl_A_const_147.GetRawRoot__O(); var linked_1789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1788, A_arbace_c_musl_checked_unit_A_fn_class); var ifn_1790 lang.IFn; if linked_1789 == nil { ifn_1790 = lang.IFn_Cast(root_1788) } else { ifn_1790 = nil }; var arg_1791 any = t.F_lib; var arg_1792 any = p1__1657000242_SHARP___1; if linked_1789 == nil { return ifn_1790.Invoke_O_O__O(arg_1791, arg_1792) } else { return linked_1789.(*A_arbace_c_musl_checked_unit_A).Invoke_O_O_O__O(root_1788, arg_1791, arg_1792) } }


































































type A_arbace_c_musl_A struct{ jrt.Object }

var A_arbace_c_musl_A_const_pool *jrt.RefArray

var A_arbace_c_musl_A_const_0 *lang.Var

var A_arbace_c_musl_A_const_1 any

var A_arbace_c_musl_A_const_2 *lang.Var

var A_arbace_c_musl_A_const_3 any

var A_arbace_c_musl_A_const_4 any

var A_arbace_c_musl_A_const_5 any

var A_arbace_c_musl_A_const_6 any

var A_arbace_c_musl_A_const_7 *lang.Var

var A_arbace_c_musl_A_const_8 *lang.Var

var A_arbace_c_musl_A_const_9 *lang.Var

var A_arbace_c_musl_A_const_10 *lang.Var

var A_arbace_c_musl_A_const_11 any

var A_arbace_c_musl_A_const_12 *lang.Var

var A_arbace_c_musl_A_const_13 *lang.Var

var A_arbace_c_musl_A_const_14 *lang.Var

var A_arbace_c_musl_A_const_15 *lang.Var

var A_arbace_c_musl_A_const_16 *lang.Var

var A_arbace_c_musl_A_const_17 *lang.Var

var A_arbace_c_musl_A_const_18 *lang.Keyword

var A_arbace_c_musl_A_const_19 *lang.Keyword

var A_arbace_c_musl_A_const_20 *lang.Keyword

var A_arbace_c_musl_A_const_21 *lang.Keyword

var A_arbace_c_musl_A_const_22 *lang.Var

var A_arbace_c_musl_A_const_23 *lang.Var

var A_arbace_c_musl_A_const_24 *lang.Var

var A_arbace_c_musl_A_const_25 *lang.Var

var A_arbace_c_musl_A_const_26 *lang.Var

var A_arbace_c_musl_A_const_27 *lang.Var

var A_arbace_c_musl_A_const_28 *lang.Var

var A_arbace_c_musl_A_const_29 *lang.Var

var A_arbace_c_musl_A_const_30 *lang.Var

var A_arbace_c_musl_A_const_31 *lang.Var

var A_arbace_c_musl_A_const_32 *lang.Var

var A_arbace_c_musl_A_const_33 *lang.Var

var A_arbace_c_musl_A_const_34 *lang.Var

var A_arbace_c_musl_A_const_35 *lang.Var

var A_arbace_c_musl_A_const_36 *lang.Var

var A_arbace_c_musl_A_const_37 *lang.Var

var A_arbace_c_musl_A_const_38 *lang.Var

var A_arbace_c_musl_A_const_39 *lang.Var

var A_arbace_c_musl_A_const_40 *lang.Var

var A_arbace_c_musl_A_const_41 *lang.Var

var A_arbace_c_musl_A_const_42 *lang.Var

var A_arbace_c_musl_A_const_43 *lang.Var

var A_arbace_c_musl_A_const_44 any

var A_arbace_c_musl_A_const_45 *lang.Var

var A_arbace_c_musl_A_const_46 *lang.Var

var A_arbace_c_musl_A_const_47 *lang.Keyword

var A_arbace_c_musl_A_const_48 any

var A_arbace_c_musl_A_const_49 *lang.Var

var A_arbace_c_musl_A_const_50 *lang.Var

var A_arbace_c_musl_A_const_51 *lang.Var

var A_arbace_c_musl_A_const_52 any

var A_arbace_c_musl_A_const_53 *lang.Var

var A_arbace_c_musl_A_const_54 any

var A_arbace_c_musl_A_const_55 *lang.Var

var A_arbace_c_musl_A_const_56 *lang.Var

var A_arbace_c_musl_A_const_57 any

var A_arbace_c_musl_A_const_58 *lang.Var

var A_arbace_c_musl_A_const_59 *lang.Var

var A_arbace_c_musl_A_const_60 *lang.Var

var A_arbace_c_musl_A_const_61 *lang.Keyword

var A_arbace_c_musl_A_const_62 *lang.Keyword

var A_arbace_c_musl_A_const_63 *lang.Keyword

var A_arbace_c_musl_A_const_64 any

var A_arbace_c_musl_A_const_65 any

var A_arbace_c_musl_A_const_66 *lang.Keyword

var A_arbace_c_musl_A_const_67 *lang.Keyword

var A_arbace_c_musl_A_const_68 *lang.Keyword

var A_arbace_c_musl_A_const_69 *lang.Keyword

var A_arbace_c_musl_A_const_70 any

var A_arbace_c_musl_A_const_71 *lang.Var

var A_arbace_c_musl_A_const_72 any

var A_arbace_c_musl_A_const_73 any

var A_arbace_c_musl_A_const_74 any

var A_arbace_c_musl_A_const_75 *lang.Var

var A_arbace_c_musl_A_const_76 any

var A_arbace_c_musl_A_const_77 any

var A_arbace_c_musl_A_const_78 any

var A_arbace_c_musl_A_const_79 any

var A_arbace_c_musl_A_const_80 any

var A_arbace_c_musl_A_const_81 *lang.Var

var A_arbace_c_musl_A_const_82 *lang.Var

var A_arbace_c_musl_A_const_83 *lang.Var

var A_arbace_c_musl_A_const_84 *lang.Keyword

var A_arbace_c_musl_A_const_85 *lang.Keyword

var A_arbace_c_musl_A_const_86 *lang.Var

var A_arbace_c_musl_A_const_87 *lang.Keyword

var A_arbace_c_musl_A_const_88 *lang.Var

var A_arbace_c_musl_A_const_89 *lang.Var

var A_arbace_c_musl_A_const_90 *lang.Keyword

var A_arbace_c_musl_A_const_91 *lang.Var

var A_arbace_c_musl_A_const_92 *lang.Var

var A_arbace_c_musl_A_const_93 *lang.Var

var A_arbace_c_musl_A_const_94 *lang.Var

var A_arbace_c_musl_A_const_95 *lang.Var

var A_arbace_c_musl_A_const_96 *lang.Var

var A_arbace_c_musl_A_const_97 *lang.Keyword

var A_arbace_c_musl_A_const_98 *lang.Var

var A_arbace_c_musl_A_const_99 *lang.Var

var A_arbace_c_musl_A_const_100 any

var A_arbace_c_musl_A_const_101 *lang.Var

var A_arbace_c_musl_A_const_102 *lang.Var

var A_arbace_c_musl_A_const_103 *lang.Var

var A_arbace_c_musl_A_const_104 *lang.Var

var A_arbace_c_musl_A_const_105 *lang.Var

var A_arbace_c_musl_A_const_106 *lang.Var

var A_arbace_c_musl_A_const_107 any

var A_arbace_c_musl_A_const_108 *lang.Var

var A_arbace_c_musl_A_const_109 *lang.Var

var A_arbace_c_musl_A_const_110 *lang.Var

var A_arbace_c_musl_A_const_111 *lang.Var

var A_arbace_c_musl_A_const_112 *lang.Var

var A_arbace_c_musl_A_const_113 *lang.Var

var A_arbace_c_musl_A_const_114 *lang.Var

var A_arbace_c_musl_A_const_115 *lang.Var

var A_arbace_c_musl_A_const_116 *lang.Var

var A_arbace_c_musl_A_const_117 *lang.Var

var A_arbace_c_musl_A_const_118 *lang.Keyword

var A_arbace_c_musl_A_const_119 any

var A_arbace_c_musl_A_const_120 *lang.Var

var A_arbace_c_musl_A_const_121 *lang.Keyword

var A_arbace_c_musl_A_const_122 *lang.Var

var A_arbace_c_musl_A_const_123 *lang.Var

var A_arbace_c_musl_A_const_124 *lang.Var

var A_arbace_c_musl_A_const_125 *lang.Var

var A_arbace_c_musl_A_const_126 *lang.Keyword

var A_arbace_c_musl_A_const_127 *lang.Var

var A_arbace_c_musl_A_const_128 *lang.Keyword

var A_arbace_c_musl_A_const_129 *lang.Var

var A_arbace_c_musl_A_const_130 *lang.Var

var A_arbace_c_musl_A_const_131 *lang.Keyword

var A_arbace_c_musl_A_const_132 *lang.Keyword

var A_arbace_c_musl_A_const_133 *lang.Keyword

var A_arbace_c_musl_A_const_134 *lang.Keyword

var A_arbace_c_musl_A_const_135 *lang.Keyword

var A_arbace_c_musl_A_const_136 *lang.Var

var A_arbace_c_musl_A_const_137 *lang.Var

var A_arbace_c_musl_A_const_138 *lang.Var

var A_arbace_c_musl_A_const_139 any

var A_arbace_c_musl_A_const_140 *lang.Keyword

var A_arbace_c_musl_A_const_141 *lang.Keyword

var A_arbace_c_musl_A_const_142 *lang.Var

var A_arbace_c_musl_A_const_143 *lang.Var

var A_arbace_c_musl_A_const_144 any

var A_arbace_c_musl_A_const_145 *lang.Var

var A_arbace_c_musl_A_const_146 *lang.Var

var A_arbace_c_musl_A_const_147 *lang.Var

var A_arbace_c_musl_A_const_148 *lang.Var

var A_arbace_c_musl_A_const_149 *lang.Keyword

var A_arbace_c_musl_A_init jrt.ClassInit

func A_arbace_c_musl_A_Init() { if !A_arbace_c_musl_A_init.Done() { A_arbace_c_musl_A_init.Run(A_arbace_c_musl_A_clinit) } }

func A_arbace_c_musl_A_clinit() { A_arbace_c_musl_A_clinit_p0(); A_arbace_c_musl_A_clinit_p1(); A_arbace_c_musl_A_clinit_p2(); A_arbace_c_musl_A_clinit_p3(); A_arbace_c_musl_A_clinit_p4(); A_arbace_c_musl_A_clinit_p5(); A_arbace_c_musl_A_clinit_p6(); A_arbace_c_musl_A_clinit_p7(); A_arbace_c_musl_A_clinit_p8(); A_arbace_c_musl_A_clinit_p9(); A_arbace_c_musl_A_clinit_p10(); A_arbace_c_musl_A_clinit_p11(); A_arbace_c_musl_A_clinit_p12() }

func A_arbace_c_musl_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_musl_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 204); A_arbace_c_musl_A_const_0 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[54]); A_arbace_c_musl_A_const_1 = A_arbace_c_musl_A_const_pool.A[55]; A_arbace_c_musl_A_const_2 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[56]); A_arbace_c_musl_A_const_3 = A_arbace_c_musl_A_const_pool.A[57]; A_arbace_c_musl_A_const_4 = A_arbace_c_musl_A_const_pool.A[58]; A_arbace_c_musl_A_const_5 = A_arbace_c_musl_A_const_pool.A[59]; A_arbace_c_musl_A_const_6 = A_arbace_c_musl_A_const_pool.A[60]; A_arbace_c_musl_A_const_7 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[61]); A_arbace_c_musl_A_const_8 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[62]); A_arbace_c_musl_A_const_9 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[63]); A_arbace_c_musl_A_const_10 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[64]); A_arbace_c_musl_A_const_11 = A_arbace_c_musl_A_const_pool.A[65] }

func A_arbace_c_musl_A_clinit_p1() { A_arbace_c_musl_A_const_12 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[66]); A_arbace_c_musl_A_const_13 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[67]); A_arbace_c_musl_A_const_14 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[68]); A_arbace_c_musl_A_const_15 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[69]); A_arbace_c_musl_A_const_16 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[70]); A_arbace_c_musl_A_const_17 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[71]); A_arbace_c_musl_A_const_18 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[72]); A_arbace_c_musl_A_const_19 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[73]); A_arbace_c_musl_A_const_20 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[74]); A_arbace_c_musl_A_const_21 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[75]); A_arbace_c_musl_A_const_22 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[76]); A_arbace_c_musl_A_const_23 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[77]) }

func A_arbace_c_musl_A_clinit_p2() { A_arbace_c_musl_A_const_24 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[78]); A_arbace_c_musl_A_const_25 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[79]); A_arbace_c_musl_A_const_26 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[80]); A_arbace_c_musl_A_const_27 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[81]); A_arbace_c_musl_A_const_28 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[82]); A_arbace_c_musl_A_const_29 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[83]); A_arbace_c_musl_A_const_30 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[84]); A_arbace_c_musl_A_const_31 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[85]); A_arbace_c_musl_A_const_32 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[86]); A_arbace_c_musl_A_const_33 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[87]); A_arbace_c_musl_A_const_34 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[88]); A_arbace_c_musl_A_const_35 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[89]) }

func A_arbace_c_musl_A_clinit_p3() { A_arbace_c_musl_A_const_36 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[90]); A_arbace_c_musl_A_const_37 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[91]); A_arbace_c_musl_A_const_38 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[92]); A_arbace_c_musl_A_const_39 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[93]); A_arbace_c_musl_A_const_40 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[94]); A_arbace_c_musl_A_const_41 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[95]); A_arbace_c_musl_A_const_42 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[96]); A_arbace_c_musl_A_const_43 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[97]); A_arbace_c_musl_A_const_44 = A_arbace_c_musl_A_const_pool.A[98]; A_arbace_c_musl_A_const_45 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[99]); A_arbace_c_musl_A_const_46 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[100]); A_arbace_c_musl_A_const_47 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[101]) }

func A_arbace_c_musl_A_clinit_p4() { A_arbace_c_musl_A_const_48 = A_arbace_c_musl_A_const_pool.A[102]; A_arbace_c_musl_A_const_49 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[103]); A_arbace_c_musl_A_const_50 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[104]); A_arbace_c_musl_A_const_51 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[105]); A_arbace_c_musl_A_const_52 = A_arbace_c_musl_A_const_pool.A[106]; A_arbace_c_musl_A_const_53 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[107]); A_arbace_c_musl_A_const_54 = A_arbace_c_musl_A_const_pool.A[108]; A_arbace_c_musl_A_const_55 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[109]); A_arbace_c_musl_A_const_56 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[110]); A_arbace_c_musl_A_const_57 = A_arbace_c_musl_A_const_pool.A[111]; A_arbace_c_musl_A_const_58 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[112]); A_arbace_c_musl_A_const_59 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[113]); A_arbace_c_musl_A_const_60 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[114]) }

func A_arbace_c_musl_A_clinit_p5() { A_arbace_c_musl_A_const_61 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[115]); A_arbace_c_musl_A_const_62 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[116]); A_arbace_c_musl_A_const_63 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[117]); A_arbace_c_musl_A_const_64 = A_arbace_c_musl_A_const_pool.A[118]; A_arbace_c_musl_A_const_65 = A_arbace_c_musl_A_const_pool.A[119]; A_arbace_c_musl_A_const_66 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[120]); A_arbace_c_musl_A_const_67 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[121]); A_arbace_c_musl_A_const_68 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[122]); A_arbace_c_musl_A_const_69 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[123]); A_arbace_c_musl_A_const_70 = A_arbace_c_musl_A_const_pool.A[124]; A_arbace_c_musl_A_const_71 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[125]); A_arbace_c_musl_A_const_72 = A_arbace_c_musl_A_const_pool.A[126]; A_arbace_c_musl_A_const_73 = A_arbace_c_musl_A_const_pool.A[127] }

func A_arbace_c_musl_A_clinit_p6() { A_arbace_c_musl_A_const_74 = A_arbace_c_musl_A_const_pool.A[128]; A_arbace_c_musl_A_const_75 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[129]); A_arbace_c_musl_A_const_76 = A_arbace_c_musl_A_const_pool.A[130]; A_arbace_c_musl_A_const_77 = A_arbace_c_musl_A_const_pool.A[131]; A_arbace_c_musl_A_const_78 = A_arbace_c_musl_A_const_pool.A[132]; A_arbace_c_musl_A_const_79 = A_arbace_c_musl_A_const_pool.A[133]; A_arbace_c_musl_A_const_80 = A_arbace_c_musl_A_const_pool.A[134]; A_arbace_c_musl_A_const_81 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[135]); A_arbace_c_musl_A_const_82 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[136]); A_arbace_c_musl_A_const_83 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[137]); A_arbace_c_musl_A_const_84 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[138]); A_arbace_c_musl_A_const_85 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[139]); A_arbace_c_musl_A_const_86 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[140]) }

func A_arbace_c_musl_A_clinit_p7() { A_arbace_c_musl_A_const_87 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[141]); A_arbace_c_musl_A_const_88 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[142]); A_arbace_c_musl_A_const_89 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[143]); A_arbace_c_musl_A_const_90 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[144]); A_arbace_c_musl_A_const_91 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[145]); A_arbace_c_musl_A_const_92 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[146]); A_arbace_c_musl_A_const_93 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[147]); A_arbace_c_musl_A_const_94 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[148]); A_arbace_c_musl_A_const_95 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[149]); A_arbace_c_musl_A_const_96 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[150]); A_arbace_c_musl_A_const_97 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[151]); A_arbace_c_musl_A_const_98 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[152]) }

func A_arbace_c_musl_A_clinit_p8() { A_arbace_c_musl_A_const_99 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[153]); A_arbace_c_musl_A_const_100 = A_arbace_c_musl_A_const_pool.A[154]; A_arbace_c_musl_A_const_101 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[155]); A_arbace_c_musl_A_const_102 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[156]); A_arbace_c_musl_A_const_103 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[157]); A_arbace_c_musl_A_const_104 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[158]); A_arbace_c_musl_A_const_105 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[159]); A_arbace_c_musl_A_const_106 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[160]); A_arbace_c_musl_A_const_107 = A_arbace_c_musl_A_const_pool.A[161]; A_arbace_c_musl_A_const_108 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[162]); A_arbace_c_musl_A_const_109 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[163]); A_arbace_c_musl_A_const_110 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[164]) }

func A_arbace_c_musl_A_clinit_p9() { A_arbace_c_musl_A_const_111 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[165]); A_arbace_c_musl_A_const_112 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[166]); A_arbace_c_musl_A_const_113 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[167]); A_arbace_c_musl_A_const_114 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[168]); A_arbace_c_musl_A_const_115 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[169]); A_arbace_c_musl_A_const_116 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[170]); A_arbace_c_musl_A_const_117 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[171]); A_arbace_c_musl_A_const_118 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[172]); A_arbace_c_musl_A_const_119 = A_arbace_c_musl_A_const_pool.A[173]; A_arbace_c_musl_A_const_120 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[174]); A_arbace_c_musl_A_const_121 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[175]); A_arbace_c_musl_A_const_122 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[176]) }

func A_arbace_c_musl_A_clinit_p10() { A_arbace_c_musl_A_const_123 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[177]); A_arbace_c_musl_A_const_124 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[178]); A_arbace_c_musl_A_const_125 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[179]); A_arbace_c_musl_A_const_126 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[180]); A_arbace_c_musl_A_const_127 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[181]); A_arbace_c_musl_A_const_128 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[182]); A_arbace_c_musl_A_const_129 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[183]); A_arbace_c_musl_A_const_130 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[184]); A_arbace_c_musl_A_const_131 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[185]); A_arbace_c_musl_A_const_132 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[186]); A_arbace_c_musl_A_const_133 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[187]); A_arbace_c_musl_A_const_134 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[188]) }

func A_arbace_c_musl_A_clinit_p11() { A_arbace_c_musl_A_const_135 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[189]); A_arbace_c_musl_A_const_136 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[190]); A_arbace_c_musl_A_const_137 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[191]); A_arbace_c_musl_A_const_138 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[192]); A_arbace_c_musl_A_const_139 = A_arbace_c_musl_A_const_pool.A[193]; A_arbace_c_musl_A_const_140 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[194]); A_arbace_c_musl_A_const_141 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[195]); A_arbace_c_musl_A_const_142 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[196]); A_arbace_c_musl_A_const_143 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[197]); A_arbace_c_musl_A_const_144 = A_arbace_c_musl_A_const_pool.A[198]; A_arbace_c_musl_A_const_145 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[199]); A_arbace_c_musl_A_const_146 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[200]) }

func A_arbace_c_musl_A_clinit_p12() { A_arbace_c_musl_A_const_147 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[201]); A_arbace_c_musl_A_const_148 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[202]); A_arbace_c_musl_A_const_149 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[203]) }

func A_arbace_c_musl_A_New() *A_arbace_c_musl_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_A{}; t.Ctor(); return t }

func (t *A_arbace_c_musl_A) Ctor() {}

func (t *A_arbace_c_musl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_musl_A) GetClass__Class() *jrt.Class { return A_arbace_c_musl_A_class }

func (t *A_arbace_c_musl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_musl_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_musl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_musl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_musl_A); return ok }

func A_arbace_c_musl_A_Cast(x any) *A_arbace_c_musl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_musl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_musl_A_class)) }; return v }



type A_arbace_c_musl_attr_names_A struct{ j2g_header uint64 }

var A_arbace_c_musl_attr_names_A_fn_class *jrt.Class



type A_arbace_c_musl_attr_names_walk__1657000035_A struct{ j2g_header uint64; F_names, F_alias any }

var A_arbace_c_musl_attr_names_walk__1657000035_A_fn_class *jrt.Class



type A_arbace_c_musl_build_linked_A struct{ j2g_header uint64 }

var A_arbace_c_musl_build_linked_A_fn_class *jrt.Class



type A_arbace_c_musl_build_linked_fn__1657000243_A struct{ j2g_header uint64 }

var A_arbace_c_musl_build_linked_fn__1657000243_A_fn_class *jrt.Class



type A_arbace_c_musl_build_linked_fn__1657000245_A struct{ j2g_header uint64 }

var A_arbace_c_musl_build_linked_fn__1657000245_A_fn_class *jrt.Class



type A_arbace_c_musl_build_linked_fn__1657000247_A struct{ j2g_header uint64 }

var A_arbace_c_musl_build_linked_fn__1657000247_A_fn_class *jrt.Class



type A_arbace_c_musl_build_linked_fn__1657000249_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_c_musl_build_linked_fn__1657000249_A_fn_class *jrt.Class



type A_arbace_c_musl_build_linked_fn__1657000251_A struct{ j2g_header uint64; F_lib any }

var A_arbace_c_musl_build_linked_fn__1657000251_A_fn_class *jrt.Class



type A_arbace_c_musl_checked_unit_A struct{ j2g_header uint64 }

var A_arbace_c_musl_checked_unit_A_fn_class *jrt.Class



type A_arbace_c_musl_closure_A struct{ j2g_header uint64 }

var A_arbace_c_musl_closure_A_fn_class *jrt.Class



type A_arbace_c_musl_config_A struct{ j2g_header uint64 }

var A_arbace_c_musl_config_A_fn_class *jrt.Class



type A_arbace_c_musl_env_A struct{ j2g_header uint64 }

var A_arbace_c_musl_env_A_fn_class *jrt.Class



type A_arbace_c_musl_eval1657000004_A struct{ jrt.Object }

func A_arbace_c_musl_eval1657000004_A_New() *A_arbace_c_musl_eval1657000004_A { t := &A_arbace_c_musl_eval1657000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c_musl_eval1657000004_A) Ctor() {}

func (t *A_arbace_c_musl_eval1657000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_musl_eval1657000004_A) GetClass__Class() *jrt.Class { return A_arbace_c_musl_eval1657000004_A_class }

func (t *A_arbace_c_musl_eval1657000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_musl_eval1657000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_musl_eval1657000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_musl_eval1657000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_musl_eval1657000004_A); return ok }

func A_arbace_c_musl_eval1657000004_A_Cast(x any) *A_arbace_c_musl_eval1657000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_musl_eval1657000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_musl_eval1657000004_A_class)) }; return v }



type A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A struct{ j2g_header uint64 }

var A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A_fn_class *jrt.Class



type A_arbace_c_musl_eval1657000008_A struct{ jrt.Object }

func A_arbace_c_musl_eval1657000008_A_New() *A_arbace_c_musl_eval1657000008_A { t := &A_arbace_c_musl_eval1657000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c_musl_eval1657000008_A) Ctor() {}

func (t *A_arbace_c_musl_eval1657000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_musl_eval1657000008_A) GetClass__Class() *jrt.Class { return A_arbace_c_musl_eval1657000008_A_class }

func (t *A_arbace_c_musl_eval1657000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_musl_eval1657000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_musl_eval1657000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_musl_eval1657000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_musl_eval1657000008_A); return ok }

func A_arbace_c_musl_eval1657000008_A_Cast(x any) *A_arbace_c_musl_eval1657000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_musl_eval1657000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_musl_eval1657000008_A_class)) }; return v }



type A_arbace_c_musl_eval1657000008_fn__1657000009_A struct{ j2g_header uint64 }

var A_arbace_c_musl_eval1657000008_fn__1657000009_A_fn_class *jrt.Class



type A_arbace_c_musl_forms_root_A struct{ j2g_header uint64 }

var A_arbace_c_musl_forms_root_A_fn_class *jrt.Class



type A_arbace_c_musl_index_A struct{ j2g_header uint64 }

var A_arbace_c_musl_index_A_fn_class *jrt.Class



type A_arbace_c_musl_index_iter__1657000169__1657000173_A struct{ j2g_header uint64; F_root any }

var A_arbace_c_musl_index_iter__1657000169__1657000173_A_fn_class *jrt.Class



type A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A struct{ j2g_header uint64; F_root, F_iter__1657000169, F_s__1657000170 any }

var A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A_fn_class *jrt.Class



type A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_fn__1657000175_A struct{ j2g_header uint64; F_root any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1657000172 any }

var A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_fn__1657000175_A_fn_class *jrt.Class



type A_arbace_c_musl_library_A struct{ j2g_header uint64 }

var A_arbace_c_musl_library_A_fn_class *jrt.Class



type A_arbace_c_musl_load_unit_A struct{ j2g_header uint64 }

var A_arbace_c_musl_load_unit_A_fn_class *jrt.Class



type A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A struct{ j2g_header uint64; F_fr any }

var A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A_fn_class *jrt.Class



type A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A struct{ j2g_header uint64; F_fr, F_s__1657000153, F_iter__1657000152 any }

var A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A_fn_class *jrt.Class



type A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_fn__1657000158_A struct{ j2g_header uint64; F_b__1657000155, F_fr any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_fn__1657000158_A_fn_class *jrt.Class



type A_arbace_c_musl_musl_root_A struct{ j2g_header uint64 }

var A_arbace_c_musl_musl_root_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_A struct{ j2g_header uint64 }

var A_arbace_c_musl_read_all_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_fn__1657000120_A struct{ j2g_header uint64; F_fr any }

var A_arbace_c_musl_read_all_fn__1657000120_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000122__1657000126_A struct{ j2g_header uint64; F_todo, F_root, F_n, F_h, F_errs, F_q any }

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A struct{ j2g_header uint64; F_todo, F_root, F_iter__1657000122, F_n, F_h, F_errs, F_q, F_s__1657000123 any }

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A struct{ j2g_header uint64; F_todo, F_root, F_n, F_h, F_errs, F_b__1657000125, F_q any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A struct{ j2g_header uint64; F_todo, F_root, F_n, F_h, F_errs, F_q any }

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000130_A struct{ j2g_header uint64; F_root, F_h, F_s any }

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000130_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000132_A struct{ j2g_header uint64; F_todo, F_k any }

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000132_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A struct{ j2g_header uint64; F_todo, F_root, F_n, F_h, F_errs, F_q any }

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000137_A struct{ j2g_header uint64; F_root, F_h, F_s any }

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000137_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000139_A struct{ j2g_header uint64; F_todo, F_k any }

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000139_A_fn_class *jrt.Class



type A_arbace_c_musl_read_one_A struct{ j2g_header uint64 }

var A_arbace_c_musl_read_one_A_fn_class *jrt.Class



type A_arbace_c_musl_refs_A struct{ j2g_header uint64 }

var A_arbace_c_musl_refs_A_fn_class *jrt.Class



type A_arbace_c_musl_refs_decl__1657000081_A struct{ j2g_header uint64; F_walk, F_walk_meta any }

var A_arbace_c_musl_refs_decl__1657000081_A_fn_class *jrt.Class



type A_arbace_c_musl_refs_walk__1657000075_A struct{ j2g_header uint64; F_acc any }

var A_arbace_c_musl_refs_walk__1657000075_A_fn_class *jrt.Class



type A_arbace_c_musl_refs_walk_meta__1657000094_A struct{ j2g_header uint64; F_acc any }

var A_arbace_c_musl_refs_walk_meta__1657000094_A_fn_class *jrt.Class



type A_arbace_c_musl_sources_A struct{ j2g_header uint64 }

var A_arbace_c_musl_sources_A_fn_class *jrt.Class



type A_arbace_c_musl_sources_iter__1657000018__1657000024_A struct{ j2g_header uint64; F_m any }

var A_arbace_c_musl_sources_iter__1657000018__1657000024_A_fn_class *jrt.Class



type A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A struct{ j2g_header uint64; F_s__1657000019, F_iter__1657000018, F_m any }

var A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A_fn_class *jrt.Class



type A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A struct{ j2g_header uint64; F_rel any }

var A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A_fn_class *jrt.Class



type A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A struct{ j2g_header uint64; F_rel, F_s__1657000021, F_iter__1657000020 any }

var A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A_fn_class *jrt.Class



type A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A struct{ j2g_header uint64; F_b__1657000023, F_rel any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A_fn_class *jrt.Class



type A_arbace_c_musl_spit_mk_A struct{ j2g_header uint64 }

var A_arbace_c_musl_spit_mk_A_fn_class *jrt.Class



type A_arbace_c_musl_sym_name_A struct{ j2g_header uint64 }

var A_arbace_c_musl_sym_name_A_fn_class *jrt.Class



type A_arbace_c_musl_unit_defs_A struct{ j2g_header uint64 }

var A_arbace_c_musl_unit_defs_A_fn_class *jrt.Class



type A_arbace_c_musl_unit_defs_decl__1657000054_A struct{ j2g_header uint64; F_out any }

var A_arbace_c_musl_unit_defs_decl__1657000054_A_fn_class *jrt.Class
