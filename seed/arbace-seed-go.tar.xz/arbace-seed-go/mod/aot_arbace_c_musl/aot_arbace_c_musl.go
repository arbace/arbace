//line aot_arbace_c_musl.ae:1
package aot_arbace_c_musl

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_c"
	"arbace/aot_arbace_repr_c_host"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A_New() *A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c_musl_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c_musl_A_const_1); lang.IFn_Cast(A_arbace_c_musl_A_const_2.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_c_musl_A_const_3, A_arbace_c_musl_A_const_4, A_arbace_c_musl_A_const_5, A_arbace_c_musl_A_const_6, A_arbace_c_musl_A_const_7); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_33)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_34)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_35)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_36)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c_musl_eval1657000008_fn__1657000009_A_New() *A_arbace_c_musl_eval1657000008_fn__1657000009_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_eval1657000008_fn__1657000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c_musl_eval1657000008_fn__1657000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c_musl_eval1657000008_fn__1657000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_8.GetRawRoot__O()); var tmp2 any; var root_19 any = A_arbace_c_musl_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_c_musl_A_const_10; if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_19, arg_22) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c_musl_A_const_11.GetRawRoot__O(), A_arbace_c_musl_A_const_12) }






















func A_arbace_c_musl_env_A_New() *A_arbace_c_musl_env_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_env_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_c_musl_env_A) Ctor() {}
//line :24:1
func (t *A_arbace_c_musl_env_A) Invoke_O_O_O__O(self, k__0, d__1 any) any { var or__1927000174__auto____3 any = jrt.System_Getenv_String__String(jrt.String_Cast(k__0)).Ref(); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return d__1 } }

func A_arbace_c_musl_musl_root_A_New() *A_arbace_c_musl_musl_root_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_musl_root_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_c_musl_musl_root_A) Ctor() {}
//line :26:1
func (t *A_arbace_c_musl_musl_root_A) Invoke_O_O__O(self, root__0 any) any { var root_23 any = A_arbace_c_musl_A_const_13.GetRawRoot__O(); var linked_24 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_23, A_arbace_c_musl_env_A_fn_class); var ifn_25 lang.IFn; if linked_24 == nil { ifn_25 = lang.IFn_Cast(root_23) } else { ifn_25 = nil }; var arg_26 any = Lit_52; var arg_27 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_53), jrt.RefArrayOf(jrt.Object_class, root__0, nil)).Ref(); if linked_24 == nil { return ifn_25.Invoke_O_O__O(arg_26, arg_27) } else { return linked_24.(*A_arbace_c_musl_env_A).Invoke_O_O_O__O(root_23, arg_26, arg_27) } }
func A_arbace_c_musl_forms_root_A_New() *A_arbace_c_musl_forms_root_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_forms_root_A{}; t.Ctor(); return t }
//line :27:1
func (t *A_arbace_c_musl_forms_root_A) Ctor() {}
//line :27:1
func (t *A_arbace_c_musl_forms_root_A) Invoke_O_O__O(self, root__0 any) any { var root_28 any = A_arbace_c_musl_A_const_13.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, A_arbace_c_musl_env_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = Lit_37; var arg_32 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, root__0, nil)).Ref(); if linked_29 == nil { return ifn_30.Invoke_O_O__O(arg_31, arg_32) } else { return linked_29.(*A_arbace_c_musl_env_A).Invoke_O_O_O__O(root_28, arg_31, arg_32) } }



func A_arbace_c_musl_config_A_New() *A_arbace_c_musl_config_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_config_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_c_musl_config_A) Ctor() {}
//line :31:1
func (t *A_arbace_c_musl_config_A) Invoke_O_O_O__O(self, h__0, root__1 any) any { var m__3 any; var root_33 any = A_arbace_c_musl_A_const_14.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, A_arbace_c_musl_musl_root_A_fn_class); var ifn_35 lang.IFn; if


	linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = root__1; if linked_34 == nil { m__3 = ifn_35.Invoke_O__O(arg_36) } else { m__3 = linked_34.(*A_arbace_c_musl_musl_root_A).Invoke_O_O__O(root_33, arg_36) }; var fc__4 any; var root_37 any = /*line :31:1*/A_arbace_c_musl_A_const_15.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A_fn_class); var ifn_39 lang.IFn; if



	linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any = A_arbace_c_musl_A_const_16.GetRawRoot__O(); var arg_41 any = Lit_11; if linked_38 == nil { fc__4 = ifn_39.Invoke_O_O__O(arg_40, arg_41) } else { fc__4 = linked_38.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_file_config_A).Invoke_O_O_O__O(root_37, arg_40, arg_41) }; var tmp1 lang.IFn = /*line :31:1*/lang.IFn_Cast(A_arbace_c_musl_A_const_17.GetRawRoot__O()); var tmp2 any; var root_54 any = A_arbace_c_musl_A_const_18.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A_fn_class); var ifn_56 lang.IFn; if




	linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = h__0; var arg_58 any = fc__4; var arg_59 any = m__3; if linked_55 == nil { tmp2 = ifn_56.Invoke_O_O_O__O(arg_57, arg_58, arg_59) } else { tmp2 = linked_55.(*aot_arbace_repr_c_host.A_arbace_repr_c_host_config_A).Invoke_O_O_O_O__O(root_54, arg_57, arg_58, arg_59) }; var tmp3 any = tmp2; var tmp4 any = A_arbace_c_musl_A_const_19; var tmp5 any = /*line :31:1*/lang.PersistentVector_EMPTY.Ref(); var tmp6 any = A_arbace_c_musl_A_const_20; var tmp7 any = lang.RT_Vector_O1__IPersistentVector_NoInit(jrt.RefArrayOf(jrt.Object_class, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_12), jrt.RefArrayOf(jrt.Object_class, root__1, nil)).Ref(), Lit_13, Lit_14, Lit_15, Lit_16, Lit_17, Lit_18, Lit_19)); var tmp8 any = A_arbace_c_musl_A_const_21; return lang.Tuple_Create_O_O__IPersistentVector(fc__4, tmp1.Invoke_O_O_O_O_O_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_20), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.NN(jrt.String_Cast(lang.RT_Get_O_O__O_NoInit(A_arbace_c_musl_A_const_21.Invoke_O__O(h__0), Lit_11))).Replace_CharSequence_CharSequence__String(Lit_21, Lit_22)).Replace_CharSequence_CharSequence__String(Lit_23, Lit_24)).Replace_CharSequence_CharSequence__String(Lit_25, Lit_26)).Replace_CharSequence_CharSequence__String(Lit_27, Lit_28)).Replace_CharSequence_CharSequence__String(Lit_29, Lit_30)).Replace_CharSequence_CharSequence__String(Lit_31, Lit_32).Ref(), nil)).Ref(), A_arbace_c_musl_A_const_22, jrt.Boolean_FALSE.Ref())) }































func A_arbace_c_musl_sources_A_New() *A_arbace_c_musl_sources_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sources_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_c_musl_sources_A) Ctor() {}
//line :63:1
func (t *A_arbace_c_musl_sources_A) Invoke_O_O__O(self, root__0 any) any { var m__2 any; var tmp1 any; var root_60 any = A_arbace_c_musl_A_const_14.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, A_arbace_c_musl_musl_root_A_fn_class); var ifn_62 lang.IFn; if



	linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = root__0; if linked_61 == nil { tmp1 = ifn_62.Invoke_O__O(arg_63) } else { tmp1 = linked_61.(*A_arbace_c_musl_musl_root_A).Invoke_O_O__O(root_60, arg_63) }; m__2 = /*line :63:1*/jrt.File_New_String(jrt.String_Cast(tmp1)); var src__3 any = jrt.File_New_File_String(jrt.File_Cast(m__2), Lit_73); var root_64 any = A_arbace_c_musl_A_const_23.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_66 lang.IFn; if





	linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var root_68 any = A_arbace_c_musl_A_const_24.GetRawRoot__O(); var linked_69 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_68, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_70 lang.IFn; if linked_69 == nil { ifn_70 = lang.IFn_Cast(root_68) } else { ifn_70 = nil }; var arg_71 any; var iter__1927001039__auto____4 any; var fnbody__195 any = A_arbace_c_musl_sources_iter__1657000018__1657000024_A_New_O(m__2); var tmp2 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_c_musl_sources_iter__1657000018__1657000024_A_fn_class; if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, fnbody__195); A_arbace_c_musl_sources_iter__1657000018__1657000024_A_fn_class = fncls__194d; tmp2 = fncls__194d } else { tmp2 = fncls__194 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__195, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp4 any; var root_196 any = A_arbace_c_musl_A_const_40.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = jrt.File_Cast(src__3).ListFiles__File1().Ref(); var arg_200 any = lang.Tuple_Create_O__IPersistentVector(jrt.File_New_File_String(jrt.File_Cast(src__3), Lit_75)); if linked_197 == nil { tmp4 = ifn_198.Invoke_O_O__O(arg_199, arg_200) } else { tmp4 = linked_197.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_196, arg_199, arg_200) }; arg_71 = tmp3.Invoke_O__O(tmp4); if linked_69 == nil { arg_67 = ifn_70.Invoke_O__O(arg_71) } else { arg_67 = linked_69.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_68, arg_71) }; if linked_65 == nil { return ifn_66.Invoke_O__O(arg_67) } else { return linked_65.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_64, arg_67) } }
//line :69:1
func A_arbace_c_musl_sources_iter__1657000018__1657000024_A_New_O(p0 any) *A_arbace_c_musl_sources_iter__1657000018__1657000024_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sources_iter__1657000018__1657000024_A{}; t.Ctor_O(p0); return t }
//line :69:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :69:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_A) Invoke_O_O__O(self, s__1657000019__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__193 any = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A_New_O_O_O(s__1657000019__1, self, t.F_m); var tmp2 *jrt.Class; var fncls__192 *jrt.Class = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A_fn_class; if fncls__192 == nil { var fncls__192d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__193); A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A_fn_class = fncls__192d; tmp2 = fncls__192d } else { tmp2 = fncls__192 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__193, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :69:1
func A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :69:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A) Ctor_O_O_O(c__s__1657000019, c__iter__1657000018, c__m any) { t.F_s__1657000019 = c__s__1657000019; t.F_iter__1657000018 = c__iter__1657000018; t.F_m = c__m }
//line :69:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A) Invoke_O__O(self any) any { { var s__1657000019__1 any; var t_ any = t.F_s__1657000019; t.F_s__1657000019 = nil; s__1657000019__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_72 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = s__1657000019__1; if linked_73 == nil { temp__1927000414__auto____2 = ifn_74.Invoke_O__O(arg_75) } else { temp__1927000414__auto____2 = linked_73.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_72, arg_75) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var d__4 any; var root_76 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any = xs__1927001018__auto____3; if linked_77 == nil { d__4 = ifn_78.Invoke_O__O(arg_79) } else { d__4 = linked_77.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_76, arg_79) }; if jrt.File_Cast(d__4).IsDirectory__Z() { var rel__5 any; var root_80 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_82 lang.IFn

	if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = jrt.File_Cast(d__4).GetPath__String().Ref(); var arg_84 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(jrt.File_Cast(t.F_m).GetPath__String().Ref())))).Ref(); if linked_81 == nil { rel__5 = ifn_82.Invoke_O_O__O(arg_83, arg_84) } else { rel__5 = linked_81.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_80, arg_83, arg_84) }
//line :69:1
	var tmp1 any; var root_85 any = A_arbace_c_musl_A_const_28.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_87 lang.IFn


	if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = lang.IFn_Cast(A_arbace_c_musl_A_const_29.GetRawRoot__O()).Invoke_O__O(rel__5); if linked_86 == nil { tmp1 = ifn_87.Invoke_O__O(arg_88) } else { tmp1 = linked_86.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_85, arg_88) }
//line :69:1
	if jrt.J2g_Truth(tmp1) { var iterys__1927001035__auto____6 any; var fnbody__166 any = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A_New_O(rel__5); var tmp2 *jrt.Class; var fncls__165 *jrt.Class = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A_fn_class; if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, fnbody__166); A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A_fn_class = fncls__165d; tmp2 = fncls__165d } else { tmp2 = fncls__165 }; iterys__1927001035__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__166, tmp2, nil); var fs__1927001036__auto____7 any; var root_167 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = lang.IFn_Cast(iterys__1927001035__auto____6).Invoke_O__O(jrt.File_Cast(d__4).ListFiles__File1().Ref()); if linked_168 == nil { fs__1927001036__auto____7 = ifn_169.Invoke_O__O(arg_170) } else { fs__1927001036__auto____7 = linked_168.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_167, arg_170) }; if jrt.J2g_Truth(fs__1927001036__auto____7) { var root_171 any = A_arbace_c_musl_A_const_40.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = fs__1927001036__auto____7; var arg_175 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1657000018); var tmp4 any; var root_176 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = s__1657000019__1; if linked_177 == nil { tmp4 = ifn_178.Invoke_O__O(arg_179) } else { tmp4 = linked_177.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_176, arg_179) }; arg_175 = tmp3.Invoke_O__O(tmp4); if linked_172 == nil { return ifn_173.Invoke_O_O__O(arg_174, arg_175) } else { return linked_172.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_171, arg_174, arg_175) } } else { var tmp5 any; var root_180 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = s__1657000019__1; if linked_181 == nil { tmp5 = ifn_182.Invoke_O__O(arg_183) } else { tmp5 = linked_181.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_180, arg_183) }; s__1657000019__1 = tmp5; continue L1 } } else { var tmp6 any; var root_184 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = s__1657000019__1; if linked_185 == nil { tmp6 = ifn_186.Invoke_O__O(arg_187) } else { tmp6 = linked_185.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_184, arg_187) }; s__1657000019__1 = tmp6; continue L1 } } else { var tmp7 any; var root_188 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = s__1657000019__1; if linked_189 == nil { tmp7 = ifn_190.Invoke_O__O(arg_191) } else { tmp7 = linked_189.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_188, arg_191) }; s__1657000019__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :69:1
func A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A_New_O(p0 any) *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A{}; t.Ctor_O(p0); return t }
//line :69:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A) Ctor_O(c__rel any) { t.F_rel = c__rel }
//line :69:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A) Invoke_O_O__O(self, s__1657000021__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__164 any = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A_New_O_O_O(t.F_rel, s__1657000021__1, self); var tmp2 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, fnbody__164); A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A_fn_class = fncls__163d; tmp2 = fncls__163d } else { tmp2 = fncls__163 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__164, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :69:1
func A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :69:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A) Ctor_O_O_O(c__rel, c__s__1657000021, c__iter__1657000020 any) { t.F_rel = c__rel; t.F_s__1657000021 = c__s__1657000021; t.F_iter__1657000020 = c__iter__1657000020 }
//line :69:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A) Invoke_O__O(self any) any { { var s__1657000021__1 any; var t_ any = t.F_s__1657000021; t.F_s__1657000021 = nil; s__1657000021__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_89 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = s__1657000021__1; if linked_90 == nil { temp__1927000414__auto____2 = ifn_91.Invoke_O__O(arg_92) } else { temp__1927000414__auto____2 = linked_90.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_89, arg_92) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1657000021__3 any = temp__1927000414__auto____2; var tmp1 any; var root_93 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = s__1657000021__3; if linked_94 == nil { tmp1 = ifn_95.Invoke_O__O(arg_96) } else { tmp1 = linked_94.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_93, arg_96) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_97 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = s__1657000021__3; if linked_98 == nil { c__1927001037__auto____4 = ifn_99.Invoke_O__O(arg_100) } else { c__1927001037__auto____4 = linked_98.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_97, arg_100) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1657000023__6 any; var root_101 any = A_arbace_c_musl_A_const_32.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_102 == nil { b__1657000023__6 = ifn_103.Invoke_O__O(arg_104) } else { b__1657000023__6 = linked_102.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_101, arg_104) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__115 any = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A_New_O_O_I_O(b__1657000023__6, t.F_rel, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__115); A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A_fn_class = fncls__114d; tmp3 = fncls__114d } else { tmp3 = fncls__114 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__115, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_116 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any; var root_121 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = b__1657000023__6; if linked_122 == nil { arg_119 = ifn_123.Invoke_O__O(arg_124) } else { arg_119 = linked_122.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_121, arg_124) }; var arg_120 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1657000020); var tmp5 any; var root_125 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = s__1657000021__3; if linked_126 == nil { tmp5 = ifn_127.Invoke_O__O(arg_128) } else { tmp5 = linked_126.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_125, arg_128) }; arg_120 = tmp4.Invoke_O__O(tmp5); if linked_117 == nil { return ifn_118.Invoke_O_O__O(arg_119, arg_120) } else { return linked_117.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_116, arg_119, arg_120) } } else { var root_129 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any; var root_134 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = b__1657000023__6; if linked_135 == nil { arg_132 = ifn_136.Invoke_O__O(arg_137) } else { arg_132 = linked_135.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_134, arg_137) }; var arg_133 any; if linked_130 == nil { return ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { return linked_130.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_129, arg_132, arg_133) } } } else { var f__4 any; var root_138 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = s__1657000021__3; if linked_139 == nil { f__4 = ifn_140.Invoke_O__O(arg_141) } else { f__4 = linked_139.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_138, arg_141) }; var tmp6 bool; var and__1927000168__auto____5 bool = jrt.File_Cast(f__4).IsFile__Z()




	if and__1927000168__auto____5 { tmp6 = jrt.NN(jrt.File_Cast(f__4).GetName__String()).EndsWith_String__Z(Lit_80) } else { tmp6 = and__1927000168__auto____5 }
//line :69:1
	if tmp6 { var tmp7 any = t.F_rel; var p__5 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil), jrt.RefArrayOf(jrt.Object_class, tmp7, nil, jrt.File_Cast(f__4).GetName__String().Ref())).Ref(); var tmp8 any; var root_142 any = A_arbace_c_musl_A_const_28.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_144 lang.IFn






		if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = lang.IFn_Cast(A_arbace_c_musl_A_const_33.GetRawRoot__O()).Invoke_O__O(p__5); if linked_143 == nil { tmp8 = ifn_144.Invoke_O__O(arg_145) } else { tmp8 = linked_143.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_142, arg_145) }
//line :69:1
		if jrt.J2g_Truth(tmp8) { var root_146 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = p__5; var arg_150 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1657000020); var tmp10 any; var root_151 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = s__1657000021__3; if linked_152 == nil { tmp10 = ifn_153.Invoke_O__O(arg_154) } else { tmp10 = linked_152.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_151, arg_154) }; arg_150 = tmp9.Invoke_O__O(tmp10); if linked_147 == nil { return ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { return linked_147.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) } } else { var tmp11 any; var root_155 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = s__1657000021__3; if linked_156 == nil { tmp11 = ifn_157.Invoke_O__O(arg_158) } else { tmp11 = linked_156.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_155, arg_158) }; s__1657000021__1 = tmp11; continue L1 } } else { var tmp12 any; var root_159 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = s__1657000021__3; if linked_160 == nil { tmp12 = ifn_161.Invoke_O__O(arg_162) } else { tmp12 = linked_160.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_159, arg_162) }; s__1657000021__1 = tmp12; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :69:1
func A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :69:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A) Ctor_O_O_I_O(c__b__1657000023, c__rel any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1657000023 = c__b__1657000023; t.F_rel = c__rel; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :69:1
func (t *A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A) Invoke_O__O(self any) any { { var i__1657000022__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1657000022__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1657000022__1)); var tmp2 bool; var and__1927000168__auto____3 bool = jrt.File_Cast(f__2).IsFile__Z()




	if and__1927000168__auto____3 { tmp2 = jrt.NN(jrt.File_Cast(f__2).GetName__String()).EndsWith_String__Z(Lit_80) } else { tmp2 = and__1927000168__auto____3 }
//line :69:1
	if tmp2 { var tmp3 any = t.F_rel; var p__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil), jrt.RefArrayOf(jrt.Object_class, tmp3, nil, jrt.File_Cast(f__2).GetName__String().Ref())).Ref(); var tmp4 any; var root_105 any = A_arbace_c_musl_A_const_28.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_107 lang.IFn






		if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = lang.IFn_Cast(A_arbace_c_musl_A_const_33.GetRawRoot__O()).Invoke_O__O(p__3); if linked_106 == nil { tmp4 = ifn_107.Invoke_O__O(arg_108) } else { tmp4 = linked_106.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_105, arg_108) }
//line :69:1
		if jrt.J2g_Truth(tmp4) { var root_109 any = A_arbace_c_musl_A_const_34.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = t.F_b__1657000023; var arg_113 any = p__3; if linked_110 == nil { ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { linked_110.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) }; i__1657000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000022__1); continue L1 } else { i__1657000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000022__1); continue L1 } } else { i__1657000022__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000022__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_c_musl_attr_names_A_New() *A_arbace_c_musl_attr_names_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_attr_names_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_c_musl_attr_names_A) Ctor() {}
//line :82:1
func (t *A_arbace_c_musl_attr_names_A) Invoke_O_O__O(self, m__0 any) any { var names__2 any = jrt.HashSet_New(); var alias__3 any; var root_201 any = A_arbace_c_musl_A_const_41.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_203 lang.IFn; if


	linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any; if linked_202 == nil { alias__3 = ifn_203.Invoke_O__O(arg_204) } else { alias__3 = linked_202.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_201, arg_204) }; var body_walk__4 /*line :82:1*/*A_arbace_c_musl_attr_names_walk__1657000035_A = A_arbace_c_musl_attr_names_walk__1657000035_A_New_O_O(names__2, alias__3); var walk__4 any; var fnbody__301 any = any(body_walk__4); var tmp1 *jrt.Class; var fncls__300 *jrt.Class = A_arbace_c_musl_attr_names_walk__1657000035_A_fn_class; if fncls__300 == nil { var fncls__300d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, fnbody__301); A_arbace_c_musl_attr_names_walk__1657000035_A_fn_class = fncls__300d; tmp1 = fncls__300d } else { tmp1 = fncls__300 }; walk__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__301, tmp1, nil); var seq_1657000048__5 any; var root_302 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_304 lang.IFn; if











	linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = A_arbace_c_musl_A_const_53; if linked_303 == nil { seq_1657000048__5 = ifn_304.Invoke_O__O(arg_305) } else { seq_1657000048__5 = linked_303.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_302, arg_305) }; var chunk_1657000049__6 any; var count_1657000050__7 int64 = 0; var i_1657000051__8 int64 = 0; L1:
//line :82:1
	for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000051__8, count_1657000050__7) { var k__9 any = lang.Indexed_Cast(chunk_1657000049__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000051__8))
			lang.IFn_Cast(walk__4).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(m__0, k__9))
//line :94:1
			seq_1657000048__5, chunk_1657000049__6, count_1657000050__7, i_1657000051__8 = seq_1657000048__5, chunk_1657000049__6, count_1657000050__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000051__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_306 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_308 lang.IFn; if linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any = seq_1657000048__5; if linked_307 == nil { temp__1927000414__auto____9 = ifn_308.Invoke_O__O(arg_309) } else { temp__1927000414__auto____9 = linked_307.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_306, arg_309) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1657000048__10 any = temp__1927000414__auto____9; var tmp2 any; var root_310 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_310, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_312 lang.IFn; if linked_311 == nil { ifn_312 = lang.IFn_Cast(root_310) } else { ifn_312 = nil }; var arg_313 any = seq_1657000048__10; if linked_311 == nil { tmp2 = ifn_312.Invoke_O__O(arg_313) } else { tmp2 = linked_311.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_310, arg_313) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____11 any; var root_314 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = seq_1657000048__10; if linked_315 == nil { c__1927000678__auto____11 = ifn_316.Invoke_O__O(arg_317) } else { c__1927000678__auto____11 = linked_315.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_314, arg_317) }; var tmp3 any; var root_322 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_324 lang.IFn; if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = seq_1657000048__10; if linked_323 == nil { tmp3 = ifn_324.Invoke_O__O(arg_325) } else { tmp3 = linked_323.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_322, arg_325) }; seq_1657000048__5, chunk_1657000049__6, count_1657000050__7, i_1657000051__8 = tmp3, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var k__11 any; var root_318 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = seq_1657000048__10; if linked_319 == nil { k__11 = ifn_320.Invoke_O__O(arg_321) } else { k__11 = linked_319.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_318, arg_321) }
				lang.IFn_Cast(walk__4).Invoke_O__O(lang.RT_Get_O_O__O_NoInit(m__0, k__11))
//line :94:1
				var tmp4 any; var root_326 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = seq_1657000048__10; if linked_327 == nil { tmp4 = ifn_328.Invoke_O__O(arg_329) } else { tmp4 = linked_327.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_326, arg_329) }; seq_1657000048__5, chunk_1657000049__6, count_1657000050__7, i_1657000051__8 = tmp4, nil, 0, 0; continue L1 } } }
//line :82:1
		break L1 }; var tmp5 any; var root_330 any = A_arbace_c_musl_A_const_54.GetRawRoot__O(); var linked_331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_330, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_332 lang.IFn; if













	linked_331 == nil { ifn_332 = lang.IFn_Cast(root_330) } else { ifn_332 = nil }; var arg_333 any = names__2; if linked_331 == nil { tmp5 = ifn_332.Invoke_O__O(arg_333) } else { tmp5 = linked_331.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_330, arg_333) }; var tmp6 any = tmp5; var tmp7 any; var root_334 any = /*line :82:1*/A_arbace_c_musl_A_const_9.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_336 lang.IFn; if


	linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = alias__3; if linked_335 == nil { tmp7 = ifn_336.Invoke_O__O(arg_337) } else { tmp7 = linked_335.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_334, arg_337) }; return /*line :82:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) }



func A_arbace_c_musl_attr_names_walk__1657000035_A_New_O_O(p0, p1 any) *A_arbace_c_musl_attr_names_walk__1657000035_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_attr_names_walk__1657000035_A{}; t.Ctor_O_O(p0, p1); return t }
//line :86:1
func (t *A_arbace_c_musl_attr_names_walk__1657000035_A) Ctor_O_O(c__names, c__alias any) { t.F_names = c__names; t.F_alias = c__alias }
//line :86:1
func (t *A_arbace_c_musl_attr_names_walk__1657000035_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_205 any = A_arbace_c_musl_A_const_42.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_207 lang.IFn
		if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = x__1; if linked_206 == nil { tmp1 = ifn_207.Invoke_O__O(arg_208) } else { tmp1 = linked_206.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_205, arg_208) }
//line :87:1
		if jrt.J2g_Truth(tmp1) {
			var tmp2 jrt.HashSet_I = jrt.HashSet_Cast(t.F_names); var tmp3 any; var root_209 any = A_arbace_c_musl_A_const_43.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any; var root_215 any = A_arbace_c_musl_A_const_44.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = x__1; if linked_216 == nil { arg_212 = ifn_217.Invoke_O__O(arg_218) } else { arg_212 = linked_216.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_215, arg_218) }; var arg_213 any = A_arbace_c_musl_A_const_45; var arg_214 any = Lit_2; if linked_210 == nil { tmp3 = ifn_211.Invoke_O_O_O__O(arg_212, arg_213, arg_214) } else { tmp3 = linked_210.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_209, arg_212, arg_213, arg_214) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2.Add_O__Z(tmp3)).Ref() } else {
//line :87:1
				var tmp4 any; var root_219 any = A_arbace_c_musl_A_const_46.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_221 lang.IFn

				if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = x__1; if linked_220 == nil { tmp4 = ifn_221.Invoke_O__O(arg_222) } else { tmp4 = linked_220.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_219, arg_222) }
//line :87:1
				if jrt.J2g_Truth(tmp4) { var vec__1657000036__2 any = x__1; var n__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000036__2, lang.RT_IntCast_J__I_NoInit(0), nil); var a__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000036__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 any; var and__1927000168__auto____5 any; var root_267 any = A_arbace_c_musl_A_const_42.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_269 lang.IFn


					if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = n__3; if linked_268 == nil { and__1927000168__auto____5 = ifn_269.Invoke_O__O(arg_270) } else { and__1927000168__auto____5 = linked_268.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_267, arg_270) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_49); var tmp7 any; var root_280 any = A_arbace_c_musl_A_const_44.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_282 lang.IFn; if linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = n__3; if linked_281 == nil { tmp7 = ifn_282.Invoke_O__O(arg_283) } else { tmp7 = linked_281.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_280, arg_283) }; and__1927000168__auto____6 = tmp6.Invoke_O__O(tmp7); if jrt.J2g_Truth(and__1927000168__auto____6) { var root_271 any = A_arbace_c_musl_A_const_50.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = a__4; if linked_272 == nil { tmp5 = ifn_273.Invoke_O__O(arg_274) } else { tmp5 = linked_272.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_271, arg_274) } } else { tmp5 = and__1927000168__auto____6 } } else { tmp5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp5) { var root_275 any = A_arbace_c_musl_A_const_51.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = t.F_alias; var arg_279 any = a__4; if linked_276 == nil { ifn_277.Invoke_O_O__O(arg_278, arg_279) } else { linked_276.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_275, arg_278, arg_279) } }
//line :87:1
					var seq_1657000039__5 any; var root_223 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_225 lang.IFn



					if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = x__1; if linked_224 == nil { seq_1657000039__5 = ifn_225.Invoke_O__O(arg_226) } else { seq_1657000039__5 = linked_224.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_223, arg_226) }
//line :87:1
					var chunk_1657000040__6 any; var count_1657000041__7 int64 = 0; var i_1657000042__8 int64 = 0; L1: for {



						if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000042__8, count_1657000041__7) { var y__9 any = lang.Indexed_Cast(chunk_1657000040__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000042__8)); lang.IFn_Cast(self).Invoke_O__O(y__9); seq_1657000039__5, chunk_1657000040__6, count_1657000041__7, i_1657000042__8 = seq_1657000039__5, chunk_1657000040__6, count_1657000041__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000042__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_227 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = seq_1657000039__5; if linked_228 == nil { temp__1927000414__auto____9 = ifn_229.Invoke_O__O(arg_230) } else { temp__1927000414__auto____9 = linked_228.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_227, arg_230) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1657000039__10 any = temp__1927000414__auto____9; var tmp8 any; var root_231 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = seq_1657000039__10; if linked_232 == nil { tmp8 = ifn_233.Invoke_O__O(arg_234) } else { tmp8 = linked_232.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_231, arg_234) }; if jrt.J2g_Truth(tmp8) { var c__1927000678__auto____11 any; var root_235 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any = seq_1657000039__10; if linked_236 == nil { c__1927000678__auto____11 = ifn_237.Invoke_O__O(arg_238) } else { c__1927000678__auto____11 = linked_236.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_235, arg_238) }; var tmp9 any; var root_284 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = seq_1657000039__10; if linked_285 == nil { tmp9 = ifn_286.Invoke_O__O(arg_287) } else { tmp9 = linked_285.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_284, arg_287) }; seq_1657000039__5, chunk_1657000040__6, count_1657000041__7, i_1657000042__8 = tmp9, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var y__11 any; var root_239 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = seq_1657000039__10; if linked_240 == nil { y__11 = ifn_241.Invoke_O__O(arg_242) } else { y__11 = linked_240.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_239, arg_242) }; lang.IFn_Cast(self).Invoke_O__O(y__11); var tmp10 any; var root_288 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_288, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_290 lang.IFn; if linked_289 == nil { ifn_290 = lang.IFn_Cast(root_288) } else { ifn_290 = nil }; var arg_291 any = seq_1657000039__10; if linked_289 == nil { tmp10 = ifn_290.Invoke_O__O(arg_291) } else { tmp10 = linked_289.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_288, arg_291) }; seq_1657000039__5, chunk_1657000040__6, count_1657000041__7, i_1657000042__8 = tmp10, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :87:1
							var tmp11 any; var root_243 any = A_arbace_c_musl_A_const_47.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_245 lang.IFn




							if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = x__1; if linked_244 == nil { tmp11 = ifn_245.Invoke_O__O(arg_246) } else { tmp11 = linked_244.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_243, arg_246) }
//line :87:1
							if jrt.J2g_Truth(tmp11) { var seq_1657000043__2 any; var root_247 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_249 lang.IFn




								if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = x__1; if linked_248 == nil { seq_1657000043__2 = ifn_249.Invoke_O__O(arg_250) } else { seq_1657000043__2 = linked_248.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_247, arg_250) }
//line :87:1
								var chunk_1657000044__3 any; var count_1657000045__4 int64 = 0; var i_1657000046__5 int64 = 0; L2: for {




									if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000046__5, count_1657000045__4) { var y__6 any = lang.Indexed_Cast(chunk_1657000044__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000046__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1657000043__2, chunk_1657000044__3, count_1657000045__4, i_1657000046__5 = seq_1657000043__2, chunk_1657000044__3, count_1657000045__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000046__5); continue L2 } else { var temp__1927000414__auto____6 any; var root_251 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = seq_1657000043__2; if linked_252 == nil { temp__1927000414__auto____6 = ifn_253.Invoke_O__O(arg_254) } else { temp__1927000414__auto____6 = linked_252.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_251, arg_254) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1657000043__7 any = temp__1927000414__auto____6; var tmp12 any; var root_255 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_257 lang.IFn; if linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any = seq_1657000043__7; if linked_256 == nil { tmp12 = ifn_257.Invoke_O__O(arg_258) } else { tmp12 = linked_256.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_255, arg_258) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____8 any; var root_259 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = seq_1657000043__7; if linked_260 == nil { c__1927000678__auto____8 = ifn_261.Invoke_O__O(arg_262) } else { c__1927000678__auto____8 = linked_260.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_259, arg_262) }; var tmp13 any; var root_292 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = seq_1657000043__7; if linked_293 == nil { tmp13 = ifn_294.Invoke_O__O(arg_295) } else { tmp13 = linked_293.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_292, arg_295) }; seq_1657000043__2, chunk_1657000044__3, count_1657000045__4, i_1657000046__5 = tmp13, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var y__8 any; var root_263 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = seq_1657000043__7; if linked_264 == nil { y__8 = ifn_265.Invoke_O__O(arg_266) } else { y__8 = linked_264.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_263, arg_266) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp14 any; var root_296 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = seq_1657000043__7; if linked_297 == nil { tmp14 = ifn_298.Invoke_O__O(arg_299) } else { tmp14 = linked_297.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_296, arg_299) }; seq_1657000043__2, chunk_1657000044__3, count_1657000045__4, i_1657000046__5 = tmp14, nil, 0, 0; continue L2 } } else { return nil } } } } else {
//line :87:1
										if A_arbace_c_musl_A_const_48 != nil { return nil } else { return nil } } } } }
//line :86:1
	panic("j2g: unreachable")
}










func A_arbace_c_musl_sym_name_A_New() *A_arbace_c_musl_sym_name_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_sym_name_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_c_musl_sym_name_A) Ctor() {}
//line :98:1
func (t *A_arbace_c_musl_sym_name_A) Invoke_O_O__O(self, x__0 any) any { var tmp1 any; var root_338 any = A_arbace_c_musl_A_const_42.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = x__0; if linked_339 == nil { tmp1 = ifn_340.Invoke_O__O(arg_341) } else { tmp1 = linked_339.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_338, arg_341) }; if jrt.J2g_Truth(tmp1) { var root_342 any = A_arbace_c_musl_A_const_44.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = x__0; if linked_343 == nil { return ifn_344.Invoke_O__O(arg_345) } else { return linked_343.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_342, arg_345) } } else { var tmp2 any; var and__1927000168__auto____2 any; var root_346 any = A_arbace_c_musl_A_const_47.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any = x__0; if linked_347 == nil { and__1927000168__auto____2 = ifn_348.Invoke_O__O(arg_349) } else { and__1927000168__auto____2 = linked_347.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_346, arg_349) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp3 any = A_arbace_c_musl_A_const_55; var tmp4 any; var root_350 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = x__0; if linked_351 == nil { tmp4 = ifn_352.Invoke_O__O(arg_353) } else { tmp4 = linked_351.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_350, arg_353) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp2) { var root_354 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = x__0; if linked_355 == nil { return ifn_356.Invoke_O__O(arg_357) } else { return linked_355.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_354, arg_357) } } else { return nil } } }

func A_arbace_c_musl_unit_defs_A_New() *A_arbace_c_musl_unit_defs_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_unit_defs_A{}; t.Ctor(); return t }
//line :100:1
func (t *A_arbace_c_musl_unit_defs_A) Ctor() {}
//line :100:1
func (t *A_arbace_c_musl_unit_defs_A) Invoke_O_O__O(self, forms__0 any) any { var out__2 any = jrt.HashMap_New(); var body_decl__3 *A_arbace_c_musl_unit_defs_decl__1657000054_A = A_arbace_c_musl_unit_defs_decl__1657000054_A_New_O(out__2); var decl__3 any; var fnbody__517 any = any(body_decl__3); var tmp1 *jrt.Class; var fncls__516 *jrt.Class = A_arbace_c_musl_unit_defs_decl__1657000054_A_fn_class; if fncls__516 == nil { var fncls__516d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__517); A_arbace_c_musl_unit_defs_decl__1657000054_A_fn_class = fncls__516d; tmp1 = fncls__516d } else { tmp1 = fncls__516 }; decl__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__517, tmp1, nil); var seq_1657000070__4 any; var root_518 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_520 lang.IFn; if

















	linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = forms__0; if linked_519 == nil { seq_1657000070__4 = ifn_520.Invoke_O__O(arg_521) } else { seq_1657000070__4 = linked_519.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_518, arg_521) }; var chunk_1657000071__5 any; var count_1657000072__6 int64 = 0; var i_1657000073__7 int64 = 0; L1:
//line :100:1
	for {

















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000073__7, count_1657000072__6) { var f__8 any = lang.Indexed_Cast(chunk_1657000071__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000073__7)); lang.IFn_Cast(decl__3).Invoke_O__O(f__8); seq_1657000070__4, chunk_1657000071__5, count_1657000072__6, i_1657000073__7 = seq_1657000070__4, chunk_1657000071__5, count_1657000072__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000073__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_522 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = seq_1657000070__4; if linked_523 == nil { temp__1927000414__auto____8 = ifn_524.Invoke_O__O(arg_525) } else { temp__1927000414__auto____8 = linked_523.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_522, arg_525) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1657000070__9 any = temp__1927000414__auto____8; var tmp2 any; var root_526 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_528 lang.IFn; if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = seq_1657000070__9; if linked_527 == nil { tmp2 = ifn_528.Invoke_O__O(arg_529) } else { tmp2 = linked_527.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_526, arg_529) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____10 any; var root_530 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_532 lang.IFn; if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any = seq_1657000070__9; if linked_531 == nil { c__1927000678__auto____10 = ifn_532.Invoke_O__O(arg_533) } else { c__1927000678__auto____10 = linked_531.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_530, arg_533) }; var tmp3 any; var root_538 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any = seq_1657000070__9; if linked_539 == nil { tmp3 = ifn_540.Invoke_O__O(arg_541) } else { tmp3 = linked_539.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_538, arg_541) }; seq_1657000070__4, chunk_1657000071__5, count_1657000072__6, i_1657000073__7 = tmp3, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__10 any; var root_534 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_536 lang.IFn; if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any = seq_1657000070__9; if linked_535 == nil { f__10 = ifn_536.Invoke_O__O(arg_537) } else { f__10 = linked_535.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_534, arg_537) }; lang.IFn_Cast(decl__3).Invoke_O__O(f__10); var tmp4 any; var root_542 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = seq_1657000070__9; if linked_543 == nil { tmp4 = ifn_544.Invoke_O__O(arg_545) } else { tmp4 = linked_543.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_542, arg_545) }; seq_1657000070__4, chunk_1657000071__5, count_1657000072__6, i_1657000073__7 = tmp4, nil, 0, 0; continue L1 } } }
//line :100:1
		break L1 }; var root_358 any =


















	A_arbace_c_musl_A_const_57.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_362 any = out__2; if linked_359 == nil { return ifn_360.Invoke_O_O__O(arg_361, arg_362) } else { return linked_359.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_358, arg_361, arg_362) } }
//line :104:1
func A_arbace_c_musl_unit_defs_decl__1657000054_A_New_O(p0 any) *A_arbace_c_musl_unit_defs_decl__1657000054_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_unit_defs_decl__1657000054_A{}; t.Ctor_O(p0); return t }
//line :104:1
func (t *A_arbace_c_musl_unit_defs_decl__1657000054_A) Ctor_O(c__out any) { t.F_out = c__out }
//line :104:1
func (t *A_arbace_c_musl_unit_defs_decl__1657000054_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 any; var root_363 any = A_arbace_c_musl_A_const_47.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = f__1; if linked_364 == nil { tmp1 = ifn_365.Invoke_O__O(arg_366) } else { tmp1 = linked_364.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_363, arg_366) }; if jrt.J2g_Truth(tmp1) { var G__1657000055__2_ any; var root_367 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_369 lang.IFn
		if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = f__1; if linked_368 == nil { G__1657000055__2_ = ifn_369.Invoke_O__O(arg_370) } else { G__1657000055__2_ = linked_368.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_367, arg_370) }; switch lang.Util_Hash_O__I_NoInit(G__1657000055__2_) >> 1 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000055__2_, A_arbace_c_musl_A_const_58) { var nm__3 any; var root_372 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_373 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_372, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_374 lang.IFn


			if linked_373 == nil { ifn_374 = lang.IFn_Cast(root_372) } else { ifn_374 = nil }; var arg_375 any = f__1; if linked_373 == nil { nm__3 = ifn_374.Invoke_O__O(arg_375) } else { nm__3 = linked_373.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_372, arg_375) }
//line :106:1
			var m__4 any = lang.RT_Meta_O__IPersistentMap_NoInit(nm__3); var n__5 any; var root_376 any = A_arbace_c_musl_A_const_59.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, A_arbace_c_musl_sym_name_A_fn_class); var ifn_378 lang.IFn


			if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = nm__3; if linked_377 == nil { n__5 = ifn_378.Invoke_O__O(arg_379) } else { n__5 = linked_377.(*A_arbace_c_musl_sym_name_A).Invoke_O_O__O(root_376, arg_379) }
//line :106:1
			var vec__1657000056__6 any; var root_380 any = A_arbace_c_musl_A_const_60.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, A_arbace_c_musl_attr_names_A_fn_class); var ifn_382 lang.IFn



			if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = m__4; if linked_381 == nil { vec__1657000056__6 = ifn_382.Invoke_O__O(arg_383) } else { vec__1657000056__6 = linked_381.(*A_arbace_c_musl_attr_names_A).Invoke_O_O__O(root_380, arg_383) }
//line :106:1
			var as__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000056__6, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000056__6, lang.RT_IntCast_J__I_NoInit(1), nil); var weak__9 any; var root_384 any = A_arbace_c_musl_A_const_61.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_386 lang.IFn




			if linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = as__7; var arg_388 any = Lit_82; if linked_385 == nil { weak__9 = ifn_386.Invoke_O_O__O(arg_387, arg_388) } else { weak__9 = linked_385.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_384, arg_387, arg_388) }
			var tmp2 any; var and__1927000168__auto____10 any = n__5; if jrt.J2g_Truth(and__1927000168__auto____10) { var root_389 any = A_arbace_c_musl_A_const_28.GetRawRoot__O(); var linked_390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_389, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_391 lang.IFn; if linked_390 == nil { ifn_391 = lang.IFn_Cast(root_389) } else { ifn_391 = nil }; var arg_392 any = A_arbace_c_musl_A_const_62.Invoke_O__O(m__4); if linked_390 == nil { tmp2 = ifn_391.Invoke_O__O(arg_392) } else { tmp2 = linked_390.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_389, arg_392) } } else { tmp2 = and__1927000168__auto____10 }; if jrt.J2g_Truth(tmp2) {
				if jrt.J2g_Truth(alias__8) {
					var tmp3 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp3.Put_O_O__O(n__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_63, weak__9, A_arbace_c_musl_A_const_64, alias__8))) } else {
//line :113:1
						var tmp4 any = A_arbace_c_musl_A_const_65; var tmp5 any; var root_393 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_395 lang.IFn

						if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = f__1; if linked_394 == nil { tmp5 = ifn_395.Invoke_O__O(arg_396) } else { tmp5 = linked_394.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_393, arg_396) }
//line :113:1
						if lang.Util_Equiv_O_O__Z_NoInit(tmp4, tmp5) {

							var tmp6 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp6.Put_O_O__O(n__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_63, weak__9))) } else {
//line :113:1
								var tmp7 any; var and__1927000168__auto____10_2 bool; var tmp8 any = A_arbace_c_musl_A_const_66; var tmp9 any; var root_397 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_399 lang.IFn


								if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = f__1; if linked_398 == nil { tmp9 = ifn_399.Invoke_O__O(arg_400) } else { tmp9 = linked_398.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_397, arg_400) }; and__1927000168__auto____10_2 = lang.Util_Equiv_O_O__Z_NoInit(tmp8, tmp9); if and__1927000168__auto____10_2 { var and__1927000168__auto____11 any; var root_401 any = A_arbace_c_musl_A_const_28.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = A_arbace_c_musl_A_const_67.Invoke_O__O(m__4); if linked_402 == nil { and__1927000168__auto____11 = ifn_403.Invoke_O__O(arg_404) } else { and__1927000168__auto____11 = linked_402.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_401, arg_404) }; if jrt.J2g_Truth(and__1927000168__auto____11) { var root_405 any = A_arbace_c_musl_A_const_28.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var tmp10 any = A_arbace_c_musl_A_const_68; var tmp11 *lang.Keyword = A_arbace_c_musl_A_const_69; var arg_408 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp10, tmp11.Invoke_O__O(A_arbace_c_musl_A_const_70.Invoke_O__O(m__4)))).Ref(); if linked_406 == nil { tmp7 = ifn_407.Invoke_O__O(arg_408) } else { tmp7 = linked_406.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_405, arg_408) } } else { tmp7 = and__1927000168__auto____11 } } else { tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_2).Ref() }
//line :113:1
								if jrt.J2g_Truth(tmp7) {


									var tmp12 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp12.Put_O_O__O(n__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_63, weak__9))) } else {
//line :113:1
										return nil } } } } else {
//line :112:1
											return nil } }
//line :106:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000055__2_, A_arbace_c_musl_A_const_71) { var seq_1657000059__3 any; var root_409 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_411 lang.IFn
			if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any; var root_413 any = A_arbace_c_musl_A_const_72.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_413, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_417 any = f__1; if linked_414 == nil { arg_412 = ifn_415.Invoke_O_O__O(A_arbace_c_musl_A_const_73, arg_417) } else { arg_412 = linked_414.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_413, 2, A_arbace_c_musl_A_const_73, arg_417) }; if linked_410 == nil { seq_1657000059__3 = ifn_411.Invoke_O__O(arg_412) } else { seq_1657000059__3 = linked_410.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_409, arg_412) }
//line :106:1
			var chunk_1657000060__4 any; var count_1657000061__5 int64 = 0; var i_1657000062__6 int64 = 0; L2: for {
				if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000062__6, count_1657000061__5) { var d__7 any = lang.Indexed_Cast(chunk_1657000060__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000062__6)); lang.IFn_Cast(self).Invoke_O__O(d__7); seq_1657000059__3, chunk_1657000060__4, count_1657000061__5, i_1657000062__6 = seq_1657000059__3, chunk_1657000060__4, count_1657000061__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000062__6); continue L2 } else { var temp__1927000414__auto____7 any; var root_418 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = seq_1657000059__3; if linked_419 == nil { temp__1927000414__auto____7 = ifn_420.Invoke_O__O(arg_421) } else { temp__1927000414__auto____7 = linked_419.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_418, arg_421) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1657000059__8 any = temp__1927000414__auto____7; var tmp13 any; var root_422 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = seq_1657000059__8; if linked_423 == nil { tmp13 = ifn_424.Invoke_O__O(arg_425) } else { tmp13 = linked_423.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_422, arg_425) }; if jrt.J2g_Truth(tmp13) { var c__1927000678__auto____9 any; var root_426 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_426, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_428 lang.IFn; if linked_427 == nil { ifn_428 = lang.IFn_Cast(root_426) } else { ifn_428 = nil }; var arg_429 any = seq_1657000059__8; if linked_427 == nil { c__1927000678__auto____9 = ifn_428.Invoke_O__O(arg_429) } else { c__1927000678__auto____9 = linked_427.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_426, arg_429) }; var tmp14 any; var root_508 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = seq_1657000059__8; if linked_509 == nil { tmp14 = ifn_510.Invoke_O__O(arg_511) } else { tmp14 = linked_509.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_508, arg_511) }; seq_1657000059__3, chunk_1657000060__4, count_1657000061__5, i_1657000062__6 = tmp14, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__9 any; var root_430 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = seq_1657000059__8; if linked_431 == nil { d__9 = ifn_432.Invoke_O__O(arg_433) } else { d__9 = linked_431.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_430, arg_433) }; lang.IFn_Cast(self).Invoke_O__O(d__9); var tmp15 any; var root_512 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = seq_1657000059__8; if linked_513 == nil { tmp15 = ifn_514.Invoke_O__O(arg_515) } else { tmp15 = linked_513.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_512, arg_515) }; seq_1657000059__3, chunk_1657000060__4, count_1657000061__5, i_1657000062__6 = tmp15, nil, 0, 0; continue L2 } } else { return nil } } } }
//line :106:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000055__2_, A_arbace_c_musl_A_const_74) { var nm__3_2 any; var root_434 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_435 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_434, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_436 lang.IFn


			if linked_435 == nil { ifn_436 = lang.IFn_Cast(root_434) } else { ifn_436 = nil }; var arg_437 any = f__1; if linked_435 == nil { nm__3_2 = ifn_436.Invoke_O__O(arg_437) } else { nm__3_2 = linked_435.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_434, arg_437) }
//line :106:1
			var m__4_2 any = lang.RT_Meta_O__IPersistentMap_NoInit(nm__3_2); var n__5_2 any; var root_438 any = A_arbace_c_musl_A_const_59.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, A_arbace_c_musl_sym_name_A_fn_class); var ifn_440 lang.IFn


			if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = nm__3_2; if linked_439 == nil { n__5_2 = ifn_440.Invoke_O__O(arg_441) } else { n__5_2 = linked_439.(*A_arbace_c_musl_sym_name_A).Invoke_O_O__O(root_438, arg_441) }
//line :106:1
			var vec__1657000063__6 any; var root_442 any = A_arbace_c_musl_A_const_60.GetRawRoot__O(); var linked_443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_442, A_arbace_c_musl_attr_names_A_fn_class); var ifn_444 lang.IFn



			if linked_443 == nil { ifn_444 = lang.IFn_Cast(root_442) } else { ifn_444 = nil }; var arg_445 any = m__4_2; if linked_443 == nil { vec__1657000063__6 = ifn_444.Invoke_O__O(arg_445) } else { vec__1657000063__6 = linked_443.(*A_arbace_c_musl_attr_names_A).Invoke_O_O__O(root_442, arg_445) }
//line :106:1
			var as__7_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000063__6, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__8_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000063__6, lang.RT_IntCast_J__I_NoInit(1), nil); var weak__9_2 any; var root_446 any = A_arbace_c_musl_A_const_61.GetRawRoot__O(); var linked_447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_446, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_448 lang.IFn




			if linked_447 == nil { ifn_448 = lang.IFn_Cast(root_446) } else { ifn_448 = nil }; var arg_449 any = as__7_2; var arg_450 any = Lit_82; if linked_447 == nil { weak__9_2 = ifn_448.Invoke_O_O__O(arg_449, arg_450) } else { weak__9_2 = linked_447.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_446, arg_449, arg_450) }
			var tmp16 any; var and__1927000168__auto____10_3 any = n__5_2; if jrt.J2g_Truth(and__1927000168__auto____10_3) { var root_451 any = A_arbace_c_musl_A_const_28.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_453 lang.IFn; if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = A_arbace_c_musl_A_const_62.Invoke_O__O(m__4_2); if linked_452 == nil { tmp16 = ifn_453.Invoke_O__O(arg_454) } else { tmp16 = linked_452.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_451, arg_454) } } else { tmp16 = and__1927000168__auto____10_3 }; if jrt.J2g_Truth(tmp16) {
				if jrt.J2g_Truth(alias__8_2) {
					var tmp17 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp17.Put_O_O__O(n__5_2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_63, weak__9_2, A_arbace_c_musl_A_const_64, alias__8_2))) } else {
//line :113:1
						var tmp18 any = A_arbace_c_musl_A_const_65; var tmp19 any; var root_455 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_457 lang.IFn

						if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = f__1; if linked_456 == nil { tmp19 = ifn_457.Invoke_O__O(arg_458) } else { tmp19 = linked_456.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_455, arg_458) }
//line :113:1
						if lang.Util_Equiv_O_O__Z_NoInit(tmp18, tmp19) {

							var tmp20 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp20.Put_O_O__O(n__5_2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_63, weak__9_2))) } else {
//line :113:1
								var tmp21 any; var and__1927000168__auto____10_4 bool; var tmp22 any = A_arbace_c_musl_A_const_66; var tmp23 any; var root_459 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_461 lang.IFn


								if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = f__1; if linked_460 == nil { tmp23 = ifn_461.Invoke_O__O(arg_462) } else { tmp23 = linked_460.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_459, arg_462) }; and__1927000168__auto____10_4 = lang.Util_Equiv_O_O__Z_NoInit(tmp22, tmp23); if and__1927000168__auto____10_4 { var and__1927000168__auto____11_2 any; var root_463 any = A_arbace_c_musl_A_const_28.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_465 lang.IFn; if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any = A_arbace_c_musl_A_const_67.Invoke_O__O(m__4_2); if linked_464 == nil { and__1927000168__auto____11_2 = ifn_465.Invoke_O__O(arg_466) } else { and__1927000168__auto____11_2 = linked_464.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_463, arg_466) }; if jrt.J2g_Truth(and__1927000168__auto____11_2) { var root_467 any = A_arbace_c_musl_A_const_28.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_469 lang.IFn; if linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var tmp24 any = A_arbace_c_musl_A_const_68; var tmp25 *lang.Keyword = A_arbace_c_musl_A_const_69; var arg_470 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp24, tmp25.Invoke_O__O(A_arbace_c_musl_A_const_70.Invoke_O__O(m__4_2)))).Ref(); if linked_468 == nil { tmp21 = ifn_469.Invoke_O__O(arg_470) } else { tmp21 = linked_468.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_467, arg_470) } } else { tmp21 = and__1927000168__auto____11_2 } } else { tmp21 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_4).Ref() }
//line :113:1
								if jrt.J2g_Truth(tmp21) {


									var tmp26 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp26.Put_O_O__O(n__5_2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_63, weak__9_2))) } else {
//line :113:1
										return nil } } } } else {
//line :112:1
											return nil } }
//line :106:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000055__2_, A_arbace_c_musl_A_const_75) { var nm__3_3 any; var root_471 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_473 lang.IFn


			if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = f__1; if linked_472 == nil { nm__3_3 = ifn_473.Invoke_O__O(arg_474) } else { nm__3_3 = linked_472.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_471, arg_474) }
//line :106:1
			var m__4_3 any = lang.RT_Meta_O__IPersistentMap_NoInit(nm__3_3); var n__5_3 any; var root_475 any = A_arbace_c_musl_A_const_59.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, A_arbace_c_musl_sym_name_A_fn_class); var ifn_477 lang.IFn


			if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = nm__3_3; if linked_476 == nil { n__5_3 = ifn_477.Invoke_O__O(arg_478) } else { n__5_3 = linked_476.(*A_arbace_c_musl_sym_name_A).Invoke_O_O__O(root_475, arg_478) }
//line :106:1
			var vec__1657000066__6 any; var root_479 any = A_arbace_c_musl_A_const_60.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, A_arbace_c_musl_attr_names_A_fn_class); var ifn_481 lang.IFn



			if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = m__4_3; if linked_480 == nil { vec__1657000066__6 = ifn_481.Invoke_O__O(arg_482) } else { vec__1657000066__6 = linked_480.(*A_arbace_c_musl_attr_names_A).Invoke_O_O__O(root_479, arg_482) }
//line :106:1
			var as__7_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000066__6, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__8_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000066__6, lang.RT_IntCast_J__I_NoInit(1), nil); var weak__9_3 any; var root_483 any = A_arbace_c_musl_A_const_61.GetRawRoot__O(); var linked_484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_483, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_485 lang.IFn




			if linked_484 == nil { ifn_485 = lang.IFn_Cast(root_483) } else { ifn_485 = nil }; var arg_486 any = as__7_3; var arg_487 any = Lit_82; if linked_484 == nil { weak__9_3 = ifn_485.Invoke_O_O__O(arg_486, arg_487) } else { weak__9_3 = linked_484.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_483, arg_486, arg_487) }
			var tmp27 any; var and__1927000168__auto____10_5 any = n__5_3; if jrt.J2g_Truth(and__1927000168__auto____10_5) { var root_488 any = A_arbace_c_musl_A_const_28.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_490 lang.IFn; if linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = A_arbace_c_musl_A_const_62.Invoke_O__O(m__4_3); if linked_489 == nil { tmp27 = ifn_490.Invoke_O__O(arg_491) } else { tmp27 = linked_489.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_488, arg_491) } } else { tmp27 = and__1927000168__auto____10_5 }; if jrt.J2g_Truth(tmp27) {
				if jrt.J2g_Truth(alias__8_3) {
					var tmp28 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp28.Put_O_O__O(n__5_3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_63, weak__9_3, A_arbace_c_musl_A_const_64, alias__8_3))) } else {
//line :113:1
						var tmp29 any = A_arbace_c_musl_A_const_65; var tmp30 any; var root_492 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_494 lang.IFn

						if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = f__1; if linked_493 == nil { tmp30 = ifn_494.Invoke_O__O(arg_495) } else { tmp30 = linked_493.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_492, arg_495) }
//line :113:1
						if lang.Util_Equiv_O_O__Z_NoInit(tmp29, tmp30) {

							var tmp31 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp31.Put_O_O__O(n__5_3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_63, weak__9_3))) } else {
//line :113:1
								var tmp32 any; var and__1927000168__auto____10_6 bool; var tmp33 any = A_arbace_c_musl_A_const_66; var tmp34 any; var root_496 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_498 lang.IFn


								if linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = f__1; if linked_497 == nil { tmp34 = ifn_498.Invoke_O__O(arg_499) } else { tmp34 = linked_497.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_496, arg_499) }; and__1927000168__auto____10_6 = lang.Util_Equiv_O_O__Z_NoInit(tmp33, tmp34); if and__1927000168__auto____10_6 { var and__1927000168__auto____11_3 any; var root_500 any = A_arbace_c_musl_A_const_28.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = A_arbace_c_musl_A_const_67.Invoke_O__O(m__4_3); if linked_501 == nil { and__1927000168__auto____11_3 = ifn_502.Invoke_O__O(arg_503) } else { and__1927000168__auto____11_3 = linked_501.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_500, arg_503) }; if jrt.J2g_Truth(and__1927000168__auto____11_3) { var root_504 any = A_arbace_c_musl_A_const_28.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_506 lang.IFn; if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var tmp35 any = A_arbace_c_musl_A_const_68; var tmp36 *lang.Keyword = A_arbace_c_musl_A_const_69; var arg_507 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp35, tmp36.Invoke_O__O(A_arbace_c_musl_A_const_70.Invoke_O__O(m__4_3)))).Ref(); if linked_505 == nil { tmp32 = ifn_506.Invoke_O__O(arg_507) } else { tmp32 = linked_505.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_504, arg_507) } } else { tmp32 = and__1927000168__auto____11_3 } } else { tmp32 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_6).Ref() }
//line :113:1
								if jrt.J2g_Truth(tmp32) {


									var tmp37 jrt.HashMap_I = jrt.HashMap_Cast(t.F_out); return tmp37.Put_O_O__O(n__5_3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_63, weak__9_3))) } else {
//line :113:1
										return nil } } } } else {
//line :112:1
											return nil } }
//line :106:1
		default:}; return nil } else {
//line :105:1
			return nil
		}
}













func A_arbace_c_musl_refs_A_New() *A_arbace_c_musl_refs_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_refs_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_c_musl_refs_A) Ctor() {}
//line :121:1
func (t *A_arbace_c_musl_refs_A) Invoke_O_O__O(self, forms__0 any) any { var acc__2 any = jrt.HashSet_New(); var body_walk__3 *A_arbace_c_musl_refs_walk__1657000075_A = A_arbace_c_musl_refs_walk__1657000075_A_New_O(acc__2); var body_decl__4 *A_arbace_c_musl_refs_decl__1657000081_A = A_arbace_c_musl_refs_decl__1657000081_A_New_O_O(nil, nil); var body_walk_meta__5 *A_arbace_c_musl_refs_walk_meta__1657000094_A = A_arbace_c_musl_refs_walk_meta__1657000094_A_New_O(acc__2); var walk__3 any; var fnbody__697 any = any(body_walk__3); var tmp1 *jrt.Class; var fncls__696 *jrt.Class = A_arbace_c_musl_refs_walk__1657000075_A_fn_class; if fncls__696 == nil { var fncls__696d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, fnbody__697); A_arbace_c_musl_refs_walk__1657000075_A_fn_class = fncls__696d; tmp1 = fncls__696d } else { tmp1 = fncls__696 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__697, tmp1, nil); var decl__4 any; var fnbody__699 any = any(body_decl__4); var tmp2 *jrt.Class; var fncls__698 *jrt.Class = A_arbace_c_musl_refs_decl__1657000081_A_fn_class; if fncls__698 == nil { var fncls__698d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, fnbody__699); A_arbace_c_musl_refs_decl__1657000081_A_fn_class = fncls__698d; tmp2 = fncls__698d } else { tmp2 = fncls__698 }; decl__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__699, tmp2, nil); var walk_meta__5 any; var fnbody__701 any = any(body_walk_meta__5); var tmp3 *jrt.Class; var fncls__700 *jrt.Class = A_arbace_c_musl_refs_walk_meta__1657000094_A_fn_class; if fncls__700 == nil { var fncls__700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__701); A_arbace_c_musl_refs_walk_meta__1657000094_A_fn_class = fncls__700d; tmp3 = fncls__700d } else { tmp3 = fncls__700 }; walk_meta__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__701, tmp3, nil); body_decl__4.F_walk = walk__3; body_decl__4.F_walk_meta = walk_meta__5; var seq_1657000099__6 any; var root_702 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_704 lang.IFn; if




















	linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = forms__0; if linked_703 == nil { seq_1657000099__6 = ifn_704.Invoke_O__O(arg_705) } else { seq_1657000099__6 = linked_703.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_702, arg_705) }; var chunk_1657000100__7 any; var count_1657000101__8 int64 = 0; var i_1657000102__9 int64 = 0; L1:
//line :121:1
	for {




















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000102__9, count_1657000101__8) { var f__10 any = lang.Indexed_Cast(chunk_1657000100__7).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000102__9)); lang.IFn_Cast(decl__4).Invoke_O__O(f__10); seq_1657000099__6, chunk_1657000100__7, count_1657000101__8, i_1657000102__9 = seq_1657000099__6, chunk_1657000100__7, count_1657000101__8, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000102__9); continue L1 } else { var temp__1927000414__auto____10 any; var root_706 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = seq_1657000099__6; if linked_707 == nil { temp__1927000414__auto____10 = ifn_708.Invoke_O__O(arg_709) } else { temp__1927000414__auto____10 = linked_707.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_706, arg_709) }; if jrt.J2g_Truth(temp__1927000414__auto____10) { var seq_1657000099__11 any = temp__1927000414__auto____10; var tmp4 any; var root_710 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_710, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_712 lang.IFn; if linked_711 == nil { ifn_712 = lang.IFn_Cast(root_710) } else { ifn_712 = nil }; var arg_713 any = seq_1657000099__11; if linked_711 == nil { tmp4 = ifn_712.Invoke_O__O(arg_713) } else { tmp4 = linked_711.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_710, arg_713) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____12 any; var root_714 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = seq_1657000099__11; if linked_715 == nil { c__1927000678__auto____12 = ifn_716.Invoke_O__O(arg_717) } else { c__1927000678__auto____12 = linked_715.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_714, arg_717) }; var tmp5 any; var root_722 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any = seq_1657000099__11; if linked_723 == nil { tmp5 = ifn_724.Invoke_O__O(arg_725) } else { tmp5 = linked_723.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_722, arg_725) }; seq_1657000099__6, chunk_1657000100__7, count_1657000101__8, i_1657000102__9 = tmp5, c__1927000678__auto____12, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__12 any; var root_718 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_718, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_720 lang.IFn; if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = seq_1657000099__11; if linked_719 == nil { f__12 = ifn_720.Invoke_O__O(arg_721) } else { f__12 = linked_719.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_718, arg_721) }; lang.IFn_Cast(decl__4).Invoke_O__O(f__12); var tmp6 any; var root_726 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = seq_1657000099__11; if linked_727 == nil { tmp6 = ifn_728.Invoke_O__O(arg_729) } else { tmp6 = linked_727.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_726, arg_729) }; seq_1657000099__6, chunk_1657000100__7, count_1657000101__8, i_1657000102__9 = tmp6, nil, 0, 0; continue L1 } } }
//line :121:1
		break L1 }; return acc__2 }




func A_arbace_c_musl_refs_decl__1657000081_A_New_O_O(p0, p1 any) *A_arbace_c_musl_refs_decl__1657000081_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_refs_decl__1657000081_A{}; t.Ctor_O_O(p0, p1); return t }
//line :126:1
func (t *A_arbace_c_musl_refs_decl__1657000081_A) Ctor_O_O(c__walk, c__walk_meta any) { t.F_walk = c__walk; t.F_walk_meta = c__walk_meta }
//line :126:1
func (t *A_arbace_c_musl_refs_decl__1657000081_A) Invoke_O_O__O(self, f__1 any) any {





	var tmp1 any; var root_594 any = A_arbace_c_musl_A_const_47.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_596 lang.IFn; if linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = f__1; if linked_595 == nil { tmp1 = ifn_596.Invoke_O__O(arg_597) } else { tmp1 = linked_595.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(tmp1) { var G__1657000082__2_ any; var root_598 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_600 lang.IFn
		if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = f__1; if linked_599 == nil { G__1657000082__2_ = ifn_600.Invoke_O__O(arg_601) } else { G__1657000082__2_ = linked_599.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_598, arg_601) }; switch lang.Util_Hash_O__I_NoInit(G__1657000082__2_) >> 8 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000082__2_, A_arbace_c_musl_A_const_77) {


			var tmp2 lang.IFn = lang.IFn_Cast(t.F_walk_meta); var tmp3 any; var root_648 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_650 lang.IFn; if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any = f__1; if linked_649 == nil { tmp3 = ifn_650.Invoke_O__O(arg_651) } else { tmp3 = linked_649.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_648, arg_651) }; return tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp3)) }
//line :133:1
		case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000082__2_, A_arbace_c_musl_A_const_78) { var seq_1657000083__3 any; var root_603 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_605 lang.IFn



			if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any; var root_607 any = A_arbace_c_musl_A_const_72.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_607, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_611 any = f__1; if linked_608 == nil { arg_606 = ifn_609.Invoke_O_O__O(A_arbace_c_musl_A_const_73, arg_611) } else { arg_606 = linked_608.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_607, 2, A_arbace_c_musl_A_const_73, arg_611) }; if linked_604 == nil { seq_1657000083__3 = ifn_605.Invoke_O__O(arg_606) } else { seq_1657000083__3 = linked_604.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_603, arg_606) }
//line :133:1
			var chunk_1657000084__4 any; var count_1657000085__5 int64 = 0; var i_1657000086__6 int64 = 0; L2: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000086__6, count_1657000085__5) { var d__7 any = lang.Indexed_Cast(chunk_1657000084__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000086__6)); lang.IFn_Cast(self).Invoke_O__O(d__7); seq_1657000083__3, chunk_1657000084__4, count_1657000085__5, i_1657000086__6 = seq_1657000083__3, chunk_1657000084__4, count_1657000085__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000086__6); continue L2 } else { var temp__1927000414__auto____7 any; var root_612 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = seq_1657000083__3; if linked_613 == nil { temp__1927000414__auto____7 = ifn_614.Invoke_O__O(arg_615) } else { temp__1927000414__auto____7 = linked_613.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_612, arg_615) }; if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1657000083__8 any = temp__1927000414__auto____7; var tmp4 any; var root_616 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = seq_1657000083__8; if linked_617 == nil { tmp4 = ifn_618.Invoke_O__O(arg_619) } else { tmp4 = linked_617.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_616, arg_619) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____9 any; var root_620 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = seq_1657000083__8; if linked_621 == nil { c__1927000678__auto____9 = ifn_622.Invoke_O__O(arg_623) } else { c__1927000678__auto____9 = linked_621.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_620, arg_623) }; var tmp5 any; var root_652 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = seq_1657000083__8; if linked_653 == nil { tmp5 = ifn_654.Invoke_O__O(arg_655) } else { tmp5 = linked_653.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_652, arg_655) }; seq_1657000083__3, chunk_1657000084__4, count_1657000085__5, i_1657000086__6 = tmp5, c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var d__9 any; var root_624 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = seq_1657000083__8; if linked_625 == nil { d__9 = ifn_626.Invoke_O__O(arg_627) } else { d__9 = linked_625.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_624, arg_627) }; lang.IFn_Cast(self).Invoke_O__O(d__9); var tmp6 any; var root_656 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = seq_1657000083__8; if linked_657 == nil { tmp6 = ifn_658.Invoke_O__O(arg_659) } else { tmp6 = linked_657.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_656, arg_659) }; seq_1657000083__3, chunk_1657000084__4, count_1657000085__5, i_1657000086__6 = tmp6, nil, 0, 0; continue L2 } } else { return nil } } } }
//line :133:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000082__2_, A_arbace_c_musl_A_const_79) { var vec__1657000087__3 any = f__1; var seq__1657000088__4 any; var root_628 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_630 lang.IFn

			if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = vec__1657000087__3; if linked_629 == nil { seq__1657000088__4 = ifn_630.Invoke_O__O(arg_631) } else { seq__1657000088__4 = linked_629.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_628, arg_631) }
//line :133:1
			var first__1657000089__5 any; var root_632 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_634 lang.IFn

			if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = seq__1657000088__4; if linked_633 == nil { first__1657000089__5 = ifn_634.Invoke_O__O(arg_635) } else { first__1657000089__5 = linked_633.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_632, arg_635) }
//line :133:1
			var seq__1657000088__6 any; var root_636 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_636, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_638 lang.IFn

			if linked_637 == nil { ifn_638 = lang.IFn_Cast(root_636) } else { ifn_638 = nil }; var arg_639 any = seq__1657000088__4; if linked_637 == nil { seq__1657000088__6 = ifn_638.Invoke_O__O(arg_639) } else { seq__1657000088__6 = linked_637.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_636, arg_639) }
//line :133:1
			var ___7 any = first__1657000089__5; var first__1657000089__8 any; var root_640 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_642 lang.IFn; _ = ___7

			if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = seq__1657000088__6; if linked_641 == nil { first__1657000089__8 = ifn_642.Invoke_O__O(arg_643) } else { first__1657000089__8 = linked_641.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_640, arg_643) }
//line :133:1
			var seq__1657000088__9 any; var root_644 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_646 lang.IFn

			if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = seq__1657000088__6; if linked_645 == nil { seq__1657000088__9 = ifn_646.Invoke_O__O(arg_647) } else { seq__1657000088__9 = linked_645.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_644, arg_647) }
//line :133:1
			var nm__10 any = first__1657000089__8
			var init__11 any = seq__1657000088__9
			lang.IFn_Cast(t.F_walk).Invoke_O__O(init__11); var tmp7 lang.IFn = lang.IFn_Cast(t.F_walk_meta); return tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__10)) }
//line :133:1
		case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000082__2_, A_arbace_c_musl_A_const_80) {


			var tmp8 lang.IFn = lang.IFn_Cast(t.F_walk_meta); var tmp9 any; var root_688 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_690 lang.IFn; if linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = f__1; if linked_689 == nil { tmp9 = ifn_690.Invoke_O__O(arg_691) } else { tmp9 = linked_689.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_688, arg_691) }; return tmp8.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(tmp9)) }
//line :133:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1657000082__2_, A_arbace_c_musl_A_const_81) { var vec__1657000090__3 any = f__1; var seq__1657000091__4 any; var root_660 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_662 lang.IFn
			if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any = vec__1657000090__3; if linked_661 == nil { seq__1657000091__4 = ifn_662.Invoke_O__O(arg_663) } else { seq__1657000091__4 = linked_661.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_660, arg_663) }
//line :133:1
			var first__1657000092__5 any; var root_664 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_664, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_666 lang.IFn
			if linked_665 == nil { ifn_666 = lang.IFn_Cast(root_664) } else { ifn_666 = nil }; var arg_667 any = seq__1657000091__4; if linked_665 == nil { first__1657000092__5 = ifn_666.Invoke_O__O(arg_667) } else { first__1657000092__5 = linked_665.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_664, arg_667) }
//line :133:1
			var seq__1657000091__6 any; var root_668 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_670 lang.IFn
			if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = seq__1657000091__4; if linked_669 == nil { seq__1657000091__6 = ifn_670.Invoke_O__O(arg_671) } else { seq__1657000091__6 = linked_669.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_668, arg_671) }
//line :133:1
			var ___7_2 any = first__1657000092__5; var first__1657000092__8 any; var root_672 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_674 lang.IFn; _ = ___7_2
			if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = seq__1657000091__6; if linked_673 == nil { first__1657000092__8 = ifn_674.Invoke_O__O(arg_675) } else { first__1657000092__8 = linked_673.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_672, arg_675) }
//line :133:1
			var seq__1657000091__9 any; var root_676 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_678 lang.IFn
			if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = seq__1657000091__6; if linked_677 == nil { seq__1657000091__9 = ifn_678.Invoke_O__O(arg_679) } else { seq__1657000091__9 = linked_677.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_676, arg_679) }
//line :133:1
			var nm__10_2 any = first__1657000092__8; var first__1657000092__11 any; var root_680 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_682 lang.IFn
			if linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any = seq__1657000091__9; if linked_681 == nil { first__1657000092__11 = ifn_682.Invoke_O__O(arg_683) } else { first__1657000092__11 = linked_681.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_680, arg_683) }
//line :133:1
			var seq__1657000091__12 any; var root_684 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_684, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_686 lang.IFn
			if linked_685 == nil { ifn_686 = lang.IFn_Cast(root_684) } else { ifn_686 = nil }; var arg_687 any = seq__1657000091__9; if linked_685 == nil { seq__1657000091__12 = ifn_686.Invoke_O__O(arg_687) } else { seq__1657000091__12 = linked_685.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_684, arg_687) }
//line :133:1
			var ___13 any = first__1657000092__11; var body__14 any = seq__1657000091__12; _ = ___13
			lang.IFn_Cast(t.F_walk).Invoke_O__O(body__14); var tmp10 lang.IFn = lang.IFn_Cast(t.F_walk_meta); return tmp10.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(nm__10_2)) }
//line :133:1
		default:}; return nil } else {
//line :132:1
			return nil } }
//line :126:1
func A_arbace_c_musl_refs_walk__1657000075_A_New_O(p0 any) *A_arbace_c_musl_refs_walk__1657000075_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_refs_walk__1657000075_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_c_musl_refs_walk__1657000075_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :126:1
func (t *A_arbace_c_musl_refs_walk__1657000075_A) Invoke_O_O__O(self, x__1 any) any {
	{ var tmp1 any; var root_546 any = A_arbace_c_musl_A_const_42.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_548 lang.IFn
		if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = x__1; if linked_547 == nil { tmp1 = ifn_548.Invoke_O__O(arg_549) } else { tmp1 = linked_547.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_546, arg_549) }
//line :127:1
		if jrt.J2g_Truth(tmp1) {
			var tmp2 any; var root_550 any = A_arbace_c_musl_A_const_76.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = x__1; if linked_551 == nil { tmp2 = ifn_552.Invoke_O__O(arg_553) } else { tmp2 = linked_551.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_550, arg_553) }; if jrt.J2g_Truth(tmp2) { return nil } else { var tmp3 jrt.HashSet_I = jrt.HashSet_Cast(t.F_acc); var tmp4 any; var root_554 any = A_arbace_c_musl_A_const_44.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = x__1; if linked_555 == nil { tmp4 = ifn_556.Invoke_O__O(arg_557) } else { tmp4 = linked_555.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_554, arg_557) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp3.Add_O__Z(tmp4)).Ref() } } else {
//line :127:1
				var tmp5 any; var or__1927000174__auto____2 any; var root_558 any = A_arbace_c_musl_A_const_47.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_560 lang.IFn

				if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = x__1; if linked_559 == nil { or__1927000174__auto____2 = ifn_560.Invoke_O__O(arg_561) } else { or__1927000174__auto____2 = linked_559.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_558, arg_561) }; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp5 = or__1927000174__auto____2 } else { var root_562 any = A_arbace_c_musl_A_const_46.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_564 lang.IFn; if linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = x__1; if linked_563 == nil { tmp5 = ifn_564.Invoke_O__O(arg_565) } else { tmp5 = linked_563.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_562, arg_565) } }
//line :127:1
				if jrt.J2g_Truth(tmp5) { var seq_1657000076__2 any; var root_566 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_566, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_568 lang.IFn

					if linked_567 == nil { ifn_568 = lang.IFn_Cast(root_566) } else { ifn_568 = nil }; var arg_569 any = x__1; if linked_567 == nil { seq_1657000076__2 = ifn_568.Invoke_O__O(arg_569) } else { seq_1657000076__2 = linked_567.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_566, arg_569) }
//line :127:1
					var chunk_1657000077__3 any; var count_1657000078__4 int64 = 0; var i_1657000079__5 int64 = 0; L1: for {

						if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000079__5, count_1657000078__4) { var y__6 any = lang.Indexed_Cast(chunk_1657000077__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000079__5)); lang.IFn_Cast(self).Invoke_O__O(y__6); seq_1657000076__2, chunk_1657000077__3, count_1657000078__4, i_1657000079__5 = seq_1657000076__2, chunk_1657000077__3, count_1657000078__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000079__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_570 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = seq_1657000076__2; if linked_571 == nil { temp__1927000414__auto____6 = ifn_572.Invoke_O__O(arg_573) } else { temp__1927000414__auto____6 = linked_571.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_570, arg_573) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1657000076__7 any = temp__1927000414__auto____6; var tmp6 any; var root_574 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = seq_1657000076__7; if linked_575 == nil { tmp6 = ifn_576.Invoke_O__O(arg_577) } else { tmp6 = linked_575.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_574, arg_577) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____8 any; var root_578 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = seq_1657000076__7; if linked_579 == nil { c__1927000678__auto____8 = ifn_580.Invoke_O__O(arg_581) } else { c__1927000678__auto____8 = linked_579.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_578, arg_581) }; var tmp7 any; var root_586 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = seq_1657000076__7; if linked_587 == nil { tmp7 = ifn_588.Invoke_O__O(arg_589) } else { tmp7 = linked_587.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_586, arg_589) }; seq_1657000076__2, chunk_1657000077__3, count_1657000078__4, i_1657000079__5 = tmp7, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var y__8 any; var root_582 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = seq_1657000076__7; if linked_583 == nil { y__8 = ifn_584.Invoke_O__O(arg_585) } else { y__8 = linked_583.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_582, arg_585) }; lang.IFn_Cast(self).Invoke_O__O(y__8); var tmp8 any; var root_590 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = seq_1657000076__7; if linked_591 == nil { tmp8 = ifn_592.Invoke_O__O(arg_593) } else { tmp8 = linked_591.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_590, arg_593) }; seq_1657000076__2, chunk_1657000077__3, count_1657000078__4, i_1657000079__5 = tmp8, nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :127:1
							if A_arbace_c_musl_A_const_48 != nil { return nil } else { return nil } } } }
//line :126:1
	panic("j2g: unreachable") }
//line :126:1
func A_arbace_c_musl_refs_walk_meta__1657000094_A_New_O(p0 any) *A_arbace_c_musl_refs_walk_meta__1657000094_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_refs_walk_meta__1657000094_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_c_musl_refs_walk_meta__1657000094_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :126:1
func (t *A_arbace_c_musl_refs_walk_meta__1657000094_A) Invoke_O_O__O(self, m__1 any) any { var vec__1657000095__2 any; var root_692 any = A_arbace_c_musl_A_const_60.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, A_arbace_c_musl_attr_names_A_fn_class); var ifn_694 lang.IFn; if














	linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = m__1; if linked_693 == nil { vec__1657000095__2 = ifn_694.Invoke_O__O(arg_695) } else { vec__1657000095__2 = linked_693.(*A_arbace_c_musl_attr_names_A).Invoke_O_O__O(root_692, arg_695) }; var ___3 any = /*line :126:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1657000095__2, lang.RT_IntCast_J__I_NoInit(0), nil); var alias__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000095__2, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___3; if














	jrt.J2g_Truth(alias__4) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.HashSet_Cast(t.F_acc).Add_O__Z(alias__4)).Ref() } else { return nil } }






func A_arbace_c_musl_spit_mk_A_New() *A_arbace_c_musl_spit_mk_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_spit_mk_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_c_musl_spit_mk_A) Ctor() {}
//line :148:1
func (t *A_arbace_c_musl_spit_mk_A) Invoke_O_O_O__O(self, path__0, s__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_New_String(jrt.String_Cast(path__0)).GetParentFile__File().Mkdirs__Z())
	return lang.IFn_Cast(A_arbace_c_musl_A_const_82.GetRawRoot__O()).Invoke_O_O__O(path__0, s__1)
}
func A_arbace_c_musl_read_one_A_New() *A_arbace_c_musl_read_one_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_one_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_c_musl_read_one_A) Ctor() {}
//line :152:1
func (t *A_arbace_c_musl_read_one_A) Invoke_O_O_O_O__O(self, h__0, root__1, src__2 any) any { var vec__1657000105__4 any; var root_735 any = A_arbace_c_musl_A_const_83.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, A_arbace_c_musl_config_A_fn_class); var ifn_737 lang.IFn; if


	linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = h__0; var arg_739 any = root__1; if linked_736 == nil { vec__1657000105__4 = ifn_737.Invoke_O_O__O(arg_738, arg_739) } else { vec__1657000105__4 = linked_736.(*A_arbace_c_musl_config_A).Invoke_O_O_O__O(root_735, arg_738, arg_739) }; var fc__5 any = /*line :152:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1657000105__4, lang.RT_IntCast_J__I_NoInit(0), nil); var cfg__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000105__4, lang.RT_IntCast_J__I_NoInit(1), nil); var rd__7 any; var root_756 any = A_arbace_c_musl_A_const_90.GetRawRoot__O(); var linked_757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_756, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_758 lang.IFn; if




	linked_757 == nil { ifn_758 = lang.IFn_Cast(root_756) } else { ifn_758 = nil }; var arg_759 any = lang.IFn_Cast(A_arbace_c_musl_A_const_91.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c_musl_A_const_92, jrt.Boolean_TRUE.Ref()); if linked_757 == nil { ifn_758.Invoke_O__O(arg_759) } else { linked_757.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_756, arg_759) }; var tmp1 *lang.Compiler_AOTFn; var fnbody__751 any = A_arbace_c_musl_read_one_fn__1657000108_A_New_O_O_O(src__2, fc__5, cfg__6); var tmp2 *jrt.Class; var fncls__750 *jrt.Class = A_arbace_c_musl_read_one_fn__1657000108_A_fn_class; if fncls__750 == nil { var fncls__750d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, fnbody__751); A_arbace_c_musl_read_one_fn__1657000108_A_fn_class = fncls__750d; tmp2 = fncls__750d } else { tmp2 = fncls__750 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__751, tmp2, nil); rd__7 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O(); if
	jrt.J2g_Truth(A_arbace_c_musl_A_const_86.Invoke_O__O(rd__7)) { var tmp3 any = A_arbace_c_musl_A_const_86; var tmp4 any; var root_765 any = A_arbace_c_musl_A_const_93.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_767 lang.IFn
		if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any = Lit_67; var arg_769 any; var root_770 any = A_arbace_c_musl_A_const_94.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_take_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = A_arbace_c_musl_A_const_73; var arg_774 any = A_arbace_c_musl_A_const_86.Invoke_O__O(rd__7); if linked_771 == nil { arg_769 = ifn_772.Invoke_O_O__O(arg_773, arg_774) } else { arg_769 = linked_771.(*aot_arbace_core.A_arbace_core_take_A).Invoke_O_O_O__O(root_770, arg_773, arg_774) }; if linked_766 == nil { tmp4 = ifn_767.Invoke_O_O__O(arg_768, arg_769) } else { tmp4 = linked_766.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_765, arg_768, arg_769) }
//line :158:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } else { if jrt.J2g_Truth(A_arbace_c_musl_A_const_87.Invoke_O__O(rd__7)) { var tmp5 any = A_arbace_c_musl_A_const_86; return lang.Tuple_Create_O_O__IPersistentVector(tmp5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_68, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_c_musl_A_const_87.Invoke_O__O(rd__7), nil, A_arbace_c_musl_A_const_95.Invoke_O__O(rd__7))).Ref()) } else { if A_arbace_c_musl_A_const_48 != nil { var fr__8 any; var root_752 any = A_arbace_c_musl_A_const_88.GetRawRoot__O(); var linked_753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_752, A_arbace_c_musl_forms_root_A_fn_class); var ifn_754 lang.IFn


			if linked_753 == nil { ifn_754 = lang.IFn_Cast(root_752) } else { ifn_754 = nil }; var arg_755 any = root__1; if linked_753 == nil { fr__8 = ifn_754.Invoke_O__O(arg_755) } else { fr__8 = linked_753.(*A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_752, arg_755) }
//line :158:1
			var seq_1657000110__9 any; var root_775 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_775, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_777 lang.IFn



			if linked_776 == nil { ifn_777 = lang.IFn_Cast(root_775) } else { ifn_777 = nil }; var arg_778 any; var root_779 any = A_arbace_c_musl_A_const_96.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_repr_c.A_arbace_repr_c_unit_texts_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = rd__7; var arg_783 any = src__2; if linked_780 == nil { arg_778 = ifn_781.Invoke_O_O__O(arg_782, arg_783) } else { arg_778 = linked_780.(*aot_arbace_repr_c.A_arbace_repr_c_unit_texts_A).Invoke_O_O_O__O(root_779, arg_782, arg_783) }; if linked_776 == nil { seq_1657000110__9 = ifn_777.Invoke_O__O(arg_778) } else { seq_1657000110__9 = linked_776.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_775, arg_778) }
//line :158:1
			var chunk_1657000111__10 any; var count_1657000112__11 int64 = 0; var i_1657000113__12 int64 = 0; L1: for {



				if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000113__12, count_1657000112__11) { var vec__1657000114__13 any = lang.Indexed_Cast(chunk_1657000111__10).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000113__12)); var p__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000114__13, lang.RT_IntCast_J__I_NoInit(0), nil); var t__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000114__13, lang.RT_IntCast_J__I_NoInit(1), nil); var out__16 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil), jrt.RefArrayOf(jrt.Object_class, fr__8, nil, p__14)).Ref(); var tmp6 bool; var and__1927000168__auto____17 bool = jrt.NN(jrt.String_Cast(p__14)).StartsWith_String__Z(Lit_69)

					if and__1927000168__auto____17 { tmp6 = jrt.File_New_String(jrt.String_Cast(out__16)).Exists__Z() } else { tmp6 = and__1927000168__auto____17 }; if tmp6 { } else {
						var root_822 any = A_arbace_c_musl_A_const_97.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, A_arbace_c_musl_spit_mk_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = out__16; var arg_826 any = t__15; if linked_823 == nil { ifn_824.Invoke_O_O__O(arg_825, arg_826) } else { linked_823.(*A_arbace_c_musl_spit_mk_A).Invoke_O_O_O__O(root_822, arg_825, arg_826) } }
//line :162:1
					seq_1657000110__9, chunk_1657000111__10, count_1657000112__11, i_1657000113__12 = seq_1657000110__9, chunk_1657000111__10, count_1657000112__11, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000113__12); continue L1 } else { var temp__1927000414__auto____13 any; var root_784 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_784, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_786 lang.IFn; if linked_785 == nil { ifn_786 = lang.IFn_Cast(root_784) } else { ifn_786 = nil }; var arg_787 any = seq_1657000110__9; if linked_785 == nil { temp__1927000414__auto____13 = ifn_786.Invoke_O__O(arg_787) } else { temp__1927000414__auto____13 = linked_785.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_784, arg_787) }; if jrt.J2g_Truth(temp__1927000414__auto____13) { var seq_1657000110__14 any = temp__1927000414__auto____13; var tmp7 any; var root_788 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_788, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_790 lang.IFn; if linked_789 == nil { ifn_790 = lang.IFn_Cast(root_788) } else { ifn_790 = nil }; var arg_791 any = seq_1657000110__14; if linked_789 == nil { tmp7 = ifn_790.Invoke_O__O(arg_791) } else { tmp7 = linked_789.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_788, arg_791) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____15 any; var root_792 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_792, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_794 lang.IFn; if linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = seq_1657000110__14; if linked_793 == nil { c__1927000678__auto____15 = ifn_794.Invoke_O__O(arg_795) } else { c__1927000678__auto____15 = linked_793.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_792, arg_795) }; var tmp8 any; var root_827 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = seq_1657000110__14; if linked_828 == nil { tmp8 = ifn_829.Invoke_O__O(arg_830) } else { tmp8 = linked_828.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_827, arg_830) }; seq_1657000110__9, chunk_1657000111__10, count_1657000112__11, i_1657000113__12 = tmp8, c__1927000678__auto____15, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1657000117__15 any; var root_796 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_796, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_798 lang.IFn; if linked_797 == nil { ifn_798 = lang.IFn_Cast(root_796) } else { ifn_798 = nil }; var arg_799 any = seq_1657000110__14; if linked_797 == nil { vec__1657000117__15 = ifn_798.Invoke_O__O(arg_799) } else { vec__1657000117__15 = linked_797.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_796, arg_799) }; var p__16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000117__15, lang.RT_IntCast_J__I_NoInit(0), nil); var t__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000117__15, lang.RT_IntCast_J__I_NoInit(1), nil); var out__18 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil), jrt.RefArrayOf(jrt.Object_class, fr__8, nil, p__16)).Ref(); var tmp9 bool; var and__1927000168__auto____19 bool = jrt.NN(jrt.String_Cast(p__16)).StartsWith_String__Z(Lit_69)

						if and__1927000168__auto____19 { tmp9 = jrt.File_New_String(jrt.String_Cast(out__18)).Exists__Z() } else { tmp9 = and__1927000168__auto____19 }; if tmp9 { } else {
							var root_831 any = A_arbace_c_musl_A_const_97.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, A_arbace_c_musl_spit_mk_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = out__18; var arg_835 any = t__17; if linked_832 == nil { ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { linked_832.(*A_arbace_c_musl_spit_mk_A).Invoke_O_O_O__O(root_831, arg_834, arg_835) } }
//line :162:1
						var tmp10 any; var root_836 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_838 lang.IFn; if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = seq_1657000110__14; if linked_837 == nil { tmp10 = ifn_838.Invoke_O__O(arg_839) } else { tmp10 = linked_837.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_836, arg_839) }; seq_1657000110__9, chunk_1657000111__10, count_1657000112__11, i_1657000113__12 = tmp10, nil, 0, 0; continue L1 } } }
//line :158:1
				break L1
			}






			var root_800 any = A_arbace_c_musl_A_const_97.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, A_arbace_c_musl_spit_mk_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, fr__8, nil, src__2, nil)).Ref(); var arg_804 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_98.GetRawRoot__O()); var tmp12 any; var root_809 any = A_arbace_c_musl_A_const_23.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any; var root_813 any = A_arbace_c_musl_A_const_99.GetRawRoot__O(); var linked_814 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_813, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_815 lang.IFn; if linked_814 == nil { ifn_815 = lang.IFn_Cast(root_813) } else { ifn_815 = nil }; var arg_816 any = A_arbace_c_musl_A_const_100.GetRawRoot__O(); var arg_817 any; var root_818 any = A_arbace_c_musl_A_const_101.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = A_arbace_c_musl_A_const_102.Invoke_O__O(rd__7); if linked_819 == nil { arg_817 = ifn_820.Invoke_O__O(arg_821) } else { arg_817 = linked_819.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_818, arg_821) }; if linked_814 == nil { arg_812 = ifn_815.Invoke_O_O__O(arg_816, arg_817) } else { arg_812 = linked_814.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_813, arg_816, arg_817) }; if linked_810 == nil { tmp12 = ifn_811.Invoke_O__O(arg_812) } else { tmp12 = linked_810.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_809, arg_812) }; arg_804 = tmp11.Invoke_O__O(tmp12); if linked_801 == nil { ifn_802.Invoke_O_O__O(arg_803, arg_804) } else { linked_801.(*A_arbace_c_musl_spit_mk_A).Invoke_O_O_O__O(root_800, arg_803, arg_804) }
//line :158:1
			return A_arbace_c_musl_A_const_89 } else { return nil } } } }
//line :157:1
func A_arbace_c_musl_read_one_fn__1657000108_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_musl_read_one_fn__1657000108_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_one_fn__1657000108_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :157:1
func (t *A_arbace_c_musl_read_one_fn__1657000108_A) Ctor_O_O_O(c__src, c__fc, c__cfg any) { t.F_src = c__src; t.F_fc = c__fc; t.F_cfg = c__cfg }
//line :157:1
func (t *A_arbace_c_musl_read_one_fn__1657000108_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_740 any = A_arbace_c_musl_A_const_84.GetRawRoot__O(); var linked_741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_740, aot_arbace_repr_c.A_arbace_repr_c_read_c_A_fn_class); var ifn_742 lang.IFn; if linked_741 == nil { ifn_742 = lang.IFn_Cast(root_740) } else { ifn_742 = nil }; var arg_743 any; var t_ any = t.F_cfg; t.F_cfg = nil; arg_743 = t_; var arg_744 any; var t__2 any = t.F_fc; t.F_fc = nil; arg_744 = t__2; var arg_745 any; var t__3 any = t.F_src; t.F_src = nil; arg_745 = t__3; var arg_746 any = jrt.Boolean_FALSE.Ref(); if linked_741 == nil { tmp1 = ifn_742.Invoke_O_O_O_O__O(arg_743, arg_744, arg_745, arg_746) } else { tmp1 = linked_741.(*aot_arbace_repr_c.A_arbace_repr_c_read_c_A).Invoke_O_O_O_O_O__O(root_740, arg_743, arg_744, arg_745, arg_746) } }; return nil }(); var root_747 any = A_arbace_c_musl_A_const_85.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; if linked_748 == nil { ifn_749.Invoke__O() } else { linked_748.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_747) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }











func A_arbace_c_musl_read_all_A_New() *A_arbace_c_musl_read_all_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_c_musl_read_all_A) Ctor() {}
//line :169:1
func (t *A_arbace_c_musl_read_all_A) Invoke_O_O_O_O__O(self, h__0, root__1, threads__2 any) any { var srcs__4 any; var root_840 any = A_arbace_c_musl_A_const_103.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, A_arbace_c_musl_sources_A_fn_class); var ifn_842 lang.IFn; if


	linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = root__1; if linked_841 == nil { srcs__4 = ifn_842.Invoke_O__O(arg_843) } else { srcs__4 = linked_841.(*A_arbace_c_musl_sources_A).Invoke_O_O__O(root_840, arg_843) }; var fr__5 any; var root_844 any = /*line :169:1*/A_arbace_c_musl_A_const_88.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, A_arbace_c_musl_forms_root_A_fn_class); var ifn_846 lang.IFn; if



	linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = root__1; if linked_845 == nil { fr__5 = ifn_846.Invoke_O__O(arg_847) } else { fr__5 = linked_845.(*A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_844, arg_847) }; var todo__6 any; var root_848 any = /*line :169:1*/A_arbace_c_musl_A_const_23.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_850 lang.IFn; if




	linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any; var root_852 any = A_arbace_c_musl_A_const_104.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any; var fnbody__858 any = A_arbace_c_musl_read_all_fn__1657000122_A_New_O(fr__5); var tmp1 *jrt.Class; var fncls__857 *jrt.Class = A_arbace_c_musl_read_all_fn__1657000122_A_fn_class; if fncls__857 == nil { var fncls__857d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__858); A_arbace_c_musl_read_all_fn__1657000122_A_fn_class = fncls__857d; tmp1 = fncls__857d } else { tmp1 = fncls__857 }; arg_855 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__858, tmp1, nil); var arg_856 any = srcs__4; if linked_853 == nil { arg_851 = ifn_854.Invoke_O_O__O(arg_855, arg_856) } else { arg_851 = linked_853.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_852, arg_855, arg_856) }; if linked_849 == nil { todo__6 = ifn_850.Invoke_O__O(arg_851) } else { todo__6 = linked_849.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_848, arg_851) }; var errs__7 any = /*line :169:1*/jrt.ConcurrentHashMap_New(); var q__8 any = jrt.ConcurrentLinkedQueue_New_Collection(jrt.Collection_Cast(todo__6)); var n__9 any; var root_859 any = A_arbace_c_musl_A_const_41.GetRawRoot__O(); var linked_860 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_859, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_861 lang.IFn; if







	linked_860 == nil { ifn_861 = lang.IFn_Cast(root_859) } else { ifn_861 = nil }; var arg_862 any = A_arbace_c_musl_A_const_105; if linked_860 == nil { n__9 = ifn_861.Invoke_O__O(arg_862) } else { n__9 = linked_860.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_859, arg_862) }; var workers__10 any; var root_863 any = /*line :169:1*/A_arbace_c_musl_A_const_106.GetRawRoot__O(); var linked_864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_863, aot_arbace_core.A_arbace_core_doall_A_fn_class); var ifn_865 lang.IFn; if








	linked_864 == nil { ifn_865 = lang.IFn_Cast(root_863) } else { ifn_865 = nil }; var arg_866 any; var iter__1927001039__auto____10 any; var fnbody__1046 any = A_arbace_c_musl_read_all_iter__1657000124__1657000128_A_New_O_O_O_O_O_O(todo__6, root__1, n__9, h__0, errs__7, q__8); var tmp2 *jrt.Class; var fncls__1045 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000124__1657000128_A_fn_class; if fncls__1045 == nil { var fncls__1045d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__1046); A_arbace_c_musl_read_all_iter__1657000124__1657000128_A_fn_class = fncls__1045d; tmp2 = fncls__1045d } else { tmp2 = fncls__1045 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1046, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____10); var tmp4 any; var root_1047 any = A_arbace_c_musl_A_const_116.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = threads__2; if linked_1048 == nil { tmp4 = ifn_1049.Invoke_O__O(arg_1050) } else { tmp4 = linked_1048.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1047, arg_1050) }; arg_866 = tmp3.Invoke_O__O(tmp4); if linked_864 == nil { workers__10 = ifn_865.Invoke_O__O(arg_866) } else { workers__10 = linked_864.(*aot_arbace_core.A_arbace_core_doall_A).Invoke_O_O__O(root_863, arg_866) }; var seq_1657000146__11 any; var root_1056 any = /*line :169:1*/A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1058 lang.IFn; if
















	linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = workers__10; if linked_1057 == nil { seq_1657000146__11 = ifn_1058.Invoke_O__O(arg_1059) } else { seq_1657000146__11 = linked_1057.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1056, arg_1059) }; var chunk_1657000147__12 any; var count_1657000148__13 int64 = 0; var i_1657000149__14 int64 = 0; L1:
//line :169:1
	for {
















		if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000149__14, count_1657000148__13) { var w__15 any = lang.Indexed_Cast(chunk_1657000147__12).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000149__14)); var root_1076 any = A_arbace_c_musl_A_const_9.GetRawRoot__O(); var linked_1077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1076, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1078 lang.IFn; if linked_1077 == nil { ifn_1078 = lang.IFn_Cast(root_1076) } else { ifn_1078 = nil }; var arg_1079 any = w__15; if linked_1077 == nil { ifn_1078.Invoke_O__O(arg_1079) } else { linked_1077.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1076, arg_1079) }; seq_1657000146__11, chunk_1657000147__12, count_1657000148__13, i_1657000149__14 = seq_1657000146__11, chunk_1657000147__12, count_1657000148__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000149__14); continue L1 } else { var temp__1927000414__auto____15 any; var root_1060 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any = seq_1657000146__11; if linked_1061 == nil { temp__1927000414__auto____15 = ifn_1062.Invoke_O__O(arg_1063) } else { temp__1927000414__auto____15 = linked_1061.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1060, arg_1063) }; if jrt.J2g_Truth(temp__1927000414__auto____15) { var seq_1657000146__16 any = temp__1927000414__auto____15; var tmp5 any; var root_1064 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = seq_1657000146__16; if linked_1065 == nil { tmp5 = ifn_1066.Invoke_O__O(arg_1067) } else { tmp5 = linked_1065.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1064, arg_1067) }; if jrt.J2g_Truth(tmp5) { var c__1927000678__auto____17 any; var root_1068 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = seq_1657000146__16; if linked_1069 == nil { c__1927000678__auto____17 = ifn_1070.Invoke_O__O(arg_1071) } else { c__1927000678__auto____17 = linked_1069.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1068, arg_1071) }; var tmp6 any; var root_1080 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = seq_1657000146__16; if linked_1081 == nil { tmp6 = ifn_1082.Invoke_O__O(arg_1083) } else { tmp6 = linked_1081.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1080, arg_1083) }; seq_1657000146__11, chunk_1657000147__12, count_1657000148__13, i_1657000149__14 = tmp6, c__1927000678__auto____17, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var w__17 any; var root_1072 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1072, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1074 lang.IFn; if linked_1073 == nil { ifn_1074 = lang.IFn_Cast(root_1072) } else { ifn_1074 = nil }; var arg_1075 any = seq_1657000146__16; if linked_1073 == nil { w__17 = ifn_1074.Invoke_O__O(arg_1075) } else { w__17 = linked_1073.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1072, arg_1075) }; var root_1084 any = A_arbace_c_musl_A_const_9.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1086 lang.IFn; if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = w__17; if linked_1085 == nil { ifn_1086.Invoke_O__O(arg_1087) } else { linked_1085.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1084, arg_1087) }; var tmp7 any; var root_1088 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = seq_1657000146__16; if linked_1089 == nil { tmp7 = ifn_1090.Invoke_O__O(arg_1091) } else { tmp7 = linked_1089.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1088, arg_1091) }; seq_1657000146__11, chunk_1657000147__12, count_1657000148__13, i_1657000149__14 = tmp7, nil, 0, 0; continue L1 } } }
//line :169:1
		break L1 }; var root_1051 any =

















	A_arbace_c_musl_A_const_57.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1053 lang.IFn; if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1055 any = errs__7; if linked_1052 == nil { return ifn_1053.Invoke_O_O__O(arg_1054, arg_1055) } else { return linked_1052.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1051, arg_1054, arg_1055) } }
//line :174:1
func A_arbace_c_musl_read_all_fn__1657000122_A_New_O(p0 any) *A_arbace_c_musl_read_all_fn__1657000122_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_fn__1657000122_A{}; t.Ctor_O(p0); return t }
//line :174:1
func (t *A_arbace_c_musl_read_all_fn__1657000122_A) Ctor_O(c__fr any) { t.F_fr = c__fr }
//line :174:1
func (t *A_arbace_c_musl_read_all_fn__1657000122_A) Invoke_O_O__O(self, p1__1657000121_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, t.F_fr, nil, p1__1657000121_SHARP___1, nil))).Exists__Z()).Ref() }



func A_arbace_c_musl_read_all_iter__1657000124__1657000128_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c_musl_read_all_iter__1657000124__1657000128_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000124__1657000128_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :178:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_A) Ctor_O_O_O_O_O_O(c__todo, c__root, c__n, c__h, c__errs, c__q any) { t.F_todo = c__todo; t.F_root = c__root; t.F_n = c__n; t.F_h = c__h; t.F_errs = c__errs; t.F_q = c__q }
//line :178:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_A) Invoke_O_O__O(self, s__1657000125__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1044 any = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_A_New_O_O_O_O_O_O_O_O(t.F_todo, t.F_root, self, t.F_n, t.F_h, t.F_errs, t.F_q, s__1657000125__1); var tmp2 *jrt.Class; var fncls__1043 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_A_fn_class; if fncls__1043 == nil { var fncls__1043d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__1044); A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_A_fn_class = fncls__1043d; tmp2 = fncls__1043d } else { tmp2 = fncls__1043 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1044, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :178:1
func A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :178:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_A) Ctor_O_O_O_O_O_O_O_O(c__todo, c__root, c__iter__1657000124, c__n, c__h, c__errs, c__q, c__s__1657000125 any) { t.F_todo = c__todo; t.F_root = c__root; t.F_iter__1657000124 = c__iter__1657000124; t.F_n = c__n; t.F_h = c__h; t.F_errs = c__errs; t.F_q = c__q; t.F_s__1657000125 = c__s__1657000125 }
//line :178:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_A) Invoke_O__O(self any) any { { var s__1657000125__1 any; var t_ any = t.F_s__1657000125; t.F_s__1657000125 = nil; s__1657000125__1 = t_; for { var temp__1927000414__auto____2 any; var root_867 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_869 lang.IFn; if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = s__1657000125__1; if linked_868 == nil { temp__1927000414__auto____2 = ifn_869.Invoke_O__O(arg_870) } else { temp__1927000414__auto____2 = linked_868.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_867, arg_870) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1657000125__3 any = temp__1927000414__auto____2; var tmp1 any; var root_871 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any = s__1657000125__3; if linked_872 == nil { tmp1 = ifn_873.Invoke_O__O(arg_874) } else { tmp1 = linked_872.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_871, arg_874) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_875 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = s__1657000125__3; if linked_876 == nil { c__1927001037__auto____4 = ifn_877.Invoke_O__O(arg_878) } else { c__1927001037__auto____4 = linked_876.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_875, arg_878) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1657000127__6 any; var root_879 any = A_arbace_c_musl_A_const_32.GetRawRoot__O(); var linked_880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_879, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_881 lang.IFn; if linked_880 == nil { ifn_881 = lang.IFn_Cast(root_879) } else { ifn_881 = nil }; var arg_882 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_880 == nil { b__1657000127__6 = ifn_881.Invoke_O__O(arg_882) } else { b__1657000127__6 = linked_880.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_879, arg_882) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__948 any = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_A_New_O_O_O_O_O_O_O_I_O(t.F_todo, t.F_root, t.F_n, t.F_h, t.F_errs, t.F_q, b__1657000127__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__947 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_A_fn_class; if fncls__947 == nil { var fncls__947d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__948); A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_A_fn_class = fncls__947d; tmp3 = fncls__947d } else { tmp3 = fncls__947 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__948, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_949 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_951 lang.IFn; if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any; var root_954 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = b__1657000127__6; if linked_955 == nil { arg_952 = ifn_956.Invoke_O__O(arg_957) } else { arg_952 = linked_955.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_954, arg_957) }; var arg_953 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1657000124); var tmp5 any; var root_958 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_958, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_960 lang.IFn; if linked_959 == nil { ifn_960 = lang.IFn_Cast(root_958) } else { ifn_960 = nil }; var arg_961 any = s__1657000125__3; if linked_959 == nil { tmp5 = ifn_960.Invoke_O__O(arg_961) } else { tmp5 = linked_959.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_958, arg_961) }; arg_953 = tmp4.Invoke_O__O(tmp5); if linked_950 == nil { return ifn_951.Invoke_O_O__O(arg_952, arg_953) } else { return linked_950.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_949, arg_952, arg_953) } } else { var root_962 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_963 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_962, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_964 lang.IFn; if linked_963 == nil { ifn_964 = lang.IFn_Cast(root_962) } else { ifn_964 = nil }; var arg_965 any; var root_967 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_967, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_969 lang.IFn; if linked_968 == nil { ifn_969 = lang.IFn_Cast(root_967) } else { ifn_969 = nil }; var arg_970 any = b__1657000127__6; if linked_968 == nil { arg_965 = ifn_969.Invoke_O__O(arg_970) } else { arg_965 = linked_968.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_967, arg_970) }; var arg_966 any; if linked_963 == nil { return ifn_964.Invoke_O_O__O(arg_965, arg_966) } else { return linked_963.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_962, arg_965, arg_966) } } } else { var ___4 any; var root_971 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_973 lang.IFn; _ = ___4; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any = s__1657000125__3; if linked_972 == nil { ___4 = ifn_973.Invoke_O__O(arg_974) } else { ___4 = linked_972.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_971, arg_974) }; var root_975 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_975, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_977 lang.IFn; if linked_976 == nil { ifn_977 = lang.IFn_Cast(root_975) } else { ifn_977 = nil }; var arg_978 any; var root_980 any = A_arbace_c_musl_A_const_107.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_982 lang.IFn
														if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any; var fnbody__1038 any = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_A_New_O_O_O_O_O_O(t.F_todo, t.F_root, t.F_n, t.F_h, t.F_errs, t.F_q); var tmp6 *jrt.Class; var fncls__1037 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_A_fn_class; if fncls__1037 == nil { var fncls__1037d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__1038); A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_A_fn_class = fncls__1037d; tmp6 = fncls__1037d } else { tmp6 = fncls__1037 }; arg_983 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1038, tmp6, nil); if linked_981 == nil { arg_978 = ifn_982.Invoke_O__O(arg_983) } else { arg_978 = linked_981.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_980, arg_983) }
//line :178:1
	var arg_979 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1657000124); var tmp8 any; var root_1039 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = s__1657000125__3; if linked_1040 == nil { tmp8 = ifn_1041.Invoke_O__O(arg_1042) } else { tmp8 = linked_1040.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1039, arg_1042) }; arg_979 = tmp7.Invoke_O__O(tmp8); if linked_976 == nil { return ifn_977.Invoke_O_O__O(arg_978, arg_979) } else { return linked_976.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_975, arg_978, arg_979) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :178:1
func A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_A_New_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6 any, p7 int32, p8 any) *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_A{}; t.Ctor_O_O_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :178:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_A) Ctor_O_O_O_O_O_O_O_I_O(c__todo, c__root, c__n, c__h, c__errs, c__q, c__b__1657000127 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_todo = c__todo; t.F_root = c__root; t.F_n = c__n; t.F_h = c__h; t.F_errs = c__errs; t.F_q = c__q; t.F_b__1657000127 = c__b__1657000127; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :178:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_A) Invoke_O__O(self any) any { { var i__1657000126__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1657000126__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var ___2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1657000126__1)); var root_883 any = A_arbace_c_musl_A_const_34.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_885 lang.IFn; _ = ___2; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = t.F_b__1657000127; var arg_887 any; var root_888 any = A_arbace_c_musl_A_const_107.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_890 lang.IFn
																if linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any; var fnbody__946 any = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_A_New_O_O_O_O_O_O(t.F_todo, t.F_root, t.F_n, t.F_h, t.F_errs, t.F_q); var tmp2 *jrt.Class; var fncls__945 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_A_fn_class; if fncls__945 == nil { var fncls__945d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__946); A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_A_fn_class = fncls__945d; tmp2 = fncls__945d } else { tmp2 = fncls__945 }; arg_891 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__946, tmp2, nil); if linked_889 == nil { arg_887 = ifn_890.Invoke_O__O(arg_891) } else { arg_887 = linked_889.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_888, arg_891) }
//line :178:1
	if linked_884 == nil { ifn_885.Invoke_O_O__O(arg_886, arg_887) } else { linked_884.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_883, arg_886, arg_887) }; i__1657000126__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000126__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :179:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_A) Ctor_O_O_O_O_O_O(c__todo, c__root, c__n, c__h, c__errs, c__q any) { t.F_todo = c__todo; t.F_root = c__root; t.F_n = c__n; t.F_h = c__h; t.F_errs = c__errs; t.F_q = c__q }
//line :179:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_A) Invoke_O__O(self any) any { for { L2: for { var temp__1927000414__auto____1 any = jrt.NN(jrt.ConcurrentLinkedQueue_Cast(t.F_q)).Poll__O()

	if jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var r__3 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__903 any = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000132_A_New_O_O_O(t.F_root, t.F_h, s__2); var tmp2 *jrt.Class; var fncls__902 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000132_A_fn_class
		if fncls__902 == nil { var fncls__902d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__903); A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000132_A_fn_class = fncls__902d; tmp2 = fncls__902d } else { tmp2 = fncls__902 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__903, tmp2, nil); r__3 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
		var tmp3 any; var root_904 any = A_arbace_c_musl_A_const_46.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = r__3; if linked_905 == nil { tmp3 = ifn_906.Invoke_O__O(arg_907) } else { tmp3 = linked_905.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_904, arg_907) }; if jrt.J2g_Truth(tmp3) { var tmp4 *jrt.ConcurrentHashMap = jrt.ConcurrentHashMap_Cast(t.F_errs); var tmp5 any; var root_908 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = r__3; if linked_909 == nil { tmp5 = ifn_910.Invoke_O__O(arg_911) } else { tmp5 = linked_909.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_908, arg_911) }; jrt.NN(tmp4).Put_O_O__O(s__2, tmp5) }
//line :181:1
		var k__4 any; var root_912 any = A_arbace_c_musl_A_const_109.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_912, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_914 lang.IFn


		if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = t.F_n; var arg_916 any = A_arbace_c_musl_A_const_110.GetRawRoot__O(); if linked_913 == nil { k__4 = ifn_914.Invoke_O_O__O(arg_915, arg_916) } else { k__4 = linked_913.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_912, arg_915, arg_916) }; var tmp6 bool; var na_917 any; var root_918 any = A_arbace_c_musl_A_const_111.GetRawRoot__O(); var linked_919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_918, aot_arbace_core.A_arbace_core_mod_A_fn_class); var ifn_920 lang.IFn; if linked_919 == nil { ifn_920 = lang.IFn_Cast(root_918) } else { ifn_920 = nil }; var arg_921 any = k__4; var arg_922 any = A_arbace_c_musl_A_const_112; if linked_919 == nil { na_917 = ifn_920.Invoke_O_O__O(arg_921, arg_922) } else { na_917 = linked_919.(*aot_arbace_core.A_arbace_core_mod_A).Invoke_O_O_O__O(root_918, arg_921, arg_922) }; if jrt.Long_InstanceOf(na_917) { var n0_923 int64 = jrt.NN(jrt.Long_Cast(na_917)).LongValue__J(); tmp6 = n0_923 == 0 } else { if jrt.Double_InstanceOf(na_917) { var n0_923_2 float64 = jrt.NN(jrt.Double_Cast(na_917)).DoubleValue__D(); tmp6 = n0_923_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_917) } }; if tmp6 { var root_936 any = A_arbace_c_musl_A_const_90.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_91.GetRawRoot__O()); var tmp8 any = A_arbace_c_musl_A_const_114; var arg_939 any = tmp7.Invoke_O_O__O(tmp8, A_arbace_c_musl_A_const_115.Get__O()); if linked_937 == nil { ifn_938.Invoke_O__O(arg_939) } else { linked_937.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_936, arg_939) }; var tmp9 *lang.Compiler_AOTFn; var fnbody__935 any = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000134_A_New_O_O(t.F_todo, k__4); var tmp10 *jrt.Class; var fncls__934 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000134_A_fn_class; if fncls__934 == nil { var fncls__934d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__935); A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000134_A_fn_class = fncls__934d; tmp10 = fncls__934d } else { tmp10 = fncls__934 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__935, tmp10, nil); Up_Compiler_AOTFn_IFn(tmp9).Invoke__O() }
		continue L2 } else {
//line :181:1
			return nil } } }; /*line :179:1*/panic("j2g: unreachable") }
//line :179:1
func A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :179:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_A) Ctor_O_O_O_O_O_O(c__todo, c__root, c__n, c__h, c__errs, c__q any) { t.F_todo = c__todo; t.F_root = c__root; t.F_n = c__n; t.F_h = c__h; t.F_errs = c__errs; t.F_q = c__q }
//line :179:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_A) Invoke_O__O(self any) any { for { L2: for { var temp__1927000414__auto____1 any = jrt.NN(jrt.ConcurrentLinkedQueue_Cast(t.F_q)).Poll__O()

	if jrt.J2g_Truth(temp__1927000414__auto____1) { var s__2 any = temp__1927000414__auto____1; var r__3 any; var tmp1 *lang.Compiler_AOTFn; var fnbody__995 any = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000139_A_New_O_O_O(t.F_root, t.F_h, s__2); var tmp2 *jrt.Class; var fncls__994 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000139_A_fn_class
		if fncls__994 == nil { var fncls__994d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__995); A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000139_A_fn_class = fncls__994d; tmp2 = fncls__994d } else { tmp2 = fncls__994 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__995, tmp2, nil); r__3 = Up_Compiler_AOTFn_IFn(tmp1).Invoke__O()
		var tmp3 any; var root_996 any = A_arbace_c_musl_A_const_46.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = r__3; if linked_997 == nil { tmp3 = ifn_998.Invoke_O__O(arg_999) } else { tmp3 = linked_997.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_996, arg_999) }; if jrt.J2g_Truth(tmp3) { var tmp4 *jrt.ConcurrentHashMap = jrt.ConcurrentHashMap_Cast(t.F_errs); var tmp5 any; var root_1000 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = r__3; if linked_1001 == nil { tmp5 = ifn_1002.Invoke_O__O(arg_1003) } else { tmp5 = linked_1001.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1000, arg_1003) }; jrt.NN(tmp4).Put_O_O__O(s__2, tmp5) }
//line :181:1
		var k__4 any; var root_1004 any = A_arbace_c_musl_A_const_109.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1006 lang.IFn


		if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = t.F_n; var arg_1008 any = A_arbace_c_musl_A_const_110.GetRawRoot__O(); if linked_1005 == nil { k__4 = ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { k__4 = linked_1005.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) }; var tmp6 bool; var na_1009 any; var root_1010 any = A_arbace_c_musl_A_const_111.GetRawRoot__O(); var linked_1011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1010, aot_arbace_core.A_arbace_core_mod_A_fn_class); var ifn_1012 lang.IFn; if linked_1011 == nil { ifn_1012 = lang.IFn_Cast(root_1010) } else { ifn_1012 = nil }; var arg_1013 any = k__4; var arg_1014 any = A_arbace_c_musl_A_const_112; if linked_1011 == nil { na_1009 = ifn_1012.Invoke_O_O__O(arg_1013, arg_1014) } else { na_1009 = linked_1011.(*aot_arbace_core.A_arbace_core_mod_A).Invoke_O_O_O__O(root_1010, arg_1013, arg_1014) }; if jrt.Long_InstanceOf(na_1009) { var n0_1015 int64 = jrt.NN(jrt.Long_Cast(na_1009)).LongValue__J(); tmp6 = n0_1015 == 0 } else { if jrt.Double_InstanceOf(na_1009) { var n0_1015_2 float64 = jrt.NN(jrt.Double_Cast(na_1009)).DoubleValue__D(); tmp6 = n0_1015_2 == 0.0 } else { tmp6 = lang.Numbers_IsZero_O__Z_NoInit(na_1009) } }; if tmp6 { var root_1028 any = A_arbace_c_musl_A_const_90.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_91.GetRawRoot__O()); var tmp8 any = A_arbace_c_musl_A_const_114; var arg_1031 any = tmp7.Invoke_O_O__O(tmp8, A_arbace_c_musl_A_const_115.Get__O()); if linked_1029 == nil { ifn_1030.Invoke_O__O(arg_1031) } else { linked_1029.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1028, arg_1031) }; var tmp9 *lang.Compiler_AOTFn; var fnbody__1027 any = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000141_A_New_O_O(t.F_todo, k__4); var tmp10 *jrt.Class; var fncls__1026 *jrt.Class = A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000141_A_fn_class; if fncls__1026 == nil { var fncls__1026d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__1027); A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000141_A_fn_class = fncls__1026d; tmp10 = fncls__1026d } else { tmp10 = fncls__1026 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1027, tmp10, nil); Up_Compiler_AOTFn_IFn(tmp9).Invoke__O() }
		continue L2 } else {
//line :181:1
			return nil } } }; /*line :179:1*/panic("j2g: unreachable") }


func A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000132_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000132_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000132_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000132_A) Ctor_O_O_O(c__root, c__h, c__s any) { t.F_root = c__root; t.F_h = c__h; t.F_s = c__s }
//line :182:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000132_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_892 any = A_arbace_c_musl_A_const_108.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, A_arbace_c_musl_read_one_A_fn_class); var ifn_894 lang.IFn; if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any; var t_ any = t.F_h; t.F_h = nil; arg_895 = t_; var arg_896 any; var t__2 any = t.F_root; t.F_root = nil; arg_896 = t__2; var arg_897 any; var t__3 any = t.F_s; t.F_s = nil; arg_897 = t__3; if linked_893 == nil { tmp1 = ifn_894.Invoke_O_O_O__O(arg_895, arg_896, arg_897) } else { tmp1 = linked_893.(*A_arbace_c_musl_read_one_A).Invoke_O_O_O_O__O(root_892, arg_895, arg_896, arg_897) } }; return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 any = A_arbace_c_musl_A_const_86; var tmp4 any; var root_898 any = A_arbace_c_musl_A_const_100.GetRawRoot__O(); var linked_899 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_898, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_900 lang.IFn; if linked_899 == nil { ifn_900 = lang.IFn_Cast(root_898) } else { ifn_900 = nil }; var arg_901 any = e__3; if linked_899 == nil { tmp4 = ifn_900.Invoke_O__O(arg_901) } else { tmp4 = linked_899.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_898, arg_901) }; tmp1 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } }; return tmp1 }
//line :182:1
func A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000139_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000139_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000139_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :182:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000139_A) Ctor_O_O_O(c__root, c__h, c__s any) { t.F_root = c__root; t.F_h = c__h; t.F_s = c__s }
//line :182:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000139_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_984 any = A_arbace_c_musl_A_const_108.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, A_arbace_c_musl_read_one_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any; var t_ any = t.F_h; t.F_h = nil; arg_987 = t_; var arg_988 any; var t__2 any = t.F_root; t.F_root = nil; arg_988 = t__2; var arg_989 any; var t__3 any = t.F_s; t.F_s = nil; arg_989 = t__3; if linked_985 == nil { tmp1 = ifn_986.Invoke_O_O_O__O(arg_987, arg_988, arg_989) } else { tmp1 = linked_985.(*A_arbace_c_musl_read_one_A).Invoke_O_O_O_O__O(root_984, arg_987, arg_988, arg_989) } }; return nil }(); if tmp2 != nil { if true { var e__3 jrt.Throwable_I = tmp2; var tmp3 any = A_arbace_c_musl_A_const_86; var tmp4 any; var root_990 any = A_arbace_c_musl_A_const_100.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = e__3; if linked_991 == nil { tmp4 = ifn_992.Invoke_O__O(arg_993) } else { tmp4 = linked_991.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_990, arg_993) }; tmp1 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4) } }; return tmp1 }

func A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000134_A_New_O_O(p0, p1 any) *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000134_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000134_A{}; t.Ctor_O_O(p0, p1); return t }
//line :184:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000134_A) Ctor_O_O(c__todo, c__k any) { t.F_todo = c__todo; t.F_k = c__k }
//line :184:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000134_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_113.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_k; t.F_k = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_todo; t.F_todo = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_62, tmp4, Lit_63, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp5)).Ref()) }; return nil }(); var root_931 any = A_arbace_c_musl_A_const_85.GetRawRoot__O(); var linked_932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_931, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_933 lang.IFn; if linked_932 == nil { ifn_933 = lang.IFn_Cast(root_931) } else { ifn_933 = nil }; if linked_932 == nil { ifn_933.Invoke__O() } else { linked_932.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_931) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }
//line :184:1
func A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000141_A_New_O_O(p0, p1 any) *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000141_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000141_A{}; t.Ctor_O_O(p0, p1); return t }
//line :184:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000141_A) Ctor_O_O(c__todo, c__k any) { t.F_todo = c__todo; t.F_k = c__k }
//line :184:1
func (t *A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000141_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_113.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_k; t.F_k = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_todo; t.F_todo = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O_O_O__O(Lit_62, tmp4, Lit_63, jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp5)).Ref()) }; return nil }(); var root_1023 any = A_arbace_c_musl_A_const_85.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1025 lang.IFn; if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; if linked_1024 == nil { ifn_1025.Invoke__O() } else { linked_1024.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1023) }; if tmp6 != nil { panic(tmp6) }; return tmp1 }




func A_arbace_c_musl_load_forms_A_New() *A_arbace_c_musl_load_forms_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_load_forms_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_c_musl_load_forms_A) Ctor() {}
//line :189:1
func (t *A_arbace_c_musl_load_forms_A) Invoke_O_O_O__O(self, fr__0, src__1 any) any { var vec__1657000152__3 any; var root_1092 any = A_arbace_c_musl_A_const_117.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A_fn_class); var ifn_1094 lang.IFn; if





	linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = lang.IFn_Cast(A_arbace_c_musl_A_const_118.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, fr__0, nil, src__1, nil)).Ref()); if linked_1093 == nil { vec__1657000152__3 = ifn_1094.Invoke_O__O(arg_1095) } else { vec__1657000152__3 = linked_1093.(*aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A).Invoke_O_O__O(root_1092, arg_1095) }; var ___4 any = /*line :189:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1657000152__3, lang.RT_IntCast_J__I_NoInit(0), nil); var forms__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000152__3, lang.RT_IntCast_J__I_NoInit(1), nil); var us__6 any; var root_1100 any = A_arbace_c_musl_A_const_119.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_1102 lang.IFn; _ = ___4; if






	linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = lang.IFn_Cast(A_arbace_c_musl_A_const_118.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, fr__0, nil, src__1, nil)).Ref()); if linked_1101 == nil { us__6 = ifn_1102.Invoke_O__O(arg_1103) } else { us__6 = linked_1101.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_1100, arg_1103) }; var tmp1 any = A_arbace_c_musl_A_const_120; var tmp2 any = A_arbace_c_musl_A_const_102; var tmp3 any; var root_1108 any = /*line :189:1*/A_arbace_c_musl_A_const_57.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1110 lang.IFn; if








	linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1112 any; var iter__1927001039__auto____7 any; var fnbody__1260 any = A_arbace_c_musl_load_forms_iter__1657000155__1657000159_A_New_O(fr__0); var tmp4 *jrt.Class; var fncls__1259 *jrt.Class = A_arbace_c_musl_load_forms_iter__1657000155__1657000159_A_fn_class; if fncls__1259 == nil { var fncls__1259d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__1260); A_arbace_c_musl_load_forms_iter__1657000155__1657000159_A_fn_class = fncls__1259d; tmp4 = fncls__1259d } else { tmp4 = fncls__1259 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1260, tmp4, nil); arg_1112 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(us__6); if linked_1109 == nil { tmp3 = ifn_1110.Invoke_O_O__O(arg_1111, arg_1112) } else { tmp3 = linked_1109.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1108, arg_1111, arg_1112) }; return /*line :189:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, forms__5, tmp2, tmp3)) }








func A_arbace_c_musl_load_forms_iter__1657000155__1657000159_A_New_O(p0 any) *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_load_forms_iter__1657000155__1657000159_A{}; t.Ctor_O(p0); return t }
//line :198:1
func (t *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_A) Ctor_O(c__fr any) { t.F_fr = c__fr }
//line :198:1
func (t *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_A) Invoke_O_O__O(self, s__1657000156__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1258 any = A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_A_New_O_O_O(self, t.F_fr, s__1657000156__1); var tmp2 *jrt.Class; var fncls__1257 *jrt.Class = A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_A_fn_class; if fncls__1257 == nil { var fncls__1257d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__1258); A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_A_fn_class = fncls__1257d; tmp2 = fncls__1257d } else { tmp2 = fncls__1257 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1258, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :198:1
func A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :198:1
func (t *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_A) Ctor_O_O_O(c__iter__1657000155, c__fr, c__s__1657000156 any) { t.F_iter__1657000155 = c__iter__1657000155; t.F_fr = c__fr; t.F_s__1657000156 = c__s__1657000156 }
//line :198:1
func (t *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_A) Invoke_O__O(self any) any { { var s__1657000156__1 any; var t_ any = t.F_s__1657000156; t.F_s__1657000156 = nil; s__1657000156__1 = t_; for { var temp__1927000414__auto____2 any; var root_1113 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = s__1657000156__1; if linked_1114 == nil { temp__1927000414__auto____2 = ifn_1115.Invoke_O__O(arg_1116) } else { temp__1927000414__auto____2 = linked_1114.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1113, arg_1116) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1657000156__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1117 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = s__1657000156__3; if linked_1118 == nil { tmp1 = ifn_1119.Invoke_O__O(arg_1120) } else { tmp1 = linked_1118.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1117, arg_1120) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1121 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = s__1657000156__3; if linked_1122 == nil { c__1927001037__auto____4 = ifn_1123.Invoke_O__O(arg_1124) } else { c__1927001037__auto____4 = linked_1122.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1121, arg_1124) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1657000158__6 any; var root_1125 any = A_arbace_c_musl_A_const_32.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1127 lang.IFn; if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1126 == nil { b__1657000158__6 = ifn_1127.Invoke_O__O(arg_1128) } else { b__1657000158__6 = linked_1126.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1125, arg_1128) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1178 any = A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_A_New_O_O_I_O(b__1657000158__6, t.F_fr, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1177 *jrt.Class = A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_A_fn_class; if fncls__1177 == nil { var fncls__1177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__1178); A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_A_fn_class = fncls__1177d; tmp3 = fncls__1177d } else { tmp3 = fncls__1177 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1178, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1179 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any; var root_1184 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1186 lang.IFn; if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = b__1657000158__6; if linked_1185 == nil { arg_1182 = ifn_1186.Invoke_O__O(arg_1187) } else { arg_1182 = linked_1185.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1184, arg_1187) }; var arg_1183 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1657000155); var tmp5 any; var root_1188 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = s__1657000156__3; if linked_1189 == nil { tmp5 = ifn_1190.Invoke_O__O(arg_1191) } else { tmp5 = linked_1189.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1188, arg_1191) }; arg_1183 = tmp4.Invoke_O__O(tmp5); if linked_1180 == nil { return ifn_1181.Invoke_O_O__O(arg_1182, arg_1183) } else { return linked_1180.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1179, arg_1182, arg_1183) } } else { var root_1192 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any; var root_1197 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_1198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1197, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1199 lang.IFn; if linked_1198 == nil { ifn_1199 = lang.IFn_Cast(root_1197) } else { ifn_1199 = nil }; var arg_1200 any = b__1657000158__6; if linked_1198 == nil { arg_1195 = ifn_1199.Invoke_O__O(arg_1200) } else { arg_1195 = linked_1198.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1197, arg_1200) }; var arg_1196 any; if linked_1193 == nil { return ifn_1194.Invoke_O_O__O(arg_1195, arg_1196) } else { return linked_1193.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1192, arg_1195, arg_1196) } } } else { var u__4 any; var root_1201 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1203 lang.IFn; if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = s__1657000156__3; if linked_1202 == nil { u__4 = ifn_1203.Invoke_O__O(arg_1204) } else { u__4 = linked_1202.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1201, arg_1204) }; var root_1205 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any; var vec__1657000169__5 any; var root_1210 any = A_arbace_c_musl_A_const_117.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A_fn_class); var ifn_1212 lang.IFn
														if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_118.GetRawRoot__O()); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_49, nil, Lit_44); var tmp8 any = t.F_fr; var tmp9 any; var root_1218 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_1219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1218, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1220 lang.IFn; if linked_1219 == nil { ifn_1220 = lang.IFn_Cast(root_1218) } else { ifn_1220 = nil }; var arg_1221 any = u__4; var arg_1222 any = A_arbace_c_musl_A_const_121; if linked_1219 == nil { tmp9 = ifn_1220.Invoke_O_O__O(arg_1221, arg_1222) } else { tmp9 = linked_1219.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1218, arg_1221, arg_1222) }; arg_1213 = tmp6.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, nil, tmp9, nil)).Ref()); if linked_1211 == nil { vec__1657000169__5 = ifn_1212.Invoke_O__O(arg_1213) } else { vec__1657000169__5 = linked_1211.(*aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A).Invoke_O_O__O(root_1210, arg_1213) }
//line :198:1
	var hf__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000169__5, lang.RT_IntCast_J__I_NoInit(0), nil); var hforms__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000169__5, lang.RT_IntCast_J__I_NoInit(1), nil); var path__8 any; var root_1223 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_1224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1223, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1225 lang.IFn

	if linked_1224 == nil { ifn_1225 = lang.IFn_Cast(root_1223) } else { ifn_1225 = nil }; var arg_1226 any; var root_1227 any = A_arbace_c_musl_A_const_122.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, aot_arbace_core.A_arbace_core_drop_while_A_fn_class); var ifn_1229 lang.IFn; if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any; var fnbody__1238 any = A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000172_A_New(); var tmp10 *jrt.Class; var fncls__1237 *jrt.Class = A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000172_A_fn_class; if fncls__1237 == nil { var fncls__1237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, nil); A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000172_A_fn_class = fncls__1237d; tmp10 = fncls__1237d } else { tmp10 = fncls__1237 }; arg_1230 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1238, tmp10, nil); var arg_1231 any = hf__6; if linked_1228 == nil { arg_1226 = ifn_1229.Invoke_O_O__O(arg_1230, arg_1231) } else { arg_1226 = linked_1228.(*aot_arbace_core.A_arbace_core_drop_while_A).Invoke_O_O_O__O(root_1227, arg_1230, arg_1231) }; if linked_1224 == nil { path__8 = ifn_1225.Invoke_O__O(arg_1226) } else { path__8 = linked_1224.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1223, arg_1226) }
//line :198:1
	var tmp11 any; var root_1239 any = A_arbace_c_musl_A_const_125.GetRawRoot__O(); var linked_1240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1239, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1241 lang.IFn


	if linked_1240 == nil { ifn_1241 = lang.IFn_Cast(root_1239) } else { ifn_1241 = nil }; var arg_1242 any = u__4; if linked_1240 == nil { tmp11 = ifn_1241.Invoke_O__O(arg_1242) } else { tmp11 = linked_1240.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1239, arg_1242) }
//line :198:1
	var tmp12 any = tmp11; var tmp13 any; var G__1657000174__9_ any; var tmp14 any = A_arbace_c_musl_A_const_120; var tmp15 any = A_arbace_c_musl_A_const_126; var tmp16 any; var root_1243 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_1244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1243, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1245 lang.IFn


	if linked_1244 == nil { ifn_1245 = lang.IFn_Cast(root_1243) } else { ifn_1245 = nil }; var arg_1246 any = hf__6; if linked_1244 == nil { tmp16 = ifn_1245.Invoke_O__O(arg_1246) } else { tmp16 = linked_1244.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1243, arg_1246) }
//line :198:1
	G__1657000174__9_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, hforms__7, tmp15, tmp16))


	if jrt.J2g_Truth(path__8) { var root_1247 any = A_arbace_c_musl_A_const_17.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1247, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any = G__1657000174__9_; var arg_1251 any = A_arbace_c_musl_A_const_124; var arg_1252 any = path__8; if linked_1248 == nil { tmp13 = ifn_1249.Invoke_O_O_O__O(arg_1250, arg_1251, arg_1252) } else { tmp13 = linked_1248.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1247, arg_1250, arg_1251, arg_1252) } } else { tmp13 = G__1657000174__9_ }
//line :198:1
	arg_1208 = lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13); var arg_1209 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__1657000155); var tmp18 any; var root_1253 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = s__1657000156__3; if linked_1254 == nil { tmp18 = ifn_1255.Invoke_O__O(arg_1256) } else { tmp18 = linked_1254.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1253, arg_1256) }; arg_1209 = tmp17.Invoke_O__O(tmp18); if linked_1206 == nil { return ifn_1207.Invoke_O_O__O(arg_1208, arg_1209) } else { return linked_1206.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1205, arg_1208, arg_1209) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :198:1
func A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :198:1
func (t *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_A) Ctor_O_O_I_O(c__b__1657000158, c__fr any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1657000158 = c__b__1657000158; t.F_fr = c__fr; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :198:1
func (t *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_A) Invoke_O__O(self any) any { { var i__1657000157__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1657000157__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var u__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1657000157__1)); var root_1129 any = A_arbace_c_musl_A_const_34.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = t.F_b__1657000158; var arg_1133 any; var vec__1657000162__3 any; var root_1134 any = A_arbace_c_musl_A_const_117.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A_fn_class); var ifn_1136 lang.IFn
																if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_118.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_49, nil, Lit_44); var tmp4 any = t.F_fr; var tmp5 any; var root_1142 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any = u__2; var arg_1146 any = A_arbace_c_musl_A_const_121; if linked_1143 == nil { tmp5 = ifn_1144.Invoke_O_O__O(arg_1145, arg_1146) } else { tmp5 = linked_1143.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1142, arg_1145, arg_1146) }; arg_1137 = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, nil, tmp5, nil)).Ref()); if linked_1135 == nil { vec__1657000162__3 = ifn_1136.Invoke_O__O(arg_1137) } else { vec__1657000162__3 = linked_1135.(*aot_arbace_repr_c.A_arbace_repr_c_read_unit_text_A).Invoke_O_O__O(root_1134, arg_1137) }
//line :198:1
	var hf__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000162__3, lang.RT_IntCast_J__I_NoInit(0), nil); var hforms__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000162__3, lang.RT_IntCast_J__I_NoInit(1), nil); var path__6 any; var root_1147 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1149 lang.IFn

	if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any; var root_1151 any = A_arbace_c_musl_A_const_122.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, aot_arbace_core.A_arbace_core_drop_while_A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any; var fnbody__1162 any = A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_fn__1657000165_A_New(); var tmp6 *jrt.Class; var fncls__1161 *jrt.Class = A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_fn__1657000165_A_fn_class; if fncls__1161 == nil { var fncls__1161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_fn__1657000165_A_fn_class = fncls__1161d; tmp6 = fncls__1161d } else { tmp6 = fncls__1161 }; arg_1154 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1162, tmp6, nil); var arg_1155 any = hf__4; if linked_1152 == nil { arg_1150 = ifn_1153.Invoke_O_O__O(arg_1154, arg_1155) } else { arg_1150 = linked_1152.(*aot_arbace_core.A_arbace_core_drop_while_A).Invoke_O_O_O__O(root_1151, arg_1154, arg_1155) }; if linked_1148 == nil { path__6 = ifn_1149.Invoke_O__O(arg_1150) } else { path__6 = linked_1148.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1147, arg_1150) }
//line :198:1
	var tmp7 any; var root_1163 any = A_arbace_c_musl_A_const_125.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1165 lang.IFn


	if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = u__2; if linked_1164 == nil { tmp7 = ifn_1165.Invoke_O__O(arg_1166) } else { tmp7 = linked_1164.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1163, arg_1166) }
//line :198:1
	var tmp8 any = tmp7; var tmp9 any; var G__1657000167__7_ any; var tmp10 any = A_arbace_c_musl_A_const_120; var tmp11 any = A_arbace_c_musl_A_const_126; var tmp12 any; var root_1167 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1169 lang.IFn


	if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = hf__4; if linked_1168 == nil { tmp12 = ifn_1169.Invoke_O__O(arg_1170) } else { tmp12 = linked_1168.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1167, arg_1170) }
//line :198:1
	G__1657000167__7_ = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, hforms__5, tmp11, tmp12))


	if jrt.J2g_Truth(path__6) { var root_1171 any = A_arbace_c_musl_A_const_17.GetRawRoot__O(); var linked_1172 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1171, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1173 lang.IFn; if linked_1172 == nil { ifn_1173 = lang.IFn_Cast(root_1171) } else { ifn_1173 = nil }; var arg_1174 any = G__1657000167__7_; var arg_1175 any = A_arbace_c_musl_A_const_124; var arg_1176 any = path__6; if linked_1172 == nil { tmp9 = ifn_1173.Invoke_O_O_O__O(arg_1174, arg_1175, arg_1176) } else { tmp9 = linked_1172.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1171, arg_1174, arg_1175, arg_1176) } } else { tmp9 = G__1657000167__7_ }
//line :198:1
	arg_1133 = lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9); if linked_1130 == nil { ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { linked_1130.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) }; i__1657000157__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000157__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_fn__1657000165_A_New() *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_fn__1657000165_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_fn__1657000165_A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_fn__1657000165_A) Ctor() {}
//line :200:1
func (t *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_fn__1657000165_A) Invoke_O_O__O(self, p1__1657000151_SHARP___1 any) any { var root_1156 any = A_arbace_c_musl_A_const_123.GetRawRoot__O(); var linked_1157 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1156, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1158 lang.IFn; if linked_1157 == nil { ifn_1158 = lang.IFn_Cast(root_1156) } else { ifn_1158 = nil }; var arg_1159 any = p1__1657000151_SHARP___1; var arg_1160 any = A_arbace_c_musl_A_const_124; if linked_1157 == nil { return ifn_1158.Invoke_O_O__O(arg_1159, arg_1160) } else { return linked_1157.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1156, arg_1159, arg_1160) } }
//line :200:1
func A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000172_A_New() *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000172_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000172_A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000172_A) Ctor() {}
//line :200:1
func (t *A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000172_A) Invoke_O_O__O(self, p1__1657000151_SHARP___1 any) any { var root_1232 any = A_arbace_c_musl_A_const_123.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any = p1__1657000151_SHARP___1; var arg_1236 any = A_arbace_c_musl_A_const_124; if linked_1233 == nil { return ifn_1234.Invoke_O_O__O(arg_1235, arg_1236) } else { return linked_1233.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1232, arg_1235, arg_1236) } }


func A_arbace_c_musl_load_unit_A_New() *A_arbace_c_musl_load_unit_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_load_unit_A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_c_musl_load_unit_A) Ctor() {}
//line :203:1
func (t *A_arbace_c_musl_load_unit_A) Invoke_O_O_O__O(self, root__0, src__1 any) any {


	var root_1261 any = A_arbace_c_musl_A_const_127.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, A_arbace_c_musl_load_forms_A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any; var root_1266 any = A_arbace_c_musl_A_const_88.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1266, A_arbace_c_musl_forms_root_A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any = root__0; if linked_1267 == nil { arg_1264 = ifn_1268.Invoke_O__O(arg_1269) } else { arg_1264 = linked_1267.(*A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_1266, arg_1269) }; var arg_1265 any = src__1; if linked_1262 == nil { return ifn_1263.Invoke_O_O__O(arg_1264, arg_1265) } else { return linked_1262.(*A_arbace_c_musl_load_forms_A).Invoke_O_O_O__O(root_1261, arg_1264, arg_1265)
	} }
func A_arbace_c_musl_index_A_New() *A_arbace_c_musl_index_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_index_A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_c_musl_index_A) Ctor() {}
//line :208:1
func (t *A_arbace_c_musl_index_A) Invoke_O_O__O(self, root__0 any) any { var f__2 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_39); var tmp2 any; var root_1270 any = A_arbace_c_musl_A_const_88.GetRawRoot__O(); var linked_1271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1270, A_arbace_c_musl_forms_root_A_fn_class); var ifn_1272 lang.IFn; if


	linked_1271 == nil { ifn_1272 = lang.IFn_Cast(root_1270) } else { ifn_1272 = nil }; var arg_1273 any = root__0; if linked_1271 == nil { tmp2 = ifn_1272.Invoke_O__O(arg_1273) } else { tmp2 = linked_1271.(*A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_1270, arg_1273) }; f__2 = /*line :208:1*/jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil))); if



	jrt.File_Cast(f__2).Exists__Z() {
		var root_1274 any = A_arbace_c_musl_A_const_119.GetRawRoot__O(); var linked_1275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1274, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_1276 lang.IFn; if linked_1275 == nil { ifn_1276 = lang.IFn_Cast(root_1274) } else { ifn_1276 = nil }; var arg_1277 any = lang.IFn_Cast(A_arbace_c_musl_A_const_118.GetRawRoot__O()).Invoke_O__O(f__2); if linked_1275 == nil { return ifn_1276.Invoke_O__O(arg_1277) } else { return linked_1275.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_1274, arg_1277) } } else {
//line :212:1
			var ix__3 any; var root_1282 any = A_arbace_c_musl_A_const_57.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1282, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1284 lang.IFn

			if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any = lang.IFn_Cast(A_arbace_c_musl_A_const_128.GetRawRoot__O()).Invoke__O(); var arg_1286 any; var iter__1927001039__auto____3 any; var fnbody__1425 any = A_arbace_c_musl_index_iter__1657000179__1657000183_A_New_O(root__0); var tmp3 *jrt.Class; var fncls__1424 *jrt.Class = A_arbace_c_musl_index_iter__1657000179__1657000183_A_fn_class
			if fncls__1424 == nil { var fncls__1424d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, fnbody__1425); A_arbace_c_musl_index_iter__1657000179__1657000183_A_fn_class = fncls__1424d; tmp3 = fncls__1424d } else { tmp3 = fncls__1424 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1425, tmp3, nil); var tmp4 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp5 any; var root_1426 any = A_arbace_c_musl_A_const_103.GetRawRoot__O(); var linked_1427 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1426, A_arbace_c_musl_sources_A_fn_class); var ifn_1428 lang.IFn; if linked_1427 == nil { ifn_1428 = lang.IFn_Cast(root_1426) } else { ifn_1428 = nil }; var arg_1429 any = root__0; if linked_1427 == nil { tmp5 = ifn_1428.Invoke_O__O(arg_1429) } else { tmp5 = linked_1427.(*A_arbace_c_musl_sources_A).Invoke_O_O__O(root_1426, arg_1429) }; arg_1286 = tmp4.Invoke_O__O(tmp5)
//line :214:1
			if linked_1283 == nil { ix__3 = ifn_1284.Invoke_O_O__O(arg_1285, arg_1286) } else { ix__3 = linked_1283.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1282, arg_1285, arg_1286)
			}




			lang.IFn_Cast(A_arbace_c_musl_A_const_82.GetRawRoot__O()).Invoke_O_O__O(f__2, lang.IFn_Cast(A_arbace_c_musl_A_const_98.GetRawRoot__O()).Invoke_O__O(ix__3))
//line :212:1
			return ix__3 } }


func A_arbace_c_musl_index_iter__1657000179__1657000183_A_New_O(p0 any) *A_arbace_c_musl_index_iter__1657000179__1657000183_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_index_iter__1657000179__1657000183_A{}; t.Ctor_O(p0); return t }
//line :215:1
func (t *A_arbace_c_musl_index_iter__1657000179__1657000183_A) Ctor_O(c__root any) { t.F_root = c__root }
//line :215:1
func (t *A_arbace_c_musl_index_iter__1657000179__1657000183_A) Invoke_O_O__O(self, s__1657000180__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1423 any = A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_A_New_O_O_O(t.F_root, self, s__1657000180__1); var tmp2 *jrt.Class; var fncls__1422 *jrt.Class = A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_A_fn_class; if fncls__1422 == nil { var fncls__1422d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__1423); A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_A_fn_class = fncls__1422d; tmp2 = fncls__1422d } else { tmp2 = fncls__1422 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1423, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :215:1
func A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :215:1
func (t *A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_A) Ctor_O_O_O(c__root, c__iter__1657000179, c__s__1657000180 any) { t.F_root = c__root; t.F_iter__1657000179 = c__iter__1657000179; t.F_s__1657000180 = c__s__1657000180 }
//line :215:1
func (t *A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_A) Invoke_O__O(self any) any { { var s__1657000180__1 any; var t_ any = t.F_s__1657000180; t.F_s__1657000180 = nil; s__1657000180__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1290 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1290, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1292 lang.IFn; if linked_1291 == nil { ifn_1292 = lang.IFn_Cast(root_1290) } else { ifn_1292 = nil }; var arg_1293 any = s__1657000180__1; if linked_1291 == nil { temp__1927000414__auto____2 = ifn_1292.Invoke_O__O(arg_1293) } else { temp__1927000414__auto____2 = linked_1291.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1290, arg_1293) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1657000180__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1294 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1294, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1296 lang.IFn; if linked_1295 == nil { ifn_1296 = lang.IFn_Cast(root_1294) } else { ifn_1296 = nil }; var arg_1297 any = s__1657000180__3; if linked_1295 == nil { tmp1 = ifn_1296.Invoke_O__O(arg_1297) } else { tmp1 = linked_1295.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1294, arg_1297) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1298 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1300 lang.IFn; if linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = s__1657000180__3; if linked_1299 == nil { c__1927001037__auto____4 = ifn_1300.Invoke_O__O(arg_1301) } else { c__1927001037__auto____4 = linked_1299.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1298, arg_1301) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1657000182__6 any; var root_1302 any = A_arbace_c_musl_A_const_32.GetRawRoot__O(); var linked_1303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1302, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1304 lang.IFn; if linked_1303 == nil { ifn_1304 = lang.IFn_Cast(root_1302) } else { ifn_1304 = nil }; var arg_1305 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1303 == nil { b__1657000182__6 = ifn_1304.Invoke_O__O(arg_1305) } else { b__1657000182__6 = linked_1303.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1302, arg_1305) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1347 any = A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_fn__1657000185_A_New_O_I_O_O(t.F_root, size__1927001038__auto____5, c__1927001037__auto____4, b__1657000182__6); var tmp3 *jrt.Class; var fncls__1346 *jrt.Class = A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_fn__1657000185_A_fn_class; if fncls__1346 == nil { var fncls__1346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__1347); A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_fn__1657000185_A_fn_class = fncls__1346d; tmp3 = fncls__1346d } else { tmp3 = fncls__1346 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1347, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1348 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any; var root_1353 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_1354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1353, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1355 lang.IFn; if linked_1354 == nil { ifn_1355 = lang.IFn_Cast(root_1353) } else { ifn_1355 = nil }; var arg_1356 any = b__1657000182__6; if linked_1354 == nil { arg_1351 = ifn_1355.Invoke_O__O(arg_1356) } else { arg_1351 = linked_1354.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1353, arg_1356) }; var arg_1352 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1657000179); var tmp5 any; var root_1357 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1359 lang.IFn; if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = s__1657000180__3; if linked_1358 == nil { tmp5 = ifn_1359.Invoke_O__O(arg_1360) } else { tmp5 = linked_1358.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1357, arg_1360) }; arg_1352 = tmp4.Invoke_O__O(tmp5); if linked_1349 == nil { return ifn_1350.Invoke_O_O__O(arg_1351, arg_1352) } else { return linked_1349.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1348, arg_1351, arg_1352) } } else { var root_1361 any = A_arbace_c_musl_A_const_35.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1363 lang.IFn; if linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any; var root_1366 any = A_arbace_c_musl_A_const_36.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1368 lang.IFn; if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = b__1657000182__6; if linked_1367 == nil { arg_1364 = ifn_1368.Invoke_O__O(arg_1369) } else { arg_1364 = linked_1367.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1366, arg_1369) }; var arg_1365 any; if linked_1362 == nil { return ifn_1363.Invoke_O_O__O(arg_1364, arg_1365) } else { return linked_1362.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1361, arg_1364, arg_1365) } } } else { var s__4 any; var root_1370 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1372 lang.IFn; if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = s__1657000180__3; if linked_1371 == nil { s__4 = ifn_1372.Invoke_O__O(arg_1373) } else { s__4 = linked_1371.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1370, arg_1373) }; var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil, Lit_44); var tmp7 any; var root_1374 any = A_arbace_c_musl_A_const_88.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, A_arbace_c_musl_forms_root_A_fn_class); var ifn_1376 lang.IFn
													if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = t.F_root; if linked_1375 == nil { tmp7 = ifn_1376.Invoke_O__O(arg_1377) } else { tmp7 = linked_1375.(*A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_1374, arg_1377) }
//line :215:1
	if jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil, s__4, nil))).Exists__Z() { var root_1378 any = A_arbace_c_musl_A_const_38.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any; var u__5 any; var root_1383 any = A_arbace_c_musl_A_const_129.GetRawRoot__O(); var linked_1384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1383, A_arbace_c_musl_load_unit_A_fn_class); var ifn_1385 lang.IFn

		if linked_1384 == nil { ifn_1385 = lang.IFn_Cast(root_1383) } else { ifn_1385 = nil }; var arg_1386 any = t.F_root; var arg_1387 any = s__4; if linked_1384 == nil { u__5 = ifn_1385.Invoke_O_O__O(arg_1386, arg_1387) } else { u__5 = linked_1384.(*A_arbace_c_musl_load_unit_A).Invoke_O_O_O__O(root_1383, arg_1386, arg_1387) }
//line :215:1
		var all__6 any; var root_1388 any = A_arbace_c_musl_A_const_40.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1390 lang.IFn


		if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = A_arbace_c_musl_A_const_120.Invoke_O__O(u__5); var arg_1392 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_130.GetRawRoot__O()); var tmp9 any = A_arbace_c_musl_A_const_120; var tmp10 any; var root_1398 any = A_arbace_c_musl_A_const_131.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any = A_arbace_c_musl_A_const_102.Invoke_O__O(u__5); if linked_1399 == nil { tmp10 = ifn_1400.Invoke_O__O(arg_1401) } else { tmp10 = linked_1399.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1398, arg_1401) }; arg_1392 = tmp8.Invoke_O_O__O(tmp9, tmp10); if linked_1389 == nil { all__6 = ifn_1390.Invoke_O_O__O(arg_1391, arg_1392) } else { all__6 = linked_1389.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1388, arg_1391, arg_1392) }
//line :215:1
		var tmp11 any = A_arbace_c_musl_A_const_132; var tmp12 any; var root_1402 any = A_arbace_c_musl_A_const_133.GetRawRoot__O(); var linked_1403 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1402, A_arbace_c_musl_unit_defs_A_fn_class); var ifn_1404 lang.IFn



		if linked_1403 == nil { ifn_1404 = lang.IFn_Cast(root_1402) } else { ifn_1404 = nil }; var arg_1405 any = A_arbace_c_musl_A_const_120.Invoke_O__O(u__5); if linked_1403 == nil { tmp12 = ifn_1404.Invoke_O__O(arg_1405) } else { tmp12 = linked_1403.(*A_arbace_c_musl_unit_defs_A).Invoke_O_O__O(root_1402, arg_1405) }
//line :215:1
		var tmp13 any = tmp12; var tmp14 any = A_arbace_c_musl_A_const_134; var tmp15 any; var root_1406 any = A_arbace_c_musl_A_const_54.GetRawRoot__O(); var linked_1407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1406, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1408 lang.IFn



		if linked_1407 == nil { ifn_1408 = lang.IFn_Cast(root_1406) } else { ifn_1408 = nil }; var arg_1409 any; var root_1410 any = A_arbace_c_musl_A_const_135.GetRawRoot__O(); var linked_1411 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1410, A_arbace_c_musl_refs_A_fn_class); var ifn_1412 lang.IFn; if linked_1411 == nil { ifn_1412 = lang.IFn_Cast(root_1410) } else { ifn_1412 = nil }; var arg_1413 any = all__6; if linked_1411 == nil { arg_1409 = ifn_1412.Invoke_O__O(arg_1413) } else { arg_1409 = linked_1411.(*A_arbace_c_musl_refs_A).Invoke_O_O__O(root_1410, arg_1413) }; if linked_1407 == nil { tmp15 = ifn_1408.Invoke_O__O(arg_1409) } else { tmp15 = linked_1407.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1406, arg_1409) }
//line :215:1
		arg_1381 = lang.Tuple_Create_O_O__IPersistentVector(s__4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp13, tmp14, tmp15))); var arg_1382 any; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__1657000179); var tmp17 any; var root_1414 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1414, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1416 lang.IFn; if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any = s__1657000180__3; if linked_1415 == nil { tmp17 = ifn_1416.Invoke_O__O(arg_1417) } else { tmp17 = linked_1415.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1414, arg_1417) }; arg_1382 = tmp16.Invoke_O__O(tmp17); if linked_1379 == nil { return ifn_1380.Invoke_O_O__O(arg_1381, arg_1382) } else { return linked_1379.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1378, arg_1381, arg_1382) } } else { var tmp18 any; var root_1418 any = A_arbace_c_musl_A_const_39.GetRawRoot__O(); var linked_1419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1418, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1420 lang.IFn; if linked_1419 == nil { ifn_1420 = lang.IFn_Cast(root_1418) } else { ifn_1420 = nil }; var arg_1421 any = s__1657000180__3; if linked_1419 == nil { tmp18 = ifn_1420.Invoke_O__O(arg_1421) } else { tmp18 = linked_1419.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1418, arg_1421) }; s__1657000180__1 = tmp18; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :215:1
func A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_fn__1657000185_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_fn__1657000185_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_fn__1657000185_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :215:1
func (t *A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_fn__1657000185_A) Ctor_O_I_O_O(c__root any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1657000182 any) { t.F_root = c__root; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1657000182 = c__b__1657000182 }
//line :215:1
func (t *A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_fn__1657000185_A) Invoke_O__O(self any) any { { var i__1657000181__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1657000181__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1657000181__1)); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_43, nil, Lit_44); var tmp3 any; var root_1306 any = A_arbace_c_musl_A_const_88.GetRawRoot__O(); var linked_1307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1306, A_arbace_c_musl_forms_root_A_fn_class); var ifn_1308 lang.IFn
															if linked_1307 == nil { ifn_1308 = lang.IFn_Cast(root_1306) } else { ifn_1308 = nil }; var arg_1309 any = t.F_root; if linked_1307 == nil { tmp3 = ifn_1308.Invoke_O__O(arg_1309) } else { tmp3 = linked_1307.(*A_arbace_c_musl_forms_root_A).Invoke_O_O__O(root_1306, arg_1309) }
//line :215:1
	if jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3, nil, s__2, nil))).Exists__Z() { var root_1310 any = A_arbace_c_musl_A_const_34.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1312 lang.IFn; if linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = t.F_b__1657000182; var arg_1314 any; var u__3 any; var root_1315 any = A_arbace_c_musl_A_const_129.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, A_arbace_c_musl_load_unit_A_fn_class); var ifn_1317 lang.IFn

		if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = t.F_root; var arg_1319 any = s__2; if linked_1316 == nil { u__3 = ifn_1317.Invoke_O_O__O(arg_1318, arg_1319) } else { u__3 = linked_1316.(*A_arbace_c_musl_load_unit_A).Invoke_O_O_O__O(root_1315, arg_1318, arg_1319) }
//line :215:1
		var all__4 any; var root_1320 any = A_arbace_c_musl_A_const_40.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1322 lang.IFn


		if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = A_arbace_c_musl_A_const_120.Invoke_O__O(u__3); var arg_1324 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_130.GetRawRoot__O()); var tmp5 any = A_arbace_c_musl_A_const_120; var tmp6 any; var root_1330 any = A_arbace_c_musl_A_const_131.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = A_arbace_c_musl_A_const_102.Invoke_O__O(u__3); if linked_1331 == nil { tmp6 = ifn_1332.Invoke_O__O(arg_1333) } else { tmp6 = linked_1331.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1330, arg_1333) }; arg_1324 = tmp4.Invoke_O_O__O(tmp5, tmp6); if linked_1321 == nil { all__4 = ifn_1322.Invoke_O_O__O(arg_1323, arg_1324) } else { all__4 = linked_1321.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1320, arg_1323, arg_1324) }
//line :215:1
		var tmp7 any = A_arbace_c_musl_A_const_132; var tmp8 any; var root_1334 any = A_arbace_c_musl_A_const_133.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, A_arbace_c_musl_unit_defs_A_fn_class); var ifn_1336 lang.IFn



		if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = A_arbace_c_musl_A_const_120.Invoke_O__O(u__3); if linked_1335 == nil { tmp8 = ifn_1336.Invoke_O__O(arg_1337) } else { tmp8 = linked_1335.(*A_arbace_c_musl_unit_defs_A).Invoke_O_O__O(root_1334, arg_1337) }
//line :215:1
		var tmp9 any = tmp8; var tmp10 any = A_arbace_c_musl_A_const_134; var tmp11 any; var root_1338 any = A_arbace_c_musl_A_const_54.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1340 lang.IFn



		if linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any; var root_1342 any = A_arbace_c_musl_A_const_135.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, A_arbace_c_musl_refs_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = all__4; if linked_1343 == nil { arg_1341 = ifn_1344.Invoke_O__O(arg_1345) } else { arg_1341 = linked_1343.(*A_arbace_c_musl_refs_A).Invoke_O_O__O(root_1342, arg_1345) }; if linked_1339 == nil { tmp11 = ifn_1340.Invoke_O__O(arg_1341) } else { tmp11 = linked_1339.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1338, arg_1341) }
//line :215:1
		arg_1314 = lang.Tuple_Create_O_O__IPersistentVector(s__2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, tmp10, tmp11))); if linked_1311 == nil { ifn_1312.Invoke_O_O__O(arg_1313, arg_1314) } else { linked_1311.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1310, arg_1313, arg_1314) }; i__1657000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000181__1); continue L1 } else { i__1657000181__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1657000181__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_c_musl_library_A_New() *A_arbace_c_musl_library_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_library_A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_c_musl_library_A) Ctor() {}
//line :226:1
func (t *A_arbace_c_musl_library_A) Invoke_O_O_O__O(self, h__0, root__1 any) any { var ix__3 any; var root_1439 any = A_arbace_c_musl_A_const_136.GetRawRoot__O(); var linked_1440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1439, A_arbace_c_musl_index_A_fn_class); var ifn_1441 lang.IFn; if


	linked_1440 == nil { ifn_1441 = lang.IFn_Cast(root_1439) } else { ifn_1441 = nil }; var arg_1442 any = root__1; if linked_1440 == nil { ix__3 = ifn_1441.Invoke_O__O(arg_1442) } else { ix__3 = linked_1440.(*A_arbace_c_musl_index_A).Invoke_O_O__O(root_1439, arg_1442) }; var by__4 any = /*line :226:1*/jrt.HashMap_New(); var seq_1657000190__5 any; var root_1447 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1447, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1449 lang.IFn; if




	linked_1448 == nil { ifn_1449 = lang.IFn_Cast(root_1447) } else { ifn_1449 = nil }; var arg_1450 any = ix__3; if linked_1448 == nil { seq_1657000190__5 = ifn_1449.Invoke_O__O(arg_1450) } else { seq_1657000190__5 = linked_1448.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1447, arg_1450) }; var chunk_1657000191__6 any; var count_1657000192__7 int64 = 0; var i_1657000193__8 int64 = 0; L1:
//line :226:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000193__8, count_1657000192__7) { var vec__1657000202__9 any = lang.Indexed_Cast(chunk_1657000191__6).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000193__8)); var s__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000202__9, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1657000205__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000202__9, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1657000205__12 any; if lang.ISeq_InstanceOf(map__1657000205__11) { var tmp1 any; var root_1451 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = map__1657000205__11; if linked_1452 == nil { tmp1 = ifn_1453.Invoke_O__O(arg_1454) } else { tmp1 = linked_1452.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1451, arg_1454) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1455 any = A_arbace_c_musl_A_const_142.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1457 lang.IFn; if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = map__1657000205__11; if linked_1456 == nil { tmp2 = ifn_1457.Invoke_O__O(arg_1458) } else { tmp2 = linked_1456.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1455, arg_1458) }; map__1657000205__12 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1459 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1461 lang.IFn; if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any = map__1657000205__11; if linked_1460 == nil { tmp3 = ifn_1461.Invoke_O__O(arg_1462) } else { tmp3 = linked_1460.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1459, arg_1462) }; if jrt.J2g_Truth(tmp3) { var root_1463 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = map__1657000205__11; if linked_1464 == nil { map__1657000205__12 = ifn_1465.Invoke_O__O(arg_1466) } else { map__1657000205__12 = linked_1464.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1463, arg_1466) } } else { map__1657000205__12 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1657000205__12 = map__1657000205__11 }; var defs__13 any = lang.RT_Get_O_O__O_NoInit(map__1657000205__12, A_arbace_c_musl_A_const_132); var seq_1657000198__14 any; var root_1499 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1499, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1501 lang.IFn; if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = defs__13; if linked_1500 == nil { seq_1657000198__14 = ifn_1501.Invoke_O__O(arg_1502) } else { seq_1657000198__14 = linked_1500.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1499, arg_1502) }; var chunk_1657000199__15 any; var count_1657000200__16 int64 = 0; var i_1657000201__17 int64 = 0; L2: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000201__17, count_1657000200__16) { var vec__1657000207__18 any = lang.Indexed_Cast(chunk_1657000199__15).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000201__17)); var n__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000207__18, lang.RT_IntCast_J__I_NoInit(0), nil); var d__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000207__18, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 jrt.HashMap_I = jrt.HashMap_Cast(by__4); var tmp5 any; var root_1519 any = A_arbace_c_musl_A_const_11.GetRawRoot__O(); var linked_1520 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1519, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1521 lang.IFn

			if linked_1520 == nil { ifn_1521 = lang.IFn_Cast(root_1519) } else { ifn_1521 = nil }; var arg_1522 any; var or__1927000174__auto____21 any = jrt.HashMap_Cast(by__4).Get_O__O(n__19); if jrt.J2g_Truth(or__1927000174__auto____21) { arg_1522 = or__1927000174__auto____21 } else { arg_1522 = lang.PersistentVector_EMPTY.Ref() }; var arg_1523 any = lang.Tuple_Create_O_O__IPersistentVector(s__10, A_arbace_c_musl_A_const_63.Invoke_O__O(d__20)); if linked_1520 == nil { tmp5 = ifn_1521.Invoke_O_O__O(arg_1522, arg_1523) } else { tmp5 = linked_1520.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1519, arg_1522, arg_1523) }; tmp4.Put_O_O__O(n__19, tmp5)
//line :231:1
			seq_1657000198__14, chunk_1657000199__15, count_1657000200__16, i_1657000201__17 = seq_1657000198__14, chunk_1657000199__15, count_1657000200__16, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000201__17); continue L2 } else { var temp__1927000414__auto____18 any; var root_1503 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1503, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1505 lang.IFn; if linked_1504 == nil { ifn_1505 = lang.IFn_Cast(root_1503) } else { ifn_1505 = nil }; var arg_1506 any = seq_1657000198__14; if linked_1504 == nil { temp__1927000414__auto____18 = ifn_1505.Invoke_O__O(arg_1506) } else { temp__1927000414__auto____18 = linked_1504.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1503, arg_1506) }; if jrt.J2g_Truth(temp__1927000414__auto____18) { var seq_1657000198__19 any = temp__1927000414__auto____18; var tmp6 any; var root_1507 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1507, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1509 lang.IFn; if linked_1508 == nil { ifn_1509 = lang.IFn_Cast(root_1507) } else { ifn_1509 = nil }; var arg_1510 any = seq_1657000198__19; if linked_1508 == nil { tmp6 = ifn_1509.Invoke_O__O(arg_1510) } else { tmp6 = linked_1508.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1507, arg_1510) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____20 any; var root_1511 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_1512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1511, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1513 lang.IFn; if linked_1512 == nil { ifn_1513 = lang.IFn_Cast(root_1511) } else { ifn_1513 = nil }; var arg_1514 any = seq_1657000198__19; if linked_1512 == nil { c__1927000678__auto____20 = ifn_1513.Invoke_O__O(arg_1514) } else { c__1927000678__auto____20 = linked_1512.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1511, arg_1514) }; var tmp7 any; var root_1524 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_1525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1524, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1526 lang.IFn; if linked_1525 == nil { ifn_1526 = lang.IFn_Cast(root_1524) } else { ifn_1526 = nil }; var arg_1527 any = seq_1657000198__19; if linked_1525 == nil { tmp7 = ifn_1526.Invoke_O__O(arg_1527) } else { tmp7 = linked_1525.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1524, arg_1527) }; seq_1657000198__14, chunk_1657000199__15, count_1657000200__16, i_1657000201__17 = tmp7, c__1927000678__auto____20, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__1657000210__20 any; var root_1515 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1515, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1517 lang.IFn; if linked_1516 == nil { ifn_1517 = lang.IFn_Cast(root_1515) } else { ifn_1517 = nil }; var arg_1518 any = seq_1657000198__19; if linked_1516 == nil { vec__1657000210__20 = ifn_1517.Invoke_O__O(arg_1518) } else { vec__1657000210__20 = linked_1516.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1515, arg_1518) }; var n__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000210__20, lang.RT_IntCast_J__I_NoInit(0), nil); var d__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000210__20, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp8 jrt.HashMap_I = jrt.HashMap_Cast(by__4); var tmp9 any; var root_1528 any = A_arbace_c_musl_A_const_11.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1530 lang.IFn

				if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any; var or__1927000174__auto____23 any = jrt.HashMap_Cast(by__4).Get_O__O(n__21); if jrt.J2g_Truth(or__1927000174__auto____23) { arg_1531 = or__1927000174__auto____23 } else { arg_1531 = lang.PersistentVector_EMPTY.Ref() }; var arg_1532 any = lang.Tuple_Create_O_O__IPersistentVector(s__10, A_arbace_c_musl_A_const_63.Invoke_O__O(d__22)); if linked_1529 == nil { tmp9 = ifn_1530.Invoke_O_O__O(arg_1531, arg_1532) } else { tmp9 = linked_1529.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1528, arg_1531, arg_1532) }; tmp8.Put_O_O__O(n__21, tmp9)
//line :231:1
				var tmp10 any; var root_1533 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1535 lang.IFn; if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = seq_1657000198__19; if linked_1534 == nil { tmp10 = ifn_1535.Invoke_O__O(arg_1536) } else { tmp10 = linked_1534.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1533, arg_1536) }; seq_1657000198__14, chunk_1657000199__15, count_1657000200__16, i_1657000201__17 = tmp10, nil, 0, 0; continue L2 } } }; break L2 }; seq_1657000190__5, chunk_1657000191__6, count_1657000192__7, i_1657000193__8 = seq_1657000190__5, chunk_1657000191__6, count_1657000192__7, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000193__8); continue L1 } else { var temp__1927000414__auto____9 any; var root_1467 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = seq_1657000190__5; if linked_1468 == nil { temp__1927000414__auto____9 = ifn_1469.Invoke_O__O(arg_1470) } else { temp__1927000414__auto____9 = linked_1468.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1467, arg_1470) }; if jrt.J2g_Truth(temp__1927000414__auto____9) { var seq_1657000190__10 any = temp__1927000414__auto____9; var tmp11 any; var root_1471 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = seq_1657000190__10; if linked_1472 == nil { tmp11 = ifn_1473.Invoke_O__O(arg_1474) } else { tmp11 = linked_1472.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1471, arg_1474) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____11 any; var root_1475 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = seq_1657000190__10; if linked_1476 == nil { c__1927000678__auto____11 = ifn_1477.Invoke_O__O(arg_1478) } else { c__1927000678__auto____11 = linked_1476.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1475, arg_1478) }; var tmp12 any; var root_1537 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = seq_1657000190__10; if linked_1538 == nil { tmp12 = ifn_1539.Invoke_O__O(arg_1540) } else { tmp12 = linked_1538.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1537, arg_1540) }; seq_1657000190__5, chunk_1657000191__6, count_1657000192__7, i_1657000193__8 = tmp12, c__1927000678__auto____11, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1657000213__11 any; var root_1479 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = seq_1657000190__10; if linked_1480 == nil { vec__1657000213__11 = ifn_1481.Invoke_O__O(arg_1482) } else { vec__1657000213__11 = linked_1480.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1479, arg_1482) }; var s__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000213__11, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1657000216__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000213__11, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1657000216__14 any; if lang.ISeq_InstanceOf(map__1657000216__13) { var tmp13 any; var root_1483 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = map__1657000216__13; if linked_1484 == nil { tmp13 = ifn_1485.Invoke_O__O(arg_1486) } else { tmp13 = linked_1484.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1483, arg_1486) }; if jrt.J2g_Truth(tmp13) { var tmp14 any; var root_1487 any = A_arbace_c_musl_A_const_142.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = map__1657000216__13; if linked_1488 == nil { tmp14 = ifn_1489.Invoke_O__O(arg_1490) } else { tmp14 = linked_1488.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1487, arg_1490) }; map__1657000216__14 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp14)).Ref() } else { var tmp15 any; var root_1491 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1491, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1493 lang.IFn; if linked_1492 == nil { ifn_1493 = lang.IFn_Cast(root_1491) } else { ifn_1493 = nil }; var arg_1494 any = map__1657000216__13; if linked_1492 == nil { tmp15 = ifn_1493.Invoke_O__O(arg_1494) } else { tmp15 = linked_1492.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1491, arg_1494) }; if jrt.J2g_Truth(tmp15) { var root_1495 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = map__1657000216__13; if linked_1496 == nil { map__1657000216__14 = ifn_1497.Invoke_O__O(arg_1498) } else { map__1657000216__14 = linked_1496.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1495, arg_1498) } } else { map__1657000216__14 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1657000216__14 = map__1657000216__13 }; var defs__15 any = lang.RT_Get_O_O__O_NoInit(map__1657000216__14, A_arbace_c_musl_A_const_132); var seq_1657000194__16 any; var root_1541 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1541, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1543 lang.IFn; if linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any = defs__15; if linked_1542 == nil { seq_1657000194__16 = ifn_1543.Invoke_O__O(arg_1544) } else { seq_1657000194__16 = linked_1542.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1541, arg_1544) }; var chunk_1657000195__17 any; var count_1657000196__18 int64 = 0; var i_1657000197__19 int64 = 0; L3: for { if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000197__19, count_1657000196__18) { var vec__1657000218__20 any = lang.Indexed_Cast(chunk_1657000195__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000197__19)); var n__21_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000218__20, lang.RT_IntCast_J__I_NoInit(0), nil); var d__22_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000218__20, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp16 jrt.HashMap_I = jrt.HashMap_Cast(by__4); var tmp17 any; var root_1561 any = A_arbace_c_musl_A_const_11.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1563 lang.IFn

					if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any; var or__1927000174__auto____23_2 any = jrt.HashMap_Cast(by__4).Get_O__O(n__21_2); if jrt.J2g_Truth(or__1927000174__auto____23_2) { arg_1564 = or__1927000174__auto____23_2 } else { arg_1564 = lang.PersistentVector_EMPTY.Ref() }; var arg_1565 any = lang.Tuple_Create_O_O__IPersistentVector(s__12, A_arbace_c_musl_A_const_63.Invoke_O__O(d__22_2)); if linked_1562 == nil { tmp17 = ifn_1563.Invoke_O_O__O(arg_1564, arg_1565) } else { tmp17 = linked_1562.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1561, arg_1564, arg_1565) }; tmp16.Put_O_O__O(n__21_2, tmp17)
//line :231:1
					seq_1657000194__16, chunk_1657000195__17, count_1657000196__18, i_1657000197__19 = seq_1657000194__16, chunk_1657000195__17, count_1657000196__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000197__19); continue L3 } else { var temp__1927000414__auto____20 any; var root_1545 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = seq_1657000194__16; if linked_1546 == nil { temp__1927000414__auto____20 = ifn_1547.Invoke_O__O(arg_1548) } else { temp__1927000414__auto____20 = linked_1546.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1545, arg_1548) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1657000194__21 any = temp__1927000414__auto____20; var tmp18 any; var root_1549 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1549, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1551 lang.IFn; if linked_1550 == nil { ifn_1551 = lang.IFn_Cast(root_1549) } else { ifn_1551 = nil }; var arg_1552 any = seq_1657000194__21; if linked_1550 == nil { tmp18 = ifn_1551.Invoke_O__O(arg_1552) } else { tmp18 = linked_1550.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1549, arg_1552) }; if jrt.J2g_Truth(tmp18) { var c__1927000678__auto____22 any; var root_1553 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1553, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1555 lang.IFn; if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = seq_1657000194__21; if linked_1554 == nil { c__1927000678__auto____22 = ifn_1555.Invoke_O__O(arg_1556) } else { c__1927000678__auto____22 = linked_1554.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1553, arg_1556) }; var tmp19 any; var root_1566 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = seq_1657000194__21; if linked_1567 == nil { tmp19 = ifn_1568.Invoke_O__O(arg_1569) } else { tmp19 = linked_1567.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1566, arg_1569) }; seq_1657000194__16, chunk_1657000195__17, count_1657000196__18, i_1657000197__19 = tmp19, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1657000221__22 any; var root_1557 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = seq_1657000194__21; if linked_1558 == nil { vec__1657000221__22 = ifn_1559.Invoke_O__O(arg_1560) } else { vec__1657000221__22 = linked_1558.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1557, arg_1560) }; var n__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000221__22, lang.RT_IntCast_J__I_NoInit(0), nil); var d__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000221__22, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp20 jrt.HashMap_I = jrt.HashMap_Cast(by__4); var tmp21 any; var root_1570 any = A_arbace_c_musl_A_const_11.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_1572 lang.IFn

						if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any; var or__1927000174__auto____25 any = jrt.HashMap_Cast(by__4).Get_O__O(n__23); if jrt.J2g_Truth(or__1927000174__auto____25) { arg_1573 = or__1927000174__auto____25 } else { arg_1573 = lang.PersistentVector_EMPTY.Ref() }; var arg_1574 any = lang.Tuple_Create_O_O__IPersistentVector(s__12, A_arbace_c_musl_A_const_63.Invoke_O__O(d__24)); if linked_1571 == nil { tmp21 = ifn_1572.Invoke_O_O__O(arg_1573, arg_1574) } else { tmp21 = linked_1571.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_1570, arg_1573, arg_1574) }; tmp20.Put_O_O__O(n__23, tmp21)
//line :231:1
						var tmp22 any; var root_1575 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1575, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1577 lang.IFn; if linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = seq_1657000194__21; if linked_1576 == nil { tmp22 = ifn_1577.Invoke_O__O(arg_1578) } else { tmp22 = linked_1576.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1575, arg_1578) }; seq_1657000194__16, chunk_1657000195__17, count_1657000196__18, i_1657000197__19 = tmp22, nil, 0, 0; continue L3 } } }; break L3 }; var tmp23 any; var root_1579 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_1580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1579, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1581 lang.IFn; if linked_1580 == nil { ifn_1581 = lang.IFn_Cast(root_1579) } else { ifn_1581 = nil }; var arg_1582 any = seq_1657000190__10; if linked_1580 == nil { tmp23 = ifn_1581.Invoke_O__O(arg_1582) } else { tmp23 = linked_1580.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1579, arg_1582) }; seq_1657000190__5, chunk_1657000191__6, count_1657000192__7, i_1657000193__8 = tmp23, nil, 0, 0; continue L1 } } }
//line :226:1
		break L1 }; var tmp24 any = A_arbace_c_musl_A_const_137; var tmp25 any = A_arbace_c_musl_A_const_138; var tmp26 any = A_arbace_c_musl_A_const_139; var tmp27 any = A_arbace_c_musl_A_const_140; var tmp28 any = A_arbace_c_musl_A_const_141; var tmp29 any; var root_1443 any = A_arbace_c_musl_A_const_41.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1445 lang.IFn; if







	linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1444 == nil { tmp29 = ifn_1445.Invoke_O__O(arg_1446) } else { tmp29 = linked_1444.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1443, arg_1446) }; return /*line :226:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp24, root__1, tmp25, h__0, tmp26, ix__3, tmp27, by__4, tmp28, tmp29)) }













func A_arbace_c_musl_closure_A_New() *A_arbace_c_musl_closure_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_closure_A{}; t.Ctor(); return t }
//line :240:1
func (t *A_arbace_c_musl_closure_A) Ctor() {}
//line :240:1
func (t *A_arbace_c_musl_closure_A) Invoke_O_O_O_O__O(self, lib__0, prog_defs__1, prog_refs__2 any) any { var map__1657000225__4 any = lib__0; var map__1657000225__5 any; if



	lang.ISeq_InstanceOf(map__1657000225__4) { var tmp1 any; var root_1583 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1585 lang.IFn; if linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = map__1657000225__4; if linked_1584 == nil { tmp1 = ifn_1585.Invoke_O__O(arg_1586) } else { tmp1 = linked_1584.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1583, arg_1586) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1587 any = A_arbace_c_musl_A_const_142.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = map__1657000225__4; if linked_1588 == nil { tmp2 = ifn_1589.Invoke_O__O(arg_1590) } else { tmp2 = linked_1588.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1587, arg_1590) }; map__1657000225__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1591 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = map__1657000225__4; if linked_1592 == nil { tmp3 = ifn_1593.Invoke_O__O(arg_1594) } else { tmp3 = linked_1592.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1591, arg_1594) }; if jrt.J2g_Truth(tmp3) { var root_1595 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any = map__1657000225__4; if linked_1596 == nil { map__1657000225__5 = ifn_1597.Invoke_O__O(arg_1598) } else { map__1657000225__5 = linked_1596.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1595, arg_1598) } } else { map__1657000225__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1657000225__5 = map__1657000225__4 }; var index__6 any = /*line :240:1*/lang.RT_Get_O_O__O_NoInit(map__1657000225__5, A_arbace_c_musl_A_const_139); var by_name__7 any = lang.RT_Get_O_O__O_NoInit(map__1657000225__5, A_arbace_c_musl_A_const_140); var defined__8 any = jrt.HashSet_New_Collection(jrt.Collection_Cast(prog_defs__1)); var linked__9 any = jrt.LinkedHashSet_New(); var q__10 any = jrt.ArrayDeque_New(); var seq_1657000227__11 any; var root_1603 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1603, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1605 lang.IFn; if







	linked_1604 == nil { ifn_1605 = lang.IFn_Cast(root_1603) } else { ifn_1605 = nil }; var arg_1606 any; var root_1607 any = A_arbace_c_musl_A_const_40.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1607, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1609 lang.IFn; if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any = A_arbace_c_musl_A_const_143.GetRawRoot__O(); var arg_1611 any = prog_refs__2; if linked_1608 == nil { arg_1606 = ifn_1609.Invoke_O_O__O(arg_1610, arg_1611) } else { arg_1606 = linked_1608.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1607, arg_1610, arg_1611) }; if linked_1604 == nil { seq_1657000227__11 = ifn_1605.Invoke_O__O(arg_1606) } else { seq_1657000227__11 = linked_1604.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1603, arg_1606) }; var chunk_1657000228__12 any; var count_1657000229__13 int64 = 0; var i_1657000230__14 int64 = 0; L1:
//line :240:1
	for {







		if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000230__14, count_1657000229__13) { var r__15 any = lang.Indexed_Cast(chunk_1657000228__12).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000230__14)); jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayDeque_Cast(q__10)).Add_O__Z(r__15)); seq_1657000227__11, chunk_1657000228__12, count_1657000229__13, i_1657000230__14 = seq_1657000227__11, chunk_1657000228__12, count_1657000229__13, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000230__14); continue L1 } else { var temp__1927000414__auto____15 any; var root_1612 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1612, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1614 lang.IFn; if linked_1613 == nil { ifn_1614 = lang.IFn_Cast(root_1612) } else { ifn_1614 = nil }; var arg_1615 any = seq_1657000227__11; if linked_1613 == nil { temp__1927000414__auto____15 = ifn_1614.Invoke_O__O(arg_1615) } else { temp__1927000414__auto____15 = linked_1613.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1612, arg_1615) }; if jrt.J2g_Truth(temp__1927000414__auto____15) { var seq_1657000227__16 any = temp__1927000414__auto____15; var tmp4 any; var root_1616 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1616, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1618 lang.IFn; if linked_1617 == nil { ifn_1618 = lang.IFn_Cast(root_1616) } else { ifn_1618 = nil }; var arg_1619 any = seq_1657000227__16; if linked_1617 == nil { tmp4 = ifn_1618.Invoke_O__O(arg_1619) } else { tmp4 = linked_1617.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1616, arg_1619) }; if jrt.J2g_Truth(tmp4) { var c__1927000678__auto____17 any; var root_1620 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = seq_1657000227__16; if linked_1621 == nil { c__1927000678__auto____17 = ifn_1622.Invoke_O__O(arg_1623) } else { c__1927000678__auto____17 = linked_1621.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1620, arg_1623) }; var tmp5 any; var root_1632 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_1633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1632, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1634 lang.IFn; if linked_1633 == nil { ifn_1634 = lang.IFn_Cast(root_1632) } else { ifn_1634 = nil }; var arg_1635 any = seq_1657000227__16; if linked_1633 == nil { tmp5 = ifn_1634.Invoke_O__O(arg_1635) } else { tmp5 = linked_1633.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1632, arg_1635) }; seq_1657000227__11, chunk_1657000228__12, count_1657000229__13, i_1657000230__14 = tmp5, c__1927000678__auto____17, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var r__17 any; var root_1624 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any = seq_1657000227__16; if linked_1625 == nil { r__17 = ifn_1626.Invoke_O__O(arg_1627) } else { r__17 = linked_1625.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1624, arg_1627) }; jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayDeque_Cast(q__10)).Add_O__Z(r__17)); var tmp6 any; var root_1636 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_1637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1636, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1638 lang.IFn; if linked_1637 == nil { ifn_1638 = lang.IFn_Cast(root_1636) } else { ifn_1638 = nil }; var arg_1639 any = seq_1657000227__16; if linked_1637 == nil { tmp6 = ifn_1638.Invoke_O__O(arg_1639) } else { tmp6 = linked_1637.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1636, arg_1639) }; seq_1657000227__11, chunk_1657000228__12, count_1657000229__13, i_1657000230__14 = tmp6, nil, 0, 0; continue L1 } } }
//line :240:1
		break L1 }; L2: for {








			var tmp7 any; var root_1628 any = A_arbace_c_musl_A_const_28.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1628, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1630 lang.IFn; if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayDeque_Cast(q__10)).IsEmpty__Z()).Ref(); if linked_1629 == nil { tmp7 = ifn_1630.Invoke_O__O(arg_1631) } else { tmp7 = linked_1629.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1628, arg_1631) }; if jrt.J2g_Truth(tmp7) { var n__11 any = jrt.NN(jrt.ArrayDeque_Cast(q__10)).Poll__O()

				if jrt.HashSet_Cast(defined__8).Contains_O__Z(n__11) { } else { var temp__1927000414__auto____12 any = jrt.HashMap_Cast(by_name__7).Get_O__O(n__11)
					if jrt.J2g_Truth(temp__1927000414__auto____12) { var cands__13 any = temp__1927000414__auto____12; var vec__1657000231__14 any; var or__1927000174__auto____14 any; var root_1640 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1642 lang.IFn
						if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any; var root_1644 any = A_arbace_c_musl_A_const_104.GetRawRoot__O(); var linked_1645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1644, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1646 lang.IFn; if linked_1645 == nil { ifn_1646 = lang.IFn_Cast(root_1644) } else { ifn_1646 = nil }; var arg_1647 any = A_arbace_c_musl_A_const_56.GetRawRoot__O(); var arg_1648 any = cands__13; if linked_1645 == nil { arg_1643 = ifn_1646.Invoke_O_O__O(arg_1647, arg_1648) } else { arg_1643 = linked_1645.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1644, arg_1647, arg_1648) }; if linked_1641 == nil { or__1927000174__auto____14 = ifn_1642.Invoke_O__O(arg_1643) } else { or__1927000174__auto____14 = linked_1641.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1640, arg_1643) }; if jrt.J2g_Truth(or__1927000174__auto____14) { vec__1657000231__14 = or__1927000174__auto____14 } else { var root_1649 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1651 lang.IFn; if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any = cands__13; if linked_1650 == nil { vec__1657000231__14 = ifn_1651.Invoke_O__O(arg_1652) } else { vec__1657000231__14 = linked_1650.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1649, arg_1652) } }
//line :252:1
						var s__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000231__14, lang.RT_IntCast_J__I_NoInit(0), nil); var ___16 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000231__14, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___16

						if jrt.HashSet_Cast(linked__9).Add_O__Z(s__15) { var map__1657000234__17 any = lang.RT_Get_O_O__O_NoInit(index__6, s__15); var map__1657000234__18 any
							if lang.ISeq_InstanceOf(map__1657000234__17) { var tmp8 any; var root_1653 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1655 lang.IFn; if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any = map__1657000234__17; if linked_1654 == nil { tmp8 = ifn_1655.Invoke_O__O(arg_1656) } else { tmp8 = linked_1654.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1653, arg_1656) }; if jrt.J2g_Truth(tmp8) { var tmp9 any; var root_1657 any = A_arbace_c_musl_A_const_142.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1657, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any = map__1657000234__17; if linked_1658 == nil { tmp9 = ifn_1659.Invoke_O__O(arg_1660) } else { tmp9 = linked_1658.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1657, arg_1660) }; map__1657000234__18 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp9)).Ref() } else { var tmp10 any; var root_1661 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1661, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1663 lang.IFn; if linked_1662 == nil { ifn_1663 = lang.IFn_Cast(root_1661) } else { ifn_1663 = nil }; var arg_1664 any = map__1657000234__17; if linked_1662 == nil { tmp10 = ifn_1663.Invoke_O__O(arg_1664) } else { tmp10 = linked_1662.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1661, arg_1664) }; if jrt.J2g_Truth(tmp10) { var root_1665 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1665, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1667 lang.IFn; if linked_1666 == nil { ifn_1667 = lang.IFn_Cast(root_1665) } else { ifn_1667 = nil }; var arg_1668 any = map__1657000234__17; if linked_1666 == nil { map__1657000234__18 = ifn_1667.Invoke_O__O(arg_1668) } else { map__1657000234__18 = linked_1666.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1665, arg_1668) } } else { map__1657000234__18 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1657000234__18 = map__1657000234__17 }
//line :254:1
							var defs__19 any = lang.RT_Get_O_O__O_NoInit(map__1657000234__18, A_arbace_c_musl_A_const_132); var refs__20 any = lang.RT_Get_O_O__O_NoInit(map__1657000234__18, A_arbace_c_musl_A_const_134); var seq_1657000236__21 any; var root_1689 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1689, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1691 lang.IFn

							if linked_1690 == nil { ifn_1691 = lang.IFn_Cast(root_1689) } else { ifn_1691 = nil }; var arg_1692 any; var root_1693 any = A_arbace_c_musl_A_const_101.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1695 lang.IFn; if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = defs__19; if linked_1694 == nil { arg_1692 = ifn_1695.Invoke_O__O(arg_1696) } else { arg_1692 = linked_1694.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1693, arg_1696) }; if linked_1690 == nil { seq_1657000236__21 = ifn_1691.Invoke_O__O(arg_1692) } else { seq_1657000236__21 = linked_1690.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1689, arg_1692) }
//line :254:1
							var chunk_1657000237__22 any; var count_1657000238__23 int64 = 0; var i_1657000239__24 int64 = 0; L3: for {

								if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000239__24, count_1657000238__23) { var d__25 any = lang.Indexed_Cast(chunk_1657000237__22).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000239__24)); jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.HashSet_Cast(defined__8).Add_O__Z(d__25)); seq_1657000236__21, chunk_1657000237__22, count_1657000238__23, i_1657000239__24 = seq_1657000236__21, chunk_1657000237__22, count_1657000238__23, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000239__24); continue L3 } else { var temp__1927000414__auto____25 any; var root_1697 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1699 lang.IFn; if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any = seq_1657000236__21; if linked_1698 == nil { temp__1927000414__auto____25 = ifn_1699.Invoke_O__O(arg_1700) } else { temp__1927000414__auto____25 = linked_1698.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1697, arg_1700) }; if jrt.J2g_Truth(temp__1927000414__auto____25) { var seq_1657000236__26 any = temp__1927000414__auto____25; var tmp11 any; var root_1701 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1701, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1703 lang.IFn; if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any = seq_1657000236__26; if linked_1702 == nil { tmp11 = ifn_1703.Invoke_O__O(arg_1704) } else { tmp11 = linked_1702.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1701, arg_1704) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____27 any; var root_1705 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_1706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1705, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1707 lang.IFn; if linked_1706 == nil { ifn_1707 = lang.IFn_Cast(root_1705) } else { ifn_1707 = nil }; var arg_1708 any = seq_1657000236__26; if linked_1706 == nil { c__1927000678__auto____27 = ifn_1707.Invoke_O__O(arg_1708) } else { c__1927000678__auto____27 = linked_1706.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1705, arg_1708) }; var tmp12 any; var root_1713 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var arg_1716 any = seq_1657000236__26; if linked_1714 == nil { tmp12 = ifn_1715.Invoke_O__O(arg_1716) } else { tmp12 = linked_1714.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1713, arg_1716) }; seq_1657000236__21, chunk_1657000237__22, count_1657000238__23, i_1657000239__24 = tmp12, c__1927000678__auto____27, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____27))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var d__27 any; var root_1709 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1709, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1711 lang.IFn; if linked_1710 == nil { ifn_1711 = lang.IFn_Cast(root_1709) } else { ifn_1711 = nil }; var arg_1712 any = seq_1657000236__26; if linked_1710 == nil { d__27 = ifn_1711.Invoke_O__O(arg_1712) } else { d__27 = linked_1710.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1709, arg_1712) }; jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.HashSet_Cast(defined__8).Add_O__Z(d__27)); var tmp13 any; var root_1717 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1719 lang.IFn; if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = seq_1657000236__26; if linked_1718 == nil { tmp13 = ifn_1719.Invoke_O__O(arg_1720) } else { tmp13 = linked_1718.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1717, arg_1720) }; seq_1657000236__21, chunk_1657000237__22, count_1657000238__23, i_1657000239__24 = tmp13, nil, 0, 0; continue L3 } } }
//line :254:1
								break L3 }; var seq_1657000240__21 any; var root_1669 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1669, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1671 lang.IFn


							if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any = refs__20; if linked_1670 == nil { seq_1657000240__21 = ifn_1671.Invoke_O__O(arg_1672) } else { seq_1657000240__21 = linked_1670.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1669, arg_1672) }
//line :254:1
							var chunk_1657000241__22 any; var count_1657000242__23 int64 = 0; var i_1657000243__24 int64 = 0; L4: for {


								if lang.Numbers_Lt_J_J__Z_NoInit(i_1657000243__24, count_1657000242__23) { var r__25 any = lang.Indexed_Cast(chunk_1657000241__22).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1657000243__24)); if jrt.HashSet_Cast(defined__8).Contains_O__Z(r__25) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayDeque_Cast(q__10)).Add_O__Z(r__25)) }; seq_1657000240__21, chunk_1657000241__22, count_1657000242__23, i_1657000243__24 = seq_1657000240__21, chunk_1657000241__22, count_1657000242__23, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1657000243__24); continue L4 } else { var temp__1927000414__auto____25_2 any; var root_1673 any = A_arbace_c_musl_A_const_25.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1675 lang.IFn; if linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any = seq_1657000240__21; if linked_1674 == nil { temp__1927000414__auto____25_2 = ifn_1675.Invoke_O__O(arg_1676) } else { temp__1927000414__auto____25_2 = linked_1674.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1673, arg_1676) }; if jrt.J2g_Truth(temp__1927000414__auto____25_2) { var seq_1657000240__26 any = temp__1927000414__auto____25_2; var tmp14 any; var root_1677 any = A_arbace_c_musl_A_const_30.GetRawRoot__O(); var linked_1678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1677, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1679 lang.IFn; if linked_1678 == nil { ifn_1679 = lang.IFn_Cast(root_1677) } else { ifn_1679 = nil }; var arg_1680 any = seq_1657000240__26; if linked_1678 == nil { tmp14 = ifn_1679.Invoke_O__O(arg_1680) } else { tmp14 = linked_1678.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1677, arg_1680) }; if jrt.J2g_Truth(tmp14) { var c__1927000678__auto____27_2 any; var root_1681 any = A_arbace_c_musl_A_const_31.GetRawRoot__O(); var linked_1682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1681, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1683 lang.IFn; if linked_1682 == nil { ifn_1683 = lang.IFn_Cast(root_1681) } else { ifn_1683 = nil }; var arg_1684 any = seq_1657000240__26; if linked_1682 == nil { c__1927000678__auto____27_2 = ifn_1683.Invoke_O__O(arg_1684) } else { c__1927000678__auto____27_2 = linked_1682.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1681, arg_1684) }; var tmp15 any; var root_1721 any = A_arbace_c_musl_A_const_37.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any = seq_1657000240__26; if linked_1722 == nil { tmp15 = ifn_1723.Invoke_O__O(arg_1724) } else { tmp15 = linked_1722.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1721, arg_1724) }; seq_1657000240__21, chunk_1657000241__22, count_1657000242__23, i_1657000243__24 = tmp15, c__1927000678__auto____27_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____27_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var r__27 any; var root_1685 any = A_arbace_c_musl_A_const_26.GetRawRoot__O(); var linked_1686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1685, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1687 lang.IFn; if linked_1686 == nil { ifn_1687 = lang.IFn_Cast(root_1685) } else { ifn_1687 = nil }; var arg_1688 any = seq_1657000240__26; if linked_1686 == nil { r__27 = ifn_1687.Invoke_O__O(arg_1688) } else { r__27 = linked_1686.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1685, arg_1688) }; if jrt.HashSet_Cast(defined__8).Contains_O__Z(r__27) { } else { jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.ArrayDeque_Cast(q__10)).Add_O__Z(r__27)) }; var tmp16 any; var root_1725 any = A_arbace_c_musl_A_const_52.GetRawRoot__O(); var linked_1726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1725, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1727 lang.IFn; if linked_1726 == nil { ifn_1727 = lang.IFn_Cast(root_1725) } else { ifn_1727 = nil }; var arg_1728 any = seq_1657000240__26; if linked_1726 == nil { tmp16 = ifn_1727.Invoke_O__O(arg_1728) } else { tmp16 = linked_1726.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1725, arg_1728) }; seq_1657000240__21, chunk_1657000241__22, count_1657000242__23, i_1657000243__24 = tmp16, nil, 0, 0; continue L4 } } }
//line :254:1
								break L4 } } } }
//line :249:1
				continue L2 }
//line :240:1
			break L2 }; var root_1599 any =

















	A_arbace_c_musl_A_const_23.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = linked__9; if linked_1600 == nil { return ifn_1601.Invoke_O__O(arg_1602) } else { return linked_1600.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1599, arg_1602) } }

func A_arbace_c_musl_checked_unit_A_New() *A_arbace_c_musl_checked_unit_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_checked_unit_A{}; t.Ctor(); return t }
//line :260:1
func (t *A_arbace_c_musl_checked_unit_A) Ctor() {}
//line :260:1
func (t *A_arbace_c_musl_checked_unit_A) Invoke_O_O_O__O(self, lib__0, src__1 any) any { var or__1927000174__auto____3 any; var tmp1 any; var root_1729 any = A_arbace_c_musl_A_const_9.GetRawRoot__O(); var linked_1730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1729, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1731 lang.IFn; if


	linked_1730 == nil { ifn_1731 = lang.IFn_Cast(root_1729) } else { ifn_1731 = nil }; var arg_1732 any = A_arbace_c_musl_A_const_141.Invoke_O__O(lib__0); if linked_1730 == nil { tmp1 = ifn_1731.Invoke_O__O(arg_1732) } else { tmp1 = linked_1730.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1729, arg_1732) }; or__1927000174__auto____3 = lang.RT_Get_O_O__O_NoInit(tmp1, src__1); if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var rd__4 any; var root_1733 any = A_arbace_c_musl_A_const_129.GetRawRoot__O(); var linked_1734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1733, A_arbace_c_musl_load_unit_A_fn_class); var ifn_1735 lang.IFn
		if linked_1734 == nil { ifn_1735 = lang.IFn_Cast(root_1733) } else { ifn_1735 = nil }; var arg_1736 any = A_arbace_c_musl_A_const_137.Invoke_O__O(lib__0); var arg_1737 any = src__1; if linked_1734 == nil { rd__4 = ifn_1735.Invoke_O_O__O(arg_1736, arg_1737) } else { rd__4 = linked_1734.(*A_arbace_c_musl_load_unit_A).Invoke_O_O_O__O(root_1733, arg_1736, arg_1737) }
//line :263:1
		var vec__1657000245__5 any; var root_1738 any = A_arbace_c_musl_A_const_83.GetRawRoot__O(); var linked_1739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1738, A_arbace_c_musl_config_A_fn_class); var ifn_1740 lang.IFn

		if linked_1739 == nil { ifn_1740 = lang.IFn_Cast(root_1738) } else { ifn_1740 = nil }; var arg_1741 any = A_arbace_c_musl_A_const_138.Invoke_O__O(lib__0); var arg_1742 any = A_arbace_c_musl_A_const_137.Invoke_O__O(lib__0); if linked_1739 == nil { vec__1657000245__5 = ifn_1740.Invoke_O_O__O(arg_1741, arg_1742) } else { vec__1657000245__5 = linked_1739.(*A_arbace_c_musl_config_A).Invoke_O_O_O__O(root_1738, arg_1741, arg_1742) }
//line :263:1
		var fc__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000245__5, lang.RT_IntCast_J__I_NoInit(0), nil); var ___7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1657000245__5, lang.RT_IntCast_J__I_NoInit(1), nil); var u__8 any; var root_1743 any = A_arbace_c_musl_A_const_17.GetRawRoot__O(); var linked_1744 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1743, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1745 lang.IFn; _ = ___7


		if linked_1744 == nil { ifn_1745 = lang.IFn_Cast(root_1743) } else { ifn_1745 = nil }; var arg_1746 any; var tmp2 any; var root_1749 any = A_arbace_c_musl_A_const_144.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any = A_arbace_c_musl_A_const_145; if linked_1750 == nil { tmp2 = ifn_1751.Invoke_O__O(arg_1752) } else { tmp2 = linked_1750.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_1749, arg_1752) }; arg_1746 = lang.IFn_Cast(tmp2).Invoke_O_O_O__O(A_arbace_c_musl_A_const_138.Invoke_O__O(lib__0), fc__6, rd__4); var arg_1747 any = A_arbace_c_musl_A_const_146; var arg_1748 any = src__1; if linked_1744 == nil { u__8 = ifn_1745.Invoke_O_O_O__O(arg_1746, arg_1747, arg_1748) } else { u__8 = linked_1744.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1743, arg_1746, arg_1747, arg_1748) }
		var root_1753 any = A_arbace_c_musl_A_const_109.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1753, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1755 lang.IFn; if linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = A_arbace_c_musl_A_const_141.Invoke_O__O(lib__0); var arg_1757 any = A_arbace_c_musl_A_const_17.GetRawRoot__O(); var arg_1758 any = src__1; var arg_1759 any = u__8; if linked_1754 == nil { ifn_1755.Invoke_O_O_O_O__O(arg_1756, arg_1757, arg_1758, arg_1759) } else { linked_1754.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_1753, arg_1756, arg_1757, arg_1758, arg_1759) }
//line :263:1
		return u__8 } }






func A_arbace_c_musl_build_linked_A_New() *A_arbace_c_musl_build_linked_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_build_linked_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_c_musl_build_linked_A) Ctor() {}
//line :270:1
func (t *A_arbace_c_musl_build_linked_A) Invoke_O_O_O__O(self, lib__0, units__1 any) any { var pdefs__3 any; var root_1760 any = A_arbace_c_musl_A_const_54.GetRawRoot__O(); var linked_1761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1760, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1762 lang.IFn; if


	linked_1761 == nil { ifn_1762 = lang.IFn_Cast(root_1760) } else { ifn_1762 = nil }; var arg_1763 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_130.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__1778 any = A_arbace_c_musl_build_linked_fn__1657000253_A_New(); var tmp3 *jrt.Class; var fncls__1777 *jrt.Class = A_arbace_c_musl_build_linked_fn__1657000253_A_fn_class; if fncls__1777 == nil { var fncls__1777d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_c_musl_build_linked_fn__1657000253_A_fn_class = fncls__1777d; tmp3 = fncls__1777d } else { tmp3 = fncls__1777 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1778, tmp3, nil); arg_1763 = tmp1.Invoke_O_O__O(tmp2.Ref(), units__1); if linked_1761 == nil { pdefs__3 = ifn_1762.Invoke_O__O(arg_1763) } else { pdefs__3 = linked_1761.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1760, arg_1763) }; var prefs__4 any; var root_1779 any = /*line :270:1*/A_arbace_c_musl_A_const_54.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1781 lang.IFn; if



	linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_130.GetRawRoot__O()); var tmp5 *lang.Compiler_AOTFn; var fnbody__1807 any = A_arbace_c_musl_build_linked_fn__1657000255_A_New(); var tmp6 *jrt.Class; var fncls__1806 *jrt.Class = A_arbace_c_musl_build_linked_fn__1657000255_A_fn_class; if fncls__1806 == nil { var fncls__1806d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_c_musl_build_linked_fn__1657000255_A_fn_class = fncls__1806d; tmp6 = fncls__1806d } else { tmp6 = fncls__1806 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1807, tmp6, nil); arg_1782 = tmp4.Invoke_O_O__O(tmp5.Ref(), units__1); if linked_1780 == nil { prefs__4 = ifn_1781.Invoke_O__O(arg_1782) } else { prefs__4 = linked_1780.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1779, arg_1782) }; var prefs__5 any; var root_1808 any = /*line :270:1*/A_arbace_c_musl_A_const_57.GetRawRoot__O(); var linked_1809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1808, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1810 lang.IFn; if





	linked_1809 == nil { ifn_1810 = lang.IFn_Cast(root_1808) } else { ifn_1810 = nil }; var arg_1811 any = prefs__4; var arg_1812 any; var root_1813 any = A_arbace_c_musl_A_const_148.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any; var fnbody__1829 any = A_arbace_c_musl_build_linked_fn__1657000257_A_New(); var tmp7 *jrt.Class; var fncls__1828 *jrt.Class = A_arbace_c_musl_build_linked_fn__1657000257_A_fn_class; if fncls__1828 == nil { var fncls__1828d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); A_arbace_c_musl_build_linked_fn__1657000257_A_fn_class = fncls__1828d; tmp7 = fncls__1828d } else { tmp7 = fncls__1828 }; arg_1816 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1829, tmp7, nil); var arg_1817 any = prefs__4; if linked_1814 == nil { arg_1812 = ifn_1815.Invoke_O_O__O(arg_1816, arg_1817) } else { arg_1812 = linked_1814.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1813, arg_1816, arg_1817) }; if linked_1809 == nil { prefs__5 = ifn_1810.Invoke_O_O__O(arg_1811, arg_1812) } else { prefs__5 = linked_1809.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1808, arg_1811, arg_1812) }; var srcs__6 any; var root_1830 any = /*line :270:1*/A_arbace_c_musl_A_const_151.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, A_arbace_c_musl_closure_A_fn_class); var ifn_1832 lang.IFn; if






	linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = lib__0; var arg_1834 any = pdefs__3; var arg_1835 any = prefs__5; if linked_1831 == nil { srcs__6 = ifn_1832.Invoke_O_O_O__O(arg_1833, arg_1834, arg_1835) } else { srcs__6 = linked_1831.(*A_arbace_c_musl_closure_A).Invoke_O_O_O_O__O(root_1830, arg_1833, arg_1834, arg_1835) }; var ___7 any; _ = ___7; if
	jrt.System_Getenv_String__String(Lit_6) != nil { var root_1874 any = A_arbace_c_musl_A_const_90.GetRawRoot__O(); var linked_1875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1874, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_1876 lang.IFn; if linked_1875 == nil { ifn_1876 = lang.IFn_Cast(root_1874) } else { ifn_1876 = nil }; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_91.GetRawRoot__O()); var tmp9 any = A_arbace_c_musl_A_const_114; var arg_1877 any = tmp8.Invoke_O_O__O(tmp9, A_arbace_c_musl_A_const_115.Get__O()); if linked_1875 == nil { ifn_1876.Invoke_O__O(arg_1877) } else { linked_1875.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_1874, arg_1877) }; var tmp10 *lang.Compiler_AOTFn; var fnbody__1846 any = A_arbace_c_musl_build_linked_fn__1657000259_A_New_O(srcs__6); var tmp11 *jrt.Class; var fncls__1845 *jrt.Class = A_arbace_c_musl_build_linked_fn__1657000259_A_fn_class; if fncls__1845 == nil { var fncls__1845d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__1846); A_arbace_c_musl_build_linked_fn__1657000259_A_fn_class = fncls__1845d; tmp11 = fncls__1845d } else { tmp11 = fncls__1845 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1846, tmp11, nil); ___7 = Up_Compiler_AOTFn_IFn(tmp10).Invoke__O() } else { ___7 = nil }; var mus__8 any; var root_1847 any = /*line :270:1*/A_arbace_c_musl_A_const_152.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1849 lang.IFn; if








	linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any; var fnbody__1858 any = A_arbace_c_musl_build_linked_fn__1657000261_A_New_O(lib__0); var tmp12 *jrt.Class; var fncls__1857 *jrt.Class = A_arbace_c_musl_build_linked_fn__1657000261_A_fn_class; if fncls__1857 == nil { var fncls__1857d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__1858); A_arbace_c_musl_build_linked_fn__1657000261_A_fn_class = fncls__1857d; tmp12 = fncls__1857d } else { tmp12 = fncls__1857 }; arg_1850 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1858, tmp12, nil); var arg_1851 any = srcs__6; if linked_1848 == nil { mus__8 = ifn_1849.Invoke_O_O__O(arg_1850, arg_1851) } else { mus__8 = linked_1848.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1847, arg_1850, arg_1851) }; var tmp13 lang.IFn =
	lang.IFn_Cast(A_arbace_c_musl_A_const_154.GetRawRoot__O()); var tmp14 any; var root_1865 any = A_arbace_c_musl_A_const_57.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1865, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var arg_1868 any; var root_1870 any = A_arbace_c_musl_A_const_23.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1870, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1872 lang.IFn; if linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any = units__1; if linked_1871 == nil { arg_1868 = ifn_1872.Invoke_O__O(arg_1873) } else { arg_1868 = linked_1871.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1870, arg_1873) }; var arg_1869 any = mus__8; if linked_1866 == nil { tmp14 = ifn_1867.Invoke_O_O__O(arg_1868, arg_1869) } else { tmp14 = linked_1866.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1865, arg_1868, arg_1869) }; return tmp13.Invoke_O_O_O__O(tmp14, A_arbace_c_musl_A_const_155, jrt.Boolean_TRUE.Ref()) }
//line :273:1
func A_arbace_c_musl_build_linked_fn__1657000253_A_New() *A_arbace_c_musl_build_linked_fn__1657000253_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_build_linked_fn__1657000253_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_c_musl_build_linked_fn__1657000253_A) Ctor() {}
//line :273:1
func (t *A_arbace_c_musl_build_linked_fn__1657000253_A) Invoke_O_O__O(self, p1__1657000249_SHARP___1 any) any { var root_1769 any = A_arbace_c_musl_A_const_101.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1771 lang.IFn; if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any; var root_1773 any = A_arbace_c_musl_A_const_133.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, A_arbace_c_musl_unit_defs_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var tmp1 *lang.Keyword = A_arbace_c_musl_A_const_120; var arg_1776 any = tmp1.Invoke_O__O(A_arbace_c_musl_A_const_147.Invoke_O__O(p1__1657000249_SHARP___1)); if linked_1774 == nil { arg_1772 = ifn_1775.Invoke_O__O(arg_1776) } else { arg_1772 = linked_1774.(*A_arbace_c_musl_unit_defs_A).Invoke_O_O__O(root_1773, arg_1776) }; if linked_1770 == nil { return ifn_1771.Invoke_O__O(arg_1772) } else { return linked_1770.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1769, arg_1772) } }
func A_arbace_c_musl_build_linked_fn__1657000255_A_New() *A_arbace_c_musl_build_linked_fn__1657000255_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_build_linked_fn__1657000255_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_c_musl_build_linked_fn__1657000255_A) Ctor() {}
//line :274:1
func (t *A_arbace_c_musl_build_linked_fn__1657000255_A) Invoke_O_O__O(self, p1__1657000250_SHARP___1 any) any { var root_1788 any = A_arbace_c_musl_A_const_135.GetRawRoot__O(); var linked_1789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1788, A_arbace_c_musl_refs_A_fn_class); var ifn_1790 lang.IFn; if linked_1789 == nil { ifn_1790 = lang.IFn_Cast(root_1788) } else { ifn_1790 = nil }; var arg_1791 any; var root_1792 any = A_arbace_c_musl_A_const_40.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1792, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1794 lang.IFn; if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var tmp1 *lang.Keyword = A_arbace_c_musl_A_const_120; var arg_1795 any = tmp1.Invoke_O__O(A_arbace_c_musl_A_const_147.Invoke_O__O(p1__1657000250_SHARP___1)); var arg_1796 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_130.GetRawRoot__O()); var tmp3 any = A_arbace_c_musl_A_const_120; var tmp4 any; var root_1802 any = A_arbace_c_musl_A_const_131.GetRawRoot__O(); var linked_1803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1802, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_1804 lang.IFn; if linked_1803 == nil { ifn_1804 = lang.IFn_Cast(root_1802) } else { ifn_1804 = nil }; var tmp5 *lang.Keyword = A_arbace_c_musl_A_const_102; var arg_1805 any = tmp5.Invoke_O__O(A_arbace_c_musl_A_const_147.Invoke_O__O(p1__1657000250_SHARP___1)); if linked_1803 == nil { tmp4 = ifn_1804.Invoke_O__O(arg_1805) } else { tmp4 = linked_1803.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_1802, arg_1805) }; arg_1796 = tmp2.Invoke_O_O__O(tmp3, tmp4); if linked_1793 == nil { arg_1791 = ifn_1794.Invoke_O_O__O(arg_1795, arg_1796) } else { arg_1791 = linked_1793.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1792, arg_1795, arg_1796) }; if linked_1789 == nil { return ifn_1790.Invoke_O__O(arg_1791) } else { return linked_1789.(*A_arbace_c_musl_refs_A).Invoke_O_O__O(root_1788, arg_1791) } }

func A_arbace_c_musl_build_linked_fn__1657000257_A_New() *A_arbace_c_musl_build_linked_fn__1657000257_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_build_linked_fn__1657000257_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_c_musl_build_linked_fn__1657000257_A) Ctor() {}
//line :276:1
func (t *A_arbace_c_musl_build_linked_fn__1657000257_A) Invoke_O_O__O(self, p1__1657000251_SHARP___1 any) any { var tmp1 any; var root_1818 any = A_arbace_c_musl_A_const_149.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = p1__1657000251_SHARP___1; var arg_1822 any = Lit_9; if linked_1819 == nil { tmp1 = ifn_1820.Invoke_O_O__O(arg_1821, arg_1822) } else { tmp1 = linked_1819.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1818, arg_1821, arg_1822) }; if jrt.J2g_Truth(tmp1) { var root_1823 any = A_arbace_c_musl_A_const_27.GetRawRoot__O(); var linked_1824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1823, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1825 lang.IFn; if linked_1824 == nil { ifn_1825 = lang.IFn_Cast(root_1823) } else { ifn_1825 = nil }; var arg_1826 any = p1__1657000251_SHARP___1; var arg_1827 any = A_arbace_c_musl_A_const_150; if linked_1824 == nil { return ifn_1825.Invoke_O_O__O(arg_1826, arg_1827) } else { return linked_1824.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1823, arg_1826, arg_1827) } } else { return nil } }

func A_arbace_c_musl_build_linked_fn__1657000259_A_New_O(p0 any) *A_arbace_c_musl_build_linked_fn__1657000259_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_build_linked_fn__1657000259_A{}; t.Ctor_O(p0); return t }
//line :278:1
func (t *A_arbace_c_musl_build_linked_fn__1657000259_A) Ctor_O(c__srcs any) { t.F_srcs = c__srcs }
//line :278:1
func (t *A_arbace_c_musl_build_linked_fn__1657000259_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c_musl_A_const_113.GetRawRoot__O()); var tmp3 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(t.F_srcs)).Ref(); var tmp4 any; var t_ any = t.F_srcs; t.F_srcs = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O_O_O__O(Lit_10, tmp3, tmp4) }; return nil }(); var root_1842 any = A_arbace_c_musl_A_const_85.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_1844 lang.IFn; if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; if linked_1843 == nil { ifn_1844.Invoke__O() } else { linked_1843.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_1842) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }
func A_arbace_c_musl_build_linked_fn__1657000261_A_New_O(p0 any) *A_arbace_c_musl_build_linked_fn__1657000261_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_build_linked_fn__1657000261_A{}; t.Ctor_O(p0); return t }
//line :279:1
func (t *A_arbace_c_musl_build_linked_fn__1657000261_A) Ctor_O(c__lib any) { t.F_lib = c__lib }
//line :279:1
func (t *A_arbace_c_musl_build_linked_fn__1657000261_A) Invoke_O_O__O(self, p1__1657000252_SHARP___1 any) any { var root_1852 any = A_arbace_c_musl_A_const_153.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, A_arbace_c_musl_checked_unit_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = t.F_lib; var arg_1856 any = p1__1657000252_SHARP___1; if linked_1853 == nil { return ifn_1854.Invoke_O_O__O(arg_1855, arg_1856) } else { return linked_1853.(*A_arbace_c_musl_checked_unit_A).Invoke_O_O_O__O(root_1852, arg_1855, arg_1856) } }















































































type A_arbace_c_musl_A struct{ jrt.Object }

var A_arbace_c_musl_A_const_pool *jrt.RefArray

var A_arbace_c_musl_A_const_0 *lang.Var

var A_arbace_c_musl_A_const_1 any

var A_arbace_c_musl_A_const_2 *lang.Var

var A_arbace_c_musl_A_const_3 any

var A_arbace_c_musl_A_const_4 any

var A_arbace_c_musl_A_const_5 any

var A_arbace_c_musl_A_const_6 any

var A_arbace_c_musl_A_const_7 any

var A_arbace_c_musl_A_const_8 *lang.Var

var A_arbace_c_musl_A_const_9 *lang.Var

var A_arbace_c_musl_A_const_10 *lang.Var

var A_arbace_c_musl_A_const_11 *lang.Var

var A_arbace_c_musl_A_const_12 any

var A_arbace_c_musl_A_const_13 *lang.Var

var A_arbace_c_musl_A_const_14 *lang.Var

var A_arbace_c_musl_A_const_15 *lang.Var

var A_arbace_c_musl_A_const_16 *lang.Var

var A_arbace_c_musl_A_const_17 *lang.Var

var A_arbace_c_musl_A_const_18 *lang.Var

var A_arbace_c_musl_A_const_19 *lang.Keyword

var A_arbace_c_musl_A_const_20 *lang.Keyword

var A_arbace_c_musl_A_const_21 *lang.Keyword

var A_arbace_c_musl_A_const_22 *lang.Keyword

var A_arbace_c_musl_A_const_23 *lang.Var

var A_arbace_c_musl_A_const_24 *lang.Var

var A_arbace_c_musl_A_const_25 *lang.Var

var A_arbace_c_musl_A_const_26 *lang.Var

var A_arbace_c_musl_A_const_27 *lang.Var

var A_arbace_c_musl_A_const_28 *lang.Var

var A_arbace_c_musl_A_const_29 *lang.Var

var A_arbace_c_musl_A_const_30 *lang.Var

var A_arbace_c_musl_A_const_31 *lang.Var

var A_arbace_c_musl_A_const_32 *lang.Var

var A_arbace_c_musl_A_const_33 *lang.Var

var A_arbace_c_musl_A_const_34 *lang.Var

var A_arbace_c_musl_A_const_35 *lang.Var

var A_arbace_c_musl_A_const_36 *lang.Var

var A_arbace_c_musl_A_const_37 *lang.Var

var A_arbace_c_musl_A_const_38 *lang.Var

var A_arbace_c_musl_A_const_39 *lang.Var

var A_arbace_c_musl_A_const_40 *lang.Var

var A_arbace_c_musl_A_const_41 *lang.Var

var A_arbace_c_musl_A_const_42 *lang.Var

var A_arbace_c_musl_A_const_43 *lang.Var

var A_arbace_c_musl_A_const_44 *lang.Var

var A_arbace_c_musl_A_const_45 any

var A_arbace_c_musl_A_const_46 *lang.Var

var A_arbace_c_musl_A_const_47 *lang.Var

var A_arbace_c_musl_A_const_48 *lang.Keyword

var A_arbace_c_musl_A_const_49 any

var A_arbace_c_musl_A_const_50 *lang.Var

var A_arbace_c_musl_A_const_51 *lang.Var

var A_arbace_c_musl_A_const_52 *lang.Var

var A_arbace_c_musl_A_const_53 any

var A_arbace_c_musl_A_const_54 *lang.Var

var A_arbace_c_musl_A_const_55 any

var A_arbace_c_musl_A_const_56 *lang.Var

var A_arbace_c_musl_A_const_57 *lang.Var

var A_arbace_c_musl_A_const_58 any

var A_arbace_c_musl_A_const_59 *lang.Var

var A_arbace_c_musl_A_const_60 *lang.Var

var A_arbace_c_musl_A_const_61 *lang.Var

var A_arbace_c_musl_A_const_62 *lang.Keyword

var A_arbace_c_musl_A_const_63 *lang.Keyword

var A_arbace_c_musl_A_const_64 *lang.Keyword

var A_arbace_c_musl_A_const_65 any

var A_arbace_c_musl_A_const_66 any

var A_arbace_c_musl_A_const_67 *lang.Keyword

var A_arbace_c_musl_A_const_68 *lang.Keyword

var A_arbace_c_musl_A_const_69 *lang.Keyword

var A_arbace_c_musl_A_const_70 *lang.Keyword

var A_arbace_c_musl_A_const_71 any

var A_arbace_c_musl_A_const_72 *lang.Var

var A_arbace_c_musl_A_const_73 any

var A_arbace_c_musl_A_const_74 any

var A_arbace_c_musl_A_const_75 any

var A_arbace_c_musl_A_const_76 *lang.Var

var A_arbace_c_musl_A_const_77 any

var A_arbace_c_musl_A_const_78 any

var A_arbace_c_musl_A_const_79 any

var A_arbace_c_musl_A_const_80 any

var A_arbace_c_musl_A_const_81 any

var A_arbace_c_musl_A_const_82 *lang.Var

var A_arbace_c_musl_A_const_83 *lang.Var

var A_arbace_c_musl_A_const_84 *lang.Var

var A_arbace_c_musl_A_const_85 *lang.Var

var A_arbace_c_musl_A_const_86 *lang.Keyword

var A_arbace_c_musl_A_const_87 *lang.Keyword

var A_arbace_c_musl_A_const_88 *lang.Var

var A_arbace_c_musl_A_const_89 *lang.Keyword

var A_arbace_c_musl_A_const_90 *lang.Var

var A_arbace_c_musl_A_const_91 *lang.Var

var A_arbace_c_musl_A_const_92 *lang.Var

var A_arbace_c_musl_A_const_93 *lang.Var

var A_arbace_c_musl_A_const_94 *lang.Var

var A_arbace_c_musl_A_const_95 *lang.Keyword

var A_arbace_c_musl_A_const_96 *lang.Var

var A_arbace_c_musl_A_const_97 *lang.Var

var A_arbace_c_musl_A_const_98 *lang.Var

var A_arbace_c_musl_A_const_99 *lang.Var

var A_arbace_c_musl_A_const_100 *lang.Var

var A_arbace_c_musl_A_const_101 *lang.Var

var A_arbace_c_musl_A_const_102 *lang.Keyword

var A_arbace_c_musl_A_const_103 *lang.Var

var A_arbace_c_musl_A_const_104 *lang.Var

var A_arbace_c_musl_A_const_105 any

var A_arbace_c_musl_A_const_106 *lang.Var

var A_arbace_c_musl_A_const_107 *lang.Var

var A_arbace_c_musl_A_const_108 *lang.Var

var A_arbace_c_musl_A_const_109 *lang.Var

var A_arbace_c_musl_A_const_110 *lang.Var

var A_arbace_c_musl_A_const_111 *lang.Var

var A_arbace_c_musl_A_const_112 any

var A_arbace_c_musl_A_const_113 *lang.Var

var A_arbace_c_musl_A_const_114 *lang.Var

var A_arbace_c_musl_A_const_115 *lang.Var

var A_arbace_c_musl_A_const_116 *lang.Var

var A_arbace_c_musl_A_const_117 *lang.Var

var A_arbace_c_musl_A_const_118 *lang.Var

var A_arbace_c_musl_A_const_119 *lang.Var

var A_arbace_c_musl_A_const_120 *lang.Keyword

var A_arbace_c_musl_A_const_121 any

var A_arbace_c_musl_A_const_122 *lang.Var

var A_arbace_c_musl_A_const_123 *lang.Var

var A_arbace_c_musl_A_const_124 *lang.Keyword

var A_arbace_c_musl_A_const_125 *lang.Var

var A_arbace_c_musl_A_const_126 *lang.Keyword

var A_arbace_c_musl_A_const_127 *lang.Var

var A_arbace_c_musl_A_const_128 *lang.Var

var A_arbace_c_musl_A_const_129 *lang.Var

var A_arbace_c_musl_A_const_130 *lang.Var

var A_arbace_c_musl_A_const_131 *lang.Var

var A_arbace_c_musl_A_const_132 *lang.Keyword

var A_arbace_c_musl_A_const_133 *lang.Var

var A_arbace_c_musl_A_const_134 *lang.Keyword

var A_arbace_c_musl_A_const_135 *lang.Var

var A_arbace_c_musl_A_const_136 *lang.Var

var A_arbace_c_musl_A_const_137 *lang.Keyword

var A_arbace_c_musl_A_const_138 *lang.Keyword

var A_arbace_c_musl_A_const_139 *lang.Keyword

var A_arbace_c_musl_A_const_140 *lang.Keyword

var A_arbace_c_musl_A_const_141 *lang.Keyword

var A_arbace_c_musl_A_const_142 *lang.Var

var A_arbace_c_musl_A_const_143 *lang.Var

var A_arbace_c_musl_A_const_144 *lang.Var

var A_arbace_c_musl_A_const_145 any

var A_arbace_c_musl_A_const_146 *lang.Keyword

var A_arbace_c_musl_A_const_147 *lang.Keyword

var A_arbace_c_musl_A_const_148 *lang.Var

var A_arbace_c_musl_A_const_149 *lang.Var

var A_arbace_c_musl_A_const_150 any

var A_arbace_c_musl_A_const_151 *lang.Var

var A_arbace_c_musl_A_const_152 *lang.Var

var A_arbace_c_musl_A_const_153 *lang.Var

var A_arbace_c_musl_A_const_154 *lang.Var

var A_arbace_c_musl_A_const_155 *lang.Keyword

var A_arbace_c_musl_A_init jrt.ClassInit

func A_arbace_c_musl_A_Init() { if !A_arbace_c_musl_A_init.Done() { A_arbace_c_musl_A_init.Run(A_arbace_c_musl_A_clinit) } }

func A_arbace_c_musl_A_clinit() { A_arbace_c_musl_A_clinit_p0(); A_arbace_c_musl_A_clinit_p1(); A_arbace_c_musl_A_clinit_p2(); A_arbace_c_musl_A_clinit_p3(); A_arbace_c_musl_A_clinit_p4(); A_arbace_c_musl_A_clinit_p5(); A_arbace_c_musl_A_clinit_p6(); A_arbace_c_musl_A_clinit_p7(); A_arbace_c_musl_A_clinit_p8(); A_arbace_c_musl_A_clinit_p9(); A_arbace_c_musl_A_clinit_p10(); A_arbace_c_musl_A_clinit_p11(); A_arbace_c_musl_A_clinit_p12() }

func A_arbace_c_musl_A_clinit_p0() { jrt.StartCheck(); A_arbace_c_musl_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 213); A_arbace_c_musl_A_const_0 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[57]); A_arbace_c_musl_A_const_1 = A_arbace_c_musl_A_const_pool.A[58]; A_arbace_c_musl_A_const_2 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[59]); A_arbace_c_musl_A_const_3 = A_arbace_c_musl_A_const_pool.A[60]; A_arbace_c_musl_A_const_4 = A_arbace_c_musl_A_const_pool.A[61]; A_arbace_c_musl_A_const_5 = A_arbace_c_musl_A_const_pool.A[62]; A_arbace_c_musl_A_const_6 = A_arbace_c_musl_A_const_pool.A[63]; A_arbace_c_musl_A_const_7 = A_arbace_c_musl_A_const_pool.A[64]; A_arbace_c_musl_A_const_8 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[65]); A_arbace_c_musl_A_const_9 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[66]); A_arbace_c_musl_A_const_10 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[67]); A_arbace_c_musl_A_const_11 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[68]); A_arbace_c_musl_A_const_12 = A_arbace_c_musl_A_const_pool.A[69] }

func A_arbace_c_musl_A_clinit_p1() { A_arbace_c_musl_A_const_13 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[70]); A_arbace_c_musl_A_const_14 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[71]); A_arbace_c_musl_A_const_15 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[72]); A_arbace_c_musl_A_const_16 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[73]); A_arbace_c_musl_A_const_17 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[74]); A_arbace_c_musl_A_const_18 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[75]); A_arbace_c_musl_A_const_19 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[76]); A_arbace_c_musl_A_const_20 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[77]); A_arbace_c_musl_A_const_21 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[78]); A_arbace_c_musl_A_const_22 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[79]); A_arbace_c_musl_A_const_23 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[80]); A_arbace_c_musl_A_const_24 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[81]) }

func A_arbace_c_musl_A_clinit_p2() { A_arbace_c_musl_A_const_25 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[82]); A_arbace_c_musl_A_const_26 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[83]); A_arbace_c_musl_A_const_27 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[84]); A_arbace_c_musl_A_const_28 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[85]); A_arbace_c_musl_A_const_29 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[86]); A_arbace_c_musl_A_const_30 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[87]); A_arbace_c_musl_A_const_31 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[88]); A_arbace_c_musl_A_const_32 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[89]); A_arbace_c_musl_A_const_33 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[90]); A_arbace_c_musl_A_const_34 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[91]); A_arbace_c_musl_A_const_35 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[92]); A_arbace_c_musl_A_const_36 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[93]) }

func A_arbace_c_musl_A_clinit_p3() { A_arbace_c_musl_A_const_37 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[94]); A_arbace_c_musl_A_const_38 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[95]); A_arbace_c_musl_A_const_39 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[96]); A_arbace_c_musl_A_const_40 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[97]); A_arbace_c_musl_A_const_41 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[98]); A_arbace_c_musl_A_const_42 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[99]); A_arbace_c_musl_A_const_43 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[100]); A_arbace_c_musl_A_const_44 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[101]); A_arbace_c_musl_A_const_45 = A_arbace_c_musl_A_const_pool.A[102]; A_arbace_c_musl_A_const_46 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[103]); A_arbace_c_musl_A_const_47 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[104]); A_arbace_c_musl_A_const_48 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[105]) }

func A_arbace_c_musl_A_clinit_p4() { A_arbace_c_musl_A_const_49 = A_arbace_c_musl_A_const_pool.A[106]; A_arbace_c_musl_A_const_50 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[107]); A_arbace_c_musl_A_const_51 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[108]); A_arbace_c_musl_A_const_52 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[109]); A_arbace_c_musl_A_const_53 = A_arbace_c_musl_A_const_pool.A[110]; A_arbace_c_musl_A_const_54 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[111]); A_arbace_c_musl_A_const_55 = A_arbace_c_musl_A_const_pool.A[112]; A_arbace_c_musl_A_const_56 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[113]); A_arbace_c_musl_A_const_57 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[114]); A_arbace_c_musl_A_const_58 = A_arbace_c_musl_A_const_pool.A[115]; A_arbace_c_musl_A_const_59 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[116]); A_arbace_c_musl_A_const_60 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[117]); A_arbace_c_musl_A_const_61 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[118]) }

func A_arbace_c_musl_A_clinit_p5() { A_arbace_c_musl_A_const_62 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[119]); A_arbace_c_musl_A_const_63 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[120]); A_arbace_c_musl_A_const_64 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[121]); A_arbace_c_musl_A_const_65 = A_arbace_c_musl_A_const_pool.A[122]; A_arbace_c_musl_A_const_66 = A_arbace_c_musl_A_const_pool.A[123]; A_arbace_c_musl_A_const_67 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[124]); A_arbace_c_musl_A_const_68 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[125]); A_arbace_c_musl_A_const_69 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[126]); A_arbace_c_musl_A_const_70 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[127]); A_arbace_c_musl_A_const_71 = A_arbace_c_musl_A_const_pool.A[128]; A_arbace_c_musl_A_const_72 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[129]); A_arbace_c_musl_A_const_73 = A_arbace_c_musl_A_const_pool.A[130]; A_arbace_c_musl_A_const_74 = A_arbace_c_musl_A_const_pool.A[131] }

func A_arbace_c_musl_A_clinit_p6() { A_arbace_c_musl_A_const_75 = A_arbace_c_musl_A_const_pool.A[132]; A_arbace_c_musl_A_const_76 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[133]); A_arbace_c_musl_A_const_77 = A_arbace_c_musl_A_const_pool.A[134]; A_arbace_c_musl_A_const_78 = A_arbace_c_musl_A_const_pool.A[135]; A_arbace_c_musl_A_const_79 = A_arbace_c_musl_A_const_pool.A[136]; A_arbace_c_musl_A_const_80 = A_arbace_c_musl_A_const_pool.A[137]; A_arbace_c_musl_A_const_81 = A_arbace_c_musl_A_const_pool.A[138]; A_arbace_c_musl_A_const_82 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[139]); A_arbace_c_musl_A_const_83 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[140]); A_arbace_c_musl_A_const_84 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[141]); A_arbace_c_musl_A_const_85 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[142]); A_arbace_c_musl_A_const_86 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[143]); A_arbace_c_musl_A_const_87 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[144]) }

func A_arbace_c_musl_A_clinit_p7() { A_arbace_c_musl_A_const_88 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[145]); A_arbace_c_musl_A_const_89 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[146]); A_arbace_c_musl_A_const_90 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[147]); A_arbace_c_musl_A_const_91 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[148]); A_arbace_c_musl_A_const_92 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[149]); A_arbace_c_musl_A_const_93 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[150]); A_arbace_c_musl_A_const_94 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[151]); A_arbace_c_musl_A_const_95 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[152]); A_arbace_c_musl_A_const_96 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[153]); A_arbace_c_musl_A_const_97 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[154]); A_arbace_c_musl_A_const_98 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[155]); A_arbace_c_musl_A_const_99 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[156]) }

func A_arbace_c_musl_A_clinit_p8() { A_arbace_c_musl_A_const_100 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[157]); A_arbace_c_musl_A_const_101 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[158]); A_arbace_c_musl_A_const_102 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[159]); A_arbace_c_musl_A_const_103 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[160]); A_arbace_c_musl_A_const_104 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[161]); A_arbace_c_musl_A_const_105 = A_arbace_c_musl_A_const_pool.A[162]; A_arbace_c_musl_A_const_106 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[163]); A_arbace_c_musl_A_const_107 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[164]); A_arbace_c_musl_A_const_108 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[165]); A_arbace_c_musl_A_const_109 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[166]); A_arbace_c_musl_A_const_110 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[167]); A_arbace_c_musl_A_const_111 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[168]) }

func A_arbace_c_musl_A_clinit_p9() { A_arbace_c_musl_A_const_112 = A_arbace_c_musl_A_const_pool.A[169]; A_arbace_c_musl_A_const_113 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[170]); A_arbace_c_musl_A_const_114 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[171]); A_arbace_c_musl_A_const_115 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[172]); A_arbace_c_musl_A_const_116 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[173]); A_arbace_c_musl_A_const_117 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[174]); A_arbace_c_musl_A_const_118 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[175]); A_arbace_c_musl_A_const_119 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[176]); A_arbace_c_musl_A_const_120 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[177]); A_arbace_c_musl_A_const_121 = A_arbace_c_musl_A_const_pool.A[178]; A_arbace_c_musl_A_const_122 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[179]); A_arbace_c_musl_A_const_123 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[180]) }

func A_arbace_c_musl_A_clinit_p10() { A_arbace_c_musl_A_const_124 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[181]); A_arbace_c_musl_A_const_125 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[182]); A_arbace_c_musl_A_const_126 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[183]); A_arbace_c_musl_A_const_127 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[184]); A_arbace_c_musl_A_const_128 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[185]); A_arbace_c_musl_A_const_129 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[186]); A_arbace_c_musl_A_const_130 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[187]); A_arbace_c_musl_A_const_131 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[188]); A_arbace_c_musl_A_const_132 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[189]); A_arbace_c_musl_A_const_133 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[190]); A_arbace_c_musl_A_const_134 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[191]); A_arbace_c_musl_A_const_135 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[192]) }

func A_arbace_c_musl_A_clinit_p11() { A_arbace_c_musl_A_const_136 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[193]); A_arbace_c_musl_A_const_137 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[194]); A_arbace_c_musl_A_const_138 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[195]); A_arbace_c_musl_A_const_139 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[196]); A_arbace_c_musl_A_const_140 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[197]); A_arbace_c_musl_A_const_141 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[198]); A_arbace_c_musl_A_const_142 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[199]); A_arbace_c_musl_A_const_143 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[200]); A_arbace_c_musl_A_const_144 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[201]); A_arbace_c_musl_A_const_145 = A_arbace_c_musl_A_const_pool.A[202]; A_arbace_c_musl_A_const_146 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[203]); A_arbace_c_musl_A_const_147 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[204]) }

func A_arbace_c_musl_A_clinit_p12() { A_arbace_c_musl_A_const_148 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[205]); A_arbace_c_musl_A_const_149 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[206]); A_arbace_c_musl_A_const_150 = A_arbace_c_musl_A_const_pool.A[207]; A_arbace_c_musl_A_const_151 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[208]); A_arbace_c_musl_A_const_152 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[209]); A_arbace_c_musl_A_const_153 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[210]); A_arbace_c_musl_A_const_154 = lang.Var_Cast(A_arbace_c_musl_A_const_pool.A[211]); A_arbace_c_musl_A_const_155 = lang.Keyword_Cast(A_arbace_c_musl_A_const_pool.A[212]) }

func A_arbace_c_musl_A_New() *A_arbace_c_musl_A { A_arbace_c_musl_A_Init(); t := &A_arbace_c_musl_A{}; t.Ctor(); return t }

func (t *A_arbace_c_musl_A) Ctor() {}

func (t *A_arbace_c_musl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_musl_A) GetClass__Class() *jrt.Class { return A_arbace_c_musl_A_class }

func (t *A_arbace_c_musl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_musl_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_musl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_musl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_musl_A); return ok }

func A_arbace_c_musl_A_Cast(x any) *A_arbace_c_musl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_musl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_musl_A_class)) }; return v }



type A_arbace_c_musl_attr_names_A struct{ j2g_header uint64 }

var A_arbace_c_musl_attr_names_A_fn_class *jrt.Class



type A_arbace_c_musl_attr_names_walk__1657000035_A struct{ j2g_header uint64; F_names, F_alias any }

var A_arbace_c_musl_attr_names_walk__1657000035_A_fn_class *jrt.Class



type A_arbace_c_musl_build_linked_A struct{ j2g_header uint64 }

var A_arbace_c_musl_build_linked_A_fn_class *jrt.Class



type A_arbace_c_musl_build_linked_fn__1657000253_A struct{ j2g_header uint64 }

var A_arbace_c_musl_build_linked_fn__1657000253_A_fn_class *jrt.Class



type A_arbace_c_musl_build_linked_fn__1657000255_A struct{ j2g_header uint64 }

var A_arbace_c_musl_build_linked_fn__1657000255_A_fn_class *jrt.Class



type A_arbace_c_musl_build_linked_fn__1657000257_A struct{ j2g_header uint64 }

var A_arbace_c_musl_build_linked_fn__1657000257_A_fn_class *jrt.Class



type A_arbace_c_musl_build_linked_fn__1657000259_A struct{ j2g_header uint64; F_srcs any }

var A_arbace_c_musl_build_linked_fn__1657000259_A_fn_class *jrt.Class



type A_arbace_c_musl_build_linked_fn__1657000261_A struct{ j2g_header uint64; F_lib any }

var A_arbace_c_musl_build_linked_fn__1657000261_A_fn_class *jrt.Class



type A_arbace_c_musl_checked_unit_A struct{ j2g_header uint64 }

var A_arbace_c_musl_checked_unit_A_fn_class *jrt.Class



type A_arbace_c_musl_closure_A struct{ j2g_header uint64 }

var A_arbace_c_musl_closure_A_fn_class *jrt.Class



type A_arbace_c_musl_config_A struct{ j2g_header uint64 }

var A_arbace_c_musl_config_A_fn_class *jrt.Class



type A_arbace_c_musl_env_A struct{ j2g_header uint64 }

var A_arbace_c_musl_env_A_fn_class *jrt.Class



type A_arbace_c_musl_eval1657000004_A struct{ jrt.Object }

func A_arbace_c_musl_eval1657000004_A_New() *A_arbace_c_musl_eval1657000004_A { t := &A_arbace_c_musl_eval1657000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c_musl_eval1657000004_A) Ctor() {}

func (t *A_arbace_c_musl_eval1657000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_musl_eval1657000004_A) GetClass__Class() *jrt.Class { return A_arbace_c_musl_eval1657000004_A_class }

func (t *A_arbace_c_musl_eval1657000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_musl_eval1657000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_musl_eval1657000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_musl_eval1657000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_musl_eval1657000004_A); return ok }

func A_arbace_c_musl_eval1657000004_A_Cast(x any) *A_arbace_c_musl_eval1657000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_musl_eval1657000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_musl_eval1657000004_A_class)) }; return v }



type A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A struct{ j2g_header uint64 }

var A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A_fn_class *jrt.Class



type A_arbace_c_musl_eval1657000008_A struct{ jrt.Object }

func A_arbace_c_musl_eval1657000008_A_New() *A_arbace_c_musl_eval1657000008_A { t := &A_arbace_c_musl_eval1657000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c_musl_eval1657000008_A) Ctor() {}

func (t *A_arbace_c_musl_eval1657000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c_musl_eval1657000008_A) GetClass__Class() *jrt.Class { return A_arbace_c_musl_eval1657000008_A_class }

func (t *A_arbace_c_musl_eval1657000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c_musl_eval1657000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c_musl_eval1657000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c_musl_eval1657000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c_musl_eval1657000008_A); return ok }

func A_arbace_c_musl_eval1657000008_A_Cast(x any) *A_arbace_c_musl_eval1657000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c_musl_eval1657000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c_musl_eval1657000008_A_class)) }; return v }



type A_arbace_c_musl_eval1657000008_fn__1657000009_A struct{ j2g_header uint64 }

var A_arbace_c_musl_eval1657000008_fn__1657000009_A_fn_class *jrt.Class



type A_arbace_c_musl_forms_root_A struct{ j2g_header uint64 }

var A_arbace_c_musl_forms_root_A_fn_class *jrt.Class



type A_arbace_c_musl_index_A struct{ j2g_header uint64 }

var A_arbace_c_musl_index_A_fn_class *jrt.Class



type A_arbace_c_musl_index_iter__1657000179__1657000183_A struct{ j2g_header uint64; F_root any }

var A_arbace_c_musl_index_iter__1657000179__1657000183_A_fn_class *jrt.Class



type A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_A struct{ j2g_header uint64; F_root, F_iter__1657000179, F_s__1657000180 any }

var A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_A_fn_class *jrt.Class



type A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_fn__1657000185_A struct{ j2g_header uint64; F_root any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1657000182 any }

var A_arbace_c_musl_index_iter__1657000179__1657000183_fn__1657000184_fn__1657000185_A_fn_class *jrt.Class



type A_arbace_c_musl_library_A struct{ j2g_header uint64 }

var A_arbace_c_musl_library_A_fn_class *jrt.Class



type A_arbace_c_musl_load_forms_A struct{ j2g_header uint64 }

var A_arbace_c_musl_load_forms_A_fn_class *jrt.Class



type A_arbace_c_musl_load_forms_iter__1657000155__1657000159_A struct{ j2g_header uint64; F_fr any }

var A_arbace_c_musl_load_forms_iter__1657000155__1657000159_A_fn_class *jrt.Class



type A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_A struct{ j2g_header uint64; F_iter__1657000155, F_fr, F_s__1657000156 any }

var A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_A_fn_class *jrt.Class



type A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_A struct{ j2g_header uint64; F_b__1657000158, F_fr any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_A_fn_class *jrt.Class



type A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_fn__1657000165_A struct{ j2g_header uint64 }

var A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000161_fn__1657000165_A_fn_class *jrt.Class



type A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000172_A struct{ j2g_header uint64 }

var A_arbace_c_musl_load_forms_iter__1657000155__1657000159_fn__1657000160_fn__1657000172_A_fn_class *jrt.Class



type A_arbace_c_musl_load_unit_A struct{ j2g_header uint64 }

var A_arbace_c_musl_load_unit_A_fn_class *jrt.Class



type A_arbace_c_musl_musl_root_A struct{ j2g_header uint64 }

var A_arbace_c_musl_musl_root_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_A struct{ j2g_header uint64 }

var A_arbace_c_musl_read_all_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_fn__1657000122_A struct{ j2g_header uint64; F_fr any }

var A_arbace_c_musl_read_all_fn__1657000122_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000124__1657000128_A struct{ j2g_header uint64; F_todo, F_root, F_n, F_h, F_errs, F_q any }

var A_arbace_c_musl_read_all_iter__1657000124__1657000128_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_A struct{ j2g_header uint64; F_todo, F_root, F_iter__1657000124, F_n, F_h, F_errs, F_q, F_s__1657000125 any }

var A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_A struct{ j2g_header uint64; F_todo, F_root, F_n, F_h, F_errs, F_q, F_b__1657000127 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_A struct{ j2g_header uint64; F_todo, F_root, F_n, F_h, F_errs, F_q any }

var A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000132_A struct{ j2g_header uint64; F_root, F_h, F_s any }

var A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000132_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000134_A struct{ j2g_header uint64; F_todo, F_k any }

var A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000130_fn__1657000131_fn__1657000134_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_A struct{ j2g_header uint64; F_todo, F_root, F_n, F_h, F_errs, F_q any }

var A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000139_A struct{ j2g_header uint64; F_root, F_h, F_s any }

var A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000139_A_fn_class *jrt.Class



type A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000141_A struct{ j2g_header uint64; F_todo, F_k any }

var A_arbace_c_musl_read_all_iter__1657000124__1657000128_fn__1657000129_fn__1657000138_fn__1657000141_A_fn_class *jrt.Class



type A_arbace_c_musl_read_one_A struct{ j2g_header uint64 }

var A_arbace_c_musl_read_one_A_fn_class *jrt.Class



type A_arbace_c_musl_read_one_fn__1657000108_A struct{ j2g_header uint64; F_src, F_fc, F_cfg any }

var A_arbace_c_musl_read_one_fn__1657000108_A_fn_class *jrt.Class



type A_arbace_c_musl_refs_A struct{ j2g_header uint64 }

var A_arbace_c_musl_refs_A_fn_class *jrt.Class



type A_arbace_c_musl_refs_decl__1657000081_A struct{ j2g_header uint64; F_walk, F_walk_meta any }

var A_arbace_c_musl_refs_decl__1657000081_A_fn_class *jrt.Class



type A_arbace_c_musl_refs_walk__1657000075_A struct{ j2g_header uint64; F_acc any }

var A_arbace_c_musl_refs_walk__1657000075_A_fn_class *jrt.Class



type A_arbace_c_musl_refs_walk_meta__1657000094_A struct{ j2g_header uint64; F_acc any }

var A_arbace_c_musl_refs_walk_meta__1657000094_A_fn_class *jrt.Class



type A_arbace_c_musl_sources_A struct{ j2g_header uint64 }

var A_arbace_c_musl_sources_A_fn_class *jrt.Class



type A_arbace_c_musl_sources_iter__1657000018__1657000024_A struct{ j2g_header uint64; F_m any }

var A_arbace_c_musl_sources_iter__1657000018__1657000024_A_fn_class *jrt.Class



type A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A struct{ j2g_header uint64; F_s__1657000019, F_iter__1657000018, F_m any }

var A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A_fn_class *jrt.Class



type A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A struct{ j2g_header uint64; F_rel any }

var A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A_fn_class *jrt.Class



type A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A struct{ j2g_header uint64; F_rel, F_s__1657000021, F_iter__1657000020 any }

var A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A_fn_class *jrt.Class



type A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A struct{ j2g_header uint64; F_b__1657000023, F_rel any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A_fn_class *jrt.Class



type A_arbace_c_musl_spit_mk_A struct{ j2g_header uint64 }

var A_arbace_c_musl_spit_mk_A_fn_class *jrt.Class



type A_arbace_c_musl_sym_name_A struct{ j2g_header uint64 }

var A_arbace_c_musl_sym_name_A_fn_class *jrt.Class



type A_arbace_c_musl_unit_defs_A struct{ j2g_header uint64 }

var A_arbace_c_musl_unit_defs_A_fn_class *jrt.Class



type A_arbace_c_musl_unit_defs_decl__1657000054_A struct{ j2g_header uint64; F_out any }

var A_arbace_c_musl_unit_defs_decl__1657000054_A_fn_class *jrt.Class
