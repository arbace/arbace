//line j2g_classes.ae:1
package aot_arbace_c_musl

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_c_musl_attr_names_A_class, Name: "arbace.c.musl$attr_names", Modifiers: 25, Simple: "attr_names", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_attr_names_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_attr_names_walk__1657000035_A_class, Name: "arbace.c.musl$attr_names$walk__1657000035", Modifiers: 25, Simple: "walk__1657000035", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_attr_names_walk__1657000035_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_attr_names_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_build_linked_A_class, Name: "arbace.c.musl$build_linked", Modifiers: 25, Simple: "build_linked", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_build_linked_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_build_linked_fn__1657000243_A_class, Name: "arbace.c.musl$build_linked$fn__1657000243", Modifiers: 25, Simple: "fn__1657000243", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_build_linked_fn__1657000243_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_build_linked_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_build_linked_fn__1657000245_A_class, Name: "arbace.c.musl$build_linked$fn__1657000245", Modifiers: 25, Simple: "fn__1657000245", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_build_linked_fn__1657000245_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_build_linked_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_build_linked_fn__1657000247_A_class, Name: "arbace.c.musl$build_linked$fn__1657000247", Modifiers: 25, Simple: "fn__1657000247", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_build_linked_fn__1657000247_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_build_linked_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_build_linked_fn__1657000249_A_class, Name: "arbace.c.musl$build_linked$fn__1657000249", Modifiers: 25, Simple: "fn__1657000249", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_build_linked_fn__1657000249_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_build_linked_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_build_linked_fn__1657000251_A_class, Name: "arbace.c.musl$build_linked$fn__1657000251", Modifiers: 25, Simple: "fn__1657000251", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_build_linked_fn__1657000251_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_build_linked_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_checked_unit_A_class, Name: "arbace.c.musl$checked_unit", Modifiers: 25, Simple: "checked_unit", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_checked_unit_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_closure_A_class, Name: "arbace.c.musl$closure", Modifiers: 25, Simple: "closure", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_closure_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_config_A_class, Name: "arbace.c.musl$config", Modifiers: 25, Simple: "config", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_config_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_env_A_class, Name: "arbace.c.musl$env", Modifiers: 25, Simple: "env", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_env_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A_class, Name: "arbace.c.musl$eval1657000004$loading__1927001464__auto____1657000005", Modifiers: 25, Simple: "loading__1927001464__auto____1657000005", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_eval1657000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_eval1657000008_fn__1657000009_A_class, Name: "arbace.c.musl$eval1657000008$fn__1657000009", Modifiers: 25, Simple: "fn__1657000009", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_eval1657000008_fn__1657000009_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_eval1657000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_forms_root_A_class, Name: "arbace.c.musl$forms_root", Modifiers: 25, Simple: "forms_root", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_forms_root_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_index_A_class, Name: "arbace.c.musl$index", Modifiers: 25, Simple: "index", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_index_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_index_iter__1657000169__1657000173_A_class, Name: "arbace.c.musl$index$iter__1657000169__1657000173", Modifiers: 25, Simple: "iter__1657000169__1657000173", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_index_iter__1657000169__1657000173_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_index_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A_class, Name: "arbace.c.musl$index$iter__1657000169__1657000173$fn__1657000174", Modifiers: 25, Simple: "fn__1657000174", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_index_iter__1657000169__1657000173_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_fn__1657000175_A_class, Name: "arbace.c.musl$index$iter__1657000169__1657000173$fn__1657000174$fn__1657000175", Modifiers: 25, Simple: "fn__1657000175", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_fn__1657000175_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_library_A_class, Name: "arbace.c.musl$library", Modifiers: 25, Simple: "library", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_library_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_load_unit_A_class, Name: "arbace.c.musl$load_unit", Modifiers: 25, Simple: "load_unit", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_load_unit_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A_class, Name: "arbace.c.musl$load_unit$iter__1657000152__1657000156", Modifiers: 25, Simple: "iter__1657000152__1657000156", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_load_unit_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A_class, Name: "arbace.c.musl$load_unit$iter__1657000152__1657000156$fn__1657000157", Modifiers: 25, Simple: "fn__1657000157", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_fn__1657000158_A_class, Name: "arbace.c.musl$load_unit$iter__1657000152__1657000156$fn__1657000157$fn__1657000158", Modifiers: 25, Simple: "fn__1657000158", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_fn__1657000158_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_musl_root_A_class, Name: "arbace.c.musl$musl_root", Modifiers: 25, Simple: "musl_root", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_musl_root_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_read_all_A_class, Name: "arbace.c.musl$read_all", Modifiers: 25, Simple: "read_all", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_read_all_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_read_all_fn__1657000120_A_class, Name: "arbace.c.musl$read_all$fn__1657000120", Modifiers: 25, Simple: "fn__1657000120", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_read_all_fn__1657000120_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_read_all_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_A_class, Name: "arbace.c.musl$read_all$iter__1657000122__1657000126", Modifiers: 25, Simple: "iter__1657000122__1657000126", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_read_all_iter__1657000122__1657000126_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_read_all_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A_class, Name: "arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127", Modifiers: 25, Simple: "fn__1657000127", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A_class, Name: "arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000128", Modifiers: 25, Simple: "fn__1657000128", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A_class, Name: "arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000128$fn__1657000129", Modifiers: 25, Simple: "fn__1657000129", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000130_A_class, Name: "arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000128$fn__1657000129$fn__1657000130", Modifiers: 25, Simple: "fn__1657000130", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000130_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000132_A_class, Name: "arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000128$fn__1657000129$fn__1657000132", Modifiers: 25, Simple: "fn__1657000132", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000132_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A_class, Name: "arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000136", Modifiers: 25, Simple: "fn__1657000136", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000137_A_class, Name: "arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000136$fn__1657000137", Modifiers: 25, Simple: "fn__1657000137", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000137_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000139_A_class, Name: "arbace.c.musl$read_all$iter__1657000122__1657000126$fn__1657000127$fn__1657000136$fn__1657000139", Modifiers: 25, Simple: "fn__1657000139", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000139_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_read_one_A_class, Name: "arbace.c.musl$read_one", Modifiers: 25, Simple: "read_one", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_read_one_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_refs_A_class, Name: "arbace.c.musl$refs", Modifiers: 25, Simple: "refs", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_refs_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_refs_decl__1657000081_A_class, Name: "arbace.c.musl$refs$decl__1657000081", Modifiers: 25, Simple: "decl__1657000081", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_refs_decl__1657000081_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_refs_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_refs_walk__1657000075_A_class, Name: "arbace.c.musl$refs$walk__1657000075", Modifiers: 25, Simple: "walk__1657000075", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_refs_walk__1657000075_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_refs_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_refs_walk_meta__1657000094_A_class, Name: "arbace.c.musl$refs$walk_meta__1657000094", Modifiers: 25, Simple: "walk_meta__1657000094", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_refs_walk_meta__1657000094_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_refs_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_sources_A_class, Name: "arbace.c.musl$sources", Modifiers: 25, Simple: "sources", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_sources_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_sources_iter__1657000018__1657000024_A_class, Name: "arbace.c.musl$sources$iter__1657000018__1657000024", Modifiers: 25, Simple: "iter__1657000018__1657000024", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_sources_iter__1657000018__1657000024_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_sources_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A_class, Name: "arbace.c.musl$sources$iter__1657000018__1657000024$fn__1657000025", Modifiers: 25, Simple: "fn__1657000025", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_sources_iter__1657000018__1657000024_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A_class, Name: "arbace.c.musl$sources$iter__1657000018__1657000024$fn__1657000025$iter__1657000020__1657000026", Modifiers: 25, Simple: "iter__1657000020__1657000026", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A_class, Name: "arbace.c.musl$sources$iter__1657000018__1657000024$fn__1657000025$iter__1657000020__1657000026$fn__1657000027", Modifiers: 25, Simple: "fn__1657000027", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A_class, Name: "arbace.c.musl$sources$iter__1657000018__1657000024$fn__1657000025$iter__1657000020__1657000026$fn__1657000027$fn__1657000028", Modifiers: 25, Simple: "fn__1657000028", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_spit_mk_A_class, Name: "arbace.c.musl$spit_mk", Modifiers: 25, Simple: "spit_mk", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_spit_mk_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_sym_name_A_class, Name: "arbace.c.musl$sym_name", Modifiers: 25, Simple: "sym_name", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_sym_name_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_unit_defs_A_class, Name: "arbace.c.musl$unit_defs", Modifiers: 25, Simple: "unit_defs", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_unit_defs_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c_musl_unit_defs_decl__1657000054_A_class, Name: "arbace.c.musl$unit_defs$decl__1657000054", Modifiers: 25, Simple: "decl__1657000054", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_unit_defs_decl__1657000054_A", Source: "musl.ae", Declaring: &A_arbace_c_musl_unit_defs_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_c_musl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_musl_A_New()}; return nil }

var A_arbace_c_musl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_musl_A_new}

var A_arbace_c_musl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.musl", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_A"})

func init() { i := A_arbace_c_musl_A_class.Info(); i.IsInstance = A_arbace_c_musl_A_InstanceOf; i.Init = A_arbace_c_musl_A_Init; i.Table = A_arbace_c_musl_A_members }

var A_arbace_c_musl_attr_names_A_class *jrt.Class

var A_arbace_c_musl_attr_names_walk__1657000035_A_class *jrt.Class

var A_arbace_c_musl_build_linked_A_class *jrt.Class

var A_arbace_c_musl_build_linked_fn__1657000243_A_class *jrt.Class

var A_arbace_c_musl_build_linked_fn__1657000245_A_class *jrt.Class

var A_arbace_c_musl_build_linked_fn__1657000247_A_class *jrt.Class

var A_arbace_c_musl_build_linked_fn__1657000249_A_class *jrt.Class

var A_arbace_c_musl_build_linked_fn__1657000251_A_class *jrt.Class

var A_arbace_c_musl_checked_unit_A_class *jrt.Class

var A_arbace_c_musl_closure_A_class *jrt.Class

var A_arbace_c_musl_config_A_class *jrt.Class

var A_arbace_c_musl_env_A_class *jrt.Class

func A_arbace_c_musl_eval1657000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_musl_eval1657000004_A_New()}; return nil }

var A_arbace_c_musl_eval1657000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_musl_eval1657000004_A_new}

var A_arbace_c_musl_eval1657000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.musl$eval1657000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_musl_A_class, Simple: "eval1657000004", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_eval1657000004_A"})

func init() { i := A_arbace_c_musl_eval1657000004_A_class.Info(); i.IsInstance = A_arbace_c_musl_eval1657000004_A_InstanceOf; i.Table = A_arbace_c_musl_eval1657000004_A_members }

var A_arbace_c_musl_eval1657000004_loading__1927001464__auto____1657000005_A_class *jrt.Class

func A_arbace_c_musl_eval1657000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_musl_eval1657000008_A_New()}; return nil }

var A_arbace_c_musl_eval1657000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c_musl_eval1657000008_A_new}

var A_arbace_c_musl_eval1657000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.musl$eval1657000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c_musl_A_class, Simple: "eval1657000008", Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl_eval1657000008_A"})

func init() { i := A_arbace_c_musl_eval1657000008_A_class.Info(); i.IsInstance = A_arbace_c_musl_eval1657000008_A_InstanceOf; i.Table = A_arbace_c_musl_eval1657000008_A_members }

var A_arbace_c_musl_eval1657000008_fn__1657000009_A_class *jrt.Class

var A_arbace_c_musl_forms_root_A_class *jrt.Class

var A_arbace_c_musl_index_A_class *jrt.Class

var A_arbace_c_musl_index_iter__1657000169__1657000173_A_class *jrt.Class

var A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_A_class *jrt.Class

var A_arbace_c_musl_index_iter__1657000169__1657000173_fn__1657000174_fn__1657000175_A_class *jrt.Class

var A_arbace_c_musl_library_A_class *jrt.Class

var A_arbace_c_musl_load_unit_A_class *jrt.Class

var A_arbace_c_musl_load_unit_iter__1657000152__1657000156_A_class *jrt.Class

var A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_A_class *jrt.Class

var A_arbace_c_musl_load_unit_iter__1657000152__1657000156_fn__1657000157_fn__1657000158_A_class *jrt.Class

var A_arbace_c_musl_musl_root_A_class *jrt.Class

var A_arbace_c_musl_read_all_A_class *jrt.Class

var A_arbace_c_musl_read_all_fn__1657000120_A_class *jrt.Class

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_A_class *jrt.Class

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_A_class *jrt.Class

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_A_class *jrt.Class

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_A_class *jrt.Class

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000130_A_class *jrt.Class

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000128_fn__1657000129_fn__1657000132_A_class *jrt.Class

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_A_class *jrt.Class

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000137_A_class *jrt.Class

var A_arbace_c_musl_read_all_iter__1657000122__1657000126_fn__1657000127_fn__1657000136_fn__1657000139_A_class *jrt.Class

var A_arbace_c_musl_read_one_A_class *jrt.Class

var A_arbace_c_musl_refs_A_class *jrt.Class

var A_arbace_c_musl_refs_decl__1657000081_A_class *jrt.Class

var A_arbace_c_musl_refs_walk__1657000075_A_class *jrt.Class

var A_arbace_c_musl_refs_walk_meta__1657000094_A_class *jrt.Class

var A_arbace_c_musl_sources_A_class *jrt.Class

var A_arbace_c_musl_sources_iter__1657000018__1657000024_A_class *jrt.Class

var A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_A_class *jrt.Class

var A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_A_class *jrt.Class

var A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_A_class *jrt.Class

var A_arbace_c_musl_sources_iter__1657000018__1657000024_fn__1657000025_iter__1657000020__1657000026_fn__1657000027_fn__1657000028_A_class *jrt.Class

var A_arbace_c_musl_spit_mk_A_class *jrt.Class

var A_arbace_c_musl_sym_name_A_class *jrt.Class

var A_arbace_c_musl_unit_defs_A_class *jrt.Class

var A_arbace_c_musl_unit_defs_decl__1657000054_A_class *jrt.Class

func A_arbace_c_musl__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c_musl__init_A_Load__O()}; return nil }

func A_arbace_c_musl__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c_musl__init_A_New()}; return nil }

var A_arbace_c_musl__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c_musl__init_A_invoke, New: A_arbace_c_musl__init_A_new}

var A_arbace_c_musl__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c.musl__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c_musl.A_arbace_c_musl__init_A", Source: "musl.ae"})

func init() { i := A_arbace_c_musl__init_A_class.Info(); i.IsInstance = A_arbace_c_musl__init_A_InstanceOf; i.Init = A_arbace_c_musl__init_A_Init; i.Table = A_arbace_c_musl__init_A_members }
