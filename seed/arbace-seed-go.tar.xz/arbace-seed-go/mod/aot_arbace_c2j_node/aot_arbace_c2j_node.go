//line aot_arbace_c2j_node.ae:1
package aot_arbace_c2j_node

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A_New() *A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c2j_node_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_c2j_node_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c2j_node_eval400000008_fn__400000009_A_New() *A_arbace_c2j_node_eval400000008_fn__400000009_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_eval400000008_fn__400000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_node_eval400000008_fn__400000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_node_eval400000008_fn__400000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_c2j_node_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_c2j_node_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c2j_node_A_const_7.GetRawRoot__O(), A_arbace_c2j_node_A_const_8) }



















































func A_arbace_c2j_node_register_BANG__A_New() *A_arbace_c2j_node_register_BANG__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_register_BANG__A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_c2j_node_register_BANG__A) Ctor() {}
//line :53:1
func (t *A_arbace_c2j_node_register_BANG__A) Invoke_O_O__O(self, d__0 any) any {


	var root_19 any = A_arbace_c2j_node_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_c2j_node_A_const_10.GetRawRoot__O(); var arg_23 any; var fnbody__47 any = A_arbace_c2j_node_register_BANG__fn__400000012_A_New_O(d__0); var tmp1 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_c2j_node_register_BANG__fn__400000012_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__47); A_arbace_c2j_node_register_BANG__fn__400000012_A_fn_class = fncls__46d; tmp1 = fncls__46d } else { tmp1 = fncls__46 }; arg_23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__47, tmp1, nil); if linked_20 == nil { return ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { return linked_20.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_19, arg_22, arg_23) } }
//line :56:1
func A_arbace_c2j_node_register_BANG__fn__400000012_A_New_O(p0 any) *A_arbace_c2j_node_register_BANG__fn__400000012_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_register_BANG__fn__400000012_A{}; t.Ctor_O(p0); return t }
//line :56:1
func (t *A_arbace_c2j_node_register_BANG__fn__400000012_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :56:1
func (t *A_arbace_c2j_node_register_BANG__fn__400000012_A) Invoke_O_O__O(self, ds__1 any) any { var i__2 any; var root_24 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var root_28 any = A_arbace_c2j_node_A_const_12.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any; var fnbody__34 any = A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_New_O(t.F_d); var tmp1 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__34); A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_fn_class = fncls__33d; tmp1 = fncls__33d } else { tmp1 = fncls__33 }; arg_31 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp1, nil); var arg_32 any = ds__1; if linked_29 == nil { arg_27 = ifn_30.Invoke_O_O__O(arg_31, arg_32) } else { arg_27 = linked_29.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_28, arg_31, arg_32) }; if linked_25 == nil { i__2 = ifn_26.Invoke_O__O(arg_27) } else { i__2 = linked_25.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_24, arg_27) }; if
												jrt.J2g_Truth(i__2) { var root_35 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = ds__1; var arg_39 any = i__2; var arg_40 any = t.F_d; if linked_36 == nil { return ifn_37.Invoke_O_O_O__O(arg_38, arg_39, arg_40) } else { return linked_36.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_35, arg_38, arg_39, arg_40) } } else { var root_41 any = A_arbace_c2j_node_A_const_7.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = ds__1; var arg_45 any = t.F_d; if linked_42 == nil { return ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { return linked_42.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_41, arg_44, arg_45) } } }
//line :56:1
func A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_New_O(p0 any) *A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A{}; t.Ctor_O(p0); return t }
//line :56:1
func (t *A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :56:1
func (t *A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_c2j_node_A_const_13.Invoke_O__O(x__2), A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d)) { return i__1 } else { return nil } }


func A_arbace_c2j_node_parse_A_New() *A_arbace_c2j_node_parse_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_parse_A{}; t.Ctor(); return t }
//line :59:1
func (t *A_arbace_c2j_node_parse_A) Ctor() {}
//line :59:1
func (t *A_arbace_c2j_node_parse_A) Invoke_O_O_O_O_O_O__O(self, kind__0, doc__1, opts__2, bindings__3, template__4 any) any { var tmp1 any = A_arbace_c2j_node_A_const_13; var tmp2 any = A_arbace_c2j_node_A_const_15; var tmp3 any = A_arbace_c2j_node_A_const_16; var tmp4 any = A_arbace_c2j_node_A_const_17; var tmp5 any; var root_48 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_50 lang.IFn; if



	linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any; var fnbody__66 any = A_arbace_c2j_node_parse_fn__400000018_A_New(); var tmp6 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_c2j_node_parse_fn__400000018_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); A_arbace_c2j_node_parse_fn__400000018_A_fn_class = fncls__65d; tmp6 = fncls__65d } else { tmp6 = fncls__65 }; arg_51 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp6, nil); var arg_52 any; var root_67 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = A_arbace_c2j_node_A_const_25; var arg_71 any = bindings__3; if linked_68 == nil { arg_52 = ifn_69.Invoke_O_O__O(arg_70, arg_71) } else { arg_52 = linked_68.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_67, arg_70, arg_71) }; if linked_49 == nil { tmp5 = ifn_50.Invoke_O_O__O(arg_51, arg_52) } else { tmp5 = linked_49.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_48, arg_51, arg_52) }; return /*line :59:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, kind__0, tmp2, doc__1, tmp3, opts__2, tmp4, tmp5, A_arbace_c2j_node_A_const_26, template__4)) }



func A_arbace_c2j_node_parse_fn__400000018_A_New() *A_arbace_c2j_node_parse_fn__400000018_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_parse_fn__400000018_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_c2j_node_parse_fn__400000018_A) Ctor() {}
//line :63:1
func (t *A_arbace_c2j_node_parse_fn__400000018_A) Invoke_O_O__O(self, p__400000017__1 any) any { var vec__400000019__2 any = p__400000017__1; var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000019__2, lang.RT_IntCast_J__I_NoInit(0), nil); var spec__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000019__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any = A_arbace_c2j_node_A_const_19; var tmp2 any = A_arbace_c2j_node_A_const_20; var tmp3 any; var root_53 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = spec__4; if linked_54 == nil { tmp3 = ifn_55.Invoke_O__O(arg_56) } else { tmp3 = linked_54.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_53, arg_56) }; var tmp4 any = tmp3; var tmp5 any = A_arbace_c2j_node_A_const_21; var tmp6 any; var root_57 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any; var root_61 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = spec__4; if linked_62 == nil { arg_60 = ifn_63.Invoke_O__O(arg_64) } else { arg_60 = linked_62.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_61, arg_64) }; if linked_58 == nil { tmp6 = ifn_59.Invoke_O__O(arg_60) } else { tmp6 = linked_58.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_57, arg_60) }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, s__3, tmp2, tmp4, tmp5, tmp6)) }


func A_arbace_c2j_node_field_names_A_New() *A_arbace_c2j_node_field_names_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_field_names_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_c2j_node_field_names_A) Ctor() {}
//line :66:1
func (t *A_arbace_c2j_node_field_names_A) Invoke_O_O__O(self, d__0 any) any {


	var root_72 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any; var root_76 any = A_arbace_c2j_node_A_const_27.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any; var root_80 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any; var root_85 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any; var fnbody__95 any = A_arbace_c2j_node_field_names_fn__400000024_A_New(); var tmp1 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_c2j_node_field_names_fn__400000024_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, nil); A_arbace_c2j_node_field_names_fn__400000024_A_fn_class = fncls__94d; tmp1 = fncls__94d } else { tmp1 = fncls__94 }; arg_88 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__95, tmp1, nil); var arg_89 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_86 == nil { arg_83 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { arg_83 = linked_86.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; var tmp2 *lang.Keyword = A_arbace_c2j_node_A_const_31; var arg_84 any = tmp2.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0)); if linked_81 == nil { arg_79 = ifn_82.Invoke_O_O__O(arg_83, arg_84) } else { arg_79 = linked_81.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_80, arg_83, arg_84) }; if linked_77 == nil { arg_75 = ifn_78.Invoke_O__O(arg_79) } else { arg_75 = linked_77.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_76, arg_79) }; if linked_73 == nil { return ifn_74.Invoke_O__O(arg_75) } else { return linked_73.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_72, arg_75) } }
//line :69:1
func A_arbace_c2j_node_field_names_fn__400000024_A_New() *A_arbace_c2j_node_field_names_fn__400000024_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_field_names_fn__400000024_A{}; t.Ctor(); return t }
//line :69:1
func (t *A_arbace_c2j_node_field_names_fn__400000024_A) Ctor() {}
//line :69:1
func (t *A_arbace_c2j_node_field_names_fn__400000024_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_30); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_c2j_node_A_const_20.Invoke_O__O(b__1))) { var root_90 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_91 == nil { return ifn_92.Invoke_O__O(arg_93) } else { return linked_91.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_90, arg_93) } } else { return nil } }


func A_arbace_c2j_node_children_bind_A_New() *A_arbace_c2j_node_children_bind_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_children_bind_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_c2j_node_children_bind_A) Ctor() {}
//line :72:1
func (t *A_arbace_c2j_node_children_bind_A) Invoke_O_O__O(self, d__0 any) any { var root_96 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any; var root_100 any = A_arbace_c2j_node_A_const_32.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any; var fnbody__106 any = A_arbace_c2j_node_children_bind_fn__400000028_A_New(); var tmp1 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_c2j_node_children_bind_fn__400000028_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, nil); A_arbace_c2j_node_children_bind_fn__400000028_A_fn_class = fncls__105d; tmp1 = fncls__105d } else { tmp1 = fncls__105 }; arg_103 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp1, nil); var arg_104 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_101 == nil { arg_99 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { arg_99 = linked_101.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }; if linked_97 == nil { return ifn_98.Invoke_O__O(arg_99) } else { return linked_97.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_96, arg_99) } }
//line :72:1
func A_arbace_c2j_node_children_bind_fn__400000028_A_New() *A_arbace_c2j_node_children_bind_fn__400000028_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_children_bind_fn__400000028_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_c2j_node_children_bind_fn__400000028_A) Ctor() {}
//line :72:1
func (t *A_arbace_c2j_node_children_bind_fn__400000028_A) Invoke_O_O__O(self, p1__400000027_SHARP___1 any) any { var tmp1 any = A_arbace_c2j_node_A_const_33; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_c2j_node_A_const_20.Invoke_O__O(p1__400000027_SHARP___1))).Ref() }

func A_arbace_c2j_node_walk_syms_A_New() *A_arbace_c2j_node_walk_syms_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_walk_syms_A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_c2j_node_walk_syms_A) Ctor() {}
//line :74:1
func (t *A_arbace_c2j_node_walk_syms_A) Invoke_O_O_O__O(self, r__0, f__1 any) any {


	var tmp1 any; var root_107 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_109 lang.IFn
	if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = f__1; if linked_108 == nil { tmp1 = ifn_109.Invoke_O__O(arg_110) } else { tmp1 = linked_108.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_107, arg_110) }
//line :77:1
	if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_111 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = r__0; var arg_115 any = f__1; if linked_112 == nil { tmp2 = ifn_113.Invoke_O_O__O(arg_114, arg_115) } else { tmp2 = linked_112.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_111, arg_114, arg_115) }; if jrt.J2g_Truth(tmp2) { return lang.IFn_Cast(r__0).Invoke_O__O(f__1) } else { return f__1 } } else {
//line :77:1
			var tmp3 any; var root_116 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_118 lang.IFn

			if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = f__1; if linked_117 == nil { tmp3 = ifn_118.Invoke_O__O(arg_119) } else { tmp3 = linked_117.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_116, arg_119) }
//line :77:1
			if jrt.J2g_Truth(tmp3) {

				var root_120 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any; var root_125 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = A_arbace_c2j_node_A_const_39.GetRawRoot__O(); var arg_129 any; var root_130 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any; var fnbody__141 any = A_arbace_c2j_node_walk_syms_fn__400000033_A_New_O(r__0); var tmp4 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_c2j_node_walk_syms_fn__400000033_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, fnbody__141); A_arbace_c2j_node_walk_syms_fn__400000033_A_fn_class = fncls__140d; tmp4 = fncls__140d } else { tmp4 = fncls__140 }; arg_133 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__141, tmp4, nil); var arg_134 any = f__1; if linked_131 == nil { arg_129 = ifn_132.Invoke_O_O__O(arg_133, arg_134) } else { arg_129 = linked_131.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_130, arg_133, arg_134) }; if linked_126 == nil { arg_123 = ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { arg_123 = linked_126.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_125, arg_128, arg_129) }; var arg_124 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); if linked_121 == nil { return ifn_122.Invoke_O_O__O(arg_123, arg_124) } else { return linked_121.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_120, arg_123, arg_124) } } else {
//line :77:1
					var tmp5 any; var root_142 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_144 lang.IFn


					if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = f__1; if linked_143 == nil { tmp5 = ifn_144.Invoke_O__O(arg_145) } else { tmp5 = linked_143.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_142, arg_145) }
//line :77:1
					if jrt.J2g_Truth(tmp5) {


						var root_146 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var root_151 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any; var fnbody__162 any = A_arbace_c2j_node_walk_syms_fn__400000035_A_New_O(r__0); var tmp6 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_c2j_node_walk_syms_fn__400000035_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, fnbody__162); A_arbace_c2j_node_walk_syms_fn__400000035_A_fn_class = fncls__161d; tmp6 = fncls__161d } else { tmp6 = fncls__161 }; arg_154 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp6, nil); var arg_155 any = f__1; if linked_152 == nil { arg_149 = ifn_153.Invoke_O_O__O(arg_154, arg_155) } else { arg_149 = linked_152.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_151, arg_154, arg_155) }; var arg_150 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); if linked_147 == nil { return ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { return linked_147.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) } } else {
//line :77:1
							var tmp7 any; var root_163 any = A_arbace_c2j_node_A_const_43.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_165 lang.IFn



							if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = f__1; if linked_164 == nil { tmp7 = ifn_165.Invoke_O__O(arg_166) } else { tmp7 = linked_164.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_163, arg_166) }
//line :77:1
							if jrt.J2g_Truth(tmp7) {



								var root_167 any = A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_171 any; var root_172 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any; var fnbody__188 any = A_arbace_c2j_node_walk_syms_fn__400000038_A_New_O(r__0); var tmp8 *jrt.Class; var fncls__187 *jrt.Class = A_arbace_c2j_node_walk_syms_fn__400000038_A_fn_class; if fncls__187 == nil { var fncls__187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, fnbody__188); A_arbace_c2j_node_walk_syms_fn__400000038_A_fn_class = fncls__187d; tmp8 = fncls__187d } else { tmp8 = fncls__187 }; arg_175 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__188, tmp8, nil); var arg_176 any = f__1; if linked_173 == nil { arg_171 = ifn_174.Invoke_O_O__O(arg_175, arg_176) } else { arg_171 = linked_173.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_172, arg_175, arg_176) }; if linked_168 == nil { return ifn_169.Invoke_O_O__O(arg_170, arg_171) } else { return linked_168.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_167, arg_170, arg_171) } } else {
//line :77:1
									if A_arbace_c2j_node_A_const_45 != nil { return f__1 } else { return nil
									} } } } } }
func A_arbace_c2j_node_walk_syms_fn__400000033_A_New_O(p0 any) *A_arbace_c2j_node_walk_syms_fn__400000033_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_walk_syms_fn__400000033_A{}; t.Ctor_O(p0); return t }
//line :79:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000033_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :79:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000033_A) Invoke_O_O__O(self, p1__400000031_SHARP___1 any) any { var root_135 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = t.F_r; var arg_139 any = p1__400000031_SHARP___1; if linked_136 == nil { return ifn_137.Invoke_O_O__O(arg_138, arg_139) } else { return linked_136.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_135, arg_138, arg_139) } }
func A_arbace_c2j_node_walk_syms_fn__400000035_A_New_O(p0 any) *A_arbace_c2j_node_walk_syms_fn__400000035_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_walk_syms_fn__400000035_A{}; t.Ctor_O(p0); return t }
//line :80:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000035_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :80:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000035_A) Invoke_O_O__O(self, p1__400000032_SHARP___1 any) any { var root_156 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = t.F_r; var arg_160 any = p1__400000032_SHARP___1; if linked_157 == nil { return ifn_158.Invoke_O_O__O(arg_159, arg_160) } else { return linked_157.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_156, arg_159, arg_160) } }
func A_arbace_c2j_node_walk_syms_fn__400000038_A_New_O(p0 any) *A_arbace_c2j_node_walk_syms_fn__400000038_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_walk_syms_fn__400000038_A{}; t.Ctor_O(p0); return t }
//line :81:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000038_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :81:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000038_A) Invoke_O_O__O(self, p__400000037__1 any) any { var vec__400000039__2 any = p__400000037__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000039__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000039__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_177 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = t.F_r; var arg_181 any = k__3; if linked_178 == nil { tmp1 = ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { tmp1 = linked_178.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_177, arg_180, arg_181) }; var tmp2 any = tmp1; var tmp3 any; var root_182 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = t.F_r; var arg_186 any = v__4; if linked_183 == nil { tmp3 = ifn_184.Invoke_O_O__O(arg_185, arg_186) } else { tmp3 = linked_183.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_182, arg_185, arg_186) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }


func A_arbace_c2j_node_head_A_New() *A_arbace_c2j_node_head_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_head_A{}; t.Ctor(); return t }
//line :84:1
func (t *A_arbace_c2j_node_head_A) Ctor() {}
//line :84:1
func (t *A_arbace_c2j_node_head_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_189 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = f__0; if linked_190 == nil { and__1927000168__auto____2 = ifn_191.Invoke_O__O(arg_192) } else { and__1927000168__auto____2 = linked_190.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_189, arg_192) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_193 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any; var root_197 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = f__0; if linked_198 == nil { arg_196 = ifn_199.Invoke_O__O(arg_200) } else { arg_196 = linked_198.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_197, arg_200) }; if linked_194 == nil { tmp1 = ifn_195.Invoke_O__O(arg_196) } else { tmp1 = linked_194.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_193, arg_196) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_201 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = f__0; if linked_202 == nil { return ifn_203.Invoke_O__O(arg_204) } else { return linked_202.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_201, arg_204) } } else { return nil } }

func A_arbace_c2j_node_runs_children_QMARK__A_New() *A_arbace_c2j_node_runs_children_QMARK__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_runs_children_QMARK__A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_c2j_node_runs_children_QMARK__A) Ctor() {}
//line :86:1
func (t *A_arbace_c2j_node_runs_children_QMARK__A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_205 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_207 lang.IFn
	if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = t__0; if linked_206 == nil { tmp1 = ifn_207.Invoke_O__O(arg_208) } else { tmp1 = linked_206.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_205, arg_208) }
//line :89:1
	if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any; var root_209 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_211 lang.IFn
		if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = A_arbace_c2j_node_A_const_46; var arg_213 any; var root_214 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, A_arbace_c2j_node_head_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = t__0; if linked_215 == nil { arg_213 = ifn_216.Invoke_O__O(arg_217) } else { arg_213 = linked_215.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_214, arg_217) }; if linked_210 == nil { or__1927000174__auto____2 = ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { or__1927000174__auto____2 = linked_210.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_209, arg_212, arg_213) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_218 any = A_arbace_c2j_node_A_const_48.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = A_arbace_c2j_node_A_const_49.GetRawRoot__O(); var arg_222 any = t__0; if linked_219 == nil { return ifn_220.Invoke_O_O__O(arg_221, arg_222) } else { return linked_219.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_218, arg_221, arg_222) } } } else {
//line :89:1
			var tmp2 any; var root_223 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_225 lang.IFn

			if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = t__0; if linked_224 == nil { tmp2 = ifn_225.Invoke_O__O(arg_226) } else { tmp2 = linked_224.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_223, arg_226) }
//line :89:1
			if jrt.J2g_Truth(tmp2) {

				var root_227 any = A_arbace_c2j_node_A_const_48.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = A_arbace_c2j_node_A_const_49.GetRawRoot__O(); var arg_231 any = t__0; if linked_228 == nil { return ifn_229.Invoke_O_O__O(arg_230, arg_231) } else { return linked_228.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_227, arg_230, arg_231) } } else {
//line :89:1
					if A_arbace_c2j_node_A_const_45 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
					}
				}
		}
}










func A_arbace_c2j_node_q_elems_A_New() *A_arbace_c2j_node_q_elems_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_elems_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_c2j_node_q_elems_A) Ctor() {}
//line :104:1
func (t *A_arbace_c2j_node_q_elems_A) Invoke_O_O_O__O(self, env__0, xs__1 any) any { var lst__3 any; var root_232 any = A_arbace_c2j_node_A_const_50.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_234 lang.IFn; if



	linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = xs__1; if linked_233 == nil { lst__3 = ifn_234.Invoke_O__O(arg_235) } else { lst__3 = linked_233.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_232, arg_235) }; var tmp1 any; var and__1927000168__auto____4 any; var root_236 any =
	A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = lst__3; if linked_237 == nil { and__1927000168__auto____4 = ifn_238.Invoke_O__O(arg_239) } else { and__1927000168__auto____4 = linked_237.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_236, arg_239) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any = A_arbace_c2j_node_A_const_51; var tmp3 any; var root_240 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, A_arbace_c2j_node_head_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = lst__3; if linked_241 == nil { tmp3 = ifn_242.Invoke_O__O(arg_243) } else { tmp3 = linked_241.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_240, arg_243) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { var b__4 any; var tmp4 lang.IFn = lang.IFn_Cast(env__0); var tmp5 any; var root_244 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_246 lang.IFn
		if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = lst__3; if linked_245 == nil { tmp5 = ifn_246.Invoke_O__O(arg_247) } else { tmp5 = linked_245.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_244, arg_247) }; b__4 = tmp4.Invoke_O__O(tmp5)
//line :109:1
		var tmp6 any; var root_248 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_250 lang.IFn

		if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any; var fnbody__259 any = A_arbace_c2j_node_q_elems_fn__400000048_A_New_O(env__0); var tmp7 *jrt.Class; var fncls__258 *jrt.Class = A_arbace_c2j_node_q_elems_fn__400000048_A_fn_class; if fncls__258 == nil { var fncls__258d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__259); A_arbace_c2j_node_q_elems_fn__400000048_A_fn_class = fncls__258d; tmp7 = fncls__258d } else { tmp7 = fncls__258 }; arg_251 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__259, tmp7, nil); var arg_252 any; var root_260 any = A_arbace_c2j_node_A_const_54.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = xs__1; if linked_261 == nil { arg_252 = ifn_262.Invoke_O__O(arg_263) } else { arg_252 = linked_261.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_260, arg_263) }; if linked_249 == nil { tmp6 = ifn_250.Invoke_O_O__O(arg_251, arg_252) } else { tmp6 = linked_249.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_248, arg_251, arg_252) }
//line :109:1
		var tmp8 any = tmp6; var tmp9 any; var G__400000050__5_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__4)


	L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__400000050__5_) { case 177445645: if any(G__400000050__5_) == any(A_arbace_c2j_node_A_const_55) {
		var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_node_A_const_57; tmp9 = tmp10.Invoke_O_O__O(tmp11, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4))
//line :112:1
		break L1 }; default:
	}
		tmp9 = A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4)}
//line :109:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9) } else { var tmp12 any; var root_265 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_267 lang.IFn





			if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any; var fnbody__276 any = A_arbace_c2j_node_q_elems_fn__400000051_A_New_O(env__0); var tmp13 *jrt.Class; var fncls__275 *jrt.Class = A_arbace_c2j_node_q_elems_fn__400000051_A_fn_class; if fncls__275 == nil { var fncls__275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__276); A_arbace_c2j_node_q_elems_fn__400000051_A_fn_class = fncls__275d; tmp13 = fncls__275d } else { tmp13 = fncls__275 }; arg_268 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__276, tmp13, nil); var arg_269 any = xs__1; if linked_266 == nil { tmp12 = ifn_267.Invoke_O_O__O(arg_268, arg_269) } else { tmp12 = linked_266.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_265, arg_268, arg_269) }
//line :109:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp12, nil) } }

func A_arbace_c2j_node_q_elems_fn__400000048_A_New_O(p0 any) *A_arbace_c2j_node_q_elems_fn__400000048_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_elems_fn__400000048_A{}; t.Ctor_O(p0); return t }
//line :111:1
func (t *A_arbace_c2j_node_q_elems_fn__400000048_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :111:1
func (t *A_arbace_c2j_node_q_elems_fn__400000048_A) Invoke_O_O__O(self, p1__400000046_SHARP___1 any) any { var root_253 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, A_arbace_c2j_node_q_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = t.F_env; var arg_257 any = p1__400000046_SHARP___1; if linked_254 == nil { return ifn_255.Invoke_O_O__O(arg_256, arg_257) } else { return linked_254.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_253, arg_256, arg_257) } }



func A_arbace_c2j_node_q_elems_fn__400000051_A_New_O(p0 any) *A_arbace_c2j_node_q_elems_fn__400000051_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_elems_fn__400000051_A{}; t.Ctor_O(p0); return t }
//line :115:1
func (t *A_arbace_c2j_node_q_elems_fn__400000051_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :115:1
func (t *A_arbace_c2j_node_q_elems_fn__400000051_A) Invoke_O_O__O(self, p1__400000047_SHARP___1 any) any { var root_270 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, A_arbace_c2j_node_q_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = t.F_env; var arg_274 any = p1__400000047_SHARP___1; if linked_271 == nil { return ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { return linked_271.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_270, arg_273, arg_274) } }

func A_arbace_c2j_node_q_drop_QMARK__A_New() *A_arbace_c2j_node_q_drop_QMARK__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_drop_QMARK__A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_c2j_node_q_drop_QMARK__A) Ctor() {}
//line :117:1
func (t *A_arbace_c2j_node_q_drop_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(x__0, A_arbace_c2j_node_A_const_58)).Ref() }

func A_arbace_c2j_node_q_body_A_New() *A_arbace_c2j_node_q_body_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_body_A{}; t.Ctor(); return t }
//line :119:1
func (t *A_arbace_c2j_node_q_body_A) Ctor() {}
//line :119:1
func (t *A_arbace_c2j_node_q_body_A) Invoke_O_O_O__O(self, env__0, bs__1 any) any { var cs__3 any; var root_277 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_279 lang.IFn; if


	linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = A_arbace_c2j_node_A_const_60.GetRawRoot__O(); var arg_281 any; var root_282 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any; var fnbody__293 any = A_arbace_c2j_node_q_body_fn__400000056_A_New_O(env__0); var tmp1 *jrt.Class; var fncls__292 *jrt.Class = A_arbace_c2j_node_q_body_fn__400000056_A_fn_class; if fncls__292 == nil { var fncls__292d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__293); A_arbace_c2j_node_q_body_fn__400000056_A_fn_class = fncls__292d; tmp1 = fncls__292d } else { tmp1 = fncls__292 }; arg_285 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__293, tmp1, nil); var arg_286 any = bs__1; if linked_283 == nil { arg_281 = ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { arg_281 = linked_283.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_282, arg_285, arg_286) }; if linked_278 == nil { cs__3 = ifn_279.Invoke_O_O__O(arg_280, arg_281) } else { cs__3 = linked_278.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_277, arg_280, arg_281) }; var tmp2 any; var root_294 any =
	A_arbace_c2j_node_A_const_61.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_296 lang.IFn; if
	linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = cs__3; if linked_295 == nil { tmp2 = ifn_296.Invoke_O__O(arg_297) } else { tmp2 = linked_295.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_294, arg_297) }; if /*line :123:1*/ jrt.J2g_Truth(tmp2) { return nil } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(cs__3))) {

		var root_298 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = cs__3; if linked_299 == nil { return ifn_300.Invoke_O__O(arg_301) } else { return linked_299.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_298, arg_301) } } else {
//line :123:1
			if A_arbace_c2j_node_A_const_45 != nil {


				var root_302 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = A_arbace_c2j_node_A_const_63; var arg_306 any = A_arbace_c2j_node_A_const_64; var arg_307 any = cs__3; if linked_303 == nil { return ifn_304.Invoke_O_O_O__O(arg_305, arg_306, arg_307) } else { return linked_303.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_302, arg_305, arg_306, arg_307) } } else {
//line :123:1
					return nil } } } }
//line :122:1
func A_arbace_c2j_node_q_body_fn__400000056_A_New_O(p0 any) *A_arbace_c2j_node_q_body_fn__400000056_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_body_fn__400000056_A{}; t.Ctor_O(p0); return t }
//line :122:1
func (t *A_arbace_c2j_node_q_body_fn__400000056_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :122:1
func (t *A_arbace_c2j_node_q_body_fn__400000056_A) Invoke_O_O__O(self, p1__400000055_SHARP___1 any) any { var root_287 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, A_arbace_c2j_node_q_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = t.F_env; var arg_291 any = p1__400000055_SHARP___1; if linked_288 == nil { return ifn_289.Invoke_O_O__O(arg_290, arg_291) } else { return linked_288.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_287, arg_290, arg_291) } }





func A_arbace_c2j_node_qs_A_New() *A_arbace_c2j_node_qs_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qs_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_c2j_node_qs_A) Ctor() {}
//line :128:1
func (t *A_arbace_c2j_node_qs_A) Invoke_O_O_O__O(self, env__0, f__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(f__1, A_arbace_c2j_node_A_const_65) {
		var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_56; return tmp1.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(A_arbace_c2j_node_A_const_69)) } else {
//line :131:1
			var tmp2 any; var and__1927000168__auto____3 any; var root_308 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_310 lang.IFn

			if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = f__1; if linked_309 == nil { and__1927000168__auto____3 = ifn_310.Invoke_O__O(arg_311) } else { and__1927000168__auto____3 = linked_309.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_c2j_node_A_const_66; var tmp4 any; var root_312 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, A_arbace_c2j_node_head_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = f__1; if linked_313 == nil { tmp4 = ifn_314.Invoke_O__O(arg_315) } else { tmp4 = linked_313.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_312, arg_315) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :131:1
			if jrt.J2g_Truth(tmp2) {

				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_node_A_const_70; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_node_A_const_72; var tmp9 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp10 lang.IFn = lang.IFn_Cast(env__0); var tmp11 any; var root_345 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = f__1; if linked_346 == nil { tmp11 = ifn_347.Invoke_O__O(arg_348) } else { tmp11 = linked_346.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_345, arg_348) }; var tmp12 any = tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O__O(tmp10.Invoke_O__O(tmp11))); var tmp13 *lang.Keyword = A_arbace_c2j_node_A_const_71; var tmp14 lang.IFn = lang.IFn_Cast(env__0); var tmp15 any; var root_349 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = f__1; if linked_350 == nil { tmp15 = ifn_351.Invoke_O__O(arg_352) } else { tmp15 = linked_350.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_349, arg_352) }; return tmp5.Invoke_O_O_O__O(tmp6, tmp12, tmp13.Invoke_O__O(tmp14.Invoke_O__O(tmp15))) } else {
//line :131:1
					var tmp16 any; var and__1927000168__auto____3_2 any; var root_316 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_318 lang.IFn


					if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = f__1; if linked_317 == nil { and__1927000168__auto____3_2 = ifn_318.Invoke_O__O(arg_319) } else { and__1927000168__auto____3_2 = linked_317.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_316, arg_319) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var tmp17 any = A_arbace_c2j_node_A_const_67; var tmp18 any; var root_320 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, A_arbace_c2j_node_head_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = f__1; if linked_321 == nil { tmp18 = ifn_322.Invoke_O__O(arg_323) } else { tmp18 = linked_321.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_320, arg_323) }; tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp17, tmp18)).Ref() } else { tmp16 = and__1927000168__auto____3_2 }
//line :131:1
					if jrt.J2g_Truth(tmp16) {


						var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp20 any = A_arbace_c2j_node_A_const_73; var tmp21 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp22 lang.IFn = lang.IFn_Cast(env__0); var tmp23 any; var root_353 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = f__1; if linked_354 == nil { tmp23 = ifn_355.Invoke_O__O(arg_356) } else { tmp23 = linked_354.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_353, arg_356) }; return tmp19.Invoke_O_O__O(tmp20, tmp21.Invoke_O__O(tmp22.Invoke_O__O(tmp23))) } else {
//line :131:1
							if A_arbace_c2j_node_A_const_45 != nil {



								var root_324 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any; var root_329 any = A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_333 any; var root_335 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_337 lang.IFn; if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any; var fnbody__344 any = A_arbace_c2j_node_qs_fn__400000060_A_New(); var tmp24 *jrt.Class; var fncls__343 *jrt.Class = A_arbace_c2j_node_qs_fn__400000060_A_fn_class; if fncls__343 == nil { var fncls__343d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, nil); A_arbace_c2j_node_qs_fn__400000060_A_fn_class = fncls__343d; tmp24 = fncls__343d } else { tmp24 = fncls__343 }; arg_338 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__344, tmp24, nil); if linked_336 == nil { arg_333 = ifn_337.Invoke_O__O(arg_338) } else { arg_333 = linked_336.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O__O(root_335, arg_338) }; var arg_334 any = env__0; if linked_330 == nil { arg_327 = ifn_331.Invoke_O_O_O__O(arg_332, arg_333, arg_334) } else { arg_327 = linked_330.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_329, arg_332, arg_333, arg_334) }; var arg_328 any = f__1; if linked_325 == nil { return ifn_326.Invoke_O_O__O(arg_327, arg_328) } else { return linked_325.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_324, arg_327, arg_328) } } else {
//line :131:1
									return nil
								}
						}
				} } }
func A_arbace_c2j_node_qs_fn__400000060_A_New() *A_arbace_c2j_node_qs_fn__400000060_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qs_fn__400000060_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_c2j_node_qs_fn__400000060_A) Ctor() {}
//line :135:1
func (t *A_arbace_c2j_node_qs_fn__400000060_A) Invoke_O_O__O(self, p__400000059__1 any) any { var vec__400000061__2 any = p__400000059__1; var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000061__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000061__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var and__1927000168__auto____5 any; var root_339 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = s__3; if linked_340 == nil { and__1927000168__auto____5 = ifn_341.Invoke_O__O(arg_342) } else { and__1927000168__auto____5 = linked_340.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_339, arg_342) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_68); tmp1 = tmp2.Invoke_O__O(A_arbace_c2j_node_A_const_20.Invoke_O__O(b__4)) } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(s__3, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4)) } else { return nil } }

func A_arbace_c2j_node_q_seq_A_New() *A_arbace_c2j_node_q_seq_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_A{}; t.Ctor(); return t }
//line :137:1
func (t *A_arbace_c2j_node_q_seq_A) Ctor() {}
//line :137:1
func (t *A_arbace_c2j_node_q_seq_A) Invoke_O_O_O__O(self, env__0, t__1 any) any { var vec__400000067__3 any = t__1; var seq__400000068__4 any; var root_357 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_359 lang.IFn; if
										linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = vec__400000067__3; if linked_358 == nil { seq__400000068__4 = ifn_359.Invoke_O__O(arg_360) } else { seq__400000068__4 = linked_358.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_357, arg_360) }; var first__400000069__5 any; var root_361 any = /*line :137:1*/A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_363 lang.IFn; if
										linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = seq__400000068__4; if linked_362 == nil { first__400000069__5 = ifn_363.Invoke_O__O(arg_364) } else { first__400000069__5 = linked_362.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_361, arg_364) }; var seq__400000068__6 any; var root_365 any = /*line :137:1*/A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_367 lang.IFn; if
										linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = seq__400000068__4; if linked_366 == nil { seq__400000068__6 = ifn_367.Invoke_O__O(arg_368) } else { seq__400000068__6 = linked_366.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_365, arg_368) }; var h__7 any = first__400000069__5; var as__8 any = seq__400000068__6; var G__400000070__9_ any = h__7; switch
										lang.Util_Hash_O__I_NoInit(G__400000070__9_) >> 2 & 63 { case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_76) { var vec__400000071__10 any = as__8; var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000071__10, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000071__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_85; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_node_A_const_86; var tmp5 any = A_arbace_c2j_node_A_const_87; var tmp6 *lang.Keyword = A_arbace_c2j_node_A_const_56; _ = ___11






		return tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O_O_O__O(tmp4, tmp5, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_88, A_arbace_c2j_node_A_const_89, A_arbace_c2j_node_A_const_90)), tmp6.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(xs__12))) }
//line :139:1
	case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_77) {




















		var root_370 any = A_arbace_c2j_node_A_const_78.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, A_arbace_c2j_node_q_body_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = env__0; var arg_374 any = as__8; if linked_371 == nil { return ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { return linked_371.(*A_arbace_c2j_node_q_body_A).Invoke_O_O_O__O(root_370, arg_373, arg_374) } }
//line :139:1
	case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_79) { var vec__400000074__10 any = as__8; var s__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000074__10, lang.RT_IntCast_J__I_NoInit(0), nil); var b__12 any = lang.IFn_Cast(env__0).Invoke_O__O(s__11); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_node_A_const_91; var tmp9 any = A_arbace_c2j_node_A_const_92; var tmp10 any = A_arbace_c2j_node_A_const_93; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_node_A_const_94; var tmp13 any
		var tmp14 any = A_arbace_c2j_node_A_const_55
































		if lang.Util_Equiv_O_O__Z_NoInit(tmp14, A_arbace_c2j_node_A_const_20.Invoke_O__O(b__12)) { var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_node_A_const_95; tmp13 = tmp15.Invoke_O_O__O(tmp16, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__12)) } else { tmp13 = A_arbace_c2j_node_A_const_56.Invoke_O__O(b__12) }; return tmp7.Invoke_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11.Invoke_O_O__O(tmp12, tmp13)) }
//line :139:1
	case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_80) { var vec__400000077__10 any = as__8; var c__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000077__10, lang.RT_IntCast_J__I_NoInit(0), nil); var a__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000077__10, lang.RT_IntCast_J__I_NoInit(1), nil); var b__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000077__10, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp18 any = A_arbace_c2j_node_A_const_100; var tmp19 any; var root_430 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, A_arbace_c2j_node_qs_A_fn_class); var ifn_432 lang.IFn





















		if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = env__0; var arg_434 any = c__11; if linked_431 == nil { tmp19 = ifn_432.Invoke_O_O__O(arg_433, arg_434) } else { tmp19 = linked_431.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_430, arg_433, arg_434) }; var tmp20 any = tmp19; var tmp21 any; var root_435 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, A_arbace_c2j_node_q_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = env__0; var arg_439 any = a__12; if linked_436 == nil { tmp21 = ifn_437.Invoke_O_O__O(arg_438, arg_439) } else { tmp21 = linked_436.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_435, arg_438, arg_439) }; var tmp22 any = tmp21; var tmp23 any; var root_440 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, A_arbace_c2j_node_q_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = env__0; var arg_444 any = b__13; if linked_441 == nil { tmp23 = ifn_442.Invoke_O_O__O(arg_443, arg_444) } else { tmp23 = linked_441.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_440, arg_443, arg_444) }; return tmp17.Invoke_O_O_O_O__O(tmp18, tmp20, tmp22, tmp23) }
//line :139:1
	case 26: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_96) { var vec__400000080__10 any = as__8; var seq__400000081__11 any; var root_391 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_393 lang.IFn






















		if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = vec__400000080__10; if linked_392 == nil { seq__400000081__11 = ifn_393.Invoke_O__O(arg_394) } else { seq__400000081__11 = linked_392.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_391, arg_394) }
//line :139:1
		var first__400000082__12 any; var root_395 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_397 lang.IFn






















		if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = seq__400000081__11; if linked_396 == nil { first__400000082__12 = ifn_397.Invoke_O__O(arg_398) } else { first__400000082__12 = linked_396.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_395, arg_398) }
//line :139:1
		var seq__400000081__13 any; var root_399 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_401 lang.IFn






















		if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = seq__400000081__11; if linked_400 == nil { seq__400000081__13 = ifn_401.Invoke_O__O(arg_402) } else { seq__400000081__13 = linked_400.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_399, arg_402) }
//line :139:1
		var sel__14 any = first__400000082__12; var cls__15 any = seq__400000081__13; var root_403 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_405 lang.IFn























		if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp25 any = A_arbace_c2j_node_A_const_97; var tmp26 any; var root_408 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, A_arbace_c2j_node_qs_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = env__0; var arg_412 any = sel__14; if linked_409 == nil { tmp26 = ifn_410.Invoke_O_O__O(arg_411, arg_412) } else { tmp26 = linked_409.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_408, arg_411, arg_412) }; arg_406 = tmp24.Invoke_O_O__O(tmp25, tmp26); var arg_407 any; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp28 *lang.Compiler_AOTFn; var fnbody__424 any = A_arbace_c2j_node_q_seq_fn__400000084_A_New_O(env__0); var tmp29 *jrt.Class; var fncls__423 *jrt.Class = A_arbace_c2j_node_q_seq_fn__400000084_A_fn_class; if fncls__423 == nil { var fncls__423d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__424); A_arbace_c2j_node_q_seq_fn__400000084_A_fn_class = fncls__423d; tmp29 = fncls__423d } else { tmp29 = fncls__423 }; tmp28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__424, tmp29, nil); var tmp30 any = tmp28.Ref(); var tmp31 any; var root_425 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = A_arbace_c2j_node_A_const_25; var arg_429 any = cls__15; if linked_426 == nil { tmp31 = ifn_427.Invoke_O_O__O(arg_428, arg_429) } else { tmp31 = linked_426.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_425, arg_428, arg_429) }; arg_407 = tmp27.Invoke_O_O__O(tmp30, tmp31); if linked_404 == nil { return ifn_405.Invoke_O_O__O(arg_406, arg_407) } else { return linked_404.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_403, arg_406, arg_407) } }
//line :139:1
	case 27: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_101) { var vec__400000089__10 any = as__8; var at__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000089__10, lang.RT_IntCast_J__I_NoInit(0), nil); var x__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000089__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp33 any = A_arbace_c2j_node_A_const_103; var tmp34 any = A_arbace_c2j_node_A_const_104; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp36 any = A_arbace_c2j_node_A_const_105; var tmp37 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp38 any = tmp35.Invoke_O_O__O(tmp36, tmp37.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(at__11))); var tmp39 any; var root_445 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, A_arbace_c2j_node_q_A_fn_class); var ifn_447 lang.IFn



































		if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = env__0; var arg_449 any = x__12; if linked_446 == nil { tmp39 = ifn_447.Invoke_O_O__O(arg_448, arg_449) } else { tmp39 = linked_446.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_445, arg_448, arg_449) }; return tmp32.Invoke_O_O_O_O__O(tmp33, tmp34, tmp38, tmp39) }
//line :139:1
	case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_102) { var vec__400000092__10 any = as__8; var at__11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000092__10, lang.RT_IntCast_J__I_NoInit(0), nil); var ___12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000092__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp41 any = A_arbace_c2j_node_A_const_105; var tmp42 *lang.Keyword = A_arbace_c2j_node_A_const_56; _ = ___12


































		return tmp40.Invoke_O_O__O(tmp41, tmp42.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(at__11_2))) }
//line :139:1
	case 36: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_106) { var vec__400000095__10 any = as__8; var c__11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000095__10, lang.RT_IntCast_J__I_NoInit(0), nil); var x__12_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000095__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp43 *lang.Keyword = A_arbace_c2j_node_A_const_56; var xv__13 any = tmp43.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(x__12_2))
		var G__400000098__14_ any = c__11_2

		switch lang.Util_Hash_O__I_NoInit(G__400000098__14_) >> 8 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_107) {

			return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_112, A_arbace_c2j_node_A_const_113, xv__13) }
//line :142:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_108) {


			var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp45 any = A_arbace_c2j_node_A_const_114; var tmp46 any = A_arbace_c2j_node_A_const_115; return tmp44.Invoke_O_O_O_O__O(tmp45, tmp46, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_116, A_arbace_c2j_node_A_const_117, xv__13), lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_118, A_arbace_c2j_node_A_const_119, xv__13)) }
//line :142:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_109) {

			return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_112, A_arbace_c2j_node_A_const_113, xv__13) }
//line :142:1
		case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_110) {

			return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_112, A_arbace_c2j_node_A_const_113, xv__13) }
//line :142:1
		case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_120) {
			return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_121, A_arbace_c2j_node_A_const_122, xv__13) }
//line :142:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__400000098__14_))))) }
//line :139:1
	case 37: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_111) { var vec__400000099__10 any = as__8; var m__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000099__10, lang.RT_IntCast_J__I_NoInit(0), nil); var a__12_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000099__10, lang.RT_IntCast_J__I_NoInit(1), nil); var b__13_2 any = lang.IFn_Cast(env__0).Invoke_O__O(a__12_2); var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp48 any = A_arbace_c2j_node_A_const_124; var tmp49 any = A_arbace_c2j_node_A_const_125; var tmp50 any; var root_451 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, A_arbace_c2j_node_qs_A_fn_class); var ifn_453 lang.IFn






























		if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = env__0; var arg_455 any = m__11; if linked_452 == nil { tmp50 = ifn_453.Invoke_O_O__O(arg_454, arg_455) } else { tmp50 = linked_452.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_451, arg_454, arg_455) }; return tmp47.Invoke_O_O_O_O_O__O(tmp48, tmp49, tmp50, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__13_2), A_arbace_c2j_node_A_const_126.Invoke_O__O(b__13_2)) }
//line :139:1
	case 45: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_123) { return A_arbace_c2j_node_A_const_58 }; case 48: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_127) { var vec__400000102__10 any = as__8; var ___11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000102__10, lang.RT_IntCast_J__I_NoInit(0), nil); var x__12_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000102__10, lang.RT_IntCast_J__I_NoInit(1), nil); var root_456 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, A_arbace_c2j_node_q_A_fn_class); var ifn_458 lang.IFn; _ = ___11_2



















		if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = env__0; var arg_460 any = x__12_3; if linked_457 == nil { return ifn_458.Invoke_O_O__O(arg_459, arg_460) } else { return linked_457.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_456, arg_459, arg_460) } }
//line :139:1
	case 54: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_128) { var vec__400000105__10 any = as__8; var seq__400000106__11 any; var root_461 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_463 lang.IFn









		if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = vec__400000105__10; if linked_462 == nil { seq__400000106__11 = ifn_463.Invoke_O__O(arg_464) } else { seq__400000106__11 = linked_462.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_461, arg_464) }
//line :139:1
		var first__400000107__12 any; var root_465 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_467 lang.IFn









		if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = seq__400000106__11; if linked_466 == nil { first__400000107__12 = ifn_467.Invoke_O__O(arg_468) } else { first__400000107__12 = linked_466.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_465, arg_468) }
//line :139:1
		var seq__400000106__13 any; var root_469 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_471 lang.IFn









		if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = seq__400000106__11; if linked_470 == nil { seq__400000106__13 = ifn_471.Invoke_O__O(arg_472) } else { seq__400000106__13 = linked_470.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_469, arg_472) }
//line :139:1
		var ___14 any = first__400000107__12; var first__400000107__15 any; var root_473 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_475 lang.IFn; _ = ___14









		if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = seq__400000106__13; if linked_474 == nil { first__400000107__15 = ifn_475.Invoke_O__O(arg_476) } else { first__400000107__15 = linked_474.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_473, arg_476) }
//line :139:1
		var seq__400000106__16 any; var root_477 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_479 lang.IFn









		if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = seq__400000106__13; if linked_478 == nil { seq__400000106__16 = ifn_479.Invoke_O__O(arg_480) } else { seq__400000106__16 = linked_478.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_477, arg_480) }
//line :139:1
		var bv__17 any = first__400000107__15; var body__18 any = seq__400000106__16; var vec__400000108__19 any; var root_481 any = A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_483 lang.IFn










		if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any; var fnbody__513 any = A_arbace_c2j_node_q_seq_fn__400000113_A_New(); var tmp51 *jrt.Class; var fncls__512 *jrt.Class = A_arbace_c2j_node_q_seq_fn__400000113_A_fn_class; if fncls__512 == nil { var fncls__512d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, nil); A_arbace_c2j_node_q_seq_fn__400000113_A_fn_class = fncls__512d; tmp51 = fncls__512d } else { tmp51 = fncls__512 }; arg_484 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__513, tmp51, nil); var arg_485 any = lang.Tuple_Create_O_O__IPersistentVector(env__0, lang.PersistentVector_EMPTY.Ref()); var arg_486 any; var root_514 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_516 lang.IFn




		if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = A_arbace_c2j_node_A_const_25; var arg_518 any = bv__17; if linked_515 == nil { arg_486 = ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { arg_486 = linked_515.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) }
//line :150:1
		if linked_482 == nil { vec__400000108__19 = ifn_483.Invoke_O_O_O__O(arg_484, arg_485, arg_486) } else { vec__400000108__19 = linked_482.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_481, arg_484, arg_485, arg_486) }
//line :139:1
		var env__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000108__19, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000108__19, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp53 any = A_arbace_c2j_node_A_const_134; var tmp54 any; var root_523 any = A_arbace_c2j_node_A_const_78.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, A_arbace_c2j_node_q_body_A_fn_class); var ifn_525 lang.IFn
















		if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = env__20; var arg_527 any = body__18; if linked_524 == nil { tmp54 = ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { tmp54 = linked_524.(*A_arbace_c2j_node_q_body_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) }; return tmp52.Invoke_O_O_O__O(tmp53, binds__21, tmp54) }
//line :139:1
	case 56: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_133) { var vec__400000121__10 any = as__8; var c__11_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000121__10, lang.RT_IntCast_J__I_NoInit(0), nil); var m__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000121__10, lang.RT_IntCast_J__I_NoInit(1), nil); var f__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000121__10, lang.RT_IntCast_J__I_NoInit(2), nil); var fv__14 any; var root_519 any = A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_521 lang.IFn

























		if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = Lit_59; if linked_520 == nil { fv__14 = ifn_521.Invoke_O__O(arg_522) } else { fv__14 = linked_520.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_519, arg_522) }
		var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp56 any = A_arbace_c2j_node_A_const_142; var tmp57 any; var root_593 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, A_arbace_c2j_node_q_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = env__0; var arg_597 any = f__13; if linked_594 == nil { tmp57 = ifn_595.Invoke_O_O__O(arg_596, arg_597) } else { tmp57 = linked_594.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_593, arg_596, arg_597) }; var tmp58 any = lang.Tuple_Create_O_O__IPersistentVector(fv__14, tmp57); var tmp59 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp60 any = A_arbace_c2j_node_A_const_143; var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp62 any = A_arbace_c2j_node_A_const_144; var tmp63 any; var root_598 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, A_arbace_c2j_node_qs_A_fn_class); var ifn_600 lang.IFn
		if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = env__0; var arg_602 any = c__11_3; if linked_599 == nil { tmp63 = ifn_600.Invoke_O_O__O(arg_601, arg_602) } else { tmp63 = linked_599.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_598, arg_601, arg_602) }
//line :166:1
		var tmp64 any = tmp61.Invoke_O_O_O__O(tmp62, tmp63, A_arbace_c2j_node_A_const_120); var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp66 any = A_arbace_c2j_node_A_const_145; var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp68 any = A_arbace_c2j_node_A_const_146; var tmp69 any; var root_603 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, A_arbace_c2j_node_qs_A_fn_class); var ifn_605 lang.IFn
		if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = env__0; var arg_607 any = m__12; if linked_604 == nil { tmp69 = ifn_605.Invoke_O_O__O(arg_606, arg_607) } else { tmp69 = linked_604.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_603, arg_606, arg_607) }
//line :166:1
		return tmp55.Invoke_O_O_O__O(tmp56, tmp58, tmp59.Invoke_O_O_O_O__O(tmp60, tmp64, tmp65.Invoke_O_O_O__O(tmp66, fv__14, tmp67.Invoke_O_O__O(tmp68, tmp69)), fv__14)) }
//line :139:1
	case 57: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_135) { var vec__400000124__10 any = as__8; var seq__400000125__11 any; var root_528 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_530 lang.IFn




































		if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = vec__400000124__10; if linked_529 == nil { seq__400000125__11 = ifn_530.Invoke_O__O(arg_531) } else { seq__400000125__11 = linked_529.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_528, arg_531) }
//line :139:1
		var first__400000126__12 any; var root_532 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_534 lang.IFn




































		if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = seq__400000125__11; if linked_533 == nil { first__400000126__12 = ifn_534.Invoke_O__O(arg_535) } else { first__400000126__12 = linked_533.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_532, arg_535) }
//line :139:1
		var seq__400000125__13 any; var root_536 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_538 lang.IFn




































		if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = seq__400000125__11; if linked_537 == nil { seq__400000125__13 = ifn_538.Invoke_O__O(arg_539) } else { seq__400000125__13 = linked_537.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_536, arg_539) }
//line :139:1
		var bv__14 any = first__400000126__12; var body__15 any = seq__400000125__13; var fresh__16 any; var root_540 any = A_arbace_c2j_node_A_const_49.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, A_arbace_c2j_node_runs_children_QMARK__A_fn_class); var ifn_542 lang.IFn





































		if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any; var root_544 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = A_arbace_c2j_node_A_const_136; var arg_548 any = body__15; if linked_545 == nil { arg_543 = ifn_546.Invoke_O_O__O(arg_547, arg_548) } else { arg_543 = linked_545.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_544, arg_547, arg_548) }; if linked_541 == nil { fresh__16 = ifn_542.Invoke_O__O(arg_543) } else { fresh__16 = linked_541.(*A_arbace_c2j_node_runs_children_QMARK__A).Invoke_O_O__O(root_540, arg_543) }
//line :139:1
		var vec__400000127__17 any; var root_549 any = A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_551 lang.IFn






































		if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any; var fnbody__587 any = A_arbace_c2j_node_q_seq_fn__400000132_A_New_O(fresh__16); var tmp70 *jrt.Class; var fncls__586 *jrt.Class = A_arbace_c2j_node_q_seq_fn__400000132_A_fn_class; if fncls__586 == nil { var fncls__586d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__587); A_arbace_c2j_node_q_seq_fn__400000132_A_fn_class = fncls__586d; tmp70 = fncls__586d } else { tmp70 = fncls__586 }; arg_552 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__587, tmp70, nil); var arg_553 any = lang.Tuple_Create_O_O_O__IPersistentVector(env__0, lang.PersistentVector_EMPTY.Ref(), lang.PersistentVector_EMPTY.Ref()); var arg_554 any; var root_588 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_590 lang.IFn




		if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = A_arbace_c2j_node_A_const_25; var arg_592 any = bv__14; if linked_589 == nil { arg_554 = ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { arg_554 = linked_589.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) }
//line :178:1
		if linked_550 == nil { vec__400000127__17 = ifn_551.Invoke_O_O_O__O(arg_552, arg_553, arg_554) } else { vec__400000127__17 = linked_550.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_549, arg_552, arg_553, arg_554) }
//line :139:1
		var env__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000127__17, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000127__17, lang.RT_IntCast_J__I_NoInit(1), nil); var lets__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000127__17, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp71 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp72 any = A_arbace_c2j_node_A_const_148; var tmp73 any; var root_608 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_610 lang.IFn












































		if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = A_arbace_c2j_node_A_const_149; var arg_612 any = A_arbace_c2j_node_A_const_150; var arg_613 any; var root_615 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = A_arbace_c2j_node_A_const_151; var arg_619 any = lets__20; if linked_616 == nil { arg_613 = ifn_617.Invoke_O_O__O(arg_618, arg_619) } else { arg_613 = linked_616.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O__O(root_615, arg_618, arg_619) }; var arg_614 any; var root_620 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = A_arbace_c2j_node_A_const_60.GetRawRoot__O(); var arg_624 any; var root_625 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any; var fnbody__636 any = A_arbace_c2j_node_q_seq_fn__400000140_A_New_O(env__18); var tmp74 *jrt.Class; var fncls__635 *jrt.Class = A_arbace_c2j_node_q_seq_fn__400000140_A_fn_class; if fncls__635 == nil { var fncls__635d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__636); A_arbace_c2j_node_q_seq_fn__400000140_A_fn_class = fncls__635d; tmp74 = fncls__635d } else { tmp74 = fncls__635 }; arg_628 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__636, tmp74, nil); var arg_629 any = body__15; if linked_626 == nil { arg_624 = ifn_627.Invoke_O_O__O(arg_628, arg_629) } else { arg_624 = linked_626.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_625, arg_628, arg_629) }; if linked_621 == nil { arg_614 = ifn_622.Invoke_O_O__O(arg_623, arg_624) } else { arg_614 = linked_621.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_620, arg_623, arg_624) }; if linked_609 == nil { tmp73 = ifn_610.Invoke_O_O_O_O__O(arg_611, arg_612, arg_613, arg_614) } else { tmp73 = linked_609.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O_O__O(root_608, arg_611, arg_612, arg_613, arg_614) }; return tmp71.Invoke_O_O_O__O(tmp72, binds__19, tmp73) }
//line :139:1
	case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_147) { var vec__400000142__10 any = as__8; var m__11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000142__10, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__12_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000142__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp75 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp76 any = A_arbace_c2j_node_A_const_152; var tmp77 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp78 any = A_arbace_c2j_node_A_const_153; var tmp79 any = A_arbace_c2j_node_A_const_154; var tmp80 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp81 any = A_arbace_c2j_node_A_const_155; var tmp82 any; var root_637 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, A_arbace_c2j_node_qs_A_fn_class); var ifn_639 lang.IFn








		if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = env__0; var arg_641 any = m__11_2; if linked_638 == nil { tmp82 = ifn_639.Invoke_O_O__O(arg_640, arg_641) } else { tmp82 = linked_638.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_637, arg_640, arg_641) }; var tmp83 *lang.Keyword = A_arbace_c2j_node_A_const_56; return tmp75.Invoke_O_O__O(tmp76, tmp77.Invoke_O_O_O_O__O(tmp78, tmp79, tmp80.Invoke_O_O__O(tmp81, tmp82), tmp83.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(xs__12_2)))) }
//line :139:1
	default:}; var vec__400000145__10 any; var root_375 any = A_arbace_c2j_node_A_const_81.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, A_arbace_c2j_node_q_elems_A_fn_class); var ifn_377 lang.IFn; if













































	linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = env__0; var arg_379 any = t__1; if linked_376 == nil { vec__400000145__10 = ifn_377.Invoke_O_O__O(arg_378, arg_379) } else { vec__400000145__10 = linked_376.(*A_arbace_c2j_node_q_elems_A).Invoke_O_O_O__O(root_375, arg_378, arg_379) }; var fixed__11 any = /*line :139:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__400000145__10, lang.RT_IntCast_J__I_NoInit(0), nil); var tail__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000145__10, lang.RT_IntCast_J__I_NoInit(1), nil); if














































	jrt.J2g_Truth(tail__12) {
		return lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_82), fixed__11, lang.Tuple_Create_O__IPersistentVector(tail__12)) } else {
			var root_386 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = A_arbace_c2j_node_A_const_84; var arg_390 any = fixed__11; if linked_387 == nil { return ifn_388.Invoke_O_O__O(arg_389, arg_390) } else { return linked_387.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_386, arg_389, arg_390) } } }
//line :150:1
func A_arbace_c2j_node_q_seq_fn__400000113_A_New() *A_arbace_c2j_node_q_seq_fn__400000113_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_fn__400000113_A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_c2j_node_q_seq_fn__400000113_A) Ctor() {}
//line :150:1
func (t *A_arbace_c2j_node_q_seq_fn__400000113_A) Invoke_O_O_O__O(self, p__400000111__1, p__400000112__2 any) any { var vec__400000114__3 any = p__400000111__1; var env__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000114__3, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000114__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__400000117__6 any = p__400000112__2; var s__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000117__6, lang.RT_IntCast_J__I_NoInit(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000117__6, lang.RT_IntCast_J__I_NoInit(1), nil); var v__9 any; var root_487 any = A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_489 lang.IFn; if
															linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, s__7, nil)).Ref(); if linked_488 == nil { v__9 = ifn_489.Invoke_O__O(arg_490) } else { v__9 = linked_488.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_487, arg_490) }; var k__10 any; var tmp1 any = A_arbace_c2j_node_A_const_131; var tmp2 any; var root_491 any = /*line :150:1*/A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, A_arbace_c2j_node_head_A_fn_class); var ifn_493 lang.IFn; if

	linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = init__8; if linked_492 == nil { tmp2 = ifn_493.Invoke_O__O(arg_494) } else { tmp2 = linked_492.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_491, arg_494) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { k__10 = A_arbace_c2j_node_A_const_55 } else { k__10 = A_arbace_c2j_node_A_const_132 }; var tmp3 any; var root_495 any = /*line :150:1*/A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_497 lang.IFn; if


	linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = env__4; var arg_499 any = s__7; var arg_500 any; var tmp4 any = A_arbace_c2j_node_A_const_20; var tmp5 any = A_arbace_c2j_node_A_const_56; var tmp6 any = A_arbace_c2j_node_A_const_126; var tmp7 any; if lang.Util_Equiv_O_O__Z_NoInit(k__10, A_arbace_c2j_node_A_const_55) { var tmp8 *lang.Keyword = A_arbace_c2j_node_A_const_56; tmp7 = tmp8.Invoke_O__O(lang.IFn_Cast(env__4).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(init__8, lang.RT_IntCast_J__I_NoInit(2)))) } else { tmp7 = nil }; arg_500 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, k__10, tmp5, v__9, tmp6, tmp7)); if linked_496 == nil { tmp3 = ifn_497.Invoke_O_O_O__O(arg_498, arg_499, arg_500) } else { tmp3 = linked_496.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_495, arg_498, arg_499, arg_500) }; var tmp9 any = tmp3; var tmp10 lang.IFn = /*line :150:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp11 any; var root_507 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, A_arbace_c2j_node_q_A_fn_class); var ifn_509 lang.IFn; if



	linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = env__4; var arg_511 any = init__8; if linked_508 == nil { tmp11 = ifn_509.Invoke_O_O__O(arg_510, arg_511) } else { tmp11 = linked_508.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_507, arg_510, arg_511) }; return /*line :150:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10.Invoke_O_O_O__O(binds__5, v__9, tmp11)) }












func A_arbace_c2j_node_q_seq_fn__400000084_A_New_O(p0 any) *A_arbace_c2j_node_q_seq_fn__400000084_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_fn__400000084_A{}; t.Ctor_O(p0); return t }
//line :163:1
func (t *A_arbace_c2j_node_q_seq_fn__400000084_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :163:1
func (t *A_arbace_c2j_node_q_seq_fn__400000084_A) Invoke_O_O__O(self, p__400000083__1 any) any { var vec__400000085__2 any = p__400000083__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000085__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000085__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_418 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, A_arbace_c2j_node_q_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = t.F_env; var arg_422 any = f__4; if linked_419 == nil { tmp1 = ifn_420.Invoke_O_O__O(arg_421, arg_422) } else { tmp1 = linked_419.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_418, arg_421, arg_422) }; return lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp1) }














func A_arbace_c2j_node_q_seq_fn__400000132_A_New_O(p0 any) *A_arbace_c2j_node_q_seq_fn__400000132_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_fn__400000132_A{}; t.Ctor_O(p0); return t }
//line :178:1
func (t *A_arbace_c2j_node_q_seq_fn__400000132_A) Ctor_O(c__fresh any) { t.F_fresh = c__fresh }
//line :178:1
func (t *A_arbace_c2j_node_q_seq_fn__400000132_A) Invoke_O_O_O__O(self, p__400000130__1, p__400000131__2 any) any { var vec__400000133__3 any = p__400000130__1; var env__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000133__3, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000133__3, lang.RT_IntCast_J__I_NoInit(1), nil); var lets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000133__3, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__400000136__7 any = p__400000131__2; var s__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000136__7, lang.RT_IntCast_J__I_NoInit(0), nil); var init__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000136__7, lang.RT_IntCast_J__I_NoInit(1), nil); var v__10 any; var root_555 any = A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_557 lang.IFn; if
															linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, s__8, nil)).Ref(); if linked_556 == nil { v__10 = ifn_557.Invoke_O__O(arg_558) } else { v__10 = linked_556.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_555, arg_558) }; var tmp1 any; var root_559 any = /*line :178:1*/A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_561 lang.IFn; if

	linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = env__4; var arg_563 any = s__8; var arg_564 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_137, A_arbace_c2j_node_A_const_56, v__10)); if linked_560 == nil { tmp1 = ifn_561.Invoke_O_O_O__O(arg_562, arg_563, arg_564) } else { tmp1 = linked_560.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_559, arg_562, arg_563, arg_564) }; var tmp2 any = tmp1; var tmp3 lang.IFn = /*line :178:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp4 any; if


	jrt.J2g_Truth(t.F_fresh) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_node_A_const_138; var tmp7 any = A_arbace_c2j_node_A_const_139; tmp4 = tmp5.Invoke_O_O_O__O(tmp6, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_62), jrt.RefArrayOf(jrt.Object_class, s__8, nil)).Ref()) } else { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_node_A_const_140; var tmp10 any; var root_571 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_62), jrt.RefArrayOf(jrt.Object_class, s__8, nil)).Ref(); if linked_572 == nil { tmp10 = ifn_573.Invoke_O__O(arg_574) } else { tmp10 = linked_572.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_571, arg_574) }; tmp4 = tmp8.Invoke_O_O__O(tmp9, tmp10) }; var tmp11 any = /*line :178:1*/tmp3.Invoke_O_O_O__O(binds__5, v__10, tmp4); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp13 any; var root_581 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, A_arbace_c2j_node_q_A_fn_class); var ifn_583 lang.IFn; if



	linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = env__4; var arg_585 any = init__9; if linked_582 == nil { tmp13 = ifn_583.Invoke_O_O__O(arg_584, arg_585) } else { tmp13 = linked_582.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_581, arg_584, arg_585) }; return /*line :178:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp11, tmp12.Invoke_O_O_O__O(lets__6, v__10, tmp13)) }





func A_arbace_c2j_node_q_seq_fn__400000140_A_New_O(p0 any) *A_arbace_c2j_node_q_seq_fn__400000140_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_fn__400000140_A{}; t.Ctor_O(p0); return t }
//line :184:1
func (t *A_arbace_c2j_node_q_seq_fn__400000140_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :184:1
func (t *A_arbace_c2j_node_q_seq_fn__400000140_A) Invoke_O_O__O(self, p1__400000066_SHARP___1 any) any { var root_630 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, A_arbace_c2j_node_q_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = t.F_env; var arg_634 any = p1__400000066_SHARP___1; if linked_631 == nil { return ifn_632.Invoke_O_O__O(arg_633, arg_634) } else { return linked_631.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_630, arg_633, arg_634) } }





func A_arbace_c2j_node_q_A_New() *A_arbace_c2j_node_q_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_c2j_node_q_A) Ctor() {}
//line :190:1
func (t *A_arbace_c2j_node_q_A) Invoke_O_O_O__O(self, env__0, t__1 any) any {


	var tmp1 any; var root_642 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_644 lang.IFn
	if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = t__1; if linked_643 == nil { tmp1 = ifn_644.Invoke_O__O(arg_645) } else { tmp1 = linked_643.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_642, arg_645) }
//line :193:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000408__auto____3 any = lang.IFn_Cast(env__0).Invoke_O__O(t__1)
		if jrt.J2g_Truth(temp__1927000408__auto____3) { var b__4 any = temp__1927000408__auto____3; var G__400000149__5_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__4)
			switch lang.Util_Hash_O__I_NoInit(G__400000149__5_) >> 2 & 3 { case 0: if any(G__400000149__5_) == any(A_arbace_c2j_node_A_const_156) {
				var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_node_A_const_159; var tmp4 any = A_arbace_c2j_node_A_const_160; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_node_A_const_161; return tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4), tmp5.Invoke_O_O__O(tmp6, A_arbace_c2j_node_A_const_162.Invoke_O__O(b__4))) }
//line :195:1
			case 2: if any(G__400000149__5_) == any(A_arbace_c2j_node_A_const_137) {

				return A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4) }
//line :195:1
			case 3: if any(G__400000149__5_) == any(A_arbace_c2j_node_A_const_132) {

				return A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4) }
//line :195:1
			default:}; var tmp7 any; var root_647 any = A_arbace_c2j_node_A_const_157.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_649 lang.IFn


			if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_52, nil, Lit_53), jrt.RefArrayOf(jrt.Object_class, nil, t__1, nil)).Ref(); var arg_651 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_648 == nil { tmp7 = ifn_649.Invoke_O_O__O(arg_650, arg_651) } else { tmp7 = linked_648.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_647, arg_650, arg_651) }
//line :195:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp7))) } else {



				return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_163, t__1) } } else {
//line :193:1
					var tmp8 any; var root_652 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_654 lang.IFn






					if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = t__1; if linked_653 == nil { tmp8 = ifn_654.Invoke_O__O(arg_655) } else { tmp8 = linked_653.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_652, arg_655) }
//line :193:1
					if jrt.J2g_Truth(tmp8) {






						var root_656 any = A_arbace_c2j_node_A_const_158.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, A_arbace_c2j_node_q_seq_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = env__0; var arg_660 any = t__1; if linked_657 == nil { return ifn_658.Invoke_O_O__O(arg_659, arg_660) } else { return linked_657.(*A_arbace_c2j_node_q_seq_A).Invoke_O_O_O__O(root_656, arg_659, arg_660) } } else {
//line :193:1
							var tmp9 any; var root_661 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_663 lang.IFn







							if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = t__1; if linked_662 == nil { tmp9 = ifn_663.Invoke_O__O(arg_664) } else { tmp9 = linked_662.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_661, arg_664) }
//line :193:1
							if jrt.J2g_Truth(tmp9) { var vec__400000150__3 any; var root_665 any = A_arbace_c2j_node_A_const_81.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, A_arbace_c2j_node_q_elems_A_fn_class); var ifn_667 lang.IFn







								if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = env__0; var arg_669 any = t__1; if linked_666 == nil { vec__400000150__3 = ifn_667.Invoke_O_O__O(arg_668, arg_669) } else { vec__400000150__3 = linked_666.(*A_arbace_c2j_node_q_elems_A).Invoke_O_O_O__O(root_665, arg_668, arg_669) }
//line :193:1
								var fixed__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000150__3, lang.RT_IntCast_J__I_NoInit(0), nil); var tail__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000150__3, lang.RT_IntCast_J__I_NoInit(1), nil)








								if jrt.J2g_Truth(tail__5) { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_node_A_const_164; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_node_A_const_165; var tmp14 any; var root_670 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = fixed__4; if linked_671 == nil { tmp14 = ifn_672.Invoke_O__O(arg_673) } else { tmp14 = linked_671.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_670, arg_673) }; return tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O_O__O(tmp13, tmp14, tail__5)) } else { return fixed__4 } } else {
//line :193:1
									if A_arbace_c2j_node_A_const_45 != nil { return t__1 } else { return nil
									}
								}
						}
				}
}






func A_arbace_c2j_node_emit_fn_A_New() *A_arbace_c2j_node_emit_fn_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_emit_fn_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_c2j_node_emit_fn_A) Ctor() {}
//line :205:1
func (t *A_arbace_c2j_node_emit_fn_A) Invoke_O_O__O(self, d__0 any) any { var fields__2 any; var root_674 any = A_arbace_c2j_node_A_const_166.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, A_arbace_c2j_node_field_names_A_fn_class); var ifn_676 lang.IFn; if


	linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = d__0; if linked_675 == nil { fields__2 = ifn_676.Invoke_O__O(arg_677) } else { fields__2 = linked_675.(*A_arbace_c2j_node_field_names_A).Invoke_O_O__O(root_674, arg_677) }; var ev__3 any; var root_678 any = /*line :205:1*/A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_680 lang.IFn; if



	linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = Lit_41; if linked_679 == nil { ev__3 = ifn_680.Invoke_O__O(arg_681) } else { ev__3 = linked_679.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_678, arg_681) }; var chv__4 any; var root_682 any = /*line :205:1*/A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_684 lang.IFn; if




	linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = Lit_42; if linked_683 == nil { chv__4 = ifn_684.Invoke_O__O(arg_685) } else { chv__4 = linked_683.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_682, arg_685) }; var env0__5 any; var root_686 any = /*line :205:1*/A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_688 lang.IFn; if





	linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var tmp1 any = A_arbace_c2j_node_A_const_167; var tmp2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_168, A_arbace_c2j_node_A_const_56, chv__4)); var tmp3 any = A_arbace_c2j_node_A_const_169; var arg_689 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_170, A_arbace_c2j_node_A_const_56, ev__3)))); var arg_690 any; var root_691 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_693 lang.IFn; if
	linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any; var fnbody__701 any = A_arbace_c2j_node_emit_fn_fn__400000157_A_New(); var tmp4 *jrt.Class; var fncls__700 *jrt.Class = A_arbace_c2j_node_emit_fn_fn__400000157_A_fn_class; if fncls__700 == nil { var fncls__700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); A_arbace_c2j_node_emit_fn_fn__400000157_A_fn_class = fncls__700d; tmp4 = fncls__700d } else { tmp4 = fncls__700 }; arg_694 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__701, tmp4, nil); var arg_695 any = fields__2; if linked_692 == nil { arg_690 = ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { arg_690 = linked_692.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_691, arg_694, arg_695) }; if /*line :211:1*/ linked_687 == nil { env0__5 = ifn_688.Invoke_O_O__O(arg_689, arg_690) } else { env0__5 = linked_687.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_686, arg_689, arg_690) }; var vec__400000154__6 any; var root_702 any = /*line :205:1*/A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_704 lang.IFn; if







	linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any; var fnbody__819 any = A_arbace_c2j_node_emit_fn_fn__400000161_A_New(); var tmp5 *jrt.Class; var fncls__818 *jrt.Class = A_arbace_c2j_node_emit_fn_fn__400000161_A_fn_class; if fncls__818 == nil { var fncls__818d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_c2j_node_emit_fn_fn__400000161_A_fn_class = fncls__818d; tmp5 = fncls__818d } else { tmp5 = fncls__818 }; arg_705 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__819, tmp5, nil); var arg_706 any = lang.Tuple_Create_O_O__IPersistentVector(env0__5, lang.PersistentVector_EMPTY.Ref()); var arg_707 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_703 == nil { vec__400000154__6 = ifn_704.Invoke_O_O_O__O(arg_705, arg_706, arg_707) } else { vec__400000154__6 = linked_703.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_702, arg_705, arg_706, arg_707) }; var env__7 any = /*line :205:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__400000154__6, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000154__6, lang.RT_IntCast_J__I_NoInit(1), nil); var body__9 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp7 any = A_arbace_c2j_node_A_const_183; var tmp8 any; var root_820 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_822 lang.IFn; if
















	linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp10 any; var root_831 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = ev__3; var arg_835 any = A_arbace_c2j_node_A_const_184; if linked_832 == nil { tmp10 = ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { tmp10 = linked_832.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_831, arg_834, arg_835) }; var tmp11 any = lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_185, A_arbace_c2j_node_A_const_186)); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp13 *lang.Compiler_AOTFn; var fnbody__850 any = A_arbace_c2j_node_emit_fn_fn__400000169_A_New_O(env0__5); var tmp14 *jrt.Class; var fncls__849 *jrt.Class = A_arbace_c2j_node_emit_fn_fn__400000169_A_fn_class; if
	fncls__849 == nil { var fncls__849d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__850); A_arbace_c2j_node_emit_fn_fn__400000169_A_fn_class = fncls__849d; tmp14 = fncls__849d } else { tmp14 = fncls__849 }; tmp13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__850, tmp14, nil); var tmp15 lang.IFn = /*line :222:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_node_A_const_190; var tmp17 any = A_arbace_c2j_node_A_const_191; arg_823 = tmp9.Invoke_O_O_O_O__O(tmp11, tmp12.Invoke_O_O__O(tmp13.Ref(), fields__2), lang.Tuple_Create_O_O__IPersistentVector(chv__4, tmp15.Invoke_O_O_O_O__O(tmp16, tmp17, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_192, A_arbace_c2j_node_A_const_193), A_arbace_c2j_node_A_const_120)), binds__8); if linked_821 == nil { tmp8 = ifn_822.Invoke_O__O(arg_823) } else { tmp8 = linked_821.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_820, arg_823) }; var tmp18 any = tmp8; var tmp19 any; var root_851 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_851, A_arbace_c2j_node_q_A_fn_class); var ifn_853 lang.IFn; if



	linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any = env__7; var arg_855 any = A_arbace_c2j_node_A_const_26.Invoke_O__O(d__0); if linked_852 == nil { tmp19 = ifn_853.Invoke_O_O__O(arg_854, arg_855) } else { tmp19 = linked_852.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_851, arg_854, arg_855) }; body__9 = /*line :222:1*/tmp6.Invoke_O_O_O__O(tmp7, tmp18, tmp19); var tmp20 lang.IFn =




	lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp21 any = A_arbace_c2j_node_A_const_194; var tmp22 any; var root_856 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_node_A_const_13.Invoke_O__O(d__0))).Ref(); if linked_857 == nil { tmp22 = ifn_858.Invoke_O__O(arg_859) } else { tmp22 = linked_857.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_856, arg_859) }; var tmp23 any = tmp22; var tmp24 any = A_arbace_c2j_node_A_const_195; var tmp25 any; var tmp26 *lang.Keyword = A_arbace_c2j_node_A_const_196; var temp__1927000408__auto____10 any = tmp26.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0)); if
	jrt.J2g_Truth(temp__1927000408__auto____10) { var r__11 any = temp__1927000408__auto____10; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp28 any = A_arbace_c2j_node_A_const_197
		tmp25 = tmp27.Invoke_O_O_O__O(tmp28, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O_O__O(r__11, A_arbace_c2j_node_A_const_198, A_arbace_c2j_node_A_const_199, A_arbace_c2j_node_A_const_200), body__9) } else {
//line :228:1
			tmp25 = body__9 }; return /*line :227:1*/ tmp20.Invoke_O_O_O_O__O(tmp21, tmp23, tmp24, tmp25) }
//line :212:1
func A_arbace_c2j_node_emit_fn_fn__400000157_A_New() *A_arbace_c2j_node_emit_fn_fn__400000157_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_emit_fn_fn__400000157_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000157_A) Ctor() {}
//line :212:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000157_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 any = A_arbace_c2j_node_A_const_20; var tmp2 any = A_arbace_c2j_node_A_const_171; var tmp3 any = A_arbace_c2j_node_A_const_56; var tmp4 any; var root_696 any = A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, f__1, nil)).Ref(); if linked_697 == nil { tmp4 = ifn_698.Invoke_O__O(arg_699) } else { tmp4 = linked_697.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_696, arg_699) }; return lang.Tuple_Create_O_O__IPersistentVector(f__1, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4))) }
func A_arbace_c2j_node_emit_fn_fn__400000161_A_New() *A_arbace_c2j_node_emit_fn_fn__400000161_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_emit_fn_fn__400000161_A{}; t.Ctor(); return t }
//line :213:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000161_A) Ctor() {}
//line :213:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000161_A) Invoke_O_O_O__O(self, p__400000159__1, p__400000160__2 any) any { var vec__400000162__3 any = p__400000159__1; var env__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000162__3, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000162__3, lang.RT_IntCast_J__I_NoInit(1), nil); var map__400000165__6 any = p__400000160__2; var map__400000165__7 any; if lang.ISeq_InstanceOf(map__400000165__6) { var tmp1 any; var root_708 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any = map__400000165__6; if linked_709 == nil { tmp1 = ifn_710.Invoke_O__O(arg_711) } else { tmp1 = linked_709.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_708, arg_711) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_712 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = map__400000165__6; if linked_713 == nil { tmp2 = ifn_714.Invoke_O__O(arg_715) } else { tmp2 = linked_713.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_712, arg_715) }; map__400000165__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_716 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = map__400000165__6; if linked_717 == nil { tmp3 = ifn_718.Invoke_O__O(arg_719) } else { tmp3 = linked_717.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_716, arg_719) }; if jrt.J2g_Truth(tmp3) { var root_720 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = map__400000165__6; if linked_721 == nil { map__400000165__7 = ifn_722.Invoke_O__O(arg_723) } else { map__400000165__7 = linked_721.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_720, arg_723) } } else { map__400000165__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000165__7 = map__400000165__6 }; var sym__8 any = lang.RT_Get_O_O__O_NoInit(map__400000165__7, A_arbace_c2j_node_A_const_19); var k__9 any = lang.RT_Get_O_O__O_NoInit(map__400000165__7, A_arbace_c2j_node_A_const_20); var args__10 any = lang.RT_Get_O_O__O_NoInit(map__400000165__7, A_arbace_c2j_node_A_const_21); var v__11 any; var root_724 any = A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_726 lang.IFn; if
															linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, sym__8, nil)).Ref(); if linked_725 == nil { v__11 = ifn_726.Invoke_O__O(arg_727) } else { v__11 = linked_725.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_724, arg_727) }; var G__400000167__12_ any = k__9; switch
															lang.Util_Hash_O__I_NoInit(G__400000167__12_) >> 8 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__400000167__12_, A_arbace_c2j_node_A_const_173) { var tmp4 any; var root_729 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_731 lang.IFn




		if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = env__4; var arg_733 any = sym__8; var arg_734 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_177, A_arbace_c2j_node_A_const_56, v__11)); if linked_730 == nil { tmp4 = ifn_731.Invoke_O_O_O__O(arg_732, arg_733, arg_734) } else { tmp4 = linked_730.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_729, arg_732, arg_733, arg_734) }
//line :215:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp4, lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(binds__5, v__11, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_178, A_arbace_c2j_node_A_const_179, A_arbace_c2j_node_A_const_180))) }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__400000167__12_, A_arbace_c2j_node_A_const_174) { var tmp5 any; var root_741 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_743 lang.IFn



			if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = env__4; var arg_745 any = sym__8; var arg_746 any; var tmp6 any = A_arbace_c2j_node_A_const_20; var tmp7 any = A_arbace_c2j_node_A_const_156; var tmp8 any = A_arbace_c2j_node_A_const_56; var tmp9 any = A_arbace_c2j_node_A_const_162; var tmp10 any; var root_747 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = args__10; if linked_748 == nil { tmp10 = ifn_749.Invoke_O__O(arg_750) } else { tmp10 = linked_748.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_747, arg_750) }; arg_746 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, v__11, tmp9, tmp10)); if linked_742 == nil { tmp5 = ifn_743.Invoke_O_O_O__O(arg_744, arg_745, arg_746) } else { tmp5 = linked_742.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_741, arg_744, arg_745, arg_746) }
//line :215:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp5, lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(binds__5, v__11, nil)) }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000167__12_, A_arbace_c2j_node_A_const_175) { var tmp11 any; var root_757 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_759 lang.IFn
				if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = env__4; var arg_761 any = sym__8; var arg_762 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_181, A_arbace_c2j_node_A_const_56, v__11)); if linked_758 == nil { tmp11 = ifn_759.Invoke_O_O_O__O(arg_760, arg_761, arg_762) } else { tmp11 = linked_758.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_757, arg_760, arg_761, arg_762) }
//line :215:1
				var tmp12 any = tmp11; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp14 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp15 lang.IFn = lang.IFn_Cast(env__4); var tmp16 any; var root_769 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_771 lang.IFn
				if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = args__10; if linked_770 == nil { tmp16 = ifn_771.Invoke_O__O(arg_772) } else { tmp16 = linked_770.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_769, arg_772) }
//line :215:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13.Invoke_O_O_O__O(binds__5, v__11, tmp14.Invoke_O__O(tmp15.Invoke_O__O(tmp16)))) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__400000167__12_, A_arbace_c2j_node_A_const_176) { var tmp17 any; var root_773 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_775 lang.IFn

					if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = env__4; var arg_777 any = sym__8; var arg_778 any; var tmp18 any = A_arbace_c2j_node_A_const_20; var tmp19 any = A_arbace_c2j_node_A_const_126; var tmp20 any = A_arbace_c2j_node_A_const_56; var tmp21 any = A_arbace_c2j_node_A_const_71; var tmp22 any; var root_779 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = args__10; if linked_780 == nil { tmp22 = ifn_781.Invoke_O__O(arg_782) } else { tmp22 = linked_780.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_779, arg_782) }; arg_778 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp19, tmp20, v__11, tmp21, tmp22)); if linked_774 == nil { tmp17 = ifn_775.Invoke_O_O_O__O(arg_776, arg_777, arg_778) } else { tmp17 = linked_774.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_773, arg_776, arg_777, arg_778) }
//line :215:1
					var tmp23 any = tmp17; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp25 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp26 lang.IFn = lang.IFn_Cast(env__4); var tmp27 any; var root_789 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_791 lang.IFn

					if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = args__10; if linked_790 == nil { tmp27 = ifn_791.Invoke_O__O(arg_792) } else { tmp27 = linked_790.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_789, arg_792) }
//line :215:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp23, tmp24.Invoke_O_O_O__O(binds__5, v__11, tmp25.Invoke_O__O(tmp26.Invoke_O__O(tmp27)))) }; case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__400000167__12_, A_arbace_c2j_node_A_const_182) { var tmp28 any; var root_793 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_795 lang.IFn


						if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = env__4; var arg_797 any = sym__8; var arg_798 any; var tmp29 any = A_arbace_c2j_node_A_const_20; var tmp30 any = A_arbace_c2j_node_A_const_156; var tmp31 any = A_arbace_c2j_node_A_const_56; var tmp32 any = A_arbace_c2j_node_A_const_162; var tmp33 any; var root_799 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = args__10; if linked_800 == nil { tmp33 = ifn_801.Invoke_O__O(arg_802) } else { tmp33 = linked_800.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_799, arg_802) }; arg_798 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30, tmp31, v__11, tmp32, tmp33)); if linked_794 == nil { tmp28 = ifn_795.Invoke_O_O_O__O(arg_796, arg_797, arg_798) } else { tmp28 = linked_794.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_793, arg_796, arg_797, arg_798) }
//line :215:1
						var tmp34 any = tmp28; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp36 any; var root_809 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, A_arbace_c2j_node_qs_A_fn_class); var ifn_811 lang.IFn


						if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = env__4; var arg_813 any; var root_814 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = args__10; if linked_815 == nil { arg_813 = ifn_816.Invoke_O__O(arg_817) } else { arg_813 = linked_815.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_814, arg_817) }; if linked_810 == nil { tmp36 = ifn_811.Invoke_O_O__O(arg_812, arg_813) } else { tmp36 = linked_810.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_809, arg_812, arg_813) }
//line :215:1
						return lang.Tuple_Create_O_O__IPersistentVector(tmp34, tmp35.Invoke_O_O_O__O(binds__5, v__11, tmp36)) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__400000167__12_))))) }







func A_arbace_c2j_node_emit_fn_fn__400000169_A_New_O(p0 any) *A_arbace_c2j_node_emit_fn_fn__400000169_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_emit_fn_fn__400000169_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000169_A) Ctor_O(c__env0 any) { t.F_env0 = c__env0 }
//line :223:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000169_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp2 any = tmp1.Invoke_O__O(lang.IFn_Cast(t.F_env0).Invoke_O__O(f__1)); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp4 any; var root_841 any = A_arbace_c2j_node_A_const_187.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any; var root_845 any = A_arbace_c2j_node_A_const_188.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = f__1; if linked_846 == nil { arg_844 = ifn_847.Invoke_O__O(arg_848) } else { arg_844 = linked_846.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_845, arg_848) }; if linked_842 == nil { tmp4 = ifn_843.Invoke_O__O(arg_844) } else { tmp4 = linked_842.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_841, arg_844) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3.Invoke_O_O__O(tmp4, A_arbace_c2j_node_A_const_189)) }








func A_arbace_c2j_node_defnode_A_New() *A_arbace_c2j_node_defnode_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_defnode_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_c2j_node_defnode_A) Ctor() {}
//line :232:1
func (t *A_arbace_c2j_node_defnode_A) Invoke_O_O_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, kind__2, doc__3, opts__4, bindings__5, template__6 any) any { var d__8 any; var root_860 any = A_arbace_c2j_node_A_const_201.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, A_arbace_c2j_node_parse_A_fn_class); var ifn_862 lang.IFn; if



	linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = kind__2; var arg_864 any = doc__3; var arg_865 any = opts__4; var arg_866 any = bindings__5; var arg_867 any = template__6; if linked_861 == nil { d__8 = ifn_862.Invoke_O_O_O_O_O__O(arg_863, arg_864, arg_865, arg_866, arg_867) } else { d__8 = linked_861.(*A_arbace_c2j_node_parse_A).Invoke_O_O_O_O_O_O__O(root_860, arg_863, arg_864, arg_865, arg_866, arg_867) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_202; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_node_A_const_204; var tmp5 any = tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_205, d__8)); var tmp6 any; var root_868 any = A_arbace_c2j_node_A_const_203.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, A_arbace_c2j_node_emit_fn_A_fn_class); var ifn_870 lang.IFn; if

	linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any = d__8; if linked_869 == nil { tmp6 = ifn_870.Invoke_O__O(arg_871) } else { tmp6 = linked_869.(*A_arbace_c2j_node_emit_fn_A).Invoke_O_O__O(root_868, arg_871) }; return /*line :237:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6) }






























func A_arbace_c2j_node_invalid_A_New() *A_arbace_c2j_node_invalid_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_invalid_A{}; t.Ctor(); return t }
//line :268:1
func (t *A_arbace_c2j_node_invalid_A) Ctor() {}
//line :268:1
func (t *A_arbace_c2j_node_invalid_A) Invoke_O__O(self any) any { var tmp1 any; var root_872 any = A_arbace_c2j_node_A_const_157.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = Lit_50; var arg_876 any = A_arbace_c2j_node_A_const_206; if linked_873 == nil { tmp1 = ifn_874.Invoke_O_O__O(arg_875, arg_876) } else { tmp1 = linked_873.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_872, arg_875, arg_876) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }

func A_arbace_c2j_node_realize_A_New() *A_arbace_c2j_node_realize_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_realize_A{}; t.Ctor(); return t }
//line :270:1
func (t *A_arbace_c2j_node_realize_A) Ctor() {}
//line :270:1
func (t *A_arbace_c2j_node_realize_A) Invoke_O_O__O(self, f__0 any) any {



	var tmp1 any; var root_877 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_879 lang.IFn
	if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = f__0; if linked_878 == nil { tmp1 = ifn_879.Invoke_O__O(arg_880) } else { tmp1 = linked_878.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_877, arg_880) }
//line :274:1
	if jrt.J2g_Truth(tmp1) {
		var root_881 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any; var root_886 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = A_arbace_c2j_node_A_const_39.GetRawRoot__O(); var arg_890 any; var root_891 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = A_arbace_c2j_node_A_const_207.GetRawRoot__O(); var arg_895 any = f__0; if linked_892 == nil { arg_890 = ifn_893.Invoke_O_O__O(arg_894, arg_895) } else { arg_890 = linked_892.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_891, arg_894, arg_895) }; if linked_887 == nil { arg_884 = ifn_888.Invoke_O_O__O(arg_889, arg_890) } else { arg_884 = linked_887.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_886, arg_889, arg_890) }; var arg_885 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__0); if linked_882 == nil { return ifn_883.Invoke_O_O__O(arg_884, arg_885) } else { return linked_882.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_881, arg_884, arg_885) } } else {
//line :274:1
			var tmp2 any; var root_896 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_898 lang.IFn

			if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = f__0; if linked_897 == nil { tmp2 = ifn_898.Invoke_O__O(arg_899) } else { tmp2 = linked_897.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_896, arg_899) }
//line :274:1
			if jrt.J2g_Truth(tmp2) {

				var root_900 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any; var root_905 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = A_arbace_c2j_node_A_const_207.GetRawRoot__O(); var arg_909 any = f__0; if linked_906 == nil { arg_903 = ifn_907.Invoke_O_O__O(arg_908, arg_909) } else { arg_903 = linked_906.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_905, arg_908, arg_909) }; var arg_904 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__0); if linked_901 == nil { return ifn_902.Invoke_O_O__O(arg_903, arg_904) } else { return linked_901.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_900, arg_903, arg_904) } } else {
//line :274:1
					if A_arbace_c2j_node_A_const_45 != nil { return f__0 } else { return nil
					}
				}
		}
}
func A_arbace_c2j_node_arg_kind_A_New() *A_arbace_c2j_node_arg_kind_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_arg_kind_A{}; t.Ctor(); return t }
//line :279:1
func (t *A_arbace_c2j_node_arg_kind_A) Ctor() {}
//line :279:1
func (t *A_arbace_c2j_node_arg_kind_A) Invoke_O_O__O(self, c__0 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Long_TYPE.Ref()) { return A_arbace_c2j_node_A_const_110 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Integer_TYPE.Ref()) { return A_arbace_c2j_node_A_const_208 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Double_TYPE.Ref()) { return A_arbace_c2j_node_A_const_109 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Boolean_TYPE.Ref()) { return A_arbace_c2j_node_A_const_107 } else { if A_arbace_c2j_node_A_const_45 != nil { return A_arbace_c2j_node_A_const_120 } else { return nil
	} } } } } }
func A_arbace_c2j_node_ret_chans_A_New() *A_arbace_c2j_node_ret_chans_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_ret_chans_A{}; t.Ctor(); return t }
//line :284:1
func (t *A_arbace_c2j_node_ret_chans_A) Ctor() {}
//line :284:1
func (t *A_arbace_c2j_node_ret_chans_A) Invoke_O_O__O(self, c__0 any) any {


	var tmp1 bool; var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Long_TYPE.Ref()); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Integer_TYPE.Ref()) }; if tmp1 { return A_arbace_c2j_node_A_const_209 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Double_TYPE.Ref()) { return A_arbace_c2j_node_A_const_210 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Boolean_TYPE.Ref()) { return A_arbace_c2j_node_A_const_211 } else { if A_arbace_c2j_node_A_const_45 != nil { return A_arbace_c2j_node_A_const_212 } else { return nil
	}
	}
	} } }
func A_arbace_c2j_node_qe_elems_A_New() *A_arbace_c2j_node_qe_elems_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_elems_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_c2j_node_qe_elems_A) Ctor() {}
//line :291:1
func (t *A_arbace_c2j_node_qe_elems_A) Invoke_O_O_O_O__O(self, env__0, v__1, xs__2 any) any {
	var root_910 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__941 any = A_arbace_c2j_node_qe_elems_fn__400000181_A_New_O_O(env__0, v__1); var tmp3 *jrt.Class; var fncls__940 *jrt.Class = A_arbace_c2j_node_qe_elems_fn__400000181_A_fn_class; if fncls__940 == nil { var fncls__940d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__941); A_arbace_c2j_node_qe_elems_fn__400000181_A_fn_class = fncls__940d; tmp3 = fncls__940d } else { tmp3 = fncls__940 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__941, tmp3, nil); arg_913 = tmp1.Invoke_O_O__O(tmp2.Ref(), xs__2); if linked_911 == nil { return ifn_912.Invoke_O__O(arg_913) } else { return linked_911.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_910, arg_913) } }
//line :292:1
func A_arbace_c2j_node_qe_elems_fn__400000181_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_elems_fn__400000181_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_elems_fn__400000181_A{}; t.Ctor_O_O(p0, p1); return t }
//line :292:1
func (t *A_arbace_c2j_node_qe_elems_fn__400000181_A) Ctor_O_O(c__env, c__v any) { t.F_env = c__env; t.F_v = c__v }
//line :292:1
func (t *A_arbace_c2j_node_qe_elems_fn__400000181_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_919 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = x__1; if linked_920 == nil { and__1927000168__auto____2 = ifn_921.Invoke_O__O(arg_922) } else { and__1927000168__auto____2 = linked_920.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_919, arg_922) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_c2j_node_A_const_213; var tmp3 any; var root_923 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, A_arbace_c2j_node_head_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = x__1; if linked_924 == nil { tmp3 = ifn_925.Invoke_O__O(arg_926) } else { tmp3 = linked_924.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_923, arg_926) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var b__2 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_env); var tmp5 any; var root_930 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_932 lang.IFn
		if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = x__1; if linked_931 == nil { tmp5 = ifn_932.Invoke_O__O(arg_933) } else { tmp5 = linked_931.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_930, arg_933) }; b__2 = tmp4.Invoke_O__O(tmp5); var tmp6 any = A_arbace_c2j_node_A_const_214; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_c2j_node_A_const_20.Invoke_O__O(b__2)) { var root_927 any = A_arbace_c2j_node_A_const_215.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, A_arbace_c2j_node_invalid_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; if linked_928 == nil { return ifn_929.Invoke__O() } else { return linked_928.(*A_arbace_c2j_node_invalid_A).Invoke_O__O(root_927) } } else { return A_arbace_c2j_node_A_const_216.Invoke_O__O(b__2) } } else {
//line :293:1
			var tmp7 any; var root_934 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, A_arbace_c2j_node_qe_A_fn_class); var ifn_936 lang.IFn

			if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = t.F_env; var arg_938 any = t.F_v; var arg_939 any = x__1; if linked_935 == nil { tmp7 = ifn_936.Invoke_O_O_O__O(arg_937, arg_938, arg_939) } else { tmp7 = linked_935.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_934, arg_937, arg_938, arg_939) }
//line :293:1
			return lang.Tuple_Create_O__IPersistentVector(tmp7)
		}
}


func A_arbace_c2j_node_qe_seq_A_New() *A_arbace_c2j_node_qe_seq_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_A{}; t.Ctor(); return t }
//line :298:1
func (t *A_arbace_c2j_node_qe_seq_A) Ctor() {}
//line :298:1
func (t *A_arbace_c2j_node_qe_seq_A) Invoke_O_O_O_O__O(self, env__0, v__1, t__2 any) any { var vec__400000187__4 any = t__2; var seq__400000188__5 any; var root_942 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_944 lang.IFn; if
												linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = vec__400000187__4; if linked_943 == nil { seq__400000188__5 = ifn_944.Invoke_O__O(arg_945) } else { seq__400000188__5 = linked_943.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_942, arg_945) }; var first__400000189__6 any; var root_946 any = /*line :298:1*/A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_948 lang.IFn; if
												linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = seq__400000188__5; if linked_947 == nil { first__400000189__6 = ifn_948.Invoke_O__O(arg_949) } else { first__400000189__6 = linked_947.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_946, arg_949) }; var seq__400000188__7 any; var root_950 any = /*line :298:1*/A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_952 lang.IFn; if
												linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = seq__400000188__5; if linked_951 == nil { seq__400000188__7 = ifn_952.Invoke_O__O(arg_953) } else { seq__400000188__7 = linked_951.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_950, arg_953) }; var h__8 any = first__400000189__6; var as__9 any = seq__400000188__7; var h_STAR___10 any; var fnbody__971 any = /*line :298:1*/A_arbace_c2j_node_qe_seq_h_STAR___400000190_A_New_O_O_O(env__0, t__2, v__1); var tmp1 *jrt.Class; var fncls__970 *jrt.Class = A_arbace_c2j_node_qe_seq_h_STAR___400000190_A_fn_class; if

	fncls__970 == nil { var fncls__970d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__971); A_arbace_c2j_node_qe_seq_h_STAR___400000190_A_fn_class = fncls__970d; tmp1 = fncls__970d } else { tmp1 = fncls__970 }; h_STAR___10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__971, tmp1, nil); var G__400000192__11_ any = h__8; switch
	lang.Util_Hash_O__I_NoInit(G__400000192__11_) >> 2 & 63 { case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_219) { var vec__400000193__12 any = as__9; var ___13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000193__12, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000193__12, lang.RT_IntCast_J__I_NoInit(1), nil); var b__15 any = lang.IFn_Cast(env__0).Invoke_O__O(xs__14); var tmp2 any = A_arbace_c2j_node_A_const_220; _ = ___13





		if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_c2j_node_A_const_221.Invoke_O__O(v__1)) { var tmp3 any = A_arbace_c2j_node_A_const_222; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_node_A_const_237; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Invoke_O_O_O__O(tmp5, A_arbace_c2j_node_A_const_171.Invoke_O__O(b__15), A_arbace_c2j_node_A_const_238))) } else { var tmp6 any = A_arbace_c2j_node_A_const_223; var tmp7 any; var root_973 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_975 lang.IFn

			if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any; var fnbody__983 any = A_arbace_c2j_node_qe_seq_fn__400000196_A_New_O(b__15); var tmp8 *jrt.Class; var fncls__982 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000196_A_fn_class; if fncls__982 == nil { var fncls__982d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__983); A_arbace_c2j_node_qe_seq_fn__400000196_A_fn_class = fncls__982d; tmp8 = fncls__982d } else { tmp8 = fncls__982 }; arg_976 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__983, tmp8, nil); var arg_977 any; var root_984 any = A_arbace_c2j_node_A_const_226.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = A_arbace_c2j_node_A_const_221.Invoke_O__O(v__1); if linked_985 == nil { arg_977 = ifn_986.Invoke_O__O(arg_987) } else { arg_977 = linked_985.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_984, arg_987) }; if linked_974 == nil { tmp7 = ifn_975.Invoke_O_O__O(arg_976, arg_977) } else { tmp7 = linked_974.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_973, arg_976, arg_977) }
//line :307:1
			return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7)) } }
//line :301:1
	case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_227) {










































		var root_988 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = A_arbace_c2j_node_A_const_228; var arg_992 any; var root_993 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = A_arbace_c2j_node_A_const_229.GetRawRoot__O(); var arg_997 any; var root_998 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any; var fnbody__1010 any = A_arbace_c2j_node_qe_seq_fn__400000198_A_New_O_O(env__0, v__1); var tmp9 *jrt.Class; var fncls__1009 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000198_A_fn_class; if fncls__1009 == nil { var fncls__1009d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, fnbody__1010); A_arbace_c2j_node_qe_seq_fn__400000198_A_fn_class = fncls__1009d; tmp9 = fncls__1009d } else { tmp9 = fncls__1009 }; arg_1001 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1010, tmp9, nil); var arg_1002 any = as__9; if linked_999 == nil { arg_997 = ifn_1000.Invoke_O_O__O(arg_1001, arg_1002) } else { arg_997 = linked_999.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_998, arg_1001, arg_1002) }; if linked_994 == nil { arg_992 = ifn_995.Invoke_O_O__O(arg_996, arg_997) } else { arg_992 = linked_994.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_993, arg_996, arg_997) }; if linked_989 == nil { return ifn_990.Invoke_O_O__O(arg_991, arg_992) } else { return linked_989.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_988, arg_991, arg_992) } }
//line :301:1
	case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_230) { var b__12 any; var tmp10 lang.IFn = lang.IFn_Cast(env__0); var tmp11 any; var root_1035 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1037 lang.IFn
































































		if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = as__9; if linked_1036 == nil { tmp11 = ifn_1037.Invoke_O__O(arg_1038) } else { tmp11 = linked_1036.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1035, arg_1038) }; b__12 = tmp10.Invoke_O__O(tmp11)
//line :301:1
		var G__400000200__13_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__12)

































































		switch lang.Util_Hash_O__I_NoInit(G__400000200__13_) >> 3 & 1 { case 0: if any(G__400000200__13_) == any(A_arbace_c2j_node_A_const_231) {

			var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_node_A_const_239; var tmp14 any = A_arbace_c2j_node_A_const_240; return tmp12.Invoke_O_O_O__O(tmp13, tmp14, A_arbace_c2j_node_A_const_216.Invoke_O__O(b__12)) }
//line :367:1
		case 1: if any(G__400000200__13_) == any(A_arbace_c2j_node_A_const_214) {
			return A_arbace_c2j_node_A_const_232.Invoke_O__O(b__12) }
//line :367:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__400000200__13_))))) }
//line :301:1
	case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_233) { var vec__400000201__12 any = as__9; var c__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000201__12, lang.RT_IntCast_J__I_NoInit(0), nil); var a__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000201__12, lang.RT_IntCast_J__I_NoInit(1), nil); var b__15_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000201__12, lang.RT_IntCast_J__I_NoInit(2), nil); var yes__16 any; var tmp15 any; var root_1012 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1014 lang.IFn













































		if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = c__13; if linked_1013 == nil { tmp15 = ifn_1014.Invoke_O__O(arg_1015) } else { tmp15 = linked_1013.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1012, arg_1015) }
//line :346:1
		if jrt.J2g_Truth(tmp15) {
			yes__16 = lang.RT_Get_O_O__O_NoInit(A_arbace_c2j_node_A_const_234.Invoke_O__O(v__1), c__13) } else {
//line :346:1
				var tmp16 any = A_arbace_c2j_node_A_const_235; var tmp17 any; var root_1016 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, A_arbace_c2j_node_head_A_fn_class); var ifn_1018 lang.IFn

				if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = c__13; if linked_1017 == nil { tmp17 = ifn_1018.Invoke_O__O(arg_1019) } else { tmp17 = linked_1017.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_1016, arg_1019) }
//line :346:1
				if lang.Util_Equiv_O_O__Z_NoInit(tmp16, tmp17) {

					var tmp18 any = A_arbace_c2j_node_A_const_220; yes__16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp18, A_arbace_c2j_node_A_const_221.Invoke_O__O(v__1))).Ref() } else {
//line :346:1
						var tmp19 any = A_arbace_c2j_node_A_const_236; var tmp20 any; var root_1020 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, A_arbace_c2j_node_head_A_fn_class); var ifn_1022 lang.IFn


						if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = c__13; if linked_1021 == nil { tmp20 = ifn_1022.Invoke_O__O(arg_1023) } else { tmp20 = linked_1021.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_1020, arg_1023) }
//line :346:1
						if lang.Util_Equiv_O_O__Z_NoInit(tmp19, tmp20) {


							yes__16 = A_arbace_c2j_node_A_const_73.Invoke_O__O(v__1) } else {
//line :346:1
								if A_arbace_c2j_node_A_const_45 != nil { var tmp21 any; var root_1024 any = A_arbace_c2j_node_A_const_157.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1026 lang.IFn



									if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__13)).Ref(); var arg_1028 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1025 == nil { tmp21 = ifn_1026.Invoke_O_O__O(arg_1027, arg_1028) } else { tmp21 = linked_1025.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1024, arg_1027, arg_1028) }
//line :346:1
									panic(jrt.Thrown(jrt.Throwable_Cast(tmp21))) } else { yes__16 = nil
									}
							}
					}
			}
		var root_1029 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, A_arbace_c2j_node_qe_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = env__0; var arg_1033 any = v__1; var arg_1034 any; if jrt.J2g_Truth(yes__16) { arg_1034 = a__14 } else { arg_1034 = b__15_2 }; if linked_1030 == nil { return ifn_1031.Invoke_O_O_O__O(arg_1032, arg_1033, arg_1034) } else { return linked_1030.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1029, arg_1032, arg_1033, arg_1034) } }
//line :301:1
	case 26: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_241) { var vec__400000204__12 any = as__9; var seq__400000205__13 any; var root_1039 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1041 lang.IFn


















































		if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = vec__400000204__12; if linked_1040 == nil { seq__400000205__13 = ifn_1041.Invoke_O__O(arg_1042) } else { seq__400000205__13 = linked_1040.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1039, arg_1042) }
//line :301:1
		var first__400000206__14 any; var root_1043 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1045 lang.IFn


















































		if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = seq__400000205__13; if linked_1044 == nil { first__400000206__14 = ifn_1045.Invoke_O__O(arg_1046) } else { first__400000206__14 = linked_1044.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1043, arg_1046) }
//line :301:1
		var seq__400000205__15 any; var root_1047 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1049 lang.IFn


















































		if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = seq__400000205__13; if linked_1048 == nil { seq__400000205__15 = ifn_1049.Invoke_O__O(arg_1050) } else { seq__400000205__15 = linked_1048.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1047, arg_1050) }
//line :301:1
		var ___16 any = first__400000206__14; var cls__17 any = seq__400000205__15; var m__18 any; var root_1051 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1053 lang.IFn; _ = ___16



















































		if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = A_arbace_c2j_node_A_const_242.GetRawRoot__O(); var arg_1055 any = cls__17; if linked_1052 == nil { m__18 = ifn_1053.Invoke_O_O__O(arg_1054, arg_1055) } else { m__18 = linked_1052.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1051, arg_1054, arg_1055) }
		var tmp22 any; var root_1056 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = m__18; var arg_1060 any = A_arbace_c2j_node_A_const_168.Invoke_O__O(v__1); if linked_1057 == nil { tmp22 = ifn_1058.Invoke_O_O__O(arg_1059, arg_1060) } else { tmp22 = linked_1057.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1056, arg_1059, arg_1060) }; if jrt.J2g_Truth(tmp22) { var root_1061 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, A_arbace_c2j_node_qe_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = env__0; var arg_1065 any = v__1; var arg_1066 any = lang.IFn_Cast(m__18).Invoke_O__O(A_arbace_c2j_node_A_const_168.Invoke_O__O(v__1)); if linked_1062 == nil { return ifn_1063.Invoke_O_O_O__O(arg_1064, arg_1065, arg_1066) } else { return linked_1062.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1061, arg_1064, arg_1065, arg_1066) } } else { var root_1067 any = A_arbace_c2j_node_A_const_215.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, A_arbace_c2j_node_invalid_A_fn_class); var ifn_1069 lang.IFn; if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; if linked_1068 == nil { return ifn_1069.Invoke__O() } else { return linked_1068.(*A_arbace_c2j_node_invalid_A).Invoke_O__O(root_1067) } } }
//line :301:1
	case 27: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_243) { var vec__400000207__12 any = as__9; var ___13_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000207__12, lang.RT_IntCast_J__I_NoInit(0), nil); var x__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000207__12, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1070 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_1072 lang.IFn; _ = ___13_2









































































		if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any; var tmp23 any = A_arbace_c2j_node_A_const_244; var tmp24 any; var root_1075 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, A_arbace_c2j_node_qe_A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = env__0; var arg_1079 any = v__1; var arg_1080 any = x__14; if linked_1076 == nil { tmp24 = ifn_1077.Invoke_O_O_O__O(arg_1078, arg_1079, arg_1080) } else { tmp24 = linked_1076.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1075, arg_1078, arg_1079, arg_1080) }; arg_1073 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24)); var tmp25 *lang.Keyword = A_arbace_c2j_node_A_const_245; var arg_1074 any = tmp25.Invoke_O__O(A_arbace_c2j_node_A_const_177.Invoke_O__O(v__1)); if linked_1071 == nil { return ifn_1072.Invoke_O_O__O(arg_1073, arg_1074) } else { return linked_1071.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_1070, arg_1073, arg_1074) } }
//line :301:1
	case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_246) { var vec__400000210__12 any = as__9; var ___13_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000210__12, lang.RT_IntCast_J__I_NoInit(0), nil); var c__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000210__12, lang.RT_IntCast_J__I_NoInit(1), nil); var c__15 any; _ = ___13_3





































































		if lang.Util_Equiv_O_O__Z_NoInit(c__14, A_arbace_c2j_node_A_const_247) { c__15 = A_arbace_c2j_node_A_const_168.Invoke_O__O(v__1) } else { c__15 = c__14 }
//line :301:1
		var tmp26 *lang.Keyword = A_arbace_c2j_node_A_const_248; var g__16 any = lang.RT_Get_O_O__O_NoInit(tmp26.Invoke_O__O(A_arbace_c2j_node_A_const_177.Invoke_O__O(v__1)), c__15)
		var or__1927000174__auto____17 any = g__16






































































		if jrt.J2g_Truth(or__1927000174__auto____17) { return or__1927000174__auto____17 } else { var root_1081 any = A_arbace_c2j_node_A_const_215.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, A_arbace_c2j_node_invalid_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; if linked_1082 == nil { return ifn_1083.Invoke__O() } else { return linked_1082.(*A_arbace_c2j_node_invalid_A).Invoke_O__O(root_1081) } } }
//line :301:1
	case 36: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_249) { var vec__400000213__12 any = as__9; var c__13_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000213__12, lang.RT_IntCast_J__I_NoInit(0), nil); var x__14_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000213__12, lang.RT_IntCast_J__I_NoInit(1), nil); var c__15_2 any

		if lang.Util_Equiv_O_O__Z_NoInit(c__13_2, A_arbace_c2j_node_A_const_250) { c__15_2 = A_arbace_c2j_node_A_const_168.Invoke_O__O(v__1) } else { c__15_2 = c__13_2 }
		var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp28 any; var root_1088 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any; var tmp29 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp30 any; var root_1092 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_256.GetRawRoot__O()).Invoke_O__O(c__15_2); if linked_1093 == nil { tmp30 = ifn_1094.Invoke_O__O(arg_1095) } else { tmp30 = linked_1093.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1092, arg_1095) }; arg_1091 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp29, jrt.RefArrayOf(jrt.Object_class, nil, tmp30)).Ref(); if linked_1089 == nil { tmp28 = ifn_1090.Invoke_O__O(arg_1091) } else { tmp28 = linked_1089.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1088, arg_1091) }; var tmp31 *lang.Keyword = A_arbace_c2j_node_A_const_171; return tmp27.Invoke_O_O_O__O(tmp28, tmp31.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(x__14_2)), A_arbace_c2j_node_A_const_257) }
//line :301:1
	case 37: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_251) { var vec__400000216__12 any = as__9; var ___13_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000216__12, lang.RT_IntCast_J__I_NoInit(0), nil); var a__14_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000216__12, lang.RT_IntCast_J__I_NoInit(1), nil); var b__15_3 any = lang.IFn_Cast(env__0).Invoke_O__O(a__14_2); var g__16_2 any; var root_1084 any = A_arbace_c2j_node_A_const_252.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1084, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1086 lang.IFn; _ = ___13_4






























































		if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = A_arbace_c2j_node_A_const_253; if linked_1085 == nil { g__16_2 = ifn_1086.Invoke_O__O(arg_1087) } else { g__16_2 = linked_1085.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1084, arg_1087) }
		var tmp32 *lang.Keyword = A_arbace_c2j_node_A_const_254; var tmp33 lang.IFn = lang.IFn_Cast(tmp32.Invoke_O__O(A_arbace_c2j_node_A_const_255.Invoke_O__O(v__1))); var tmp34 any = A_arbace_c2j_node_A_const_259.Invoke_O__O(v__1); var tmp35 any = A_arbace_c2j_node_A_const_216.Invoke_O__O(b__15_3); var tmp36 *lang.Compiler_AOTFn; var fnbody__1116 any = A_arbace_c2j_node_qe_seq_fn__400000219_A_New_O(g__16_2); var tmp37 *jrt.Class; var fncls__1115 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000219_A_fn_class; if fncls__1115 == nil { var fncls__1115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, fnbody__1116); A_arbace_c2j_node_qe_seq_fn__400000219_A_fn_class = fncls__1115d; tmp37 = fncls__1115d } else { tmp37 = fncls__1115 }; tmp36 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1116, tmp37, nil); return tmp33.Invoke_O_O_O__O(tmp34, tmp35, tmp36.Ref()) }
//line :301:1
	case 45: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_258) {





































		var root_1096 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, A_arbace_c2j_node_qe_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = env__0; var arg_1100 any = v__1; var arg_1101 any; var root_1102 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1104 lang.IFn; if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = as__9; if linked_1103 == nil { arg_1101 = ifn_1104.Invoke_O__O(arg_1105) } else { arg_1101 = linked_1103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1102, arg_1105) }; if linked_1097 == nil { return ifn_1098.Invoke_O_O_O__O(arg_1099, arg_1100, arg_1101) } else { return linked_1097.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1096, arg_1099, arg_1100, arg_1101) } }
//line :301:1
	case 48: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_261) { var vec__400000221__12 any = as__9; var l__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000221__12, lang.RT_IntCast_J__I_NoInit(0), nil); var x__14_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000221__12, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp39 any = A_arbace_c2j_node_A_const_268; var tmp40 any = A_arbace_c2j_node_A_const_270; var tmp41 any; var root_1255 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1255, A_arbace_c2j_node_qe_A_fn_class); var ifn_1257 lang.IFn









































		if linked_1256 == nil { ifn_1257 = lang.IFn_Cast(root_1255) } else { ifn_1257 = nil }; var arg_1258 any = env__0; var arg_1259 any = v__1; var arg_1260 any = x__14_3; if linked_1256 == nil { tmp41 = ifn_1257.Invoke_O_O_O__O(arg_1258, arg_1259, arg_1260) } else { tmp41 = linked_1256.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1255, arg_1258, arg_1259, arg_1260) }; var tmp42 any = lang.Tuple_Create_O_O__IPersistentVector(tmp40, tmp41); var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp44 any = A_arbace_c2j_node_A_const_271; var tmp45 any = A_arbace_c2j_node_A_const_272; var tmp46 any; var root_1261 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, A_arbace_c2j_node_qe_A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any = env__0; var arg_1265 any = v__1; var arg_1266 any = l__13; if linked_1262 == nil { tmp46 = ifn_1263.Invoke_O_O_O__O(arg_1264, arg_1265, arg_1266) } else { tmp46 = linked_1262.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1261, arg_1264, arg_1265, arg_1266) }; return tmp38.Invoke_O_O_O_O__O(tmp39, tmp42, tmp43.Invoke_O_O_O__O(tmp44, tmp45, tmp46), A_arbace_c2j_node_A_const_269) }
//line :301:1
	case 54: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_262) { var vec__400000224__12 any = as__9; var seq__400000225__13 any; var root_1117 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1119 lang.IFn






















		if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = vec__400000224__12; if linked_1118 == nil { seq__400000225__13 = ifn_1119.Invoke_O__O(arg_1120) } else { seq__400000225__13 = linked_1118.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1117, arg_1120) }
//line :301:1
		var first__400000226__14 any; var root_1121 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1123 lang.IFn






















		if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = seq__400000225__13; if linked_1122 == nil { first__400000226__14 = ifn_1123.Invoke_O__O(arg_1124) } else { first__400000226__14 = linked_1122.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1121, arg_1124) }
//line :301:1
		var seq__400000225__15 any; var root_1125 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1127 lang.IFn






















		if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = seq__400000225__13; if linked_1126 == nil { seq__400000225__15 = ifn_1127.Invoke_O__O(arg_1128) } else { seq__400000225__15 = linked_1126.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1125, arg_1128) }
//line :301:1
		var line__16 any = first__400000226__14; var first__400000226__17 any; var root_1129 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1131 lang.IFn






















		if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = seq__400000225__15; if linked_1130 == nil { first__400000226__17 = ifn_1131.Invoke_O__O(arg_1132) } else { first__400000226__17 = linked_1130.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1129, arg_1132) }
//line :301:1
		var seq__400000225__18 any; var root_1133 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1135 lang.IFn






















		if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = seq__400000225__15; if linked_1134 == nil { seq__400000225__18 = ifn_1135.Invoke_O__O(arg_1136) } else { seq__400000225__18 = linked_1134.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1133, arg_1136) }
//line :301:1
		var bv__19 any = first__400000226__17; var body__20 any = seq__400000225__18; var n__21 any; var root_1137 any = A_arbace_c2j_node_A_const_252.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1137, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1139 lang.IFn























		if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = A_arbace_c2j_node_A_const_263; if linked_1138 == nil { n__21 = ifn_1139.Invoke_O__O(arg_1140) } else { n__21 = linked_1138.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1137, arg_1140) }
//line :301:1
		var tmp__22 any; var fnbody__1151 any = A_arbace_c2j_node_qe_seq_tmp__400000230_A_New_O(n__21); var tmp47 *jrt.Class
		var fncls__1150 /*line :301:1*/*jrt.Class = A_arbace_c2j_node_qe_seq_tmp__400000230_A_fn_class
























		if fncls__1150 == nil { var fncls__1150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, fnbody__1151); A_arbace_c2j_node_qe_seq_tmp__400000230_A_fn_class = fncls__1150d; tmp47 = fncls__1150d } else { tmp47 = fncls__1150 }; tmp__22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1151, tmp47, nil)
//line :301:1
		var vec__400000227__23 any; var root_1152 any = A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_1153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1152, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1154 lang.IFn

























		if linked_1153 == nil { ifn_1154 = lang.IFn_Cast(root_1152) } else { ifn_1154 = nil }; var arg_1155 any; var fnbody__1220 any = A_arbace_c2j_node_qe_seq_fn__400000234_A_New_O_O(tmp__22, v__1); var tmp48 *jrt.Class; var fncls__1219 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000234_A_fn_class; if fncls__1219 == nil { var fncls__1219d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, fnbody__1220); A_arbace_c2j_node_qe_seq_fn__400000234_A_fn_class = fncls__1219d; tmp48 = fncls__1219d } else { tmp48 = fncls__1219 }; arg_1155 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1220, tmp48, nil); var arg_1156 any = lang.Tuple_Create_O_O__IPersistentVector(env__0, lang.PersistentVector_EMPTY.Ref()); var arg_1157 any; var root_1221 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_1223 lang.IFn








		if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = A_arbace_c2j_node_A_const_25; var arg_1225 any = bv__19; if linked_1222 == nil { arg_1157 = ifn_1223.Invoke_O_O__O(arg_1224, arg_1225) } else { arg_1157 = linked_1222.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_1221, arg_1224, arg_1225) }
//line :327:1
		if linked_1153 == nil { vec__400000227__23 = ifn_1154.Invoke_O_O_O__O(arg_1155, arg_1156, arg_1157) } else { vec__400000227__23 = linked_1153.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1152, arg_1155, arg_1156, arg_1157) }
//line :301:1
		var env__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000227__23, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000227__23, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1226 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1228 lang.IFn



































		if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any; var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp50 any = A_arbace_c2j_node_A_const_265; var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp52 any = A_arbace_c2j_node_A_const_266; var tmp53 any = A_arbace_c2j_node_A_const_267; var tmp54 any; var root_1231 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, A_arbace_c2j_node_qe_A_fn_class); var ifn_1233 lang.IFn; if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any = env__24; var arg_1235 any = v__1; var arg_1236 any = line__16; if linked_1232 == nil { tmp54 = ifn_1233.Invoke_O_O_O__O(arg_1234, arg_1235, arg_1236) } else { tmp54 = linked_1232.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1231, arg_1234, arg_1235, arg_1236) }; arg_1229 = tmp49.Invoke_O_O_O__O(tmp50, binds__25, tmp51.Invoke_O_O_O__O(tmp52, tmp53, tmp54)); var arg_1230 any; var root_1237 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1239 lang.IFn
		if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any = A_arbace_c2j_node_A_const_229.GetRawRoot__O(); var arg_1241 any; var root_1242 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1242, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1244 lang.IFn; if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any; var fnbody__1254 any = A_arbace_c2j_node_qe_seq_fn__400000244_A_New_O_O(v__1, env__24); var tmp55 *jrt.Class; var fncls__1253 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000244_A_fn_class; if fncls__1253 == nil { var fncls__1253d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__1254); A_arbace_c2j_node_qe_seq_fn__400000244_A_fn_class = fncls__1253d; tmp55 = fncls__1253d } else { tmp55 = fncls__1253 }; arg_1245 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1254, tmp55, nil); var arg_1246 any = body__20; if linked_1243 == nil { arg_1241 = ifn_1244.Invoke_O_O__O(arg_1245, arg_1246) } else { arg_1241 = linked_1243.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1242, arg_1245, arg_1246) }; if linked_1238 == nil { arg_1230 = ifn_1239.Invoke_O_O__O(arg_1240, arg_1241) } else { arg_1230 = linked_1238.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1237, arg_1240, arg_1241) }
//line :337:1
		if linked_1227 == nil { return ifn_1228.Invoke_O_O__O(arg_1229, arg_1230) } else { return linked_1227.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1226, arg_1229, arg_1230) } }
//line :301:1
	case 56: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_273) { var vec__400000246__12 any = as__9; var ___13_5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000246__12, lang.RT_IntCast_J__I_NoInit(0), nil); var ___14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000246__12, lang.RT_IntCast_J__I_NoInit(1), nil); var f__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000246__12, lang.RT_IntCast_J__I_NoInit(2), nil); var m__16 any = A_arbace_c2j_node_A_const_259.Invoke_O__O(v__1); var r__17 any = jrt.NN(jrt.Method_Cast(m__16)).GetReturnType__Class().Ref(); var tmp56 any; var root_1267 any = A_arbace_c2j_node_A_const_274.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1269 lang.IFn; _ = ___13_5; _ = ___14

























































		if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any; var root_1271 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any; var root_1276 any = A_arbace_c2j_node_A_const_275.GetRawRoot__O(); var linked_1277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1276, A_arbace_c2j_node_ret_chans_A_fn_class); var ifn_1278 lang.IFn; if linked_1277 == nil { ifn_1278 = lang.IFn_Cast(root_1276) } else { ifn_1278 = nil }; var arg_1279 any = r__17; if linked_1277 == nil { arg_1274 = ifn_1278.Invoke_O__O(arg_1279) } else { arg_1274 = linked_1277.(*A_arbace_c2j_node_ret_chans_A).Invoke_O_O__O(root_1276, arg_1279) }; var arg_1275 any = A_arbace_c2j_node_A_const_168.Invoke_O__O(v__1); if linked_1272 == nil { arg_1270 = ifn_1273.Invoke_O_O__O(arg_1274, arg_1275) } else { arg_1270 = linked_1272.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1271, arg_1274, arg_1275) }; if linked_1268 == nil { tmp56 = ifn_1269.Invoke_O__O(arg_1270) } else { tmp56 = linked_1268.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1267, arg_1270) }
//line :358:1
		if jrt.J2g_Truth(tmp56) {
			var root_1280 any = A_arbace_c2j_node_A_const_215.GetRawRoot__O(); var linked_1281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1280, A_arbace_c2j_node_invalid_A_fn_class); var ifn_1282 lang.IFn; if linked_1281 == nil { ifn_1282 = lang.IFn_Cast(root_1280) } else { ifn_1282 = nil }; if linked_1281 == nil { return ifn_1282.Invoke__O() } else { return linked_1281.(*A_arbace_c2j_node_invalid_A).Invoke_O__O(root_1280) } } else {
//line :358:1
				var tmp57 any = A_arbace_c2j_node_A_const_120; if lang.Util_Equiv_O_O__Z_NoInit(tmp57, A_arbace_c2j_node_A_const_168.Invoke_O__O(v__1)) {

					var tmp58 *lang.Keyword = A_arbace_c2j_node_A_const_276; var tmp59 lang.IFn = lang.IFn_Cast(tmp58.Invoke_O__O(A_arbace_c2j_node_A_const_255.Invoke_O__O(v__1))); var tmp60 any; var root_1342 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1342, A_arbace_c2j_node_qe_A_fn_class); var ifn_1344 lang.IFn; if linked_1343 == nil { ifn_1344 = lang.IFn_Cast(root_1342) } else { ifn_1344 = nil }; var arg_1345 any = env__0; var arg_1346 any = v__1; var arg_1347 any = f__15; if linked_1343 == nil { tmp60 = ifn_1344.Invoke_O_O_O__O(arg_1345, arg_1346, arg_1347) } else { tmp60 = linked_1343.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1342, arg_1345, arg_1346, arg_1347) }; return tmp59.Invoke_O_O__O(tmp60, r__17) } else {
//line :358:1
						if A_arbace_c2j_node_A_const_45 != nil {


							var root_1283 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1283, A_arbace_c2j_node_qe_A_fn_class); var ifn_1285 lang.IFn; if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any = env__0; var arg_1287 any = v__1; var arg_1288 any = f__15; if linked_1284 == nil { return ifn_1285.Invoke_O_O_O__O(arg_1286, arg_1287, arg_1288) } else { return linked_1284.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1283, arg_1286, arg_1287, arg_1288) } } else {
//line :358:1
								return nil } } } }
//line :301:1
	case 57: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_277) { var vec__400000249__12 any = as__9; var seq__400000250__13 any; var root_1289 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1291 lang.IFn










































































		if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = vec__400000249__12; if linked_1290 == nil { seq__400000250__13 = ifn_1291.Invoke_O__O(arg_1292) } else { seq__400000250__13 = linked_1290.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1289, arg_1292) }
//line :301:1
		var first__400000251__14 any; var root_1293 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1295 lang.IFn










































































		if linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = seq__400000250__13; if linked_1294 == nil { first__400000251__14 = ifn_1295.Invoke_O__O(arg_1296) } else { first__400000251__14 = linked_1294.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1293, arg_1296) }
//line :301:1
		var seq__400000250__15 any; var root_1297 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1297, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1299 lang.IFn










































































		if linked_1298 == nil { ifn_1299 = lang.IFn_Cast(root_1297) } else { ifn_1299 = nil }; var arg_1300 any = seq__400000250__13; if linked_1298 == nil { seq__400000250__15 = ifn_1299.Invoke_O__O(arg_1300) } else { seq__400000250__15 = linked_1298.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1297, arg_1300) }
//line :301:1
		var bv__16 any = first__400000251__14; var body__17 any = seq__400000250__15; var root_1301 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1303 lang.IFn











































































		if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = A_arbace_c2j_node_A_const_278; var arg_1305 any; var root_1307 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1309 lang.IFn; if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any; var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp62 *lang.Compiler_AOTFn; var fnbody__1323 any = A_arbace_c2j_node_qe_seq_fn__400000253_A_New_O_O(env__0, v__1); var tmp63 *jrt.Class; var fncls__1322 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000253_A_fn_class; if fncls__1322 == nil { var fncls__1322d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, fnbody__1323); A_arbace_c2j_node_qe_seq_fn__400000253_A_fn_class = fncls__1322d; tmp63 = fncls__1322d } else { tmp63 = fncls__1322 }; tmp62 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1323, tmp63, nil); var tmp64 any = tmp62.Ref(); var tmp65 any; var root_1324 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_1326 lang.IFn; if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = A_arbace_c2j_node_A_const_25; var arg_1328 any = bv__16; if linked_1325 == nil { tmp65 = ifn_1326.Invoke_O_O__O(arg_1327, arg_1328) } else { tmp65 = linked_1325.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_1324, arg_1327, arg_1328) }; arg_1310 = tmp61.Invoke_O_O__O(tmp64, tmp65); if linked_1308 == nil { arg_1305 = ifn_1309.Invoke_O__O(arg_1310) } else { arg_1305 = linked_1308.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1307, arg_1310) }; var arg_1306 any; var root_1329 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1330 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1329, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1331 lang.IFn
		if linked_1330 == nil { ifn_1331 = lang.IFn_Cast(root_1329) } else { ifn_1331 = nil }; var arg_1332 any; var fnbody__1341 any = A_arbace_c2j_node_qe_seq_fn__400000258_A_New_O_O(env__0, v__1); var tmp66 *jrt.Class; var fncls__1340 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000258_A_fn_class; if fncls__1340 == nil { var fncls__1340d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, fnbody__1341); A_arbace_c2j_node_qe_seq_fn__400000258_A_fn_class = fncls__1340d; tmp66 = fncls__1340d } else { tmp66 = fncls__1340 }; arg_1332 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1341, tmp66, nil); var arg_1333 any = body__17; if linked_1330 == nil { arg_1306 = ifn_1331.Invoke_O_O__O(arg_1332, arg_1333) } else { arg_1306 = linked_1330.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1329, arg_1332, arg_1333) }
//line :377:1
		if linked_1302 == nil { return ifn_1303.Invoke_O_O_O__O(arg_1304, arg_1305, arg_1306) } else { return linked_1302.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1301, arg_1304, arg_1305, arg_1306) } }
//line :301:1
	case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_279) { var vec__400000260__12 any = as__9; var ___13_6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000260__12, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__14_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000260__12, lang.RT_IntCast_J__I_NoInit(1), nil); var b__15_4 any = lang.IFn_Cast(env__0).Invoke_O__O(xs__14_2); var m__16_2 any = A_arbace_c2j_node_A_const_259.Invoke_O__O(v__1); var tmp67 *lang.Keyword = A_arbace_c2j_node_A_const_280; var ts__17 any = tmp67.Invoke_O__O(A_arbace_c2j_node_A_const_255.Invoke_O__O(v__1)); var tmp68 any = A_arbace_c2j_node_A_const_223; var tmp69 any; var root_1348 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1350 lang.IFn; _ = ___13_6












		if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any; var root_1352 any = A_arbace_c2j_node_A_const_281.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1354 lang.IFn; if linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any; var fnbody__1367 any = A_arbace_c2j_node_qe_seq_fn__400000263_A_New_O_O(ts__17, b__15_4); var tmp70 *jrt.Class; var fncls__1366 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000263_A_fn_class
		if fncls__1366 == nil { var fncls__1366d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, fnbody__1367); A_arbace_c2j_node_qe_seq_fn__400000263_A_fn_class = fncls__1366d; tmp70 = fncls__1366d } else { tmp70 = fncls__1366 }; arg_1355 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1367, tmp70, nil)
//line :314:1
		var arg_1356 any = jrt.NN(jrt.Method_Cast(m__16_2)).GetParameterTypes__Class1().Ref(); if linked_1353 == nil { arg_1351 = ifn_1354.Invoke_O_O__O(arg_1355, arg_1356) } else { arg_1351 = linked_1353.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1352, arg_1355, arg_1356) }; if linked_1349 == nil { tmp69 = ifn_1350.Invoke_O__O(arg_1351) } else { tmp69 = linked_1349.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1348, arg_1351) }
//line :301:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp68, tmp69)) }; default:}; return /*line :379:1*/ lang.IFn_Cast(h_STAR___10).Invoke__O() }
//line :300:1
func A_arbace_c2j_node_qe_seq_h_STAR___400000190_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_qe_seq_h_STAR___400000190_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_h_STAR___400000190_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :300:1
func (t *A_arbace_c2j_node_qe_seq_h_STAR___400000190_A) Ctor_O_O_O(c__env, c__t, c__v any) { t.F_env = c__env; t.F_t = c__t; t.F_v = c__v }
//line :300:1
func (t *A_arbace_c2j_node_qe_seq_h_STAR___400000190_A) Invoke_O__O(self any) any { var root_954 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any; var root_959 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_959, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = A_arbace_c2j_node_A_const_39.GetRawRoot__O(); var arg_963 any; var root_964 any = A_arbace_c2j_node_A_const_218.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, A_arbace_c2j_node_qe_elems_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = t.F_env; var arg_968 any = t.F_v; var arg_969 any = t.F_t; if linked_965 == nil { arg_963 = ifn_966.Invoke_O_O_O__O(arg_967, arg_968, arg_969) } else { arg_963 = linked_965.(*A_arbace_c2j_node_qe_elems_A).Invoke_O_O_O_O__O(root_964, arg_967, arg_968, arg_969) }; if linked_960 == nil { arg_957 = ifn_961.Invoke_O_O__O(arg_962, arg_963) } else { arg_957 = linked_960.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_959, arg_962, arg_963) }; var arg_958 any = lang.RT_Meta_O__IPersistentMap_NoInit(t.F_t); if linked_955 == nil { return ifn_956.Invoke_O_O__O(arg_957, arg_958) } else { return linked_955.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_954, arg_957, arg_958) } }








func A_arbace_c2j_node_qe_seq_fn__400000196_A_New_O(p0 any) *A_arbace_c2j_node_qe_seq_fn__400000196_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000196_A{}; t.Ctor_O(p0); return t }
//line :309:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000196_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :309:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000196_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_224; var tmp3 any; var root_978 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_980 lang.IFn; if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_171.Invoke_O__O(t.F_b), i__1)).Ref(); if linked_979 == nil { tmp3 = ifn_980.Invoke_O__O(arg_981) } else { tmp3 = linked_979.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_978, arg_981) }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_c2j_node_A_const_225) }





func A_arbace_c2j_node_qe_seq_fn__400000263_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000263_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000263_A{}; t.Ctor_O_O(p0, p1); return t }
//line :315:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000263_A) Ctor_O_O(c__ts, c__b any) { t.F_ts = c__ts; t.F_b = c__b }
//line :315:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000263_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var a__3 any; var root_1357 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1359 lang.IFn; if
												linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_171.Invoke_O__O(t.F_b), i__1)).Ref(); if linked_1358 == nil { a__3 = ifn_1359.Invoke_O__O(arg_1360) } else { a__3 = linked_1358.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1357, arg_1360) }; var G__400000264__4_ any; var root_1361 any = /*line :315:1*/A_arbace_c2j_node_A_const_282.GetRawRoot__O(); var linked_1362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1361, A_arbace_c2j_node_arg_kind_A_fn_class); var ifn_1363 lang.IFn; if

	linked_1362 == nil { ifn_1363 = lang.IFn_Cast(root_1361) } else { ifn_1363 = nil }; var arg_1364 any = p__2; if linked_1362 == nil { G__400000264__4_ = ifn_1363.Invoke_O__O(arg_1364) } else { G__400000264__4_ = linked_1362.(*A_arbace_c2j_node_arg_kind_A).Invoke_O_O__O(root_1361, arg_1364) }; switch lang.Util_Hash_O__I_NoInit(G__400000264__4_) { case 1013910639: if any(G__400000264__4_) == any(A_arbace_c2j_node_A_const_109) {


		return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_284, a__3, A_arbace_c2j_node_A_const_285) }
//line :317:1
	case 1013911026: if any(G__400000264__4_) == any(A_arbace_c2j_node_A_const_110) {
		return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_286, a__3, A_arbace_c2j_node_A_const_287) }
//line :317:1
	case 1013911091: if any(G__400000264__4_) == any(A_arbace_c2j_node_A_const_208) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_288; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_289, a__3, A_arbace_c2j_node_A_const_290)) }
//line :317:1
	case 1013911476: if any(G__400000264__4_) == any(A_arbace_c2j_node_A_const_120) {




		if lang.Util_Equiv_O_O__Z_NoInit(p__2, A_arbace_c2j_node_A_const_283) { return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_291, a__3, A_arbace_c2j_node_A_const_292) } else { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_node_A_const_293; return tmp3.Invoke_O_O_O__O(tmp4, lang.IFn_Cast(t.F_ts).Invoke_O__O(p__2), lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_294, a__3, A_arbace_c2j_node_A_const_295)) } }
//line :317:1
	case 1013912038: if any(G__400000264__4_) == any(A_arbace_c2j_node_A_const_107) {



		return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_296, a__3, A_arbace_c2j_node_A_const_297) }
//line :317:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__400000264__4_))))) }








func A_arbace_c2j_node_qe_seq_tmp__400000230_A_New_O(p0 any) *A_arbace_c2j_node_qe_seq_tmp__400000230_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_tmp__400000230_A{}; t.Ctor_O(p0); return t }
//line :326:1
func (t *A_arbace_c2j_node_qe_seq_tmp__400000230_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :326:1
func (t *A_arbace_c2j_node_qe_seq_tmp__400000230_A) Invoke_O__O(self any) any { var root_1141 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1141, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1143 lang.IFn; if linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_77, nil); var tmp2 any; var root_1145 any = A_arbace_c2j_node_A_const_9.GetRawRoot__O(); var linked_1146 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1145, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1147 lang.IFn; if linked_1146 == nil { ifn_1147 = lang.IFn_Cast(root_1145) } else { ifn_1147 = nil }; var arg_1148 any = t.F_n; var arg_1149 any = A_arbace_c2j_node_A_const_260.GetRawRoot__O(); if linked_1146 == nil { tmp2 = ifn_1147.Invoke_O_O__O(arg_1148, arg_1149) } else { tmp2 = linked_1146.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_1145, arg_1148, arg_1149) }; arg_1144 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_1142 == nil { return ifn_1143.Invoke_O__O(arg_1144) } else { return linked_1142.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1141, arg_1144) } }
func A_arbace_c2j_node_qe_seq_fn__400000234_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000234_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000234_A{}; t.Ctor_O_O(p0, p1); return t }
//line :327:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000234_A) Ctor_O_O(c__tmp, c__v any) { t.F_tmp = c__tmp; t.F_v = c__v }
//line :327:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000234_A) Invoke_O_O_O__O(self, p__400000232__1, p__400000233__2 any) any { var vec__400000235__3 any = p__400000232__1; var env__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000235__3, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000235__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__400000238__6 any = p__400000233__2; var s__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000238__6, lang.RT_IntCast_J__I_NoInit(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000238__6, lang.RT_IntCast_J__I_NoInit(1), nil); var r__9 any; var root_1158 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, A_arbace_c2j_node_qe_A_fn_class); var ifn_1160 lang.IFn; if
															linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any = env__4; var arg_1162 any = t.F_v; var arg_1163 any = init__8; if linked_1159 == nil { r__9 = ifn_1160.Invoke_O_O_O__O(arg_1161, arg_1162, arg_1163) } else { r__9 = linked_1159.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1158, arg_1161, arg_1162, arg_1163) }; var tmp1 any; var and__1927000168__auto____10 any; var root_1164 any =
															A_arbace_c2j_node_A_const_43.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1166 lang.IFn; if
															linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = r__9; if linked_1165 == nil { and__1927000168__auto____10 = ifn_1166.Invoke_O__O(arg_1167) } else { and__1927000168__auto____10 = linked_1165.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1164, arg_1167) }; if jrt.J2g_Truth(and__1927000168__auto____10) { tmp1 = A_arbace_c2j_node_A_const_223.Invoke_O__O(r__9) } else { tmp1 = and__1927000168__auto____10 }; if /*line :329:1*/ jrt.J2g_Truth(tmp1) { var ts__10 any; var root_1168 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_1169 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1168, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1170 lang.IFn

		if linked_1169 == nil { ifn_1170 = lang.IFn_Cast(root_1168) } else { ifn_1170 = nil }; var arg_1171 any; var fnbody__1174 any = A_arbace_c2j_node_qe_seq_fn__400000234_fn__400000241_A_New_O(t.F_tmp); var tmp2 *jrt.Class; var fncls__1173 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000234_fn__400000241_A_fn_class; if fncls__1173 == nil { var fncls__1173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__1174); A_arbace_c2j_node_qe_seq_fn__400000234_fn__400000241_A_fn_class = fncls__1173d; tmp2 = fncls__1173d } else { tmp2 = fncls__1173 }; arg_1171 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1174, tmp2, nil); var arg_1172 any = A_arbace_c2j_node_A_const_223.Invoke_O__O(r__9); if linked_1169 == nil { ts__10 = ifn_1170.Invoke_O_O__O(arg_1171, arg_1172) } else { ts__10 = linked_1169.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1168, arg_1171, arg_1172) }
//line :329:1
		var tmp3 any; var root_1179 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1181 lang.IFn


		if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any = env__4; var arg_1183 any = s__7; var arg_1184 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_231, A_arbace_c2j_node_A_const_216, ts__10)); if linked_1180 == nil { tmp3 = ifn_1181.Invoke_O_O_O__O(arg_1182, arg_1183, arg_1184) } else { tmp3 = linked_1180.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1179, arg_1182, arg_1183, arg_1184) }
//line :329:1
		var tmp4 any = tmp3; var tmp5 any; var root_1185 any = A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1187 lang.IFn


		if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = binds__5; var arg_1189 any; var root_1190 any = A_arbace_c2j_node_A_const_264.GetRawRoot__O(); var linked_1191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1190, aot_arbace_core.A_arbace_core_interleave_A_fn_class); var ifn_1192 lang.IFn; if linked_1191 == nil { ifn_1192 = lang.IFn_Cast(root_1190) } else { ifn_1192 = nil }; var arg_1193 any = ts__10; var arg_1194 any = A_arbace_c2j_node_A_const_223.Invoke_O__O(r__9); if linked_1191 == nil { arg_1189 = ifn_1192.Invoke_O_O__O(arg_1193, arg_1194) } else { arg_1189 = linked_1191.(*aot_arbace_core.A_arbace_core_interleave_A).Invoke_O_O_O__O(root_1190, arg_1193, arg_1194) }; if linked_1186 == nil { tmp5 = ifn_1187.Invoke_O_O__O(arg_1188, arg_1189) } else { tmp5 = linked_1186.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1185, arg_1188, arg_1189) }
//line :329:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5) } else { var tmp6 any; var and__1927000168__auto____10_2 any; var root_1175 any = A_arbace_c2j_node_A_const_43.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1177 lang.IFn



			if linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = r__9; if linked_1176 == nil { and__1927000168__auto____10_2 = ifn_1177.Invoke_O__O(arg_1178) } else { and__1927000168__auto____10_2 = linked_1176.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1175, arg_1178) }; if jrt.J2g_Truth(and__1927000168__auto____10_2) { tmp6 = A_arbace_c2j_node_A_const_222.Invoke_O__O(r__9) } else { tmp6 = and__1927000168__auto____10_2 }
//line :329:1
			if jrt.J2g_Truth(tmp6) { var t__10 any = lang.IFn_Cast(t.F_tmp).Invoke__O(); var tmp7 any; var root_1195 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1197 lang.IFn




				if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any = env__4; var arg_1199 any = s__7; var arg_1200 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_214, A_arbace_c2j_node_A_const_232, t__10)); if linked_1196 == nil { tmp7 = ifn_1197.Invoke_O_O_O__O(arg_1198, arg_1199, arg_1200) } else { tmp7 = linked_1196.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1195, arg_1198, arg_1199, arg_1200) }
//line :329:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(binds__5, t__10, A_arbace_c2j_node_A_const_222.Invoke_O__O(r__9))) } else { if A_arbace_c2j_node_A_const_45 != nil { var t__10_2 any = lang.IFn_Cast(t.F_tmp).Invoke__O(); var tmp8 any; var root_1207 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1207, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1209 lang.IFn





					if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = env__4; var arg_1211 any = s__7; var arg_1212 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_132, A_arbace_c2j_node_A_const_232, t__10_2)); if linked_1208 == nil { tmp8 = ifn_1209.Invoke_O_O_O__O(arg_1210, arg_1211, arg_1212) } else { tmp8 = linked_1208.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1207, arg_1210, arg_1211, arg_1212) }
//line :329:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(binds__5, t__10_2, r__9)) } else { return nil } } } }

func A_arbace_c2j_node_qe_seq_fn__400000234_fn__400000241_A_New_O(p0 any) *A_arbace_c2j_node_qe_seq_fn__400000234_fn__400000241_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000234_fn__400000241_A{}; t.Ctor_O(p0); return t }
//line :331:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000234_fn__400000241_A) Ctor_O(c__tmp any) { t.F_tmp = c__tmp }
//line :331:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000234_fn__400000241_A) Invoke_O_O__O(self, ___1 any) any { return lang.IFn_Cast(t.F_tmp).Invoke__O() }






func A_arbace_c2j_node_qe_seq_fn__400000244_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000244_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000244_A{}; t.Ctor_O_O(p0, p1); return t }
//line :338:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000244_A) Ctor_O_O(c__v, c__env any) { t.F_v = c__v; t.F_env = c__env }
//line :338:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000244_A) Invoke_O_O__O(self, p1__400000184_SHARP___1 any) any { var root_1247 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1247, A_arbace_c2j_node_qe_A_fn_class); var ifn_1249 lang.IFn; if linked_1248 == nil { ifn_1249 = lang.IFn_Cast(root_1247) } else { ifn_1249 = nil }; var arg_1250 any = t.F_env; var arg_1251 any = t.F_v; var arg_1252 any = p1__400000184_SHARP___1; if linked_1248 == nil { return ifn_1249.Invoke_O_O_O__O(arg_1250, arg_1251, arg_1252) } else { return linked_1248.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1247, arg_1250, arg_1251, arg_1252) } }





func A_arbace_c2j_node_qe_seq_fn__400000198_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000198_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000198_A{}; t.Ctor_O_O(p0, p1); return t }
//line :344:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000198_A) Ctor_O_O(c__env, c__v any) { t.F_env = c__env; t.F_v = c__v }
//line :344:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000198_A) Invoke_O_O__O(self, p1__400000185_SHARP___1 any) any { var root_1003 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, A_arbace_c2j_node_qe_A_fn_class); var ifn_1005 lang.IFn; if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = t.F_env; var arg_1007 any = t.F_v; var arg_1008 any = p1__400000185_SHARP___1; if linked_1004 == nil { return ifn_1005.Invoke_O_O_O__O(arg_1006, arg_1007, arg_1008) } else { return linked_1004.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1003, arg_1006, arg_1007, arg_1008) } }




















func A_arbace_c2j_node_qe_seq_fn__400000219_A_New_O(p0 any) *A_arbace_c2j_node_qe_seq_fn__400000219_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000219_A{}; t.Ctor_O(p0); return t }
//line :365:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000219_A) Ctor_O(c__g any) { t.F_g = c__g }
//line :365:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000219_A) Invoke_O_O__O(self, base__1 any) any { var root_1106 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1106, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1108 lang.IFn; if linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_1110 any = A_arbace_c2j_node_A_const_9.GetRawRoot__O(); var linked_1111 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1110, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1112 lang.IFn; if linked_1111 == nil { ifn_1112 = lang.IFn_Cast(root_1110) } else { ifn_1112 = nil }; var arg_1113 any = t.F_g; var arg_1114 any = A_arbace_c2j_node_A_const_260.GetRawRoot__O(); if linked_1111 == nil { tmp2 = ifn_1112.Invoke_O_O__O(arg_1113, arg_1114) } else { tmp2 = linked_1111.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_1110, arg_1113, arg_1114) }; arg_1109 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, base__1, tmp2)).Ref(); if linked_1107 == nil { return ifn_1108.Invoke_O__O(arg_1109) } else { return linked_1107.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1106, arg_1109) } }











func A_arbace_c2j_node_qe_seq_fn__400000253_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000253_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000253_A{}; t.Ctor_O_O(p0, p1); return t }
//line :377:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000253_A) Ctor_O_O(c__env, c__v any) { t.F_env = c__env; t.F_v = c__v }
//line :377:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000253_A) Invoke_O_O__O(self, p__400000252__1 any) any { var vec__400000254__2 any = p__400000252__1; var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000254__2, lang.RT_IntCast_J__I_NoInit(0), nil); var init__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000254__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1316 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1316, A_arbace_c2j_node_qe_A_fn_class); var ifn_1318 lang.IFn; if linked_1317 == nil { ifn_1318 = lang.IFn_Cast(root_1316) } else { ifn_1318 = nil }; var arg_1319 any = t.F_env; var arg_1320 any = t.F_v; var arg_1321 any = init__4; if linked_1317 == nil { tmp1 = ifn_1318.Invoke_O_O_O__O(arg_1319, arg_1320, arg_1321) } else { tmp1 = linked_1317.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1316, arg_1319, arg_1320, arg_1321) }; return lang.Tuple_Create_O_O__IPersistentVector(s__3, tmp1) }
func A_arbace_c2j_node_qe_seq_fn__400000258_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000258_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000258_A{}; t.Ctor_O_O(p0, p1); return t }
//line :378:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000258_A) Ctor_O_O(c__env, c__v any) { t.F_env = c__env; t.F_v = c__v }
//line :378:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000258_A) Invoke_O_O__O(self, p1__400000186_SHARP___1 any) any { var root_1334 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, A_arbace_c2j_node_qe_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = t.F_env; var arg_1338 any = t.F_v; var arg_1339 any = p1__400000186_SHARP___1; if linked_1335 == nil { return ifn_1336.Invoke_O_O_O__O(arg_1337, arg_1338, arg_1339) } else { return linked_1335.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1334, arg_1337, arg_1338, arg_1339) } }


func A_arbace_c2j_node_qe_A_New() *A_arbace_c2j_node_qe_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_A{}; t.Ctor(); return t }
//line :381:1
func (t *A_arbace_c2j_node_qe_A) Ctor() {}
//line :381:1
func (t *A_arbace_c2j_node_qe_A) Invoke_O_O_O_O__O(self, env__0, v__1, t__2 any) any {


	var tmp1 any; var root_1368 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1370 lang.IFn
	if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any = t__2; if linked_1369 == nil { tmp1 = ifn_1370.Invoke_O__O(arg_1371) } else { tmp1 = linked_1369.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1368, arg_1371) }
//line :384:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000408__auto____4 any = lang.IFn_Cast(env__0).Invoke_O__O(t__2)
		if jrt.J2g_Truth(temp__1927000408__auto____4) { var b__5 any = temp__1927000408__auto____4; var G__400000267__6_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__5)
			switch lang.Util_Hash_O__I_NoInit(G__400000267__6_) >> 0 & 3 { case 1: if any(G__400000267__6_) == any(A_arbace_c2j_node_A_const_214) {


				return A_arbace_c2j_node_A_const_232.Invoke_O__O(b__5) }
//line :386:1
			case 2: if any(G__400000267__6_) == any(A_arbace_c2j_node_A_const_132) {

				return A_arbace_c2j_node_A_const_232.Invoke_O__O(b__5) }
//line :386:1
			case 3: if any(G__400000267__6_) == any(A_arbace_c2j_node_A_const_156) {
				var tmp2 any; var root_1373 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = A_arbace_c2j_node_A_const_234.Invoke_O__O(v__1); var arg_1377 any = t__2; if linked_1374 == nil { tmp2 = ifn_1375.Invoke_O_O__O(arg_1376, arg_1377) } else { tmp2 = linked_1374.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1373, arg_1376, arg_1377) }; if jrt.J2g_Truth(tmp2) { return lang.RT_Get_O_O__O_NoInit(A_arbace_c2j_node_A_const_234.Invoke_O__O(v__1), t__2) } else { return A_arbace_c2j_node_A_const_171.Invoke_O__O(b__5) } }
//line :386:1
			default:}; return t__2 } else {
//line :385:1
				return t__2 } } else {
//line :384:1
					var tmp3 any; var root_1378 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1380 lang.IFn







					if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = t__2; if linked_1379 == nil { tmp3 = ifn_1380.Invoke_O__O(arg_1381) } else { tmp3 = linked_1379.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1378, arg_1381) }
//line :384:1
					if jrt.J2g_Truth(tmp3) {







						var root_1382 any = A_arbace_c2j_node_A_const_298.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, A_arbace_c2j_node_qe_seq_A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = env__0; var arg_1386 any = v__1; var arg_1387 any = t__2; if linked_1383 == nil { return ifn_1384.Invoke_O_O_O__O(arg_1385, arg_1386, arg_1387) } else { return linked_1383.(*A_arbace_c2j_node_qe_seq_A).Invoke_O_O_O_O__O(root_1382, arg_1385, arg_1386, arg_1387) } } else {
//line :384:1
							var tmp4 any; var root_1388 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1390 lang.IFn








							if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = t__2; if linked_1389 == nil { tmp4 = ifn_1390.Invoke_O__O(arg_1391) } else { tmp4 = linked_1389.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1388, arg_1391) }
//line :384:1
							if jrt.J2g_Truth(tmp4) {








								var root_1392 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1392, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1394 lang.IFn; if linked_1393 == nil { ifn_1394 = lang.IFn_Cast(root_1392) } else { ifn_1394 = nil }; var arg_1395 any; var root_1397 any = A_arbace_c2j_node_A_const_218.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1397, A_arbace_c2j_node_qe_elems_A_fn_class); var ifn_1399 lang.IFn; if linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any = env__0; var arg_1401 any = v__1; var arg_1402 any = t__2; if linked_1398 == nil { arg_1395 = ifn_1399.Invoke_O_O_O__O(arg_1400, arg_1401, arg_1402) } else { arg_1395 = linked_1398.(*A_arbace_c2j_node_qe_elems_A).Invoke_O_O_O_O__O(root_1397, arg_1400, arg_1401, arg_1402) }; var arg_1396 any = lang.RT_Meta_O__IPersistentMap_NoInit(t__2); if linked_1393 == nil { return ifn_1394.Invoke_O_O__O(arg_1395, arg_1396) } else { return linked_1393.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1392, arg_1395, arg_1396) } } else {
//line :384:1
									if A_arbace_c2j_node_A_const_45 != nil { return t__2 } else { return nil
									}
								}
						}
				}
}






func A_arbace_c2j_node_splits_A_New() *A_arbace_c2j_node_splits_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_splits_A{}; t.Ctor(); return t }
//line :396:1
func (t *A_arbace_c2j_node_splits_A) Ctor() {}
//line :396:1
func (t *A_arbace_c2j_node_splits_A) Invoke_O_O__O(self, d__0 any) any { var tested__2 any; var root_1403 any = A_arbace_c2j_node_A_const_252.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1403, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1405 lang.IFn; if


	linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1404 == nil { tested__2 = ifn_1405.Invoke_O__O(arg_1406) } else { tested__2 = linked_1404.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1403, arg_1406) }; var body_w__3 /*line :396:1*/*A_arbace_c2j_node_splits_w__400000269_A = A_arbace_c2j_node_splits_w__400000269_A_New_O(tested__2); var w__3 any; var fnbody__1468 any = any(body_w__3); var tmp1 *jrt.Class; var fncls__1467 *jrt.Class = A_arbace_c2j_node_splits_w__400000269_A_fn_class; if fncls__1467 == nil { var fncls__1467d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__1468); A_arbace_c2j_node_splits_w__400000269_A_fn_class = fncls__1467d; tmp1 = fncls__1467d } else { tmp1 = fncls__1467 }; w__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1468, tmp1, nil);






	lang.IFn_Cast(w__3).Invoke_O__O(A_arbace_c2j_node_A_const_26.Invoke_O__O(d__0)); var root_1407 any =
	A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1407, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1409 lang.IFn; if linked_1408 == nil { ifn_1409 = lang.IFn_Cast(root_1407) } else { ifn_1409 = nil }; var arg_1410 any; var root_1411 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1413 lang.IFn; if linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any; var fnbody__1426 any = A_arbace_c2j_node_splits_fn__400000271_A_New_O(tested__2); var tmp2 *jrt.Class; var fncls__1425 *jrt.Class = A_arbace_c2j_node_splits_fn__400000271_A_fn_class; if fncls__1425 == nil { var fncls__1425d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__1426); A_arbace_c2j_node_splits_fn__400000271_A_fn_class = fncls__1425d; tmp2 = fncls__1425d } else { tmp2 = fncls__1425 }; arg_1414 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1426, tmp2, nil); var arg_1415 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_1412 == nil { arg_1410 = ifn_1413.Invoke_O_O__O(arg_1414, arg_1415) } else { arg_1410 = linked_1412.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1411, arg_1414, arg_1415) }; if linked_1408 == nil { return ifn_1409.Invoke_O__O(arg_1410) } else { return linked_1408.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1407, arg_1410) } }
//line :400:1
func A_arbace_c2j_node_splits_w__400000269_A_New_O(p0 any) *A_arbace_c2j_node_splits_w__400000269_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_splits_w__400000269_A{}; t.Ctor_O(p0); return t }
//line :400:1
func (t *A_arbace_c2j_node_splits_w__400000269_A) Ctor_O(c__tested any) { t.F_tested = c__tested }
//line :400:1
func (t *A_arbace_c2j_node_splits_w__400000269_A) Invoke_O_O__O(self, t__1 any) any { var tmp1 any; var root_1427 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = t__1; if linked_1428 == nil { tmp1 = ifn_1429.Invoke_O__O(arg_1430) } else { tmp1 = linked_1428.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1427, arg_1430) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var and__1927000168__auto____2 bool; var tmp3 any = A_arbace_c2j_node_A_const_300; var tmp4 any; var root_1445 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, A_arbace_c2j_node_head_A_fn_class); var ifn_1447 lang.IFn; if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = t__1; if linked_1446 == nil { tmp4 = ifn_1447.Invoke_O__O(arg_1448) } else { tmp4 = linked_1446.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_1445, arg_1448) }; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4); if and__1927000168__auto____2 { var root_1449 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1451 lang.IFn; if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any; var root_1453 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_1454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1453, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1455 lang.IFn; if linked_1454 == nil { ifn_1455 = lang.IFn_Cast(root_1453) } else { ifn_1455 = nil }; var arg_1456 any = t__1; if linked_1454 == nil { arg_1452 = ifn_1455.Invoke_O__O(arg_1456) } else { arg_1452 = linked_1454.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1453, arg_1456) }; if linked_1450 == nil { tmp2 = ifn_1451.Invoke_O__O(arg_1452) } else { tmp2 = linked_1450.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1449, arg_1452) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp2) { var root_1457 any = A_arbace_c2j_node_A_const_9.GetRawRoot__O(); var linked_1458 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1457, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1459 lang.IFn; if linked_1458 == nil { ifn_1459 = lang.IFn_Cast(root_1457) } else { ifn_1459 = nil }; var arg_1460 any = t.F_tested; var arg_1461 any = A_arbace_c2j_node_A_const_7.GetRawRoot__O(); var arg_1462 any; var root_1463 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = t__1; if linked_1464 == nil { arg_1462 = ifn_1465.Invoke_O__O(arg_1466) } else { arg_1462 = linked_1464.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1463, arg_1466) }; if linked_1458 == nil { ifn_1459.Invoke_O_O_O__O(arg_1460, arg_1461, arg_1462) } else { linked_1458.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1457, arg_1460, arg_1461, arg_1462) } }
											var root_1431 any = A_arbace_c2j_node_A_const_299.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = self; var arg_1435 any = t__1; if linked_1432 == nil { return ifn_1433.Invoke_O_O__O(arg_1434, arg_1435) } else { return linked_1432.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_1431, arg_1434, arg_1435) } } else {
//line :400:1
		var tmp5 any; var root_1436 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1438 lang.IFn

		if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = t__1; if linked_1437 == nil { tmp5 = ifn_1438.Invoke_O__O(arg_1439) } else { tmp5 = linked_1437.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1436, arg_1439) }
//line :400:1
		if jrt.J2g_Truth(tmp5) {

			var root_1440 any = A_arbace_c2j_node_A_const_299.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = self; var arg_1444 any = t__1; if linked_1441 == nil { return ifn_1442.Invoke_O_O__O(arg_1443, arg_1444) } else { return linked_1441.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_1440, arg_1443, arg_1444) } } else {
//line :400:1
				return nil } } }



func A_arbace_c2j_node_splits_fn__400000271_A_New_O(p0 any) *A_arbace_c2j_node_splits_fn__400000271_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_splits_fn__400000271_A{}; t.Ctor_O(p0); return t }
//line :404:1
func (t *A_arbace_c2j_node_splits_fn__400000271_A) Ctor_O(c__tested any) { t.F_tested = c__tested }
//line :404:1
func (t *A_arbace_c2j_node_splits_fn__400000271_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 any; var root_1416 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any; var root_1421 any = A_arbace_c2j_node_A_const_5.GetRawRoot__O(); var linked_1422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1421, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1423 lang.IFn; if linked_1422 == nil { ifn_1423 = lang.IFn_Cast(root_1421) } else { ifn_1423 = nil }; var arg_1424 any = t.F_tested; if linked_1422 == nil { arg_1419 = ifn_1423.Invoke_O__O(arg_1424) } else { arg_1419 = linked_1422.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1421, arg_1424) }; var arg_1420 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); if linked_1417 == nil { tmp1 = ifn_1418.Invoke_O_O__O(arg_1419, arg_1420) } else { tmp1 = linked_1417.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1416, arg_1419, arg_1420) }; if jrt.J2g_Truth(tmp1) { return A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1) } else { return nil } }

func A_arbace_c2j_node_uses_many_QMARK__A_New() *A_arbace_c2j_node_uses_many_QMARK__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_uses_many_QMARK__A{}; t.Ctor(); return t }
//line :406:1
func (t *A_arbace_c2j_node_uses_many_QMARK__A) Ctor() {}
//line :406:1
func (t *A_arbace_c2j_node_uses_many_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var r__2 any; var root_1469 any = A_arbace_c2j_node_A_const_252.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1471 lang.IFn; if
											linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = jrt.Boolean_FALSE.Ref(); if linked_1470 == nil { r__2 = ifn_1471.Invoke_O__O(arg_1472) } else { r__2 = linked_1470.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1469, arg_1472) }; var body_w__3 /*line :406:1*/*A_arbace_c2j_node_uses_many_QMARK__w__400000274_A = A_arbace_c2j_node_uses_many_QMARK__w__400000274_A_New_O(r__2); var w__3 any; var fnbody__1505 any = any(body_w__3); var tmp1 *jrt.Class; var fncls__1504 *jrt.Class = A_arbace_c2j_node_uses_many_QMARK__w__400000274_A_fn_class; if fncls__1504 == nil { var fncls__1504d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, fnbody__1505); A_arbace_c2j_node_uses_many_QMARK__w__400000274_A_fn_class = fncls__1504d; tmp1 = fncls__1504d } else { tmp1 = fncls__1504 }; w__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1505, tmp1, nil);



	lang.IFn_Cast(w__3).Invoke_O__O(A_arbace_c2j_node_A_const_26.Invoke_O__O(d__0)); var root_1473 any = /*line :407:1*/A_arbace_c2j_node_A_const_5.GetRawRoot__O(); var linked_1474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1473, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1475 lang.IFn; if linked_1474 == nil { ifn_1475 = lang.IFn_Cast(root_1473) } else { ifn_1475 = nil }; var arg_1476 any = r__2; if linked_1474 == nil { return ifn_1475.Invoke_O__O(arg_1476) } else { return linked_1474.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1473, arg_1476) } }
func A_arbace_c2j_node_uses_many_QMARK__w__400000274_A_New_O(p0 any) *A_arbace_c2j_node_uses_many_QMARK__w__400000274_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_uses_many_QMARK__w__400000274_A{}; t.Ctor_O(p0); return t }
//line :408:1
func (t *A_arbace_c2j_node_uses_many_QMARK__w__400000274_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :408:1
func (t *A_arbace_c2j_node_uses_many_QMARK__w__400000274_A) Invoke_O_O__O(self, t__1 any) any { var tmp1 any; var root_1477 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_1478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1477, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1479 lang.IFn; if linked_1478 == nil { ifn_1479 = lang.IFn_Cast(root_1477) } else { ifn_1479 = nil }; var arg_1480 any = t__1; if linked_1478 == nil { tmp1 = ifn_1479.Invoke_O__O(arg_1480) } else { tmp1 = linked_1478.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1477, arg_1480) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_c2j_node_A_const_301; var tmp3 any; var root_1495 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, A_arbace_c2j_node_head_A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = t__1; if linked_1496 == nil { tmp3 = ifn_1497.Invoke_O__O(arg_1498) } else { tmp3 = linked_1496.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_1495, arg_1498) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var root_1499 any = A_arbace_c2j_node_A_const_302.GetRawRoot__O(); var linked_1500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1499, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_1501 lang.IFn; if linked_1500 == nil { ifn_1501 = lang.IFn_Cast(root_1499) } else { ifn_1501 = nil }; var arg_1502 any = t.F_r; var arg_1503 any = jrt.Boolean_TRUE.Ref(); if linked_1500 == nil { ifn_1501.Invoke_O_O__O(arg_1502, arg_1503) } else { linked_1500.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_1499, arg_1502, arg_1503) } }; var root_1481 any = A_arbace_c2j_node_A_const_299.GetRawRoot__O(); var linked_1482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1481, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_1483 lang.IFn; if linked_1482 == nil { ifn_1483 = lang.IFn_Cast(root_1481) } else { ifn_1483 = nil }; var arg_1484 any = self; var arg_1485 any = t__1; if linked_1482 == nil { return ifn_1483.Invoke_O_O__O(arg_1484, arg_1485) } else { return linked_1482.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_1481, arg_1484, arg_1485) } } else { var tmp4 any; var root_1486 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1488 lang.IFn
												if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any = t__1; if linked_1487 == nil { tmp4 = ifn_1488.Invoke_O__O(arg_1489) } else { tmp4 = linked_1487.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1486, arg_1489) }
//line :408:1
	if jrt.J2g_Truth(tmp4) {
		var root_1490 any = A_arbace_c2j_node_A_const_299.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any = self; var arg_1494 any = t__1; if linked_1491 == nil { return ifn_1492.Invoke_O_O__O(arg_1493, arg_1494) } else { return linked_1491.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_1490, arg_1493, arg_1494) } } else {
//line :408:1
			return nil } } }




func A_arbace_c2j_node_camel_A_New() *A_arbace_c2j_node_camel_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_camel_A{}; t.Ctor(); return t }
//line :413:1
func (t *A_arbace_c2j_node_camel_A) Ctor() {}
//line :413:1
func (t *A_arbace_c2j_node_camel_A) Invoke_O_O__O(self, s__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_1506 any = A_arbace_c2j_node_A_const_303.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1506, aot_arbace_string.A_arbace_string_upper_case_A_fn_class); var ifn_1508 lang.IFn; if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any; var root_1510 any = A_arbace_c2j_node_A_const_304.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any; var root_1516 any = A_arbace_c2j_node_A_const_188.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1516, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1518 lang.IFn; if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any = s__0; if linked_1517 == nil { arg_1513 = ifn_1518.Invoke_O__O(arg_1519) } else { arg_1513 = linked_1517.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1516, arg_1519) }; var arg_1514 any = A_arbace_c2j_node_A_const_253; var arg_1515 any = A_arbace_c2j_node_A_const_305; if linked_1511 == nil { arg_1509 = ifn_1512.Invoke_O_O_O__O(arg_1513, arg_1514, arg_1515) } else { arg_1509 = linked_1511.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1510, arg_1513, arg_1514, arg_1515) }; if linked_1507 == nil { tmp2 = ifn_1508.Invoke_O__O(arg_1509) } else { tmp2 = linked_1507.(*aot_arbace_string.A_arbace_string_upper_case_A).Invoke_O_O__O(root_1506, arg_1509) }; var tmp3 any = tmp2; var tmp4 any; var root_1520 any = A_arbace_c2j_node_A_const_304.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1520, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any; var root_1525 any = A_arbace_c2j_node_A_const_188.GetRawRoot__O(); var linked_1526 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1525, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1527 lang.IFn; if linked_1526 == nil { ifn_1527 = lang.IFn_Cast(root_1525) } else { ifn_1527 = nil }; var arg_1528 any = s__0; if linked_1526 == nil { arg_1523 = ifn_1527.Invoke_O__O(arg_1528) } else { arg_1523 = linked_1526.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1525, arg_1528) }; var arg_1524 any = A_arbace_c2j_node_A_const_305; if linked_1521 == nil { tmp4 = ifn_1522.Invoke_O_O__O(arg_1523, arg_1524) } else { tmp4 = linked_1521.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1520, arg_1523, arg_1524) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref() }

func A_arbace_c2j_node_sym_occurs_QMARK__A_New() *A_arbace_c2j_node_sym_occurs_QMARK__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_sym_occurs_QMARK__A{}; t.Ctor(); return t }
//line :415:1
func (t *A_arbace_c2j_node_sym_occurs_QMARK__A) Ctor() {}
//line :415:1
func (t *A_arbace_c2j_node_sym_occurs_QMARK__A) Invoke_O_O_O__O(self, s__0, f__1 any) any {
	var tmp1 any; var root_1529 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_1530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1529, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1531 lang.IFn; if linked_1530 == nil { ifn_1531 = lang.IFn_Cast(root_1529) } else { ifn_1531 = nil }; var arg_1532 any = f__1; if linked_1530 == nil { tmp1 = ifn_1531.Invoke_O__O(arg_1532) } else { tmp1 = linked_1530.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1529, arg_1532) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(s__0, f__1)).Ref() } else { var tmp2 any; var or__1927000174__auto____3 any; var root_1533 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1535 lang.IFn
		if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any = f__1; if linked_1534 == nil { or__1927000174__auto____3 = ifn_1535.Invoke_O__O(arg_1536) } else { or__1927000174__auto____3 = linked_1534.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1533, arg_1536) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_1537 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = f__1; if linked_1538 == nil { tmp2 = ifn_1539.Invoke_O__O(arg_1540) } else { tmp2 = linked_1538.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1537, arg_1540) } }
//line :416:1
		if jrt.J2g_Truth(tmp2) {
			var root_1541 any = A_arbace_c2j_node_A_const_48.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1541, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1543 lang.IFn; if linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any; var fnbody__1552 any = A_arbace_c2j_node_sym_occurs_QMARK__fn__400000279_A_New_O(s__0); var tmp3 *jrt.Class; var fncls__1551 *jrt.Class = A_arbace_c2j_node_sym_occurs_QMARK__fn__400000279_A_fn_class; if fncls__1551 == nil { var fncls__1551d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__1552); A_arbace_c2j_node_sym_occurs_QMARK__fn__400000279_A_fn_class = fncls__1551d; tmp3 = fncls__1551d } else { tmp3 = fncls__1551 }; arg_1544 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1552, tmp3, nil); var arg_1545 any = f__1; if linked_1542 == nil { return ifn_1543.Invoke_O_O__O(arg_1544, arg_1545) } else { return linked_1542.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1541, arg_1544, arg_1545) } } else {
//line :416:1
				if A_arbace_c2j_node_A_const_45 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil } } } }
func A_arbace_c2j_node_sym_occurs_QMARK__fn__400000279_A_New_O(p0 any) *A_arbace_c2j_node_sym_occurs_QMARK__fn__400000279_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_sym_occurs_QMARK__fn__400000279_A{}; t.Ctor_O(p0); return t }
//line :417:1
func (t *A_arbace_c2j_node_sym_occurs_QMARK__fn__400000279_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :417:1
func (t *A_arbace_c2j_node_sym_occurs_QMARK__fn__400000279_A) Invoke_O_O__O(self, p1__400000278_SHARP___1 any) any { var root_1546 any = A_arbace_c2j_node_A_const_306.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = t.F_s; var arg_1550 any = p1__400000278_SHARP___1; if linked_1547 == nil { return ifn_1548.Invoke_O_O__O(arg_1549, arg_1550) } else { return linked_1547.(*A_arbace_c2j_node_sym_occurs_QMARK__A).Invoke_O_O_O__O(root_1546, arg_1549, arg_1550) } }


func A_arbace_c2j_node_tag_sym_A_New() *A_arbace_c2j_node_tag_sym_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_tag_sym_A{}; t.Ctor(); return t }
//line :420:1
func (t *A_arbace_c2j_node_tag_sym_A) Ctor() {}
//line :420:1
func (t *A_arbace_c2j_node_tag_sym_A) Invoke_O_O_O__O(self, s__0, t__1 any) any { var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z_NoInit(t__1, nil); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(t__1, A_arbace_c2j_node_A_const_307) }; if tmp1 { return s__0 } else { return lang.IFn_Cast(A_arbace_c2j_node_A_const_308.GetRawRoot__O()).Invoke_O_O_O_O__O(s__0, A_arbace_c2j_node_A_const_14.GetRawRoot__O(), A_arbace_c2j_node_A_const_309, t__1) } }

func A_arbace_c2j_node_variant_class_A_New() *A_arbace_c2j_node_variant_class_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_A{}; t.Ctor(); return t }
//line :422:1
func (t *A_arbace_c2j_node_variant_class_A) Ctor() {}
//line :422:1
func (t *A_arbace_c2j_node_variant_class_A) Invoke_O_O_O__O(self, d__0, v__1 any) any { var env__3 any; var root_1560 any = A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_1561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1560, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1562 lang.IFn; if



	linked_1561 == nil { ifn_1562 = lang.IFn_Cast(root_1560) } else { ifn_1562 = nil }; var arg_1563 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1564 any; var root_1565 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any; var fnbody__1580 any = A_arbace_c2j_node_variant_class_fn__400000283_A_New(); var tmp1 *jrt.Class; var fncls__1579 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000283_A_fn_class; if fncls__1579 == nil { var fncls__1579d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, nil); A_arbace_c2j_node_variant_class_fn__400000283_A_fn_class = fncls__1579d; tmp1 = fncls__1579d } else { tmp1 = fncls__1579 }; arg_1568 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1580, tmp1, nil); var arg_1569 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_1566 == nil { arg_1564 = ifn_1567.Invoke_O_O__O(arg_1568, arg_1569) } else { arg_1564 = linked_1566.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1565, arg_1568, arg_1569) }; if linked_1561 == nil { env__3 = ifn_1562.Invoke_O_O__O(arg_1563, arg_1564) } else { env__3 = linked_1561.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1560, arg_1563, arg_1564) }; var chans__4 any; if






	jrt.J2g_Truth(A_arbace_c2j_node_A_const_177.Invoke_O__O(v__1)) {
		if jrt.J2g_Truth(A_arbace_c2j_node_A_const_73.Invoke_O__O(v__1)) { chans__4 = A_arbace_c2j_node_A_const_316 } else { var root_1581 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1583 lang.IFn; if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any; var root_1585 any = A_arbace_c2j_node_A_const_317.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var tmp2 *lang.Keyword = A_arbace_c2j_node_A_const_248; var arg_1588 any = tmp2.Invoke_O__O(A_arbace_c2j_node_A_const_177.Invoke_O__O(v__1)); if linked_1586 == nil { arg_1584 = ifn_1587.Invoke_O__O(arg_1588) } else { arg_1584 = linked_1586.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1585, arg_1588) }; if linked_1582 == nil { chans__4 = ifn_1583.Invoke_O__O(arg_1584) } else { chans__4 = linked_1582.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1581, arg_1584) } } } else {
//line :433:1
			var tmp3 *lang.Keyword = A_arbace_c2j_node_A_const_318; var or__1927000174__auto____4 any = tmp3.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0))

			if jrt.J2g_Truth(or__1927000174__auto____4) { chans__4 = or__1927000174__auto____4 } else { chans__4 = A_arbace_c2j_node_A_const_319 } }; var domain__5 any = /*line :422:1*/A_arbace_c2j_node_A_const_320.Invoke_O__O(v__1); var method__6 any; var fnbody__1657 any = A_arbace_c2j_node_variant_class_method__400000286_A_New_O_O_O_O(d__0, env__3, v__1, domain__5); var tmp4 *jrt.Class; var fncls__1656 *jrt.Class = A_arbace_c2j_node_variant_class_method__400000286_A_fn_class; if














	fncls__1656 == nil { var fncls__1656d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__1657); A_arbace_c2j_node_variant_class_method__400000286_A_fn_class = fncls__1656d; tmp4 = fncls__1656d } else { tmp4 = fncls__1656 }; method__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1657, tmp4, nil); var methods__7 any; var root_1658 any = /*line :422:1*/A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1658, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1660 lang.IFn; if



























	linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any; var root_1662 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any = method__6; var arg_1666 any = chans__4; if linked_1663 == nil { arg_1661 = ifn_1664.Invoke_O_O__O(arg_1665, arg_1666) } else { arg_1661 = linked_1663.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1662, arg_1665, arg_1666) }; if linked_1659 == nil { methods__7 = ifn_1660.Invoke_O__O(arg_1661) } else { methods__7 = linked_1659.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1658, arg_1661) }; var cb__8 any; var root_1667 any = /*line :422:1*/A_arbace_c2j_node_A_const_334.GetRawRoot__O(); var linked_1668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1667, A_arbace_c2j_node_children_bind_A_fn_class); var ifn_1669 lang.IFn; if




























	linked_1668 == nil { ifn_1669 = lang.IFn_Cast(root_1667) } else { ifn_1669 = nil }; var arg_1670 any = d__0; if linked_1668 == nil { cb__8 = ifn_1669.Invoke_O__O(arg_1670) } else { cb__8 = linked_1668.(*A_arbace_c2j_node_children_bind_A).Invoke_O_O__O(root_1667, arg_1670) }; var conv__9 any; if
	jrt.J2g_Truth(cb__8) { var tmp5 *lang.Keyword = A_arbace_c2j_node_A_const_335; var tmp6 any; var root_1671 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = A_arbace_c2j_node_A_const_242.GetRawRoot__O(); var arg_1675 any; var root_1676 any = A_arbace_c2j_node_A_const_336.GetRawRoot__O(); var linked_1677 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1676, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1678 lang.IFn; if linked_1677 == nil { ifn_1678 = lang.IFn_Cast(root_1676) } else { ifn_1678 = nil }; var arg_1680 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(cb__8); if linked_1677 == nil { arg_1675 = ifn_1678.Invoke_O_O__O(A_arbace_c2j_node_A_const_25, arg_1680) } else { arg_1675 = linked_1677.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1676, 2, A_arbace_c2j_node_A_const_25, arg_1680) }; if linked_1672 == nil { tmp6 = ifn_1673.Invoke_O_O__O(arg_1674, arg_1675) } else { tmp6 = linked_1672.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1671, arg_1674, arg_1675) }; conv__9 = tmp5.Invoke_O__O(tmp6) } else { conv__9 = nil }; var fields__10 any; var root_1681 any = /*line :422:1*/A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1681, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1683 lang.IFn; if































	linked_1682 == nil { ifn_1683 = lang.IFn_Cast(root_1681) } else { ifn_1683 = nil }; var arg_1684 any; var root_1685 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_1686 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1685, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1687 lang.IFn; if linked_1686 == nil { ifn_1687 = lang.IFn_Cast(root_1685) } else { ifn_1687 = nil }; var arg_1688 any; if
	jrt.J2g_Truth(domain__5) { var tmp7 any = A_arbace_c2j_node_A_const_337; var tmp8 any; var root_1690 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1690, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1692 lang.IFn; if linked_1691 == nil { ifn_1692 = lang.IFn_Cast(root_1690) } else { ifn_1692 = nil }; var arg_1693 any = A_arbace_c2j_node_A_const_338; var arg_1694 any = A_arbace_c2j_node_A_const_339; if linked_1691 == nil { tmp8 = ifn_1692.Invoke_O_O__O(arg_1693, arg_1694) } else { tmp8 = linked_1691.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1690, arg_1693, arg_1694) }; arg_1688 = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, A_arbace_c2j_node_A_const_340, A_arbace_c2j_node_A_const_341))) } else { arg_1688 = nil }; var arg_1689 any; var tmp9 lang.IFn = /*line :454:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp10 *lang.Compiler_AOTFn; var fnbody__1789 any = A_arbace_c2j_node_variant_class_fn__400000299_A_New_O_O_O(conv__9, methods__7, v__1); var tmp11 *jrt.Class; var fncls__1788 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000299_A_fn_class; if

	fncls__1788 == nil { var fncls__1788d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__1789); A_arbace_c2j_node_variant_class_fn__400000299_A_fn_class = fncls__1788d; tmp11 = fncls__1788d } else { tmp11 = fncls__1788 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1789, tmp11, nil); arg_1689 = tmp9.Invoke_O_O__O(tmp10.Ref(), A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0)); if /*line :454:1*/ linked_1686 == nil { arg_1684 = ifn_1687.Invoke_O_O__O(arg_1688, arg_1689) } else { arg_1684 = linked_1686.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1685, arg_1688, arg_1689) }; if linked_1682 == nil { fields__10 = ifn_1683.Invoke_O__O(arg_1684) } else { fields__10 = linked_1682.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1681, arg_1684) }; var bare__11 any; var fnbody__1796 any = /*line :422:1*/A_arbace_c2j_node_variant_class_bare__400000306_A_New(); var tmp12 *jrt.Class; var fncls__1795 *jrt.Class = A_arbace_c2j_node_variant_class_bare__400000306_A_fn_class; if


















































	fncls__1795 == nil { var fncls__1795d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); A_arbace_c2j_node_variant_class_bare__400000306_A_fn_class = fncls__1795d; tmp12 = fncls__1795d } else { tmp12 = fncls__1795 }; bare__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1796, tmp12, nil); var tmp13 lang.IFn = /*line :422:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_node_A_const_362; var tmp16 any; var root_1804 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1804, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1806 lang.IFn; if




















































	linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any; var root_1809 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = A_arbace_c2j_node_A_const_328.Invoke_O__O(v__1); if linked_1810 == nil { arg_1807 = ifn_1811.Invoke_O__O(arg_1812) } else { arg_1807 = linked_1810.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1809, arg_1812) }; var arg_1808 any = A_arbace_c2j_node_A_const_363; if linked_1805 == nil { tmp16 = ifn_1806.Invoke_O_O__O(arg_1807, arg_1808) } else { tmp16 = linked_1805.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1804, arg_1807, arg_1808) }; var tmp17 any = /*line :422:1*/tmp14.Invoke_O_O_O_O__O(tmp15, tmp16, A_arbace_c2j_node_A_const_364, A_arbace_c2j_node_A_const_365); var tmp18 any; var root_1813 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1815 lang.IFn; if






















































	linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any; var fnbody__1844 any = A_arbace_c2j_node_variant_class_fn__400000309_A_New(); var tmp19 *jrt.Class; var fncls__1843 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000309_A_fn_class; if fncls__1843 == nil { var fncls__1843d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, nil); A_arbace_c2j_node_variant_class_fn__400000309_A_fn_class = fncls__1843d; tmp19 = fncls__1843d } else { tmp19 = fncls__1843 }; arg_1816 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1844, tmp19, nil); var arg_1817 any = fields__10; if linked_1814 == nil { tmp18 = ifn_1815.Invoke_O_O__O(arg_1816, arg_1817) } else { tmp18 = linked_1814.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1813, arg_1816, arg_1817) }; var tmp20 any = tmp18; var tmp21 any; var root_1845 any = /*line :422:1*/A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_1846 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1845, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1847 lang.IFn; if























































	linked_1846 == nil { ifn_1847 = lang.IFn_Cast(root_1845) } else { ifn_1847 = nil }; var arg_1848 any = A_arbace_c2j_node_A_const_369; var arg_1849 any; var root_1851 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1853 lang.IFn; if linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any; var root_1856 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any; var root_1860 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = A_arbace_c2j_node_A_const_370; var arg_1864 any; var root_1865 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1866 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1865, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1867 lang.IFn; if linked_1866 == nil { ifn_1867 = lang.IFn_Cast(root_1865) } else { ifn_1867 = nil }; var arg_1868 any = A_arbace_c2j_node_A_const_337; var arg_1869 any = fields__10; if linked_1866 == nil { arg_1864 = ifn_1867.Invoke_O_O__O(arg_1868, arg_1869) } else { arg_1864 = linked_1866.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1865, arg_1868, arg_1869) }; if linked_1861 == nil { arg_1859 = ifn_1862.Invoke_O_O__O(arg_1863, arg_1864) } else { arg_1859 = linked_1861.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1860, arg_1863, arg_1864) }; if linked_1857 == nil { arg_1854 = ifn_1858.Invoke_O__O(arg_1859) } else { arg_1854 = linked_1857.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1856, arg_1859) }; var arg_1855 any = A_arbace_c2j_node_A_const_371; if linked_1852 == nil { arg_1849 = ifn_1853.Invoke_O_O__O(arg_1854, arg_1855) } else { arg_1849 = linked_1852.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1851, arg_1854, arg_1855) }; var arg_1850 any; var root_1870 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1870, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1872 lang.IFn; if
	linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any; var fnbody__1896 any = A_arbace_c2j_node_variant_class_fn__400000314_A_New_O(bare__11); var tmp22 *jrt.Class; var fncls__1895 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000314_A_fn_class; if fncls__1895 == nil { var fncls__1895d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__1896); A_arbace_c2j_node_variant_class_fn__400000314_A_fn_class = fncls__1895d; tmp22 = fncls__1895d } else { tmp22 = fncls__1895 }; arg_1873 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1896, tmp22, nil); var arg_1874 any = fields__10; if linked_1871 == nil { arg_1850 = ifn_1872.Invoke_O_O__O(arg_1873, arg_1874) } else { arg_1850 = linked_1871.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1870, arg_1873, arg_1874) }; if /*line :478:1*/ linked_1846 == nil { tmp21 = ifn_1847.Invoke_O_O_O__O(arg_1848, arg_1849, arg_1850) } else { tmp21 = linked_1846.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1845, arg_1848, arg_1849, arg_1850) }; return /*line :422:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp13.Invoke_O_O_O_O__O(tmp17, tmp20, lang.Tuple_Create_O__IPersistentVector(tmp21), methods__7), fields__10) }



func A_arbace_c2j_node_variant_class_fn__400000283_A_New() *A_arbace_c2j_node_variant_class_fn__400000283_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000283_A{}; t.Ctor(); return t }
//line :426:1
func (t *A_arbace_c2j_node_variant_class_fn__400000283_A) Ctor() {}
//line :426:1
func (t *A_arbace_c2j_node_variant_class_fn__400000283_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp2 any; var G__400000284__2_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__1); L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__400000284__2_) >> 8 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__400000284__2_, A_arbace_c2j_node_A_const_310) { tmp2 = A_arbace_c2j_node_A_const_311; break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__400000284__2_, A_arbace_c2j_node_A_const_312) { var tmp3 any = A_arbace_c2j_node_A_const_20; var tmp4 any = A_arbace_c2j_node_A_const_156; var tmp5 any = A_arbace_c2j_node_A_const_171; var tmp6 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp7 any = A_arbace_c2j_node_A_const_162; var tmp8 any; var root_1571 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1573 lang.IFn


	if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1572 == nil { tmp8 = ifn_1573.Invoke_O__O(arg_1574) } else { tmp8 = linked_1572.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1571, arg_1574) }
//line :426:1
	tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8)); break L1 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000284__2_, A_arbace_c2j_node_A_const_313) { var tmp9 any = A_arbace_c2j_node_A_const_20; var tmp10 any = A_arbace_c2j_node_A_const_181; var tmp11 any = A_arbace_c2j_node_A_const_171; tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1))); break L1 }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__400000284__2_, A_arbace_c2j_node_A_const_314) { var tmp12 any = A_arbace_c2j_node_A_const_20; var tmp13 any = A_arbace_c2j_node_A_const_126; var tmp14 any = A_arbace_c2j_node_A_const_171; tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1))); break L1 }; case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__400000284__2_, A_arbace_c2j_node_A_const_315) { var tmp15 any = A_arbace_c2j_node_A_const_20; var tmp16 any = A_arbace_c2j_node_A_const_156; var tmp17 any = A_arbace_c2j_node_A_const_171; var tmp18 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp19 any = A_arbace_c2j_node_A_const_162; var tmp20 any; var root_1575 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1575, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1577 lang.IFn


		if linked_1576 == nil { ifn_1577 = lang.IFn_Cast(root_1575) } else { ifn_1577 = nil }; var arg_1578 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1576 == nil { tmp20 = ifn_1577.Invoke_O__O(arg_1578) } else { tmp20 = linked_1576.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1575, arg_1578) }
//line :426:1
		tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20)); break L1 }; default:}; tmp2 = nil}; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }










func A_arbace_c2j_node_variant_class_method__400000286_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variant_class_method__400000286_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_method__400000286_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :437:1
func (t *A_arbace_c2j_node_variant_class_method__400000286_A) Ctor_O_O_O_O(c__d, c__env, c__v, c__domain any) { t.F_d = c__d; t.F_env = c__env; t.F_v = c__v; t.F_domain = c__domain }
//line :437:1
func (t *A_arbace_c2j_node_variant_class_method__400000286_A) Invoke_O_O__O(self, c__1 any) any { var vec__400000287__2 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_256.GetRawRoot__O()).Invoke_O__O(c__1); var mn__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000287__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rt__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000287__2, lang.RT_IntCast_J__I_NoInit(1), nil); var params__5 any; var tmp1 any = A_arbace_c2j_node_A_const_329; var tmp2 any; var root_1635 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1635, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1637 lang.IFn; if

	linked_1636 == nil { ifn_1637 = lang.IFn_Cast(root_1635) } else { ifn_1637 = nil }; var arg_1638 any = A_arbace_c2j_node_A_const_330; var arg_1639 any = A_arbace_c2j_node_A_const_331; if linked_1636 == nil { tmp2 = ifn_1637.Invoke_O_O__O(arg_1638, arg_1639) } else { tmp2 = linked_1636.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1635, arg_1638, arg_1639) }; params__5 = /*line :437:1*/lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2); var try_qe__6 any; var fnbody__1604 any = A_arbace_c2j_node_variant_class_method__400000286_try_qe__400000290_A_New_O_O(t.F_d, t.F_env); var tmp3 *jrt.Class; var fncls__1603 *jrt.Class = A_arbace_c2j_node_variant_class_method__400000286_try_qe__400000290_A_fn_class; if


	fncls__1603 == nil { var fncls__1603d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, fnbody__1604); A_arbace_c2j_node_variant_class_method__400000286_try_qe__400000290_A_fn_class = fncls__1603d; tmp3 = fncls__1603d } else { tmp3 = fncls__1603 }; try_qe__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1604, tmp3, nil); var body__7 any; if

	jrt.J2g_Truth(t.F_domain) { var cases__7 any; var root_1605 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1607 lang.IFn
		if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any; var fnbody__1619 any = A_arbace_c2j_node_variant_class_method__400000286_fn__400000293_A_New_O_O_O(c__1, try_qe__6, t.F_v); var tmp4 *jrt.Class; var fncls__1618 *jrt.Class = A_arbace_c2j_node_variant_class_method__400000286_fn__400000293_A_fn_class; if fncls__1618 == nil { var fncls__1618d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, fnbody__1619); A_arbace_c2j_node_variant_class_method__400000286_fn__400000293_A_fn_class = fncls__1618d; tmp4 = fncls__1618d } else { tmp4 = fncls__1618 }; arg_1608 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1619, tmp4, nil); var arg_1609 any = t.F_domain; if linked_1606 == nil { cases__7 = ifn_1607.Invoke_O_O__O(arg_1608, arg_1609) } else { cases__7 = linked_1606.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1605, arg_1608, arg_1609) }
		var tmp5 any; var root_1620 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any = cases__7; if linked_1621 == nil { tmp5 = ifn_1622.Invoke_O__O(arg_1623) } else { tmp5 = linked_1621.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1620, arg_1623) }; if jrt.J2g_Truth(tmp5) {
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp7 any = A_arbace_c2j_node_A_const_326; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_node_A_const_327; body__7 = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_323, A_arbace_c2j_node_A_const_324), lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_325.GetRawRoot__O(), cases__7), lang.Tuple_Create_O__IPersistentVector(tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp9, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_328.Invoke_O__O(t.F_v), nil)).Ref())))) } else {
//line :444:1
				body__7 = nil } } else {


					var tmp10 lang.IFn = lang.IFn_Cast(try_qe__6); var tmp11 any; var root_1640 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1641 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1640, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1642 lang.IFn; if linked_1641 == nil { ifn_1642 = lang.IFn_Cast(root_1640) } else { ifn_1642 = nil }; var arg_1643 any = t.F_v; var arg_1644 any = A_arbace_c2j_node_A_const_168; var arg_1645 any = c__1; if linked_1641 == nil { tmp11 = ifn_1642.Invoke_O_O_O__O(arg_1643, arg_1644, arg_1645) } else { tmp11 = linked_1641.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1640, arg_1643, arg_1644, arg_1645) }; body__7 = tmp10.Invoke_O__O(tmp11) }; if
	jrt.J2g_Truth(body__7) {
		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_node_A_const_332; var tmp14 any; var root_1646 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = mn__3; var arg_1650 any = A_arbace_c2j_node_A_const_333; if linked_1647 == nil { tmp14 = ifn_1648.Invoke_O_O__O(arg_1649, arg_1650) } else { tmp14 = linked_1647.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1646, arg_1649, arg_1650) }; var tmp15 any = tmp14; var tmp16 any; if jrt.J2g_Truth(rt__4) { var root_1651 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1651, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1653 lang.IFn; if linked_1652 == nil { ifn_1653 = lang.IFn_Cast(root_1651) } else { ifn_1653 = nil }; var arg_1654 any = params__5; var arg_1655 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_309, rt__4)); if linked_1652 == nil { tmp16 = ifn_1653.Invoke_O_O__O(arg_1654, arg_1655) } else { tmp16 = linked_1652.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1651, arg_1654, arg_1655) } } else { tmp16 = params__5 }; return tmp12.Invoke_O_O_O_O__O(tmp13, tmp15, tmp16, body__7) } else {
//line :448:1
			return nil } }
//line :440:1
func A_arbace_c2j_node_variant_class_method__400000286_try_qe__400000290_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_variant_class_method__400000286_try_qe__400000290_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_method__400000286_try_qe__400000290_A{}; t.Ctor_O_O(p0, p1); return t }
//line :440:1
func (t *A_arbace_c2j_node_variant_class_method__400000286_try_qe__400000290_A) Ctor_O_O(c__d, c__env any) { t.F_d = c__d; t.F_env = c__env }
//line :440:1
func (t *A_arbace_c2j_node_variant_class_method__400000286_try_qe__400000290_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1589 any = A_arbace_c2j_node_A_const_207.GetRawRoot__O(); var linked_1590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1589, A_arbace_c2j_node_realize_A_fn_class); var ifn_1591 lang.IFn; if linked_1590 == nil { ifn_1591 = lang.IFn_Cast(root_1589) } else { ifn_1591 = nil }; var arg_1592 any; var root_1593 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1593, A_arbace_c2j_node_qe_A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any = t.F_env; var arg_1597 any = v__1; var arg_1598 any = A_arbace_c2j_node_A_const_26.Invoke_O__O(t.F_d); if linked_1594 == nil { arg_1592 = ifn_1595.Invoke_O_O_O__O(arg_1596, arg_1597, arg_1598) } else { arg_1592 = linked_1594.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1593, arg_1596, arg_1597, arg_1598) }; if linked_1590 == nil { tmp1 = ifn_1591.Invoke_O__O(arg_1592) } else { tmp1 = linked_1590.(*A_arbace_c2j_node_realize_A).Invoke_O_O__O(root_1589, arg_1592) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var x__4 jrt.Exception_I = jrt.Exception_Cast(tmp2); var tmp3 *lang.Keyword = A_arbace_c2j_node_A_const_321; var tmp4 any; var root_1599 any = A_arbace_c2j_node_A_const_322.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1601 lang.IFn
															if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = x__4; if linked_1600 == nil { tmp4 = ifn_1601.Invoke_O__O(arg_1602) } else { tmp4 = linked_1600.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1599, arg_1602) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(tmp4)) { tmp1 = nil } else { panic(jrt.Thrown(x__4)) } } else {
//line :440:1
		panic(tmp2) } }; return tmp1 }


func A_arbace_c2j_node_variant_class_method__400000286_fn__400000293_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_variant_class_method__400000286_fn__400000293_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_method__400000286_fn__400000293_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :443:1
func (t *A_arbace_c2j_node_variant_class_method__400000286_fn__400000293_A) Ctor_O_O_O(c__c, c__try_qe, c__v any) { t.F_c = c__c; t.F_try_qe = c__try_qe; t.F_v = c__v }
//line :443:1
func (t *A_arbace_c2j_node_variant_class_method__400000286_fn__400000293_A) Invoke_O_O__O(self, p__400000292__1 any) any { var vec__400000294__2 any = p__400000292__1; var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000294__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000294__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_try_qe); var temp__1927000414__auto____5 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_node_A_const_14.GetRawRoot__O()).Invoke_O_O_O_O_O__O(t.F_v, A_arbace_c2j_node_A_const_168, t.F_c, A_arbace_c2j_node_A_const_259, m__4)); if jrt.J2g_Truth(temp__1927000414__auto____5) { var b__6 any = temp__1927000414__auto____5; return lang.Tuple_Create_O_O__IPersistentVector(i__3, b__6) } else { return nil } }












func A_arbace_c2j_node_variant_class_fn__400000299_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_variant_class_fn__400000299_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000299_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :456:1
func (t *A_arbace_c2j_node_variant_class_fn__400000299_A) Ctor_O_O_O(c__conv, c__methods, c__v any) { t.F_conv = c__conv; t.F_methods = c__methods; t.F_v = c__v }
//line :456:1
func (t *A_arbace_c2j_node_variant_class_fn__400000299_A) Invoke_O_O__O(self, b__1 any) any { var G__400000300__2_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__1); switch
												lang.Util_Hash_O__I_NoInit(G__400000300__2_) >> 8 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__400000300__2_, A_arbace_c2j_node_A_const_342) {









		var root_1701 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1702 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1701, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1703 lang.IFn; if linked_1702 == nil { ifn_1703 = lang.IFn_Cast(root_1701) } else { ifn_1703 = nil }; var arg_1704 any; var fnbody__1707 any = A_arbace_c2j_node_variant_class_fn__400000299_fn__400000301_A_New(); var tmp1 *jrt.Class; var fncls__1706 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000299_fn__400000301_A_fn_class; if fncls__1706 == nil { var fncls__1706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, nil); A_arbace_c2j_node_variant_class_fn__400000299_fn__400000301_A_fn_class = fncls__1706d; tmp1 = fncls__1706d } else { tmp1 = fncls__1706 }; arg_1704 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1707, tmp1, nil); var tmp2 *lang.Keyword = A_arbace_c2j_node_A_const_31; var arg_1705 any = tmp2.Invoke_O__O(A_arbace_c2j_node_A_const_177.Invoke_O__O(t.F_v)); if linked_1702 == nil { return ifn_1703.Invoke_O_O__O(arg_1704, arg_1705) } else { return linked_1702.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1701, arg_1704, arg_1705) } }
//line :457:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__400000300__2_, A_arbace_c2j_node_A_const_343) {










		var tmp3 any; var and__1927000168__auto____3 any; var root_1708 any = A_arbace_c2j_node_A_const_274.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any; var root_1712 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = A_arbace_c2j_node_A_const_234.Invoke_O__O(t.F_v); var arg_1716 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); if linked_1713 == nil { arg_1711 = ifn_1714.Invoke_O_O__O(arg_1715, arg_1716) } else { arg_1711 = linked_1713.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1712, arg_1715, arg_1716) }; if linked_1709 == nil { and__1927000168__auto____3 = ifn_1710.Invoke_O__O(arg_1711) } else { and__1927000168__auto____3 = linked_1709.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1708, arg_1711) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
			var root_1717 any = A_arbace_c2j_node_A_const_306.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class); var ifn_1719 lang.IFn; if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1721 any = t.F_methods; if linked_1718 == nil { tmp3 = ifn_1719.Invoke_O_O__O(arg_1720, arg_1721) } else { tmp3 = linked_1718.(*A_arbace_c2j_node_sym_occurs_QMARK__A).Invoke_O_O_O__O(root_1717, arg_1720, arg_1721) } } else {
//line :468:1
				tmp3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp3) { var tmp4 any = A_arbace_c2j_node_A_const_337; var tmp5 any; var root_1746 any = A_arbace_c2j_node_A_const_346.GetRawRoot__O(); var linked_1747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1746, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1748 lang.IFn

					if linked_1747 == nil { ifn_1748 = lang.IFn_Cast(root_1746) } else { ifn_1748 = nil }; var arg_1749 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1750 any; var root_1751 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1752 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1751, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1753 lang.IFn; if linked_1752 == nil { ifn_1753 = lang.IFn_Cast(root_1751) } else { ifn_1753 = nil }; var arg_1754 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1752 == nil { arg_1750 = ifn_1753.Invoke_O__O(arg_1754) } else { arg_1750 = linked_1752.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1751, arg_1754) }; if linked_1747 == nil { tmp5 = ifn_1748.Invoke_O_O__O(arg_1749, arg_1750) } else { tmp5 = linked_1747.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1746, arg_1749, arg_1750) }
//line :468:1
					var tmp6 any = tmp5; var tmp7 any = A_arbace_c2j_node_A_const_340; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1)))) } else { return nil } }
//line :457:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000300__2_, A_arbace_c2j_node_A_const_344) { var tmp8 any = A_arbace_c2j_node_A_const_337; var tmp9 any; var root_1755 any = A_arbace_c2j_node_A_const_346.GetRawRoot__O(); var linked_1756 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1755, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1757 lang.IFn
		if linked_1756 == nil { ifn_1757 = lang.IFn_Cast(root_1755) } else { ifn_1757 = nil }; var arg_1758 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1759 any = A_arbace_c2j_node_A_const_357; if linked_1756 == nil { tmp9 = ifn_1757.Invoke_O_O__O(arg_1758, arg_1759) } else { tmp9 = linked_1756.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1755, arg_1758, arg_1759) }
//line :457:1
		var tmp10 any = tmp9; var tmp11 any = A_arbace_c2j_node_A_const_340; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp10, tmp11, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1)))) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__400000300__2_, A_arbace_c2j_node_A_const_345) { var fld__3 any; var root_1722 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1722, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1724 lang.IFn

			if linked_1723 == nil { ifn_1724 = lang.IFn_Cast(root_1722) } else { ifn_1724 = nil }; var arg_1725 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1723 == nil { fld__3 = ifn_1724.Invoke_O__O(arg_1725) } else { fld__3 = linked_1723.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1722, arg_1725) }
			var tmp12 any = A_arbace_c2j_node_A_const_220; if lang.Util_Equiv_O_O__Z_NoInit(tmp12, A_arbace_c2j_node_A_const_221.Invoke_O__O(t.F_v)) { var tmp13 any = A_arbace_c2j_node_A_const_337; var tmp14 any; var root_1774 any = A_arbace_c2j_node_A_const_346.GetRawRoot__O(); var linked_1775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1774, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1776 lang.IFn
				if linked_1775 == nil { ifn_1776 = lang.IFn_Cast(root_1774) } else { ifn_1776 = nil }; var arg_1777 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1778 any = A_arbace_c2j_node_A_const_359; if linked_1775 == nil { tmp14 = ifn_1776.Invoke_O_O__O(arg_1777, arg_1778) } else { tmp14 = linked_1775.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1774, arg_1777, arg_1778) }
//line :460:1
				var tmp15 any = tmp14; var tmp16 any = A_arbace_c2j_node_A_const_340; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, tmp16, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_360, A_arbace_c2j_node_A_const_361, fld__3)))) } else {

					var root_1726 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1726, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1728 lang.IFn; if linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any; var fnbody__1741 any = A_arbace_c2j_node_variant_class_fn__400000299_fn__400000303_A_New_O_O_O(b__1, t.F_conv, fld__3); var tmp17 *jrt.Class; var fncls__1740 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000299_fn__400000303_A_fn_class; if fncls__1740 == nil { var fncls__1740d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, fnbody__1741); A_arbace_c2j_node_variant_class_fn__400000299_fn__400000303_A_fn_class = fncls__1740d; tmp17 = fncls__1740d } else { tmp17 = fncls__1740 }; arg_1729 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1741, tmp17, nil); var arg_1730 any; var root_1742 any = A_arbace_c2j_node_A_const_226.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1744 lang.IFn



					if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = A_arbace_c2j_node_A_const_221.Invoke_O__O(t.F_v); if linked_1743 == nil { arg_1730 = ifn_1744.Invoke_O__O(arg_1745) } else { arg_1730 = linked_1743.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1742, arg_1745) }
//line :462:1
					if linked_1727 == nil { return ifn_1728.Invoke_O_O__O(arg_1729, arg_1730) } else { return linked_1727.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1726, arg_1729, arg_1730) } } }
//line :457:1
	case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__400000300__2_, A_arbace_c2j_node_A_const_358) {










		var tmp18 any; var and__1927000168__auto____3_2 any; var root_1760 any = A_arbace_c2j_node_A_const_274.GetRawRoot__O(); var linked_1761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1760, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1762 lang.IFn; if linked_1761 == nil { ifn_1762 = lang.IFn_Cast(root_1760) } else { ifn_1762 = nil }; var arg_1763 any; var root_1764 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1764, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1766 lang.IFn; if linked_1765 == nil { ifn_1766 = lang.IFn_Cast(root_1764) } else { ifn_1766 = nil }; var arg_1767 any = A_arbace_c2j_node_A_const_234.Invoke_O__O(t.F_v); var arg_1768 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); if linked_1765 == nil { arg_1763 = ifn_1766.Invoke_O_O__O(arg_1767, arg_1768) } else { arg_1763 = linked_1765.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1764, arg_1767, arg_1768) }; if linked_1761 == nil { and__1927000168__auto____3_2 = ifn_1762.Invoke_O__O(arg_1763) } else { and__1927000168__auto____3_2 = linked_1761.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1760, arg_1763) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) {
			var root_1769 any = A_arbace_c2j_node_A_const_306.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class); var ifn_1771 lang.IFn; if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1773 any = t.F_methods; if linked_1770 == nil { tmp18 = ifn_1771.Invoke_O_O__O(arg_1772, arg_1773) } else { tmp18 = linked_1770.(*A_arbace_c2j_node_sym_occurs_QMARK__A).Invoke_O_O_O__O(root_1769, arg_1772, arg_1773) } } else {
//line :468:1
				tmp18 = and__1927000168__auto____3_2 }; if jrt.J2g_Truth(tmp18) { var tmp19 any = A_arbace_c2j_node_A_const_337; var tmp20 any; var root_1779 any = A_arbace_c2j_node_A_const_346.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1781 lang.IFn

					if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1783 any; var root_1784 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1784, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1786 lang.IFn; if linked_1785 == nil { ifn_1786 = lang.IFn_Cast(root_1784) } else { ifn_1786 = nil }; var arg_1787 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1785 == nil { arg_1783 = ifn_1786.Invoke_O__O(arg_1787) } else { arg_1783 = linked_1785.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1784, arg_1787) }; if linked_1780 == nil { tmp20 = ifn_1781.Invoke_O_O__O(arg_1782, arg_1783) } else { tmp20 = linked_1780.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1779, arg_1782, arg_1783) }
//line :468:1
					var tmp21 any = tmp20; var tmp22 any = A_arbace_c2j_node_A_const_340; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, tmp22, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1)))) } else { return nil } }
//line :457:1
	default:}; return nil }




func A_arbace_c2j_node_variant_class_fn__400000299_fn__400000303_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_variant_class_fn__400000299_fn__400000303_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000299_fn__400000303_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :462:1
func (t *A_arbace_c2j_node_variant_class_fn__400000299_fn__400000303_A) Ctor_O_O_O(c__b, c__conv, c__fld any) { t.F_b = c__b; t.F_conv = c__conv; t.F_fld = c__fld }
//line :462:1
func (t *A_arbace_c2j_node_variant_class_fn__400000299_fn__400000303_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_348; var tmp3 any = A_arbace_c2j_node_A_const_349; var x__2 any = tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_350, t.F_fld, i__1)); var tmp4 any = A_arbace_c2j_node_A_const_337; var tmp5 any; var root_1731 any = A_arbace_c2j_node_A_const_346.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1733 lang.IFn; if

	linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any; var root_1736 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_19.Invoke_O__O(t.F_b), i__1)).Ref(); if linked_1737 == nil { arg_1734 = ifn_1738.Invoke_O__O(arg_1739) } else { arg_1734 = linked_1737.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1736, arg_1739) }; var arg_1735 any = A_arbace_c2j_node_A_const_347; if linked_1732 == nil { tmp5 = ifn_1733.Invoke_O_O__O(arg_1734, arg_1735) } else { tmp5 = linked_1732.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1731, arg_1734, arg_1735) }; var tmp6 any = tmp5; var tmp7 any = A_arbace_c2j_node_A_const_340; var tmp8 any; if
	jrt.J2g_Truth(t.F_conv) { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_node_A_const_351; var tmp11 any = A_arbace_c2j_node_A_const_352; tmp8 = tmp9.Invoke_O_O_O_O__O(tmp10, tmp11, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_353, A_arbace_c2j_node_A_const_354, i__1), x__2) } else { tmp8 = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_355, A_arbace_c2j_node_A_const_356, x__2) }; return /*line :462:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, tmp8)) }




func A_arbace_c2j_node_variant_class_fn__400000299_fn__400000301_A_New() *A_arbace_c2j_node_variant_class_fn__400000299_fn__400000301_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000299_fn__400000301_A{}; t.Ctor(); return t }
//line :467:1
func (t *A_arbace_c2j_node_variant_class_fn__400000299_fn__400000301_A) Ctor() {}
//line :467:1
func (t *A_arbace_c2j_node_variant_class_fn__400000299_fn__400000301_A) Invoke_O_O__O(self, s__1 any) any { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_337, s__1)) }





func A_arbace_c2j_node_variant_class_bare__400000306_A_New() *A_arbace_c2j_node_variant_class_bare__400000306_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_bare__400000306_A{}; t.Ctor(); return t }
//line :473:1
func (t *A_arbace_c2j_node_variant_class_bare__400000306_A) Ctor() {}
//line :473:1
func (t *A_arbace_c2j_node_variant_class_bare__400000306_A) Invoke_O_O__O(self, s__1 any) any { var root_1790 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any = s__1; var arg_1794 any; if linked_1791 == nil { return ifn_1792.Invoke_O_O__O(arg_1793, arg_1794) } else { return linked_1791.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1790, arg_1793, arg_1794) } }



func A_arbace_c2j_node_variant_class_fn__400000309_A_New() *A_arbace_c2j_node_variant_class_fn__400000309_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000309_A{}; t.Ctor(); return t }
//line :477:1
func (t *A_arbace_c2j_node_variant_class_fn__400000309_A) Ctor() {}
//line :477:1
func (t *A_arbace_c2j_node_variant_class_fn__400000309_A) Invoke_O_O__O(self, p__400000308__1 any) any { var map__400000310__2 any = p__400000308__1; var map__400000310__3 any; if lang.ISeq_InstanceOf(map__400000310__2) { var tmp1 any; var root_1818 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = map__400000310__2; if linked_1819 == nil { tmp1 = ifn_1820.Invoke_O__O(arg_1821) } else { tmp1 = linked_1819.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1818, arg_1821) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1822 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = map__400000310__2; if linked_1823 == nil { tmp2 = ifn_1824.Invoke_O__O(arg_1825) } else { tmp2 = linked_1823.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1822, arg_1825) }; map__400000310__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1826 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = map__400000310__2; if linked_1827 == nil { tmp3 = ifn_1828.Invoke_O__O(arg_1829) } else { tmp3 = linked_1827.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1826, arg_1829) }; if jrt.J2g_Truth(tmp3) { var root_1830 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1832 lang.IFn; if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = map__400000310__2; if linked_1831 == nil { map__400000310__3 = ifn_1832.Invoke_O__O(arg_1833) } else { map__400000310__3 = linked_1831.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1830, arg_1833) } } else { map__400000310__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000310__3 = map__400000310__2 }; var fs__4 any = lang.RT_Get_O_O__O_NoInit(map__400000310__3, A_arbace_c2j_node_A_const_337); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_node_A_const_366; return tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_node_A_const_308.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(fs__4, A_arbace_c2j_node_A_const_14.GetRawRoot__O(), A_arbace_c2j_node_A_const_367, jrt.Boolean_TRUE.Ref(), A_arbace_c2j_node_A_const_368, jrt.Boolean_TRUE.Ref())) }

func A_arbace_c2j_node_variant_class_fn__400000314_A_New_O(p0 any) *A_arbace_c2j_node_variant_class_fn__400000314_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000314_A{}; t.Ctor_O(p0); return t }
//line :479:1
func (t *A_arbace_c2j_node_variant_class_fn__400000314_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :479:1
func (t *A_arbace_c2j_node_variant_class_fn__400000314_A) Invoke_O_O__O(self, p__400000313__1 any) any { var map__400000315__2 any = p__400000313__1; var map__400000315__3 any; if lang.ISeq_InstanceOf(map__400000315__2) { var tmp1 any; var root_1875 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1875, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1877 lang.IFn; if linked_1876 == nil { ifn_1877 = lang.IFn_Cast(root_1875) } else { ifn_1877 = nil }; var arg_1878 any = map__400000315__2; if linked_1876 == nil { tmp1 = ifn_1877.Invoke_O__O(arg_1878) } else { tmp1 = linked_1876.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1875, arg_1878) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1879 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_1880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1879, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1881 lang.IFn; if linked_1880 == nil { ifn_1881 = lang.IFn_Cast(root_1879) } else { ifn_1881 = nil }; var arg_1882 any = map__400000315__2; if linked_1880 == nil { tmp2 = ifn_1881.Invoke_O__O(arg_1882) } else { tmp2 = linked_1880.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1879, arg_1882) }; map__400000315__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1883 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1883, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1885 lang.IFn; if linked_1884 == nil { ifn_1885 = lang.IFn_Cast(root_1883) } else { ifn_1885 = nil }; var arg_1886 any = map__400000315__2; if linked_1884 == nil { tmp3 = ifn_1885.Invoke_O__O(arg_1886) } else { tmp3 = linked_1884.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1883, arg_1886) }; if jrt.J2g_Truth(tmp3) { var root_1887 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1889 lang.IFn; if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var arg_1890 any = map__400000315__2; if linked_1888 == nil { map__400000315__3 = ifn_1889.Invoke_O__O(arg_1890) } else { map__400000315__3 = linked_1888.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1887, arg_1890) } } else { map__400000315__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000315__3 = map__400000315__2 }; var fs__4 any = lang.RT_Get_O_O__O_NoInit(map__400000315__3, A_arbace_c2j_node_A_const_337); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_node_A_const_372; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp7 any; var root_1891 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1891, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1893 lang.IFn; if linked_1892 == nil { ifn_1893 = lang.IFn_Cast(root_1891) } else { ifn_1893 = nil }; var arg_1894 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(t.F_bare).Invoke_O__O(fs__4))).Ref(); if linked_1892 == nil { tmp7 = ifn_1893.Invoke_O__O(arg_1894) } else { tmp7 = linked_1892.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1891, arg_1894) }; return tmp4.Invoke_O_O_O__O(tmp5, tmp6.Invoke_O_O__O(tmp7, A_arbace_c2j_node_A_const_373), lang.IFn_Cast(t.F_bare).Invoke_O__O(fs__4)) }



func A_arbace_c2j_node_variants_A_New() *A_arbace_c2j_node_variants_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_A{}; t.Ctor(); return t }
//line :483:1
func (t *A_arbace_c2j_node_variants_A) Ctor() {}
//line :483:1
func (t *A_arbace_c2j_node_variants_A) Invoke_O_O_O__O(self, d__0, domains__1 any) any { var base__3 any; var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_374; var or__1927000174__auto____3 any = tmp1.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0)); if



	jrt.J2g_Truth(or__1927000174__auto____3) { base__3 = or__1927000174__auto____3 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_96, nil); var tmp3 any; var root_1897 any = A_arbace_c2j_node_A_const_375.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, A_arbace_c2j_node_camel_A_fn_class); var ifn_1899 lang.IFn; if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any = A_arbace_c2j_node_A_const_13.Invoke_O__O(d__0); if linked_1898 == nil { tmp3 = ifn_1899.Invoke_O__O(arg_1900) } else { tmp3 = linked_1898.(*A_arbace_c2j_node_camel_A).Invoke_O_O__O(root_1897, arg_1900) }; base__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() }; var ss__4 any; var root_1901 any = /*line :483:1*/A_arbace_c2j_node_A_const_376.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, A_arbace_c2j_node_splits_A_fn_class); var ifn_1903 lang.IFn; if




	linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any = d__0; if linked_1902 == nil { ss__4 = ifn_1903.Invoke_O__O(arg_1904) } else { ss__4 = linked_1902.(*A_arbace_c2j_node_splits_A).Invoke_O_O__O(root_1901, arg_1904) }; var cb__5 any; var root_1905 any = /*line :483:1*/A_arbace_c2j_node_A_const_334.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1905, A_arbace_c2j_node_children_bind_A_fn_class); var ifn_1907 lang.IFn; if





	linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any = d__0; if linked_1906 == nil { cb__5 = ifn_1907.Invoke_O__O(arg_1908) } else { cb__5 = linked_1906.(*A_arbace_c2j_node_children_bind_A).Invoke_O_O__O(root_1905, arg_1908) }; var counts__6 any; if
	jrt.J2g_Truth(cb__5) {
		var root_1909 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_1910 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1909, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1911 lang.IFn; if linked_1910 == nil { ifn_1911 = lang.IFn_Cast(root_1909) } else { ifn_1911 = nil }; var arg_1912 any; var root_1914 any = A_arbace_c2j_node_A_const_226.GetRawRoot__O(); var linked_1915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1914, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1916 lang.IFn; if linked_1915 == nil { ifn_1916 = lang.IFn_Cast(root_1914) } else { ifn_1916 = nil }; var arg_1917 any; var na_1918 any; var root_1919 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_1920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1919, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1921 lang.IFn; if linked_1920 == nil { ifn_1921 = lang.IFn_Cast(root_1919) } else { ifn_1921 = nil }; var arg_1922 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(cb__5); if linked_1920 == nil { na_1918 = ifn_1921.Invoke_O__O(arg_1922) } else { na_1918 = linked_1920.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1919, arg_1922) }; if jrt.Long_InstanceOf(na_1918) { var n0_1923 int64 = jrt.NN(jrt.Long_Cast(na_1918)).LongValue__J(); if n0_1923 == 9223372036854775807 { arg_1917 = lang.Numbers_Inc_O__Number_NoInit(na_1918) } else { arg_1917 = jrt.Long_ValueOf_J__Long_NoInit(n0_1923 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1918) { var n0_1923_2 float64 = jrt.NN(jrt.Double_Cast(na_1918)).DoubleValue__D(); arg_1917 = jrt.Double_ValueOf_D__Double_NoInit(n0_1923_2 + 1.0).Ref() } else { arg_1917 = lang.Numbers_Inc_O__Number_NoInit(na_1918) } }; if linked_1915 == nil { arg_1912 = ifn_1916.Invoke_O__O(arg_1917) } else { arg_1912 = linked_1915.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1914, arg_1917) }; var arg_1913 any; var tmp4 any; var root_1924 any = A_arbace_c2j_node_A_const_377.GetRawRoot__O(); var linked_1925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1924, A_arbace_c2j_node_uses_many_QMARK__A_fn_class); var ifn_1926 lang.IFn; if linked_1925 == nil { ifn_1926 = lang.IFn_Cast(root_1924) } else { ifn_1926 = nil }; var arg_1927 any = d__0; if linked_1925 == nil { tmp4 = ifn_1926.Invoke_O__O(arg_1927) } else { tmp4 = linked_1925.(*A_arbace_c2j_node_uses_many_QMARK__A).Invoke_O_O__O(root_1924, arg_1927) }; if jrt.J2g_Truth(tmp4) { arg_1913 = A_arbace_c2j_node_A_const_378 } else { arg_1913 = nil }; if linked_1910 == nil { counts__6 = ifn_1911.Invoke_O_O__O(arg_1912, arg_1913) } else { counts__6 = linked_1910.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1909, arg_1912, arg_1913) } } else {
//line :490:1
			counts__6 = A_arbace_c2j_node_A_const_379 }; var split_sets__7 any; var root_1928 any = /*line :483:1*/A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_1929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1928, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1930 lang.IFn; if









	linked_1929 == nil { ifn_1930 = lang.IFn_Cast(root_1928) } else { ifn_1930 = nil }; var arg_1931 any; var fnbody__2038 any = A_arbace_c2j_node_variants_fn__400000320_A_New(); var tmp5 *jrt.Class; var fncls__2037 *jrt.Class = A_arbace_c2j_node_variants_fn__400000320_A_fn_class; if fncls__2037 == nil { var fncls__2037d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, nil); A_arbace_c2j_node_variants_fn__400000320_A_fn_class = fncls__2037d; tmp5 = fncls__2037d } else { tmp5 = fncls__2037 }; arg_1931 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2038, tmp5, nil); var arg_1932 any = lang.Tuple_Create_O__IPersistentVector(lang.PersistentArrayMap_EMPTY.Ref()); var arg_1933 any = ss__4; if linked_1929 == nil { split_sets__7 = ifn_1930.Invoke_O_O_O__O(arg_1931, arg_1932, arg_1933) } else { split_sets__7 = linked_1929.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1928, arg_1931, arg_1932, arg_1933) }; var dom__8 any; var tmp6 /*line :483:1*/*lang.Keyword = A_arbace_c2j_node_A_const_388; if










	jrt.J2g_Truth(tmp6.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0))) { dom__8 = lang.IFn_Cast(domains__1).Invoke_O__O(A_arbace_c2j_node_A_const_13.Invoke_O__O(d__0)) } else { dom__8 = nil }; var tmp7 any; var root_2039 any =
	A_arbace_c2j_node_A_const_48.GetRawRoot__O(); var linked_2040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2039, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2041 lang.IFn; if linked_2040 == nil { ifn_2041 = lang.IFn_Cast(root_2039) } else { ifn_2041 = nil }; var arg_2042 any; var fnbody__2045 any = A_arbace_c2j_node_variants_fn__400000338_A_New(); var tmp8 *jrt.Class; var fncls__2044 *jrt.Class = A_arbace_c2j_node_variants_fn__400000338_A_fn_class; if fncls__2044 == nil { var fncls__2044d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, nil); A_arbace_c2j_node_variants_fn__400000338_A_fn_class = fncls__2044d; tmp8 = fncls__2044d } else { tmp8 = fncls__2044 }; arg_2042 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2045, tmp8, nil); var arg_2043 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_2040 == nil { tmp7 = ifn_2041.Invoke_O_O__O(arg_2042, arg_2043) } else { tmp7 = linked_2040.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2039, arg_2042, arg_2043) }; if jrt.J2g_Truth(tmp7) { var iter__1927001039__auto____9 any; var fnbody__2136 any = A_arbace_c2j_node_variants_iter__400000340__400000346_A_New(); var tmp9 *jrt.Class; var fncls__2135 *jrt.Class = A_arbace_c2j_node_variants_iter__400000340__400000346_A_fn_class
		if fncls__2135 == nil { var fncls__2135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, nil); A_arbace_c2j_node_variants_iter__400000340__400000346_A_fn_class = fncls__2135d; tmp9 = fncls__2135d } else { tmp9 = fncls__2135 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2136, tmp9, nil); return lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_c2j_node_A_const_395.GetRawRoot__O()) } else {
//line :495:1
			var iter__1927001039__auto____9_2 any; var fnbody__2285 any = A_arbace_c2j_node_variants_iter__400000359__400000365_A_New_O_O_O_O(base__3, split_sets__7, dom__8, ss__4); var tmp10 *jrt.Class
			var fncls__2284 /*line :495:1*/*jrt.Class = A_arbace_c2j_node_variants_iter__400000359__400000365_A_fn_class


			if fncls__2284 == nil { var fncls__2284d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, fnbody__2285); A_arbace_c2j_node_variants_iter__400000359__400000365_A_fn_class = fncls__2284d; tmp10 = fncls__2284d } else { tmp10 = fncls__2284 }; iter__1927001039__auto____9_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2285, tmp10, nil); return lang.IFn_Cast(iter__1927001039__auto____9_2).Invoke_O__O(counts__6) } }
//line :493:1
func A_arbace_c2j_node_variants_fn__400000320_A_New() *A_arbace_c2j_node_variants_fn__400000320_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000320_A{}; t.Ctor(); return t }
//line :493:1
func (t *A_arbace_c2j_node_variants_fn__400000320_A) Ctor() {}
//line :493:1
func (t *A_arbace_c2j_node_variants_fn__400000320_A) Invoke_O_O_O__O(self, acc__1, s__2 any) any { var iter__1927001039__auto____3 any; var fnbody__2036 any = A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_A_New_O(s__2); var tmp1 *jrt.Class; var fncls__2035 *jrt.Class = A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_A_fn_class; if fncls__2035 == nil { var fncls__2035d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, fnbody__2036); A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_A_fn_class = fncls__2035d; tmp1 = fncls__2035d } else { tmp1 = fncls__2035 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2036, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(acc__1) }
//line :493:1
func A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_A_New_O(p0 any) *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_A{}; t.Ctor_O(p0); return t }
//line :493:1
func (t *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :493:1
func (t *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_A) Invoke_O_O__O(self, s__400000322__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2034 any = A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_A_New_O_O_O(s__400000322__1, t.F_s, self); var tmp2 *jrt.Class; var fncls__2033 *jrt.Class = A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_A_fn_class; if fncls__2033 == nil { var fncls__2033d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, fnbody__2034); A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_A_fn_class = fncls__2033d; tmp2 = fncls__2033d } else { tmp2 = fncls__2033 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2034, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :493:1
func A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :493:1
func (t *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_A) Ctor_O_O_O(c__s__400000322, c__s, c__iter__400000321 any) { t.F_s__400000322 = c__s__400000322; t.F_s = c__s; t.F_iter__400000321 = c__iter__400000321 }
//line :493:1
func (t *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_A) Invoke_O__O(self any) any { { var s__400000322__1 any; var t_ any = t.F_s__400000322; t.F_s__400000322 = nil; s__400000322__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1934 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1934, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1936 lang.IFn; if linked_1935 == nil { ifn_1936 = lang.IFn_Cast(root_1934) } else { ifn_1936 = nil }; var arg_1937 any = s__400000322__1; if linked_1935 == nil { temp__1927000414__auto____2 = ifn_1936.Invoke_O__O(arg_1937) } else { temp__1927000414__auto____2 = linked_1935.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1934, arg_1937) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var m__4 any; var root_1938 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1938, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1940 lang.IFn; if linked_1939 == nil { ifn_1940 = lang.IFn_Cast(root_1938) } else { ifn_1940 = nil }; var arg_1941 any = xs__1927001018__auto____3; if linked_1939 == nil { m__4 = ifn_1940.Invoke_O__O(arg_1941) } else { m__4 = linked_1939.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1938, arg_1941) }; var iterys__1927001035__auto____5 any; var fnbody__2015 any = A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_A_New_O_O(m__4, t.F_s); var tmp1 *jrt.Class; var fncls__2014 *jrt.Class = A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_A_fn_class; if fncls__2014 == nil { var fncls__2014d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, fnbody__2015); A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_A_fn_class = fncls__2014d; tmp1 = fncls__2014d } else { tmp1 = fncls__2014 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2015, tmp1, nil); var fs__1927001036__auto____6 any; var root_2016 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2018 lang.IFn; if linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_c2j_node_A_const_387); if linked_2017 == nil { fs__1927001036__auto____6 = ifn_2018.Invoke_O__O(arg_2019) } else { fs__1927001036__auto____6 = linked_2017.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2016, arg_2019) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_2020 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2021 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2020, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2022 lang.IFn; if linked_2021 == nil { ifn_2022 = lang.IFn_Cast(root_2020) } else { ifn_2022 = nil }; var arg_2023 any = fs__1927001036__auto____6; var arg_2024 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_iter__400000321); var tmp3 any; var root_2025 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2025, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2027 lang.IFn; if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any = s__400000322__1; if linked_2026 == nil { tmp3 = ifn_2027.Invoke_O__O(arg_2028) } else { tmp3 = linked_2026.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2025, arg_2028) }; arg_2024 = tmp2.Invoke_O__O(tmp3); if linked_2021 == nil { return ifn_2022.Invoke_O_O__O(arg_2023, arg_2024) } else { return linked_2021.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2020, arg_2023, arg_2024) } } else { var tmp4 any; var root_2029 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2029, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2031 lang.IFn; if linked_2030 == nil { ifn_2031 = lang.IFn_Cast(root_2029) } else { ifn_2031 = nil }; var arg_2032 any = s__400000322__1; if linked_2030 == nil { tmp4 = ifn_2031.Invoke_O__O(arg_2032) } else { tmp4 = linked_2030.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2029, arg_2032) }; s__400000322__1 = tmp4; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :493:1
func A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_A{}; t.Ctor_O_O(p0, p1); return t }
//line :493:1
func (t *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_A) Ctor_O_O(c__m, c__s any) { t.F_m = c__m; t.F_s = c__s }
//line :493:1
func (t *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_A) Invoke_O_O__O(self, s__400000324__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2013 any = A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_A_New_O_O_O_O(self, s__400000324__1, t.F_m, t.F_s); var tmp2 *jrt.Class; var fncls__2012 *jrt.Class = A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_A_fn_class; if fncls__2012 == nil { var fncls__2012d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, false, fnbody__2013); A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_A_fn_class = fncls__2012d; tmp2 = fncls__2012d } else { tmp2 = fncls__2012 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2013, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :493:1
func A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :493:1
func (t *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_A) Ctor_O_O_O_O(c__iter__400000323, c__s__400000324, c__m, c__s any) { t.F_iter__400000323 = c__iter__400000323; t.F_s__400000324 = c__s__400000324; t.F_m = c__m; t.F_s = c__s }
//line :493:1
func (t *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_A) Invoke_O__O(self any) any { { var s__400000324__1 any; var t_ any = t.F_s__400000324; t.F_s__400000324 = nil; s__400000324__1 = t_; for { var temp__1927000414__auto____2 any; var root_1942 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1942, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1944 lang.IFn; if linked_1943 == nil { ifn_1944 = lang.IFn_Cast(root_1942) } else { ifn_1944 = nil }; var arg_1945 any = s__400000324__1; if linked_1943 == nil { temp__1927000414__auto____2 = ifn_1944.Invoke_O__O(arg_1945) } else { temp__1927000414__auto____2 = linked_1943.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1942, arg_1945) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000324__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1946 any = A_arbace_c2j_node_A_const_380.GetRawRoot__O(); var linked_1947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1946, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1948 lang.IFn; if linked_1947 == nil { ifn_1948 = lang.IFn_Cast(root_1946) } else { ifn_1948 = nil }; var arg_1949 any = s__400000324__3; if linked_1947 == nil { tmp1 = ifn_1948.Invoke_O__O(arg_1949) } else { tmp1 = linked_1947.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1946, arg_1949) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1950 any = A_arbace_c2j_node_A_const_381.GetRawRoot__O(); var linked_1951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1950, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1952 lang.IFn; if linked_1951 == nil { ifn_1952 = lang.IFn_Cast(root_1950) } else { ifn_1952 = nil }; var arg_1953 any = s__400000324__3; if linked_1951 == nil { c__1927001037__auto____4 = ifn_1952.Invoke_O__O(arg_1953) } else { c__1927001037__auto____4 = linked_1951.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1950, arg_1953) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000326__6 any; var root_1954 any = A_arbace_c2j_node_A_const_382.GetRawRoot__O(); var linked_1955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1954, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1956 lang.IFn; if linked_1955 == nil { ifn_1956 = lang.IFn_Cast(root_1954) } else { ifn_1956 = nil }; var arg_1957 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1955 == nil { b__400000326__6 = ifn_1956.Invoke_O__O(arg_1957) } else { b__400000326__6 = linked_1955.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1954, arg_1957) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1970 any = A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_fn__400000331_A_New_O_O_O_I_O(t.F_m, t.F_s, b__400000326__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1969 *jrt.Class = A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_fn__400000331_A_fn_class; if fncls__1969 == nil { var fncls__1969d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, fnbody__1970); A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_fn__400000331_A_fn_class = fncls__1969d; tmp3 = fncls__1969d } else { tmp3 = fncls__1969 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1970, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1971 any = A_arbace_c2j_node_A_const_384.GetRawRoot__O(); var linked_1972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1971, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1973 lang.IFn; if linked_1972 == nil { ifn_1973 = lang.IFn_Cast(root_1971) } else { ifn_1973 = nil }; var arg_1974 any; var root_1976 any = A_arbace_c2j_node_A_const_385.GetRawRoot__O(); var linked_1977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1976, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1978 lang.IFn; if linked_1977 == nil { ifn_1978 = lang.IFn_Cast(root_1976) } else { ifn_1978 = nil }; var arg_1979 any = b__400000326__6; if linked_1977 == nil { arg_1974 = ifn_1978.Invoke_O__O(arg_1979) } else { arg_1974 = linked_1977.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1976, arg_1979) }; var arg_1975 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000323); var tmp5 any; var root_1980 any = A_arbace_c2j_node_A_const_386.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1980, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1982 lang.IFn; if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any = s__400000324__3; if linked_1981 == nil { tmp5 = ifn_1982.Invoke_O__O(arg_1983) } else { tmp5 = linked_1981.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1980, arg_1983) }; arg_1975 = tmp4.Invoke_O__O(tmp5); if linked_1972 == nil { return ifn_1973.Invoke_O_O__O(arg_1974, arg_1975) } else { return linked_1972.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1971, arg_1974, arg_1975) } } else { var root_1984 any = A_arbace_c2j_node_A_const_384.GetRawRoot__O(); var linked_1985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1984, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1986 lang.IFn; if linked_1985 == nil { ifn_1986 = lang.IFn_Cast(root_1984) } else { ifn_1986 = nil }; var arg_1987 any; var root_1989 any = A_arbace_c2j_node_A_const_385.GetRawRoot__O(); var linked_1990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1989, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1991 lang.IFn; if linked_1990 == nil { ifn_1991 = lang.IFn_Cast(root_1989) } else { ifn_1991 = nil }; var arg_1992 any = b__400000326__6; if linked_1990 == nil { arg_1987 = ifn_1991.Invoke_O__O(arg_1992) } else { arg_1987 = linked_1990.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1989, arg_1992) }; var arg_1988 any; if linked_1985 == nil { return ifn_1986.Invoke_O_O__O(arg_1987, arg_1988) } else { return linked_1985.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1984, arg_1987, arg_1988) } } } else { var x__4 any; var root_1993 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1993, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1995 lang.IFn; if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var arg_1996 any = s__400000324__3; if linked_1994 == nil { x__4 = ifn_1995.Invoke_O__O(arg_1996) } else { x__4 = linked_1994.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1993, arg_1996) }; var root_1997 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_1998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1997, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1999 lang.IFn; if linked_1998 == nil { ifn_1999 = lang.IFn_Cast(root_1997) } else { ifn_1999 = nil }; var arg_2000 any; var root_2002 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2002, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2004 lang.IFn; if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any = t.F_m; var arg_2006 any = t.F_s; var arg_2007 any = x__4; if linked_2003 == nil { arg_2000 = ifn_2004.Invoke_O_O_O__O(arg_2005, arg_2006, arg_2007) } else { arg_2000 = linked_2003.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2002, arg_2005, arg_2006, arg_2007) }; var arg_2001 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__400000323); var tmp7 any; var root_2008 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2008, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2010 lang.IFn; if linked_2009 == nil { ifn_2010 = lang.IFn_Cast(root_2008) } else { ifn_2010 = nil }; var arg_2011 any = s__400000324__3; if linked_2009 == nil { tmp7 = ifn_2010.Invoke_O__O(arg_2011) } else { tmp7 = linked_2009.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2008, arg_2011) }; arg_2001 = tmp6.Invoke_O__O(tmp7); if linked_1998 == nil { return ifn_1999.Invoke_O_O__O(arg_2000, arg_2001) } else { return linked_1998.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1997, arg_2000, arg_2001) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :493:1
func A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_fn__400000331_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_fn__400000331_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_fn__400000331_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :493:1
func (t *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_fn__400000331_A) Ctor_O_O_O_I_O(c__m, c__s, c__b__400000326 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_m = c__m; t.F_s = c__s; t.F_b__400000326 = c__b__400000326; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :493:1
func (t *A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_fn__400000331_A) Invoke_O__O(self any) any { { var i__400000325__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000325__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000325__1)); var root_1958 any = A_arbace_c2j_node_A_const_383.GetRawRoot__O(); var linked_1959 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1958, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1960 lang.IFn; if linked_1959 == nil { ifn_1960 = lang.IFn_Cast(root_1958) } else { ifn_1960 = nil }; var arg_1961 any = t.F_b__400000326; var arg_1962 any; var root_1963 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1964 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1963, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1965 lang.IFn; if linked_1964 == nil { ifn_1965 = lang.IFn_Cast(root_1963) } else { ifn_1965 = nil }; var arg_1966 any = t.F_m; var arg_1967 any = t.F_s; var arg_1968 any = x__2; if linked_1964 == nil { arg_1962 = ifn_1965.Invoke_O_O_O__O(arg_1966, arg_1967, arg_1968) } else { arg_1962 = linked_1964.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1963, arg_1966, arg_1967, arg_1968) }; if linked_1959 == nil { ifn_1960.Invoke_O_O__O(arg_1961, arg_1962) } else { linked_1959.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1958, arg_1961, arg_1962) }; i__400000325__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000325__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_node_variants_fn__400000338_A_New() *A_arbace_c2j_node_variants_fn__400000338_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000338_A{}; t.Ctor(); return t }
//line :495:1
func (t *A_arbace_c2j_node_variants_fn__400000338_A) Ctor() {}
//line :495:1
func (t *A_arbace_c2j_node_variants_fn__400000338_A) Invoke_O_O__O(self, p1__400000319_SHARP___1 any) any { var tmp1 any = A_arbace_c2j_node_A_const_389; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_c2j_node_A_const_20.Invoke_O__O(p1__400000319_SHARP___1))).Ref() }
func A_arbace_c2j_node_variants_iter__400000340__400000346_A_New() *A_arbace_c2j_node_variants_iter__400000340__400000346_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000340__400000346_A{}; t.Ctor(); return t }
//line :496:1
func (t *A_arbace_c2j_node_variants_iter__400000340__400000346_A) Ctor() {}
//line :496:1
func (t *A_arbace_c2j_node_variants_iter__400000340__400000346_A) Invoke_O_O__O(self, s__400000341__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2134 any = A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_A_New_O_O(s__400000341__1, self); var tmp2 *jrt.Class; var fncls__2133 *jrt.Class = A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_A_fn_class; if fncls__2133 == nil { var fncls__2133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, fnbody__2134); A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_A_fn_class = fncls__2133d; tmp2 = fncls__2133d } else { tmp2 = fncls__2133 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2134, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :496:1
func A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_A{}; t.Ctor_O_O(p0, p1); return t }
//line :496:1
func (t *A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_A) Ctor_O_O(c__s__400000341, c__iter__400000340 any) { t.F_s__400000341 = c__s__400000341; t.F_iter__400000340 = c__iter__400000340 }
//line :496:1
func (t *A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_A) Invoke_O__O(self any) any { { var s__400000341__1 any; var t_ any = t.F_s__400000341; t.F_s__400000341 = nil; s__400000341__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2046 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2046, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2048 lang.IFn; if linked_2047 == nil { ifn_2048 = lang.IFn_Cast(root_2046) } else { ifn_2048 = nil }; var arg_2049 any = s__400000341__1; if linked_2047 == nil { temp__1927000414__auto____2 = ifn_2048.Invoke_O__O(arg_2049) } else { temp__1927000414__auto____2 = linked_2047.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2046, arg_2049) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__400000348__4 any; var root_2050 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2050, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2052 lang.IFn; if linked_2051 == nil { ifn_2052 = lang.IFn_Cast(root_2050) } else { ifn_2052 = nil }; var arg_2053 any = xs__1927001018__auto____3; if linked_2051 == nil { vec__400000348__4 = ifn_2052.Invoke_O__O(arg_2053) } else { vec__400000348__4 = linked_2051.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2050, arg_2053) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000348__4, lang.RT_IntCast_J__I_NoInit(0), nil); var p__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000348__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var fnbody__2115 any = A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_A_New_O_O(k__5, p__6); var tmp1 *jrt.Class; var fncls__2114 *jrt.Class = A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_A_fn_class; if fncls__2114 == nil { var fncls__2114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, false, fnbody__2115); A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_A_fn_class = fncls__2114d; tmp1 = fncls__2114d } else { tmp1 = fncls__2114 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2115, tmp1, nil); var fs__1927001036__auto____8 any; var root_2116 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2116, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2118 lang.IFn; if linked_2117 == nil { ifn_2118 = lang.IFn_Cast(root_2116) } else { ifn_2118 = nil }; var arg_2119 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp3 any; if jrt.J2g_Truth(A_arbace_c2j_node_A_const_245.Invoke_O__O(p__6)) { tmp3 = A_arbace_c2j_node_A_const_391 } else { tmp3 = A_arbace_c2j_node_A_const_392 }; arg_2119 = tmp2.Invoke_O__O(tmp3); if linked_2117 == nil { fs__1927001036__auto____8 = ifn_2118.Invoke_O__O(arg_2119) } else { fs__1927001036__auto____8 = linked_2117.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2116, arg_2119) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2120 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2120, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2122 lang.IFn; if linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any = fs__1927001036__auto____8; var arg_2124 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000340); var tmp5 any; var root_2125 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2125, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2127 lang.IFn; if linked_2126 == nil { ifn_2127 = lang.IFn_Cast(root_2125) } else { ifn_2127 = nil }; var arg_2128 any = s__400000341__1; if linked_2126 == nil { tmp5 = ifn_2127.Invoke_O__O(arg_2128) } else { tmp5 = linked_2126.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2125, arg_2128) }; arg_2124 = tmp4.Invoke_O__O(tmp5); if linked_2121 == nil { return ifn_2122.Invoke_O_O__O(arg_2123, arg_2124) } else { return linked_2121.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2120, arg_2123, arg_2124) } } else { var tmp6 any; var root_2129 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2129, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2131 lang.IFn; if linked_2130 == nil { ifn_2131 = lang.IFn_Cast(root_2129) } else { ifn_2131 = nil }; var arg_2132 any = s__400000341__1; if linked_2130 == nil { tmp6 = ifn_2131.Invoke_O__O(arg_2132) } else { tmp6 = linked_2130.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2129, arg_2132) }; s__400000341__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :496:1
func A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_A{}; t.Ctor_O_O(p0, p1); return t }
//line :496:1
func (t *A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_A) Ctor_O_O(c__k, c__p any) { t.F_k = c__k; t.F_p = c__p }
//line :496:1
func (t *A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_A) Invoke_O_O__O(self, s__400000343__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2113 any = A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_A_New_O_O_O_O(s__400000343__1, t.F_k, t.F_p, self); var tmp2 *jrt.Class; var fncls__2112 *jrt.Class = A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_A_fn_class; if fncls__2112 == nil { var fncls__2112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, fnbody__2113); A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_A_fn_class = fncls__2112d; tmp2 = fncls__2112d } else { tmp2 = fncls__2112 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2113, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :496:1
func A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :496:1
func (t *A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_A) Ctor_O_O_O_O(c__s__400000343, c__k, c__p, c__iter__400000342 any) { t.F_s__400000343 = c__s__400000343; t.F_k = c__k; t.F_p = c__p; t.F_iter__400000342 = c__iter__400000342 }
//line :496:1
func (t *A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_A) Invoke_O__O(self any) any { { var s__400000343__1 any; var t_ any = t.F_s__400000343; t.F_s__400000343 = nil; s__400000343__1 = t_; for { var temp__1927000414__auto____2 any; var root_2054 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2054, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2056 lang.IFn; if linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any = s__400000343__1; if linked_2055 == nil { temp__1927000414__auto____2 = ifn_2056.Invoke_O__O(arg_2057) } else { temp__1927000414__auto____2 = linked_2055.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2054, arg_2057) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000343__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2058 any = A_arbace_c2j_node_A_const_380.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2060 lang.IFn; if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any = s__400000343__3; if linked_2059 == nil { tmp1 = ifn_2060.Invoke_O__O(arg_2061) } else { tmp1 = linked_2059.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2058, arg_2061) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2062 any = A_arbace_c2j_node_A_const_381.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2062, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2064 lang.IFn; if linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any = s__400000343__3; if linked_2063 == nil { c__1927001037__auto____4 = ifn_2064.Invoke_O__O(arg_2065) } else { c__1927001037__auto____4 = linked_2063.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2062, arg_2065) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000345__6 any; var root_2066 any = A_arbace_c2j_node_A_const_382.GetRawRoot__O(); var linked_2067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2066, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2068 lang.IFn; if linked_2067 == nil { ifn_2068 = lang.IFn_Cast(root_2066) } else { ifn_2068 = nil }; var arg_2069 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2067 == nil { b__400000345__6 = ifn_2068.Invoke_O__O(arg_2069) } else { b__400000345__6 = linked_2067.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2066, arg_2069) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2076 any = A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_fn__400000353_A_New_O_O_O_I_O(t.F_k, t.F_p, b__400000345__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2075 *jrt.Class = A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_fn__400000353_A_fn_class; if fncls__2075 == nil { var fncls__2075d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_109, false, fnbody__2076); A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_fn__400000353_A_fn_class = fncls__2075d; tmp3 = fncls__2075d } else { tmp3 = fncls__2075 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2076, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2077 any = A_arbace_c2j_node_A_const_384.GetRawRoot__O(); var linked_2078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2077, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2079 lang.IFn; if linked_2078 == nil { ifn_2079 = lang.IFn_Cast(root_2077) } else { ifn_2079 = nil }; var arg_2080 any; var root_2082 any = A_arbace_c2j_node_A_const_385.GetRawRoot__O(); var linked_2083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2082, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2084 lang.IFn; if linked_2083 == nil { ifn_2084 = lang.IFn_Cast(root_2082) } else { ifn_2084 = nil }; var arg_2085 any = b__400000345__6; if linked_2083 == nil { arg_2080 = ifn_2084.Invoke_O__O(arg_2085) } else { arg_2080 = linked_2083.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2082, arg_2085) }; var arg_2081 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000342); var tmp5 any; var root_2086 any = A_arbace_c2j_node_A_const_386.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2088 lang.IFn; if linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var arg_2089 any = s__400000343__3; if linked_2087 == nil { tmp5 = ifn_2088.Invoke_O__O(arg_2089) } else { tmp5 = linked_2087.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2086, arg_2089) }; arg_2081 = tmp4.Invoke_O__O(tmp5); if linked_2078 == nil { return ifn_2079.Invoke_O_O__O(arg_2080, arg_2081) } else { return linked_2078.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2077, arg_2080, arg_2081) } } else { var root_2090 any = A_arbace_c2j_node_A_const_384.GetRawRoot__O(); var linked_2091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2090, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2092 lang.IFn; if linked_2091 == nil { ifn_2092 = lang.IFn_Cast(root_2090) } else { ifn_2092 = nil }; var arg_2093 any; var root_2095 any = A_arbace_c2j_node_A_const_385.GetRawRoot__O(); var linked_2096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2095, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2097 lang.IFn; if linked_2096 == nil { ifn_2097 = lang.IFn_Cast(root_2095) } else { ifn_2097 = nil }; var arg_2098 any = b__400000345__6; if linked_2096 == nil { arg_2093 = ifn_2097.Invoke_O__O(arg_2098) } else { arg_2093 = linked_2096.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2095, arg_2098) }; var arg_2094 any; if linked_2091 == nil { return ifn_2092.Invoke_O_O__O(arg_2093, arg_2094) } else { return linked_2091.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2090, arg_2093, arg_2094) } } } else { var c__4 any; var root_2099 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2099, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2101 lang.IFn; if linked_2100 == nil { ifn_2101 = lang.IFn_Cast(root_2099) } else { ifn_2101 = nil }; var arg_2102 any = s__400000343__3; if linked_2100 == nil { c__4 = ifn_2101.Invoke_O__O(arg_2102) } else { c__4 = linked_2100.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2099, arg_2102) }; var root_2103 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2103, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2105 lang.IFn; if linked_2104 == nil { ifn_2105 = lang.IFn_Cast(root_2103) } else { ifn_2105 = nil }; var arg_2106 any; var tmp6 any = A_arbace_c2j_node_A_const_328; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp8 any = A_arbace_c2j_node_A_const_374.Invoke_O__O(t.F_p); var tmp9 *jrt.String
																			if jrt.J2g_Truth(c__4) { tmp9 = Lit_110 } else { tmp9 = nil }
//line :496:1
	arg_2106 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9.Ref())).Ref(), A_arbace_c2j_node_A_const_177, t.F_p, A_arbace_c2j_node_A_const_390, t.F_k, A_arbace_c2j_node_A_const_73, c__4, A_arbace_c2j_node_A_const_234, lang.PersistentArrayMap_EMPTY.Ref())); var arg_2107 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__400000342); var tmp11 any; var root_2108 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2108, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2110 lang.IFn; if linked_2109 == nil { ifn_2110 = lang.IFn_Cast(root_2108) } else { ifn_2110 = nil }; var arg_2111 any = s__400000343__3; if linked_2109 == nil { tmp11 = ifn_2110.Invoke_O__O(arg_2111) } else { tmp11 = linked_2109.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2108, arg_2111) }; arg_2107 = tmp10.Invoke_O__O(tmp11); if linked_2104 == nil { return ifn_2105.Invoke_O_O__O(arg_2106, arg_2107) } else { return linked_2104.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2103, arg_2106, arg_2107) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :496:1
func A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_fn__400000353_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_fn__400000353_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_fn__400000353_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :496:1
func (t *A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_fn__400000353_A) Ctor_O_O_O_I_O(c__k, c__p, c__b__400000345 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_k = c__k; t.F_p = c__p; t.F_b__400000345 = c__b__400000345; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :496:1
func (t *A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_fn__400000353_A) Invoke_O__O(self any) any { { var i__400000344__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000344__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000344__1)); var root_2070 any = A_arbace_c2j_node_A_const_383.GetRawRoot__O(); var linked_2071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2070, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2072 lang.IFn; if linked_2071 == nil { ifn_2072 = lang.IFn_Cast(root_2070) } else { ifn_2072 = nil }; var arg_2073 any = t.F_b__400000345; var arg_2074 any; var tmp2 any = A_arbace_c2j_node_A_const_328; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp4 any = A_arbace_c2j_node_A_const_374.Invoke_O__O(t.F_p); var tmp5 *jrt.String
																					if jrt.J2g_Truth(c__2) { tmp5 = Lit_110 } else { tmp5 = nil }
//line :496:1
	arg_2074 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref())).Ref(), A_arbace_c2j_node_A_const_177, t.F_p, A_arbace_c2j_node_A_const_390, t.F_k, A_arbace_c2j_node_A_const_73, c__2, A_arbace_c2j_node_A_const_234, lang.PersistentArrayMap_EMPTY.Ref())); if linked_2071 == nil { ifn_2072.Invoke_O_O__O(arg_2073, arg_2074) } else { linked_2071.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2070, arg_2073, arg_2074) }; i__400000344__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000344__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_node_variants_iter__400000359__400000365_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variants_iter__400000359__400000365_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000359__400000365_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :498:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_A) Ctor_O_O_O_O(c__base, c__split_sets, c__dom, c__ss any) { t.F_base = c__base; t.F_split_sets = c__split_sets; t.F_dom = c__dom; t.F_ss = c__ss }
//line :498:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_A) Invoke_O_O__O(self, s__400000360__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2283 any = A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_A_New_O_O_O_O_O_O(self, t.F_base, t.F_split_sets, t.F_dom, t.F_ss, s__400000360__1); var tmp2 *jrt.Class; var fncls__2282 *jrt.Class = A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_A_fn_class; if fncls__2282 == nil { var fncls__2282d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_111, false, fnbody__2283); A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_A_fn_class = fncls__2282d; tmp2 = fncls__2282d } else { tmp2 = fncls__2282 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2283, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :498:1
func A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :498:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_A) Ctor_O_O_O_O_O_O(c__iter__400000359, c__base, c__split_sets, c__dom, c__ss, c__s__400000360 any) { t.F_iter__400000359 = c__iter__400000359; t.F_base = c__base; t.F_split_sets = c__split_sets; t.F_dom = c__dom; t.F_ss = c__ss; t.F_s__400000360 = c__s__400000360 }
//line :498:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_A) Invoke_O__O(self any) any { { var s__400000360__1 any; var t_ any = t.F_s__400000360; t.F_s__400000360 = nil; s__400000360__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2137 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2137, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2139 lang.IFn; if linked_2138 == nil { ifn_2139 = lang.IFn_Cast(root_2137) } else { ifn_2139 = nil }; var arg_2140 any = s__400000360__1; if linked_2138 == nil { temp__1927000414__auto____2 = ifn_2139.Invoke_O__O(arg_2140) } else { temp__1927000414__auto____2 = linked_2138.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2137, arg_2140) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_2141 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2141, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2143 lang.IFn; if linked_2142 == nil { ifn_2143 = lang.IFn_Cast(root_2141) } else { ifn_2143 = nil }; var arg_2144 any = xs__1927001018__auto____3; if linked_2142 == nil { c__4 = ifn_2143.Invoke_O__O(arg_2144) } else { c__4 = linked_2142.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2141, arg_2144) }; var iterys__1927001035__auto____5 any; var fnbody__2264 any = A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_A_New_O_O_O_O(t.F_base, t.F_dom, t.F_ss, c__4); var tmp1 *jrt.Class; var fncls__2263 *jrt.Class = A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_A_fn_class; if fncls__2263 == nil { var fncls__2263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, fnbody__2264); A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_A_fn_class = fncls__2263d; tmp1 = fncls__2263d } else { tmp1 = fncls__2263 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2264, tmp1, nil); var fs__1927001036__auto____6 any; var root_2265 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2265, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2267 lang.IFn; if linked_2266 == nil { ifn_2267 = lang.IFn_Cast(root_2265) } else { ifn_2267 = nil }; var arg_2268 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(t.F_split_sets); if linked_2266 == nil { fs__1927001036__auto____6 = ifn_2267.Invoke_O__O(arg_2268) } else { fs__1927001036__auto____6 = linked_2266.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2265, arg_2268) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_2269 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2270 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2269, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2271 lang.IFn; if linked_2270 == nil { ifn_2271 = lang.IFn_Cast(root_2269) } else { ifn_2271 = nil }; var arg_2272 any = fs__1927001036__auto____6; var arg_2273 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_iter__400000359); var tmp3 any; var root_2274 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2274, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2276 lang.IFn; if linked_2275 == nil { ifn_2276 = lang.IFn_Cast(root_2274) } else { ifn_2276 = nil }; var arg_2277 any = s__400000360__1; if linked_2275 == nil { tmp3 = ifn_2276.Invoke_O__O(arg_2277) } else { tmp3 = linked_2275.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2274, arg_2277) }; arg_2273 = tmp2.Invoke_O__O(tmp3); if linked_2270 == nil { return ifn_2271.Invoke_O_O__O(arg_2272, arg_2273) } else { return linked_2270.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2269, arg_2272, arg_2273) } } else { var tmp4 any; var root_2278 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2278, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2280 lang.IFn; if linked_2279 == nil { ifn_2280 = lang.IFn_Cast(root_2278) } else { ifn_2280 = nil }; var arg_2281 any = s__400000360__1; if linked_2279 == nil { tmp4 = ifn_2280.Invoke_O__O(arg_2281) } else { tmp4 = linked_2279.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2278, arg_2281) }; s__400000360__1 = tmp4; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :498:1
func A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :498:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_A) Ctor_O_O_O_O(c__base, c__dom, c__ss, c__c any) { t.F_base = c__base; t.F_dom = c__dom; t.F_ss = c__ss; t.F_c = c__c }
//line :498:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_A) Invoke_O_O__O(self, s__400000362__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2262 any = A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_A_New_O_O_O_O_O_O(t.F_base, t.F_dom, self, t.F_ss, t.F_c, s__400000362__1); var tmp2 *jrt.Class; var fncls__2261 *jrt.Class = A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_A_fn_class; if fncls__2261 == nil { var fncls__2261d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, fnbody__2262); A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_A_fn_class = fncls__2261d; tmp2 = fncls__2261d } else { tmp2 = fncls__2261 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2262, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :498:1
func A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :498:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_A) Ctor_O_O_O_O_O_O(c__base, c__dom, c__iter__400000361, c__ss, c__c, c__s__400000362 any) { t.F_base = c__base; t.F_dom = c__dom; t.F_iter__400000361 = c__iter__400000361; t.F_ss = c__ss; t.F_c = c__c; t.F_s__400000362 = c__s__400000362 }
//line :498:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_A) Invoke_O__O(self any) any { { var s__400000362__1 any; var t_ any = t.F_s__400000362; t.F_s__400000362 = nil; s__400000362__1 = t_; for { var temp__1927000414__auto____2 any; var root_2145 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2145, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2147 lang.IFn; if linked_2146 == nil { ifn_2147 = lang.IFn_Cast(root_2145) } else { ifn_2147 = nil }; var arg_2148 any = s__400000362__1; if linked_2146 == nil { temp__1927000414__auto____2 = ifn_2147.Invoke_O__O(arg_2148) } else { temp__1927000414__auto____2 = linked_2146.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2145, arg_2148) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000362__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2149 any = A_arbace_c2j_node_A_const_380.GetRawRoot__O(); var linked_2150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2149, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2151 lang.IFn; if linked_2150 == nil { ifn_2151 = lang.IFn_Cast(root_2149) } else { ifn_2151 = nil }; var arg_2152 any = s__400000362__3; if linked_2150 == nil { tmp1 = ifn_2151.Invoke_O__O(arg_2152) } else { tmp1 = linked_2150.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2149, arg_2152) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2153 any = A_arbace_c2j_node_A_const_381.GetRawRoot__O(); var linked_2154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2153, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2155 lang.IFn; if linked_2154 == nil { ifn_2155 = lang.IFn_Cast(root_2153) } else { ifn_2155 = nil }; var arg_2156 any = s__400000362__3; if linked_2154 == nil { c__1927001037__auto____4 = ifn_2155.Invoke_O__O(arg_2156) } else { c__1927001037__auto____4 = linked_2154.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2153, arg_2156) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000364__6 any; var root_2157 any = A_arbace_c2j_node_A_const_382.GetRawRoot__O(); var linked_2158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2157, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2159 lang.IFn; if linked_2158 == nil { ifn_2159 = lang.IFn_Cast(root_2157) } else { ifn_2159 = nil }; var arg_2160 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2158 == nil { b__400000364__6 = ifn_2159.Invoke_O__O(arg_2160) } else { b__400000364__6 = linked_2158.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2157, arg_2160) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2196 any = A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_A_New_O_O_O_I_O_O_O(b__400000364__6, t.F_base, t.F_dom, size__1927001038__auto____5, t.F_ss, c__1927001037__auto____4, t.F_c); var tmp3 *jrt.Class; var fncls__2195 *jrt.Class = A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_A_fn_class; if fncls__2195 == nil { var fncls__2195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, fnbody__2196); A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_A_fn_class = fncls__2195d; tmp3 = fncls__2195d } else { tmp3 = fncls__2195 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2196, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2197 any = A_arbace_c2j_node_A_const_384.GetRawRoot__O(); var linked_2198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2197, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2199 lang.IFn; if linked_2198 == nil { ifn_2199 = lang.IFn_Cast(root_2197) } else { ifn_2199 = nil }; var arg_2200 any; var root_2202 any = A_arbace_c2j_node_A_const_385.GetRawRoot__O(); var linked_2203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2202, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2204 lang.IFn; if linked_2203 == nil { ifn_2204 = lang.IFn_Cast(root_2202) } else { ifn_2204 = nil }; var arg_2205 any = b__400000364__6; if linked_2203 == nil { arg_2200 = ifn_2204.Invoke_O__O(arg_2205) } else { arg_2200 = linked_2203.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2202, arg_2205) }; var arg_2201 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000361); var tmp5 any; var root_2206 any = A_arbace_c2j_node_A_const_386.GetRawRoot__O(); var linked_2207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2206, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2208 lang.IFn; if linked_2207 == nil { ifn_2208 = lang.IFn_Cast(root_2206) } else { ifn_2208 = nil }; var arg_2209 any = s__400000362__3; if linked_2207 == nil { tmp5 = ifn_2208.Invoke_O__O(arg_2209) } else { tmp5 = linked_2207.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2206, arg_2209) }; arg_2201 = tmp4.Invoke_O__O(tmp5); if linked_2198 == nil { return ifn_2199.Invoke_O_O__O(arg_2200, arg_2201) } else { return linked_2198.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2197, arg_2200, arg_2201) } } else { var root_2210 any = A_arbace_c2j_node_A_const_384.GetRawRoot__O(); var linked_2211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2210, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2212 lang.IFn; if linked_2211 == nil { ifn_2212 = lang.IFn_Cast(root_2210) } else { ifn_2212 = nil }; var arg_2213 any; var root_2215 any = A_arbace_c2j_node_A_const_385.GetRawRoot__O(); var linked_2216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2215, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2217 lang.IFn; if linked_2216 == nil { ifn_2217 = lang.IFn_Cast(root_2215) } else { ifn_2217 = nil }; var arg_2218 any = b__400000364__6; if linked_2216 == nil { arg_2213 = ifn_2217.Invoke_O__O(arg_2218) } else { arg_2213 = linked_2216.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2215, arg_2218) }; var arg_2214 any; if linked_2211 == nil { return ifn_2212.Invoke_O_O__O(arg_2213, arg_2214) } else { return linked_2211.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2210, arg_2213, arg_2214) } } } else { var sp__4 any; var root_2219 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2219, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2221 lang.IFn; if linked_2220 == nil { ifn_2221 = lang.IFn_Cast(root_2219) } else { ifn_2221 = nil }; var arg_2222 any = s__400000362__3; if linked_2220 == nil { sp__4 = ifn_2221.Invoke_O__O(arg_2222) } else { sp__4 = linked_2220.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2219, arg_2222) }; var root_2223 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2223, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2225 lang.IFn; if linked_2224 == nil { ifn_2225 = lang.IFn_Cast(root_2223) } else { ifn_2225 = nil }; var arg_2226 any; var tmp6 any = A_arbace_c2j_node_A_const_328; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp8 any = t.F_base; var tmp9 any
																			if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_c2j_node_A_const_220, t.F_c) { tmp9 = Lit_115 } else { var tmp10 any; var root_2228 any = A_arbace_c2j_node_A_const_393.GetRawRoot__O(); var linked_2229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2228, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2230 lang.IFn; if linked_2229 == nil { ifn_2230 = lang.IFn_Cast(root_2228) } else { ifn_2230 = nil }; var arg_2231 any = t.F_c; if linked_2229 == nil { tmp10 = ifn_2230.Invoke_O__O(arg_2231) } else { tmp10 = linked_2229.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2228, arg_2231) }; if jrt.J2g_Truth(tmp10) { tmp9 = t.F_c } else { if A_arbace_c2j_node_A_const_45 != nil { tmp9 = Lit_116 } else { tmp9 = nil } } }
//line :498:1
	var tmp11 any = tmp9; var tmp12 any; var root_2232 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_2233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2232, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2234 lang.IFn

	if linked_2233 == nil { ifn_2234 = lang.IFn_Cast(root_2232) } else { ifn_2234 = nil }; var arg_2235 any = A_arbace_c2j_node_A_const_188.GetRawRoot__O(); var arg_2236 any; var root_2237 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2237, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2239 lang.IFn; if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any; var fnbody__2247 any = A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000373_A_New_O(sp__4); var tmp13 *jrt.Class; var fncls__2246 *jrt.Class = A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000373_A_fn_class; if fncls__2246 == nil { var fncls__2246d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, fnbody__2247); A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000373_A_fn_class = fncls__2246d; tmp13 = fncls__2246d } else { tmp13 = fncls__2246 }; arg_2240 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2247, tmp13, nil); var arg_2241 any = t.F_ss; if linked_2238 == nil { arg_2236 = ifn_2239.Invoke_O_O__O(arg_2240, arg_2241) } else { arg_2236 = linked_2238.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2237, arg_2240, arg_2241) }; if linked_2233 == nil { tmp12 = ifn_2234.Invoke_O_O__O(arg_2235, arg_2236) } else { tmp12 = linked_2233.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2232, arg_2235, arg_2236) }
//line :498:1
	var tmp14 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp11, tmp12)).Ref(); var tmp15 any = A_arbace_c2j_node_A_const_234; var tmp16 any = A_arbace_c2j_node_A_const_221; var tmp17 any = t.F_c; var tmp18 any = A_arbace_c2j_node_A_const_320; var tmp19 any



	if jrt.J2g_Truth(t.F_dom) { var root_2248 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2248, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2250 lang.IFn; if linked_2249 == nil { ifn_2250 = lang.IFn_Cast(root_2248) } else { ifn_2250 = nil }; var arg_2251 any; var root_2252 any = A_arbace_c2j_node_A_const_281.GetRawRoot__O(); var linked_2253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2252, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2254 lang.IFn; if linked_2253 == nil { ifn_2254 = lang.IFn_Cast(root_2252) } else { ifn_2254 = nil }; var arg_2255 any = A_arbace_c2j_node_A_const_394.GetRawRoot__O(); var arg_2256 any = lang.RT_Get_O_O__O_NoInit(t.F_dom, t.F_c); if linked_2253 == nil { arg_2251 = ifn_2254.Invoke_O_O__O(arg_2255, arg_2256) } else { arg_2251 = linked_2253.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2252, arg_2255, arg_2256) }; if linked_2249 == nil { tmp19 = ifn_2250.Invoke_O__O(arg_2251) } else { tmp19 = linked_2249.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2248, arg_2251) } } else { tmp19 = nil }
//line :498:1
	arg_2226 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp14, tmp15, sp__4, tmp16, tmp17, tmp18, tmp19)); var arg_2227 any; var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__400000361); var tmp21 any; var root_2257 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2257, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2259 lang.IFn; if linked_2258 == nil { ifn_2259 = lang.IFn_Cast(root_2257) } else { ifn_2259 = nil }; var arg_2260 any = s__400000362__3; if linked_2258 == nil { tmp21 = ifn_2259.Invoke_O__O(arg_2260) } else { tmp21 = linked_2258.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2257, arg_2260) }; arg_2227 = tmp20.Invoke_O__O(tmp21); if linked_2224 == nil { return ifn_2225.Invoke_O_O__O(arg_2226, arg_2227) } else { return linked_2224.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2223, arg_2226, arg_2227) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :498:1
func A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_A_New_O_O_O_I_O_O_O(p0, p1, p2 any, p3 int32, p4, p5, p6 any) *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_A{}; t.Ctor_O_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :498:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_A) Ctor_O_O_O_I_O_O_O(c__b__400000364, c__base, c__dom any, c__size__1927001038__auto__ int32, c__ss, c__c__1927001037__auto__, c__c any) { t.F_b__400000364 = c__b__400000364; t.F_base = c__base; t.F_dom = c__dom; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ss = c__ss; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_c = c__c }
//line :498:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_A) Invoke_O__O(self any) any { { var i__400000363__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000363__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var sp__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000363__1)); var root_2161 any = A_arbace_c2j_node_A_const_383.GetRawRoot__O(); var linked_2162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2161, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2163 lang.IFn; if linked_2162 == nil { ifn_2163 = lang.IFn_Cast(root_2161) } else { ifn_2163 = nil }; var arg_2164 any = t.F_b__400000364; var arg_2165 any; var tmp2 any = A_arbace_c2j_node_A_const_328; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp4 any = t.F_base; var tmp5 any
																					if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_c2j_node_A_const_220, t.F_c) { tmp5 = Lit_115 } else { var tmp6 any; var root_2166 any = A_arbace_c2j_node_A_const_393.GetRawRoot__O(); var linked_2167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2166, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2168 lang.IFn; if linked_2167 == nil { ifn_2168 = lang.IFn_Cast(root_2166) } else { ifn_2168 = nil }; var arg_2169 any = t.F_c; if linked_2167 == nil { tmp6 = ifn_2168.Invoke_O__O(arg_2169) } else { tmp6 = linked_2167.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2166, arg_2169) }; if jrt.J2g_Truth(tmp6) { tmp5 = t.F_c } else { if A_arbace_c2j_node_A_const_45 != nil { tmp5 = Lit_116 } else { tmp5 = nil } } }
//line :498:1
	var tmp7 any = tmp5; var tmp8 any; var root_2170 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_2171 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2170, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2172 lang.IFn

	if linked_2171 == nil { ifn_2172 = lang.IFn_Cast(root_2170) } else { ifn_2172 = nil }; var arg_2173 any = A_arbace_c2j_node_A_const_188.GetRawRoot__O(); var arg_2174 any; var root_2175 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any; var fnbody__2185 any = A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_fn__400000370_A_New_O(sp__2); var tmp9 *jrt.Class; var fncls__2184 *jrt.Class = A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_fn__400000370_A_fn_class; if fncls__2184 == nil { var fncls__2184d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_118, false, fnbody__2185); A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_fn__400000370_A_fn_class = fncls__2184d; tmp9 = fncls__2184d } else { tmp9 = fncls__2184 }; arg_2178 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2185, tmp9, nil); var arg_2179 any = t.F_ss; if linked_2176 == nil { arg_2174 = ifn_2177.Invoke_O_O__O(arg_2178, arg_2179) } else { arg_2174 = linked_2176.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2175, arg_2178, arg_2179) }; if linked_2171 == nil { tmp8 = ifn_2172.Invoke_O_O__O(arg_2173, arg_2174) } else { tmp8 = linked_2171.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2170, arg_2173, arg_2174) }
//line :498:1
	var tmp10 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8)).Ref(); var tmp11 any = A_arbace_c2j_node_A_const_234; var tmp12 any = A_arbace_c2j_node_A_const_221; var tmp13 any = t.F_c; var tmp14 any = A_arbace_c2j_node_A_const_320; var tmp15 any



	if jrt.J2g_Truth(t.F_dom) { var root_2186 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2188 lang.IFn; if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any; var root_2190 any = A_arbace_c2j_node_A_const_281.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any = A_arbace_c2j_node_A_const_394.GetRawRoot__O(); var arg_2194 any = lang.RT_Get_O_O__O_NoInit(t.F_dom, t.F_c); if linked_2191 == nil { arg_2189 = ifn_2192.Invoke_O_O__O(arg_2193, arg_2194) } else { arg_2189 = linked_2191.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2190, arg_2193, arg_2194) }; if linked_2187 == nil { tmp15 = ifn_2188.Invoke_O__O(arg_2189) } else { tmp15 = linked_2187.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2186, arg_2189) } } else { tmp15 = nil }
//line :498:1
	arg_2165 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp10, tmp11, sp__2, tmp12, tmp13, tmp14, tmp15)); if linked_2162 == nil { ifn_2163.Invoke_O_O__O(arg_2164, arg_2165) } else { linked_2162.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2161, arg_2164, arg_2165) }; i__400000363__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000363__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_fn__400000370_A_New_O(p0 any) *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_fn__400000370_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_fn__400000370_A{}; t.Ctor_O(p0); return t }
//line :500:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_fn__400000370_A) Ctor_O(c__sp any) { t.F_sp = c__sp }
//line :500:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_fn__400000370_A) Invoke_O_O__O(self, s__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_sp).Invoke_O__O(s__1)) { var root_2180 any = A_arbace_c2j_node_A_const_375.GetRawRoot__O(); var linked_2181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2180, A_arbace_c2j_node_camel_A_fn_class); var ifn_2182 lang.IFn; if linked_2181 == nil { ifn_2182 = lang.IFn_Cast(root_2180) } else { ifn_2182 = nil }; var arg_2183 any = s__1; if linked_2181 == nil { return ifn_2182.Invoke_O__O(arg_2183) } else { return linked_2181.(*A_arbace_c2j_node_camel_A).Invoke_O_O__O(root_2180, arg_2183) } } else { return nil } }
//line :500:1
func A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000373_A_New_O(p0 any) *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000373_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000373_A{}; t.Ctor_O(p0); return t }
//line :500:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000373_A) Ctor_O(c__sp any) { t.F_sp = c__sp }
//line :500:1
func (t *A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000373_A) Invoke_O_O__O(self, s__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_sp).Invoke_O__O(s__1)) { var root_2242 any = A_arbace_c2j_node_A_const_375.GetRawRoot__O(); var linked_2243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2242, A_arbace_c2j_node_camel_A_fn_class); var ifn_2244 lang.IFn; if linked_2243 == nil { ifn_2244 = lang.IFn_Cast(root_2242) } else { ifn_2244 = nil }; var arg_2245 any = s__1; if linked_2243 == nil { return ifn_2244.Invoke_O__O(arg_2245) } else { return linked_2243.(*A_arbace_c2j_node_camel_A).Invoke_O_O__O(root_2242, arg_2245) } } else { return nil } }



func A_arbace_c2j_node_clause_A_New() *A_arbace_c2j_node_clause_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_A{}; t.Ctor(); return t }
//line :504:1
func (t *A_arbace_c2j_node_clause_A) Ctor() {}
//line :504:1
func (t *A_arbace_c2j_node_clause_A) Invoke_O_O_O__O(self, d__0, vs__1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_396; var exprs__3 any = tmp1.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0)); var one__4 any; if




	lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(exprs__3))) { var root_2286 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2286, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2288 lang.IFn; if linked_2287 == nil { ifn_2288 = lang.IFn_Cast(root_2286) } else { ifn_2288 = nil }; var arg_2289 any = exprs__3; if linked_2287 == nil { one__4 = ifn_2288.Invoke_O__O(arg_2289) } else { one__4 = linked_2287.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2286, arg_2289) } } else { one__4 = nil }; var test__5 any; if
	jrt.J2g_Truth(one__4) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_node_A_const_417; var tmp4 any; var root_2462 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_2463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2462, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2464 lang.IFn; if linked_2463 == nil { ifn_2464 = lang.IFn_Cast(root_2462) } else { ifn_2464 = nil }; var arg_2465 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, one__4)).Ref(); if linked_2463 == nil { tmp4 = ifn_2464.Invoke_O__O(arg_2465) } else { tmp4 = linked_2463.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2462, arg_2465) }; test__5 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_c2j_node_A_const_418) } else {
			var root_2290 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2290, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2292 lang.IFn; if linked_2291 == nil { ifn_2292 = lang.IFn_Cast(root_2290) } else { ifn_2292 = nil }; var arg_2293 any = A_arbace_c2j_node_A_const_397; var arg_2294 any; var root_2295 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_2296 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2295, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2297 lang.IFn; if linked_2296 == nil { ifn_2297 = lang.IFn_Cast(root_2295) } else { ifn_2297 = nil }; var arg_2298 any; var fnbody__2305 any = A_arbace_c2j_node_clause_fn__400000383_A_New(); var tmp5 *jrt.Class; var fncls__2304 *jrt.Class = A_arbace_c2j_node_clause_fn__400000383_A_fn_class; if fncls__2304 == nil { var fncls__2304d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_c2j_node_clause_fn__400000383_A_fn_class = fncls__2304d; tmp5 = fncls__2304d } else { tmp5 = fncls__2304 }; arg_2298 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2305, tmp5, nil); var arg_2299 any = exprs__3; if linked_2296 == nil { arg_2294 = ifn_2297.Invoke_O_O__O(arg_2298, arg_2299) } else { arg_2294 = linked_2296.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2295, arg_2298, arg_2299) }; if linked_2291 == nil { test__5 = ifn_2292.Invoke_O_O__O(arg_2293, arg_2294) } else { test__5 = linked_2291.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2290, arg_2293, arg_2294) } }; var fields__6 any; var root_2306 any = /*line :504:1*/A_arbace_c2j_node_A_const_166.GetRawRoot__O(); var linked_2307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2306, A_arbace_c2j_node_field_names_A_fn_class); var ifn_2308 lang.IFn; if








	linked_2307 == nil { ifn_2308 = lang.IFn_Cast(root_2306) } else { ifn_2308 = nil }; var arg_2309 any = d__0; if linked_2307 == nil { fields__6 = ifn_2308.Invoke_O__O(arg_2309) } else { fields__6 = linked_2307.(*A_arbace_c2j_node_field_names_A).Invoke_O_O__O(root_2306, arg_2309) }; var fbinds__7 any; var tmp6 lang.IFn = /*line :504:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp7 *lang.Compiler_AOTFn; var fnbody__2320 any = A_arbace_c2j_node_clause_fn__400000385_A_New(); var tmp8 *jrt.Class; var fncls__2319 *jrt.Class = A_arbace_c2j_node_clause_fn__400000385_A_fn_class; if









	fncls__2319 == nil { var fncls__2319d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_c2j_node_clause_fn__400000385_A_fn_class = fncls__2319d; tmp8 = fncls__2319d } else { tmp8 = fncls__2319 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2320, tmp8, nil); fbinds__7 = tmp6.Invoke_O_O__O(tmp7.Ref(), fields__6); var cb__8 any; var root_2321 any = /*line :504:1*/A_arbace_c2j_node_A_const_334.GetRawRoot__O(); var linked_2322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2321, A_arbace_c2j_node_children_bind_A_fn_class); var ifn_2323 lang.IFn; if










	linked_2322 == nil { ifn_2323 = lang.IFn_Cast(root_2321) } else { ifn_2323 = nil }; var arg_2324 any = d__0; if linked_2322 == nil { cb__8 = ifn_2323.Invoke_O__O(arg_2324) } else { cb__8 = linked_2322.(*A_arbace_c2j_node_children_bind_A).Invoke_O_O__O(root_2321, arg_2324) }; var conv__9 any; if
	jrt.J2g_Truth(cb__8) { var tmp9 *lang.Keyword = A_arbace_c2j_node_A_const_335; var tmp10 any; var root_2325 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2325, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2327 lang.IFn; if linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any = A_arbace_c2j_node_A_const_242.GetRawRoot__O(); var arg_2329 any; var root_2330 any = A_arbace_c2j_node_A_const_336.GetRawRoot__O(); var linked_2331 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2330, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2332 lang.IFn; if linked_2331 == nil { ifn_2332 = lang.IFn_Cast(root_2330) } else { ifn_2332 = nil }; var arg_2334 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(cb__8); if linked_2331 == nil { arg_2329 = ifn_2332.Invoke_O_O__O(A_arbace_c2j_node_A_const_25, arg_2334) } else { arg_2329 = linked_2331.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2330, 2, A_arbace_c2j_node_A_const_25, arg_2334) }; if linked_2326 == nil { tmp10 = ifn_2327.Invoke_O_O__O(arg_2328, arg_2329) } else { tmp10 = linked_2326.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2325, arg_2328, arg_2329) }; conv__9 = tmp9.Invoke_O__O(tmp10) } else { conv__9 = nil }; var binds__10 any; var root_2335 any = /*line :504:1*/A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2335, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2337 lang.IFn; if












	linked_2336 == nil { ifn_2337 = lang.IFn_Cast(root_2335) } else { ifn_2337 = nil }; var arg_2338 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp12 lang.IPersistentVector; if
	jrt.J2g_Truth(one__4) { var tmp13 any = A_arbace_c2j_node_A_const_401; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_node_A_const_402; var tmp16 any; var root_2346 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_2347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2346, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2348 lang.IFn; if linked_2347 == nil { ifn_2348 = lang.IFn_Cast(root_2346) } else { ifn_2348 = nil }; var arg_2349 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, one__4)).Ref(); if linked_2347 == nil { tmp16 = ifn_2348.Invoke_O__O(arg_2349) } else { tmp16 = linked_2347.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2346, arg_2349) }; tmp12 = lang.Tuple_Create_O_O__IPersistentVector(tmp13, tmp14.Invoke_O_O_O__O(tmp15, tmp16, A_arbace_c2j_node_A_const_403)) } else { tmp12 = nil }; var tmp17 any = tmp12; var tmp18 lang.IFn = /*line :517:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp19 *lang.Compiler_AOTFn; var fnbody__2369 any = A_arbace_c2j_node_clause_fn__400000387_A_New(); var tmp20 *jrt.Class; var fncls__2368 *jrt.Class = A_arbace_c2j_node_clause_fn__400000387_A_fn_class; if


	fncls__2368 == nil { var fncls__2368d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); A_arbace_c2j_node_clause_fn__400000387_A_fn_class = fncls__2368d; tmp20 = fncls__2368d } else { tmp20 = fncls__2368 }; tmp19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2369, tmp20, nil); var tmp21 any = /*line :517:1*/tmp18.Invoke_O_O__O(tmp19.Ref(), A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0)); var tmp22 lang.IPersistentVector; if








	jrt.J2g_Truth(conv__9) { tmp22 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_c2j_node_A_const_409, conv__9) } else { tmp22 = nil }; arg_2338 = /*line :517:1*/tmp11.Invoke_O_O_O_O__O(tmp17, fbinds__7, tmp21, tmp22); if linked_2336 == nil { binds__10 = ifn_2337.Invoke_O__O(arg_2338) } else { binds__10 = linked_2336.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2335, arg_2338) }; var ss__11 any; var root_2370 any = /*line :504:1*/A_arbace_c2j_node_A_const_376.GetRawRoot__O(); var linked_2371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2370, A_arbace_c2j_node_splits_A_fn_class); var ifn_2372 lang.IFn; if






















	linked_2371 == nil { ifn_2372 = lang.IFn_Cast(root_2370) } else { ifn_2372 = nil }; var arg_2373 any = d__0; if linked_2371 == nil { ss__11 = ifn_2372.Invoke_O__O(arg_2373) } else { ss__11 = linked_2371.(*A_arbace_c2j_node_splits_A).Invoke_O_O__O(root_2370, arg_2373) }; var construct__12 any; var fnbody__2390 any = /*line :504:1*/A_arbace_c2j_node_clause_construct__400000391_A_New(); var tmp23 *jrt.Class; var fncls__2389 *jrt.Class = A_arbace_c2j_node_clause_construct__400000391_A_fn_class; if























	fncls__2389 == nil { var fncls__2389d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); A_arbace_c2j_node_clause_construct__400000391_A_fn_class = fncls__2389d; tmp23 = fncls__2389d } else { tmp23 = fncls__2389 }; construct__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2390, tmp23, nil); var pick__13 any; var fnbody__2436 any = /*line :504:1*/A_arbace_c2j_node_clause_pick__400000396_A_New_O_O(construct__12, ss__11); var tmp24 *jrt.Class; var fncls__2435 *jrt.Class = A_arbace_c2j_node_clause_pick__400000396_A_fn_class; if
























	fncls__2435 == nil { var fncls__2435d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__2436); A_arbace_c2j_node_clause_pick__400000396_A_fn_class = fncls__2435d; tmp24 = fncls__2435d } else { tmp24 = fncls__2435 }; pick__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2436, tmp24, nil); var by_count__14 any; var root_2437 any = /*line :504:1*/A_arbace_c2j_node_A_const_412.GetRawRoot__O(); var linked_2438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2437, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_2439 lang.IFn; if


































	linked_2438 == nil { ifn_2439 = lang.IFn_Cast(root_2437) } else { ifn_2439 = nil }; var arg_2440 any; var root_2442 any = A_arbace_c2j_node_A_const_413.GetRawRoot__O(); var linked_2443 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2442, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_2444 lang.IFn; if linked_2443 == nil { ifn_2444 = lang.IFn_Cast(root_2442) } else { ifn_2444 = nil }; var arg_2445 any = A_arbace_c2j_node_A_const_221; var arg_2446 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); if linked_2443 == nil { arg_2440 = ifn_2444.Invoke_O_O__O(arg_2445, arg_2446) } else { arg_2440 = linked_2443.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_2442, arg_2445, arg_2446) }; var arg_2441 any = vs__1; if linked_2438 == nil { by_count__14 = ifn_2439.Invoke_O_O__O(arg_2440, arg_2441) } else { by_count__14 = linked_2438.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_2437, arg_2440, arg_2441) }; var counted__15 any; var root_2447 any = /*line :504:1*/A_arbace_c2j_node_A_const_414.GetRawRoot__O(); var linked_2448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2447, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2449 lang.IFn; if



































	linked_2448 == nil { ifn_2449 = lang.IFn_Cast(root_2447) } else { ifn_2449 = nil }; var arg_2450 any = A_arbace_c2j_node_A_const_415.GetRawRoot__O(); var arg_2451 any; var root_2452 any = A_arbace_c2j_node_A_const_32.GetRawRoot__O(); var linked_2453 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2452, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2454 lang.IFn; if linked_2453 == nil { ifn_2454 = lang.IFn_Cast(root_2452) } else { ifn_2454 = nil }; var arg_2455 any; var root_2457 any = A_arbace_c2j_node_A_const_413.GetRawRoot__O(); var linked_2458 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2457, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_2459 lang.IFn; if linked_2458 == nil { ifn_2459 = lang.IFn_Cast(root_2457) } else { ifn_2459 = nil }; var arg_2460 any = A_arbace_c2j_node_A_const_416.GetRawRoot__O(); var arg_2461 any = A_arbace_c2j_node_A_const_415.GetRawRoot__O(); if linked_2458 == nil { arg_2455 = ifn_2459.Invoke_O_O__O(arg_2460, arg_2461) } else { arg_2455 = linked_2458.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_2457, arg_2460, arg_2461) }; var arg_2456 any = by_count__14; if linked_2453 == nil { arg_2451 = ifn_2454.Invoke_O_O__O(arg_2455, arg_2456) } else { arg_2451 = linked_2453.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2452, arg_2455, arg_2456) }; if linked_2448 == nil { counted__15 = ifn_2449.Invoke_O_O__O(arg_2450, arg_2451) } else { counted__15 = linked_2448.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2447, arg_2450, arg_2451) }; var body__16 any; var tmp25 /*line :504:1*/*lang.Keyword = A_arbace_c2j_node_A_const_388; if




































	jrt.J2g_Truth(tmp25.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0))) {

		var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp27 any = A_arbace_c2j_node_A_const_419; var tmp28 any = A_arbace_c2j_node_A_const_424; var tmp29 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_426, A_arbace_c2j_node_A_const_427, A_arbace_c2j_node_A_const_428); var tmp30 any = A_arbace_c2j_node_A_const_425; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp32 any = A_arbace_c2j_node_A_const_429; var tmp33 any = A_arbace_c2j_node_A_const_430; var tmp34 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp28, tmp29, tmp30, tmp31.Invoke_O_O_O__O(tmp32, tmp33, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_431, A_arbace_c2j_node_A_const_432, A_arbace_c2j_node_A_const_433))); var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp36 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_420); var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp38 *lang.Compiler_AOTFn; var fnbody__2478 any = A_arbace_c2j_node_clause_fn__400000405_A_New_O(pick__13); var tmp39 *jrt.Class
		var fncls__2477 /*line :543:1*/*jrt.Class = A_arbace_c2j_node_clause_fn__400000405_A_fn_class

		if fncls__2477 == nil { var fncls__2477d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__2478); A_arbace_c2j_node_clause_fn__400000405_A_fn_class = fncls__2477d; tmp39 = fncls__2477d } else { tmp39 = fncls__2477 }; tmp38 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2478, tmp39, nil)
//line :543:1
		body__16 = tmp26.Invoke_O_O_O__O(tmp27, tmp34, tmp35.Invoke_O_O_O__O(tmp36, tmp37.Invoke_O_O__O(tmp38.Ref(), counted__15), A_arbace_c2j_node_A_const_423)) } else {
//line :541:1
			if jrt.J2g_Truth(cb__8) {





				var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp41 any = A_arbace_c2j_node_A_const_434; var tmp42 any = A_arbace_c2j_node_A_const_438; var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp44 any = A_arbace_c2j_node_A_const_439; var tmp45 any; var root_2492 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2492, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2494 lang.IFn; if linked_2493 == nil { ifn_2494 = lang.IFn_Cast(root_2492) } else { ifn_2494 = nil }; var arg_2495 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(cb__8); if linked_2493 == nil { tmp45 = ifn_2494.Invoke_O__O(arg_2495) } else { tmp45 = linked_2493.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2492, arg_2495) }; var tmp46 any = lang.Tuple_Create_O_O__IPersistentVector(tmp42, tmp43.Invoke_O_O__O(tmp44, tmp45)); var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp48 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_435); var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp50 *lang.Compiler_AOTFn; var fnbody__2491 any = A_arbace_c2j_node_clause_fn__400000411_A_New_O(pick__13); var tmp51 *jrt.Class; var fncls__2490 *jrt.Class = A_arbace_c2j_node_clause_fn__400000411_A_fn_class
				if fncls__2490 == nil { var fncls__2490d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__2491); A_arbace_c2j_node_clause_fn__400000411_A_fn_class = fncls__2490d; tmp51 = fncls__2490d } else { tmp51 = fncls__2490 }; tmp50 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2491, tmp51, nil)
//line :547:1
				var tmp52 any = tmp49.Invoke_O_O__O(tmp50.Ref(), counted__15); var tmp53 any = A_arbace_c2j_node_A_const_45; var tmp54 any; var temp__1927000414__auto____16 any = lang.IFn_Cast(by_count__14).Invoke_O__O(A_arbace_c2j_node_A_const_220)

				if jrt.J2g_Truth(temp__1927000414__auto____16) { var m__17 any = temp__1927000414__auto____16; tmp54 = lang.IFn_Cast(pick__13).Invoke_O__O(m__17) } else { tmp54 = nil }
//line :547:1
				body__16 = tmp40.Invoke_O_O_O__O(tmp41, tmp46, tmp47.Invoke_O_O_O__O(tmp48, tmp52, lang.Tuple_Create_O_O__IPersistentVector(tmp53, tmp54))) } else {
//line :541:1
					if A_arbace_c2j_node_A_const_45 != nil {








						body__16 = lang.IFn_Cast(pick__13).Invoke_O__O(vs__1) } else {
//line :541:1
							body__16 = nil } } }; var tmp55 any; var tmp56 /*line :504:1*/*lang.Keyword = A_arbace_c2j_node_A_const_440; var tmp57 *lang.Keyword = A_arbace_c2j_node_A_const_388; var temp__1927000408__auto____17 any = tmp56.Invoke_O__O(tmp57.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0))); if














































	jrt.J2g_Truth(temp__1927000408__auto____17) { var ix__18 any = temp__1927000408__auto____17; var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp59 any = A_arbace_c2j_node_A_const_441; var tmp60 any; var root_2496 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2496, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2498 lang.IFn
		if linked_2497 == nil { ifn_2498 = lang.IFn_Cast(root_2496) } else { ifn_2498 = nil }; var arg_2499 any; var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp62 any = A_arbace_c2j_node_A_const_442; var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp64 any = A_arbace_c2j_node_A_const_443; var tmp65 any; var root_2506 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_2507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2506, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2508 lang.IFn; if linked_2507 == nil { ifn_2508 = lang.IFn_Cast(root_2506) } else { ifn_2508 = nil }; var arg_2509 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, one__4)).Ref(); if linked_2507 == nil { tmp65 = ifn_2508.Invoke_O__O(arg_2509) } else { tmp65 = linked_2507.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2506, arg_2509) }; arg_2499 = tmp61.Invoke_O_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp62, tmp63.Invoke_O_O_O__O(tmp64, tmp65, A_arbace_c2j_node_A_const_444)), fbinds__7, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_c2j_node_A_const_445, ix__18)); if linked_2497 == nil { tmp60 = ifn_2498.Invoke_O__O(arg_2499) } else { tmp60 = linked_2497.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2496, arg_2499) }; var tmp66 any = tmp60; var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp68 any = A_arbace_c2j_node_A_const_446; var tmp69 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_447, A_arbace_c2j_node_A_const_448, A_arbace_c2j_node_A_const_253); var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp71 any = A_arbace_c2j_node_A_const_449; var tmp72 any; var root_2510 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2510, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2512 lang.IFn
		if linked_2511 == nil { ifn_2512 = lang.IFn_Cast(root_2510) } else { ifn_2512 = nil }; var arg_2513 any; var root_2514 any = A_arbace_c2j_node_A_const_336.GetRawRoot__O(); var linked_2515 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2514, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2516 lang.IFn; if linked_2515 == nil { ifn_2516 = lang.IFn_Cast(root_2514) } else { ifn_2516 = nil }; var arg_2517 int64 = lang.Numbers_Add_J_J__J_NoInit(2, int64(lang.RT_Count_O__I_NoInit(fbinds__7))); var arg_2518 any = binds__10; if linked_2515 == nil { arg_2513 = ifn_2516.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_2517).Ref(), arg_2518) } else { arg_2513 = linked_2515.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2514, arg_2517, nil, arg_2518) }; if linked_2511 == nil { tmp72 = ifn_2512.Invoke_O__O(arg_2513) } else { tmp72 = linked_2511.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2510, arg_2513) }
//line :552:1
		tmp55 = tmp58.Invoke_O_O_O__O(tmp59, tmp66, tmp67.Invoke_O_O_O_O__O(tmp68, tmp69, nil, tmp70.Invoke_O_O_O__O(tmp71, tmp72, body__16))) } else {

			tmp55 = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_450, binds__10, body__16) }; return /*line :504:1*/ lang.Tuple_Create_O_O__IPersistentVector(test__5, tmp55) }







func A_arbace_c2j_node_clause_fn__400000383_A_New() *A_arbace_c2j_node_clause_fn__400000383_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000383_A{}; t.Ctor(); return t }
//line :512:1
func (t *A_arbace_c2j_node_clause_fn__400000383_A) Ctor() {}
//line :512:1
func (t *A_arbace_c2j_node_clause_fn__400000383_A) Invoke_O_O__O(self, p1__400000380_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_398; var tmp3 any; var root_2300 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_2301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2300, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2302 lang.IFn; if linked_2301 == nil { ifn_2302 = lang.IFn_Cast(root_2300) } else { ifn_2302 = nil }; var arg_2303 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__400000380_SHARP___1)).Ref(); if linked_2301 == nil { tmp3 = ifn_2302.Invoke_O__O(arg_2303) } else { tmp3 = linked_2301.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2300, arg_2303) }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_c2j_node_A_const_399) }

func A_arbace_c2j_node_clause_fn__400000385_A_New() *A_arbace_c2j_node_clause_fn__400000385_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000385_A{}; t.Ctor(); return t }
//line :514:1
func (t *A_arbace_c2j_node_clause_fn__400000385_A) Ctor() {}
//line :514:1
func (t *A_arbace_c2j_node_clause_fn__400000385_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any; var root_2315 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_2316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2315, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2317 lang.IFn; if linked_2316 == nil { ifn_2317 = lang.IFn_Cast(root_2315) } else { ifn_2317 = nil }; var arg_2318 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1)).Ref(); if linked_2316 == nil { tmp2 = ifn_2317.Invoke_O__O(arg_2318) } else { tmp2 = linked_2316.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2315, arg_2318) }; return lang.Tuple_Create_O_O__IPersistentVector(f__1, tmp1.Invoke_O_O__O(tmp2, A_arbace_c2j_node_A_const_400)) }





func A_arbace_c2j_node_clause_fn__400000387_A_New() *A_arbace_c2j_node_clause_fn__400000387_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000387_A{}; t.Ctor(); return t }
//line :520:1
func (t *A_arbace_c2j_node_clause_fn__400000387_A) Ctor() {}
//line :520:1
func (t *A_arbace_c2j_node_clause_fn__400000387_A) Invoke_O_O__O(self, b__1 any) any { var G__400000388__2_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__1); switch
											lang.Util_Hash_O__I_NoInit(G__400000388__2_) >> 0 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__400000388__2_, A_arbace_c2j_node_A_const_404) { var tmp1 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_node_A_const_407; var tmp4 any = A_arbace_c2j_node_A_const_408; var tmp5 any; var root_2356 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2356, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2358 lang.IFn
												if linked_2357 == nil { ifn_2358 = lang.IFn_Cast(root_2356) } else { ifn_2358 = nil }; var arg_2359 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_2357 == nil { tmp5 = ifn_2358.Invoke_O__O(arg_2359) } else { tmp5 = linked_2357.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2356, arg_2359) }
//line :521:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__400000388__2_, A_arbace_c2j_node_A_const_405) { var tmp6 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp7 any; var root_2360 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_2361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2360, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2362 lang.IFn

			if linked_2361 == nil { ifn_2362 = lang.IFn_Cast(root_2360) } else { ifn_2362 = nil }; var arg_2363 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_2361 == nil { tmp7 = ifn_2362.Invoke_O__O(arg_2363) } else { tmp7 = linked_2361.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2360, arg_2363) }
//line :521:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000388__2_, A_arbace_c2j_node_A_const_406) { var tmp8 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp9 any; var root_2364 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_2365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2364, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2366 lang.IFn

				if linked_2365 == nil { ifn_2366 = lang.IFn_Cast(root_2364) } else { ifn_2366 = nil }; var arg_2367 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_2365 == nil { tmp9 = ifn_2366.Invoke_O__O(arg_2367) } else { tmp9 = linked_2365.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2364, arg_2367) }
//line :521:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9) }; default:}; return nil }






func A_arbace_c2j_node_clause_construct__400000391_A_New() *A_arbace_c2j_node_clause_construct__400000391_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_construct__400000391_A{}; t.Ctor(); return t }
//line :528:1
func (t *A_arbace_c2j_node_clause_construct__400000391_A) Ctor() {}
//line :528:1
func (t *A_arbace_c2j_node_clause_construct__400000391_A) Invoke_O_O__O(self, p__400000390__1 any) any { var vec__400000392__2 any = p__400000390__1; var v__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000392__2, lang.RT_IntCast_J__I_NoInit(0), nil); var fields__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000392__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2374 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_2375 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2374, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_2376 lang.IFn; if linked_2375 == nil { ifn_2376 = lang.IFn_Cast(root_2374) } else { ifn_2376 = nil }; var arg_2377 any = A_arbace_c2j_node_A_const_410; var arg_2378 any; var root_2380 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_2381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2380, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2382 lang.IFn; if linked_2381 == nil { ifn_2382 = lang.IFn_Cast(root_2380) } else { ifn_2382 = nil }; var arg_2383 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_node_A_const_328.Invoke_O__O(v__3))).Ref(); if linked_2381 == nil { arg_2378 = ifn_2382.Invoke_O__O(arg_2383) } else { arg_2378 = linked_2381.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2380, arg_2383) }; var arg_2379 any; var root_2384 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_2385 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2384, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2386 lang.IFn; if linked_2385 == nil { ifn_2386 = lang.IFn_Cast(root_2384) } else { ifn_2386 = nil }; var arg_2387 any = A_arbace_c2j_node_A_const_340; var arg_2388 any = fields__4; if linked_2385 == nil { arg_2379 = ifn_2386.Invoke_O_O__O(arg_2387, arg_2388) } else { arg_2379 = linked_2385.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2384, arg_2387, arg_2388) }; if linked_2375 == nil { return ifn_2376.Invoke_O_O_O__O(arg_2377, arg_2378, arg_2379) } else { return linked_2375.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_2374, arg_2377, arg_2378, arg_2379) } }
func A_arbace_c2j_node_clause_pick__400000396_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_clause_pick__400000396_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_pick__400000396_A{}; t.Ctor_O_O(p0, p1); return t }
//line :529:1
func (t *A_arbace_c2j_node_clause_pick__400000396_A) Ctor_O_O(c__construct, c__ss any) { t.F_construct = c__construct; t.F_ss = c__ss }
//line :529:1
func (t *A_arbace_c2j_node_clause_pick__400000396_A) Invoke_O_O__O(self, vfs__1 any) any { var body_go__2 *A_arbace_c2j_node_clause_pick__400000396_go__400000397_A = A_arbace_c2j_node_clause_pick__400000396_go__400000397_A_New_O(t.F_construct); var go__2 any; var fnbody__2434 any = any(body_go__2); var tmp1 *jrt.Class; var fncls__2433 *jrt.Class = A_arbace_c2j_node_clause_pick__400000396_go__400000397_A_fn_class; if fncls__2433 == nil { var fncls__2433d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__2434); A_arbace_c2j_node_clause_pick__400000396_go__400000397_A_fn_class = fncls__2433d; tmp1 = fncls__2433d } else { tmp1 = fncls__2433 }; go__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2434, tmp1, nil); return /*line :538:1*/ lang.IFn_Cast(go__2).Invoke_O_O__O(t.F_ss, vfs__1) }
//line :531:1
func A_arbace_c2j_node_clause_pick__400000396_go__400000397_A_New_O(p0 any) *A_arbace_c2j_node_clause_pick__400000396_go__400000397_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_pick__400000396_go__400000397_A{}; t.Ctor_O(p0); return t }
//line :531:1
func (t *A_arbace_c2j_node_clause_pick__400000396_go__400000397_A) Ctor_O(c__construct any) { t.F_construct = c__construct }
//line :531:1
func (t *A_arbace_c2j_node_clause_pick__400000396_go__400000397_A) Invoke_O_O_O__O(self, ss__1, vfs__2 any) any {
	var tmp1 any; var root_2391 any = A_arbace_c2j_node_A_const_61.GetRawRoot__O(); var linked_2392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2391, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2393 lang.IFn; if linked_2392 == nil { ifn_2393 = lang.IFn_Cast(root_2391) } else { ifn_2393 = nil }; var arg_2394 any = ss__1; if linked_2392 == nil { tmp1 = ifn_2393.Invoke_O__O(arg_2394) } else { tmp1 = linked_2392.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2391, arg_2394) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(t.F_construct); var tmp3 any; var root_2399 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2399, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2401 lang.IFn; if linked_2400 == nil { ifn_2401 = lang.IFn_Cast(root_2399) } else { ifn_2401 = nil }; var arg_2402 any = vfs__2; if linked_2400 == nil { tmp3 = ifn_2401.Invoke_O__O(arg_2402) } else { tmp3 = linked_2400.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2399, arg_2402) }; return tmp2.Invoke_O__O(tmp3) } else {
//line :532:1
			var s__3 any; var root_2395 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2395, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2397 lang.IFn

			if linked_2396 == nil { ifn_2397 = lang.IFn_Cast(root_2395) } else { ifn_2397 = nil }; var arg_2398 any = ss__1; if linked_2396 == nil { s__3 = ifn_2397.Invoke_O__O(arg_2398) } else { s__3 = linked_2396.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2395, arg_2398) }
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_node_A_const_411; var tmp6 lang.IFn = lang.IFn_Cast(self); var tmp7 any; var root_2403 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2403, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2405 lang.IFn
			if linked_2404 == nil { ifn_2405 = lang.IFn_Cast(root_2403) } else { ifn_2405 = nil }; var arg_2406 any = ss__1; if linked_2404 == nil { tmp7 = ifn_2405.Invoke_O__O(arg_2406) } else { tmp7 = linked_2404.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2403, arg_2406) }
//line :535:1
			var tmp8 any = tmp7; var tmp9 any; var root_2407 any = A_arbace_c2j_node_A_const_32.GetRawRoot__O(); var linked_2408 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2407, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2409 lang.IFn
			if linked_2408 == nil { ifn_2409 = lang.IFn_Cast(root_2407) } else { ifn_2409 = nil }; var arg_2410 any; var fnbody__2417 any = A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000398_A_New_O(s__3); var tmp10 *jrt.Class; var fncls__2416 *jrt.Class = A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000398_A_fn_class; if fncls__2416 == nil { var fncls__2416d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__2417); A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000398_A_fn_class = fncls__2416d; tmp10 = fncls__2416d } else { tmp10 = fncls__2416 }; arg_2410 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2417, tmp10, nil); var arg_2411 any = vfs__2; if linked_2408 == nil { tmp9 = ifn_2409.Invoke_O_O__O(arg_2410, arg_2411) } else { tmp9 = linked_2408.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2407, arg_2410, arg_2411) }
//line :535:1
			var tmp11 any = tmp6.Invoke_O_O__O(tmp8, tmp9); var tmp12 lang.IFn = lang.IFn_Cast(self); var tmp13 any; var root_2418 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2418, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2420 lang.IFn

			if linked_2419 == nil { ifn_2420 = lang.IFn_Cast(root_2418) } else { ifn_2420 = nil }; var arg_2421 any = ss__1; if linked_2419 == nil { tmp13 = ifn_2420.Invoke_O__O(arg_2421) } else { tmp13 = linked_2419.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2418, arg_2421) }
//line :535:1
			var tmp14 any = tmp13; var tmp15 any; var root_2422 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_2423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2422, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2424 lang.IFn

			if linked_2423 == nil { ifn_2424 = lang.IFn_Cast(root_2422) } else { ifn_2424 = nil }; var arg_2425 any; var fnbody__2432 any = A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000400_A_New_O(s__3); var tmp16 *jrt.Class; var fncls__2431 *jrt.Class = A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000400_A_fn_class; if fncls__2431 == nil { var fncls__2431d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__2432); A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000400_A_fn_class = fncls__2431d; tmp16 = fncls__2431d } else { tmp16 = fncls__2431 }; arg_2425 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2432, tmp16, nil); var arg_2426 any = vfs__2; if linked_2423 == nil { tmp15 = ifn_2424.Invoke_O_O__O(arg_2425, arg_2426) } else { tmp15 = linked_2423.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2422, arg_2425, arg_2426) }
//line :535:1
			return tmp4.Invoke_O_O_O_O__O(tmp5, s__3, tmp11, tmp12.Invoke_O_O__O(tmp14, tmp15)) } }
func A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000398_A_New_O(p0 any) *A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000398_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000398_A{}; t.Ctor_O(p0); return t }
//line :536:1
func (t *A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000398_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :536:1
func (t *A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000398_A) Invoke_O_O__O(self, p1__400000381_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_234; var tmp2 any; var root_2412 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2412, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2414 lang.IFn; if linked_2413 == nil { ifn_2414 = lang.IFn_Cast(root_2412) } else { ifn_2414 = nil }; var arg_2415 any = p1__400000381_SHARP___1; if linked_2413 == nil { tmp2 = ifn_2414.Invoke_O__O(arg_2415) } else { tmp2 = linked_2413.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2412, arg_2415) }; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(tmp2), t.F_s) }
func A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000400_A_New_O(p0 any) *A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000400_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000400_A{}; t.Ctor_O(p0); return t }
//line :537:1
func (t *A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000400_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :537:1
func (t *A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000400_A) Invoke_O_O__O(self, p1__400000382_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_234; var tmp2 any; var root_2427 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2427, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2429 lang.IFn; if linked_2428 == nil { ifn_2429 = lang.IFn_Cast(root_2427) } else { ifn_2429 = nil }; var arg_2430 any = p1__400000382_SHARP___1; if linked_2428 == nil { tmp2 = ifn_2429.Invoke_O__O(arg_2430) } else { tmp2 = linked_2428.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2427, arg_2430) }; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(tmp2), t.F_s) }







func A_arbace_c2j_node_clause_fn__400000405_A_New_O(p0 any) *A_arbace_c2j_node_clause_fn__400000405_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000405_A{}; t.Ctor_O(p0); return t }
//line :545:1
func (t *A_arbace_c2j_node_clause_fn__400000405_A) Ctor_O(c__pick any) { t.F_pick = c__pick }
//line :545:1
func (t *A_arbace_c2j_node_clause_fn__400000405_A) Invoke_O_O__O(self, p__400000404__1 any) any { var vec__400000406__2 any = p__400000404__1; var c__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000406__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000406__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_421, A_arbace_c2j_node_A_const_422, c__3), lang.IFn_Cast(t.F_pick).Invoke_O__O(vfs__4)) }


func A_arbace_c2j_node_clause_fn__400000411_A_New_O(p0 any) *A_arbace_c2j_node_clause_fn__400000411_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000411_A{}; t.Ctor_O(p0); return t }
//line :548:1
func (t *A_arbace_c2j_node_clause_fn__400000411_A) Ctor_O(c__pick any) { t.F_pick = c__pick }
//line :548:1
func (t *A_arbace_c2j_node_clause_fn__400000411_A) Invoke_O_O__O(self, p__400000410__1 any) any { var vec__400000412__2 any = p__400000410__1; var c__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000412__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000412__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_436, A_arbace_c2j_node_A_const_437, c__3), lang.IFn_Cast(t.F_pick).Invoke_O__O(vfs__4)) }







func A_arbace_c2j_node_code_forms_A_New() *A_arbace_c2j_node_code_forms_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_A{}; t.Ctor(); return t }
//line :556:1
func (t *A_arbace_c2j_node_code_forms_A) Ctor() {}
//line :556:1
func (t *A_arbace_c2j_node_code_forms_A) Invoke_O_O_O_O__O(self, helpers__0, domains__1, keys__2 any) any { var per__4 any; var iter__1927001039__auto____4 any; var fnbody__2626 any = A_arbace_c2j_node_code_forms_iter__400000417__400000421_A_New_O_O(helpers__0, domains__1); var tmp1 *jrt.Class; var fncls__2625 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000417__400000421_A_fn_class; if






	fncls__2625 == nil { var fncls__2625d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__2626); A_arbace_c2j_node_code_forms_iter__400000417__400000421_A_fn_class = fncls__2625d; tmp1 = fncls__2625d } else { tmp1 = fncls__2625 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2626, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp3 any; var root_3093 any = A_arbace_c2j_node_A_const_5.GetRawRoot__O(); var linked_3094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3093, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3095 lang.IFn; if linked_3094 == nil { ifn_3095 = lang.IFn_Cast(root_3093) } else { ifn_3095 = nil }; var arg_3096 any = A_arbace_c2j_node_A_const_10.GetRawRoot__O(); if linked_3094 == nil { tmp3 = ifn_3095.Invoke_O__O(arg_3096) } else { tmp3 = linked_3094.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3093, arg_3096) }; per__4 = tmp2.Invoke_O__O(tmp3); var clauses__5 any; var tmp4 lang.IFn = /*line :556:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp5 *lang.Compiler_AOTFn; var fnbody__2668 any = A_arbace_c2j_node_code_forms_fn__400000438_A_New(); var tmp6 *jrt.Class; var fncls__2667 *jrt.Class = A_arbace_c2j_node_code_forms_fn__400000438_A_fn_class; if











	fncls__2667 == nil { var fncls__2667d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, nil); A_arbace_c2j_node_code_forms_fn__400000438_A_fn_class = fncls__2667d; tmp6 = fncls__2667d } else { tmp6 = fncls__2667 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2668, tmp6, nil); clauses__5 = tmp4.Invoke_O_O__O(tmp5.Ref(), per__4); var table__6 any; var iter__1927001039__auto____6 any; var fnbody__2838 any = /*line :556:1*/A_arbace_c2j_node_code_forms_iter__400000442__400000450_A_New_O_O(domains__1, keys__2); var tmp7 *jrt.Class; var fncls__2837 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000442__400000450_A_fn_class; if












	fncls__2837 == nil { var fncls__2837d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__2838); A_arbace_c2j_node_code_forms_iter__400000442__400000450_A_fn_class = fncls__2837d; tmp7 = fncls__2837d } else { tmp7 = fncls__2837 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2838, tmp7, nil); table__6 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(per__4); var root_2839 any =



	A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2840 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2839, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2841 lang.IFn; if linked_2840 == nil { ifn_2841 = lang.IFn_Cast(root_2839) } else { ifn_2841 = nil }; var arg_2842 any; var iter__1927001039__auto____7 any; var fnbody__3038 any = A_arbace_c2j_node_code_forms_iter__400000475__400000481_A_New(); var tmp8 *jrt.Class; var fncls__3037 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000475__400000481_A_fn_class; if
	fncls__3037 == nil { var fncls__3037d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_c2j_node_code_forms_iter__400000475__400000481_A_fn_class = fncls__3037d; tmp8 = fncls__3037d } else { tmp8 = fncls__3037 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3038, tmp8, nil); arg_2842 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(per__4); var arg_2843 any; var tmp9 lang.IFn = /*line :573:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_node_A_const_459; var tmp11 any; var root_3039 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3039, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3041 lang.IFn; if







	linked_3040 == nil { ifn_3041 = lang.IFn_Cast(root_3039) } else { ifn_3041 = nil }; var arg_3042 any = A_arbace_c2j_node_A_const_460; var arg_3043 any = A_arbace_c2j_node_A_const_461; if linked_3040 == nil { tmp11 = ifn_3041.Invoke_O_O__O(arg_3042, arg_3043) } else { tmp11 = linked_3040.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3039, arg_3042, arg_3043) }; var tmp12 any = tmp11; var tmp13 lang.IFn = /*line :573:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp14 any = A_arbace_c2j_node_A_const_462; var tmp15 any; var root_3044 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3044, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3046 lang.IFn; if








	linked_3045 == nil { ifn_3046 = lang.IFn_Cast(root_3044) } else { ifn_3046 = nil }; var arg_3047 any = A_arbace_c2j_node_A_const_463; var arg_3048 any = A_arbace_c2j_node_A_const_464; if linked_3045 == nil { tmp15 = ifn_3046.Invoke_O_O__O(arg_3047, arg_3048) } else { tmp15 = linked_3045.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3044, arg_3047, arg_3048) }; var tmp16 any = tmp15; var tmp17 any; var root_3049 any = /*line :573:1*/A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3050 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3049, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3051 lang.IFn; if









	linked_3050 == nil { ifn_3051 = lang.IFn_Cast(root_3049) } else { ifn_3051 = nil }; var arg_3052 any; var tmp18 any; var root_3054 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3054, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3056 lang.IFn; if linked_3055 == nil { ifn_3056 = lang.IFn_Cast(root_3054) } else { ifn_3056 = nil }; var arg_3057 any = A_arbace_c2j_node_A_const_465; var arg_3058 any = A_arbace_c2j_node_A_const_466; if linked_3055 == nil { tmp18 = ifn_3056.Invoke_O_O__O(arg_3057, arg_3058) } else { tmp18 = linked_3055.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3054, arg_3057, arg_3058) }; var tmp19 any = tmp18; var tmp20 any; var root_3059 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3059, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3061 lang.IFn; if linked_3060 == nil { ifn_3061 = lang.IFn_Cast(root_3059) } else { ifn_3061 = nil }; var arg_3062 any = A_arbace_c2j_node_A_const_467; var arg_3063 any = A_arbace_c2j_node_A_const_468; if linked_3060 == nil { tmp20 = ifn_3061.Invoke_O_O__O(arg_3062, arg_3063) } else { tmp20 = linked_3060.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3059, arg_3062, arg_3063) }; arg_3052 = lang.Tuple_Create_O_O__IPersistentVector(tmp19, tmp20); var arg_3053 any = A_arbace_c2j_node_A_const_469; if linked_3050 == nil { tmp17 = ifn_3051.Invoke_O_O__O(arg_3052, arg_3053) } else { tmp17 = linked_3050.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3049, arg_3052, arg_3053) }; var tmp21 any = /*line :573:1*/tmp13.Invoke_O_O_O_O__O(tmp14, tmp16, tmp17, lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_470), clauses__5, A_arbace_c2j_node_A_const_471)); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp23 any = A_arbace_c2j_node_A_const_472; var tmp24 any; var root_3070 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3070, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3072 lang.IFn; if











	linked_3071 == nil { ifn_3072 = lang.IFn_Cast(root_3070) } else { ifn_3072 = nil }; var arg_3073 any = A_arbace_c2j_node_A_const_473; var arg_3074 any = A_arbace_c2j_node_A_const_474; if linked_3071 == nil { tmp24 = ifn_3072.Invoke_O_O__O(arg_3073, arg_3074) } else { tmp24 = linked_3071.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3070, arg_3073, arg_3074) }; var tmp25 any = tmp24; var tmp26 any; var root_3075 any = /*line :573:1*/A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3075, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3077 lang.IFn; if












	linked_3076 == nil { ifn_3077 = lang.IFn_Cast(root_3075) } else { ifn_3077 = nil }; var arg_3078 any = lang.PersistentVector_EMPTY.Ref(); var arg_3079 any = A_arbace_c2j_node_A_const_475; if linked_3076 == nil { tmp26 = ifn_3077.Invoke_O_O__O(arg_3078, arg_3079) } else { tmp26 = linked_3076.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3075, arg_3078, arg_3079) }; var tmp27 any = tmp26; var tmp28 lang.IFn = /*line :573:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp29 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_476, A_arbace_c2j_node_A_const_477); var tmp30 any; var root_3086 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_3087 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3086, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3088 lang.IFn; if














	linked_3087 == nil { ifn_3088 = lang.IFn_Cast(root_3086) } else { ifn_3088 = nil }; var arg_3089 any; var fnbody__3092 any = A_arbace_c2j_node_code_forms_fn__400000510_A_New(); var tmp31 *jrt.Class; var fncls__3091 *jrt.Class = A_arbace_c2j_node_code_forms_fn__400000510_A_fn_class; if fncls__3091 == nil { var fncls__3091d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_c2j_node_code_forms_fn__400000510_A_fn_class = fncls__3091d; tmp31 = fncls__3091d } else { tmp31 = fncls__3091 }; arg_3089 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3092, tmp31, nil); var arg_3090 any = table__6; if linked_3087 == nil { tmp30 = ifn_3088.Invoke_O_O__O(arg_3089, arg_3090) } else { tmp30 = linked_3087.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3086, arg_3089, arg_3090) }; arg_2843 = /*line :573:1*/lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(Lit_18, tmp9.Invoke_O_O_O_O__O(tmp10, tmp12, tmp21, tmp22.Invoke_O_O_O_O__O(tmp23, tmp25, tmp27, tmp28.Invoke_O_O_O__O(tmp29, tmp30, A_arbace_c2j_node_A_const_481))))); if linked_2840 == nil { return ifn_2841.Invoke_O_O__O(arg_2842, arg_2843) } else { return linked_2840.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2839, arg_2842, arg_2843) } }
//line :563:1
func A_arbace_c2j_node_code_forms_iter__400000417__400000421_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000417__400000421_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000417__400000421_A{}; t.Ctor_O_O(p0, p1); return t }
//line :563:1
func (t *A_arbace_c2j_node_code_forms_iter__400000417__400000421_A) Ctor_O_O(c__helpers, c__domains any) { t.F_helpers = c__helpers; t.F_domains = c__domains }
//line :563:1
func (t *A_arbace_c2j_node_code_forms_iter__400000417__400000421_A) Invoke_O_O__O(self, s__400000418__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2624 any = A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_A_New_O_O_O_O(t.F_helpers, self, s__400000418__1, t.F_domains); var tmp2 *jrt.Class; var fncls__2623 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_A_fn_class; if fncls__2623 == nil { var fncls__2623d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__2624); A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_A_fn_class = fncls__2623d; tmp2 = fncls__2623d } else { tmp2 = fncls__2623 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2624, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :563:1
func A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :563:1
func (t *A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_A) Ctor_O_O_O_O(c__helpers, c__iter__400000417, c__s__400000418, c__domains any) { t.F_helpers = c__helpers; t.F_iter__400000417 = c__iter__400000417; t.F_s__400000418 = c__s__400000418; t.F_domains = c__domains }
//line :563:1
func (t *A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_A) Invoke_O__O(self any) any { { var s__400000418__1 any; var t_ any = t.F_s__400000418; t.F_s__400000418 = nil; s__400000418__1 = t_; for { var temp__1927000414__auto____2 any; var root_2519 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2519, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2521 lang.IFn; if linked_2520 == nil { ifn_2521 = lang.IFn_Cast(root_2519) } else { ifn_2521 = nil }; var arg_2522 any = s__400000418__1; if linked_2520 == nil { temp__1927000414__auto____2 = ifn_2521.Invoke_O__O(arg_2522) } else { temp__1927000414__auto____2 = linked_2520.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2519, arg_2522) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000418__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2523 any = A_arbace_c2j_node_A_const_380.GetRawRoot__O(); var linked_2524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2523, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2525 lang.IFn; if linked_2524 == nil { ifn_2525 = lang.IFn_Cast(root_2523) } else { ifn_2525 = nil }; var arg_2526 any = s__400000418__3; if linked_2524 == nil { tmp1 = ifn_2525.Invoke_O__O(arg_2526) } else { tmp1 = linked_2524.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2523, arg_2526) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2527 any = A_arbace_c2j_node_A_const_381.GetRawRoot__O(); var linked_2528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2527, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2529 lang.IFn; if linked_2528 == nil { ifn_2529 = lang.IFn_Cast(root_2527) } else { ifn_2529 = nil }; var arg_2530 any = s__400000418__3; if linked_2528 == nil { c__1927001037__auto____4 = ifn_2529.Invoke_O__O(arg_2530) } else { c__1927001037__auto____4 = linked_2528.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2527, arg_2530) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000420__6 any; var root_2531 any = A_arbace_c2j_node_A_const_382.GetRawRoot__O(); var linked_2532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2531, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2533 lang.IFn; if linked_2532 == nil { ifn_2533 = lang.IFn_Cast(root_2531) } else { ifn_2533 = nil }; var arg_2534 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2532 == nil { b__400000420__6 = ifn_2533.Invoke_O__O(arg_2534) } else { b__400000420__6 = linked_2532.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2531, arg_2534) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2564 any = A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_A_New_O_O_O_I_O(t.F_helpers, t.F_domains, b__400000420__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2563 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_A_fn_class; if fncls__2563 == nil { var fncls__2563d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__2564); A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_A_fn_class = fncls__2563d; tmp3 = fncls__2563d } else { tmp3 = fncls__2563 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2564, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2565 any = A_arbace_c2j_node_A_const_384.GetRawRoot__O(); var linked_2566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2565, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2567 lang.IFn; if linked_2566 == nil { ifn_2567 = lang.IFn_Cast(root_2565) } else { ifn_2567 = nil }; var arg_2568 any; var root_2570 any = A_arbace_c2j_node_A_const_385.GetRawRoot__O(); var linked_2571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2570, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2572 lang.IFn; if linked_2571 == nil { ifn_2572 = lang.IFn_Cast(root_2570) } else { ifn_2572 = nil }; var arg_2573 any = b__400000420__6; if linked_2571 == nil { arg_2568 = ifn_2572.Invoke_O__O(arg_2573) } else { arg_2568 = linked_2571.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2570, arg_2573) }; var arg_2569 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000417); var tmp5 any; var root_2574 any = A_arbace_c2j_node_A_const_386.GetRawRoot__O(); var linked_2575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2574, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2576 lang.IFn; if linked_2575 == nil { ifn_2576 = lang.IFn_Cast(root_2574) } else { ifn_2576 = nil }; var arg_2577 any = s__400000418__3; if linked_2575 == nil { tmp5 = ifn_2576.Invoke_O__O(arg_2577) } else { tmp5 = linked_2575.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2574, arg_2577) }; arg_2569 = tmp4.Invoke_O__O(tmp5); if linked_2566 == nil { return ifn_2567.Invoke_O_O__O(arg_2568, arg_2569) } else { return linked_2566.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2565, arg_2568, arg_2569) } } else { var root_2578 any = A_arbace_c2j_node_A_const_384.GetRawRoot__O(); var linked_2579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2578, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2580 lang.IFn; if linked_2579 == nil { ifn_2580 = lang.IFn_Cast(root_2578) } else { ifn_2580 = nil }; var arg_2581 any; var root_2583 any = A_arbace_c2j_node_A_const_385.GetRawRoot__O(); var linked_2584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2583, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2585 lang.IFn; if linked_2584 == nil { ifn_2585 = lang.IFn_Cast(root_2583) } else { ifn_2585 = nil }; var arg_2586 any = b__400000420__6; if linked_2584 == nil { arg_2581 = ifn_2585.Invoke_O__O(arg_2586) } else { arg_2581 = linked_2584.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2583, arg_2586) }; var arg_2582 any; if linked_2579 == nil { return ifn_2580.Invoke_O_O__O(arg_2581, arg_2582) } else { return linked_2579.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2578, arg_2581, arg_2582) } } } else { var d__4 any; var root_2587 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2587, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2589 lang.IFn; if linked_2588 == nil { ifn_2589 = lang.IFn_Cast(root_2587) } else { ifn_2589 = nil }; var arg_2590 any = s__400000418__3; if linked_2588 == nil { d__4 = ifn_2589.Invoke_O__O(arg_2590) } else { d__4 = linked_2588.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2587, arg_2590) }; var root_2591 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2591, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2593 lang.IFn; if linked_2592 == nil { ifn_2593 = lang.IFn_Cast(root_2591) } else { ifn_2593 = nil }; var arg_2594 any; var tmp6 any = A_arbace_c2j_node_A_const_109; var tmp7 any = A_arbace_c2j_node_A_const_451; var tmp8 any; var root_2596 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_2597 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2596, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2598 lang.IFn
														if linked_2597 == nil { ifn_2598 = lang.IFn_Cast(root_2596) } else { ifn_2598 = nil }; var arg_2599 any; var fnbody__2613 any = A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000430_A_New_O_O(d__4, t.F_helpers); var tmp9 *jrt.Class; var fncls__2612 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000430_A_fn_class; if fncls__2612 == nil { var fncls__2612d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__2613); A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000430_A_fn_class = fncls__2612d; tmp9 = fncls__2612d } else { tmp9 = fncls__2612 }; arg_2599 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2613, tmp9, nil); var arg_2600 any; var root_2614 any = A_arbace_c2j_node_A_const_454.GetRawRoot__O(); var linked_2615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2614, A_arbace_c2j_node_variants_A_fn_class); var ifn_2616 lang.IFn


	if linked_2615 == nil { ifn_2616 = lang.IFn_Cast(root_2614) } else { ifn_2616 = nil }; var arg_2617 any = d__4; var arg_2618 any = t.F_domains; if linked_2615 == nil { arg_2600 = ifn_2616.Invoke_O_O__O(arg_2617, arg_2618) } else { arg_2600 = linked_2615.(*A_arbace_c2j_node_variants_A).Invoke_O_O_O__O(root_2614, arg_2617, arg_2618) }
//line :564:1
	if linked_2597 == nil { tmp8 = ifn_2598.Invoke_O_O__O(arg_2599, arg_2600) } else { tmp8 = linked_2597.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2596, arg_2599, arg_2600) }
//line :563:1
	arg_2594 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, d__4, tmp7, tmp8)); var arg_2595 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__400000417); var tmp11 any; var root_2619 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2619, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2621 lang.IFn; if linked_2620 == nil { ifn_2621 = lang.IFn_Cast(root_2619) } else { ifn_2621 = nil }; var arg_2622 any = s__400000418__3; if linked_2620 == nil { tmp11 = ifn_2621.Invoke_O__O(arg_2622) } else { tmp11 = linked_2620.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2619, arg_2622) }; arg_2595 = tmp10.Invoke_O__O(tmp11); if linked_2592 == nil { return ifn_2593.Invoke_O_O__O(arg_2594, arg_2595) } else { return linked_2592.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2591, arg_2594, arg_2595) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :563:1
func A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :563:1
func (t *A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_A) Ctor_O_O_O_I_O(c__helpers, c__domains, c__b__400000420 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_helpers = c__helpers; t.F_domains = c__domains; t.F_b__400000420 = c__b__400000420; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :563:1
func (t *A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_A) Invoke_O__O(self any) any { { var i__400000419__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000419__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000419__1)); var root_2535 any = A_arbace_c2j_node_A_const_383.GetRawRoot__O(); var linked_2536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2535, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2537 lang.IFn; if linked_2536 == nil { ifn_2537 = lang.IFn_Cast(root_2535) } else { ifn_2537 = nil }; var arg_2538 any = t.F_b__400000420; var arg_2539 any; var tmp2 any = A_arbace_c2j_node_A_const_109; var tmp3 any = A_arbace_c2j_node_A_const_451; var tmp4 any; var root_2540 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_2541 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2540, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2542 lang.IFn
																if linked_2541 == nil { ifn_2542 = lang.IFn_Cast(root_2540) } else { ifn_2542 = nil }; var arg_2543 any; var fnbody__2557 any = A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_fn__400000424_A_New_O_O(d__2, t.F_helpers); var tmp5 *jrt.Class; var fncls__2556 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_fn__400000424_A_fn_class; if fncls__2556 == nil { var fncls__2556d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__2557); A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_fn__400000424_A_fn_class = fncls__2556d; tmp5 = fncls__2556d } else { tmp5 = fncls__2556 }; arg_2543 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2557, tmp5, nil); var arg_2544 any; var root_2558 any = A_arbace_c2j_node_A_const_454.GetRawRoot__O(); var linked_2559 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2558, A_arbace_c2j_node_variants_A_fn_class); var ifn_2560 lang.IFn


	if linked_2559 == nil { ifn_2560 = lang.IFn_Cast(root_2558) } else { ifn_2560 = nil }; var arg_2561 any = d__2; var arg_2562 any = t.F_domains; if linked_2559 == nil { arg_2544 = ifn_2560.Invoke_O_O__O(arg_2561, arg_2562) } else { arg_2544 = linked_2559.(*A_arbace_c2j_node_variants_A).Invoke_O_O_O__O(root_2558, arg_2561, arg_2562) }
//line :564:1
	if linked_2541 == nil { tmp4 = ifn_2542.Invoke_O_O__O(arg_2543, arg_2544) } else { tmp4 = linked_2541.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2540, arg_2543, arg_2544) }
//line :563:1
	arg_2539 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, d__2, tmp3, tmp4)); if linked_2536 == nil { ifn_2537.Invoke_O_O__O(arg_2538, arg_2539) } else { linked_2536.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2535, arg_2538, arg_2539) }; i__400000419__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000419__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_fn__400000424_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_fn__400000424_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_fn__400000424_A{}; t.Ctor_O_O(p0, p1); return t }
//line :564:1
func (t *A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_fn__400000424_A) Ctor_O_O(c__d, c__helpers any) { t.F_d = c__d; t.F_helpers = c__helpers }
//line :564:1
func (t *A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_fn__400000424_A) Invoke_O_O__O(self, v__1 any) any { var v__2 any; var root_2545 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_2546 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2545, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2547 lang.IFn; if linked_2546 == nil { ifn_2547 = lang.IFn_Cast(root_2545) } else { ifn_2547 = nil }; var arg_2548 any = v__1; var arg_2549 any = A_arbace_c2j_node_A_const_255; var arg_2550 any = t.F_helpers; if linked_2546 == nil { v__2 = ifn_2547.Invoke_O_O_O__O(arg_2548, arg_2549, arg_2550) } else { v__2 = linked_2546.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2545, arg_2548, arg_2549, arg_2550) }; var vec__400000425__3 any; var root_2551 any = A_arbace_c2j_node_A_const_452.GetRawRoot__O(); var linked_2552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2551, A_arbace_c2j_node_variant_class_A_fn_class); var ifn_2553 lang.IFn; if
																		linked_2552 == nil { ifn_2553 = lang.IFn_Cast(root_2551) } else { ifn_2553 = nil }; var arg_2554 any = t.F_d; var arg_2555 any = v__2; if linked_2552 == nil { vec__400000425__3 = ifn_2553.Invoke_O_O__O(arg_2554, arg_2555) } else { vec__400000425__3 = linked_2552.(*A_arbace_c2j_node_variant_class_A).Invoke_O_O_O__O(root_2551, arg_2554, arg_2555) }; var cf__4 any = /*line :564:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__400000425__3, lang.RT_IntCast_J__I_NoInit(0), nil); var fields__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000425__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_56, v__2, A_arbace_c2j_node_A_const_453, cf__4, A_arbace_c2j_node_A_const_31, fields__5)) }
//line :564:1
func A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000430_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000430_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000430_A{}; t.Ctor_O_O(p0, p1); return t }
//line :564:1
func (t *A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000430_A) Ctor_O_O(c__d, c__helpers any) { t.F_d = c__d; t.F_helpers = c__helpers }
//line :564:1
func (t *A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000430_A) Invoke_O_O__O(self, v__1 any) any { var v__2 any; var root_2601 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_2602 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2601, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2603 lang.IFn; if linked_2602 == nil { ifn_2603 = lang.IFn_Cast(root_2601) } else { ifn_2603 = nil }; var arg_2604 any = v__1; var arg_2605 any = A_arbace_c2j_node_A_const_255; var arg_2606 any = t.F_helpers; if linked_2602 == nil { v__2 = ifn_2603.Invoke_O_O_O__O(arg_2604, arg_2605, arg_2606) } else { v__2 = linked_2602.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2601, arg_2604, arg_2605, arg_2606) }; var vec__400000431__3 any; var root_2607 any = A_arbace_c2j_node_A_const_452.GetRawRoot__O(); var linked_2608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2607, A_arbace_c2j_node_variant_class_A_fn_class); var ifn_2609 lang.IFn; if
																	linked_2608 == nil { ifn_2609 = lang.IFn_Cast(root_2607) } else { ifn_2609 = nil }; var arg_2610 any = t.F_d; var arg_2611 any = v__2; if linked_2608 == nil { vec__400000431__3 = ifn_2609.Invoke_O_O__O(arg_2610, arg_2611) } else { vec__400000431__3 = linked_2608.(*A_arbace_c2j_node_variant_class_A).Invoke_O_O_O__O(root_2607, arg_2610, arg_2611) }; var cf__4 any = /*line :564:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__400000431__3, lang.RT_IntCast_J__I_NoInit(0), nil); var fields__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000431__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_56, v__2, A_arbace_c2j_node_A_const_453, cf__4, A_arbace_c2j_node_A_const_31, fields__5)) }



func A_arbace_c2j_node_code_forms_fn__400000438_A_New() *A_arbace_c2j_node_code_forms_fn__400000438_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_fn__400000438_A{}; t.Ctor(); return t }
//line :568:1
func (t *A_arbace_c2j_node_code_forms_fn__400000438_A) Ctor() {}
//line :568:1
func (t *A_arbace_c2j_node_code_forms_fn__400000438_A) Invoke_O_O__O(self, p__400000437__1 any) any { var map__400000439__2 any = p__400000437__1; var map__400000439__3 any; if lang.ISeq_InstanceOf(map__400000439__2) { var tmp1 any; var root_2632 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2632, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2634 lang.IFn; if linked_2633 == nil { ifn_2634 = lang.IFn_Cast(root_2632) } else { ifn_2634 = nil }; var arg_2635 any = map__400000439__2; if linked_2633 == nil { tmp1 = ifn_2634.Invoke_O__O(arg_2635) } else { tmp1 = linked_2633.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2632, arg_2635) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2636 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_2637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2636, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2638 lang.IFn; if linked_2637 == nil { ifn_2638 = lang.IFn_Cast(root_2636) } else { ifn_2638 = nil }; var arg_2639 any = map__400000439__2; if linked_2637 == nil { tmp2 = ifn_2638.Invoke_O__O(arg_2639) } else { tmp2 = linked_2637.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2636, arg_2639) }; map__400000439__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2640 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2640, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2642 lang.IFn; if linked_2641 == nil { ifn_2642 = lang.IFn_Cast(root_2640) } else { ifn_2642 = nil }; var arg_2643 any = map__400000439__2; if linked_2641 == nil { tmp3 = ifn_2642.Invoke_O__O(arg_2643) } else { tmp3 = linked_2641.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2640, arg_2643) }; if jrt.J2g_Truth(tmp3) { var root_2644 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2644, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2646 lang.IFn; if linked_2645 == nil { ifn_2646 = lang.IFn_Cast(root_2644) } else { ifn_2646 = nil }; var arg_2647 any = map__400000439__2; if linked_2645 == nil { map__400000439__3 = ifn_2646.Invoke_O__O(arg_2647) } else { map__400000439__3 = linked_2645.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2644, arg_2647) } } else { map__400000439__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000439__3 = map__400000439__2 }; var d__4 any = lang.RT_Get_O_O__O_NoInit(map__400000439__3, A_arbace_c2j_node_A_const_109); var vs__5 any = lang.RT_Get_O_O__O_NoInit(map__400000439__3, A_arbace_c2j_node_A_const_451); var tmp4 any; var root_2648 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2648, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2650 lang.IFn; if linked_2649 == nil { ifn_2650 = lang.IFn_Cast(root_2648) } else { ifn_2650 = nil }; var tmp5 *lang.Keyword = A_arbace_c2j_node_A_const_396; var arg_2651 any = tmp5.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__4)); if linked_2649 == nil { tmp4 = ifn_2650.Invoke_O__O(arg_2651) } else { tmp4 = linked_2649.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2648, arg_2651) }; if jrt.J2g_Truth(tmp4) { var root_2652 any = A_arbace_c2j_node_A_const_455.GetRawRoot__O(); var linked_2653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2652, A_arbace_c2j_node_clause_A_fn_class); var ifn_2654 lang.IFn; if linked_2653 == nil { ifn_2654 = lang.IFn_Cast(root_2652) } else { ifn_2654 = nil }; var arg_2655 any = d__4; var arg_2656 any; var root_2657 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_2658 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2657, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2659 lang.IFn; if linked_2658 == nil { ifn_2659 = lang.IFn_Cast(root_2657) } else { ifn_2659 = nil }; var arg_2660 any; var root_2662 any = A_arbace_c2j_node_A_const_456.GetRawRoot__O(); var linked_2663 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2662, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2664 lang.IFn; if linked_2663 == nil { ifn_2664 = lang.IFn_Cast(root_2662) } else { ifn_2664 = nil }; var arg_2665 any = A_arbace_c2j_node_A_const_56; var arg_2666 any = A_arbace_c2j_node_A_const_31; if linked_2663 == nil { arg_2660 = ifn_2664.Invoke_O_O__O(arg_2665, arg_2666) } else { arg_2660 = linked_2663.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2662, arg_2665, arg_2666) }; var arg_2661 any = vs__5; if linked_2658 == nil { arg_2656 = ifn_2659.Invoke_O_O__O(arg_2660, arg_2661) } else { arg_2656 = linked_2658.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2657, arg_2660, arg_2661) }; if linked_2653 == nil { return ifn_2654.Invoke_O_O__O(arg_2655, arg_2656) } else { return linked_2653.(*A_arbace_c2j_node_clause_A).Invoke_O_O_O__O(root_2652, arg_2655, arg_2656) } } else { return nil } }
func A_arbace_c2j_node_code_forms_iter__400000442__400000450_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000442__400000450_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000442__400000450_A{}; t.Ctor_O_O(p0, p1); return t }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_A) Ctor_O_O(c__domains, c__keys any) { t.F_domains = c__domains; t.F_keys = c__keys }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_A) Invoke_O_O__O(self, s__400000443__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2836 any = A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_A_New_O_O_O_O(s__400000443__1, t.F_domains, t.F_keys, self); var tmp2 *jrt.Class; var fncls__2835 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_A_fn_class; if fncls__2835 == nil { var fncls__2835d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__2836); A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_A_fn_class = fncls__2835d; tmp2 = fncls__2835d } else { tmp2 = fncls__2835 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2836, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :569:1
func A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_A) Ctor_O_O_O_O(c__s__400000443, c__domains, c__keys, c__iter__400000442 any) { t.F_s__400000443 = c__s__400000443; t.F_domains = c__domains; t.F_keys = c__keys; t.F_iter__400000442 = c__iter__400000442 }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_A) Invoke_O__O(self any) any { { var s__400000443__1 any; var t_ any = t.F_s__400000443; t.F_s__400000443 = nil; s__400000443__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2669 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2669, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2671 lang.IFn; if linked_2670 == nil { ifn_2671 = lang.IFn_Cast(root_2669) } else { ifn_2671 = nil }; var arg_2672 any = s__400000443__1; if linked_2670 == nil { temp__1927000414__auto____2 = ifn_2671.Invoke_O__O(arg_2672) } else { temp__1927000414__auto____2 = linked_2670.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2669, arg_2672) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__400000452__4 any; var root_2673 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2673, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2675 lang.IFn; if linked_2674 == nil { ifn_2675 = lang.IFn_Cast(root_2673) } else { ifn_2675 = nil }; var arg_2676 any = xs__1927001018__auto____3; if linked_2674 == nil { map__400000452__4 = ifn_2675.Invoke_O__O(arg_2676) } else { map__400000452__4 = linked_2674.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2673, arg_2676) }; var map__400000452__5 any; if lang.ISeq_InstanceOf(map__400000452__4) { var tmp1 any; var root_2677 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2677, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2679 lang.IFn; if linked_2678 == nil { ifn_2679 = lang.IFn_Cast(root_2677) } else { ifn_2679 = nil }; var arg_2680 any = map__400000452__4; if linked_2678 == nil { tmp1 = ifn_2679.Invoke_O__O(arg_2680) } else { tmp1 = linked_2678.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2677, arg_2680) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2681 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_2682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2681, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2683 lang.IFn; if linked_2682 == nil { ifn_2683 = lang.IFn_Cast(root_2681) } else { ifn_2683 = nil }; var arg_2684 any = map__400000452__4; if linked_2682 == nil { tmp2 = ifn_2683.Invoke_O__O(arg_2684) } else { tmp2 = linked_2682.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2681, arg_2684) }; map__400000452__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2685 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2686 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2685, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2687 lang.IFn; if linked_2686 == nil { ifn_2687 = lang.IFn_Cast(root_2685) } else { ifn_2687 = nil }; var arg_2688 any = map__400000452__4; if linked_2686 == nil { tmp3 = ifn_2687.Invoke_O__O(arg_2688) } else { tmp3 = linked_2686.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2685, arg_2688) }; if jrt.J2g_Truth(tmp3) { var root_2689 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2689, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2691 lang.IFn; if linked_2690 == nil { ifn_2691 = lang.IFn_Cast(root_2689) } else { ifn_2691 = nil }; var arg_2692 any = map__400000452__4; if linked_2690 == nil { map__400000452__5 = ifn_2691.Invoke_O__O(arg_2692) } else { map__400000452__5 = linked_2690.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2689, arg_2692) } } else { map__400000452__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000452__5 = map__400000452__4 }; var d__6 any = lang.RT_Get_O_O__O_NoInit(map__400000452__5, A_arbace_c2j_node_A_const_109); var tmp4 *lang.Keyword = A_arbace_c2j_node_A_const_388; if jrt.J2g_Truth(tmp4.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__6))) { var iterys__1927001035__auto____7 any; var fnbody__2808 any = A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_A_New_O_O(t.F_keys, d__6); var tmp5 *jrt.Class; var fncls__2807 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_A_fn_class; if fncls__2807 == nil { var fncls__2807d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, fnbody__2808); A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_A_fn_class = fncls__2807d; tmp5 = fncls__2807d } else { tmp5 = fncls__2807 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2808, tmp5, nil); var fs__1927001036__auto____8 any; var root_2809 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2809, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2811 lang.IFn; if linked_2810 == nil { ifn_2811 = lang.IFn_Cast(root_2809) } else { ifn_2811 = nil }; var arg_2812 any; var tmp6 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp7 any; var root_2813 any = A_arbace_c2j_node_A_const_414.GetRawRoot__O(); var linked_2814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2813, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2815 lang.IFn
														if linked_2814 == nil { ifn_2815 = lang.IFn_Cast(root_2813) } else { ifn_2815 = nil }; var arg_2816 any = A_arbace_c2j_node_A_const_415.GetRawRoot__O(); var tmp8 lang.IFn = lang.IFn_Cast(t.F_domains); var arg_2817 any = tmp8.Invoke_O__O(A_arbace_c2j_node_A_const_13.Invoke_O__O(d__6)); if linked_2814 == nil { tmp7 = ifn_2815.Invoke_O_O__O(arg_2816, arg_2817) } else { tmp7 = linked_2814.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2813, arg_2816, arg_2817) }
//line :569:1
	arg_2812 = tmp6.Invoke_O__O(tmp7); if linked_2810 == nil { fs__1927001036__auto____8 = ifn_2811.Invoke_O__O(arg_2812) } else { fs__1927001036__auto____8 = linked_2810.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2809, arg_2812) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2818 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2819 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2818, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2820 lang.IFn; if linked_2819 == nil { ifn_2820 = lang.IFn_Cast(root_2818) } else { ifn_2820 = nil }; var arg_2821 any = fs__1927001036__auto____8; var arg_2822 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__400000442); var tmp10 any; var root_2823 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2823, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2825 lang.IFn; if linked_2824 == nil { ifn_2825 = lang.IFn_Cast(root_2823) } else { ifn_2825 = nil }; var arg_2826 any = s__400000443__1; if linked_2824 == nil { tmp10 = ifn_2825.Invoke_O__O(arg_2826) } else { tmp10 = linked_2824.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2823, arg_2826) }; arg_2822 = tmp9.Invoke_O__O(tmp10); if linked_2819 == nil { return ifn_2820.Invoke_O_O__O(arg_2821, arg_2822) } else { return linked_2819.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2818, arg_2821, arg_2822) } } else { var tmp11 any; var root_2827 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2827, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2829 lang.IFn; if linked_2828 == nil { ifn_2829 = lang.IFn_Cast(root_2827) } else { ifn_2829 = nil }; var arg_2830 any = s__400000443__1; if linked_2828 == nil { tmp11 = ifn_2829.Invoke_O__O(arg_2830) } else { tmp11 = linked_2828.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2827, arg_2830) }; s__400000443__1 = tmp11; continue L1 } } else { var tmp12 any; var root_2831 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2831, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2833 lang.IFn; if linked_2832 == nil { ifn_2833 = lang.IFn_Cast(root_2831) } else { ifn_2833 = nil }; var arg_2834 any = s__400000443__1; if linked_2832 == nil { tmp12 = ifn_2833.Invoke_O__O(arg_2834) } else { tmp12 = linked_2832.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2831, arg_2834) }; s__400000443__1 = tmp12; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :569:1
func A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_A{}; t.Ctor_O_O(p0, p1); return t }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_A) Ctor_O_O(c__keys, c__d any) { t.F_keys = c__keys; t.F_d = c__d }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_A) Invoke_O_O__O(self, s__400000445__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2806 any = A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_A_New_O_O_O_O(self, s__400000445__1, t.F_keys, t.F_d); var tmp2 *jrt.Class; var fncls__2805 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_A_fn_class; if fncls__2805 == nil { var fncls__2805d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__2806); A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_A_fn_class = fncls__2805d; tmp2 = fncls__2805d } else { tmp2 = fncls__2805 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2806, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :569:1
func A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_A) Ctor_O_O_O_O(c__iter__400000444, c__s__400000445, c__keys, c__d any) { t.F_iter__400000444 = c__iter__400000444; t.F_s__400000445 = c__s__400000445; t.F_keys = c__keys; t.F_d = c__d }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_A) Invoke_O__O(self any) any { { var s__400000445__1 any; var t_ any = t.F_s__400000445; t.F_s__400000445 = nil; s__400000445__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2693 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2693, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2695 lang.IFn; if linked_2694 == nil { ifn_2695 = lang.IFn_Cast(root_2693) } else { ifn_2695 = nil }; var arg_2696 any = s__400000445__1; if linked_2694 == nil { temp__1927000414__auto____2 = ifn_2695.Invoke_O__O(arg_2696) } else { temp__1927000414__auto____2 = linked_2694.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2693, arg_2696) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__400000456__4 any; var root_2697 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2697, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2699 lang.IFn; if linked_2698 == nil { ifn_2699 = lang.IFn_Cast(root_2697) } else { ifn_2699 = nil }; var arg_2700 any = xs__1927001018__auto____3; if linked_2698 == nil { vec__400000456__4 = ifn_2699.Invoke_O__O(arg_2700) } else { vec__400000456__4 = linked_2698.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2697, arg_2700) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000456__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ms__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000456__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var fnbody__2782 any = A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_A_New_O_O_O(k__5, t.F_keys, t.F_d); var tmp1 *jrt.Class; var fncls__2781 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_A_fn_class; if fncls__2781 == nil { var fncls__2781d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__2782); A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_A_fn_class = fncls__2781d; tmp1 = fncls__2781d } else { tmp1 = fncls__2781 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2782, tmp1, nil); var fs__1927001036__auto____8 any; var root_2783 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2783, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2785 lang.IFn; if linked_2784 == nil { ifn_2785 = lang.IFn_Cast(root_2783) } else { ifn_2785 = nil }; var arg_2786 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp3 any; var root_2787 any = A_arbace_c2j_node_A_const_281.GetRawRoot__O(); var linked_2788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2787, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2789 lang.IFn

	if linked_2788 == nil { ifn_2789 = lang.IFn_Cast(root_2787) } else { ifn_2789 = nil }; var arg_2790 any = A_arbace_c2j_node_A_const_394.GetRawRoot__O(); var arg_2791 any = ms__6; if linked_2788 == nil { tmp3 = ifn_2789.Invoke_O_O__O(arg_2790, arg_2791) } else { tmp3 = linked_2788.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2787, arg_2790, arg_2791) }
//line :569:1
	arg_2786 = tmp2.Invoke_O__O(tmp3); if linked_2784 == nil { fs__1927001036__auto____8 = ifn_2785.Invoke_O__O(arg_2786) } else { fs__1927001036__auto____8 = linked_2784.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2783, arg_2786) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2792 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2793 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2792, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2794 lang.IFn; if linked_2793 == nil { ifn_2794 = lang.IFn_Cast(root_2792) } else { ifn_2794 = nil }; var arg_2795 any = fs__1927001036__auto____8; var arg_2796 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000444); var tmp5 any; var root_2797 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2797, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2799 lang.IFn; if linked_2798 == nil { ifn_2799 = lang.IFn_Cast(root_2797) } else { ifn_2799 = nil }; var arg_2800 any = s__400000445__1; if linked_2798 == nil { tmp5 = ifn_2799.Invoke_O__O(arg_2800) } else { tmp5 = linked_2798.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2797, arg_2800) }; arg_2796 = tmp4.Invoke_O__O(tmp5); if linked_2793 == nil { return ifn_2794.Invoke_O_O__O(arg_2795, arg_2796) } else { return linked_2793.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2792, arg_2795, arg_2796) } } else { var tmp6 any; var root_2801 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2801, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2803 lang.IFn; if linked_2802 == nil { ifn_2803 = lang.IFn_Cast(root_2801) } else { ifn_2803 = nil }; var arg_2804 any = s__400000445__1; if linked_2802 == nil { tmp6 = ifn_2803.Invoke_O__O(arg_2804) } else { tmp6 = linked_2802.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2801, arg_2804) }; s__400000445__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :569:1
func A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_A) Ctor_O_O_O(c__k, c__keys, c__d any) { t.F_k = c__k; t.F_keys = c__keys; t.F_d = c__d }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_A) Invoke_O_O__O(self, s__400000447__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2780 any = A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_A_New_O_O_O_O_O(self, t.F_k, s__400000447__1, t.F_keys, t.F_d); var tmp2 *jrt.Class; var fncls__2779 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_A_fn_class; if fncls__2779 == nil { var fncls__2779d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__2780); A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_A_fn_class = fncls__2779d; tmp2 = fncls__2779d } else { tmp2 = fncls__2779 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2780, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :569:1
func A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_A) Ctor_O_O_O_O_O(c__iter__400000446, c__k, c__s__400000447, c__keys, c__d any) { t.F_iter__400000446 = c__iter__400000446; t.F_k = c__k; t.F_s__400000447 = c__s__400000447; t.F_keys = c__keys; t.F_d = c__d }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_A) Invoke_O__O(self any) any { { var s__400000447__1 any; var t_ any = t.F_s__400000447; t.F_s__400000447 = nil; s__400000447__1 = t_; for { var temp__1927000414__auto____2 any; var root_2701 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2701, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2703 lang.IFn; if linked_2702 == nil { ifn_2703 = lang.IFn_Cast(root_2701) } else { ifn_2703 = nil }; var arg_2704 any = s__400000447__1; if linked_2702 == nil { temp__1927000414__auto____2 = ifn_2703.Invoke_O__O(arg_2704) } else { temp__1927000414__auto____2 = linked_2702.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2701, arg_2704) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000447__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2705 any = A_arbace_c2j_node_A_const_380.GetRawRoot__O(); var linked_2706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2705, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2707 lang.IFn; if linked_2706 == nil { ifn_2707 = lang.IFn_Cast(root_2705) } else { ifn_2707 = nil }; var arg_2708 any = s__400000447__3; if linked_2706 == nil { tmp1 = ifn_2707.Invoke_O__O(arg_2708) } else { tmp1 = linked_2706.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2705, arg_2708) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2709 any = A_arbace_c2j_node_A_const_381.GetRawRoot__O(); var linked_2710 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2709, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2711 lang.IFn; if linked_2710 == nil { ifn_2711 = lang.IFn_Cast(root_2709) } else { ifn_2711 = nil }; var arg_2712 any = s__400000447__3; if linked_2710 == nil { c__1927001037__auto____4 = ifn_2711.Invoke_O__O(arg_2712) } else { c__1927001037__auto____4 = linked_2710.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2709, arg_2712) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000449__6 any; var root_2713 any = A_arbace_c2j_node_A_const_382.GetRawRoot__O(); var linked_2714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2713, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2715 lang.IFn; if linked_2714 == nil { ifn_2715 = lang.IFn_Cast(root_2713) } else { ifn_2715 = nil }; var arg_2716 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2714 == nil { b__400000449__6 = ifn_2715.Invoke_O__O(arg_2716) } else { b__400000449__6 = linked_2714.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2713, arg_2716) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2733 any = A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_fn__400000461_A_New_O_O_O_I_O_O(t.F_k, t.F_keys, b__400000449__6, size__1927001038__auto____5, t.F_d, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2732 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_fn__400000461_A_fn_class; if fncls__2732 == nil { var fncls__2732d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__2733); A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_fn__400000461_A_fn_class = fncls__2732d; tmp3 = fncls__2732d } else { tmp3 = fncls__2732 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2733, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2734 any = A_arbace_c2j_node_A_const_384.GetRawRoot__O(); var linked_2735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2734, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2736 lang.IFn; if linked_2735 == nil { ifn_2736 = lang.IFn_Cast(root_2734) } else { ifn_2736 = nil }; var arg_2737 any; var root_2739 any = A_arbace_c2j_node_A_const_385.GetRawRoot__O(); var linked_2740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2739, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2741 lang.IFn; if linked_2740 == nil { ifn_2741 = lang.IFn_Cast(root_2739) } else { ifn_2741 = nil }; var arg_2742 any = b__400000449__6; if linked_2740 == nil { arg_2737 = ifn_2741.Invoke_O__O(arg_2742) } else { arg_2737 = linked_2740.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2739, arg_2742) }; var arg_2738 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000446); var tmp5 any; var root_2743 any = A_arbace_c2j_node_A_const_386.GetRawRoot__O(); var linked_2744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2743, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2745 lang.IFn; if linked_2744 == nil { ifn_2745 = lang.IFn_Cast(root_2743) } else { ifn_2745 = nil }; var arg_2746 any = s__400000447__3; if linked_2744 == nil { tmp5 = ifn_2745.Invoke_O__O(arg_2746) } else { tmp5 = linked_2744.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2743, arg_2746) }; arg_2738 = tmp4.Invoke_O__O(tmp5); if linked_2735 == nil { return ifn_2736.Invoke_O_O__O(arg_2737, arg_2738) } else { return linked_2735.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2734, arg_2737, arg_2738) } } else { var root_2747 any = A_arbace_c2j_node_A_const_384.GetRawRoot__O(); var linked_2748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2747, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2749 lang.IFn; if linked_2748 == nil { ifn_2749 = lang.IFn_Cast(root_2747) } else { ifn_2749 = nil }; var arg_2750 any; var root_2752 any = A_arbace_c2j_node_A_const_385.GetRawRoot__O(); var linked_2753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2752, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2754 lang.IFn; if linked_2753 == nil { ifn_2754 = lang.IFn_Cast(root_2752) } else { ifn_2754 = nil }; var arg_2755 any = b__400000449__6; if linked_2753 == nil { arg_2750 = ifn_2754.Invoke_O__O(arg_2755) } else { arg_2750 = linked_2753.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2752, arg_2755) }; var arg_2751 any; if linked_2748 == nil { return ifn_2749.Invoke_O_O__O(arg_2750, arg_2751) } else { return linked_2748.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2747, arg_2750, arg_2751) } } } else { var vec__400000466__4 any; var root_2756 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2756, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2758 lang.IFn; if linked_2757 == nil { ifn_2758 = lang.IFn_Cast(root_2756) } else { ifn_2758 = nil }; var arg_2759 any = s__400000447__3; if linked_2757 == nil { vec__400000466__4 = ifn_2758.Invoke_O__O(arg_2759) } else { vec__400000466__4 = linked_2757.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2756, arg_2759) }; var i__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000466__4, lang.RT_IntCast_J__I_NoInit(0), nil); var m__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000466__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2760 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2760, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2762 lang.IFn; if linked_2761 == nil { ifn_2762 = lang.IFn_Cast(root_2760) } else { ifn_2762 = nil }; var arg_2763 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_keys); var tmp7 any = lang.IFn_Cast(tmp6.Invoke_O__O(A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d))).Invoke_O__O(m__6); var tmp8 jrt.Number_I; var na_2765 any; var na_2767 any = t.F_k
																								var na_2768 int64 = 10000

	if jrt.Long_InstanceOf(na_2767) { var n0_2769 int64 = jrt.NN(jrt.Long_Cast(na_2767)).LongValue__J(); var n1_2770 int64 = na_2768; var nr_2771 int64 = n0_2769 * n1_2770; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; tmp12 = n0_2769 == -9223372036854775808; if tmp12 { tmp12 = n1_2770 < 0 }; tmp11 = tmp12; tmp10 = !tmp11; if tmp10 { var tmp13 bool; tmp13 = n1_2770 == 0; if !tmp13 { tmp13 = nr_2771/n1_2770 == n0_2769 }; tmp10 = tmp13 }; tmp9 = tmp10; if tmp9 { na_2765 = jrt.Long_ValueOf_J__Long_NoInit(nr_2771).Ref() } else { na_2765 = lang.Numbers_Multiply_O_J__Number_NoInit(na_2767, na_2768) } } else { na_2765 = lang.Numbers_Multiply_O_J__Number_NoInit(na_2767, na_2768) }; var na_2766 any = i__5; var tmp14 bool; var tmp15 bool; tmp15 = jrt.Long_InstanceOf(na_2765); if tmp15 { tmp15 = jrt.Long_InstanceOf(na_2766) }; tmp14 = tmp15; if tmp14 { var n0_2772 int64 = jrt.NN(jrt.Long_Cast(na_2765)).LongValue__J(); var n1_2773 int64 = jrt.NN(jrt.Long_Cast(na_2766)).LongValue__J(); var nr_2774 int64 = n0_2772 + n1_2773; if (n0_2772^nr_2774)&(n1_2773^nr_2774) >= 0 { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2774)) } else { tmp8 = lang.Numbers_Add_O_O__Number_NoInit(na_2765, na_2766) } } else { var tmp16 bool; var tmp17 bool; tmp17 = jrt.Double_InstanceOf(na_2765); if tmp17 { tmp17 = jrt.Double_InstanceOf(na_2766) }; tmp16 = tmp17; if tmp16 { var n0_2772_2 float64 = jrt.NN(jrt.Double_Cast(na_2765)).DoubleValue__D(); var n1_2773_2 float64 = jrt.NN(jrt.Double_Cast(na_2766)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_2772_2 + n1_2773_2)) } else { tmp8 = lang.Numbers_Add_O_O__Number_NoInit(na_2765, na_2766) } }
//line :569:1
	arg_2763 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, tmp8); var arg_2764 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__400000446); var tmp19 any; var root_2775 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2775, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2777 lang.IFn; if linked_2776 == nil { ifn_2777 = lang.IFn_Cast(root_2775) } else { ifn_2777 = nil }; var arg_2778 any = s__400000447__3; if linked_2776 == nil { tmp19 = ifn_2777.Invoke_O__O(arg_2778) } else { tmp19 = linked_2776.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2775, arg_2778) }; arg_2764 = tmp18.Invoke_O__O(tmp19); if linked_2761 == nil { return ifn_2762.Invoke_O_O__O(arg_2763, arg_2764) } else { return linked_2761.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2760, arg_2763, arg_2764) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :569:1
func A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_fn__400000461_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_fn__400000461_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_fn__400000461_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_fn__400000461_A) Ctor_O_O_O_I_O_O(c__k, c__keys, c__b__400000449 any, c__size__1927001038__auto__ int32, c__d, c__c__1927001037__auto__ any) { t.F_k = c__k; t.F_keys = c__keys; t.F_b__400000449 = c__b__400000449; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_d = c__d; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_fn__400000461_A) Invoke_O__O(self any) any { { var i__400000448__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000448__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__400000462__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000448__1)); var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000462__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000462__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2717 any = A_arbace_c2j_node_A_const_383.GetRawRoot__O(); var linked_2718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2717, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2719 lang.IFn; if linked_2718 == nil { ifn_2719 = lang.IFn_Cast(root_2717) } else { ifn_2719 = nil }; var arg_2720 any = t.F_b__400000449; var arg_2721 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_keys); var tmp3 any = lang.IFn_Cast(tmp2.Invoke_O__O(A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d))).Invoke_O__O(m__4); var tmp4 jrt.Number_I; var na_2722 any; var na_2724 any = t.F_k
																										var na_2725 int64 = 10000

	if jrt.Long_InstanceOf(na_2724) { var n0_2726 int64 = jrt.NN(jrt.Long_Cast(na_2724)).LongValue__J(); var n1_2727 int64 = na_2725; var nr_2728 int64 = n0_2726 * n1_2727; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; tmp8 = n0_2726 == -9223372036854775808; if tmp8 { tmp8 = n1_2727 < 0 }; tmp7 = tmp8; tmp6 = !tmp7; if tmp6 { var tmp9 bool; tmp9 = n1_2727 == 0; if !tmp9 { tmp9 = nr_2728/n1_2727 == n0_2726 }; tmp6 = tmp9 }; tmp5 = tmp6; if tmp5 { na_2722 = jrt.Long_ValueOf_J__Long_NoInit(nr_2728).Ref() } else { na_2722 = lang.Numbers_Multiply_O_J__Number_NoInit(na_2724, na_2725) } } else { na_2722 = lang.Numbers_Multiply_O_J__Number_NoInit(na_2724, na_2725) }; var na_2723 any = i__3; var tmp10 bool; var tmp11 bool; tmp11 = jrt.Long_InstanceOf(na_2722); if tmp11 { tmp11 = jrt.Long_InstanceOf(na_2723) }; tmp10 = tmp11; if tmp10 { var n0_2729 int64 = jrt.NN(jrt.Long_Cast(na_2722)).LongValue__J(); var n1_2730 int64 = jrt.NN(jrt.Long_Cast(na_2723)).LongValue__J(); var nr_2731 int64 = n0_2729 + n1_2730; if (n0_2729^nr_2731)&(n1_2730^nr_2731) >= 0 { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2731)) } else { tmp4 = lang.Numbers_Add_O_O__Number_NoInit(na_2722, na_2723) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_2722); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_2723) }; tmp12 = tmp13; if tmp12 { var n0_2729_2 float64 = jrt.NN(jrt.Double_Cast(na_2722)).DoubleValue__D(); var n1_2730_2 float64 = jrt.NN(jrt.Double_Cast(na_2723)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_2729_2 + n1_2730_2)) } else { tmp4 = lang.Numbers_Add_O_O__Number_NoInit(na_2722, na_2723) } }
//line :569:1
	arg_2721 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4); if linked_2718 == nil { ifn_2719.Invoke_O_O__O(arg_2720, arg_2721) } else { linked_2718.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2717, arg_2720, arg_2721) }; i__400000448__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000448__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_c2j_node_code_forms_iter__400000475__400000481_A_New() *A_arbace_c2j_node_code_forms_iter__400000475__400000481_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000475__400000481_A{}; t.Ctor(); return t }
//line :574:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_A) Ctor() {}
//line :574:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_A) Invoke_O_O__O(self, s__400000476__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3036 any = A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_A_New_O_O(s__400000476__1, self); var tmp2 *jrt.Class; var fncls__3035 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_A_fn_class; if fncls__3035 == nil { var fncls__3035d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__3036); A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_A_fn_class = fncls__3035d; tmp2 = fncls__3035d } else { tmp2 = fncls__3035 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3036, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :574:1
func A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_A{}; t.Ctor_O_O(p0, p1); return t }
//line :574:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_A) Ctor_O_O(c__s__400000476, c__iter__400000475 any) { t.F_s__400000476 = c__s__400000476; t.F_iter__400000475 = c__iter__400000475 }
//line :574:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_A) Invoke_O__O(self any) any { { var s__400000476__1 any; var t_ any = t.F_s__400000476; t.F_s__400000476 = nil; s__400000476__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2844 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2844, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2846 lang.IFn; if linked_2845 == nil { ifn_2846 = lang.IFn_Cast(root_2844) } else { ifn_2846 = nil }; var arg_2847 any = s__400000476__1; if linked_2845 == nil { temp__1927000414__auto____2 = ifn_2846.Invoke_O__O(arg_2847) } else { temp__1927000414__auto____2 = linked_2845.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2844, arg_2847) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__400000483__4 any; var root_2848 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2848, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2850 lang.IFn; if linked_2849 == nil { ifn_2850 = lang.IFn_Cast(root_2848) } else { ifn_2850 = nil }; var arg_2851 any = xs__1927001018__auto____3; if linked_2849 == nil { map__400000483__4 = ifn_2850.Invoke_O__O(arg_2851) } else { map__400000483__4 = linked_2849.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2848, arg_2851) }; var map__400000483__5 any; if lang.ISeq_InstanceOf(map__400000483__4) { var tmp1 any; var root_2852 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2852, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2854 lang.IFn; if linked_2853 == nil { ifn_2854 = lang.IFn_Cast(root_2852) } else { ifn_2854 = nil }; var arg_2855 any = map__400000483__4; if linked_2853 == nil { tmp1 = ifn_2854.Invoke_O__O(arg_2855) } else { tmp1 = linked_2853.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2852, arg_2855) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2856 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_2857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2856, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2858 lang.IFn; if linked_2857 == nil { ifn_2858 = lang.IFn_Cast(root_2856) } else { ifn_2858 = nil }; var arg_2859 any = map__400000483__4; if linked_2857 == nil { tmp2 = ifn_2858.Invoke_O__O(arg_2859) } else { tmp2 = linked_2857.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2856, arg_2859) }; map__400000483__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2860 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2860, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2862 lang.IFn; if linked_2861 == nil { ifn_2862 = lang.IFn_Cast(root_2860) } else { ifn_2862 = nil }; var arg_2863 any = map__400000483__4; if linked_2861 == nil { tmp3 = ifn_2862.Invoke_O__O(arg_2863) } else { tmp3 = linked_2861.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2860, arg_2863) }; if jrt.J2g_Truth(tmp3) { var root_2864 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2864, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2866 lang.IFn; if linked_2865 == nil { ifn_2866 = lang.IFn_Cast(root_2864) } else { ifn_2866 = nil }; var arg_2867 any = map__400000483__4; if linked_2865 == nil { map__400000483__5 = ifn_2866.Invoke_O__O(arg_2867) } else { map__400000483__5 = linked_2865.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2864, arg_2867) } } else { map__400000483__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000483__5 = map__400000483__4 }; var d__6 any = lang.RT_Get_O_O__O_NoInit(map__400000483__5, A_arbace_c2j_node_A_const_109); var vs__7 any = lang.RT_Get_O_O__O_NoInit(map__400000483__5, A_arbace_c2j_node_A_const_451); var iterys__1927001035__auto____8 any; var fnbody__3017 any = A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_A_New_O(d__6); var tmp4 *jrt.Class; var fncls__3016 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_A_fn_class; if fncls__3016 == nil { var fncls__3016d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__3017); A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_A_fn_class = fncls__3016d; tmp4 = fncls__3016d } else { tmp4 = fncls__3016 }; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3017, tmp4, nil); var fs__1927001036__auto____9 any; var root_3018 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_3019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3018, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3020 lang.IFn; if linked_3019 == nil { ifn_3020 = lang.IFn_Cast(root_3018) } else { ifn_3020 = nil }; var arg_3021 any = lang.IFn_Cast(iterys__1927001035__auto____8).Invoke_O__O(vs__7); if linked_3019 == nil { fs__1927001036__auto____9 = ifn_3020.Invoke_O__O(arg_3021) } else { fs__1927001036__auto____9 = linked_3019.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3018, arg_3021) }; if jrt.J2g_Truth(fs__1927001036__auto____9) { var root_3022 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_3023 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3022, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3024 lang.IFn; if linked_3023 == nil { ifn_3024 = lang.IFn_Cast(root_3022) } else { ifn_3024 = nil }; var arg_3025 any = fs__1927001036__auto____9; var arg_3026 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__400000475); var tmp6 any; var root_3027 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_3028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3027, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3029 lang.IFn; if linked_3028 == nil { ifn_3029 = lang.IFn_Cast(root_3027) } else { ifn_3029 = nil }; var arg_3030 any = s__400000476__1; if linked_3028 == nil { tmp6 = ifn_3029.Invoke_O__O(arg_3030) } else { tmp6 = linked_3028.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3027, arg_3030) }; arg_3026 = tmp5.Invoke_O__O(tmp6); if linked_3023 == nil { return ifn_3024.Invoke_O_O__O(arg_3025, arg_3026) } else { return linked_3023.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3022, arg_3025, arg_3026) } } else { var tmp7 any; var root_3031 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_3032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3031, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3033 lang.IFn; if linked_3032 == nil { ifn_3033 = lang.IFn_Cast(root_3031) } else { ifn_3033 = nil }; var arg_3034 any = s__400000476__1; if linked_3032 == nil { tmp7 = ifn_3033.Invoke_O__O(arg_3034) } else { tmp7 = linked_3032.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3031, arg_3034) }; s__400000476__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :574:1
func A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_A_New_O(p0 any) *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_A{}; t.Ctor_O(p0); return t }
//line :574:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :574:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_A) Invoke_O_O__O(self, s__400000478__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3015 any = A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_A_New_O_O_O(self, s__400000478__1, t.F_d); var tmp2 *jrt.Class; var fncls__3014 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_A_fn_class; if fncls__3014 == nil { var fncls__3014d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__3015); A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_A_fn_class = fncls__3014d; tmp2 = fncls__3014d } else { tmp2 = fncls__3014 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3015, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :574:1
func A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :574:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_A) Ctor_O_O_O(c__iter__400000477, c__s__400000478, c__d any) { t.F_iter__400000477 = c__iter__400000477; t.F_s__400000478 = c__s__400000478; t.F_d = c__d }
//line :574:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_A) Invoke_O__O(self any) any { { var s__400000478__1 any; var t_ any = t.F_s__400000478; t.F_s__400000478 = nil; s__400000478__1 = t_; for { var temp__1927000414__auto____2 any; var root_2868 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2868, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2870 lang.IFn; if linked_2869 == nil { ifn_2870 = lang.IFn_Cast(root_2868) } else { ifn_2870 = nil }; var arg_2871 any = s__400000478__1; if linked_2869 == nil { temp__1927000414__auto____2 = ifn_2870.Invoke_O__O(arg_2871) } else { temp__1927000414__auto____2 = linked_2869.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2868, arg_2871) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000478__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2872 any = A_arbace_c2j_node_A_const_380.GetRawRoot__O(); var linked_2873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2872, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2874 lang.IFn; if linked_2873 == nil { ifn_2874 = lang.IFn_Cast(root_2872) } else { ifn_2874 = nil }; var arg_2875 any = s__400000478__3; if linked_2873 == nil { tmp1 = ifn_2874.Invoke_O__O(arg_2875) } else { tmp1 = linked_2873.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2872, arg_2875) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2876 any = A_arbace_c2j_node_A_const_381.GetRawRoot__O(); var linked_2877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2876, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2878 lang.IFn; if linked_2877 == nil { ifn_2878 = lang.IFn_Cast(root_2876) } else { ifn_2878 = nil }; var arg_2879 any = s__400000478__3; if linked_2877 == nil { c__1927001037__auto____4 = ifn_2878.Invoke_O__O(arg_2879) } else { c__1927001037__auto____4 = linked_2877.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2876, arg_2879) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000480__6 any; var root_2880 any = A_arbace_c2j_node_A_const_382.GetRawRoot__O(); var linked_2881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2880, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2882 lang.IFn; if linked_2881 == nil { ifn_2882 = lang.IFn_Cast(root_2880) } else { ifn_2882 = nil }; var arg_2883 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2881 == nil { b__400000480__6 = ifn_2882.Invoke_O__O(arg_2883) } else { b__400000480__6 = linked_2881.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2880, arg_2883) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2934 any = A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_A_New_O_I_O_O(b__400000480__6, size__1927001038__auto____5, t.F_d, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2933 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_A_fn_class; if fncls__2933 == nil { var fncls__2933d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__2934); A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_A_fn_class = fncls__2933d; tmp3 = fncls__2933d } else { tmp3 = fncls__2933 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2934, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2935 any = A_arbace_c2j_node_A_const_384.GetRawRoot__O(); var linked_2936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2935, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2937 lang.IFn; if linked_2936 == nil { ifn_2937 = lang.IFn_Cast(root_2935) } else { ifn_2937 = nil }; var arg_2938 any; var root_2940 any = A_arbace_c2j_node_A_const_385.GetRawRoot__O(); var linked_2941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2940, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2942 lang.IFn; if linked_2941 == nil { ifn_2942 = lang.IFn_Cast(root_2940) } else { ifn_2942 = nil }; var arg_2943 any = b__400000480__6; if linked_2941 == nil { arg_2938 = ifn_2942.Invoke_O__O(arg_2943) } else { arg_2938 = linked_2941.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2940, arg_2943) }; var arg_2939 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000477); var tmp5 any; var root_2944 any = A_arbace_c2j_node_A_const_386.GetRawRoot__O(); var linked_2945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2944, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2946 lang.IFn; if linked_2945 == nil { ifn_2946 = lang.IFn_Cast(root_2944) } else { ifn_2946 = nil }; var arg_2947 any = s__400000478__3; if linked_2945 == nil { tmp5 = ifn_2946.Invoke_O__O(arg_2947) } else { tmp5 = linked_2945.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2944, arg_2947) }; arg_2939 = tmp4.Invoke_O__O(tmp5); if linked_2936 == nil { return ifn_2937.Invoke_O_O__O(arg_2938, arg_2939) } else { return linked_2936.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2935, arg_2938, arg_2939) } } else { var root_2948 any = A_arbace_c2j_node_A_const_384.GetRawRoot__O(); var linked_2949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2948, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2950 lang.IFn; if linked_2949 == nil { ifn_2950 = lang.IFn_Cast(root_2948) } else { ifn_2950 = nil }; var arg_2951 any; var root_2953 any = A_arbace_c2j_node_A_const_385.GetRawRoot__O(); var linked_2954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2953, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2955 lang.IFn; if linked_2954 == nil { ifn_2955 = lang.IFn_Cast(root_2953) } else { ifn_2955 = nil }; var arg_2956 any = b__400000480__6; if linked_2954 == nil { arg_2951 = ifn_2955.Invoke_O__O(arg_2956) } else { arg_2951 = linked_2954.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2953, arg_2956) }; var arg_2952 any; if linked_2949 == nil { return ifn_2950.Invoke_O_O__O(arg_2951, arg_2952) } else { return linked_2949.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2948, arg_2951, arg_2952) } } } else { var map__400000497__4 any; var root_2957 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2957, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2959 lang.IFn; if linked_2958 == nil { ifn_2959 = lang.IFn_Cast(root_2957) } else { ifn_2959 = nil }; var arg_2960 any = s__400000478__3; if linked_2958 == nil { map__400000497__4 = ifn_2959.Invoke_O__O(arg_2960) } else { map__400000497__4 = linked_2958.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2957, arg_2960) }; var map__400000497__5 any; if lang.ISeq_InstanceOf(map__400000497__4) { var tmp6 any; var root_2961 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2961, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2963 lang.IFn; if linked_2962 == nil { ifn_2963 = lang.IFn_Cast(root_2961) } else { ifn_2963 = nil }; var arg_2964 any = map__400000497__4; if linked_2962 == nil { tmp6 = ifn_2963.Invoke_O__O(arg_2964) } else { tmp6 = linked_2962.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2961, arg_2964) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_2965 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_2966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2965, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2967 lang.IFn; if linked_2966 == nil { ifn_2967 = lang.IFn_Cast(root_2965) } else { ifn_2967 = nil }; var arg_2968 any = map__400000497__4; if linked_2966 == nil { tmp7 = ifn_2967.Invoke_O__O(arg_2968) } else { tmp7 = linked_2966.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2965, arg_2968) }; map__400000497__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp7)).Ref() } else { var tmp8 any; var root_2969 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2969, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2971 lang.IFn; if linked_2970 == nil { ifn_2971 = lang.IFn_Cast(root_2969) } else { ifn_2971 = nil }; var arg_2972 any = map__400000497__4; if linked_2970 == nil { tmp8 = ifn_2971.Invoke_O__O(arg_2972) } else { tmp8 = linked_2970.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2969, arg_2972) }; if jrt.J2g_Truth(tmp8) { var root_2973 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2973, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2975 lang.IFn; if linked_2974 == nil { ifn_2975 = lang.IFn_Cast(root_2973) } else { ifn_2975 = nil }; var arg_2976 any = map__400000497__4; if linked_2974 == nil { map__400000497__5 = ifn_2975.Invoke_O__O(arg_2976) } else { map__400000497__5 = linked_2974.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2973, arg_2976) } } else { map__400000497__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000497__5 = map__400000497__4 }; var v__6 any = lang.RT_Get_O_O__O_NoInit(map__400000497__5, A_arbace_c2j_node_A_const_56); var cf__7 any = lang.RT_Get_O_O__O_NoInit(map__400000497__5, A_arbace_c2j_node_A_const_453); var root_2977 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2977, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2979 lang.IFn; if linked_2978 == nil { ifn_2979 = lang.IFn_Cast(root_2977) } else { ifn_2979 = nil }; var arg_2980 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_34, nil, nil, nil, nil); var tmp10 any = A_arbace_c2j_node_A_const_328.Invoke_O__O(v__6); var tmp11 any = A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d); var tmp12 *jrt.String; var temp__1927000414__auto____14 any; var root_2982 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2982, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2984 lang.IFn

	if linked_2983 == nil { ifn_2984 = lang.IFn_Cast(root_2982) } else { ifn_2984 = nil }; var arg_2985 any; var root_2986 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_2987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2986, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2988 lang.IFn; if linked_2987 == nil { ifn_2988 = lang.IFn_Cast(root_2986) } else { ifn_2988 = nil }; var arg_2989 any; var fnbody__2996 any = A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000500_A_New(); var tmp13 *jrt.Class; var fncls__2995 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000500_A_fn_class; if fncls__2995 == nil { var fncls__2995d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000500_A_fn_class = fncls__2995d; tmp13 = fncls__2995d } else { tmp13 = fncls__2995 }; arg_2989 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2996, tmp13, nil); var arg_2990 any = A_arbace_c2j_node_A_const_234.Invoke_O__O(v__6); if linked_2987 == nil { arg_2985 = ifn_2988.Invoke_O_O__O(arg_2989, arg_2990) } else { arg_2985 = linked_2987.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2986, arg_2989, arg_2990) }; if linked_2983 == nil { temp__1927000414__auto____14 = ifn_2984.Invoke_O__O(arg_2985) } else { temp__1927000414__auto____14 = linked_2983.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2982, arg_2985) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var s__15 any = temp__1927000414__auto____14; var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp15 any; var root_2997 any = A_arbace_c2j_node_A_const_458.GetRawRoot__O(); var linked_2998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2997, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2999 lang.IFn; if linked_2998 == nil { ifn_2999 = lang.IFn_Cast(root_2997) } else { ifn_2999 = nil }; var arg_3000 any = Lit_36; var arg_3001 any = s__15; if linked_2998 == nil { tmp15 = ifn_2999.Invoke_O_O__O(arg_3000, arg_3001) } else { tmp15 = linked_2998.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2997, arg_3000, arg_3001) }; tmp12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15)) } else { tmp12 = nil }
//line :574:1
	var tmp16 any = tmp12.Ref(); var tmp17 *jrt.String; var tmp18 any; var root_3002 any = A_arbace_c2j_node_A_const_393.GetRawRoot__O(); var linked_3003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3002, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_3004 lang.IFn


	if linked_3003 == nil { ifn_3004 = lang.IFn_Cast(root_3002) } else { ifn_3004 = nil }; var arg_3005 any = A_arbace_c2j_node_A_const_221.Invoke_O__O(v__6); if linked_3003 == nil { tmp18 = ifn_3004.Invoke_O__O(arg_3005) } else { tmp18 = linked_3003.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_3002, arg_3005) }; if jrt.J2g_Truth(tmp18) { var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp20 *jrt.String; var tmp21 any = A_arbace_c2j_node_A_const_220; if lang.Util_Equiv_O_O__Z_NoInit(tmp21, A_arbace_c2j_node_A_const_221.Invoke_O__O(v__6)) { tmp20 = Lit_37 } else { tmp20 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_221.Invoke_O__O(v__6), nil)) }; tmp17 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, tmp20.Ref())) } else { tmp17 = nil }
//line :574:1
	var tmp22 any = tmp17.Ref(); var tmp23 *jrt.String



	if jrt.J2g_Truth(A_arbace_c2j_node_A_const_177.Invoke_O__O(v__6)) { var tmp24 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil, nil); var tmp25 any; var root_3006 any = A_arbace_c2j_node_A_const_457.GetRawRoot__O(); var linked_3007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3006, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_3008 lang.IFn; if linked_3007 == nil { ifn_3008 = lang.IFn_Cast(root_3006) } else { ifn_3008 = nil }; var arg_3009 any = A_arbace_c2j_node_A_const_390.Invoke_O__O(v__6); if linked_3007 == nil { tmp25 = ifn_3008.Invoke_O__O(arg_3009) } else { tmp25 = linked_3007.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_3006, arg_3009) }; var tmp26 any = tmp25; var tmp27 *jrt.String; if jrt.J2g_Truth(A_arbace_c2j_node_A_const_73.Invoke_O__O(v__6)) { tmp27 = Lit_39 } else { tmp27 = nil }; tmp23 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp24, jrt.RefArrayOf(jrt.Object_class, nil, tmp26, tmp27.Ref())) } else { tmp23 = nil }
//line :574:1
	arg_2980 = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp10, nil, tmp11, tmp16, tmp22, tmp23.Ref())).Ref(), cf__7); var arg_2981 any; var tmp28 lang.IFn = lang.IFn_Cast(t.F_iter__400000477); var tmp29 any; var root_3010 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_3011 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3010, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3012 lang.IFn; if linked_3011 == nil { ifn_3012 = lang.IFn_Cast(root_3010) } else { ifn_3012 = nil }; var arg_3013 any = s__400000478__3; if linked_3011 == nil { tmp29 = ifn_3012.Invoke_O__O(arg_3013) } else { tmp29 = linked_3011.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3010, arg_3013) }; arg_2981 = tmp28.Invoke_O__O(tmp29); if linked_2978 == nil { return ifn_2979.Invoke_O_O__O(arg_2980, arg_2981) } else { return linked_2978.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2977, arg_2980, arg_2981) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :574:1
func A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :574:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_A) Ctor_O_I_O_O(c__b__400000480 any, c__size__1927001038__auto__ int32, c__d, c__c__1927001037__auto__ any) { t.F_b__400000480 = c__b__400000480; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_d = c__d; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :574:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_A) Invoke_O__O(self any) any { { var i__400000479__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000479__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__400000488__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000479__1)); var map__400000488__3 any; if lang.ISeq_InstanceOf(map__400000488__2) { var tmp2 any; var root_2884 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2884, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2886 lang.IFn; if linked_2885 == nil { ifn_2886 = lang.IFn_Cast(root_2884) } else { ifn_2886 = nil }; var arg_2887 any = map__400000488__2; if linked_2885 == nil { tmp2 = ifn_2886.Invoke_O__O(arg_2887) } else { tmp2 = linked_2885.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2884, arg_2887) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_2888 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_2889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2888, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2890 lang.IFn; if linked_2889 == nil { ifn_2890 = lang.IFn_Cast(root_2888) } else { ifn_2890 = nil }; var arg_2891 any = map__400000488__2; if linked_2889 == nil { tmp3 = ifn_2890.Invoke_O__O(arg_2891) } else { tmp3 = linked_2889.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2888, arg_2891) }; map__400000488__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp3)).Ref() } else { var tmp4 any; var root_2892 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2892, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2894 lang.IFn; if linked_2893 == nil { ifn_2894 = lang.IFn_Cast(root_2892) } else { ifn_2894 = nil }; var arg_2895 any = map__400000488__2; if linked_2893 == nil { tmp4 = ifn_2894.Invoke_O__O(arg_2895) } else { tmp4 = linked_2893.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2892, arg_2895) }; if jrt.J2g_Truth(tmp4) { var root_2896 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2896, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2898 lang.IFn; if linked_2897 == nil { ifn_2898 = lang.IFn_Cast(root_2896) } else { ifn_2898 = nil }; var arg_2899 any = map__400000488__2; if linked_2897 == nil { map__400000488__3 = ifn_2898.Invoke_O__O(arg_2899) } else { map__400000488__3 = linked_2897.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2896, arg_2899) } } else { map__400000488__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000488__3 = map__400000488__2 }; var v__4 any = lang.RT_Get_O_O__O_NoInit(map__400000488__3, A_arbace_c2j_node_A_const_56); var cf__5 any = lang.RT_Get_O_O__O_NoInit(map__400000488__3, A_arbace_c2j_node_A_const_453); var root_2900 any = A_arbace_c2j_node_A_const_383.GetRawRoot__O(); var linked_2901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2900, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2902 lang.IFn; if linked_2901 == nil { ifn_2902 = lang.IFn_Cast(root_2900) } else { ifn_2902 = nil }; var arg_2903 any = t.F_b__400000480; var arg_2904 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_34, nil, nil, nil, nil); var tmp6 any = A_arbace_c2j_node_A_const_328.Invoke_O__O(v__4); var tmp7 any = A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d); var tmp8 *jrt.String; var temp__1927000414__auto____12 any; var root_2905 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2905, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2907 lang.IFn

	if linked_2906 == nil { ifn_2907 = lang.IFn_Cast(root_2905) } else { ifn_2907 = nil }; var arg_2908 any; var root_2909 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_2910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2909, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2911 lang.IFn; if linked_2910 == nil { ifn_2911 = lang.IFn_Cast(root_2909) } else { ifn_2911 = nil }; var arg_2912 any; var fnbody__2919 any = A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_fn__400000491_A_New(); var tmp9 *jrt.Class; var fncls__2918 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_fn__400000491_A_fn_class; if fncls__2918 == nil { var fncls__2918d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_fn__400000491_A_fn_class = fncls__2918d; tmp9 = fncls__2918d } else { tmp9 = fncls__2918 }; arg_2912 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2919, tmp9, nil); var arg_2913 any = A_arbace_c2j_node_A_const_234.Invoke_O__O(v__4); if linked_2910 == nil { arg_2908 = ifn_2911.Invoke_O_O__O(arg_2912, arg_2913) } else { arg_2908 = linked_2910.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2909, arg_2912, arg_2913) }; if linked_2906 == nil { temp__1927000414__auto____12 = ifn_2907.Invoke_O__O(arg_2908) } else { temp__1927000414__auto____12 = linked_2906.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2905, arg_2908) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var s__13 any = temp__1927000414__auto____12; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp11 any; var root_2920 any = A_arbace_c2j_node_A_const_458.GetRawRoot__O(); var linked_2921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2920, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2922 lang.IFn; if linked_2921 == nil { ifn_2922 = lang.IFn_Cast(root_2920) } else { ifn_2922 = nil }; var arg_2923 any = Lit_36; var arg_2924 any = s__13; if linked_2921 == nil { tmp11 = ifn_2922.Invoke_O_O__O(arg_2923, arg_2924) } else { tmp11 = linked_2921.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2920, arg_2923, arg_2924) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11)) } else { tmp8 = nil }
//line :574:1
	var tmp12 any = tmp8.Ref(); var tmp13 *jrt.String; var tmp14 any; var root_2925 any = A_arbace_c2j_node_A_const_393.GetRawRoot__O(); var linked_2926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2925, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2927 lang.IFn


	if linked_2926 == nil { ifn_2927 = lang.IFn_Cast(root_2925) } else { ifn_2927 = nil }; var arg_2928 any = A_arbace_c2j_node_A_const_221.Invoke_O__O(v__4); if linked_2926 == nil { tmp14 = ifn_2927.Invoke_O__O(arg_2928) } else { tmp14 = linked_2926.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2925, arg_2928) }; if jrt.J2g_Truth(tmp14) { var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp16 *jrt.String; var tmp17 any = A_arbace_c2j_node_A_const_220; if lang.Util_Equiv_O_O__Z_NoInit(tmp17, A_arbace_c2j_node_A_const_221.Invoke_O__O(v__4)) { tmp16 = Lit_37 } else { tmp16 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_221.Invoke_O__O(v__4), nil)) }; tmp13 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16.Ref())) } else { tmp13 = nil }
//line :574:1
	var tmp18 any = tmp13.Ref(); var tmp19 *jrt.String



	if jrt.J2g_Truth(A_arbace_c2j_node_A_const_177.Invoke_O__O(v__4)) { var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil, nil); var tmp21 any; var root_2929 any = A_arbace_c2j_node_A_const_457.GetRawRoot__O(); var linked_2930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2929, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2931 lang.IFn; if linked_2930 == nil { ifn_2931 = lang.IFn_Cast(root_2929) } else { ifn_2931 = nil }; var arg_2932 any = A_arbace_c2j_node_A_const_390.Invoke_O__O(v__4); if linked_2930 == nil { tmp21 = ifn_2931.Invoke_O__O(arg_2932) } else { tmp21 = linked_2930.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2929, arg_2932) }; var tmp22 any = tmp21; var tmp23 *jrt.String; if jrt.J2g_Truth(A_arbace_c2j_node_A_const_73.Invoke_O__O(v__4)) { tmp23 = Lit_39 } else { tmp23 = nil }; tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp22, tmp23.Ref())) } else { tmp19 = nil }
//line :574:1
	arg_2904 = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil, tmp7, tmp12, tmp18, tmp19.Ref())).Ref(), cf__5); if linked_2901 == nil { ifn_2902.Invoke_O_O__O(arg_2903, arg_2904) } else { linked_2901.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2900, arg_2903, arg_2904) }; i__400000479__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000479__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_fn__400000491_A_New() *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_fn__400000491_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_fn__400000491_A{}; t.Ctor(); return t }
//line :576:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_fn__400000491_A) Ctor() {}
//line :576:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_fn__400000491_A) Invoke_O_O__O(self, p__400000490__1 any) any { var vec__400000492__2 any = p__400000490__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000492__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000492__2, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(x__4) { var root_2914 any = A_arbace_c2j_node_A_const_457.GetRawRoot__O(); var linked_2915 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2914, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2916 lang.IFn; if linked_2915 == nil { ifn_2916 = lang.IFn_Cast(root_2914) } else { ifn_2916 = nil }; var arg_2917 any = k__3; if linked_2915 == nil { return ifn_2916.Invoke_O__O(arg_2917) } else { return linked_2915.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2914, arg_2917) } } else { return nil } }
//line :576:1
func A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000500_A_New() *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000500_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000500_A{}; t.Ctor(); return t }
//line :576:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000500_A) Ctor() {}
//line :576:1
func (t *A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000500_A) Invoke_O_O__O(self, p__400000499__1 any) any { var vec__400000501__2 any = p__400000499__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000501__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000501__2, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(x__4) { var root_2991 any = A_arbace_c2j_node_A_const_457.GetRawRoot__O(); var linked_2992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2991, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2993 lang.IFn; if linked_2992 == nil { ifn_2993 = lang.IFn_Cast(root_2991) } else { ifn_2993 = nil }; var arg_2994 any = k__3; if linked_2992 == nil { return ifn_2993.Invoke_O__O(arg_2994) } else { return linked_2992.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2991, arg_2994) } } else { return nil } }











func A_arbace_c2j_node_code_forms_fn__400000510_A_New() *A_arbace_c2j_node_code_forms_fn__400000510_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_fn__400000510_A{}; t.Ctor(); return t }
//line :588:1
func (t *A_arbace_c2j_node_code_forms_fn__400000510_A) Ctor() {}
//line :588:1
func (t *A_arbace_c2j_node_code_forms_fn__400000510_A) Invoke_O_O__O(self, p__400000509__1 any) any { var vec__400000511__2 any = p__400000509__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000511__2, lang.RT_IntCast_J__I_NoInit(0), nil); var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000511__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_478; var tmp3 any = A_arbace_c2j_node_A_const_479; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, k__3, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_480, i__4)) }























































































































































































































































type A_arbace_c2j_node_A struct{ jrt.Object }

var A_arbace_c2j_node_A_const_pool *jrt.RefArray

var A_arbace_c2j_node_A_const_0 *lang.Var

var A_arbace_c2j_node_A_const_1 any

var A_arbace_c2j_node_A_const_2 *lang.Var

var A_arbace_c2j_node_A_const_3 any

var A_arbace_c2j_node_A_const_4 *lang.Var

var A_arbace_c2j_node_A_const_5 *lang.Var

var A_arbace_c2j_node_A_const_6 *lang.Var

var A_arbace_c2j_node_A_const_7 *lang.Var

var A_arbace_c2j_node_A_const_8 any

var A_arbace_c2j_node_A_const_9 *lang.Var

var A_arbace_c2j_node_A_const_10 *lang.Var

var A_arbace_c2j_node_A_const_11 *lang.Var

var A_arbace_c2j_node_A_const_12 *lang.Var

var A_arbace_c2j_node_A_const_13 *lang.Keyword

var A_arbace_c2j_node_A_const_14 *lang.Var

var A_arbace_c2j_node_A_const_15 *lang.Keyword

var A_arbace_c2j_node_A_const_16 *lang.Keyword

var A_arbace_c2j_node_A_const_17 *lang.Keyword

var A_arbace_c2j_node_A_const_18 *lang.Var

var A_arbace_c2j_node_A_const_19 *lang.Keyword

var A_arbace_c2j_node_A_const_20 *lang.Keyword

var A_arbace_c2j_node_A_const_21 *lang.Keyword

var A_arbace_c2j_node_A_const_22 *lang.Var

var A_arbace_c2j_node_A_const_23 *lang.Var

var A_arbace_c2j_node_A_const_24 *lang.Var

var A_arbace_c2j_node_A_const_25 any

var A_arbace_c2j_node_A_const_26 *lang.Keyword

var A_arbace_c2j_node_A_const_27 *lang.Var

var A_arbace_c2j_node_A_const_28 *lang.Var

var A_arbace_c2j_node_A_const_29 *lang.Var

var A_arbace_c2j_node_A_const_30 any

var A_arbace_c2j_node_A_const_31 *lang.Keyword

var A_arbace_c2j_node_A_const_32 *lang.Var

var A_arbace_c2j_node_A_const_33 any

var A_arbace_c2j_node_A_const_34 *lang.Var

var A_arbace_c2j_node_A_const_35 *lang.Var

var A_arbace_c2j_node_A_const_36 *lang.Var

var A_arbace_c2j_node_A_const_37 *lang.Var

var A_arbace_c2j_node_A_const_38 *lang.Var

var A_arbace_c2j_node_A_const_39 *lang.Var

var A_arbace_c2j_node_A_const_40 *lang.Var

var A_arbace_c2j_node_A_const_41 *lang.Var

var A_arbace_c2j_node_A_const_42 *lang.Var

var A_arbace_c2j_node_A_const_43 *lang.Var

var A_arbace_c2j_node_A_const_44 *lang.Var

var A_arbace_c2j_node_A_const_45 *lang.Keyword

var A_arbace_c2j_node_A_const_46 any

var A_arbace_c2j_node_A_const_47 *lang.Var

var A_arbace_c2j_node_A_const_48 *lang.Var

var A_arbace_c2j_node_A_const_49 *lang.Var

var A_arbace_c2j_node_A_const_50 *lang.Var

var A_arbace_c2j_node_A_const_51 any

var A_arbace_c2j_node_A_const_52 *lang.Var

var A_arbace_c2j_node_A_const_53 *lang.Var

var A_arbace_c2j_node_A_const_54 *lang.Var

var A_arbace_c2j_node_A_const_55 *lang.Keyword

var A_arbace_c2j_node_A_const_56 *lang.Keyword

var A_arbace_c2j_node_A_const_57 any

var A_arbace_c2j_node_A_const_58 *lang.Keyword

var A_arbace_c2j_node_A_const_59 *lang.Var

var A_arbace_c2j_node_A_const_60 *lang.Var

var A_arbace_c2j_node_A_const_61 *lang.Var

var A_arbace_c2j_node_A_const_62 *lang.Var

var A_arbace_c2j_node_A_const_63 any

var A_arbace_c2j_node_A_const_64 any

var A_arbace_c2j_node_A_const_65 any

var A_arbace_c2j_node_A_const_66 any

var A_arbace_c2j_node_A_const_67 any

var A_arbace_c2j_node_A_const_68 any

var A_arbace_c2j_node_A_const_69 any

var A_arbace_c2j_node_A_const_70 any

var A_arbace_c2j_node_A_const_71 *lang.Keyword

var A_arbace_c2j_node_A_const_72 any

var A_arbace_c2j_node_A_const_73 *lang.Keyword

var A_arbace_c2j_node_A_const_74 *lang.Var

var A_arbace_c2j_node_A_const_75 *lang.Var

var A_arbace_c2j_node_A_const_76 any

var A_arbace_c2j_node_A_const_77 any

var A_arbace_c2j_node_A_const_78 *lang.Var

var A_arbace_c2j_node_A_const_79 any

var A_arbace_c2j_node_A_const_80 any

var A_arbace_c2j_node_A_const_81 *lang.Var

var A_arbace_c2j_node_A_const_82 any

var A_arbace_c2j_node_A_const_83 *lang.Var

var A_arbace_c2j_node_A_const_84 any

var A_arbace_c2j_node_A_const_85 any

var A_arbace_c2j_node_A_const_86 any

var A_arbace_c2j_node_A_const_87 any

var A_arbace_c2j_node_A_const_88 any

var A_arbace_c2j_node_A_const_89 any

var A_arbace_c2j_node_A_const_90 any

var A_arbace_c2j_node_A_const_91 any

var A_arbace_c2j_node_A_const_92 any

var A_arbace_c2j_node_A_const_93 any

var A_arbace_c2j_node_A_const_94 any

var A_arbace_c2j_node_A_const_95 any

var A_arbace_c2j_node_A_const_96 any

var A_arbace_c2j_node_A_const_97 any

var A_arbace_c2j_node_A_const_98 *lang.Var

var A_arbace_c2j_node_A_const_99 *lang.Var

var A_arbace_c2j_node_A_const_100 any

var A_arbace_c2j_node_A_const_101 any

var A_arbace_c2j_node_A_const_102 any

var A_arbace_c2j_node_A_const_103 any

var A_arbace_c2j_node_A_const_104 any

var A_arbace_c2j_node_A_const_105 *lang.Keyword

var A_arbace_c2j_node_A_const_106 any

var A_arbace_c2j_node_A_const_107 *lang.Keyword

var A_arbace_c2j_node_A_const_108 any

var A_arbace_c2j_node_A_const_109 *lang.Keyword

var A_arbace_c2j_node_A_const_110 *lang.Keyword

var A_arbace_c2j_node_A_const_111 any

var A_arbace_c2j_node_A_const_112 any

var A_arbace_c2j_node_A_const_113 any

var A_arbace_c2j_node_A_const_114 any

var A_arbace_c2j_node_A_const_115 any

var A_arbace_c2j_node_A_const_116 any

var A_arbace_c2j_node_A_const_117 any

var A_arbace_c2j_node_A_const_118 any

var A_arbace_c2j_node_A_const_119 any

var A_arbace_c2j_node_A_const_120 *lang.Keyword

var A_arbace_c2j_node_A_const_121 any

var A_arbace_c2j_node_A_const_122 any

var A_arbace_c2j_node_A_const_123 any

var A_arbace_c2j_node_A_const_124 any

var A_arbace_c2j_node_A_const_125 any

var A_arbace_c2j_node_A_const_126 *lang.Keyword

var A_arbace_c2j_node_A_const_127 any

var A_arbace_c2j_node_A_const_128 any

var A_arbace_c2j_node_A_const_129 *lang.Var

var A_arbace_c2j_node_A_const_130 *lang.Var

var A_arbace_c2j_node_A_const_131 any

var A_arbace_c2j_node_A_const_132 *lang.Keyword

var A_arbace_c2j_node_A_const_133 any

var A_arbace_c2j_node_A_const_134 any

var A_arbace_c2j_node_A_const_135 any

var A_arbace_c2j_node_A_const_136 any

var A_arbace_c2j_node_A_const_137 *lang.Keyword

var A_arbace_c2j_node_A_const_138 any

var A_arbace_c2j_node_A_const_139 any

var A_arbace_c2j_node_A_const_140 any

var A_arbace_c2j_node_A_const_141 *lang.Var

var A_arbace_c2j_node_A_const_142 any

var A_arbace_c2j_node_A_const_143 any

var A_arbace_c2j_node_A_const_144 any

var A_arbace_c2j_node_A_const_145 any

var A_arbace_c2j_node_A_const_146 any

var A_arbace_c2j_node_A_const_147 any

var A_arbace_c2j_node_A_const_148 any

var A_arbace_c2j_node_A_const_149 any

var A_arbace_c2j_node_A_const_150 any

var A_arbace_c2j_node_A_const_151 any

var A_arbace_c2j_node_A_const_152 any

var A_arbace_c2j_node_A_const_153 any

var A_arbace_c2j_node_A_const_154 any

var A_arbace_c2j_node_A_const_155 any

var A_arbace_c2j_node_A_const_156 *lang.Keyword

var A_arbace_c2j_node_A_const_157 *lang.Var

var A_arbace_c2j_node_A_const_158 *lang.Var

var A_arbace_c2j_node_A_const_159 any

var A_arbace_c2j_node_A_const_160 any

var A_arbace_c2j_node_A_const_161 any

var A_arbace_c2j_node_A_const_162 *lang.Keyword

var A_arbace_c2j_node_A_const_163 any

var A_arbace_c2j_node_A_const_164 any

var A_arbace_c2j_node_A_const_165 any

var A_arbace_c2j_node_A_const_166 *lang.Var

var A_arbace_c2j_node_A_const_167 any

var A_arbace_c2j_node_A_const_168 *lang.Keyword

var A_arbace_c2j_node_A_const_169 any

var A_arbace_c2j_node_A_const_170 *lang.Keyword

var A_arbace_c2j_node_A_const_171 *lang.Keyword

var A_arbace_c2j_node_A_const_172 *lang.Var

var A_arbace_c2j_node_A_const_173 any

var A_arbace_c2j_node_A_const_174 any

var A_arbace_c2j_node_A_const_175 any

var A_arbace_c2j_node_A_const_176 any

var A_arbace_c2j_node_A_const_177 *lang.Keyword

var A_arbace_c2j_node_A_const_178 any

var A_arbace_c2j_node_A_const_179 any

var A_arbace_c2j_node_A_const_180 any

var A_arbace_c2j_node_A_const_181 *lang.Keyword

var A_arbace_c2j_node_A_const_182 any

var A_arbace_c2j_node_A_const_183 any

var A_arbace_c2j_node_A_const_184 any

var A_arbace_c2j_node_A_const_185 *lang.Keyword

var A_arbace_c2j_node_A_const_186 any

var A_arbace_c2j_node_A_const_187 *lang.Var

var A_arbace_c2j_node_A_const_188 *lang.Var

var A_arbace_c2j_node_A_const_189 any

var A_arbace_c2j_node_A_const_190 any

var A_arbace_c2j_node_A_const_191 any

var A_arbace_c2j_node_A_const_192 any

var A_arbace_c2j_node_A_const_193 any

var A_arbace_c2j_node_A_const_194 any

var A_arbace_c2j_node_A_const_195 any

var A_arbace_c2j_node_A_const_196 *lang.Keyword

var A_arbace_c2j_node_A_const_197 any

var A_arbace_c2j_node_A_const_198 any

var A_arbace_c2j_node_A_const_199 any

var A_arbace_c2j_node_A_const_200 any

var A_arbace_c2j_node_A_const_201 *lang.Var

var A_arbace_c2j_node_A_const_202 any

var A_arbace_c2j_node_A_const_203 *lang.Var

var A_arbace_c2j_node_A_const_204 any

var A_arbace_c2j_node_A_const_205 any

var A_arbace_c2j_node_A_const_206 any

var A_arbace_c2j_node_A_const_207 *lang.Var

var A_arbace_c2j_node_A_const_208 *lang.Keyword

var A_arbace_c2j_node_A_const_209 any

var A_arbace_c2j_node_A_const_210 any

var A_arbace_c2j_node_A_const_211 any

var A_arbace_c2j_node_A_const_212 any

var A_arbace_c2j_node_A_const_213 any

var A_arbace_c2j_node_A_const_214 *lang.Keyword

var A_arbace_c2j_node_A_const_215 *lang.Var

var A_arbace_c2j_node_A_const_216 *lang.Keyword

var A_arbace_c2j_node_A_const_217 *lang.Var

var A_arbace_c2j_node_A_const_218 *lang.Var

var A_arbace_c2j_node_A_const_219 any

var A_arbace_c2j_node_A_const_220 *lang.Keyword

var A_arbace_c2j_node_A_const_221 *lang.Keyword

var A_arbace_c2j_node_A_const_222 *lang.Keyword

var A_arbace_c2j_node_A_const_223 *lang.Keyword

var A_arbace_c2j_node_A_const_224 any

var A_arbace_c2j_node_A_const_225 any

var A_arbace_c2j_node_A_const_226 *lang.Var

var A_arbace_c2j_node_A_const_227 any

var A_arbace_c2j_node_A_const_228 any

var A_arbace_c2j_node_A_const_229 *lang.Var

var A_arbace_c2j_node_A_const_230 any

var A_arbace_c2j_node_A_const_231 *lang.Keyword

var A_arbace_c2j_node_A_const_232 *lang.Keyword

var A_arbace_c2j_node_A_const_233 any

var A_arbace_c2j_node_A_const_234 *lang.Keyword

var A_arbace_c2j_node_A_const_235 any

var A_arbace_c2j_node_A_const_236 any

var A_arbace_c2j_node_A_const_237 any

var A_arbace_c2j_node_A_const_238 any

var A_arbace_c2j_node_A_const_239 any

var A_arbace_c2j_node_A_const_240 any

var A_arbace_c2j_node_A_const_241 any

var A_arbace_c2j_node_A_const_242 *lang.Var

var A_arbace_c2j_node_A_const_243 any

var A_arbace_c2j_node_A_const_244 any

var A_arbace_c2j_node_A_const_245 *lang.Keyword

var A_arbace_c2j_node_A_const_246 any

var A_arbace_c2j_node_A_const_247 any

var A_arbace_c2j_node_A_const_248 *lang.Keyword

var A_arbace_c2j_node_A_const_249 any

var A_arbace_c2j_node_A_const_250 any

var A_arbace_c2j_node_A_const_251 any

var A_arbace_c2j_node_A_const_252 *lang.Var

var A_arbace_c2j_node_A_const_253 any

var A_arbace_c2j_node_A_const_254 *lang.Keyword

var A_arbace_c2j_node_A_const_255 *lang.Keyword

var A_arbace_c2j_node_A_const_256 *lang.Var

var A_arbace_c2j_node_A_const_257 any

var A_arbace_c2j_node_A_const_258 any

var A_arbace_c2j_node_A_const_259 *lang.Keyword

var A_arbace_c2j_node_A_const_260 *lang.Var

var A_arbace_c2j_node_A_const_261 any

var A_arbace_c2j_node_A_const_262 any

var A_arbace_c2j_node_A_const_263 any

var A_arbace_c2j_node_A_const_264 *lang.Var

var A_arbace_c2j_node_A_const_265 any

var A_arbace_c2j_node_A_const_266 any

var A_arbace_c2j_node_A_const_267 any

var A_arbace_c2j_node_A_const_268 any

var A_arbace_c2j_node_A_const_269 any

var A_arbace_c2j_node_A_const_270 any

var A_arbace_c2j_node_A_const_271 any

var A_arbace_c2j_node_A_const_272 any

var A_arbace_c2j_node_A_const_273 any

var A_arbace_c2j_node_A_const_274 *lang.Var

var A_arbace_c2j_node_A_const_275 *lang.Var

var A_arbace_c2j_node_A_const_276 *lang.Keyword

var A_arbace_c2j_node_A_const_277 any

var A_arbace_c2j_node_A_const_278 any

var A_arbace_c2j_node_A_const_279 any

var A_arbace_c2j_node_A_const_280 *lang.Keyword

var A_arbace_c2j_node_A_const_281 *lang.Var

var A_arbace_c2j_node_A_const_282 *lang.Var

var A_arbace_c2j_node_A_const_283 *jrt.Class

var A_arbace_c2j_node_A_const_284 any

var A_arbace_c2j_node_A_const_285 any

var A_arbace_c2j_node_A_const_286 any

var A_arbace_c2j_node_A_const_287 any

var A_arbace_c2j_node_A_const_288 any

var A_arbace_c2j_node_A_const_289 any

var A_arbace_c2j_node_A_const_290 any

var A_arbace_c2j_node_A_const_291 any

var A_arbace_c2j_node_A_const_292 any

var A_arbace_c2j_node_A_const_293 any

var A_arbace_c2j_node_A_const_294 any

var A_arbace_c2j_node_A_const_295 any

var A_arbace_c2j_node_A_const_296 any

var A_arbace_c2j_node_A_const_297 any

var A_arbace_c2j_node_A_const_298 *lang.Var

var A_arbace_c2j_node_A_const_299 *lang.Var

var A_arbace_c2j_node_A_const_300 any

var A_arbace_c2j_node_A_const_301 any

var A_arbace_c2j_node_A_const_302 *lang.Var

var A_arbace_c2j_node_A_const_303 *lang.Var

var A_arbace_c2j_node_A_const_304 *lang.Var

var A_arbace_c2j_node_A_const_305 any

var A_arbace_c2j_node_A_const_306 *lang.Var

var A_arbace_c2j_node_A_const_307 any

var A_arbace_c2j_node_A_const_308 *lang.Var

var A_arbace_c2j_node_A_const_309 *lang.Keyword

var A_arbace_c2j_node_A_const_310 any

var A_arbace_c2j_node_A_const_311 any

var A_arbace_c2j_node_A_const_312 any

var A_arbace_c2j_node_A_const_313 any

var A_arbace_c2j_node_A_const_314 any

var A_arbace_c2j_node_A_const_315 any

var A_arbace_c2j_node_A_const_316 any

var A_arbace_c2j_node_A_const_317 *lang.Var

var A_arbace_c2j_node_A_const_318 *lang.Keyword

var A_arbace_c2j_node_A_const_319 any

var A_arbace_c2j_node_A_const_320 *lang.Keyword

var A_arbace_c2j_node_A_const_321 *lang.Keyword

var A_arbace_c2j_node_A_const_322 *lang.Var

var A_arbace_c2j_node_A_const_323 any

var A_arbace_c2j_node_A_const_324 any

var A_arbace_c2j_node_A_const_325 *lang.Var

var A_arbace_c2j_node_A_const_326 any

var A_arbace_c2j_node_A_const_327 any

var A_arbace_c2j_node_A_const_328 *lang.Keyword

var A_arbace_c2j_node_A_const_329 any

var A_arbace_c2j_node_A_const_330 any

var A_arbace_c2j_node_A_const_331 any

var A_arbace_c2j_node_A_const_332 any

var A_arbace_c2j_node_A_const_333 any

var A_arbace_c2j_node_A_const_334 *lang.Var

var A_arbace_c2j_node_A_const_335 *lang.Keyword

var A_arbace_c2j_node_A_const_336 *lang.Var

var A_arbace_c2j_node_A_const_337 *lang.Keyword

var A_arbace_c2j_node_A_const_338 any

var A_arbace_c2j_node_A_const_339 any

var A_arbace_c2j_node_A_const_340 *lang.Keyword

var A_arbace_c2j_node_A_const_341 any

var A_arbace_c2j_node_A_const_342 any

var A_arbace_c2j_node_A_const_343 any

var A_arbace_c2j_node_A_const_344 any

var A_arbace_c2j_node_A_const_345 any

var A_arbace_c2j_node_A_const_346 *lang.Var

var A_arbace_c2j_node_A_const_347 any

var A_arbace_c2j_node_A_const_348 any

var A_arbace_c2j_node_A_const_349 any

var A_arbace_c2j_node_A_const_350 any

var A_arbace_c2j_node_A_const_351 any

var A_arbace_c2j_node_A_const_352 any

var A_arbace_c2j_node_A_const_353 any

var A_arbace_c2j_node_A_const_354 any

var A_arbace_c2j_node_A_const_355 any

var A_arbace_c2j_node_A_const_356 any

var A_arbace_c2j_node_A_const_357 any

var A_arbace_c2j_node_A_const_358 any

var A_arbace_c2j_node_A_const_359 any

var A_arbace_c2j_node_A_const_360 any

var A_arbace_c2j_node_A_const_361 any

var A_arbace_c2j_node_A_const_362 any

var A_arbace_c2j_node_A_const_363 any

var A_arbace_c2j_node_A_const_364 *lang.Keyword

var A_arbace_c2j_node_A_const_365 any

var A_arbace_c2j_node_A_const_366 any

var A_arbace_c2j_node_A_const_367 *lang.Keyword

var A_arbace_c2j_node_A_const_368 *lang.Keyword

var A_arbace_c2j_node_A_const_369 any

var A_arbace_c2j_node_A_const_370 any

var A_arbace_c2j_node_A_const_371 any

var A_arbace_c2j_node_A_const_372 any

var A_arbace_c2j_node_A_const_373 any

var A_arbace_c2j_node_A_const_374 *lang.Keyword

var A_arbace_c2j_node_A_const_375 *lang.Var

var A_arbace_c2j_node_A_const_376 *lang.Var

var A_arbace_c2j_node_A_const_377 *lang.Var

var A_arbace_c2j_node_A_const_378 any

var A_arbace_c2j_node_A_const_379 any

var A_arbace_c2j_node_A_const_380 *lang.Var

var A_arbace_c2j_node_A_const_381 *lang.Var

var A_arbace_c2j_node_A_const_382 *lang.Var

var A_arbace_c2j_node_A_const_383 *lang.Var

var A_arbace_c2j_node_A_const_384 *lang.Var

var A_arbace_c2j_node_A_const_385 *lang.Var

var A_arbace_c2j_node_A_const_386 *lang.Var

var A_arbace_c2j_node_A_const_387 any

var A_arbace_c2j_node_A_const_388 *lang.Keyword

var A_arbace_c2j_node_A_const_389 any

var A_arbace_c2j_node_A_const_390 *lang.Keyword

var A_arbace_c2j_node_A_const_391 any

var A_arbace_c2j_node_A_const_392 any

var A_arbace_c2j_node_A_const_393 *lang.Var

var A_arbace_c2j_node_A_const_394 *lang.Var

var A_arbace_c2j_node_A_const_395 *lang.Var

var A_arbace_c2j_node_A_const_396 *lang.Keyword

var A_arbace_c2j_node_A_const_397 any

var A_arbace_c2j_node_A_const_398 any

var A_arbace_c2j_node_A_const_399 any

var A_arbace_c2j_node_A_const_400 any

var A_arbace_c2j_node_A_const_401 any

var A_arbace_c2j_node_A_const_402 any

var A_arbace_c2j_node_A_const_403 any

var A_arbace_c2j_node_A_const_404 any

var A_arbace_c2j_node_A_const_405 any

var A_arbace_c2j_node_A_const_406 any

var A_arbace_c2j_node_A_const_407 any

var A_arbace_c2j_node_A_const_408 any

var A_arbace_c2j_node_A_const_409 any

var A_arbace_c2j_node_A_const_410 any

var A_arbace_c2j_node_A_const_411 any

var A_arbace_c2j_node_A_const_412 *lang.Var

var A_arbace_c2j_node_A_const_413 *lang.Var

var A_arbace_c2j_node_A_const_414 *lang.Var

var A_arbace_c2j_node_A_const_415 *lang.Var

var A_arbace_c2j_node_A_const_416 *lang.Var

var A_arbace_c2j_node_A_const_417 any

var A_arbace_c2j_node_A_const_418 any

var A_arbace_c2j_node_A_const_419 any

var A_arbace_c2j_node_A_const_420 any

var A_arbace_c2j_node_A_const_421 any

var A_arbace_c2j_node_A_const_422 any

var A_arbace_c2j_node_A_const_423 any

var A_arbace_c2j_node_A_const_424 any

var A_arbace_c2j_node_A_const_425 any

var A_arbace_c2j_node_A_const_426 any

var A_arbace_c2j_node_A_const_427 any

var A_arbace_c2j_node_A_const_428 any

var A_arbace_c2j_node_A_const_429 any

var A_arbace_c2j_node_A_const_430 any

var A_arbace_c2j_node_A_const_431 any

var A_arbace_c2j_node_A_const_432 any

var A_arbace_c2j_node_A_const_433 any

var A_arbace_c2j_node_A_const_434 any

var A_arbace_c2j_node_A_const_435 any

var A_arbace_c2j_node_A_const_436 any

var A_arbace_c2j_node_A_const_437 any

var A_arbace_c2j_node_A_const_438 any

var A_arbace_c2j_node_A_const_439 any

var A_arbace_c2j_node_A_const_440 *lang.Keyword

var A_arbace_c2j_node_A_const_441 any

var A_arbace_c2j_node_A_const_442 any

var A_arbace_c2j_node_A_const_443 any

var A_arbace_c2j_node_A_const_444 any

var A_arbace_c2j_node_A_const_445 any

var A_arbace_c2j_node_A_const_446 any

var A_arbace_c2j_node_A_const_447 any

var A_arbace_c2j_node_A_const_448 any

var A_arbace_c2j_node_A_const_449 any

var A_arbace_c2j_node_A_const_450 any

var A_arbace_c2j_node_A_const_451 *lang.Keyword

var A_arbace_c2j_node_A_const_452 *lang.Var

var A_arbace_c2j_node_A_const_453 *lang.Keyword

var A_arbace_c2j_node_A_const_454 *lang.Var

var A_arbace_c2j_node_A_const_455 *lang.Var

var A_arbace_c2j_node_A_const_456 *lang.Var

var A_arbace_c2j_node_A_const_457 *lang.Var

var A_arbace_c2j_node_A_const_458 *lang.Var

var A_arbace_c2j_node_A_const_459 any

var A_arbace_c2j_node_A_const_460 any

var A_arbace_c2j_node_A_const_461 any

var A_arbace_c2j_node_A_const_462 any

var A_arbace_c2j_node_A_const_463 any

var A_arbace_c2j_node_A_const_464 any

var A_arbace_c2j_node_A_const_465 any

var A_arbace_c2j_node_A_const_466 any

var A_arbace_c2j_node_A_const_467 any

var A_arbace_c2j_node_A_const_468 any

var A_arbace_c2j_node_A_const_469 any

var A_arbace_c2j_node_A_const_470 any

var A_arbace_c2j_node_A_const_471 any

var A_arbace_c2j_node_A_const_472 any

var A_arbace_c2j_node_A_const_473 any

var A_arbace_c2j_node_A_const_474 any

var A_arbace_c2j_node_A_const_475 any

var A_arbace_c2j_node_A_const_476 any

var A_arbace_c2j_node_A_const_477 any

var A_arbace_c2j_node_A_const_478 any

var A_arbace_c2j_node_A_const_479 any

var A_arbace_c2j_node_A_const_480 any

var A_arbace_c2j_node_A_const_481 any

var A_arbace_c2j_node_A_init jrt.ClassInit

func A_arbace_c2j_node_A_Init() { if !A_arbace_c2j_node_A_init.Done() { A_arbace_c2j_node_A_init.Run(A_arbace_c2j_node_A_clinit) } }

func A_arbace_c2j_node_A_clinit() { A_arbace_c2j_node_A_clinit_p0(); A_arbace_c2j_node_A_clinit_p1(); A_arbace_c2j_node_A_clinit_p2(); A_arbace_c2j_node_A_clinit_p3(); A_arbace_c2j_node_A_clinit_p4(); A_arbace_c2j_node_A_clinit_p5(); A_arbace_c2j_node_A_clinit_p6(); A_arbace_c2j_node_A_clinit_p7(); A_arbace_c2j_node_A_clinit_p8(); A_arbace_c2j_node_A_clinit_p9(); A_arbace_c2j_node_A_clinit_p10(); A_arbace_c2j_node_A_clinit_p11(); A_arbace_c2j_node_A_clinit_p12(); A_arbace_c2j_node_A_clinit_p13(); A_arbace_c2j_node_A_clinit_p14(); A_arbace_c2j_node_A_clinit_p15(); A_arbace_c2j_node_A_clinit_p16(); A_arbace_c2j_node_A_clinit_p17(); A_arbace_c2j_node_A_clinit_p18(); A_arbace_c2j_node_A_clinit_p19(); A_arbace_c2j_node_A_clinit_p20(); A_arbace_c2j_node_A_clinit_p21(); A_arbace_c2j_node_A_clinit_p22(); A_arbace_c2j_node_A_clinit_p23(); A_arbace_c2j_node_A_clinit_p24(); A_arbace_c2j_node_A_clinit_p25(); A_arbace_c2j_node_A_clinit_p26(); A_arbace_c2j_node_A_clinit_p27(); A_arbace_c2j_node_A_clinit_p28(); A_arbace_c2j_node_A_clinit_p29(); A_arbace_c2j_node_A_clinit_p30(); A_arbace_c2j_node_A_clinit_p31(); A_arbace_c2j_node_A_clinit_p32(); A_arbace_c2j_node_A_clinit_p33(); A_arbace_c2j_node_A_clinit_p34() }

func A_arbace_c2j_node_A_clinit_p0() { jrt.StartCheck(); A_arbace_c2j_node_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 670); A_arbace_c2j_node_A_const_0 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[188]); A_arbace_c2j_node_A_const_1 = A_arbace_c2j_node_A_const_pool.A[189]; A_arbace_c2j_node_A_const_2 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[190]); A_arbace_c2j_node_A_const_3 = A_arbace_c2j_node_A_const_pool.A[191]; A_arbace_c2j_node_A_const_4 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[192]); A_arbace_c2j_node_A_const_5 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[193]); A_arbace_c2j_node_A_const_6 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[194]); A_arbace_c2j_node_A_const_7 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[195]); A_arbace_c2j_node_A_const_8 = A_arbace_c2j_node_A_const_pool.A[196]; A_arbace_c2j_node_A_const_9 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[197]); A_arbace_c2j_node_A_const_10 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[198]); A_arbace_c2j_node_A_const_11 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[199]) }

func A_arbace_c2j_node_A_clinit_p1() { A_arbace_c2j_node_A_const_12 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[200]); A_arbace_c2j_node_A_const_13 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[201]); A_arbace_c2j_node_A_const_14 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[202]); A_arbace_c2j_node_A_const_15 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[203]); A_arbace_c2j_node_A_const_16 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[204]); A_arbace_c2j_node_A_const_17 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[205]); A_arbace_c2j_node_A_const_18 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[206]); A_arbace_c2j_node_A_const_19 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[207]); A_arbace_c2j_node_A_const_20 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[208]); A_arbace_c2j_node_A_const_21 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[209]); A_arbace_c2j_node_A_const_22 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[210]); A_arbace_c2j_node_A_const_23 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[211]) }

func A_arbace_c2j_node_A_clinit_p2() { A_arbace_c2j_node_A_const_24 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[212]); A_arbace_c2j_node_A_const_25 = A_arbace_c2j_node_A_const_pool.A[213]; A_arbace_c2j_node_A_const_26 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[214]); A_arbace_c2j_node_A_const_27 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[215]); A_arbace_c2j_node_A_const_28 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[216]); A_arbace_c2j_node_A_const_29 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[217]); A_arbace_c2j_node_A_const_30 = A_arbace_c2j_node_A_const_pool.A[218]; A_arbace_c2j_node_A_const_31 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[219]); A_arbace_c2j_node_A_const_32 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[220]); A_arbace_c2j_node_A_const_33 = A_arbace_c2j_node_A_const_pool.A[221]; A_arbace_c2j_node_A_const_34 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[222]); A_arbace_c2j_node_A_const_35 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[223]) }

func A_arbace_c2j_node_A_clinit_p3() { A_arbace_c2j_node_A_const_36 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[224]); A_arbace_c2j_node_A_const_37 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[225]); A_arbace_c2j_node_A_const_38 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[226]); A_arbace_c2j_node_A_const_39 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[227]); A_arbace_c2j_node_A_const_40 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[228]); A_arbace_c2j_node_A_const_41 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[229]); A_arbace_c2j_node_A_const_42 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[230]); A_arbace_c2j_node_A_const_43 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[231]); A_arbace_c2j_node_A_const_44 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[232]); A_arbace_c2j_node_A_const_45 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[233]); A_arbace_c2j_node_A_const_46 = A_arbace_c2j_node_A_const_pool.A[234]; A_arbace_c2j_node_A_const_47 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[235]) }

func A_arbace_c2j_node_A_clinit_p4() { A_arbace_c2j_node_A_const_48 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[236]); A_arbace_c2j_node_A_const_49 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[237]); A_arbace_c2j_node_A_const_50 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[238]); A_arbace_c2j_node_A_const_51 = A_arbace_c2j_node_A_const_pool.A[239]; A_arbace_c2j_node_A_const_52 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[240]); A_arbace_c2j_node_A_const_53 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[241]); A_arbace_c2j_node_A_const_54 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[242]); A_arbace_c2j_node_A_const_55 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[243]); A_arbace_c2j_node_A_const_56 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[244]); A_arbace_c2j_node_A_const_57 = A_arbace_c2j_node_A_const_pool.A[245]; A_arbace_c2j_node_A_const_58 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[246]); A_arbace_c2j_node_A_const_59 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[247]) }

func A_arbace_c2j_node_A_clinit_p5() { A_arbace_c2j_node_A_const_60 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[248]); A_arbace_c2j_node_A_const_61 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[249]); A_arbace_c2j_node_A_const_62 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[250]); A_arbace_c2j_node_A_const_63 = A_arbace_c2j_node_A_const_pool.A[251]; A_arbace_c2j_node_A_const_64 = A_arbace_c2j_node_A_const_pool.A[252]; A_arbace_c2j_node_A_const_65 = A_arbace_c2j_node_A_const_pool.A[253]; A_arbace_c2j_node_A_const_66 = A_arbace_c2j_node_A_const_pool.A[254]; A_arbace_c2j_node_A_const_67 = A_arbace_c2j_node_A_const_pool.A[255]; A_arbace_c2j_node_A_const_68 = A_arbace_c2j_node_A_const_pool.A[256]; A_arbace_c2j_node_A_const_69 = A_arbace_c2j_node_A_const_pool.A[257]; A_arbace_c2j_node_A_const_70 = A_arbace_c2j_node_A_const_pool.A[258]; A_arbace_c2j_node_A_const_71 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[259]); A_arbace_c2j_node_A_const_72 = A_arbace_c2j_node_A_const_pool.A[260]; A_arbace_c2j_node_A_const_73 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[261]) }

func A_arbace_c2j_node_A_clinit_p6() { A_arbace_c2j_node_A_const_74 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[262]); A_arbace_c2j_node_A_const_75 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[263]); A_arbace_c2j_node_A_const_76 = A_arbace_c2j_node_A_const_pool.A[264]; A_arbace_c2j_node_A_const_77 = A_arbace_c2j_node_A_const_pool.A[265]; A_arbace_c2j_node_A_const_78 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[266]); A_arbace_c2j_node_A_const_79 = A_arbace_c2j_node_A_const_pool.A[267]; A_arbace_c2j_node_A_const_80 = A_arbace_c2j_node_A_const_pool.A[268]; A_arbace_c2j_node_A_const_81 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[269]); A_arbace_c2j_node_A_const_82 = A_arbace_c2j_node_A_const_pool.A[270]; A_arbace_c2j_node_A_const_83 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[271]); A_arbace_c2j_node_A_const_84 = A_arbace_c2j_node_A_const_pool.A[272]; A_arbace_c2j_node_A_const_85 = A_arbace_c2j_node_A_const_pool.A[273]; A_arbace_c2j_node_A_const_86 = A_arbace_c2j_node_A_const_pool.A[274]; A_arbace_c2j_node_A_const_87 = A_arbace_c2j_node_A_const_pool.A[275] }

func A_arbace_c2j_node_A_clinit_p7() { A_arbace_c2j_node_A_const_88 = A_arbace_c2j_node_A_const_pool.A[276]; A_arbace_c2j_node_A_const_89 = A_arbace_c2j_node_A_const_pool.A[277]; A_arbace_c2j_node_A_const_90 = A_arbace_c2j_node_A_const_pool.A[278]; A_arbace_c2j_node_A_const_91 = A_arbace_c2j_node_A_const_pool.A[279]; A_arbace_c2j_node_A_const_92 = A_arbace_c2j_node_A_const_pool.A[280]; A_arbace_c2j_node_A_const_93 = A_arbace_c2j_node_A_const_pool.A[281]; A_arbace_c2j_node_A_const_94 = A_arbace_c2j_node_A_const_pool.A[282]; A_arbace_c2j_node_A_const_95 = A_arbace_c2j_node_A_const_pool.A[283]; A_arbace_c2j_node_A_const_96 = A_arbace_c2j_node_A_const_pool.A[284]; A_arbace_c2j_node_A_const_97 = A_arbace_c2j_node_A_const_pool.A[285]; A_arbace_c2j_node_A_const_98 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[286]); A_arbace_c2j_node_A_const_99 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[287]); A_arbace_c2j_node_A_const_100 = A_arbace_c2j_node_A_const_pool.A[288]; A_arbace_c2j_node_A_const_101 = A_arbace_c2j_node_A_const_pool.A[289]; A_arbace_c2j_node_A_const_102 = A_arbace_c2j_node_A_const_pool.A[290] }

func A_arbace_c2j_node_A_clinit_p8() { A_arbace_c2j_node_A_const_103 = A_arbace_c2j_node_A_const_pool.A[291]; A_arbace_c2j_node_A_const_104 = A_arbace_c2j_node_A_const_pool.A[292]; A_arbace_c2j_node_A_const_105 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[293]); A_arbace_c2j_node_A_const_106 = A_arbace_c2j_node_A_const_pool.A[294]; A_arbace_c2j_node_A_const_107 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[295]); A_arbace_c2j_node_A_const_108 = A_arbace_c2j_node_A_const_pool.A[296]; A_arbace_c2j_node_A_const_109 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[297]); A_arbace_c2j_node_A_const_110 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[298]); A_arbace_c2j_node_A_const_111 = A_arbace_c2j_node_A_const_pool.A[299]; A_arbace_c2j_node_A_const_112 = A_arbace_c2j_node_A_const_pool.A[300]; A_arbace_c2j_node_A_const_113 = A_arbace_c2j_node_A_const_pool.A[301]; A_arbace_c2j_node_A_const_114 = A_arbace_c2j_node_A_const_pool.A[302]; A_arbace_c2j_node_A_const_115 = A_arbace_c2j_node_A_const_pool.A[303]; A_arbace_c2j_node_A_const_116 = A_arbace_c2j_node_A_const_pool.A[304] }

func A_arbace_c2j_node_A_clinit_p9() { A_arbace_c2j_node_A_const_117 = A_arbace_c2j_node_A_const_pool.A[305]; A_arbace_c2j_node_A_const_118 = A_arbace_c2j_node_A_const_pool.A[306]; A_arbace_c2j_node_A_const_119 = A_arbace_c2j_node_A_const_pool.A[307]; A_arbace_c2j_node_A_const_120 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[308]); A_arbace_c2j_node_A_const_121 = A_arbace_c2j_node_A_const_pool.A[309]; A_arbace_c2j_node_A_const_122 = A_arbace_c2j_node_A_const_pool.A[310]; A_arbace_c2j_node_A_const_123 = A_arbace_c2j_node_A_const_pool.A[311]; A_arbace_c2j_node_A_const_124 = A_arbace_c2j_node_A_const_pool.A[312]; A_arbace_c2j_node_A_const_125 = A_arbace_c2j_node_A_const_pool.A[313]; A_arbace_c2j_node_A_const_126 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[314]); A_arbace_c2j_node_A_const_127 = A_arbace_c2j_node_A_const_pool.A[315]; A_arbace_c2j_node_A_const_128 = A_arbace_c2j_node_A_const_pool.A[316]; A_arbace_c2j_node_A_const_129 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[317]); A_arbace_c2j_node_A_const_130 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[318]) }

func A_arbace_c2j_node_A_clinit_p10() { A_arbace_c2j_node_A_const_131 = A_arbace_c2j_node_A_const_pool.A[319]; A_arbace_c2j_node_A_const_132 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[320]); A_arbace_c2j_node_A_const_133 = A_arbace_c2j_node_A_const_pool.A[321]; A_arbace_c2j_node_A_const_134 = A_arbace_c2j_node_A_const_pool.A[322]; A_arbace_c2j_node_A_const_135 = A_arbace_c2j_node_A_const_pool.A[323]; A_arbace_c2j_node_A_const_136 = A_arbace_c2j_node_A_const_pool.A[324]; A_arbace_c2j_node_A_const_137 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[325]); A_arbace_c2j_node_A_const_138 = A_arbace_c2j_node_A_const_pool.A[326]; A_arbace_c2j_node_A_const_139 = A_arbace_c2j_node_A_const_pool.A[327]; A_arbace_c2j_node_A_const_140 = A_arbace_c2j_node_A_const_pool.A[328]; A_arbace_c2j_node_A_const_141 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[329]); A_arbace_c2j_node_A_const_142 = A_arbace_c2j_node_A_const_pool.A[330]; A_arbace_c2j_node_A_const_143 = A_arbace_c2j_node_A_const_pool.A[331]; A_arbace_c2j_node_A_const_144 = A_arbace_c2j_node_A_const_pool.A[332]; A_arbace_c2j_node_A_const_145 = A_arbace_c2j_node_A_const_pool.A[333] }

func A_arbace_c2j_node_A_clinit_p11() { A_arbace_c2j_node_A_const_146 = A_arbace_c2j_node_A_const_pool.A[334]; A_arbace_c2j_node_A_const_147 = A_arbace_c2j_node_A_const_pool.A[335]; A_arbace_c2j_node_A_const_148 = A_arbace_c2j_node_A_const_pool.A[336]; A_arbace_c2j_node_A_const_149 = A_arbace_c2j_node_A_const_pool.A[337]; A_arbace_c2j_node_A_const_150 = A_arbace_c2j_node_A_const_pool.A[338]; A_arbace_c2j_node_A_const_151 = A_arbace_c2j_node_A_const_pool.A[339]; A_arbace_c2j_node_A_const_152 = A_arbace_c2j_node_A_const_pool.A[340]; A_arbace_c2j_node_A_const_153 = A_arbace_c2j_node_A_const_pool.A[341]; A_arbace_c2j_node_A_const_154 = A_arbace_c2j_node_A_const_pool.A[342]; A_arbace_c2j_node_A_const_155 = A_arbace_c2j_node_A_const_pool.A[343]; A_arbace_c2j_node_A_const_156 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[344]); A_arbace_c2j_node_A_const_157 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[345]); A_arbace_c2j_node_A_const_158 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[346]); A_arbace_c2j_node_A_const_159 = A_arbace_c2j_node_A_const_pool.A[347]; A_arbace_c2j_node_A_const_160 = A_arbace_c2j_node_A_const_pool.A[348] }

func A_arbace_c2j_node_A_clinit_p12() { A_arbace_c2j_node_A_const_161 = A_arbace_c2j_node_A_const_pool.A[349]; A_arbace_c2j_node_A_const_162 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[350]); A_arbace_c2j_node_A_const_163 = A_arbace_c2j_node_A_const_pool.A[351]; A_arbace_c2j_node_A_const_164 = A_arbace_c2j_node_A_const_pool.A[352]; A_arbace_c2j_node_A_const_165 = A_arbace_c2j_node_A_const_pool.A[353]; A_arbace_c2j_node_A_const_166 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[354]); A_arbace_c2j_node_A_const_167 = A_arbace_c2j_node_A_const_pool.A[355]; A_arbace_c2j_node_A_const_168 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[356]); A_arbace_c2j_node_A_const_169 = A_arbace_c2j_node_A_const_pool.A[357]; A_arbace_c2j_node_A_const_170 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[358]); A_arbace_c2j_node_A_const_171 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[359]); A_arbace_c2j_node_A_const_172 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[360]); A_arbace_c2j_node_A_const_173 = A_arbace_c2j_node_A_const_pool.A[361]; A_arbace_c2j_node_A_const_174 = A_arbace_c2j_node_A_const_pool.A[362] }

func A_arbace_c2j_node_A_clinit_p13() { A_arbace_c2j_node_A_const_175 = A_arbace_c2j_node_A_const_pool.A[363]; A_arbace_c2j_node_A_const_176 = A_arbace_c2j_node_A_const_pool.A[364]; A_arbace_c2j_node_A_const_177 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[365]); A_arbace_c2j_node_A_const_178 = A_arbace_c2j_node_A_const_pool.A[366]; A_arbace_c2j_node_A_const_179 = A_arbace_c2j_node_A_const_pool.A[367]; A_arbace_c2j_node_A_const_180 = A_arbace_c2j_node_A_const_pool.A[368]; A_arbace_c2j_node_A_const_181 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[369]); A_arbace_c2j_node_A_const_182 = A_arbace_c2j_node_A_const_pool.A[370]; A_arbace_c2j_node_A_const_183 = A_arbace_c2j_node_A_const_pool.A[371]; A_arbace_c2j_node_A_const_184 = A_arbace_c2j_node_A_const_pool.A[372]; A_arbace_c2j_node_A_const_185 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[373]); A_arbace_c2j_node_A_const_186 = A_arbace_c2j_node_A_const_pool.A[374]; A_arbace_c2j_node_A_const_187 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[375]); A_arbace_c2j_node_A_const_188 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[376]) }

func A_arbace_c2j_node_A_clinit_p14() { A_arbace_c2j_node_A_const_189 = A_arbace_c2j_node_A_const_pool.A[377]; A_arbace_c2j_node_A_const_190 = A_arbace_c2j_node_A_const_pool.A[378]; A_arbace_c2j_node_A_const_191 = A_arbace_c2j_node_A_const_pool.A[379]; A_arbace_c2j_node_A_const_192 = A_arbace_c2j_node_A_const_pool.A[380]; A_arbace_c2j_node_A_const_193 = A_arbace_c2j_node_A_const_pool.A[381]; A_arbace_c2j_node_A_const_194 = A_arbace_c2j_node_A_const_pool.A[382]; A_arbace_c2j_node_A_const_195 = A_arbace_c2j_node_A_const_pool.A[383]; A_arbace_c2j_node_A_const_196 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[384]); A_arbace_c2j_node_A_const_197 = A_arbace_c2j_node_A_const_pool.A[385]; A_arbace_c2j_node_A_const_198 = A_arbace_c2j_node_A_const_pool.A[386]; A_arbace_c2j_node_A_const_199 = A_arbace_c2j_node_A_const_pool.A[387]; A_arbace_c2j_node_A_const_200 = A_arbace_c2j_node_A_const_pool.A[388]; A_arbace_c2j_node_A_const_201 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[389]); A_arbace_c2j_node_A_const_202 = A_arbace_c2j_node_A_const_pool.A[390]; A_arbace_c2j_node_A_const_203 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[391]) }

func A_arbace_c2j_node_A_clinit_p15() { A_arbace_c2j_node_A_const_204 = A_arbace_c2j_node_A_const_pool.A[392]; A_arbace_c2j_node_A_const_205 = A_arbace_c2j_node_A_const_pool.A[393]; A_arbace_c2j_node_A_const_206 = A_arbace_c2j_node_A_const_pool.A[394]; A_arbace_c2j_node_A_const_207 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[395]); A_arbace_c2j_node_A_const_208 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[396]); A_arbace_c2j_node_A_const_209 = A_arbace_c2j_node_A_const_pool.A[397]; A_arbace_c2j_node_A_const_210 = A_arbace_c2j_node_A_const_pool.A[398]; A_arbace_c2j_node_A_const_211 = A_arbace_c2j_node_A_const_pool.A[399]; A_arbace_c2j_node_A_const_212 = A_arbace_c2j_node_A_const_pool.A[400]; A_arbace_c2j_node_A_const_213 = A_arbace_c2j_node_A_const_pool.A[401]; A_arbace_c2j_node_A_const_214 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[402]); A_arbace_c2j_node_A_const_215 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[403]); A_arbace_c2j_node_A_const_216 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[404]); A_arbace_c2j_node_A_const_217 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[405]) }

func A_arbace_c2j_node_A_clinit_p16() { A_arbace_c2j_node_A_const_218 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[406]); A_arbace_c2j_node_A_const_219 = A_arbace_c2j_node_A_const_pool.A[407]; A_arbace_c2j_node_A_const_220 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[408]); A_arbace_c2j_node_A_const_221 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[409]); A_arbace_c2j_node_A_const_222 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[410]); A_arbace_c2j_node_A_const_223 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[411]); A_arbace_c2j_node_A_const_224 = A_arbace_c2j_node_A_const_pool.A[412]; A_arbace_c2j_node_A_const_225 = A_arbace_c2j_node_A_const_pool.A[413]; A_arbace_c2j_node_A_const_226 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[414]); A_arbace_c2j_node_A_const_227 = A_arbace_c2j_node_A_const_pool.A[415]; A_arbace_c2j_node_A_const_228 = A_arbace_c2j_node_A_const_pool.A[416]; A_arbace_c2j_node_A_const_229 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[417]); A_arbace_c2j_node_A_const_230 = A_arbace_c2j_node_A_const_pool.A[418] }

func A_arbace_c2j_node_A_clinit_p17() { A_arbace_c2j_node_A_const_231 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[419]); A_arbace_c2j_node_A_const_232 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[420]); A_arbace_c2j_node_A_const_233 = A_arbace_c2j_node_A_const_pool.A[421]; A_arbace_c2j_node_A_const_234 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[422]); A_arbace_c2j_node_A_const_235 = A_arbace_c2j_node_A_const_pool.A[423]; A_arbace_c2j_node_A_const_236 = A_arbace_c2j_node_A_const_pool.A[424]; A_arbace_c2j_node_A_const_237 = A_arbace_c2j_node_A_const_pool.A[425]; A_arbace_c2j_node_A_const_238 = A_arbace_c2j_node_A_const_pool.A[426]; A_arbace_c2j_node_A_const_239 = A_arbace_c2j_node_A_const_pool.A[427]; A_arbace_c2j_node_A_const_240 = A_arbace_c2j_node_A_const_pool.A[428]; A_arbace_c2j_node_A_const_241 = A_arbace_c2j_node_A_const_pool.A[429]; A_arbace_c2j_node_A_const_242 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[430]); A_arbace_c2j_node_A_const_243 = A_arbace_c2j_node_A_const_pool.A[431]; A_arbace_c2j_node_A_const_244 = A_arbace_c2j_node_A_const_pool.A[432] }

func A_arbace_c2j_node_A_clinit_p18() { A_arbace_c2j_node_A_const_245 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[433]); A_arbace_c2j_node_A_const_246 = A_arbace_c2j_node_A_const_pool.A[434]; A_arbace_c2j_node_A_const_247 = A_arbace_c2j_node_A_const_pool.A[435]; A_arbace_c2j_node_A_const_248 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[436]); A_arbace_c2j_node_A_const_249 = A_arbace_c2j_node_A_const_pool.A[437]; A_arbace_c2j_node_A_const_250 = A_arbace_c2j_node_A_const_pool.A[438]; A_arbace_c2j_node_A_const_251 = A_arbace_c2j_node_A_const_pool.A[439]; A_arbace_c2j_node_A_const_252 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[440]); A_arbace_c2j_node_A_const_253 = A_arbace_c2j_node_A_const_pool.A[441]; A_arbace_c2j_node_A_const_254 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[442]); A_arbace_c2j_node_A_const_255 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[443]); A_arbace_c2j_node_A_const_256 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[444]); A_arbace_c2j_node_A_const_257 = A_arbace_c2j_node_A_const_pool.A[445]; A_arbace_c2j_node_A_const_258 = A_arbace_c2j_node_A_const_pool.A[446] }

func A_arbace_c2j_node_A_clinit_p19() { A_arbace_c2j_node_A_const_259 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[447]); A_arbace_c2j_node_A_const_260 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[448]); A_arbace_c2j_node_A_const_261 = A_arbace_c2j_node_A_const_pool.A[449]; A_arbace_c2j_node_A_const_262 = A_arbace_c2j_node_A_const_pool.A[450]; A_arbace_c2j_node_A_const_263 = A_arbace_c2j_node_A_const_pool.A[451]; A_arbace_c2j_node_A_const_264 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[452]); A_arbace_c2j_node_A_const_265 = A_arbace_c2j_node_A_const_pool.A[453]; A_arbace_c2j_node_A_const_266 = A_arbace_c2j_node_A_const_pool.A[454]; A_arbace_c2j_node_A_const_267 = A_arbace_c2j_node_A_const_pool.A[455]; A_arbace_c2j_node_A_const_268 = A_arbace_c2j_node_A_const_pool.A[456]; A_arbace_c2j_node_A_const_269 = A_arbace_c2j_node_A_const_pool.A[457]; A_arbace_c2j_node_A_const_270 = A_arbace_c2j_node_A_const_pool.A[458]; A_arbace_c2j_node_A_const_271 = A_arbace_c2j_node_A_const_pool.A[459]; A_arbace_c2j_node_A_const_272 = A_arbace_c2j_node_A_const_pool.A[460]; A_arbace_c2j_node_A_const_273 = A_arbace_c2j_node_A_const_pool.A[461] }

func A_arbace_c2j_node_A_clinit_p20() { A_arbace_c2j_node_A_const_274 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[462]); A_arbace_c2j_node_A_const_275 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[463]); A_arbace_c2j_node_A_const_276 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[464]); A_arbace_c2j_node_A_const_277 = A_arbace_c2j_node_A_const_pool.A[465]; A_arbace_c2j_node_A_const_278 = A_arbace_c2j_node_A_const_pool.A[466]; A_arbace_c2j_node_A_const_279 = A_arbace_c2j_node_A_const_pool.A[467]; A_arbace_c2j_node_A_const_280 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[468]); A_arbace_c2j_node_A_const_281 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[469]); A_arbace_c2j_node_A_const_282 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[470]); A_arbace_c2j_node_A_const_283 = jrt.Class_Cast(A_arbace_c2j_node_A_const_pool.A[471]); A_arbace_c2j_node_A_const_284 = A_arbace_c2j_node_A_const_pool.A[472]; A_arbace_c2j_node_A_const_285 = A_arbace_c2j_node_A_const_pool.A[473]; A_arbace_c2j_node_A_const_286 = A_arbace_c2j_node_A_const_pool.A[474] }

func A_arbace_c2j_node_A_clinit_p21() { A_arbace_c2j_node_A_const_287 = A_arbace_c2j_node_A_const_pool.A[475]; A_arbace_c2j_node_A_const_288 = A_arbace_c2j_node_A_const_pool.A[476]; A_arbace_c2j_node_A_const_289 = A_arbace_c2j_node_A_const_pool.A[477]; A_arbace_c2j_node_A_const_290 = A_arbace_c2j_node_A_const_pool.A[478]; A_arbace_c2j_node_A_const_291 = A_arbace_c2j_node_A_const_pool.A[479]; A_arbace_c2j_node_A_const_292 = A_arbace_c2j_node_A_const_pool.A[480]; A_arbace_c2j_node_A_const_293 = A_arbace_c2j_node_A_const_pool.A[481]; A_arbace_c2j_node_A_const_294 = A_arbace_c2j_node_A_const_pool.A[482]; A_arbace_c2j_node_A_const_295 = A_arbace_c2j_node_A_const_pool.A[483]; A_arbace_c2j_node_A_const_296 = A_arbace_c2j_node_A_const_pool.A[484]; A_arbace_c2j_node_A_const_297 = A_arbace_c2j_node_A_const_pool.A[485]; A_arbace_c2j_node_A_const_298 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[486]); A_arbace_c2j_node_A_const_299 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[487]); A_arbace_c2j_node_A_const_300 = A_arbace_c2j_node_A_const_pool.A[488]; A_arbace_c2j_node_A_const_301 = A_arbace_c2j_node_A_const_pool.A[489] }

func A_arbace_c2j_node_A_clinit_p22() { A_arbace_c2j_node_A_const_302 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[490]); A_arbace_c2j_node_A_const_303 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[491]); A_arbace_c2j_node_A_const_304 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[492]); A_arbace_c2j_node_A_const_305 = A_arbace_c2j_node_A_const_pool.A[493]; A_arbace_c2j_node_A_const_306 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[494]); A_arbace_c2j_node_A_const_307 = A_arbace_c2j_node_A_const_pool.A[495]; A_arbace_c2j_node_A_const_308 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[496]); A_arbace_c2j_node_A_const_309 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[497]); A_arbace_c2j_node_A_const_310 = A_arbace_c2j_node_A_const_pool.A[498]; A_arbace_c2j_node_A_const_311 = A_arbace_c2j_node_A_const_pool.A[499]; A_arbace_c2j_node_A_const_312 = A_arbace_c2j_node_A_const_pool.A[500]; A_arbace_c2j_node_A_const_313 = A_arbace_c2j_node_A_const_pool.A[501]; A_arbace_c2j_node_A_const_314 = A_arbace_c2j_node_A_const_pool.A[502]; A_arbace_c2j_node_A_const_315 = A_arbace_c2j_node_A_const_pool.A[503] }

func A_arbace_c2j_node_A_clinit_p23() { A_arbace_c2j_node_A_const_316 = A_arbace_c2j_node_A_const_pool.A[504]; A_arbace_c2j_node_A_const_317 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[505]); A_arbace_c2j_node_A_const_318 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[506]); A_arbace_c2j_node_A_const_319 = A_arbace_c2j_node_A_const_pool.A[507]; A_arbace_c2j_node_A_const_320 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[508]); A_arbace_c2j_node_A_const_321 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[509]); A_arbace_c2j_node_A_const_322 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[510]); A_arbace_c2j_node_A_const_323 = A_arbace_c2j_node_A_const_pool.A[511]; A_arbace_c2j_node_A_const_324 = A_arbace_c2j_node_A_const_pool.A[512]; A_arbace_c2j_node_A_const_325 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[513]); A_arbace_c2j_node_A_const_326 = A_arbace_c2j_node_A_const_pool.A[514]; A_arbace_c2j_node_A_const_327 = A_arbace_c2j_node_A_const_pool.A[515]; A_arbace_c2j_node_A_const_328 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[516]) }

func A_arbace_c2j_node_A_clinit_p24() { A_arbace_c2j_node_A_const_329 = A_arbace_c2j_node_A_const_pool.A[517]; A_arbace_c2j_node_A_const_330 = A_arbace_c2j_node_A_const_pool.A[518]; A_arbace_c2j_node_A_const_331 = A_arbace_c2j_node_A_const_pool.A[519]; A_arbace_c2j_node_A_const_332 = A_arbace_c2j_node_A_const_pool.A[520]; A_arbace_c2j_node_A_const_333 = A_arbace_c2j_node_A_const_pool.A[521]; A_arbace_c2j_node_A_const_334 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[522]); A_arbace_c2j_node_A_const_335 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[523]); A_arbace_c2j_node_A_const_336 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[524]); A_arbace_c2j_node_A_const_337 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[525]); A_arbace_c2j_node_A_const_338 = A_arbace_c2j_node_A_const_pool.A[526]; A_arbace_c2j_node_A_const_339 = A_arbace_c2j_node_A_const_pool.A[527]; A_arbace_c2j_node_A_const_340 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[528]); A_arbace_c2j_node_A_const_341 = A_arbace_c2j_node_A_const_pool.A[529]; A_arbace_c2j_node_A_const_342 = A_arbace_c2j_node_A_const_pool.A[530] }

func A_arbace_c2j_node_A_clinit_p25() { A_arbace_c2j_node_A_const_343 = A_arbace_c2j_node_A_const_pool.A[531]; A_arbace_c2j_node_A_const_344 = A_arbace_c2j_node_A_const_pool.A[532]; A_arbace_c2j_node_A_const_345 = A_arbace_c2j_node_A_const_pool.A[533]; A_arbace_c2j_node_A_const_346 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[534]); A_arbace_c2j_node_A_const_347 = A_arbace_c2j_node_A_const_pool.A[535]; A_arbace_c2j_node_A_const_348 = A_arbace_c2j_node_A_const_pool.A[536]; A_arbace_c2j_node_A_const_349 = A_arbace_c2j_node_A_const_pool.A[537]; A_arbace_c2j_node_A_const_350 = A_arbace_c2j_node_A_const_pool.A[538]; A_arbace_c2j_node_A_const_351 = A_arbace_c2j_node_A_const_pool.A[539]; A_arbace_c2j_node_A_const_352 = A_arbace_c2j_node_A_const_pool.A[540]; A_arbace_c2j_node_A_const_353 = A_arbace_c2j_node_A_const_pool.A[541]; A_arbace_c2j_node_A_const_354 = A_arbace_c2j_node_A_const_pool.A[542]; A_arbace_c2j_node_A_const_355 = A_arbace_c2j_node_A_const_pool.A[543]; A_arbace_c2j_node_A_const_356 = A_arbace_c2j_node_A_const_pool.A[544]; A_arbace_c2j_node_A_const_357 = A_arbace_c2j_node_A_const_pool.A[545] }

func A_arbace_c2j_node_A_clinit_p26() { A_arbace_c2j_node_A_const_358 = A_arbace_c2j_node_A_const_pool.A[546]; A_arbace_c2j_node_A_const_359 = A_arbace_c2j_node_A_const_pool.A[547]; A_arbace_c2j_node_A_const_360 = A_arbace_c2j_node_A_const_pool.A[548]; A_arbace_c2j_node_A_const_361 = A_arbace_c2j_node_A_const_pool.A[549]; A_arbace_c2j_node_A_const_362 = A_arbace_c2j_node_A_const_pool.A[550]; A_arbace_c2j_node_A_const_363 = A_arbace_c2j_node_A_const_pool.A[551]; A_arbace_c2j_node_A_const_364 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[552]); A_arbace_c2j_node_A_const_365 = A_arbace_c2j_node_A_const_pool.A[553]; A_arbace_c2j_node_A_const_366 = A_arbace_c2j_node_A_const_pool.A[554]; A_arbace_c2j_node_A_const_367 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[555]); A_arbace_c2j_node_A_const_368 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[556]); A_arbace_c2j_node_A_const_369 = A_arbace_c2j_node_A_const_pool.A[557]; A_arbace_c2j_node_A_const_370 = A_arbace_c2j_node_A_const_pool.A[558]; A_arbace_c2j_node_A_const_371 = A_arbace_c2j_node_A_const_pool.A[559]; A_arbace_c2j_node_A_const_372 = A_arbace_c2j_node_A_const_pool.A[560] }

func A_arbace_c2j_node_A_clinit_p27() { A_arbace_c2j_node_A_const_373 = A_arbace_c2j_node_A_const_pool.A[561]; A_arbace_c2j_node_A_const_374 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[562]); A_arbace_c2j_node_A_const_375 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[563]); A_arbace_c2j_node_A_const_376 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[564]); A_arbace_c2j_node_A_const_377 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[565]); A_arbace_c2j_node_A_const_378 = A_arbace_c2j_node_A_const_pool.A[566]; A_arbace_c2j_node_A_const_379 = A_arbace_c2j_node_A_const_pool.A[567]; A_arbace_c2j_node_A_const_380 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[568]); A_arbace_c2j_node_A_const_381 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[569]); A_arbace_c2j_node_A_const_382 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[570]); A_arbace_c2j_node_A_const_383 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[571]); A_arbace_c2j_node_A_const_384 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[572]) }

func A_arbace_c2j_node_A_clinit_p28() { A_arbace_c2j_node_A_const_385 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[573]); A_arbace_c2j_node_A_const_386 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[574]); A_arbace_c2j_node_A_const_387 = A_arbace_c2j_node_A_const_pool.A[575]; A_arbace_c2j_node_A_const_388 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[576]); A_arbace_c2j_node_A_const_389 = A_arbace_c2j_node_A_const_pool.A[577]; A_arbace_c2j_node_A_const_390 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[578]); A_arbace_c2j_node_A_const_391 = A_arbace_c2j_node_A_const_pool.A[579]; A_arbace_c2j_node_A_const_392 = A_arbace_c2j_node_A_const_pool.A[580]; A_arbace_c2j_node_A_const_393 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[581]); A_arbace_c2j_node_A_const_394 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[582]); A_arbace_c2j_node_A_const_395 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[583]); A_arbace_c2j_node_A_const_396 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[584]); A_arbace_c2j_node_A_const_397 = A_arbace_c2j_node_A_const_pool.A[585] }

func A_arbace_c2j_node_A_clinit_p29() { A_arbace_c2j_node_A_const_398 = A_arbace_c2j_node_A_const_pool.A[586]; A_arbace_c2j_node_A_const_399 = A_arbace_c2j_node_A_const_pool.A[587]; A_arbace_c2j_node_A_const_400 = A_arbace_c2j_node_A_const_pool.A[588]; A_arbace_c2j_node_A_const_401 = A_arbace_c2j_node_A_const_pool.A[589]; A_arbace_c2j_node_A_const_402 = A_arbace_c2j_node_A_const_pool.A[590]; A_arbace_c2j_node_A_const_403 = A_arbace_c2j_node_A_const_pool.A[591]; A_arbace_c2j_node_A_const_404 = A_arbace_c2j_node_A_const_pool.A[592]; A_arbace_c2j_node_A_const_405 = A_arbace_c2j_node_A_const_pool.A[593]; A_arbace_c2j_node_A_const_406 = A_arbace_c2j_node_A_const_pool.A[594]; A_arbace_c2j_node_A_const_407 = A_arbace_c2j_node_A_const_pool.A[595]; A_arbace_c2j_node_A_const_408 = A_arbace_c2j_node_A_const_pool.A[596]; A_arbace_c2j_node_A_const_409 = A_arbace_c2j_node_A_const_pool.A[597]; A_arbace_c2j_node_A_const_410 = A_arbace_c2j_node_A_const_pool.A[598]; A_arbace_c2j_node_A_const_411 = A_arbace_c2j_node_A_const_pool.A[599]; A_arbace_c2j_node_A_const_412 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[600]) }

func A_arbace_c2j_node_A_clinit_p30() { A_arbace_c2j_node_A_const_413 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[601]); A_arbace_c2j_node_A_const_414 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[602]); A_arbace_c2j_node_A_const_415 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[603]); A_arbace_c2j_node_A_const_416 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[604]); A_arbace_c2j_node_A_const_417 = A_arbace_c2j_node_A_const_pool.A[605]; A_arbace_c2j_node_A_const_418 = A_arbace_c2j_node_A_const_pool.A[606]; A_arbace_c2j_node_A_const_419 = A_arbace_c2j_node_A_const_pool.A[607]; A_arbace_c2j_node_A_const_420 = A_arbace_c2j_node_A_const_pool.A[608]; A_arbace_c2j_node_A_const_421 = A_arbace_c2j_node_A_const_pool.A[609]; A_arbace_c2j_node_A_const_422 = A_arbace_c2j_node_A_const_pool.A[610]; A_arbace_c2j_node_A_const_423 = A_arbace_c2j_node_A_const_pool.A[611]; A_arbace_c2j_node_A_const_424 = A_arbace_c2j_node_A_const_pool.A[612]; A_arbace_c2j_node_A_const_425 = A_arbace_c2j_node_A_const_pool.A[613]; A_arbace_c2j_node_A_const_426 = A_arbace_c2j_node_A_const_pool.A[614] }

func A_arbace_c2j_node_A_clinit_p31() { A_arbace_c2j_node_A_const_427 = A_arbace_c2j_node_A_const_pool.A[615]; A_arbace_c2j_node_A_const_428 = A_arbace_c2j_node_A_const_pool.A[616]; A_arbace_c2j_node_A_const_429 = A_arbace_c2j_node_A_const_pool.A[617]; A_arbace_c2j_node_A_const_430 = A_arbace_c2j_node_A_const_pool.A[618]; A_arbace_c2j_node_A_const_431 = A_arbace_c2j_node_A_const_pool.A[619]; A_arbace_c2j_node_A_const_432 = A_arbace_c2j_node_A_const_pool.A[620]; A_arbace_c2j_node_A_const_433 = A_arbace_c2j_node_A_const_pool.A[621]; A_arbace_c2j_node_A_const_434 = A_arbace_c2j_node_A_const_pool.A[622]; A_arbace_c2j_node_A_const_435 = A_arbace_c2j_node_A_const_pool.A[623]; A_arbace_c2j_node_A_const_436 = A_arbace_c2j_node_A_const_pool.A[624]; A_arbace_c2j_node_A_const_437 = A_arbace_c2j_node_A_const_pool.A[625]; A_arbace_c2j_node_A_const_438 = A_arbace_c2j_node_A_const_pool.A[626]; A_arbace_c2j_node_A_const_439 = A_arbace_c2j_node_A_const_pool.A[627]; A_arbace_c2j_node_A_const_440 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[628]); A_arbace_c2j_node_A_const_441 = A_arbace_c2j_node_A_const_pool.A[629] }

func A_arbace_c2j_node_A_clinit_p32() { A_arbace_c2j_node_A_const_442 = A_arbace_c2j_node_A_const_pool.A[630]; A_arbace_c2j_node_A_const_443 = A_arbace_c2j_node_A_const_pool.A[631]; A_arbace_c2j_node_A_const_444 = A_arbace_c2j_node_A_const_pool.A[632]; A_arbace_c2j_node_A_const_445 = A_arbace_c2j_node_A_const_pool.A[633]; A_arbace_c2j_node_A_const_446 = A_arbace_c2j_node_A_const_pool.A[634]; A_arbace_c2j_node_A_const_447 = A_arbace_c2j_node_A_const_pool.A[635]; A_arbace_c2j_node_A_const_448 = A_arbace_c2j_node_A_const_pool.A[636]; A_arbace_c2j_node_A_const_449 = A_arbace_c2j_node_A_const_pool.A[637]; A_arbace_c2j_node_A_const_450 = A_arbace_c2j_node_A_const_pool.A[638]; A_arbace_c2j_node_A_const_451 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[639]); A_arbace_c2j_node_A_const_452 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[640]); A_arbace_c2j_node_A_const_453 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[641]); A_arbace_c2j_node_A_const_454 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[642]); A_arbace_c2j_node_A_const_455 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[643]) }

func A_arbace_c2j_node_A_clinit_p33() { A_arbace_c2j_node_A_const_456 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[644]); A_arbace_c2j_node_A_const_457 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[645]); A_arbace_c2j_node_A_const_458 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[646]); A_arbace_c2j_node_A_const_459 = A_arbace_c2j_node_A_const_pool.A[647]; A_arbace_c2j_node_A_const_460 = A_arbace_c2j_node_A_const_pool.A[648]; A_arbace_c2j_node_A_const_461 = A_arbace_c2j_node_A_const_pool.A[649]; A_arbace_c2j_node_A_const_462 = A_arbace_c2j_node_A_const_pool.A[650]; A_arbace_c2j_node_A_const_463 = A_arbace_c2j_node_A_const_pool.A[651]; A_arbace_c2j_node_A_const_464 = A_arbace_c2j_node_A_const_pool.A[652]; A_arbace_c2j_node_A_const_465 = A_arbace_c2j_node_A_const_pool.A[653]; A_arbace_c2j_node_A_const_466 = A_arbace_c2j_node_A_const_pool.A[654]; A_arbace_c2j_node_A_const_467 = A_arbace_c2j_node_A_const_pool.A[655]; A_arbace_c2j_node_A_const_468 = A_arbace_c2j_node_A_const_pool.A[656]; A_arbace_c2j_node_A_const_469 = A_arbace_c2j_node_A_const_pool.A[657]; A_arbace_c2j_node_A_const_470 = A_arbace_c2j_node_A_const_pool.A[658] }

func A_arbace_c2j_node_A_clinit_p34() { A_arbace_c2j_node_A_const_471 = A_arbace_c2j_node_A_const_pool.A[659]; A_arbace_c2j_node_A_const_472 = A_arbace_c2j_node_A_const_pool.A[660]; A_arbace_c2j_node_A_const_473 = A_arbace_c2j_node_A_const_pool.A[661]; A_arbace_c2j_node_A_const_474 = A_arbace_c2j_node_A_const_pool.A[662]; A_arbace_c2j_node_A_const_475 = A_arbace_c2j_node_A_const_pool.A[663]; A_arbace_c2j_node_A_const_476 = A_arbace_c2j_node_A_const_pool.A[664]; A_arbace_c2j_node_A_const_477 = A_arbace_c2j_node_A_const_pool.A[665]; A_arbace_c2j_node_A_const_478 = A_arbace_c2j_node_A_const_pool.A[666]; A_arbace_c2j_node_A_const_479 = A_arbace_c2j_node_A_const_pool.A[667]; A_arbace_c2j_node_A_const_480 = A_arbace_c2j_node_A_const_pool.A[668]; A_arbace_c2j_node_A_const_481 = A_arbace_c2j_node_A_const_pool.A[669] }

func A_arbace_c2j_node_A_New() *A_arbace_c2j_node_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_node_A) Ctor() {}

func (t *A_arbace_c2j_node_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_node_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_node_A_class }

func (t *A_arbace_c2j_node_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_node_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_node_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_node_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_node_A); return ok }

func A_arbace_c2j_node_A_Cast(x any) *A_arbace_c2j_node_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_node_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_node_A_class)) }; return v }



type A_arbace_c2j_node_arg_kind_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_arg_kind_A_fn_class *jrt.Class



type A_arbace_c2j_node_camel_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_camel_A_fn_class *jrt.Class



type A_arbace_c2j_node_children_bind_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_children_bind_A_fn_class *jrt.Class



type A_arbace_c2j_node_children_bind_fn__400000028_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_children_bind_fn__400000028_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_construct__400000391_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_construct__400000391_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000383_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_fn__400000383_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000385_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_fn__400000385_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000387_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_fn__400000387_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000405_A struct{ j2g_header uint64; F_pick any }

var A_arbace_c2j_node_clause_fn__400000405_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000411_A struct{ j2g_header uint64; F_pick any }

var A_arbace_c2j_node_clause_fn__400000411_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_pick__400000396_A struct{ j2g_header uint64; F_construct, F_ss any }

var A_arbace_c2j_node_clause_pick__400000396_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_pick__400000396_go__400000397_A struct{ j2g_header uint64; F_construct any }

var A_arbace_c2j_node_clause_pick__400000396_go__400000397_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000398_A struct{ j2g_header uint64; F_s any }

var A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000398_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000400_A struct{ j2g_header uint64; F_s any }

var A_arbace_c2j_node_clause_pick__400000396_go__400000397_fn__400000400_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_fn__400000438_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_fn__400000438_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_fn__400000510_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_fn__400000510_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000417__400000421_A struct{ j2g_header uint64; F_helpers, F_domains any }

var A_arbace_c2j_node_code_forms_iter__400000417__400000421_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_A struct{ j2g_header uint64; F_helpers, F_iter__400000417, F_s__400000418, F_domains any }

var A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_A struct{ j2g_header uint64; F_helpers, F_domains, F_b__400000420 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_fn__400000424_A struct{ j2g_header uint64; F_d, F_helpers any }

var A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000423_fn__400000424_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000430_A struct{ j2g_header uint64; F_d, F_helpers any }

var A_arbace_c2j_node_code_forms_iter__400000417__400000421_fn__400000422_fn__400000430_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000442__400000450_A struct{ j2g_header uint64; F_domains, F_keys any }

var A_arbace_c2j_node_code_forms_iter__400000442__400000450_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_A struct{ j2g_header uint64; F_s__400000443, F_domains, F_keys, F_iter__400000442 any }

var A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_A struct{ j2g_header uint64; F_keys, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_A struct{ j2g_header uint64; F_iter__400000444, F_s__400000445, F_keys, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_A struct{ j2g_header uint64; F_k, F_keys, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_A struct{ j2g_header uint64; F_iter__400000446, F_k, F_s__400000447, F_keys, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_fn__400000461_A struct{ j2g_header uint64; F_k, F_keys, F_b__400000449 any; F_size__1927001038__auto__ int32; F_d, F_c__1927001037__auto__ any }

var A_arbace_c2j_node_code_forms_iter__400000442__400000450_fn__400000451_iter__400000444__400000454_fn__400000455_iter__400000446__400000459_fn__400000460_fn__400000461_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000475__400000481_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_iter__400000475__400000481_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_A struct{ j2g_header uint64; F_s__400000476, F_iter__400000475 any }

var A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_A struct{ j2g_header uint64; F_d any }

var A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_A struct{ j2g_header uint64; F_iter__400000477, F_s__400000478, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_A struct{ j2g_header uint64; F_b__400000480 any; F_size__1927001038__auto__ int32; F_d, F_c__1927001037__auto__ any }

var A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_fn__400000491_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000487_fn__400000491_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000500_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_iter__400000475__400000481_fn__400000482_iter__400000477__400000485_fn__400000486_fn__400000500_A_fn_class *jrt.Class



type A_arbace_c2j_node_defnode_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_defnode_A_fn_class *jrt.Class



type A_arbace_c2j_node_emit_fn_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_emit_fn_A_fn_class *jrt.Class



type A_arbace_c2j_node_emit_fn_fn__400000157_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_emit_fn_fn__400000157_A_fn_class *jrt.Class



type A_arbace_c2j_node_emit_fn_fn__400000161_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_emit_fn_fn__400000161_A_fn_class *jrt.Class



type A_arbace_c2j_node_emit_fn_fn__400000169_A struct{ j2g_header uint64; F_env0 any }

var A_arbace_c2j_node_emit_fn_fn__400000169_A_fn_class *jrt.Class



type A_arbace_c2j_node_eval400000004_A struct{ jrt.Object }

func A_arbace_c2j_node_eval400000004_A_New() *A_arbace_c2j_node_eval400000004_A { t := &A_arbace_c2j_node_eval400000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_node_eval400000004_A) Ctor() {}

func (t *A_arbace_c2j_node_eval400000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_node_eval400000004_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_node_eval400000004_A_class }

func (t *A_arbace_c2j_node_eval400000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_node_eval400000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_node_eval400000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_node_eval400000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_node_eval400000004_A); return ok }

func A_arbace_c2j_node_eval400000004_A_Cast(x any) *A_arbace_c2j_node_eval400000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_node_eval400000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_node_eval400000004_A_class)) }; return v }



type A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A_fn_class *jrt.Class



type A_arbace_c2j_node_eval400000008_A struct{ jrt.Object }

func A_arbace_c2j_node_eval400000008_A_New() *A_arbace_c2j_node_eval400000008_A { t := &A_arbace_c2j_node_eval400000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_node_eval400000008_A) Ctor() {}

func (t *A_arbace_c2j_node_eval400000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_node_eval400000008_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_node_eval400000008_A_class }

func (t *A_arbace_c2j_node_eval400000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_node_eval400000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_node_eval400000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_node_eval400000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_node_eval400000008_A); return ok }

func A_arbace_c2j_node_eval400000008_A_Cast(x any) *A_arbace_c2j_node_eval400000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_node_eval400000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_node_eval400000008_A_class)) }; return v }



type A_arbace_c2j_node_eval400000008_fn__400000009_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_eval400000008_fn__400000009_A_fn_class *jrt.Class



type A_arbace_c2j_node_field_names_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_field_names_A_fn_class *jrt.Class



type A_arbace_c2j_node_field_names_fn__400000024_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_field_names_fn__400000024_A_fn_class *jrt.Class



type A_arbace_c2j_node_head_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_head_A_fn_class *jrt.Class



type A_arbace_c2j_node_invalid_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_invalid_A_fn_class *jrt.Class



type A_arbace_c2j_node_parse_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_parse_A_fn_class *jrt.Class



type A_arbace_c2j_node_parse_fn__400000018_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_parse_fn__400000018_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_body_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_body_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_body_fn__400000056_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_body_fn__400000056_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_drop_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_drop_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_node_q_elems_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_elems_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_elems_fn__400000048_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_elems_fn__400000048_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_elems_fn__400000051_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_elems_fn__400000051_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_seq_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_fn__400000084_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_seq_fn__400000084_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_fn__400000113_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_seq_fn__400000113_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_fn__400000132_A struct{ j2g_header uint64; F_fresh any }

var A_arbace_c2j_node_q_seq_fn__400000132_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_fn__400000140_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_seq_fn__400000140_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qe_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_elems_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qe_elems_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_elems_fn__400000181_A struct{ j2g_header uint64; F_env, F_v any }

var A_arbace_c2j_node_qe_elems_fn__400000181_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qe_seq_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000196_A struct{ j2g_header uint64; F_b any }

var A_arbace_c2j_node_qe_seq_fn__400000196_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000198_A struct{ j2g_header uint64; F_env, F_v any }

var A_arbace_c2j_node_qe_seq_fn__400000198_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000219_A struct{ j2g_header uint64; F_g any }

var A_arbace_c2j_node_qe_seq_fn__400000219_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000234_A struct{ j2g_header uint64; F_tmp, F_v any }

var A_arbace_c2j_node_qe_seq_fn__400000234_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000234_fn__400000241_A struct{ j2g_header uint64; F_tmp any }

var A_arbace_c2j_node_qe_seq_fn__400000234_fn__400000241_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000244_A struct{ j2g_header uint64; F_v, F_env any }

var A_arbace_c2j_node_qe_seq_fn__400000244_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000253_A struct{ j2g_header uint64; F_env, F_v any }

var A_arbace_c2j_node_qe_seq_fn__400000253_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000258_A struct{ j2g_header uint64; F_env, F_v any }

var A_arbace_c2j_node_qe_seq_fn__400000258_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000263_A struct{ j2g_header uint64; F_ts, F_b any }

var A_arbace_c2j_node_qe_seq_fn__400000263_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_h_STAR___400000190_A struct{ j2g_header uint64; F_env, F_t, F_v any }

var A_arbace_c2j_node_qe_seq_h_STAR___400000190_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_tmp__400000230_A struct{ j2g_header uint64; F_n any }

var A_arbace_c2j_node_qe_seq_tmp__400000230_A_fn_class *jrt.Class



type A_arbace_c2j_node_qs_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qs_A_fn_class *jrt.Class



type A_arbace_c2j_node_qs_fn__400000060_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qs_fn__400000060_A_fn_class *jrt.Class



type A_arbace_c2j_node_realize_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_realize_A_fn_class *jrt.Class



type A_arbace_c2j_node_register_BANG__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_register_BANG__A_fn_class *jrt.Class



type A_arbace_c2j_node_register_BANG__fn__400000012_A struct{ j2g_header uint64; F_d any }

var A_arbace_c2j_node_register_BANG__fn__400000012_A_fn_class *jrt.Class



type A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A struct{ j2g_header uint64; F_d any }

var A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_fn_class *jrt.Class



type A_arbace_c2j_node_ret_chans_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_ret_chans_A_fn_class *jrt.Class



type A_arbace_c2j_node_runs_children_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_runs_children_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_node_splits_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_splits_A_fn_class *jrt.Class



type A_arbace_c2j_node_splits_fn__400000271_A struct{ j2g_header uint64; F_tested any }

var A_arbace_c2j_node_splits_fn__400000271_A_fn_class *jrt.Class



type A_arbace_c2j_node_splits_w__400000269_A struct{ j2g_header uint64; F_tested any }

var A_arbace_c2j_node_splits_w__400000269_A_fn_class *jrt.Class



type A_arbace_c2j_node_sym_occurs_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_node_sym_occurs_QMARK__fn__400000279_A struct{ j2g_header uint64; F_s any }

var A_arbace_c2j_node_sym_occurs_QMARK__fn__400000279_A_fn_class *jrt.Class



type A_arbace_c2j_node_tag_sym_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_tag_sym_A_fn_class *jrt.Class



type A_arbace_c2j_node_uses_many_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_uses_many_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_node_uses_many_QMARK__w__400000274_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_node_uses_many_QMARK__w__400000274_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_bare__400000306_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_bare__400000306_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000283_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_fn__400000283_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000299_A struct{ j2g_header uint64; F_conv, F_methods, F_v any }

var A_arbace_c2j_node_variant_class_fn__400000299_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000299_fn__400000301_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_fn__400000299_fn__400000301_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000299_fn__400000303_A struct{ j2g_header uint64; F_b, F_conv, F_fld any }

var A_arbace_c2j_node_variant_class_fn__400000299_fn__400000303_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000309_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_fn__400000309_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000314_A struct{ j2g_header uint64; F_bare any }

var A_arbace_c2j_node_variant_class_fn__400000314_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_method__400000286_A struct{ j2g_header uint64; F_d, F_env, F_v, F_domain any }

var A_arbace_c2j_node_variant_class_method__400000286_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_method__400000286_fn__400000293_A struct{ j2g_header uint64; F_c, F_try_qe, F_v any }

var A_arbace_c2j_node_variant_class_method__400000286_fn__400000293_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_method__400000286_try_qe__400000290_A struct{ j2g_header uint64; F_d, F_env any }

var A_arbace_c2j_node_variant_class_method__400000286_try_qe__400000290_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variants_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000320_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variants_fn__400000320_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_A struct{ j2g_header uint64; F_s any }

var A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_A struct{ j2g_header uint64; F_s__400000322, F_s, F_iter__400000321 any }

var A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_A struct{ j2g_header uint64; F_m, F_s any }

var A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_A struct{ j2g_header uint64; F_iter__400000323, F_s__400000324, F_m, F_s any }

var A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_fn__400000331_A struct{ j2g_header uint64; F_m, F_s, F_b__400000326 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_node_variants_fn__400000320_iter__400000321__400000327_fn__400000328_iter__400000323__400000329_fn__400000330_fn__400000331_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000338_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variants_fn__400000338_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000340__400000346_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variants_iter__400000340__400000346_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_A struct{ j2g_header uint64; F_s__400000341, F_iter__400000340 any }

var A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_A struct{ j2g_header uint64; F_k, F_p any }

var A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_A struct{ j2g_header uint64; F_s__400000343, F_k, F_p, F_iter__400000342 any }

var A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_fn__400000353_A struct{ j2g_header uint64; F_k, F_p, F_b__400000345 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_node_variants_iter__400000340__400000346_fn__400000347_iter__400000342__400000351_fn__400000352_fn__400000353_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000359__400000365_A struct{ j2g_header uint64; F_base, F_split_sets, F_dom, F_ss any }

var A_arbace_c2j_node_variants_iter__400000359__400000365_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_A struct{ j2g_header uint64; F_iter__400000359, F_base, F_split_sets, F_dom, F_ss, F_s__400000360 any }

var A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_A struct{ j2g_header uint64; F_base, F_dom, F_ss, F_c any }

var A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_A struct{ j2g_header uint64; F_base, F_dom, F_iter__400000361, F_ss, F_c, F_s__400000362 any }

var A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_A struct{ j2g_header uint64; F_b__400000364, F_base, F_dom any; F_size__1927001038__auto__ int32; F_ss, F_c__1927001037__auto__, F_c any }

var A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_fn__400000370_A struct{ j2g_header uint64; F_sp any }

var A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000369_fn__400000370_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000373_A struct{ j2g_header uint64; F_sp any }

var A_arbace_c2j_node_variants_iter__400000359__400000365_fn__400000366_iter__400000361__400000367_fn__400000368_fn__400000373_A_fn_class *jrt.Class



type A_arbace_c2j_node_walk_syms_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_walk_syms_A_fn_class *jrt.Class



type A_arbace_c2j_node_walk_syms_fn__400000033_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_node_walk_syms_fn__400000033_A_fn_class *jrt.Class



type A_arbace_c2j_node_walk_syms_fn__400000035_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_node_walk_syms_fn__400000035_A_fn_class *jrt.Class



type A_arbace_c2j_node_walk_syms_fn__400000038_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_node_walk_syms_fn__400000038_A_fn_class *jrt.Class
