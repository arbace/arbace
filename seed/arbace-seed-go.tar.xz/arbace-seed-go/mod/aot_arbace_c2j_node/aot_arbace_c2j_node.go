//line aot_arbace_c2j_node.ae:1
package aot_arbace_c2j_node

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A_New() *A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c2j_node_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_c2j_node_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c2j_node_eval400000008_fn__400000009_A_New() *A_arbace_c2j_node_eval400000008_fn__400000009_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_eval400000008_fn__400000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_node_eval400000008_fn__400000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_node_eval400000008_fn__400000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_c2j_node_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_c2j_node_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c2j_node_A_const_7.GetRawRoot__O(), A_arbace_c2j_node_A_const_8) }


















































func A_arbace_c2j_node_register_BANG__A_New() *A_arbace_c2j_node_register_BANG__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_register_BANG__A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_c2j_node_register_BANG__A) Ctor() {}
//line :52:1
func (t *A_arbace_c2j_node_register_BANG__A) Invoke_O_O__O(self, d__0 any) any {


	var root_19 any = A_arbace_c2j_node_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_c2j_node_A_const_10.GetRawRoot__O(); var arg_23 any; var tmp1 any = A_arbace_c2j_node_register_BANG__fn__400000012_A_New_O(d__0); var tmp2 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_c2j_node_register_BANG__fn__400000012_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_c2j_node_register_BANG__fn__400000012_A_fn_class = fncls__45d; tmp2 = fncls__45d } else { tmp2 = fncls__45 }; arg_23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_20 == nil { return ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { return linked_20.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_19, arg_22, arg_23) } }
//line :55:1
func A_arbace_c2j_node_register_BANG__fn__400000012_A_New_O(p0 any) *A_arbace_c2j_node_register_BANG__fn__400000012_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_register_BANG__fn__400000012_A{}; t.Ctor_O(p0); return t }
//line :55:1
func (t *A_arbace_c2j_node_register_BANG__fn__400000012_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :55:1
func (t *A_arbace_c2j_node_register_BANG__fn__400000012_A) Invoke_O_O__O(self, ds__1 any) any { var i__2 any; var root_24 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var root_28 any = A_arbace_c2j_node_A_const_12.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any; var tmp1 any = A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_New_O(t.F_d); var tmp2 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_fn_class = fncls__33d; tmp2 = fncls__33d } else { tmp2 = fncls__33 }; arg_31 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_32 any = ds__1; if linked_29 == nil { arg_27 = ifn_30.Invoke_O_O__O(arg_31, arg_32) } else { arg_27 = linked_29.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_28, arg_31, arg_32) }; if linked_25 == nil { i__2 = ifn_26.Invoke_O__O(arg_27) } else { i__2 = linked_25.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_24, arg_27) }; if
												jrt.J2g_Truth(i__2) { var root_34 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = ds__1; var arg_38 any = i__2; var arg_39 any = t.F_d; if linked_35 == nil { return ifn_36.Invoke_O_O_O__O(arg_37, arg_38, arg_39) } else { return linked_35.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_34, arg_37, arg_38, arg_39) } } else { var root_40 any = A_arbace_c2j_node_A_const_7.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = ds__1; var arg_44 any = t.F_d; if linked_41 == nil { return ifn_42.Invoke_O_O__O(arg_43, arg_44) } else { return linked_41.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_40, arg_43, arg_44) } } }
//line :55:1
func A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_New_O(p0 any) *A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A{}; t.Ctor_O(p0); return t }
//line :55:1
func (t *A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :55:1
func (t *A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_c2j_node_A_const_13.Invoke_O__O(x__2), A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d)) { return i__1 } else { return nil } }


func A_arbace_c2j_node_parse_A_New() *A_arbace_c2j_node_parse_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_parse_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_c2j_node_parse_A) Ctor() {}
//line :58:1
func (t *A_arbace_c2j_node_parse_A) Invoke_O_O_O_O_O_O__O(self, kind__0, doc__1, opts__2, bindings__3, template__4 any) any { var tmp1 any = A_arbace_c2j_node_A_const_13; var tmp2 any = A_arbace_c2j_node_A_const_15; var tmp3 any = A_arbace_c2j_node_A_const_16; var tmp4 any = A_arbace_c2j_node_A_const_17; var tmp5 any; var root_46 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_48 lang.IFn; if



	linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any; var tmp6 any = A_arbace_c2j_node_parse_fn__400000018_A_New(); var tmp7 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_c2j_node_parse_fn__400000018_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_c2j_node_parse_fn__400000018_A_fn_class = fncls__63d; tmp7 = fncls__63d } else { tmp7 = fncls__63 }; arg_49 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_50 any; var root_64 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = A_arbace_c2j_node_A_const_25; var arg_68 any = bindings__3; if linked_65 == nil { arg_50 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { arg_50 = linked_65.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_64, arg_67, arg_68) }; if linked_47 == nil { tmp5 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { tmp5 = linked_47.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }; return /*line :58:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, kind__0, tmp2, doc__1, tmp3, opts__2, tmp4, tmp5, A_arbace_c2j_node_A_const_26, template__4)) }



func A_arbace_c2j_node_parse_fn__400000018_A_New() *A_arbace_c2j_node_parse_fn__400000018_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_parse_fn__400000018_A{}; t.Ctor(); return t }
//line :62:1
func (t *A_arbace_c2j_node_parse_fn__400000018_A) Ctor() {}
//line :62:1
func (t *A_arbace_c2j_node_parse_fn__400000018_A) Invoke_O_O__O(self, p__400000017__1 any) any { var vec__400000019__2 any = p__400000017__1; var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000019__2, lang.RT_IntCast_J__I_NoInit(0), nil); var spec__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000019__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any = A_arbace_c2j_node_A_const_19; var tmp2 any = A_arbace_c2j_node_A_const_20; var tmp3 any; var root_51 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = spec__4; if linked_52 == nil { tmp3 = ifn_53.Invoke_O__O(arg_54) } else { tmp3 = linked_52.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_51, arg_54) }; var tmp4 any = tmp3; var tmp5 any = A_arbace_c2j_node_A_const_21; var tmp6 any; var root_55 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any; var root_59 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = spec__4; if linked_60 == nil { arg_58 = ifn_61.Invoke_O__O(arg_62) } else { arg_58 = linked_60.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_59, arg_62) }; if linked_56 == nil { tmp6 = ifn_57.Invoke_O__O(arg_58) } else { tmp6 = linked_56.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_55, arg_58) }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, s__3, tmp2, tmp4, tmp5, tmp6)) }


func A_arbace_c2j_node_field_names_A_New() *A_arbace_c2j_node_field_names_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_field_names_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_c2j_node_field_names_A) Ctor() {}
//line :65:1
func (t *A_arbace_c2j_node_field_names_A) Invoke_O_O__O(self, d__0 any) any {


	var root_69 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var root_73 any = A_arbace_c2j_node_A_const_27.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any; var root_77 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any; var root_82 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any; var tmp1 any = A_arbace_c2j_node_field_names_fn__400000024_A_New(); var tmp2 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_c2j_node_field_names_fn__400000024_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_c2j_node_field_names_fn__400000024_A_fn_class = fncls__91d; tmp2 = fncls__91d } else { tmp2 = fncls__91 }; arg_85 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_86 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_83 == nil { arg_80 = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { arg_80 = linked_83.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_82, arg_85, arg_86) }; var tmp3 *lang.Keyword = A_arbace_c2j_node_A_const_31; var arg_81 any = tmp3.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0)); if linked_78 == nil { arg_76 = ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { arg_76 = linked_78.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_77, arg_80, arg_81) }; if linked_74 == nil { arg_72 = ifn_75.Invoke_O__O(arg_76) } else { arg_72 = linked_74.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_73, arg_76) }; if linked_70 == nil { return ifn_71.Invoke_O__O(arg_72) } else { return linked_70.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_69, arg_72) } }
//line :68:1
func A_arbace_c2j_node_field_names_fn__400000024_A_New() *A_arbace_c2j_node_field_names_fn__400000024_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_field_names_fn__400000024_A{}; t.Ctor(); return t }
//line :68:1
func (t *A_arbace_c2j_node_field_names_fn__400000024_A) Ctor() {}
//line :68:1
func (t *A_arbace_c2j_node_field_names_fn__400000024_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_30); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_c2j_node_A_const_20.Invoke_O__O(b__1))) { var root_87 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_88 == nil { return ifn_89.Invoke_O__O(arg_90) } else { return linked_88.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_87, arg_90) } } else { return nil } }


func A_arbace_c2j_node_children_bind_A_New() *A_arbace_c2j_node_children_bind_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_children_bind_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_c2j_node_children_bind_A) Ctor() {}
//line :71:1
func (t *A_arbace_c2j_node_children_bind_A) Invoke_O_O__O(self, d__0 any) any { var root_92 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any; var root_96 any = A_arbace_c2j_node_A_const_32.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any; var tmp1 any = A_arbace_c2j_node_children_bind_fn__400000028_A_New(); var tmp2 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_c2j_node_children_bind_fn__400000028_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_c2j_node_children_bind_fn__400000028_A_fn_class = fncls__101d; tmp2 = fncls__101d } else { tmp2 = fncls__101 }; arg_99 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_100 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_97 == nil { arg_95 = ifn_98.Invoke_O_O__O(arg_99, arg_100) } else { arg_95 = linked_97.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_96, arg_99, arg_100) }; if linked_93 == nil { return ifn_94.Invoke_O__O(arg_95) } else { return linked_93.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_92, arg_95) } }
//line :71:1
func A_arbace_c2j_node_children_bind_fn__400000028_A_New() *A_arbace_c2j_node_children_bind_fn__400000028_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_children_bind_fn__400000028_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_c2j_node_children_bind_fn__400000028_A) Ctor() {}
//line :71:1
func (t *A_arbace_c2j_node_children_bind_fn__400000028_A) Invoke_O_O__O(self, p1__400000027_SHARP___1 any) any { var tmp1 any = A_arbace_c2j_node_A_const_33; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_c2j_node_A_const_20.Invoke_O__O(p1__400000027_SHARP___1))).Ref() }

func A_arbace_c2j_node_walk_syms_A_New() *A_arbace_c2j_node_walk_syms_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_walk_syms_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_c2j_node_walk_syms_A) Ctor() {}
//line :73:1
func (t *A_arbace_c2j_node_walk_syms_A) Invoke_O_O_O__O(self, r__0, f__1 any) any {


	var tmp1 any; var root_102 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_104 lang.IFn
	if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = f__1; if linked_103 == nil { tmp1 = ifn_104.Invoke_O__O(arg_105) } else { tmp1 = linked_103.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_102, arg_105) }
//line :76:1
	if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_106 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = r__0; var arg_110 any = f__1; if linked_107 == nil { tmp2 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { tmp2 = linked_107.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_106, arg_109, arg_110) }; if jrt.J2g_Truth(tmp2) { return lang.IFn_Cast(r__0).Invoke_O__O(f__1) } else { return f__1 } } else {
//line :76:1
			var tmp3 any; var root_111 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_113 lang.IFn

			if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = f__1; if linked_112 == nil { tmp3 = ifn_113.Invoke_O__O(arg_114) } else { tmp3 = linked_112.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_111, arg_114) }
//line :76:1
			if jrt.J2g_Truth(tmp3) {

				var root_115 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any; var root_120 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = A_arbace_c2j_node_A_const_39.GetRawRoot__O(); var arg_124 any; var root_125 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any; var tmp4 any = A_arbace_c2j_node_walk_syms_fn__400000033_A_New_O(r__0); var tmp5 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_c2j_node_walk_syms_fn__400000033_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_c2j_node_walk_syms_fn__400000033_A_fn_class = fncls__135d; tmp5 = fncls__135d } else { tmp5 = fncls__135 }; arg_128 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_129 any = f__1; if linked_126 == nil { arg_124 = ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { arg_124 = linked_126.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_125, arg_128, arg_129) }; if linked_121 == nil { arg_118 = ifn_122.Invoke_O_O__O(arg_123, arg_124) } else { arg_118 = linked_121.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_120, arg_123, arg_124) }; var arg_119 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); if linked_116 == nil { return ifn_117.Invoke_O_O__O(arg_118, arg_119) } else { return linked_116.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_115, arg_118, arg_119) } } else {
//line :76:1
					var tmp6 any; var root_136 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_138 lang.IFn


					if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = f__1; if linked_137 == nil { tmp6 = ifn_138.Invoke_O__O(arg_139) } else { tmp6 = linked_137.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_136, arg_139) }
//line :76:1
					if jrt.J2g_Truth(tmp6) {


						var root_140 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any; var root_145 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_146 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_145, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_147 lang.IFn; if linked_146 == nil { ifn_147 = lang.IFn_Cast(root_145) } else { ifn_147 = nil }; var arg_148 any; var tmp7 any = A_arbace_c2j_node_walk_syms_fn__400000035_A_New_O(r__0); var tmp8 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_c2j_node_walk_syms_fn__400000035_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_c2j_node_walk_syms_fn__400000035_A_fn_class = fncls__155d; tmp8 = fncls__155d } else { tmp8 = fncls__155 }; arg_148 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_149 any = f__1; if linked_146 == nil { arg_143 = ifn_147.Invoke_O_O__O(arg_148, arg_149) } else { arg_143 = linked_146.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_145, arg_148, arg_149) }; var arg_144 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); if linked_141 == nil { return ifn_142.Invoke_O_O__O(arg_143, arg_144) } else { return linked_141.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_140, arg_143, arg_144) } } else {
//line :76:1
							var tmp9 any; var root_156 any = A_arbace_c2j_node_A_const_43.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_158 lang.IFn



							if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = f__1; if linked_157 == nil { tmp9 = ifn_158.Invoke_O__O(arg_159) } else { tmp9 = linked_157.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_156, arg_159) }
//line :76:1
							if jrt.J2g_Truth(tmp9) {



								var root_160 any = A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_164 any; var root_165 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any; var tmp10 any = A_arbace_c2j_node_walk_syms_fn__400000038_A_New_O(r__0); var tmp11 *jrt.Class; var fncls__180 *jrt.Class = A_arbace_c2j_node_walk_syms_fn__400000038_A_fn_class; if fncls__180 == nil { var fncls__180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_c2j_node_walk_syms_fn__400000038_A_fn_class = fncls__180d; tmp11 = fncls__180d } else { tmp11 = fncls__180 }; arg_168 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_169 any = f__1; if linked_166 == nil { arg_164 = ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { arg_164 = linked_166.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_165, arg_168, arg_169) }; if linked_161 == nil { return ifn_162.Invoke_O_O__O(arg_163, arg_164) } else { return linked_161.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_160, arg_163, arg_164) } } else {
//line :76:1
									if A_arbace_c2j_node_A_const_45 != nil { return f__1 } else { return nil
									} } } } } }
func A_arbace_c2j_node_walk_syms_fn__400000033_A_New_O(p0 any) *A_arbace_c2j_node_walk_syms_fn__400000033_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_walk_syms_fn__400000033_A{}; t.Ctor_O(p0); return t }
//line :78:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000033_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :78:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000033_A) Invoke_O_O__O(self, p1__400000031_SHARP___1 any) any { var root_130 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = t.F_r; var arg_134 any = p1__400000031_SHARP___1; if linked_131 == nil { return ifn_132.Invoke_O_O__O(arg_133, arg_134) } else { return linked_131.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_130, arg_133, arg_134) } }
func A_arbace_c2j_node_walk_syms_fn__400000035_A_New_O(p0 any) *A_arbace_c2j_node_walk_syms_fn__400000035_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_walk_syms_fn__400000035_A{}; t.Ctor_O(p0); return t }
//line :79:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000035_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :79:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000035_A) Invoke_O_O__O(self, p1__400000032_SHARP___1 any) any { var root_150 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = t.F_r; var arg_154 any = p1__400000032_SHARP___1; if linked_151 == nil { return ifn_152.Invoke_O_O__O(arg_153, arg_154) } else { return linked_151.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_150, arg_153, arg_154) } }
func A_arbace_c2j_node_walk_syms_fn__400000038_A_New_O(p0 any) *A_arbace_c2j_node_walk_syms_fn__400000038_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_walk_syms_fn__400000038_A{}; t.Ctor_O(p0); return t }
//line :80:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000038_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :80:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000038_A) Invoke_O_O__O(self, p__400000037__1 any) any { var vec__400000039__2 any = p__400000037__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000039__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000039__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_170 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = t.F_r; var arg_174 any = k__3; if linked_171 == nil { tmp1 = ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { tmp1 = linked_171.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_170, arg_173, arg_174) }; var tmp2 any = tmp1; var tmp3 any; var root_175 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = t.F_r; var arg_179 any = v__4; if linked_176 == nil { tmp3 = ifn_177.Invoke_O_O__O(arg_178, arg_179) } else { tmp3 = linked_176.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_175, arg_178, arg_179) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }


func A_arbace_c2j_node_head_A_New() *A_arbace_c2j_node_head_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_head_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_c2j_node_head_A) Ctor() {}
//line :83:1
func (t *A_arbace_c2j_node_head_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_181 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = f__0; if linked_182 == nil { and__1927000168__auto____2 = ifn_183.Invoke_O__O(arg_184) } else { and__1927000168__auto____2 = linked_182.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_181, arg_184) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_185 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any; var root_189 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = f__0; if linked_190 == nil { arg_188 = ifn_191.Invoke_O__O(arg_192) } else { arg_188 = linked_190.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_189, arg_192) }; if linked_186 == nil { tmp1 = ifn_187.Invoke_O__O(arg_188) } else { tmp1 = linked_186.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_185, arg_188) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_193 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = f__0; if linked_194 == nil { return ifn_195.Invoke_O__O(arg_196) } else { return linked_194.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_193, arg_196) } } else { return nil } }

func A_arbace_c2j_node_runs_children_QMARK__A_New() *A_arbace_c2j_node_runs_children_QMARK__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_runs_children_QMARK__A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_c2j_node_runs_children_QMARK__A) Ctor() {}
//line :85:1
func (t *A_arbace_c2j_node_runs_children_QMARK__A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_197 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_199 lang.IFn
	if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = t__0; if linked_198 == nil { tmp1 = ifn_199.Invoke_O__O(arg_200) } else { tmp1 = linked_198.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_197, arg_200) }
//line :88:1
	if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any; var root_201 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_203 lang.IFn
		if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = A_arbace_c2j_node_A_const_46; var arg_205 any; var root_206 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, A_arbace_c2j_node_head_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = t__0; if linked_207 == nil { arg_205 = ifn_208.Invoke_O__O(arg_209) } else { arg_205 = linked_207.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_206, arg_209) }; if linked_202 == nil { or__1927000174__auto____2 = ifn_203.Invoke_O_O__O(arg_204, arg_205) } else { or__1927000174__auto____2 = linked_202.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_201, arg_204, arg_205) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_210 any = A_arbace_c2j_node_A_const_48.GetRawRoot__O(); var linked_211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_210, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_212 lang.IFn; if linked_211 == nil { ifn_212 = lang.IFn_Cast(root_210) } else { ifn_212 = nil }; var arg_213 any = A_arbace_c2j_node_A_const_49.GetRawRoot__O(); var arg_214 any = t__0; if linked_211 == nil { return ifn_212.Invoke_O_O__O(arg_213, arg_214) } else { return linked_211.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_210, arg_213, arg_214) } } } else {
//line :88:1
			var tmp2 any; var root_215 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_217 lang.IFn

			if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = t__0; if linked_216 == nil { tmp2 = ifn_217.Invoke_O__O(arg_218) } else { tmp2 = linked_216.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_215, arg_218) }
//line :88:1
			if jrt.J2g_Truth(tmp2) {

				var root_219 any = A_arbace_c2j_node_A_const_48.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = A_arbace_c2j_node_A_const_49.GetRawRoot__O(); var arg_223 any = t__0; if linked_220 == nil { return ifn_221.Invoke_O_O__O(arg_222, arg_223) } else { return linked_220.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_219, arg_222, arg_223) } } else {
//line :88:1
					if A_arbace_c2j_node_A_const_45 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
					}
				}
		}
}










func A_arbace_c2j_node_q_elems_A_New() *A_arbace_c2j_node_q_elems_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_elems_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_c2j_node_q_elems_A) Ctor() {}
//line :103:1
func (t *A_arbace_c2j_node_q_elems_A) Invoke_O_O_O__O(self, env__0, xs__1 any) any { var lst__3 any; var root_224 any = A_arbace_c2j_node_A_const_50.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_226 lang.IFn; if



	linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = xs__1; if linked_225 == nil { lst__3 = ifn_226.Invoke_O__O(arg_227) } else { lst__3 = linked_225.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_224, arg_227) }; var tmp1 any; var and__1927000168__auto____4 any; var root_228 any =
	A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = lst__3; if linked_229 == nil { and__1927000168__auto____4 = ifn_230.Invoke_O__O(arg_231) } else { and__1927000168__auto____4 = linked_229.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_228, arg_231) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any = A_arbace_c2j_node_A_const_51; var tmp3 any; var root_232 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, A_arbace_c2j_node_head_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = lst__3; if linked_233 == nil { tmp3 = ifn_234.Invoke_O__O(arg_235) } else { tmp3 = linked_233.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_232, arg_235) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { var b__4 any; var tmp4 lang.IFn = lang.IFn_Cast(env__0); var tmp5 any; var root_236 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_238 lang.IFn
		if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = lst__3; if linked_237 == nil { tmp5 = ifn_238.Invoke_O__O(arg_239) } else { tmp5 = linked_237.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_236, arg_239) }; b__4 = tmp4.Invoke_O__O(tmp5)
//line :108:1
		var tmp6 any; var root_240 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_242 lang.IFn

		if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any; var tmp7 any = A_arbace_c2j_node_q_elems_fn__400000048_A_New_O(env__0); var tmp8 *jrt.Class; var fncls__250 *jrt.Class = A_arbace_c2j_node_q_elems_fn__400000048_A_fn_class; if fncls__250 == nil { var fncls__250d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_c2j_node_q_elems_fn__400000048_A_fn_class = fncls__250d; tmp8 = fncls__250d } else { tmp8 = fncls__250 }; arg_243 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_244 any; var root_251 any = A_arbace_c2j_node_A_const_54.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = xs__1; if linked_252 == nil { arg_244 = ifn_253.Invoke_O__O(arg_254) } else { arg_244 = linked_252.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_251, arg_254) }; if linked_241 == nil { tmp6 = ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { tmp6 = linked_241.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_240, arg_243, arg_244) }
//line :108:1
		var tmp9 any = tmp6; var tmp10 any; var G__400000050__5_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__4)


	L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__400000050__5_) { case 177445645: if any(G__400000050__5_) == any(A_arbace_c2j_node_A_const_55) {
		var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_node_A_const_57; tmp10 = tmp11.Invoke_O_O__O(tmp12, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4))
//line :111:1
		break L1 }; default:
	}
		tmp10 = A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4)}
//line :108:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10) } else { var tmp13 any; var root_256 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_258 lang.IFn





			if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any; var tmp14 any = A_arbace_c2j_node_q_elems_fn__400000051_A_New_O(env__0); var tmp15 *jrt.Class; var fncls__266 *jrt.Class = A_arbace_c2j_node_q_elems_fn__400000051_A_fn_class; if fncls__266 == nil { var fncls__266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_56, false); A_arbace_c2j_node_q_elems_fn__400000051_A_fn_class = fncls__266d; tmp15 = fncls__266d } else { tmp15 = fncls__266 }; arg_259 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var arg_260 any = xs__1; if linked_257 == nil { tmp13 = ifn_258.Invoke_O_O__O(arg_259, arg_260) } else { tmp13 = linked_257.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_256, arg_259, arg_260) }
//line :108:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp13, nil) } }

func A_arbace_c2j_node_q_elems_fn__400000048_A_New_O(p0 any) *A_arbace_c2j_node_q_elems_fn__400000048_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_elems_fn__400000048_A{}; t.Ctor_O(p0); return t }
//line :110:1
func (t *A_arbace_c2j_node_q_elems_fn__400000048_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :110:1
func (t *A_arbace_c2j_node_q_elems_fn__400000048_A) Invoke_O_O__O(self, p1__400000046_SHARP___1 any) any { var root_245 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, A_arbace_c2j_node_q_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = t.F_env; var arg_249 any = p1__400000046_SHARP___1; if linked_246 == nil { return ifn_247.Invoke_O_O__O(arg_248, arg_249) } else { return linked_246.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_245, arg_248, arg_249) } }



func A_arbace_c2j_node_q_elems_fn__400000051_A_New_O(p0 any) *A_arbace_c2j_node_q_elems_fn__400000051_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_elems_fn__400000051_A{}; t.Ctor_O(p0); return t }
//line :114:1
func (t *A_arbace_c2j_node_q_elems_fn__400000051_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :114:1
func (t *A_arbace_c2j_node_q_elems_fn__400000051_A) Invoke_O_O__O(self, p1__400000047_SHARP___1 any) any { var root_261 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, A_arbace_c2j_node_q_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = t.F_env; var arg_265 any = p1__400000047_SHARP___1; if linked_262 == nil { return ifn_263.Invoke_O_O__O(arg_264, arg_265) } else { return linked_262.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_261, arg_264, arg_265) } }

func A_arbace_c2j_node_q_drop_QMARK__A_New() *A_arbace_c2j_node_q_drop_QMARK__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_drop_QMARK__A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_c2j_node_q_drop_QMARK__A) Ctor() {}
//line :116:1
func (t *A_arbace_c2j_node_q_drop_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(x__0, A_arbace_c2j_node_A_const_58)).Ref() }

func A_arbace_c2j_node_q_body_A_New() *A_arbace_c2j_node_q_body_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_body_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_c2j_node_q_body_A) Ctor() {}
//line :118:1
func (t *A_arbace_c2j_node_q_body_A) Invoke_O_O_O__O(self, env__0, bs__1 any) any { var cs__3 any; var root_267 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_269 lang.IFn; if


	linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = A_arbace_c2j_node_A_const_60.GetRawRoot__O(); var arg_271 any; var root_272 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any; var tmp1 any = A_arbace_c2j_node_q_body_fn__400000056_A_New_O(env__0); var tmp2 *jrt.Class; var fncls__282 *jrt.Class = A_arbace_c2j_node_q_body_fn__400000056_A_fn_class; if fncls__282 == nil { var fncls__282d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_c2j_node_q_body_fn__400000056_A_fn_class = fncls__282d; tmp2 = fncls__282d } else { tmp2 = fncls__282 }; arg_275 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_276 any = bs__1; if linked_273 == nil { arg_271 = ifn_274.Invoke_O_O__O(arg_275, arg_276) } else { arg_271 = linked_273.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_272, arg_275, arg_276) }; if linked_268 == nil { cs__3 = ifn_269.Invoke_O_O__O(arg_270, arg_271) } else { cs__3 = linked_268.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_267, arg_270, arg_271) }; var tmp3 any; var root_283 any =
	A_arbace_c2j_node_A_const_61.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_285 lang.IFn; if
	linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = cs__3; if linked_284 == nil { tmp3 = ifn_285.Invoke_O__O(arg_286) } else { tmp3 = linked_284.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_283, arg_286) }; if /*line :122:1*/ jrt.J2g_Truth(tmp3) { return nil } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(cs__3))) {

		var root_287 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = cs__3; if linked_288 == nil { return ifn_289.Invoke_O__O(arg_290) } else { return linked_288.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_287, arg_290) } } else {
//line :122:1
			if A_arbace_c2j_node_A_const_45 != nil {


				var root_291 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = A_arbace_c2j_node_A_const_63; var arg_295 any = A_arbace_c2j_node_A_const_64; var arg_296 any = cs__3; if linked_292 == nil { return ifn_293.Invoke_O_O_O__O(arg_294, arg_295, arg_296) } else { return linked_292.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_291, arg_294, arg_295, arg_296) } } else {
//line :122:1
					return nil } } } }
//line :121:1
func A_arbace_c2j_node_q_body_fn__400000056_A_New_O(p0 any) *A_arbace_c2j_node_q_body_fn__400000056_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_body_fn__400000056_A{}; t.Ctor_O(p0); return t }
//line :121:1
func (t *A_arbace_c2j_node_q_body_fn__400000056_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :121:1
func (t *A_arbace_c2j_node_q_body_fn__400000056_A) Invoke_O_O__O(self, p1__400000055_SHARP___1 any) any { var root_277 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, A_arbace_c2j_node_q_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = t.F_env; var arg_281 any = p1__400000055_SHARP___1; if linked_278 == nil { return ifn_279.Invoke_O_O__O(arg_280, arg_281) } else { return linked_278.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_277, arg_280, arg_281) } }





func A_arbace_c2j_node_qs_A_New() *A_arbace_c2j_node_qs_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qs_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_c2j_node_qs_A) Ctor() {}
//line :127:1
func (t *A_arbace_c2j_node_qs_A) Invoke_O_O_O__O(self, env__0, f__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(f__1, A_arbace_c2j_node_A_const_65) {
		var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_56; return tmp1.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(A_arbace_c2j_node_A_const_69)) } else {
//line :130:1
			var tmp2 any; var and__1927000168__auto____3 any; var root_297 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_299 lang.IFn

			if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = f__1; if linked_298 == nil { and__1927000168__auto____3 = ifn_299.Invoke_O__O(arg_300) } else { and__1927000168__auto____3 = linked_298.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_297, arg_300) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_c2j_node_A_const_66; var tmp4 any; var root_301 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_301, A_arbace_c2j_node_head_A_fn_class); var ifn_303 lang.IFn; if linked_302 == nil { ifn_303 = lang.IFn_Cast(root_301) } else { ifn_303 = nil }; var arg_304 any = f__1; if linked_302 == nil { tmp4 = ifn_303.Invoke_O__O(arg_304) } else { tmp4 = linked_302.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_301, arg_304) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :130:1
			if jrt.J2g_Truth(tmp2) {

				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_node_A_const_70; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_node_A_const_72; var tmp9 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp10 lang.IFn = lang.IFn_Cast(env__0); var tmp11 any; var root_333 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = f__1; if linked_334 == nil { tmp11 = ifn_335.Invoke_O__O(arg_336) } else { tmp11 = linked_334.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_333, arg_336) }; var tmp12 any = tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O__O(tmp10.Invoke_O__O(tmp11))); var tmp13 *lang.Keyword = A_arbace_c2j_node_A_const_71; var tmp14 lang.IFn = lang.IFn_Cast(env__0); var tmp15 any; var root_337 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = f__1; if linked_338 == nil { tmp15 = ifn_339.Invoke_O__O(arg_340) } else { tmp15 = linked_338.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_337, arg_340) }; return tmp5.Invoke_O_O_O__O(tmp6, tmp12, tmp13.Invoke_O__O(tmp14.Invoke_O__O(tmp15))) } else {
//line :130:1
					var tmp16 any; var and__1927000168__auto____3_2 any; var root_305 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_307 lang.IFn


					if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any = f__1; if linked_306 == nil { and__1927000168__auto____3_2 = ifn_307.Invoke_O__O(arg_308) } else { and__1927000168__auto____3_2 = linked_306.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_305, arg_308) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var tmp17 any = A_arbace_c2j_node_A_const_67; var tmp18 any; var root_309 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, A_arbace_c2j_node_head_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = f__1; if linked_310 == nil { tmp18 = ifn_311.Invoke_O__O(arg_312) } else { tmp18 = linked_310.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_309, arg_312) }; tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp17, tmp18)).Ref() } else { tmp16 = and__1927000168__auto____3_2 }
//line :130:1
					if jrt.J2g_Truth(tmp16) {


						var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp20 any = A_arbace_c2j_node_A_const_73; var tmp21 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp22 lang.IFn = lang.IFn_Cast(env__0); var tmp23 any; var root_341 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = f__1; if linked_342 == nil { tmp23 = ifn_343.Invoke_O__O(arg_344) } else { tmp23 = linked_342.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_341, arg_344) }; return tmp19.Invoke_O_O__O(tmp20, tmp21.Invoke_O__O(tmp22.Invoke_O__O(tmp23))) } else {
//line :130:1
							if A_arbace_c2j_node_A_const_45 != nil {



								var root_313 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any; var root_318 any = A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_318, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_320 lang.IFn; if linked_319 == nil { ifn_320 = lang.IFn_Cast(root_318) } else { ifn_320 = nil }; var arg_321 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_322 any; var root_324 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any; var tmp24 any = A_arbace_c2j_node_qs_fn__400000060_A_New(); var tmp25 *jrt.Class; var fncls__332 *jrt.Class = A_arbace_c2j_node_qs_fn__400000060_A_fn_class; if fncls__332 == nil { var fncls__332d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_c2j_node_qs_fn__400000060_A_fn_class = fncls__332d; tmp25 = fncls__332d } else { tmp25 = fncls__332 }; arg_327 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); if linked_325 == nil { arg_322 = ifn_326.Invoke_O__O(arg_327) } else { arg_322 = linked_325.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O__O(root_324, arg_327) }; var arg_323 any = env__0; if linked_319 == nil { arg_316 = ifn_320.Invoke_O_O_O__O(arg_321, arg_322, arg_323) } else { arg_316 = linked_319.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_318, arg_321, arg_322, arg_323) }; var arg_317 any = f__1; if linked_314 == nil { return ifn_315.Invoke_O_O__O(arg_316, arg_317) } else { return linked_314.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_313, arg_316, arg_317) } } else {
//line :130:1
									return nil
								}
						}
				} } }
func A_arbace_c2j_node_qs_fn__400000060_A_New() *A_arbace_c2j_node_qs_fn__400000060_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qs_fn__400000060_A{}; t.Ctor(); return t }
//line :134:1
func (t *A_arbace_c2j_node_qs_fn__400000060_A) Ctor() {}
//line :134:1
func (t *A_arbace_c2j_node_qs_fn__400000060_A) Invoke_O_O__O(self, p__400000059__1 any) any { var vec__400000061__2 any = p__400000059__1; var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000061__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000061__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var and__1927000168__auto____5 any; var root_328 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = s__3; if linked_329 == nil { and__1927000168__auto____5 = ifn_330.Invoke_O__O(arg_331) } else { and__1927000168__auto____5 = linked_329.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_328, arg_331) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_68); tmp1 = tmp2.Invoke_O__O(A_arbace_c2j_node_A_const_20.Invoke_O__O(b__4)) } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(s__3, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4)) } else { return nil } }

func A_arbace_c2j_node_q_seq_A_New() *A_arbace_c2j_node_q_seq_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_c2j_node_q_seq_A) Ctor() {}
//line :136:1
func (t *A_arbace_c2j_node_q_seq_A) Invoke_O_O_O__O(self, env__0, t__1 any) any { var vec__400000067__3 any = t__1; var seq__400000068__4 any; var root_345 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_347 lang.IFn; if
										linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = vec__400000067__3; if linked_346 == nil { seq__400000068__4 = ifn_347.Invoke_O__O(arg_348) } else { seq__400000068__4 = linked_346.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_345, arg_348) }; var first__400000069__5 any; var root_349 any = /*line :136:1*/A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_351 lang.IFn; if
										linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = seq__400000068__4; if linked_350 == nil { first__400000069__5 = ifn_351.Invoke_O__O(arg_352) } else { first__400000069__5 = linked_350.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_349, arg_352) }; var seq__400000068__6 any; var root_353 any = /*line :136:1*/A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_355 lang.IFn; if
										linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = seq__400000068__4; if linked_354 == nil { seq__400000068__6 = ifn_355.Invoke_O__O(arg_356) } else { seq__400000068__6 = linked_354.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_353, arg_356) }; var h__7 any = first__400000069__5; var as__8 any = seq__400000068__6; var G__400000070__9_ any = h__7; switch
										lang.Util_Hash_O__I_NoInit(G__400000070__9_) >> 2 & 63 { case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_76) { var vec__400000071__10 any = as__8; var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000071__10, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000071__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_85; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_node_A_const_86; var tmp5 any = A_arbace_c2j_node_A_const_87; var tmp6 *lang.Keyword = A_arbace_c2j_node_A_const_56; _ = ___11






		return tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O_O_O__O(tmp4, tmp5, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_88, A_arbace_c2j_node_A_const_89, A_arbace_c2j_node_A_const_90)), tmp6.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(xs__12))) }
//line :138:1
	case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_77) {


















		var root_358 any = A_arbace_c2j_node_A_const_78.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, A_arbace_c2j_node_q_body_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = env__0; var arg_362 any = as__8; if linked_359 == nil { return ifn_360.Invoke_O_O__O(arg_361, arg_362) } else { return linked_359.(*A_arbace_c2j_node_q_body_A).Invoke_O_O_O__O(root_358, arg_361, arg_362) } }
//line :138:1
	case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_79) { var vec__400000074__10 any = as__8; var s__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000074__10, lang.RT_IntCast_J__I_NoInit(0), nil); var b__12 any = lang.IFn_Cast(env__0).Invoke_O__O(s__11); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_node_A_const_91; var tmp9 any = A_arbace_c2j_node_A_const_92; var tmp10 any = A_arbace_c2j_node_A_const_93; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_node_A_const_94; var tmp13 any
		var tmp14 any = A_arbace_c2j_node_A_const_55






























		if lang.Util_Equiv_O_O__Z_NoInit(tmp14, A_arbace_c2j_node_A_const_20.Invoke_O__O(b__12)) { var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_node_A_const_95; tmp13 = tmp15.Invoke_O_O__O(tmp16, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__12)) } else { tmp13 = A_arbace_c2j_node_A_const_56.Invoke_O__O(b__12) }; return tmp7.Invoke_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11.Invoke_O_O__O(tmp12, tmp13)) }
//line :138:1
	case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_80) { var vec__400000077__10 any = as__8; var c__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000077__10, lang.RT_IntCast_J__I_NoInit(0), nil); var a__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000077__10, lang.RT_IntCast_J__I_NoInit(1), nil); var b__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000077__10, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp18 any = A_arbace_c2j_node_A_const_100; var tmp19 any; var root_417 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, A_arbace_c2j_node_qs_A_fn_class); var ifn_419 lang.IFn



















		if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = env__0; var arg_421 any = c__11; if linked_418 == nil { tmp19 = ifn_419.Invoke_O_O__O(arg_420, arg_421) } else { tmp19 = linked_418.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_417, arg_420, arg_421) }; var tmp20 any = tmp19; var tmp21 any; var root_422 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_422, A_arbace_c2j_node_q_A_fn_class); var ifn_424 lang.IFn; if linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = env__0; var arg_426 any = a__12; if linked_423 == nil { tmp21 = ifn_424.Invoke_O_O__O(arg_425, arg_426) } else { tmp21 = linked_423.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_422, arg_425, arg_426) }; var tmp22 any = tmp21; var tmp23 any; var root_427 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_427, A_arbace_c2j_node_q_A_fn_class); var ifn_429 lang.IFn; if linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = env__0; var arg_431 any = b__13; if linked_428 == nil { tmp23 = ifn_429.Invoke_O_O__O(arg_430, arg_431) } else { tmp23 = linked_428.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_427, arg_430, arg_431) }; return tmp17.Invoke_O_O_O_O__O(tmp18, tmp20, tmp22, tmp23) }
//line :138:1
	case 26: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_96) { var vec__400000080__10 any = as__8; var seq__400000081__11 any; var root_379 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_381 lang.IFn




















		if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = vec__400000080__10; if linked_380 == nil { seq__400000081__11 = ifn_381.Invoke_O__O(arg_382) } else { seq__400000081__11 = linked_380.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_379, arg_382) }
//line :138:1
		var first__400000082__12 any; var root_383 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_385 lang.IFn




















		if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = seq__400000081__11; if linked_384 == nil { first__400000082__12 = ifn_385.Invoke_O__O(arg_386) } else { first__400000082__12 = linked_384.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_383, arg_386) }
//line :138:1
		var seq__400000081__13 any; var root_387 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_389 lang.IFn




















		if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = seq__400000081__11; if linked_388 == nil { seq__400000081__13 = ifn_389.Invoke_O__O(arg_390) } else { seq__400000081__13 = linked_388.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_387, arg_390) }
//line :138:1
		var sel__14 any = first__400000082__12; var cls__15 any = seq__400000081__13; var root_391 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_393 lang.IFn





















		if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp25 any = A_arbace_c2j_node_A_const_97; var tmp26 any; var root_396 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, A_arbace_c2j_node_qs_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = env__0; var arg_400 any = sel__14; if linked_397 == nil { tmp26 = ifn_398.Invoke_O_O__O(arg_399, arg_400) } else { tmp26 = linked_397.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_396, arg_399, arg_400) }; arg_394 = tmp24.Invoke_O_O__O(tmp25, tmp26); var arg_395 any; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp28 any = A_arbace_c2j_node_q_seq_fn__400000084_A_New_O(env__0); var tmp29 *jrt.Class; var fncls__411 *jrt.Class = A_arbace_c2j_node_q_seq_fn__400000084_A_fn_class; if fncls__411 == nil { var fncls__411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_57, false); A_arbace_c2j_node_q_seq_fn__400000084_A_fn_class = fncls__411d; tmp29 = fncls__411d } else { tmp29 = fncls__411 }; var tmp30 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var tmp31 any; var root_412 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = A_arbace_c2j_node_A_const_25; var arg_416 any = cls__15; if linked_413 == nil { tmp31 = ifn_414.Invoke_O_O__O(arg_415, arg_416) } else { tmp31 = linked_413.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_412, arg_415, arg_416) }; arg_395 = tmp27.Invoke_O_O__O(tmp30, tmp31); if linked_392 == nil { return ifn_393.Invoke_O_O__O(arg_394, arg_395) } else { return linked_392.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_391, arg_394, arg_395) } }
//line :138:1
	case 27: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_101) { var vec__400000089__10 any = as__8; var at__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000089__10, lang.RT_IntCast_J__I_NoInit(0), nil); var x__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000089__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp33 any = A_arbace_c2j_node_A_const_103; var tmp34 any = A_arbace_c2j_node_A_const_104; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp36 any = A_arbace_c2j_node_A_const_105; var tmp37 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp38 any = tmp35.Invoke_O_O__O(tmp36, tmp37.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(at__11))); var tmp39 any; var root_432 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, A_arbace_c2j_node_q_A_fn_class); var ifn_434 lang.IFn

































		if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = env__0; var arg_436 any = x__12; if linked_433 == nil { tmp39 = ifn_434.Invoke_O_O__O(arg_435, arg_436) } else { tmp39 = linked_433.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_432, arg_435, arg_436) }; return tmp32.Invoke_O_O_O_O__O(tmp33, tmp34, tmp38, tmp39) }
//line :138:1
	case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_102) { var vec__400000092__10 any = as__8; var at__11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000092__10, lang.RT_IntCast_J__I_NoInit(0), nil); var ___12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000092__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp41 any = A_arbace_c2j_node_A_const_105; var tmp42 *lang.Keyword = A_arbace_c2j_node_A_const_56; _ = ___12
































		return tmp40.Invoke_O_O__O(tmp41, tmp42.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(at__11_2))) }
//line :138:1
	case 36: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_106) { var vec__400000095__10 any = as__8; var c__11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000095__10, lang.RT_IntCast_J__I_NoInit(0), nil); var x__12_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000095__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp43 *lang.Keyword = A_arbace_c2j_node_A_const_56; var xv__13 any = tmp43.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(x__12_2))
		var G__400000098__14_ any = c__11_2

		switch lang.Util_Hash_O__I_NoInit(G__400000098__14_) >> 8 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_107) {

			return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_112, A_arbace_c2j_node_A_const_113, xv__13) }
//line :141:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_108) {


			var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp45 any = A_arbace_c2j_node_A_const_114; var tmp46 any = A_arbace_c2j_node_A_const_115; return tmp44.Invoke_O_O_O_O__O(tmp45, tmp46, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_116, A_arbace_c2j_node_A_const_117, xv__13), lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_118, A_arbace_c2j_node_A_const_119, xv__13)) }
//line :141:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_109) {

			return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_112, A_arbace_c2j_node_A_const_113, xv__13) }
//line :141:1
		case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_110) {

			return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_112, A_arbace_c2j_node_A_const_113, xv__13) }
//line :141:1
		case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_120) {
			return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_121, A_arbace_c2j_node_A_const_122, xv__13) }
//line :141:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__400000098__14_))))) }
//line :138:1
	case 37: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_111) { var vec__400000099__10 any = as__8; var m__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000099__10, lang.RT_IntCast_J__I_NoInit(0), nil); var a__12_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000099__10, lang.RT_IntCast_J__I_NoInit(1), nil); var b__13_2 any = lang.IFn_Cast(env__0).Invoke_O__O(a__12_2); var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp48 any = A_arbace_c2j_node_A_const_124; var tmp49 any = A_arbace_c2j_node_A_const_125; var tmp50 any; var root_438 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_439 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_438, A_arbace_c2j_node_qs_A_fn_class); var ifn_440 lang.IFn




























		if linked_439 == nil { ifn_440 = lang.IFn_Cast(root_438) } else { ifn_440 = nil }; var arg_441 any = env__0; var arg_442 any = m__11; if linked_439 == nil { tmp50 = ifn_440.Invoke_O_O__O(arg_441, arg_442) } else { tmp50 = linked_439.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_438, arg_441, arg_442) }; return tmp47.Invoke_O_O_O_O_O__O(tmp48, tmp49, tmp50, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__13_2), A_arbace_c2j_node_A_const_126.Invoke_O__O(b__13_2)) }
//line :138:1
	case 45: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_123) { return A_arbace_c2j_node_A_const_58 }; case 54: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_127) { var vec__400000102__10 any = as__8; var seq__400000103__11 any; var root_443 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_443, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_445 lang.IFn









		if linked_444 == nil { ifn_445 = lang.IFn_Cast(root_443) } else { ifn_445 = nil }; var arg_446 any = vec__400000102__10; if linked_444 == nil { seq__400000103__11 = ifn_445.Invoke_O__O(arg_446) } else { seq__400000103__11 = linked_444.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_443, arg_446) }
//line :138:1
		var first__400000104__12 any; var root_447 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_449 lang.IFn









		if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = seq__400000103__11; if linked_448 == nil { first__400000104__12 = ifn_449.Invoke_O__O(arg_450) } else { first__400000104__12 = linked_448.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_447, arg_450) }
//line :138:1
		var seq__400000103__13 any; var root_451 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_453 lang.IFn









		if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = seq__400000103__11; if linked_452 == nil { seq__400000103__13 = ifn_453.Invoke_O__O(arg_454) } else { seq__400000103__13 = linked_452.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_451, arg_454) }
//line :138:1
		var ___14 any = first__400000104__12; var first__400000104__15 any; var root_455 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_455, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_457 lang.IFn; _ = ___14









		if linked_456 == nil { ifn_457 = lang.IFn_Cast(root_455) } else { ifn_457 = nil }; var arg_458 any = seq__400000103__13; if linked_456 == nil { first__400000104__15 = ifn_457.Invoke_O__O(arg_458) } else { first__400000104__15 = linked_456.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_455, arg_458) }
//line :138:1
		var seq__400000103__16 any; var root_459 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_459, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_461 lang.IFn









		if linked_460 == nil { ifn_461 = lang.IFn_Cast(root_459) } else { ifn_461 = nil }; var arg_462 any = seq__400000103__13; if linked_460 == nil { seq__400000103__16 = ifn_461.Invoke_O__O(arg_462) } else { seq__400000103__16 = linked_460.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_459, arg_462) }
//line :138:1
		var bv__17 any = first__400000104__15; var body__18 any = seq__400000103__16; var vec__400000105__19 any; var root_463 any = A_arbace_c2j_node_A_const_128.GetRawRoot__O(); var linked_464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_463, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_465 lang.IFn










		if linked_464 == nil { ifn_465 = lang.IFn_Cast(root_463) } else { ifn_465 = nil }; var arg_466 any; var tmp51 any = A_arbace_c2j_node_q_seq_fn__400000110_A_New(); var tmp52 *jrt.Class; var fncls__494 *jrt.Class = A_arbace_c2j_node_q_seq_fn__400000110_A_fn_class; if fncls__494 == nil { var fncls__494d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_c2j_node_q_seq_fn__400000110_A_fn_class = fncls__494d; tmp52 = fncls__494d } else { tmp52 = fncls__494 }; arg_466 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp51, tmp52, nil); var arg_467 any = lang.Tuple_Create_O_O__IPersistentVector(env__0, lang.PersistentVector_EMPTY.Ref()); var arg_468 any; var root_495 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_497 lang.IFn




		if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = A_arbace_c2j_node_A_const_25; var arg_499 any = bv__17; if linked_496 == nil { arg_468 = ifn_497.Invoke_O_O__O(arg_498, arg_499) } else { arg_468 = linked_496.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_495, arg_498, arg_499) }
//line :149:1
		if linked_464 == nil { vec__400000105__19 = ifn_465.Invoke_O_O_O__O(arg_466, arg_467, arg_468) } else { vec__400000105__19 = linked_464.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_463, arg_466, arg_467, arg_468) }
//line :138:1
		var env__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000105__19, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000105__19, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp54 any = A_arbace_c2j_node_A_const_133; var tmp55 any; var root_504 any = A_arbace_c2j_node_A_const_78.GetRawRoot__O(); var linked_505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_504, A_arbace_c2j_node_q_body_A_fn_class); var ifn_506 lang.IFn
















		if linked_505 == nil { ifn_506 = lang.IFn_Cast(root_504) } else { ifn_506 = nil }; var arg_507 any = env__20; var arg_508 any = body__18; if linked_505 == nil { tmp55 = ifn_506.Invoke_O_O__O(arg_507, arg_508) } else { tmp55 = linked_505.(*A_arbace_c2j_node_q_body_A).Invoke_O_O_O__O(root_504, arg_507, arg_508) }; return tmp53.Invoke_O_O_O__O(tmp54, binds__21, tmp55) }
//line :138:1
	case 56: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_132) { var vec__400000118__10 any = as__8; var c__11_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000118__10, lang.RT_IntCast_J__I_NoInit(0), nil); var m__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000118__10, lang.RT_IntCast_J__I_NoInit(1), nil); var f__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000118__10, lang.RT_IntCast_J__I_NoInit(2), nil); var fv__14 any; var root_500 any = A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_502 lang.IFn























		if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = Lit_59; if linked_501 == nil { fv__14 = ifn_502.Invoke_O__O(arg_503) } else { fv__14 = linked_501.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_500, arg_503) }
		var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp57 any = A_arbace_c2j_node_A_const_141; var tmp58 any; var root_573 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, A_arbace_c2j_node_q_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = env__0; var arg_577 any = f__13; if linked_574 == nil { tmp58 = ifn_575.Invoke_O_O__O(arg_576, arg_577) } else { tmp58 = linked_574.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_573, arg_576, arg_577) }; var tmp59 any = lang.Tuple_Create_O_O__IPersistentVector(fv__14, tmp58); var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp61 any = A_arbace_c2j_node_A_const_142; var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp63 any = A_arbace_c2j_node_A_const_143; var tmp64 any; var root_578 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, A_arbace_c2j_node_qs_A_fn_class); var ifn_580 lang.IFn
		if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = env__0; var arg_582 any = c__11_3; if linked_579 == nil { tmp64 = ifn_580.Invoke_O_O__O(arg_581, arg_582) } else { tmp64 = linked_579.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_578, arg_581, arg_582) }
//line :163:1
		var tmp65 any = tmp62.Invoke_O_O_O__O(tmp63, tmp64, A_arbace_c2j_node_A_const_120); var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp67 any = A_arbace_c2j_node_A_const_144; var tmp68 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp69 any = A_arbace_c2j_node_A_const_145; var tmp70 any; var root_583 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, A_arbace_c2j_node_qs_A_fn_class); var ifn_585 lang.IFn
		if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = env__0; var arg_587 any = m__12; if linked_584 == nil { tmp70 = ifn_585.Invoke_O_O__O(arg_586, arg_587) } else { tmp70 = linked_584.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_583, arg_586, arg_587) }
//line :163:1
		return tmp56.Invoke_O_O_O__O(tmp57, tmp59, tmp60.Invoke_O_O_O_O__O(tmp61, tmp65, tmp66.Invoke_O_O_O__O(tmp67, fv__14, tmp68.Invoke_O_O__O(tmp69, tmp70)), fv__14)) }
//line :138:1
	case 57: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_134) { var vec__400000121__10 any = as__8; var seq__400000122__11 any; var root_509 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_511 lang.IFn


































		if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = vec__400000121__10; if linked_510 == nil { seq__400000122__11 = ifn_511.Invoke_O__O(arg_512) } else { seq__400000122__11 = linked_510.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_509, arg_512) }
//line :138:1
		var first__400000123__12 any; var root_513 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_515 lang.IFn


































		if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any = seq__400000122__11; if linked_514 == nil { first__400000123__12 = ifn_515.Invoke_O__O(arg_516) } else { first__400000123__12 = linked_514.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_513, arg_516) }
//line :138:1
		var seq__400000122__13 any; var root_517 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_519 lang.IFn


































		if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any = seq__400000122__11; if linked_518 == nil { seq__400000122__13 = ifn_519.Invoke_O__O(arg_520) } else { seq__400000122__13 = linked_518.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_517, arg_520) }
//line :138:1
		var bv__14 any = first__400000123__12; var body__15 any = seq__400000122__13; var fresh__16 any; var root_521 any = A_arbace_c2j_node_A_const_49.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_521, A_arbace_c2j_node_runs_children_QMARK__A_fn_class); var ifn_523 lang.IFn



































		if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any; var root_525 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_527 lang.IFn; if linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any = A_arbace_c2j_node_A_const_135; var arg_529 any = body__15; if linked_526 == nil { arg_524 = ifn_527.Invoke_O_O__O(arg_528, arg_529) } else { arg_524 = linked_526.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_525, arg_528, arg_529) }; if linked_522 == nil { fresh__16 = ifn_523.Invoke_O__O(arg_524) } else { fresh__16 = linked_522.(*A_arbace_c2j_node_runs_children_QMARK__A).Invoke_O_O__O(root_521, arg_524) }
//line :138:1
		var vec__400000124__17 any; var root_530 any = A_arbace_c2j_node_A_const_128.GetRawRoot__O(); var linked_531 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_530, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_532 lang.IFn




































		if linked_531 == nil { ifn_532 = lang.IFn_Cast(root_530) } else { ifn_532 = nil }; var arg_533 any; var tmp71 any = A_arbace_c2j_node_q_seq_fn__400000129_A_New_O(fresh__16); var tmp72 *jrt.Class; var fncls__567 *jrt.Class = A_arbace_c2j_node_q_seq_fn__400000129_A_fn_class; if fncls__567 == nil { var fncls__567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_60, false); A_arbace_c2j_node_q_seq_fn__400000129_A_fn_class = fncls__567d; tmp72 = fncls__567d } else { tmp72 = fncls__567 }; arg_533 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp71, tmp72, nil); var arg_534 any = lang.Tuple_Create_O_O_O__IPersistentVector(env__0, lang.PersistentVector_EMPTY.Ref(), lang.PersistentVector_EMPTY.Ref()); var arg_535 any; var root_568 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_570 lang.IFn




		if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = A_arbace_c2j_node_A_const_25; var arg_572 any = bv__14; if linked_569 == nil { arg_535 = ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { arg_535 = linked_569.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_568, arg_571, arg_572) }
//line :175:1
		if linked_531 == nil { vec__400000124__17 = ifn_532.Invoke_O_O_O__O(arg_533, arg_534, arg_535) } else { vec__400000124__17 = linked_531.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_530, arg_533, arg_534, arg_535) }
//line :138:1
		var env__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000124__17, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000124__17, lang.RT_IntCast_J__I_NoInit(1), nil); var lets__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000124__17, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp74 any = A_arbace_c2j_node_A_const_147; var tmp75 any; var root_588 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_590 lang.IFn










































		if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = A_arbace_c2j_node_A_const_148; var arg_592 any = A_arbace_c2j_node_A_const_149; var arg_593 any; var root_595 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = A_arbace_c2j_node_A_const_150; var arg_599 any = lets__20; if linked_596 == nil { arg_593 = ifn_597.Invoke_O_O__O(arg_598, arg_599) } else { arg_593 = linked_596.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O__O(root_595, arg_598, arg_599) }; var arg_594 any; var root_600 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = A_arbace_c2j_node_A_const_60.GetRawRoot__O(); var arg_604 any; var root_605 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any; var tmp76 any = A_arbace_c2j_node_q_seq_fn__400000137_A_New_O(env__18); var tmp77 *jrt.Class; var fncls__615 *jrt.Class = A_arbace_c2j_node_q_seq_fn__400000137_A_fn_class; if fncls__615 == nil { var fncls__615d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_61, false); A_arbace_c2j_node_q_seq_fn__400000137_A_fn_class = fncls__615d; tmp77 = fncls__615d } else { tmp77 = fncls__615 }; arg_608 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp76, tmp77, nil); var arg_609 any = body__15; if linked_606 == nil { arg_604 = ifn_607.Invoke_O_O__O(arg_608, arg_609) } else { arg_604 = linked_606.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_605, arg_608, arg_609) }; if linked_601 == nil { arg_594 = ifn_602.Invoke_O_O__O(arg_603, arg_604) } else { arg_594 = linked_601.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_600, arg_603, arg_604) }; if linked_589 == nil { tmp75 = ifn_590.Invoke_O_O_O_O__O(arg_591, arg_592, arg_593, arg_594) } else { tmp75 = linked_589.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O_O__O(root_588, arg_591, arg_592, arg_593, arg_594) }; return tmp73.Invoke_O_O_O__O(tmp74, binds__19, tmp75) }
//line :138:1
	case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_146) { var vec__400000139__10 any = as__8; var m__11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000139__10, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__12_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000139__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp78 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp79 any = A_arbace_c2j_node_A_const_151; var tmp80 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp81 any = A_arbace_c2j_node_A_const_152; var tmp82 any = A_arbace_c2j_node_A_const_153; var tmp83 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp84 any = A_arbace_c2j_node_A_const_154; var tmp85 any; var root_616 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, A_arbace_c2j_node_qs_A_fn_class); var ifn_618 lang.IFn








		if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = env__0; var arg_620 any = m__11_2; if linked_617 == nil { tmp85 = ifn_618.Invoke_O_O__O(arg_619, arg_620) } else { tmp85 = linked_617.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_616, arg_619, arg_620) }; var tmp86 *lang.Keyword = A_arbace_c2j_node_A_const_56; return tmp78.Invoke_O_O__O(tmp79, tmp80.Invoke_O_O_O_O__O(tmp81, tmp82, tmp83.Invoke_O_O__O(tmp84, tmp85), tmp86.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(xs__12_2)))) }
//line :138:1
	default:}; var vec__400000142__10 any; var root_363 any = A_arbace_c2j_node_A_const_81.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, A_arbace_c2j_node_q_elems_A_fn_class); var ifn_365 lang.IFn; if











































	linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = env__0; var arg_367 any = t__1; if linked_364 == nil { vec__400000142__10 = ifn_365.Invoke_O_O__O(arg_366, arg_367) } else { vec__400000142__10 = linked_364.(*A_arbace_c2j_node_q_elems_A).Invoke_O_O_O__O(root_363, arg_366, arg_367) }; var fixed__11 any = /*line :138:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__400000142__10, lang.RT_IntCast_J__I_NoInit(0), nil); var tail__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000142__10, lang.RT_IntCast_J__I_NoInit(1), nil); if












































	jrt.J2g_Truth(tail__12) {
		return lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_82), fixed__11, lang.Tuple_Create_O__IPersistentVector(tail__12)) } else {
			var root_374 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any = A_arbace_c2j_node_A_const_84; var arg_378 any = fixed__11; if linked_375 == nil { return ifn_376.Invoke_O_O__O(arg_377, arg_378) } else { return linked_375.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_374, arg_377, arg_378) } } }
//line :149:1
func A_arbace_c2j_node_q_seq_fn__400000110_A_New() *A_arbace_c2j_node_q_seq_fn__400000110_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_fn__400000110_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_c2j_node_q_seq_fn__400000110_A) Ctor() {}
//line :149:1
func (t *A_arbace_c2j_node_q_seq_fn__400000110_A) Invoke_O_O_O__O(self, p__400000108__1, p__400000109__2 any) any { var vec__400000111__3 any = p__400000108__1; var env__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000111__3, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000111__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__400000114__6 any = p__400000109__2; var s__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000114__6, lang.RT_IntCast_J__I_NoInit(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000114__6, lang.RT_IntCast_J__I_NoInit(1), nil); var v__9 any; var root_469 any = A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_471 lang.IFn; if
															linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, s__7, nil)).Ref(); if linked_470 == nil { v__9 = ifn_471.Invoke_O__O(arg_472) } else { v__9 = linked_470.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_469, arg_472) }; var k__10 any; var tmp1 any = A_arbace_c2j_node_A_const_130; var tmp2 any; var root_473 any = /*line :149:1*/A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, A_arbace_c2j_node_head_A_fn_class); var ifn_475 lang.IFn; if

	linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = init__8; if linked_474 == nil { tmp2 = ifn_475.Invoke_O__O(arg_476) } else { tmp2 = linked_474.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_473, arg_476) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { k__10 = A_arbace_c2j_node_A_const_55 } else { k__10 = A_arbace_c2j_node_A_const_131 }; var tmp3 any; var root_477 any = /*line :149:1*/A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_479 lang.IFn; if


	linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = env__4; var arg_481 any = s__7; var arg_482 any; var tmp4 any = A_arbace_c2j_node_A_const_20; var tmp5 any = A_arbace_c2j_node_A_const_56; var tmp6 any = A_arbace_c2j_node_A_const_126; var tmp7 any; if lang.Util_Equiv_O_O__Z_NoInit(k__10, A_arbace_c2j_node_A_const_55) { var tmp8 *lang.Keyword = A_arbace_c2j_node_A_const_56; tmp7 = tmp8.Invoke_O__O(lang.IFn_Cast(env__4).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(init__8, lang.RT_IntCast_J__I_NoInit(2)))) } else { tmp7 = nil }; arg_482 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, k__10, tmp5, v__9, tmp6, tmp7)); if linked_478 == nil { tmp3 = ifn_479.Invoke_O_O_O__O(arg_480, arg_481, arg_482) } else { tmp3 = linked_478.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_477, arg_480, arg_481, arg_482) }; var tmp9 any = tmp3; var tmp10 lang.IFn = /*line :149:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp11 any; var root_489 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_489, A_arbace_c2j_node_q_A_fn_class); var ifn_491 lang.IFn; if



	linked_490 == nil { ifn_491 = lang.IFn_Cast(root_489) } else { ifn_491 = nil }; var arg_492 any = env__4; var arg_493 any = init__8; if linked_490 == nil { tmp11 = ifn_491.Invoke_O_O__O(arg_492, arg_493) } else { tmp11 = linked_490.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_489, arg_492, arg_493) }; return /*line :149:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10.Invoke_O_O_O__O(binds__5, v__9, tmp11)) }










func A_arbace_c2j_node_q_seq_fn__400000084_A_New_O(p0 any) *A_arbace_c2j_node_q_seq_fn__400000084_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_fn__400000084_A{}; t.Ctor_O(p0); return t }
//line :160:1
func (t *A_arbace_c2j_node_q_seq_fn__400000084_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :160:1
func (t *A_arbace_c2j_node_q_seq_fn__400000084_A) Invoke_O_O__O(self, p__400000083__1 any) any { var vec__400000085__2 any = p__400000083__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000085__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000085__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_406 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_407 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_406, A_arbace_c2j_node_q_A_fn_class); var ifn_408 lang.IFn; if linked_407 == nil { ifn_408 = lang.IFn_Cast(root_406) } else { ifn_408 = nil }; var arg_409 any = t.F_env; var arg_410 any = f__4; if linked_407 == nil { tmp1 = ifn_408.Invoke_O_O__O(arg_409, arg_410) } else { tmp1 = linked_407.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_406, arg_409, arg_410) }; return lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp1) }














func A_arbace_c2j_node_q_seq_fn__400000129_A_New_O(p0 any) *A_arbace_c2j_node_q_seq_fn__400000129_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_fn__400000129_A{}; t.Ctor_O(p0); return t }
//line :175:1
func (t *A_arbace_c2j_node_q_seq_fn__400000129_A) Ctor_O(c__fresh any) { t.F_fresh = c__fresh }
//line :175:1
func (t *A_arbace_c2j_node_q_seq_fn__400000129_A) Invoke_O_O_O__O(self, p__400000127__1, p__400000128__2 any) any { var vec__400000130__3 any = p__400000127__1; var env__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000130__3, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000130__3, lang.RT_IntCast_J__I_NoInit(1), nil); var lets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000130__3, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__400000133__7 any = p__400000128__2; var s__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000133__7, lang.RT_IntCast_J__I_NoInit(0), nil); var init__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000133__7, lang.RT_IntCast_J__I_NoInit(1), nil); var v__10 any; var root_536 any = A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_538 lang.IFn; if
															linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, s__8, nil)).Ref(); if linked_537 == nil { v__10 = ifn_538.Invoke_O__O(arg_539) } else { v__10 = linked_537.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_536, arg_539) }; var tmp1 any; var root_540 any = /*line :175:1*/A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_540, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_542 lang.IFn; if

	linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = env__4; var arg_544 any = s__8; var arg_545 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_136, A_arbace_c2j_node_A_const_56, v__10)); if linked_541 == nil { tmp1 = ifn_542.Invoke_O_O_O__O(arg_543, arg_544, arg_545) } else { tmp1 = linked_541.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_540, arg_543, arg_544, arg_545) }; var tmp2 any = tmp1; var tmp3 lang.IFn = /*line :175:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp4 any; if


	jrt.J2g_Truth(t.F_fresh) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_node_A_const_137; var tmp7 any = A_arbace_c2j_node_A_const_138; tmp4 = tmp5.Invoke_O_O_O__O(tmp6, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_62), jrt.RefArrayOf(jrt.Object_class, s__8, nil)).Ref()) } else { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_node_A_const_139; var tmp10 any; var root_552 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_62), jrt.RefArrayOf(jrt.Object_class, s__8, nil)).Ref(); if linked_553 == nil { tmp10 = ifn_554.Invoke_O__O(arg_555) } else { tmp10 = linked_553.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_552, arg_555) }; tmp4 = tmp8.Invoke_O_O__O(tmp9, tmp10) }; var tmp11 any = /*line :175:1*/tmp3.Invoke_O_O_O__O(binds__5, v__10, tmp4); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp13 any; var root_562 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_563 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_562, A_arbace_c2j_node_q_A_fn_class); var ifn_564 lang.IFn; if



	linked_563 == nil { ifn_564 = lang.IFn_Cast(root_562) } else { ifn_564 = nil }; var arg_565 any = env__4; var arg_566 any = init__9; if linked_563 == nil { tmp13 = ifn_564.Invoke_O_O__O(arg_565, arg_566) } else { tmp13 = linked_563.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_562, arg_565, arg_566) }; return /*line :175:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp11, tmp12.Invoke_O_O_O__O(lets__6, v__10, tmp13)) }





func A_arbace_c2j_node_q_seq_fn__400000137_A_New_O(p0 any) *A_arbace_c2j_node_q_seq_fn__400000137_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_fn__400000137_A{}; t.Ctor_O(p0); return t }
//line :181:1
func (t *A_arbace_c2j_node_q_seq_fn__400000137_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :181:1
func (t *A_arbace_c2j_node_q_seq_fn__400000137_A) Invoke_O_O__O(self, p1__400000066_SHARP___1 any) any { var root_610 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, A_arbace_c2j_node_q_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = t.F_env; var arg_614 any = p1__400000066_SHARP___1; if linked_611 == nil { return ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { return linked_611.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_610, arg_613, arg_614) } }





func A_arbace_c2j_node_q_A_New() *A_arbace_c2j_node_q_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_c2j_node_q_A) Ctor() {}
//line :187:1
func (t *A_arbace_c2j_node_q_A) Invoke_O_O_O__O(self, env__0, t__1 any) any {


	var tmp1 any; var root_621 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_622 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_621, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_623 lang.IFn
	if linked_622 == nil { ifn_623 = lang.IFn_Cast(root_621) } else { ifn_623 = nil }; var arg_624 any = t__1; if linked_622 == nil { tmp1 = ifn_623.Invoke_O__O(arg_624) } else { tmp1 = linked_622.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_621, arg_624) }
//line :190:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000408__auto____3 any = lang.IFn_Cast(env__0).Invoke_O__O(t__1)
		if jrt.J2g_Truth(temp__1927000408__auto____3) { var b__4 any = temp__1927000408__auto____3; var G__400000146__5_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__4)
			switch lang.Util_Hash_O__I_NoInit(G__400000146__5_) >> 2 & 3 { case 0: if any(G__400000146__5_) == any(A_arbace_c2j_node_A_const_155) {
				var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_node_A_const_158; var tmp4 any = A_arbace_c2j_node_A_const_159; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_node_A_const_160; return tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4), tmp5.Invoke_O_O__O(tmp6, A_arbace_c2j_node_A_const_161.Invoke_O__O(b__4))) }
//line :192:1
			case 2: if any(G__400000146__5_) == any(A_arbace_c2j_node_A_const_136) {

				return A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4) }
//line :192:1
			case 3: if any(G__400000146__5_) == any(A_arbace_c2j_node_A_const_131) {

				return A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4) }
//line :192:1
			default:}; var tmp7 any; var root_626 any = A_arbace_c2j_node_A_const_156.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_628 lang.IFn


			if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_52, nil, Lit_53), jrt.RefArrayOf(jrt.Object_class, nil, t__1, nil)).Ref(); var arg_630 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_627 == nil { tmp7 = ifn_628.Invoke_O_O__O(arg_629, arg_630) } else { tmp7 = linked_627.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_626, arg_629, arg_630) }
//line :192:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp7))) } else {



				return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_162, t__1) } } else {
//line :190:1
					var tmp8 any; var root_631 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_633 lang.IFn






					if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = t__1; if linked_632 == nil { tmp8 = ifn_633.Invoke_O__O(arg_634) } else { tmp8 = linked_632.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_631, arg_634) }
//line :190:1
					if jrt.J2g_Truth(tmp8) {






						var root_635 any = A_arbace_c2j_node_A_const_157.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, A_arbace_c2j_node_q_seq_A_fn_class); var ifn_637 lang.IFn; if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = env__0; var arg_639 any = t__1; if linked_636 == nil { return ifn_637.Invoke_O_O__O(arg_638, arg_639) } else { return linked_636.(*A_arbace_c2j_node_q_seq_A).Invoke_O_O_O__O(root_635, arg_638, arg_639) } } else {
//line :190:1
							var tmp9 any; var root_640 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_640, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_642 lang.IFn







							if linked_641 == nil { ifn_642 = lang.IFn_Cast(root_640) } else { ifn_642 = nil }; var arg_643 any = t__1; if linked_641 == nil { tmp9 = ifn_642.Invoke_O__O(arg_643) } else { tmp9 = linked_641.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_640, arg_643) }
//line :190:1
							if jrt.J2g_Truth(tmp9) { var vec__400000147__3 any; var root_644 any = A_arbace_c2j_node_A_const_81.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, A_arbace_c2j_node_q_elems_A_fn_class); var ifn_646 lang.IFn







								if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = env__0; var arg_648 any = t__1; if linked_645 == nil { vec__400000147__3 = ifn_646.Invoke_O_O__O(arg_647, arg_648) } else { vec__400000147__3 = linked_645.(*A_arbace_c2j_node_q_elems_A).Invoke_O_O_O__O(root_644, arg_647, arg_648) }
//line :190:1
								var fixed__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000147__3, lang.RT_IntCast_J__I_NoInit(0), nil); var tail__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000147__3, lang.RT_IntCast_J__I_NoInit(1), nil)








								if jrt.J2g_Truth(tail__5) { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_node_A_const_163; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_node_A_const_164; var tmp14 any; var root_649 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_649, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_651 lang.IFn; if linked_650 == nil { ifn_651 = lang.IFn_Cast(root_649) } else { ifn_651 = nil }; var arg_652 any = fixed__4; if linked_650 == nil { tmp14 = ifn_651.Invoke_O__O(arg_652) } else { tmp14 = linked_650.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_649, arg_652) }; return tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O_O__O(tmp13, tmp14, tail__5)) } else { return fixed__4 } } else {
//line :190:1
									if A_arbace_c2j_node_A_const_45 != nil { return t__1 } else { return nil
									}
								}
						}
				}
}






func A_arbace_c2j_node_emit_fn_A_New() *A_arbace_c2j_node_emit_fn_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_emit_fn_A{}; t.Ctor(); return t }
//line :202:1
func (t *A_arbace_c2j_node_emit_fn_A) Ctor() {}
//line :202:1
func (t *A_arbace_c2j_node_emit_fn_A) Invoke_O_O__O(self, d__0 any) any { var fields__2 any; var root_653 any = A_arbace_c2j_node_A_const_165.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, A_arbace_c2j_node_field_names_A_fn_class); var ifn_655 lang.IFn; if


	linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = d__0; if linked_654 == nil { fields__2 = ifn_655.Invoke_O__O(arg_656) } else { fields__2 = linked_654.(*A_arbace_c2j_node_field_names_A).Invoke_O_O__O(root_653, arg_656) }; var ev__3 any; var root_657 any = /*line :202:1*/A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_659 lang.IFn; if



	linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any = Lit_41; if linked_658 == nil { ev__3 = ifn_659.Invoke_O__O(arg_660) } else { ev__3 = linked_658.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_657, arg_660) }; var chv__4 any; var root_661 any = /*line :202:1*/A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_663 lang.IFn; if




	linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = Lit_42; if linked_662 == nil { chv__4 = ifn_663.Invoke_O__O(arg_664) } else { chv__4 = linked_662.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_661, arg_664) }; var env0__5 any; var root_665 any = /*line :202:1*/A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_667 lang.IFn; if





	linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var tmp1 any = A_arbace_c2j_node_A_const_166; var tmp2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_167, A_arbace_c2j_node_A_const_56, chv__4)); var tmp3 any = A_arbace_c2j_node_A_const_168; var arg_668 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_169, A_arbace_c2j_node_A_const_56, ev__3)))); var arg_669 any; var root_670 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_672 lang.IFn; if
	linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any; var tmp4 any = A_arbace_c2j_node_emit_fn_fn__400000154_A_New(); var tmp5 *jrt.Class; var fncls__679 *jrt.Class = A_arbace_c2j_node_emit_fn_fn__400000154_A_fn_class; if fncls__679 == nil { var fncls__679d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_c2j_node_emit_fn_fn__400000154_A_fn_class = fncls__679d; tmp5 = fncls__679d } else { tmp5 = fncls__679 }; arg_673 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_674 any = fields__2; if linked_671 == nil { arg_669 = ifn_672.Invoke_O_O__O(arg_673, arg_674) } else { arg_669 = linked_671.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_670, arg_673, arg_674) }; if /*line :208:1*/ linked_666 == nil { env0__5 = ifn_667.Invoke_O_O__O(arg_668, arg_669) } else { env0__5 = linked_666.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_665, arg_668, arg_669) }; var vec__400000151__6 any; var root_680 any = /*line :202:1*/A_arbace_c2j_node_A_const_128.GetRawRoot__O(); var linked_681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_680, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_682 lang.IFn; if







	linked_681 == nil { ifn_682 = lang.IFn_Cast(root_680) } else { ifn_682 = nil }; var arg_683 any; var tmp6 any = A_arbace_c2j_node_emit_fn_fn__400000158_A_New(); var tmp7 *jrt.Class; var fncls__796 *jrt.Class = A_arbace_c2j_node_emit_fn_fn__400000158_A_fn_class; if fncls__796 == nil { var fncls__796d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_c2j_node_emit_fn_fn__400000158_A_fn_class = fncls__796d; tmp7 = fncls__796d } else { tmp7 = fncls__796 }; arg_683 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_684 any = lang.Tuple_Create_O_O__IPersistentVector(env0__5, lang.PersistentVector_EMPTY.Ref()); var arg_685 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_681 == nil { vec__400000151__6 = ifn_682.Invoke_O_O_O__O(arg_683, arg_684, arg_685) } else { vec__400000151__6 = linked_681.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_680, arg_683, arg_684, arg_685) }; var env__7 any = /*line :202:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__400000151__6, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000151__6, lang.RT_IntCast_J__I_NoInit(1), nil); var body__9 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_node_A_const_182; var tmp10 any; var root_797 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_799 lang.IFn; if
















	linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp12 any; var root_808 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_810 lang.IFn; if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any = ev__3; var arg_812 any = A_arbace_c2j_node_A_const_183; if linked_809 == nil { tmp12 = ifn_810.Invoke_O_O__O(arg_811, arg_812) } else { tmp12 = linked_809.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_808, arg_811, arg_812) }; var tmp13 any = lang.Tuple_Create_O_O__IPersistentVector(tmp12, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_184, A_arbace_c2j_node_A_const_185)); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_node_emit_fn_fn__400000166_A_New_O(env0__5); var tmp16 *jrt.Class; var fncls__826 *jrt.Class = A_arbace_c2j_node_emit_fn_fn__400000166_A_fn_class; if
	fncls__826 == nil { var fncls__826d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_c2j_node_emit_fn_fn__400000166_A_fn_class = fncls__826d; tmp16 = fncls__826d } else { tmp16 = fncls__826 }; var tmp17 lang.IFn = /*line :219:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp18 any = A_arbace_c2j_node_A_const_189; var tmp19 any = A_arbace_c2j_node_A_const_190; arg_800 = tmp11.Invoke_O_O_O_O__O(tmp13, tmp14.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil), fields__2), lang.Tuple_Create_O_O__IPersistentVector(chv__4, tmp17.Invoke_O_O_O_O__O(tmp18, tmp19, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_191, A_arbace_c2j_node_A_const_192), A_arbace_c2j_node_A_const_120)), binds__8); if linked_798 == nil { tmp10 = ifn_799.Invoke_O__O(arg_800) } else { tmp10 = linked_798.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_797, arg_800) }; var tmp20 any = tmp10; var tmp21 any; var root_827 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, A_arbace_c2j_node_q_A_fn_class); var ifn_829 lang.IFn; if



	linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = env__7; var arg_831 any = A_arbace_c2j_node_A_const_26.Invoke_O__O(d__0); if linked_828 == nil { tmp21 = ifn_829.Invoke_O_O__O(arg_830, arg_831) } else { tmp21 = linked_828.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_827, arg_830, arg_831) }; body__9 = /*line :219:1*/tmp8.Invoke_O_O_O__O(tmp9, tmp20, tmp21); var tmp22 lang.IFn =




	lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp23 any = A_arbace_c2j_node_A_const_193; var tmp24 any; var root_832 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_832, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_834 lang.IFn; if linked_833 == nil { ifn_834 = lang.IFn_Cast(root_832) } else { ifn_834 = nil }; var arg_835 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_node_A_const_13.Invoke_O__O(d__0))).Ref(); if linked_833 == nil { tmp24 = ifn_834.Invoke_O__O(arg_835) } else { tmp24 = linked_833.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_832, arg_835) }; var tmp25 any = tmp24; var tmp26 any = A_arbace_c2j_node_A_const_194; var tmp27 any; var tmp28 *lang.Keyword = A_arbace_c2j_node_A_const_195; var temp__1927000408__auto____10 any = tmp28.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0)); if
	jrt.J2g_Truth(temp__1927000408__auto____10) { var r__11 any = temp__1927000408__auto____10; var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp30 any = A_arbace_c2j_node_A_const_196
		tmp27 = tmp29.Invoke_O_O_O__O(tmp30, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O_O__O(r__11, A_arbace_c2j_node_A_const_197, A_arbace_c2j_node_A_const_198, A_arbace_c2j_node_A_const_199), body__9) } else {
//line :225:1
			tmp27 = body__9 }; return /*line :224:1*/ tmp22.Invoke_O_O_O_O__O(tmp23, tmp25, tmp26, tmp27) }
//line :209:1
func A_arbace_c2j_node_emit_fn_fn__400000154_A_New() *A_arbace_c2j_node_emit_fn_fn__400000154_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_emit_fn_fn__400000154_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000154_A) Ctor() {}
//line :209:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000154_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 any = A_arbace_c2j_node_A_const_20; var tmp2 any = A_arbace_c2j_node_A_const_170; var tmp3 any = A_arbace_c2j_node_A_const_56; var tmp4 any; var root_675 any = A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, f__1, nil)).Ref(); if linked_676 == nil { tmp4 = ifn_677.Invoke_O__O(arg_678) } else { tmp4 = linked_676.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_675, arg_678) }; return lang.Tuple_Create_O_O__IPersistentVector(f__1, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4))) }
func A_arbace_c2j_node_emit_fn_fn__400000158_A_New() *A_arbace_c2j_node_emit_fn_fn__400000158_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_emit_fn_fn__400000158_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000158_A) Ctor() {}
//line :210:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000158_A) Invoke_O_O_O__O(self, p__400000156__1, p__400000157__2 any) any { var vec__400000159__3 any = p__400000156__1; var env__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000159__3, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000159__3, lang.RT_IntCast_J__I_NoInit(1), nil); var map__400000162__6 any = p__400000157__2; var map__400000162__7 any; if lang.ISeq_InstanceOf(map__400000162__6) { var tmp1 any; var root_686 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = map__400000162__6; if linked_687 == nil { tmp1 = ifn_688.Invoke_O__O(arg_689) } else { tmp1 = linked_687.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_686, arg_689) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_690 any = A_arbace_c2j_node_A_const_171.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = map__400000162__6; if linked_691 == nil { tmp2 = ifn_692.Invoke_O__O(arg_693) } else { tmp2 = linked_691.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_690, arg_693) }; map__400000162__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_694 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = map__400000162__6; if linked_695 == nil { tmp3 = ifn_696.Invoke_O__O(arg_697) } else { tmp3 = linked_695.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_694, arg_697) }; if jrt.J2g_Truth(tmp3) { var root_698 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_698, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_700 lang.IFn; if linked_699 == nil { ifn_700 = lang.IFn_Cast(root_698) } else { ifn_700 = nil }; var arg_701 any = map__400000162__6; if linked_699 == nil { map__400000162__7 = ifn_700.Invoke_O__O(arg_701) } else { map__400000162__7 = linked_699.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_698, arg_701) } } else { map__400000162__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000162__7 = map__400000162__6 }; var sym__8 any = lang.RT_Get_O_O__O_NoInit(map__400000162__7, A_arbace_c2j_node_A_const_19); var k__9 any = lang.RT_Get_O_O__O_NoInit(map__400000162__7, A_arbace_c2j_node_A_const_20); var args__10 any = lang.RT_Get_O_O__O_NoInit(map__400000162__7, A_arbace_c2j_node_A_const_21); var v__11 any; var root_702 any = A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_704 lang.IFn; if
															linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, sym__8, nil)).Ref(); if linked_703 == nil { v__11 = ifn_704.Invoke_O__O(arg_705) } else { v__11 = linked_703.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_702, arg_705) }; var G__400000164__12_ any = k__9; switch
															lang.Util_Hash_O__I_NoInit(G__400000164__12_) >> 8 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__400000164__12_, A_arbace_c2j_node_A_const_172) { var tmp4 any; var root_707 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_709 lang.IFn




		if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any = env__4; var arg_711 any = sym__8; var arg_712 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_176, A_arbace_c2j_node_A_const_56, v__11)); if linked_708 == nil { tmp4 = ifn_709.Invoke_O_O_O__O(arg_710, arg_711, arg_712) } else { tmp4 = linked_708.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_707, arg_710, arg_711, arg_712) }
//line :212:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp4, lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(binds__5, v__11, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_177, A_arbace_c2j_node_A_const_178, A_arbace_c2j_node_A_const_179))) }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__400000164__12_, A_arbace_c2j_node_A_const_173) { var tmp5 any; var root_719 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_721 lang.IFn



			if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = env__4; var arg_723 any = sym__8; var arg_724 any; var tmp6 any = A_arbace_c2j_node_A_const_20; var tmp7 any = A_arbace_c2j_node_A_const_155; var tmp8 any = A_arbace_c2j_node_A_const_56; var tmp9 any = A_arbace_c2j_node_A_const_161; var tmp10 any; var root_725 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = args__10; if linked_726 == nil { tmp10 = ifn_727.Invoke_O__O(arg_728) } else { tmp10 = linked_726.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_725, arg_728) }; arg_724 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, v__11, tmp9, tmp10)); if linked_720 == nil { tmp5 = ifn_721.Invoke_O_O_O__O(arg_722, arg_723, arg_724) } else { tmp5 = linked_720.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_719, arg_722, arg_723, arg_724) }
//line :212:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp5, lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(binds__5, v__11, nil)) }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000164__12_, A_arbace_c2j_node_A_const_174) { var tmp11 any; var root_735 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_737 lang.IFn
				if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = env__4; var arg_739 any = sym__8; var arg_740 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_180, A_arbace_c2j_node_A_const_56, v__11)); if linked_736 == nil { tmp11 = ifn_737.Invoke_O_O_O__O(arg_738, arg_739, arg_740) } else { tmp11 = linked_736.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_735, arg_738, arg_739, arg_740) }
//line :212:1
				var tmp12 any = tmp11; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp14 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp15 lang.IFn = lang.IFn_Cast(env__4); var tmp16 any; var root_747 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_749 lang.IFn
				if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = args__10; if linked_748 == nil { tmp16 = ifn_749.Invoke_O__O(arg_750) } else { tmp16 = linked_748.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_747, arg_750) }
//line :212:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13.Invoke_O_O_O__O(binds__5, v__11, tmp14.Invoke_O__O(tmp15.Invoke_O__O(tmp16)))) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__400000164__12_, A_arbace_c2j_node_A_const_175) { var tmp17 any; var root_751 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_752 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_751, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_753 lang.IFn

					if linked_752 == nil { ifn_753 = lang.IFn_Cast(root_751) } else { ifn_753 = nil }; var arg_754 any = env__4; var arg_755 any = sym__8; var arg_756 any; var tmp18 any = A_arbace_c2j_node_A_const_20; var tmp19 any = A_arbace_c2j_node_A_const_126; var tmp20 any = A_arbace_c2j_node_A_const_56; var tmp21 any = A_arbace_c2j_node_A_const_71; var tmp22 any; var root_757 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = args__10; if linked_758 == nil { tmp22 = ifn_759.Invoke_O__O(arg_760) } else { tmp22 = linked_758.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_757, arg_760) }; arg_756 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp19, tmp20, v__11, tmp21, tmp22)); if linked_752 == nil { tmp17 = ifn_753.Invoke_O_O_O__O(arg_754, arg_755, arg_756) } else { tmp17 = linked_752.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_751, arg_754, arg_755, arg_756) }
//line :212:1
					var tmp23 any = tmp17; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp25 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp26 lang.IFn = lang.IFn_Cast(env__4); var tmp27 any; var root_767 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_768 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_767, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_769 lang.IFn

					if linked_768 == nil { ifn_769 = lang.IFn_Cast(root_767) } else { ifn_769 = nil }; var arg_770 any = args__10; if linked_768 == nil { tmp27 = ifn_769.Invoke_O__O(arg_770) } else { tmp27 = linked_768.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_767, arg_770) }
//line :212:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp23, tmp24.Invoke_O_O_O__O(binds__5, v__11, tmp25.Invoke_O__O(tmp26.Invoke_O__O(tmp27)))) }; case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__400000164__12_, A_arbace_c2j_node_A_const_181) { var tmp28 any; var root_771 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_772 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_771, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_773 lang.IFn


						if linked_772 == nil { ifn_773 = lang.IFn_Cast(root_771) } else { ifn_773 = nil }; var arg_774 any = env__4; var arg_775 any = sym__8; var arg_776 any; var tmp29 any = A_arbace_c2j_node_A_const_20; var tmp30 any = A_arbace_c2j_node_A_const_155; var tmp31 any = A_arbace_c2j_node_A_const_56; var tmp32 any = A_arbace_c2j_node_A_const_161; var tmp33 any; var root_777 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_779 lang.IFn; if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = args__10; if linked_778 == nil { tmp33 = ifn_779.Invoke_O__O(arg_780) } else { tmp33 = linked_778.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_777, arg_780) }; arg_776 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30, tmp31, v__11, tmp32, tmp33)); if linked_772 == nil { tmp28 = ifn_773.Invoke_O_O_O__O(arg_774, arg_775, arg_776) } else { tmp28 = linked_772.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_771, arg_774, arg_775, arg_776) }
//line :212:1
						var tmp34 any = tmp28; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp36 any; var root_787 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, A_arbace_c2j_node_qs_A_fn_class); var ifn_789 lang.IFn


						if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = env__4; var arg_791 any; var root_792 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_792, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_794 lang.IFn; if linked_793 == nil { ifn_794 = lang.IFn_Cast(root_792) } else { ifn_794 = nil }; var arg_795 any = args__10; if linked_793 == nil { arg_791 = ifn_794.Invoke_O__O(arg_795) } else { arg_791 = linked_793.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_792, arg_795) }; if linked_788 == nil { tmp36 = ifn_789.Invoke_O_O__O(arg_790, arg_791) } else { tmp36 = linked_788.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_787, arg_790, arg_791) }
//line :212:1
						return lang.Tuple_Create_O_O__IPersistentVector(tmp34, tmp35.Invoke_O_O_O__O(binds__5, v__11, tmp36)) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__400000164__12_))))) }







func A_arbace_c2j_node_emit_fn_fn__400000166_A_New_O(p0 any) *A_arbace_c2j_node_emit_fn_fn__400000166_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_emit_fn_fn__400000166_A{}; t.Ctor_O(p0); return t }
//line :220:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000166_A) Ctor_O(c__env0 any) { t.F_env0 = c__env0 }
//line :220:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000166_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp2 any = tmp1.Invoke_O__O(lang.IFn_Cast(t.F_env0).Invoke_O__O(f__1)); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp4 any; var root_818 any = A_arbace_c2j_node_A_const_186.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any; var root_822 any = A_arbace_c2j_node_A_const_187.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any = f__1; if linked_823 == nil { arg_821 = ifn_824.Invoke_O__O(arg_825) } else { arg_821 = linked_823.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_822, arg_825) }; if linked_819 == nil { tmp4 = ifn_820.Invoke_O__O(arg_821) } else { tmp4 = linked_819.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_818, arg_821) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3.Invoke_O_O__O(tmp4, A_arbace_c2j_node_A_const_188)) }








func A_arbace_c2j_node_defnode_A_New() *A_arbace_c2j_node_defnode_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_defnode_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_c2j_node_defnode_A) Ctor() {}
//line :229:1
func (t *A_arbace_c2j_node_defnode_A) Invoke_O_O_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, kind__2, doc__3, opts__4, bindings__5, template__6 any) any { var d__8 any; var root_836 any = A_arbace_c2j_node_A_const_200.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, A_arbace_c2j_node_parse_A_fn_class); var ifn_838 lang.IFn; if



	linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = kind__2; var arg_840 any = doc__3; var arg_841 any = opts__4; var arg_842 any = bindings__5; var arg_843 any = template__6; if linked_837 == nil { d__8 = ifn_838.Invoke_O_O_O_O_O__O(arg_839, arg_840, arg_841, arg_842, arg_843) } else { d__8 = linked_837.(*A_arbace_c2j_node_parse_A).Invoke_O_O_O_O_O_O__O(root_836, arg_839, arg_840, arg_841, arg_842, arg_843) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_201; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_node_A_const_203; var tmp5 any = tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_204, d__8)); var tmp6 any; var root_844 any = A_arbace_c2j_node_A_const_202.GetRawRoot__O(); var linked_845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_844, A_arbace_c2j_node_emit_fn_A_fn_class); var ifn_846 lang.IFn; if

	linked_845 == nil { ifn_846 = lang.IFn_Cast(root_844) } else { ifn_846 = nil }; var arg_847 any = d__8; if linked_845 == nil { tmp6 = ifn_846.Invoke_O__O(arg_847) } else { tmp6 = linked_845.(*A_arbace_c2j_node_emit_fn_A).Invoke_O_O__O(root_844, arg_847) }; return /*line :234:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6) }






























func A_arbace_c2j_node_invalid_A_New() *A_arbace_c2j_node_invalid_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_invalid_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_c2j_node_invalid_A) Ctor() {}
//line :265:1
func (t *A_arbace_c2j_node_invalid_A) Invoke_O__O(self any) any { var tmp1 any; var root_848 any = A_arbace_c2j_node_A_const_156.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any = Lit_50; var arg_852 any = A_arbace_c2j_node_A_const_205; if linked_849 == nil { tmp1 = ifn_850.Invoke_O_O__O(arg_851, arg_852) } else { tmp1 = linked_849.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_848, arg_851, arg_852) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }

func A_arbace_c2j_node_realize_A_New() *A_arbace_c2j_node_realize_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_realize_A{}; t.Ctor(); return t }
//line :267:1
func (t *A_arbace_c2j_node_realize_A) Ctor() {}
//line :267:1
func (t *A_arbace_c2j_node_realize_A) Invoke_O_O__O(self, f__0 any) any {



	var tmp1 any; var root_853 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_854 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_853, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_855 lang.IFn
	if linked_854 == nil { ifn_855 = lang.IFn_Cast(root_853) } else { ifn_855 = nil }; var arg_856 any = f__0; if linked_854 == nil { tmp1 = ifn_855.Invoke_O__O(arg_856) } else { tmp1 = linked_854.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_853, arg_856) }
//line :271:1
	if jrt.J2g_Truth(tmp1) {
		var root_857 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_857, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_859 lang.IFn; if linked_858 == nil { ifn_859 = lang.IFn_Cast(root_857) } else { ifn_859 = nil }; var arg_860 any; var root_862 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_862, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_864 lang.IFn; if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = A_arbace_c2j_node_A_const_39.GetRawRoot__O(); var arg_866 any; var root_867 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_869 lang.IFn; if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = A_arbace_c2j_node_A_const_206.GetRawRoot__O(); var arg_871 any = f__0; if linked_868 == nil { arg_866 = ifn_869.Invoke_O_O__O(arg_870, arg_871) } else { arg_866 = linked_868.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_867, arg_870, arg_871) }; if linked_863 == nil { arg_860 = ifn_864.Invoke_O_O__O(arg_865, arg_866) } else { arg_860 = linked_863.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_862, arg_865, arg_866) }; var arg_861 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__0); if linked_858 == nil { return ifn_859.Invoke_O_O__O(arg_860, arg_861) } else { return linked_858.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_857, arg_860, arg_861) } } else {
//line :271:1
			var tmp2 any; var root_872 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_874 lang.IFn

			if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = f__0; if linked_873 == nil { tmp2 = ifn_874.Invoke_O__O(arg_875) } else { tmp2 = linked_873.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_872, arg_875) }
//line :271:1
			if jrt.J2g_Truth(tmp2) {

				var root_876 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_878 lang.IFn; if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any; var root_881 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any = A_arbace_c2j_node_A_const_206.GetRawRoot__O(); var arg_885 any = f__0; if linked_882 == nil { arg_879 = ifn_883.Invoke_O_O__O(arg_884, arg_885) } else { arg_879 = linked_882.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_881, arg_884, arg_885) }; var arg_880 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__0); if linked_877 == nil { return ifn_878.Invoke_O_O__O(arg_879, arg_880) } else { return linked_877.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_876, arg_879, arg_880) } } else {
//line :271:1
					if A_arbace_c2j_node_A_const_45 != nil { return f__0 } else { return nil
					}
				}
		}
}
func A_arbace_c2j_node_arg_kind_A_New() *A_arbace_c2j_node_arg_kind_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_arg_kind_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_c2j_node_arg_kind_A) Ctor() {}
//line :276:1
func (t *A_arbace_c2j_node_arg_kind_A) Invoke_O_O__O(self, c__0 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Long_TYPE.Ref()) { return A_arbace_c2j_node_A_const_110 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Integer_TYPE.Ref()) { return A_arbace_c2j_node_A_const_207 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Double_TYPE.Ref()) { return A_arbace_c2j_node_A_const_109 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Boolean_TYPE.Ref()) { return A_arbace_c2j_node_A_const_107 } else { if A_arbace_c2j_node_A_const_45 != nil { return A_arbace_c2j_node_A_const_120 } else { return nil
	} } } } } }
func A_arbace_c2j_node_ret_chans_A_New() *A_arbace_c2j_node_ret_chans_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_ret_chans_A{}; t.Ctor(); return t }
//line :281:1
func (t *A_arbace_c2j_node_ret_chans_A) Ctor() {}
//line :281:1
func (t *A_arbace_c2j_node_ret_chans_A) Invoke_O_O__O(self, c__0 any) any {


	var tmp1 bool; var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Long_TYPE.Ref()); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Integer_TYPE.Ref()) }; if tmp1 { return A_arbace_c2j_node_A_const_208 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Double_TYPE.Ref()) { return A_arbace_c2j_node_A_const_209 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Boolean_TYPE.Ref()) { return A_arbace_c2j_node_A_const_210 } else { if A_arbace_c2j_node_A_const_45 != nil { return A_arbace_c2j_node_A_const_211 } else { return nil
	}
	}
	} } }
func A_arbace_c2j_node_qe_elems_A_New() *A_arbace_c2j_node_qe_elems_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_elems_A{}; t.Ctor(); return t }
//line :288:1
func (t *A_arbace_c2j_node_qe_elems_A) Ctor() {}
//line :288:1
func (t *A_arbace_c2j_node_qe_elems_A) Invoke_O_O_O_O__O(self, env__0, v__1, xs__2 any) any {
	var root_886 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_qe_elems_fn__400000178_A_New_O_O(env__0, v__1); var tmp3 *jrt.Class; var fncls__916 *jrt.Class = A_arbace_c2j_node_qe_elems_fn__400000178_A_fn_class; if fncls__916 == nil { var fncls__916d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_c2j_node_qe_elems_fn__400000178_A_fn_class = fncls__916d; tmp3 = fncls__916d } else { tmp3 = fncls__916 }; arg_889 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), xs__2); if linked_887 == nil { return ifn_888.Invoke_O__O(arg_889) } else { return linked_887.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_886, arg_889) } }
//line :289:1
func A_arbace_c2j_node_qe_elems_fn__400000178_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_elems_fn__400000178_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_elems_fn__400000178_A{}; t.Ctor_O_O(p0, p1); return t }
//line :289:1
func (t *A_arbace_c2j_node_qe_elems_fn__400000178_A) Ctor_O_O(c__env, c__v any) { t.F_env = c__env; t.F_v = c__v }
//line :289:1
func (t *A_arbace_c2j_node_qe_elems_fn__400000178_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_895 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_897 lang.IFn; if linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any = x__1; if linked_896 == nil { and__1927000168__auto____2 = ifn_897.Invoke_O__O(arg_898) } else { and__1927000168__auto____2 = linked_896.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_895, arg_898) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_c2j_node_A_const_212; var tmp3 any; var root_899 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, A_arbace_c2j_node_head_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = x__1; if linked_900 == nil { tmp3 = ifn_901.Invoke_O__O(arg_902) } else { tmp3 = linked_900.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_899, arg_902) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var b__2 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_env); var tmp5 any; var root_906 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_906, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_908 lang.IFn
		if linked_907 == nil { ifn_908 = lang.IFn_Cast(root_906) } else { ifn_908 = nil }; var arg_909 any = x__1; if linked_907 == nil { tmp5 = ifn_908.Invoke_O__O(arg_909) } else { tmp5 = linked_907.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_906, arg_909) }; b__2 = tmp4.Invoke_O__O(tmp5); var tmp6 any = A_arbace_c2j_node_A_const_213; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_c2j_node_A_const_20.Invoke_O__O(b__2)) { var root_903 any = A_arbace_c2j_node_A_const_214.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, A_arbace_c2j_node_invalid_A_fn_class); var ifn_905 lang.IFn; if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; if linked_904 == nil { return ifn_905.Invoke__O() } else { return linked_904.(*A_arbace_c2j_node_invalid_A).Invoke_O__O(root_903) } } else { return A_arbace_c2j_node_A_const_215.Invoke_O__O(b__2) } } else {
//line :290:1
			var tmp7 any; var root_910 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, A_arbace_c2j_node_qe_A_fn_class); var ifn_912 lang.IFn

			if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any = t.F_env; var arg_914 any = t.F_v; var arg_915 any = x__1; if linked_911 == nil { tmp7 = ifn_912.Invoke_O_O_O__O(arg_913, arg_914, arg_915) } else { tmp7 = linked_911.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_910, arg_913, arg_914, arg_915) }
//line :290:1
			return lang.Tuple_Create_O__IPersistentVector(tmp7)
		}
}


func A_arbace_c2j_node_qe_seq_A_New() *A_arbace_c2j_node_qe_seq_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_A{}; t.Ctor(); return t }
//line :295:1
func (t *A_arbace_c2j_node_qe_seq_A) Ctor() {}
//line :295:1
func (t *A_arbace_c2j_node_qe_seq_A) Invoke_O_O_O_O__O(self, env__0, v__1, t__2 any) any { var vec__400000184__4 any = t__2; var seq__400000185__5 any; var root_917 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_917, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_919 lang.IFn; if
												linked_918 == nil { ifn_919 = lang.IFn_Cast(root_917) } else { ifn_919 = nil }; var arg_920 any = vec__400000184__4; if linked_918 == nil { seq__400000185__5 = ifn_919.Invoke_O__O(arg_920) } else { seq__400000185__5 = linked_918.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_917, arg_920) }; var first__400000186__6 any; var root_921 any = /*line :295:1*/A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_921, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_923 lang.IFn; if
												linked_922 == nil { ifn_923 = lang.IFn_Cast(root_921) } else { ifn_923 = nil }; var arg_924 any = seq__400000185__5; if linked_922 == nil { first__400000186__6 = ifn_923.Invoke_O__O(arg_924) } else { first__400000186__6 = linked_922.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_921, arg_924) }; var seq__400000185__7 any; var root_925 any = /*line :295:1*/A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_925, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_927 lang.IFn; if
												linked_926 == nil { ifn_927 = lang.IFn_Cast(root_925) } else { ifn_927 = nil }; var arg_928 any = seq__400000185__5; if linked_926 == nil { seq__400000185__7 = ifn_927.Invoke_O__O(arg_928) } else { seq__400000185__7 = linked_926.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_925, arg_928) }; var h__8 any = first__400000186__6; var as__9 any = seq__400000185__7; var h_STAR___10 any; var tmp1 any = /*line :295:1*/A_arbace_c2j_node_qe_seq_h_STAR___400000187_A_New_O_O_O(env__0, t__2, v__1); var tmp2 *jrt.Class; var fncls__945 *jrt.Class = A_arbace_c2j_node_qe_seq_h_STAR___400000187_A_fn_class; if

	fncls__945 == nil { var fncls__945d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_64, false); A_arbace_c2j_node_qe_seq_h_STAR___400000187_A_fn_class = fncls__945d; tmp2 = fncls__945d } else { tmp2 = fncls__945 }; h_STAR___10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var G__400000189__11_ any = h__8; switch
	lang.Util_Hash_O__I_NoInit(G__400000189__11_) >> 2 & 63 { case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_218) { var vec__400000190__12 any = as__9; var ___13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000190__12, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000190__12, lang.RT_IntCast_J__I_NoInit(1), nil); var b__15 any = lang.IFn_Cast(env__0).Invoke_O__O(xs__14); var tmp3 any = A_arbace_c2j_node_A_const_219; _ = ___13





		if lang.Util_Equiv_O_O__Z_NoInit(tmp3, A_arbace_c2j_node_A_const_220.Invoke_O__O(v__1)) { var tmp4 any = A_arbace_c2j_node_A_const_221; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_node_A_const_236; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Invoke_O_O_O__O(tmp6, A_arbace_c2j_node_A_const_170.Invoke_O__O(b__15), A_arbace_c2j_node_A_const_237))) } else { var tmp7 any = A_arbace_c2j_node_A_const_222; var tmp8 any; var root_947 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_947, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_949 lang.IFn

			if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any; var tmp9 any = A_arbace_c2j_node_qe_seq_fn__400000193_A_New_O(b__15); var tmp10 *jrt.Class; var fncls__956 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000193_A_fn_class; if fncls__956 == nil { var fncls__956d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_c2j_node_qe_seq_fn__400000193_A_fn_class = fncls__956d; tmp10 = fncls__956d } else { tmp10 = fncls__956 }; arg_950 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_951 any; var root_957 any = A_arbace_c2j_node_A_const_225.GetRawRoot__O(); var linked_958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_957, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_959 lang.IFn; if linked_958 == nil { ifn_959 = lang.IFn_Cast(root_957) } else { ifn_959 = nil }; var arg_960 any = A_arbace_c2j_node_A_const_220.Invoke_O__O(v__1); if linked_958 == nil { arg_951 = ifn_959.Invoke_O__O(arg_960) } else { arg_951 = linked_958.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_957, arg_960) }; if linked_948 == nil { tmp8 = ifn_949.Invoke_O_O__O(arg_950, arg_951) } else { tmp8 = linked_948.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_947, arg_950, arg_951) }
//line :304:1
			return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8)) } }
//line :298:1
	case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_226) {






































		var root_961 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = A_arbace_c2j_node_A_const_227; var arg_965 any; var root_966 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = A_arbace_c2j_node_A_const_228.GetRawRoot__O(); var arg_970 any; var root_971 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_972 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_971, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_973 lang.IFn; if linked_972 == nil { ifn_973 = lang.IFn_Cast(root_971) } else { ifn_973 = nil }; var arg_974 any; var tmp11 any = A_arbace_c2j_node_qe_seq_fn__400000195_A_New_O_O(env__0, v__1); var tmp12 *jrt.Class; var fncls__982 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000195_A_fn_class; if fncls__982 == nil { var fncls__982d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_c2j_node_qe_seq_fn__400000195_A_fn_class = fncls__982d; tmp12 = fncls__982d } else { tmp12 = fncls__982 }; arg_974 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var arg_975 any = as__9; if linked_972 == nil { arg_970 = ifn_973.Invoke_O_O__O(arg_974, arg_975) } else { arg_970 = linked_972.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_971, arg_974, arg_975) }; if linked_967 == nil { arg_965 = ifn_968.Invoke_O_O__O(arg_969, arg_970) } else { arg_965 = linked_967.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_966, arg_969, arg_970) }; if linked_962 == nil { return ifn_963.Invoke_O_O__O(arg_964, arg_965) } else { return linked_962.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_961, arg_964, arg_965) } }
//line :298:1
	case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_229) { var b__12 any; var tmp13 lang.IFn = lang.IFn_Cast(env__0); var tmp14 any; var root_1007 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1009 lang.IFn




























































		if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = as__9; if linked_1008 == nil { tmp14 = ifn_1009.Invoke_O__O(arg_1010) } else { tmp14 = linked_1008.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1007, arg_1010) }; b__12 = tmp13.Invoke_O__O(tmp14)
//line :298:1
		var G__400000197__13_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__12)





























































		switch lang.Util_Hash_O__I_NoInit(G__400000197__13_) >> 3 & 1 { case 0: if any(G__400000197__13_) == any(A_arbace_c2j_node_A_const_230) {

			var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_node_A_const_238; var tmp17 any = A_arbace_c2j_node_A_const_239; return tmp15.Invoke_O_O_O__O(tmp16, tmp17, A_arbace_c2j_node_A_const_215.Invoke_O__O(b__12)) }
//line :360:1
		case 1: if any(G__400000197__13_) == any(A_arbace_c2j_node_A_const_213) {
			return A_arbace_c2j_node_A_const_231.Invoke_O__O(b__12) }
//line :360:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__400000197__13_))))) }
//line :298:1
	case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_232) { var vec__400000198__12 any = as__9; var c__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000198__12, lang.RT_IntCast_J__I_NoInit(0), nil); var a__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000198__12, lang.RT_IntCast_J__I_NoInit(1), nil); var b__15_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000198__12, lang.RT_IntCast_J__I_NoInit(2), nil); var yes__16 any; var tmp18 any; var root_984 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_986 lang.IFn









































		if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = c__13; if linked_985 == nil { tmp18 = ifn_986.Invoke_O__O(arg_987) } else { tmp18 = linked_985.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_984, arg_987) }
//line :339:1
		if jrt.J2g_Truth(tmp18) {
			yes__16 = lang.RT_Get_O_O__O_NoInit(A_arbace_c2j_node_A_const_233.Invoke_O__O(v__1), c__13) } else {
//line :339:1
				var tmp19 any = A_arbace_c2j_node_A_const_234; var tmp20 any; var root_988 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, A_arbace_c2j_node_head_A_fn_class); var ifn_990 lang.IFn

				if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = c__13; if linked_989 == nil { tmp20 = ifn_990.Invoke_O__O(arg_991) } else { tmp20 = linked_989.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_988, arg_991) }
//line :339:1
				if lang.Util_Equiv_O_O__Z_NoInit(tmp19, tmp20) {

					var tmp21 any = A_arbace_c2j_node_A_const_219; yes__16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp21, A_arbace_c2j_node_A_const_220.Invoke_O__O(v__1))).Ref() } else {
//line :339:1
						var tmp22 any = A_arbace_c2j_node_A_const_235; var tmp23 any; var root_992 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_992, A_arbace_c2j_node_head_A_fn_class); var ifn_994 lang.IFn


						if linked_993 == nil { ifn_994 = lang.IFn_Cast(root_992) } else { ifn_994 = nil }; var arg_995 any = c__13; if linked_993 == nil { tmp23 = ifn_994.Invoke_O__O(arg_995) } else { tmp23 = linked_993.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_992, arg_995) }
//line :339:1
						if lang.Util_Equiv_O_O__Z_NoInit(tmp22, tmp23) {


							yes__16 = A_arbace_c2j_node_A_const_73.Invoke_O__O(v__1) } else {
//line :339:1
								if A_arbace_c2j_node_A_const_45 != nil { var tmp24 any; var root_996 any = A_arbace_c2j_node_A_const_156.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_998 lang.IFn



									if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__13)).Ref(); var arg_1000 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_997 == nil { tmp24 = ifn_998.Invoke_O_O__O(arg_999, arg_1000) } else { tmp24 = linked_997.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_996, arg_999, arg_1000) }
//line :339:1
									panic(jrt.Thrown(jrt.Throwable_Cast(tmp24))) } else { yes__16 = nil
									}
							}
					}
			}
		var root_1001 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, A_arbace_c2j_node_qe_A_fn_class); var ifn_1003 lang.IFn; if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = env__0; var arg_1005 any = v__1; var arg_1006 any; if jrt.J2g_Truth(yes__16) { arg_1006 = a__14 } else { arg_1006 = b__15_2 }; if linked_1002 == nil { return ifn_1003.Invoke_O_O_O__O(arg_1004, arg_1005, arg_1006) } else { return linked_1002.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1001, arg_1004, arg_1005, arg_1006) } }
//line :298:1
	case 26: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_240) { var vec__400000201__12 any = as__9; var seq__400000202__13 any; var root_1011 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1013 lang.IFn














































		if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = vec__400000201__12; if linked_1012 == nil { seq__400000202__13 = ifn_1013.Invoke_O__O(arg_1014) } else { seq__400000202__13 = linked_1012.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1011, arg_1014) }
//line :298:1
		var first__400000203__14 any; var root_1015 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1017 lang.IFn














































		if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = seq__400000202__13; if linked_1016 == nil { first__400000203__14 = ifn_1017.Invoke_O__O(arg_1018) } else { first__400000203__14 = linked_1016.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1015, arg_1018) }
//line :298:1
		var seq__400000202__15 any; var root_1019 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1021 lang.IFn














































		if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any = seq__400000202__13; if linked_1020 == nil { seq__400000202__15 = ifn_1021.Invoke_O__O(arg_1022) } else { seq__400000202__15 = linked_1020.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1019, arg_1022) }
//line :298:1
		var ___16 any = first__400000203__14; var cls__17 any = seq__400000202__15; var m__18 any; var root_1023 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1023, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1025 lang.IFn; _ = ___16















































		if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any = A_arbace_c2j_node_A_const_241.GetRawRoot__O(); var arg_1027 any = cls__17; if linked_1024 == nil { m__18 = ifn_1025.Invoke_O_O__O(arg_1026, arg_1027) } else { m__18 = linked_1024.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1023, arg_1026, arg_1027) }
		var tmp25 any; var root_1028 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = m__18; var arg_1032 any = A_arbace_c2j_node_A_const_167.Invoke_O__O(v__1); if linked_1029 == nil { tmp25 = ifn_1030.Invoke_O_O__O(arg_1031, arg_1032) } else { tmp25 = linked_1029.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1028, arg_1031, arg_1032) }; if jrt.J2g_Truth(tmp25) { var root_1033 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, A_arbace_c2j_node_qe_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any = env__0; var arg_1037 any = v__1; var arg_1038 any = lang.IFn_Cast(m__18).Invoke_O__O(A_arbace_c2j_node_A_const_167.Invoke_O__O(v__1)); if linked_1034 == nil { return ifn_1035.Invoke_O_O_O__O(arg_1036, arg_1037, arg_1038) } else { return linked_1034.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1033, arg_1036, arg_1037, arg_1038) } } else { var root_1039 any = A_arbace_c2j_node_A_const_214.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, A_arbace_c2j_node_invalid_A_fn_class); var ifn_1041 lang.IFn; if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; if linked_1040 == nil { return ifn_1041.Invoke__O() } else { return linked_1040.(*A_arbace_c2j_node_invalid_A).Invoke_O__O(root_1039) } } }
//line :298:1
	case 27: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_242) { var vec__400000204__12 any = as__9; var ___13_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000204__12, lang.RT_IntCast_J__I_NoInit(0), nil); var x__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000204__12, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1042 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_1044 lang.IFn; _ = ___13_2





































































		if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any; var tmp26 any = A_arbace_c2j_node_A_const_243; var tmp27 any; var root_1047 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, A_arbace_c2j_node_qe_A_fn_class); var ifn_1049 lang.IFn; if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = env__0; var arg_1051 any = v__1; var arg_1052 any = x__14; if linked_1048 == nil { tmp27 = ifn_1049.Invoke_O_O_O__O(arg_1050, arg_1051, arg_1052) } else { tmp27 = linked_1048.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1047, arg_1050, arg_1051, arg_1052) }; arg_1045 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp26, tmp27)); var tmp28 *lang.Keyword = A_arbace_c2j_node_A_const_244; var arg_1046 any = tmp28.Invoke_O__O(A_arbace_c2j_node_A_const_176.Invoke_O__O(v__1)); if linked_1043 == nil { return ifn_1044.Invoke_O_O__O(arg_1045, arg_1046) } else { return linked_1043.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_1042, arg_1045, arg_1046) } }
//line :298:1
	case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_245) { var vec__400000207__12 any = as__9; var ___13_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000207__12, lang.RT_IntCast_J__I_NoInit(0), nil); var c__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000207__12, lang.RT_IntCast_J__I_NoInit(1), nil); var c__15 any; _ = ___13_3

































































		if lang.Util_Equiv_O_O__Z_NoInit(c__14, A_arbace_c2j_node_A_const_246) { c__15 = A_arbace_c2j_node_A_const_167.Invoke_O__O(v__1) } else { c__15 = c__14 }
//line :298:1
		var tmp29 *lang.Keyword = A_arbace_c2j_node_A_const_247; var g__16 any = lang.RT_Get_O_O__O_NoInit(tmp29.Invoke_O__O(A_arbace_c2j_node_A_const_176.Invoke_O__O(v__1)), c__15)
		var or__1927000174__auto____17 any = g__16


































































		if jrt.J2g_Truth(or__1927000174__auto____17) { return or__1927000174__auto____17 } else { var root_1053 any = A_arbace_c2j_node_A_const_214.GetRawRoot__O(); var linked_1054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1053, A_arbace_c2j_node_invalid_A_fn_class); var ifn_1055 lang.IFn; if linked_1054 == nil { ifn_1055 = lang.IFn_Cast(root_1053) } else { ifn_1055 = nil }; if linked_1054 == nil { return ifn_1055.Invoke__O() } else { return linked_1054.(*A_arbace_c2j_node_invalid_A).Invoke_O__O(root_1053) } } }
//line :298:1
	case 36: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_248) { var vec__400000210__12 any = as__9; var c__13_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000210__12, lang.RT_IntCast_J__I_NoInit(0), nil); var x__14_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000210__12, lang.RT_IntCast_J__I_NoInit(1), nil); var c__15_2 any

		if lang.Util_Equiv_O_O__Z_NoInit(c__13_2, A_arbace_c2j_node_A_const_249) { c__15_2 = A_arbace_c2j_node_A_const_167.Invoke_O__O(v__1) } else { c__15_2 = c__13_2 }
		var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp31 any; var root_1060 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_1061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1060, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1062 lang.IFn; if linked_1061 == nil { ifn_1062 = lang.IFn_Cast(root_1060) } else { ifn_1062 = nil }; var arg_1063 any; var tmp32 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp33 any; var root_1064 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1064, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1066 lang.IFn; if linked_1065 == nil { ifn_1066 = lang.IFn_Cast(root_1064) } else { ifn_1066 = nil }; var arg_1067 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_255.GetRawRoot__O()).Invoke_O__O(c__15_2); if linked_1065 == nil { tmp33 = ifn_1066.Invoke_O__O(arg_1067) } else { tmp33 = linked_1065.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1064, arg_1067) }; arg_1063 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp32, jrt.RefArrayOf(jrt.Object_class, nil, tmp33)).Ref(); if linked_1061 == nil { tmp31 = ifn_1062.Invoke_O__O(arg_1063) } else { tmp31 = linked_1061.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1060, arg_1063) }; var tmp34 *lang.Keyword = A_arbace_c2j_node_A_const_170; return tmp30.Invoke_O_O_O__O(tmp31, tmp34.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(x__14_2)), A_arbace_c2j_node_A_const_256) }
//line :298:1
	case 37: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_250) { var vec__400000213__12 any = as__9; var ___13_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000213__12, lang.RT_IntCast_J__I_NoInit(0), nil); var a__14_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000213__12, lang.RT_IntCast_J__I_NoInit(1), nil); var b__15_3 any = lang.IFn_Cast(env__0).Invoke_O__O(a__14_2); var g__16_2 any; var root_1056 any = A_arbace_c2j_node_A_const_251.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1058 lang.IFn; _ = ___13_4


























































		if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = A_arbace_c2j_node_A_const_252; if linked_1057 == nil { g__16_2 = ifn_1058.Invoke_O__O(arg_1059) } else { g__16_2 = linked_1057.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1056, arg_1059) }
		var tmp35 *lang.Keyword = A_arbace_c2j_node_A_const_253; var tmp36 lang.IFn = lang.IFn_Cast(tmp35.Invoke_O__O(A_arbace_c2j_node_A_const_254.Invoke_O__O(v__1))); var tmp37 any = A_arbace_c2j_node_A_const_258.Invoke_O__O(v__1); var tmp38 any = A_arbace_c2j_node_A_const_215.Invoke_O__O(b__15_3); var tmp39 any = A_arbace_c2j_node_qe_seq_fn__400000216_A_New_O(g__16_2); var tmp40 *jrt.Class; var fncls__1087 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000216_A_fn_class; if fncls__1087 == nil { var fncls__1087d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_c2j_node_qe_seq_fn__400000216_A_fn_class = fncls__1087d; tmp40 = fncls__1087d } else { tmp40 = fncls__1087 }; return tmp36.Invoke_O_O_O__O(tmp37, tmp38, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil)) }
//line :298:1
	case 45: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_257) {





































		var root_1068 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, A_arbace_c2j_node_qe_A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = env__0; var arg_1072 any = v__1; var arg_1073 any; var root_1074 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = as__9; if linked_1075 == nil { arg_1073 = ifn_1076.Invoke_O__O(arg_1077) } else { arg_1073 = linked_1075.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1074, arg_1077) }; if linked_1069 == nil { return ifn_1070.Invoke_O_O_O__O(arg_1071, arg_1072, arg_1073) } else { return linked_1069.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1068, arg_1071, arg_1072, arg_1073) } }
//line :298:1
	case 54: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_260) { var vec__400000218__12 any = as__9; var seq__400000219__13 any; var root_1088 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1090 lang.IFn






















		if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any = vec__400000218__12; if linked_1089 == nil { seq__400000219__13 = ifn_1090.Invoke_O__O(arg_1091) } else { seq__400000219__13 = linked_1089.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1088, arg_1091) }
//line :298:1
		var first__400000220__14 any; var root_1092 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1094 lang.IFn






















		if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = seq__400000219__13; if linked_1093 == nil { first__400000220__14 = ifn_1094.Invoke_O__O(arg_1095) } else { first__400000220__14 = linked_1093.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1092, arg_1095) }
//line :298:1
		var seq__400000219__15 any; var root_1096 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1098 lang.IFn






















		if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = seq__400000219__13; if linked_1097 == nil { seq__400000219__15 = ifn_1098.Invoke_O__O(arg_1099) } else { seq__400000219__15 = linked_1097.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1096, arg_1099) }
//line :298:1
		var line__16 any = first__400000220__14; var first__400000220__17 any; var root_1100 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1102 lang.IFn






















		if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = seq__400000219__15; if linked_1101 == nil { first__400000220__17 = ifn_1102.Invoke_O__O(arg_1103) } else { first__400000220__17 = linked_1101.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1100, arg_1103) }
//line :298:1
		var seq__400000219__18 any; var root_1104 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1104, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1106 lang.IFn






















		if linked_1105 == nil { ifn_1106 = lang.IFn_Cast(root_1104) } else { ifn_1106 = nil }; var arg_1107 any = seq__400000219__15; if linked_1105 == nil { seq__400000219__18 = ifn_1106.Invoke_O__O(arg_1107) } else { seq__400000219__18 = linked_1105.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1104, arg_1107) }
//line :298:1
		var bv__19 any = first__400000220__17; var body__20 any = seq__400000219__18; var n__21 any; var root_1108 any = A_arbace_c2j_node_A_const_251.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1110 lang.IFn























		if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = A_arbace_c2j_node_A_const_261; if linked_1109 == nil { n__21 = ifn_1110.Invoke_O__O(arg_1111) } else { n__21 = linked_1109.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1108, arg_1111) }
//line :298:1
		var tmp__22 any; var tmp41 any = A_arbace_c2j_node_qe_seq_tmp__400000224_A_New_O(n__21); var tmp42 *jrt.Class
		var fncls__1121 /*line :298:1*/*jrt.Class = A_arbace_c2j_node_qe_seq_tmp__400000224_A_fn_class
























		if fncls__1121 == nil { var fncls__1121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_c2j_node_qe_seq_tmp__400000224_A_fn_class = fncls__1121d; tmp42 = fncls__1121d } else { tmp42 = fncls__1121 }; tmp__22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil)
//line :298:1
		var vec__400000221__23 any; var root_1122 any = A_arbace_c2j_node_A_const_128.GetRawRoot__O(); var linked_1123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1122, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1124 lang.IFn

























		if linked_1123 == nil { ifn_1124 = lang.IFn_Cast(root_1122) } else { ifn_1124 = nil }; var arg_1125 any; var tmp43 any = A_arbace_c2j_node_qe_seq_fn__400000228_A_New_O_O(tmp__22, v__1); var tmp44 *jrt.Class; var fncls__1188 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000228_A_fn_class; if fncls__1188 == nil { var fncls__1188d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_c2j_node_qe_seq_fn__400000228_A_fn_class = fncls__1188d; tmp44 = fncls__1188d } else { tmp44 = fncls__1188 }; arg_1125 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp43, tmp44, nil); var arg_1126 any = lang.Tuple_Create_O_O__IPersistentVector(env__0, lang.PersistentVector_EMPTY.Ref()); var arg_1127 any; var root_1189 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_1190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1189, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_1191 lang.IFn








		if linked_1190 == nil { ifn_1191 = lang.IFn_Cast(root_1189) } else { ifn_1191 = nil }; var arg_1192 any = A_arbace_c2j_node_A_const_25; var arg_1193 any = bv__19; if linked_1190 == nil { arg_1127 = ifn_1191.Invoke_O_O__O(arg_1192, arg_1193) } else { arg_1127 = linked_1190.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_1189, arg_1192, arg_1193) }
//line :324:1
		if linked_1123 == nil { vec__400000221__23 = ifn_1124.Invoke_O_O_O__O(arg_1125, arg_1126, arg_1127) } else { vec__400000221__23 = linked_1123.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1122, arg_1125, arg_1126, arg_1127) }
//line :298:1
		var env__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000221__23, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000221__23, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1194 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_1195 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1194, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1196 lang.IFn



































		if linked_1195 == nil { ifn_1196 = lang.IFn_Cast(root_1194) } else { ifn_1196 = nil }; var arg_1197 any; var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp46 any = A_arbace_c2j_node_A_const_263; var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp48 any = A_arbace_c2j_node_A_const_264; var tmp49 any = A_arbace_c2j_node_A_const_265; var tmp50 any; var root_1199 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_1200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1199, A_arbace_c2j_node_qe_A_fn_class); var ifn_1201 lang.IFn; if linked_1200 == nil { ifn_1201 = lang.IFn_Cast(root_1199) } else { ifn_1201 = nil }; var arg_1202 any = env__24; var arg_1203 any = v__1; var arg_1204 any = line__16; if linked_1200 == nil { tmp50 = ifn_1201.Invoke_O_O_O__O(arg_1202, arg_1203, arg_1204) } else { tmp50 = linked_1200.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1199, arg_1202, arg_1203, arg_1204) }; arg_1197 = tmp45.Invoke_O_O_O__O(tmp46, binds__25, tmp47.Invoke_O_O_O__O(tmp48, tmp49, tmp50)); var arg_1198 any; var root_1205 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1207 lang.IFn
		if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = A_arbace_c2j_node_A_const_228.GetRawRoot__O(); var arg_1209 any; var root_1210 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1210, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; var arg_1213 any; var tmp51 any = A_arbace_c2j_node_qe_seq_fn__400000238_A_New_O_O(v__1, env__24); var tmp52 *jrt.Class; var fncls__1221 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000238_A_fn_class; if fncls__1221 == nil { var fncls__1221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_c2j_node_qe_seq_fn__400000238_A_fn_class = fncls__1221d; tmp52 = fncls__1221d } else { tmp52 = fncls__1221 }; arg_1213 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp51, tmp52, nil); var arg_1214 any = body__20; if linked_1211 == nil { arg_1209 = ifn_1212.Invoke_O_O__O(arg_1213, arg_1214) } else { arg_1209 = linked_1211.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1210, arg_1213, arg_1214) }; if linked_1206 == nil { arg_1198 = ifn_1207.Invoke_O_O__O(arg_1208, arg_1209) } else { arg_1198 = linked_1206.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1205, arg_1208, arg_1209) }
//line :334:1
		if linked_1195 == nil { return ifn_1196.Invoke_O_O__O(arg_1197, arg_1198) } else { return linked_1195.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1194, arg_1197, arg_1198) } }
//line :298:1
	case 56: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_266) { var vec__400000240__12 any = as__9; var ___13_5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000240__12, lang.RT_IntCast_J__I_NoInit(0), nil); var ___14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000240__12, lang.RT_IntCast_J__I_NoInit(1), nil); var f__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000240__12, lang.RT_IntCast_J__I_NoInit(2), nil); var m__16 any = A_arbace_c2j_node_A_const_258.Invoke_O__O(v__1); var r__17 any = jrt.NN(jrt.Method_Cast(m__16)).GetReturnType__Class().Ref(); var tmp53 any; var root_1222 any = A_arbace_c2j_node_A_const_267.GetRawRoot__O(); var linked_1223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1222, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1224 lang.IFn; _ = ___13_5; _ = ___14





















































		if linked_1223 == nil { ifn_1224 = lang.IFn_Cast(root_1222) } else { ifn_1224 = nil }; var arg_1225 any; var root_1226 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1226, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1228 lang.IFn; if linked_1227 == nil { ifn_1228 = lang.IFn_Cast(root_1226) } else { ifn_1228 = nil }; var arg_1229 any; var root_1231 any = A_arbace_c2j_node_A_const_268.GetRawRoot__O(); var linked_1232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1231, A_arbace_c2j_node_ret_chans_A_fn_class); var ifn_1233 lang.IFn; if linked_1232 == nil { ifn_1233 = lang.IFn_Cast(root_1231) } else { ifn_1233 = nil }; var arg_1234 any = r__17; if linked_1232 == nil { arg_1229 = ifn_1233.Invoke_O__O(arg_1234) } else { arg_1229 = linked_1232.(*A_arbace_c2j_node_ret_chans_A).Invoke_O_O__O(root_1231, arg_1234) }; var arg_1230 any = A_arbace_c2j_node_A_const_167.Invoke_O__O(v__1); if linked_1227 == nil { arg_1225 = ifn_1228.Invoke_O_O__O(arg_1229, arg_1230) } else { arg_1225 = linked_1227.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1226, arg_1229, arg_1230) }; if linked_1223 == nil { tmp53 = ifn_1224.Invoke_O__O(arg_1225) } else { tmp53 = linked_1223.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1222, arg_1225) }
//line :351:1
		if jrt.J2g_Truth(tmp53) {
			var root_1235 any = A_arbace_c2j_node_A_const_214.GetRawRoot__O(); var linked_1236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1235, A_arbace_c2j_node_invalid_A_fn_class); var ifn_1237 lang.IFn; if linked_1236 == nil { ifn_1237 = lang.IFn_Cast(root_1235) } else { ifn_1237 = nil }; if linked_1236 == nil { return ifn_1237.Invoke__O() } else { return linked_1236.(*A_arbace_c2j_node_invalid_A).Invoke_O__O(root_1235) } } else {
//line :351:1
				var tmp54 any = A_arbace_c2j_node_A_const_120; if lang.Util_Equiv_O_O__Z_NoInit(tmp54, A_arbace_c2j_node_A_const_167.Invoke_O__O(v__1)) {

					var tmp55 *lang.Keyword = A_arbace_c2j_node_A_const_269; var tmp56 lang.IFn = lang.IFn_Cast(tmp55.Invoke_O__O(A_arbace_c2j_node_A_const_254.Invoke_O__O(v__1))); var tmp57 any; var root_1295 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, A_arbace_c2j_node_qe_A_fn_class); var ifn_1297 lang.IFn; if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = env__0; var arg_1299 any = v__1; var arg_1300 any = f__15; if linked_1296 == nil { tmp57 = ifn_1297.Invoke_O_O_O__O(arg_1298, arg_1299, arg_1300) } else { tmp57 = linked_1296.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1295, arg_1298, arg_1299, arg_1300) }; return tmp56.Invoke_O_O__O(tmp57, r__17) } else {
//line :351:1
						if A_arbace_c2j_node_A_const_45 != nil {


							var root_1238 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, A_arbace_c2j_node_qe_A_fn_class); var ifn_1240 lang.IFn; if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any = env__0; var arg_1242 any = v__1; var arg_1243 any = f__15; if linked_1239 == nil { return ifn_1240.Invoke_O_O_O__O(arg_1241, arg_1242, arg_1243) } else { return linked_1239.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1238, arg_1241, arg_1242, arg_1243) } } else {
//line :351:1
								return nil } } } }
//line :298:1
	case 57: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_270) { var vec__400000243__12 any = as__9; var seq__400000244__13 any; var root_1244 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1244, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1246 lang.IFn






































































		if linked_1245 == nil { ifn_1246 = lang.IFn_Cast(root_1244) } else { ifn_1246 = nil }; var arg_1247 any = vec__400000243__12; if linked_1245 == nil { seq__400000244__13 = ifn_1246.Invoke_O__O(arg_1247) } else { seq__400000244__13 = linked_1245.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1244, arg_1247) }
//line :298:1
		var first__400000245__14 any; var root_1248 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1250 lang.IFn






































































		if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any = seq__400000244__13; if linked_1249 == nil { first__400000245__14 = ifn_1250.Invoke_O__O(arg_1251) } else { first__400000245__14 = linked_1249.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1248, arg_1251) }
//line :298:1
		var seq__400000244__15 any; var root_1252 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1252, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1254 lang.IFn






































































		if linked_1253 == nil { ifn_1254 = lang.IFn_Cast(root_1252) } else { ifn_1254 = nil }; var arg_1255 any = seq__400000244__13; if linked_1253 == nil { seq__400000244__15 = ifn_1254.Invoke_O__O(arg_1255) } else { seq__400000244__15 = linked_1253.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1252, arg_1255) }
//line :298:1
		var bv__16 any = first__400000245__14; var body__17 any = seq__400000244__15; var root_1256 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_1257 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1256, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1258 lang.IFn







































































		if linked_1257 == nil { ifn_1258 = lang.IFn_Cast(root_1256) } else { ifn_1258 = nil }; var arg_1259 any = A_arbace_c2j_node_A_const_271; var arg_1260 any; var root_1262 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1263 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1262, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1264 lang.IFn; if linked_1263 == nil { ifn_1264 = lang.IFn_Cast(root_1262) } else { ifn_1264 = nil }; var arg_1265 any; var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp59 any = A_arbace_c2j_node_qe_seq_fn__400000247_A_New_O_O(env__0, v__1); var tmp60 *jrt.Class; var fncls__1277 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000247_A_fn_class; if fncls__1277 == nil { var fncls__1277d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_c2j_node_qe_seq_fn__400000247_A_fn_class = fncls__1277d; tmp60 = fncls__1277d } else { tmp60 = fncls__1277 }; var tmp61 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp59, tmp60, nil); var tmp62 any; var root_1278 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_1279 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1278, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_1280 lang.IFn; if linked_1279 == nil { ifn_1280 = lang.IFn_Cast(root_1278) } else { ifn_1280 = nil }; var arg_1281 any = A_arbace_c2j_node_A_const_25; var arg_1282 any = bv__16; if linked_1279 == nil { tmp62 = ifn_1280.Invoke_O_O__O(arg_1281, arg_1282) } else { tmp62 = linked_1279.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_1278, arg_1281, arg_1282) }; arg_1265 = tmp58.Invoke_O_O__O(tmp61, tmp62); if linked_1263 == nil { arg_1260 = ifn_1264.Invoke_O__O(arg_1265) } else { arg_1260 = linked_1263.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1262, arg_1265) }; var arg_1261 any; var root_1283 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1284 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1283, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1285 lang.IFn
		if linked_1284 == nil { ifn_1285 = lang.IFn_Cast(root_1283) } else { ifn_1285 = nil }; var arg_1286 any; var tmp63 any = A_arbace_c2j_node_qe_seq_fn__400000252_A_New_O_O(env__0, v__1); var tmp64 *jrt.Class; var fncls__1294 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000252_A_fn_class; if fncls__1294 == nil { var fncls__1294d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_c2j_node_qe_seq_fn__400000252_A_fn_class = fncls__1294d; tmp64 = fncls__1294d } else { tmp64 = fncls__1294 }; arg_1286 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp63, tmp64, nil); var arg_1287 any = body__17; if linked_1284 == nil { arg_1261 = ifn_1285.Invoke_O_O__O(arg_1286, arg_1287) } else { arg_1261 = linked_1284.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1283, arg_1286, arg_1287) }
//line :370:1
		if linked_1257 == nil { return ifn_1258.Invoke_O_O_O__O(arg_1259, arg_1260, arg_1261) } else { return linked_1257.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1256, arg_1259, arg_1260, arg_1261) } }
//line :298:1
	case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__400000189__11_, A_arbace_c2j_node_A_const_272) { var vec__400000254__12 any = as__9; var ___13_6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000254__12, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__14_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000254__12, lang.RT_IntCast_J__I_NoInit(1), nil); var b__15_4 any = lang.IFn_Cast(env__0).Invoke_O__O(xs__14_2); var m__16_2 any = A_arbace_c2j_node_A_const_258.Invoke_O__O(v__1); var tmp65 *lang.Keyword = A_arbace_c2j_node_A_const_273; var ts__17 any = tmp65.Invoke_O__O(A_arbace_c2j_node_A_const_254.Invoke_O__O(v__1)); var tmp66 any = A_arbace_c2j_node_A_const_222; var tmp67 any; var root_1301 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1303 lang.IFn; _ = ___13_6












		if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any; var root_1305 any = A_arbace_c2j_node_A_const_274.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1307 lang.IFn; if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any; var tmp68 any = A_arbace_c2j_node_qe_seq_fn__400000257_A_New_O_O(ts__17, b__15_4); var tmp69 *jrt.Class; var fncls__1319 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000257_A_fn_class
		if fncls__1319 == nil { var fncls__1319d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_c2j_node_qe_seq_fn__400000257_A_fn_class = fncls__1319d; tmp69 = fncls__1319d } else { tmp69 = fncls__1319 }; arg_1308 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp68, tmp69, nil)
//line :311:1
		var arg_1309 any = jrt.NN(jrt.Method_Cast(m__16_2)).GetParameterTypes__Class1().Ref(); if linked_1306 == nil { arg_1304 = ifn_1307.Invoke_O_O__O(arg_1308, arg_1309) } else { arg_1304 = linked_1306.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1305, arg_1308, arg_1309) }; if linked_1302 == nil { tmp67 = ifn_1303.Invoke_O__O(arg_1304) } else { tmp67 = linked_1302.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1301, arg_1304) }
//line :298:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp66, tmp67)) }; default:}; return /*line :372:1*/ lang.IFn_Cast(h_STAR___10).Invoke__O() }
//line :297:1
func A_arbace_c2j_node_qe_seq_h_STAR___400000187_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_qe_seq_h_STAR___400000187_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_h_STAR___400000187_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :297:1
func (t *A_arbace_c2j_node_qe_seq_h_STAR___400000187_A) Ctor_O_O_O(c__env, c__t, c__v any) { t.F_env = c__env; t.F_t = c__t; t.F_v = c__v }
//line :297:1
func (t *A_arbace_c2j_node_qe_seq_h_STAR___400000187_A) Invoke_O__O(self any) any { var root_929 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_929, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_931 lang.IFn; if linked_930 == nil { ifn_931 = lang.IFn_Cast(root_929) } else { ifn_931 = nil }; var arg_932 any; var root_934 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_934, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_936 lang.IFn; if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = A_arbace_c2j_node_A_const_39.GetRawRoot__O(); var arg_938 any; var root_939 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, A_arbace_c2j_node_qe_elems_A_fn_class); var ifn_941 lang.IFn; if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = t.F_env; var arg_943 any = t.F_v; var arg_944 any = t.F_t; if linked_940 == nil { arg_938 = ifn_941.Invoke_O_O_O__O(arg_942, arg_943, arg_944) } else { arg_938 = linked_940.(*A_arbace_c2j_node_qe_elems_A).Invoke_O_O_O_O__O(root_939, arg_942, arg_943, arg_944) }; if linked_935 == nil { arg_932 = ifn_936.Invoke_O_O__O(arg_937, arg_938) } else { arg_932 = linked_935.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_934, arg_937, arg_938) }; var arg_933 any = lang.RT_Meta_O__IPersistentMap_NoInit(t.F_t); if linked_930 == nil { return ifn_931.Invoke_O_O__O(arg_932, arg_933) } else { return linked_930.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_929, arg_932, arg_933) } }








func A_arbace_c2j_node_qe_seq_fn__400000193_A_New_O(p0 any) *A_arbace_c2j_node_qe_seq_fn__400000193_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000193_A{}; t.Ctor_O(p0); return t }
//line :306:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000193_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :306:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000193_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_223; var tmp3 any; var root_952 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_170.Invoke_O__O(t.F_b), i__1)).Ref(); if linked_953 == nil { tmp3 = ifn_954.Invoke_O__O(arg_955) } else { tmp3 = linked_953.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_952, arg_955) }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_c2j_node_A_const_224) }





func A_arbace_c2j_node_qe_seq_fn__400000257_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000257_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000257_A{}; t.Ctor_O_O(p0, p1); return t }
//line :312:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000257_A) Ctor_O_O(c__ts, c__b any) { t.F_ts = c__ts; t.F_b = c__b }
//line :312:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000257_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var a__3 any; var root_1310 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1312 lang.IFn; if
												linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_170.Invoke_O__O(t.F_b), i__1)).Ref(); if linked_1311 == nil { a__3 = ifn_1312.Invoke_O__O(arg_1313) } else { a__3 = linked_1311.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1310, arg_1313) }; var G__400000258__4_ any; var root_1314 any = /*line :312:1*/A_arbace_c2j_node_A_const_275.GetRawRoot__O(); var linked_1315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1314, A_arbace_c2j_node_arg_kind_A_fn_class); var ifn_1316 lang.IFn; if

	linked_1315 == nil { ifn_1316 = lang.IFn_Cast(root_1314) } else { ifn_1316 = nil }; var arg_1317 any = p__2; if linked_1315 == nil { G__400000258__4_ = ifn_1316.Invoke_O__O(arg_1317) } else { G__400000258__4_ = linked_1315.(*A_arbace_c2j_node_arg_kind_A).Invoke_O_O__O(root_1314, arg_1317) }; switch lang.Util_Hash_O__I_NoInit(G__400000258__4_) { case 1013910639: if any(G__400000258__4_) == any(A_arbace_c2j_node_A_const_109) {


		return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_277, a__3, A_arbace_c2j_node_A_const_278) }
//line :314:1
	case 1013911026: if any(G__400000258__4_) == any(A_arbace_c2j_node_A_const_110) {
		return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_279, a__3, A_arbace_c2j_node_A_const_280) }
//line :314:1
	case 1013911091: if any(G__400000258__4_) == any(A_arbace_c2j_node_A_const_207) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_281; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_282, a__3, A_arbace_c2j_node_A_const_283)) }
//line :314:1
	case 1013911476: if any(G__400000258__4_) == any(A_arbace_c2j_node_A_const_120) {




		if lang.Util_Equiv_O_O__Z_NoInit(p__2, A_arbace_c2j_node_A_const_276) { return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_284, a__3, A_arbace_c2j_node_A_const_285) } else { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_node_A_const_286; return tmp3.Invoke_O_O_O__O(tmp4, lang.IFn_Cast(t.F_ts).Invoke_O__O(p__2), lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_287, a__3, A_arbace_c2j_node_A_const_288)) } }
//line :314:1
	case 1013912038: if any(G__400000258__4_) == any(A_arbace_c2j_node_A_const_107) {



		return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_289, a__3, A_arbace_c2j_node_A_const_290) }
//line :314:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__400000258__4_))))) }








func A_arbace_c2j_node_qe_seq_tmp__400000224_A_New_O(p0 any) *A_arbace_c2j_node_qe_seq_tmp__400000224_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_tmp__400000224_A{}; t.Ctor_O(p0); return t }
//line :323:1
func (t *A_arbace_c2j_node_qe_seq_tmp__400000224_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :323:1
func (t *A_arbace_c2j_node_qe_seq_tmp__400000224_A) Invoke_O__O(self any) any { var root_1112 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_1113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1112, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1114 lang.IFn; if linked_1113 == nil { ifn_1114 = lang.IFn_Cast(root_1112) } else { ifn_1114 = nil }; var arg_1115 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_77, nil); var tmp2 any; var root_1116 any = A_arbace_c2j_node_A_const_9.GetRawRoot__O(); var linked_1117 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1116, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1118 lang.IFn; if linked_1117 == nil { ifn_1118 = lang.IFn_Cast(root_1116) } else { ifn_1118 = nil }; var arg_1119 any = t.F_n; var arg_1120 any = A_arbace_c2j_node_A_const_259.GetRawRoot__O(); if linked_1117 == nil { tmp2 = ifn_1118.Invoke_O_O__O(arg_1119, arg_1120) } else { tmp2 = linked_1117.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_1116, arg_1119, arg_1120) }; arg_1115 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_1113 == nil { return ifn_1114.Invoke_O__O(arg_1115) } else { return linked_1113.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1112, arg_1115) } }
func A_arbace_c2j_node_qe_seq_fn__400000228_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000228_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000228_A{}; t.Ctor_O_O(p0, p1); return t }
//line :324:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000228_A) Ctor_O_O(c__tmp, c__v any) { t.F_tmp = c__tmp; t.F_v = c__v }
//line :324:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000228_A) Invoke_O_O_O__O(self, p__400000226__1, p__400000227__2 any) any { var vec__400000229__3 any = p__400000226__1; var env__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000229__3, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000229__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__400000232__6 any = p__400000227__2; var s__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000232__6, lang.RT_IntCast_J__I_NoInit(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000232__6, lang.RT_IntCast_J__I_NoInit(1), nil); var r__9 any; var root_1128 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, A_arbace_c2j_node_qe_A_fn_class); var ifn_1130 lang.IFn; if
															linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = env__4; var arg_1132 any = t.F_v; var arg_1133 any = init__8; if linked_1129 == nil { r__9 = ifn_1130.Invoke_O_O_O__O(arg_1131, arg_1132, arg_1133) } else { r__9 = linked_1129.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1128, arg_1131, arg_1132, arg_1133) }; var tmp1 any; var and__1927000168__auto____10 any; var root_1134 any =
															A_arbace_c2j_node_A_const_43.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1136 lang.IFn; if
															linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = r__9; if linked_1135 == nil { and__1927000168__auto____10 = ifn_1136.Invoke_O__O(arg_1137) } else { and__1927000168__auto____10 = linked_1135.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1134, arg_1137) }; if jrt.J2g_Truth(and__1927000168__auto____10) { tmp1 = A_arbace_c2j_node_A_const_222.Invoke_O__O(r__9) } else { tmp1 = and__1927000168__auto____10 }; if /*line :326:1*/ jrt.J2g_Truth(tmp1) { var ts__10 any; var root_1138 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_1139 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1138, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1140 lang.IFn

		if linked_1139 == nil { ifn_1140 = lang.IFn_Cast(root_1138) } else { ifn_1140 = nil }; var arg_1141 any; var tmp2 any = A_arbace_c2j_node_qe_seq_fn__400000228_fn__400000235_A_New_O(t.F_tmp); var tmp3 *jrt.Class; var fncls__1143 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000228_fn__400000235_A_fn_class; if fncls__1143 == nil { var fncls__1143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_c2j_node_qe_seq_fn__400000228_fn__400000235_A_fn_class = fncls__1143d; tmp3 = fncls__1143d } else { tmp3 = fncls__1143 }; arg_1141 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1142 any = A_arbace_c2j_node_A_const_222.Invoke_O__O(r__9); if linked_1139 == nil { ts__10 = ifn_1140.Invoke_O_O__O(arg_1141, arg_1142) } else { ts__10 = linked_1139.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1138, arg_1141, arg_1142) }
//line :326:1
		var tmp4 any; var root_1148 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1149 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1148, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1150 lang.IFn


		if linked_1149 == nil { ifn_1150 = lang.IFn_Cast(root_1148) } else { ifn_1150 = nil }; var arg_1151 any = env__4; var arg_1152 any = s__7; var arg_1153 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_230, A_arbace_c2j_node_A_const_215, ts__10)); if linked_1149 == nil { tmp4 = ifn_1150.Invoke_O_O_O__O(arg_1151, arg_1152, arg_1153) } else { tmp4 = linked_1149.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1148, arg_1151, arg_1152, arg_1153) }
//line :326:1
		var tmp5 any = tmp4; var tmp6 any; var root_1154 any = A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1156 lang.IFn


		if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = binds__5; var arg_1158 any; var root_1159 any = A_arbace_c2j_node_A_const_262.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_interleave_A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = ts__10; var arg_1163 any = A_arbace_c2j_node_A_const_222.Invoke_O__O(r__9); if linked_1160 == nil { arg_1158 = ifn_1161.Invoke_O_O__O(arg_1162, arg_1163) } else { arg_1158 = linked_1160.(*aot_arbace_core.A_arbace_core_interleave_A).Invoke_O_O_O__O(root_1159, arg_1162, arg_1163) }; if linked_1155 == nil { tmp6 = ifn_1156.Invoke_O_O__O(arg_1157, arg_1158) } else { tmp6 = linked_1155.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1154, arg_1157, arg_1158) }
//line :326:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp5, tmp6) } else { var tmp7 any; var and__1927000168__auto____10_2 any; var root_1144 any = A_arbace_c2j_node_A_const_43.GetRawRoot__O(); var linked_1145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1144, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1146 lang.IFn



			if linked_1145 == nil { ifn_1146 = lang.IFn_Cast(root_1144) } else { ifn_1146 = nil }; var arg_1147 any = r__9; if linked_1145 == nil { and__1927000168__auto____10_2 = ifn_1146.Invoke_O__O(arg_1147) } else { and__1927000168__auto____10_2 = linked_1145.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1144, arg_1147) }; if jrt.J2g_Truth(and__1927000168__auto____10_2) { tmp7 = A_arbace_c2j_node_A_const_221.Invoke_O__O(r__9) } else { tmp7 = and__1927000168__auto____10_2 }
//line :326:1
			if jrt.J2g_Truth(tmp7) { var t__10 any = lang.IFn_Cast(t.F_tmp).Invoke__O(); var tmp8 any; var root_1164 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1164, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1166 lang.IFn




				if linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = env__4; var arg_1168 any = s__7; var arg_1169 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_213, A_arbace_c2j_node_A_const_231, t__10)); if linked_1165 == nil { tmp8 = ifn_1166.Invoke_O_O_O__O(arg_1167, arg_1168, arg_1169) } else { tmp8 = linked_1165.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1164, arg_1167, arg_1168, arg_1169) }
//line :326:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(binds__5, t__10, A_arbace_c2j_node_A_const_221.Invoke_O__O(r__9))) } else { if A_arbace_c2j_node_A_const_45 != nil { var t__10_2 any = lang.IFn_Cast(t.F_tmp).Invoke__O(); var tmp9 any; var root_1176 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1178 lang.IFn





					if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = env__4; var arg_1180 any = s__7; var arg_1181 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_131, A_arbace_c2j_node_A_const_231, t__10_2)); if linked_1177 == nil { tmp9 = ifn_1178.Invoke_O_O_O__O(arg_1179, arg_1180, arg_1181) } else { tmp9 = linked_1177.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1176, arg_1179, arg_1180, arg_1181) }
//line :326:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp9, lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(binds__5, t__10_2, r__9)) } else { return nil } } } }

func A_arbace_c2j_node_qe_seq_fn__400000228_fn__400000235_A_New_O(p0 any) *A_arbace_c2j_node_qe_seq_fn__400000228_fn__400000235_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000228_fn__400000235_A{}; t.Ctor_O(p0); return t }
//line :328:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000228_fn__400000235_A) Ctor_O(c__tmp any) { t.F_tmp = c__tmp }
//line :328:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000228_fn__400000235_A) Invoke_O_O__O(self, ___1 any) any { return lang.IFn_Cast(t.F_tmp).Invoke__O() }






func A_arbace_c2j_node_qe_seq_fn__400000238_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000238_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000238_A{}; t.Ctor_O_O(p0, p1); return t }
//line :335:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000238_A) Ctor_O_O(c__v, c__env any) { t.F_v = c__v; t.F_env = c__env }
//line :335:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000238_A) Invoke_O_O__O(self, p1__400000181_SHARP___1 any) any { var root_1215 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_1216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1215, A_arbace_c2j_node_qe_A_fn_class); var ifn_1217 lang.IFn; if linked_1216 == nil { ifn_1217 = lang.IFn_Cast(root_1215) } else { ifn_1217 = nil }; var arg_1218 any = t.F_env; var arg_1219 any = t.F_v; var arg_1220 any = p1__400000181_SHARP___1; if linked_1216 == nil { return ifn_1217.Invoke_O_O_O__O(arg_1218, arg_1219, arg_1220) } else { return linked_1216.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1215, arg_1218, arg_1219, arg_1220) } }

func A_arbace_c2j_node_qe_seq_fn__400000195_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000195_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000195_A{}; t.Ctor_O_O(p0, p1); return t }
//line :337:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000195_A) Ctor_O_O(c__env, c__v any) { t.F_env = c__env; t.F_v = c__v }
//line :337:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000195_A) Invoke_O_O__O(self, p1__400000182_SHARP___1 any) any { var root_976 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, A_arbace_c2j_node_qe_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = t.F_env; var arg_980 any = t.F_v; var arg_981 any = p1__400000182_SHARP___1; if linked_977 == nil { return ifn_978.Invoke_O_O_O__O(arg_979, arg_980, arg_981) } else { return linked_977.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_976, arg_979, arg_980, arg_981) } }




















func A_arbace_c2j_node_qe_seq_fn__400000216_A_New_O(p0 any) *A_arbace_c2j_node_qe_seq_fn__400000216_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000216_A{}; t.Ctor_O(p0); return t }
//line :358:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000216_A) Ctor_O(c__g any) { t.F_g = c__g }
//line :358:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000216_A) Invoke_O_O__O(self, base__1 any) any { var root_1078 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1080 lang.IFn; if linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_1082 any = A_arbace_c2j_node_A_const_9.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = t.F_g; var arg_1086 any = A_arbace_c2j_node_A_const_259.GetRawRoot__O(); if linked_1083 == nil { tmp2 = ifn_1084.Invoke_O_O__O(arg_1085, arg_1086) } else { tmp2 = linked_1083.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_1082, arg_1085, arg_1086) }; arg_1081 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, base__1, tmp2)).Ref(); if linked_1079 == nil { return ifn_1080.Invoke_O__O(arg_1081) } else { return linked_1079.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1078, arg_1081) } }











func A_arbace_c2j_node_qe_seq_fn__400000247_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000247_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000247_A{}; t.Ctor_O_O(p0, p1); return t }
//line :370:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000247_A) Ctor_O_O(c__env, c__v any) { t.F_env = c__env; t.F_v = c__v }
//line :370:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000247_A) Invoke_O_O__O(self, p__400000246__1 any) any { var vec__400000248__2 any = p__400000246__1; var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000248__2, lang.RT_IntCast_J__I_NoInit(0), nil); var init__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000248__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1271 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_1272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1271, A_arbace_c2j_node_qe_A_fn_class); var ifn_1273 lang.IFn; if linked_1272 == nil { ifn_1273 = lang.IFn_Cast(root_1271) } else { ifn_1273 = nil }; var arg_1274 any = t.F_env; var arg_1275 any = t.F_v; var arg_1276 any = init__4; if linked_1272 == nil { tmp1 = ifn_1273.Invoke_O_O_O__O(arg_1274, arg_1275, arg_1276) } else { tmp1 = linked_1272.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1271, arg_1274, arg_1275, arg_1276) }; return lang.Tuple_Create_O_O__IPersistentVector(s__3, tmp1) }
func A_arbace_c2j_node_qe_seq_fn__400000252_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000252_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000252_A{}; t.Ctor_O_O(p0, p1); return t }
//line :371:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000252_A) Ctor_O_O(c__env, c__v any) { t.F_env = c__env; t.F_v = c__v }
//line :371:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000252_A) Invoke_O_O__O(self, p1__400000183_SHARP___1 any) any { var root_1288 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_1289 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1288, A_arbace_c2j_node_qe_A_fn_class); var ifn_1290 lang.IFn; if linked_1289 == nil { ifn_1290 = lang.IFn_Cast(root_1288) } else { ifn_1290 = nil }; var arg_1291 any = t.F_env; var arg_1292 any = t.F_v; var arg_1293 any = p1__400000183_SHARP___1; if linked_1289 == nil { return ifn_1290.Invoke_O_O_O__O(arg_1291, arg_1292, arg_1293) } else { return linked_1289.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1288, arg_1291, arg_1292, arg_1293) } }


func A_arbace_c2j_node_qe_A_New() *A_arbace_c2j_node_qe_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_A{}; t.Ctor(); return t }
//line :374:1
func (t *A_arbace_c2j_node_qe_A) Ctor() {}
//line :374:1
func (t *A_arbace_c2j_node_qe_A) Invoke_O_O_O_O__O(self, env__0, v__1, t__2 any) any {


	var tmp1 any; var root_1320 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_1321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1320, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1322 lang.IFn
	if linked_1321 == nil { ifn_1322 = lang.IFn_Cast(root_1320) } else { ifn_1322 = nil }; var arg_1323 any = t__2; if linked_1321 == nil { tmp1 = ifn_1322.Invoke_O__O(arg_1323) } else { tmp1 = linked_1321.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1320, arg_1323) }
//line :377:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000408__auto____4 any = lang.IFn_Cast(env__0).Invoke_O__O(t__2)
		if jrt.J2g_Truth(temp__1927000408__auto____4) { var b__5 any = temp__1927000408__auto____4; var G__400000261__6_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__5)
			switch lang.Util_Hash_O__I_NoInit(G__400000261__6_) >> 0 & 3 { case 1: if any(G__400000261__6_) == any(A_arbace_c2j_node_A_const_213) {


				return A_arbace_c2j_node_A_const_231.Invoke_O__O(b__5) }
//line :379:1
			case 2: if any(G__400000261__6_) == any(A_arbace_c2j_node_A_const_131) {

				return A_arbace_c2j_node_A_const_231.Invoke_O__O(b__5) }
//line :379:1
			case 3: if any(G__400000261__6_) == any(A_arbace_c2j_node_A_const_155) {
				var tmp2 any; var root_1325 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1325, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1327 lang.IFn; if linked_1326 == nil { ifn_1327 = lang.IFn_Cast(root_1325) } else { ifn_1327 = nil }; var arg_1328 any = A_arbace_c2j_node_A_const_233.Invoke_O__O(v__1); var arg_1329 any = t__2; if linked_1326 == nil { tmp2 = ifn_1327.Invoke_O_O__O(arg_1328, arg_1329) } else { tmp2 = linked_1326.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1325, arg_1328, arg_1329) }; if jrt.J2g_Truth(tmp2) { return lang.RT_Get_O_O__O_NoInit(A_arbace_c2j_node_A_const_233.Invoke_O__O(v__1), t__2) } else { return A_arbace_c2j_node_A_const_170.Invoke_O__O(b__5) } }
//line :379:1
			default:}; return t__2 } else {
//line :378:1
				return t__2 } } else {
//line :377:1
					var tmp3 any; var root_1330 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1332 lang.IFn







					if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = t__2; if linked_1331 == nil { tmp3 = ifn_1332.Invoke_O__O(arg_1333) } else { tmp3 = linked_1331.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1330, arg_1333) }
//line :377:1
					if jrt.J2g_Truth(tmp3) {







						var root_1334 any = A_arbace_c2j_node_A_const_291.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, A_arbace_c2j_node_qe_seq_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = env__0; var arg_1338 any = v__1; var arg_1339 any = t__2; if linked_1335 == nil { return ifn_1336.Invoke_O_O_O__O(arg_1337, arg_1338, arg_1339) } else { return linked_1335.(*A_arbace_c2j_node_qe_seq_A).Invoke_O_O_O_O__O(root_1334, arg_1337, arg_1338, arg_1339) } } else {
//line :377:1
							var tmp4 any; var root_1340 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1342 lang.IFn








							if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = t__2; if linked_1341 == nil { tmp4 = ifn_1342.Invoke_O__O(arg_1343) } else { tmp4 = linked_1341.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1340, arg_1343) }
//line :377:1
							if jrt.J2g_Truth(tmp4) {








								var root_1344 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1344, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1346 lang.IFn; if linked_1345 == nil { ifn_1346 = lang.IFn_Cast(root_1344) } else { ifn_1346 = nil }; var arg_1347 any; var root_1349 any = A_arbace_c2j_node_A_const_217.GetRawRoot__O(); var linked_1350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1349, A_arbace_c2j_node_qe_elems_A_fn_class); var ifn_1351 lang.IFn; if linked_1350 == nil { ifn_1351 = lang.IFn_Cast(root_1349) } else { ifn_1351 = nil }; var arg_1352 any = env__0; var arg_1353 any = v__1; var arg_1354 any = t__2; if linked_1350 == nil { arg_1347 = ifn_1351.Invoke_O_O_O__O(arg_1352, arg_1353, arg_1354) } else { arg_1347 = linked_1350.(*A_arbace_c2j_node_qe_elems_A).Invoke_O_O_O_O__O(root_1349, arg_1352, arg_1353, arg_1354) }; var arg_1348 any = lang.RT_Meta_O__IPersistentMap_NoInit(t__2); if linked_1345 == nil { return ifn_1346.Invoke_O_O__O(arg_1347, arg_1348) } else { return linked_1345.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1344, arg_1347, arg_1348) } } else {
//line :377:1
									if A_arbace_c2j_node_A_const_45 != nil { return t__2 } else { return nil
									}
								}
						}
				}
}






func A_arbace_c2j_node_splits_A_New() *A_arbace_c2j_node_splits_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_splits_A{}; t.Ctor(); return t }
//line :389:1
func (t *A_arbace_c2j_node_splits_A) Ctor() {}
//line :389:1
func (t *A_arbace_c2j_node_splits_A) Invoke_O_O__O(self, d__0 any) any { var tested__2 any; var root_1355 any = A_arbace_c2j_node_A_const_251.GetRawRoot__O(); var linked_1356 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1355, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1357 lang.IFn; if


	linked_1356 == nil { ifn_1357 = lang.IFn_Cast(root_1355) } else { ifn_1357 = nil }; var arg_1358 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1356 == nil { tested__2 = ifn_1357.Invoke_O__O(arg_1358) } else { tested__2 = linked_1356.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1355, arg_1358) }; var body_w__3 /*line :389:1*/*A_arbace_c2j_node_splits_w__400000263_A = A_arbace_c2j_node_splits_w__400000263_A_New_O(tested__2); var w__3 any; var tmp1 *jrt.Class; var fncls__1418 *jrt.Class = A_arbace_c2j_node_splits_w__400000263_A_fn_class; if fncls__1418 == nil { var fncls__1418d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_c2j_node_splits_w__400000263_A_fn_class = fncls__1418d; tmp1 = fncls__1418d } else { tmp1 = fncls__1418 }; w__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_w__3), tmp1, nil);






	lang.IFn_Cast(w__3).Invoke_O__O(A_arbace_c2j_node_A_const_26.Invoke_O__O(d__0)); var root_1359 any =
	A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1359, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1361 lang.IFn; if linked_1360 == nil { ifn_1361 = lang.IFn_Cast(root_1359) } else { ifn_1361 = nil }; var arg_1362 any; var root_1363 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any; var tmp2 any = A_arbace_c2j_node_splits_fn__400000265_A_New_O(tested__2); var tmp3 *jrt.Class; var fncls__1377 *jrt.Class = A_arbace_c2j_node_splits_fn__400000265_A_fn_class; if fncls__1377 == nil { var fncls__1377d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_c2j_node_splits_fn__400000265_A_fn_class = fncls__1377d; tmp3 = fncls__1377d } else { tmp3 = fncls__1377 }; arg_1366 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_1367 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_1364 == nil { arg_1362 = ifn_1365.Invoke_O_O__O(arg_1366, arg_1367) } else { arg_1362 = linked_1364.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1363, arg_1366, arg_1367) }; if linked_1360 == nil { return ifn_1361.Invoke_O__O(arg_1362) } else { return linked_1360.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1359, arg_1362) } }
//line :393:1
func A_arbace_c2j_node_splits_w__400000263_A_New_O(p0 any) *A_arbace_c2j_node_splits_w__400000263_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_splits_w__400000263_A{}; t.Ctor_O(p0); return t }
//line :393:1
func (t *A_arbace_c2j_node_splits_w__400000263_A) Ctor_O(c__tested any) { t.F_tested = c__tested }
//line :393:1
func (t *A_arbace_c2j_node_splits_w__400000263_A) Invoke_O_O__O(self, t__1 any) any { var tmp1 any; var root_1378 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_1379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1378, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1380 lang.IFn; if linked_1379 == nil { ifn_1380 = lang.IFn_Cast(root_1378) } else { ifn_1380 = nil }; var arg_1381 any = t__1; if linked_1379 == nil { tmp1 = ifn_1380.Invoke_O__O(arg_1381) } else { tmp1 = linked_1379.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1378, arg_1381) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var and__1927000168__auto____2 bool; var tmp3 any = A_arbace_c2j_node_A_const_293; var tmp4 any; var root_1396 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, A_arbace_c2j_node_head_A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = t__1; if linked_1397 == nil { tmp4 = ifn_1398.Invoke_O__O(arg_1399) } else { tmp4 = linked_1397.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_1396, arg_1399) }; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4); if and__1927000168__auto____2 { var root_1400 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any; var root_1404 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = t__1; if linked_1405 == nil { arg_1403 = ifn_1406.Invoke_O__O(arg_1407) } else { arg_1403 = linked_1405.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1404, arg_1407) }; if linked_1401 == nil { tmp2 = ifn_1402.Invoke_O__O(arg_1403) } else { tmp2 = linked_1401.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1400, arg_1403) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp2) { var root_1408 any = A_arbace_c2j_node_A_const_9.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = t.F_tested; var arg_1412 any = A_arbace_c2j_node_A_const_7.GetRawRoot__O(); var arg_1413 any; var root_1414 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_1415 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1414, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1416 lang.IFn; if linked_1415 == nil { ifn_1416 = lang.IFn_Cast(root_1414) } else { ifn_1416 = nil }; var arg_1417 any = t__1; if linked_1415 == nil { arg_1413 = ifn_1416.Invoke_O__O(arg_1417) } else { arg_1413 = linked_1415.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1414, arg_1417) }; if linked_1409 == nil { ifn_1410.Invoke_O_O_O__O(arg_1411, arg_1412, arg_1413) } else { linked_1409.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1408, arg_1411, arg_1412, arg_1413) } }
											var root_1382 any = A_arbace_c2j_node_A_const_292.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_1384 lang.IFn; if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = self; var arg_1386 any = t__1; if linked_1383 == nil { return ifn_1384.Invoke_O_O__O(arg_1385, arg_1386) } else { return linked_1383.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_1382, arg_1385, arg_1386) } } else {
//line :393:1
		var tmp5 any; var root_1387 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_1388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1387, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1389 lang.IFn

		if linked_1388 == nil { ifn_1389 = lang.IFn_Cast(root_1387) } else { ifn_1389 = nil }; var arg_1390 any = t__1; if linked_1388 == nil { tmp5 = ifn_1389.Invoke_O__O(arg_1390) } else { tmp5 = linked_1388.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1387, arg_1390) }
//line :393:1
		if jrt.J2g_Truth(tmp5) {

			var root_1391 any = A_arbace_c2j_node_A_const_292.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = self; var arg_1395 any = t__1; if linked_1392 == nil { return ifn_1393.Invoke_O_O__O(arg_1394, arg_1395) } else { return linked_1392.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_1391, arg_1394, arg_1395) } } else {
//line :393:1
				return nil } } }



func A_arbace_c2j_node_splits_fn__400000265_A_New_O(p0 any) *A_arbace_c2j_node_splits_fn__400000265_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_splits_fn__400000265_A{}; t.Ctor_O(p0); return t }
//line :397:1
func (t *A_arbace_c2j_node_splits_fn__400000265_A) Ctor_O(c__tested any) { t.F_tested = c__tested }
//line :397:1
func (t *A_arbace_c2j_node_splits_fn__400000265_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 any; var root_1368 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any; var root_1373 any = A_arbace_c2j_node_A_const_5.GetRawRoot__O(); var linked_1374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1373, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1375 lang.IFn; if linked_1374 == nil { ifn_1375 = lang.IFn_Cast(root_1373) } else { ifn_1375 = nil }; var arg_1376 any = t.F_tested; if linked_1374 == nil { arg_1371 = ifn_1375.Invoke_O__O(arg_1376) } else { arg_1371 = linked_1374.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1373, arg_1376) }; var arg_1372 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); if linked_1369 == nil { tmp1 = ifn_1370.Invoke_O_O__O(arg_1371, arg_1372) } else { tmp1 = linked_1369.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1368, arg_1371, arg_1372) }; if jrt.J2g_Truth(tmp1) { return A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1) } else { return nil } }

func A_arbace_c2j_node_uses_many_QMARK__A_New() *A_arbace_c2j_node_uses_many_QMARK__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_uses_many_QMARK__A{}; t.Ctor(); return t }
//line :399:1
func (t *A_arbace_c2j_node_uses_many_QMARK__A) Ctor() {}
//line :399:1
func (t *A_arbace_c2j_node_uses_many_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var r__2 any; var root_1419 any = A_arbace_c2j_node_A_const_251.GetRawRoot__O(); var linked_1420 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1419, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1421 lang.IFn; if
											linked_1420 == nil { ifn_1421 = lang.IFn_Cast(root_1419) } else { ifn_1421 = nil }; var arg_1422 any = jrt.Boolean_FALSE.Ref(); if linked_1420 == nil { r__2 = ifn_1421.Invoke_O__O(arg_1422) } else { r__2 = linked_1420.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1419, arg_1422) }; var body_w__3 /*line :399:1*/*A_arbace_c2j_node_uses_many_QMARK__w__400000268_A = A_arbace_c2j_node_uses_many_QMARK__w__400000268_A_New_O(r__2); var w__3 any; var tmp1 *jrt.Class; var fncls__1454 *jrt.Class = A_arbace_c2j_node_uses_many_QMARK__w__400000268_A_fn_class; if fncls__1454 == nil { var fncls__1454d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_c2j_node_uses_many_QMARK__w__400000268_A_fn_class = fncls__1454d; tmp1 = fncls__1454d } else { tmp1 = fncls__1454 }; w__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_w__3), tmp1, nil);



	lang.IFn_Cast(w__3).Invoke_O__O(A_arbace_c2j_node_A_const_26.Invoke_O__O(d__0)); var root_1423 any = /*line :400:1*/A_arbace_c2j_node_A_const_5.GetRawRoot__O(); var linked_1424 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1423, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1425 lang.IFn; if linked_1424 == nil { ifn_1425 = lang.IFn_Cast(root_1423) } else { ifn_1425 = nil }; var arg_1426 any = r__2; if linked_1424 == nil { return ifn_1425.Invoke_O__O(arg_1426) } else { return linked_1424.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1423, arg_1426) } }
func A_arbace_c2j_node_uses_many_QMARK__w__400000268_A_New_O(p0 any) *A_arbace_c2j_node_uses_many_QMARK__w__400000268_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_uses_many_QMARK__w__400000268_A{}; t.Ctor_O(p0); return t }
//line :401:1
func (t *A_arbace_c2j_node_uses_many_QMARK__w__400000268_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :401:1
func (t *A_arbace_c2j_node_uses_many_QMARK__w__400000268_A) Invoke_O_O__O(self, t__1 any) any { var tmp1 any; var root_1427 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = t__1; if linked_1428 == nil { tmp1 = ifn_1429.Invoke_O__O(arg_1430) } else { tmp1 = linked_1428.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1427, arg_1430) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_c2j_node_A_const_294; var tmp3 any; var root_1445 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_1446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1445, A_arbace_c2j_node_head_A_fn_class); var ifn_1447 lang.IFn; if linked_1446 == nil { ifn_1447 = lang.IFn_Cast(root_1445) } else { ifn_1447 = nil }; var arg_1448 any = t__1; if linked_1446 == nil { tmp3 = ifn_1447.Invoke_O__O(arg_1448) } else { tmp3 = linked_1446.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_1445, arg_1448) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var root_1449 any = A_arbace_c2j_node_A_const_295.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_1451 lang.IFn; if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = t.F_r; var arg_1453 any = jrt.Boolean_TRUE.Ref(); if linked_1450 == nil { ifn_1451.Invoke_O_O__O(arg_1452, arg_1453) } else { linked_1450.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_1449, arg_1452, arg_1453) } }; var root_1431 any = A_arbace_c2j_node_A_const_292.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = self; var arg_1435 any = t__1; if linked_1432 == nil { return ifn_1433.Invoke_O_O__O(arg_1434, arg_1435) } else { return linked_1432.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_1431, arg_1434, arg_1435) } } else { var tmp4 any; var root_1436 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_1437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1436, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1438 lang.IFn
												if linked_1437 == nil { ifn_1438 = lang.IFn_Cast(root_1436) } else { ifn_1438 = nil }; var arg_1439 any = t__1; if linked_1437 == nil { tmp4 = ifn_1438.Invoke_O__O(arg_1439) } else { tmp4 = linked_1437.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1436, arg_1439) }
//line :401:1
	if jrt.J2g_Truth(tmp4) {
		var root_1440 any = A_arbace_c2j_node_A_const_292.GetRawRoot__O(); var linked_1441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1440, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_1442 lang.IFn; if linked_1441 == nil { ifn_1442 = lang.IFn_Cast(root_1440) } else { ifn_1442 = nil }; var arg_1443 any = self; var arg_1444 any = t__1; if linked_1441 == nil { return ifn_1442.Invoke_O_O__O(arg_1443, arg_1444) } else { return linked_1441.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_1440, arg_1443, arg_1444) } } else {
//line :401:1
			return nil } } }




func A_arbace_c2j_node_camel_A_New() *A_arbace_c2j_node_camel_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_camel_A{}; t.Ctor(); return t }
//line :406:1
func (t *A_arbace_c2j_node_camel_A) Ctor() {}
//line :406:1
func (t *A_arbace_c2j_node_camel_A) Invoke_O_O__O(self, s__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_1455 any = A_arbace_c2j_node_A_const_296.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_string.A_arbace_string_upper_case_A_fn_class); var ifn_1457 lang.IFn; if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any; var root_1459 any = A_arbace_c2j_node_A_const_297.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1461 lang.IFn; if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any; var root_1465 any = A_arbace_c2j_node_A_const_187.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = s__0; if linked_1466 == nil { arg_1462 = ifn_1467.Invoke_O__O(arg_1468) } else { arg_1462 = linked_1466.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1465, arg_1468) }; var arg_1463 any = A_arbace_c2j_node_A_const_252; var arg_1464 any = A_arbace_c2j_node_A_const_298; if linked_1460 == nil { arg_1458 = ifn_1461.Invoke_O_O_O__O(arg_1462, arg_1463, arg_1464) } else { arg_1458 = linked_1460.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1459, arg_1462, arg_1463, arg_1464) }; if linked_1456 == nil { tmp2 = ifn_1457.Invoke_O__O(arg_1458) } else { tmp2 = linked_1456.(*aot_arbace_string.A_arbace_string_upper_case_A).Invoke_O_O__O(root_1455, arg_1458) }; var tmp3 any = tmp2; var tmp4 any; var root_1469 any = A_arbace_c2j_node_A_const_297.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any; var root_1474 any = A_arbace_c2j_node_A_const_187.GetRawRoot__O(); var linked_1475 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1474, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1476 lang.IFn; if linked_1475 == nil { ifn_1476 = lang.IFn_Cast(root_1474) } else { ifn_1476 = nil }; var arg_1477 any = s__0; if linked_1475 == nil { arg_1472 = ifn_1476.Invoke_O__O(arg_1477) } else { arg_1472 = linked_1475.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1474, arg_1477) }; var arg_1473 any = A_arbace_c2j_node_A_const_298; if linked_1470 == nil { tmp4 = ifn_1471.Invoke_O_O__O(arg_1472, arg_1473) } else { tmp4 = linked_1470.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1469, arg_1472, arg_1473) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref() }

func A_arbace_c2j_node_sym_occurs_QMARK__A_New() *A_arbace_c2j_node_sym_occurs_QMARK__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_sym_occurs_QMARK__A{}; t.Ctor(); return t }
//line :408:1
func (t *A_arbace_c2j_node_sym_occurs_QMARK__A) Ctor() {}
//line :408:1
func (t *A_arbace_c2j_node_sym_occurs_QMARK__A) Invoke_O_O_O__O(self, s__0, f__1 any) any {
	var tmp1 any; var root_1478 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any = f__1; if linked_1479 == nil { tmp1 = ifn_1480.Invoke_O__O(arg_1481) } else { tmp1 = linked_1479.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1478, arg_1481) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(s__0, f__1)).Ref() } else { var tmp2 any; var or__1927000174__auto____3 any; var root_1482 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1484 lang.IFn
		if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = f__1; if linked_1483 == nil { or__1927000174__auto____3 = ifn_1484.Invoke_O__O(arg_1485) } else { or__1927000174__auto____3 = linked_1483.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1482, arg_1485) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_1486 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1486, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any = f__1; if linked_1487 == nil { tmp2 = ifn_1488.Invoke_O__O(arg_1489) } else { tmp2 = linked_1487.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1486, arg_1489) } }
//line :409:1
		if jrt.J2g_Truth(tmp2) {
			var root_1490 any = A_arbace_c2j_node_A_const_48.GetRawRoot__O(); var linked_1491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1490, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1492 lang.IFn; if linked_1491 == nil { ifn_1492 = lang.IFn_Cast(root_1490) } else { ifn_1492 = nil }; var arg_1493 any; var tmp3 any = A_arbace_c2j_node_sym_occurs_QMARK__fn__400000273_A_New_O(s__0); var tmp4 *jrt.Class; var fncls__1500 *jrt.Class = A_arbace_c2j_node_sym_occurs_QMARK__fn__400000273_A_fn_class; if fncls__1500 == nil { var fncls__1500d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_c2j_node_sym_occurs_QMARK__fn__400000273_A_fn_class = fncls__1500d; tmp4 = fncls__1500d } else { tmp4 = fncls__1500 }; arg_1493 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_1494 any = f__1; if linked_1491 == nil { return ifn_1492.Invoke_O_O__O(arg_1493, arg_1494) } else { return linked_1491.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1490, arg_1493, arg_1494) } } else {
//line :409:1
				if A_arbace_c2j_node_A_const_45 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil } } } }
func A_arbace_c2j_node_sym_occurs_QMARK__fn__400000273_A_New_O(p0 any) *A_arbace_c2j_node_sym_occurs_QMARK__fn__400000273_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_sym_occurs_QMARK__fn__400000273_A{}; t.Ctor_O(p0); return t }
//line :410:1
func (t *A_arbace_c2j_node_sym_occurs_QMARK__fn__400000273_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :410:1
func (t *A_arbace_c2j_node_sym_occurs_QMARK__fn__400000273_A) Invoke_O_O__O(self, p1__400000272_SHARP___1 any) any { var root_1495 any = A_arbace_c2j_node_A_const_299.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1495, A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = t.F_s; var arg_1499 any = p1__400000272_SHARP___1; if linked_1496 == nil { return ifn_1497.Invoke_O_O__O(arg_1498, arg_1499) } else { return linked_1496.(*A_arbace_c2j_node_sym_occurs_QMARK__A).Invoke_O_O_O__O(root_1495, arg_1498, arg_1499) } }


func A_arbace_c2j_node_tag_sym_A_New() *A_arbace_c2j_node_tag_sym_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_tag_sym_A{}; t.Ctor(); return t }
//line :413:1
func (t *A_arbace_c2j_node_tag_sym_A) Ctor() {}
//line :413:1
func (t *A_arbace_c2j_node_tag_sym_A) Invoke_O_O_O__O(self, s__0, t__1 any) any { var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z_NoInit(t__1, nil); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(t__1, A_arbace_c2j_node_A_const_300) }; if tmp1 { return s__0 } else { return lang.IFn_Cast(A_arbace_c2j_node_A_const_301.GetRawRoot__O()).Invoke_O_O_O_O__O(s__0, A_arbace_c2j_node_A_const_14.GetRawRoot__O(), A_arbace_c2j_node_A_const_302, t__1) } }

func A_arbace_c2j_node_variant_class_A_New() *A_arbace_c2j_node_variant_class_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_A{}; t.Ctor(); return t }
//line :415:1
func (t *A_arbace_c2j_node_variant_class_A) Ctor() {}
//line :415:1
func (t *A_arbace_c2j_node_variant_class_A) Invoke_O_O_O__O(self, d__0, v__1 any) any { var env__3 any; var root_1508 any = A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_1509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1508, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1510 lang.IFn; if



	linked_1509 == nil { ifn_1510 = lang.IFn_Cast(root_1508) } else { ifn_1510 = nil }; var arg_1511 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1512 any; var root_1513 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1514 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1513, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1515 lang.IFn; if linked_1514 == nil { ifn_1515 = lang.IFn_Cast(root_1513) } else { ifn_1515 = nil }; var arg_1516 any; var tmp1 any = A_arbace_c2j_node_variant_class_fn__400000277_A_New(); var tmp2 *jrt.Class; var fncls__1527 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000277_A_fn_class; if fncls__1527 == nil { var fncls__1527d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_c2j_node_variant_class_fn__400000277_A_fn_class = fncls__1527d; tmp2 = fncls__1527d } else { tmp2 = fncls__1527 }; arg_1516 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1517 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_1514 == nil { arg_1512 = ifn_1515.Invoke_O_O__O(arg_1516, arg_1517) } else { arg_1512 = linked_1514.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1513, arg_1516, arg_1517) }; if linked_1509 == nil { env__3 = ifn_1510.Invoke_O_O__O(arg_1511, arg_1512) } else { env__3 = linked_1509.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1508, arg_1511, arg_1512) }; var chans__4 any; if






	jrt.J2g_Truth(A_arbace_c2j_node_A_const_176.Invoke_O__O(v__1)) {
		if jrt.J2g_Truth(A_arbace_c2j_node_A_const_73.Invoke_O__O(v__1)) { chans__4 = A_arbace_c2j_node_A_const_309 } else { var root_1528 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1528, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1530 lang.IFn; if linked_1529 == nil { ifn_1530 = lang.IFn_Cast(root_1528) } else { ifn_1530 = nil }; var arg_1531 any; var root_1532 any = A_arbace_c2j_node_A_const_310.GetRawRoot__O(); var linked_1533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1532, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1534 lang.IFn; if linked_1533 == nil { ifn_1534 = lang.IFn_Cast(root_1532) } else { ifn_1534 = nil }; var tmp3 *lang.Keyword = A_arbace_c2j_node_A_const_247; var arg_1535 any = tmp3.Invoke_O__O(A_arbace_c2j_node_A_const_176.Invoke_O__O(v__1)); if linked_1533 == nil { arg_1531 = ifn_1534.Invoke_O__O(arg_1535) } else { arg_1531 = linked_1533.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1532, arg_1535) }; if linked_1529 == nil { chans__4 = ifn_1530.Invoke_O__O(arg_1531) } else { chans__4 = linked_1529.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1528, arg_1531) } } } else {
//line :426:1
			var tmp4 *lang.Keyword = A_arbace_c2j_node_A_const_311; var or__1927000174__auto____4 any = tmp4.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0))

			if jrt.J2g_Truth(or__1927000174__auto____4) { chans__4 = or__1927000174__auto____4 } else { chans__4 = A_arbace_c2j_node_A_const_312 } }; var domain__5 any = /*line :415:1*/A_arbace_c2j_node_A_const_313.Invoke_O__O(v__1); var method__6 any; var tmp5 any = A_arbace_c2j_node_variant_class_method__400000280_A_New_O_O_O_O(d__0, env__3, v__1, domain__5); var tmp6 *jrt.Class; var fncls__1601 *jrt.Class = A_arbace_c2j_node_variant_class_method__400000280_A_fn_class; if














	fncls__1601 == nil { var fncls__1601d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_c2j_node_variant_class_method__400000280_A_fn_class = fncls__1601d; tmp6 = fncls__1601d } else { tmp6 = fncls__1601 }; method__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var methods__7 any; var root_1602 any = /*line :415:1*/A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1604 lang.IFn; if



























	linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any; var root_1606 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_1607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1606, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1608 lang.IFn; if linked_1607 == nil { ifn_1608 = lang.IFn_Cast(root_1606) } else { ifn_1608 = nil }; var arg_1609 any = method__6; var arg_1610 any = chans__4; if linked_1607 == nil { arg_1605 = ifn_1608.Invoke_O_O__O(arg_1609, arg_1610) } else { arg_1605 = linked_1607.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1606, arg_1609, arg_1610) }; if linked_1603 == nil { methods__7 = ifn_1604.Invoke_O__O(arg_1605) } else { methods__7 = linked_1603.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1602, arg_1605) }; var cb__8 any; var root_1611 any = /*line :415:1*/A_arbace_c2j_node_A_const_327.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, A_arbace_c2j_node_children_bind_A_fn_class); var ifn_1613 lang.IFn; if




























	linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any = d__0; if linked_1612 == nil { cb__8 = ifn_1613.Invoke_O__O(arg_1614) } else { cb__8 = linked_1612.(*A_arbace_c2j_node_children_bind_A).Invoke_O_O__O(root_1611, arg_1614) }; var conv__9 any; if
	jrt.J2g_Truth(cb__8) { var tmp7 *lang.Keyword = A_arbace_c2j_node_A_const_328; var tmp8 any; var root_1615 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_1616 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1615, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1617 lang.IFn; if linked_1616 == nil { ifn_1617 = lang.IFn_Cast(root_1615) } else { ifn_1617 = nil }; var arg_1618 any = A_arbace_c2j_node_A_const_241.GetRawRoot__O(); var arg_1619 any; var root_1620 any = A_arbace_c2j_node_A_const_329.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1624 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(cb__8); if linked_1621 == nil { arg_1619 = ifn_1622.Invoke_O_O__O(A_arbace_c2j_node_A_const_25, arg_1624) } else { arg_1619 = linked_1621.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1620, 2, A_arbace_c2j_node_A_const_25, arg_1624) }; if linked_1616 == nil { tmp8 = ifn_1617.Invoke_O_O__O(arg_1618, arg_1619) } else { tmp8 = linked_1616.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1615, arg_1618, arg_1619) }; conv__9 = tmp7.Invoke_O__O(tmp8) } else { conv__9 = nil }; var fields__10 any; var root_1625 any = /*line :415:1*/A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1625, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1627 lang.IFn; if































	linked_1626 == nil { ifn_1627 = lang.IFn_Cast(root_1625) } else { ifn_1627 = nil }; var arg_1628 any; var root_1629 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1629, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any; if
	jrt.J2g_Truth(domain__5) { var tmp9 any = A_arbace_c2j_node_A_const_330; var tmp10 any; var root_1634 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1634, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1636 lang.IFn; if linked_1635 == nil { ifn_1636 = lang.IFn_Cast(root_1634) } else { ifn_1636 = nil }; var arg_1637 any = A_arbace_c2j_node_A_const_331; var arg_1638 any = A_arbace_c2j_node_A_const_332; if linked_1635 == nil { tmp10 = ifn_1636.Invoke_O_O__O(arg_1637, arg_1638) } else { tmp10 = linked_1635.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1634, arg_1637, arg_1638) }; arg_1632 = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, A_arbace_c2j_node_A_const_333, A_arbace_c2j_node_A_const_334))) } else { arg_1632 = nil }; var arg_1633 any; var tmp11 lang.IFn = /*line :447:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_node_variant_class_fn__400000293_A_New_O_O_O(conv__9, methods__7, v__1); var tmp13 *jrt.Class; var fncls__1730 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000293_A_fn_class; if

	fncls__1730 == nil { var fncls__1730d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_c2j_node_variant_class_fn__400000293_A_fn_class = fncls__1730d; tmp13 = fncls__1730d } else { tmp13 = fncls__1730 }; arg_1633 = tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0)); if /*line :447:1*/ linked_1630 == nil { arg_1628 = ifn_1631.Invoke_O_O__O(arg_1632, arg_1633) } else { arg_1628 = linked_1630.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1629, arg_1632, arg_1633) }; if linked_1626 == nil { fields__10 = ifn_1627.Invoke_O__O(arg_1628) } else { fields__10 = linked_1626.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1625, arg_1628) }; var bare__11 any; var tmp14 any = /*line :415:1*/A_arbace_c2j_node_variant_class_bare__400000300_A_New(); var tmp15 *jrt.Class; var fncls__1736 *jrt.Class = A_arbace_c2j_node_variant_class_bare__400000300_A_fn_class; if


















































	fncls__1736 == nil { var fncls__1736d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_c2j_node_variant_class_bare__400000300_A_fn_class = fncls__1736d; tmp15 = fncls__1736d } else { tmp15 = fncls__1736 }; bare__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp16 lang.IFn = /*line :415:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp18 any = A_arbace_c2j_node_A_const_355; var tmp19 any; var root_1744 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1746 lang.IFn; if




















































	linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any; var root_1749 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_1750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1749, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1751 lang.IFn; if linked_1750 == nil { ifn_1751 = lang.IFn_Cast(root_1749) } else { ifn_1751 = nil }; var arg_1752 any = A_arbace_c2j_node_A_const_321.Invoke_O__O(v__1); if linked_1750 == nil { arg_1747 = ifn_1751.Invoke_O__O(arg_1752) } else { arg_1747 = linked_1750.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1749, arg_1752) }; var arg_1748 any = A_arbace_c2j_node_A_const_356; if linked_1745 == nil { tmp19 = ifn_1746.Invoke_O_O__O(arg_1747, arg_1748) } else { tmp19 = linked_1745.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1744, arg_1747, arg_1748) }; var tmp20 any = /*line :415:1*/tmp17.Invoke_O_O_O_O__O(tmp18, tmp19, A_arbace_c2j_node_A_const_357, A_arbace_c2j_node_A_const_358); var tmp21 any; var root_1753 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1753, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1755 lang.IFn; if






















































	linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any; var tmp22 any = A_arbace_c2j_node_variant_class_fn__400000303_A_New(); var tmp23 *jrt.Class; var fncls__1783 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000303_A_fn_class; if fncls__1783 == nil { var fncls__1783d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_c2j_node_variant_class_fn__400000303_A_fn_class = fncls__1783d; tmp23 = fncls__1783d } else { tmp23 = fncls__1783 }; arg_1756 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_1757 any = fields__10; if linked_1754 == nil { tmp21 = ifn_1755.Invoke_O_O__O(arg_1756, arg_1757) } else { tmp21 = linked_1754.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1753, arg_1756, arg_1757) }; var tmp24 any = tmp21; var tmp25 any; var root_1784 any = /*line :415:1*/A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_1785 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1784, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1786 lang.IFn; if























































	linked_1785 == nil { ifn_1786 = lang.IFn_Cast(root_1784) } else { ifn_1786 = nil }; var arg_1787 any = A_arbace_c2j_node_A_const_362; var arg_1788 any; var root_1790 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any; var root_1795 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1795, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1797 lang.IFn; if linked_1796 == nil { ifn_1797 = lang.IFn_Cast(root_1795) } else { ifn_1797 = nil }; var arg_1798 any; var root_1799 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_1800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1799, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1801 lang.IFn; if linked_1800 == nil { ifn_1801 = lang.IFn_Cast(root_1799) } else { ifn_1801 = nil }; var arg_1802 any = A_arbace_c2j_node_A_const_363; var arg_1803 any; var root_1804 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1804, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1806 lang.IFn; if linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any = A_arbace_c2j_node_A_const_330; var arg_1808 any = fields__10; if linked_1805 == nil { arg_1803 = ifn_1806.Invoke_O_O__O(arg_1807, arg_1808) } else { arg_1803 = linked_1805.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1804, arg_1807, arg_1808) }; if linked_1800 == nil { arg_1798 = ifn_1801.Invoke_O_O__O(arg_1802, arg_1803) } else { arg_1798 = linked_1800.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1799, arg_1802, arg_1803) }; if linked_1796 == nil { arg_1793 = ifn_1797.Invoke_O__O(arg_1798) } else { arg_1793 = linked_1796.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1795, arg_1798) }; var arg_1794 any = A_arbace_c2j_node_A_const_364; if linked_1791 == nil { arg_1788 = ifn_1792.Invoke_O_O__O(arg_1793, arg_1794) } else { arg_1788 = linked_1791.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1790, arg_1793, arg_1794) }; var arg_1789 any; var root_1809 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1811 lang.IFn; if
	linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any; var tmp26 any = A_arbace_c2j_node_variant_class_fn__400000308_A_New_O(bare__11); var tmp27 *jrt.Class; var fncls__1834 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000308_A_fn_class; if fncls__1834 == nil { var fncls__1834d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_c2j_node_variant_class_fn__400000308_A_fn_class = fncls__1834d; tmp27 = fncls__1834d } else { tmp27 = fncls__1834 }; arg_1812 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var arg_1813 any = fields__10; if linked_1810 == nil { arg_1789 = ifn_1811.Invoke_O_O__O(arg_1812, arg_1813) } else { arg_1789 = linked_1810.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1809, arg_1812, arg_1813) }; if /*line :471:1*/ linked_1785 == nil { tmp25 = ifn_1786.Invoke_O_O_O__O(arg_1787, arg_1788, arg_1789) } else { tmp25 = linked_1785.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1784, arg_1787, arg_1788, arg_1789) }; return /*line :415:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp16.Invoke_O_O_O_O__O(tmp20, tmp24, lang.Tuple_Create_O__IPersistentVector(tmp25), methods__7), fields__10) }



func A_arbace_c2j_node_variant_class_fn__400000277_A_New() *A_arbace_c2j_node_variant_class_fn__400000277_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000277_A{}; t.Ctor(); return t }
//line :419:1
func (t *A_arbace_c2j_node_variant_class_fn__400000277_A) Ctor() {}
//line :419:1
func (t *A_arbace_c2j_node_variant_class_fn__400000277_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp2 any; var G__400000278__2_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__1); L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__400000278__2_) >> 8 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__400000278__2_, A_arbace_c2j_node_A_const_303) { tmp2 = A_arbace_c2j_node_A_const_304; break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__400000278__2_, A_arbace_c2j_node_A_const_305) { var tmp3 any = A_arbace_c2j_node_A_const_20; var tmp4 any = A_arbace_c2j_node_A_const_155; var tmp5 any = A_arbace_c2j_node_A_const_170; var tmp6 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp7 any = A_arbace_c2j_node_A_const_161; var tmp8 any; var root_1519 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1519, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1521 lang.IFn


	if linked_1520 == nil { ifn_1521 = lang.IFn_Cast(root_1519) } else { ifn_1521 = nil }; var arg_1522 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1520 == nil { tmp8 = ifn_1521.Invoke_O__O(arg_1522) } else { tmp8 = linked_1520.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1519, arg_1522) }
//line :419:1
	tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8)); break L1 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000278__2_, A_arbace_c2j_node_A_const_306) { var tmp9 any = A_arbace_c2j_node_A_const_20; var tmp10 any = A_arbace_c2j_node_A_const_180; var tmp11 any = A_arbace_c2j_node_A_const_170; tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1))); break L1 }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__400000278__2_, A_arbace_c2j_node_A_const_307) { var tmp12 any = A_arbace_c2j_node_A_const_20; var tmp13 any = A_arbace_c2j_node_A_const_126; var tmp14 any = A_arbace_c2j_node_A_const_170; tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1))); break L1 }; case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__400000278__2_, A_arbace_c2j_node_A_const_308) { var tmp15 any = A_arbace_c2j_node_A_const_20; var tmp16 any = A_arbace_c2j_node_A_const_155; var tmp17 any = A_arbace_c2j_node_A_const_170; var tmp18 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp19 any = A_arbace_c2j_node_A_const_161; var tmp20 any; var root_1523 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1525 lang.IFn


		if linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1524 == nil { tmp20 = ifn_1525.Invoke_O__O(arg_1526) } else { tmp20 = linked_1524.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1523, arg_1526) }
//line :419:1
		tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20)); break L1 }; default:}; tmp2 = nil}; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }










func A_arbace_c2j_node_variant_class_method__400000280_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variant_class_method__400000280_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_method__400000280_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :430:1
func (t *A_arbace_c2j_node_variant_class_method__400000280_A) Ctor_O_O_O_O(c__d, c__env, c__v, c__domain any) { t.F_d = c__d; t.F_env = c__env; t.F_v = c__v; t.F_domain = c__domain }
//line :430:1
func (t *A_arbace_c2j_node_variant_class_method__400000280_A) Invoke_O_O__O(self, c__1 any) any { var vec__400000281__2 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_255.GetRawRoot__O()).Invoke_O__O(c__1); var mn__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000281__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rt__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000281__2, lang.RT_IntCast_J__I_NoInit(1), nil); var params__5 any; var tmp1 any = A_arbace_c2j_node_A_const_322; var tmp2 any; var root_1580 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1580, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1582 lang.IFn; if

	linked_1581 == nil { ifn_1582 = lang.IFn_Cast(root_1580) } else { ifn_1582 = nil }; var arg_1583 any = A_arbace_c2j_node_A_const_323; var arg_1584 any = A_arbace_c2j_node_A_const_324; if linked_1581 == nil { tmp2 = ifn_1582.Invoke_O_O__O(arg_1583, arg_1584) } else { tmp2 = linked_1581.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1580, arg_1583, arg_1584) }; params__5 = /*line :430:1*/lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2); var try_qe__6 any; var tmp3 any = A_arbace_c2j_node_variant_class_method__400000280_try_qe__400000284_A_New_O_O(t.F_d, t.F_env); var tmp4 *jrt.Class; var fncls__1550 *jrt.Class = A_arbace_c2j_node_variant_class_method__400000280_try_qe__400000284_A_fn_class; if


	fncls__1550 == nil { var fncls__1550d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_c2j_node_variant_class_method__400000280_try_qe__400000284_A_fn_class = fncls__1550d; tmp4 = fncls__1550d } else { tmp4 = fncls__1550 }; try_qe__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var body__7 any; if

	jrt.J2g_Truth(t.F_domain) { var cases__7 any; var root_1551 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1551, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1553 lang.IFn
		if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any; var tmp5 any = A_arbace_c2j_node_variant_class_method__400000280_fn__400000287_A_New_O_O_O(c__1, try_qe__6, t.F_v); var tmp6 *jrt.Class; var fncls__1564 *jrt.Class = A_arbace_c2j_node_variant_class_method__400000280_fn__400000287_A_fn_class; if fncls__1564 == nil { var fncls__1564d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_c2j_node_variant_class_method__400000280_fn__400000287_A_fn_class = fncls__1564d; tmp6 = fncls__1564d } else { tmp6 = fncls__1564 }; arg_1554 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1555 any = t.F_domain; if linked_1552 == nil { cases__7 = ifn_1553.Invoke_O_O__O(arg_1554, arg_1555) } else { cases__7 = linked_1552.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1551, arg_1554, arg_1555) }
		var tmp7 any; var root_1565 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1565, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1567 lang.IFn; if linked_1566 == nil { ifn_1567 = lang.IFn_Cast(root_1565) } else { ifn_1567 = nil }; var arg_1568 any = cases__7; if linked_1566 == nil { tmp7 = ifn_1567.Invoke_O__O(arg_1568) } else { tmp7 = linked_1566.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1565, arg_1568) }; if jrt.J2g_Truth(tmp7) {
			var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_node_A_const_319; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_node_A_const_320; body__7 = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_316, A_arbace_c2j_node_A_const_317), lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_318.GetRawRoot__O(), cases__7), lang.Tuple_Create_O__IPersistentVector(tmp8.Invoke_O_O__O(tmp9, tmp10.Invoke_O_O__O(tmp11, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_321.Invoke_O__O(t.F_v), nil)).Ref())))) } else {
//line :437:1
				body__7 = nil } } else {


					var tmp12 lang.IFn = lang.IFn_Cast(try_qe__6); var tmp13 any; var root_1585 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = t.F_v; var arg_1589 any = A_arbace_c2j_node_A_const_167; var arg_1590 any = c__1; if linked_1586 == nil { tmp13 = ifn_1587.Invoke_O_O_O__O(arg_1588, arg_1589, arg_1590) } else { tmp13 = linked_1586.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1585, arg_1588, arg_1589, arg_1590) }; body__7 = tmp12.Invoke_O__O(tmp13) }; if
	jrt.J2g_Truth(body__7) {
		var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_node_A_const_325; var tmp16 any; var root_1591 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = mn__3; var arg_1595 any = A_arbace_c2j_node_A_const_326; if linked_1592 == nil { tmp16 = ifn_1593.Invoke_O_O__O(arg_1594, arg_1595) } else { tmp16 = linked_1592.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1591, arg_1594, arg_1595) }; var tmp17 any = tmp16; var tmp18 any; if jrt.J2g_Truth(rt__4) { var root_1596 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1596, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any = params__5; var arg_1600 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_302, rt__4)); if linked_1597 == nil { tmp18 = ifn_1598.Invoke_O_O__O(arg_1599, arg_1600) } else { tmp18 = linked_1597.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1596, arg_1599, arg_1600) } } else { tmp18 = params__5 }; return tmp14.Invoke_O_O_O_O__O(tmp15, tmp17, tmp18, body__7) } else {
//line :441:1
			return nil } }
//line :433:1
func A_arbace_c2j_node_variant_class_method__400000280_try_qe__400000284_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_variant_class_method__400000280_try_qe__400000284_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_method__400000280_try_qe__400000284_A{}; t.Ctor_O_O(p0, p1); return t }
//line :433:1
func (t *A_arbace_c2j_node_variant_class_method__400000280_try_qe__400000284_A) Ctor_O_O(c__d, c__env any) { t.F_d = c__d; t.F_env = c__env }
//line :433:1
func (t *A_arbace_c2j_node_variant_class_method__400000280_try_qe__400000284_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1536 any = A_arbace_c2j_node_A_const_206.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, A_arbace_c2j_node_realize_A_fn_class); var ifn_1538 lang.IFn; if linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any; var root_1540 any = A_arbace_c2j_node_A_const_216.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1540, A_arbace_c2j_node_qe_A_fn_class); var ifn_1542 lang.IFn; if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any = t.F_env; var arg_1544 any = v__1; var arg_1545 any = A_arbace_c2j_node_A_const_26.Invoke_O__O(t.F_d); if linked_1541 == nil { arg_1539 = ifn_1542.Invoke_O_O_O__O(arg_1543, arg_1544, arg_1545) } else { arg_1539 = linked_1541.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1540, arg_1543, arg_1544, arg_1545) }; if linked_1537 == nil { tmp1 = ifn_1538.Invoke_O__O(arg_1539) } else { tmp1 = linked_1537.(*A_arbace_c2j_node_realize_A).Invoke_O_O__O(root_1536, arg_1539) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var x__4 jrt.Exception_I = jrt.Exception_Cast(tmp2); var tmp3 *lang.Keyword = A_arbace_c2j_node_A_const_314; var tmp4 any; var root_1546 any = A_arbace_c2j_node_A_const_315.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1548 lang.IFn
															if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = x__4; if linked_1547 == nil { tmp4 = ifn_1548.Invoke_O__O(arg_1549) } else { tmp4 = linked_1547.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1546, arg_1549) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(tmp4)) { tmp1 = nil } else { panic(jrt.Thrown(x__4)) } } else {
//line :433:1
		panic(tmp2) } }; return tmp1 }


func A_arbace_c2j_node_variant_class_method__400000280_fn__400000287_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_variant_class_method__400000280_fn__400000287_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_method__400000280_fn__400000287_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :436:1
func (t *A_arbace_c2j_node_variant_class_method__400000280_fn__400000287_A) Ctor_O_O_O(c__c, c__try_qe, c__v any) { t.F_c = c__c; t.F_try_qe = c__try_qe; t.F_v = c__v }
//line :436:1
func (t *A_arbace_c2j_node_variant_class_method__400000280_fn__400000287_A) Invoke_O_O__O(self, p__400000286__1 any) any { var vec__400000288__2 any = p__400000286__1; var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000288__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000288__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_try_qe); var temp__1927000414__auto____5 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_node_A_const_14.GetRawRoot__O()).Invoke_O_O_O_O_O__O(t.F_v, A_arbace_c2j_node_A_const_167, t.F_c, A_arbace_c2j_node_A_const_258, m__4)); if jrt.J2g_Truth(temp__1927000414__auto____5) { var b__6 any = temp__1927000414__auto____5; return lang.Tuple_Create_O_O__IPersistentVector(i__3, b__6) } else { return nil } }












func A_arbace_c2j_node_variant_class_fn__400000293_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_variant_class_fn__400000293_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000293_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :449:1
func (t *A_arbace_c2j_node_variant_class_fn__400000293_A) Ctor_O_O_O(c__conv, c__methods, c__v any) { t.F_conv = c__conv; t.F_methods = c__methods; t.F_v = c__v }
//line :449:1
func (t *A_arbace_c2j_node_variant_class_fn__400000293_A) Invoke_O_O__O(self, b__1 any) any { var G__400000294__2_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__1); switch
												lang.Util_Hash_O__I_NoInit(G__400000294__2_) >> 8 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__400000294__2_, A_arbace_c2j_node_A_const_335) {









		var root_1645 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1645, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1647 lang.IFn; if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any; var tmp1 any = A_arbace_c2j_node_variant_class_fn__400000293_fn__400000295_A_New(); var tmp2 *jrt.Class; var fncls__1650 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000293_fn__400000295_A_fn_class; if fncls__1650 == nil { var fncls__1650d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_c2j_node_variant_class_fn__400000293_fn__400000295_A_fn_class = fncls__1650d; tmp2 = fncls__1650d } else { tmp2 = fncls__1650 }; arg_1648 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 *lang.Keyword = A_arbace_c2j_node_A_const_31; var arg_1649 any = tmp3.Invoke_O__O(A_arbace_c2j_node_A_const_176.Invoke_O__O(t.F_v)); if linked_1646 == nil { return ifn_1647.Invoke_O_O__O(arg_1648, arg_1649) } else { return linked_1646.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1645, arg_1648, arg_1649) } }
//line :450:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__400000294__2_, A_arbace_c2j_node_A_const_336) {










		var tmp4 any; var and__1927000168__auto____3 any; var root_1651 any = A_arbace_c2j_node_A_const_267.GetRawRoot__O(); var linked_1652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1651, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1653 lang.IFn; if linked_1652 == nil { ifn_1653 = lang.IFn_Cast(root_1651) } else { ifn_1653 = nil }; var arg_1654 any; var root_1655 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1655, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1657 lang.IFn; if linked_1656 == nil { ifn_1657 = lang.IFn_Cast(root_1655) } else { ifn_1657 = nil }; var arg_1658 any = A_arbace_c2j_node_A_const_233.Invoke_O__O(t.F_v); var arg_1659 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); if linked_1656 == nil { arg_1654 = ifn_1657.Invoke_O_O__O(arg_1658, arg_1659) } else { arg_1654 = linked_1656.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1655, arg_1658, arg_1659) }; if linked_1652 == nil { and__1927000168__auto____3 = ifn_1653.Invoke_O__O(arg_1654) } else { and__1927000168__auto____3 = linked_1652.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1651, arg_1654) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
			var root_1660 any = A_arbace_c2j_node_A_const_299.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1660, A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1664 any = t.F_methods; if linked_1661 == nil { tmp4 = ifn_1662.Invoke_O_O__O(arg_1663, arg_1664) } else { tmp4 = linked_1661.(*A_arbace_c2j_node_sym_occurs_QMARK__A).Invoke_O_O_O__O(root_1660, arg_1663, arg_1664) } } else {
//line :461:1
				tmp4 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp4) { var tmp5 any = A_arbace_c2j_node_A_const_330; var tmp6 any; var root_1688 any = A_arbace_c2j_node_A_const_339.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1688, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1690 lang.IFn

					if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1692 any; var root_1693 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1693, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1695 lang.IFn; if linked_1694 == nil { ifn_1695 = lang.IFn_Cast(root_1693) } else { ifn_1695 = nil }; var arg_1696 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1694 == nil { arg_1692 = ifn_1695.Invoke_O__O(arg_1696) } else { arg_1692 = linked_1694.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1693, arg_1696) }; if linked_1689 == nil { tmp6 = ifn_1690.Invoke_O_O__O(arg_1691, arg_1692) } else { tmp6 = linked_1689.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1688, arg_1691, arg_1692) }
//line :461:1
					var tmp7 any = tmp6; var tmp8 any = A_arbace_c2j_node_A_const_333; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp7, tmp8, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1)))) } else { return nil } }
//line :450:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000294__2_, A_arbace_c2j_node_A_const_337) { var tmp9 any = A_arbace_c2j_node_A_const_330; var tmp10 any; var root_1697 any = A_arbace_c2j_node_A_const_339.GetRawRoot__O(); var linked_1698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1697, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1699 lang.IFn
		if linked_1698 == nil { ifn_1699 = lang.IFn_Cast(root_1697) } else { ifn_1699 = nil }; var arg_1700 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1701 any = A_arbace_c2j_node_A_const_350; if linked_1698 == nil { tmp10 = ifn_1699.Invoke_O_O__O(arg_1700, arg_1701) } else { tmp10 = linked_1698.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1697, arg_1700, arg_1701) }
//line :450:1
		var tmp11 any = tmp10; var tmp12 any = A_arbace_c2j_node_A_const_333; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp11, tmp12, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1)))) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__400000294__2_, A_arbace_c2j_node_A_const_338) { var fld__3 any; var root_1665 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1665, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1667 lang.IFn

			if linked_1666 == nil { ifn_1667 = lang.IFn_Cast(root_1665) } else { ifn_1667 = nil }; var arg_1668 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1666 == nil { fld__3 = ifn_1667.Invoke_O__O(arg_1668) } else { fld__3 = linked_1666.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1665, arg_1668) }
			var tmp13 any = A_arbace_c2j_node_A_const_219; if lang.Util_Equiv_O_O__Z_NoInit(tmp13, A_arbace_c2j_node_A_const_220.Invoke_O__O(t.F_v)) { var tmp14 any = A_arbace_c2j_node_A_const_330; var tmp15 any; var root_1716 any = A_arbace_c2j_node_A_const_339.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1718 lang.IFn
				if linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1720 any = A_arbace_c2j_node_A_const_352; if linked_1717 == nil { tmp15 = ifn_1718.Invoke_O_O__O(arg_1719, arg_1720) } else { tmp15 = linked_1717.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1716, arg_1719, arg_1720) }
//line :453:1
				var tmp16 any = tmp15; var tmp17 any = A_arbace_c2j_node_A_const_333; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp16, tmp17, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_353, A_arbace_c2j_node_A_const_354, fld__3)))) } else {

					var root_1669 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1670 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1669, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1671 lang.IFn; if linked_1670 == nil { ifn_1671 = lang.IFn_Cast(root_1669) } else { ifn_1671 = nil }; var arg_1672 any; var tmp18 any = A_arbace_c2j_node_variant_class_fn__400000293_fn__400000297_A_New_O_O_O(b__1, t.F_conv, fld__3); var tmp19 *jrt.Class; var fncls__1683 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000293_fn__400000297_A_fn_class; if fncls__1683 == nil { var fncls__1683d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_c2j_node_variant_class_fn__400000293_fn__400000297_A_fn_class = fncls__1683d; tmp19 = fncls__1683d } else { tmp19 = fncls__1683 }; arg_1672 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var arg_1673 any; var root_1684 any = A_arbace_c2j_node_A_const_225.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1686 lang.IFn



					if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = A_arbace_c2j_node_A_const_220.Invoke_O__O(t.F_v); if linked_1685 == nil { arg_1673 = ifn_1686.Invoke_O__O(arg_1687) } else { arg_1673 = linked_1685.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1684, arg_1687) }
//line :455:1
					if linked_1670 == nil { return ifn_1671.Invoke_O_O__O(arg_1672, arg_1673) } else { return linked_1670.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1669, arg_1672, arg_1673) } } }
//line :450:1
	case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__400000294__2_, A_arbace_c2j_node_A_const_351) {










		var tmp20 any; var and__1927000168__auto____3_2 any; var root_1702 any = A_arbace_c2j_node_A_const_267.GetRawRoot__O(); var linked_1703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1702, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1704 lang.IFn; if linked_1703 == nil { ifn_1704 = lang.IFn_Cast(root_1702) } else { ifn_1704 = nil }; var arg_1705 any; var root_1706 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1706, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1708 lang.IFn; if linked_1707 == nil { ifn_1708 = lang.IFn_Cast(root_1706) } else { ifn_1708 = nil }; var arg_1709 any = A_arbace_c2j_node_A_const_233.Invoke_O__O(t.F_v); var arg_1710 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); if linked_1707 == nil { arg_1705 = ifn_1708.Invoke_O_O__O(arg_1709, arg_1710) } else { arg_1705 = linked_1707.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1706, arg_1709, arg_1710) }; if linked_1703 == nil { and__1927000168__auto____3_2 = ifn_1704.Invoke_O__O(arg_1705) } else { and__1927000168__auto____3_2 = linked_1703.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1702, arg_1705) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) {
			var root_1711 any = A_arbace_c2j_node_A_const_299.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1711, A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class); var ifn_1713 lang.IFn; if linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var arg_1714 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1715 any = t.F_methods; if linked_1712 == nil { tmp20 = ifn_1713.Invoke_O_O__O(arg_1714, arg_1715) } else { tmp20 = linked_1712.(*A_arbace_c2j_node_sym_occurs_QMARK__A).Invoke_O_O_O__O(root_1711, arg_1714, arg_1715) } } else {
//line :461:1
				tmp20 = and__1927000168__auto____3_2 }; if jrt.J2g_Truth(tmp20) { var tmp21 any = A_arbace_c2j_node_A_const_330; var tmp22 any; var root_1721 any = A_arbace_c2j_node_A_const_339.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1723 lang.IFn

					if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1725 any; var root_1726 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1726, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1728 lang.IFn; if linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1727 == nil { arg_1725 = ifn_1728.Invoke_O__O(arg_1729) } else { arg_1725 = linked_1727.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1726, arg_1729) }; if linked_1722 == nil { tmp22 = ifn_1723.Invoke_O_O__O(arg_1724, arg_1725) } else { tmp22 = linked_1722.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1721, arg_1724, arg_1725) }
//line :461:1
					var tmp23 any = tmp22; var tmp24 any = A_arbace_c2j_node_A_const_333; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp21, tmp23, tmp24, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1)))) } else { return nil } }
//line :450:1
	default:}; return nil }




func A_arbace_c2j_node_variant_class_fn__400000293_fn__400000297_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_variant_class_fn__400000293_fn__400000297_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000293_fn__400000297_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :455:1
func (t *A_arbace_c2j_node_variant_class_fn__400000293_fn__400000297_A) Ctor_O_O_O(c__b, c__conv, c__fld any) { t.F_b = c__b; t.F_conv = c__conv; t.F_fld = c__fld }
//line :455:1
func (t *A_arbace_c2j_node_variant_class_fn__400000293_fn__400000297_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_341; var tmp3 any = A_arbace_c2j_node_A_const_342; var x__2 any = tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_343, t.F_fld, i__1)); var tmp4 any = A_arbace_c2j_node_A_const_330; var tmp5 any; var root_1674 any = A_arbace_c2j_node_A_const_339.GetRawRoot__O(); var linked_1675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1674, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1676 lang.IFn; if

	linked_1675 == nil { ifn_1676 = lang.IFn_Cast(root_1674) } else { ifn_1676 = nil }; var arg_1677 any; var root_1679 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_1680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1679, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1681 lang.IFn; if linked_1680 == nil { ifn_1681 = lang.IFn_Cast(root_1679) } else { ifn_1681 = nil }; var arg_1682 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_19.Invoke_O__O(t.F_b), i__1)).Ref(); if linked_1680 == nil { arg_1677 = ifn_1681.Invoke_O__O(arg_1682) } else { arg_1677 = linked_1680.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1679, arg_1682) }; var arg_1678 any = A_arbace_c2j_node_A_const_340; if linked_1675 == nil { tmp5 = ifn_1676.Invoke_O_O__O(arg_1677, arg_1678) } else { tmp5 = linked_1675.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1674, arg_1677, arg_1678) }; var tmp6 any = tmp5; var tmp7 any = A_arbace_c2j_node_A_const_333; var tmp8 any; if
	jrt.J2g_Truth(t.F_conv) { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_node_A_const_344; var tmp11 any = A_arbace_c2j_node_A_const_345; tmp8 = tmp9.Invoke_O_O_O_O__O(tmp10, tmp11, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_346, A_arbace_c2j_node_A_const_347, i__1), x__2) } else { tmp8 = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_348, A_arbace_c2j_node_A_const_349, x__2) }; return /*line :455:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, tmp8)) }




func A_arbace_c2j_node_variant_class_fn__400000293_fn__400000295_A_New() *A_arbace_c2j_node_variant_class_fn__400000293_fn__400000295_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000293_fn__400000295_A{}; t.Ctor(); return t }
//line :460:1
func (t *A_arbace_c2j_node_variant_class_fn__400000293_fn__400000295_A) Ctor() {}
//line :460:1
func (t *A_arbace_c2j_node_variant_class_fn__400000293_fn__400000295_A) Invoke_O_O__O(self, s__1 any) any { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_330, s__1)) }





func A_arbace_c2j_node_variant_class_bare__400000300_A_New() *A_arbace_c2j_node_variant_class_bare__400000300_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_bare__400000300_A{}; t.Ctor(); return t }
//line :466:1
func (t *A_arbace_c2j_node_variant_class_bare__400000300_A) Ctor() {}
//line :466:1
func (t *A_arbace_c2j_node_variant_class_bare__400000300_A) Invoke_O_O__O(self, s__1 any) any { var root_1731 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1733 lang.IFn; if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any = s__1; var arg_1735 any; if linked_1732 == nil { return ifn_1733.Invoke_O_O__O(arg_1734, arg_1735) } else { return linked_1732.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1731, arg_1734, arg_1735) } }



func A_arbace_c2j_node_variant_class_fn__400000303_A_New() *A_arbace_c2j_node_variant_class_fn__400000303_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000303_A{}; t.Ctor(); return t }
//line :470:1
func (t *A_arbace_c2j_node_variant_class_fn__400000303_A) Ctor() {}
//line :470:1
func (t *A_arbace_c2j_node_variant_class_fn__400000303_A) Invoke_O_O__O(self, p__400000302__1 any) any { var map__400000304__2 any = p__400000302__1; var map__400000304__3 any; if lang.ISeq_InstanceOf(map__400000304__2) { var tmp1 any; var root_1758 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1758, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1760 lang.IFn; if linked_1759 == nil { ifn_1760 = lang.IFn_Cast(root_1758) } else { ifn_1760 = nil }; var arg_1761 any = map__400000304__2; if linked_1759 == nil { tmp1 = ifn_1760.Invoke_O__O(arg_1761) } else { tmp1 = linked_1759.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1758, arg_1761) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1762 any = A_arbace_c2j_node_A_const_171.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = map__400000304__2; if linked_1763 == nil { tmp2 = ifn_1764.Invoke_O__O(arg_1765) } else { tmp2 = linked_1763.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1762, arg_1765) }; map__400000304__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1766 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = map__400000304__2; if linked_1767 == nil { tmp3 = ifn_1768.Invoke_O__O(arg_1769) } else { tmp3 = linked_1767.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1766, arg_1769) }; if jrt.J2g_Truth(tmp3) { var root_1770 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = map__400000304__2; if linked_1771 == nil { map__400000304__3 = ifn_1772.Invoke_O__O(arg_1773) } else { map__400000304__3 = linked_1771.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1770, arg_1773) } } else { map__400000304__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000304__3 = map__400000304__2 }; var fs__4 any = lang.RT_Get_O_O__O_NoInit(map__400000304__3, A_arbace_c2j_node_A_const_330); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_node_A_const_359; return tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_node_A_const_301.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(fs__4, A_arbace_c2j_node_A_const_14.GetRawRoot__O(), A_arbace_c2j_node_A_const_360, jrt.Boolean_TRUE.Ref(), A_arbace_c2j_node_A_const_361, jrt.Boolean_TRUE.Ref())) }

func A_arbace_c2j_node_variant_class_fn__400000308_A_New_O(p0 any) *A_arbace_c2j_node_variant_class_fn__400000308_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000308_A{}; t.Ctor_O(p0); return t }
//line :472:1
func (t *A_arbace_c2j_node_variant_class_fn__400000308_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :472:1
func (t *A_arbace_c2j_node_variant_class_fn__400000308_A) Invoke_O_O__O(self, p__400000307__1 any) any { var map__400000309__2 any = p__400000307__1; var map__400000309__3 any; if lang.ISeq_InstanceOf(map__400000309__2) { var tmp1 any; var root_1814 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1814, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1816 lang.IFn; if linked_1815 == nil { ifn_1816 = lang.IFn_Cast(root_1814) } else { ifn_1816 = nil }; var arg_1817 any = map__400000309__2; if linked_1815 == nil { tmp1 = ifn_1816.Invoke_O__O(arg_1817) } else { tmp1 = linked_1815.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1814, arg_1817) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1818 any = A_arbace_c2j_node_A_const_171.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = map__400000309__2; if linked_1819 == nil { tmp2 = ifn_1820.Invoke_O__O(arg_1821) } else { tmp2 = linked_1819.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1818, arg_1821) }; map__400000309__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1822 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = map__400000309__2; if linked_1823 == nil { tmp3 = ifn_1824.Invoke_O__O(arg_1825) } else { tmp3 = linked_1823.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1822, arg_1825) }; if jrt.J2g_Truth(tmp3) { var root_1826 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = map__400000309__2; if linked_1827 == nil { map__400000309__3 = ifn_1828.Invoke_O__O(arg_1829) } else { map__400000309__3 = linked_1827.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1826, arg_1829) } } else { map__400000309__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000309__3 = map__400000309__2 }; var fs__4 any = lang.RT_Get_O_O__O_NoInit(map__400000309__3, A_arbace_c2j_node_A_const_330); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_node_A_const_365; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp7 any; var root_1830 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1832 lang.IFn; if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(t.F_bare).Invoke_O__O(fs__4))).Ref(); if linked_1831 == nil { tmp7 = ifn_1832.Invoke_O__O(arg_1833) } else { tmp7 = linked_1831.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1830, arg_1833) }; return tmp4.Invoke_O_O_O__O(tmp5, tmp6.Invoke_O_O__O(tmp7, A_arbace_c2j_node_A_const_366), lang.IFn_Cast(t.F_bare).Invoke_O__O(fs__4)) }



func A_arbace_c2j_node_variants_A_New() *A_arbace_c2j_node_variants_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_A{}; t.Ctor(); return t }
//line :476:1
func (t *A_arbace_c2j_node_variants_A) Ctor() {}
//line :476:1
func (t *A_arbace_c2j_node_variants_A) Invoke_O_O_O__O(self, d__0, domains__1 any) any { var base__3 any; var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_367; var or__1927000174__auto____3 any = tmp1.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0)); if



	jrt.J2g_Truth(or__1927000174__auto____3) { base__3 = or__1927000174__auto____3 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_96, nil); var tmp3 any; var root_1835 any = A_arbace_c2j_node_A_const_368.GetRawRoot__O(); var linked_1836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1835, A_arbace_c2j_node_camel_A_fn_class); var ifn_1837 lang.IFn; if linked_1836 == nil { ifn_1837 = lang.IFn_Cast(root_1835) } else { ifn_1837 = nil }; var arg_1838 any = A_arbace_c2j_node_A_const_13.Invoke_O__O(d__0); if linked_1836 == nil { tmp3 = ifn_1837.Invoke_O__O(arg_1838) } else { tmp3 = linked_1836.(*A_arbace_c2j_node_camel_A).Invoke_O_O__O(root_1835, arg_1838) }; base__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() }; var ss__4 any; var root_1839 any = /*line :476:1*/A_arbace_c2j_node_A_const_369.GetRawRoot__O(); var linked_1840 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1839, A_arbace_c2j_node_splits_A_fn_class); var ifn_1841 lang.IFn; if




	linked_1840 == nil { ifn_1841 = lang.IFn_Cast(root_1839) } else { ifn_1841 = nil }; var arg_1842 any = d__0; if linked_1840 == nil { ss__4 = ifn_1841.Invoke_O__O(arg_1842) } else { ss__4 = linked_1840.(*A_arbace_c2j_node_splits_A).Invoke_O_O__O(root_1839, arg_1842) }; var cb__5 any; var root_1843 any = /*line :476:1*/A_arbace_c2j_node_A_const_327.GetRawRoot__O(); var linked_1844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1843, A_arbace_c2j_node_children_bind_A_fn_class); var ifn_1845 lang.IFn; if





	linked_1844 == nil { ifn_1845 = lang.IFn_Cast(root_1843) } else { ifn_1845 = nil }; var arg_1846 any = d__0; if linked_1844 == nil { cb__5 = ifn_1845.Invoke_O__O(arg_1846) } else { cb__5 = linked_1844.(*A_arbace_c2j_node_children_bind_A).Invoke_O_O__O(root_1843, arg_1846) }; var counts__6 any; if
	jrt.J2g_Truth(cb__5) {
		var root_1847 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_1848 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1847, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1849 lang.IFn; if linked_1848 == nil { ifn_1849 = lang.IFn_Cast(root_1847) } else { ifn_1849 = nil }; var arg_1850 any; var root_1852 any = A_arbace_c2j_node_A_const_225.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any; var na_1856 any; var root_1857 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(cb__5); if linked_1858 == nil { na_1856 = ifn_1859.Invoke_O__O(arg_1860) } else { na_1856 = linked_1858.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1857, arg_1860) }; if jrt.Long_InstanceOf(na_1856) { var n0_1861 int64 = jrt.NN(jrt.Long_Cast(na_1856)).LongValue__J(); if n0_1861 == 9223372036854775807 { arg_1855 = lang.Numbers_Inc_O__Number_NoInit(na_1856) } else { arg_1855 = jrt.Long_ValueOf_J__Long_NoInit(n0_1861 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1856) { var n0_1861_2 float64 = jrt.NN(jrt.Double_Cast(na_1856)).DoubleValue__D(); arg_1855 = jrt.Double_ValueOf_D__Double_NoInit(n0_1861_2 + 1.0).Ref() } else { arg_1855 = lang.Numbers_Inc_O__Number_NoInit(na_1856) } }; if linked_1853 == nil { arg_1850 = ifn_1854.Invoke_O__O(arg_1855) } else { arg_1850 = linked_1853.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1852, arg_1855) }; var arg_1851 any; var tmp4 any; var root_1862 any = A_arbace_c2j_node_A_const_370.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1862, A_arbace_c2j_node_uses_many_QMARK__A_fn_class); var ifn_1864 lang.IFn; if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = d__0; if linked_1863 == nil { tmp4 = ifn_1864.Invoke_O__O(arg_1865) } else { tmp4 = linked_1863.(*A_arbace_c2j_node_uses_many_QMARK__A).Invoke_O_O__O(root_1862, arg_1865) }; if jrt.J2g_Truth(tmp4) { arg_1851 = A_arbace_c2j_node_A_const_371 } else { arg_1851 = nil }; if linked_1848 == nil { counts__6 = ifn_1849.Invoke_O_O__O(arg_1850, arg_1851) } else { counts__6 = linked_1848.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1847, arg_1850, arg_1851) } } else {
//line :483:1
			counts__6 = A_arbace_c2j_node_A_const_372 }; var split_sets__7 any; var root_1866 any = /*line :476:1*/A_arbace_c2j_node_A_const_128.GetRawRoot__O(); var linked_1867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1866, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1868 lang.IFn; if









	linked_1867 == nil { ifn_1868 = lang.IFn_Cast(root_1866) } else { ifn_1868 = nil }; var arg_1869 any; var tmp5 any = A_arbace_c2j_node_variants_fn__400000314_A_New(); var tmp6 *jrt.Class; var fncls__1970 *jrt.Class = A_arbace_c2j_node_variants_fn__400000314_A_fn_class; if fncls__1970 == nil { var fncls__1970d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_c2j_node_variants_fn__400000314_A_fn_class = fncls__1970d; tmp6 = fncls__1970d } else { tmp6 = fncls__1970 }; arg_1869 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1870 any = lang.Tuple_Create_O__IPersistentVector(lang.PersistentArrayMap_EMPTY.Ref()); var arg_1871 any = ss__4; if linked_1867 == nil { split_sets__7 = ifn_1868.Invoke_O_O_O__O(arg_1869, arg_1870, arg_1871) } else { split_sets__7 = linked_1867.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1866, arg_1869, arg_1870, arg_1871) }; var dom__8 any; var tmp7 /*line :476:1*/*lang.Keyword = A_arbace_c2j_node_A_const_381; if










	jrt.J2g_Truth(tmp7.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0))) { dom__8 = lang.IFn_Cast(domains__1).Invoke_O__O(A_arbace_c2j_node_A_const_13.Invoke_O__O(d__0)) } else { dom__8 = nil }; var tmp8 any; var root_1971 any =
	A_arbace_c2j_node_A_const_48.GetRawRoot__O(); var linked_1972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1971, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1973 lang.IFn; if linked_1972 == nil { ifn_1973 = lang.IFn_Cast(root_1971) } else { ifn_1973 = nil }; var arg_1974 any; var tmp9 any = A_arbace_c2j_node_variants_fn__400000332_A_New(); var tmp10 *jrt.Class; var fncls__1976 *jrt.Class = A_arbace_c2j_node_variants_fn__400000332_A_fn_class; if fncls__1976 == nil { var fncls__1976d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_c2j_node_variants_fn__400000332_A_fn_class = fncls__1976d; tmp10 = fncls__1976d } else { tmp10 = fncls__1976 }; arg_1974 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_1975 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_1972 == nil { tmp8 = ifn_1973.Invoke_O_O__O(arg_1974, arg_1975) } else { tmp8 = linked_1972.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1971, arg_1974, arg_1975) }; if jrt.J2g_Truth(tmp8) { var iter__1927001039__auto____9 any; var tmp11 any = A_arbace_c2j_node_variants_iter__400000334__400000340_A_New(); var tmp12 *jrt.Class; var fncls__2062 *jrt.Class = A_arbace_c2j_node_variants_iter__400000334__400000340_A_fn_class
		if fncls__2062 == nil { var fncls__2062d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_c2j_node_variants_iter__400000334__400000340_A_fn_class = fncls__2062d; tmp12 = fncls__2062d } else { tmp12 = fncls__2062 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); return lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_c2j_node_A_const_388.GetRawRoot__O()) } else {
//line :488:1
			var iter__1927001039__auto____9_2 any; var tmp13 any = A_arbace_c2j_node_variants_iter__400000353__400000359_A_New_O_O_O_O(base__3, split_sets__7, dom__8, ss__4); var tmp14 *jrt.Class
			var fncls__2204 /*line :488:1*/*jrt.Class = A_arbace_c2j_node_variants_iter__400000353__400000359_A_fn_class


			if fncls__2204 == nil { var fncls__2204d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_c2j_node_variants_iter__400000353__400000359_A_fn_class = fncls__2204d; tmp14 = fncls__2204d } else { tmp14 = fncls__2204 }; iter__1927001039__auto____9_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); return lang.IFn_Cast(iter__1927001039__auto____9_2).Invoke_O__O(counts__6) } }
//line :486:1
func A_arbace_c2j_node_variants_fn__400000314_A_New() *A_arbace_c2j_node_variants_fn__400000314_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000314_A{}; t.Ctor(); return t }
//line :486:1
func (t *A_arbace_c2j_node_variants_fn__400000314_A) Ctor() {}
//line :486:1
func (t *A_arbace_c2j_node_variants_fn__400000314_A) Invoke_O_O_O__O(self, acc__1, s__2 any) any { var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_A_New_O(s__2); var tmp2 *jrt.Class; var fncls__1969 *jrt.Class = A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_A_fn_class; if fncls__1969 == nil { var fncls__1969d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_A_fn_class = fncls__1969d; tmp2 = fncls__1969d } else { tmp2 = fncls__1969 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(acc__1) }
//line :486:1
func A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_A_New_O(p0 any) *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_A{}; t.Ctor_O(p0); return t }
//line :486:1
func (t *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :486:1
func (t *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_A) Invoke_O_O__O(self, s__400000316__1 any) any { var tmp1 any = A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_A_New_O_O_O(self, s__400000316__1, t.F_s); var tmp2 *jrt.Class; var fncls__1968 *jrt.Class = A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_A_fn_class; if fncls__1968 == nil { var fncls__1968d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_A_fn_class = fncls__1968d; tmp2 = fncls__1968d } else { tmp2 = fncls__1968 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :486:1
func A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :486:1
func (t *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_A) Ctor_O_O_O(c__iter__400000315, c__s__400000316, c__s any) { t.F_iter__400000315 = c__iter__400000315; t.F_s__400000316 = c__s__400000316; t.F_s = c__s }
//line :486:1
func (t *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_A) Invoke_O__O(self any) any { { var s__400000316__1 any; var t_ any = t.F_s__400000316; t.F_s__400000316 = nil; s__400000316__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1872 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1872, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1874 lang.IFn; if linked_1873 == nil { ifn_1874 = lang.IFn_Cast(root_1872) } else { ifn_1874 = nil }; var arg_1875 any = s__400000316__1; if linked_1873 == nil { temp__1927000414__auto____2 = ifn_1874.Invoke_O__O(arg_1875) } else { temp__1927000414__auto____2 = linked_1873.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1872, arg_1875) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var m__4 any; var root_1876 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1878 lang.IFn; if linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any = xs__1927001018__auto____3; if linked_1877 == nil { m__4 = ifn_1878.Invoke_O__O(arg_1879) } else { m__4 = linked_1877.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1876, arg_1879) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_A_New_O_O(m__4, t.F_s); var tmp2 *jrt.Class; var fncls__1950 *jrt.Class = A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_A_fn_class; if fncls__1950 == nil { var fncls__1950d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_A_fn_class = fncls__1950d; tmp2 = fncls__1950d } else { tmp2 = fncls__1950 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_1951 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_c2j_node_A_const_380); if linked_1952 == nil { fs__1927001036__auto____6 = ifn_1953.Invoke_O__O(arg_1954) } else { fs__1927001036__auto____6 = linked_1952.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1951, arg_1954) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_1955 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_1956 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1955, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1957 lang.IFn; if linked_1956 == nil { ifn_1957 = lang.IFn_Cast(root_1955) } else { ifn_1957 = nil }; var arg_1958 any = fs__1927001036__auto____6; var arg_1959 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__400000315); var tmp4 any; var root_1960 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1960, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1962 lang.IFn; if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any = s__400000316__1; if linked_1961 == nil { tmp4 = ifn_1962.Invoke_O__O(arg_1963) } else { tmp4 = linked_1961.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1960, arg_1963) }; arg_1959 = tmp3.Invoke_O__O(tmp4); if linked_1956 == nil { return ifn_1957.Invoke_O_O__O(arg_1958, arg_1959) } else { return linked_1956.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1955, arg_1958, arg_1959) } } else { var tmp5 any; var root_1964 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1966 lang.IFn; if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any = s__400000316__1; if linked_1965 == nil { tmp5 = ifn_1966.Invoke_O__O(arg_1967) } else { tmp5 = linked_1965.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1964, arg_1967) }; s__400000316__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :486:1
func A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_A{}; t.Ctor_O_O(p0, p1); return t }
//line :486:1
func (t *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_A) Ctor_O_O(c__m, c__s any) { t.F_m = c__m; t.F_s = c__s }
//line :486:1
func (t *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_A) Invoke_O_O__O(self, s__400000318__1 any) any { var tmp1 any = A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_A_New_O_O_O_O(self, t.F_m, s__400000318__1, t.F_s); var tmp2 *jrt.Class; var fncls__1949 *jrt.Class = A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_A_fn_class; if fncls__1949 == nil { var fncls__1949d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_A_fn_class = fncls__1949d; tmp2 = fncls__1949d } else { tmp2 = fncls__1949 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :486:1
func A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :486:1
func (t *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_A) Ctor_O_O_O_O(c__iter__400000317, c__m, c__s__400000318, c__s any) { t.F_iter__400000317 = c__iter__400000317; t.F_m = c__m; t.F_s__400000318 = c__s__400000318; t.F_s = c__s }
//line :486:1
func (t *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_A) Invoke_O__O(self any) any { { var s__400000318__1 any; var t_ any = t.F_s__400000318; t.F_s__400000318 = nil; s__400000318__1 = t_; for { var temp__1927000414__auto____2 any; var root_1880 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1880, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1882 lang.IFn; if linked_1881 == nil { ifn_1882 = lang.IFn_Cast(root_1880) } else { ifn_1882 = nil }; var arg_1883 any = s__400000318__1; if linked_1881 == nil { temp__1927000414__auto____2 = ifn_1882.Invoke_O__O(arg_1883) } else { temp__1927000414__auto____2 = linked_1881.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1880, arg_1883) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000318__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1884 any = A_arbace_c2j_node_A_const_373.GetRawRoot__O(); var linked_1885 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1884, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1886 lang.IFn; if linked_1885 == nil { ifn_1886 = lang.IFn_Cast(root_1884) } else { ifn_1886 = nil }; var arg_1887 any = s__400000318__3; if linked_1885 == nil { tmp1 = ifn_1886.Invoke_O__O(arg_1887) } else { tmp1 = linked_1885.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1884, arg_1887) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1888 any = A_arbace_c2j_node_A_const_374.GetRawRoot__O(); var linked_1889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1888, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1890 lang.IFn; if linked_1889 == nil { ifn_1890 = lang.IFn_Cast(root_1888) } else { ifn_1890 = nil }; var arg_1891 any = s__400000318__3; if linked_1889 == nil { c__1927001037__auto____4 = ifn_1890.Invoke_O__O(arg_1891) } else { c__1927001037__auto____4 = linked_1889.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1888, arg_1891) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000320__6 any; var root_1892 any = A_arbace_c2j_node_A_const_375.GetRawRoot__O(); var linked_1893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1892, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1894 lang.IFn; if linked_1893 == nil { ifn_1894 = lang.IFn_Cast(root_1892) } else { ifn_1894 = nil }; var arg_1895 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1893 == nil { b__400000320__6 = ifn_1894.Invoke_O__O(arg_1895) } else { b__400000320__6 = linked_1893.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1892, arg_1895) }; var tmp2 any = A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_fn__400000325_A_New_O_O_O_I_O(t.F_m, b__400000320__6, t.F_s, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1907 *jrt.Class = A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_fn__400000325_A_fn_class; if fncls__1907 == nil { var fncls__1907d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_fn__400000325_A_fn_class = fncls__1907d; tmp3 = fncls__1907d } else { tmp3 = fncls__1907 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1908 any = A_arbace_c2j_node_A_const_377.GetRawRoot__O(); var linked_1909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1908, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1910 lang.IFn; if linked_1909 == nil { ifn_1910 = lang.IFn_Cast(root_1908) } else { ifn_1910 = nil }; var arg_1911 any; var root_1913 any = A_arbace_c2j_node_A_const_378.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1913, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1915 lang.IFn; if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = b__400000320__6; if linked_1914 == nil { arg_1911 = ifn_1915.Invoke_O__O(arg_1916) } else { arg_1911 = linked_1914.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1913, arg_1916) }; var arg_1912 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000317); var tmp5 any; var root_1917 any = A_arbace_c2j_node_A_const_379.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1919 lang.IFn; if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = s__400000318__3; if linked_1918 == nil { tmp5 = ifn_1919.Invoke_O__O(arg_1920) } else { tmp5 = linked_1918.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1917, arg_1920) }; arg_1912 = tmp4.Invoke_O__O(tmp5); if linked_1909 == nil { return ifn_1910.Invoke_O_O__O(arg_1911, arg_1912) } else { return linked_1909.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1908, arg_1911, arg_1912) } } else { var root_1921 any = A_arbace_c2j_node_A_const_377.GetRawRoot__O(); var linked_1922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1921, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1923 lang.IFn; if linked_1922 == nil { ifn_1923 = lang.IFn_Cast(root_1921) } else { ifn_1923 = nil }; var arg_1924 any; var root_1926 any = A_arbace_c2j_node_A_const_378.GetRawRoot__O(); var linked_1927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1926, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1928 lang.IFn; if linked_1927 == nil { ifn_1928 = lang.IFn_Cast(root_1926) } else { ifn_1928 = nil }; var arg_1929 any = b__400000320__6; if linked_1927 == nil { arg_1924 = ifn_1928.Invoke_O__O(arg_1929) } else { arg_1924 = linked_1927.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1926, arg_1929) }; var arg_1925 any; if linked_1922 == nil { return ifn_1923.Invoke_O_O__O(arg_1924, arg_1925) } else { return linked_1922.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1921, arg_1924, arg_1925) } } } else { var x__4 any; var root_1930 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1930, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = s__400000318__3; if linked_1931 == nil { x__4 = ifn_1932.Invoke_O__O(arg_1933) } else { x__4 = linked_1931.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1930, arg_1933) }; var root_1934 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_1935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1934, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1936 lang.IFn; if linked_1935 == nil { ifn_1936 = lang.IFn_Cast(root_1934) } else { ifn_1936 = nil }; var arg_1937 any; var root_1939 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1940 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1939, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1941 lang.IFn; if linked_1940 == nil { ifn_1941 = lang.IFn_Cast(root_1939) } else { ifn_1941 = nil }; var arg_1942 any = t.F_m; var arg_1943 any = t.F_s; var arg_1944 any = x__4; if linked_1940 == nil { arg_1937 = ifn_1941.Invoke_O_O_O__O(arg_1942, arg_1943, arg_1944) } else { arg_1937 = linked_1940.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1939, arg_1942, arg_1943, arg_1944) }; var arg_1938 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__400000317); var tmp7 any; var root_1945 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1945, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1947 lang.IFn; if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var arg_1948 any = s__400000318__3; if linked_1946 == nil { tmp7 = ifn_1947.Invoke_O__O(arg_1948) } else { tmp7 = linked_1946.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1945, arg_1948) }; arg_1938 = tmp6.Invoke_O__O(tmp7); if linked_1935 == nil { return ifn_1936.Invoke_O_O__O(arg_1937, arg_1938) } else { return linked_1935.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1934, arg_1937, arg_1938) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :486:1
func A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_fn__400000325_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_fn__400000325_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_fn__400000325_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :486:1
func (t *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_fn__400000325_A) Ctor_O_O_O_I_O(c__m, c__b__400000320, c__s any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_m = c__m; t.F_b__400000320 = c__b__400000320; t.F_s = c__s; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :486:1
func (t *A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_fn__400000325_A) Invoke_O__O(self any) any { { var i__400000319__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000319__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000319__1)); var root_1896 any = A_arbace_c2j_node_A_const_376.GetRawRoot__O(); var linked_1897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1896, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1898 lang.IFn; if linked_1897 == nil { ifn_1898 = lang.IFn_Cast(root_1896) } else { ifn_1898 = nil }; var arg_1899 any = t.F_b__400000320; var arg_1900 any; var root_1901 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any = t.F_m; var arg_1905 any = t.F_s; var arg_1906 any = x__2; if linked_1902 == nil { arg_1900 = ifn_1903.Invoke_O_O_O__O(arg_1904, arg_1905, arg_1906) } else { arg_1900 = linked_1902.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1901, arg_1904, arg_1905, arg_1906) }; if linked_1897 == nil { ifn_1898.Invoke_O_O__O(arg_1899, arg_1900) } else { linked_1897.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1896, arg_1899, arg_1900) }; i__400000319__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000319__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_node_variants_fn__400000332_A_New() *A_arbace_c2j_node_variants_fn__400000332_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000332_A{}; t.Ctor(); return t }
//line :488:1
func (t *A_arbace_c2j_node_variants_fn__400000332_A) Ctor() {}
//line :488:1
func (t *A_arbace_c2j_node_variants_fn__400000332_A) Invoke_O_O__O(self, p1__400000313_SHARP___1 any) any { var tmp1 any = A_arbace_c2j_node_A_const_382; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_c2j_node_A_const_20.Invoke_O__O(p1__400000313_SHARP___1))).Ref() }
func A_arbace_c2j_node_variants_iter__400000334__400000340_A_New() *A_arbace_c2j_node_variants_iter__400000334__400000340_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000334__400000340_A{}; t.Ctor(); return t }
//line :489:1
func (t *A_arbace_c2j_node_variants_iter__400000334__400000340_A) Ctor() {}
//line :489:1
func (t *A_arbace_c2j_node_variants_iter__400000334__400000340_A) Invoke_O_O__O(self, s__400000335__1 any) any { var tmp1 any = A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_A_New_O_O(self, s__400000335__1); var tmp2 *jrt.Class; var fncls__2061 *jrt.Class = A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_A_fn_class; if fncls__2061 == nil { var fncls__2061d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_A_fn_class = fncls__2061d; tmp2 = fncls__2061d } else { tmp2 = fncls__2061 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :489:1
func A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_A{}; t.Ctor_O_O(p0, p1); return t }
//line :489:1
func (t *A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_A) Ctor_O_O(c__iter__400000334, c__s__400000335 any) { t.F_iter__400000334 = c__iter__400000334; t.F_s__400000335 = c__s__400000335 }
//line :489:1
func (t *A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_A) Invoke_O__O(self any) any { { var s__400000335__1 any; var t_ any = t.F_s__400000335; t.F_s__400000335 = nil; s__400000335__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1977 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1977, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1979 lang.IFn; if linked_1978 == nil { ifn_1979 = lang.IFn_Cast(root_1977) } else { ifn_1979 = nil }; var arg_1980 any = s__400000335__1; if linked_1978 == nil { temp__1927000414__auto____2 = ifn_1979.Invoke_O__O(arg_1980) } else { temp__1927000414__auto____2 = linked_1978.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1977, arg_1980) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__400000342__4 any; var root_1981 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1981, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1983 lang.IFn; if linked_1982 == nil { ifn_1983 = lang.IFn_Cast(root_1981) } else { ifn_1983 = nil }; var arg_1984 any = xs__1927001018__auto____3; if linked_1982 == nil { vec__400000342__4 = ifn_1983.Invoke_O__O(arg_1984) } else { vec__400000342__4 = linked_1982.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1981, arg_1984) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000342__4, lang.RT_IntCast_J__I_NoInit(0), nil); var p__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000342__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var tmp1 any = A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_A_New_O_O(k__5, p__6); var tmp2 *jrt.Class; var fncls__2043 *jrt.Class = A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_A_fn_class; if fncls__2043 == nil { var fncls__2043d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_A_fn_class = fncls__2043d; tmp2 = fncls__2043d } else { tmp2 = fncls__2043 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____8 any; var root_2044 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2044, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2046 lang.IFn; if linked_2045 == nil { ifn_2046 = lang.IFn_Cast(root_2044) } else { ifn_2046 = nil }; var arg_2047 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp4 any; if jrt.J2g_Truth(A_arbace_c2j_node_A_const_244.Invoke_O__O(p__6)) { tmp4 = A_arbace_c2j_node_A_const_384 } else { tmp4 = A_arbace_c2j_node_A_const_385 }; arg_2047 = tmp3.Invoke_O__O(tmp4); if linked_2045 == nil { fs__1927001036__auto____8 = ifn_2046.Invoke_O__O(arg_2047) } else { fs__1927001036__auto____8 = linked_2045.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2044, arg_2047) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2048 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2050 lang.IFn; if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any = fs__1927001036__auto____8; var arg_2052 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__400000334); var tmp6 any; var root_2053 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2055 lang.IFn; if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2056 any = s__400000335__1; if linked_2054 == nil { tmp6 = ifn_2055.Invoke_O__O(arg_2056) } else { tmp6 = linked_2054.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2053, arg_2056) }; arg_2052 = tmp5.Invoke_O__O(tmp6); if linked_2049 == nil { return ifn_2050.Invoke_O_O__O(arg_2051, arg_2052) } else { return linked_2049.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2048, arg_2051, arg_2052) } } else { var tmp7 any; var root_2057 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2057, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2059 lang.IFn; if linked_2058 == nil { ifn_2059 = lang.IFn_Cast(root_2057) } else { ifn_2059 = nil }; var arg_2060 any = s__400000335__1; if linked_2058 == nil { tmp7 = ifn_2059.Invoke_O__O(arg_2060) } else { tmp7 = linked_2058.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2057, arg_2060) }; s__400000335__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :489:1
func A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_A{}; t.Ctor_O_O(p0, p1); return t }
//line :489:1
func (t *A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_A) Ctor_O_O(c__k, c__p any) { t.F_k = c__k; t.F_p = c__p }
//line :489:1
func (t *A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_A) Invoke_O_O__O(self, s__400000337__1 any) any { var tmp1 any = A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_A_New_O_O_O_O(self, t.F_k, s__400000337__1, t.F_p); var tmp2 *jrt.Class; var fncls__2042 *jrt.Class = A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_A_fn_class; if fncls__2042 == nil { var fncls__2042d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_A_fn_class = fncls__2042d; tmp2 = fncls__2042d } else { tmp2 = fncls__2042 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :489:1
func A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :489:1
func (t *A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_A) Ctor_O_O_O_O(c__iter__400000336, c__k, c__s__400000337, c__p any) { t.F_iter__400000336 = c__iter__400000336; t.F_k = c__k; t.F_s__400000337 = c__s__400000337; t.F_p = c__p }
//line :489:1
func (t *A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_A) Invoke_O__O(self any) any { { var s__400000337__1 any; var t_ any = t.F_s__400000337; t.F_s__400000337 = nil; s__400000337__1 = t_; for { var temp__1927000414__auto____2 any; var root_1985 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1985, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1987 lang.IFn; if linked_1986 == nil { ifn_1987 = lang.IFn_Cast(root_1985) } else { ifn_1987 = nil }; var arg_1988 any = s__400000337__1; if linked_1986 == nil { temp__1927000414__auto____2 = ifn_1987.Invoke_O__O(arg_1988) } else { temp__1927000414__auto____2 = linked_1986.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1985, arg_1988) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000337__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1989 any = A_arbace_c2j_node_A_const_373.GetRawRoot__O(); var linked_1990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1989, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1991 lang.IFn; if linked_1990 == nil { ifn_1991 = lang.IFn_Cast(root_1989) } else { ifn_1991 = nil }; var arg_1992 any = s__400000337__3; if linked_1990 == nil { tmp1 = ifn_1991.Invoke_O__O(arg_1992) } else { tmp1 = linked_1990.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1989, arg_1992) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1993 any = A_arbace_c2j_node_A_const_374.GetRawRoot__O(); var linked_1994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1993, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1995 lang.IFn; if linked_1994 == nil { ifn_1995 = lang.IFn_Cast(root_1993) } else { ifn_1995 = nil }; var arg_1996 any = s__400000337__3; if linked_1994 == nil { c__1927001037__auto____4 = ifn_1995.Invoke_O__O(arg_1996) } else { c__1927001037__auto____4 = linked_1994.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1993, arg_1996) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000339__6 any; var root_1997 any = A_arbace_c2j_node_A_const_375.GetRawRoot__O(); var linked_1998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1997, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1999 lang.IFn; if linked_1998 == nil { ifn_1999 = lang.IFn_Cast(root_1997) } else { ifn_1999 = nil }; var arg_2000 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1998 == nil { b__400000339__6 = ifn_1999.Invoke_O__O(arg_2000) } else { b__400000339__6 = linked_1998.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1997, arg_2000) }; var tmp2 any = A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_fn__400000347_A_New_O_O_O_I_O(t.F_k, t.F_p, b__400000339__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2006 *jrt.Class = A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_fn__400000347_A_fn_class; if fncls__2006 == nil { var fncls__2006d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_fn__400000347_A_fn_class = fncls__2006d; tmp3 = fncls__2006d } else { tmp3 = fncls__2006 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2007 any = A_arbace_c2j_node_A_const_377.GetRawRoot__O(); var linked_2008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2007, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2009 lang.IFn; if linked_2008 == nil { ifn_2009 = lang.IFn_Cast(root_2007) } else { ifn_2009 = nil }; var arg_2010 any; var root_2012 any = A_arbace_c2j_node_A_const_378.GetRawRoot__O(); var linked_2013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2012, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2014 lang.IFn; if linked_2013 == nil { ifn_2014 = lang.IFn_Cast(root_2012) } else { ifn_2014 = nil }; var arg_2015 any = b__400000339__6; if linked_2013 == nil { arg_2010 = ifn_2014.Invoke_O__O(arg_2015) } else { arg_2010 = linked_2013.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2012, arg_2015) }; var arg_2011 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000336); var tmp5 any; var root_2016 any = A_arbace_c2j_node_A_const_379.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2018 lang.IFn; if linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any = s__400000337__3; if linked_2017 == nil { tmp5 = ifn_2018.Invoke_O__O(arg_2019) } else { tmp5 = linked_2017.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2016, arg_2019) }; arg_2011 = tmp4.Invoke_O__O(tmp5); if linked_2008 == nil { return ifn_2009.Invoke_O_O__O(arg_2010, arg_2011) } else { return linked_2008.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2007, arg_2010, arg_2011) } } else { var root_2020 any = A_arbace_c2j_node_A_const_377.GetRawRoot__O(); var linked_2021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2020, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2022 lang.IFn; if linked_2021 == nil { ifn_2022 = lang.IFn_Cast(root_2020) } else { ifn_2022 = nil }; var arg_2023 any; var root_2025 any = A_arbace_c2j_node_A_const_378.GetRawRoot__O(); var linked_2026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2025, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2027 lang.IFn; if linked_2026 == nil { ifn_2027 = lang.IFn_Cast(root_2025) } else { ifn_2027 = nil }; var arg_2028 any = b__400000339__6; if linked_2026 == nil { arg_2023 = ifn_2027.Invoke_O__O(arg_2028) } else { arg_2023 = linked_2026.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2025, arg_2028) }; var arg_2024 any; if linked_2021 == nil { return ifn_2022.Invoke_O_O__O(arg_2023, arg_2024) } else { return linked_2021.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2020, arg_2023, arg_2024) } } } else { var c__4 any; var root_2029 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2029, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2031 lang.IFn; if linked_2030 == nil { ifn_2031 = lang.IFn_Cast(root_2029) } else { ifn_2031 = nil }; var arg_2032 any = s__400000337__3; if linked_2030 == nil { c__4 = ifn_2031.Invoke_O__O(arg_2032) } else { c__4 = linked_2030.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2029, arg_2032) }; var root_2033 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2033, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2035 lang.IFn; if linked_2034 == nil { ifn_2035 = lang.IFn_Cast(root_2033) } else { ifn_2035 = nil }; var arg_2036 any; var tmp6 any = A_arbace_c2j_node_A_const_321; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp8 any = A_arbace_c2j_node_A_const_367.Invoke_O__O(t.F_p); var tmp9 *jrt.String
																			if jrt.J2g_Truth(c__4) { tmp9 = Lit_110 } else { tmp9 = nil }
//line :489:1
	arg_2036 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9.Ref())).Ref(), A_arbace_c2j_node_A_const_176, t.F_p, A_arbace_c2j_node_A_const_383, t.F_k, A_arbace_c2j_node_A_const_73, c__4, A_arbace_c2j_node_A_const_233, lang.PersistentArrayMap_EMPTY.Ref())); var arg_2037 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__400000336); var tmp11 any; var root_2038 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2038, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2040 lang.IFn; if linked_2039 == nil { ifn_2040 = lang.IFn_Cast(root_2038) } else { ifn_2040 = nil }; var arg_2041 any = s__400000337__3; if linked_2039 == nil { tmp11 = ifn_2040.Invoke_O__O(arg_2041) } else { tmp11 = linked_2039.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2038, arg_2041) }; arg_2037 = tmp10.Invoke_O__O(tmp11); if linked_2034 == nil { return ifn_2035.Invoke_O_O__O(arg_2036, arg_2037) } else { return linked_2034.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2033, arg_2036, arg_2037) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :489:1
func A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_fn__400000347_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_fn__400000347_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_fn__400000347_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :489:1
func (t *A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_fn__400000347_A) Ctor_O_O_O_I_O(c__k, c__p, c__b__400000339 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_k = c__k; t.F_p = c__p; t.F_b__400000339 = c__b__400000339; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :489:1
func (t *A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_fn__400000347_A) Invoke_O__O(self any) any { { var i__400000338__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000338__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000338__1)); var root_2001 any = A_arbace_c2j_node_A_const_376.GetRawRoot__O(); var linked_2002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2001, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2003 lang.IFn; if linked_2002 == nil { ifn_2003 = lang.IFn_Cast(root_2001) } else { ifn_2003 = nil }; var arg_2004 any = t.F_b__400000339; var arg_2005 any; var tmp2 any = A_arbace_c2j_node_A_const_321; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp4 any = A_arbace_c2j_node_A_const_367.Invoke_O__O(t.F_p); var tmp5 *jrt.String
																					if jrt.J2g_Truth(c__2) { tmp5 = Lit_110 } else { tmp5 = nil }
//line :489:1
	arg_2005 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref())).Ref(), A_arbace_c2j_node_A_const_176, t.F_p, A_arbace_c2j_node_A_const_383, t.F_k, A_arbace_c2j_node_A_const_73, c__2, A_arbace_c2j_node_A_const_233, lang.PersistentArrayMap_EMPTY.Ref())); if linked_2002 == nil { ifn_2003.Invoke_O_O__O(arg_2004, arg_2005) } else { linked_2002.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2001, arg_2004, arg_2005) }; i__400000338__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000338__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_node_variants_iter__400000353__400000359_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variants_iter__400000353__400000359_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000353__400000359_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :491:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_A) Ctor_O_O_O_O(c__base, c__split_sets, c__dom, c__ss any) { t.F_base = c__base; t.F_split_sets = c__split_sets; t.F_dom = c__dom; t.F_ss = c__ss }
//line :491:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_A) Invoke_O_O__O(self, s__400000354__1 any) any { var tmp1 any = A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_A_New_O_O_O_O_O_O(s__400000354__1, t.F_base, t.F_split_sets, t.F_dom, t.F_ss, self); var tmp2 *jrt.Class; var fncls__2203 *jrt.Class = A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_A_fn_class; if fncls__2203 == nil { var fncls__2203d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_A_fn_class = fncls__2203d; tmp2 = fncls__2203d } else { tmp2 = fncls__2203 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :491:1
func A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :491:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_A) Ctor_O_O_O_O_O_O(c__s__400000354, c__base, c__split_sets, c__dom, c__ss, c__iter__400000353 any) { t.F_s__400000354 = c__s__400000354; t.F_base = c__base; t.F_split_sets = c__split_sets; t.F_dom = c__dom; t.F_ss = c__ss; t.F_iter__400000353 = c__iter__400000353 }
//line :491:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_A) Invoke_O__O(self any) any { { var s__400000354__1 any; var t_ any = t.F_s__400000354; t.F_s__400000354 = nil; s__400000354__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2063 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2063, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2065 lang.IFn; if linked_2064 == nil { ifn_2065 = lang.IFn_Cast(root_2063) } else { ifn_2065 = nil }; var arg_2066 any = s__400000354__1; if linked_2064 == nil { temp__1927000414__auto____2 = ifn_2065.Invoke_O__O(arg_2066) } else { temp__1927000414__auto____2 = linked_2064.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2063, arg_2066) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_2067 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2067, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2069 lang.IFn; if linked_2068 == nil { ifn_2069 = lang.IFn_Cast(root_2067) } else { ifn_2069 = nil }; var arg_2070 any = xs__1927001018__auto____3; if linked_2068 == nil { c__4 = ifn_2069.Invoke_O__O(arg_2070) } else { c__4 = linked_2068.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2067, arg_2070) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_A_New_O_O_O_O(t.F_base, t.F_dom, t.F_ss, c__4); var tmp2 *jrt.Class; var fncls__2185 *jrt.Class = A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_A_fn_class; if fncls__2185 == nil { var fncls__2185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_A_fn_class = fncls__2185d; tmp2 = fncls__2185d } else { tmp2 = fncls__2185 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_2186 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2188 lang.IFn; if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(t.F_split_sets); if linked_2187 == nil { fs__1927001036__auto____6 = ifn_2188.Invoke_O__O(arg_2189) } else { fs__1927001036__auto____6 = linked_2187.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2186, arg_2189) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_2190 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any = fs__1927001036__auto____6; var arg_2194 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__400000353); var tmp4 any; var root_2195 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = s__400000354__1; if linked_2196 == nil { tmp4 = ifn_2197.Invoke_O__O(arg_2198) } else { tmp4 = linked_2196.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2195, arg_2198) }; arg_2194 = tmp3.Invoke_O__O(tmp4); if linked_2191 == nil { return ifn_2192.Invoke_O_O__O(arg_2193, arg_2194) } else { return linked_2191.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2190, arg_2193, arg_2194) } } else { var tmp5 any; var root_2199 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2199, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2201 lang.IFn; if linked_2200 == nil { ifn_2201 = lang.IFn_Cast(root_2199) } else { ifn_2201 = nil }; var arg_2202 any = s__400000354__1; if linked_2200 == nil { tmp5 = ifn_2201.Invoke_O__O(arg_2202) } else { tmp5 = linked_2200.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2199, arg_2202) }; s__400000354__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :491:1
func A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :491:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_A) Ctor_O_O_O_O(c__base, c__dom, c__ss, c__c any) { t.F_base = c__base; t.F_dom = c__dom; t.F_ss = c__ss; t.F_c = c__c }
//line :491:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_A) Invoke_O_O__O(self, s__400000356__1 any) any { var tmp1 any = A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_A_New_O_O_O_O_O_O(s__400000356__1, t.F_base, t.F_dom, t.F_ss, t.F_c, self); var tmp2 *jrt.Class; var fncls__2184 *jrt.Class = A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_A_fn_class; if fncls__2184 == nil { var fncls__2184d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_A_fn_class = fncls__2184d; tmp2 = fncls__2184d } else { tmp2 = fncls__2184 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :491:1
func A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :491:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_A) Ctor_O_O_O_O_O_O(c__s__400000356, c__base, c__dom, c__ss, c__c, c__iter__400000355 any) { t.F_s__400000356 = c__s__400000356; t.F_base = c__base; t.F_dom = c__dom; t.F_ss = c__ss; t.F_c = c__c; t.F_iter__400000355 = c__iter__400000355 }
//line :491:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_A) Invoke_O__O(self any) any { { var s__400000356__1 any; var t_ any = t.F_s__400000356; t.F_s__400000356 = nil; s__400000356__1 = t_; for { var temp__1927000414__auto____2 any; var root_2071 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2071, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2073 lang.IFn; if linked_2072 == nil { ifn_2073 = lang.IFn_Cast(root_2071) } else { ifn_2073 = nil }; var arg_2074 any = s__400000356__1; if linked_2072 == nil { temp__1927000414__auto____2 = ifn_2073.Invoke_O__O(arg_2074) } else { temp__1927000414__auto____2 = linked_2072.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2071, arg_2074) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000356__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2075 any = A_arbace_c2j_node_A_const_373.GetRawRoot__O(); var linked_2076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2075, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2077 lang.IFn; if linked_2076 == nil { ifn_2077 = lang.IFn_Cast(root_2075) } else { ifn_2077 = nil }; var arg_2078 any = s__400000356__3; if linked_2076 == nil { tmp1 = ifn_2077.Invoke_O__O(arg_2078) } else { tmp1 = linked_2076.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2075, arg_2078) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2079 any = A_arbace_c2j_node_A_const_374.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2081 lang.IFn; if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = s__400000356__3; if linked_2080 == nil { c__1927001037__auto____4 = ifn_2081.Invoke_O__O(arg_2082) } else { c__1927001037__auto____4 = linked_2080.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2079, arg_2082) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000358__6 any; var root_2083 any = A_arbace_c2j_node_A_const_375.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2083, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2085 lang.IFn; if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2084 == nil { b__400000358__6 = ifn_2085.Invoke_O__O(arg_2086) } else { b__400000358__6 = linked_2084.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2083, arg_2086) }; var tmp2 any = A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_A_New_O_O_O_I_O_O_O(t.F_base, b__400000358__6, t.F_dom, size__1927001038__auto____5, t.F_ss, c__1927001037__auto____4, t.F_c); var tmp3 *jrt.Class; var fncls__2120 *jrt.Class = A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_A_fn_class; if fncls__2120 == nil { var fncls__2120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_A_fn_class = fncls__2120d; tmp3 = fncls__2120d } else { tmp3 = fncls__2120 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2121 any = A_arbace_c2j_node_A_const_377.GetRawRoot__O(); var linked_2122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2121, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2123 lang.IFn; if linked_2122 == nil { ifn_2123 = lang.IFn_Cast(root_2121) } else { ifn_2123 = nil }; var arg_2124 any; var root_2126 any = A_arbace_c2j_node_A_const_378.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2126, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = b__400000358__6; if linked_2127 == nil { arg_2124 = ifn_2128.Invoke_O__O(arg_2129) } else { arg_2124 = linked_2127.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2126, arg_2129) }; var arg_2125 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000355); var tmp5 any; var root_2130 any = A_arbace_c2j_node_A_const_379.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2132 lang.IFn; if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any = s__400000356__3; if linked_2131 == nil { tmp5 = ifn_2132.Invoke_O__O(arg_2133) } else { tmp5 = linked_2131.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2130, arg_2133) }; arg_2125 = tmp4.Invoke_O__O(tmp5); if linked_2122 == nil { return ifn_2123.Invoke_O_O__O(arg_2124, arg_2125) } else { return linked_2122.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2121, arg_2124, arg_2125) } } else { var root_2134 any = A_arbace_c2j_node_A_const_377.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2136 lang.IFn; if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any; var root_2139 any = A_arbace_c2j_node_A_const_378.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = b__400000358__6; if linked_2140 == nil { arg_2137 = ifn_2141.Invoke_O__O(arg_2142) } else { arg_2137 = linked_2140.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2139, arg_2142) }; var arg_2138 any; if linked_2135 == nil { return ifn_2136.Invoke_O_O__O(arg_2137, arg_2138) } else { return linked_2135.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2134, arg_2137, arg_2138) } } } else { var sp__4 any; var root_2143 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2143, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = s__400000356__3; if linked_2144 == nil { sp__4 = ifn_2145.Invoke_O__O(arg_2146) } else { sp__4 = linked_2144.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2143, arg_2146) }; var root_2147 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2149 lang.IFn; if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any; var tmp6 any = A_arbace_c2j_node_A_const_321; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp8 any = t.F_base; var tmp9 any
																			if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_c2j_node_A_const_219, t.F_c) { tmp9 = Lit_115 } else { var tmp10 any; var root_2152 any = A_arbace_c2j_node_A_const_386.GetRawRoot__O(); var linked_2153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2152, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2154 lang.IFn; if linked_2153 == nil { ifn_2154 = lang.IFn_Cast(root_2152) } else { ifn_2154 = nil }; var arg_2155 any = t.F_c; if linked_2153 == nil { tmp10 = ifn_2154.Invoke_O__O(arg_2155) } else { tmp10 = linked_2153.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2152, arg_2155) }; if jrt.J2g_Truth(tmp10) { tmp9 = t.F_c } else { if A_arbace_c2j_node_A_const_45 != nil { tmp9 = Lit_116 } else { tmp9 = nil } } }
//line :491:1
	var tmp11 any = tmp9; var tmp12 any; var root_2156 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2156, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2158 lang.IFn

	if linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var arg_2159 any = A_arbace_c2j_node_A_const_187.GetRawRoot__O(); var arg_2160 any; var root_2161 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_2162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2161, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2163 lang.IFn; if linked_2162 == nil { ifn_2163 = lang.IFn_Cast(root_2161) } else { ifn_2163 = nil }; var arg_2164 any; var tmp13 any = A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000367_A_New_O(sp__4); var tmp14 *jrt.Class; var fncls__2170 *jrt.Class = A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000367_A_fn_class; if fncls__2170 == nil { var fncls__2170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000367_A_fn_class = fncls__2170d; tmp14 = fncls__2170d } else { tmp14 = fncls__2170 }; arg_2164 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_2165 any = t.F_ss; if linked_2162 == nil { arg_2160 = ifn_2163.Invoke_O_O__O(arg_2164, arg_2165) } else { arg_2160 = linked_2162.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2161, arg_2164, arg_2165) }; if linked_2157 == nil { tmp12 = ifn_2158.Invoke_O_O__O(arg_2159, arg_2160) } else { tmp12 = linked_2157.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2156, arg_2159, arg_2160) }
//line :491:1
	var tmp15 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp11, tmp12)).Ref(); var tmp16 any = A_arbace_c2j_node_A_const_233; var tmp17 any = A_arbace_c2j_node_A_const_220; var tmp18 any = t.F_c; var tmp19 any = A_arbace_c2j_node_A_const_313; var tmp20 any



	if jrt.J2g_Truth(t.F_dom) { var root_2171 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2171, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2173 lang.IFn; if linked_2172 == nil { ifn_2173 = lang.IFn_Cast(root_2171) } else { ifn_2173 = nil }; var arg_2174 any; var root_2175 any = A_arbace_c2j_node_A_const_274.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any = A_arbace_c2j_node_A_const_387.GetRawRoot__O(); var arg_2179 any = lang.RT_Get_O_O__O_NoInit(t.F_dom, t.F_c); if linked_2176 == nil { arg_2174 = ifn_2177.Invoke_O_O__O(arg_2178, arg_2179) } else { arg_2174 = linked_2176.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2175, arg_2178, arg_2179) }; if linked_2172 == nil { tmp20 = ifn_2173.Invoke_O__O(arg_2174) } else { tmp20 = linked_2172.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2171, arg_2174) } } else { tmp20 = nil }
//line :491:1
	arg_2150 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp15, tmp16, sp__4, tmp17, tmp18, tmp19, tmp20)); var arg_2151 any; var tmp21 lang.IFn = lang.IFn_Cast(t.F_iter__400000355); var tmp22 any; var root_2180 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2180, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2182 lang.IFn; if linked_2181 == nil { ifn_2182 = lang.IFn_Cast(root_2180) } else { ifn_2182 = nil }; var arg_2183 any = s__400000356__3; if linked_2181 == nil { tmp22 = ifn_2182.Invoke_O__O(arg_2183) } else { tmp22 = linked_2181.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2180, arg_2183) }; arg_2151 = tmp21.Invoke_O__O(tmp22); if linked_2148 == nil { return ifn_2149.Invoke_O_O__O(arg_2150, arg_2151) } else { return linked_2148.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2147, arg_2150, arg_2151) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :491:1
func A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_A_New_O_O_O_I_O_O_O(p0, p1, p2 any, p3 int32, p4, p5, p6 any) *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_A{}; t.Ctor_O_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :491:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_A) Ctor_O_O_O_I_O_O_O(c__base, c__b__400000358, c__dom any, c__size__1927001038__auto__ int32, c__ss, c__c__1927001037__auto__, c__c any) { t.F_base = c__base; t.F_b__400000358 = c__b__400000358; t.F_dom = c__dom; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ss = c__ss; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_c = c__c }
//line :491:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_A) Invoke_O__O(self any) any { { var i__400000357__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000357__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var sp__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000357__1)); var root_2087 any = A_arbace_c2j_node_A_const_376.GetRawRoot__O(); var linked_2088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2087, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2089 lang.IFn; if linked_2088 == nil { ifn_2089 = lang.IFn_Cast(root_2087) } else { ifn_2089 = nil }; var arg_2090 any = t.F_b__400000358; var arg_2091 any; var tmp2 any = A_arbace_c2j_node_A_const_321; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp4 any = t.F_base; var tmp5 any
																					if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_c2j_node_A_const_219, t.F_c) { tmp5 = Lit_115 } else { var tmp6 any; var root_2092 any = A_arbace_c2j_node_A_const_386.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2094 lang.IFn; if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = t.F_c; if linked_2093 == nil { tmp6 = ifn_2094.Invoke_O__O(arg_2095) } else { tmp6 = linked_2093.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2092, arg_2095) }; if jrt.J2g_Truth(tmp6) { tmp5 = t.F_c } else { if A_arbace_c2j_node_A_const_45 != nil { tmp5 = Lit_116 } else { tmp5 = nil } } }
//line :491:1
	var tmp7 any = tmp5; var tmp8 any; var root_2096 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2096, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2098 lang.IFn

	if linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any = A_arbace_c2j_node_A_const_187.GetRawRoot__O(); var arg_2100 any; var root_2101 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_2102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2101, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2103 lang.IFn; if linked_2102 == nil { ifn_2103 = lang.IFn_Cast(root_2101) } else { ifn_2103 = nil }; var arg_2104 any; var tmp9 any = A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_fn__400000364_A_New_O(sp__2); var tmp10 *jrt.Class; var fncls__2110 *jrt.Class = A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_fn__400000364_A_fn_class; if fncls__2110 == nil { var fncls__2110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_fn__400000364_A_fn_class = fncls__2110d; tmp10 = fncls__2110d } else { tmp10 = fncls__2110 }; arg_2104 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_2105 any = t.F_ss; if linked_2102 == nil { arg_2100 = ifn_2103.Invoke_O_O__O(arg_2104, arg_2105) } else { arg_2100 = linked_2102.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2101, arg_2104, arg_2105) }; if linked_2097 == nil { tmp8 = ifn_2098.Invoke_O_O__O(arg_2099, arg_2100) } else { tmp8 = linked_2097.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2096, arg_2099, arg_2100) }
//line :491:1
	var tmp11 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8)).Ref(); var tmp12 any = A_arbace_c2j_node_A_const_233; var tmp13 any = A_arbace_c2j_node_A_const_220; var tmp14 any = t.F_c; var tmp15 any = A_arbace_c2j_node_A_const_313; var tmp16 any



	if jrt.J2g_Truth(t.F_dom) { var root_2111 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2111, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2113 lang.IFn; if linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; var arg_2114 any; var root_2115 any = A_arbace_c2j_node_A_const_274.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2115, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2117 lang.IFn; if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any = A_arbace_c2j_node_A_const_387.GetRawRoot__O(); var arg_2119 any = lang.RT_Get_O_O__O_NoInit(t.F_dom, t.F_c); if linked_2116 == nil { arg_2114 = ifn_2117.Invoke_O_O__O(arg_2118, arg_2119) } else { arg_2114 = linked_2116.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2115, arg_2118, arg_2119) }; if linked_2112 == nil { tmp16 = ifn_2113.Invoke_O__O(arg_2114) } else { tmp16 = linked_2112.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2111, arg_2114) } } else { tmp16 = nil }
//line :491:1
	arg_2091 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp11, tmp12, sp__2, tmp13, tmp14, tmp15, tmp16)); if linked_2088 == nil { ifn_2089.Invoke_O_O__O(arg_2090, arg_2091) } else { linked_2088.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2087, arg_2090, arg_2091) }; i__400000357__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000357__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_fn__400000364_A_New_O(p0 any) *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_fn__400000364_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_fn__400000364_A{}; t.Ctor_O(p0); return t }
//line :493:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_fn__400000364_A) Ctor_O(c__sp any) { t.F_sp = c__sp }
//line :493:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_fn__400000364_A) Invoke_O_O__O(self, s__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_sp).Invoke_O__O(s__1)) { var root_2106 any = A_arbace_c2j_node_A_const_368.GetRawRoot__O(); var linked_2107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2106, A_arbace_c2j_node_camel_A_fn_class); var ifn_2108 lang.IFn; if linked_2107 == nil { ifn_2108 = lang.IFn_Cast(root_2106) } else { ifn_2108 = nil }; var arg_2109 any = s__1; if linked_2107 == nil { return ifn_2108.Invoke_O__O(arg_2109) } else { return linked_2107.(*A_arbace_c2j_node_camel_A).Invoke_O_O__O(root_2106, arg_2109) } } else { return nil } }
//line :493:1
func A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000367_A_New_O(p0 any) *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000367_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000367_A{}; t.Ctor_O(p0); return t }
//line :493:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000367_A) Ctor_O(c__sp any) { t.F_sp = c__sp }
//line :493:1
func (t *A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000367_A) Invoke_O_O__O(self, s__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_sp).Invoke_O__O(s__1)) { var root_2166 any = A_arbace_c2j_node_A_const_368.GetRawRoot__O(); var linked_2167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2166, A_arbace_c2j_node_camel_A_fn_class); var ifn_2168 lang.IFn; if linked_2167 == nil { ifn_2168 = lang.IFn_Cast(root_2166) } else { ifn_2168 = nil }; var arg_2169 any = s__1; if linked_2167 == nil { return ifn_2168.Invoke_O__O(arg_2169) } else { return linked_2167.(*A_arbace_c2j_node_camel_A).Invoke_O_O__O(root_2166, arg_2169) } } else { return nil } }



func A_arbace_c2j_node_clause_A_New() *A_arbace_c2j_node_clause_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_A{}; t.Ctor(); return t }
//line :497:1
func (t *A_arbace_c2j_node_clause_A) Ctor() {}
//line :497:1
func (t *A_arbace_c2j_node_clause_A) Invoke_O_O_O__O(self, d__0, vs__1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_389; var exprs__3 any = tmp1.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0)); var one__4 any; if




	lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(exprs__3))) { var root_2205 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2205, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2207 lang.IFn; if linked_2206 == nil { ifn_2207 = lang.IFn_Cast(root_2205) } else { ifn_2207 = nil }; var arg_2208 any = exprs__3; if linked_2206 == nil { one__4 = ifn_2207.Invoke_O__O(arg_2208) } else { one__4 = linked_2206.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2205, arg_2208) } } else { one__4 = nil }; var test__5 any; if
	jrt.J2g_Truth(one__4) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_node_A_const_410; var tmp4 any; var root_2373 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_2374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2373, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2375 lang.IFn; if linked_2374 == nil { ifn_2375 = lang.IFn_Cast(root_2373) } else { ifn_2375 = nil }; var arg_2376 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, one__4)).Ref(); if linked_2374 == nil { tmp4 = ifn_2375.Invoke_O__O(arg_2376) } else { tmp4 = linked_2374.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2373, arg_2376) }; test__5 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_c2j_node_A_const_411) } else {
			var root_2209 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2209, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2211 lang.IFn; if linked_2210 == nil { ifn_2211 = lang.IFn_Cast(root_2209) } else { ifn_2211 = nil }; var arg_2212 any = A_arbace_c2j_node_A_const_390; var arg_2213 any; var root_2214 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_2215 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2214, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2216 lang.IFn; if linked_2215 == nil { ifn_2216 = lang.IFn_Cast(root_2214) } else { ifn_2216 = nil }; var arg_2217 any; var tmp5 any = A_arbace_c2j_node_clause_fn__400000377_A_New(); var tmp6 *jrt.Class; var fncls__2223 *jrt.Class = A_arbace_c2j_node_clause_fn__400000377_A_fn_class; if fncls__2223 == nil { var fncls__2223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_c2j_node_clause_fn__400000377_A_fn_class = fncls__2223d; tmp6 = fncls__2223d } else { tmp6 = fncls__2223 }; arg_2217 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_2218 any = exprs__3; if linked_2215 == nil { arg_2213 = ifn_2216.Invoke_O_O__O(arg_2217, arg_2218) } else { arg_2213 = linked_2215.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2214, arg_2217, arg_2218) }; if linked_2210 == nil { test__5 = ifn_2211.Invoke_O_O__O(arg_2212, arg_2213) } else { test__5 = linked_2210.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2209, arg_2212, arg_2213) } }; var fields__6 any; var root_2224 any = /*line :497:1*/A_arbace_c2j_node_A_const_165.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2224, A_arbace_c2j_node_field_names_A_fn_class); var ifn_2226 lang.IFn; if








	linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any = d__0; if linked_2225 == nil { fields__6 = ifn_2226.Invoke_O__O(arg_2227) } else { fields__6 = linked_2225.(*A_arbace_c2j_node_field_names_A).Invoke_O_O__O(root_2224, arg_2227) }; var fbinds__7 any; var tmp7 lang.IFn = /*line :497:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_node_clause_fn__400000379_A_New(); var tmp9 *jrt.Class; var fncls__2237 *jrt.Class = A_arbace_c2j_node_clause_fn__400000379_A_fn_class; if









	fncls__2237 == nil { var fncls__2237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_c2j_node_clause_fn__400000379_A_fn_class = fncls__2237d; tmp9 = fncls__2237d } else { tmp9 = fncls__2237 }; fbinds__7 = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), fields__6); var cb__8 any; var root_2238 any = /*line :497:1*/A_arbace_c2j_node_A_const_327.GetRawRoot__O(); var linked_2239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2238, A_arbace_c2j_node_children_bind_A_fn_class); var ifn_2240 lang.IFn; if










	linked_2239 == nil { ifn_2240 = lang.IFn_Cast(root_2238) } else { ifn_2240 = nil }; var arg_2241 any = d__0; if linked_2239 == nil { cb__8 = ifn_2240.Invoke_O__O(arg_2241) } else { cb__8 = linked_2239.(*A_arbace_c2j_node_children_bind_A).Invoke_O_O__O(root_2238, arg_2241) }; var conv__9 any; if
	jrt.J2g_Truth(cb__8) { var tmp10 *lang.Keyword = A_arbace_c2j_node_A_const_328; var tmp11 any; var root_2242 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_2243 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2242, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2244 lang.IFn; if linked_2243 == nil { ifn_2244 = lang.IFn_Cast(root_2242) } else { ifn_2244 = nil }; var arg_2245 any = A_arbace_c2j_node_A_const_241.GetRawRoot__O(); var arg_2246 any; var root_2247 any = A_arbace_c2j_node_A_const_329.GetRawRoot__O(); var linked_2248 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2247, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2249 lang.IFn; if linked_2248 == nil { ifn_2249 = lang.IFn_Cast(root_2247) } else { ifn_2249 = nil }; var arg_2251 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(cb__8); if linked_2248 == nil { arg_2246 = ifn_2249.Invoke_O_O__O(A_arbace_c2j_node_A_const_25, arg_2251) } else { arg_2246 = linked_2248.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2247, 2, A_arbace_c2j_node_A_const_25, arg_2251) }; if linked_2243 == nil { tmp11 = ifn_2244.Invoke_O_O__O(arg_2245, arg_2246) } else { tmp11 = linked_2243.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2242, arg_2245, arg_2246) }; conv__9 = tmp10.Invoke_O__O(tmp11) } else { conv__9 = nil }; var binds__10 any; var root_2252 any = /*line :497:1*/A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2252, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2254 lang.IFn; if












	linked_2253 == nil { ifn_2254 = lang.IFn_Cast(root_2252) } else { ifn_2254 = nil }; var arg_2255 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp13 lang.IPersistentVector; if
	jrt.J2g_Truth(one__4) { var tmp14 any = A_arbace_c2j_node_A_const_394; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_node_A_const_395; var tmp17 any; var root_2263 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_2264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2263, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2265 lang.IFn; if linked_2264 == nil { ifn_2265 = lang.IFn_Cast(root_2263) } else { ifn_2265 = nil }; var arg_2266 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, one__4)).Ref(); if linked_2264 == nil { tmp17 = ifn_2265.Invoke_O__O(arg_2266) } else { tmp17 = linked_2264.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2263, arg_2266) }; tmp13 = lang.Tuple_Create_O_O__IPersistentVector(tmp14, tmp15.Invoke_O_O_O__O(tmp16, tmp17, A_arbace_c2j_node_A_const_396)) } else { tmp13 = nil }; var tmp18 any = tmp13; var tmp19 lang.IFn = /*line :510:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp20 any = A_arbace_c2j_node_clause_fn__400000381_A_New(); var tmp21 *jrt.Class; var fncls__2285 *jrt.Class = A_arbace_c2j_node_clause_fn__400000381_A_fn_class; if


	fncls__2285 == nil { var fncls__2285d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_c2j_node_clause_fn__400000381_A_fn_class = fncls__2285d; tmp21 = fncls__2285d } else { tmp21 = fncls__2285 }; var tmp22 any = /*line :510:1*/tmp19.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil), A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0)); var tmp23 lang.IPersistentVector; if








	jrt.J2g_Truth(conv__9) { tmp23 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_c2j_node_A_const_402, conv__9) } else { tmp23 = nil }; arg_2255 = /*line :510:1*/tmp12.Invoke_O_O_O_O__O(tmp18, fbinds__7, tmp22, tmp23); if linked_2253 == nil { binds__10 = ifn_2254.Invoke_O__O(arg_2255) } else { binds__10 = linked_2253.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2252, arg_2255) }; var ss__11 any; var root_2286 any = /*line :497:1*/A_arbace_c2j_node_A_const_369.GetRawRoot__O(); var linked_2287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2286, A_arbace_c2j_node_splits_A_fn_class); var ifn_2288 lang.IFn; if






















	linked_2287 == nil { ifn_2288 = lang.IFn_Cast(root_2286) } else { ifn_2288 = nil }; var arg_2289 any = d__0; if linked_2287 == nil { ss__11 = ifn_2288.Invoke_O__O(arg_2289) } else { ss__11 = linked_2287.(*A_arbace_c2j_node_splits_A).Invoke_O_O__O(root_2286, arg_2289) }; var construct__12 any; var tmp24 any = /*line :497:1*/A_arbace_c2j_node_clause_construct__400000385_A_New(); var tmp25 *jrt.Class; var fncls__2305 *jrt.Class = A_arbace_c2j_node_clause_construct__400000385_A_fn_class; if























	fncls__2305 == nil { var fncls__2305d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_c2j_node_clause_construct__400000385_A_fn_class = fncls__2305d; tmp25 = fncls__2305d } else { tmp25 = fncls__2305 }; construct__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var pick__13 any; var tmp26 any = /*line :497:1*/A_arbace_c2j_node_clause_pick__400000390_A_New_O_O(construct__12, ss__11); var tmp27 *jrt.Class; var fncls__2347 *jrt.Class = A_arbace_c2j_node_clause_pick__400000390_A_fn_class; if
























	fncls__2347 == nil { var fncls__2347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_c2j_node_clause_pick__400000390_A_fn_class = fncls__2347d; tmp27 = fncls__2347d } else { tmp27 = fncls__2347 }; pick__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var by_count__14 any; var root_2348 any = /*line :497:1*/A_arbace_c2j_node_A_const_405.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_2350 lang.IFn; if


































	linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any; var root_2353 any = A_arbace_c2j_node_A_const_406.GetRawRoot__O(); var linked_2354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2353, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_2355 lang.IFn; if linked_2354 == nil { ifn_2355 = lang.IFn_Cast(root_2353) } else { ifn_2355 = nil }; var arg_2356 any = A_arbace_c2j_node_A_const_220; var arg_2357 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); if linked_2354 == nil { arg_2351 = ifn_2355.Invoke_O_O__O(arg_2356, arg_2357) } else { arg_2351 = linked_2354.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_2353, arg_2356, arg_2357) }; var arg_2352 any = vs__1; if linked_2349 == nil { by_count__14 = ifn_2350.Invoke_O_O__O(arg_2351, arg_2352) } else { by_count__14 = linked_2349.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_2348, arg_2351, arg_2352) }; var counted__15 any; var root_2358 any = /*line :497:1*/A_arbace_c2j_node_A_const_407.GetRawRoot__O(); var linked_2359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2358, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2360 lang.IFn; if



































	linked_2359 == nil { ifn_2360 = lang.IFn_Cast(root_2358) } else { ifn_2360 = nil }; var arg_2361 any = A_arbace_c2j_node_A_const_408.GetRawRoot__O(); var arg_2362 any; var root_2363 any = A_arbace_c2j_node_A_const_32.GetRawRoot__O(); var linked_2364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2363, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2365 lang.IFn; if linked_2364 == nil { ifn_2365 = lang.IFn_Cast(root_2363) } else { ifn_2365 = nil }; var arg_2366 any; var root_2368 any = A_arbace_c2j_node_A_const_406.GetRawRoot__O(); var linked_2369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2368, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_2370 lang.IFn; if linked_2369 == nil { ifn_2370 = lang.IFn_Cast(root_2368) } else { ifn_2370 = nil }; var arg_2371 any = A_arbace_c2j_node_A_const_409.GetRawRoot__O(); var arg_2372 any = A_arbace_c2j_node_A_const_408.GetRawRoot__O(); if linked_2369 == nil { arg_2366 = ifn_2370.Invoke_O_O__O(arg_2371, arg_2372) } else { arg_2366 = linked_2369.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_2368, arg_2371, arg_2372) }; var arg_2367 any = by_count__14; if linked_2364 == nil { arg_2362 = ifn_2365.Invoke_O_O__O(arg_2366, arg_2367) } else { arg_2362 = linked_2364.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2363, arg_2366, arg_2367) }; if linked_2359 == nil { counted__15 = ifn_2360.Invoke_O_O__O(arg_2361, arg_2362) } else { counted__15 = linked_2359.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2358, arg_2361, arg_2362) }; var body__16 any; var tmp28 /*line :497:1*/*lang.Keyword = A_arbace_c2j_node_A_const_381; if




































	jrt.J2g_Truth(tmp28.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0))) {

		var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp30 any = A_arbace_c2j_node_A_const_412; var tmp31 any = A_arbace_c2j_node_A_const_417; var tmp32 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_419, A_arbace_c2j_node_A_const_420, A_arbace_c2j_node_A_const_421); var tmp33 any = A_arbace_c2j_node_A_const_418; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp35 any = A_arbace_c2j_node_A_const_422; var tmp36 any = A_arbace_c2j_node_A_const_423; var tmp37 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp31, tmp32, tmp33, tmp34.Invoke_O_O_O__O(tmp35, tmp36, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_424, A_arbace_c2j_node_A_const_425, A_arbace_c2j_node_A_const_426))); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp39 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_413); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp41 any = A_arbace_c2j_node_clause_fn__400000399_A_New_O(pick__13); var tmp42 *jrt.Class
		var fncls__2388 /*line :536:1*/*jrt.Class = A_arbace_c2j_node_clause_fn__400000399_A_fn_class

		if fncls__2388 == nil { var fncls__2388d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_c2j_node_clause_fn__400000399_A_fn_class = fncls__2388d; tmp42 = fncls__2388d } else { tmp42 = fncls__2388 }
//line :536:1
		body__16 = tmp29.Invoke_O_O_O__O(tmp30, tmp37, tmp38.Invoke_O_O_O__O(tmp39, tmp40.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil), counted__15), A_arbace_c2j_node_A_const_416)) } else {
//line :534:1
			if jrt.J2g_Truth(cb__8) {





				var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp44 any = A_arbace_c2j_node_A_const_427; var tmp45 any = A_arbace_c2j_node_A_const_431; var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp47 any = A_arbace_c2j_node_A_const_432; var tmp48 any; var root_2401 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2401, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2403 lang.IFn; if linked_2402 == nil { ifn_2403 = lang.IFn_Cast(root_2401) } else { ifn_2403 = nil }; var arg_2404 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(cb__8); if linked_2402 == nil { tmp48 = ifn_2403.Invoke_O__O(arg_2404) } else { tmp48 = linked_2402.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2401, arg_2404) }; var tmp49 any = lang.Tuple_Create_O_O__IPersistentVector(tmp45, tmp46.Invoke_O_O__O(tmp47, tmp48)); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp51 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_428); var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp53 any = A_arbace_c2j_node_clause_fn__400000405_A_New_O(pick__13); var tmp54 *jrt.Class; var fncls__2400 *jrt.Class = A_arbace_c2j_node_clause_fn__400000405_A_fn_class
				if fncls__2400 == nil { var fncls__2400d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_c2j_node_clause_fn__400000405_A_fn_class = fncls__2400d; tmp54 = fncls__2400d } else { tmp54 = fncls__2400 }
//line :540:1
				var tmp55 any = tmp52.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil), counted__15); var tmp56 any = A_arbace_c2j_node_A_const_45; var tmp57 any; var temp__1927000414__auto____16 any = lang.IFn_Cast(by_count__14).Invoke_O__O(A_arbace_c2j_node_A_const_219)

				if jrt.J2g_Truth(temp__1927000414__auto____16) { var m__17 any = temp__1927000414__auto____16; tmp57 = lang.IFn_Cast(pick__13).Invoke_O__O(m__17) } else { tmp57 = nil }
//line :540:1
				body__16 = tmp43.Invoke_O_O_O__O(tmp44, tmp49, tmp50.Invoke_O_O_O__O(tmp51, tmp55, lang.Tuple_Create_O_O__IPersistentVector(tmp56, tmp57))) } else {
//line :534:1
					if A_arbace_c2j_node_A_const_45 != nil {








						body__16 = lang.IFn_Cast(pick__13).Invoke_O__O(vs__1) } else {
//line :534:1
							body__16 = nil } } }; var tmp58 any; var tmp59 /*line :497:1*/*lang.Keyword = A_arbace_c2j_node_A_const_433; var tmp60 *lang.Keyword = A_arbace_c2j_node_A_const_381; var temp__1927000408__auto____17 any = tmp59.Invoke_O__O(tmp60.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0))); if














































	jrt.J2g_Truth(temp__1927000408__auto____17) { var ix__18 any = temp__1927000408__auto____17; var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp62 any = A_arbace_c2j_node_A_const_434; var tmp63 any; var root_2405 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2405, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2407 lang.IFn
		if linked_2406 == nil { ifn_2407 = lang.IFn_Cast(root_2405) } else { ifn_2407 = nil }; var arg_2408 any; var tmp64 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp65 any = A_arbace_c2j_node_A_const_435; var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp67 any = A_arbace_c2j_node_A_const_436; var tmp68 any; var root_2415 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_2416 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2415, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2417 lang.IFn; if linked_2416 == nil { ifn_2417 = lang.IFn_Cast(root_2415) } else { ifn_2417 = nil }; var arg_2418 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, one__4)).Ref(); if linked_2416 == nil { tmp68 = ifn_2417.Invoke_O__O(arg_2418) } else { tmp68 = linked_2416.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2415, arg_2418) }; arg_2408 = tmp64.Invoke_O_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp65, tmp66.Invoke_O_O_O__O(tmp67, tmp68, A_arbace_c2j_node_A_const_437)), fbinds__7, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_c2j_node_A_const_438, ix__18)); if linked_2406 == nil { tmp63 = ifn_2407.Invoke_O__O(arg_2408) } else { tmp63 = linked_2406.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2405, arg_2408) }; var tmp69 any = tmp63; var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp71 any = A_arbace_c2j_node_A_const_439; var tmp72 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_440, A_arbace_c2j_node_A_const_441, A_arbace_c2j_node_A_const_252); var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp74 any = A_arbace_c2j_node_A_const_442; var tmp75 any; var root_2419 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2420 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2419, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2421 lang.IFn
		if linked_2420 == nil { ifn_2421 = lang.IFn_Cast(root_2419) } else { ifn_2421 = nil }; var arg_2422 any; var root_2423 any = A_arbace_c2j_node_A_const_329.GetRawRoot__O(); var linked_2424 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2423, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2425 lang.IFn; if linked_2424 == nil { ifn_2425 = lang.IFn_Cast(root_2423) } else { ifn_2425 = nil }; var arg_2426 int64 = lang.Numbers_Add_J_J__J_NoInit(2, int64(lang.RT_Count_O__I_NoInit(fbinds__7))); var arg_2427 any = binds__10; if linked_2424 == nil { arg_2422 = ifn_2425.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_2426).Ref(), arg_2427) } else { arg_2422 = linked_2424.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2423, arg_2426, nil, arg_2427) }; if linked_2420 == nil { tmp75 = ifn_2421.Invoke_O__O(arg_2422) } else { tmp75 = linked_2420.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2419, arg_2422) }
//line :545:1
		tmp58 = tmp61.Invoke_O_O_O__O(tmp62, tmp69, tmp70.Invoke_O_O_O_O__O(tmp71, tmp72, nil, tmp73.Invoke_O_O_O__O(tmp74, tmp75, body__16))) } else {

			tmp58 = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_443, binds__10, body__16) }; return /*line :497:1*/ lang.Tuple_Create_O_O__IPersistentVector(test__5, tmp58) }







func A_arbace_c2j_node_clause_fn__400000377_A_New() *A_arbace_c2j_node_clause_fn__400000377_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000377_A{}; t.Ctor(); return t }
//line :505:1
func (t *A_arbace_c2j_node_clause_fn__400000377_A) Ctor() {}
//line :505:1
func (t *A_arbace_c2j_node_clause_fn__400000377_A) Invoke_O_O__O(self, p1__400000374_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_391; var tmp3 any; var root_2219 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_2220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2219, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2221 lang.IFn; if linked_2220 == nil { ifn_2221 = lang.IFn_Cast(root_2219) } else { ifn_2221 = nil }; var arg_2222 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__400000374_SHARP___1)).Ref(); if linked_2220 == nil { tmp3 = ifn_2221.Invoke_O__O(arg_2222) } else { tmp3 = linked_2220.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2219, arg_2222) }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_c2j_node_A_const_392) }

func A_arbace_c2j_node_clause_fn__400000379_A_New() *A_arbace_c2j_node_clause_fn__400000379_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000379_A{}; t.Ctor(); return t }
//line :507:1
func (t *A_arbace_c2j_node_clause_fn__400000379_A) Ctor() {}
//line :507:1
func (t *A_arbace_c2j_node_clause_fn__400000379_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any; var root_2233 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_2234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2233, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2235 lang.IFn; if linked_2234 == nil { ifn_2235 = lang.IFn_Cast(root_2233) } else { ifn_2235 = nil }; var arg_2236 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1)).Ref(); if linked_2234 == nil { tmp2 = ifn_2235.Invoke_O__O(arg_2236) } else { tmp2 = linked_2234.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2233, arg_2236) }; return lang.Tuple_Create_O_O__IPersistentVector(f__1, tmp1.Invoke_O_O__O(tmp2, A_arbace_c2j_node_A_const_393)) }





func A_arbace_c2j_node_clause_fn__400000381_A_New() *A_arbace_c2j_node_clause_fn__400000381_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000381_A{}; t.Ctor(); return t }
//line :513:1
func (t *A_arbace_c2j_node_clause_fn__400000381_A) Ctor() {}
//line :513:1
func (t *A_arbace_c2j_node_clause_fn__400000381_A) Invoke_O_O__O(self, b__1 any) any { var G__400000382__2_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__1); switch
											lang.Util_Hash_O__I_NoInit(G__400000382__2_) >> 0 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__400000382__2_, A_arbace_c2j_node_A_const_397) { var tmp1 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_node_A_const_400; var tmp4 any = A_arbace_c2j_node_A_const_401; var tmp5 any; var root_2273 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2273, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2275 lang.IFn
												if linked_2274 == nil { ifn_2275 = lang.IFn_Cast(root_2273) } else { ifn_2275 = nil }; var arg_2276 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_2274 == nil { tmp5 = ifn_2275.Invoke_O__O(arg_2276) } else { tmp5 = linked_2274.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2273, arg_2276) }
//line :514:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__400000382__2_, A_arbace_c2j_node_A_const_398) { var tmp6 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp7 any; var root_2277 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_2278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2277, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2279 lang.IFn

			if linked_2278 == nil { ifn_2279 = lang.IFn_Cast(root_2277) } else { ifn_2279 = nil }; var arg_2280 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_2278 == nil { tmp7 = ifn_2279.Invoke_O__O(arg_2280) } else { tmp7 = linked_2278.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2277, arg_2280) }
//line :514:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000382__2_, A_arbace_c2j_node_A_const_399) { var tmp8 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp9 any; var root_2281 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_2282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2281, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2283 lang.IFn

				if linked_2282 == nil { ifn_2283 = lang.IFn_Cast(root_2281) } else { ifn_2283 = nil }; var arg_2284 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_2282 == nil { tmp9 = ifn_2283.Invoke_O__O(arg_2284) } else { tmp9 = linked_2282.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2281, arg_2284) }
//line :514:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9) }; default:}; return nil }






func A_arbace_c2j_node_clause_construct__400000385_A_New() *A_arbace_c2j_node_clause_construct__400000385_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_construct__400000385_A{}; t.Ctor(); return t }
//line :521:1
func (t *A_arbace_c2j_node_clause_construct__400000385_A) Ctor() {}
//line :521:1
func (t *A_arbace_c2j_node_clause_construct__400000385_A) Invoke_O_O__O(self, p__400000384__1 any) any { var vec__400000386__2 any = p__400000384__1; var v__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000386__2, lang.RT_IntCast_J__I_NoInit(0), nil); var fields__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000386__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2290 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_2291 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2290, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_2292 lang.IFn; if linked_2291 == nil { ifn_2292 = lang.IFn_Cast(root_2290) } else { ifn_2292 = nil }; var arg_2293 any = A_arbace_c2j_node_A_const_403; var arg_2294 any; var root_2296 any = A_arbace_c2j_node_A_const_140.GetRawRoot__O(); var linked_2297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2296, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2298 lang.IFn; if linked_2297 == nil { ifn_2298 = lang.IFn_Cast(root_2296) } else { ifn_2298 = nil }; var arg_2299 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_node_A_const_321.Invoke_O__O(v__3))).Ref(); if linked_2297 == nil { arg_2294 = ifn_2298.Invoke_O__O(arg_2299) } else { arg_2294 = linked_2297.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2296, arg_2299) }; var arg_2295 any; var root_2300 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_2301 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2300, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2302 lang.IFn; if linked_2301 == nil { ifn_2302 = lang.IFn_Cast(root_2300) } else { ifn_2302 = nil }; var arg_2303 any = A_arbace_c2j_node_A_const_333; var arg_2304 any = fields__4; if linked_2301 == nil { arg_2295 = ifn_2302.Invoke_O_O__O(arg_2303, arg_2304) } else { arg_2295 = linked_2301.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2300, arg_2303, arg_2304) }; if linked_2291 == nil { return ifn_2292.Invoke_O_O_O__O(arg_2293, arg_2294, arg_2295) } else { return linked_2291.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_2290, arg_2293, arg_2294, arg_2295) } }
func A_arbace_c2j_node_clause_pick__400000390_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_clause_pick__400000390_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_pick__400000390_A{}; t.Ctor_O_O(p0, p1); return t }
//line :522:1
func (t *A_arbace_c2j_node_clause_pick__400000390_A) Ctor_O_O(c__construct, c__ss any) { t.F_construct = c__construct; t.F_ss = c__ss }
//line :522:1
func (t *A_arbace_c2j_node_clause_pick__400000390_A) Invoke_O_O__O(self, vfs__1 any) any { var body_go__2 *A_arbace_c2j_node_clause_pick__400000390_go__400000391_A = A_arbace_c2j_node_clause_pick__400000390_go__400000391_A_New_O(t.F_construct); var go__2 any; var tmp1 *jrt.Class; var fncls__2346 *jrt.Class = A_arbace_c2j_node_clause_pick__400000390_go__400000391_A_fn_class; if fncls__2346 == nil { var fncls__2346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_c2j_node_clause_pick__400000390_go__400000391_A_fn_class = fncls__2346d; tmp1 = fncls__2346d } else { tmp1 = fncls__2346 }; go__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_go__2), tmp1, nil); return /*line :531:1*/ lang.IFn_Cast(go__2).Invoke_O_O__O(t.F_ss, vfs__1) }
//line :524:1
func A_arbace_c2j_node_clause_pick__400000390_go__400000391_A_New_O(p0 any) *A_arbace_c2j_node_clause_pick__400000390_go__400000391_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_pick__400000390_go__400000391_A{}; t.Ctor_O(p0); return t }
//line :524:1
func (t *A_arbace_c2j_node_clause_pick__400000390_go__400000391_A) Ctor_O(c__construct any) { t.F_construct = c__construct }
//line :524:1
func (t *A_arbace_c2j_node_clause_pick__400000390_go__400000391_A) Invoke_O_O_O__O(self, ss__1, vfs__2 any) any {
	var tmp1 any; var root_2306 any = A_arbace_c2j_node_A_const_61.GetRawRoot__O(); var linked_2307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2306, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2308 lang.IFn; if linked_2307 == nil { ifn_2308 = lang.IFn_Cast(root_2306) } else { ifn_2308 = nil }; var arg_2309 any = ss__1; if linked_2307 == nil { tmp1 = ifn_2308.Invoke_O__O(arg_2309) } else { tmp1 = linked_2307.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2306, arg_2309) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(t.F_construct); var tmp3 any; var root_2314 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2314, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2316 lang.IFn; if linked_2315 == nil { ifn_2316 = lang.IFn_Cast(root_2314) } else { ifn_2316 = nil }; var arg_2317 any = vfs__2; if linked_2315 == nil { tmp3 = ifn_2316.Invoke_O__O(arg_2317) } else { tmp3 = linked_2315.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2314, arg_2317) }; return tmp2.Invoke_O__O(tmp3) } else {
//line :525:1
			var s__3 any; var root_2310 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2310, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2312 lang.IFn

			if linked_2311 == nil { ifn_2312 = lang.IFn_Cast(root_2310) } else { ifn_2312 = nil }; var arg_2313 any = ss__1; if linked_2311 == nil { s__3 = ifn_2312.Invoke_O__O(arg_2313) } else { s__3 = linked_2311.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2310, arg_2313) }
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_node_A_const_404; var tmp6 lang.IFn = lang.IFn_Cast(self); var tmp7 any; var root_2318 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2318, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2320 lang.IFn
			if linked_2319 == nil { ifn_2320 = lang.IFn_Cast(root_2318) } else { ifn_2320 = nil }; var arg_2321 any = ss__1; if linked_2319 == nil { tmp7 = ifn_2320.Invoke_O__O(arg_2321) } else { tmp7 = linked_2319.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2318, arg_2321) }
//line :528:1
			var tmp8 any = tmp7; var tmp9 any; var root_2322 any = A_arbace_c2j_node_A_const_32.GetRawRoot__O(); var linked_2323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2322, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2324 lang.IFn
			if linked_2323 == nil { ifn_2324 = lang.IFn_Cast(root_2322) } else { ifn_2324 = nil }; var arg_2325 any; var tmp10 any = A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000392_A_New_O(s__3); var tmp11 *jrt.Class; var fncls__2331 *jrt.Class = A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000392_A_fn_class; if fncls__2331 == nil { var fncls__2331d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000392_A_fn_class = fncls__2331d; tmp11 = fncls__2331d } else { tmp11 = fncls__2331 }; arg_2325 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var arg_2326 any = vfs__2; if linked_2323 == nil { tmp9 = ifn_2324.Invoke_O_O__O(arg_2325, arg_2326) } else { tmp9 = linked_2323.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2322, arg_2325, arg_2326) }
//line :528:1
			var tmp12 any = tmp6.Invoke_O_O__O(tmp8, tmp9); var tmp13 lang.IFn = lang.IFn_Cast(self); var tmp14 any; var root_2332 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2332, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2334 lang.IFn

			if linked_2333 == nil { ifn_2334 = lang.IFn_Cast(root_2332) } else { ifn_2334 = nil }; var arg_2335 any = ss__1; if linked_2333 == nil { tmp14 = ifn_2334.Invoke_O__O(arg_2335) } else { tmp14 = linked_2333.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2332, arg_2335) }
//line :528:1
			var tmp15 any = tmp14; var tmp16 any; var root_2336 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_2337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2336, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2338 lang.IFn

			if linked_2337 == nil { ifn_2338 = lang.IFn_Cast(root_2336) } else { ifn_2338 = nil }; var arg_2339 any; var tmp17 any = A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000394_A_New_O(s__3); var tmp18 *jrt.Class; var fncls__2345 *jrt.Class = A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000394_A_fn_class; if fncls__2345 == nil { var fncls__2345d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000394_A_fn_class = fncls__2345d; tmp18 = fncls__2345d } else { tmp18 = fncls__2345 }; arg_2339 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_2340 any = vfs__2; if linked_2337 == nil { tmp16 = ifn_2338.Invoke_O_O__O(arg_2339, arg_2340) } else { tmp16 = linked_2337.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2336, arg_2339, arg_2340) }
//line :528:1
			return tmp4.Invoke_O_O_O_O__O(tmp5, s__3, tmp12, tmp13.Invoke_O_O__O(tmp15, tmp16)) } }
func A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000392_A_New_O(p0 any) *A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000392_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000392_A{}; t.Ctor_O(p0); return t }
//line :529:1
func (t *A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000392_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :529:1
func (t *A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000392_A) Invoke_O_O__O(self, p1__400000375_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_233; var tmp2 any; var root_2327 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2327, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2329 lang.IFn; if linked_2328 == nil { ifn_2329 = lang.IFn_Cast(root_2327) } else { ifn_2329 = nil }; var arg_2330 any = p1__400000375_SHARP___1; if linked_2328 == nil { tmp2 = ifn_2329.Invoke_O__O(arg_2330) } else { tmp2 = linked_2328.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2327, arg_2330) }; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(tmp2), t.F_s) }
func A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000394_A_New_O(p0 any) *A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000394_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000394_A{}; t.Ctor_O(p0); return t }
//line :530:1
func (t *A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000394_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :530:1
func (t *A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000394_A) Invoke_O_O__O(self, p1__400000376_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_233; var tmp2 any; var root_2341 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2341, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2343 lang.IFn; if linked_2342 == nil { ifn_2343 = lang.IFn_Cast(root_2341) } else { ifn_2343 = nil }; var arg_2344 any = p1__400000376_SHARP___1; if linked_2342 == nil { tmp2 = ifn_2343.Invoke_O__O(arg_2344) } else { tmp2 = linked_2342.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2341, arg_2344) }; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(tmp2), t.F_s) }







func A_arbace_c2j_node_clause_fn__400000399_A_New_O(p0 any) *A_arbace_c2j_node_clause_fn__400000399_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000399_A{}; t.Ctor_O(p0); return t }
//line :538:1
func (t *A_arbace_c2j_node_clause_fn__400000399_A) Ctor_O(c__pick any) { t.F_pick = c__pick }
//line :538:1
func (t *A_arbace_c2j_node_clause_fn__400000399_A) Invoke_O_O__O(self, p__400000398__1 any) any { var vec__400000400__2 any = p__400000398__1; var c__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000400__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000400__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_414, A_arbace_c2j_node_A_const_415, c__3), lang.IFn_Cast(t.F_pick).Invoke_O__O(vfs__4)) }


func A_arbace_c2j_node_clause_fn__400000405_A_New_O(p0 any) *A_arbace_c2j_node_clause_fn__400000405_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000405_A{}; t.Ctor_O(p0); return t }
//line :541:1
func (t *A_arbace_c2j_node_clause_fn__400000405_A) Ctor_O(c__pick any) { t.F_pick = c__pick }
//line :541:1
func (t *A_arbace_c2j_node_clause_fn__400000405_A) Invoke_O_O__O(self, p__400000404__1 any) any { var vec__400000406__2 any = p__400000404__1; var c__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000406__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000406__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_429, A_arbace_c2j_node_A_const_430, c__3), lang.IFn_Cast(t.F_pick).Invoke_O__O(vfs__4)) }







func A_arbace_c2j_node_code_forms_A_New() *A_arbace_c2j_node_code_forms_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_A{}; t.Ctor(); return t }
//line :549:1
func (t *A_arbace_c2j_node_code_forms_A) Ctor() {}
//line :549:1
func (t *A_arbace_c2j_node_code_forms_A) Invoke_O_O_O_O__O(self, helpers__0, domains__1, keys__2 any) any { var per__4 any; var iter__1927001039__auto____4 any; var tmp1 any = A_arbace_c2j_node_code_forms_iter__400000411__400000415_A_New_O_O(helpers__0, domains__1); var tmp2 *jrt.Class; var fncls__2530 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000411__400000415_A_fn_class; if






	fncls__2530 == nil { var fncls__2530d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_c2j_node_code_forms_iter__400000411__400000415_A_fn_class = fncls__2530d; tmp2 = fncls__2530d } else { tmp2 = fncls__2530 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp4 any; var root_2981 any = A_arbace_c2j_node_A_const_5.GetRawRoot__O(); var linked_2982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2981, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_2983 lang.IFn; if linked_2982 == nil { ifn_2983 = lang.IFn_Cast(root_2981) } else { ifn_2983 = nil }; var arg_2984 any = A_arbace_c2j_node_A_const_10.GetRawRoot__O(); if linked_2982 == nil { tmp4 = ifn_2983.Invoke_O__O(arg_2984) } else { tmp4 = linked_2982.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_2981, arg_2984) }; per__4 = tmp3.Invoke_O__O(tmp4); var clauses__5 any; var tmp5 lang.IFn = /*line :549:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_node_code_forms_fn__400000432_A_New(); var tmp7 *jrt.Class; var fncls__2571 *jrt.Class = A_arbace_c2j_node_code_forms_fn__400000432_A_fn_class; if











	fncls__2571 == nil { var fncls__2571d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_c2j_node_code_forms_fn__400000432_A_fn_class = fncls__2571d; tmp7 = fncls__2571d } else { tmp7 = fncls__2571 }; clauses__5 = tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), per__4); var table__6 any; var iter__1927001039__auto____6 any; var tmp8 any = /*line :549:1*/A_arbace_c2j_node_code_forms_iter__400000436__400000444_A_New_O_O(domains__1, keys__2); var tmp9 *jrt.Class; var fncls__2734 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000436__400000444_A_fn_class; if












	fncls__2734 == nil { var fncls__2734d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_c2j_node_code_forms_iter__400000436__400000444_A_fn_class = fncls__2734d; tmp9 = fncls__2734d } else { tmp9 = fncls__2734 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); table__6 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(per__4); var root_2735 any =



	A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2736 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2735, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2737 lang.IFn; if linked_2736 == nil { ifn_2737 = lang.IFn_Cast(root_2735) } else { ifn_2737 = nil }; var arg_2738 any; var iter__1927001039__auto____7 any; var tmp10 any = A_arbace_c2j_node_code_forms_iter__400000469__400000475_A_New(); var tmp11 *jrt.Class; var fncls__2927 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000469__400000475_A_fn_class; if
	fncls__2927 == nil { var fncls__2927d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_c2j_node_code_forms_iter__400000469__400000475_A_fn_class = fncls__2927d; tmp11 = fncls__2927d } else { tmp11 = fncls__2927 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); arg_2738 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(per__4); var arg_2739 any; var tmp12 lang.IFn = /*line :566:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_node_A_const_452; var tmp14 any; var root_2928 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_2929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2928, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2930 lang.IFn; if







	linked_2929 == nil { ifn_2930 = lang.IFn_Cast(root_2928) } else { ifn_2930 = nil }; var arg_2931 any = A_arbace_c2j_node_A_const_453; var arg_2932 any = A_arbace_c2j_node_A_const_454; if linked_2929 == nil { tmp14 = ifn_2930.Invoke_O_O__O(arg_2931, arg_2932) } else { tmp14 = linked_2929.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2928, arg_2931, arg_2932) }; var tmp15 any = tmp14; var tmp16 lang.IFn = /*line :566:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp17 any = A_arbace_c2j_node_A_const_455; var tmp18 any; var root_2933 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_2934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2933, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2935 lang.IFn; if








	linked_2934 == nil { ifn_2935 = lang.IFn_Cast(root_2933) } else { ifn_2935 = nil }; var arg_2936 any = A_arbace_c2j_node_A_const_456; var arg_2937 any = A_arbace_c2j_node_A_const_457; if linked_2934 == nil { tmp18 = ifn_2935.Invoke_O_O__O(arg_2936, arg_2937) } else { tmp18 = linked_2934.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2933, arg_2936, arg_2937) }; var tmp19 any = tmp18; var tmp20 any; var root_2938 any = /*line :566:1*/A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_2939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2938, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2940 lang.IFn; if









	linked_2939 == nil { ifn_2940 = lang.IFn_Cast(root_2938) } else { ifn_2940 = nil }; var arg_2941 any; var tmp21 any; var root_2943 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_2944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2943, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2945 lang.IFn; if linked_2944 == nil { ifn_2945 = lang.IFn_Cast(root_2943) } else { ifn_2945 = nil }; var arg_2946 any = A_arbace_c2j_node_A_const_458; var arg_2947 any = A_arbace_c2j_node_A_const_459; if linked_2944 == nil { tmp21 = ifn_2945.Invoke_O_O__O(arg_2946, arg_2947) } else { tmp21 = linked_2944.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2943, arg_2946, arg_2947) }; var tmp22 any = tmp21; var tmp23 any; var root_2948 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_2949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2948, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2950 lang.IFn; if linked_2949 == nil { ifn_2950 = lang.IFn_Cast(root_2948) } else { ifn_2950 = nil }; var arg_2951 any = A_arbace_c2j_node_A_const_460; var arg_2952 any = A_arbace_c2j_node_A_const_461; if linked_2949 == nil { tmp23 = ifn_2950.Invoke_O_O__O(arg_2951, arg_2952) } else { tmp23 = linked_2949.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2948, arg_2951, arg_2952) }; arg_2941 = lang.Tuple_Create_O_O__IPersistentVector(tmp22, tmp23); var arg_2942 any = A_arbace_c2j_node_A_const_462; if linked_2939 == nil { tmp20 = ifn_2940.Invoke_O_O__O(arg_2941, arg_2942) } else { tmp20 = linked_2939.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2938, arg_2941, arg_2942) }; var tmp24 any = /*line :566:1*/tmp16.Invoke_O_O_O_O__O(tmp17, tmp19, tmp20, lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_463), clauses__5, A_arbace_c2j_node_A_const_464)); var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp26 any = A_arbace_c2j_node_A_const_465; var tmp27 any; var root_2959 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_2960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2959, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2961 lang.IFn; if











	linked_2960 == nil { ifn_2961 = lang.IFn_Cast(root_2959) } else { ifn_2961 = nil }; var arg_2962 any = A_arbace_c2j_node_A_const_466; var arg_2963 any = A_arbace_c2j_node_A_const_467; if linked_2960 == nil { tmp27 = ifn_2961.Invoke_O_O__O(arg_2962, arg_2963) } else { tmp27 = linked_2960.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2959, arg_2962, arg_2963) }; var tmp28 any = tmp27; var tmp29 any; var root_2964 any = /*line :566:1*/A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_2965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2964, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_2966 lang.IFn; if












	linked_2965 == nil { ifn_2966 = lang.IFn_Cast(root_2964) } else { ifn_2966 = nil }; var arg_2967 any = lang.PersistentVector_EMPTY.Ref(); var arg_2968 any = A_arbace_c2j_node_A_const_468; if linked_2965 == nil { tmp29 = ifn_2966.Invoke_O_O__O(arg_2967, arg_2968) } else { tmp29 = linked_2965.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_2964, arg_2967, arg_2968) }; var tmp30 any = tmp29; var tmp31 lang.IFn = /*line :566:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp32 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_469, A_arbace_c2j_node_A_const_470); var tmp33 any; var root_2975 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_2976 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2975, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2977 lang.IFn; if














	linked_2976 == nil { ifn_2977 = lang.IFn_Cast(root_2975) } else { ifn_2977 = nil }; var arg_2978 any; var tmp34 any = A_arbace_c2j_node_code_forms_fn__400000504_A_New(); var tmp35 *jrt.Class; var fncls__2980 *jrt.Class = A_arbace_c2j_node_code_forms_fn__400000504_A_fn_class; if fncls__2980 == nil { var fncls__2980d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_c2j_node_code_forms_fn__400000504_A_fn_class = fncls__2980d; tmp35 = fncls__2980d } else { tmp35 = fncls__2980 }; arg_2978 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil); var arg_2979 any = table__6; if linked_2976 == nil { tmp33 = ifn_2977.Invoke_O_O__O(arg_2978, arg_2979) } else { tmp33 = linked_2976.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2975, arg_2978, arg_2979) }; arg_2739 = /*line :566:1*/lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(Lit_18, tmp12.Invoke_O_O_O_O__O(tmp13, tmp15, tmp24, tmp25.Invoke_O_O_O_O__O(tmp26, tmp28, tmp30, tmp31.Invoke_O_O_O__O(tmp32, tmp33, A_arbace_c2j_node_A_const_474))))); if linked_2736 == nil { return ifn_2737.Invoke_O_O__O(arg_2738, arg_2739) } else { return linked_2736.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2735, arg_2738, arg_2739) } }
//line :556:1
func A_arbace_c2j_node_code_forms_iter__400000411__400000415_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000411__400000415_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000411__400000415_A{}; t.Ctor_O_O(p0, p1); return t }
//line :556:1
func (t *A_arbace_c2j_node_code_forms_iter__400000411__400000415_A) Ctor_O_O(c__helpers, c__domains any) { t.F_helpers = c__helpers; t.F_domains = c__domains }
//line :556:1
func (t *A_arbace_c2j_node_code_forms_iter__400000411__400000415_A) Invoke_O_O__O(self, s__400000412__1 any) any { var tmp1 any = A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_A_New_O_O_O_O(self, t.F_helpers, s__400000412__1, t.F_domains); var tmp2 *jrt.Class; var fncls__2529 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_A_fn_class; if fncls__2529 == nil { var fncls__2529d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_A_fn_class = fncls__2529d; tmp2 = fncls__2529d } else { tmp2 = fncls__2529 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :556:1
func A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :556:1
func (t *A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_A) Ctor_O_O_O_O(c__iter__400000411, c__helpers, c__s__400000412, c__domains any) { t.F_iter__400000411 = c__iter__400000411; t.F_helpers = c__helpers; t.F_s__400000412 = c__s__400000412; t.F_domains = c__domains }
//line :556:1
func (t *A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_A) Invoke_O__O(self any) any { { var s__400000412__1 any; var t_ any = t.F_s__400000412; t.F_s__400000412 = nil; s__400000412__1 = t_; for { var temp__1927000414__auto____2 any; var root_2428 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2428, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2430 lang.IFn; if linked_2429 == nil { ifn_2430 = lang.IFn_Cast(root_2428) } else { ifn_2430 = nil }; var arg_2431 any = s__400000412__1; if linked_2429 == nil { temp__1927000414__auto____2 = ifn_2430.Invoke_O__O(arg_2431) } else { temp__1927000414__auto____2 = linked_2429.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2428, arg_2431) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000412__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2432 any = A_arbace_c2j_node_A_const_373.GetRawRoot__O(); var linked_2433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2432, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2434 lang.IFn; if linked_2433 == nil { ifn_2434 = lang.IFn_Cast(root_2432) } else { ifn_2434 = nil }; var arg_2435 any = s__400000412__3; if linked_2433 == nil { tmp1 = ifn_2434.Invoke_O__O(arg_2435) } else { tmp1 = linked_2433.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2432, arg_2435) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2436 any = A_arbace_c2j_node_A_const_374.GetRawRoot__O(); var linked_2437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2436, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2438 lang.IFn; if linked_2437 == nil { ifn_2438 = lang.IFn_Cast(root_2436) } else { ifn_2438 = nil }; var arg_2439 any = s__400000412__3; if linked_2437 == nil { c__1927001037__auto____4 = ifn_2438.Invoke_O__O(arg_2439) } else { c__1927001037__auto____4 = linked_2437.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2436, arg_2439) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000414__6 any; var root_2440 any = A_arbace_c2j_node_A_const_375.GetRawRoot__O(); var linked_2441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2440, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2442 lang.IFn; if linked_2441 == nil { ifn_2442 = lang.IFn_Cast(root_2440) } else { ifn_2442 = nil }; var arg_2443 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2441 == nil { b__400000414__6 = ifn_2442.Invoke_O__O(arg_2443) } else { b__400000414__6 = linked_2441.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2440, arg_2443) }; var tmp2 any = A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_A_New_O_O_O_I_O(t.F_helpers, t.F_domains, b__400000414__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2471 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_A_fn_class; if fncls__2471 == nil { var fncls__2471d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_A_fn_class = fncls__2471d; tmp3 = fncls__2471d } else { tmp3 = fncls__2471 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2472 any = A_arbace_c2j_node_A_const_377.GetRawRoot__O(); var linked_2473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2472, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2474 lang.IFn; if linked_2473 == nil { ifn_2474 = lang.IFn_Cast(root_2472) } else { ifn_2474 = nil }; var arg_2475 any; var root_2477 any = A_arbace_c2j_node_A_const_378.GetRawRoot__O(); var linked_2478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2477, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2479 lang.IFn; if linked_2478 == nil { ifn_2479 = lang.IFn_Cast(root_2477) } else { ifn_2479 = nil }; var arg_2480 any = b__400000414__6; if linked_2478 == nil { arg_2475 = ifn_2479.Invoke_O__O(arg_2480) } else { arg_2475 = linked_2478.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2477, arg_2480) }; var arg_2476 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000411); var tmp5 any; var root_2481 any = A_arbace_c2j_node_A_const_379.GetRawRoot__O(); var linked_2482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2481, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2483 lang.IFn; if linked_2482 == nil { ifn_2483 = lang.IFn_Cast(root_2481) } else { ifn_2483 = nil }; var arg_2484 any = s__400000412__3; if linked_2482 == nil { tmp5 = ifn_2483.Invoke_O__O(arg_2484) } else { tmp5 = linked_2482.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2481, arg_2484) }; arg_2476 = tmp4.Invoke_O__O(tmp5); if linked_2473 == nil { return ifn_2474.Invoke_O_O__O(arg_2475, arg_2476) } else { return linked_2473.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2472, arg_2475, arg_2476) } } else { var root_2485 any = A_arbace_c2j_node_A_const_377.GetRawRoot__O(); var linked_2486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2485, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2487 lang.IFn; if linked_2486 == nil { ifn_2487 = lang.IFn_Cast(root_2485) } else { ifn_2487 = nil }; var arg_2488 any; var root_2490 any = A_arbace_c2j_node_A_const_378.GetRawRoot__O(); var linked_2491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2490, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2492 lang.IFn; if linked_2491 == nil { ifn_2492 = lang.IFn_Cast(root_2490) } else { ifn_2492 = nil }; var arg_2493 any = b__400000414__6; if linked_2491 == nil { arg_2488 = ifn_2492.Invoke_O__O(arg_2493) } else { arg_2488 = linked_2491.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2490, arg_2493) }; var arg_2489 any; if linked_2486 == nil { return ifn_2487.Invoke_O_O__O(arg_2488, arg_2489) } else { return linked_2486.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2485, arg_2488, arg_2489) } } } else { var d__4 any; var root_2494 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2494, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2496 lang.IFn; if linked_2495 == nil { ifn_2496 = lang.IFn_Cast(root_2494) } else { ifn_2496 = nil }; var arg_2497 any = s__400000412__3; if linked_2495 == nil { d__4 = ifn_2496.Invoke_O__O(arg_2497) } else { d__4 = linked_2495.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2494, arg_2497) }; var root_2498 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2498, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2500 lang.IFn; if linked_2499 == nil { ifn_2500 = lang.IFn_Cast(root_2498) } else { ifn_2500 = nil }; var arg_2501 any; var tmp6 any = A_arbace_c2j_node_A_const_109; var tmp7 any = A_arbace_c2j_node_A_const_444; var tmp8 any; var root_2503 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_2504 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2503, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2505 lang.IFn
														if linked_2504 == nil { ifn_2505 = lang.IFn_Cast(root_2503) } else { ifn_2505 = nil }; var arg_2506 any; var tmp9 any = A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000424_A_New_O_O(d__4, t.F_helpers); var tmp10 *jrt.Class; var fncls__2519 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000424_A_fn_class; if fncls__2519 == nil { var fncls__2519d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000424_A_fn_class = fncls__2519d; tmp10 = fncls__2519d } else { tmp10 = fncls__2519 }; arg_2506 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_2507 any; var root_2520 any = A_arbace_c2j_node_A_const_447.GetRawRoot__O(); var linked_2521 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2520, A_arbace_c2j_node_variants_A_fn_class); var ifn_2522 lang.IFn


	if linked_2521 == nil { ifn_2522 = lang.IFn_Cast(root_2520) } else { ifn_2522 = nil }; var arg_2523 any = d__4; var arg_2524 any = t.F_domains; if linked_2521 == nil { arg_2507 = ifn_2522.Invoke_O_O__O(arg_2523, arg_2524) } else { arg_2507 = linked_2521.(*A_arbace_c2j_node_variants_A).Invoke_O_O_O__O(root_2520, arg_2523, arg_2524) }
//line :557:1
	if linked_2504 == nil { tmp8 = ifn_2505.Invoke_O_O__O(arg_2506, arg_2507) } else { tmp8 = linked_2504.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2503, arg_2506, arg_2507) }
//line :556:1
	arg_2501 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, d__4, tmp7, tmp8)); var arg_2502 any; var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__400000411); var tmp12 any; var root_2525 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2525, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2527 lang.IFn; if linked_2526 == nil { ifn_2527 = lang.IFn_Cast(root_2525) } else { ifn_2527 = nil }; var arg_2528 any = s__400000412__3; if linked_2526 == nil { tmp12 = ifn_2527.Invoke_O__O(arg_2528) } else { tmp12 = linked_2526.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2525, arg_2528) }; arg_2502 = tmp11.Invoke_O__O(tmp12); if linked_2499 == nil { return ifn_2500.Invoke_O_O__O(arg_2501, arg_2502) } else { return linked_2499.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2498, arg_2501, arg_2502) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :556:1
func A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :556:1
func (t *A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_A) Ctor_O_O_O_I_O(c__helpers, c__domains, c__b__400000414 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_helpers = c__helpers; t.F_domains = c__domains; t.F_b__400000414 = c__b__400000414; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :556:1
func (t *A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_A) Invoke_O__O(self any) any { { var i__400000413__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000413__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000413__1)); var root_2444 any = A_arbace_c2j_node_A_const_376.GetRawRoot__O(); var linked_2445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2444, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2446 lang.IFn; if linked_2445 == nil { ifn_2446 = lang.IFn_Cast(root_2444) } else { ifn_2446 = nil }; var arg_2447 any = t.F_b__400000414; var arg_2448 any; var tmp2 any = A_arbace_c2j_node_A_const_109; var tmp3 any = A_arbace_c2j_node_A_const_444; var tmp4 any; var root_2449 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_2450 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2449, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2451 lang.IFn
																if linked_2450 == nil { ifn_2451 = lang.IFn_Cast(root_2449) } else { ifn_2451 = nil }; var arg_2452 any; var tmp5 any = A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_fn__400000418_A_New_O_O(d__2, t.F_helpers); var tmp6 *jrt.Class; var fncls__2465 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_fn__400000418_A_fn_class; if fncls__2465 == nil { var fncls__2465d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_fn__400000418_A_fn_class = fncls__2465d; tmp6 = fncls__2465d } else { tmp6 = fncls__2465 }; arg_2452 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_2453 any; var root_2466 any = A_arbace_c2j_node_A_const_447.GetRawRoot__O(); var linked_2467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2466, A_arbace_c2j_node_variants_A_fn_class); var ifn_2468 lang.IFn


	if linked_2467 == nil { ifn_2468 = lang.IFn_Cast(root_2466) } else { ifn_2468 = nil }; var arg_2469 any = d__2; var arg_2470 any = t.F_domains; if linked_2467 == nil { arg_2453 = ifn_2468.Invoke_O_O__O(arg_2469, arg_2470) } else { arg_2453 = linked_2467.(*A_arbace_c2j_node_variants_A).Invoke_O_O_O__O(root_2466, arg_2469, arg_2470) }
//line :557:1
	if linked_2450 == nil { tmp4 = ifn_2451.Invoke_O_O__O(arg_2452, arg_2453) } else { tmp4 = linked_2450.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2449, arg_2452, arg_2453) }
//line :556:1
	arg_2448 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, d__2, tmp3, tmp4)); if linked_2445 == nil { ifn_2446.Invoke_O_O__O(arg_2447, arg_2448) } else { linked_2445.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2444, arg_2447, arg_2448) }; i__400000413__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000413__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_fn__400000418_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_fn__400000418_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_fn__400000418_A{}; t.Ctor_O_O(p0, p1); return t }
//line :557:1
func (t *A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_fn__400000418_A) Ctor_O_O(c__d, c__helpers any) { t.F_d = c__d; t.F_helpers = c__helpers }
//line :557:1
func (t *A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_fn__400000418_A) Invoke_O_O__O(self, v__1 any) any { var v__2 any; var root_2454 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_2455 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2454, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2456 lang.IFn; if linked_2455 == nil { ifn_2456 = lang.IFn_Cast(root_2454) } else { ifn_2456 = nil }; var arg_2457 any = v__1; var arg_2458 any = A_arbace_c2j_node_A_const_254; var arg_2459 any = t.F_helpers; if linked_2455 == nil { v__2 = ifn_2456.Invoke_O_O_O__O(arg_2457, arg_2458, arg_2459) } else { v__2 = linked_2455.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2454, arg_2457, arg_2458, arg_2459) }; var vec__400000419__3 any; var root_2460 any = A_arbace_c2j_node_A_const_445.GetRawRoot__O(); var linked_2461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2460, A_arbace_c2j_node_variant_class_A_fn_class); var ifn_2462 lang.IFn; if
																		linked_2461 == nil { ifn_2462 = lang.IFn_Cast(root_2460) } else { ifn_2462 = nil }; var arg_2463 any = t.F_d; var arg_2464 any = v__2; if linked_2461 == nil { vec__400000419__3 = ifn_2462.Invoke_O_O__O(arg_2463, arg_2464) } else { vec__400000419__3 = linked_2461.(*A_arbace_c2j_node_variant_class_A).Invoke_O_O_O__O(root_2460, arg_2463, arg_2464) }; var cf__4 any = /*line :557:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__400000419__3, lang.RT_IntCast_J__I_NoInit(0), nil); var fields__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000419__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_56, v__2, A_arbace_c2j_node_A_const_446, cf__4, A_arbace_c2j_node_A_const_31, fields__5)) }
//line :557:1
func A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000424_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000424_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000424_A{}; t.Ctor_O_O(p0, p1); return t }
//line :557:1
func (t *A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000424_A) Ctor_O_O(c__d, c__helpers any) { t.F_d = c__d; t.F_helpers = c__helpers }
//line :557:1
func (t *A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000424_A) Invoke_O_O__O(self, v__1 any) any { var v__2 any; var root_2508 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_2509 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2508, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2510 lang.IFn; if linked_2509 == nil { ifn_2510 = lang.IFn_Cast(root_2508) } else { ifn_2510 = nil }; var arg_2511 any = v__1; var arg_2512 any = A_arbace_c2j_node_A_const_254; var arg_2513 any = t.F_helpers; if linked_2509 == nil { v__2 = ifn_2510.Invoke_O_O_O__O(arg_2511, arg_2512, arg_2513) } else { v__2 = linked_2509.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2508, arg_2511, arg_2512, arg_2513) }; var vec__400000425__3 any; var root_2514 any = A_arbace_c2j_node_A_const_445.GetRawRoot__O(); var linked_2515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2514, A_arbace_c2j_node_variant_class_A_fn_class); var ifn_2516 lang.IFn; if
																	linked_2515 == nil { ifn_2516 = lang.IFn_Cast(root_2514) } else { ifn_2516 = nil }; var arg_2517 any = t.F_d; var arg_2518 any = v__2; if linked_2515 == nil { vec__400000425__3 = ifn_2516.Invoke_O_O__O(arg_2517, arg_2518) } else { vec__400000425__3 = linked_2515.(*A_arbace_c2j_node_variant_class_A).Invoke_O_O_O__O(root_2514, arg_2517, arg_2518) }; var cf__4 any = /*line :557:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__400000425__3, lang.RT_IntCast_J__I_NoInit(0), nil); var fields__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000425__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_56, v__2, A_arbace_c2j_node_A_const_446, cf__4, A_arbace_c2j_node_A_const_31, fields__5)) }



func A_arbace_c2j_node_code_forms_fn__400000432_A_New() *A_arbace_c2j_node_code_forms_fn__400000432_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_fn__400000432_A{}; t.Ctor(); return t }
//line :561:1
func (t *A_arbace_c2j_node_code_forms_fn__400000432_A) Ctor() {}
//line :561:1
func (t *A_arbace_c2j_node_code_forms_fn__400000432_A) Invoke_O_O__O(self, p__400000431__1 any) any { var map__400000433__2 any = p__400000431__1; var map__400000433__3 any; if lang.ISeq_InstanceOf(map__400000433__2) { var tmp1 any; var root_2536 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2536, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2538 lang.IFn; if linked_2537 == nil { ifn_2538 = lang.IFn_Cast(root_2536) } else { ifn_2538 = nil }; var arg_2539 any = map__400000433__2; if linked_2537 == nil { tmp1 = ifn_2538.Invoke_O__O(arg_2539) } else { tmp1 = linked_2537.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2536, arg_2539) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2540 any = A_arbace_c2j_node_A_const_171.GetRawRoot__O(); var linked_2541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2540, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2542 lang.IFn; if linked_2541 == nil { ifn_2542 = lang.IFn_Cast(root_2540) } else { ifn_2542 = nil }; var arg_2543 any = map__400000433__2; if linked_2541 == nil { tmp2 = ifn_2542.Invoke_O__O(arg_2543) } else { tmp2 = linked_2541.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2540, arg_2543) }; map__400000433__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2544 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2544, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2546 lang.IFn; if linked_2545 == nil { ifn_2546 = lang.IFn_Cast(root_2544) } else { ifn_2546 = nil }; var arg_2547 any = map__400000433__2; if linked_2545 == nil { tmp3 = ifn_2546.Invoke_O__O(arg_2547) } else { tmp3 = linked_2545.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2544, arg_2547) }; if jrt.J2g_Truth(tmp3) { var root_2548 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2548, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2550 lang.IFn; if linked_2549 == nil { ifn_2550 = lang.IFn_Cast(root_2548) } else { ifn_2550 = nil }; var arg_2551 any = map__400000433__2; if linked_2549 == nil { map__400000433__3 = ifn_2550.Invoke_O__O(arg_2551) } else { map__400000433__3 = linked_2549.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2548, arg_2551) } } else { map__400000433__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000433__3 = map__400000433__2 }; var d__4 any = lang.RT_Get_O_O__O_NoInit(map__400000433__3, A_arbace_c2j_node_A_const_109); var vs__5 any = lang.RT_Get_O_O__O_NoInit(map__400000433__3, A_arbace_c2j_node_A_const_444); var tmp4 any; var root_2552 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2552, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2554 lang.IFn; if linked_2553 == nil { ifn_2554 = lang.IFn_Cast(root_2552) } else { ifn_2554 = nil }; var tmp5 *lang.Keyword = A_arbace_c2j_node_A_const_389; var arg_2555 any = tmp5.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__4)); if linked_2553 == nil { tmp4 = ifn_2554.Invoke_O__O(arg_2555) } else { tmp4 = linked_2553.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2552, arg_2555) }; if jrt.J2g_Truth(tmp4) { var root_2556 any = A_arbace_c2j_node_A_const_448.GetRawRoot__O(); var linked_2557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2556, A_arbace_c2j_node_clause_A_fn_class); var ifn_2558 lang.IFn; if linked_2557 == nil { ifn_2558 = lang.IFn_Cast(root_2556) } else { ifn_2558 = nil }; var arg_2559 any = d__4; var arg_2560 any; var root_2561 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_2562 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2561, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2563 lang.IFn; if linked_2562 == nil { ifn_2563 = lang.IFn_Cast(root_2561) } else { ifn_2563 = nil }; var arg_2564 any; var root_2566 any = A_arbace_c2j_node_A_const_449.GetRawRoot__O(); var linked_2567 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2566, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2568 lang.IFn; if linked_2567 == nil { ifn_2568 = lang.IFn_Cast(root_2566) } else { ifn_2568 = nil }; var arg_2569 any = A_arbace_c2j_node_A_const_56; var arg_2570 any = A_arbace_c2j_node_A_const_31; if linked_2567 == nil { arg_2564 = ifn_2568.Invoke_O_O__O(arg_2569, arg_2570) } else { arg_2564 = linked_2567.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2566, arg_2569, arg_2570) }; var arg_2565 any = vs__5; if linked_2562 == nil { arg_2560 = ifn_2563.Invoke_O_O__O(arg_2564, arg_2565) } else { arg_2560 = linked_2562.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2561, arg_2564, arg_2565) }; if linked_2557 == nil { return ifn_2558.Invoke_O_O__O(arg_2559, arg_2560) } else { return linked_2557.(*A_arbace_c2j_node_clause_A).Invoke_O_O_O__O(root_2556, arg_2559, arg_2560) } } else { return nil } }
func A_arbace_c2j_node_code_forms_iter__400000436__400000444_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000436__400000444_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000436__400000444_A{}; t.Ctor_O_O(p0, p1); return t }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_A) Ctor_O_O(c__domains, c__keys any) { t.F_domains = c__domains; t.F_keys = c__keys }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_A) Invoke_O_O__O(self, s__400000437__1 any) any { var tmp1 any = A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_A_New_O_O_O_O(self, s__400000437__1, t.F_domains, t.F_keys); var tmp2 *jrt.Class; var fncls__2733 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_A_fn_class; if fncls__2733 == nil { var fncls__2733d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_A_fn_class = fncls__2733d; tmp2 = fncls__2733d } else { tmp2 = fncls__2733 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :562:1
func A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_A) Ctor_O_O_O_O(c__iter__400000436, c__s__400000437, c__domains, c__keys any) { t.F_iter__400000436 = c__iter__400000436; t.F_s__400000437 = c__s__400000437; t.F_domains = c__domains; t.F_keys = c__keys }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_A) Invoke_O__O(self any) any { { var s__400000437__1 any; var t_ any = t.F_s__400000437; t.F_s__400000437 = nil; s__400000437__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2572 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2572, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2574 lang.IFn; if linked_2573 == nil { ifn_2574 = lang.IFn_Cast(root_2572) } else { ifn_2574 = nil }; var arg_2575 any = s__400000437__1; if linked_2573 == nil { temp__1927000414__auto____2 = ifn_2574.Invoke_O__O(arg_2575) } else { temp__1927000414__auto____2 = linked_2573.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2572, arg_2575) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__400000446__4 any; var root_2576 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2578 lang.IFn; if linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any = xs__1927001018__auto____3; if linked_2577 == nil { map__400000446__4 = ifn_2578.Invoke_O__O(arg_2579) } else { map__400000446__4 = linked_2577.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2576, arg_2579) }; var map__400000446__5 any; if lang.ISeq_InstanceOf(map__400000446__4) { var tmp1 any; var root_2580 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2580, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2582 lang.IFn; if linked_2581 == nil { ifn_2582 = lang.IFn_Cast(root_2580) } else { ifn_2582 = nil }; var arg_2583 any = map__400000446__4; if linked_2581 == nil { tmp1 = ifn_2582.Invoke_O__O(arg_2583) } else { tmp1 = linked_2581.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2580, arg_2583) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2584 any = A_arbace_c2j_node_A_const_171.GetRawRoot__O(); var linked_2585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2584, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2586 lang.IFn; if linked_2585 == nil { ifn_2586 = lang.IFn_Cast(root_2584) } else { ifn_2586 = nil }; var arg_2587 any = map__400000446__4; if linked_2585 == nil { tmp2 = ifn_2586.Invoke_O__O(arg_2587) } else { tmp2 = linked_2585.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2584, arg_2587) }; map__400000446__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2588 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2588, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2590 lang.IFn; if linked_2589 == nil { ifn_2590 = lang.IFn_Cast(root_2588) } else { ifn_2590 = nil }; var arg_2591 any = map__400000446__4; if linked_2589 == nil { tmp3 = ifn_2590.Invoke_O__O(arg_2591) } else { tmp3 = linked_2589.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2588, arg_2591) }; if jrt.J2g_Truth(tmp3) { var root_2592 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2592, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2594 lang.IFn; if linked_2593 == nil { ifn_2594 = lang.IFn_Cast(root_2592) } else { ifn_2594 = nil }; var arg_2595 any = map__400000446__4; if linked_2593 == nil { map__400000446__5 = ifn_2594.Invoke_O__O(arg_2595) } else { map__400000446__5 = linked_2593.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2592, arg_2595) } } else { map__400000446__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000446__5 = map__400000446__4 }; var d__6 any = lang.RT_Get_O_O__O_NoInit(map__400000446__5, A_arbace_c2j_node_A_const_109); var tmp4 *lang.Keyword = A_arbace_c2j_node_A_const_381; if jrt.J2g_Truth(tmp4.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__6))) { var iterys__1927001035__auto____7 any; var tmp5 any = A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_A_New_O_O(t.F_keys, d__6); var tmp6 *jrt.Class; var fncls__2706 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_A_fn_class; if fncls__2706 == nil { var fncls__2706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_A_fn_class = fncls__2706d; tmp6 = fncls__2706d } else { tmp6 = fncls__2706 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var fs__1927001036__auto____8 any; var root_2707 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2709 lang.IFn; if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any; var tmp7 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp8 any; var root_2711 any = A_arbace_c2j_node_A_const_407.GetRawRoot__O(); var linked_2712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2711, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2713 lang.IFn
														if linked_2712 == nil { ifn_2713 = lang.IFn_Cast(root_2711) } else { ifn_2713 = nil }; var arg_2714 any = A_arbace_c2j_node_A_const_408.GetRawRoot__O(); var tmp9 lang.IFn = lang.IFn_Cast(t.F_domains); var arg_2715 any = tmp9.Invoke_O__O(A_arbace_c2j_node_A_const_13.Invoke_O__O(d__6)); if linked_2712 == nil { tmp8 = ifn_2713.Invoke_O_O__O(arg_2714, arg_2715) } else { tmp8 = linked_2712.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2711, arg_2714, arg_2715) }
//line :562:1
	arg_2710 = tmp7.Invoke_O__O(tmp8); if linked_2708 == nil { fs__1927001036__auto____8 = ifn_2709.Invoke_O__O(arg_2710) } else { fs__1927001036__auto____8 = linked_2708.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2707, arg_2710) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2716 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2717 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2716, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2718 lang.IFn; if linked_2717 == nil { ifn_2718 = lang.IFn_Cast(root_2716) } else { ifn_2718 = nil }; var arg_2719 any = fs__1927001036__auto____8; var arg_2720 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__400000436); var tmp11 any; var root_2721 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2721, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2723 lang.IFn; if linked_2722 == nil { ifn_2723 = lang.IFn_Cast(root_2721) } else { ifn_2723 = nil }; var arg_2724 any = s__400000437__1; if linked_2722 == nil { tmp11 = ifn_2723.Invoke_O__O(arg_2724) } else { tmp11 = linked_2722.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2721, arg_2724) }; arg_2720 = tmp10.Invoke_O__O(tmp11); if linked_2717 == nil { return ifn_2718.Invoke_O_O__O(arg_2719, arg_2720) } else { return linked_2717.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2716, arg_2719, arg_2720) } } else { var tmp12 any; var root_2725 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2725, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2727 lang.IFn; if linked_2726 == nil { ifn_2727 = lang.IFn_Cast(root_2725) } else { ifn_2727 = nil }; var arg_2728 any = s__400000437__1; if linked_2726 == nil { tmp12 = ifn_2727.Invoke_O__O(arg_2728) } else { tmp12 = linked_2726.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2725, arg_2728) }; s__400000437__1 = tmp12; continue L1 } } else { var tmp13 any; var root_2729 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2729, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2731 lang.IFn; if linked_2730 == nil { ifn_2731 = lang.IFn_Cast(root_2729) } else { ifn_2731 = nil }; var arg_2732 any = s__400000437__1; if linked_2730 == nil { tmp13 = ifn_2731.Invoke_O__O(arg_2732) } else { tmp13 = linked_2730.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2729, arg_2732) }; s__400000437__1 = tmp13; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :562:1
func A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_A{}; t.Ctor_O_O(p0, p1); return t }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_A) Ctor_O_O(c__keys, c__d any) { t.F_keys = c__keys; t.F_d = c__d }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_A) Invoke_O_O__O(self, s__400000439__1 any) any { var tmp1 any = A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_A_New_O_O_O_O(self, s__400000439__1, t.F_keys, t.F_d); var tmp2 *jrt.Class; var fncls__2705 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_A_fn_class; if fncls__2705 == nil { var fncls__2705d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_A_fn_class = fncls__2705d; tmp2 = fncls__2705d } else { tmp2 = fncls__2705 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :562:1
func A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_A) Ctor_O_O_O_O(c__iter__400000438, c__s__400000439, c__keys, c__d any) { t.F_iter__400000438 = c__iter__400000438; t.F_s__400000439 = c__s__400000439; t.F_keys = c__keys; t.F_d = c__d }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_A) Invoke_O__O(self any) any { { var s__400000439__1 any; var t_ any = t.F_s__400000439; t.F_s__400000439 = nil; s__400000439__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2596 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2596, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2598 lang.IFn; if linked_2597 == nil { ifn_2598 = lang.IFn_Cast(root_2596) } else { ifn_2598 = nil }; var arg_2599 any = s__400000439__1; if linked_2597 == nil { temp__1927000414__auto____2 = ifn_2598.Invoke_O__O(arg_2599) } else { temp__1927000414__auto____2 = linked_2597.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2596, arg_2599) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__400000450__4 any; var root_2600 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2600, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2602 lang.IFn; if linked_2601 == nil { ifn_2602 = lang.IFn_Cast(root_2600) } else { ifn_2602 = nil }; var arg_2603 any = xs__1927001018__auto____3; if linked_2601 == nil { vec__400000450__4 = ifn_2602.Invoke_O__O(arg_2603) } else { vec__400000450__4 = linked_2601.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2600, arg_2603) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000450__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ms__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000450__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var tmp1 any = A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_A_New_O_O_O(k__5, t.F_keys, t.F_d); var tmp2 *jrt.Class; var fncls__2682 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_A_fn_class; if fncls__2682 == nil { var fncls__2682d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_A_fn_class = fncls__2682d; tmp2 = fncls__2682d } else { tmp2 = fncls__2682 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____8 any; var root_2683 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2683, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2685 lang.IFn; if linked_2684 == nil { ifn_2685 = lang.IFn_Cast(root_2683) } else { ifn_2685 = nil }; var arg_2686 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp4 any; var root_2687 any = A_arbace_c2j_node_A_const_274.GetRawRoot__O(); var linked_2688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2687, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2689 lang.IFn

	if linked_2688 == nil { ifn_2689 = lang.IFn_Cast(root_2687) } else { ifn_2689 = nil }; var arg_2690 any = A_arbace_c2j_node_A_const_387.GetRawRoot__O(); var arg_2691 any = ms__6; if linked_2688 == nil { tmp4 = ifn_2689.Invoke_O_O__O(arg_2690, arg_2691) } else { tmp4 = linked_2688.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2687, arg_2690, arg_2691) }
//line :562:1
	arg_2686 = tmp3.Invoke_O__O(tmp4); if linked_2684 == nil { fs__1927001036__auto____8 = ifn_2685.Invoke_O__O(arg_2686) } else { fs__1927001036__auto____8 = linked_2684.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2683, arg_2686) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2692 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2693 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2692, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2694 lang.IFn; if linked_2693 == nil { ifn_2694 = lang.IFn_Cast(root_2692) } else { ifn_2694 = nil }; var arg_2695 any = fs__1927001036__auto____8; var arg_2696 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__400000438); var tmp6 any; var root_2697 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2697, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2699 lang.IFn; if linked_2698 == nil { ifn_2699 = lang.IFn_Cast(root_2697) } else { ifn_2699 = nil }; var arg_2700 any = s__400000439__1; if linked_2698 == nil { tmp6 = ifn_2699.Invoke_O__O(arg_2700) } else { tmp6 = linked_2698.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2697, arg_2700) }; arg_2696 = tmp5.Invoke_O__O(tmp6); if linked_2693 == nil { return ifn_2694.Invoke_O_O__O(arg_2695, arg_2696) } else { return linked_2693.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2692, arg_2695, arg_2696) } } else { var tmp7 any; var root_2701 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2702 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2701, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2703 lang.IFn; if linked_2702 == nil { ifn_2703 = lang.IFn_Cast(root_2701) } else { ifn_2703 = nil }; var arg_2704 any = s__400000439__1; if linked_2702 == nil { tmp7 = ifn_2703.Invoke_O__O(arg_2704) } else { tmp7 = linked_2702.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2701, arg_2704) }; s__400000439__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :562:1
func A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_A) Ctor_O_O_O(c__k, c__keys, c__d any) { t.F_k = c__k; t.F_keys = c__keys; t.F_d = c__d }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_A) Invoke_O_O__O(self, s__400000441__1 any) any { var tmp1 any = A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_A_New_O_O_O_O_O(s__400000441__1, t.F_k, t.F_keys, self, t.F_d); var tmp2 *jrt.Class; var fncls__2681 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_A_fn_class; if fncls__2681 == nil { var fncls__2681d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_A_fn_class = fncls__2681d; tmp2 = fncls__2681d } else { tmp2 = fncls__2681 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :562:1
func A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_A) Ctor_O_O_O_O_O(c__s__400000441, c__k, c__keys, c__iter__400000440, c__d any) { t.F_s__400000441 = c__s__400000441; t.F_k = c__k; t.F_keys = c__keys; t.F_iter__400000440 = c__iter__400000440; t.F_d = c__d }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_A) Invoke_O__O(self any) any { { var s__400000441__1 any; var t_ any = t.F_s__400000441; t.F_s__400000441 = nil; s__400000441__1 = t_; for { var temp__1927000414__auto____2 any; var root_2604 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2604, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2606 lang.IFn; if linked_2605 == nil { ifn_2606 = lang.IFn_Cast(root_2604) } else { ifn_2606 = nil }; var arg_2607 any = s__400000441__1; if linked_2605 == nil { temp__1927000414__auto____2 = ifn_2606.Invoke_O__O(arg_2607) } else { temp__1927000414__auto____2 = linked_2605.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2604, arg_2607) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000441__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2608 any = A_arbace_c2j_node_A_const_373.GetRawRoot__O(); var linked_2609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2608, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2610 lang.IFn; if linked_2609 == nil { ifn_2610 = lang.IFn_Cast(root_2608) } else { ifn_2610 = nil }; var arg_2611 any = s__400000441__3; if linked_2609 == nil { tmp1 = ifn_2610.Invoke_O__O(arg_2611) } else { tmp1 = linked_2609.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2608, arg_2611) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2612 any = A_arbace_c2j_node_A_const_374.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2612, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2614 lang.IFn; if linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any = s__400000441__3; if linked_2613 == nil { c__1927001037__auto____4 = ifn_2614.Invoke_O__O(arg_2615) } else { c__1927001037__auto____4 = linked_2613.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2612, arg_2615) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000443__6 any; var root_2616 any = A_arbace_c2j_node_A_const_375.GetRawRoot__O(); var linked_2617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2616, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2618 lang.IFn; if linked_2617 == nil { ifn_2618 = lang.IFn_Cast(root_2616) } else { ifn_2618 = nil }; var arg_2619 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2617 == nil { b__400000443__6 = ifn_2618.Invoke_O__O(arg_2619) } else { b__400000443__6 = linked_2617.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2616, arg_2619) }; var tmp2 any = A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_fn__400000455_A_New_O_O_O_I_O_O(t.F_k, b__400000443__6, t.F_keys, size__1927001038__auto____5, t.F_d, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2635 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_fn__400000455_A_fn_class; if fncls__2635 == nil { var fncls__2635d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_fn__400000455_A_fn_class = fncls__2635d; tmp3 = fncls__2635d } else { tmp3 = fncls__2635 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2636 any = A_arbace_c2j_node_A_const_377.GetRawRoot__O(); var linked_2637 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2636, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2638 lang.IFn; if linked_2637 == nil { ifn_2638 = lang.IFn_Cast(root_2636) } else { ifn_2638 = nil }; var arg_2639 any; var root_2641 any = A_arbace_c2j_node_A_const_378.GetRawRoot__O(); var linked_2642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2641, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2643 lang.IFn; if linked_2642 == nil { ifn_2643 = lang.IFn_Cast(root_2641) } else { ifn_2643 = nil }; var arg_2644 any = b__400000443__6; if linked_2642 == nil { arg_2639 = ifn_2643.Invoke_O__O(arg_2644) } else { arg_2639 = linked_2642.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2641, arg_2644) }; var arg_2640 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000440); var tmp5 any; var root_2645 any = A_arbace_c2j_node_A_const_379.GetRawRoot__O(); var linked_2646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2645, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2647 lang.IFn; if linked_2646 == nil { ifn_2647 = lang.IFn_Cast(root_2645) } else { ifn_2647 = nil }; var arg_2648 any = s__400000441__3; if linked_2646 == nil { tmp5 = ifn_2647.Invoke_O__O(arg_2648) } else { tmp5 = linked_2646.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2645, arg_2648) }; arg_2640 = tmp4.Invoke_O__O(tmp5); if linked_2637 == nil { return ifn_2638.Invoke_O_O__O(arg_2639, arg_2640) } else { return linked_2637.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2636, arg_2639, arg_2640) } } else { var root_2649 any = A_arbace_c2j_node_A_const_377.GetRawRoot__O(); var linked_2650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2649, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2651 lang.IFn; if linked_2650 == nil { ifn_2651 = lang.IFn_Cast(root_2649) } else { ifn_2651 = nil }; var arg_2652 any; var root_2654 any = A_arbace_c2j_node_A_const_378.GetRawRoot__O(); var linked_2655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2654, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2656 lang.IFn; if linked_2655 == nil { ifn_2656 = lang.IFn_Cast(root_2654) } else { ifn_2656 = nil }; var arg_2657 any = b__400000443__6; if linked_2655 == nil { arg_2652 = ifn_2656.Invoke_O__O(arg_2657) } else { arg_2652 = linked_2655.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2654, arg_2657) }; var arg_2653 any; if linked_2650 == nil { return ifn_2651.Invoke_O_O__O(arg_2652, arg_2653) } else { return linked_2650.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2649, arg_2652, arg_2653) } } } else { var vec__400000460__4 any; var root_2658 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2658, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2660 lang.IFn; if linked_2659 == nil { ifn_2660 = lang.IFn_Cast(root_2658) } else { ifn_2660 = nil }; var arg_2661 any = s__400000441__3; if linked_2659 == nil { vec__400000460__4 = ifn_2660.Invoke_O__O(arg_2661) } else { vec__400000460__4 = linked_2659.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2658, arg_2661) }; var i__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000460__4, lang.RT_IntCast_J__I_NoInit(0), nil); var m__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000460__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2662 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2662, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2664 lang.IFn; if linked_2663 == nil { ifn_2664 = lang.IFn_Cast(root_2662) } else { ifn_2664 = nil }; var arg_2665 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_keys); var tmp7 any = lang.IFn_Cast(tmp6.Invoke_O__O(A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d))).Invoke_O__O(m__6); var tmp8 jrt.Number_I; var na_2667 any; var na_2669 any = t.F_k
																								var na_2670 int64 = 10000

	if jrt.Long_InstanceOf(na_2669) { var n0_2671 int64 = jrt.NN(jrt.Long_Cast(na_2669)).LongValue__J(); var n1_2672 int64 = na_2670; var nr_2673 int64 = n0_2671 * n1_2672; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; tmp12 = n0_2671 == -9223372036854775808; if tmp12 { tmp12 = n1_2672 < 0 }; tmp11 = tmp12; tmp10 = !tmp11; if tmp10 { var tmp13 bool; tmp13 = n1_2672 == 0; if !tmp13 { tmp13 = nr_2673/n1_2672 == n0_2671 }; tmp10 = tmp13 }; tmp9 = tmp10; if tmp9 { na_2667 = jrt.Long_ValueOf_J__Long_NoInit(nr_2673).Ref() } else { na_2667 = lang.Numbers_Multiply_O_J__Number_NoInit(na_2669, na_2670) } } else { na_2667 = lang.Numbers_Multiply_O_J__Number_NoInit(na_2669, na_2670) }; var na_2668 any = i__5; var tmp14 bool; var tmp15 bool; tmp15 = jrt.Long_InstanceOf(na_2667); if tmp15 { tmp15 = jrt.Long_InstanceOf(na_2668) }; tmp14 = tmp15; if tmp14 { var n0_2674 int64 = jrt.NN(jrt.Long_Cast(na_2667)).LongValue__J(); var n1_2675 int64 = jrt.NN(jrt.Long_Cast(na_2668)).LongValue__J(); var nr_2676 int64 = n0_2674 + n1_2675; if (n0_2674^nr_2676)&(n1_2675^nr_2676) >= 0 { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2676)) } else { tmp8 = lang.Numbers_Add_O_O__Number_NoInit(na_2667, na_2668) } } else { var tmp16 bool; var tmp17 bool; tmp17 = jrt.Double_InstanceOf(na_2667); if tmp17 { tmp17 = jrt.Double_InstanceOf(na_2668) }; tmp16 = tmp17; if tmp16 { var n0_2674_2 float64 = jrt.NN(jrt.Double_Cast(na_2667)).DoubleValue__D(); var n1_2675_2 float64 = jrt.NN(jrt.Double_Cast(na_2668)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_2674_2 + n1_2675_2)) } else { tmp8 = lang.Numbers_Add_O_O__Number_NoInit(na_2667, na_2668) } }
//line :562:1
	arg_2665 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, tmp8); var arg_2666 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__400000440); var tmp19 any; var root_2677 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2677, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2679 lang.IFn; if linked_2678 == nil { ifn_2679 = lang.IFn_Cast(root_2677) } else { ifn_2679 = nil }; var arg_2680 any = s__400000441__3; if linked_2678 == nil { tmp19 = ifn_2679.Invoke_O__O(arg_2680) } else { tmp19 = linked_2678.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2677, arg_2680) }; arg_2666 = tmp18.Invoke_O__O(tmp19); if linked_2663 == nil { return ifn_2664.Invoke_O_O__O(arg_2665, arg_2666) } else { return linked_2663.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2662, arg_2665, arg_2666) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :562:1
func A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_fn__400000455_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_fn__400000455_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_fn__400000455_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_fn__400000455_A) Ctor_O_O_O_I_O_O(c__k, c__b__400000443, c__keys any, c__size__1927001038__auto__ int32, c__d, c__c__1927001037__auto__ any) { t.F_k = c__k; t.F_b__400000443 = c__b__400000443; t.F_keys = c__keys; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_d = c__d; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :562:1
func (t *A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_fn__400000455_A) Invoke_O__O(self any) any { { var i__400000442__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000442__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__400000456__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000442__1)); var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000456__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000456__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2620 any = A_arbace_c2j_node_A_const_376.GetRawRoot__O(); var linked_2621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2620, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2622 lang.IFn; if linked_2621 == nil { ifn_2622 = lang.IFn_Cast(root_2620) } else { ifn_2622 = nil }; var arg_2623 any = t.F_b__400000443; var arg_2624 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_keys); var tmp3 any = lang.IFn_Cast(tmp2.Invoke_O__O(A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d))).Invoke_O__O(m__4); var tmp4 jrt.Number_I; var na_2625 any; var na_2627 any = t.F_k
																										var na_2628 int64 = 10000

	if jrt.Long_InstanceOf(na_2627) { var n0_2629 int64 = jrt.NN(jrt.Long_Cast(na_2627)).LongValue__J(); var n1_2630 int64 = na_2628; var nr_2631 int64 = n0_2629 * n1_2630; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; tmp8 = n0_2629 == -9223372036854775808; if tmp8 { tmp8 = n1_2630 < 0 }; tmp7 = tmp8; tmp6 = !tmp7; if tmp6 { var tmp9 bool; tmp9 = n1_2630 == 0; if !tmp9 { tmp9 = nr_2631/n1_2630 == n0_2629 }; tmp6 = tmp9 }; tmp5 = tmp6; if tmp5 { na_2625 = jrt.Long_ValueOf_J__Long_NoInit(nr_2631).Ref() } else { na_2625 = lang.Numbers_Multiply_O_J__Number_NoInit(na_2627, na_2628) } } else { na_2625 = lang.Numbers_Multiply_O_J__Number_NoInit(na_2627, na_2628) }; var na_2626 any = i__3; var tmp10 bool; var tmp11 bool; tmp11 = jrt.Long_InstanceOf(na_2625); if tmp11 { tmp11 = jrt.Long_InstanceOf(na_2626) }; tmp10 = tmp11; if tmp10 { var n0_2632 int64 = jrt.NN(jrt.Long_Cast(na_2625)).LongValue__J(); var n1_2633 int64 = jrt.NN(jrt.Long_Cast(na_2626)).LongValue__J(); var nr_2634 int64 = n0_2632 + n1_2633; if (n0_2632^nr_2634)&(n1_2633^nr_2634) >= 0 { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2634)) } else { tmp4 = lang.Numbers_Add_O_O__Number_NoInit(na_2625, na_2626) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_2625); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_2626) }; tmp12 = tmp13; if tmp12 { var n0_2632_2 float64 = jrt.NN(jrt.Double_Cast(na_2625)).DoubleValue__D(); var n1_2633_2 float64 = jrt.NN(jrt.Double_Cast(na_2626)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_2632_2 + n1_2633_2)) } else { tmp4 = lang.Numbers_Add_O_O__Number_NoInit(na_2625, na_2626) } }
//line :562:1
	arg_2624 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4); if linked_2621 == nil { ifn_2622.Invoke_O_O__O(arg_2623, arg_2624) } else { linked_2621.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2620, arg_2623, arg_2624) }; i__400000442__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000442__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_c2j_node_code_forms_iter__400000469__400000475_A_New() *A_arbace_c2j_node_code_forms_iter__400000469__400000475_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000469__400000475_A{}; t.Ctor(); return t }
//line :567:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_A) Ctor() {}
//line :567:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_A) Invoke_O_O__O(self, s__400000470__1 any) any { var tmp1 any = A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_A_New_O_O(self, s__400000470__1); var tmp2 *jrt.Class; var fncls__2926 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_A_fn_class; if fncls__2926 == nil { var fncls__2926d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_A_fn_class = fncls__2926d; tmp2 = fncls__2926d } else { tmp2 = fncls__2926 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :567:1
func A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_A{}; t.Ctor_O_O(p0, p1); return t }
//line :567:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_A) Ctor_O_O(c__iter__400000469, c__s__400000470 any) { t.F_iter__400000469 = c__iter__400000469; t.F_s__400000470 = c__s__400000470 }
//line :567:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_A) Invoke_O__O(self any) any { { var s__400000470__1 any; var t_ any = t.F_s__400000470; t.F_s__400000470 = nil; s__400000470__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2740 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2740, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2742 lang.IFn; if linked_2741 == nil { ifn_2742 = lang.IFn_Cast(root_2740) } else { ifn_2742 = nil }; var arg_2743 any = s__400000470__1; if linked_2741 == nil { temp__1927000414__auto____2 = ifn_2742.Invoke_O__O(arg_2743) } else { temp__1927000414__auto____2 = linked_2741.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2740, arg_2743) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__400000477__4 any; var root_2744 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2744, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2746 lang.IFn; if linked_2745 == nil { ifn_2746 = lang.IFn_Cast(root_2744) } else { ifn_2746 = nil }; var arg_2747 any = xs__1927001018__auto____3; if linked_2745 == nil { map__400000477__4 = ifn_2746.Invoke_O__O(arg_2747) } else { map__400000477__4 = linked_2745.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2744, arg_2747) }; var map__400000477__5 any; if lang.ISeq_InstanceOf(map__400000477__4) { var tmp1 any; var root_2748 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2748, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2750 lang.IFn; if linked_2749 == nil { ifn_2750 = lang.IFn_Cast(root_2748) } else { ifn_2750 = nil }; var arg_2751 any = map__400000477__4; if linked_2749 == nil { tmp1 = ifn_2750.Invoke_O__O(arg_2751) } else { tmp1 = linked_2749.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2748, arg_2751) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2752 any = A_arbace_c2j_node_A_const_171.GetRawRoot__O(); var linked_2753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2752, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2754 lang.IFn; if linked_2753 == nil { ifn_2754 = lang.IFn_Cast(root_2752) } else { ifn_2754 = nil }; var arg_2755 any = map__400000477__4; if linked_2753 == nil { tmp2 = ifn_2754.Invoke_O__O(arg_2755) } else { tmp2 = linked_2753.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2752, arg_2755) }; map__400000477__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2756 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2757 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2756, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2758 lang.IFn; if linked_2757 == nil { ifn_2758 = lang.IFn_Cast(root_2756) } else { ifn_2758 = nil }; var arg_2759 any = map__400000477__4; if linked_2757 == nil { tmp3 = ifn_2758.Invoke_O__O(arg_2759) } else { tmp3 = linked_2757.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2756, arg_2759) }; if jrt.J2g_Truth(tmp3) { var root_2760 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2760, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2762 lang.IFn; if linked_2761 == nil { ifn_2762 = lang.IFn_Cast(root_2760) } else { ifn_2762 = nil }; var arg_2763 any = map__400000477__4; if linked_2761 == nil { map__400000477__5 = ifn_2762.Invoke_O__O(arg_2763) } else { map__400000477__5 = linked_2761.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2760, arg_2763) } } else { map__400000477__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000477__5 = map__400000477__4 }; var d__6 any = lang.RT_Get_O_O__O_NoInit(map__400000477__5, A_arbace_c2j_node_A_const_109); var vs__7 any = lang.RT_Get_O_O__O_NoInit(map__400000477__5, A_arbace_c2j_node_A_const_444); var iterys__1927001035__auto____8 any; var tmp4 any = A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_A_New_O(d__6); var tmp5 *jrt.Class; var fncls__2908 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_A_fn_class; if fncls__2908 == nil { var fncls__2908d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_A_fn_class = fncls__2908d; tmp5 = fncls__2908d } else { tmp5 = fncls__2908 }; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var fs__1927001036__auto____9 any; var root_2909 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2909, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2911 lang.IFn; if linked_2910 == nil { ifn_2911 = lang.IFn_Cast(root_2909) } else { ifn_2911 = nil }; var arg_2912 any = lang.IFn_Cast(iterys__1927001035__auto____8).Invoke_O__O(vs__7); if linked_2910 == nil { fs__1927001036__auto____9 = ifn_2911.Invoke_O__O(arg_2912) } else { fs__1927001036__auto____9 = linked_2910.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2909, arg_2912) }; if jrt.J2g_Truth(fs__1927001036__auto____9) { var root_2913 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2914 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2913, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2915 lang.IFn; if linked_2914 == nil { ifn_2915 = lang.IFn_Cast(root_2913) } else { ifn_2915 = nil }; var arg_2916 any = fs__1927001036__auto____9; var arg_2917 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__400000469); var tmp7 any; var root_2918 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2919 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2918, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2920 lang.IFn; if linked_2919 == nil { ifn_2920 = lang.IFn_Cast(root_2918) } else { ifn_2920 = nil }; var arg_2921 any = s__400000470__1; if linked_2919 == nil { tmp7 = ifn_2920.Invoke_O__O(arg_2921) } else { tmp7 = linked_2919.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2918, arg_2921) }; arg_2917 = tmp6.Invoke_O__O(tmp7); if linked_2914 == nil { return ifn_2915.Invoke_O_O__O(arg_2916, arg_2917) } else { return linked_2914.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2913, arg_2916, arg_2917) } } else { var tmp8 any; var root_2922 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2923 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2922, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2924 lang.IFn; if linked_2923 == nil { ifn_2924 = lang.IFn_Cast(root_2922) } else { ifn_2924 = nil }; var arg_2925 any = s__400000470__1; if linked_2923 == nil { tmp8 = ifn_2924.Invoke_O__O(arg_2925) } else { tmp8 = linked_2923.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2922, arg_2925) }; s__400000470__1 = tmp8; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :567:1
func A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_A_New_O(p0 any) *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_A{}; t.Ctor_O(p0); return t }
//line :567:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :567:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_A) Invoke_O_O__O(self, s__400000472__1 any) any { var tmp1 any = A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_A_New_O_O_O(self, t.F_d, s__400000472__1); var tmp2 *jrt.Class; var fncls__2907 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_A_fn_class; if fncls__2907 == nil { var fncls__2907d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_A_fn_class = fncls__2907d; tmp2 = fncls__2907d } else { tmp2 = fncls__2907 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :567:1
func A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :567:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_A) Ctor_O_O_O(c__iter__400000471, c__d, c__s__400000472 any) { t.F_iter__400000471 = c__iter__400000471; t.F_d = c__d; t.F_s__400000472 = c__s__400000472 }
//line :567:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_A) Invoke_O__O(self any) any { { var s__400000472__1 any; var t_ any = t.F_s__400000472; t.F_s__400000472 = nil; s__400000472__1 = t_; for { var temp__1927000414__auto____2 any; var root_2764 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2764, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2766 lang.IFn; if linked_2765 == nil { ifn_2766 = lang.IFn_Cast(root_2764) } else { ifn_2766 = nil }; var arg_2767 any = s__400000472__1; if linked_2765 == nil { temp__1927000414__auto____2 = ifn_2766.Invoke_O__O(arg_2767) } else { temp__1927000414__auto____2 = linked_2765.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2764, arg_2767) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000472__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2768 any = A_arbace_c2j_node_A_const_373.GetRawRoot__O(); var linked_2769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2768, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2770 lang.IFn; if linked_2769 == nil { ifn_2770 = lang.IFn_Cast(root_2768) } else { ifn_2770 = nil }; var arg_2771 any = s__400000472__3; if linked_2769 == nil { tmp1 = ifn_2770.Invoke_O__O(arg_2771) } else { tmp1 = linked_2769.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2768, arg_2771) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2772 any = A_arbace_c2j_node_A_const_374.GetRawRoot__O(); var linked_2773 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2772, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2774 lang.IFn; if linked_2773 == nil { ifn_2774 = lang.IFn_Cast(root_2772) } else { ifn_2774 = nil }; var arg_2775 any = s__400000472__3; if linked_2773 == nil { c__1927001037__auto____4 = ifn_2774.Invoke_O__O(arg_2775) } else { c__1927001037__auto____4 = linked_2773.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2772, arg_2775) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000474__6 any; var root_2776 any = A_arbace_c2j_node_A_const_375.GetRawRoot__O(); var linked_2777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2776, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2778 lang.IFn; if linked_2777 == nil { ifn_2778 = lang.IFn_Cast(root_2776) } else { ifn_2778 = nil }; var arg_2779 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2777 == nil { b__400000474__6 = ifn_2778.Invoke_O__O(arg_2779) } else { b__400000474__6 = linked_2777.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2776, arg_2779) }; var tmp2 any = A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_A_New_O_I_O_O(b__400000474__6, size__1927001038__auto____5, t.F_d, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2828 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_A_fn_class; if fncls__2828 == nil { var fncls__2828d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_A_fn_class = fncls__2828d; tmp3 = fncls__2828d } else { tmp3 = fncls__2828 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2829 any = A_arbace_c2j_node_A_const_377.GetRawRoot__O(); var linked_2830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2829, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2831 lang.IFn; if linked_2830 == nil { ifn_2831 = lang.IFn_Cast(root_2829) } else { ifn_2831 = nil }; var arg_2832 any; var root_2834 any = A_arbace_c2j_node_A_const_378.GetRawRoot__O(); var linked_2835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2834, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2836 lang.IFn; if linked_2835 == nil { ifn_2836 = lang.IFn_Cast(root_2834) } else { ifn_2836 = nil }; var arg_2837 any = b__400000474__6; if linked_2835 == nil { arg_2832 = ifn_2836.Invoke_O__O(arg_2837) } else { arg_2832 = linked_2835.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2834, arg_2837) }; var arg_2833 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000471); var tmp5 any; var root_2838 any = A_arbace_c2j_node_A_const_379.GetRawRoot__O(); var linked_2839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2838, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2840 lang.IFn; if linked_2839 == nil { ifn_2840 = lang.IFn_Cast(root_2838) } else { ifn_2840 = nil }; var arg_2841 any = s__400000472__3; if linked_2839 == nil { tmp5 = ifn_2840.Invoke_O__O(arg_2841) } else { tmp5 = linked_2839.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2838, arg_2841) }; arg_2833 = tmp4.Invoke_O__O(tmp5); if linked_2830 == nil { return ifn_2831.Invoke_O_O__O(arg_2832, arg_2833) } else { return linked_2830.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2829, arg_2832, arg_2833) } } else { var root_2842 any = A_arbace_c2j_node_A_const_377.GetRawRoot__O(); var linked_2843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2842, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2844 lang.IFn; if linked_2843 == nil { ifn_2844 = lang.IFn_Cast(root_2842) } else { ifn_2844 = nil }; var arg_2845 any; var root_2847 any = A_arbace_c2j_node_A_const_378.GetRawRoot__O(); var linked_2848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2847, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2849 lang.IFn; if linked_2848 == nil { ifn_2849 = lang.IFn_Cast(root_2847) } else { ifn_2849 = nil }; var arg_2850 any = b__400000474__6; if linked_2848 == nil { arg_2845 = ifn_2849.Invoke_O__O(arg_2850) } else { arg_2845 = linked_2848.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2847, arg_2850) }; var arg_2846 any; if linked_2843 == nil { return ifn_2844.Invoke_O_O__O(arg_2845, arg_2846) } else { return linked_2843.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2842, arg_2845, arg_2846) } } } else { var map__400000491__4 any; var root_2851 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2851, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2853 lang.IFn; if linked_2852 == nil { ifn_2853 = lang.IFn_Cast(root_2851) } else { ifn_2853 = nil }; var arg_2854 any = s__400000472__3; if linked_2852 == nil { map__400000491__4 = ifn_2853.Invoke_O__O(arg_2854) } else { map__400000491__4 = linked_2852.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2851, arg_2854) }; var map__400000491__5 any; if lang.ISeq_InstanceOf(map__400000491__4) { var tmp6 any; var root_2855 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2855, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2857 lang.IFn; if linked_2856 == nil { ifn_2857 = lang.IFn_Cast(root_2855) } else { ifn_2857 = nil }; var arg_2858 any = map__400000491__4; if linked_2856 == nil { tmp6 = ifn_2857.Invoke_O__O(arg_2858) } else { tmp6 = linked_2856.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2855, arg_2858) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_2859 any = A_arbace_c2j_node_A_const_171.GetRawRoot__O(); var linked_2860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2859, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2861 lang.IFn; if linked_2860 == nil { ifn_2861 = lang.IFn_Cast(root_2859) } else { ifn_2861 = nil }; var arg_2862 any = map__400000491__4; if linked_2860 == nil { tmp7 = ifn_2861.Invoke_O__O(arg_2862) } else { tmp7 = linked_2860.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2859, arg_2862) }; map__400000491__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp7, jrt.Object_class.ArrayClass())).Ref() } else { var tmp8 any; var root_2863 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2863, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2865 lang.IFn; if linked_2864 == nil { ifn_2865 = lang.IFn_Cast(root_2863) } else { ifn_2865 = nil }; var arg_2866 any = map__400000491__4; if linked_2864 == nil { tmp8 = ifn_2865.Invoke_O__O(arg_2866) } else { tmp8 = linked_2864.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2863, arg_2866) }; if jrt.J2g_Truth(tmp8) { var root_2867 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2867, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2869 lang.IFn; if linked_2868 == nil { ifn_2869 = lang.IFn_Cast(root_2867) } else { ifn_2869 = nil }; var arg_2870 any = map__400000491__4; if linked_2868 == nil { map__400000491__5 = ifn_2869.Invoke_O__O(arg_2870) } else { map__400000491__5 = linked_2868.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2867, arg_2870) } } else { map__400000491__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000491__5 = map__400000491__4 }; var v__6 any = lang.RT_Get_O_O__O_NoInit(map__400000491__5, A_arbace_c2j_node_A_const_56); var cf__7 any = lang.RT_Get_O_O__O_NoInit(map__400000491__5, A_arbace_c2j_node_A_const_446); var root_2871 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2871, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2873 lang.IFn; if linked_2872 == nil { ifn_2873 = lang.IFn_Cast(root_2871) } else { ifn_2873 = nil }; var arg_2874 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_34, nil, nil, nil, nil); var tmp10 any = A_arbace_c2j_node_A_const_321.Invoke_O__O(v__6); var tmp11 any = A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d); var tmp12 *jrt.String; var temp__1927000414__auto____14 any; var root_2876 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2876, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2878 lang.IFn

	if linked_2877 == nil { ifn_2878 = lang.IFn_Cast(root_2876) } else { ifn_2878 = nil }; var arg_2879 any; var root_2880 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_2881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2880, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2882 lang.IFn; if linked_2881 == nil { ifn_2882 = lang.IFn_Cast(root_2880) } else { ifn_2882 = nil }; var arg_2883 any; var tmp13 any = A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000494_A_New(); var tmp14 *jrt.Class; var fncls__2889 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000494_A_fn_class; if fncls__2889 == nil { var fncls__2889d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000494_A_fn_class = fncls__2889d; tmp14 = fncls__2889d } else { tmp14 = fncls__2889 }; arg_2883 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_2884 any = A_arbace_c2j_node_A_const_233.Invoke_O__O(v__6); if linked_2881 == nil { arg_2879 = ifn_2882.Invoke_O_O__O(arg_2883, arg_2884) } else { arg_2879 = linked_2881.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2880, arg_2883, arg_2884) }; if linked_2877 == nil { temp__1927000414__auto____14 = ifn_2878.Invoke_O__O(arg_2879) } else { temp__1927000414__auto____14 = linked_2877.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2876, arg_2879) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var s__15 any = temp__1927000414__auto____14; var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp16 any; var root_2890 any = A_arbace_c2j_node_A_const_451.GetRawRoot__O(); var linked_2891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2890, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2892 lang.IFn; if linked_2891 == nil { ifn_2892 = lang.IFn_Cast(root_2890) } else { ifn_2892 = nil }; var arg_2893 any = Lit_36; var arg_2894 any = s__15; if linked_2891 == nil { tmp16 = ifn_2892.Invoke_O_O__O(arg_2893, arg_2894) } else { tmp16 = linked_2891.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2890, arg_2893, arg_2894) }; tmp12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16)) } else { tmp12 = nil }
//line :567:1
	var tmp17 any = tmp12.Ref(); var tmp18 *jrt.String; var tmp19 any; var root_2895 any = A_arbace_c2j_node_A_const_386.GetRawRoot__O(); var linked_2896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2895, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2897 lang.IFn


	if linked_2896 == nil { ifn_2897 = lang.IFn_Cast(root_2895) } else { ifn_2897 = nil }; var arg_2898 any = A_arbace_c2j_node_A_const_220.Invoke_O__O(v__6); if linked_2896 == nil { tmp19 = ifn_2897.Invoke_O__O(arg_2898) } else { tmp19 = linked_2896.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2895, arg_2898) }; if jrt.J2g_Truth(tmp19) { var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp21 *jrt.String; var tmp22 any = A_arbace_c2j_node_A_const_219; if lang.Util_Equiv_O_O__Z_NoInit(tmp22, A_arbace_c2j_node_A_const_220.Invoke_O__O(v__6)) { tmp21 = Lit_37 } else { tmp21 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_220.Invoke_O__O(v__6), nil)) }; tmp18 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp21.Ref())) } else { tmp18 = nil }
//line :567:1
	var tmp23 any = tmp18.Ref(); var tmp24 *jrt.String



	if jrt.J2g_Truth(A_arbace_c2j_node_A_const_176.Invoke_O__O(v__6)) { var tmp25 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil, nil); var tmp26 any; var root_2899 any = A_arbace_c2j_node_A_const_450.GetRawRoot__O(); var linked_2900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2899, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2901 lang.IFn; if linked_2900 == nil { ifn_2901 = lang.IFn_Cast(root_2899) } else { ifn_2901 = nil }; var arg_2902 any = A_arbace_c2j_node_A_const_383.Invoke_O__O(v__6); if linked_2900 == nil { tmp26 = ifn_2901.Invoke_O__O(arg_2902) } else { tmp26 = linked_2900.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2899, arg_2902) }; var tmp27 any = tmp26; var tmp28 *jrt.String; if jrt.J2g_Truth(A_arbace_c2j_node_A_const_73.Invoke_O__O(v__6)) { tmp28 = Lit_39 } else { tmp28 = nil }; tmp24 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp25, jrt.RefArrayOf(jrt.Object_class, nil, tmp27, tmp28.Ref())) } else { tmp24 = nil }
//line :567:1
	arg_2874 = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp10, nil, tmp11, tmp17, tmp23, tmp24.Ref())).Ref(), cf__7); var arg_2875 any; var tmp29 lang.IFn = lang.IFn_Cast(t.F_iter__400000471); var tmp30 any; var root_2903 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2903, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2905 lang.IFn; if linked_2904 == nil { ifn_2905 = lang.IFn_Cast(root_2903) } else { ifn_2905 = nil }; var arg_2906 any = s__400000472__3; if linked_2904 == nil { tmp30 = ifn_2905.Invoke_O__O(arg_2906) } else { tmp30 = linked_2904.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2903, arg_2906) }; arg_2875 = tmp29.Invoke_O__O(tmp30); if linked_2872 == nil { return ifn_2873.Invoke_O_O__O(arg_2874, arg_2875) } else { return linked_2872.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2871, arg_2874, arg_2875) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :567:1
func A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :567:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_A) Ctor_O_I_O_O(c__b__400000474 any, c__size__1927001038__auto__ int32, c__d, c__c__1927001037__auto__ any) { t.F_b__400000474 = c__b__400000474; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_d = c__d; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :567:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_A) Invoke_O__O(self any) any { { var i__400000473__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000473__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__400000482__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000473__1)); var map__400000482__3 any; if lang.ISeq_InstanceOf(map__400000482__2) { var tmp2 any; var root_2780 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2780, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2782 lang.IFn; if linked_2781 == nil { ifn_2782 = lang.IFn_Cast(root_2780) } else { ifn_2782 = nil }; var arg_2783 any = map__400000482__2; if linked_2781 == nil { tmp2 = ifn_2782.Invoke_O__O(arg_2783) } else { tmp2 = linked_2781.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2780, arg_2783) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_2784 any = A_arbace_c2j_node_A_const_171.GetRawRoot__O(); var linked_2785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2784, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2786 lang.IFn; if linked_2785 == nil { ifn_2786 = lang.IFn_Cast(root_2784) } else { ifn_2786 = nil }; var arg_2787 any = map__400000482__2; if linked_2785 == nil { tmp3 = ifn_2786.Invoke_O__O(arg_2787) } else { tmp3 = linked_2785.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2784, arg_2787) }; map__400000482__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp3, jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 any; var root_2788 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2788, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2790 lang.IFn; if linked_2789 == nil { ifn_2790 = lang.IFn_Cast(root_2788) } else { ifn_2790 = nil }; var arg_2791 any = map__400000482__2; if linked_2789 == nil { tmp4 = ifn_2790.Invoke_O__O(arg_2791) } else { tmp4 = linked_2789.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2788, arg_2791) }; if jrt.J2g_Truth(tmp4) { var root_2792 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2792, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2794 lang.IFn; if linked_2793 == nil { ifn_2794 = lang.IFn_Cast(root_2792) } else { ifn_2794 = nil }; var arg_2795 any = map__400000482__2; if linked_2793 == nil { map__400000482__3 = ifn_2794.Invoke_O__O(arg_2795) } else { map__400000482__3 = linked_2793.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2792, arg_2795) } } else { map__400000482__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000482__3 = map__400000482__2 }; var v__4 any = lang.RT_Get_O_O__O_NoInit(map__400000482__3, A_arbace_c2j_node_A_const_56); var cf__5 any = lang.RT_Get_O_O__O_NoInit(map__400000482__3, A_arbace_c2j_node_A_const_446); var root_2796 any = A_arbace_c2j_node_A_const_376.GetRawRoot__O(); var linked_2797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2796, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2798 lang.IFn; if linked_2797 == nil { ifn_2798 = lang.IFn_Cast(root_2796) } else { ifn_2798 = nil }; var arg_2799 any = t.F_b__400000474; var arg_2800 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_34, nil, nil, nil, nil); var tmp6 any = A_arbace_c2j_node_A_const_321.Invoke_O__O(v__4); var tmp7 any = A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d); var tmp8 *jrt.String; var temp__1927000414__auto____12 any; var root_2801 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2801, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2803 lang.IFn

	if linked_2802 == nil { ifn_2803 = lang.IFn_Cast(root_2801) } else { ifn_2803 = nil }; var arg_2804 any; var root_2805 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_2806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2805, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2807 lang.IFn; if linked_2806 == nil { ifn_2807 = lang.IFn_Cast(root_2805) } else { ifn_2807 = nil }; var arg_2808 any; var tmp9 any = A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_fn__400000485_A_New(); var tmp10 *jrt.Class; var fncls__2814 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_fn__400000485_A_fn_class; if fncls__2814 == nil { var fncls__2814d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_fn__400000485_A_fn_class = fncls__2814d; tmp10 = fncls__2814d } else { tmp10 = fncls__2814 }; arg_2808 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_2809 any = A_arbace_c2j_node_A_const_233.Invoke_O__O(v__4); if linked_2806 == nil { arg_2804 = ifn_2807.Invoke_O_O__O(arg_2808, arg_2809) } else { arg_2804 = linked_2806.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2805, arg_2808, arg_2809) }; if linked_2802 == nil { temp__1927000414__auto____12 = ifn_2803.Invoke_O__O(arg_2804) } else { temp__1927000414__auto____12 = linked_2802.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2801, arg_2804) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var s__13 any = temp__1927000414__auto____12; var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp12 any; var root_2815 any = A_arbace_c2j_node_A_const_451.GetRawRoot__O(); var linked_2816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2815, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2817 lang.IFn; if linked_2816 == nil { ifn_2817 = lang.IFn_Cast(root_2815) } else { ifn_2817 = nil }; var arg_2818 any = Lit_36; var arg_2819 any = s__13; if linked_2816 == nil { tmp12 = ifn_2817.Invoke_O_O__O(arg_2818, arg_2819) } else { tmp12 = linked_2816.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2815, arg_2818, arg_2819) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp12)) } else { tmp8 = nil }
//line :567:1
	var tmp13 any = tmp8.Ref(); var tmp14 *jrt.String; var tmp15 any; var root_2820 any = A_arbace_c2j_node_A_const_386.GetRawRoot__O(); var linked_2821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2820, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2822 lang.IFn


	if linked_2821 == nil { ifn_2822 = lang.IFn_Cast(root_2820) } else { ifn_2822 = nil }; var arg_2823 any = A_arbace_c2j_node_A_const_220.Invoke_O__O(v__4); if linked_2821 == nil { tmp15 = ifn_2822.Invoke_O__O(arg_2823) } else { tmp15 = linked_2821.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2820, arg_2823) }; if jrt.J2g_Truth(tmp15) { var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp17 *jrt.String; var tmp18 any = A_arbace_c2j_node_A_const_219; if lang.Util_Equiv_O_O__Z_NoInit(tmp18, A_arbace_c2j_node_A_const_220.Invoke_O__O(v__4)) { tmp17 = Lit_37 } else { tmp17 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_220.Invoke_O__O(v__4), nil)) }; tmp14 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp17.Ref())) } else { tmp14 = nil }
//line :567:1
	var tmp19 any = tmp14.Ref(); var tmp20 *jrt.String



	if jrt.J2g_Truth(A_arbace_c2j_node_A_const_176.Invoke_O__O(v__4)) { var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil, nil); var tmp22 any; var root_2824 any = A_arbace_c2j_node_A_const_450.GetRawRoot__O(); var linked_2825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2824, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2826 lang.IFn; if linked_2825 == nil { ifn_2826 = lang.IFn_Cast(root_2824) } else { ifn_2826 = nil }; var arg_2827 any = A_arbace_c2j_node_A_const_383.Invoke_O__O(v__4); if linked_2825 == nil { tmp22 = ifn_2826.Invoke_O__O(arg_2827) } else { tmp22 = linked_2825.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2824, arg_2827) }; var tmp23 any = tmp22; var tmp24 *jrt.String; if jrt.J2g_Truth(A_arbace_c2j_node_A_const_73.Invoke_O__O(v__4)) { tmp24 = Lit_39 } else { tmp24 = nil }; tmp20 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp23, tmp24.Ref())) } else { tmp20 = nil }
//line :567:1
	arg_2800 = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil, tmp7, tmp13, tmp19, tmp20.Ref())).Ref(), cf__5); if linked_2797 == nil { ifn_2798.Invoke_O_O__O(arg_2799, arg_2800) } else { linked_2797.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2796, arg_2799, arg_2800) }; i__400000473__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000473__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_fn__400000485_A_New() *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_fn__400000485_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_fn__400000485_A{}; t.Ctor(); return t }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_fn__400000485_A) Ctor() {}
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_fn__400000485_A) Invoke_O_O__O(self, p__400000484__1 any) any { var vec__400000486__2 any = p__400000484__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000486__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000486__2, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(x__4) { var root_2810 any = A_arbace_c2j_node_A_const_450.GetRawRoot__O(); var linked_2811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2810, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2812 lang.IFn; if linked_2811 == nil { ifn_2812 = lang.IFn_Cast(root_2810) } else { ifn_2812 = nil }; var arg_2813 any = k__3; if linked_2811 == nil { return ifn_2812.Invoke_O__O(arg_2813) } else { return linked_2811.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2810, arg_2813) } } else { return nil } }
//line :569:1
func A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000494_A_New() *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000494_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000494_A{}; t.Ctor(); return t }
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000494_A) Ctor() {}
//line :569:1
func (t *A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000494_A) Invoke_O_O__O(self, p__400000493__1 any) any { var vec__400000495__2 any = p__400000493__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000495__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000495__2, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(x__4) { var root_2885 any = A_arbace_c2j_node_A_const_450.GetRawRoot__O(); var linked_2886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2885, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2887 lang.IFn; if linked_2886 == nil { ifn_2887 = lang.IFn_Cast(root_2885) } else { ifn_2887 = nil }; var arg_2888 any = k__3; if linked_2886 == nil { return ifn_2887.Invoke_O__O(arg_2888) } else { return linked_2886.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2885, arg_2888) } } else { return nil } }











func A_arbace_c2j_node_code_forms_fn__400000504_A_New() *A_arbace_c2j_node_code_forms_fn__400000504_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_fn__400000504_A{}; t.Ctor(); return t }
//line :581:1
func (t *A_arbace_c2j_node_code_forms_fn__400000504_A) Ctor() {}
//line :581:1
func (t *A_arbace_c2j_node_code_forms_fn__400000504_A) Invoke_O_O__O(self, p__400000503__1 any) any { var vec__400000505__2 any = p__400000503__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000505__2, lang.RT_IntCast_J__I_NoInit(0), nil); var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000505__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_471; var tmp3 any = A_arbace_c2j_node_A_const_472; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, k__3, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_473, i__4)) }























































































































































































































































type A_arbace_c2j_node_A struct{ jrt.Object }

var A_arbace_c2j_node_A_const_pool *jrt.RefArray

var A_arbace_c2j_node_A_const_0 *lang.Var

var A_arbace_c2j_node_A_const_1 any

var A_arbace_c2j_node_A_const_2 *lang.Var

var A_arbace_c2j_node_A_const_3 any

var A_arbace_c2j_node_A_const_4 *lang.Var

var A_arbace_c2j_node_A_const_5 *lang.Var

var A_arbace_c2j_node_A_const_6 *lang.Var

var A_arbace_c2j_node_A_const_7 *lang.Var

var A_arbace_c2j_node_A_const_8 any

var A_arbace_c2j_node_A_const_9 *lang.Var

var A_arbace_c2j_node_A_const_10 *lang.Var

var A_arbace_c2j_node_A_const_11 *lang.Var

var A_arbace_c2j_node_A_const_12 *lang.Var

var A_arbace_c2j_node_A_const_13 *lang.Keyword

var A_arbace_c2j_node_A_const_14 *lang.Var

var A_arbace_c2j_node_A_const_15 *lang.Keyword

var A_arbace_c2j_node_A_const_16 *lang.Keyword

var A_arbace_c2j_node_A_const_17 *lang.Keyword

var A_arbace_c2j_node_A_const_18 *lang.Var

var A_arbace_c2j_node_A_const_19 *lang.Keyword

var A_arbace_c2j_node_A_const_20 *lang.Keyword

var A_arbace_c2j_node_A_const_21 *lang.Keyword

var A_arbace_c2j_node_A_const_22 *lang.Var

var A_arbace_c2j_node_A_const_23 *lang.Var

var A_arbace_c2j_node_A_const_24 *lang.Var

var A_arbace_c2j_node_A_const_25 any

var A_arbace_c2j_node_A_const_26 *lang.Keyword

var A_arbace_c2j_node_A_const_27 *lang.Var

var A_arbace_c2j_node_A_const_28 *lang.Var

var A_arbace_c2j_node_A_const_29 *lang.Var

var A_arbace_c2j_node_A_const_30 any

var A_arbace_c2j_node_A_const_31 *lang.Keyword

var A_arbace_c2j_node_A_const_32 *lang.Var

var A_arbace_c2j_node_A_const_33 any

var A_arbace_c2j_node_A_const_34 *lang.Var

var A_arbace_c2j_node_A_const_35 *lang.Var

var A_arbace_c2j_node_A_const_36 *lang.Var

var A_arbace_c2j_node_A_const_37 *lang.Var

var A_arbace_c2j_node_A_const_38 *lang.Var

var A_arbace_c2j_node_A_const_39 *lang.Var

var A_arbace_c2j_node_A_const_40 *lang.Var

var A_arbace_c2j_node_A_const_41 *lang.Var

var A_arbace_c2j_node_A_const_42 *lang.Var

var A_arbace_c2j_node_A_const_43 *lang.Var

var A_arbace_c2j_node_A_const_44 *lang.Var

var A_arbace_c2j_node_A_const_45 *lang.Keyword

var A_arbace_c2j_node_A_const_46 any

var A_arbace_c2j_node_A_const_47 *lang.Var

var A_arbace_c2j_node_A_const_48 *lang.Var

var A_arbace_c2j_node_A_const_49 *lang.Var

var A_arbace_c2j_node_A_const_50 *lang.Var

var A_arbace_c2j_node_A_const_51 any

var A_arbace_c2j_node_A_const_52 *lang.Var

var A_arbace_c2j_node_A_const_53 *lang.Var

var A_arbace_c2j_node_A_const_54 *lang.Var

var A_arbace_c2j_node_A_const_55 *lang.Keyword

var A_arbace_c2j_node_A_const_56 *lang.Keyword

var A_arbace_c2j_node_A_const_57 any

var A_arbace_c2j_node_A_const_58 *lang.Keyword

var A_arbace_c2j_node_A_const_59 *lang.Var

var A_arbace_c2j_node_A_const_60 *lang.Var

var A_arbace_c2j_node_A_const_61 *lang.Var

var A_arbace_c2j_node_A_const_62 *lang.Var

var A_arbace_c2j_node_A_const_63 any

var A_arbace_c2j_node_A_const_64 any

var A_arbace_c2j_node_A_const_65 any

var A_arbace_c2j_node_A_const_66 any

var A_arbace_c2j_node_A_const_67 any

var A_arbace_c2j_node_A_const_68 any

var A_arbace_c2j_node_A_const_69 any

var A_arbace_c2j_node_A_const_70 any

var A_arbace_c2j_node_A_const_71 *lang.Keyword

var A_arbace_c2j_node_A_const_72 any

var A_arbace_c2j_node_A_const_73 *lang.Keyword

var A_arbace_c2j_node_A_const_74 *lang.Var

var A_arbace_c2j_node_A_const_75 *lang.Var

var A_arbace_c2j_node_A_const_76 any

var A_arbace_c2j_node_A_const_77 any

var A_arbace_c2j_node_A_const_78 *lang.Var

var A_arbace_c2j_node_A_const_79 any

var A_arbace_c2j_node_A_const_80 any

var A_arbace_c2j_node_A_const_81 *lang.Var

var A_arbace_c2j_node_A_const_82 any

var A_arbace_c2j_node_A_const_83 *lang.Var

var A_arbace_c2j_node_A_const_84 any

var A_arbace_c2j_node_A_const_85 any

var A_arbace_c2j_node_A_const_86 any

var A_arbace_c2j_node_A_const_87 any

var A_arbace_c2j_node_A_const_88 any

var A_arbace_c2j_node_A_const_89 any

var A_arbace_c2j_node_A_const_90 any

var A_arbace_c2j_node_A_const_91 any

var A_arbace_c2j_node_A_const_92 any

var A_arbace_c2j_node_A_const_93 any

var A_arbace_c2j_node_A_const_94 any

var A_arbace_c2j_node_A_const_95 any

var A_arbace_c2j_node_A_const_96 any

var A_arbace_c2j_node_A_const_97 any

var A_arbace_c2j_node_A_const_98 *lang.Var

var A_arbace_c2j_node_A_const_99 *lang.Var

var A_arbace_c2j_node_A_const_100 any

var A_arbace_c2j_node_A_const_101 any

var A_arbace_c2j_node_A_const_102 any

var A_arbace_c2j_node_A_const_103 any

var A_arbace_c2j_node_A_const_104 any

var A_arbace_c2j_node_A_const_105 *lang.Keyword

var A_arbace_c2j_node_A_const_106 any

var A_arbace_c2j_node_A_const_107 *lang.Keyword

var A_arbace_c2j_node_A_const_108 any

var A_arbace_c2j_node_A_const_109 *lang.Keyword

var A_arbace_c2j_node_A_const_110 *lang.Keyword

var A_arbace_c2j_node_A_const_111 any

var A_arbace_c2j_node_A_const_112 any

var A_arbace_c2j_node_A_const_113 any

var A_arbace_c2j_node_A_const_114 any

var A_arbace_c2j_node_A_const_115 any

var A_arbace_c2j_node_A_const_116 any

var A_arbace_c2j_node_A_const_117 any

var A_arbace_c2j_node_A_const_118 any

var A_arbace_c2j_node_A_const_119 any

var A_arbace_c2j_node_A_const_120 *lang.Keyword

var A_arbace_c2j_node_A_const_121 any

var A_arbace_c2j_node_A_const_122 any

var A_arbace_c2j_node_A_const_123 any

var A_arbace_c2j_node_A_const_124 any

var A_arbace_c2j_node_A_const_125 any

var A_arbace_c2j_node_A_const_126 *lang.Keyword

var A_arbace_c2j_node_A_const_127 any

var A_arbace_c2j_node_A_const_128 *lang.Var

var A_arbace_c2j_node_A_const_129 *lang.Var

var A_arbace_c2j_node_A_const_130 any

var A_arbace_c2j_node_A_const_131 *lang.Keyword

var A_arbace_c2j_node_A_const_132 any

var A_arbace_c2j_node_A_const_133 any

var A_arbace_c2j_node_A_const_134 any

var A_arbace_c2j_node_A_const_135 any

var A_arbace_c2j_node_A_const_136 *lang.Keyword

var A_arbace_c2j_node_A_const_137 any

var A_arbace_c2j_node_A_const_138 any

var A_arbace_c2j_node_A_const_139 any

var A_arbace_c2j_node_A_const_140 *lang.Var

var A_arbace_c2j_node_A_const_141 any

var A_arbace_c2j_node_A_const_142 any

var A_arbace_c2j_node_A_const_143 any

var A_arbace_c2j_node_A_const_144 any

var A_arbace_c2j_node_A_const_145 any

var A_arbace_c2j_node_A_const_146 any

var A_arbace_c2j_node_A_const_147 any

var A_arbace_c2j_node_A_const_148 any

var A_arbace_c2j_node_A_const_149 any

var A_arbace_c2j_node_A_const_150 any

var A_arbace_c2j_node_A_const_151 any

var A_arbace_c2j_node_A_const_152 any

var A_arbace_c2j_node_A_const_153 any

var A_arbace_c2j_node_A_const_154 any

var A_arbace_c2j_node_A_const_155 *lang.Keyword

var A_arbace_c2j_node_A_const_156 *lang.Var

var A_arbace_c2j_node_A_const_157 *lang.Var

var A_arbace_c2j_node_A_const_158 any

var A_arbace_c2j_node_A_const_159 any

var A_arbace_c2j_node_A_const_160 any

var A_arbace_c2j_node_A_const_161 *lang.Keyword

var A_arbace_c2j_node_A_const_162 any

var A_arbace_c2j_node_A_const_163 any

var A_arbace_c2j_node_A_const_164 any

var A_arbace_c2j_node_A_const_165 *lang.Var

var A_arbace_c2j_node_A_const_166 any

var A_arbace_c2j_node_A_const_167 *lang.Keyword

var A_arbace_c2j_node_A_const_168 any

var A_arbace_c2j_node_A_const_169 *lang.Keyword

var A_arbace_c2j_node_A_const_170 *lang.Keyword

var A_arbace_c2j_node_A_const_171 *lang.Var

var A_arbace_c2j_node_A_const_172 any

var A_arbace_c2j_node_A_const_173 any

var A_arbace_c2j_node_A_const_174 any

var A_arbace_c2j_node_A_const_175 any

var A_arbace_c2j_node_A_const_176 *lang.Keyword

var A_arbace_c2j_node_A_const_177 any

var A_arbace_c2j_node_A_const_178 any

var A_arbace_c2j_node_A_const_179 any

var A_arbace_c2j_node_A_const_180 *lang.Keyword

var A_arbace_c2j_node_A_const_181 any

var A_arbace_c2j_node_A_const_182 any

var A_arbace_c2j_node_A_const_183 any

var A_arbace_c2j_node_A_const_184 *lang.Keyword

var A_arbace_c2j_node_A_const_185 any

var A_arbace_c2j_node_A_const_186 *lang.Var

var A_arbace_c2j_node_A_const_187 *lang.Var

var A_arbace_c2j_node_A_const_188 any

var A_arbace_c2j_node_A_const_189 any

var A_arbace_c2j_node_A_const_190 any

var A_arbace_c2j_node_A_const_191 any

var A_arbace_c2j_node_A_const_192 any

var A_arbace_c2j_node_A_const_193 any

var A_arbace_c2j_node_A_const_194 any

var A_arbace_c2j_node_A_const_195 *lang.Keyword

var A_arbace_c2j_node_A_const_196 any

var A_arbace_c2j_node_A_const_197 any

var A_arbace_c2j_node_A_const_198 any

var A_arbace_c2j_node_A_const_199 any

var A_arbace_c2j_node_A_const_200 *lang.Var

var A_arbace_c2j_node_A_const_201 any

var A_arbace_c2j_node_A_const_202 *lang.Var

var A_arbace_c2j_node_A_const_203 any

var A_arbace_c2j_node_A_const_204 any

var A_arbace_c2j_node_A_const_205 any

var A_arbace_c2j_node_A_const_206 *lang.Var

var A_arbace_c2j_node_A_const_207 *lang.Keyword

var A_arbace_c2j_node_A_const_208 any

var A_arbace_c2j_node_A_const_209 any

var A_arbace_c2j_node_A_const_210 any

var A_arbace_c2j_node_A_const_211 any

var A_arbace_c2j_node_A_const_212 any

var A_arbace_c2j_node_A_const_213 *lang.Keyword

var A_arbace_c2j_node_A_const_214 *lang.Var

var A_arbace_c2j_node_A_const_215 *lang.Keyword

var A_arbace_c2j_node_A_const_216 *lang.Var

var A_arbace_c2j_node_A_const_217 *lang.Var

var A_arbace_c2j_node_A_const_218 any

var A_arbace_c2j_node_A_const_219 *lang.Keyword

var A_arbace_c2j_node_A_const_220 *lang.Keyword

var A_arbace_c2j_node_A_const_221 *lang.Keyword

var A_arbace_c2j_node_A_const_222 *lang.Keyword

var A_arbace_c2j_node_A_const_223 any

var A_arbace_c2j_node_A_const_224 any

var A_arbace_c2j_node_A_const_225 *lang.Var

var A_arbace_c2j_node_A_const_226 any

var A_arbace_c2j_node_A_const_227 any

var A_arbace_c2j_node_A_const_228 *lang.Var

var A_arbace_c2j_node_A_const_229 any

var A_arbace_c2j_node_A_const_230 *lang.Keyword

var A_arbace_c2j_node_A_const_231 *lang.Keyword

var A_arbace_c2j_node_A_const_232 any

var A_arbace_c2j_node_A_const_233 *lang.Keyword

var A_arbace_c2j_node_A_const_234 any

var A_arbace_c2j_node_A_const_235 any

var A_arbace_c2j_node_A_const_236 any

var A_arbace_c2j_node_A_const_237 any

var A_arbace_c2j_node_A_const_238 any

var A_arbace_c2j_node_A_const_239 any

var A_arbace_c2j_node_A_const_240 any

var A_arbace_c2j_node_A_const_241 *lang.Var

var A_arbace_c2j_node_A_const_242 any

var A_arbace_c2j_node_A_const_243 any

var A_arbace_c2j_node_A_const_244 *lang.Keyword

var A_arbace_c2j_node_A_const_245 any

var A_arbace_c2j_node_A_const_246 any

var A_arbace_c2j_node_A_const_247 *lang.Keyword

var A_arbace_c2j_node_A_const_248 any

var A_arbace_c2j_node_A_const_249 any

var A_arbace_c2j_node_A_const_250 any

var A_arbace_c2j_node_A_const_251 *lang.Var

var A_arbace_c2j_node_A_const_252 any

var A_arbace_c2j_node_A_const_253 *lang.Keyword

var A_arbace_c2j_node_A_const_254 *lang.Keyword

var A_arbace_c2j_node_A_const_255 *lang.Var

var A_arbace_c2j_node_A_const_256 any

var A_arbace_c2j_node_A_const_257 any

var A_arbace_c2j_node_A_const_258 *lang.Keyword

var A_arbace_c2j_node_A_const_259 *lang.Var

var A_arbace_c2j_node_A_const_260 any

var A_arbace_c2j_node_A_const_261 any

var A_arbace_c2j_node_A_const_262 *lang.Var

var A_arbace_c2j_node_A_const_263 any

var A_arbace_c2j_node_A_const_264 any

var A_arbace_c2j_node_A_const_265 any

var A_arbace_c2j_node_A_const_266 any

var A_arbace_c2j_node_A_const_267 *lang.Var

var A_arbace_c2j_node_A_const_268 *lang.Var

var A_arbace_c2j_node_A_const_269 *lang.Keyword

var A_arbace_c2j_node_A_const_270 any

var A_arbace_c2j_node_A_const_271 any

var A_arbace_c2j_node_A_const_272 any

var A_arbace_c2j_node_A_const_273 *lang.Keyword

var A_arbace_c2j_node_A_const_274 *lang.Var

var A_arbace_c2j_node_A_const_275 *lang.Var

var A_arbace_c2j_node_A_const_276 *jrt.Class

var A_arbace_c2j_node_A_const_277 any

var A_arbace_c2j_node_A_const_278 any

var A_arbace_c2j_node_A_const_279 any

var A_arbace_c2j_node_A_const_280 any

var A_arbace_c2j_node_A_const_281 any

var A_arbace_c2j_node_A_const_282 any

var A_arbace_c2j_node_A_const_283 any

var A_arbace_c2j_node_A_const_284 any

var A_arbace_c2j_node_A_const_285 any

var A_arbace_c2j_node_A_const_286 any

var A_arbace_c2j_node_A_const_287 any

var A_arbace_c2j_node_A_const_288 any

var A_arbace_c2j_node_A_const_289 any

var A_arbace_c2j_node_A_const_290 any

var A_arbace_c2j_node_A_const_291 *lang.Var

var A_arbace_c2j_node_A_const_292 *lang.Var

var A_arbace_c2j_node_A_const_293 any

var A_arbace_c2j_node_A_const_294 any

var A_arbace_c2j_node_A_const_295 *lang.Var

var A_arbace_c2j_node_A_const_296 *lang.Var

var A_arbace_c2j_node_A_const_297 *lang.Var

var A_arbace_c2j_node_A_const_298 any

var A_arbace_c2j_node_A_const_299 *lang.Var

var A_arbace_c2j_node_A_const_300 any

var A_arbace_c2j_node_A_const_301 *lang.Var

var A_arbace_c2j_node_A_const_302 *lang.Keyword

var A_arbace_c2j_node_A_const_303 any

var A_arbace_c2j_node_A_const_304 any

var A_arbace_c2j_node_A_const_305 any

var A_arbace_c2j_node_A_const_306 any

var A_arbace_c2j_node_A_const_307 any

var A_arbace_c2j_node_A_const_308 any

var A_arbace_c2j_node_A_const_309 any

var A_arbace_c2j_node_A_const_310 *lang.Var

var A_arbace_c2j_node_A_const_311 *lang.Keyword

var A_arbace_c2j_node_A_const_312 any

var A_arbace_c2j_node_A_const_313 *lang.Keyword

var A_arbace_c2j_node_A_const_314 *lang.Keyword

var A_arbace_c2j_node_A_const_315 *lang.Var

var A_arbace_c2j_node_A_const_316 any

var A_arbace_c2j_node_A_const_317 any

var A_arbace_c2j_node_A_const_318 *lang.Var

var A_arbace_c2j_node_A_const_319 any

var A_arbace_c2j_node_A_const_320 any

var A_arbace_c2j_node_A_const_321 *lang.Keyword

var A_arbace_c2j_node_A_const_322 any

var A_arbace_c2j_node_A_const_323 any

var A_arbace_c2j_node_A_const_324 any

var A_arbace_c2j_node_A_const_325 any

var A_arbace_c2j_node_A_const_326 any

var A_arbace_c2j_node_A_const_327 *lang.Var

var A_arbace_c2j_node_A_const_328 *lang.Keyword

var A_arbace_c2j_node_A_const_329 *lang.Var

var A_arbace_c2j_node_A_const_330 *lang.Keyword

var A_arbace_c2j_node_A_const_331 any

var A_arbace_c2j_node_A_const_332 any

var A_arbace_c2j_node_A_const_333 *lang.Keyword

var A_arbace_c2j_node_A_const_334 any

var A_arbace_c2j_node_A_const_335 any

var A_arbace_c2j_node_A_const_336 any

var A_arbace_c2j_node_A_const_337 any

var A_arbace_c2j_node_A_const_338 any

var A_arbace_c2j_node_A_const_339 *lang.Var

var A_arbace_c2j_node_A_const_340 any

var A_arbace_c2j_node_A_const_341 any

var A_arbace_c2j_node_A_const_342 any

var A_arbace_c2j_node_A_const_343 any

var A_arbace_c2j_node_A_const_344 any

var A_arbace_c2j_node_A_const_345 any

var A_arbace_c2j_node_A_const_346 any

var A_arbace_c2j_node_A_const_347 any

var A_arbace_c2j_node_A_const_348 any

var A_arbace_c2j_node_A_const_349 any

var A_arbace_c2j_node_A_const_350 any

var A_arbace_c2j_node_A_const_351 any

var A_arbace_c2j_node_A_const_352 any

var A_arbace_c2j_node_A_const_353 any

var A_arbace_c2j_node_A_const_354 any

var A_arbace_c2j_node_A_const_355 any

var A_arbace_c2j_node_A_const_356 any

var A_arbace_c2j_node_A_const_357 *lang.Keyword

var A_arbace_c2j_node_A_const_358 any

var A_arbace_c2j_node_A_const_359 any

var A_arbace_c2j_node_A_const_360 *lang.Keyword

var A_arbace_c2j_node_A_const_361 *lang.Keyword

var A_arbace_c2j_node_A_const_362 any

var A_arbace_c2j_node_A_const_363 any

var A_arbace_c2j_node_A_const_364 any

var A_arbace_c2j_node_A_const_365 any

var A_arbace_c2j_node_A_const_366 any

var A_arbace_c2j_node_A_const_367 *lang.Keyword

var A_arbace_c2j_node_A_const_368 *lang.Var

var A_arbace_c2j_node_A_const_369 *lang.Var

var A_arbace_c2j_node_A_const_370 *lang.Var

var A_arbace_c2j_node_A_const_371 any

var A_arbace_c2j_node_A_const_372 any

var A_arbace_c2j_node_A_const_373 *lang.Var

var A_arbace_c2j_node_A_const_374 *lang.Var

var A_arbace_c2j_node_A_const_375 *lang.Var

var A_arbace_c2j_node_A_const_376 *lang.Var

var A_arbace_c2j_node_A_const_377 *lang.Var

var A_arbace_c2j_node_A_const_378 *lang.Var

var A_arbace_c2j_node_A_const_379 *lang.Var

var A_arbace_c2j_node_A_const_380 any

var A_arbace_c2j_node_A_const_381 *lang.Keyword

var A_arbace_c2j_node_A_const_382 any

var A_arbace_c2j_node_A_const_383 *lang.Keyword

var A_arbace_c2j_node_A_const_384 any

var A_arbace_c2j_node_A_const_385 any

var A_arbace_c2j_node_A_const_386 *lang.Var

var A_arbace_c2j_node_A_const_387 *lang.Var

var A_arbace_c2j_node_A_const_388 *lang.Var

var A_arbace_c2j_node_A_const_389 *lang.Keyword

var A_arbace_c2j_node_A_const_390 any

var A_arbace_c2j_node_A_const_391 any

var A_arbace_c2j_node_A_const_392 any

var A_arbace_c2j_node_A_const_393 any

var A_arbace_c2j_node_A_const_394 any

var A_arbace_c2j_node_A_const_395 any

var A_arbace_c2j_node_A_const_396 any

var A_arbace_c2j_node_A_const_397 any

var A_arbace_c2j_node_A_const_398 any

var A_arbace_c2j_node_A_const_399 any

var A_arbace_c2j_node_A_const_400 any

var A_arbace_c2j_node_A_const_401 any

var A_arbace_c2j_node_A_const_402 any

var A_arbace_c2j_node_A_const_403 any

var A_arbace_c2j_node_A_const_404 any

var A_arbace_c2j_node_A_const_405 *lang.Var

var A_arbace_c2j_node_A_const_406 *lang.Var

var A_arbace_c2j_node_A_const_407 *lang.Var

var A_arbace_c2j_node_A_const_408 *lang.Var

var A_arbace_c2j_node_A_const_409 *lang.Var

var A_arbace_c2j_node_A_const_410 any

var A_arbace_c2j_node_A_const_411 any

var A_arbace_c2j_node_A_const_412 any

var A_arbace_c2j_node_A_const_413 any

var A_arbace_c2j_node_A_const_414 any

var A_arbace_c2j_node_A_const_415 any

var A_arbace_c2j_node_A_const_416 any

var A_arbace_c2j_node_A_const_417 any

var A_arbace_c2j_node_A_const_418 any

var A_arbace_c2j_node_A_const_419 any

var A_arbace_c2j_node_A_const_420 any

var A_arbace_c2j_node_A_const_421 any

var A_arbace_c2j_node_A_const_422 any

var A_arbace_c2j_node_A_const_423 any

var A_arbace_c2j_node_A_const_424 any

var A_arbace_c2j_node_A_const_425 any

var A_arbace_c2j_node_A_const_426 any

var A_arbace_c2j_node_A_const_427 any

var A_arbace_c2j_node_A_const_428 any

var A_arbace_c2j_node_A_const_429 any

var A_arbace_c2j_node_A_const_430 any

var A_arbace_c2j_node_A_const_431 any

var A_arbace_c2j_node_A_const_432 any

var A_arbace_c2j_node_A_const_433 *lang.Keyword

var A_arbace_c2j_node_A_const_434 any

var A_arbace_c2j_node_A_const_435 any

var A_arbace_c2j_node_A_const_436 any

var A_arbace_c2j_node_A_const_437 any

var A_arbace_c2j_node_A_const_438 any

var A_arbace_c2j_node_A_const_439 any

var A_arbace_c2j_node_A_const_440 any

var A_arbace_c2j_node_A_const_441 any

var A_arbace_c2j_node_A_const_442 any

var A_arbace_c2j_node_A_const_443 any

var A_arbace_c2j_node_A_const_444 *lang.Keyword

var A_arbace_c2j_node_A_const_445 *lang.Var

var A_arbace_c2j_node_A_const_446 *lang.Keyword

var A_arbace_c2j_node_A_const_447 *lang.Var

var A_arbace_c2j_node_A_const_448 *lang.Var

var A_arbace_c2j_node_A_const_449 *lang.Var

var A_arbace_c2j_node_A_const_450 *lang.Var

var A_arbace_c2j_node_A_const_451 *lang.Var

var A_arbace_c2j_node_A_const_452 any

var A_arbace_c2j_node_A_const_453 any

var A_arbace_c2j_node_A_const_454 any

var A_arbace_c2j_node_A_const_455 any

var A_arbace_c2j_node_A_const_456 any

var A_arbace_c2j_node_A_const_457 any

var A_arbace_c2j_node_A_const_458 any

var A_arbace_c2j_node_A_const_459 any

var A_arbace_c2j_node_A_const_460 any

var A_arbace_c2j_node_A_const_461 any

var A_arbace_c2j_node_A_const_462 any

var A_arbace_c2j_node_A_const_463 any

var A_arbace_c2j_node_A_const_464 any

var A_arbace_c2j_node_A_const_465 any

var A_arbace_c2j_node_A_const_466 any

var A_arbace_c2j_node_A_const_467 any

var A_arbace_c2j_node_A_const_468 any

var A_arbace_c2j_node_A_const_469 any

var A_arbace_c2j_node_A_const_470 any

var A_arbace_c2j_node_A_const_471 any

var A_arbace_c2j_node_A_const_472 any

var A_arbace_c2j_node_A_const_473 any

var A_arbace_c2j_node_A_const_474 any

var A_arbace_c2j_node_A_init jrt.ClassInit

func A_arbace_c2j_node_A_Init() { if !A_arbace_c2j_node_A_init.Done() { A_arbace_c2j_node_A_init.Run(A_arbace_c2j_node_A_clinit) } }

func A_arbace_c2j_node_A_clinit() { A_arbace_c2j_node_A_clinit_p0(); A_arbace_c2j_node_A_clinit_p1(); A_arbace_c2j_node_A_clinit_p2(); A_arbace_c2j_node_A_clinit_p3(); A_arbace_c2j_node_A_clinit_p4(); A_arbace_c2j_node_A_clinit_p5(); A_arbace_c2j_node_A_clinit_p6(); A_arbace_c2j_node_A_clinit_p7(); A_arbace_c2j_node_A_clinit_p8(); A_arbace_c2j_node_A_clinit_p9(); A_arbace_c2j_node_A_clinit_p10(); A_arbace_c2j_node_A_clinit_p11(); A_arbace_c2j_node_A_clinit_p12(); A_arbace_c2j_node_A_clinit_p13(); A_arbace_c2j_node_A_clinit_p14(); A_arbace_c2j_node_A_clinit_p15(); A_arbace_c2j_node_A_clinit_p16(); A_arbace_c2j_node_A_clinit_p17(); A_arbace_c2j_node_A_clinit_p18(); A_arbace_c2j_node_A_clinit_p19(); A_arbace_c2j_node_A_clinit_p20(); A_arbace_c2j_node_A_clinit_p21(); A_arbace_c2j_node_A_clinit_p22(); A_arbace_c2j_node_A_clinit_p23(); A_arbace_c2j_node_A_clinit_p24(); A_arbace_c2j_node_A_clinit_p25(); A_arbace_c2j_node_A_clinit_p26(); A_arbace_c2j_node_A_clinit_p27(); A_arbace_c2j_node_A_clinit_p28(); A_arbace_c2j_node_A_clinit_p29(); A_arbace_c2j_node_A_clinit_p30(); A_arbace_c2j_node_A_clinit_p31(); A_arbace_c2j_node_A_clinit_p32(); A_arbace_c2j_node_A_clinit_p33(); A_arbace_c2j_node_A_clinit_p34() }

func A_arbace_c2j_node_A_clinit_p0() { jrt.StartCheck(); A_arbace_c2j_node_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 661); A_arbace_c2j_node_A_const_0 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[186]); A_arbace_c2j_node_A_const_1 = A_arbace_c2j_node_A_const_pool.A[187]; A_arbace_c2j_node_A_const_2 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[188]); A_arbace_c2j_node_A_const_3 = A_arbace_c2j_node_A_const_pool.A[189]; A_arbace_c2j_node_A_const_4 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[190]); A_arbace_c2j_node_A_const_5 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[191]); A_arbace_c2j_node_A_const_6 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[192]); A_arbace_c2j_node_A_const_7 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[193]); A_arbace_c2j_node_A_const_8 = A_arbace_c2j_node_A_const_pool.A[194]; A_arbace_c2j_node_A_const_9 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[195]); A_arbace_c2j_node_A_const_10 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[196]); A_arbace_c2j_node_A_const_11 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[197]) }

func A_arbace_c2j_node_A_clinit_p1() { A_arbace_c2j_node_A_const_12 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[198]); A_arbace_c2j_node_A_const_13 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[199]); A_arbace_c2j_node_A_const_14 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[200]); A_arbace_c2j_node_A_const_15 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[201]); A_arbace_c2j_node_A_const_16 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[202]); A_arbace_c2j_node_A_const_17 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[203]); A_arbace_c2j_node_A_const_18 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[204]); A_arbace_c2j_node_A_const_19 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[205]); A_arbace_c2j_node_A_const_20 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[206]); A_arbace_c2j_node_A_const_21 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[207]); A_arbace_c2j_node_A_const_22 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[208]); A_arbace_c2j_node_A_const_23 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[209]) }

func A_arbace_c2j_node_A_clinit_p2() { A_arbace_c2j_node_A_const_24 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[210]); A_arbace_c2j_node_A_const_25 = A_arbace_c2j_node_A_const_pool.A[211]; A_arbace_c2j_node_A_const_26 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[212]); A_arbace_c2j_node_A_const_27 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[213]); A_arbace_c2j_node_A_const_28 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[214]); A_arbace_c2j_node_A_const_29 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[215]); A_arbace_c2j_node_A_const_30 = A_arbace_c2j_node_A_const_pool.A[216]; A_arbace_c2j_node_A_const_31 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[217]); A_arbace_c2j_node_A_const_32 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[218]); A_arbace_c2j_node_A_const_33 = A_arbace_c2j_node_A_const_pool.A[219]; A_arbace_c2j_node_A_const_34 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[220]); A_arbace_c2j_node_A_const_35 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[221]) }

func A_arbace_c2j_node_A_clinit_p3() { A_arbace_c2j_node_A_const_36 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[222]); A_arbace_c2j_node_A_const_37 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[223]); A_arbace_c2j_node_A_const_38 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[224]); A_arbace_c2j_node_A_const_39 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[225]); A_arbace_c2j_node_A_const_40 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[226]); A_arbace_c2j_node_A_const_41 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[227]); A_arbace_c2j_node_A_const_42 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[228]); A_arbace_c2j_node_A_const_43 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[229]); A_arbace_c2j_node_A_const_44 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[230]); A_arbace_c2j_node_A_const_45 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[231]); A_arbace_c2j_node_A_const_46 = A_arbace_c2j_node_A_const_pool.A[232]; A_arbace_c2j_node_A_const_47 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[233]) }

func A_arbace_c2j_node_A_clinit_p4() { A_arbace_c2j_node_A_const_48 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[234]); A_arbace_c2j_node_A_const_49 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[235]); A_arbace_c2j_node_A_const_50 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[236]); A_arbace_c2j_node_A_const_51 = A_arbace_c2j_node_A_const_pool.A[237]; A_arbace_c2j_node_A_const_52 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[238]); A_arbace_c2j_node_A_const_53 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[239]); A_arbace_c2j_node_A_const_54 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[240]); A_arbace_c2j_node_A_const_55 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[241]); A_arbace_c2j_node_A_const_56 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[242]); A_arbace_c2j_node_A_const_57 = A_arbace_c2j_node_A_const_pool.A[243]; A_arbace_c2j_node_A_const_58 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[244]); A_arbace_c2j_node_A_const_59 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[245]) }

func A_arbace_c2j_node_A_clinit_p5() { A_arbace_c2j_node_A_const_60 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[246]); A_arbace_c2j_node_A_const_61 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[247]); A_arbace_c2j_node_A_const_62 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[248]); A_arbace_c2j_node_A_const_63 = A_arbace_c2j_node_A_const_pool.A[249]; A_arbace_c2j_node_A_const_64 = A_arbace_c2j_node_A_const_pool.A[250]; A_arbace_c2j_node_A_const_65 = A_arbace_c2j_node_A_const_pool.A[251]; A_arbace_c2j_node_A_const_66 = A_arbace_c2j_node_A_const_pool.A[252]; A_arbace_c2j_node_A_const_67 = A_arbace_c2j_node_A_const_pool.A[253]; A_arbace_c2j_node_A_const_68 = A_arbace_c2j_node_A_const_pool.A[254]; A_arbace_c2j_node_A_const_69 = A_arbace_c2j_node_A_const_pool.A[255]; A_arbace_c2j_node_A_const_70 = A_arbace_c2j_node_A_const_pool.A[256]; A_arbace_c2j_node_A_const_71 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[257]); A_arbace_c2j_node_A_const_72 = A_arbace_c2j_node_A_const_pool.A[258]; A_arbace_c2j_node_A_const_73 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[259]) }

func A_arbace_c2j_node_A_clinit_p6() { A_arbace_c2j_node_A_const_74 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[260]); A_arbace_c2j_node_A_const_75 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[261]); A_arbace_c2j_node_A_const_76 = A_arbace_c2j_node_A_const_pool.A[262]; A_arbace_c2j_node_A_const_77 = A_arbace_c2j_node_A_const_pool.A[263]; A_arbace_c2j_node_A_const_78 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[264]); A_arbace_c2j_node_A_const_79 = A_arbace_c2j_node_A_const_pool.A[265]; A_arbace_c2j_node_A_const_80 = A_arbace_c2j_node_A_const_pool.A[266]; A_arbace_c2j_node_A_const_81 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[267]); A_arbace_c2j_node_A_const_82 = A_arbace_c2j_node_A_const_pool.A[268]; A_arbace_c2j_node_A_const_83 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[269]); A_arbace_c2j_node_A_const_84 = A_arbace_c2j_node_A_const_pool.A[270]; A_arbace_c2j_node_A_const_85 = A_arbace_c2j_node_A_const_pool.A[271]; A_arbace_c2j_node_A_const_86 = A_arbace_c2j_node_A_const_pool.A[272]; A_arbace_c2j_node_A_const_87 = A_arbace_c2j_node_A_const_pool.A[273] }

func A_arbace_c2j_node_A_clinit_p7() { A_arbace_c2j_node_A_const_88 = A_arbace_c2j_node_A_const_pool.A[274]; A_arbace_c2j_node_A_const_89 = A_arbace_c2j_node_A_const_pool.A[275]; A_arbace_c2j_node_A_const_90 = A_arbace_c2j_node_A_const_pool.A[276]; A_arbace_c2j_node_A_const_91 = A_arbace_c2j_node_A_const_pool.A[277]; A_arbace_c2j_node_A_const_92 = A_arbace_c2j_node_A_const_pool.A[278]; A_arbace_c2j_node_A_const_93 = A_arbace_c2j_node_A_const_pool.A[279]; A_arbace_c2j_node_A_const_94 = A_arbace_c2j_node_A_const_pool.A[280]; A_arbace_c2j_node_A_const_95 = A_arbace_c2j_node_A_const_pool.A[281]; A_arbace_c2j_node_A_const_96 = A_arbace_c2j_node_A_const_pool.A[282]; A_arbace_c2j_node_A_const_97 = A_arbace_c2j_node_A_const_pool.A[283]; A_arbace_c2j_node_A_const_98 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[284]); A_arbace_c2j_node_A_const_99 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[285]); A_arbace_c2j_node_A_const_100 = A_arbace_c2j_node_A_const_pool.A[286]; A_arbace_c2j_node_A_const_101 = A_arbace_c2j_node_A_const_pool.A[287]; A_arbace_c2j_node_A_const_102 = A_arbace_c2j_node_A_const_pool.A[288] }

func A_arbace_c2j_node_A_clinit_p8() { A_arbace_c2j_node_A_const_103 = A_arbace_c2j_node_A_const_pool.A[289]; A_arbace_c2j_node_A_const_104 = A_arbace_c2j_node_A_const_pool.A[290]; A_arbace_c2j_node_A_const_105 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[291]); A_arbace_c2j_node_A_const_106 = A_arbace_c2j_node_A_const_pool.A[292]; A_arbace_c2j_node_A_const_107 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[293]); A_arbace_c2j_node_A_const_108 = A_arbace_c2j_node_A_const_pool.A[294]; A_arbace_c2j_node_A_const_109 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[295]); A_arbace_c2j_node_A_const_110 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[296]); A_arbace_c2j_node_A_const_111 = A_arbace_c2j_node_A_const_pool.A[297]; A_arbace_c2j_node_A_const_112 = A_arbace_c2j_node_A_const_pool.A[298]; A_arbace_c2j_node_A_const_113 = A_arbace_c2j_node_A_const_pool.A[299]; A_arbace_c2j_node_A_const_114 = A_arbace_c2j_node_A_const_pool.A[300]; A_arbace_c2j_node_A_const_115 = A_arbace_c2j_node_A_const_pool.A[301]; A_arbace_c2j_node_A_const_116 = A_arbace_c2j_node_A_const_pool.A[302] }

func A_arbace_c2j_node_A_clinit_p9() { A_arbace_c2j_node_A_const_117 = A_arbace_c2j_node_A_const_pool.A[303]; A_arbace_c2j_node_A_const_118 = A_arbace_c2j_node_A_const_pool.A[304]; A_arbace_c2j_node_A_const_119 = A_arbace_c2j_node_A_const_pool.A[305]; A_arbace_c2j_node_A_const_120 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[306]); A_arbace_c2j_node_A_const_121 = A_arbace_c2j_node_A_const_pool.A[307]; A_arbace_c2j_node_A_const_122 = A_arbace_c2j_node_A_const_pool.A[308]; A_arbace_c2j_node_A_const_123 = A_arbace_c2j_node_A_const_pool.A[309]; A_arbace_c2j_node_A_const_124 = A_arbace_c2j_node_A_const_pool.A[310]; A_arbace_c2j_node_A_const_125 = A_arbace_c2j_node_A_const_pool.A[311]; A_arbace_c2j_node_A_const_126 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[312]); A_arbace_c2j_node_A_const_127 = A_arbace_c2j_node_A_const_pool.A[313]; A_arbace_c2j_node_A_const_128 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[314]); A_arbace_c2j_node_A_const_129 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[315]); A_arbace_c2j_node_A_const_130 = A_arbace_c2j_node_A_const_pool.A[316] }

func A_arbace_c2j_node_A_clinit_p10() { A_arbace_c2j_node_A_const_131 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[317]); A_arbace_c2j_node_A_const_132 = A_arbace_c2j_node_A_const_pool.A[318]; A_arbace_c2j_node_A_const_133 = A_arbace_c2j_node_A_const_pool.A[319]; A_arbace_c2j_node_A_const_134 = A_arbace_c2j_node_A_const_pool.A[320]; A_arbace_c2j_node_A_const_135 = A_arbace_c2j_node_A_const_pool.A[321]; A_arbace_c2j_node_A_const_136 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[322]); A_arbace_c2j_node_A_const_137 = A_arbace_c2j_node_A_const_pool.A[323]; A_arbace_c2j_node_A_const_138 = A_arbace_c2j_node_A_const_pool.A[324]; A_arbace_c2j_node_A_const_139 = A_arbace_c2j_node_A_const_pool.A[325]; A_arbace_c2j_node_A_const_140 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[326]); A_arbace_c2j_node_A_const_141 = A_arbace_c2j_node_A_const_pool.A[327]; A_arbace_c2j_node_A_const_142 = A_arbace_c2j_node_A_const_pool.A[328]; A_arbace_c2j_node_A_const_143 = A_arbace_c2j_node_A_const_pool.A[329]; A_arbace_c2j_node_A_const_144 = A_arbace_c2j_node_A_const_pool.A[330]; A_arbace_c2j_node_A_const_145 = A_arbace_c2j_node_A_const_pool.A[331] }

func A_arbace_c2j_node_A_clinit_p11() { A_arbace_c2j_node_A_const_146 = A_arbace_c2j_node_A_const_pool.A[332]; A_arbace_c2j_node_A_const_147 = A_arbace_c2j_node_A_const_pool.A[333]; A_arbace_c2j_node_A_const_148 = A_arbace_c2j_node_A_const_pool.A[334]; A_arbace_c2j_node_A_const_149 = A_arbace_c2j_node_A_const_pool.A[335]; A_arbace_c2j_node_A_const_150 = A_arbace_c2j_node_A_const_pool.A[336]; A_arbace_c2j_node_A_const_151 = A_arbace_c2j_node_A_const_pool.A[337]; A_arbace_c2j_node_A_const_152 = A_arbace_c2j_node_A_const_pool.A[338]; A_arbace_c2j_node_A_const_153 = A_arbace_c2j_node_A_const_pool.A[339]; A_arbace_c2j_node_A_const_154 = A_arbace_c2j_node_A_const_pool.A[340]; A_arbace_c2j_node_A_const_155 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[341]); A_arbace_c2j_node_A_const_156 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[342]); A_arbace_c2j_node_A_const_157 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[343]); A_arbace_c2j_node_A_const_158 = A_arbace_c2j_node_A_const_pool.A[344]; A_arbace_c2j_node_A_const_159 = A_arbace_c2j_node_A_const_pool.A[345]; A_arbace_c2j_node_A_const_160 = A_arbace_c2j_node_A_const_pool.A[346] }

func A_arbace_c2j_node_A_clinit_p12() { A_arbace_c2j_node_A_const_161 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[347]); A_arbace_c2j_node_A_const_162 = A_arbace_c2j_node_A_const_pool.A[348]; A_arbace_c2j_node_A_const_163 = A_arbace_c2j_node_A_const_pool.A[349]; A_arbace_c2j_node_A_const_164 = A_arbace_c2j_node_A_const_pool.A[350]; A_arbace_c2j_node_A_const_165 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[351]); A_arbace_c2j_node_A_const_166 = A_arbace_c2j_node_A_const_pool.A[352]; A_arbace_c2j_node_A_const_167 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[353]); A_arbace_c2j_node_A_const_168 = A_arbace_c2j_node_A_const_pool.A[354]; A_arbace_c2j_node_A_const_169 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[355]); A_arbace_c2j_node_A_const_170 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[356]); A_arbace_c2j_node_A_const_171 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[357]); A_arbace_c2j_node_A_const_172 = A_arbace_c2j_node_A_const_pool.A[358]; A_arbace_c2j_node_A_const_173 = A_arbace_c2j_node_A_const_pool.A[359]; A_arbace_c2j_node_A_const_174 = A_arbace_c2j_node_A_const_pool.A[360] }

func A_arbace_c2j_node_A_clinit_p13() { A_arbace_c2j_node_A_const_175 = A_arbace_c2j_node_A_const_pool.A[361]; A_arbace_c2j_node_A_const_176 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[362]); A_arbace_c2j_node_A_const_177 = A_arbace_c2j_node_A_const_pool.A[363]; A_arbace_c2j_node_A_const_178 = A_arbace_c2j_node_A_const_pool.A[364]; A_arbace_c2j_node_A_const_179 = A_arbace_c2j_node_A_const_pool.A[365]; A_arbace_c2j_node_A_const_180 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[366]); A_arbace_c2j_node_A_const_181 = A_arbace_c2j_node_A_const_pool.A[367]; A_arbace_c2j_node_A_const_182 = A_arbace_c2j_node_A_const_pool.A[368]; A_arbace_c2j_node_A_const_183 = A_arbace_c2j_node_A_const_pool.A[369]; A_arbace_c2j_node_A_const_184 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[370]); A_arbace_c2j_node_A_const_185 = A_arbace_c2j_node_A_const_pool.A[371]; A_arbace_c2j_node_A_const_186 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[372]); A_arbace_c2j_node_A_const_187 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[373]); A_arbace_c2j_node_A_const_188 = A_arbace_c2j_node_A_const_pool.A[374] }

func A_arbace_c2j_node_A_clinit_p14() { A_arbace_c2j_node_A_const_189 = A_arbace_c2j_node_A_const_pool.A[375]; A_arbace_c2j_node_A_const_190 = A_arbace_c2j_node_A_const_pool.A[376]; A_arbace_c2j_node_A_const_191 = A_arbace_c2j_node_A_const_pool.A[377]; A_arbace_c2j_node_A_const_192 = A_arbace_c2j_node_A_const_pool.A[378]; A_arbace_c2j_node_A_const_193 = A_arbace_c2j_node_A_const_pool.A[379]; A_arbace_c2j_node_A_const_194 = A_arbace_c2j_node_A_const_pool.A[380]; A_arbace_c2j_node_A_const_195 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[381]); A_arbace_c2j_node_A_const_196 = A_arbace_c2j_node_A_const_pool.A[382]; A_arbace_c2j_node_A_const_197 = A_arbace_c2j_node_A_const_pool.A[383]; A_arbace_c2j_node_A_const_198 = A_arbace_c2j_node_A_const_pool.A[384]; A_arbace_c2j_node_A_const_199 = A_arbace_c2j_node_A_const_pool.A[385]; A_arbace_c2j_node_A_const_200 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[386]); A_arbace_c2j_node_A_const_201 = A_arbace_c2j_node_A_const_pool.A[387]; A_arbace_c2j_node_A_const_202 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[388]); A_arbace_c2j_node_A_const_203 = A_arbace_c2j_node_A_const_pool.A[389] }

func A_arbace_c2j_node_A_clinit_p15() { A_arbace_c2j_node_A_const_204 = A_arbace_c2j_node_A_const_pool.A[390]; A_arbace_c2j_node_A_const_205 = A_arbace_c2j_node_A_const_pool.A[391]; A_arbace_c2j_node_A_const_206 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[392]); A_arbace_c2j_node_A_const_207 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[393]); A_arbace_c2j_node_A_const_208 = A_arbace_c2j_node_A_const_pool.A[394]; A_arbace_c2j_node_A_const_209 = A_arbace_c2j_node_A_const_pool.A[395]; A_arbace_c2j_node_A_const_210 = A_arbace_c2j_node_A_const_pool.A[396]; A_arbace_c2j_node_A_const_211 = A_arbace_c2j_node_A_const_pool.A[397]; A_arbace_c2j_node_A_const_212 = A_arbace_c2j_node_A_const_pool.A[398]; A_arbace_c2j_node_A_const_213 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[399]); A_arbace_c2j_node_A_const_214 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[400]); A_arbace_c2j_node_A_const_215 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[401]); A_arbace_c2j_node_A_const_216 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[402]) }

func A_arbace_c2j_node_A_clinit_p16() { A_arbace_c2j_node_A_const_217 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[403]); A_arbace_c2j_node_A_const_218 = A_arbace_c2j_node_A_const_pool.A[404]; A_arbace_c2j_node_A_const_219 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[405]); A_arbace_c2j_node_A_const_220 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[406]); A_arbace_c2j_node_A_const_221 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[407]); A_arbace_c2j_node_A_const_222 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[408]); A_arbace_c2j_node_A_const_223 = A_arbace_c2j_node_A_const_pool.A[409]; A_arbace_c2j_node_A_const_224 = A_arbace_c2j_node_A_const_pool.A[410]; A_arbace_c2j_node_A_const_225 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[411]); A_arbace_c2j_node_A_const_226 = A_arbace_c2j_node_A_const_pool.A[412]; A_arbace_c2j_node_A_const_227 = A_arbace_c2j_node_A_const_pool.A[413]; A_arbace_c2j_node_A_const_228 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[414]); A_arbace_c2j_node_A_const_229 = A_arbace_c2j_node_A_const_pool.A[415] }

func A_arbace_c2j_node_A_clinit_p17() { A_arbace_c2j_node_A_const_230 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[416]); A_arbace_c2j_node_A_const_231 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[417]); A_arbace_c2j_node_A_const_232 = A_arbace_c2j_node_A_const_pool.A[418]; A_arbace_c2j_node_A_const_233 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[419]); A_arbace_c2j_node_A_const_234 = A_arbace_c2j_node_A_const_pool.A[420]; A_arbace_c2j_node_A_const_235 = A_arbace_c2j_node_A_const_pool.A[421]; A_arbace_c2j_node_A_const_236 = A_arbace_c2j_node_A_const_pool.A[422]; A_arbace_c2j_node_A_const_237 = A_arbace_c2j_node_A_const_pool.A[423]; A_arbace_c2j_node_A_const_238 = A_arbace_c2j_node_A_const_pool.A[424]; A_arbace_c2j_node_A_const_239 = A_arbace_c2j_node_A_const_pool.A[425]; A_arbace_c2j_node_A_const_240 = A_arbace_c2j_node_A_const_pool.A[426]; A_arbace_c2j_node_A_const_241 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[427]); A_arbace_c2j_node_A_const_242 = A_arbace_c2j_node_A_const_pool.A[428]; A_arbace_c2j_node_A_const_243 = A_arbace_c2j_node_A_const_pool.A[429] }

func A_arbace_c2j_node_A_clinit_p18() { A_arbace_c2j_node_A_const_244 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[430]); A_arbace_c2j_node_A_const_245 = A_arbace_c2j_node_A_const_pool.A[431]; A_arbace_c2j_node_A_const_246 = A_arbace_c2j_node_A_const_pool.A[432]; A_arbace_c2j_node_A_const_247 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[433]); A_arbace_c2j_node_A_const_248 = A_arbace_c2j_node_A_const_pool.A[434]; A_arbace_c2j_node_A_const_249 = A_arbace_c2j_node_A_const_pool.A[435]; A_arbace_c2j_node_A_const_250 = A_arbace_c2j_node_A_const_pool.A[436]; A_arbace_c2j_node_A_const_251 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[437]); A_arbace_c2j_node_A_const_252 = A_arbace_c2j_node_A_const_pool.A[438]; A_arbace_c2j_node_A_const_253 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[439]); A_arbace_c2j_node_A_const_254 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[440]); A_arbace_c2j_node_A_const_255 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[441]); A_arbace_c2j_node_A_const_256 = A_arbace_c2j_node_A_const_pool.A[442]; A_arbace_c2j_node_A_const_257 = A_arbace_c2j_node_A_const_pool.A[443] }

func A_arbace_c2j_node_A_clinit_p19() { A_arbace_c2j_node_A_const_258 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[444]); A_arbace_c2j_node_A_const_259 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[445]); A_arbace_c2j_node_A_const_260 = A_arbace_c2j_node_A_const_pool.A[446]; A_arbace_c2j_node_A_const_261 = A_arbace_c2j_node_A_const_pool.A[447]; A_arbace_c2j_node_A_const_262 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[448]); A_arbace_c2j_node_A_const_263 = A_arbace_c2j_node_A_const_pool.A[449]; A_arbace_c2j_node_A_const_264 = A_arbace_c2j_node_A_const_pool.A[450]; A_arbace_c2j_node_A_const_265 = A_arbace_c2j_node_A_const_pool.A[451]; A_arbace_c2j_node_A_const_266 = A_arbace_c2j_node_A_const_pool.A[452]; A_arbace_c2j_node_A_const_267 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[453]); A_arbace_c2j_node_A_const_268 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[454]); A_arbace_c2j_node_A_const_269 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[455]); A_arbace_c2j_node_A_const_270 = A_arbace_c2j_node_A_const_pool.A[456]; A_arbace_c2j_node_A_const_271 = A_arbace_c2j_node_A_const_pool.A[457] }

func A_arbace_c2j_node_A_clinit_p20() { A_arbace_c2j_node_A_const_272 = A_arbace_c2j_node_A_const_pool.A[458]; A_arbace_c2j_node_A_const_273 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[459]); A_arbace_c2j_node_A_const_274 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[460]); A_arbace_c2j_node_A_const_275 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[461]); A_arbace_c2j_node_A_const_276 = jrt.Class_Cast(A_arbace_c2j_node_A_const_pool.A[462]); A_arbace_c2j_node_A_const_277 = A_arbace_c2j_node_A_const_pool.A[463]; A_arbace_c2j_node_A_const_278 = A_arbace_c2j_node_A_const_pool.A[464]; A_arbace_c2j_node_A_const_279 = A_arbace_c2j_node_A_const_pool.A[465]; A_arbace_c2j_node_A_const_280 = A_arbace_c2j_node_A_const_pool.A[466]; A_arbace_c2j_node_A_const_281 = A_arbace_c2j_node_A_const_pool.A[467]; A_arbace_c2j_node_A_const_282 = A_arbace_c2j_node_A_const_pool.A[468]; A_arbace_c2j_node_A_const_283 = A_arbace_c2j_node_A_const_pool.A[469]; A_arbace_c2j_node_A_const_284 = A_arbace_c2j_node_A_const_pool.A[470]; A_arbace_c2j_node_A_const_285 = A_arbace_c2j_node_A_const_pool.A[471] }

func A_arbace_c2j_node_A_clinit_p21() { A_arbace_c2j_node_A_const_286 = A_arbace_c2j_node_A_const_pool.A[472]; A_arbace_c2j_node_A_const_287 = A_arbace_c2j_node_A_const_pool.A[473]; A_arbace_c2j_node_A_const_288 = A_arbace_c2j_node_A_const_pool.A[474]; A_arbace_c2j_node_A_const_289 = A_arbace_c2j_node_A_const_pool.A[475]; A_arbace_c2j_node_A_const_290 = A_arbace_c2j_node_A_const_pool.A[476]; A_arbace_c2j_node_A_const_291 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[477]); A_arbace_c2j_node_A_const_292 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[478]); A_arbace_c2j_node_A_const_293 = A_arbace_c2j_node_A_const_pool.A[479]; A_arbace_c2j_node_A_const_294 = A_arbace_c2j_node_A_const_pool.A[480]; A_arbace_c2j_node_A_const_295 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[481]); A_arbace_c2j_node_A_const_296 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[482]); A_arbace_c2j_node_A_const_297 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[483]); A_arbace_c2j_node_A_const_298 = A_arbace_c2j_node_A_const_pool.A[484]; A_arbace_c2j_node_A_const_299 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[485]) }

func A_arbace_c2j_node_A_clinit_p22() { A_arbace_c2j_node_A_const_300 = A_arbace_c2j_node_A_const_pool.A[486]; A_arbace_c2j_node_A_const_301 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[487]); A_arbace_c2j_node_A_const_302 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[488]); A_arbace_c2j_node_A_const_303 = A_arbace_c2j_node_A_const_pool.A[489]; A_arbace_c2j_node_A_const_304 = A_arbace_c2j_node_A_const_pool.A[490]; A_arbace_c2j_node_A_const_305 = A_arbace_c2j_node_A_const_pool.A[491]; A_arbace_c2j_node_A_const_306 = A_arbace_c2j_node_A_const_pool.A[492]; A_arbace_c2j_node_A_const_307 = A_arbace_c2j_node_A_const_pool.A[493]; A_arbace_c2j_node_A_const_308 = A_arbace_c2j_node_A_const_pool.A[494]; A_arbace_c2j_node_A_const_309 = A_arbace_c2j_node_A_const_pool.A[495]; A_arbace_c2j_node_A_const_310 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[496]); A_arbace_c2j_node_A_const_311 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[497]); A_arbace_c2j_node_A_const_312 = A_arbace_c2j_node_A_const_pool.A[498]; A_arbace_c2j_node_A_const_313 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[499]) }

func A_arbace_c2j_node_A_clinit_p23() { A_arbace_c2j_node_A_const_314 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[500]); A_arbace_c2j_node_A_const_315 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[501]); A_arbace_c2j_node_A_const_316 = A_arbace_c2j_node_A_const_pool.A[502]; A_arbace_c2j_node_A_const_317 = A_arbace_c2j_node_A_const_pool.A[503]; A_arbace_c2j_node_A_const_318 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[504]); A_arbace_c2j_node_A_const_319 = A_arbace_c2j_node_A_const_pool.A[505]; A_arbace_c2j_node_A_const_320 = A_arbace_c2j_node_A_const_pool.A[506]; A_arbace_c2j_node_A_const_321 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[507]); A_arbace_c2j_node_A_const_322 = A_arbace_c2j_node_A_const_pool.A[508]; A_arbace_c2j_node_A_const_323 = A_arbace_c2j_node_A_const_pool.A[509]; A_arbace_c2j_node_A_const_324 = A_arbace_c2j_node_A_const_pool.A[510]; A_arbace_c2j_node_A_const_325 = A_arbace_c2j_node_A_const_pool.A[511]; A_arbace_c2j_node_A_const_326 = A_arbace_c2j_node_A_const_pool.A[512]; A_arbace_c2j_node_A_const_327 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[513]) }

func A_arbace_c2j_node_A_clinit_p24() { A_arbace_c2j_node_A_const_328 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[514]); A_arbace_c2j_node_A_const_329 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[515]); A_arbace_c2j_node_A_const_330 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[516]); A_arbace_c2j_node_A_const_331 = A_arbace_c2j_node_A_const_pool.A[517]; A_arbace_c2j_node_A_const_332 = A_arbace_c2j_node_A_const_pool.A[518]; A_arbace_c2j_node_A_const_333 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[519]); A_arbace_c2j_node_A_const_334 = A_arbace_c2j_node_A_const_pool.A[520]; A_arbace_c2j_node_A_const_335 = A_arbace_c2j_node_A_const_pool.A[521]; A_arbace_c2j_node_A_const_336 = A_arbace_c2j_node_A_const_pool.A[522]; A_arbace_c2j_node_A_const_337 = A_arbace_c2j_node_A_const_pool.A[523]; A_arbace_c2j_node_A_const_338 = A_arbace_c2j_node_A_const_pool.A[524]; A_arbace_c2j_node_A_const_339 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[525]); A_arbace_c2j_node_A_const_340 = A_arbace_c2j_node_A_const_pool.A[526]; A_arbace_c2j_node_A_const_341 = A_arbace_c2j_node_A_const_pool.A[527] }

func A_arbace_c2j_node_A_clinit_p25() { A_arbace_c2j_node_A_const_342 = A_arbace_c2j_node_A_const_pool.A[528]; A_arbace_c2j_node_A_const_343 = A_arbace_c2j_node_A_const_pool.A[529]; A_arbace_c2j_node_A_const_344 = A_arbace_c2j_node_A_const_pool.A[530]; A_arbace_c2j_node_A_const_345 = A_arbace_c2j_node_A_const_pool.A[531]; A_arbace_c2j_node_A_const_346 = A_arbace_c2j_node_A_const_pool.A[532]; A_arbace_c2j_node_A_const_347 = A_arbace_c2j_node_A_const_pool.A[533]; A_arbace_c2j_node_A_const_348 = A_arbace_c2j_node_A_const_pool.A[534]; A_arbace_c2j_node_A_const_349 = A_arbace_c2j_node_A_const_pool.A[535]; A_arbace_c2j_node_A_const_350 = A_arbace_c2j_node_A_const_pool.A[536]; A_arbace_c2j_node_A_const_351 = A_arbace_c2j_node_A_const_pool.A[537]; A_arbace_c2j_node_A_const_352 = A_arbace_c2j_node_A_const_pool.A[538]; A_arbace_c2j_node_A_const_353 = A_arbace_c2j_node_A_const_pool.A[539]; A_arbace_c2j_node_A_const_354 = A_arbace_c2j_node_A_const_pool.A[540]; A_arbace_c2j_node_A_const_355 = A_arbace_c2j_node_A_const_pool.A[541]; A_arbace_c2j_node_A_const_356 = A_arbace_c2j_node_A_const_pool.A[542] }

func A_arbace_c2j_node_A_clinit_p26() { A_arbace_c2j_node_A_const_357 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[543]); A_arbace_c2j_node_A_const_358 = A_arbace_c2j_node_A_const_pool.A[544]; A_arbace_c2j_node_A_const_359 = A_arbace_c2j_node_A_const_pool.A[545]; A_arbace_c2j_node_A_const_360 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[546]); A_arbace_c2j_node_A_const_361 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[547]); A_arbace_c2j_node_A_const_362 = A_arbace_c2j_node_A_const_pool.A[548]; A_arbace_c2j_node_A_const_363 = A_arbace_c2j_node_A_const_pool.A[549]; A_arbace_c2j_node_A_const_364 = A_arbace_c2j_node_A_const_pool.A[550]; A_arbace_c2j_node_A_const_365 = A_arbace_c2j_node_A_const_pool.A[551]; A_arbace_c2j_node_A_const_366 = A_arbace_c2j_node_A_const_pool.A[552]; A_arbace_c2j_node_A_const_367 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[553]); A_arbace_c2j_node_A_const_368 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[554]); A_arbace_c2j_node_A_const_369 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[555]) }

func A_arbace_c2j_node_A_clinit_p27() { A_arbace_c2j_node_A_const_370 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[556]); A_arbace_c2j_node_A_const_371 = A_arbace_c2j_node_A_const_pool.A[557]; A_arbace_c2j_node_A_const_372 = A_arbace_c2j_node_A_const_pool.A[558]; A_arbace_c2j_node_A_const_373 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[559]); A_arbace_c2j_node_A_const_374 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[560]); A_arbace_c2j_node_A_const_375 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[561]); A_arbace_c2j_node_A_const_376 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[562]); A_arbace_c2j_node_A_const_377 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[563]); A_arbace_c2j_node_A_const_378 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[564]); A_arbace_c2j_node_A_const_379 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[565]); A_arbace_c2j_node_A_const_380 = A_arbace_c2j_node_A_const_pool.A[566]; A_arbace_c2j_node_A_const_381 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[567]); A_arbace_c2j_node_A_const_382 = A_arbace_c2j_node_A_const_pool.A[568] }

func A_arbace_c2j_node_A_clinit_p28() { A_arbace_c2j_node_A_const_383 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[569]); A_arbace_c2j_node_A_const_384 = A_arbace_c2j_node_A_const_pool.A[570]; A_arbace_c2j_node_A_const_385 = A_arbace_c2j_node_A_const_pool.A[571]; A_arbace_c2j_node_A_const_386 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[572]); A_arbace_c2j_node_A_const_387 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[573]); A_arbace_c2j_node_A_const_388 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[574]); A_arbace_c2j_node_A_const_389 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[575]); A_arbace_c2j_node_A_const_390 = A_arbace_c2j_node_A_const_pool.A[576]; A_arbace_c2j_node_A_const_391 = A_arbace_c2j_node_A_const_pool.A[577]; A_arbace_c2j_node_A_const_392 = A_arbace_c2j_node_A_const_pool.A[578]; A_arbace_c2j_node_A_const_393 = A_arbace_c2j_node_A_const_pool.A[579]; A_arbace_c2j_node_A_const_394 = A_arbace_c2j_node_A_const_pool.A[580]; A_arbace_c2j_node_A_const_395 = A_arbace_c2j_node_A_const_pool.A[581]; A_arbace_c2j_node_A_const_396 = A_arbace_c2j_node_A_const_pool.A[582] }

func A_arbace_c2j_node_A_clinit_p29() { A_arbace_c2j_node_A_const_397 = A_arbace_c2j_node_A_const_pool.A[583]; A_arbace_c2j_node_A_const_398 = A_arbace_c2j_node_A_const_pool.A[584]; A_arbace_c2j_node_A_const_399 = A_arbace_c2j_node_A_const_pool.A[585]; A_arbace_c2j_node_A_const_400 = A_arbace_c2j_node_A_const_pool.A[586]; A_arbace_c2j_node_A_const_401 = A_arbace_c2j_node_A_const_pool.A[587]; A_arbace_c2j_node_A_const_402 = A_arbace_c2j_node_A_const_pool.A[588]; A_arbace_c2j_node_A_const_403 = A_arbace_c2j_node_A_const_pool.A[589]; A_arbace_c2j_node_A_const_404 = A_arbace_c2j_node_A_const_pool.A[590]; A_arbace_c2j_node_A_const_405 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[591]); A_arbace_c2j_node_A_const_406 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[592]); A_arbace_c2j_node_A_const_407 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[593]); A_arbace_c2j_node_A_const_408 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[594]); A_arbace_c2j_node_A_const_409 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[595]); A_arbace_c2j_node_A_const_410 = A_arbace_c2j_node_A_const_pool.A[596] }

func A_arbace_c2j_node_A_clinit_p30() { A_arbace_c2j_node_A_const_411 = A_arbace_c2j_node_A_const_pool.A[597]; A_arbace_c2j_node_A_const_412 = A_arbace_c2j_node_A_const_pool.A[598]; A_arbace_c2j_node_A_const_413 = A_arbace_c2j_node_A_const_pool.A[599]; A_arbace_c2j_node_A_const_414 = A_arbace_c2j_node_A_const_pool.A[600]; A_arbace_c2j_node_A_const_415 = A_arbace_c2j_node_A_const_pool.A[601]; A_arbace_c2j_node_A_const_416 = A_arbace_c2j_node_A_const_pool.A[602]; A_arbace_c2j_node_A_const_417 = A_arbace_c2j_node_A_const_pool.A[603]; A_arbace_c2j_node_A_const_418 = A_arbace_c2j_node_A_const_pool.A[604]; A_arbace_c2j_node_A_const_419 = A_arbace_c2j_node_A_const_pool.A[605]; A_arbace_c2j_node_A_const_420 = A_arbace_c2j_node_A_const_pool.A[606]; A_arbace_c2j_node_A_const_421 = A_arbace_c2j_node_A_const_pool.A[607]; A_arbace_c2j_node_A_const_422 = A_arbace_c2j_node_A_const_pool.A[608]; A_arbace_c2j_node_A_const_423 = A_arbace_c2j_node_A_const_pool.A[609]; A_arbace_c2j_node_A_const_424 = A_arbace_c2j_node_A_const_pool.A[610]; A_arbace_c2j_node_A_const_425 = A_arbace_c2j_node_A_const_pool.A[611]; A_arbace_c2j_node_A_const_426 = A_arbace_c2j_node_A_const_pool.A[612] }

func A_arbace_c2j_node_A_clinit_p31() { A_arbace_c2j_node_A_const_427 = A_arbace_c2j_node_A_const_pool.A[613]; A_arbace_c2j_node_A_const_428 = A_arbace_c2j_node_A_const_pool.A[614]; A_arbace_c2j_node_A_const_429 = A_arbace_c2j_node_A_const_pool.A[615]; A_arbace_c2j_node_A_const_430 = A_arbace_c2j_node_A_const_pool.A[616]; A_arbace_c2j_node_A_const_431 = A_arbace_c2j_node_A_const_pool.A[617]; A_arbace_c2j_node_A_const_432 = A_arbace_c2j_node_A_const_pool.A[618]; A_arbace_c2j_node_A_const_433 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[619]); A_arbace_c2j_node_A_const_434 = A_arbace_c2j_node_A_const_pool.A[620]; A_arbace_c2j_node_A_const_435 = A_arbace_c2j_node_A_const_pool.A[621]; A_arbace_c2j_node_A_const_436 = A_arbace_c2j_node_A_const_pool.A[622]; A_arbace_c2j_node_A_const_437 = A_arbace_c2j_node_A_const_pool.A[623]; A_arbace_c2j_node_A_const_438 = A_arbace_c2j_node_A_const_pool.A[624]; A_arbace_c2j_node_A_const_439 = A_arbace_c2j_node_A_const_pool.A[625]; A_arbace_c2j_node_A_const_440 = A_arbace_c2j_node_A_const_pool.A[626]; A_arbace_c2j_node_A_const_441 = A_arbace_c2j_node_A_const_pool.A[627] }

func A_arbace_c2j_node_A_clinit_p32() { A_arbace_c2j_node_A_const_442 = A_arbace_c2j_node_A_const_pool.A[628]; A_arbace_c2j_node_A_const_443 = A_arbace_c2j_node_A_const_pool.A[629]; A_arbace_c2j_node_A_const_444 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[630]); A_arbace_c2j_node_A_const_445 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[631]); A_arbace_c2j_node_A_const_446 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[632]); A_arbace_c2j_node_A_const_447 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[633]); A_arbace_c2j_node_A_const_448 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[634]); A_arbace_c2j_node_A_const_449 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[635]); A_arbace_c2j_node_A_const_450 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[636]); A_arbace_c2j_node_A_const_451 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[637]); A_arbace_c2j_node_A_const_452 = A_arbace_c2j_node_A_const_pool.A[638]; A_arbace_c2j_node_A_const_453 = A_arbace_c2j_node_A_const_pool.A[639]; A_arbace_c2j_node_A_const_454 = A_arbace_c2j_node_A_const_pool.A[640] }

func A_arbace_c2j_node_A_clinit_p33() { A_arbace_c2j_node_A_const_455 = A_arbace_c2j_node_A_const_pool.A[641]; A_arbace_c2j_node_A_const_456 = A_arbace_c2j_node_A_const_pool.A[642]; A_arbace_c2j_node_A_const_457 = A_arbace_c2j_node_A_const_pool.A[643]; A_arbace_c2j_node_A_const_458 = A_arbace_c2j_node_A_const_pool.A[644]; A_arbace_c2j_node_A_const_459 = A_arbace_c2j_node_A_const_pool.A[645]; A_arbace_c2j_node_A_const_460 = A_arbace_c2j_node_A_const_pool.A[646]; A_arbace_c2j_node_A_const_461 = A_arbace_c2j_node_A_const_pool.A[647]; A_arbace_c2j_node_A_const_462 = A_arbace_c2j_node_A_const_pool.A[648]; A_arbace_c2j_node_A_const_463 = A_arbace_c2j_node_A_const_pool.A[649]; A_arbace_c2j_node_A_const_464 = A_arbace_c2j_node_A_const_pool.A[650]; A_arbace_c2j_node_A_const_465 = A_arbace_c2j_node_A_const_pool.A[651]; A_arbace_c2j_node_A_const_466 = A_arbace_c2j_node_A_const_pool.A[652]; A_arbace_c2j_node_A_const_467 = A_arbace_c2j_node_A_const_pool.A[653]; A_arbace_c2j_node_A_const_468 = A_arbace_c2j_node_A_const_pool.A[654]; A_arbace_c2j_node_A_const_469 = A_arbace_c2j_node_A_const_pool.A[655]; A_arbace_c2j_node_A_const_470 = A_arbace_c2j_node_A_const_pool.A[656] }

func A_arbace_c2j_node_A_clinit_p34() { A_arbace_c2j_node_A_const_471 = A_arbace_c2j_node_A_const_pool.A[657]; A_arbace_c2j_node_A_const_472 = A_arbace_c2j_node_A_const_pool.A[658]; A_arbace_c2j_node_A_const_473 = A_arbace_c2j_node_A_const_pool.A[659]; A_arbace_c2j_node_A_const_474 = A_arbace_c2j_node_A_const_pool.A[660] }

func A_arbace_c2j_node_A_New() *A_arbace_c2j_node_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_node_A) Ctor() {}

func (t *A_arbace_c2j_node_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_node_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_node_A_class }

func (t *A_arbace_c2j_node_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_node_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_node_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_node_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_node_A); return ok }

func A_arbace_c2j_node_A_Cast(x any) *A_arbace_c2j_node_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_node_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_node_A_class)) }; return v }



type A_arbace_c2j_node_arg_kind_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_arg_kind_A_fn_class *jrt.Class



type A_arbace_c2j_node_camel_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_camel_A_fn_class *jrt.Class



type A_arbace_c2j_node_children_bind_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_children_bind_A_fn_class *jrt.Class



type A_arbace_c2j_node_children_bind_fn__400000028_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_children_bind_fn__400000028_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_construct__400000385_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_construct__400000385_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000377_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_fn__400000377_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000379_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_fn__400000379_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000381_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_fn__400000381_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000399_A struct{ j2g_header uint64; F_pick any }

var A_arbace_c2j_node_clause_fn__400000399_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000405_A struct{ j2g_header uint64; F_pick any }

var A_arbace_c2j_node_clause_fn__400000405_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_pick__400000390_A struct{ j2g_header uint64; F_construct, F_ss any }

var A_arbace_c2j_node_clause_pick__400000390_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_pick__400000390_go__400000391_A struct{ j2g_header uint64; F_construct any }

var A_arbace_c2j_node_clause_pick__400000390_go__400000391_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000392_A struct{ j2g_header uint64; F_s any }

var A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000392_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000394_A struct{ j2g_header uint64; F_s any }

var A_arbace_c2j_node_clause_pick__400000390_go__400000391_fn__400000394_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_fn__400000432_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_fn__400000432_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_fn__400000504_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_fn__400000504_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000411__400000415_A struct{ j2g_header uint64; F_helpers, F_domains any }

var A_arbace_c2j_node_code_forms_iter__400000411__400000415_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_A struct{ j2g_header uint64; F_iter__400000411, F_helpers, F_s__400000412, F_domains any }

var A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_A struct{ j2g_header uint64; F_helpers, F_domains, F_b__400000414 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_fn__400000418_A struct{ j2g_header uint64; F_d, F_helpers any }

var A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000417_fn__400000418_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000424_A struct{ j2g_header uint64; F_d, F_helpers any }

var A_arbace_c2j_node_code_forms_iter__400000411__400000415_fn__400000416_fn__400000424_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000436__400000444_A struct{ j2g_header uint64; F_domains, F_keys any }

var A_arbace_c2j_node_code_forms_iter__400000436__400000444_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_A struct{ j2g_header uint64; F_iter__400000436, F_s__400000437, F_domains, F_keys any }

var A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_A struct{ j2g_header uint64; F_keys, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_A struct{ j2g_header uint64; F_iter__400000438, F_s__400000439, F_keys, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_A struct{ j2g_header uint64; F_k, F_keys, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_A struct{ j2g_header uint64; F_s__400000441, F_k, F_keys, F_iter__400000440, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_fn__400000455_A struct{ j2g_header uint64; F_k, F_b__400000443, F_keys any; F_size__1927001038__auto__ int32; F_d, F_c__1927001037__auto__ any }

var A_arbace_c2j_node_code_forms_iter__400000436__400000444_fn__400000445_iter__400000438__400000448_fn__400000449_iter__400000440__400000453_fn__400000454_fn__400000455_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000469__400000475_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_iter__400000469__400000475_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_A struct{ j2g_header uint64; F_iter__400000469, F_s__400000470 any }

var A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_A struct{ j2g_header uint64; F_d any }

var A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_A struct{ j2g_header uint64; F_iter__400000471, F_d, F_s__400000472 any }

var A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_A struct{ j2g_header uint64; F_b__400000474 any; F_size__1927001038__auto__ int32; F_d, F_c__1927001037__auto__ any }

var A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_fn__400000485_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000481_fn__400000485_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000494_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_iter__400000469__400000475_fn__400000476_iter__400000471__400000479_fn__400000480_fn__400000494_A_fn_class *jrt.Class



type A_arbace_c2j_node_defnode_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_defnode_A_fn_class *jrt.Class



type A_arbace_c2j_node_emit_fn_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_emit_fn_A_fn_class *jrt.Class



type A_arbace_c2j_node_emit_fn_fn__400000154_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_emit_fn_fn__400000154_A_fn_class *jrt.Class



type A_arbace_c2j_node_emit_fn_fn__400000158_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_emit_fn_fn__400000158_A_fn_class *jrt.Class



type A_arbace_c2j_node_emit_fn_fn__400000166_A struct{ j2g_header uint64; F_env0 any }

var A_arbace_c2j_node_emit_fn_fn__400000166_A_fn_class *jrt.Class



type A_arbace_c2j_node_eval400000004_A struct{ jrt.Object }

func A_arbace_c2j_node_eval400000004_A_New() *A_arbace_c2j_node_eval400000004_A { t := &A_arbace_c2j_node_eval400000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_node_eval400000004_A) Ctor() {}

func (t *A_arbace_c2j_node_eval400000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_node_eval400000004_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_node_eval400000004_A_class }

func (t *A_arbace_c2j_node_eval400000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_node_eval400000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_node_eval400000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_node_eval400000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_node_eval400000004_A); return ok }

func A_arbace_c2j_node_eval400000004_A_Cast(x any) *A_arbace_c2j_node_eval400000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_node_eval400000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_node_eval400000004_A_class)) }; return v }



type A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A_fn_class *jrt.Class



type A_arbace_c2j_node_eval400000008_A struct{ jrt.Object }

func A_arbace_c2j_node_eval400000008_A_New() *A_arbace_c2j_node_eval400000008_A { t := &A_arbace_c2j_node_eval400000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_node_eval400000008_A) Ctor() {}

func (t *A_arbace_c2j_node_eval400000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_node_eval400000008_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_node_eval400000008_A_class }

func (t *A_arbace_c2j_node_eval400000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_node_eval400000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_node_eval400000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_node_eval400000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_node_eval400000008_A); return ok }

func A_arbace_c2j_node_eval400000008_A_Cast(x any) *A_arbace_c2j_node_eval400000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_node_eval400000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_node_eval400000008_A_class)) }; return v }



type A_arbace_c2j_node_eval400000008_fn__400000009_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_eval400000008_fn__400000009_A_fn_class *jrt.Class



type A_arbace_c2j_node_field_names_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_field_names_A_fn_class *jrt.Class



type A_arbace_c2j_node_field_names_fn__400000024_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_field_names_fn__400000024_A_fn_class *jrt.Class



type A_arbace_c2j_node_head_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_head_A_fn_class *jrt.Class



type A_arbace_c2j_node_invalid_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_invalid_A_fn_class *jrt.Class



type A_arbace_c2j_node_parse_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_parse_A_fn_class *jrt.Class



type A_arbace_c2j_node_parse_fn__400000018_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_parse_fn__400000018_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_body_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_body_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_body_fn__400000056_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_body_fn__400000056_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_drop_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_drop_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_node_q_elems_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_elems_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_elems_fn__400000048_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_elems_fn__400000048_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_elems_fn__400000051_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_elems_fn__400000051_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_seq_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_fn__400000084_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_seq_fn__400000084_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_fn__400000110_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_seq_fn__400000110_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_fn__400000129_A struct{ j2g_header uint64; F_fresh any }

var A_arbace_c2j_node_q_seq_fn__400000129_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_fn__400000137_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_seq_fn__400000137_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qe_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_elems_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qe_elems_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_elems_fn__400000178_A struct{ j2g_header uint64; F_env, F_v any }

var A_arbace_c2j_node_qe_elems_fn__400000178_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qe_seq_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000193_A struct{ j2g_header uint64; F_b any }

var A_arbace_c2j_node_qe_seq_fn__400000193_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000195_A struct{ j2g_header uint64; F_env, F_v any }

var A_arbace_c2j_node_qe_seq_fn__400000195_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000216_A struct{ j2g_header uint64; F_g any }

var A_arbace_c2j_node_qe_seq_fn__400000216_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000228_A struct{ j2g_header uint64; F_tmp, F_v any }

var A_arbace_c2j_node_qe_seq_fn__400000228_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000228_fn__400000235_A struct{ j2g_header uint64; F_tmp any }

var A_arbace_c2j_node_qe_seq_fn__400000228_fn__400000235_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000238_A struct{ j2g_header uint64; F_v, F_env any }

var A_arbace_c2j_node_qe_seq_fn__400000238_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000247_A struct{ j2g_header uint64; F_env, F_v any }

var A_arbace_c2j_node_qe_seq_fn__400000247_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000252_A struct{ j2g_header uint64; F_env, F_v any }

var A_arbace_c2j_node_qe_seq_fn__400000252_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000257_A struct{ j2g_header uint64; F_ts, F_b any }

var A_arbace_c2j_node_qe_seq_fn__400000257_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_h_STAR___400000187_A struct{ j2g_header uint64; F_env, F_t, F_v any }

var A_arbace_c2j_node_qe_seq_h_STAR___400000187_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_tmp__400000224_A struct{ j2g_header uint64; F_n any }

var A_arbace_c2j_node_qe_seq_tmp__400000224_A_fn_class *jrt.Class



type A_arbace_c2j_node_qs_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qs_A_fn_class *jrt.Class



type A_arbace_c2j_node_qs_fn__400000060_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qs_fn__400000060_A_fn_class *jrt.Class



type A_arbace_c2j_node_realize_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_realize_A_fn_class *jrt.Class



type A_arbace_c2j_node_register_BANG__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_register_BANG__A_fn_class *jrt.Class



type A_arbace_c2j_node_register_BANG__fn__400000012_A struct{ j2g_header uint64; F_d any }

var A_arbace_c2j_node_register_BANG__fn__400000012_A_fn_class *jrt.Class



type A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A struct{ j2g_header uint64; F_d any }

var A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_fn_class *jrt.Class



type A_arbace_c2j_node_ret_chans_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_ret_chans_A_fn_class *jrt.Class



type A_arbace_c2j_node_runs_children_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_runs_children_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_node_splits_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_splits_A_fn_class *jrt.Class



type A_arbace_c2j_node_splits_fn__400000265_A struct{ j2g_header uint64; F_tested any }

var A_arbace_c2j_node_splits_fn__400000265_A_fn_class *jrt.Class



type A_arbace_c2j_node_splits_w__400000263_A struct{ j2g_header uint64; F_tested any }

var A_arbace_c2j_node_splits_w__400000263_A_fn_class *jrt.Class



type A_arbace_c2j_node_sym_occurs_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_node_sym_occurs_QMARK__fn__400000273_A struct{ j2g_header uint64; F_s any }

var A_arbace_c2j_node_sym_occurs_QMARK__fn__400000273_A_fn_class *jrt.Class



type A_arbace_c2j_node_tag_sym_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_tag_sym_A_fn_class *jrt.Class



type A_arbace_c2j_node_uses_many_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_uses_many_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_node_uses_many_QMARK__w__400000268_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_node_uses_many_QMARK__w__400000268_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_bare__400000300_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_bare__400000300_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000277_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_fn__400000277_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000293_A struct{ j2g_header uint64; F_conv, F_methods, F_v any }

var A_arbace_c2j_node_variant_class_fn__400000293_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000293_fn__400000295_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_fn__400000293_fn__400000295_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000293_fn__400000297_A struct{ j2g_header uint64; F_b, F_conv, F_fld any }

var A_arbace_c2j_node_variant_class_fn__400000293_fn__400000297_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000303_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_fn__400000303_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000308_A struct{ j2g_header uint64; F_bare any }

var A_arbace_c2j_node_variant_class_fn__400000308_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_method__400000280_A struct{ j2g_header uint64; F_d, F_env, F_v, F_domain any }

var A_arbace_c2j_node_variant_class_method__400000280_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_method__400000280_fn__400000287_A struct{ j2g_header uint64; F_c, F_try_qe, F_v any }

var A_arbace_c2j_node_variant_class_method__400000280_fn__400000287_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_method__400000280_try_qe__400000284_A struct{ j2g_header uint64; F_d, F_env any }

var A_arbace_c2j_node_variant_class_method__400000280_try_qe__400000284_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variants_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000314_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variants_fn__400000314_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_A struct{ j2g_header uint64; F_s any }

var A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_A struct{ j2g_header uint64; F_iter__400000315, F_s__400000316, F_s any }

var A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_A struct{ j2g_header uint64; F_m, F_s any }

var A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_A struct{ j2g_header uint64; F_iter__400000317, F_m, F_s__400000318, F_s any }

var A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_fn__400000325_A struct{ j2g_header uint64; F_m, F_b__400000320, F_s any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_node_variants_fn__400000314_iter__400000315__400000321_fn__400000322_iter__400000317__400000323_fn__400000324_fn__400000325_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000332_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variants_fn__400000332_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000334__400000340_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variants_iter__400000334__400000340_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_A struct{ j2g_header uint64; F_iter__400000334, F_s__400000335 any }

var A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_A struct{ j2g_header uint64; F_k, F_p any }

var A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_A struct{ j2g_header uint64; F_iter__400000336, F_k, F_s__400000337, F_p any }

var A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_fn__400000347_A struct{ j2g_header uint64; F_k, F_p, F_b__400000339 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_node_variants_iter__400000334__400000340_fn__400000341_iter__400000336__400000345_fn__400000346_fn__400000347_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000353__400000359_A struct{ j2g_header uint64; F_base, F_split_sets, F_dom, F_ss any }

var A_arbace_c2j_node_variants_iter__400000353__400000359_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_A struct{ j2g_header uint64; F_s__400000354, F_base, F_split_sets, F_dom, F_ss, F_iter__400000353 any }

var A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_A struct{ j2g_header uint64; F_base, F_dom, F_ss, F_c any }

var A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_A struct{ j2g_header uint64; F_s__400000356, F_base, F_dom, F_ss, F_c, F_iter__400000355 any }

var A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_A struct{ j2g_header uint64; F_base, F_b__400000358, F_dom any; F_size__1927001038__auto__ int32; F_ss, F_c__1927001037__auto__, F_c any }

var A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_fn__400000364_A struct{ j2g_header uint64; F_sp any }

var A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000363_fn__400000364_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000367_A struct{ j2g_header uint64; F_sp any }

var A_arbace_c2j_node_variants_iter__400000353__400000359_fn__400000360_iter__400000355__400000361_fn__400000362_fn__400000367_A_fn_class *jrt.Class



type A_arbace_c2j_node_walk_syms_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_walk_syms_A_fn_class *jrt.Class



type A_arbace_c2j_node_walk_syms_fn__400000033_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_node_walk_syms_fn__400000033_A_fn_class *jrt.Class



type A_arbace_c2j_node_walk_syms_fn__400000035_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_node_walk_syms_fn__400000035_A_fn_class *jrt.Class



type A_arbace_c2j_node_walk_syms_fn__400000038_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_node_walk_syms_fn__400000038_A_fn_class *jrt.Class
