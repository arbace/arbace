//line aot_arbace_c2j_node.ae:1
package aot_arbace_c2j_node

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A_New() *A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c2j_node_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_3); tmp2 = lang.IFn_Cast(A_arbace_c2j_node_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_c2j_node_eval400000008_fn__400000009_A_New() *A_arbace_c2j_node_eval400000008_fn__400000009_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_eval400000008_fn__400000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2j_node_eval400000008_fn__400000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2j_node_eval400000008_fn__400000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_c2j_node_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_c2j_node_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_c2j_node_A_const_7.GetRawRoot__O(), A_arbace_c2j_node_A_const_8) }























































func A_arbace_c2j_node_register_BANG__A_New() *A_arbace_c2j_node_register_BANG__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_register_BANG__A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_c2j_node_register_BANG__A) Ctor() {}
//line :57:1
func (t *A_arbace_c2j_node_register_BANG__A) Invoke_O_O__O(self, d__0 any) any {


	var root_19 any = A_arbace_c2j_node_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_c2j_node_A_const_10.GetRawRoot__O(); var arg_23 any; var fnbody__47 any = A_arbace_c2j_node_register_BANG__fn__400000012_A_New_O(d__0); var tmp1 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_c2j_node_register_BANG__fn__400000012_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, fnbody__47); A_arbace_c2j_node_register_BANG__fn__400000012_A_fn_class = fncls__46d; tmp1 = fncls__46d } else { tmp1 = fncls__46 }; arg_23 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__47, tmp1, nil); if linked_20 == nil { return ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { return linked_20.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_19, arg_22, arg_23) } }
//line :60:1
func A_arbace_c2j_node_register_BANG__fn__400000012_A_New_O(p0 any) *A_arbace_c2j_node_register_BANG__fn__400000012_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_register_BANG__fn__400000012_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_c2j_node_register_BANG__fn__400000012_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :60:1
func (t *A_arbace_c2j_node_register_BANG__fn__400000012_A) Invoke_O_O__O(self, ds__1 any) any { var i__2 any; var root_24 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var root_28 any = A_arbace_c2j_node_A_const_12.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_keep_indexed_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any; var fnbody__34 any = A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_New_O(t.F_d); var tmp1 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, fnbody__34); A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_fn_class = fncls__33d; tmp1 = fncls__33d } else { tmp1 = fncls__33 }; arg_31 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp1, nil); var arg_32 any = ds__1; if linked_29 == nil { arg_27 = ifn_30.Invoke_O_O__O(arg_31, arg_32) } else { arg_27 = linked_29.(*aot_arbace_core.A_arbace_core_keep_indexed_A).Invoke_O_O_O__O(root_28, arg_31, arg_32) }; if linked_25 == nil { i__2 = ifn_26.Invoke_O__O(arg_27) } else { i__2 = linked_25.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_24, arg_27) }; if
												jrt.J2g_Truth(i__2) { var root_35 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_36 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_35, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_37 lang.IFn; if linked_36 == nil { ifn_37 = lang.IFn_Cast(root_35) } else { ifn_37 = nil }; var arg_38 any = ds__1; var arg_39 any = i__2; var arg_40 any = t.F_d; if linked_36 == nil { return ifn_37.Invoke_O_O_O__O(arg_38, arg_39, arg_40) } else { return linked_36.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_35, arg_38, arg_39, arg_40) } } else { var root_41 any = A_arbace_c2j_node_A_const_7.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = ds__1; var arg_45 any = t.F_d; if linked_42 == nil { return ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { return linked_42.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_41, arg_44, arg_45) } } }
//line :60:1
func A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_New_O(p0 any) *A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A{}; t.Ctor_O(p0); return t }
//line :60:1
func (t *A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :60:1
func (t *A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A) Invoke_O_O_O__O(self, i__1, x__2 any) any { if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_c2j_node_A_const_13.Invoke_O__O(x__2), A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d)) { return i__1 } else { return nil } }


func A_arbace_c2j_node_parse_A_New() *A_arbace_c2j_node_parse_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_parse_A{}; t.Ctor(); return t }
//line :63:1
func (t *A_arbace_c2j_node_parse_A) Ctor() {}
//line :63:1
func (t *A_arbace_c2j_node_parse_A) Invoke_O_O_O_O_O_O__O(self, kind__0, doc__1, opts__2, bindings__3, template__4 any) any { var tmp1 any = A_arbace_c2j_node_A_const_13; var tmp2 any = A_arbace_c2j_node_A_const_15; var tmp3 any = A_arbace_c2j_node_A_const_16; var tmp4 any = A_arbace_c2j_node_A_const_17; var tmp5 any; var root_48 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_50 lang.IFn; if



	linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any; var fnbody__66 any = A_arbace_c2j_node_parse_fn__400000018_A_New(); var tmp6 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_c2j_node_parse_fn__400000018_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); A_arbace_c2j_node_parse_fn__400000018_A_fn_class = fncls__65d; tmp6 = fncls__65d } else { tmp6 = fncls__65 }; arg_51 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp6, nil); var arg_52 any; var root_67 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = A_arbace_c2j_node_A_const_25; var arg_71 any = bindings__3; if linked_68 == nil { arg_52 = ifn_69.Invoke_O_O__O(arg_70, arg_71) } else { arg_52 = linked_68.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_67, arg_70, arg_71) }; if linked_49 == nil { tmp5 = ifn_50.Invoke_O_O__O(arg_51, arg_52) } else { tmp5 = linked_49.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_48, arg_51, arg_52) }; return /*line :63:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, kind__0, tmp2, doc__1, tmp3, opts__2, tmp4, tmp5, A_arbace_c2j_node_A_const_26, template__4)) }



func A_arbace_c2j_node_parse_fn__400000018_A_New() *A_arbace_c2j_node_parse_fn__400000018_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_parse_fn__400000018_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_c2j_node_parse_fn__400000018_A) Ctor() {}
//line :67:1
func (t *A_arbace_c2j_node_parse_fn__400000018_A) Invoke_O_O__O(self, p__400000017__1 any) any { var vec__400000019__2 any = p__400000017__1; var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000019__2, lang.RT_IntCast_J__I_NoInit(0), nil); var spec__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000019__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any = A_arbace_c2j_node_A_const_19; var tmp2 any = A_arbace_c2j_node_A_const_20; var tmp3 any; var root_53 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = spec__4; if linked_54 == nil { tmp3 = ifn_55.Invoke_O__O(arg_56) } else { tmp3 = linked_54.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_53, arg_56) }; var tmp4 any = tmp3; var tmp5 any = A_arbace_c2j_node_A_const_21; var tmp6 any; var root_57 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any; var root_61 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = spec__4; if linked_62 == nil { arg_60 = ifn_63.Invoke_O__O(arg_64) } else { arg_60 = linked_62.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_61, arg_64) }; if linked_58 == nil { tmp6 = ifn_59.Invoke_O__O(arg_60) } else { tmp6 = linked_58.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_57, arg_60) }; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, s__3, tmp2, tmp4, tmp5, tmp6)) }


func A_arbace_c2j_node_field_names_A_New() *A_arbace_c2j_node_field_names_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_field_names_A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_c2j_node_field_names_A) Ctor() {}
//line :70:1
func (t *A_arbace_c2j_node_field_names_A) Invoke_O_O__O(self, d__0 any) any {


	var root_72 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any; var root_76 any = A_arbace_c2j_node_A_const_27.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_78 lang.IFn; if linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any; var root_80 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any; var root_85 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any; var fnbody__95 any = A_arbace_c2j_node_field_names_fn__400000024_A_New(); var tmp1 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_c2j_node_field_names_fn__400000024_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, nil); A_arbace_c2j_node_field_names_fn__400000024_A_fn_class = fncls__94d; tmp1 = fncls__94d } else { tmp1 = fncls__94 }; arg_88 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__95, tmp1, nil); var arg_89 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_86 == nil { arg_83 = ifn_87.Invoke_O_O__O(arg_88, arg_89) } else { arg_83 = linked_86.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_85, arg_88, arg_89) }; var tmp2 *lang.Keyword = A_arbace_c2j_node_A_const_31; var arg_84 any = tmp2.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0)); if linked_81 == nil { arg_79 = ifn_82.Invoke_O_O__O(arg_83, arg_84) } else { arg_79 = linked_81.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_80, arg_83, arg_84) }; if linked_77 == nil { arg_75 = ifn_78.Invoke_O__O(arg_79) } else { arg_75 = linked_77.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_76, arg_79) }; if linked_73 == nil { return ifn_74.Invoke_O__O(arg_75) } else { return linked_73.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_72, arg_75) } }
//line :73:1
func A_arbace_c2j_node_field_names_fn__400000024_A_New() *A_arbace_c2j_node_field_names_fn__400000024_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_field_names_fn__400000024_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_c2j_node_field_names_fn__400000024_A) Ctor() {}
//line :73:1
func (t *A_arbace_c2j_node_field_names_fn__400000024_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_30); if jrt.J2g_Truth(tmp1.Invoke_O__O(A_arbace_c2j_node_A_const_20.Invoke_O__O(b__1))) { var root_90 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_91 == nil { return ifn_92.Invoke_O__O(arg_93) } else { return linked_91.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_90, arg_93) } } else { return nil } }


func A_arbace_c2j_node_children_bind_A_New() *A_arbace_c2j_node_children_bind_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_children_bind_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_c2j_node_children_bind_A) Ctor() {}
//line :76:1
func (t *A_arbace_c2j_node_children_bind_A) Invoke_O_O__O(self, d__0 any) any { var root_96 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any; var root_100 any = A_arbace_c2j_node_A_const_32.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any; var fnbody__106 any = A_arbace_c2j_node_children_bind_fn__400000028_A_New(); var tmp1 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_c2j_node_children_bind_fn__400000028_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, nil); A_arbace_c2j_node_children_bind_fn__400000028_A_fn_class = fncls__105d; tmp1 = fncls__105d } else { tmp1 = fncls__105 }; arg_103 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp1, nil); var arg_104 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_101 == nil { arg_99 = ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { arg_99 = linked_101.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_100, arg_103, arg_104) }; if linked_97 == nil { return ifn_98.Invoke_O__O(arg_99) } else { return linked_97.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_96, arg_99) } }
//line :76:1
func A_arbace_c2j_node_children_bind_fn__400000028_A_New() *A_arbace_c2j_node_children_bind_fn__400000028_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_children_bind_fn__400000028_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_c2j_node_children_bind_fn__400000028_A) Ctor() {}
//line :76:1
func (t *A_arbace_c2j_node_children_bind_fn__400000028_A) Invoke_O_O__O(self, p1__400000027_SHARP___1 any) any { var tmp1 any = A_arbace_c2j_node_A_const_33; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_c2j_node_A_const_20.Invoke_O__O(p1__400000027_SHARP___1))).Ref() }

func A_arbace_c2j_node_walk_syms_A_New() *A_arbace_c2j_node_walk_syms_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_walk_syms_A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_c2j_node_walk_syms_A) Ctor() {}
//line :78:1
func (t *A_arbace_c2j_node_walk_syms_A) Invoke_O_O_O__O(self, r__0, f__1 any) any {


	var tmp1 any; var root_107 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_109 lang.IFn
	if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = f__1; if linked_108 == nil { tmp1 = ifn_109.Invoke_O__O(arg_110) } else { tmp1 = linked_108.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_107, arg_110) }
//line :81:1
	if jrt.J2g_Truth(tmp1) {
		var tmp2 any; var root_111 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = r__0; var arg_115 any = f__1; if linked_112 == nil { tmp2 = ifn_113.Invoke_O_O__O(arg_114, arg_115) } else { tmp2 = linked_112.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_111, arg_114, arg_115) }; if jrt.J2g_Truth(tmp2) { return lang.IFn_Cast(r__0).Invoke_O__O(f__1) } else { return f__1 } } else {
//line :81:1
			var tmp3 any; var root_116 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_118 lang.IFn

			if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = f__1; if linked_117 == nil { tmp3 = ifn_118.Invoke_O__O(arg_119) } else { tmp3 = linked_117.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_116, arg_119) }
//line :81:1
			if jrt.J2g_Truth(tmp3) {

				var root_120 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any; var root_125 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = A_arbace_c2j_node_A_const_39.GetRawRoot__O(); var arg_129 any; var root_130 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any; var fnbody__141 any = A_arbace_c2j_node_walk_syms_fn__400000033_A_New_O(r__0); var tmp4 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_c2j_node_walk_syms_fn__400000033_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, fnbody__141); A_arbace_c2j_node_walk_syms_fn__400000033_A_fn_class = fncls__140d; tmp4 = fncls__140d } else { tmp4 = fncls__140 }; arg_133 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__141, tmp4, nil); var arg_134 any = f__1; if linked_131 == nil { arg_129 = ifn_132.Invoke_O_O__O(arg_133, arg_134) } else { arg_129 = linked_131.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_130, arg_133, arg_134) }; if linked_126 == nil { arg_123 = ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { arg_123 = linked_126.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_125, arg_128, arg_129) }; var arg_124 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); if linked_121 == nil { return ifn_122.Invoke_O_O__O(arg_123, arg_124) } else { return linked_121.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_120, arg_123, arg_124) } } else {
//line :81:1
					var tmp5 any; var root_142 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_144 lang.IFn


					if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = f__1; if linked_143 == nil { tmp5 = ifn_144.Invoke_O__O(arg_145) } else { tmp5 = linked_143.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_142, arg_145) }
//line :81:1
					if jrt.J2g_Truth(tmp5) {


						var root_146 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var root_151 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any; var fnbody__162 any = A_arbace_c2j_node_walk_syms_fn__400000035_A_New_O(r__0); var tmp6 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_c2j_node_walk_syms_fn__400000035_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, fnbody__162); A_arbace_c2j_node_walk_syms_fn__400000035_A_fn_class = fncls__161d; tmp6 = fncls__161d } else { tmp6 = fncls__161 }; arg_154 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp6, nil); var arg_155 any = f__1; if linked_152 == nil { arg_149 = ifn_153.Invoke_O_O__O(arg_154, arg_155) } else { arg_149 = linked_152.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_151, arg_154, arg_155) }; var arg_150 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__1); if linked_147 == nil { return ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { return linked_147.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) } } else {
//line :81:1
							var tmp7 any; var root_163 any = A_arbace_c2j_node_A_const_43.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_165 lang.IFn



							if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = f__1; if linked_164 == nil { tmp7 = ifn_165.Invoke_O__O(arg_166) } else { tmp7 = linked_164.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_163, arg_166) }
//line :81:1
							if jrt.J2g_Truth(tmp7) {



								var root_167 any = A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_171 any; var root_172 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any; var fnbody__188 any = A_arbace_c2j_node_walk_syms_fn__400000038_A_New_O(r__0); var tmp8 *jrt.Class; var fncls__187 *jrt.Class = A_arbace_c2j_node_walk_syms_fn__400000038_A_fn_class; if fncls__187 == nil { var fncls__187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, fnbody__188); A_arbace_c2j_node_walk_syms_fn__400000038_A_fn_class = fncls__187d; tmp8 = fncls__187d } else { tmp8 = fncls__187 }; arg_175 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__188, tmp8, nil); var arg_176 any = f__1; if linked_173 == nil { arg_171 = ifn_174.Invoke_O_O__O(arg_175, arg_176) } else { arg_171 = linked_173.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_172, arg_175, arg_176) }; if linked_168 == nil { return ifn_169.Invoke_O_O__O(arg_170, arg_171) } else { return linked_168.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_167, arg_170, arg_171) } } else {
//line :81:1
									if A_arbace_c2j_node_A_const_45 != nil { return f__1 } else { return nil
									} } } } } }
func A_arbace_c2j_node_walk_syms_fn__400000033_A_New_O(p0 any) *A_arbace_c2j_node_walk_syms_fn__400000033_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_walk_syms_fn__400000033_A{}; t.Ctor_O(p0); return t }
//line :83:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000033_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :83:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000033_A) Invoke_O_O__O(self, p1__400000031_SHARP___1 any) any { var root_135 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = t.F_r; var arg_139 any = p1__400000031_SHARP___1; if linked_136 == nil { return ifn_137.Invoke_O_O__O(arg_138, arg_139) } else { return linked_136.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_135, arg_138, arg_139) } }
func A_arbace_c2j_node_walk_syms_fn__400000035_A_New_O(p0 any) *A_arbace_c2j_node_walk_syms_fn__400000035_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_walk_syms_fn__400000035_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000035_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :84:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000035_A) Invoke_O_O__O(self, p1__400000032_SHARP___1 any) any { var root_156 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = t.F_r; var arg_160 any = p1__400000032_SHARP___1; if linked_157 == nil { return ifn_158.Invoke_O_O__O(arg_159, arg_160) } else { return linked_157.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_156, arg_159, arg_160) } }
func A_arbace_c2j_node_walk_syms_fn__400000038_A_New_O(p0 any) *A_arbace_c2j_node_walk_syms_fn__400000038_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_walk_syms_fn__400000038_A{}; t.Ctor_O(p0); return t }
//line :85:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000038_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :85:1
func (t *A_arbace_c2j_node_walk_syms_fn__400000038_A) Invoke_O_O__O(self, p__400000037__1 any) any { var vec__400000039__2 any = p__400000037__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000039__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000039__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_177 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any = t.F_r; var arg_181 any = k__3; if linked_178 == nil { tmp1 = ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { tmp1 = linked_178.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_177, arg_180, arg_181) }; var tmp2 any = tmp1; var tmp3 any; var root_182 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = t.F_r; var arg_186 any = v__4; if linked_183 == nil { tmp3 = ifn_184.Invoke_O_O__O(arg_185, arg_186) } else { tmp3 = linked_183.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_182, arg_185, arg_186) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }


func A_arbace_c2j_node_head_A_New() *A_arbace_c2j_node_head_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_head_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_c2j_node_head_A) Ctor() {}
//line :88:1
func (t *A_arbace_c2j_node_head_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_189 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = f__0; if linked_190 == nil { and__1927000168__auto____2 = ifn_191.Invoke_O__O(arg_192) } else { and__1927000168__auto____2 = linked_190.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_189, arg_192) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_193 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any; var root_197 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = f__0; if linked_198 == nil { arg_196 = ifn_199.Invoke_O__O(arg_200) } else { arg_196 = linked_198.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_197, arg_200) }; if linked_194 == nil { tmp1 = ifn_195.Invoke_O__O(arg_196) } else { tmp1 = linked_194.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_193, arg_196) } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var root_201 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = f__0; if linked_202 == nil { return ifn_203.Invoke_O__O(arg_204) } else { return linked_202.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_201, arg_204) } } else { return nil } }

func A_arbace_c2j_node_runs_children_QMARK__A_New() *A_arbace_c2j_node_runs_children_QMARK__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_runs_children_QMARK__A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_c2j_node_runs_children_QMARK__A) Ctor() {}
//line :90:1
func (t *A_arbace_c2j_node_runs_children_QMARK__A) Invoke_O_O__O(self, t__0 any) any {


	var tmp1 any; var root_205 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_207 lang.IFn
	if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = t__0; if linked_206 == nil { tmp1 = ifn_207.Invoke_O__O(arg_208) } else { tmp1 = linked_206.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_205, arg_208) }
//line :93:1
	if jrt.J2g_Truth(tmp1) { var or__1927000174__auto____2 any; var root_209 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_211 lang.IFn
		if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = A_arbace_c2j_node_A_const_46; var arg_213 any; var root_214 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, A_arbace_c2j_node_head_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = t__0; if linked_215 == nil { arg_213 = ifn_216.Invoke_O__O(arg_217) } else { arg_213 = linked_215.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_214, arg_217) }; if linked_210 == nil { or__1927000174__auto____2 = ifn_211.Invoke_O_O__O(arg_212, arg_213) } else { or__1927000174__auto____2 = linked_210.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_209, arg_212, arg_213) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_218 any = A_arbace_c2j_node_A_const_48.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = A_arbace_c2j_node_A_const_49.GetRawRoot__O(); var arg_222 any = t__0; if linked_219 == nil { return ifn_220.Invoke_O_O__O(arg_221, arg_222) } else { return linked_219.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_218, arg_221, arg_222) } } } else {
//line :93:1
			var tmp2 any; var root_223 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_225 lang.IFn

			if linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any = t__0; if linked_224 == nil { tmp2 = ifn_225.Invoke_O__O(arg_226) } else { tmp2 = linked_224.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_223, arg_226) }
//line :93:1
			if jrt.J2g_Truth(tmp2) {

				var root_227 any = A_arbace_c2j_node_A_const_48.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any = A_arbace_c2j_node_A_const_49.GetRawRoot__O(); var arg_231 any = t__0; if linked_228 == nil { return ifn_229.Invoke_O_O__O(arg_230, arg_231) } else { return linked_228.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_227, arg_230, arg_231) } } else {
//line :93:1
					if A_arbace_c2j_node_A_const_45 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil
					}
				}
		}
}










func A_arbace_c2j_node_q_elems_A_New() *A_arbace_c2j_node_q_elems_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_elems_A{}; t.Ctor(); return t }
//line :108:1
func (t *A_arbace_c2j_node_q_elems_A) Ctor() {}
//line :108:1
func (t *A_arbace_c2j_node_q_elems_A) Invoke_O_O_O__O(self, env__0, xs__1 any) any { var lst__3 any; var root_232 any = A_arbace_c2j_node_A_const_50.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_234 lang.IFn; if



	linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = xs__1; if linked_233 == nil { lst__3 = ifn_234.Invoke_O__O(arg_235) } else { lst__3 = linked_233.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_232, arg_235) }; var tmp1 any; var and__1927000168__auto____4 any; var root_236 any =
	A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = lst__3; if linked_237 == nil { and__1927000168__auto____4 = ifn_238.Invoke_O__O(arg_239) } else { and__1927000168__auto____4 = linked_237.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_236, arg_239) }; if jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 any = A_arbace_c2j_node_A_const_51; var tmp3 any; var root_240 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_240, A_arbace_c2j_node_head_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = lst__3; if linked_241 == nil { tmp3 = ifn_242.Invoke_O__O(arg_243) } else { tmp3 = linked_241.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_240, arg_243) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { var b__4 any; var tmp4 lang.IFn = lang.IFn_Cast(env__0); var tmp5 any; var root_244 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_246 lang.IFn
		if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = lst__3; if linked_245 == nil { tmp5 = ifn_246.Invoke_O__O(arg_247) } else { tmp5 = linked_245.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_244, arg_247) }; b__4 = tmp4.Invoke_O__O(tmp5)
//line :113:1
		var tmp6 any; var root_248 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_250 lang.IFn

		if linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any; var fnbody__259 any = A_arbace_c2j_node_q_elems_fn__400000048_A_New_O(env__0); var tmp7 *jrt.Class; var fncls__258 *jrt.Class = A_arbace_c2j_node_q_elems_fn__400000048_A_fn_class; if fncls__258 == nil { var fncls__258d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__259); A_arbace_c2j_node_q_elems_fn__400000048_A_fn_class = fncls__258d; tmp7 = fncls__258d } else { tmp7 = fncls__258 }; arg_251 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__259, tmp7, nil); var arg_252 any; var root_260 any = A_arbace_c2j_node_A_const_54.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_262 lang.IFn; if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = xs__1; if linked_261 == nil { arg_252 = ifn_262.Invoke_O__O(arg_263) } else { arg_252 = linked_261.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_260, arg_263) }; if linked_249 == nil { tmp6 = ifn_250.Invoke_O_O__O(arg_251, arg_252) } else { tmp6 = linked_249.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_248, arg_251, arg_252) }
//line :113:1
		var tmp8 any = tmp6; var tmp9 any; var G__400000050__5_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__4)


	L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__400000050__5_) { case 177445645: if any(G__400000050__5_) == any(A_arbace_c2j_node_A_const_55) {
		var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_node_A_const_57; tmp9 = tmp10.Invoke_O_O__O(tmp11, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4))
//line :116:1
		break L1 }; default:
	}
		tmp9 = A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4)}
//line :113:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9) } else { var tmp12 any; var root_265 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_267 lang.IFn





			if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any; var fnbody__276 any = A_arbace_c2j_node_q_elems_fn__400000051_A_New_O(env__0); var tmp13 *jrt.Class; var fncls__275 *jrt.Class = A_arbace_c2j_node_q_elems_fn__400000051_A_fn_class; if fncls__275 == nil { var fncls__275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, fnbody__276); A_arbace_c2j_node_q_elems_fn__400000051_A_fn_class = fncls__275d; tmp13 = fncls__275d } else { tmp13 = fncls__275 }; arg_268 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__276, tmp13, nil); var arg_269 any = xs__1; if linked_266 == nil { tmp12 = ifn_267.Invoke_O_O__O(arg_268, arg_269) } else { tmp12 = linked_266.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_265, arg_268, arg_269) }
//line :113:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp12, nil) } }

func A_arbace_c2j_node_q_elems_fn__400000048_A_New_O(p0 any) *A_arbace_c2j_node_q_elems_fn__400000048_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_elems_fn__400000048_A{}; t.Ctor_O(p0); return t }
//line :115:1
func (t *A_arbace_c2j_node_q_elems_fn__400000048_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :115:1
func (t *A_arbace_c2j_node_q_elems_fn__400000048_A) Invoke_O_O__O(self, p1__400000046_SHARP___1 any) any { var root_253 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, A_arbace_c2j_node_q_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = t.F_env; var arg_257 any = p1__400000046_SHARP___1; if linked_254 == nil { return ifn_255.Invoke_O_O__O(arg_256, arg_257) } else { return linked_254.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_253, arg_256, arg_257) } }



func A_arbace_c2j_node_q_elems_fn__400000051_A_New_O(p0 any) *A_arbace_c2j_node_q_elems_fn__400000051_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_elems_fn__400000051_A{}; t.Ctor_O(p0); return t }
//line :119:1
func (t *A_arbace_c2j_node_q_elems_fn__400000051_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :119:1
func (t *A_arbace_c2j_node_q_elems_fn__400000051_A) Invoke_O_O__O(self, p1__400000047_SHARP___1 any) any { var root_270 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, A_arbace_c2j_node_q_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = t.F_env; var arg_274 any = p1__400000047_SHARP___1; if linked_271 == nil { return ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { return linked_271.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_270, arg_273, arg_274) } }

func A_arbace_c2j_node_q_drop_QMARK__A_New() *A_arbace_c2j_node_q_drop_QMARK__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_drop_QMARK__A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_c2j_node_q_drop_QMARK__A) Ctor() {}
//line :121:1
func (t *A_arbace_c2j_node_q_drop_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(x__0, A_arbace_c2j_node_A_const_58)).Ref() }

func A_arbace_c2j_node_q_body_A_New() *A_arbace_c2j_node_q_body_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_body_A{}; t.Ctor(); return t }
//line :123:1
func (t *A_arbace_c2j_node_q_body_A) Ctor() {}
//line :123:1
func (t *A_arbace_c2j_node_q_body_A) Invoke_O_O_O__O(self, env__0, bs__1 any) any { var cs__3 any; var root_277 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_279 lang.IFn; if


	linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = A_arbace_c2j_node_A_const_60.GetRawRoot__O(); var arg_281 any; var root_282 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any; var fnbody__293 any = A_arbace_c2j_node_q_body_fn__400000056_A_New_O(env__0); var tmp1 *jrt.Class; var fncls__292 *jrt.Class = A_arbace_c2j_node_q_body_fn__400000056_A_fn_class; if fncls__292 == nil { var fncls__292d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__293); A_arbace_c2j_node_q_body_fn__400000056_A_fn_class = fncls__292d; tmp1 = fncls__292d } else { tmp1 = fncls__292 }; arg_285 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__293, tmp1, nil); var arg_286 any = bs__1; if linked_283 == nil { arg_281 = ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { arg_281 = linked_283.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_282, arg_285, arg_286) }; if linked_278 == nil { cs__3 = ifn_279.Invoke_O_O__O(arg_280, arg_281) } else { cs__3 = linked_278.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_277, arg_280, arg_281) }; var tmp2 any; var root_294 any =
	A_arbace_c2j_node_A_const_61.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_296 lang.IFn; if
	linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = cs__3; if linked_295 == nil { tmp2 = ifn_296.Invoke_O__O(arg_297) } else { tmp2 = linked_295.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_294, arg_297) }; if /*line :127:1*/ jrt.J2g_Truth(tmp2) { return nil } else { if lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(cs__3))) {

		var root_298 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any = cs__3; if linked_299 == nil { return ifn_300.Invoke_O__O(arg_301) } else { return linked_299.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_298, arg_301) } } else {
//line :127:1
			if A_arbace_c2j_node_A_const_45 != nil {


				var root_302 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = A_arbace_c2j_node_A_const_63; var arg_306 any = A_arbace_c2j_node_A_const_64; var arg_307 any = cs__3; if linked_303 == nil { return ifn_304.Invoke_O_O_O__O(arg_305, arg_306, arg_307) } else { return linked_303.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_302, arg_305, arg_306, arg_307) } } else {
//line :127:1
					return nil } } } }
//line :126:1
func A_arbace_c2j_node_q_body_fn__400000056_A_New_O(p0 any) *A_arbace_c2j_node_q_body_fn__400000056_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_body_fn__400000056_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_c2j_node_q_body_fn__400000056_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :126:1
func (t *A_arbace_c2j_node_q_body_fn__400000056_A) Invoke_O_O__O(self, p1__400000055_SHARP___1 any) any { var root_287 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, A_arbace_c2j_node_q_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any = t.F_env; var arg_291 any = p1__400000055_SHARP___1; if linked_288 == nil { return ifn_289.Invoke_O_O__O(arg_290, arg_291) } else { return linked_288.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_287, arg_290, arg_291) } }





func A_arbace_c2j_node_qs_A_New() *A_arbace_c2j_node_qs_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qs_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_c2j_node_qs_A) Ctor() {}
//line :132:1
func (t *A_arbace_c2j_node_qs_A) Invoke_O_O_O__O(self, env__0, f__1 any) any {


	if lang.Util_Equiv_O_O__Z_NoInit(f__1, A_arbace_c2j_node_A_const_65) {
		var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_56; return tmp1.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(A_arbace_c2j_node_A_const_69)) } else {
//line :135:1
			var tmp2 any; var and__1927000168__auto____3 any; var root_308 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_309 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_308, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_310 lang.IFn

			if linked_309 == nil { ifn_310 = lang.IFn_Cast(root_308) } else { ifn_310 = nil }; var arg_311 any = f__1; if linked_309 == nil { and__1927000168__auto____3 = ifn_310.Invoke_O__O(arg_311) } else { and__1927000168__auto____3 = linked_309.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_308, arg_311) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var tmp3 any = A_arbace_c2j_node_A_const_66; var tmp4 any; var root_312 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, A_arbace_c2j_node_head_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = f__1; if linked_313 == nil { tmp4 = ifn_314.Invoke_O__O(arg_315) } else { tmp4 = linked_313.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_312, arg_315) }; tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4)).Ref() } else { tmp2 = and__1927000168__auto____3 }
//line :135:1
			if jrt.J2g_Truth(tmp2) {

				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_node_A_const_70; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_node_A_const_72; var tmp9 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp10 lang.IFn = lang.IFn_Cast(env__0); var tmp11 any; var root_345 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = f__1; if linked_346 == nil { tmp11 = ifn_347.Invoke_O__O(arg_348) } else { tmp11 = linked_346.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_345, arg_348) }; var tmp12 any = tmp7.Invoke_O_O__O(tmp8, tmp9.Invoke_O__O(tmp10.Invoke_O__O(tmp11))); var tmp13 *lang.Keyword = A_arbace_c2j_node_A_const_71; var tmp14 lang.IFn = lang.IFn_Cast(env__0); var tmp15 any; var root_349 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any = f__1; if linked_350 == nil { tmp15 = ifn_351.Invoke_O__O(arg_352) } else { tmp15 = linked_350.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_349, arg_352) }; return tmp5.Invoke_O_O_O__O(tmp6, tmp12, tmp13.Invoke_O__O(tmp14.Invoke_O__O(tmp15))) } else {
//line :135:1
					var tmp16 any; var and__1927000168__auto____3_2 any; var root_316 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_317 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_316, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_318 lang.IFn


					if linked_317 == nil { ifn_318 = lang.IFn_Cast(root_316) } else { ifn_318 = nil }; var arg_319 any = f__1; if linked_317 == nil { and__1927000168__auto____3_2 = ifn_318.Invoke_O__O(arg_319) } else { and__1927000168__auto____3_2 = linked_317.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_316, arg_319) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) { var tmp17 any = A_arbace_c2j_node_A_const_67; var tmp18 any; var root_320 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, A_arbace_c2j_node_head_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any = f__1; if linked_321 == nil { tmp18 = ifn_322.Invoke_O__O(arg_323) } else { tmp18 = linked_321.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_320, arg_323) }; tmp16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp17, tmp18)).Ref() } else { tmp16 = and__1927000168__auto____3_2 }
//line :135:1
					if jrt.J2g_Truth(tmp16) {


						var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp20 any = A_arbace_c2j_node_A_const_73; var tmp21 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp22 lang.IFn = lang.IFn_Cast(env__0); var tmp23 any; var root_353 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = f__1; if linked_354 == nil { tmp23 = ifn_355.Invoke_O__O(arg_356) } else { tmp23 = linked_354.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_353, arg_356) }; return tmp19.Invoke_O_O__O(tmp20, tmp21.Invoke_O__O(tmp22.Invoke_O__O(tmp23))) } else {
//line :135:1
							if A_arbace_c2j_node_A_const_45 != nil {



								var root_324 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any; var root_329 any = A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_333 any; var root_335 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_336 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_335, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_337 lang.IFn; if linked_336 == nil { ifn_337 = lang.IFn_Cast(root_335) } else { ifn_337 = nil }; var arg_338 any; var fnbody__344 any = A_arbace_c2j_node_qs_fn__400000060_A_New(); var tmp24 *jrt.Class; var fncls__343 *jrt.Class = A_arbace_c2j_node_qs_fn__400000060_A_fn_class; if fncls__343 == nil { var fncls__343d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_78, false, nil); A_arbace_c2j_node_qs_fn__400000060_A_fn_class = fncls__343d; tmp24 = fncls__343d } else { tmp24 = fncls__343 }; arg_338 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__344, tmp24, nil); if linked_336 == nil { arg_333 = ifn_337.Invoke_O__O(arg_338) } else { arg_333 = linked_336.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O__O(root_335, arg_338) }; var arg_334 any = env__0; if linked_330 == nil { arg_327 = ifn_331.Invoke_O_O_O__O(arg_332, arg_333, arg_334) } else { arg_327 = linked_330.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_329, arg_332, arg_333, arg_334) }; var arg_328 any = f__1; if linked_325 == nil { return ifn_326.Invoke_O_O__O(arg_327, arg_328) } else { return linked_325.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_324, arg_327, arg_328) } } else {
//line :135:1
									return nil
								}
						}
				} } }
func A_arbace_c2j_node_qs_fn__400000060_A_New() *A_arbace_c2j_node_qs_fn__400000060_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qs_fn__400000060_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_c2j_node_qs_fn__400000060_A) Ctor() {}
//line :139:1
func (t *A_arbace_c2j_node_qs_fn__400000060_A) Invoke_O_O__O(self, p__400000059__1 any) any { var vec__400000061__2 any = p__400000059__1; var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000061__2, lang.RT_IntCast_J__I_NoInit(0), nil); var b__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000061__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var and__1927000168__auto____5 any; var root_339 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_339, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_341 lang.IFn; if linked_340 == nil { ifn_341 = lang.IFn_Cast(root_339) } else { ifn_341 = nil }; var arg_342 any = s__3; if linked_340 == nil { and__1927000168__auto____5 = ifn_341.Invoke_O__O(arg_342) } else { and__1927000168__auto____5 = linked_340.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_339, arg_342) }; if jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_68); tmp1 = tmp2.Invoke_O__O(A_arbace_c2j_node_A_const_20.Invoke_O__O(b__4)) } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(s__3, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4)) } else { return nil } }

func A_arbace_c2j_node_q_seq_A_New() *A_arbace_c2j_node_q_seq_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_c2j_node_q_seq_A) Ctor() {}
//line :141:1
func (t *A_arbace_c2j_node_q_seq_A) Invoke_O_O_O__O(self, env__0, t__1 any) any { var vec__400000067__3 any = t__1; var seq__400000068__4 any; var root_357 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_359 lang.IFn; if
										linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = vec__400000067__3; if linked_358 == nil { seq__400000068__4 = ifn_359.Invoke_O__O(arg_360) } else { seq__400000068__4 = linked_358.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_357, arg_360) }; var first__400000069__5 any; var root_361 any = /*line :141:1*/A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_361, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_363 lang.IFn; if
										linked_362 == nil { ifn_363 = lang.IFn_Cast(root_361) } else { ifn_363 = nil }; var arg_364 any = seq__400000068__4; if linked_362 == nil { first__400000069__5 = ifn_363.Invoke_O__O(arg_364) } else { first__400000069__5 = linked_362.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_361, arg_364) }; var seq__400000068__6 any; var root_365 any = /*line :141:1*/A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_365, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_367 lang.IFn; if
										linked_366 == nil { ifn_367 = lang.IFn_Cast(root_365) } else { ifn_367 = nil }; var arg_368 any = seq__400000068__4; if linked_366 == nil { seq__400000068__6 = ifn_367.Invoke_O__O(arg_368) } else { seq__400000068__6 = linked_366.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_365, arg_368) }; var h__7 any = first__400000069__5; var as__8 any = seq__400000068__6; var G__400000070__9_ any = h__7; switch
										lang.Util_Hash_O__I_NoInit(G__400000070__9_) >> 2 & 63 { case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_76) { var vec__400000071__10 any = as__8; var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000071__10, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000071__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_85; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_node_A_const_86; var tmp5 any = A_arbace_c2j_node_A_const_87; var tmp6 *lang.Keyword = A_arbace_c2j_node_A_const_56; _ = ___11






		return tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O_O_O__O(tmp4, tmp5, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_88, A_arbace_c2j_node_A_const_89, A_arbace_c2j_node_A_const_90)), tmp6.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(xs__12))) }
//line :143:1
	case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_77) {




















		var root_370 any = A_arbace_c2j_node_A_const_78.GetRawRoot__O(); var linked_371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_370, A_arbace_c2j_node_q_body_A_fn_class); var ifn_372 lang.IFn; if linked_371 == nil { ifn_372 = lang.IFn_Cast(root_370) } else { ifn_372 = nil }; var arg_373 any = env__0; var arg_374 any = as__8; if linked_371 == nil { return ifn_372.Invoke_O_O__O(arg_373, arg_374) } else { return linked_371.(*A_arbace_c2j_node_q_body_A).Invoke_O_O_O__O(root_370, arg_373, arg_374) } }
//line :143:1
	case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_79) { var vec__400000074__10 any = as__8; var s__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000074__10, lang.RT_IntCast_J__I_NoInit(0), nil); var b__12 any = lang.IFn_Cast(env__0).Invoke_O__O(s__11); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_node_A_const_91; var tmp9 any = A_arbace_c2j_node_A_const_92; var tmp10 any = A_arbace_c2j_node_A_const_93; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_node_A_const_94; var tmp13 any
		var tmp14 any = A_arbace_c2j_node_A_const_55
































		if lang.Util_Equiv_O_O__Z_NoInit(tmp14, A_arbace_c2j_node_A_const_20.Invoke_O__O(b__12)) { var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_node_A_const_95; tmp13 = tmp15.Invoke_O_O__O(tmp16, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__12)) } else { tmp13 = A_arbace_c2j_node_A_const_56.Invoke_O__O(b__12) }; return tmp7.Invoke_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11.Invoke_O_O__O(tmp12, tmp13)) }
//line :143:1
	case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_80) { var vec__400000077__10 any = as__8; var c__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000077__10, lang.RT_IntCast_J__I_NoInit(0), nil); var a__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000077__10, lang.RT_IntCast_J__I_NoInit(1), nil); var b__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000077__10, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp18 any = A_arbace_c2j_node_A_const_100; var tmp19 any; var root_430 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, A_arbace_c2j_node_qs_A_fn_class); var ifn_432 lang.IFn





















		if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = env__0; var arg_434 any = c__11; if linked_431 == nil { tmp19 = ifn_432.Invoke_O_O__O(arg_433, arg_434) } else { tmp19 = linked_431.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_430, arg_433, arg_434) }; var tmp20 any = tmp19; var tmp21 any; var root_435 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, A_arbace_c2j_node_q_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = env__0; var arg_439 any = a__12; if linked_436 == nil { tmp21 = ifn_437.Invoke_O_O__O(arg_438, arg_439) } else { tmp21 = linked_436.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_435, arg_438, arg_439) }; var tmp22 any = tmp21; var tmp23 any; var root_440 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, A_arbace_c2j_node_q_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = env__0; var arg_444 any = b__13; if linked_441 == nil { tmp23 = ifn_442.Invoke_O_O__O(arg_443, arg_444) } else { tmp23 = linked_441.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_440, arg_443, arg_444) }; return tmp17.Invoke_O_O_O_O__O(tmp18, tmp20, tmp22, tmp23) }
//line :143:1
	case 26: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_96) { var vec__400000080__10 any = as__8; var seq__400000081__11 any; var root_391 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_393 lang.IFn






















		if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = vec__400000080__10; if linked_392 == nil { seq__400000081__11 = ifn_393.Invoke_O__O(arg_394) } else { seq__400000081__11 = linked_392.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_391, arg_394) }
//line :143:1
		var first__400000082__12 any; var root_395 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_397 lang.IFn






















		if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = seq__400000081__11; if linked_396 == nil { first__400000082__12 = ifn_397.Invoke_O__O(arg_398) } else { first__400000082__12 = linked_396.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_395, arg_398) }
//line :143:1
		var seq__400000081__13 any; var root_399 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_401 lang.IFn






















		if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = seq__400000081__11; if linked_400 == nil { seq__400000081__13 = ifn_401.Invoke_O__O(arg_402) } else { seq__400000081__13 = linked_400.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_399, arg_402) }
//line :143:1
		var sel__14 any = first__400000082__12; var cls__15 any = seq__400000081__13; var root_403 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_405 lang.IFn























		if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp25 any = A_arbace_c2j_node_A_const_97; var tmp26 any; var root_408 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, A_arbace_c2j_node_qs_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = env__0; var arg_412 any = sel__14; if linked_409 == nil { tmp26 = ifn_410.Invoke_O_O__O(arg_411, arg_412) } else { tmp26 = linked_409.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_408, arg_411, arg_412) }; arg_406 = tmp24.Invoke_O_O__O(tmp25, tmp26); var arg_407 any; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp28 *lang.Compiler_AOTFn; var fnbody__424 any = A_arbace_c2j_node_q_seq_fn__400000084_A_New_O(env__0); var tmp29 *jrt.Class; var fncls__423 *jrt.Class = A_arbace_c2j_node_q_seq_fn__400000084_A_fn_class; if fncls__423 == nil { var fncls__423d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, fnbody__424); A_arbace_c2j_node_q_seq_fn__400000084_A_fn_class = fncls__423d; tmp29 = fncls__423d } else { tmp29 = fncls__423 }; tmp28 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__424, tmp29, nil); var tmp30 any = tmp28.Ref(); var tmp31 any; var root_425 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = A_arbace_c2j_node_A_const_25; var arg_429 any = cls__15; if linked_426 == nil { tmp31 = ifn_427.Invoke_O_O__O(arg_428, arg_429) } else { tmp31 = linked_426.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_425, arg_428, arg_429) }; arg_407 = tmp27.Invoke_O_O__O(tmp30, tmp31); if linked_404 == nil { return ifn_405.Invoke_O_O__O(arg_406, arg_407) } else { return linked_404.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_403, arg_406, arg_407) } }
//line :143:1
	case 27: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_101) { var vec__400000089__10 any = as__8; var at__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000089__10, lang.RT_IntCast_J__I_NoInit(0), nil); var x__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000089__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp33 any = A_arbace_c2j_node_A_const_103; var tmp34 any = A_arbace_c2j_node_A_const_104; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp36 any = A_arbace_c2j_node_A_const_105; var tmp37 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp38 any = tmp35.Invoke_O_O__O(tmp36, tmp37.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(at__11))); var tmp39 any; var root_445 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, A_arbace_c2j_node_q_A_fn_class); var ifn_447 lang.IFn



































		if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = env__0; var arg_449 any = x__12; if linked_446 == nil { tmp39 = ifn_447.Invoke_O_O__O(arg_448, arg_449) } else { tmp39 = linked_446.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_445, arg_448, arg_449) }; return tmp32.Invoke_O_O_O_O__O(tmp33, tmp34, tmp38, tmp39) }
//line :143:1
	case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_102) { var vec__400000092__10 any = as__8; var at__11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000092__10, lang.RT_IntCast_J__I_NoInit(0), nil); var ___12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000092__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp41 any = A_arbace_c2j_node_A_const_105; var tmp42 *lang.Keyword = A_arbace_c2j_node_A_const_56; _ = ___12


































		return tmp40.Invoke_O_O__O(tmp41, tmp42.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(at__11_2))) }
//line :143:1
	case 36: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_106) { var vec__400000095__10 any = as__8; var c__11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000095__10, lang.RT_IntCast_J__I_NoInit(0), nil); var x__12_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000095__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp43 *lang.Keyword = A_arbace_c2j_node_A_const_56; var xv__13 any = tmp43.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(x__12_2))
		var G__400000098__14_ any = c__11_2

		switch lang.Util_Hash_O__I_NoInit(G__400000098__14_) >> 8 & 7 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_107) {

			return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_112, A_arbace_c2j_node_A_const_113, xv__13) }
//line :146:1
		case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_108) {


			var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp45 any = A_arbace_c2j_node_A_const_114; var tmp46 any = A_arbace_c2j_node_A_const_115; return tmp44.Invoke_O_O_O_O__O(tmp45, tmp46, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_116, A_arbace_c2j_node_A_const_117, xv__13), lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_118, A_arbace_c2j_node_A_const_119, xv__13)) }
//line :146:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_109) {

			return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_112, A_arbace_c2j_node_A_const_113, xv__13) }
//line :146:1
		case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_110) {

			return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_112, A_arbace_c2j_node_A_const_113, xv__13) }
//line :146:1
		case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__400000098__14_, A_arbace_c2j_node_A_const_120) {
			return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_121, A_arbace_c2j_node_A_const_122, xv__13) }
//line :146:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__400000098__14_))))) }
//line :143:1
	case 37: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_111) { var vec__400000099__10 any = as__8; var m__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000099__10, lang.RT_IntCast_J__I_NoInit(0), nil); var a__12_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000099__10, lang.RT_IntCast_J__I_NoInit(1), nil); var b__13_2 any = lang.IFn_Cast(env__0).Invoke_O__O(a__12_2); var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp48 any = A_arbace_c2j_node_A_const_124; var tmp49 any = A_arbace_c2j_node_A_const_125; var tmp50 any; var root_451 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_451, A_arbace_c2j_node_qs_A_fn_class); var ifn_453 lang.IFn






























		if linked_452 == nil { ifn_453 = lang.IFn_Cast(root_451) } else { ifn_453 = nil }; var arg_454 any = env__0; var arg_455 any = m__11; if linked_452 == nil { tmp50 = ifn_453.Invoke_O_O__O(arg_454, arg_455) } else { tmp50 = linked_452.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_451, arg_454, arg_455) }; return tmp47.Invoke_O_O_O_O_O__O(tmp48, tmp49, tmp50, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__13_2), A_arbace_c2j_node_A_const_126.Invoke_O__O(b__13_2)) }
//line :143:1
	case 45: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_123) { return A_arbace_c2j_node_A_const_58 }; case 48: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_127) { var vec__400000102__10 any = as__8; var ___11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000102__10, lang.RT_IntCast_J__I_NoInit(0), nil); var x__12_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000102__10, lang.RT_IntCast_J__I_NoInit(1), nil); var root_456 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, A_arbace_c2j_node_q_A_fn_class); var ifn_458 lang.IFn; _ = ___11_2



















		if linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = env__0; var arg_460 any = x__12_3; if linked_457 == nil { return ifn_458.Invoke_O_O__O(arg_459, arg_460) } else { return linked_457.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_456, arg_459, arg_460) } }
//line :143:1
	case 54: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_128) { var vec__400000105__10 any = as__8; var seq__400000106__11 any; var root_461 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_463 lang.IFn









		if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = vec__400000105__10; if linked_462 == nil { seq__400000106__11 = ifn_463.Invoke_O__O(arg_464) } else { seq__400000106__11 = linked_462.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_461, arg_464) }
//line :143:1
		var first__400000107__12 any; var root_465 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_467 lang.IFn









		if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = seq__400000106__11; if linked_466 == nil { first__400000107__12 = ifn_467.Invoke_O__O(arg_468) } else { first__400000107__12 = linked_466.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_465, arg_468) }
//line :143:1
		var seq__400000106__13 any; var root_469 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_471 lang.IFn









		if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = seq__400000106__11; if linked_470 == nil { seq__400000106__13 = ifn_471.Invoke_O__O(arg_472) } else { seq__400000106__13 = linked_470.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_469, arg_472) }
//line :143:1
		var ___14 any = first__400000107__12; var first__400000107__15 any; var root_473 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_475 lang.IFn; _ = ___14









		if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = seq__400000106__13; if linked_474 == nil { first__400000107__15 = ifn_475.Invoke_O__O(arg_476) } else { first__400000107__15 = linked_474.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_473, arg_476) }
//line :143:1
		var seq__400000106__16 any; var root_477 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_479 lang.IFn









		if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = seq__400000106__13; if linked_478 == nil { seq__400000106__16 = ifn_479.Invoke_O__O(arg_480) } else { seq__400000106__16 = linked_478.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_477, arg_480) }
//line :143:1
		var bv__17 any = first__400000107__15; var body__18 any = seq__400000106__16; var vec__400000108__19 any; var root_481 any = A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_481, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_483 lang.IFn










		if linked_482 == nil { ifn_483 = lang.IFn_Cast(root_481) } else { ifn_483 = nil }; var arg_484 any; var fnbody__513 any = A_arbace_c2j_node_q_seq_fn__400000113_A_New(); var tmp51 *jrt.Class; var fncls__512 *jrt.Class = A_arbace_c2j_node_q_seq_fn__400000113_A_fn_class; if fncls__512 == nil { var fncls__512d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, nil); A_arbace_c2j_node_q_seq_fn__400000113_A_fn_class = fncls__512d; tmp51 = fncls__512d } else { tmp51 = fncls__512 }; arg_484 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__513, tmp51, nil); var arg_485 any = lang.Tuple_Create_O_O__IPersistentVector(env__0, lang.PersistentVector_EMPTY.Ref()); var arg_486 any; var root_514 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_516 lang.IFn




		if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = A_arbace_c2j_node_A_const_25; var arg_518 any = bv__17; if linked_515 == nil { arg_486 = ifn_516.Invoke_O_O__O(arg_517, arg_518) } else { arg_486 = linked_515.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_514, arg_517, arg_518) }
//line :154:1
		if linked_482 == nil { vec__400000108__19 = ifn_483.Invoke_O_O_O__O(arg_484, arg_485, arg_486) } else { vec__400000108__19 = linked_482.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_481, arg_484, arg_485, arg_486) }
//line :143:1
		var env__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000108__19, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000108__19, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp53 any = A_arbace_c2j_node_A_const_134; var tmp54 any; var root_523 any = A_arbace_c2j_node_A_const_78.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, A_arbace_c2j_node_q_body_A_fn_class); var ifn_525 lang.IFn
















		if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = env__20; var arg_527 any = body__18; if linked_524 == nil { tmp54 = ifn_525.Invoke_O_O__O(arg_526, arg_527) } else { tmp54 = linked_524.(*A_arbace_c2j_node_q_body_A).Invoke_O_O_O__O(root_523, arg_526, arg_527) }; return tmp52.Invoke_O_O_O__O(tmp53, binds__21, tmp54) }
//line :143:1
	case 56: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_133) { var vec__400000121__10 any = as__8; var c__11_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000121__10, lang.RT_IntCast_J__I_NoInit(0), nil); var m__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000121__10, lang.RT_IntCast_J__I_NoInit(1), nil); var f__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000121__10, lang.RT_IntCast_J__I_NoInit(2), nil); var fv__14 any; var root_519 any = A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_521 lang.IFn

























		if linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any = Lit_59; if linked_520 == nil { fv__14 = ifn_521.Invoke_O__O(arg_522) } else { fv__14 = linked_520.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_519, arg_522) }
		var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp56 any = A_arbace_c2j_node_A_const_142; var tmp57 any; var root_593 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, A_arbace_c2j_node_q_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = env__0; var arg_597 any = f__13; if linked_594 == nil { tmp57 = ifn_595.Invoke_O_O__O(arg_596, arg_597) } else { tmp57 = linked_594.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_593, arg_596, arg_597) }; var tmp58 any = lang.Tuple_Create_O_O__IPersistentVector(fv__14, tmp57); var tmp59 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp60 any = A_arbace_c2j_node_A_const_143; var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp62 any = A_arbace_c2j_node_A_const_144; var tmp63 any; var root_598 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, A_arbace_c2j_node_qs_A_fn_class); var ifn_600 lang.IFn
		if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = env__0; var arg_602 any = c__11_3; if linked_599 == nil { tmp63 = ifn_600.Invoke_O_O__O(arg_601, arg_602) } else { tmp63 = linked_599.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_598, arg_601, arg_602) }
//line :170:1
		var tmp64 any = tmp61.Invoke_O_O_O__O(tmp62, tmp63, A_arbace_c2j_node_A_const_120); var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp66 any = A_arbace_c2j_node_A_const_145; var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp68 any = A_arbace_c2j_node_A_const_146; var tmp69 any; var root_603 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_603, A_arbace_c2j_node_qs_A_fn_class); var ifn_605 lang.IFn
		if linked_604 == nil { ifn_605 = lang.IFn_Cast(root_603) } else { ifn_605 = nil }; var arg_606 any = env__0; var arg_607 any = m__12; if linked_604 == nil { tmp69 = ifn_605.Invoke_O_O__O(arg_606, arg_607) } else { tmp69 = linked_604.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_603, arg_606, arg_607) }
//line :170:1
		return tmp55.Invoke_O_O_O__O(tmp56, tmp58, tmp59.Invoke_O_O_O_O__O(tmp60, tmp64, tmp65.Invoke_O_O_O__O(tmp66, fv__14, tmp67.Invoke_O_O__O(tmp68, tmp69)), fv__14)) }
//line :143:1
	case 57: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_135) { var vec__400000124__10 any = as__8; var seq__400000125__11 any; var root_528 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_530 lang.IFn




































		if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = vec__400000124__10; if linked_529 == nil { seq__400000125__11 = ifn_530.Invoke_O__O(arg_531) } else { seq__400000125__11 = linked_529.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_528, arg_531) }
//line :143:1
		var first__400000126__12 any; var root_532 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_534 lang.IFn




































		if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = seq__400000125__11; if linked_533 == nil { first__400000126__12 = ifn_534.Invoke_O__O(arg_535) } else { first__400000126__12 = linked_533.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_532, arg_535) }
//line :143:1
		var seq__400000125__13 any; var root_536 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_538 lang.IFn




































		if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = seq__400000125__11; if linked_537 == nil { seq__400000125__13 = ifn_538.Invoke_O__O(arg_539) } else { seq__400000125__13 = linked_537.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_536, arg_539) }
//line :143:1
		var bv__14 any = first__400000126__12; var body__15 any = seq__400000125__13; var fresh__16 any; var root_540 any = A_arbace_c2j_node_A_const_49.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, A_arbace_c2j_node_runs_children_QMARK__A_fn_class); var ifn_542 lang.IFn





































		if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any; var root_544 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = A_arbace_c2j_node_A_const_136; var arg_548 any = body__15; if linked_545 == nil { arg_543 = ifn_546.Invoke_O_O__O(arg_547, arg_548) } else { arg_543 = linked_545.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_544, arg_547, arg_548) }; if linked_541 == nil { fresh__16 = ifn_542.Invoke_O__O(arg_543) } else { fresh__16 = linked_541.(*A_arbace_c2j_node_runs_children_QMARK__A).Invoke_O_O__O(root_540, arg_543) }
//line :143:1
		var vec__400000127__17 any; var root_549 any = A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_551 lang.IFn






































		if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any; var fnbody__587 any = A_arbace_c2j_node_q_seq_fn__400000132_A_New_O(fresh__16); var tmp70 *jrt.Class; var fncls__586 *jrt.Class = A_arbace_c2j_node_q_seq_fn__400000132_A_fn_class; if fncls__586 == nil { var fncls__586d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, fnbody__587); A_arbace_c2j_node_q_seq_fn__400000132_A_fn_class = fncls__586d; tmp70 = fncls__586d } else { tmp70 = fncls__586 }; arg_552 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__587, tmp70, nil); var arg_553 any = lang.Tuple_Create_O_O_O__IPersistentVector(env__0, lang.PersistentVector_EMPTY.Ref(), lang.PersistentVector_EMPTY.Ref()); var arg_554 any; var root_588 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_590 lang.IFn




		if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any = A_arbace_c2j_node_A_const_25; var arg_592 any = bv__14; if linked_589 == nil { arg_554 = ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { arg_554 = linked_589.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) }
//line :182:1
		if linked_550 == nil { vec__400000127__17 = ifn_551.Invoke_O_O_O__O(arg_552, arg_553, arg_554) } else { vec__400000127__17 = linked_550.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_549, arg_552, arg_553, arg_554) }
//line :143:1
		var env__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000127__17, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000127__17, lang.RT_IntCast_J__I_NoInit(1), nil); var lets__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000127__17, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp71 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp72 any = A_arbace_c2j_node_A_const_148; var tmp73 any; var root_608 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_609 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_608, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_610 lang.IFn












































		if linked_609 == nil { ifn_610 = lang.IFn_Cast(root_608) } else { ifn_610 = nil }; var arg_611 any = A_arbace_c2j_node_A_const_149; var arg_612 any = A_arbace_c2j_node_A_const_150; var arg_613 any; var root_615 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = A_arbace_c2j_node_A_const_151; var arg_619 any = lets__20; if linked_616 == nil { arg_613 = ifn_617.Invoke_O_O__O(arg_618, arg_619) } else { arg_613 = linked_616.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O__O(root_615, arg_618, arg_619) }; var arg_614 any; var root_620 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_620, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_622 lang.IFn; if linked_621 == nil { ifn_622 = lang.IFn_Cast(root_620) } else { ifn_622 = nil }; var arg_623 any = A_arbace_c2j_node_A_const_60.GetRawRoot__O(); var arg_624 any; var root_625 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any; var fnbody__636 any = A_arbace_c2j_node_q_seq_fn__400000140_A_New_O(env__18); var tmp74 *jrt.Class; var fncls__635 *jrt.Class = A_arbace_c2j_node_q_seq_fn__400000140_A_fn_class; if fncls__635 == nil { var fncls__635d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__636); A_arbace_c2j_node_q_seq_fn__400000140_A_fn_class = fncls__635d; tmp74 = fncls__635d } else { tmp74 = fncls__635 }; arg_628 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__636, tmp74, nil); var arg_629 any = body__15; if linked_626 == nil { arg_624 = ifn_627.Invoke_O_O__O(arg_628, arg_629) } else { arg_624 = linked_626.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_625, arg_628, arg_629) }; if linked_621 == nil { arg_614 = ifn_622.Invoke_O_O__O(arg_623, arg_624) } else { arg_614 = linked_621.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_620, arg_623, arg_624) }; if linked_609 == nil { tmp73 = ifn_610.Invoke_O_O_O_O__O(arg_611, arg_612, arg_613, arg_614) } else { tmp73 = linked_609.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O_O__O(root_608, arg_611, arg_612, arg_613, arg_614) }; return tmp71.Invoke_O_O_O__O(tmp72, binds__19, tmp73) }
//line :143:1
	case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__400000070__9_, A_arbace_c2j_node_A_const_147) { var vec__400000142__10 any = as__8; var m__11_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000142__10, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__12_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000142__10, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp75 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp76 any = A_arbace_c2j_node_A_const_152; var tmp77 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp78 any = A_arbace_c2j_node_A_const_153; var tmp79 any = A_arbace_c2j_node_A_const_154; var tmp80 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp81 any = A_arbace_c2j_node_A_const_155; var tmp82 any; var root_637 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, A_arbace_c2j_node_qs_A_fn_class); var ifn_639 lang.IFn








		if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = env__0; var arg_641 any = m__11_2; if linked_638 == nil { tmp82 = ifn_639.Invoke_O_O__O(arg_640, arg_641) } else { tmp82 = linked_638.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_637, arg_640, arg_641) }; var tmp83 *lang.Keyword = A_arbace_c2j_node_A_const_56; return tmp75.Invoke_O_O__O(tmp76, tmp77.Invoke_O_O_O_O__O(tmp78, tmp79, tmp80.Invoke_O_O__O(tmp81, tmp82), tmp83.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(xs__12_2)))) }
//line :143:1
	default:}; var vec__400000145__10 any; var root_375 any = A_arbace_c2j_node_A_const_81.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, A_arbace_c2j_node_q_elems_A_fn_class); var ifn_377 lang.IFn; if













































	linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = env__0; var arg_379 any = t__1; if linked_376 == nil { vec__400000145__10 = ifn_377.Invoke_O_O__O(arg_378, arg_379) } else { vec__400000145__10 = linked_376.(*A_arbace_c2j_node_q_elems_A).Invoke_O_O_O__O(root_375, arg_378, arg_379) }; var fixed__11 any = /*line :143:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__400000145__10, lang.RT_IntCast_J__I_NoInit(0), nil); var tail__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000145__10, lang.RT_IntCast_J__I_NoInit(1), nil); if














































	jrt.J2g_Truth(tail__12) {
		return lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_82), fixed__11, lang.Tuple_Create_O__IPersistentVector(tail__12)) } else {
			var root_386 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = A_arbace_c2j_node_A_const_84; var arg_390 any = fixed__11; if linked_387 == nil { return ifn_388.Invoke_O_O__O(arg_389, arg_390) } else { return linked_387.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_386, arg_389, arg_390) } } }
//line :154:1
func A_arbace_c2j_node_q_seq_fn__400000113_A_New() *A_arbace_c2j_node_q_seq_fn__400000113_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_fn__400000113_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_c2j_node_q_seq_fn__400000113_A) Ctor() {}
//line :154:1
func (t *A_arbace_c2j_node_q_seq_fn__400000113_A) Invoke_O_O_O__O(self, p__400000111__1, p__400000112__2 any) any { var vec__400000114__3 any = p__400000111__1; var env__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000114__3, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000114__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__400000117__6 any = p__400000112__2; var s__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000117__6, lang.RT_IntCast_J__I_NoInit(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000117__6, lang.RT_IntCast_J__I_NoInit(1), nil); var v__9 any; var root_487 any = A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_489 lang.IFn; if
															linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, s__7, nil)).Ref(); if linked_488 == nil { v__9 = ifn_489.Invoke_O__O(arg_490) } else { v__9 = linked_488.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_487, arg_490) }; var k__10 any; var tmp1 any = A_arbace_c2j_node_A_const_131; var tmp2 any; var root_491 any = /*line :154:1*/A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, A_arbace_c2j_node_head_A_fn_class); var ifn_493 lang.IFn; if

	linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = init__8; if linked_492 == nil { tmp2 = ifn_493.Invoke_O__O(arg_494) } else { tmp2 = linked_492.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_491, arg_494) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2) { k__10 = A_arbace_c2j_node_A_const_55 } else { k__10 = A_arbace_c2j_node_A_const_132 }; var tmp3 any; var root_495 any = /*line :154:1*/A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_495, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_497 lang.IFn; if


	linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = env__4; var arg_499 any = s__7; var arg_500 any; var tmp4 any = A_arbace_c2j_node_A_const_20; var tmp5 any = A_arbace_c2j_node_A_const_56; var tmp6 any = A_arbace_c2j_node_A_const_126; var tmp7 any; if lang.Util_Equiv_O_O__Z_NoInit(k__10, A_arbace_c2j_node_A_const_55) { var tmp8 *lang.Keyword = A_arbace_c2j_node_A_const_56; tmp7 = tmp8.Invoke_O__O(lang.IFn_Cast(env__4).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(init__8, lang.RT_IntCast_J__I_NoInit(2)))) } else { tmp7 = nil }; arg_500 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, k__10, tmp5, v__9, tmp6, tmp7)); if linked_496 == nil { tmp3 = ifn_497.Invoke_O_O_O__O(arg_498, arg_499, arg_500) } else { tmp3 = linked_496.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_495, arg_498, arg_499, arg_500) }; var tmp9 any = tmp3; var tmp10 lang.IFn = /*line :154:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp11 any; var root_507 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, A_arbace_c2j_node_q_A_fn_class); var ifn_509 lang.IFn; if



	linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any = env__4; var arg_511 any = init__8; if linked_508 == nil { tmp11 = ifn_509.Invoke_O_O__O(arg_510, arg_511) } else { tmp11 = linked_508.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_507, arg_510, arg_511) }; return /*line :154:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp9, tmp10.Invoke_O_O_O__O(binds__5, v__9, tmp11)) }












func A_arbace_c2j_node_q_seq_fn__400000084_A_New_O(p0 any) *A_arbace_c2j_node_q_seq_fn__400000084_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_fn__400000084_A{}; t.Ctor_O(p0); return t }
//line :167:1
func (t *A_arbace_c2j_node_q_seq_fn__400000084_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :167:1
func (t *A_arbace_c2j_node_q_seq_fn__400000084_A) Invoke_O_O__O(self, p__400000083__1 any) any { var vec__400000085__2 any = p__400000083__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000085__2, lang.RT_IntCast_J__I_NoInit(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000085__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_418 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_418, A_arbace_c2j_node_q_A_fn_class); var ifn_420 lang.IFn; if linked_419 == nil { ifn_420 = lang.IFn_Cast(root_418) } else { ifn_420 = nil }; var arg_421 any = t.F_env; var arg_422 any = f__4; if linked_419 == nil { tmp1 = ifn_420.Invoke_O_O__O(arg_421, arg_422) } else { tmp1 = linked_419.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_418, arg_421, arg_422) }; return lang.Tuple_Create_O_O__IPersistentVector(k__3, tmp1) }














func A_arbace_c2j_node_q_seq_fn__400000132_A_New_O(p0 any) *A_arbace_c2j_node_q_seq_fn__400000132_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_fn__400000132_A{}; t.Ctor_O(p0); return t }
//line :182:1
func (t *A_arbace_c2j_node_q_seq_fn__400000132_A) Ctor_O(c__fresh any) { t.F_fresh = c__fresh }
//line :182:1
func (t *A_arbace_c2j_node_q_seq_fn__400000132_A) Invoke_O_O_O__O(self, p__400000130__1, p__400000131__2 any) any { var vec__400000133__3 any = p__400000130__1; var env__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000133__3, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000133__3, lang.RT_IntCast_J__I_NoInit(1), nil); var lets__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000133__3, lang.RT_IntCast_J__I_NoInit(2), nil); var vec__400000136__7 any = p__400000131__2; var s__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000136__7, lang.RT_IntCast_J__I_NoInit(0), nil); var init__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000136__7, lang.RT_IntCast_J__I_NoInit(1), nil); var v__10 any; var root_555 any = A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_557 lang.IFn; if
															linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, s__8, nil)).Ref(); if linked_556 == nil { v__10 = ifn_557.Invoke_O__O(arg_558) } else { v__10 = linked_556.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_555, arg_558) }; var tmp1 any; var root_559 any = /*line :182:1*/A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_561 lang.IFn; if

	linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = env__4; var arg_563 any = s__8; var arg_564 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_137, A_arbace_c2j_node_A_const_56, v__10)); if linked_560 == nil { tmp1 = ifn_561.Invoke_O_O_O__O(arg_562, arg_563, arg_564) } else { tmp1 = linked_560.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_559, arg_562, arg_563, arg_564) }; var tmp2 any = tmp1; var tmp3 lang.IFn = /*line :182:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp4 any; if


	jrt.J2g_Truth(t.F_fresh) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_node_A_const_138; var tmp7 any = A_arbace_c2j_node_A_const_139; tmp4 = tmp5.Invoke_O_O_O__O(tmp6, tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_62), jrt.RefArrayOf(jrt.Object_class, s__8, nil)).Ref()) } else { var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_node_A_const_140; var tmp10 any; var root_571 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_62), jrt.RefArrayOf(jrt.Object_class, s__8, nil)).Ref(); if linked_572 == nil { tmp10 = ifn_573.Invoke_O__O(arg_574) } else { tmp10 = linked_572.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_571, arg_574) }; tmp4 = tmp8.Invoke_O_O__O(tmp9, tmp10) }; var tmp11 any = /*line :182:1*/tmp3.Invoke_O_O_O__O(binds__5, v__10, tmp4); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp13 any; var root_581 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, A_arbace_c2j_node_q_A_fn_class); var ifn_583 lang.IFn; if



	linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = env__4; var arg_585 any = init__9; if linked_582 == nil { tmp13 = ifn_583.Invoke_O_O__O(arg_584, arg_585) } else { tmp13 = linked_582.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_581, arg_584, arg_585) }; return /*line :182:1*/ lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, tmp11, tmp12.Invoke_O_O_O__O(lets__6, v__10, tmp13)) }





func A_arbace_c2j_node_q_seq_fn__400000140_A_New_O(p0 any) *A_arbace_c2j_node_q_seq_fn__400000140_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_seq_fn__400000140_A{}; t.Ctor_O(p0); return t }
//line :188:1
func (t *A_arbace_c2j_node_q_seq_fn__400000140_A) Ctor_O(c__env any) { t.F_env = c__env }
//line :188:1
func (t *A_arbace_c2j_node_q_seq_fn__400000140_A) Invoke_O_O__O(self, p1__400000066_SHARP___1 any) any { var root_630 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, A_arbace_c2j_node_q_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = t.F_env; var arg_634 any = p1__400000066_SHARP___1; if linked_631 == nil { return ifn_632.Invoke_O_O__O(arg_633, arg_634) } else { return linked_631.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_630, arg_633, arg_634) } }





func A_arbace_c2j_node_q_A_New() *A_arbace_c2j_node_q_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_q_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_c2j_node_q_A) Ctor() {}
//line :194:1
func (t *A_arbace_c2j_node_q_A) Invoke_O_O_O__O(self, env__0, t__1 any) any {


	var tmp1 any; var root_642 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_644 lang.IFn
	if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = t__1; if linked_643 == nil { tmp1 = ifn_644.Invoke_O__O(arg_645) } else { tmp1 = linked_643.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_642, arg_645) }
//line :197:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000408__auto____3 any = lang.IFn_Cast(env__0).Invoke_O__O(t__1)
		if jrt.J2g_Truth(temp__1927000408__auto____3) { var b__4 any = temp__1927000408__auto____3; var G__400000149__5_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__4)
			switch lang.Util_Hash_O__I_NoInit(G__400000149__5_) >> 2 & 3 { case 0: if any(G__400000149__5_) == any(A_arbace_c2j_node_A_const_156) {
				var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_node_A_const_159; var tmp4 any = A_arbace_c2j_node_A_const_160; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_node_A_const_161; return tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4), tmp5.Invoke_O_O__O(tmp6, A_arbace_c2j_node_A_const_162.Invoke_O__O(b__4))) }
//line :199:1
			case 2: if any(G__400000149__5_) == any(A_arbace_c2j_node_A_const_137) {

				return A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4) }
//line :199:1
			case 3: if any(G__400000149__5_) == any(A_arbace_c2j_node_A_const_132) {

				return A_arbace_c2j_node_A_const_56.Invoke_O__O(b__4) }
//line :199:1
			default:}; var tmp7 any; var root_647 any = A_arbace_c2j_node_A_const_157.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_649 lang.IFn


			if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_52, nil, Lit_53), jrt.RefArrayOf(jrt.Object_class, nil, t__1, nil)).Ref(); var arg_651 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_648 == nil { tmp7 = ifn_649.Invoke_O_O__O(arg_650, arg_651) } else { tmp7 = linked_648.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_647, arg_650, arg_651) }
//line :199:1
			panic(jrt.Thrown(jrt.Throwable_Cast(tmp7))) } else {



				return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_163, t__1) } } else {
//line :197:1
					var tmp8 any; var root_652 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_654 lang.IFn






					if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = t__1; if linked_653 == nil { tmp8 = ifn_654.Invoke_O__O(arg_655) } else { tmp8 = linked_653.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_652, arg_655) }
//line :197:1
					if jrt.J2g_Truth(tmp8) {






						var root_656 any = A_arbace_c2j_node_A_const_158.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, A_arbace_c2j_node_q_seq_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = env__0; var arg_660 any = t__1; if linked_657 == nil { return ifn_658.Invoke_O_O__O(arg_659, arg_660) } else { return linked_657.(*A_arbace_c2j_node_q_seq_A).Invoke_O_O_O__O(root_656, arg_659, arg_660) } } else {
//line :197:1
							var tmp9 any; var root_661 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_663 lang.IFn







							if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = t__1; if linked_662 == nil { tmp9 = ifn_663.Invoke_O__O(arg_664) } else { tmp9 = linked_662.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_661, arg_664) }
//line :197:1
							if jrt.J2g_Truth(tmp9) { var vec__400000150__3 any; var root_665 any = A_arbace_c2j_node_A_const_81.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, A_arbace_c2j_node_q_elems_A_fn_class); var ifn_667 lang.IFn







								if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = env__0; var arg_669 any = t__1; if linked_666 == nil { vec__400000150__3 = ifn_667.Invoke_O_O__O(arg_668, arg_669) } else { vec__400000150__3 = linked_666.(*A_arbace_c2j_node_q_elems_A).Invoke_O_O_O__O(root_665, arg_668, arg_669) }
//line :197:1
								var fixed__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000150__3, lang.RT_IntCast_J__I_NoInit(0), nil); var tail__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000150__3, lang.RT_IntCast_J__I_NoInit(1), nil)








								if jrt.J2g_Truth(tail__5) { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp11 any = A_arbace_c2j_node_A_const_164; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_node_A_const_165; var tmp14 any; var root_670 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_670, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_672 lang.IFn; if linked_671 == nil { ifn_672 = lang.IFn_Cast(root_670) } else { ifn_672 = nil }; var arg_673 any = fixed__4; if linked_671 == nil { tmp14 = ifn_672.Invoke_O__O(arg_673) } else { tmp14 = linked_671.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_670, arg_673) }; return tmp10.Invoke_O_O__O(tmp11, tmp12.Invoke_O_O_O__O(tmp13, tmp14, tail__5)) } else { return fixed__4 } } else {
//line :197:1
									if A_arbace_c2j_node_A_const_45 != nil { return t__1 } else { return nil
									}
								}
						}
				}
}






func A_arbace_c2j_node_emit_fn_A_New() *A_arbace_c2j_node_emit_fn_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_emit_fn_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_c2j_node_emit_fn_A) Ctor() {}
//line :209:1
func (t *A_arbace_c2j_node_emit_fn_A) Invoke_O_O__O(self, d__0 any) any { var fields__2 any; var root_674 any = A_arbace_c2j_node_A_const_166.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, A_arbace_c2j_node_field_names_A_fn_class); var ifn_676 lang.IFn; if


	linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = d__0; if linked_675 == nil { fields__2 = ifn_676.Invoke_O__O(arg_677) } else { fields__2 = linked_675.(*A_arbace_c2j_node_field_names_A).Invoke_O_O__O(root_674, arg_677) }; var ev__3 any; var root_678 any = /*line :209:1*/A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_680 lang.IFn; if



	linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = Lit_41; if linked_679 == nil { ev__3 = ifn_680.Invoke_O__O(arg_681) } else { ev__3 = linked_679.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_678, arg_681) }; var chv__4 any; var root_682 any = /*line :209:1*/A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_684 lang.IFn; if




	linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = Lit_42; if linked_683 == nil { chv__4 = ifn_684.Invoke_O__O(arg_685) } else { chv__4 = linked_683.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_682, arg_685) }; var env0__5 any; var root_686 any = /*line :209:1*/A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_688 lang.IFn; if





	linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var tmp1 any = A_arbace_c2j_node_A_const_167; var tmp2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_168, A_arbace_c2j_node_A_const_56, chv__4)); var tmp3 any = A_arbace_c2j_node_A_const_169; var arg_689 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_170, A_arbace_c2j_node_A_const_56, ev__3)))); var arg_690 any; var root_691 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_692 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_691, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_693 lang.IFn; if
	linked_692 == nil { ifn_693 = lang.IFn_Cast(root_691) } else { ifn_693 = nil }; var arg_694 any; var fnbody__701 any = A_arbace_c2j_node_emit_fn_fn__400000157_A_New(); var tmp4 *jrt.Class; var fncls__700 *jrt.Class = A_arbace_c2j_node_emit_fn_fn__400000157_A_fn_class; if fncls__700 == nil { var fncls__700d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); A_arbace_c2j_node_emit_fn_fn__400000157_A_fn_class = fncls__700d; tmp4 = fncls__700d } else { tmp4 = fncls__700 }; arg_694 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__701, tmp4, nil); var arg_695 any = fields__2; if linked_692 == nil { arg_690 = ifn_693.Invoke_O_O__O(arg_694, arg_695) } else { arg_690 = linked_692.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_691, arg_694, arg_695) }; if /*line :215:1*/ linked_687 == nil { env0__5 = ifn_688.Invoke_O_O__O(arg_689, arg_690) } else { env0__5 = linked_687.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_686, arg_689, arg_690) }; var vec__400000154__6 any; var root_702 any = /*line :209:1*/A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_704 lang.IFn; if







	linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any; var fnbody__819 any = A_arbace_c2j_node_emit_fn_fn__400000161_A_New(); var tmp5 *jrt.Class; var fncls__818 *jrt.Class = A_arbace_c2j_node_emit_fn_fn__400000161_A_fn_class; if fncls__818 == nil { var fncls__818d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_c2j_node_emit_fn_fn__400000161_A_fn_class = fncls__818d; tmp5 = fncls__818d } else { tmp5 = fncls__818 }; arg_705 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__819, tmp5, nil); var arg_706 any = lang.Tuple_Create_O_O__IPersistentVector(env0__5, lang.PersistentVector_EMPTY.Ref()); var arg_707 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_703 == nil { vec__400000154__6 = ifn_704.Invoke_O_O_O__O(arg_705, arg_706, arg_707) } else { vec__400000154__6 = linked_703.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_702, arg_705, arg_706, arg_707) }; var env__7 any = /*line :209:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__400000154__6, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000154__6, lang.RT_IntCast_J__I_NoInit(1), nil); var body__9 any; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp7 any = A_arbace_c2j_node_A_const_183; var tmp8 any; var root_820 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_821 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_820, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_822 lang.IFn; if
















	linked_821 == nil { ifn_822 = lang.IFn_Cast(root_820) } else { ifn_822 = nil }; var arg_823 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp10 any; var root_831 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = ev__3; var arg_835 any = A_arbace_c2j_node_A_const_184; if linked_832 == nil { tmp10 = ifn_833.Invoke_O_O__O(arg_834, arg_835) } else { tmp10 = linked_832.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_831, arg_834, arg_835) }; var tmp11 any = lang.Tuple_Create_O_O__IPersistentVector(tmp10, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_185, A_arbace_c2j_node_A_const_186)); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp13 *lang.Compiler_AOTFn; var fnbody__850 any = A_arbace_c2j_node_emit_fn_fn__400000169_A_New_O(env0__5); var tmp14 *jrt.Class; var fncls__849 *jrt.Class = A_arbace_c2j_node_emit_fn_fn__400000169_A_fn_class; if
	fncls__849 == nil { var fncls__849d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__850); A_arbace_c2j_node_emit_fn_fn__400000169_A_fn_class = fncls__849d; tmp14 = fncls__849d } else { tmp14 = fncls__849 }; tmp13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__850, tmp14, nil); var tmp15 lang.IFn = /*line :226:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp16 any = A_arbace_c2j_node_A_const_190; var tmp17 any = A_arbace_c2j_node_A_const_191; arg_823 = tmp9.Invoke_O_O_O_O__O(tmp11, tmp12.Invoke_O_O__O(tmp13.Ref(), fields__2), lang.Tuple_Create_O_O__IPersistentVector(chv__4, tmp15.Invoke_O_O_O_O__O(tmp16, tmp17, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_192, A_arbace_c2j_node_A_const_193), A_arbace_c2j_node_A_const_120)), binds__8); if linked_821 == nil { tmp8 = ifn_822.Invoke_O__O(arg_823) } else { tmp8 = linked_821.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_820, arg_823) }; var tmp18 any = tmp8; var tmp19 any; var root_851 any = A_arbace_c2j_node_A_const_53.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_851, A_arbace_c2j_node_q_A_fn_class); var ifn_853 lang.IFn; if



	linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; var arg_854 any = env__7; var arg_855 any = A_arbace_c2j_node_A_const_26.Invoke_O__O(d__0); if linked_852 == nil { tmp19 = ifn_853.Invoke_O_O__O(arg_854, arg_855) } else { tmp19 = linked_852.(*A_arbace_c2j_node_q_A).Invoke_O_O_O__O(root_851, arg_854, arg_855) }; body__9 = /*line :226:1*/tmp6.Invoke_O_O_O__O(tmp7, tmp18, tmp19); var tmp20 lang.IFn =




	lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp21 any = A_arbace_c2j_node_A_const_194; var tmp22 any; var root_856 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_node_A_const_13.Invoke_O__O(d__0))).Ref(); if linked_857 == nil { tmp22 = ifn_858.Invoke_O__O(arg_859) } else { tmp22 = linked_857.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_856, arg_859) }; var tmp23 any = tmp22; var tmp24 any = A_arbace_c2j_node_A_const_195; var tmp25 any; var tmp26 *lang.Keyword = A_arbace_c2j_node_A_const_196; var temp__1927000408__auto____10 any = tmp26.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0)); if
	jrt.J2g_Truth(temp__1927000408__auto____10) { var r__11 any = temp__1927000408__auto____10; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp28 any = A_arbace_c2j_node_A_const_197
		tmp25 = tmp27.Invoke_O_O_O__O(tmp28, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O_O__O(r__11, A_arbace_c2j_node_A_const_198, A_arbace_c2j_node_A_const_199, A_arbace_c2j_node_A_const_200), body__9) } else {
//line :232:1
			tmp25 = body__9 }; return /*line :231:1*/ tmp20.Invoke_O_O_O_O__O(tmp21, tmp23, tmp24, tmp25) }
//line :216:1
func A_arbace_c2j_node_emit_fn_fn__400000157_A_New() *A_arbace_c2j_node_emit_fn_fn__400000157_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_emit_fn_fn__400000157_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000157_A) Ctor() {}
//line :216:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000157_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 any = A_arbace_c2j_node_A_const_20; var tmp2 any = A_arbace_c2j_node_A_const_171; var tmp3 any = A_arbace_c2j_node_A_const_56; var tmp4 any; var root_696 any = A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, f__1, nil)).Ref(); if linked_697 == nil { tmp4 = ifn_698.Invoke_O__O(arg_699) } else { tmp4 = linked_697.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_696, arg_699) }; return lang.Tuple_Create_O_O__IPersistentVector(f__1, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, tmp4))) }
func A_arbace_c2j_node_emit_fn_fn__400000161_A_New() *A_arbace_c2j_node_emit_fn_fn__400000161_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_emit_fn_fn__400000161_A{}; t.Ctor(); return t }
//line :217:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000161_A) Ctor() {}
//line :217:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000161_A) Invoke_O_O_O__O(self, p__400000159__1, p__400000160__2 any) any { var vec__400000162__3 any = p__400000159__1; var env__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000162__3, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000162__3, lang.RT_IntCast_J__I_NoInit(1), nil); var map__400000165__6 any = p__400000160__2; var map__400000165__7 any; if lang.ISeq_InstanceOf(map__400000165__6) { var tmp1 any; var root_708 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any = map__400000165__6; if linked_709 == nil { tmp1 = ifn_710.Invoke_O__O(arg_711) } else { tmp1 = linked_709.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_708, arg_711) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_712 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = map__400000165__6; if linked_713 == nil { tmp2 = ifn_714.Invoke_O__O(arg_715) } else { tmp2 = linked_713.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_712, arg_715) }; map__400000165__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_716 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = map__400000165__6; if linked_717 == nil { tmp3 = ifn_718.Invoke_O__O(arg_719) } else { tmp3 = linked_717.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_716, arg_719) }; if jrt.J2g_Truth(tmp3) { var root_720 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = map__400000165__6; if linked_721 == nil { map__400000165__7 = ifn_722.Invoke_O__O(arg_723) } else { map__400000165__7 = linked_721.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_720, arg_723) } } else { map__400000165__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000165__7 = map__400000165__6 }; var sym__8 any = lang.RT_Get_O_O__O_NoInit(map__400000165__7, A_arbace_c2j_node_A_const_19); var k__9 any = lang.RT_Get_O_O__O_NoInit(map__400000165__7, A_arbace_c2j_node_A_const_20); var args__10 any = lang.RT_Get_O_O__O_NoInit(map__400000165__7, A_arbace_c2j_node_A_const_21); var v__11 any; var root_724 any = A_arbace_c2j_node_A_const_130.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_726 lang.IFn; if
															linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_47), jrt.RefArrayOf(jrt.Object_class, sym__8, nil)).Ref(); if linked_725 == nil { v__11 = ifn_726.Invoke_O__O(arg_727) } else { v__11 = linked_725.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_724, arg_727) }; var G__400000167__12_ any = k__9; switch
															lang.Util_Hash_O__I_NoInit(G__400000167__12_) >> 8 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__400000167__12_, A_arbace_c2j_node_A_const_173) { var tmp4 any; var root_729 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_730 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_729, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_731 lang.IFn




		if linked_730 == nil { ifn_731 = lang.IFn_Cast(root_729) } else { ifn_731 = nil }; var arg_732 any = env__4; var arg_733 any = sym__8; var arg_734 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_177, A_arbace_c2j_node_A_const_56, v__11)); if linked_730 == nil { tmp4 = ifn_731.Invoke_O_O_O__O(arg_732, arg_733, arg_734) } else { tmp4 = linked_730.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_729, arg_732, arg_733, arg_734) }
//line :219:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp4, lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(binds__5, v__11, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_178, A_arbace_c2j_node_A_const_179, A_arbace_c2j_node_A_const_180))) }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__400000167__12_, A_arbace_c2j_node_A_const_174) { var tmp5 any; var root_741 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_742 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_741, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_743 lang.IFn



			if linked_742 == nil { ifn_743 = lang.IFn_Cast(root_741) } else { ifn_743 = nil }; var arg_744 any = env__4; var arg_745 any = sym__8; var arg_746 any; var tmp6 any = A_arbace_c2j_node_A_const_20; var tmp7 any = A_arbace_c2j_node_A_const_156; var tmp8 any = A_arbace_c2j_node_A_const_56; var tmp9 any = A_arbace_c2j_node_A_const_162; var tmp10 any; var root_747 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_747, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_749 lang.IFn; if linked_748 == nil { ifn_749 = lang.IFn_Cast(root_747) } else { ifn_749 = nil }; var arg_750 any = args__10; if linked_748 == nil { tmp10 = ifn_749.Invoke_O__O(arg_750) } else { tmp10 = linked_748.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_747, arg_750) }; arg_746 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, v__11, tmp9, tmp10)); if linked_742 == nil { tmp5 = ifn_743.Invoke_O_O_O__O(arg_744, arg_745, arg_746) } else { tmp5 = linked_742.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_741, arg_744, arg_745, arg_746) }
//line :219:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp5, lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(binds__5, v__11, nil)) }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000167__12_, A_arbace_c2j_node_A_const_175) { var tmp11 any; var root_757 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_759 lang.IFn
				if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any = env__4; var arg_761 any = sym__8; var arg_762 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_181, A_arbace_c2j_node_A_const_56, v__11)); if linked_758 == nil { tmp11 = ifn_759.Invoke_O_O_O__O(arg_760, arg_761, arg_762) } else { tmp11 = linked_758.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_757, arg_760, arg_761, arg_762) }
//line :219:1
				var tmp12 any = tmp11; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp14 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp15 lang.IFn = lang.IFn_Cast(env__4); var tmp16 any; var root_769 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_771 lang.IFn
				if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = args__10; if linked_770 == nil { tmp16 = ifn_771.Invoke_O__O(arg_772) } else { tmp16 = linked_770.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_769, arg_772) }
//line :219:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13.Invoke_O_O_O__O(binds__5, v__11, tmp14.Invoke_O__O(tmp15.Invoke_O__O(tmp16)))) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__400000167__12_, A_arbace_c2j_node_A_const_176) { var tmp17 any; var root_773 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_775 lang.IFn

					if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = env__4; var arg_777 any = sym__8; var arg_778 any; var tmp18 any = A_arbace_c2j_node_A_const_20; var tmp19 any = A_arbace_c2j_node_A_const_126; var tmp20 any = A_arbace_c2j_node_A_const_56; var tmp21 any = A_arbace_c2j_node_A_const_71; var tmp22 any; var root_779 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_779, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_781 lang.IFn; if linked_780 == nil { ifn_781 = lang.IFn_Cast(root_779) } else { ifn_781 = nil }; var arg_782 any = args__10; if linked_780 == nil { tmp22 = ifn_781.Invoke_O__O(arg_782) } else { tmp22 = linked_780.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_779, arg_782) }; arg_778 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp19, tmp20, v__11, tmp21, tmp22)); if linked_774 == nil { tmp17 = ifn_775.Invoke_O_O_O__O(arg_776, arg_777, arg_778) } else { tmp17 = linked_774.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_773, arg_776, arg_777, arg_778) }
//line :219:1
					var tmp23 any = tmp17; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp25 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp26 lang.IFn = lang.IFn_Cast(env__4); var tmp27 any; var root_789 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_789, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_791 lang.IFn

					if linked_790 == nil { ifn_791 = lang.IFn_Cast(root_789) } else { ifn_791 = nil }; var arg_792 any = args__10; if linked_790 == nil { tmp27 = ifn_791.Invoke_O__O(arg_792) } else { tmp27 = linked_790.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_789, arg_792) }
//line :219:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp23, tmp24.Invoke_O_O_O__O(binds__5, v__11, tmp25.Invoke_O__O(tmp26.Invoke_O__O(tmp27)))) }; case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__400000167__12_, A_arbace_c2j_node_A_const_182) { var tmp28 any; var root_793 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_795 lang.IFn


						if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = env__4; var arg_797 any = sym__8; var arg_798 any; var tmp29 any = A_arbace_c2j_node_A_const_20; var tmp30 any = A_arbace_c2j_node_A_const_156; var tmp31 any = A_arbace_c2j_node_A_const_56; var tmp32 any = A_arbace_c2j_node_A_const_162; var tmp33 any; var root_799 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = args__10; if linked_800 == nil { tmp33 = ifn_801.Invoke_O__O(arg_802) } else { tmp33 = linked_800.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_799, arg_802) }; arg_798 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30, tmp31, v__11, tmp32, tmp33)); if linked_794 == nil { tmp28 = ifn_795.Invoke_O_O_O__O(arg_796, arg_797, arg_798) } else { tmp28 = linked_794.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_793, arg_796, arg_797, arg_798) }
//line :219:1
						var tmp34 any = tmp28; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()); var tmp36 any; var root_809 any = A_arbace_c2j_node_A_const_98.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, A_arbace_c2j_node_qs_A_fn_class); var ifn_811 lang.IFn


						if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any = env__4; var arg_813 any; var root_814 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = args__10; if linked_815 == nil { arg_813 = ifn_816.Invoke_O__O(arg_817) } else { arg_813 = linked_815.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_814, arg_817) }; if linked_810 == nil { tmp36 = ifn_811.Invoke_O_O__O(arg_812, arg_813) } else { tmp36 = linked_810.(*A_arbace_c2j_node_qs_A).Invoke_O_O_O__O(root_809, arg_812, arg_813) }
//line :219:1
						return lang.Tuple_Create_O_O__IPersistentVector(tmp34, tmp35.Invoke_O_O_O__O(binds__5, v__11, tmp36)) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__400000167__12_))))) }







func A_arbace_c2j_node_emit_fn_fn__400000169_A_New_O(p0 any) *A_arbace_c2j_node_emit_fn_fn__400000169_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_emit_fn_fn__400000169_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000169_A) Ctor_O(c__env0 any) { t.F_env0 = c__env0 }
//line :227:1
func (t *A_arbace_c2j_node_emit_fn_fn__400000169_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_56; var tmp2 any = tmp1.Invoke_O__O(lang.IFn_Cast(t.F_env0).Invoke_O__O(f__1)); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp4 any; var root_841 any = A_arbace_c2j_node_A_const_187.GetRawRoot__O(); var linked_842 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_841, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_843 lang.IFn; if linked_842 == nil { ifn_843 = lang.IFn_Cast(root_841) } else { ifn_843 = nil }; var arg_844 any; var root_845 any = A_arbace_c2j_node_A_const_188.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any = f__1; if linked_846 == nil { arg_844 = ifn_847.Invoke_O__O(arg_848) } else { arg_844 = linked_846.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_845, arg_848) }; if linked_842 == nil { tmp4 = ifn_843.Invoke_O__O(arg_844) } else { tmp4 = linked_842.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_841, arg_844) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3.Invoke_O_O__O(tmp4, A_arbace_c2j_node_A_const_189)) }








func A_arbace_c2j_node_defnode_A_New() *A_arbace_c2j_node_defnode_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_defnode_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_c2j_node_defnode_A) Ctor() {}
//line :236:1
func (t *A_arbace_c2j_node_defnode_A) Invoke_O_O_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, kind__2, doc__3, opts__4, bindings__5, template__6 any) any { var d__8 any; var root_860 any = A_arbace_c2j_node_A_const_201.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, A_arbace_c2j_node_parse_A_fn_class); var ifn_862 lang.IFn; if



	linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any = kind__2; var arg_864 any = doc__3; var arg_865 any = opts__4; var arg_866 any = bindings__5; var arg_867 any = template__6; if linked_861 == nil { d__8 = ifn_862.Invoke_O_O_O_O_O__O(arg_863, arg_864, arg_865, arg_866, arg_867) } else { d__8 = linked_861.(*A_arbace_c2j_node_parse_A).Invoke_O_O_O_O_O_O__O(root_860, arg_863, arg_864, arg_865, arg_866, arg_867) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_202; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_node_A_const_205; var tmp5 any = tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_206, d__8)); var tmp6 any; var tmp7 *lang.Keyword = A_arbace_c2j_node_A_const_203; if

	jrt.J2g_Truth(tmp7.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__8))) { tmp6 = nil } else { var root_868 any = A_arbace_c2j_node_A_const_204.GetRawRoot__O(); var linked_869 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_868, A_arbace_c2j_node_emit_fn_A_fn_class); var ifn_870 lang.IFn; if linked_869 == nil { ifn_870 = lang.IFn_Cast(root_868) } else { ifn_870 = nil }; var arg_871 any = d__8; if linked_869 == nil { tmp6 = ifn_870.Invoke_O__O(arg_871) } else { tmp6 = linked_869.(*A_arbace_c2j_node_emit_fn_A).Invoke_O_O__O(root_868, arg_871) } }; return /*line :241:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6) }






























func A_arbace_c2j_node_invalid_A_New() *A_arbace_c2j_node_invalid_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_invalid_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_c2j_node_invalid_A) Ctor() {}
//line :272:1
func (t *A_arbace_c2j_node_invalid_A) Invoke_O__O(self any) any { var tmp1 any; var root_872 any = A_arbace_c2j_node_A_const_157.GetRawRoot__O(); var linked_873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_872, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_874 lang.IFn; if linked_873 == nil { ifn_874 = lang.IFn_Cast(root_872) } else { ifn_874 = nil }; var arg_875 any = Lit_50; var arg_876 any = A_arbace_c2j_node_A_const_207; if linked_873 == nil { tmp1 = ifn_874.Invoke_O_O__O(arg_875, arg_876) } else { tmp1 = linked_873.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_872, arg_875, arg_876) }; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }

func A_arbace_c2j_node_realize_A_New() *A_arbace_c2j_node_realize_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_realize_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_c2j_node_realize_A) Ctor() {}
//line :274:1
func (t *A_arbace_c2j_node_realize_A) Invoke_O_O__O(self, f__0 any) any {



	var tmp1 any; var root_877 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_879 lang.IFn
	if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = f__0; if linked_878 == nil { tmp1 = ifn_879.Invoke_O__O(arg_880) } else { tmp1 = linked_878.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_877, arg_880) }
//line :278:1
	if jrt.J2g_Truth(tmp1) {
		var root_881 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_881, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_883 lang.IFn; if linked_882 == nil { ifn_883 = lang.IFn_Cast(root_881) } else { ifn_883 = nil }; var arg_884 any; var root_886 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = A_arbace_c2j_node_A_const_39.GetRawRoot__O(); var arg_890 any; var root_891 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = A_arbace_c2j_node_A_const_208.GetRawRoot__O(); var arg_895 any = f__0; if linked_892 == nil { arg_890 = ifn_893.Invoke_O_O__O(arg_894, arg_895) } else { arg_890 = linked_892.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_891, arg_894, arg_895) }; if linked_887 == nil { arg_884 = ifn_888.Invoke_O_O__O(arg_889, arg_890) } else { arg_884 = linked_887.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_886, arg_889, arg_890) }; var arg_885 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__0); if linked_882 == nil { return ifn_883.Invoke_O_O__O(arg_884, arg_885) } else { return linked_882.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_881, arg_884, arg_885) } } else {
//line :278:1
			var tmp2 any; var root_896 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_898 lang.IFn

			if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = f__0; if linked_897 == nil { tmp2 = ifn_898.Invoke_O__O(arg_899) } else { tmp2 = linked_897.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_896, arg_899) }
//line :278:1
			if jrt.J2g_Truth(tmp2) {

				var root_900 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any; var root_905 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_905, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = A_arbace_c2j_node_A_const_208.GetRawRoot__O(); var arg_909 any = f__0; if linked_906 == nil { arg_903 = ifn_907.Invoke_O_O__O(arg_908, arg_909) } else { arg_903 = linked_906.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_905, arg_908, arg_909) }; var arg_904 any = lang.RT_Meta_O__IPersistentMap_NoInit(f__0); if linked_901 == nil { return ifn_902.Invoke_O_O__O(arg_903, arg_904) } else { return linked_901.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_900, arg_903, arg_904) } } else {
//line :278:1
					if A_arbace_c2j_node_A_const_45 != nil { return f__0 } else { return nil
					}
				}
		}
}
func A_arbace_c2j_node_arg_kind_A_New() *A_arbace_c2j_node_arg_kind_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_arg_kind_A{}; t.Ctor(); return t }
//line :283:1
func (t *A_arbace_c2j_node_arg_kind_A) Ctor() {}
//line :283:1
func (t *A_arbace_c2j_node_arg_kind_A) Invoke_O_O__O(self, c__0 any) any {



	if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Long_TYPE.Ref()) { return A_arbace_c2j_node_A_const_110 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Integer_TYPE.Ref()) { return A_arbace_c2j_node_A_const_209 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Double_TYPE.Ref()) { return A_arbace_c2j_node_A_const_109 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Boolean_TYPE.Ref()) { return A_arbace_c2j_node_A_const_107 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Byte_TYPE.Ref()) { return A_arbace_c2j_node_A_const_210 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Short_TYPE.Ref()) { return A_arbace_c2j_node_A_const_211 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Character_TYPE.Ref()) { return A_arbace_c2j_node_A_const_212 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Float_TYPE.Ref()) { return A_arbace_c2j_node_A_const_213 } else { if A_arbace_c2j_node_A_const_45 != nil { return A_arbace_c2j_node_A_const_120 } else { return nil
	}
	} } } } } } } } }
func A_arbace_c2j_node_ret_chans_A_New() *A_arbace_c2j_node_ret_chans_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_ret_chans_A{}; t.Ctor(); return t }
//line :290:1
func (t *A_arbace_c2j_node_ret_chans_A) Ctor() {}
//line :290:1
func (t *A_arbace_c2j_node_ret_chans_A) Invoke_O_O__O(self, c__0 any) any {



	var tmp1 bool; var or__1927000174__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Long_TYPE.Ref()); if or__1927000174__auto____2 { tmp1 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Integer_TYPE.Ref()); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Byte_TYPE.Ref()); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Short_TYPE.Ref()); if or__1927000174__auto____5 { tmp1 = or__1927000174__auto____5 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Character_TYPE.Ref()) } } } }; if tmp1 { return A_arbace_c2j_node_A_const_214 } else { var tmp2 bool; var or__1927000174__auto____2_2 bool = lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Double_TYPE.Ref())
		if or__1927000174__auto____2_2 { tmp2 = or__1927000174__auto____2_2 } else { tmp2 = lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Float_TYPE.Ref()) }
//line :294:1
		if tmp2 { return A_arbace_c2j_node_A_const_215 } else { if lang.Util_Equiv_O_O__Z_NoInit(c__0, jrt.Boolean_TYPE.Ref()) { return A_arbace_c2j_node_A_const_216 } else { if A_arbace_c2j_node_A_const_45 != nil { return A_arbace_c2j_node_A_const_217 } else { return nil
		}
		}
		}
	} }
func A_arbace_c2j_node_qe_elems_A_New() *A_arbace_c2j_node_qe_elems_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_elems_A{}; t.Ctor(); return t }
//line :299:1
func (t *A_arbace_c2j_node_qe_elems_A) Ctor() {}
//line :299:1
func (t *A_arbace_c2j_node_qe_elems_A) Invoke_O_O_O_O__O(self, env__0, v__1, xs__2 any) any {
	var root_910 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_911 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_910, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_912 lang.IFn; if linked_911 == nil { ifn_912 = lang.IFn_Cast(root_910) } else { ifn_912 = nil }; var arg_913 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp2 *lang.Compiler_AOTFn; var fnbody__941 any = A_arbace_c2j_node_qe_elems_fn__400000181_A_New_O_O(env__0, v__1); var tmp3 *jrt.Class; var fncls__940 *jrt.Class = A_arbace_c2j_node_qe_elems_fn__400000181_A_fn_class; if fncls__940 == nil { var fncls__940d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, fnbody__941); A_arbace_c2j_node_qe_elems_fn__400000181_A_fn_class = fncls__940d; tmp3 = fncls__940d } else { tmp3 = fncls__940 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__941, tmp3, nil); arg_913 = tmp1.Invoke_O_O__O(tmp2.Ref(), xs__2); if linked_911 == nil { return ifn_912.Invoke_O__O(arg_913) } else { return linked_911.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_910, arg_913) } }
//line :300:1
func A_arbace_c2j_node_qe_elems_fn__400000181_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_elems_fn__400000181_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_elems_fn__400000181_A{}; t.Ctor_O_O(p0, p1); return t }
//line :300:1
func (t *A_arbace_c2j_node_qe_elems_fn__400000181_A) Ctor_O_O(c__env, c__v any) { t.F_env = c__env; t.F_v = c__v }
//line :300:1
func (t *A_arbace_c2j_node_qe_elems_fn__400000181_A) Invoke_O_O__O(self, x__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any; var root_919 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = x__1; if linked_920 == nil { and__1927000168__auto____2 = ifn_921.Invoke_O__O(arg_922) } else { and__1927000168__auto____2 = linked_920.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_919, arg_922) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_c2j_node_A_const_218; var tmp3 any; var root_923 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, A_arbace_c2j_node_head_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = x__1; if linked_924 == nil { tmp3 = ifn_925.Invoke_O__O(arg_926) } else { tmp3 = linked_924.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_923, arg_926) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var b__2 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_env); var tmp5 any; var root_930 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_930, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_932 lang.IFn
		if linked_931 == nil { ifn_932 = lang.IFn_Cast(root_930) } else { ifn_932 = nil }; var arg_933 any = x__1; if linked_931 == nil { tmp5 = ifn_932.Invoke_O__O(arg_933) } else { tmp5 = linked_931.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_930, arg_933) }; b__2 = tmp4.Invoke_O__O(tmp5); var tmp6 any = A_arbace_c2j_node_A_const_219; if lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_c2j_node_A_const_20.Invoke_O__O(b__2)) { var root_927 any = A_arbace_c2j_node_A_const_220.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, A_arbace_c2j_node_invalid_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; if linked_928 == nil { return ifn_929.Invoke__O() } else { return linked_928.(*A_arbace_c2j_node_invalid_A).Invoke_O__O(root_927) } } else { return A_arbace_c2j_node_A_const_221.Invoke_O__O(b__2) } } else {
//line :301:1
			var tmp7 any; var root_934 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_934, A_arbace_c2j_node_qe_A_fn_class); var ifn_936 lang.IFn

			if linked_935 == nil { ifn_936 = lang.IFn_Cast(root_934) } else { ifn_936 = nil }; var arg_937 any = t.F_env; var arg_938 any = t.F_v; var arg_939 any = x__1; if linked_935 == nil { tmp7 = ifn_936.Invoke_O_O_O__O(arg_937, arg_938, arg_939) } else { tmp7 = linked_935.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_934, arg_937, arg_938, arg_939) }
//line :301:1
			return lang.Tuple_Create_O__IPersistentVector(tmp7)
		}
}


func A_arbace_c2j_node_qe_seq_A_New() *A_arbace_c2j_node_qe_seq_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_c2j_node_qe_seq_A) Ctor() {}
//line :306:1
func (t *A_arbace_c2j_node_qe_seq_A) Invoke_O_O_O_O__O(self, env__0, v__1, t__2 any) any { var vec__400000187__4 any = t__2; var seq__400000188__5 any; var root_942 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_942, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_944 lang.IFn; if
												linked_943 == nil { ifn_944 = lang.IFn_Cast(root_942) } else { ifn_944 = nil }; var arg_945 any = vec__400000187__4; if linked_943 == nil { seq__400000188__5 = ifn_944.Invoke_O__O(arg_945) } else { seq__400000188__5 = linked_943.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_942, arg_945) }; var first__400000189__6 any; var root_946 any = /*line :306:1*/A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_948 lang.IFn; if
												linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = seq__400000188__5; if linked_947 == nil { first__400000189__6 = ifn_948.Invoke_O__O(arg_949) } else { first__400000189__6 = linked_947.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_946, arg_949) }; var seq__400000188__7 any; var root_950 any = /*line :306:1*/A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_952 lang.IFn; if
												linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any = seq__400000188__5; if linked_951 == nil { seq__400000188__7 = ifn_952.Invoke_O__O(arg_953) } else { seq__400000188__7 = linked_951.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_950, arg_953) }; var h__8 any = first__400000189__6; var as__9 any = seq__400000188__7; var h_STAR___10 any; var fnbody__971 any = /*line :306:1*/A_arbace_c2j_node_qe_seq_h_STAR___400000190_A_New_O_O_O(env__0, t__2, v__1); var tmp1 *jrt.Class; var fncls__970 *jrt.Class = A_arbace_c2j_node_qe_seq_h_STAR___400000190_A_fn_class; if

	fncls__970 == nil { var fncls__970d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, fnbody__971); A_arbace_c2j_node_qe_seq_h_STAR___400000190_A_fn_class = fncls__970d; tmp1 = fncls__970d } else { tmp1 = fncls__970 }; h_STAR___10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__971, tmp1, nil); var G__400000192__11_ any = h__8; switch
	lang.Util_Hash_O__I_NoInit(G__400000192__11_) >> 2 & 63 { case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_224) { var vec__400000193__12 any = as__9; var ___13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000193__12, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000193__12, lang.RT_IntCast_J__I_NoInit(1), nil); var b__15 any = lang.IFn_Cast(env__0).Invoke_O__O(xs__14); var tmp2 any = A_arbace_c2j_node_A_const_225; _ = ___13





		if lang.Util_Equiv_O_O__Z_NoInit(tmp2, A_arbace_c2j_node_A_const_226.Invoke_O__O(v__1)) { var tmp3 any = A_arbace_c2j_node_A_const_227; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_node_A_const_242; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4.Invoke_O_O_O__O(tmp5, A_arbace_c2j_node_A_const_171.Invoke_O__O(b__15), A_arbace_c2j_node_A_const_243))) } else { var tmp6 any = A_arbace_c2j_node_A_const_228; var tmp7 any; var root_973 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_975 lang.IFn

			if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any; var fnbody__983 any = A_arbace_c2j_node_qe_seq_fn__400000196_A_New_O(b__15); var tmp8 *jrt.Class; var fncls__982 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000196_A_fn_class; if fncls__982 == nil { var fncls__982d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, fnbody__983); A_arbace_c2j_node_qe_seq_fn__400000196_A_fn_class = fncls__982d; tmp8 = fncls__982d } else { tmp8 = fncls__982 }; arg_976 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__983, tmp8, nil); var arg_977 any; var root_984 any = A_arbace_c2j_node_A_const_231.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = A_arbace_c2j_node_A_const_226.Invoke_O__O(v__1); if linked_985 == nil { arg_977 = ifn_986.Invoke_O__O(arg_987) } else { arg_977 = linked_985.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_984, arg_987) }; if linked_974 == nil { tmp7 = ifn_975.Invoke_O_O__O(arg_976, arg_977) } else { tmp7 = linked_974.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_973, arg_976, arg_977) }
//line :315:1
			return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7)) } }
//line :309:1
	case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_232) {














































		var root_988 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_988, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_990 lang.IFn; if linked_989 == nil { ifn_990 = lang.IFn_Cast(root_988) } else { ifn_990 = nil }; var arg_991 any = A_arbace_c2j_node_A_const_233; var arg_992 any; var root_993 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = A_arbace_c2j_node_A_const_234.GetRawRoot__O(); var arg_997 any; var root_998 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_999 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_998, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1000 lang.IFn; if linked_999 == nil { ifn_1000 = lang.IFn_Cast(root_998) } else { ifn_1000 = nil }; var arg_1001 any; var fnbody__1010 any = A_arbace_c2j_node_qe_seq_fn__400000198_A_New_O_O(env__0, v__1); var tmp9 *jrt.Class; var fncls__1009 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000198_A_fn_class; if fncls__1009 == nil { var fncls__1009d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, fnbody__1010); A_arbace_c2j_node_qe_seq_fn__400000198_A_fn_class = fncls__1009d; tmp9 = fncls__1009d } else { tmp9 = fncls__1009 }; arg_1001 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1010, tmp9, nil); var arg_1002 any = as__9; if linked_999 == nil { arg_997 = ifn_1000.Invoke_O_O__O(arg_1001, arg_1002) } else { arg_997 = linked_999.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_998, arg_1001, arg_1002) }; if linked_994 == nil { arg_992 = ifn_995.Invoke_O_O__O(arg_996, arg_997) } else { arg_992 = linked_994.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_993, arg_996, arg_997) }; if linked_989 == nil { return ifn_990.Invoke_O_O__O(arg_991, arg_992) } else { return linked_989.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_988, arg_991, arg_992) } }
//line :309:1
	case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_235) { var b__12 any; var tmp10 lang.IFn = lang.IFn_Cast(env__0); var tmp11 any; var root_1035 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1035, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1037 lang.IFn









































































		if linked_1036 == nil { ifn_1037 = lang.IFn_Cast(root_1035) } else { ifn_1037 = nil }; var arg_1038 any = as__9; if linked_1036 == nil { tmp11 = ifn_1037.Invoke_O__O(arg_1038) } else { tmp11 = linked_1036.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1035, arg_1038) }; b__12 = tmp10.Invoke_O__O(tmp11)
//line :309:1
		var G__400000200__13_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__12)










































































		switch lang.Util_Hash_O__I_NoInit(G__400000200__13_) >> 3 & 1 { case 0: if any(G__400000200__13_) == any(A_arbace_c2j_node_A_const_236) {

			var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_node_A_const_244; var tmp14 any = A_arbace_c2j_node_A_const_245; return tmp12.Invoke_O_O_O__O(tmp13, tmp14, A_arbace_c2j_node_A_const_221.Invoke_O__O(b__12)) }
//line :384:1
		case 1: if any(G__400000200__13_) == any(A_arbace_c2j_node_A_const_219) {
			return A_arbace_c2j_node_A_const_237.Invoke_O__O(b__12) }
//line :384:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__400000200__13_))))) }
//line :309:1
	case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_238) { var vec__400000201__12 any = as__9; var c__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000201__12, lang.RT_IntCast_J__I_NoInit(0), nil); var a__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000201__12, lang.RT_IntCast_J__I_NoInit(1), nil); var b__15_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000201__12, lang.RT_IntCast_J__I_NoInit(2), nil); var yes__16 any; var tmp15 any; var root_1012 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_1013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1012, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1014 lang.IFn

















































		if linked_1013 == nil { ifn_1014 = lang.IFn_Cast(root_1012) } else { ifn_1014 = nil }; var arg_1015 any = c__13; if linked_1013 == nil { tmp15 = ifn_1014.Invoke_O__O(arg_1015) } else { tmp15 = linked_1013.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1012, arg_1015) }
//line :358:1
		if jrt.J2g_Truth(tmp15) {
			yes__16 = lang.RT_Get_O_O__O_NoInit(A_arbace_c2j_node_A_const_239.Invoke_O__O(v__1), c__13) } else {
//line :358:1
				var tmp16 any = A_arbace_c2j_node_A_const_240; var tmp17 any; var root_1016 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_1017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1016, A_arbace_c2j_node_head_A_fn_class); var ifn_1018 lang.IFn

				if linked_1017 == nil { ifn_1018 = lang.IFn_Cast(root_1016) } else { ifn_1018 = nil }; var arg_1019 any = c__13; if linked_1017 == nil { tmp17 = ifn_1018.Invoke_O__O(arg_1019) } else { tmp17 = linked_1017.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_1016, arg_1019) }
//line :358:1
				if lang.Util_Equiv_O_O__Z_NoInit(tmp16, tmp17) {

					var tmp18 any = A_arbace_c2j_node_A_const_225; yes__16 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp18, A_arbace_c2j_node_A_const_226.Invoke_O__O(v__1))).Ref() } else {
//line :358:1
						var tmp19 any = A_arbace_c2j_node_A_const_241; var tmp20 any; var root_1020 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, A_arbace_c2j_node_head_A_fn_class); var ifn_1022 lang.IFn


						if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any = c__13; if linked_1021 == nil { tmp20 = ifn_1022.Invoke_O__O(arg_1023) } else { tmp20 = linked_1021.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_1020, arg_1023) }
//line :358:1
						if lang.Util_Equiv_O_O__Z_NoInit(tmp19, tmp20) {


							yes__16 = A_arbace_c2j_node_A_const_73.Invoke_O__O(v__1) } else {
//line :358:1
								if A_arbace_c2j_node_A_const_45 != nil { var tmp21 any; var root_1024 any = A_arbace_c2j_node_A_const_157.GetRawRoot__O(); var linked_1025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1024, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1026 lang.IFn



									if linked_1025 == nil { ifn_1026 = lang.IFn_Cast(root_1024) } else { ifn_1026 = nil }; var arg_1027 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__13)).Ref(); var arg_1028 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1025 == nil { tmp21 = ifn_1026.Invoke_O_O__O(arg_1027, arg_1028) } else { tmp21 = linked_1025.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1024, arg_1027, arg_1028) }
//line :358:1
									panic(jrt.Thrown(jrt.Throwable_Cast(tmp21))) } else { yes__16 = nil
									}
							}
					}
			}
		var root_1029 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, A_arbace_c2j_node_qe_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = env__0; var arg_1033 any = v__1; var arg_1034 any; if jrt.J2g_Truth(yes__16) { arg_1034 = a__14 } else { arg_1034 = b__15_2 }; if linked_1030 == nil { return ifn_1031.Invoke_O_O_O__O(arg_1032, arg_1033, arg_1034) } else { return linked_1030.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1029, arg_1032, arg_1033, arg_1034) } }
//line :309:1
	case 26: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_246) { var vec__400000204__12 any = as__9; var seq__400000205__13 any; var root_1039 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1041 lang.IFn






















































		if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = vec__400000204__12; if linked_1040 == nil { seq__400000205__13 = ifn_1041.Invoke_O__O(arg_1042) } else { seq__400000205__13 = linked_1040.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1039, arg_1042) }
//line :309:1
		var first__400000206__14 any; var root_1043 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1043, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1045 lang.IFn






















































		if linked_1044 == nil { ifn_1045 = lang.IFn_Cast(root_1043) } else { ifn_1045 = nil }; var arg_1046 any = seq__400000205__13; if linked_1044 == nil { first__400000206__14 = ifn_1045.Invoke_O__O(arg_1046) } else { first__400000206__14 = linked_1044.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1043, arg_1046) }
//line :309:1
		var seq__400000205__15 any; var root_1047 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1049 lang.IFn






















































		if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = seq__400000205__13; if linked_1048 == nil { seq__400000205__15 = ifn_1049.Invoke_O__O(arg_1050) } else { seq__400000205__15 = linked_1048.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1047, arg_1050) }
//line :309:1
		var ___16 any = first__400000206__14; var cls__17 any = seq__400000205__15; var m__18 any; var root_1051 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1053 lang.IFn; _ = ___16























































		if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any = A_arbace_c2j_node_A_const_247.GetRawRoot__O(); var arg_1055 any = cls__17; if linked_1052 == nil { m__18 = ifn_1053.Invoke_O_O__O(arg_1054, arg_1055) } else { m__18 = linked_1052.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1051, arg_1054, arg_1055) }
		var tmp22 any; var root_1056 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any = m__18; var arg_1060 any = A_arbace_c2j_node_A_const_168.Invoke_O__O(v__1); if linked_1057 == nil { tmp22 = ifn_1058.Invoke_O_O__O(arg_1059, arg_1060) } else { tmp22 = linked_1057.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1056, arg_1059, arg_1060) }; if jrt.J2g_Truth(tmp22) { var root_1061 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1061, A_arbace_c2j_node_qe_A_fn_class); var ifn_1063 lang.IFn; if linked_1062 == nil { ifn_1063 = lang.IFn_Cast(root_1061) } else { ifn_1063 = nil }; var arg_1064 any = env__0; var arg_1065 any = v__1; var arg_1066 any = lang.IFn_Cast(m__18).Invoke_O__O(A_arbace_c2j_node_A_const_168.Invoke_O__O(v__1)); if linked_1062 == nil { return ifn_1063.Invoke_O_O_O__O(arg_1064, arg_1065, arg_1066) } else { return linked_1062.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1061, arg_1064, arg_1065, arg_1066) } } else { var root_1067 any = A_arbace_c2j_node_A_const_220.GetRawRoot__O(); var linked_1068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1067, A_arbace_c2j_node_invalid_A_fn_class); var ifn_1069 lang.IFn; if linked_1068 == nil { ifn_1069 = lang.IFn_Cast(root_1067) } else { ifn_1069 = nil }; if linked_1068 == nil { return ifn_1069.Invoke__O() } else { return linked_1068.(*A_arbace_c2j_node_invalid_A).Invoke_O__O(root_1067) } } }
//line :309:1
	case 27: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_248) { var vec__400000207__12 any = as__9; var ___13_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000207__12, lang.RT_IntCast_J__I_NoInit(0), nil); var x__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000207__12, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1070 any = A_arbace_c2j_node_A_const_41.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, A_arbace_c2j_node_walk_syms_A_fn_class); var ifn_1072 lang.IFn; _ = ___13_2


















































































		if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any; var tmp23 any = A_arbace_c2j_node_A_const_249; var tmp24 any; var root_1075 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1075, A_arbace_c2j_node_qe_A_fn_class); var ifn_1077 lang.IFn; if linked_1076 == nil { ifn_1077 = lang.IFn_Cast(root_1075) } else { ifn_1077 = nil }; var arg_1078 any = env__0; var arg_1079 any = v__1; var arg_1080 any = x__14; if linked_1076 == nil { tmp24 = ifn_1077.Invoke_O_O_O__O(arg_1078, arg_1079, arg_1080) } else { tmp24 = linked_1076.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1075, arg_1078, arg_1079, arg_1080) }; arg_1073 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp24)); var tmp25 *lang.Keyword = A_arbace_c2j_node_A_const_250; var arg_1074 any = tmp25.Invoke_O__O(A_arbace_c2j_node_A_const_177.Invoke_O__O(v__1)); if linked_1071 == nil { return ifn_1072.Invoke_O_O__O(arg_1073, arg_1074) } else { return linked_1071.(*A_arbace_c2j_node_walk_syms_A).Invoke_O_O_O__O(root_1070, arg_1073, arg_1074) } }
//line :309:1
	case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_251) { var vec__400000210__12 any = as__9; var ___13_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000210__12, lang.RT_IntCast_J__I_NoInit(0), nil); var c__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000210__12, lang.RT_IntCast_J__I_NoInit(1), nil); var c__15 any; _ = ___13_3














































































		if lang.Util_Equiv_O_O__Z_NoInit(c__14, A_arbace_c2j_node_A_const_252) { c__15 = A_arbace_c2j_node_A_const_168.Invoke_O__O(v__1) } else { c__15 = c__14 }
//line :309:1
		var tmp26 *lang.Keyword = A_arbace_c2j_node_A_const_253; var g__16 any = lang.RT_Get_O_O__O_NoInit(tmp26.Invoke_O__O(A_arbace_c2j_node_A_const_177.Invoke_O__O(v__1)), c__15)
		var or__1927000174__auto____17 any = g__16















































































		if jrt.J2g_Truth(or__1927000174__auto____17) { return or__1927000174__auto____17 } else { var root_1081 any = A_arbace_c2j_node_A_const_220.GetRawRoot__O(); var linked_1082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1081, A_arbace_c2j_node_invalid_A_fn_class); var ifn_1083 lang.IFn; if linked_1082 == nil { ifn_1083 = lang.IFn_Cast(root_1081) } else { ifn_1083 = nil }; if linked_1082 == nil { return ifn_1083.Invoke__O() } else { return linked_1082.(*A_arbace_c2j_node_invalid_A).Invoke_O__O(root_1081) } } }
//line :309:1
	case 36: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_254) { var vec__400000213__12 any = as__9; var c__13_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000213__12, lang.RT_IntCast_J__I_NoInit(0), nil); var x__14_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000213__12, lang.RT_IntCast_J__I_NoInit(1), nil); var c__15_2 any

		if lang.Util_Equiv_O_O__Z_NoInit(c__13_2, A_arbace_c2j_node_A_const_255) { c__15_2 = A_arbace_c2j_node_A_const_168.Invoke_O__O(v__1) } else { c__15_2 = c__13_2 }
		var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp28 any; var root_1088 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1088, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1090 lang.IFn; if linked_1089 == nil { ifn_1090 = lang.IFn_Cast(root_1088) } else { ifn_1090 = nil }; var arg_1091 any; var tmp29 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_68, nil); var tmp30 any; var root_1092 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1092, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1094 lang.IFn; if linked_1093 == nil { ifn_1094 = lang.IFn_Cast(root_1092) } else { ifn_1094 = nil }; var arg_1095 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_261.GetRawRoot__O()).Invoke_O__O(c__15_2); if linked_1093 == nil { tmp30 = ifn_1094.Invoke_O__O(arg_1095) } else { tmp30 = linked_1093.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1092, arg_1095) }; arg_1091 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp29, jrt.RefArrayOf(jrt.Object_class, nil, tmp30)).Ref(); if linked_1089 == nil { tmp28 = ifn_1090.Invoke_O__O(arg_1091) } else { tmp28 = linked_1089.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1088, arg_1091) }; var tmp31 *lang.Keyword = A_arbace_c2j_node_A_const_171; return tmp27.Invoke_O_O_O__O(tmp28, tmp31.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(x__14_2)), A_arbace_c2j_node_A_const_262) }
//line :309:1
	case 37: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_256) { var vec__400000216__12 any = as__9; var ___13_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000216__12, lang.RT_IntCast_J__I_NoInit(0), nil); var a__14_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000216__12, lang.RT_IntCast_J__I_NoInit(1), nil); var b__15_3 any = lang.IFn_Cast(env__0).Invoke_O__O(a__14_2); var g__16_2 any; var root_1084 any = A_arbace_c2j_node_A_const_257.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1084, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1086 lang.IFn; _ = ___13_4


































































		if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = A_arbace_c2j_node_A_const_258; if linked_1085 == nil { g__16_2 = ifn_1086.Invoke_O__O(arg_1087) } else { g__16_2 = linked_1085.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1084, arg_1087) }
		var tmp32 *lang.Keyword = A_arbace_c2j_node_A_const_259; var tmp33 lang.IFn = lang.IFn_Cast(tmp32.Invoke_O__O(A_arbace_c2j_node_A_const_260.Invoke_O__O(v__1))); var tmp34 any = A_arbace_c2j_node_A_const_265.Invoke_O__O(v__1); var tmp35 any = A_arbace_c2j_node_A_const_221.Invoke_O__O(b__15_3); var tmp36 *lang.Compiler_AOTFn; var fnbody__1106 any = A_arbace_c2j_node_qe_seq_fn__400000219_A_New_O(g__16_2); var tmp37 *jrt.Class; var fncls__1105 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000219_A_fn_class; if fncls__1105 == nil { var fncls__1105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, fnbody__1106); A_arbace_c2j_node_qe_seq_fn__400000219_A_fn_class = fncls__1105d; tmp37 = fncls__1105d } else { tmp37 = fncls__1105 }; tmp36 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1106, tmp37, nil); return tmp33.Invoke_O_O_O__O(tmp34, tmp35, tmp36.Ref()) }
//line :309:1
	case 41: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_263) { var vec__400000221__12 any = as__9; var ___13_5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000221__12, lang.RT_IntCast_J__I_NoInit(0), nil); var t__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000221__12, lang.RT_IntCast_J__I_NoInit(1), nil); var a__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000221__12, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp38 *lang.Keyword = A_arbace_c2j_node_A_const_264; var tmp39 *lang.Keyword = A_arbace_c2j_node_A_const_237; var tmp40 *lang.Keyword = A_arbace_c2j_node_A_const_221; _ = ___13_5








































































		return lang.IFn_Cast(tmp38.Invoke_O__O(A_arbace_c2j_node_A_const_260.Invoke_O__O(v__1))).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_265.Invoke_O__O(v__1), tmp39.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(t__14)), tmp40.Invoke_O__O(lang.IFn_Cast(env__0).Invoke_O__O(a__15))) }
//line :309:1
	case 43: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_267) { var vec__400000224__12 any = as__9; var ___13_6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000224__12, lang.RT_IntCast_J__I_NoInit(0), nil); var x__14_3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000224__12, lang.RT_IntCast_J__I_NoInit(1), nil); var m__15 any = A_arbace_c2j_node_A_const_265.Invoke_O__O(v__1); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp42 any = A_arbace_c2j_node_A_const_269; var tmp43 *lang.Keyword = A_arbace_c2j_node_A_const_270; var tmp44 any = lang.IFn_Cast(tmp43.Invoke_O__O(A_arbace_c2j_node_A_const_260.Invoke_O__O(v__1))).Invoke_O__O(jrt.NN(jrt.Method_Cast(m__15)).GetDeclaringClass__Class().Ref()); var tmp45 any; var root_1117 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, A_arbace_c2j_node_qe_A_fn_class); var ifn_1119 lang.IFn; _ = ___13_6






































































		if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = env__0; var arg_1121 any = v__1; var arg_1122 any = x__14_3; if linked_1118 == nil { tmp45 = ifn_1119.Invoke_O_O_O__O(arg_1120, arg_1121, arg_1122) } else { tmp45 = linked_1118.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1117, arg_1120, arg_1121, arg_1122) }; return tmp41.Invoke_O_O_O__O(tmp42, tmp44, tmp45) }
//line :309:1
	case 45: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_268) {









































		var root_1107 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, A_arbace_c2j_node_qe_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = env__0; var arg_1111 any = v__1; var arg_1112 any; var root_1113 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1115 lang.IFn; if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = as__9; if linked_1114 == nil { arg_1112 = ifn_1115.Invoke_O__O(arg_1116) } else { arg_1112 = linked_1114.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1113, arg_1116) }; if linked_1108 == nil { return ifn_1109.Invoke_O_O_O__O(arg_1110, arg_1111, arg_1112) } else { return linked_1108.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1107, arg_1110, arg_1111, arg_1112) } }
//line :309:1
	case 48: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_271) { var vec__400000227__12 any = as__9; var l__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000227__12, lang.RT_IntCast_J__I_NoInit(0), nil); var x__14_4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000227__12, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp47 any = A_arbace_c2j_node_A_const_278; var tmp48 any = A_arbace_c2j_node_A_const_280; var tmp49 any; var root_1261 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, A_arbace_c2j_node_qe_A_fn_class); var ifn_1263 lang.IFn













































		if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any = env__0; var arg_1265 any = v__1; var arg_1266 any = x__14_4; if linked_1262 == nil { tmp49 = ifn_1263.Invoke_O_O_O__O(arg_1264, arg_1265, arg_1266) } else { tmp49 = linked_1262.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1261, arg_1264, arg_1265, arg_1266) }; var tmp50 any = lang.Tuple_Create_O_O__IPersistentVector(tmp48, tmp49); var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp52 any = A_arbace_c2j_node_A_const_281; var tmp53 any = A_arbace_c2j_node_A_const_282; var tmp54 any; var root_1267 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1267, A_arbace_c2j_node_qe_A_fn_class); var ifn_1269 lang.IFn; if linked_1268 == nil { ifn_1269 = lang.IFn_Cast(root_1267) } else { ifn_1269 = nil }; var arg_1270 any = env__0; var arg_1271 any = v__1; var arg_1272 any = l__13; if linked_1268 == nil { tmp54 = ifn_1269.Invoke_O_O_O__O(arg_1270, arg_1271, arg_1272) } else { tmp54 = linked_1268.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1267, arg_1270, arg_1271, arg_1272) }; return tmp46.Invoke_O_O_O_O__O(tmp47, tmp50, tmp51.Invoke_O_O_O__O(tmp52, tmp53, tmp54), A_arbace_c2j_node_A_const_279) }
//line :309:1
	case 54: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_272) { var vec__400000230__12 any = as__9; var seq__400000231__13 any; var root_1123 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1125 lang.IFn


























		if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = vec__400000230__12; if linked_1124 == nil { seq__400000231__13 = ifn_1125.Invoke_O__O(arg_1126) } else { seq__400000231__13 = linked_1124.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1123, arg_1126) }
//line :309:1
		var first__400000232__14 any; var root_1127 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1127, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1129 lang.IFn


























		if linked_1128 == nil { ifn_1129 = lang.IFn_Cast(root_1127) } else { ifn_1129 = nil }; var arg_1130 any = seq__400000231__13; if linked_1128 == nil { first__400000232__14 = ifn_1129.Invoke_O__O(arg_1130) } else { first__400000232__14 = linked_1128.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1127, arg_1130) }
//line :309:1
		var seq__400000231__15 any; var root_1131 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1131, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1133 lang.IFn


























		if linked_1132 == nil { ifn_1133 = lang.IFn_Cast(root_1131) } else { ifn_1133 = nil }; var arg_1134 any = seq__400000231__13; if linked_1132 == nil { seq__400000231__15 = ifn_1133.Invoke_O__O(arg_1134) } else { seq__400000231__15 = linked_1132.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1131, arg_1134) }
//line :309:1
		var line__16 any = first__400000232__14; var first__400000232__17 any; var root_1135 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1135, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1137 lang.IFn


























		if linked_1136 == nil { ifn_1137 = lang.IFn_Cast(root_1135) } else { ifn_1137 = nil }; var arg_1138 any = seq__400000231__15; if linked_1136 == nil { first__400000232__17 = ifn_1137.Invoke_O__O(arg_1138) } else { first__400000232__17 = linked_1136.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1135, arg_1138) }
//line :309:1
		var seq__400000231__18 any; var root_1139 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1140 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1139, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1141 lang.IFn


























		if linked_1140 == nil { ifn_1141 = lang.IFn_Cast(root_1139) } else { ifn_1141 = nil }; var arg_1142 any = seq__400000231__15; if linked_1140 == nil { seq__400000231__18 = ifn_1141.Invoke_O__O(arg_1142) } else { seq__400000231__18 = linked_1140.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1139, arg_1142) }
//line :309:1
		var bv__19 any = first__400000232__17; var body__20 any = seq__400000231__18; var n__21 any; var root_1143 any = A_arbace_c2j_node_A_const_257.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1143, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1145 lang.IFn



























		if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = A_arbace_c2j_node_A_const_273; if linked_1144 == nil { n__21 = ifn_1145.Invoke_O__O(arg_1146) } else { n__21 = linked_1144.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1143, arg_1146) }
//line :309:1
		var tmp__22 any; var fnbody__1157 any = A_arbace_c2j_node_qe_seq_tmp__400000236_A_New_O(n__21); var tmp55 *jrt.Class
		var fncls__1156 /*line :309:1*/*jrt.Class = A_arbace_c2j_node_qe_seq_tmp__400000236_A_fn_class




























		if fncls__1156 == nil { var fncls__1156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, fnbody__1157); A_arbace_c2j_node_qe_seq_tmp__400000236_A_fn_class = fncls__1156d; tmp55 = fncls__1156d } else { tmp55 = fncls__1156 }; tmp__22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1157, tmp55, nil)
//line :309:1
		var vec__400000233__23 any; var root_1158 any = A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_1159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1158, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1160 lang.IFn





























		if linked_1159 == nil { ifn_1160 = lang.IFn_Cast(root_1158) } else { ifn_1160 = nil }; var arg_1161 any; var fnbody__1226 any = A_arbace_c2j_node_qe_seq_fn__400000240_A_New_O_O(tmp__22, v__1); var tmp56 *jrt.Class; var fncls__1225 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000240_A_fn_class; if fncls__1225 == nil { var fncls__1225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, fnbody__1226); A_arbace_c2j_node_qe_seq_fn__400000240_A_fn_class = fncls__1225d; tmp56 = fncls__1225d } else { tmp56 = fncls__1225 }; arg_1161 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1226, tmp56, nil); var arg_1162 any = lang.Tuple_Create_O_O__IPersistentVector(env__0, lang.PersistentVector_EMPTY.Ref()); var arg_1163 any; var root_1227 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_1228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1227, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_1229 lang.IFn








		if linked_1228 == nil { ifn_1229 = lang.IFn_Cast(root_1227) } else { ifn_1229 = nil }; var arg_1230 any = A_arbace_c2j_node_A_const_25; var arg_1231 any = bv__19; if linked_1228 == nil { arg_1163 = ifn_1229.Invoke_O_O__O(arg_1230, arg_1231) } else { arg_1163 = linked_1228.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_1227, arg_1230, arg_1231) }
//line :339:1
		if linked_1159 == nil { vec__400000233__23 = ifn_1160.Invoke_O_O_O__O(arg_1161, arg_1162, arg_1163) } else { vec__400000233__23 = linked_1159.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1158, arg_1161, arg_1162, arg_1163) }
//line :309:1
		var env__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000233__23, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__25 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000233__23, lang.RT_IntCast_J__I_NoInit(1), nil); var root_1232 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1232, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1234 lang.IFn







































		if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any; var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp58 any = A_arbace_c2j_node_A_const_275; var tmp59 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp60 any = A_arbace_c2j_node_A_const_276; var tmp61 any = A_arbace_c2j_node_A_const_277; var tmp62 any; var root_1237 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1237, A_arbace_c2j_node_qe_A_fn_class); var ifn_1239 lang.IFn; if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any = env__24; var arg_1241 any = v__1; var arg_1242 any = line__16; if linked_1238 == nil { tmp62 = ifn_1239.Invoke_O_O_O__O(arg_1240, arg_1241, arg_1242) } else { tmp62 = linked_1238.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1237, arg_1240, arg_1241, arg_1242) }; arg_1235 = tmp57.Invoke_O_O_O__O(tmp58, binds__25, tmp59.Invoke_O_O_O__O(tmp60, tmp61, tmp62)); var arg_1236 any; var root_1243 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_1244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1243, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_1245 lang.IFn
		if linked_1244 == nil { ifn_1245 = lang.IFn_Cast(root_1243) } else { ifn_1245 = nil }; var arg_1246 any = A_arbace_c2j_node_A_const_234.GetRawRoot__O(); var arg_1247 any; var root_1248 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any; var fnbody__1260 any = A_arbace_c2j_node_qe_seq_fn__400000250_A_New_O_O(v__1, env__24); var tmp63 *jrt.Class; var fncls__1259 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000250_A_fn_class; if fncls__1259 == nil { var fncls__1259d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, fnbody__1260); A_arbace_c2j_node_qe_seq_fn__400000250_A_fn_class = fncls__1259d; tmp63 = fncls__1259d } else { tmp63 = fncls__1259 }; arg_1251 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1260, tmp63, nil); var arg_1252 any = body__20; if linked_1249 == nil { arg_1247 = ifn_1250.Invoke_O_O__O(arg_1251, arg_1252) } else { arg_1247 = linked_1249.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1248, arg_1251, arg_1252) }; if linked_1244 == nil { arg_1236 = ifn_1245.Invoke_O_O__O(arg_1246, arg_1247) } else { arg_1236 = linked_1244.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_1243, arg_1246, arg_1247) }
//line :349:1
		if linked_1233 == nil { return ifn_1234.Invoke_O_O__O(arg_1235, arg_1236) } else { return linked_1233.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1232, arg_1235, arg_1236) } }
//line :309:1
	case 56: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_283) { var vec__400000252__12 any = as__9; var ___13_7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000252__12, lang.RT_IntCast_J__I_NoInit(0), nil); var ___14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000252__12, lang.RT_IntCast_J__I_NoInit(1), nil); var f__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000252__12, lang.RT_IntCast_J__I_NoInit(2), nil); var m__16 any = A_arbace_c2j_node_A_const_265.Invoke_O__O(v__1); var r__17 any = jrt.NN(jrt.Method_Cast(m__16)).GetReturnType__Class().Ref(); var tmp64 any; var root_1273 any = A_arbace_c2j_node_A_const_284.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1275 lang.IFn; _ = ___13_7; _ = ___14





























































		if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any; var root_1277 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any; var root_1282 any = A_arbace_c2j_node_A_const_285.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1282, A_arbace_c2j_node_ret_chans_A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any = r__17; if linked_1283 == nil { arg_1280 = ifn_1284.Invoke_O__O(arg_1285) } else { arg_1280 = linked_1283.(*A_arbace_c2j_node_ret_chans_A).Invoke_O_O__O(root_1282, arg_1285) }; var arg_1281 any = A_arbace_c2j_node_A_const_168.Invoke_O__O(v__1); if linked_1278 == nil { arg_1276 = ifn_1279.Invoke_O_O__O(arg_1280, arg_1281) } else { arg_1276 = linked_1278.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1277, arg_1280, arg_1281) }; if linked_1274 == nil { tmp64 = ifn_1275.Invoke_O__O(arg_1276) } else { tmp64 = linked_1274.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1273, arg_1276) }
//line :370:1
		if jrt.J2g_Truth(tmp64) {
			var root_1286 any = A_arbace_c2j_node_A_const_220.GetRawRoot__O(); var linked_1287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1286, A_arbace_c2j_node_invalid_A_fn_class); var ifn_1288 lang.IFn; if linked_1287 == nil { ifn_1288 = lang.IFn_Cast(root_1286) } else { ifn_1288 = nil }; if linked_1287 == nil { return ifn_1288.Invoke__O() } else { return linked_1287.(*A_arbace_c2j_node_invalid_A).Invoke_O__O(root_1286) } } else {
//line :370:1
				var tmp65 any = A_arbace_c2j_node_A_const_120; if lang.Util_Equiv_O_O__Z_NoInit(tmp65, A_arbace_c2j_node_A_const_168.Invoke_O__O(v__1)) {

					var tmp66 *lang.Keyword = A_arbace_c2j_node_A_const_286; var tmp67 lang.IFn = lang.IFn_Cast(tmp66.Invoke_O__O(A_arbace_c2j_node_A_const_260.Invoke_O__O(v__1))); var tmp68 any; var root_1348 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, A_arbace_c2j_node_qe_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = env__0; var arg_1352 any = v__1; var arg_1353 any = f__15; if linked_1349 == nil { tmp68 = ifn_1350.Invoke_O_O_O__O(arg_1351, arg_1352, arg_1353) } else { tmp68 = linked_1349.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1348, arg_1351, arg_1352, arg_1353) }; return tmp67.Invoke_O_O__O(tmp68, r__17) } else {
//line :370:1
						if A_arbace_c2j_node_A_const_45 != nil {


							var root_1289 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, A_arbace_c2j_node_qe_A_fn_class); var ifn_1291 lang.IFn; if linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = env__0; var arg_1293 any = v__1; var arg_1294 any = f__15; if linked_1290 == nil { return ifn_1291.Invoke_O_O_O__O(arg_1292, arg_1293, arg_1294) } else { return linked_1290.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1289, arg_1292, arg_1293, arg_1294) } } else {
//line :370:1
								return nil } } } }
//line :309:1
	case 57: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_287) { var vec__400000255__12 any = as__9; var seq__400000256__13 any; var root_1295 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1295, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1297 lang.IFn



















































































		if linked_1296 == nil { ifn_1297 = lang.IFn_Cast(root_1295) } else { ifn_1297 = nil }; var arg_1298 any = vec__400000255__12; if linked_1296 == nil { seq__400000256__13 = ifn_1297.Invoke_O__O(arg_1298) } else { seq__400000256__13 = linked_1296.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1295, arg_1298) }
//line :309:1
		var first__400000257__14 any; var root_1299 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1299, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1301 lang.IFn



















































































		if linked_1300 == nil { ifn_1301 = lang.IFn_Cast(root_1299) } else { ifn_1301 = nil }; var arg_1302 any = seq__400000256__13; if linked_1300 == nil { first__400000257__14 = ifn_1301.Invoke_O__O(arg_1302) } else { first__400000257__14 = linked_1300.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1299, arg_1302) }
//line :309:1
		var seq__400000256__15 any; var root_1303 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1303, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1305 lang.IFn



















































































		if linked_1304 == nil { ifn_1305 = lang.IFn_Cast(root_1303) } else { ifn_1305 = nil }; var arg_1306 any = seq__400000256__13; if linked_1304 == nil { seq__400000256__15 = ifn_1305.Invoke_O__O(arg_1306) } else { seq__400000256__15 = linked_1304.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1303, arg_1306) }
//line :309:1
		var bv__16 any = first__400000257__14; var body__17 any = seq__400000256__15; var root_1307 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_1308 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1307, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1309 lang.IFn




















































































		if linked_1308 == nil { ifn_1309 = lang.IFn_Cast(root_1307) } else { ifn_1309 = nil }; var arg_1310 any = A_arbace_c2j_node_A_const_288; var arg_1311 any; var root_1313 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1313, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1315 lang.IFn; if linked_1314 == nil { ifn_1315 = lang.IFn_Cast(root_1313) } else { ifn_1315 = nil }; var arg_1316 any; var tmp69 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp70 *lang.Compiler_AOTFn; var fnbody__1329 any = A_arbace_c2j_node_qe_seq_fn__400000259_A_New_O_O(env__0, v__1); var tmp71 *jrt.Class; var fncls__1328 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000259_A_fn_class; if fncls__1328 == nil { var fncls__1328d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, fnbody__1329); A_arbace_c2j_node_qe_seq_fn__400000259_A_fn_class = fncls__1328d; tmp71 = fncls__1328d } else { tmp71 = fncls__1328 }; tmp70 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1329, tmp71, nil); var tmp72 any = tmp70.Ref(); var tmp73 any; var root_1330 any = A_arbace_c2j_node_A_const_24.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_partition_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = A_arbace_c2j_node_A_const_25; var arg_1334 any = bv__16; if linked_1331 == nil { tmp73 = ifn_1332.Invoke_O_O__O(arg_1333, arg_1334) } else { tmp73 = linked_1331.(*aot_arbace_core.A_arbace_core_partition_A).Invoke_O_O_O__O(root_1330, arg_1333, arg_1334) }; arg_1316 = tmp69.Invoke_O_O__O(tmp72, tmp73); if linked_1314 == nil { arg_1311 = ifn_1315.Invoke_O__O(arg_1316) } else { arg_1311 = linked_1314.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1313, arg_1316) }; var arg_1312 any; var root_1335 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1336 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1335, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1337 lang.IFn
		if linked_1336 == nil { ifn_1337 = lang.IFn_Cast(root_1335) } else { ifn_1337 = nil }; var arg_1338 any; var fnbody__1347 any = A_arbace_c2j_node_qe_seq_fn__400000264_A_New_O_O(env__0, v__1); var tmp74 *jrt.Class; var fncls__1346 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000264_A_fn_class; if fncls__1346 == nil { var fncls__1346d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, fnbody__1347); A_arbace_c2j_node_qe_seq_fn__400000264_A_fn_class = fncls__1346d; tmp74 = fncls__1346d } else { tmp74 = fncls__1346 }; arg_1338 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1347, tmp74, nil); var arg_1339 any = body__17; if linked_1336 == nil { arg_1312 = ifn_1337.Invoke_O_O__O(arg_1338, arg_1339) } else { arg_1312 = linked_1336.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1335, arg_1338, arg_1339) }
//line :394:1
		if linked_1308 == nil { return ifn_1309.Invoke_O_O_O__O(arg_1310, arg_1311, arg_1312) } else { return linked_1308.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1307, arg_1310, arg_1311, arg_1312) } }
//line :309:1
	case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__400000192__11_, A_arbace_c2j_node_A_const_289) { var vec__400000266__12 any = as__9; var ___13_8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000266__12, lang.RT_IntCast_J__I_NoInit(0), nil); var xs__14_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000266__12, lang.RT_IntCast_J__I_NoInit(1), nil); var b__15_4 any = lang.IFn_Cast(env__0).Invoke_O__O(xs__14_2); var m__16_2 any = A_arbace_c2j_node_A_const_265.Invoke_O__O(v__1); var tmp75 *lang.Keyword = A_arbace_c2j_node_A_const_270; var ts__17 any = tmp75.Invoke_O__O(A_arbace_c2j_node_A_const_260.Invoke_O__O(v__1)); var tmp76 any = A_arbace_c2j_node_A_const_228; var tmp77 any; var root_1354 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1356 lang.IFn; _ = ___13_8












		if linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any; var root_1358 any = A_arbace_c2j_node_A_const_290.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_1360 lang.IFn; if linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any; var fnbody__1373 any = A_arbace_c2j_node_qe_seq_fn__400000269_A_New_O_O(ts__17, b__15_4); var tmp78 *jrt.Class; var fncls__1372 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000269_A_fn_class
		if fncls__1372 == nil { var fncls__1372d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, fnbody__1373); A_arbace_c2j_node_qe_seq_fn__400000269_A_fn_class = fncls__1372d; tmp78 = fncls__1372d } else { tmp78 = fncls__1372 }; arg_1361 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1373, tmp78, nil)
//line :322:1
		var arg_1362 any = jrt.NN(jrt.Method_Cast(m__16_2)).GetParameterTypes__Class1().Ref(); if linked_1359 == nil { arg_1357 = ifn_1360.Invoke_O_O__O(arg_1361, arg_1362) } else { arg_1357 = linked_1359.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_1358, arg_1361, arg_1362) }; if linked_1355 == nil { tmp77 = ifn_1356.Invoke_O__O(arg_1357) } else { tmp77 = linked_1355.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1354, arg_1357) }
//line :309:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp76, tmp77)) }; default:}; return /*line :396:1*/ lang.IFn_Cast(h_STAR___10).Invoke__O() }
//line :308:1
func A_arbace_c2j_node_qe_seq_h_STAR___400000190_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_qe_seq_h_STAR___400000190_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_h_STAR___400000190_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :308:1
func (t *A_arbace_c2j_node_qe_seq_h_STAR___400000190_A) Ctor_O_O_O(c__env, c__t, c__v any) { t.F_env = c__env; t.F_t = c__t; t.F_v = c__v }
//line :308:1
func (t *A_arbace_c2j_node_qe_seq_h_STAR___400000190_A) Invoke_O__O(self any) any { var root_954 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any; var root_959 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_959, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = A_arbace_c2j_node_A_const_39.GetRawRoot__O(); var arg_963 any; var root_964 any = A_arbace_c2j_node_A_const_223.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, A_arbace_c2j_node_qe_elems_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = t.F_env; var arg_968 any = t.F_v; var arg_969 any = t.F_t; if linked_965 == nil { arg_963 = ifn_966.Invoke_O_O_O__O(arg_967, arg_968, arg_969) } else { arg_963 = linked_965.(*A_arbace_c2j_node_qe_elems_A).Invoke_O_O_O_O__O(root_964, arg_967, arg_968, arg_969) }; if linked_960 == nil { arg_957 = ifn_961.Invoke_O_O__O(arg_962, arg_963) } else { arg_957 = linked_960.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_959, arg_962, arg_963) }; var arg_958 any = lang.RT_Meta_O__IPersistentMap_NoInit(t.F_t); if linked_955 == nil { return ifn_956.Invoke_O_O__O(arg_957, arg_958) } else { return linked_955.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_954, arg_957, arg_958) } }








func A_arbace_c2j_node_qe_seq_fn__400000196_A_New_O(p0 any) *A_arbace_c2j_node_qe_seq_fn__400000196_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000196_A{}; t.Ctor_O(p0); return t }
//line :317:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000196_A) Ctor_O(c__b any) { t.F_b = c__b }
//line :317:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000196_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_229; var tmp3 any; var root_978 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_978, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_980 lang.IFn; if linked_979 == nil { ifn_980 = lang.IFn_Cast(root_978) } else { ifn_980 = nil }; var arg_981 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_171.Invoke_O__O(t.F_b), i__1)).Ref(); if linked_979 == nil { tmp3 = ifn_980.Invoke_O__O(arg_981) } else { tmp3 = linked_979.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_978, arg_981) }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_c2j_node_A_const_230) }





func A_arbace_c2j_node_qe_seq_fn__400000269_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000269_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000269_A{}; t.Ctor_O_O(p0, p1); return t }
//line :323:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000269_A) Ctor_O_O(c__ts, c__b any) { t.F_ts = c__ts; t.F_b = c__b }
//line :323:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000269_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { var a__3 any; var root_1363 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1365 lang.IFn; if
												linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_171.Invoke_O__O(t.F_b), i__1)).Ref(); if linked_1364 == nil { a__3 = ifn_1365.Invoke_O__O(arg_1366) } else { a__3 = linked_1364.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1363, arg_1366) }; var G__400000270__4_ any; var root_1367 any = /*line :323:1*/A_arbace_c2j_node_A_const_291.GetRawRoot__O(); var linked_1368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1367, A_arbace_c2j_node_arg_kind_A_fn_class); var ifn_1369 lang.IFn; if

	linked_1368 == nil { ifn_1369 = lang.IFn_Cast(root_1367) } else { ifn_1369 = nil }; var arg_1370 any = p__2; if linked_1368 == nil { G__400000270__4_ = ifn_1369.Invoke_O__O(arg_1370) } else { G__400000270__4_ = linked_1368.(*A_arbace_c2j_node_arg_kind_A).Invoke_O_O__O(root_1367, arg_1370) }; switch lang.Util_Hash_O__I_NoInit(G__400000270__4_) { case 1013910508: if any(G__400000270__4_) == any(A_arbace_c2j_node_A_const_210) {


		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_292; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_293, a__3, A_arbace_c2j_node_A_const_294)) }
//line :325:1
	case 1013910639: if any(G__400000270__4_) == any(A_arbace_c2j_node_A_const_109) {






		return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_295, a__3, A_arbace_c2j_node_A_const_296) }
//line :325:1
	case 1013910699: if any(G__400000270__4_) == any(A_arbace_c2j_node_A_const_212) {




		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp4 any = A_arbace_c2j_node_A_const_297; return tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_298, a__3, A_arbace_c2j_node_A_const_299)) }
//line :325:1
	case 1013910765: if any(G__400000270__4_) == any(A_arbace_c2j_node_A_const_213) {





		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp6 any = A_arbace_c2j_node_A_const_300; return tmp5.Invoke_O_O__O(tmp6, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_301, a__3, A_arbace_c2j_node_A_const_302)) }
//line :325:1
	case 1013911026: if any(G__400000270__4_) == any(A_arbace_c2j_node_A_const_110) {
		return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_303, a__3, A_arbace_c2j_node_A_const_304) }
//line :325:1
	case 1013911091: if any(G__400000270__4_) == any(A_arbace_c2j_node_A_const_209) {

		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp8 any = A_arbace_c2j_node_A_const_306; return tmp7.Invoke_O_O__O(tmp8, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_307, a__3, A_arbace_c2j_node_A_const_308)) }
//line :325:1
	case 1013911476: if any(G__400000270__4_) == any(A_arbace_c2j_node_A_const_120) {








		if lang.Util_Equiv_O_O__Z_NoInit(p__2, A_arbace_c2j_node_A_const_305) { return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_309, a__3, A_arbace_c2j_node_A_const_310) } else { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_node_A_const_311; return tmp9.Invoke_O_O_O__O(tmp10, lang.IFn_Cast(t.F_ts).Invoke_O__O(p__2), lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_312, a__3, A_arbace_c2j_node_A_const_313)) } }
//line :325:1
	case 1013911711: if any(G__400000270__4_) == any(A_arbace_c2j_node_A_const_211) {



		var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp12 any = A_arbace_c2j_node_A_const_314; return tmp11.Invoke_O_O__O(tmp12, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_315, a__3, A_arbace_c2j_node_A_const_316)) }
//line :325:1
	case 1013912038: if any(G__400000270__4_) == any(A_arbace_c2j_node_A_const_107) {







		return lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_317, a__3, A_arbace_c2j_node_A_const_318) }
//line :325:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_48, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__400000270__4_))))) }












func A_arbace_c2j_node_qe_seq_tmp__400000236_A_New_O(p0 any) *A_arbace_c2j_node_qe_seq_tmp__400000236_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_tmp__400000236_A{}; t.Ctor_O(p0); return t }
//line :338:1
func (t *A_arbace_c2j_node_qe_seq_tmp__400000236_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :338:1
func (t *A_arbace_c2j_node_qe_seq_tmp__400000236_A) Invoke_O__O(self any) any { var root_1147 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_77, nil); var tmp2 any; var root_1151 any = A_arbace_c2j_node_A_const_9.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1151, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = t.F_n; var arg_1155 any = A_arbace_c2j_node_A_const_266.GetRawRoot__O(); if linked_1152 == nil { tmp2 = ifn_1153.Invoke_O_O__O(arg_1154, arg_1155) } else { tmp2 = linked_1152.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_1151, arg_1154, arg_1155) }; arg_1150 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref(); if linked_1148 == nil { return ifn_1149.Invoke_O__O(arg_1150) } else { return linked_1148.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1147, arg_1150) } }
func A_arbace_c2j_node_qe_seq_fn__400000240_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000240_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000240_A{}; t.Ctor_O_O(p0, p1); return t }
//line :339:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000240_A) Ctor_O_O(c__tmp, c__v any) { t.F_tmp = c__tmp; t.F_v = c__v }
//line :339:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000240_A) Invoke_O_O_O__O(self, p__400000238__1, p__400000239__2 any) any { var vec__400000241__3 any = p__400000238__1; var env__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000241__3, lang.RT_IntCast_J__I_NoInit(0), nil); var binds__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000241__3, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__400000244__6 any = p__400000239__2; var s__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000244__6, lang.RT_IntCast_J__I_NoInit(0), nil); var init__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000244__6, lang.RT_IntCast_J__I_NoInit(1), nil); var r__9 any; var root_1164 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1164, A_arbace_c2j_node_qe_A_fn_class); var ifn_1166 lang.IFn; if
															linked_1165 == nil { ifn_1166 = lang.IFn_Cast(root_1164) } else { ifn_1166 = nil }; var arg_1167 any = env__4; var arg_1168 any = t.F_v; var arg_1169 any = init__8; if linked_1165 == nil { r__9 = ifn_1166.Invoke_O_O_O__O(arg_1167, arg_1168, arg_1169) } else { r__9 = linked_1165.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1164, arg_1167, arg_1168, arg_1169) }; var tmp1 any; var and__1927000168__auto____10 any; var root_1170 any =
															A_arbace_c2j_node_A_const_43.GetRawRoot__O(); var linked_1171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1170, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1172 lang.IFn; if
															linked_1171 == nil { ifn_1172 = lang.IFn_Cast(root_1170) } else { ifn_1172 = nil }; var arg_1173 any = r__9; if linked_1171 == nil { and__1927000168__auto____10 = ifn_1172.Invoke_O__O(arg_1173) } else { and__1927000168__auto____10 = linked_1171.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1170, arg_1173) }; if jrt.J2g_Truth(and__1927000168__auto____10) { tmp1 = A_arbace_c2j_node_A_const_228.Invoke_O__O(r__9) } else { tmp1 = and__1927000168__auto____10 }; if /*line :341:1*/ jrt.J2g_Truth(tmp1) { var ts__10 any; var root_1174 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_1175 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1174, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1176 lang.IFn

		if linked_1175 == nil { ifn_1176 = lang.IFn_Cast(root_1174) } else { ifn_1176 = nil }; var arg_1177 any; var fnbody__1180 any = A_arbace_c2j_node_qe_seq_fn__400000240_fn__400000247_A_New_O(t.F_tmp); var tmp2 *jrt.Class; var fncls__1179 *jrt.Class = A_arbace_c2j_node_qe_seq_fn__400000240_fn__400000247_A_fn_class; if fncls__1179 == nil { var fncls__1179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, fnbody__1180); A_arbace_c2j_node_qe_seq_fn__400000240_fn__400000247_A_fn_class = fncls__1179d; tmp2 = fncls__1179d } else { tmp2 = fncls__1179 }; arg_1177 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1180, tmp2, nil); var arg_1178 any = A_arbace_c2j_node_A_const_228.Invoke_O__O(r__9); if linked_1175 == nil { ts__10 = ifn_1176.Invoke_O_O__O(arg_1177, arg_1178) } else { ts__10 = linked_1175.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1174, arg_1177, arg_1178) }
//line :341:1
		var tmp3 any; var root_1185 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1186 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1185, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1187 lang.IFn


		if linked_1186 == nil { ifn_1187 = lang.IFn_Cast(root_1185) } else { ifn_1187 = nil }; var arg_1188 any = env__4; var arg_1189 any = s__7; var arg_1190 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_236, A_arbace_c2j_node_A_const_221, ts__10)); if linked_1186 == nil { tmp3 = ifn_1187.Invoke_O_O_O__O(arg_1188, arg_1189, arg_1190) } else { tmp3 = linked_1186.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1185, arg_1188, arg_1189, arg_1190) }
//line :341:1
		var tmp4 any = tmp3; var tmp5 any; var root_1191 any = A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1193 lang.IFn


		if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = binds__5; var arg_1195 any; var root_1196 any = A_arbace_c2j_node_A_const_274.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_interleave_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = ts__10; var arg_1200 any = A_arbace_c2j_node_A_const_228.Invoke_O__O(r__9); if linked_1197 == nil { arg_1195 = ifn_1198.Invoke_O_O__O(arg_1199, arg_1200) } else { arg_1195 = linked_1197.(*aot_arbace_core.A_arbace_core_interleave_A).Invoke_O_O_O__O(root_1196, arg_1199, arg_1200) }; if linked_1192 == nil { tmp5 = ifn_1193.Invoke_O_O__O(arg_1194, arg_1195) } else { tmp5 = linked_1192.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1191, arg_1194, arg_1195) }
//line :341:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp5) } else { var tmp6 any; var and__1927000168__auto____10_2 any; var root_1181 any = A_arbace_c2j_node_A_const_43.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1183 lang.IFn



			if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any = r__9; if linked_1182 == nil { and__1927000168__auto____10_2 = ifn_1183.Invoke_O__O(arg_1184) } else { and__1927000168__auto____10_2 = linked_1182.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1181, arg_1184) }; if jrt.J2g_Truth(and__1927000168__auto____10_2) { tmp6 = A_arbace_c2j_node_A_const_227.Invoke_O__O(r__9) } else { tmp6 = and__1927000168__auto____10_2 }
//line :341:1
			if jrt.J2g_Truth(tmp6) { var t__10 any = lang.IFn_Cast(t.F_tmp).Invoke__O(); var tmp7 any; var root_1201 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1202 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1201, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1203 lang.IFn




				if linked_1202 == nil { ifn_1203 = lang.IFn_Cast(root_1201) } else { ifn_1203 = nil }; var arg_1204 any = env__4; var arg_1205 any = s__7; var arg_1206 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_219, A_arbace_c2j_node_A_const_237, t__10)); if linked_1202 == nil { tmp7 = ifn_1203.Invoke_O_O_O__O(arg_1204, arg_1205, arg_1206) } else { tmp7 = linked_1202.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1201, arg_1204, arg_1205, arg_1206) }
//line :341:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp7, lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(binds__5, t__10, A_arbace_c2j_node_A_const_227.Invoke_O__O(r__9))) } else { if A_arbace_c2j_node_A_const_45 != nil { var t__10_2 any = lang.IFn_Cast(t.F_tmp).Invoke__O(); var tmp8 any; var root_1213 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1215 lang.IFn





					if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = env__4; var arg_1217 any = s__7; var arg_1218 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_20, A_arbace_c2j_node_A_const_132, A_arbace_c2j_node_A_const_237, t__10_2)); if linked_1214 == nil { tmp8 = ifn_1215.Invoke_O_O_O__O(arg_1216, arg_1217, arg_1218) } else { tmp8 = linked_1214.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1213, arg_1216, arg_1217, arg_1218) }
//line :341:1
					return lang.Tuple_Create_O_O__IPersistentVector(tmp8, lang.IFn_Cast(A_arbace_c2j_node_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(binds__5, t__10_2, r__9)) } else { return nil } } } }

func A_arbace_c2j_node_qe_seq_fn__400000240_fn__400000247_A_New_O(p0 any) *A_arbace_c2j_node_qe_seq_fn__400000240_fn__400000247_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000240_fn__400000247_A{}; t.Ctor_O(p0); return t }
//line :343:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000240_fn__400000247_A) Ctor_O(c__tmp any) { t.F_tmp = c__tmp }
//line :343:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000240_fn__400000247_A) Invoke_O_O__O(self, ___1 any) any { return lang.IFn_Cast(t.F_tmp).Invoke__O() }






func A_arbace_c2j_node_qe_seq_fn__400000250_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000250_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000250_A{}; t.Ctor_O_O(p0, p1); return t }
//line :350:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000250_A) Ctor_O_O(c__v, c__env any) { t.F_v = c__v; t.F_env = c__env }
//line :350:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000250_A) Invoke_O_O__O(self, p1__400000184_SHARP___1 any) any { var root_1253 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1253, A_arbace_c2j_node_qe_A_fn_class); var ifn_1255 lang.IFn; if linked_1254 == nil { ifn_1255 = lang.IFn_Cast(root_1253) } else { ifn_1255 = nil }; var arg_1256 any = t.F_env; var arg_1257 any = t.F_v; var arg_1258 any = p1__400000184_SHARP___1; if linked_1254 == nil { return ifn_1255.Invoke_O_O_O__O(arg_1256, arg_1257, arg_1258) } else { return linked_1254.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1253, arg_1256, arg_1257, arg_1258) } }





func A_arbace_c2j_node_qe_seq_fn__400000198_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000198_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000198_A{}; t.Ctor_O_O(p0, p1); return t }
//line :356:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000198_A) Ctor_O_O(c__env, c__v any) { t.F_env = c__env; t.F_v = c__v }
//line :356:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000198_A) Invoke_O_O__O(self, p1__400000185_SHARP___1 any) any { var root_1003 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, A_arbace_c2j_node_qe_A_fn_class); var ifn_1005 lang.IFn; if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = t.F_env; var arg_1007 any = t.F_v; var arg_1008 any = p1__400000185_SHARP___1; if linked_1004 == nil { return ifn_1005.Invoke_O_O_O__O(arg_1006, arg_1007, arg_1008) } else { return linked_1004.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1003, arg_1006, arg_1007, arg_1008) } }




















func A_arbace_c2j_node_qe_seq_fn__400000219_A_New_O(p0 any) *A_arbace_c2j_node_qe_seq_fn__400000219_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000219_A{}; t.Ctor_O(p0); return t }
//line :377:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000219_A) Ctor_O(c__g any) { t.F_g = c__g }
//line :377:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000219_A) Invoke_O_O__O(self, base__1 any) any { var root_1096 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any; var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_1100 any = A_arbace_c2j_node_A_const_9.GetRawRoot__O(); var linked_1101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1100, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1102 lang.IFn; if linked_1101 == nil { ifn_1102 = lang.IFn_Cast(root_1100) } else { ifn_1102 = nil }; var arg_1103 any = t.F_g; var arg_1104 any = A_arbace_c2j_node_A_const_266.GetRawRoot__O(); if linked_1101 == nil { tmp2 = ifn_1102.Invoke_O_O__O(arg_1103, arg_1104) } else { tmp2 = linked_1101.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O__O(root_1100, arg_1103, arg_1104) }; arg_1099 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, base__1, tmp2)).Ref(); if linked_1097 == nil { return ifn_1098.Invoke_O__O(arg_1099) } else { return linked_1097.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1096, arg_1099) } }
















func A_arbace_c2j_node_qe_seq_fn__400000259_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000259_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000259_A{}; t.Ctor_O_O(p0, p1); return t }
//line :394:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000259_A) Ctor_O_O(c__env, c__v any) { t.F_env = c__env; t.F_v = c__v }
//line :394:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000259_A) Invoke_O_O__O(self, p__400000258__1 any) any { var vec__400000260__2 any = p__400000258__1; var s__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000260__2, lang.RT_IntCast_J__I_NoInit(0), nil); var init__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000260__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_1322 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, A_arbace_c2j_node_qe_A_fn_class); var ifn_1324 lang.IFn; if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = t.F_env; var arg_1326 any = t.F_v; var arg_1327 any = init__4; if linked_1323 == nil { tmp1 = ifn_1324.Invoke_O_O_O__O(arg_1325, arg_1326, arg_1327) } else { tmp1 = linked_1323.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1322, arg_1325, arg_1326, arg_1327) }; return lang.Tuple_Create_O_O__IPersistentVector(s__3, tmp1) }
func A_arbace_c2j_node_qe_seq_fn__400000264_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_qe_seq_fn__400000264_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_seq_fn__400000264_A{}; t.Ctor_O_O(p0, p1); return t }
//line :395:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000264_A) Ctor_O_O(c__env, c__v any) { t.F_env = c__env; t.F_v = c__v }
//line :395:1
func (t *A_arbace_c2j_node_qe_seq_fn__400000264_A) Invoke_O_O__O(self, p1__400000186_SHARP___1 any) any { var root_1340 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, A_arbace_c2j_node_qe_A_fn_class); var ifn_1342 lang.IFn; if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = t.F_env; var arg_1344 any = t.F_v; var arg_1345 any = p1__400000186_SHARP___1; if linked_1341 == nil { return ifn_1342.Invoke_O_O_O__O(arg_1343, arg_1344, arg_1345) } else { return linked_1341.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1340, arg_1343, arg_1344, arg_1345) } }


func A_arbace_c2j_node_qe_A_New() *A_arbace_c2j_node_qe_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_qe_A{}; t.Ctor(); return t }
//line :398:1
func (t *A_arbace_c2j_node_qe_A) Ctor() {}
//line :398:1
func (t *A_arbace_c2j_node_qe_A) Invoke_O_O_O_O__O(self, env__0, v__1, t__2 any) any {


	var tmp1 any; var root_1374 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1376 lang.IFn
	if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = t__2; if linked_1375 == nil { tmp1 = ifn_1376.Invoke_O__O(arg_1377) } else { tmp1 = linked_1375.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1374, arg_1377) }
//line :401:1
	if jrt.J2g_Truth(tmp1) { var temp__1927000408__auto____4 any = lang.IFn_Cast(env__0).Invoke_O__O(t__2)
		if jrt.J2g_Truth(temp__1927000408__auto____4) { var b__5 any = temp__1927000408__auto____4; var G__400000273__6_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__5)
			switch lang.Util_Hash_O__I_NoInit(G__400000273__6_) >> 0 & 3 { case 1: if any(G__400000273__6_) == any(A_arbace_c2j_node_A_const_219) {


				return A_arbace_c2j_node_A_const_237.Invoke_O__O(b__5) }
//line :403:1
			case 2: if any(G__400000273__6_) == any(A_arbace_c2j_node_A_const_132) {

				return A_arbace_c2j_node_A_const_237.Invoke_O__O(b__5) }
//line :403:1
			case 3: if any(G__400000273__6_) == any(A_arbace_c2j_node_A_const_156) {
				var tmp2 any; var root_1379 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = A_arbace_c2j_node_A_const_239.Invoke_O__O(v__1); var arg_1383 any = t__2; if linked_1380 == nil { tmp2 = ifn_1381.Invoke_O_O__O(arg_1382, arg_1383) } else { tmp2 = linked_1380.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1379, arg_1382, arg_1383) }; if jrt.J2g_Truth(tmp2) { return lang.RT_Get_O_O__O_NoInit(A_arbace_c2j_node_A_const_239.Invoke_O__O(v__1), t__2) } else { return A_arbace_c2j_node_A_const_171.Invoke_O__O(b__5) } }
//line :403:1
			default:}; return t__2 } else {
//line :402:1
				return t__2 } } else {
//line :401:1
					var tmp3 any; var root_1384 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1386 lang.IFn







					if linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any = t__2; if linked_1385 == nil { tmp3 = ifn_1386.Invoke_O__O(arg_1387) } else { tmp3 = linked_1385.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1384, arg_1387) }
//line :401:1
					if jrt.J2g_Truth(tmp3) {







						var root_1388 any = A_arbace_c2j_node_A_const_319.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, A_arbace_c2j_node_qe_seq_A_fn_class); var ifn_1390 lang.IFn; if linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = env__0; var arg_1392 any = v__1; var arg_1393 any = t__2; if linked_1389 == nil { return ifn_1390.Invoke_O_O_O__O(arg_1391, arg_1392, arg_1393) } else { return linked_1389.(*A_arbace_c2j_node_qe_seq_A).Invoke_O_O_O_O__O(root_1388, arg_1391, arg_1392, arg_1393) } } else {
//line :401:1
							var tmp4 any; var root_1394 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_1395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1394, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1396 lang.IFn








							if linked_1395 == nil { ifn_1396 = lang.IFn_Cast(root_1394) } else { ifn_1396 = nil }; var arg_1397 any = t__2; if linked_1395 == nil { tmp4 = ifn_1396.Invoke_O__O(arg_1397) } else { tmp4 = linked_1395.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1394, arg_1397) }
//line :401:1
							if jrt.J2g_Truth(tmp4) {








								var root_1398 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1398, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1400 lang.IFn; if linked_1399 == nil { ifn_1400 = lang.IFn_Cast(root_1398) } else { ifn_1400 = nil }; var arg_1401 any; var root_1403 any = A_arbace_c2j_node_A_const_223.GetRawRoot__O(); var linked_1404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1403, A_arbace_c2j_node_qe_elems_A_fn_class); var ifn_1405 lang.IFn; if linked_1404 == nil { ifn_1405 = lang.IFn_Cast(root_1403) } else { ifn_1405 = nil }; var arg_1406 any = env__0; var arg_1407 any = v__1; var arg_1408 any = t__2; if linked_1404 == nil { arg_1401 = ifn_1405.Invoke_O_O_O__O(arg_1406, arg_1407, arg_1408) } else { arg_1401 = linked_1404.(*A_arbace_c2j_node_qe_elems_A).Invoke_O_O_O_O__O(root_1403, arg_1406, arg_1407, arg_1408) }; var arg_1402 any = lang.RT_Meta_O__IPersistentMap_NoInit(t__2); if linked_1399 == nil { return ifn_1400.Invoke_O_O__O(arg_1401, arg_1402) } else { return linked_1399.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1398, arg_1401, arg_1402) } } else {
//line :401:1
									if A_arbace_c2j_node_A_const_45 != nil { return t__2 } else { return nil
									}
								}
						}
				}
}






func A_arbace_c2j_node_splits_A_New() *A_arbace_c2j_node_splits_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_splits_A{}; t.Ctor(); return t }
//line :413:1
func (t *A_arbace_c2j_node_splits_A) Ctor() {}
//line :413:1
func (t *A_arbace_c2j_node_splits_A) Invoke_O_O__O(self, d__0 any) any { var tested__2 any; var root_1409 any = A_arbace_c2j_node_A_const_257.GetRawRoot__O(); var linked_1410 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1409, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1411 lang.IFn; if


	linked_1410 == nil { ifn_1411 = lang.IFn_Cast(root_1409) } else { ifn_1411 = nil }; var arg_1412 any = lang.PersistentHashSet_EMPTY.Ref(); if linked_1410 == nil { tested__2 = ifn_1411.Invoke_O__O(arg_1412) } else { tested__2 = linked_1410.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1409, arg_1412) }; var body_w__3 /*line :413:1*/*A_arbace_c2j_node_splits_w__400000275_A = A_arbace_c2j_node_splits_w__400000275_A_New_O(tested__2); var w__3 any; var fnbody__1474 any = any(body_w__3); var tmp1 *jrt.Class; var fncls__1473 *jrt.Class = A_arbace_c2j_node_splits_w__400000275_A_fn_class; if fncls__1473 == nil { var fncls__1473d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, fnbody__1474); A_arbace_c2j_node_splits_w__400000275_A_fn_class = fncls__1473d; tmp1 = fncls__1473d } else { tmp1 = fncls__1473 }; w__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1474, tmp1, nil);






	lang.IFn_Cast(w__3).Invoke_O__O(A_arbace_c2j_node_A_const_26.Invoke_O__O(d__0)); var root_1413 any =
	A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1413, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1415 lang.IFn; if linked_1414 == nil { ifn_1415 = lang.IFn_Cast(root_1413) } else { ifn_1415 = nil }; var arg_1416 any; var root_1417 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_1418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1417, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1419 lang.IFn; if linked_1418 == nil { ifn_1419 = lang.IFn_Cast(root_1417) } else { ifn_1419 = nil }; var arg_1420 any; var fnbody__1432 any = A_arbace_c2j_node_splits_fn__400000277_A_New_O(tested__2); var tmp2 *jrt.Class; var fncls__1431 *jrt.Class = A_arbace_c2j_node_splits_fn__400000277_A_fn_class; if fncls__1431 == nil { var fncls__1431d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, fnbody__1432); A_arbace_c2j_node_splits_fn__400000277_A_fn_class = fncls__1431d; tmp2 = fncls__1431d } else { tmp2 = fncls__1431 }; arg_1420 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1432, tmp2, nil); var arg_1421 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_1418 == nil { arg_1416 = ifn_1419.Invoke_O_O__O(arg_1420, arg_1421) } else { arg_1416 = linked_1418.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1417, arg_1420, arg_1421) }; if linked_1414 == nil { return ifn_1415.Invoke_O__O(arg_1416) } else { return linked_1414.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1413, arg_1416) } }
//line :417:1
func A_arbace_c2j_node_splits_w__400000275_A_New_O(p0 any) *A_arbace_c2j_node_splits_w__400000275_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_splits_w__400000275_A{}; t.Ctor_O(p0); return t }
//line :417:1
func (t *A_arbace_c2j_node_splits_w__400000275_A) Ctor_O(c__tested any) { t.F_tested = c__tested }
//line :417:1
func (t *A_arbace_c2j_node_splits_w__400000275_A) Invoke_O_O__O(self, t__1 any) any { var tmp1 any; var root_1433 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = t__1; if linked_1434 == nil { tmp1 = ifn_1435.Invoke_O__O(arg_1436) } else { tmp1 = linked_1434.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1433, arg_1436) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var and__1927000168__auto____2 bool; var tmp3 any = A_arbace_c2j_node_A_const_321; var tmp4 any; var root_1451 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, A_arbace_c2j_node_head_A_fn_class); var ifn_1453 lang.IFn; if linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = t__1; if linked_1452 == nil { tmp4 = ifn_1453.Invoke_O__O(arg_1454) } else { tmp4 = linked_1452.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_1451, arg_1454) }; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z_NoInit(tmp3, tmp4); if and__1927000168__auto____2 { var root_1455 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1457 lang.IFn; if linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any; var root_1459 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_1460 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1459, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1461 lang.IFn; if linked_1460 == nil { ifn_1461 = lang.IFn_Cast(root_1459) } else { ifn_1461 = nil }; var arg_1462 any = t__1; if linked_1460 == nil { arg_1458 = ifn_1461.Invoke_O__O(arg_1462) } else { arg_1458 = linked_1460.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1459, arg_1462) }; if linked_1456 == nil { tmp2 = ifn_1457.Invoke_O__O(arg_1458) } else { tmp2 = linked_1456.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1455, arg_1458) } } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp2) { var root_1463 any = A_arbace_c2j_node_A_const_9.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = t.F_tested; var arg_1467 any = A_arbace_c2j_node_A_const_7.GetRawRoot__O(); var arg_1468 any; var root_1469 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_1470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1469, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1471 lang.IFn; if linked_1470 == nil { ifn_1471 = lang.IFn_Cast(root_1469) } else { ifn_1471 = nil }; var arg_1472 any = t__1; if linked_1470 == nil { arg_1468 = ifn_1471.Invoke_O__O(arg_1472) } else { arg_1468 = linked_1470.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1469, arg_1472) }; if linked_1464 == nil { ifn_1465.Invoke_O_O_O__O(arg_1466, arg_1467, arg_1468) } else { linked_1464.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_1463, arg_1466, arg_1467, arg_1468) } }
											var root_1437 any = A_arbace_c2j_node_A_const_320.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = self; var arg_1441 any = t__1; if linked_1438 == nil { return ifn_1439.Invoke_O_O__O(arg_1440, arg_1441) } else { return linked_1438.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_1437, arg_1440, arg_1441) } } else {
//line :417:1
		var tmp5 any; var root_1442 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1442, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1444 lang.IFn

		if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any = t__1; if linked_1443 == nil { tmp5 = ifn_1444.Invoke_O__O(arg_1445) } else { tmp5 = linked_1443.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1442, arg_1445) }
//line :417:1
		if jrt.J2g_Truth(tmp5) {

			var root_1446 any = A_arbace_c2j_node_A_const_320.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = self; var arg_1450 any = t__1; if linked_1447 == nil { return ifn_1448.Invoke_O_O__O(arg_1449, arg_1450) } else { return linked_1447.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_1446, arg_1449, arg_1450) } } else {
//line :417:1
				return nil } } }



func A_arbace_c2j_node_splits_fn__400000277_A_New_O(p0 any) *A_arbace_c2j_node_splits_fn__400000277_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_splits_fn__400000277_A{}; t.Ctor_O(p0); return t }
//line :421:1
func (t *A_arbace_c2j_node_splits_fn__400000277_A) Ctor_O(c__tested any) { t.F_tested = c__tested }
//line :421:1
func (t *A_arbace_c2j_node_splits_fn__400000277_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 any; var root_1422 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any; var root_1427 any = A_arbace_c2j_node_A_const_5.GetRawRoot__O(); var linked_1428 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1427, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1429 lang.IFn; if linked_1428 == nil { ifn_1429 = lang.IFn_Cast(root_1427) } else { ifn_1429 = nil }; var arg_1430 any = t.F_tested; if linked_1428 == nil { arg_1425 = ifn_1429.Invoke_O__O(arg_1430) } else { arg_1425 = linked_1428.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1427, arg_1430) }; var arg_1426 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); if linked_1423 == nil { tmp1 = ifn_1424.Invoke_O_O__O(arg_1425, arg_1426) } else { tmp1 = linked_1423.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1422, arg_1425, arg_1426) }; if jrt.J2g_Truth(tmp1) { return A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1) } else { return nil } }

func A_arbace_c2j_node_uses_many_QMARK__A_New() *A_arbace_c2j_node_uses_many_QMARK__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_uses_many_QMARK__A{}; t.Ctor(); return t }
//line :423:1
func (t *A_arbace_c2j_node_uses_many_QMARK__A) Ctor() {}
//line :423:1
func (t *A_arbace_c2j_node_uses_many_QMARK__A) Invoke_O_O__O(self, d__0 any) any { var r__2 any; var root_1475 any = A_arbace_c2j_node_A_const_257.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_1477 lang.IFn; if
											linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = jrt.Boolean_FALSE.Ref(); if linked_1476 == nil { r__2 = ifn_1477.Invoke_O__O(arg_1478) } else { r__2 = linked_1476.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_1475, arg_1478) }; var body_w__3 /*line :423:1*/*A_arbace_c2j_node_uses_many_QMARK__w__400000280_A = A_arbace_c2j_node_uses_many_QMARK__w__400000280_A_New_O(r__2); var w__3 any; var fnbody__1511 any = any(body_w__3); var tmp1 *jrt.Class; var fncls__1510 *jrt.Class = A_arbace_c2j_node_uses_many_QMARK__w__400000280_A_fn_class; if fncls__1510 == nil { var fncls__1510d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, false, fnbody__1511); A_arbace_c2j_node_uses_many_QMARK__w__400000280_A_fn_class = fncls__1510d; tmp1 = fncls__1510d } else { tmp1 = fncls__1510 }; w__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1511, tmp1, nil);



	lang.IFn_Cast(w__3).Invoke_O__O(A_arbace_c2j_node_A_const_26.Invoke_O__O(d__0)); var root_1479 any = /*line :424:1*/A_arbace_c2j_node_A_const_5.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = r__2; if linked_1480 == nil { return ifn_1481.Invoke_O__O(arg_1482) } else { return linked_1480.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1479, arg_1482) } }
func A_arbace_c2j_node_uses_many_QMARK__w__400000280_A_New_O(p0 any) *A_arbace_c2j_node_uses_many_QMARK__w__400000280_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_uses_many_QMARK__w__400000280_A{}; t.Ctor_O(p0); return t }
//line :425:1
func (t *A_arbace_c2j_node_uses_many_QMARK__w__400000280_A) Ctor_O(c__r any) { t.F_r = c__r }
//line :425:1
func (t *A_arbace_c2j_node_uses_many_QMARK__w__400000280_A) Invoke_O_O__O(self, t__1 any) any { var tmp1 any; var root_1483 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = t__1; if linked_1484 == nil { tmp1 = ifn_1485.Invoke_O__O(arg_1486) } else { tmp1 = linked_1484.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1483, arg_1486) }; if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_c2j_node_A_const_322; var tmp3 any; var root_1501 any = A_arbace_c2j_node_A_const_47.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, A_arbace_c2j_node_head_A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = t__1; if linked_1502 == nil { tmp3 = ifn_1503.Invoke_O__O(arg_1504) } else { tmp3 = linked_1502.(*A_arbace_c2j_node_head_A).Invoke_O_O__O(root_1501, arg_1504) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { var root_1505 any = A_arbace_c2j_node_A_const_323.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_reset_BANG__A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any = t.F_r; var arg_1509 any = jrt.Boolean_TRUE.Ref(); if linked_1506 == nil { ifn_1507.Invoke_O_O__O(arg_1508, arg_1509) } else { linked_1506.(*aot_arbace_core.A_arbace_core_reset_BANG__A).Invoke_O_O_O__O(root_1505, arg_1508, arg_1509) } }; var root_1487 any = A_arbace_c2j_node_A_const_320.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = self; var arg_1491 any = t__1; if linked_1488 == nil { return ifn_1489.Invoke_O_O__O(arg_1490, arg_1491) } else { return linked_1488.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_1487, arg_1490, arg_1491) } } else { var tmp4 any; var root_1492 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1494 lang.IFn
												if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = t__1; if linked_1493 == nil { tmp4 = ifn_1494.Invoke_O__O(arg_1495) } else { tmp4 = linked_1493.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1492, arg_1495) }
//line :425:1
	if jrt.J2g_Truth(tmp4) {
		var root_1496 any = A_arbace_c2j_node_A_const_320.GetRawRoot__O(); var linked_1497 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1496, aot_arbace_core.A_arbace_core_run_BANG__A_fn_class); var ifn_1498 lang.IFn; if linked_1497 == nil { ifn_1498 = lang.IFn_Cast(root_1496) } else { ifn_1498 = nil }; var arg_1499 any = self; var arg_1500 any = t__1; if linked_1497 == nil { return ifn_1498.Invoke_O_O__O(arg_1499, arg_1500) } else { return linked_1497.(*aot_arbace_core.A_arbace_core_run_BANG__A).Invoke_O_O_O__O(root_1496, arg_1499, arg_1500) } } else {
//line :425:1
			return nil } } }




func A_arbace_c2j_node_camel_A_New() *A_arbace_c2j_node_camel_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_camel_A{}; t.Ctor(); return t }
//line :430:1
func (t *A_arbace_c2j_node_camel_A) Ctor() {}
//line :430:1
func (t *A_arbace_c2j_node_camel_A) Invoke_O_O__O(self, s__0 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp2 any; var root_1512 any = A_arbace_c2j_node_A_const_324.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_string.A_arbace_string_upper_case_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any; var root_1516 any = A_arbace_c2j_node_A_const_325.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1518 lang.IFn; if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any; var root_1522 any = A_arbace_c2j_node_A_const_188.GetRawRoot__O(); var linked_1523 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1522, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1524 lang.IFn; if linked_1523 == nil { ifn_1524 = lang.IFn_Cast(root_1522) } else { ifn_1524 = nil }; var arg_1525 any = s__0; if linked_1523 == nil { arg_1519 = ifn_1524.Invoke_O__O(arg_1525) } else { arg_1519 = linked_1523.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1522, arg_1525) }; var arg_1520 any = A_arbace_c2j_node_A_const_258; var arg_1521 any = A_arbace_c2j_node_A_const_326; if linked_1517 == nil { arg_1515 = ifn_1518.Invoke_O_O_O__O(arg_1519, arg_1520, arg_1521) } else { arg_1515 = linked_1517.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1516, arg_1519, arg_1520, arg_1521) }; if linked_1513 == nil { tmp2 = ifn_1514.Invoke_O__O(arg_1515) } else { tmp2 = linked_1513.(*aot_arbace_string.A_arbace_string_upper_case_A).Invoke_O_O__O(root_1512, arg_1515) }; var tmp3 any = tmp2; var tmp4 any; var root_1526 any = A_arbace_c2j_node_A_const_325.GetRawRoot__O(); var linked_1527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1526, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1528 lang.IFn; if linked_1527 == nil { ifn_1528 = lang.IFn_Cast(root_1526) } else { ifn_1528 = nil }; var arg_1529 any; var root_1531 any = A_arbace_c2j_node_A_const_188.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1531, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1533 lang.IFn; if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = s__0; if linked_1532 == nil { arg_1529 = ifn_1533.Invoke_O__O(arg_1534) } else { arg_1529 = linked_1532.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1531, arg_1534) }; var arg_1530 any = A_arbace_c2j_node_A_const_326; if linked_1527 == nil { tmp4 = ifn_1528.Invoke_O_O__O(arg_1529, arg_1530) } else { tmp4 = linked_1527.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1526, arg_1529, arg_1530) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)).Ref() }

func A_arbace_c2j_node_sym_occurs_QMARK__A_New() *A_arbace_c2j_node_sym_occurs_QMARK__A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_sym_occurs_QMARK__A{}; t.Ctor(); return t }
//line :432:1
func (t *A_arbace_c2j_node_sym_occurs_QMARK__A) Ctor() {}
//line :432:1
func (t *A_arbace_c2j_node_sym_occurs_QMARK__A) Invoke_O_O_O__O(self, s__0, f__1 any) any {
	var tmp1 any; var root_1535 any = A_arbace_c2j_node_A_const_34.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = f__1; if linked_1536 == nil { tmp1 = ifn_1537.Invoke_O__O(arg_1538) } else { tmp1 = linked_1536.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_1535, arg_1538) }; if jrt.J2g_Truth(tmp1) { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(s__0, f__1)).Ref() } else { var tmp2 any; var or__1927000174__auto____3 any; var root_1539 any = A_arbace_c2j_node_A_const_36.GetRawRoot__O(); var linked_1540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1539, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_1541 lang.IFn
		if linked_1540 == nil { ifn_1541 = lang.IFn_Cast(root_1539) } else { ifn_1541 = nil }; var arg_1542 any = f__1; if linked_1540 == nil { or__1927000174__auto____3 = ifn_1541.Invoke_O__O(arg_1542) } else { or__1927000174__auto____3 = linked_1540.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_1539, arg_1542) }; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { var root_1543 any = A_arbace_c2j_node_A_const_42.GetRawRoot__O(); var linked_1544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1543, aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A_fn_class); var ifn_1545 lang.IFn; if linked_1544 == nil { ifn_1545 = lang.IFn_Cast(root_1543) } else { ifn_1545 = nil }; var arg_1546 any = f__1; if linked_1544 == nil { tmp2 = ifn_1545.Invoke_O__O(arg_1546) } else { tmp2 = linked_1544.(*aot_arbace_core.A_arbace_core_vector_QMARK___1927000038_A).Invoke_O_O__O(root_1543, arg_1546) } }
//line :433:1
		if jrt.J2g_Truth(tmp2) {
			var root_1547 any = A_arbace_c2j_node_A_const_48.GetRawRoot__O(); var linked_1548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1547, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_1549 lang.IFn; if linked_1548 == nil { ifn_1549 = lang.IFn_Cast(root_1547) } else { ifn_1549 = nil }; var arg_1550 any; var fnbody__1558 any = A_arbace_c2j_node_sym_occurs_QMARK__fn__400000285_A_New_O(s__0); var tmp3 *jrt.Class; var fncls__1557 *jrt.Class = A_arbace_c2j_node_sym_occurs_QMARK__fn__400000285_A_fn_class; if fncls__1557 == nil { var fncls__1557d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__1558); A_arbace_c2j_node_sym_occurs_QMARK__fn__400000285_A_fn_class = fncls__1557d; tmp3 = fncls__1557d } else { tmp3 = fncls__1557 }; arg_1550 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1558, tmp3, nil); var arg_1551 any = f__1; if linked_1548 == nil { return ifn_1549.Invoke_O_O__O(arg_1550, arg_1551) } else { return linked_1548.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_1547, arg_1550, arg_1551) } } else {
//line :433:1
				if A_arbace_c2j_node_A_const_45 != nil { return jrt.Boolean_FALSE.Ref() } else { return nil } } } }
func A_arbace_c2j_node_sym_occurs_QMARK__fn__400000285_A_New_O(p0 any) *A_arbace_c2j_node_sym_occurs_QMARK__fn__400000285_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_sym_occurs_QMARK__fn__400000285_A{}; t.Ctor_O(p0); return t }
//line :434:1
func (t *A_arbace_c2j_node_sym_occurs_QMARK__fn__400000285_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :434:1
func (t *A_arbace_c2j_node_sym_occurs_QMARK__fn__400000285_A) Invoke_O_O__O(self, p1__400000284_SHARP___1 any) any { var root_1552 any = A_arbace_c2j_node_A_const_327.GetRawRoot__O(); var linked_1553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1552, A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class); var ifn_1554 lang.IFn; if linked_1553 == nil { ifn_1554 = lang.IFn_Cast(root_1552) } else { ifn_1554 = nil }; var arg_1555 any = t.F_s; var arg_1556 any = p1__400000284_SHARP___1; if linked_1553 == nil { return ifn_1554.Invoke_O_O__O(arg_1555, arg_1556) } else { return linked_1553.(*A_arbace_c2j_node_sym_occurs_QMARK__A).Invoke_O_O_O__O(root_1552, arg_1555, arg_1556) } }


func A_arbace_c2j_node_tag_sym_A_New() *A_arbace_c2j_node_tag_sym_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_tag_sym_A{}; t.Ctor(); return t }
//line :437:1
func (t *A_arbace_c2j_node_tag_sym_A) Ctor() {}
//line :437:1
func (t *A_arbace_c2j_node_tag_sym_A) Invoke_O_O_O__O(self, s__0, t__1 any) any { var tmp1 bool; var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z_NoInit(t__1, nil); if or__1927000174__auto____3 { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(t__1, A_arbace_c2j_node_A_const_328) }; if tmp1 { return s__0 } else { return lang.IFn_Cast(A_arbace_c2j_node_A_const_329.GetRawRoot__O()).Invoke_O_O_O_O__O(s__0, A_arbace_c2j_node_A_const_14.GetRawRoot__O(), A_arbace_c2j_node_A_const_330, t__1) } }

func A_arbace_c2j_node_variant_class_A_New() *A_arbace_c2j_node_variant_class_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_A{}; t.Ctor(); return t }
//line :439:1
func (t *A_arbace_c2j_node_variant_class_A) Ctor() {}
//line :439:1
func (t *A_arbace_c2j_node_variant_class_A) Invoke_O_O_O__O(self, d__0, v__1 any) any { var env__3 any; var root_1566 any = A_arbace_c2j_node_A_const_44.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1568 lang.IFn; if



	linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_1570 any; var root_1571 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1572 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1571, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1573 lang.IFn; if linked_1572 == nil { ifn_1573 = lang.IFn_Cast(root_1571) } else { ifn_1573 = nil }; var arg_1574 any; var fnbody__1586 any = A_arbace_c2j_node_variant_class_fn__400000289_A_New(); var tmp1 *jrt.Class; var fncls__1585 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000289_A_fn_class; if fncls__1585 == nil { var fncls__1585d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, nil); A_arbace_c2j_node_variant_class_fn__400000289_A_fn_class = fncls__1585d; tmp1 = fncls__1585d } else { tmp1 = fncls__1585 }; arg_1574 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1586, tmp1, nil); var arg_1575 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_1572 == nil { arg_1570 = ifn_1573.Invoke_O_O__O(arg_1574, arg_1575) } else { arg_1570 = linked_1572.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1571, arg_1574, arg_1575) }; if linked_1567 == nil { env__3 = ifn_1568.Invoke_O_O__O(arg_1569, arg_1570) } else { env__3 = linked_1567.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1566, arg_1569, arg_1570) }; var chans__4 any; if






	jrt.J2g_Truth(A_arbace_c2j_node_A_const_177.Invoke_O__O(v__1)) {
		if jrt.J2g_Truth(A_arbace_c2j_node_A_const_73.Invoke_O__O(v__1)) { chans__4 = A_arbace_c2j_node_A_const_337 } else { var root_1587 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any; var root_1591 any = A_arbace_c2j_node_A_const_338.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var tmp2 *lang.Keyword = A_arbace_c2j_node_A_const_253; var arg_1594 any = tmp2.Invoke_O__O(A_arbace_c2j_node_A_const_177.Invoke_O__O(v__1)); if linked_1592 == nil { arg_1590 = ifn_1593.Invoke_O__O(arg_1594) } else { arg_1590 = linked_1592.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1591, arg_1594) }; if linked_1588 == nil { chans__4 = ifn_1589.Invoke_O__O(arg_1590) } else { chans__4 = linked_1588.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1587, arg_1590) } } } else {
//line :450:1
			var tmp3 *lang.Keyword = A_arbace_c2j_node_A_const_339; var or__1927000174__auto____4 any = tmp3.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0))

			if jrt.J2g_Truth(or__1927000174__auto____4) { chans__4 = or__1927000174__auto____4 } else { chans__4 = A_arbace_c2j_node_A_const_340 } }; var domain__5 any = /*line :439:1*/A_arbace_c2j_node_A_const_341.Invoke_O__O(v__1); var method__6 any; var fnbody__1663 any = A_arbace_c2j_node_variant_class_method__400000292_A_New_O_O_O_O(d__0, env__3, v__1, domain__5); var tmp4 *jrt.Class; var fncls__1662 *jrt.Class = A_arbace_c2j_node_variant_class_method__400000292_A_fn_class; if














	fncls__1662 == nil { var fncls__1662d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, false, fnbody__1663); A_arbace_c2j_node_variant_class_method__400000292_A_fn_class = fncls__1662d; tmp4 = fncls__1662d } else { tmp4 = fncls__1662 }; method__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1663, tmp4, nil); var methods__7 any; var root_1664 any = /*line :439:1*/A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1664, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1666 lang.IFn; if



























	linked_1665 == nil { ifn_1666 = lang.IFn_Cast(root_1664) } else { ifn_1666 = nil }; var arg_1667 any; var root_1668 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_1669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1668, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1670 lang.IFn; if linked_1669 == nil { ifn_1670 = lang.IFn_Cast(root_1668) } else { ifn_1670 = nil }; var arg_1671 any = method__6; var arg_1672 any = chans__4; if linked_1669 == nil { arg_1667 = ifn_1670.Invoke_O_O__O(arg_1671, arg_1672) } else { arg_1667 = linked_1669.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1668, arg_1671, arg_1672) }; if linked_1665 == nil { methods__7 = ifn_1666.Invoke_O__O(arg_1667) } else { methods__7 = linked_1665.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1664, arg_1667) }; var cb__8 any; var root_1673 any = /*line :439:1*/A_arbace_c2j_node_A_const_355.GetRawRoot__O(); var linked_1674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1673, A_arbace_c2j_node_children_bind_A_fn_class); var ifn_1675 lang.IFn; if




























	linked_1674 == nil { ifn_1675 = lang.IFn_Cast(root_1673) } else { ifn_1675 = nil }; var arg_1676 any = d__0; if linked_1674 == nil { cb__8 = ifn_1675.Invoke_O__O(arg_1676) } else { cb__8 = linked_1674.(*A_arbace_c2j_node_children_bind_A).Invoke_O_O__O(root_1673, arg_1676) }; var conv__9 any; if
	jrt.J2g_Truth(cb__8) { var tmp5 *lang.Keyword = A_arbace_c2j_node_A_const_356; var tmp6 any; var root_1677 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_1678 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1677, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1679 lang.IFn; if linked_1678 == nil { ifn_1679 = lang.IFn_Cast(root_1677) } else { ifn_1679 = nil }; var arg_1680 any = A_arbace_c2j_node_A_const_247.GetRawRoot__O(); var arg_1681 any; var root_1682 any = A_arbace_c2j_node_A_const_357.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_1682, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_1684 lang.IFn; if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1686 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(cb__8); if linked_1683 == nil { arg_1681 = ifn_1684.Invoke_O_O__O(A_arbace_c2j_node_A_const_25, arg_1686) } else { arg_1681 = linked_1683.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_1682, 2, A_arbace_c2j_node_A_const_25, arg_1686) }; if linked_1678 == nil { tmp6 = ifn_1679.Invoke_O_O__O(arg_1680, arg_1681) } else { tmp6 = linked_1678.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1677, arg_1680, arg_1681) }; conv__9 = tmp5.Invoke_O__O(tmp6) } else { conv__9 = nil }; var fields__10 any; var root_1687 any = /*line :439:1*/A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1687, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1689 lang.IFn; if































	linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any; var root_1691 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any; if
	jrt.J2g_Truth(domain__5) { var tmp7 any = A_arbace_c2j_node_A_const_211; var tmp8 any; var root_1696 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = A_arbace_c2j_node_A_const_358; var arg_1700 any = A_arbace_c2j_node_A_const_359; if linked_1697 == nil { tmp8 = ifn_1698.Invoke_O_O__O(arg_1699, arg_1700) } else { tmp8 = linked_1697.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1696, arg_1699, arg_1700) }; arg_1694 = lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp8, A_arbace_c2j_node_A_const_360, A_arbace_c2j_node_A_const_361))) } else { arg_1694 = nil }; var arg_1695 any; var tmp9 lang.IFn = /*line :471:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp10 *lang.Compiler_AOTFn; var fnbody__1795 any = A_arbace_c2j_node_variant_class_fn__400000305_A_New_O_O_O(conv__9, methods__7, v__1); var tmp11 *jrt.Class; var fncls__1794 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000305_A_fn_class; if

	fncls__1794 == nil { var fncls__1794d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, fnbody__1795); A_arbace_c2j_node_variant_class_fn__400000305_A_fn_class = fncls__1794d; tmp11 = fncls__1794d } else { tmp11 = fncls__1794 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1795, tmp11, nil); arg_1695 = tmp9.Invoke_O_O__O(tmp10.Ref(), A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0)); if /*line :471:1*/ linked_1692 == nil { arg_1690 = ifn_1693.Invoke_O_O__O(arg_1694, arg_1695) } else { arg_1690 = linked_1692.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1691, arg_1694, arg_1695) }; if linked_1688 == nil { fields__10 = ifn_1689.Invoke_O__O(arg_1690) } else { fields__10 = linked_1688.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1687, arg_1690) }; var bare__11 any; var fnbody__1802 any = /*line :439:1*/A_arbace_c2j_node_variant_class_bare__400000312_A_New(); var tmp12 *jrt.Class; var fncls__1801 *jrt.Class = A_arbace_c2j_node_variant_class_bare__400000312_A_fn_class; if


















































	fncls__1801 == nil { var fncls__1801d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); A_arbace_c2j_node_variant_class_bare__400000312_A_fn_class = fncls__1801d; tmp12 = fncls__1801d } else { tmp12 = fncls__1801 }; bare__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1802, tmp12, nil); var tmp13 lang.IFn = /*line :439:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_node_A_const_382; var tmp16 any; var root_1810 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1810, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1812 lang.IFn; if




















































	linked_1811 == nil { ifn_1812 = lang.IFn_Cast(root_1810) } else { ifn_1812 = nil }; var arg_1813 any; var root_1815 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1815, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1817 lang.IFn; if linked_1816 == nil { ifn_1817 = lang.IFn_Cast(root_1815) } else { ifn_1817 = nil }; var arg_1818 any = A_arbace_c2j_node_A_const_349.Invoke_O__O(v__1); if linked_1816 == nil { arg_1813 = ifn_1817.Invoke_O__O(arg_1818) } else { arg_1813 = linked_1816.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1815, arg_1818) }; var arg_1814 any = A_arbace_c2j_node_A_const_383; if linked_1811 == nil { tmp16 = ifn_1812.Invoke_O_O__O(arg_1813, arg_1814) } else { tmp16 = linked_1811.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1810, arg_1813, arg_1814) }; var tmp17 any = /*line :439:1*/tmp14.Invoke_O_O_O_O__O(tmp15, tmp16, A_arbace_c2j_node_A_const_384, A_arbace_c2j_node_A_const_385); var tmp18 any; var root_1819 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1821 lang.IFn; if






















































	linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any; var fnbody__1850 any = A_arbace_c2j_node_variant_class_fn__400000315_A_New(); var tmp19 *jrt.Class; var fncls__1849 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000315_A_fn_class; if fncls__1849 == nil { var fncls__1849d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, nil); A_arbace_c2j_node_variant_class_fn__400000315_A_fn_class = fncls__1849d; tmp19 = fncls__1849d } else { tmp19 = fncls__1849 }; arg_1822 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1850, tmp19, nil); var arg_1823 any = fields__10; if linked_1820 == nil { tmp18 = ifn_1821.Invoke_O_O__O(arg_1822, arg_1823) } else { tmp18 = linked_1820.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1819, arg_1822, arg_1823) }; var tmp20 any = tmp18; var tmp21 any; var root_1851 any = /*line :439:1*/A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_1852 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1851, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_1853 lang.IFn; if























































	linked_1852 == nil { ifn_1853 = lang.IFn_Cast(root_1851) } else { ifn_1853 = nil }; var arg_1854 any = A_arbace_c2j_node_A_const_389; var arg_1855 any; var root_1857 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any; var root_1862 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1862, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1864 lang.IFn; if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any; var root_1866 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_1867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1866, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1868 lang.IFn; if linked_1867 == nil { ifn_1868 = lang.IFn_Cast(root_1866) } else { ifn_1868 = nil }; var arg_1869 any = A_arbace_c2j_node_A_const_390; var arg_1870 any; var root_1871 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1872 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1871, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1873 lang.IFn; if linked_1872 == nil { ifn_1873 = lang.IFn_Cast(root_1871) } else { ifn_1873 = nil }; var arg_1874 any = A_arbace_c2j_node_A_const_211; var arg_1875 any = fields__10; if linked_1872 == nil { arg_1870 = ifn_1873.Invoke_O_O__O(arg_1874, arg_1875) } else { arg_1870 = linked_1872.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1871, arg_1874, arg_1875) }; if linked_1867 == nil { arg_1865 = ifn_1868.Invoke_O_O__O(arg_1869, arg_1870) } else { arg_1865 = linked_1867.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1866, arg_1869, arg_1870) }; if linked_1863 == nil { arg_1860 = ifn_1864.Invoke_O__O(arg_1865) } else { arg_1860 = linked_1863.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1862, arg_1865) }; var arg_1861 any = A_arbace_c2j_node_A_const_391; if linked_1858 == nil { arg_1855 = ifn_1859.Invoke_O_O__O(arg_1860, arg_1861) } else { arg_1855 = linked_1858.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1857, arg_1860, arg_1861) }; var arg_1856 any; var root_1876 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1877 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1876, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1878 lang.IFn; if
	linked_1877 == nil { ifn_1878 = lang.IFn_Cast(root_1876) } else { ifn_1878 = nil }; var arg_1879 any; var fnbody__1902 any = A_arbace_c2j_node_variant_class_fn__400000320_A_New_O(bare__11); var tmp22 *jrt.Class; var fncls__1901 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000320_A_fn_class; if fncls__1901 == nil { var fncls__1901d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, fnbody__1902); A_arbace_c2j_node_variant_class_fn__400000320_A_fn_class = fncls__1901d; tmp22 = fncls__1901d } else { tmp22 = fncls__1901 }; arg_1879 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1902, tmp22, nil); var arg_1880 any = fields__10; if linked_1877 == nil { arg_1856 = ifn_1878.Invoke_O_O__O(arg_1879, arg_1880) } else { arg_1856 = linked_1877.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1876, arg_1879, arg_1880) }; if /*line :495:1*/ linked_1852 == nil { tmp21 = ifn_1853.Invoke_O_O_O__O(arg_1854, arg_1855, arg_1856) } else { tmp21 = linked_1852.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_1851, arg_1854, arg_1855, arg_1856) }; return /*line :439:1*/ lang.Tuple_Create_O_O__IPersistentVector(tmp13.Invoke_O_O_O_O__O(tmp17, tmp20, lang.Tuple_Create_O__IPersistentVector(tmp21), methods__7), fields__10) }



func A_arbace_c2j_node_variant_class_fn__400000289_A_New() *A_arbace_c2j_node_variant_class_fn__400000289_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000289_A{}; t.Ctor(); return t }
//line :443:1
func (t *A_arbace_c2j_node_variant_class_fn__400000289_A) Ctor() {}
//line :443:1
func (t *A_arbace_c2j_node_variant_class_fn__400000289_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp2 any; var G__400000290__2_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__1); L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__400000290__2_) >> 8 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__400000290__2_, A_arbace_c2j_node_A_const_331) { tmp2 = A_arbace_c2j_node_A_const_332; break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__400000290__2_, A_arbace_c2j_node_A_const_333) { var tmp3 any = A_arbace_c2j_node_A_const_20; var tmp4 any = A_arbace_c2j_node_A_const_156; var tmp5 any = A_arbace_c2j_node_A_const_171; var tmp6 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp7 any = A_arbace_c2j_node_A_const_162; var tmp8 any; var root_1577 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1579 lang.IFn


	if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1578 == nil { tmp8 = ifn_1579.Invoke_O__O(arg_1580) } else { tmp8 = linked_1578.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1577, arg_1580) }
//line :443:1
	tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8)); break L1 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000290__2_, A_arbace_c2j_node_A_const_334) { var tmp9 any = A_arbace_c2j_node_A_const_20; var tmp10 any = A_arbace_c2j_node_A_const_181; var tmp11 any = A_arbace_c2j_node_A_const_171; tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10, tmp11, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1))); break L1 }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__400000290__2_, A_arbace_c2j_node_A_const_335) { var tmp12 any = A_arbace_c2j_node_A_const_20; var tmp13 any = A_arbace_c2j_node_A_const_126; var tmp14 any = A_arbace_c2j_node_A_const_171; tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1))); break L1 }; case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__400000290__2_, A_arbace_c2j_node_A_const_336) { var tmp15 any = A_arbace_c2j_node_A_const_20; var tmp16 any = A_arbace_c2j_node_A_const_156; var tmp17 any = A_arbace_c2j_node_A_const_171; var tmp18 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp19 any = A_arbace_c2j_node_A_const_162; var tmp20 any; var root_1581 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1581, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1583 lang.IFn


		if linked_1582 == nil { ifn_1583 = lang.IFn_Cast(root_1581) } else { ifn_1583 = nil }; var arg_1584 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1582 == nil { tmp20 = ifn_1583.Invoke_O__O(arg_1584) } else { tmp20 = linked_1582.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1581, arg_1584) }
//line :443:1
		tmp2 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20)); break L1 }; default:}; tmp2 = nil}; return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2) }










func A_arbace_c2j_node_variant_class_method__400000292_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variant_class_method__400000292_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_method__400000292_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :454:1
func (t *A_arbace_c2j_node_variant_class_method__400000292_A) Ctor_O_O_O_O(c__d, c__env, c__v, c__domain any) { t.F_d = c__d; t.F_env = c__env; t.F_v = c__v; t.F_domain = c__domain }
//line :454:1
func (t *A_arbace_c2j_node_variant_class_method__400000292_A) Invoke_O_O__O(self, c__1 any) any { var vec__400000293__2 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_261.GetRawRoot__O()).Invoke_O__O(c__1); var mn__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000293__2, lang.RT_IntCast_J__I_NoInit(0), nil); var rt__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000293__2, lang.RT_IntCast_J__I_NoInit(1), nil); var params__5 any; var tmp1 any = A_arbace_c2j_node_A_const_350; var tmp2 any; var root_1641 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1643 lang.IFn; if

	linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = A_arbace_c2j_node_A_const_351; var arg_1645 any = A_arbace_c2j_node_A_const_352; if linked_1642 == nil { tmp2 = ifn_1643.Invoke_O_O__O(arg_1644, arg_1645) } else { tmp2 = linked_1642.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1641, arg_1644, arg_1645) }; params__5 = /*line :454:1*/lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2); var try_qe__6 any; var fnbody__1610 any = A_arbace_c2j_node_variant_class_method__400000292_try_qe__400000296_A_New_O_O(t.F_d, t.F_env); var tmp3 *jrt.Class; var fncls__1609 *jrt.Class = A_arbace_c2j_node_variant_class_method__400000292_try_qe__400000296_A_fn_class; if


	fncls__1609 == nil { var fncls__1609d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, fnbody__1610); A_arbace_c2j_node_variant_class_method__400000292_try_qe__400000296_A_fn_class = fncls__1609d; tmp3 = fncls__1609d } else { tmp3 = fncls__1609 }; try_qe__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1610, tmp3, nil); var body__7 any; if

	jrt.J2g_Truth(t.F_domain) { var cases__7 any; var root_1611 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_1612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1611, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1613 lang.IFn
		if linked_1612 == nil { ifn_1613 = lang.IFn_Cast(root_1611) } else { ifn_1613 = nil }; var arg_1614 any; var fnbody__1625 any = A_arbace_c2j_node_variant_class_method__400000292_fn__400000299_A_New_O_O_O(c__1, try_qe__6, t.F_v); var tmp4 *jrt.Class; var fncls__1624 *jrt.Class = A_arbace_c2j_node_variant_class_method__400000292_fn__400000299_A_fn_class; if fncls__1624 == nil { var fncls__1624d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, fnbody__1625); A_arbace_c2j_node_variant_class_method__400000292_fn__400000299_A_fn_class = fncls__1624d; tmp4 = fncls__1624d } else { tmp4 = fncls__1624 }; arg_1614 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1625, tmp4, nil); var arg_1615 any = t.F_domain; if linked_1612 == nil { cases__7 = ifn_1613.Invoke_O_O__O(arg_1614, arg_1615) } else { cases__7 = linked_1612.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1611, arg_1614, arg_1615) }
		var tmp5 any; var root_1626 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1626, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1628 lang.IFn; if linked_1627 == nil { ifn_1628 = lang.IFn_Cast(root_1626) } else { ifn_1628 = nil }; var arg_1629 any = cases__7; if linked_1627 == nil { tmp5 = ifn_1628.Invoke_O__O(arg_1629) } else { tmp5 = linked_1627.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1626, arg_1629) }; if jrt.J2g_Truth(tmp5) {
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp7 any = A_arbace_c2j_node_A_const_347; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp9 any = A_arbace_c2j_node_A_const_348; body__7 = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_344, A_arbace_c2j_node_A_const_345), lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_346.GetRawRoot__O(), cases__7), lang.Tuple_Create_O__IPersistentVector(tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp9, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_349.Invoke_O__O(t.F_v), nil)).Ref())))) } else {
//line :461:1
				body__7 = nil } } else {


					var tmp10 lang.IFn = lang.IFn_Cast(try_qe__6); var tmp11 any; var root_1646 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = t.F_v; var arg_1650 any = A_arbace_c2j_node_A_const_168; var arg_1651 any = c__1; if linked_1647 == nil { tmp11 = ifn_1648.Invoke_O_O_O__O(arg_1649, arg_1650, arg_1651) } else { tmp11 = linked_1647.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1646, arg_1649, arg_1650, arg_1651) }; body__7 = tmp10.Invoke_O__O(tmp11) }; if
	jrt.J2g_Truth(body__7) {
		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp13 any = A_arbace_c2j_node_A_const_353; var tmp14 any; var root_1652 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1652, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1654 lang.IFn; if linked_1653 == nil { ifn_1654 = lang.IFn_Cast(root_1652) } else { ifn_1654 = nil }; var arg_1655 any = mn__3; var arg_1656 any = A_arbace_c2j_node_A_const_354; if linked_1653 == nil { tmp14 = ifn_1654.Invoke_O_O__O(arg_1655, arg_1656) } else { tmp14 = linked_1653.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1652, arg_1655, arg_1656) }; var tmp15 any = tmp14; var tmp16 any; if jrt.J2g_Truth(rt__4) { var root_1657 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1657, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any = params__5; var arg_1661 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_330, rt__4)); if linked_1658 == nil { tmp16 = ifn_1659.Invoke_O_O__O(arg_1660, arg_1661) } else { tmp16 = linked_1658.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1657, arg_1660, arg_1661) } } else { tmp16 = params__5 }; return tmp12.Invoke_O_O_O_O__O(tmp13, tmp15, tmp16, body__7) } else {
//line :465:1
			return nil } }
//line :457:1
func A_arbace_c2j_node_variant_class_method__400000292_try_qe__400000296_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_variant_class_method__400000292_try_qe__400000296_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_method__400000292_try_qe__400000296_A{}; t.Ctor_O_O(p0, p1); return t }
//line :457:1
func (t *A_arbace_c2j_node_variant_class_method__400000292_try_qe__400000296_A) Ctor_O_O(c__d, c__env any) { t.F_d = c__d; t.F_env = c__env }
//line :457:1
func (t *A_arbace_c2j_node_variant_class_method__400000292_try_qe__400000296_A) Invoke_O_O__O(self, v__1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1595 any = A_arbace_c2j_node_A_const_208.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, A_arbace_c2j_node_realize_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any; var root_1599 any = A_arbace_c2j_node_A_const_222.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, A_arbace_c2j_node_qe_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = t.F_env; var arg_1603 any = v__1; var arg_1604 any = A_arbace_c2j_node_A_const_26.Invoke_O__O(t.F_d); if linked_1600 == nil { arg_1598 = ifn_1601.Invoke_O_O_O__O(arg_1602, arg_1603, arg_1604) } else { arg_1598 = linked_1600.(*A_arbace_c2j_node_qe_A).Invoke_O_O_O_O__O(root_1599, arg_1602, arg_1603, arg_1604) }; if linked_1596 == nil { tmp1 = ifn_1597.Invoke_O__O(arg_1598) } else { tmp1 = linked_1596.(*A_arbace_c2j_node_realize_A).Invoke_O_O__O(root_1595, arg_1598) } }; return nil }(); if tmp2 != nil { if jrt.Exception_InstanceOf(tmp2) { var x__4 jrt.Exception_I = jrt.Exception_Cast(tmp2); var tmp3 *lang.Keyword = A_arbace_c2j_node_A_const_342; var tmp4 any; var root_1605 any = A_arbace_c2j_node_A_const_343.GetRawRoot__O(); var linked_1606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1605, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1607 lang.IFn
															if linked_1606 == nil { ifn_1607 = lang.IFn_Cast(root_1605) } else { ifn_1607 = nil }; var arg_1608 any = x__4; if linked_1606 == nil { tmp4 = ifn_1607.Invoke_O__O(arg_1608) } else { tmp4 = linked_1606.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1605, arg_1608) }; if jrt.J2g_Truth(tmp3.Invoke_O__O(tmp4)) { tmp1 = nil } else { panic(jrt.Thrown(x__4)) } } else {
//line :457:1
		panic(tmp2) } }; return tmp1 }


func A_arbace_c2j_node_variant_class_method__400000292_fn__400000299_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_variant_class_method__400000292_fn__400000299_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_method__400000292_fn__400000299_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :460:1
func (t *A_arbace_c2j_node_variant_class_method__400000292_fn__400000299_A) Ctor_O_O_O(c__c, c__try_qe, c__v any) { t.F_c = c__c; t.F_try_qe = c__try_qe; t.F_v = c__v }
//line :460:1
func (t *A_arbace_c2j_node_variant_class_method__400000292_fn__400000299_A) Invoke_O_O__O(self, p__400000298__1 any) any { var vec__400000300__2 any = p__400000298__1; var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000300__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000300__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(t.F_try_qe); var temp__1927000414__auto____5 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_c2j_node_A_const_14.GetRawRoot__O()).Invoke_O_O_O_O_O__O(t.F_v, A_arbace_c2j_node_A_const_168, t.F_c, A_arbace_c2j_node_A_const_265, m__4)); if jrt.J2g_Truth(temp__1927000414__auto____5) { var b__6 any = temp__1927000414__auto____5; return lang.Tuple_Create_O_O__IPersistentVector(i__3, b__6) } else { return nil } }












func A_arbace_c2j_node_variant_class_fn__400000305_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_variant_class_fn__400000305_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000305_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :473:1
func (t *A_arbace_c2j_node_variant_class_fn__400000305_A) Ctor_O_O_O(c__conv, c__methods, c__v any) { t.F_conv = c__conv; t.F_methods = c__methods; t.F_v = c__v }
//line :473:1
func (t *A_arbace_c2j_node_variant_class_fn__400000305_A) Invoke_O_O__O(self, b__1 any) any { var G__400000306__2_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__1); switch
												lang.Util_Hash_O__I_NoInit(G__400000306__2_) >> 8 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__400000306__2_, A_arbace_c2j_node_A_const_362) {









		var root_1707 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any; var fnbody__1713 any = A_arbace_c2j_node_variant_class_fn__400000305_fn__400000307_A_New(); var tmp1 *jrt.Class; var fncls__1712 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000305_fn__400000307_A_fn_class; if fncls__1712 == nil { var fncls__1712d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, nil); A_arbace_c2j_node_variant_class_fn__400000305_fn__400000307_A_fn_class = fncls__1712d; tmp1 = fncls__1712d } else { tmp1 = fncls__1712 }; arg_1710 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1713, tmp1, nil); var tmp2 *lang.Keyword = A_arbace_c2j_node_A_const_31; var arg_1711 any = tmp2.Invoke_O__O(A_arbace_c2j_node_A_const_177.Invoke_O__O(t.F_v)); if linked_1708 == nil { return ifn_1709.Invoke_O_O__O(arg_1710, arg_1711) } else { return linked_1708.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1707, arg_1710, arg_1711) } }
//line :474:1
	case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__400000306__2_, A_arbace_c2j_node_A_const_363) {










		var tmp3 any; var and__1927000168__auto____3 any; var root_1714 any = A_arbace_c2j_node_A_const_284.GetRawRoot__O(); var linked_1715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1714, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1716 lang.IFn; if linked_1715 == nil { ifn_1716 = lang.IFn_Cast(root_1714) } else { ifn_1716 = nil }; var arg_1717 any; var root_1718 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1720 lang.IFn; if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any = A_arbace_c2j_node_A_const_239.Invoke_O__O(t.F_v); var arg_1722 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); if linked_1719 == nil { arg_1717 = ifn_1720.Invoke_O_O__O(arg_1721, arg_1722) } else { arg_1717 = linked_1719.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1718, arg_1721, arg_1722) }; if linked_1715 == nil { and__1927000168__auto____3 = ifn_1716.Invoke_O__O(arg_1717) } else { and__1927000168__auto____3 = linked_1715.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1714, arg_1717) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
			var root_1723 any = A_arbace_c2j_node_A_const_327.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1727 any = t.F_methods; if linked_1724 == nil { tmp3 = ifn_1725.Invoke_O_O__O(arg_1726, arg_1727) } else { tmp3 = linked_1724.(*A_arbace_c2j_node_sym_occurs_QMARK__A).Invoke_O_O_O__O(root_1723, arg_1726, arg_1727) } } else {
//line :485:1
				tmp3 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp3) { var tmp4 any = A_arbace_c2j_node_A_const_211; var tmp5 any; var root_1752 any = A_arbace_c2j_node_A_const_366.GetRawRoot__O(); var linked_1753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1752, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1754 lang.IFn

					if linked_1753 == nil { ifn_1754 = lang.IFn_Cast(root_1752) } else { ifn_1754 = nil }; var arg_1755 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1756 any; var root_1757 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1759 lang.IFn; if linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1758 == nil { arg_1756 = ifn_1759.Invoke_O__O(arg_1760) } else { arg_1756 = linked_1758.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1757, arg_1760) }; if linked_1753 == nil { tmp5 = ifn_1754.Invoke_O_O__O(arg_1755, arg_1756) } else { tmp5 = linked_1753.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1752, arg_1755, arg_1756) }
//line :485:1
					var tmp6 any = tmp5; var tmp7 any = A_arbace_c2j_node_A_const_360; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1)))) } else { return nil } }
//line :474:1
	case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000306__2_, A_arbace_c2j_node_A_const_364) { var tmp8 any = A_arbace_c2j_node_A_const_211; var tmp9 any; var root_1761 any = A_arbace_c2j_node_A_const_366.GetRawRoot__O(); var linked_1762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1761, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1763 lang.IFn
		if linked_1762 == nil { ifn_1763 = lang.IFn_Cast(root_1761) } else { ifn_1763 = nil }; var arg_1764 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1765 any = A_arbace_c2j_node_A_const_377; if linked_1762 == nil { tmp9 = ifn_1763.Invoke_O_O__O(arg_1764, arg_1765) } else { tmp9 = linked_1762.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1761, arg_1764, arg_1765) }
//line :474:1
		var tmp10 any = tmp9; var tmp11 any = A_arbace_c2j_node_A_const_360; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp10, tmp11, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1)))) }; case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__400000306__2_, A_arbace_c2j_node_A_const_365) { var fld__3 any; var root_1728 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1728, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1730 lang.IFn

			if linked_1729 == nil { ifn_1730 = lang.IFn_Cast(root_1728) } else { ifn_1730 = nil }; var arg_1731 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1729 == nil { fld__3 = ifn_1730.Invoke_O__O(arg_1731) } else { fld__3 = linked_1729.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1728, arg_1731) }
			var tmp12 any = A_arbace_c2j_node_A_const_225; if lang.Util_Equiv_O_O__Z_NoInit(tmp12, A_arbace_c2j_node_A_const_226.Invoke_O__O(t.F_v)) { var tmp13 any = A_arbace_c2j_node_A_const_211; var tmp14 any; var root_1780 any = A_arbace_c2j_node_A_const_366.GetRawRoot__O(); var linked_1781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1780, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1782 lang.IFn
				if linked_1781 == nil { ifn_1782 = lang.IFn_Cast(root_1780) } else { ifn_1782 = nil }; var arg_1783 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1784 any = A_arbace_c2j_node_A_const_379; if linked_1781 == nil { tmp14 = ifn_1782.Invoke_O_O__O(arg_1783, arg_1784) } else { tmp14 = linked_1781.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1780, arg_1783, arg_1784) }
//line :477:1
				var tmp15 any = tmp14; var tmp16 any = A_arbace_c2j_node_A_const_360; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, tmp16, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_380, A_arbace_c2j_node_A_const_381, fld__3)))) } else {

					var root_1732 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_1733 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1732, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1734 lang.IFn; if linked_1733 == nil { ifn_1734 = lang.IFn_Cast(root_1732) } else { ifn_1734 = nil }; var arg_1735 any; var fnbody__1747 any = A_arbace_c2j_node_variant_class_fn__400000305_fn__400000309_A_New_O_O_O(b__1, t.F_conv, fld__3); var tmp17 *jrt.Class; var fncls__1746 *jrt.Class = A_arbace_c2j_node_variant_class_fn__400000305_fn__400000309_A_fn_class; if fncls__1746 == nil { var fncls__1746d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, fnbody__1747); A_arbace_c2j_node_variant_class_fn__400000305_fn__400000309_A_fn_class = fncls__1746d; tmp17 = fncls__1746d } else { tmp17 = fncls__1746 }; arg_1735 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1747, tmp17, nil); var arg_1736 any; var root_1748 any = A_arbace_c2j_node_A_const_231.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1750 lang.IFn



					if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = A_arbace_c2j_node_A_const_226.Invoke_O__O(t.F_v); if linked_1749 == nil { arg_1736 = ifn_1750.Invoke_O__O(arg_1751) } else { arg_1736 = linked_1749.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1748, arg_1751) }
//line :479:1
					if linked_1733 == nil { return ifn_1734.Invoke_O_O__O(arg_1735, arg_1736) } else { return linked_1733.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1732, arg_1735, arg_1736) } } }
//line :474:1
	case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__400000306__2_, A_arbace_c2j_node_A_const_378) {










		var tmp18 any; var and__1927000168__auto____3_2 any; var root_1766 any = A_arbace_c2j_node_A_const_284.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any; var root_1770 any = A_arbace_c2j_node_A_const_35.GetRawRoot__O(); var linked_1771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1770, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_1772 lang.IFn; if linked_1771 == nil { ifn_1772 = lang.IFn_Cast(root_1770) } else { ifn_1772 = nil }; var arg_1773 any = A_arbace_c2j_node_A_const_239.Invoke_O__O(t.F_v); var arg_1774 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); if linked_1771 == nil { arg_1769 = ifn_1772.Invoke_O_O__O(arg_1773, arg_1774) } else { arg_1769 = linked_1771.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_1770, arg_1773, arg_1774) }; if linked_1767 == nil { and__1927000168__auto____3_2 = ifn_1768.Invoke_O__O(arg_1769) } else { and__1927000168__auto____3_2 = linked_1767.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1766, arg_1769) }; if jrt.J2g_Truth(and__1927000168__auto____3_2) {
			var root_1775 any = A_arbace_c2j_node_A_const_327.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1775, A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class); var ifn_1777 lang.IFn; if linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1779 any = t.F_methods; if linked_1776 == nil { tmp18 = ifn_1777.Invoke_O_O__O(arg_1778, arg_1779) } else { tmp18 = linked_1776.(*A_arbace_c2j_node_sym_occurs_QMARK__A).Invoke_O_O_O__O(root_1775, arg_1778, arg_1779) } } else {
//line :485:1
				tmp18 = and__1927000168__auto____3_2 }; if jrt.J2g_Truth(tmp18) { var tmp19 any = A_arbace_c2j_node_A_const_211; var tmp20 any; var root_1785 any = A_arbace_c2j_node_A_const_366.GetRawRoot__O(); var linked_1786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1785, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1787 lang.IFn

					if linked_1786 == nil { ifn_1787 = lang.IFn_Cast(root_1785) } else { ifn_1787 = nil }; var arg_1788 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var arg_1789 any; var root_1790 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1790, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1792 lang.IFn; if linked_1791 == nil { ifn_1792 = lang.IFn_Cast(root_1790) } else { ifn_1792 = nil }; var arg_1793 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_1791 == nil { arg_1789 = ifn_1792.Invoke_O__O(arg_1793) } else { arg_1789 = linked_1791.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1790, arg_1793) }; if linked_1786 == nil { tmp20 = ifn_1787.Invoke_O_O__O(arg_1788, arg_1789) } else { tmp20 = linked_1786.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1785, arg_1788, arg_1789) }
//line :485:1
					var tmp21 any = tmp20; var tmp22 any = A_arbace_c2j_node_A_const_360; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, tmp22, A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1)))) } else { return nil } }
//line :474:1
	default:}; return nil }




func A_arbace_c2j_node_variant_class_fn__400000305_fn__400000309_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_variant_class_fn__400000305_fn__400000309_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000305_fn__400000309_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :479:1
func (t *A_arbace_c2j_node_variant_class_fn__400000305_fn__400000309_A) Ctor_O_O_O(c__b, c__conv, c__fld any) { t.F_b = c__b; t.F_conv = c__conv; t.F_fld = c__fld }
//line :479:1
func (t *A_arbace_c2j_node_variant_class_fn__400000305_fn__400000309_A) Invoke_O_O__O(self, i__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_368; var tmp3 any = A_arbace_c2j_node_A_const_369; var x__2 any = tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_370, t.F_fld, i__1)); var tmp4 any = A_arbace_c2j_node_A_const_211; var tmp5 any; var root_1737 any = A_arbace_c2j_node_A_const_366.GetRawRoot__O(); var linked_1738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1737, A_arbace_c2j_node_tag_sym_A_fn_class); var ifn_1739 lang.IFn; if

	linked_1738 == nil { ifn_1739 = lang.IFn_Cast(root_1737) } else { ifn_1739 = nil }; var arg_1740 any; var root_1742 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_19.Invoke_O__O(t.F_b), i__1)).Ref(); if linked_1743 == nil { arg_1740 = ifn_1744.Invoke_O__O(arg_1745) } else { arg_1740 = linked_1743.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1742, arg_1745) }; var arg_1741 any = A_arbace_c2j_node_A_const_367; if linked_1738 == nil { tmp5 = ifn_1739.Invoke_O_O__O(arg_1740, arg_1741) } else { tmp5 = linked_1738.(*A_arbace_c2j_node_tag_sym_A).Invoke_O_O_O__O(root_1737, arg_1740, arg_1741) }; var tmp6 any = tmp5; var tmp7 any = A_arbace_c2j_node_A_const_360; var tmp8 any; if
	jrt.J2g_Truth(t.F_conv) { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_node_A_const_371; var tmp11 any = A_arbace_c2j_node_A_const_372; tmp8 = tmp9.Invoke_O_O_O_O__O(tmp10, tmp11, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_373, A_arbace_c2j_node_A_const_374, i__1), x__2) } else { tmp8 = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_375, A_arbace_c2j_node_A_const_376, x__2) }; return /*line :479:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7, tmp8)) }




func A_arbace_c2j_node_variant_class_fn__400000305_fn__400000307_A_New() *A_arbace_c2j_node_variant_class_fn__400000305_fn__400000307_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000305_fn__400000307_A{}; t.Ctor(); return t }
//line :484:1
func (t *A_arbace_c2j_node_variant_class_fn__400000305_fn__400000307_A) Ctor() {}
//line :484:1
func (t *A_arbace_c2j_node_variant_class_fn__400000305_fn__400000307_A) Invoke_O_O__O(self, s__1 any) any { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_211, s__1)) }





func A_arbace_c2j_node_variant_class_bare__400000312_A_New() *A_arbace_c2j_node_variant_class_bare__400000312_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_bare__400000312_A{}; t.Ctor(); return t }
//line :490:1
func (t *A_arbace_c2j_node_variant_class_bare__400000312_A) Ctor() {}
//line :490:1
func (t *A_arbace_c2j_node_variant_class_bare__400000312_A) Invoke_O_O__O(self, s__1 any) any { var root_1796 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = s__1; var arg_1800 any; if linked_1797 == nil { return ifn_1798.Invoke_O_O__O(arg_1799, arg_1800) } else { return linked_1797.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_1796, arg_1799, arg_1800) } }



func A_arbace_c2j_node_variant_class_fn__400000315_A_New() *A_arbace_c2j_node_variant_class_fn__400000315_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000315_A{}; t.Ctor(); return t }
//line :494:1
func (t *A_arbace_c2j_node_variant_class_fn__400000315_A) Ctor() {}
//line :494:1
func (t *A_arbace_c2j_node_variant_class_fn__400000315_A) Invoke_O_O__O(self, p__400000314__1 any) any { var map__400000316__2 any = p__400000314__1; var map__400000316__3 any; if lang.ISeq_InstanceOf(map__400000316__2) { var tmp1 any; var root_1824 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1825 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1824, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1826 lang.IFn; if linked_1825 == nil { ifn_1826 = lang.IFn_Cast(root_1824) } else { ifn_1826 = nil }; var arg_1827 any = map__400000316__2; if linked_1825 == nil { tmp1 = ifn_1826.Invoke_O__O(arg_1827) } else { tmp1 = linked_1825.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1824, arg_1827) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1828 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any = map__400000316__2; if linked_1829 == nil { tmp2 = ifn_1830.Invoke_O__O(arg_1831) } else { tmp2 = linked_1829.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1828, arg_1831) }; map__400000316__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1832 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1834 lang.IFn; if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = map__400000316__2; if linked_1833 == nil { tmp3 = ifn_1834.Invoke_O__O(arg_1835) } else { tmp3 = linked_1833.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1832, arg_1835) }; if jrt.J2g_Truth(tmp3) { var root_1836 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = map__400000316__2; if linked_1837 == nil { map__400000316__3 = ifn_1838.Invoke_O__O(arg_1839) } else { map__400000316__3 = linked_1837.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1836, arg_1839) } } else { map__400000316__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000316__3 = map__400000316__2 }; var fs__4 any = lang.RT_Get_O_O__O_NoInit(map__400000316__3, A_arbace_c2j_node_A_const_211); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_node_A_const_386; return tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_c2j_node_A_const_329.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(fs__4, A_arbace_c2j_node_A_const_14.GetRawRoot__O(), A_arbace_c2j_node_A_const_387, jrt.Boolean_TRUE.Ref(), A_arbace_c2j_node_A_const_388, jrt.Boolean_TRUE.Ref())) }

func A_arbace_c2j_node_variant_class_fn__400000320_A_New_O(p0 any) *A_arbace_c2j_node_variant_class_fn__400000320_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variant_class_fn__400000320_A{}; t.Ctor_O(p0); return t }
//line :496:1
func (t *A_arbace_c2j_node_variant_class_fn__400000320_A) Ctor_O(c__bare any) { t.F_bare = c__bare }
//line :496:1
func (t *A_arbace_c2j_node_variant_class_fn__400000320_A) Invoke_O_O__O(self, p__400000319__1 any) any { var map__400000321__2 any = p__400000319__1; var map__400000321__3 any; if lang.ISeq_InstanceOf(map__400000321__2) { var tmp1 any; var root_1881 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_1882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1881, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1883 lang.IFn; if linked_1882 == nil { ifn_1883 = lang.IFn_Cast(root_1881) } else { ifn_1883 = nil }; var arg_1884 any = map__400000321__2; if linked_1882 == nil { tmp1 = ifn_1883.Invoke_O__O(arg_1884) } else { tmp1 = linked_1882.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1881, arg_1884) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1885 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_1886 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1885, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1887 lang.IFn; if linked_1886 == nil { ifn_1887 = lang.IFn_Cast(root_1885) } else { ifn_1887 = nil }; var arg_1888 any = map__400000321__2; if linked_1886 == nil { tmp2 = ifn_1887.Invoke_O__O(arg_1888) } else { tmp2 = linked_1886.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1885, arg_1888) }; map__400000321__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1889 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1889, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1891 lang.IFn; if linked_1890 == nil { ifn_1891 = lang.IFn_Cast(root_1889) } else { ifn_1891 = nil }; var arg_1892 any = map__400000321__2; if linked_1890 == nil { tmp3 = ifn_1891.Invoke_O__O(arg_1892) } else { tmp3 = linked_1890.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1889, arg_1892) }; if jrt.J2g_Truth(tmp3) { var root_1893 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any = map__400000321__2; if linked_1894 == nil { map__400000321__3 = ifn_1895.Invoke_O__O(arg_1896) } else { map__400000321__3 = linked_1894.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1893, arg_1896) } } else { map__400000321__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000321__3 = map__400000321__2 }; var fs__4 any = lang.RT_Get_O_O__O_NoInit(map__400000321__3, A_arbace_c2j_node_A_const_211); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_node_A_const_392; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp7 any; var root_1897 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_1898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1897, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_1899 lang.IFn; if linked_1898 == nil { ifn_1899 = lang.IFn_Cast(root_1897) } else { ifn_1899 = nil }; var arg_1900 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(t.F_bare).Invoke_O__O(fs__4))).Ref(); if linked_1898 == nil { tmp7 = ifn_1899.Invoke_O__O(arg_1900) } else { tmp7 = linked_1898.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_1897, arg_1900) }; return tmp4.Invoke_O_O_O__O(tmp5, tmp6.Invoke_O_O__O(tmp7, A_arbace_c2j_node_A_const_393), lang.IFn_Cast(t.F_bare).Invoke_O__O(fs__4)) }



func A_arbace_c2j_node_variants_A_New() *A_arbace_c2j_node_variants_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_A{}; t.Ctor(); return t }
//line :500:1
func (t *A_arbace_c2j_node_variants_A) Ctor() {}
//line :500:1
func (t *A_arbace_c2j_node_variants_A) Invoke_O_O_O__O(self, d__0, domains__1 any) any { var base__3 any; var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_394; var or__1927000174__auto____3 any = tmp1.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0)); if



	jrt.J2g_Truth(or__1927000174__auto____3) { base__3 = or__1927000174__auto____3 } else { var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_96, nil); var tmp3 any; var root_1903 any = A_arbace_c2j_node_A_const_395.GetRawRoot__O(); var linked_1904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1903, A_arbace_c2j_node_camel_A_fn_class); var ifn_1905 lang.IFn; if linked_1904 == nil { ifn_1905 = lang.IFn_Cast(root_1903) } else { ifn_1905 = nil }; var arg_1906 any = A_arbace_c2j_node_A_const_13.Invoke_O__O(d__0); if linked_1904 == nil { tmp3 = ifn_1905.Invoke_O__O(arg_1906) } else { tmp3 = linked_1904.(*A_arbace_c2j_node_camel_A).Invoke_O_O__O(root_1903, arg_1906) }; base__3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, nil, tmp3)).Ref() }; var ss__4 any; var root_1907 any = /*line :500:1*/A_arbace_c2j_node_A_const_396.GetRawRoot__O(); var linked_1908 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1907, A_arbace_c2j_node_splits_A_fn_class); var ifn_1909 lang.IFn; if




	linked_1908 == nil { ifn_1909 = lang.IFn_Cast(root_1907) } else { ifn_1909 = nil }; var arg_1910 any = d__0; if linked_1908 == nil { ss__4 = ifn_1909.Invoke_O__O(arg_1910) } else { ss__4 = linked_1908.(*A_arbace_c2j_node_splits_A).Invoke_O_O__O(root_1907, arg_1910) }; var cb__5 any; var root_1911 any = /*line :500:1*/A_arbace_c2j_node_A_const_355.GetRawRoot__O(); var linked_1912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1911, A_arbace_c2j_node_children_bind_A_fn_class); var ifn_1913 lang.IFn; if





	linked_1912 == nil { ifn_1913 = lang.IFn_Cast(root_1911) } else { ifn_1913 = nil }; var arg_1914 any = d__0; if linked_1912 == nil { cb__5 = ifn_1913.Invoke_O__O(arg_1914) } else { cb__5 = linked_1912.(*A_arbace_c2j_node_children_bind_A).Invoke_O_O__O(root_1911, arg_1914) }; var counts__6 any; if
	jrt.J2g_Truth(cb__5) {
		var root_1915 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_1916 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1915, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1917 lang.IFn; if linked_1916 == nil { ifn_1917 = lang.IFn_Cast(root_1915) } else { ifn_1917 = nil }; var arg_1918 any; var root_1920 any = A_arbace_c2j_node_A_const_231.GetRawRoot__O(); var linked_1921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1920, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_1922 lang.IFn; if linked_1921 == nil { ifn_1922 = lang.IFn_Cast(root_1920) } else { ifn_1922 = nil }; var arg_1923 any; var na_1924 any; var root_1925 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_1926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1925, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_1927 lang.IFn; if linked_1926 == nil { ifn_1927 = lang.IFn_Cast(root_1925) } else { ifn_1927 = nil }; var arg_1928 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(cb__5); if linked_1926 == nil { na_1924 = ifn_1927.Invoke_O__O(arg_1928) } else { na_1924 = linked_1926.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_1925, arg_1928) }; if jrt.Long_InstanceOf(na_1924) { var n0_1929 int64 = jrt.NN(jrt.Long_Cast(na_1924)).LongValue__J(); if n0_1929 == 9223372036854775807 { arg_1923 = lang.Numbers_Inc_O__Number_NoInit(na_1924) } else { arg_1923 = jrt.Long_ValueOf_J__Long_NoInit(n0_1929 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_1924) { var n0_1929_2 float64 = jrt.NN(jrt.Double_Cast(na_1924)).DoubleValue__D(); arg_1923 = jrt.Double_ValueOf_D__Double_NoInit(n0_1929_2 + 1.0).Ref() } else { arg_1923 = lang.Numbers_Inc_O__Number_NoInit(na_1924) } }; if linked_1921 == nil { arg_1918 = ifn_1922.Invoke_O__O(arg_1923) } else { arg_1918 = linked_1921.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O__O(root_1920, arg_1923) }; var arg_1919 any; var tmp4 any; var root_1930 any = A_arbace_c2j_node_A_const_397.GetRawRoot__O(); var linked_1931 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1930, A_arbace_c2j_node_uses_many_QMARK__A_fn_class); var ifn_1932 lang.IFn; if linked_1931 == nil { ifn_1932 = lang.IFn_Cast(root_1930) } else { ifn_1932 = nil }; var arg_1933 any = d__0; if linked_1931 == nil { tmp4 = ifn_1932.Invoke_O__O(arg_1933) } else { tmp4 = linked_1931.(*A_arbace_c2j_node_uses_many_QMARK__A).Invoke_O_O__O(root_1930, arg_1933) }; if jrt.J2g_Truth(tmp4) { arg_1919 = A_arbace_c2j_node_A_const_398 } else { arg_1919 = nil }; if linked_1916 == nil { counts__6 = ifn_1917.Invoke_O_O__O(arg_1918, arg_1919) } else { counts__6 = linked_1916.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1915, arg_1918, arg_1919) } } else {
//line :507:1
			counts__6 = A_arbace_c2j_node_A_const_399 }; var split_sets__7 any; var root_1934 any = /*line :500:1*/A_arbace_c2j_node_A_const_129.GetRawRoot__O(); var linked_1935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1934, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1936 lang.IFn; if









	linked_1935 == nil { ifn_1936 = lang.IFn_Cast(root_1934) } else { ifn_1936 = nil }; var arg_1937 any; var fnbody__2044 any = A_arbace_c2j_node_variants_fn__400000326_A_New(); var tmp5 *jrt.Class; var fncls__2043 *jrt.Class = A_arbace_c2j_node_variants_fn__400000326_A_fn_class; if fncls__2043 == nil { var fncls__2043d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, nil); A_arbace_c2j_node_variants_fn__400000326_A_fn_class = fncls__2043d; tmp5 = fncls__2043d } else { tmp5 = fncls__2043 }; arg_1937 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2044, tmp5, nil); var arg_1938 any = lang.Tuple_Create_O__IPersistentVector(lang.PersistentArrayMap_EMPTY.Ref()); var arg_1939 any = ss__4; if linked_1935 == nil { split_sets__7 = ifn_1936.Invoke_O_O_O__O(arg_1937, arg_1938, arg_1939) } else { split_sets__7 = linked_1935.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1934, arg_1937, arg_1938, arg_1939) }; var dom__8 any; var tmp6 /*line :500:1*/*lang.Keyword = A_arbace_c2j_node_A_const_408; if










	jrt.J2g_Truth(tmp6.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0))) { dom__8 = lang.IFn_Cast(domains__1).Invoke_O__O(A_arbace_c2j_node_A_const_13.Invoke_O__O(d__0)) } else { dom__8 = nil }; var tmp7 any; var root_2045 any =
	A_arbace_c2j_node_A_const_48.GetRawRoot__O(); var linked_2046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2045, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_2047 lang.IFn; if linked_2046 == nil { ifn_2047 = lang.IFn_Cast(root_2045) } else { ifn_2047 = nil }; var arg_2048 any; var fnbody__2051 any = A_arbace_c2j_node_variants_fn__400000344_A_New(); var tmp8 *jrt.Class; var fncls__2050 *jrt.Class = A_arbace_c2j_node_variants_fn__400000344_A_fn_class; if fncls__2050 == nil { var fncls__2050d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, nil); A_arbace_c2j_node_variants_fn__400000344_A_fn_class = fncls__2050d; tmp8 = fncls__2050d } else { tmp8 = fncls__2050 }; arg_2048 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2051, tmp8, nil); var arg_2049 any = A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0); if linked_2046 == nil { tmp7 = ifn_2047.Invoke_O_O__O(arg_2048, arg_2049) } else { tmp7 = linked_2046.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_2045, arg_2048, arg_2049) }; if jrt.J2g_Truth(tmp7) { var iter__1927001039__auto____9 any; var fnbody__2142 any = A_arbace_c2j_node_variants_iter__400000346__400000352_A_New(); var tmp9 *jrt.Class; var fncls__2141 *jrt.Class = A_arbace_c2j_node_variants_iter__400000346__400000352_A_fn_class
		if fncls__2141 == nil { var fncls__2141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, nil); A_arbace_c2j_node_variants_iter__400000346__400000352_A_fn_class = fncls__2141d; tmp9 = fncls__2141d } else { tmp9 = fncls__2141 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2142, tmp9, nil); return lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_c2j_node_A_const_415.GetRawRoot__O()) } else {
//line :512:1
			var iter__1927001039__auto____9_2 any; var fnbody__2291 any = A_arbace_c2j_node_variants_iter__400000365__400000371_A_New_O_O_O_O(base__3, split_sets__7, dom__8, ss__4); var tmp10 *jrt.Class
			var fncls__2290 /*line :512:1*/*jrt.Class = A_arbace_c2j_node_variants_iter__400000365__400000371_A_fn_class


			if fncls__2290 == nil { var fncls__2290d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, fnbody__2291); A_arbace_c2j_node_variants_iter__400000365__400000371_A_fn_class = fncls__2290d; tmp10 = fncls__2290d } else { tmp10 = fncls__2290 }; iter__1927001039__auto____9_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2291, tmp10, nil); return lang.IFn_Cast(iter__1927001039__auto____9_2).Invoke_O__O(counts__6) } }
//line :510:1
func A_arbace_c2j_node_variants_fn__400000326_A_New() *A_arbace_c2j_node_variants_fn__400000326_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000326_A{}; t.Ctor(); return t }
//line :510:1
func (t *A_arbace_c2j_node_variants_fn__400000326_A) Ctor() {}
//line :510:1
func (t *A_arbace_c2j_node_variants_fn__400000326_A) Invoke_O_O_O__O(self, acc__1, s__2 any) any { var iter__1927001039__auto____3 any; var fnbody__2042 any = A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_A_New_O(s__2); var tmp1 *jrt.Class; var fncls__2041 *jrt.Class = A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_A_fn_class; if fncls__2041 == nil { var fncls__2041d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, fnbody__2042); A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_A_fn_class = fncls__2041d; tmp1 = fncls__2041d } else { tmp1 = fncls__2041 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2042, tmp1, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(acc__1) }
//line :510:1
func A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_A_New_O(p0 any) *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_A{}; t.Ctor_O(p0); return t }
//line :510:1
func (t *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :510:1
func (t *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_A) Invoke_O_O__O(self, s__400000328__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2040 any = A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_A_New_O_O_O(self, s__400000328__1, t.F_s); var tmp2 *jrt.Class; var fncls__2039 *jrt.Class = A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_A_fn_class; if fncls__2039 == nil { var fncls__2039d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, fnbody__2040); A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_A_fn_class = fncls__2039d; tmp2 = fncls__2039d } else { tmp2 = fncls__2039 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2040, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :510:1
func A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :510:1
func (t *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_A) Ctor_O_O_O(c__iter__400000327, c__s__400000328, c__s any) { t.F_iter__400000327 = c__iter__400000327; t.F_s__400000328 = c__s__400000328; t.F_s = c__s }
//line :510:1
func (t *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_A) Invoke_O__O(self any) any { { var s__400000328__1 any; var t_ any = t.F_s__400000328; t.F_s__400000328 = nil; s__400000328__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1940 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1940, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1942 lang.IFn; if linked_1941 == nil { ifn_1942 = lang.IFn_Cast(root_1940) } else { ifn_1942 = nil }; var arg_1943 any = s__400000328__1; if linked_1941 == nil { temp__1927000414__auto____2 = ifn_1942.Invoke_O__O(arg_1943) } else { temp__1927000414__auto____2 = linked_1941.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1940, arg_1943) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var m__4 any; var root_1944 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_1945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1944, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1946 lang.IFn; if linked_1945 == nil { ifn_1946 = lang.IFn_Cast(root_1944) } else { ifn_1946 = nil }; var arg_1947 any = xs__1927001018__auto____3; if linked_1945 == nil { m__4 = ifn_1946.Invoke_O__O(arg_1947) } else { m__4 = linked_1945.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1944, arg_1947) }; var iterys__1927001035__auto____5 any; var fnbody__2021 any = A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_A_New_O_O(m__4, t.F_s); var tmp1 *jrt.Class; var fncls__2020 *jrt.Class = A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_A_fn_class; if fncls__2020 == nil { var fncls__2020d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, fnbody__2021); A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_A_fn_class = fncls__2020d; tmp1 = fncls__2020d } else { tmp1 = fncls__2020 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2021, tmp1, nil); var fs__1927001036__auto____6 any; var root_2022 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2022, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2024 lang.IFn; if linked_2023 == nil { ifn_2024 = lang.IFn_Cast(root_2022) } else { ifn_2024 = nil }; var arg_2025 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(A_arbace_c2j_node_A_const_407); if linked_2023 == nil { fs__1927001036__auto____6 = ifn_2024.Invoke_O__O(arg_2025) } else { fs__1927001036__auto____6 = linked_2023.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2022, arg_2025) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_2026 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2027 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2026, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2028 lang.IFn; if linked_2027 == nil { ifn_2028 = lang.IFn_Cast(root_2026) } else { ifn_2028 = nil }; var arg_2029 any = fs__1927001036__auto____6; var arg_2030 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_iter__400000327); var tmp3 any; var root_2031 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = s__400000328__1; if linked_2032 == nil { tmp3 = ifn_2033.Invoke_O__O(arg_2034) } else { tmp3 = linked_2032.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2031, arg_2034) }; arg_2030 = tmp2.Invoke_O__O(tmp3); if linked_2027 == nil { return ifn_2028.Invoke_O_O__O(arg_2029, arg_2030) } else { return linked_2027.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2026, arg_2029, arg_2030) } } else { var tmp4 any; var root_2035 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2035, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2037 lang.IFn; if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var arg_2038 any = s__400000328__1; if linked_2036 == nil { tmp4 = ifn_2037.Invoke_O__O(arg_2038) } else { tmp4 = linked_2036.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2035, arg_2038) }; s__400000328__1 = tmp4; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :510:1
func A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_A{}; t.Ctor_O_O(p0, p1); return t }
//line :510:1
func (t *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_A) Ctor_O_O(c__m, c__s any) { t.F_m = c__m; t.F_s = c__s }
//line :510:1
func (t *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_A) Invoke_O_O__O(self, s__400000330__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2019 any = A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_A_New_O_O_O_O(s__400000330__1, self, t.F_m, t.F_s); var tmp2 *jrt.Class; var fncls__2018 *jrt.Class = A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_A_fn_class; if fncls__2018 == nil { var fncls__2018d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, false, fnbody__2019); A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_A_fn_class = fncls__2018d; tmp2 = fncls__2018d } else { tmp2 = fncls__2018 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2019, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :510:1
func A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :510:1
func (t *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_A) Ctor_O_O_O_O(c__s__400000330, c__iter__400000329, c__m, c__s any) { t.F_s__400000330 = c__s__400000330; t.F_iter__400000329 = c__iter__400000329; t.F_m = c__m; t.F_s = c__s }
//line :510:1
func (t *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_A) Invoke_O__O(self any) any { { var s__400000330__1 any; var t_ any = t.F_s__400000330; t.F_s__400000330 = nil; s__400000330__1 = t_; for { var temp__1927000414__auto____2 any; var root_1948 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_1949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1948, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1950 lang.IFn; if linked_1949 == nil { ifn_1950 = lang.IFn_Cast(root_1948) } else { ifn_1950 = nil }; var arg_1951 any = s__400000330__1; if linked_1949 == nil { temp__1927000414__auto____2 = ifn_1950.Invoke_O__O(arg_1951) } else { temp__1927000414__auto____2 = linked_1949.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1948, arg_1951) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000330__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1952 any = A_arbace_c2j_node_A_const_400.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1952, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1954 lang.IFn; if linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any = s__400000330__3; if linked_1953 == nil { tmp1 = ifn_1954.Invoke_O__O(arg_1955) } else { tmp1 = linked_1953.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1952, arg_1955) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1956 any = A_arbace_c2j_node_A_const_401.GetRawRoot__O(); var linked_1957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1956, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1958 lang.IFn; if linked_1957 == nil { ifn_1958 = lang.IFn_Cast(root_1956) } else { ifn_1958 = nil }; var arg_1959 any = s__400000330__3; if linked_1957 == nil { c__1927001037__auto____4 = ifn_1958.Invoke_O__O(arg_1959) } else { c__1927001037__auto____4 = linked_1957.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1956, arg_1959) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000332__6 any; var root_1960 any = A_arbace_c2j_node_A_const_402.GetRawRoot__O(); var linked_1961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1960, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1962 lang.IFn; if linked_1961 == nil { ifn_1962 = lang.IFn_Cast(root_1960) } else { ifn_1962 = nil }; var arg_1963 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1961 == nil { b__400000332__6 = ifn_1962.Invoke_O__O(arg_1963) } else { b__400000332__6 = linked_1961.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1960, arg_1963) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1976 any = A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_fn__400000337_A_New_O_O_O_I_O(t.F_m, b__400000332__6, t.F_s, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1975 *jrt.Class = A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_fn__400000337_A_fn_class; if fncls__1975 == nil { var fncls__1975d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, fnbody__1976); A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_fn__400000337_A_fn_class = fncls__1975d; tmp3 = fncls__1975d } else { tmp3 = fncls__1975 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1976, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1977 any = A_arbace_c2j_node_A_const_404.GetRawRoot__O(); var linked_1978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1977, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1979 lang.IFn; if linked_1978 == nil { ifn_1979 = lang.IFn_Cast(root_1977) } else { ifn_1979 = nil }; var arg_1980 any; var root_1982 any = A_arbace_c2j_node_A_const_405.GetRawRoot__O(); var linked_1983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1982, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1984 lang.IFn; if linked_1983 == nil { ifn_1984 = lang.IFn_Cast(root_1982) } else { ifn_1984 = nil }; var arg_1985 any = b__400000332__6; if linked_1983 == nil { arg_1980 = ifn_1984.Invoke_O__O(arg_1985) } else { arg_1980 = linked_1983.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1982, arg_1985) }; var arg_1981 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000329); var tmp5 any; var root_1986 any = A_arbace_c2j_node_A_const_406.GetRawRoot__O(); var linked_1987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1986, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1988 lang.IFn; if linked_1987 == nil { ifn_1988 = lang.IFn_Cast(root_1986) } else { ifn_1988 = nil }; var arg_1989 any = s__400000330__3; if linked_1987 == nil { tmp5 = ifn_1988.Invoke_O__O(arg_1989) } else { tmp5 = linked_1987.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1986, arg_1989) }; arg_1981 = tmp4.Invoke_O__O(tmp5); if linked_1978 == nil { return ifn_1979.Invoke_O_O__O(arg_1980, arg_1981) } else { return linked_1978.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1977, arg_1980, arg_1981) } } else { var root_1990 any = A_arbace_c2j_node_A_const_404.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1992 lang.IFn; if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any; var root_1995 any = A_arbace_c2j_node_A_const_405.GetRawRoot__O(); var linked_1996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1995, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1997 lang.IFn; if linked_1996 == nil { ifn_1997 = lang.IFn_Cast(root_1995) } else { ifn_1997 = nil }; var arg_1998 any = b__400000332__6; if linked_1996 == nil { arg_1993 = ifn_1997.Invoke_O__O(arg_1998) } else { arg_1993 = linked_1996.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1995, arg_1998) }; var arg_1994 any; if linked_1991 == nil { return ifn_1992.Invoke_O_O__O(arg_1993, arg_1994) } else { return linked_1991.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1990, arg_1993, arg_1994) } } } else { var x__4 any; var root_1999 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1999, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2001 lang.IFn; if linked_2000 == nil { ifn_2001 = lang.IFn_Cast(root_1999) } else { ifn_2001 = nil }; var arg_2002 any = s__400000330__3; if linked_2000 == nil { x__4 = ifn_2001.Invoke_O__O(arg_2002) } else { x__4 = linked_2000.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1999, arg_2002) }; var root_2003 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2003, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2005 lang.IFn; if linked_2004 == nil { ifn_2005 = lang.IFn_Cast(root_2003) } else { ifn_2005 = nil }; var arg_2006 any; var root_2008 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_2009 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2008, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2010 lang.IFn; if linked_2009 == nil { ifn_2010 = lang.IFn_Cast(root_2008) } else { ifn_2010 = nil }; var arg_2011 any = t.F_m; var arg_2012 any = t.F_s; var arg_2013 any = x__4; if linked_2009 == nil { arg_2006 = ifn_2010.Invoke_O_O_O__O(arg_2011, arg_2012, arg_2013) } else { arg_2006 = linked_2009.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2008, arg_2011, arg_2012, arg_2013) }; var arg_2007 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__400000329); var tmp7 any; var root_2014 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2014, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2016 lang.IFn; if linked_2015 == nil { ifn_2016 = lang.IFn_Cast(root_2014) } else { ifn_2016 = nil }; var arg_2017 any = s__400000330__3; if linked_2015 == nil { tmp7 = ifn_2016.Invoke_O__O(arg_2017) } else { tmp7 = linked_2015.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2014, arg_2017) }; arg_2007 = tmp6.Invoke_O__O(tmp7); if linked_2004 == nil { return ifn_2005.Invoke_O_O__O(arg_2006, arg_2007) } else { return linked_2004.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2003, arg_2006, arg_2007) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :510:1
func A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_fn__400000337_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_fn__400000337_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_fn__400000337_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :510:1
func (t *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_fn__400000337_A) Ctor_O_O_O_I_O(c__m, c__b__400000332, c__s any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_m = c__m; t.F_b__400000332 = c__b__400000332; t.F_s = c__s; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :510:1
func (t *A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_fn__400000337_A) Invoke_O__O(self any) any { { var i__400000331__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000331__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var x__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000331__1)); var root_1964 any = A_arbace_c2j_node_A_const_403.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1964, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1966 lang.IFn; if linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any = t.F_b__400000332; var arg_1968 any; var root_1969 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_1970 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1969, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1971 lang.IFn; if linked_1970 == nil { ifn_1971 = lang.IFn_Cast(root_1969) } else { ifn_1971 = nil }; var arg_1972 any = t.F_m; var arg_1973 any = t.F_s; var arg_1974 any = x__2; if linked_1970 == nil { arg_1968 = ifn_1971.Invoke_O_O_O__O(arg_1972, arg_1973, arg_1974) } else { arg_1968 = linked_1970.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1969, arg_1972, arg_1973, arg_1974) }; if linked_1965 == nil { ifn_1966.Invoke_O_O__O(arg_1967, arg_1968) } else { linked_1965.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1964, arg_1967, arg_1968) }; i__400000331__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000331__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_node_variants_fn__400000344_A_New() *A_arbace_c2j_node_variants_fn__400000344_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_fn__400000344_A{}; t.Ctor(); return t }
//line :512:1
func (t *A_arbace_c2j_node_variants_fn__400000344_A) Ctor() {}
//line :512:1
func (t *A_arbace_c2j_node_variants_fn__400000344_A) Invoke_O_O__O(self, p1__400000325_SHARP___1 any) any { var tmp1 any = A_arbace_c2j_node_A_const_409; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, A_arbace_c2j_node_A_const_20.Invoke_O__O(p1__400000325_SHARP___1))).Ref() }
func A_arbace_c2j_node_variants_iter__400000346__400000352_A_New() *A_arbace_c2j_node_variants_iter__400000346__400000352_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000346__400000352_A{}; t.Ctor(); return t }
//line :513:1
func (t *A_arbace_c2j_node_variants_iter__400000346__400000352_A) Ctor() {}
//line :513:1
func (t *A_arbace_c2j_node_variants_iter__400000346__400000352_A) Invoke_O_O__O(self, s__400000347__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2140 any = A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_A_New_O_O(self, s__400000347__1); var tmp2 *jrt.Class; var fncls__2139 *jrt.Class = A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_A_fn_class; if fncls__2139 == nil { var fncls__2139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, fnbody__2140); A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_A_fn_class = fncls__2139d; tmp2 = fncls__2139d } else { tmp2 = fncls__2139 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2140, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :513:1
func A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_A{}; t.Ctor_O_O(p0, p1); return t }
//line :513:1
func (t *A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_A) Ctor_O_O(c__iter__400000346, c__s__400000347 any) { t.F_iter__400000346 = c__iter__400000346; t.F_s__400000347 = c__s__400000347 }
//line :513:1
func (t *A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_A) Invoke_O__O(self any) any { { var s__400000347__1 any; var t_ any = t.F_s__400000347; t.F_s__400000347 = nil; s__400000347__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2052 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2052, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2054 lang.IFn; if linked_2053 == nil { ifn_2054 = lang.IFn_Cast(root_2052) } else { ifn_2054 = nil }; var arg_2055 any = s__400000347__1; if linked_2053 == nil { temp__1927000414__auto____2 = ifn_2054.Invoke_O__O(arg_2055) } else { temp__1927000414__auto____2 = linked_2053.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2052, arg_2055) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__400000354__4 any; var root_2056 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2056, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2058 lang.IFn; if linked_2057 == nil { ifn_2058 = lang.IFn_Cast(root_2056) } else { ifn_2058 = nil }; var arg_2059 any = xs__1927001018__auto____3; if linked_2057 == nil { vec__400000354__4 = ifn_2058.Invoke_O__O(arg_2059) } else { vec__400000354__4 = linked_2057.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2056, arg_2059) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000354__4, lang.RT_IntCast_J__I_NoInit(0), nil); var p__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000354__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var fnbody__2121 any = A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_A_New_O_O(k__5, p__6); var tmp1 *jrt.Class; var fncls__2120 *jrt.Class = A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_A_fn_class; if fncls__2120 == nil { var fncls__2120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, false, fnbody__2121); A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_A_fn_class = fncls__2120d; tmp1 = fncls__2120d } else { tmp1 = fncls__2120 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2121, tmp1, nil); var fs__1927001036__auto____8 any; var root_2122 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2122, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2124 lang.IFn; if linked_2123 == nil { ifn_2124 = lang.IFn_Cast(root_2122) } else { ifn_2124 = nil }; var arg_2125 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp3 any; if jrt.J2g_Truth(A_arbace_c2j_node_A_const_250.Invoke_O__O(p__6)) { tmp3 = A_arbace_c2j_node_A_const_411 } else { tmp3 = A_arbace_c2j_node_A_const_412 }; arg_2125 = tmp2.Invoke_O__O(tmp3); if linked_2123 == nil { fs__1927001036__auto____8 = ifn_2124.Invoke_O__O(arg_2125) } else { fs__1927001036__auto____8 = linked_2123.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2122, arg_2125) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2126 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2127 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2126, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2128 lang.IFn; if linked_2127 == nil { ifn_2128 = lang.IFn_Cast(root_2126) } else { ifn_2128 = nil }; var arg_2129 any = fs__1927001036__auto____8; var arg_2130 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000346); var tmp5 any; var root_2131 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2132 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2131, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2133 lang.IFn; if linked_2132 == nil { ifn_2133 = lang.IFn_Cast(root_2131) } else { ifn_2133 = nil }; var arg_2134 any = s__400000347__1; if linked_2132 == nil { tmp5 = ifn_2133.Invoke_O__O(arg_2134) } else { tmp5 = linked_2132.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2131, arg_2134) }; arg_2130 = tmp4.Invoke_O__O(tmp5); if linked_2127 == nil { return ifn_2128.Invoke_O_O__O(arg_2129, arg_2130) } else { return linked_2127.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2126, arg_2129, arg_2130) } } else { var tmp6 any; var root_2135 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2135, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2137 lang.IFn; if linked_2136 == nil { ifn_2137 = lang.IFn_Cast(root_2135) } else { ifn_2137 = nil }; var arg_2138 any = s__400000347__1; if linked_2136 == nil { tmp6 = ifn_2137.Invoke_O__O(arg_2138) } else { tmp6 = linked_2136.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2135, arg_2138) }; s__400000347__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :513:1
func A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_A{}; t.Ctor_O_O(p0, p1); return t }
//line :513:1
func (t *A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_A) Ctor_O_O(c__k, c__p any) { t.F_k = c__k; t.F_p = c__p }
//line :513:1
func (t *A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_A) Invoke_O_O__O(self, s__400000349__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2119 any = A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_A_New_O_O_O_O(self, t.F_k, s__400000349__1, t.F_p); var tmp2 *jrt.Class; var fncls__2118 *jrt.Class = A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_A_fn_class; if fncls__2118 == nil { var fncls__2118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, fnbody__2119); A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_A_fn_class = fncls__2118d; tmp2 = fncls__2118d } else { tmp2 = fncls__2118 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2119, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :513:1
func A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :513:1
func (t *A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_A) Ctor_O_O_O_O(c__iter__400000348, c__k, c__s__400000349, c__p any) { t.F_iter__400000348 = c__iter__400000348; t.F_k = c__k; t.F_s__400000349 = c__s__400000349; t.F_p = c__p }
//line :513:1
func (t *A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_A) Invoke_O__O(self any) any { { var s__400000349__1 any; var t_ any = t.F_s__400000349; t.F_s__400000349 = nil; s__400000349__1 = t_; for { var temp__1927000414__auto____2 any; var root_2060 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2060, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2062 lang.IFn; if linked_2061 == nil { ifn_2062 = lang.IFn_Cast(root_2060) } else { ifn_2062 = nil }; var arg_2063 any = s__400000349__1; if linked_2061 == nil { temp__1927000414__auto____2 = ifn_2062.Invoke_O__O(arg_2063) } else { temp__1927000414__auto____2 = linked_2061.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2060, arg_2063) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000349__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2064 any = A_arbace_c2j_node_A_const_400.GetRawRoot__O(); var linked_2065 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2064, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2066 lang.IFn; if linked_2065 == nil { ifn_2066 = lang.IFn_Cast(root_2064) } else { ifn_2066 = nil }; var arg_2067 any = s__400000349__3; if linked_2065 == nil { tmp1 = ifn_2066.Invoke_O__O(arg_2067) } else { tmp1 = linked_2065.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2064, arg_2067) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2068 any = A_arbace_c2j_node_A_const_401.GetRawRoot__O(); var linked_2069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2068, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2070 lang.IFn; if linked_2069 == nil { ifn_2070 = lang.IFn_Cast(root_2068) } else { ifn_2070 = nil }; var arg_2071 any = s__400000349__3; if linked_2069 == nil { c__1927001037__auto____4 = ifn_2070.Invoke_O__O(arg_2071) } else { c__1927001037__auto____4 = linked_2069.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2068, arg_2071) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000351__6 any; var root_2072 any = A_arbace_c2j_node_A_const_402.GetRawRoot__O(); var linked_2073 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2072, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2074 lang.IFn; if linked_2073 == nil { ifn_2074 = lang.IFn_Cast(root_2072) } else { ifn_2074 = nil }; var arg_2075 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2073 == nil { b__400000351__6 = ifn_2074.Invoke_O__O(arg_2075) } else { b__400000351__6 = linked_2073.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2072, arg_2075) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2082 any = A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_fn__400000359_A_New_O_O_O_I_O(t.F_k, t.F_p, b__400000351__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2081 *jrt.Class = A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_fn__400000359_A_fn_class; if fncls__2081 == nil { var fncls__2081d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_109, false, fnbody__2082); A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_fn__400000359_A_fn_class = fncls__2081d; tmp3 = fncls__2081d } else { tmp3 = fncls__2081 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2082, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2083 any = A_arbace_c2j_node_A_const_404.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2083, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2085 lang.IFn; if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any; var root_2088 any = A_arbace_c2j_node_A_const_405.GetRawRoot__O(); var linked_2089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2088, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2090 lang.IFn; if linked_2089 == nil { ifn_2090 = lang.IFn_Cast(root_2088) } else { ifn_2090 = nil }; var arg_2091 any = b__400000351__6; if linked_2089 == nil { arg_2086 = ifn_2090.Invoke_O__O(arg_2091) } else { arg_2086 = linked_2089.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2088, arg_2091) }; var arg_2087 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000348); var tmp5 any; var root_2092 any = A_arbace_c2j_node_A_const_406.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2092, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2094 lang.IFn; if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = s__400000349__3; if linked_2093 == nil { tmp5 = ifn_2094.Invoke_O__O(arg_2095) } else { tmp5 = linked_2093.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2092, arg_2095) }; arg_2087 = tmp4.Invoke_O__O(tmp5); if linked_2084 == nil { return ifn_2085.Invoke_O_O__O(arg_2086, arg_2087) } else { return linked_2084.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2083, arg_2086, arg_2087) } } else { var root_2096 any = A_arbace_c2j_node_A_const_404.GetRawRoot__O(); var linked_2097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2096, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2098 lang.IFn; if linked_2097 == nil { ifn_2098 = lang.IFn_Cast(root_2096) } else { ifn_2098 = nil }; var arg_2099 any; var root_2101 any = A_arbace_c2j_node_A_const_405.GetRawRoot__O(); var linked_2102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2101, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2103 lang.IFn; if linked_2102 == nil { ifn_2103 = lang.IFn_Cast(root_2101) } else { ifn_2103 = nil }; var arg_2104 any = b__400000351__6; if linked_2102 == nil { arg_2099 = ifn_2103.Invoke_O__O(arg_2104) } else { arg_2099 = linked_2102.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2101, arg_2104) }; var arg_2100 any; if linked_2097 == nil { return ifn_2098.Invoke_O_O__O(arg_2099, arg_2100) } else { return linked_2097.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2096, arg_2099, arg_2100) } } } else { var c__4 any; var root_2105 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2105, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2107 lang.IFn; if linked_2106 == nil { ifn_2107 = lang.IFn_Cast(root_2105) } else { ifn_2107 = nil }; var arg_2108 any = s__400000349__3; if linked_2106 == nil { c__4 = ifn_2107.Invoke_O__O(arg_2108) } else { c__4 = linked_2106.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2105, arg_2108) }; var root_2109 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2109, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2111 lang.IFn; if linked_2110 == nil { ifn_2111 = lang.IFn_Cast(root_2109) } else { ifn_2111 = nil }; var arg_2112 any; var tmp6 any = A_arbace_c2j_node_A_const_349; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp8 any = A_arbace_c2j_node_A_const_394.Invoke_O__O(t.F_p); var tmp9 *jrt.String
																			if jrt.J2g_Truth(c__4) { tmp9 = Lit_110 } else { tmp9 = nil }
//line :513:1
	arg_2112 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9.Ref())).Ref(), A_arbace_c2j_node_A_const_177, t.F_p, A_arbace_c2j_node_A_const_410, t.F_k, A_arbace_c2j_node_A_const_73, c__4, A_arbace_c2j_node_A_const_239, lang.PersistentArrayMap_EMPTY.Ref())); var arg_2113 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__400000348); var tmp11 any; var root_2114 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2114, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2116 lang.IFn; if linked_2115 == nil { ifn_2116 = lang.IFn_Cast(root_2114) } else { ifn_2116 = nil }; var arg_2117 any = s__400000349__3; if linked_2115 == nil { tmp11 = ifn_2116.Invoke_O__O(arg_2117) } else { tmp11 = linked_2115.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2114, arg_2117) }; arg_2113 = tmp10.Invoke_O__O(tmp11); if linked_2110 == nil { return ifn_2111.Invoke_O_O__O(arg_2112, arg_2113) } else { return linked_2110.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2109, arg_2112, arg_2113) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :513:1
func A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_fn__400000359_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_fn__400000359_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_fn__400000359_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :513:1
func (t *A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_fn__400000359_A) Ctor_O_O_O_I_O(c__k, c__p, c__b__400000351 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_k = c__k; t.F_p = c__p; t.F_b__400000351 = c__b__400000351; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :513:1
func (t *A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_fn__400000359_A) Invoke_O__O(self any) any { { var i__400000350__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000350__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000350__1)); var root_2076 any = A_arbace_c2j_node_A_const_403.GetRawRoot__O(); var linked_2077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2076, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2078 lang.IFn; if linked_2077 == nil { ifn_2078 = lang.IFn_Cast(root_2076) } else { ifn_2078 = nil }; var arg_2079 any = t.F_b__400000351; var arg_2080 any; var tmp2 any = A_arbace_c2j_node_A_const_349; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil); var tmp4 any = A_arbace_c2j_node_A_const_394.Invoke_O__O(t.F_p); var tmp5 *jrt.String
																					if jrt.J2g_Truth(c__2) { tmp5 = Lit_110 } else { tmp5 = nil }
//line :513:1
	arg_2080 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5.Ref())).Ref(), A_arbace_c2j_node_A_const_177, t.F_p, A_arbace_c2j_node_A_const_410, t.F_k, A_arbace_c2j_node_A_const_73, c__2, A_arbace_c2j_node_A_const_239, lang.PersistentArrayMap_EMPTY.Ref())); if linked_2077 == nil { ifn_2078.Invoke_O_O__O(arg_2079, arg_2080) } else { linked_2077.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2076, arg_2079, arg_2080) }; i__400000350__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000350__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_node_variants_iter__400000365__400000371_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variants_iter__400000365__400000371_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000365__400000371_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :515:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_A) Ctor_O_O_O_O(c__base, c__split_sets, c__dom, c__ss any) { t.F_base = c__base; t.F_split_sets = c__split_sets; t.F_dom = c__dom; t.F_ss = c__ss }
//line :515:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_A) Invoke_O_O__O(self, s__400000366__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2289 any = A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_A_New_O_O_O_O_O_O(s__400000366__1, t.F_base, t.F_split_sets, t.F_dom, t.F_ss, self); var tmp2 *jrt.Class; var fncls__2288 *jrt.Class = A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_A_fn_class; if fncls__2288 == nil { var fncls__2288d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_111, false, fnbody__2289); A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_A_fn_class = fncls__2288d; tmp2 = fncls__2288d } else { tmp2 = fncls__2288 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2289, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :515:1
func A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :515:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_A) Ctor_O_O_O_O_O_O(c__s__400000366, c__base, c__split_sets, c__dom, c__ss, c__iter__400000365 any) { t.F_s__400000366 = c__s__400000366; t.F_base = c__base; t.F_split_sets = c__split_sets; t.F_dom = c__dom; t.F_ss = c__ss; t.F_iter__400000365 = c__iter__400000365 }
//line :515:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_A) Invoke_O__O(self any) any { { var s__400000366__1 any; var t_ any = t.F_s__400000366; t.F_s__400000366 = nil; s__400000366__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2143 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2143, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = s__400000366__1; if linked_2144 == nil { temp__1927000414__auto____2 = ifn_2145.Invoke_O__O(arg_2146) } else { temp__1927000414__auto____2 = linked_2144.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2143, arg_2146) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var c__4 any; var root_2147 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2149 lang.IFn; if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any = xs__1927001018__auto____3; if linked_2148 == nil { c__4 = ifn_2149.Invoke_O__O(arg_2150) } else { c__4 = linked_2148.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2147, arg_2150) }; var iterys__1927001035__auto____5 any; var fnbody__2270 any = A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_A_New_O_O_O_O(t.F_base, t.F_dom, t.F_ss, c__4); var tmp1 *jrt.Class; var fncls__2269 *jrt.Class = A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_A_fn_class; if fncls__2269 == nil { var fncls__2269d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, fnbody__2270); A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_A_fn_class = fncls__2269d; tmp1 = fncls__2269d } else { tmp1 = fncls__2269 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2270, tmp1, nil); var fs__1927001036__auto____6 any; var root_2271 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2271, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2273 lang.IFn; if linked_2272 == nil { ifn_2273 = lang.IFn_Cast(root_2271) } else { ifn_2273 = nil }; var arg_2274 any = lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(t.F_split_sets); if linked_2272 == nil { fs__1927001036__auto____6 = ifn_2273.Invoke_O__O(arg_2274) } else { fs__1927001036__auto____6 = linked_2272.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2271, arg_2274) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_2275 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2276 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2275, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2277 lang.IFn; if linked_2276 == nil { ifn_2277 = lang.IFn_Cast(root_2275) } else { ifn_2277 = nil }; var arg_2278 any = fs__1927001036__auto____6; var arg_2279 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_iter__400000365); var tmp3 any; var root_2280 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2280, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2282 lang.IFn; if linked_2281 == nil { ifn_2282 = lang.IFn_Cast(root_2280) } else { ifn_2282 = nil }; var arg_2283 any = s__400000366__1; if linked_2281 == nil { tmp3 = ifn_2282.Invoke_O__O(arg_2283) } else { tmp3 = linked_2281.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2280, arg_2283) }; arg_2279 = tmp2.Invoke_O__O(tmp3); if linked_2276 == nil { return ifn_2277.Invoke_O_O__O(arg_2278, arg_2279) } else { return linked_2276.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2275, arg_2278, arg_2279) } } else { var tmp4 any; var root_2284 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2284, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2286 lang.IFn; if linked_2285 == nil { ifn_2286 = lang.IFn_Cast(root_2284) } else { ifn_2286 = nil }; var arg_2287 any = s__400000366__1; if linked_2285 == nil { tmp4 = ifn_2286.Invoke_O__O(arg_2287) } else { tmp4 = linked_2285.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2284, arg_2287) }; s__400000366__1 = tmp4; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :515:1
func A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :515:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_A) Ctor_O_O_O_O(c__base, c__dom, c__ss, c__c any) { t.F_base = c__base; t.F_dom = c__dom; t.F_ss = c__ss; t.F_c = c__c }
//line :515:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_A) Invoke_O_O__O(self, s__400000368__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2268 any = A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_A_New_O_O_O_O_O_O(self, s__400000368__1, t.F_base, t.F_dom, t.F_ss, t.F_c); var tmp2 *jrt.Class; var fncls__2267 *jrt.Class = A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_A_fn_class; if fncls__2267 == nil { var fncls__2267d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, fnbody__2268); A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_A_fn_class = fncls__2267d; tmp2 = fncls__2267d } else { tmp2 = fncls__2267 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2268, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :515:1
func A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :515:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_A) Ctor_O_O_O_O_O_O(c__iter__400000367, c__s__400000368, c__base, c__dom, c__ss, c__c any) { t.F_iter__400000367 = c__iter__400000367; t.F_s__400000368 = c__s__400000368; t.F_base = c__base; t.F_dom = c__dom; t.F_ss = c__ss; t.F_c = c__c }
//line :515:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_A) Invoke_O__O(self any) any { { var s__400000368__1 any; var t_ any = t.F_s__400000368; t.F_s__400000368 = nil; s__400000368__1 = t_; for { var temp__1927000414__auto____2 any; var root_2151 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2151, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2153 lang.IFn; if linked_2152 == nil { ifn_2153 = lang.IFn_Cast(root_2151) } else { ifn_2153 = nil }; var arg_2154 any = s__400000368__1; if linked_2152 == nil { temp__1927000414__auto____2 = ifn_2153.Invoke_O__O(arg_2154) } else { temp__1927000414__auto____2 = linked_2152.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2151, arg_2154) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000368__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2155 any = A_arbace_c2j_node_A_const_400.GetRawRoot__O(); var linked_2156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2155, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2157 lang.IFn; if linked_2156 == nil { ifn_2157 = lang.IFn_Cast(root_2155) } else { ifn_2157 = nil }; var arg_2158 any = s__400000368__3; if linked_2156 == nil { tmp1 = ifn_2157.Invoke_O__O(arg_2158) } else { tmp1 = linked_2156.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2155, arg_2158) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2159 any = A_arbace_c2j_node_A_const_401.GetRawRoot__O(); var linked_2160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2159, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2161 lang.IFn; if linked_2160 == nil { ifn_2161 = lang.IFn_Cast(root_2159) } else { ifn_2161 = nil }; var arg_2162 any = s__400000368__3; if linked_2160 == nil { c__1927001037__auto____4 = ifn_2161.Invoke_O__O(arg_2162) } else { c__1927001037__auto____4 = linked_2160.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2159, arg_2162) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000370__6 any; var root_2163 any = A_arbace_c2j_node_A_const_402.GetRawRoot__O(); var linked_2164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2163, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2165 lang.IFn; if linked_2164 == nil { ifn_2165 = lang.IFn_Cast(root_2163) } else { ifn_2165 = nil }; var arg_2166 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2164 == nil { b__400000370__6 = ifn_2165.Invoke_O__O(arg_2166) } else { b__400000370__6 = linked_2164.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2163, arg_2166) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2202 any = A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_A_New_O_O_O_I_O_O_O(b__400000370__6, t.F_base, t.F_dom, size__1927001038__auto____5, t.F_ss, c__1927001037__auto____4, t.F_c); var tmp3 *jrt.Class; var fncls__2201 *jrt.Class = A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_A_fn_class; if fncls__2201 == nil { var fncls__2201d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, fnbody__2202); A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_A_fn_class = fncls__2201d; tmp3 = fncls__2201d } else { tmp3 = fncls__2201 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2202, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2203 any = A_arbace_c2j_node_A_const_404.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2203, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2205 lang.IFn; if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any; var root_2208 any = A_arbace_c2j_node_A_const_405.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2208, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2210 lang.IFn; if linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any = b__400000370__6; if linked_2209 == nil { arg_2206 = ifn_2210.Invoke_O__O(arg_2211) } else { arg_2206 = linked_2209.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2208, arg_2211) }; var arg_2207 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000367); var tmp5 any; var root_2212 any = A_arbace_c2j_node_A_const_406.GetRawRoot__O(); var linked_2213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2212, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2214 lang.IFn; if linked_2213 == nil { ifn_2214 = lang.IFn_Cast(root_2212) } else { ifn_2214 = nil }; var arg_2215 any = s__400000368__3; if linked_2213 == nil { tmp5 = ifn_2214.Invoke_O__O(arg_2215) } else { tmp5 = linked_2213.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2212, arg_2215) }; arg_2207 = tmp4.Invoke_O__O(tmp5); if linked_2204 == nil { return ifn_2205.Invoke_O_O__O(arg_2206, arg_2207) } else { return linked_2204.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2203, arg_2206, arg_2207) } } else { var root_2216 any = A_arbace_c2j_node_A_const_404.GetRawRoot__O(); var linked_2217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2216, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2218 lang.IFn; if linked_2217 == nil { ifn_2218 = lang.IFn_Cast(root_2216) } else { ifn_2218 = nil }; var arg_2219 any; var root_2221 any = A_arbace_c2j_node_A_const_405.GetRawRoot__O(); var linked_2222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2221, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2223 lang.IFn; if linked_2222 == nil { ifn_2223 = lang.IFn_Cast(root_2221) } else { ifn_2223 = nil }; var arg_2224 any = b__400000370__6; if linked_2222 == nil { arg_2219 = ifn_2223.Invoke_O__O(arg_2224) } else { arg_2219 = linked_2222.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2221, arg_2224) }; var arg_2220 any; if linked_2217 == nil { return ifn_2218.Invoke_O_O__O(arg_2219, arg_2220) } else { return linked_2217.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2216, arg_2219, arg_2220) } } } else { var sp__4 any; var root_2225 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2225, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2227 lang.IFn; if linked_2226 == nil { ifn_2227 = lang.IFn_Cast(root_2225) } else { ifn_2227 = nil }; var arg_2228 any = s__400000368__3; if linked_2226 == nil { sp__4 = ifn_2227.Invoke_O__O(arg_2228) } else { sp__4 = linked_2226.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2225, arg_2228) }; var root_2229 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2229, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2231 lang.IFn; if linked_2230 == nil { ifn_2231 = lang.IFn_Cast(root_2229) } else { ifn_2231 = nil }; var arg_2232 any; var tmp6 any = A_arbace_c2j_node_A_const_349; var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp8 any = t.F_base; var tmp9 any
																			if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_c2j_node_A_const_225, t.F_c) { tmp9 = Lit_115 } else { var tmp10 any; var root_2234 any = A_arbace_c2j_node_A_const_413.GetRawRoot__O(); var linked_2235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2234, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2236 lang.IFn; if linked_2235 == nil { ifn_2236 = lang.IFn_Cast(root_2234) } else { ifn_2236 = nil }; var arg_2237 any = t.F_c; if linked_2235 == nil { tmp10 = ifn_2236.Invoke_O__O(arg_2237) } else { tmp10 = linked_2235.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2234, arg_2237) }; if jrt.J2g_Truth(tmp10) { tmp9 = t.F_c } else { if A_arbace_c2j_node_A_const_45 != nil { tmp9 = Lit_116 } else { tmp9 = nil } } }
//line :515:1
	var tmp11 any = tmp9; var tmp12 any; var root_2238 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_2239 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2238, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2240 lang.IFn

	if linked_2239 == nil { ifn_2240 = lang.IFn_Cast(root_2238) } else { ifn_2240 = nil }; var arg_2241 any = A_arbace_c2j_node_A_const_188.GetRawRoot__O(); var arg_2242 any; var root_2243 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_2244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2243, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2245 lang.IFn; if linked_2244 == nil { ifn_2245 = lang.IFn_Cast(root_2243) } else { ifn_2245 = nil }; var arg_2246 any; var fnbody__2253 any = A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000379_A_New_O(sp__4); var tmp13 *jrt.Class; var fncls__2252 *jrt.Class = A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000379_A_fn_class; if fncls__2252 == nil { var fncls__2252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, fnbody__2253); A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000379_A_fn_class = fncls__2252d; tmp13 = fncls__2252d } else { tmp13 = fncls__2252 }; arg_2246 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2253, tmp13, nil); var arg_2247 any = t.F_ss; if linked_2244 == nil { arg_2242 = ifn_2245.Invoke_O_O__O(arg_2246, arg_2247) } else { arg_2242 = linked_2244.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2243, arg_2246, arg_2247) }; if linked_2239 == nil { tmp12 = ifn_2240.Invoke_O_O__O(arg_2241, arg_2242) } else { tmp12 = linked_2239.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2238, arg_2241, arg_2242) }
//line :515:1
	var tmp14 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, tmp8, tmp11, tmp12)).Ref(); var tmp15 any = A_arbace_c2j_node_A_const_239; var tmp16 any = A_arbace_c2j_node_A_const_226; var tmp17 any = t.F_c; var tmp18 any = A_arbace_c2j_node_A_const_341; var tmp19 any



	if jrt.J2g_Truth(t.F_dom) { var root_2254 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2254, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2256 lang.IFn; if linked_2255 == nil { ifn_2256 = lang.IFn_Cast(root_2254) } else { ifn_2256 = nil }; var arg_2257 any; var root_2258 any = A_arbace_c2j_node_A_const_290.GetRawRoot__O(); var linked_2259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2258, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2260 lang.IFn; if linked_2259 == nil { ifn_2260 = lang.IFn_Cast(root_2258) } else { ifn_2260 = nil }; var arg_2261 any = A_arbace_c2j_node_A_const_414.GetRawRoot__O(); var arg_2262 any = lang.RT_Get_O_O__O_NoInit(t.F_dom, t.F_c); if linked_2259 == nil { arg_2257 = ifn_2260.Invoke_O_O__O(arg_2261, arg_2262) } else { arg_2257 = linked_2259.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2258, arg_2261, arg_2262) }; if linked_2255 == nil { tmp19 = ifn_2256.Invoke_O__O(arg_2257) } else { tmp19 = linked_2255.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2254, arg_2257) } } else { tmp19 = nil }
//line :515:1
	arg_2232 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp14, tmp15, sp__4, tmp16, tmp17, tmp18, tmp19)); var arg_2233 any; var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__400000367); var tmp21 any; var root_2263 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2263, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2265 lang.IFn; if linked_2264 == nil { ifn_2265 = lang.IFn_Cast(root_2263) } else { ifn_2265 = nil }; var arg_2266 any = s__400000368__3; if linked_2264 == nil { tmp21 = ifn_2265.Invoke_O__O(arg_2266) } else { tmp21 = linked_2264.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2263, arg_2266) }; arg_2233 = tmp20.Invoke_O__O(tmp21); if linked_2230 == nil { return ifn_2231.Invoke_O_O__O(arg_2232, arg_2233) } else { return linked_2230.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2229, arg_2232, arg_2233) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :515:1
func A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_A_New_O_O_O_I_O_O_O(p0, p1, p2 any, p3 int32, p4, p5, p6 any) *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_A{}; t.Ctor_O_O_O_I_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :515:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_A) Ctor_O_O_O_I_O_O_O(c__b__400000370, c__base, c__dom any, c__size__1927001038__auto__ int32, c__ss, c__c__1927001037__auto__, c__c any) { t.F_b__400000370 = c__b__400000370; t.F_base = c__base; t.F_dom = c__dom; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_ss = c__ss; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_c = c__c }
//line :515:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_A) Invoke_O__O(self any) any { { var i__400000369__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000369__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var sp__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000369__1)); var root_2167 any = A_arbace_c2j_node_A_const_403.GetRawRoot__O(); var linked_2168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2167, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2169 lang.IFn; if linked_2168 == nil { ifn_2169 = lang.IFn_Cast(root_2167) } else { ifn_2169 = nil }; var arg_2170 any = t.F_b__400000370; var arg_2171 any; var tmp2 any = A_arbace_c2j_node_A_const_349; var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, nil); var tmp4 any = t.F_base; var tmp5 any
																					if lang.Util_Equiv_O_O__Z_NoInit(A_arbace_c2j_node_A_const_225, t.F_c) { tmp5 = Lit_115 } else { var tmp6 any; var root_2172 any = A_arbace_c2j_node_A_const_413.GetRawRoot__O(); var linked_2173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2172, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2174 lang.IFn; if linked_2173 == nil { ifn_2174 = lang.IFn_Cast(root_2172) } else { ifn_2174 = nil }; var arg_2175 any = t.F_c; if linked_2173 == nil { tmp6 = ifn_2174.Invoke_O__O(arg_2175) } else { tmp6 = linked_2173.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2172, arg_2175) }; if jrt.J2g_Truth(tmp6) { tmp5 = t.F_c } else { if A_arbace_c2j_node_A_const_45 != nil { tmp5 = Lit_116 } else { tmp5 = nil } } }
//line :515:1
	var tmp7 any = tmp5; var tmp8 any; var root_2176 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_2177 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2176, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2178 lang.IFn

	if linked_2177 == nil { ifn_2178 = lang.IFn_Cast(root_2176) } else { ifn_2178 = nil }; var arg_2179 any = A_arbace_c2j_node_A_const_188.GetRawRoot__O(); var arg_2180 any; var root_2181 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_2182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2181, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2183 lang.IFn; if linked_2182 == nil { ifn_2183 = lang.IFn_Cast(root_2181) } else { ifn_2183 = nil }; var arg_2184 any; var fnbody__2191 any = A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_fn__400000376_A_New_O(sp__2); var tmp9 *jrt.Class; var fncls__2190 *jrt.Class = A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_fn__400000376_A_fn_class; if fncls__2190 == nil { var fncls__2190d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_118, false, fnbody__2191); A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_fn__400000376_A_fn_class = fncls__2190d; tmp9 = fncls__2190d } else { tmp9 = fncls__2190 }; arg_2184 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2191, tmp9, nil); var arg_2185 any = t.F_ss; if linked_2182 == nil { arg_2180 = ifn_2183.Invoke_O_O__O(arg_2184, arg_2185) } else { arg_2180 = linked_2182.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2181, arg_2184, arg_2185) }; if linked_2177 == nil { tmp8 = ifn_2178.Invoke_O_O__O(arg_2179, arg_2180) } else { tmp8 = linked_2177.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2176, arg_2179, arg_2180) }
//line :515:1
	var tmp10 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8)).Ref(); var tmp11 any = A_arbace_c2j_node_A_const_239; var tmp12 any = A_arbace_c2j_node_A_const_226; var tmp13 any = t.F_c; var tmp14 any = A_arbace_c2j_node_A_const_341; var tmp15 any



	if jrt.J2g_Truth(t.F_dom) { var root_2192 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2192, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2194 lang.IFn; if linked_2193 == nil { ifn_2194 = lang.IFn_Cast(root_2192) } else { ifn_2194 = nil }; var arg_2195 any; var root_2196 any = A_arbace_c2j_node_A_const_290.GetRawRoot__O(); var linked_2197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2196, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2198 lang.IFn; if linked_2197 == nil { ifn_2198 = lang.IFn_Cast(root_2196) } else { ifn_2198 = nil }; var arg_2199 any = A_arbace_c2j_node_A_const_414.GetRawRoot__O(); var arg_2200 any = lang.RT_Get_O_O__O_NoInit(t.F_dom, t.F_c); if linked_2197 == nil { arg_2195 = ifn_2198.Invoke_O_O__O(arg_2199, arg_2200) } else { arg_2195 = linked_2197.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2196, arg_2199, arg_2200) }; if linked_2193 == nil { tmp15 = ifn_2194.Invoke_O__O(arg_2195) } else { tmp15 = linked_2193.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2192, arg_2195) } } else { tmp15 = nil }
//line :515:1
	arg_2171 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp10, tmp11, sp__2, tmp12, tmp13, tmp14, tmp15)); if linked_2168 == nil { ifn_2169.Invoke_O_O__O(arg_2170, arg_2171) } else { linked_2168.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2167, arg_2170, arg_2171) }; i__400000369__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000369__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_fn__400000376_A_New_O(p0 any) *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_fn__400000376_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_fn__400000376_A{}; t.Ctor_O(p0); return t }
//line :517:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_fn__400000376_A) Ctor_O(c__sp any) { t.F_sp = c__sp }
//line :517:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_fn__400000376_A) Invoke_O_O__O(self, s__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_sp).Invoke_O__O(s__1)) { var root_2186 any = A_arbace_c2j_node_A_const_395.GetRawRoot__O(); var linked_2187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2186, A_arbace_c2j_node_camel_A_fn_class); var ifn_2188 lang.IFn; if linked_2187 == nil { ifn_2188 = lang.IFn_Cast(root_2186) } else { ifn_2188 = nil }; var arg_2189 any = s__1; if linked_2187 == nil { return ifn_2188.Invoke_O__O(arg_2189) } else { return linked_2187.(*A_arbace_c2j_node_camel_A).Invoke_O_O__O(root_2186, arg_2189) } } else { return nil } }
//line :517:1
func A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000379_A_New_O(p0 any) *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000379_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000379_A{}; t.Ctor_O(p0); return t }
//line :517:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000379_A) Ctor_O(c__sp any) { t.F_sp = c__sp }
//line :517:1
func (t *A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000379_A) Invoke_O_O__O(self, s__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_sp).Invoke_O__O(s__1)) { var root_2248 any = A_arbace_c2j_node_A_const_395.GetRawRoot__O(); var linked_2249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2248, A_arbace_c2j_node_camel_A_fn_class); var ifn_2250 lang.IFn; if linked_2249 == nil { ifn_2250 = lang.IFn_Cast(root_2248) } else { ifn_2250 = nil }; var arg_2251 any = s__1; if linked_2249 == nil { return ifn_2250.Invoke_O__O(arg_2251) } else { return linked_2249.(*A_arbace_c2j_node_camel_A).Invoke_O_O__O(root_2248, arg_2251) } } else { return nil } }



func A_arbace_c2j_node_clause_A_New() *A_arbace_c2j_node_clause_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_A{}; t.Ctor(); return t }
//line :521:1
func (t *A_arbace_c2j_node_clause_A) Ctor() {}
//line :521:1
func (t *A_arbace_c2j_node_clause_A) Invoke_O_O_O__O(self, d__0, vs__1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_416; var exprs__3 any = tmp1.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0)); var one__4 any; if




	lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(exprs__3))) { var root_2292 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2292, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2294 lang.IFn; if linked_2293 == nil { ifn_2294 = lang.IFn_Cast(root_2292) } else { ifn_2294 = nil }; var arg_2295 any = exprs__3; if linked_2293 == nil { one__4 = ifn_2294.Invoke_O__O(arg_2295) } else { one__4 = linked_2293.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2292, arg_2295) } } else { one__4 = nil }; var test__5 any; if
	jrt.J2g_Truth(one__4) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_node_A_const_437; var tmp4 any; var root_2468 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_2469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2468, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2470 lang.IFn; if linked_2469 == nil { ifn_2470 = lang.IFn_Cast(root_2468) } else { ifn_2470 = nil }; var arg_2471 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, one__4)).Ref(); if linked_2469 == nil { tmp4 = ifn_2470.Invoke_O__O(arg_2471) } else { tmp4 = linked_2469.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2468, arg_2471) }; test__5 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_c2j_node_A_const_438) } else {
			var root_2296 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2296, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2298 lang.IFn; if linked_2297 == nil { ifn_2298 = lang.IFn_Cast(root_2296) } else { ifn_2298 = nil }; var arg_2299 any = A_arbace_c2j_node_A_const_417; var arg_2300 any; var root_2301 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any; var fnbody__2311 any = A_arbace_c2j_node_clause_fn__400000389_A_New(); var tmp5 *jrt.Class; var fncls__2310 *jrt.Class = A_arbace_c2j_node_clause_fn__400000389_A_fn_class; if fncls__2310 == nil { var fncls__2310d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_3, false, nil); A_arbace_c2j_node_clause_fn__400000389_A_fn_class = fncls__2310d; tmp5 = fncls__2310d } else { tmp5 = fncls__2310 }; arg_2304 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2311, tmp5, nil); var arg_2305 any = exprs__3; if linked_2302 == nil { arg_2300 = ifn_2303.Invoke_O_O__O(arg_2304, arg_2305) } else { arg_2300 = linked_2302.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2301, arg_2304, arg_2305) }; if linked_2297 == nil { test__5 = ifn_2298.Invoke_O_O__O(arg_2299, arg_2300) } else { test__5 = linked_2297.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2296, arg_2299, arg_2300) } }; var fields__6 any; var root_2312 any = /*line :521:1*/A_arbace_c2j_node_A_const_166.GetRawRoot__O(); var linked_2313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2312, A_arbace_c2j_node_field_names_A_fn_class); var ifn_2314 lang.IFn; if








	linked_2313 == nil { ifn_2314 = lang.IFn_Cast(root_2312) } else { ifn_2314 = nil }; var arg_2315 any = d__0; if linked_2313 == nil { fields__6 = ifn_2314.Invoke_O__O(arg_2315) } else { fields__6 = linked_2313.(*A_arbace_c2j_node_field_names_A).Invoke_O_O__O(root_2312, arg_2315) }; var fbinds__7 any; var tmp6 lang.IFn = /*line :521:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp7 *lang.Compiler_AOTFn; var fnbody__2326 any = A_arbace_c2j_node_clause_fn__400000391_A_New(); var tmp8 *jrt.Class; var fncls__2325 *jrt.Class = A_arbace_c2j_node_clause_fn__400000391_A_fn_class; if









	fncls__2325 == nil { var fncls__2325d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_4, false, nil); A_arbace_c2j_node_clause_fn__400000391_A_fn_class = fncls__2325d; tmp8 = fncls__2325d } else { tmp8 = fncls__2325 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2326, tmp8, nil); fbinds__7 = tmp6.Invoke_O_O__O(tmp7.Ref(), fields__6); var cb__8 any; var root_2327 any = /*line :521:1*/A_arbace_c2j_node_A_const_355.GetRawRoot__O(); var linked_2328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2327, A_arbace_c2j_node_children_bind_A_fn_class); var ifn_2329 lang.IFn; if










	linked_2328 == nil { ifn_2329 = lang.IFn_Cast(root_2327) } else { ifn_2329 = nil }; var arg_2330 any = d__0; if linked_2328 == nil { cb__8 = ifn_2329.Invoke_O__O(arg_2330) } else { cb__8 = linked_2328.(*A_arbace_c2j_node_children_bind_A).Invoke_O_O__O(root_2327, arg_2330) }; var conv__9 any; if
	jrt.J2g_Truth(cb__8) { var tmp9 *lang.Keyword = A_arbace_c2j_node_A_const_356; var tmp10 any; var root_2331 any = A_arbace_c2j_node_A_const_38.GetRawRoot__O(); var linked_2332 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2331, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2333 lang.IFn; if linked_2332 == nil { ifn_2333 = lang.IFn_Cast(root_2331) } else { ifn_2333 = nil }; var arg_2334 any = A_arbace_c2j_node_A_const_247.GetRawRoot__O(); var arg_2335 any; var root_2336 any = A_arbace_c2j_node_A_const_357.GetRawRoot__O(); var linked_2337 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2336, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2338 lang.IFn; if linked_2337 == nil { ifn_2338 = lang.IFn_Cast(root_2336) } else { ifn_2338 = nil }; var arg_2340 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(cb__8); if linked_2337 == nil { arg_2335 = ifn_2338.Invoke_O_O__O(A_arbace_c2j_node_A_const_25, arg_2340) } else { arg_2335 = linked_2337.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2336, 2, A_arbace_c2j_node_A_const_25, arg_2340) }; if linked_2332 == nil { tmp10 = ifn_2333.Invoke_O_O__O(arg_2334, arg_2335) } else { tmp10 = linked_2332.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2331, arg_2334, arg_2335) }; conv__9 = tmp9.Invoke_O__O(tmp10) } else { conv__9 = nil }; var binds__10 any; var root_2341 any = /*line :521:1*/A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2341, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2343 lang.IFn; if












	linked_2342 == nil { ifn_2343 = lang.IFn_Cast(root_2341) } else { ifn_2343 = nil }; var arg_2344 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp12 lang.IPersistentVector; if
	jrt.J2g_Truth(one__4) { var tmp13 any = A_arbace_c2j_node_A_const_421; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp15 any = A_arbace_c2j_node_A_const_422; var tmp16 any; var root_2352 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, one__4)).Ref(); if linked_2353 == nil { tmp16 = ifn_2354.Invoke_O__O(arg_2355) } else { tmp16 = linked_2353.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2352, arg_2355) }; tmp12 = lang.Tuple_Create_O_O__IPersistentVector(tmp13, tmp14.Invoke_O_O_O__O(tmp15, tmp16, A_arbace_c2j_node_A_const_423)) } else { tmp12 = nil }; var tmp17 any = tmp12; var tmp18 lang.IFn = /*line :534:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp19 *lang.Compiler_AOTFn; var fnbody__2375 any = A_arbace_c2j_node_clause_fn__400000393_A_New(); var tmp20 *jrt.Class; var fncls__2374 *jrt.Class = A_arbace_c2j_node_clause_fn__400000393_A_fn_class; if


	fncls__2374 == nil { var fncls__2374d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, nil); A_arbace_c2j_node_clause_fn__400000393_A_fn_class = fncls__2374d; tmp20 = fncls__2374d } else { tmp20 = fncls__2374 }; tmp19 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2375, tmp20, nil); var tmp21 any = /*line :534:1*/tmp18.Invoke_O_O__O(tmp19.Ref(), A_arbace_c2j_node_A_const_17.Invoke_O__O(d__0)); var tmp22 lang.IPersistentVector; if








	jrt.J2g_Truth(conv__9) { tmp22 = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_c2j_node_A_const_429, conv__9) } else { tmp22 = nil }; arg_2344 = /*line :534:1*/tmp11.Invoke_O_O_O_O__O(tmp17, fbinds__7, tmp21, tmp22); if linked_2342 == nil { binds__10 = ifn_2343.Invoke_O__O(arg_2344) } else { binds__10 = linked_2342.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2341, arg_2344) }; var ss__11 any; var root_2376 any = /*line :521:1*/A_arbace_c2j_node_A_const_396.GetRawRoot__O(); var linked_2377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2376, A_arbace_c2j_node_splits_A_fn_class); var ifn_2378 lang.IFn; if






















	linked_2377 == nil { ifn_2378 = lang.IFn_Cast(root_2376) } else { ifn_2378 = nil }; var arg_2379 any = d__0; if linked_2377 == nil { ss__11 = ifn_2378.Invoke_O__O(arg_2379) } else { ss__11 = linked_2377.(*A_arbace_c2j_node_splits_A).Invoke_O_O__O(root_2376, arg_2379) }; var construct__12 any; var fnbody__2396 any = /*line :521:1*/A_arbace_c2j_node_clause_construct__400000397_A_New(); var tmp23 *jrt.Class; var fncls__2395 *jrt.Class = A_arbace_c2j_node_clause_construct__400000397_A_fn_class; if























	fncls__2395 == nil { var fncls__2395d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, nil); A_arbace_c2j_node_clause_construct__400000397_A_fn_class = fncls__2395d; tmp23 = fncls__2395d } else { tmp23 = fncls__2395 }; construct__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2396, tmp23, nil); var pick__13 any; var fnbody__2442 any = /*line :521:1*/A_arbace_c2j_node_clause_pick__400000402_A_New_O_O(construct__12, ss__11); var tmp24 *jrt.Class; var fncls__2441 *jrt.Class = A_arbace_c2j_node_clause_pick__400000402_A_fn_class; if
























	fncls__2441 == nil { var fncls__2441d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__2442); A_arbace_c2j_node_clause_pick__400000402_A_fn_class = fncls__2441d; tmp24 = fncls__2441d } else { tmp24 = fncls__2441 }; pick__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2442, tmp24, nil); var by_count__14 any; var root_2443 any = /*line :521:1*/A_arbace_c2j_node_A_const_432.GetRawRoot__O(); var linked_2444 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2443, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_2445 lang.IFn; if


































	linked_2444 == nil { ifn_2445 = lang.IFn_Cast(root_2443) } else { ifn_2445 = nil }; var arg_2446 any; var root_2448 any = A_arbace_c2j_node_A_const_433.GetRawRoot__O(); var linked_2449 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2448, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_2450 lang.IFn; if linked_2449 == nil { ifn_2450 = lang.IFn_Cast(root_2448) } else { ifn_2450 = nil }; var arg_2451 any = A_arbace_c2j_node_A_const_226; var arg_2452 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); if linked_2449 == nil { arg_2446 = ifn_2450.Invoke_O_O__O(arg_2451, arg_2452) } else { arg_2446 = linked_2449.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_2448, arg_2451, arg_2452) }; var arg_2447 any = vs__1; if linked_2444 == nil { by_count__14 = ifn_2445.Invoke_O_O__O(arg_2446, arg_2447) } else { by_count__14 = linked_2444.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_2443, arg_2446, arg_2447) }; var counted__15 any; var root_2453 any = /*line :521:1*/A_arbace_c2j_node_A_const_434.GetRawRoot__O(); var linked_2454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2453, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2455 lang.IFn; if



































	linked_2454 == nil { ifn_2455 = lang.IFn_Cast(root_2453) } else { ifn_2455 = nil }; var arg_2456 any = A_arbace_c2j_node_A_const_435.GetRawRoot__O(); var arg_2457 any; var root_2458 any = A_arbace_c2j_node_A_const_32.GetRawRoot__O(); var linked_2459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2458, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2460 lang.IFn; if linked_2459 == nil { ifn_2460 = lang.IFn_Cast(root_2458) } else { ifn_2460 = nil }; var arg_2461 any; var root_2463 any = A_arbace_c2j_node_A_const_433.GetRawRoot__O(); var linked_2464 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2463, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_2465 lang.IFn; if linked_2464 == nil { ifn_2465 = lang.IFn_Cast(root_2463) } else { ifn_2465 = nil }; var arg_2466 any = A_arbace_c2j_node_A_const_436.GetRawRoot__O(); var arg_2467 any = A_arbace_c2j_node_A_const_435.GetRawRoot__O(); if linked_2464 == nil { arg_2461 = ifn_2465.Invoke_O_O__O(arg_2466, arg_2467) } else { arg_2461 = linked_2464.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_2463, arg_2466, arg_2467) }; var arg_2462 any = by_count__14; if linked_2459 == nil { arg_2457 = ifn_2460.Invoke_O_O__O(arg_2461, arg_2462) } else { arg_2457 = linked_2459.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2458, arg_2461, arg_2462) }; if linked_2454 == nil { counted__15 = ifn_2455.Invoke_O_O__O(arg_2456, arg_2457) } else { counted__15 = linked_2454.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2453, arg_2456, arg_2457) }; var body__16 any; var tmp25 /*line :521:1*/*lang.Keyword = A_arbace_c2j_node_A_const_408; if




































	jrt.J2g_Truth(tmp25.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0))) {

		var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp27 any = A_arbace_c2j_node_A_const_439; var tmp28 any = A_arbace_c2j_node_A_const_444; var tmp29 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_446, A_arbace_c2j_node_A_const_447, A_arbace_c2j_node_A_const_448); var tmp30 any = A_arbace_c2j_node_A_const_445; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp32 any = A_arbace_c2j_node_A_const_449; var tmp33 any = A_arbace_c2j_node_A_const_450; var tmp34 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp28, tmp29, tmp30, tmp31.Invoke_O_O_O__O(tmp32, tmp33, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_451, A_arbace_c2j_node_A_const_452, A_arbace_c2j_node_A_const_453))); var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp36 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_440); var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp38 *lang.Compiler_AOTFn; var fnbody__2484 any = A_arbace_c2j_node_clause_fn__400000411_A_New_O(pick__13); var tmp39 *jrt.Class
		var fncls__2483 /*line :560:1*/*jrt.Class = A_arbace_c2j_node_clause_fn__400000411_A_fn_class

		if fncls__2483 == nil { var fncls__2483d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__2484); A_arbace_c2j_node_clause_fn__400000411_A_fn_class = fncls__2483d; tmp39 = fncls__2483d } else { tmp39 = fncls__2483 }; tmp38 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2484, tmp39, nil)
//line :560:1
		body__16 = tmp26.Invoke_O_O_O__O(tmp27, tmp34, tmp35.Invoke_O_O_O__O(tmp36, tmp37.Invoke_O_O__O(tmp38.Ref(), counted__15), A_arbace_c2j_node_A_const_443)) } else {
//line :558:1
			if jrt.J2g_Truth(cb__8) {





				var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp41 any = A_arbace_c2j_node_A_const_454; var tmp42 any = A_arbace_c2j_node_A_const_458; var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp44 any = A_arbace_c2j_node_A_const_459; var tmp45 any; var root_2498 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2498, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2500 lang.IFn; if linked_2499 == nil { ifn_2500 = lang.IFn_Cast(root_2498) } else { ifn_2500 = nil }; var arg_2501 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(cb__8); if linked_2499 == nil { tmp45 = ifn_2500.Invoke_O__O(arg_2501) } else { tmp45 = linked_2499.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2498, arg_2501) }; var tmp46 any = lang.Tuple_Create_O_O__IPersistentVector(tmp42, tmp43.Invoke_O_O__O(tmp44, tmp45)); var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp48 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_455); var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp50 *lang.Compiler_AOTFn; var fnbody__2497 any = A_arbace_c2j_node_clause_fn__400000417_A_New_O(pick__13); var tmp51 *jrt.Class; var fncls__2496 *jrt.Class = A_arbace_c2j_node_clause_fn__400000417_A_fn_class
				if fncls__2496 == nil { var fncls__2496d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__2497); A_arbace_c2j_node_clause_fn__400000417_A_fn_class = fncls__2496d; tmp51 = fncls__2496d } else { tmp51 = fncls__2496 }; tmp50 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2497, tmp51, nil)
//line :564:1
				var tmp52 any = tmp49.Invoke_O_O__O(tmp50.Ref(), counted__15); var tmp53 any = A_arbace_c2j_node_A_const_45; var tmp54 any; var temp__1927000414__auto____16 any = lang.IFn_Cast(by_count__14).Invoke_O__O(A_arbace_c2j_node_A_const_225)

				if jrt.J2g_Truth(temp__1927000414__auto____16) { var m__17 any = temp__1927000414__auto____16; tmp54 = lang.IFn_Cast(pick__13).Invoke_O__O(m__17) } else { tmp54 = nil }
//line :564:1
				body__16 = tmp40.Invoke_O_O_O__O(tmp41, tmp46, tmp47.Invoke_O_O_O__O(tmp48, tmp52, lang.Tuple_Create_O_O__IPersistentVector(tmp53, tmp54))) } else {
//line :558:1
					if A_arbace_c2j_node_A_const_45 != nil {








						body__16 = lang.IFn_Cast(pick__13).Invoke_O__O(vs__1) } else {
//line :558:1
							body__16 = nil } } }; var tmp55 any; var tmp56 /*line :521:1*/*lang.Keyword = A_arbace_c2j_node_A_const_460; var tmp57 *lang.Keyword = A_arbace_c2j_node_A_const_408; var temp__1927000408__auto____17 any = tmp56.Invoke_O__O(tmp57.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__0))); if














































	jrt.J2g_Truth(temp__1927000408__auto____17) { var ix__18 any = temp__1927000408__auto____17; var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp59 any = A_arbace_c2j_node_A_const_461; var tmp60 any; var root_2502 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2502, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2504 lang.IFn
		if linked_2503 == nil { ifn_2504 = lang.IFn_Cast(root_2502) } else { ifn_2504 = nil }; var arg_2505 any; var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp62 any = A_arbace_c2j_node_A_const_462; var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp64 any = A_arbace_c2j_node_A_const_463; var tmp65 any; var root_2512 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_2513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2512, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2514 lang.IFn; if linked_2513 == nil { ifn_2514 = lang.IFn_Cast(root_2512) } else { ifn_2514 = nil }; var arg_2515 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, one__4)).Ref(); if linked_2513 == nil { tmp65 = ifn_2514.Invoke_O__O(arg_2515) } else { tmp65 = linked_2513.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2512, arg_2515) }; arg_2505 = tmp61.Invoke_O_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp62, tmp63.Invoke_O_O_O__O(tmp64, tmp65, A_arbace_c2j_node_A_const_464)), fbinds__7, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_c2j_node_A_const_465, ix__18)); if linked_2503 == nil { tmp60 = ifn_2504.Invoke_O__O(arg_2505) } else { tmp60 = linked_2503.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2502, arg_2505) }; var tmp66 any = tmp60; var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp68 any = A_arbace_c2j_node_A_const_466; var tmp69 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_467, A_arbace_c2j_node_A_const_468, A_arbace_c2j_node_A_const_258); var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp71 any = A_arbace_c2j_node_A_const_469; var tmp72 any; var root_2516 any = A_arbace_c2j_node_A_const_22.GetRawRoot__O(); var linked_2517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2516, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2518 lang.IFn
		if linked_2517 == nil { ifn_2518 = lang.IFn_Cast(root_2516) } else { ifn_2518 = nil }; var arg_2519 any; var root_2520 any = A_arbace_c2j_node_A_const_357.GetRawRoot__O(); var linked_2521 any = lang.Compiler_AOTFn_LinkedFast_O_Class__O(root_2520, aot_arbace_core.A_arbace_core_drop_A_fn_class); var ifn_2522 lang.IFn; if linked_2521 == nil { ifn_2522 = lang.IFn_Cast(root_2520) } else { ifn_2522 = nil }; var arg_2523 int64 = lang.Numbers_Add_J_J__J_NoInit(2, int64(lang.RT_Count_O__I_NoInit(fbinds__7))); var arg_2524 any = binds__10; if linked_2521 == nil { arg_2519 = ifn_2522.Invoke_O_O__O(jrt.Long_ValueOf_J__Long_NoInit(arg_2523).Ref(), arg_2524) } else { arg_2519 = linked_2521.(*aot_arbace_core.A_arbace_core_drop_A).InvokeSpec_O_J_O_O__O(root_2520, arg_2523, nil, arg_2524) }; if linked_2517 == nil { tmp72 = ifn_2518.Invoke_O__O(arg_2519) } else { tmp72 = linked_2517.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2516, arg_2519) }
//line :569:1
		tmp55 = tmp58.Invoke_O_O_O__O(tmp59, tmp66, tmp67.Invoke_O_O_O_O__O(tmp68, tmp69, nil, tmp70.Invoke_O_O_O__O(tmp71, tmp72, body__16))) } else {

			tmp55 = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_470, binds__10, body__16) }; return /*line :521:1*/ lang.Tuple_Create_O_O__IPersistentVector(test__5, tmp55) }







func A_arbace_c2j_node_clause_fn__400000389_A_New() *A_arbace_c2j_node_clause_fn__400000389_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000389_A{}; t.Ctor(); return t }
//line :529:1
func (t *A_arbace_c2j_node_clause_fn__400000389_A) Ctor() {}
//line :529:1
func (t *A_arbace_c2j_node_clause_fn__400000389_A) Invoke_O_O__O(self, p1__400000386_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_418; var tmp3 any; var root_2306 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_2307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2306, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2308 lang.IFn; if linked_2307 == nil { ifn_2308 = lang.IFn_Cast(root_2306) } else { ifn_2308 = nil }; var arg_2309 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__400000386_SHARP___1)).Ref(); if linked_2307 == nil { tmp3 = ifn_2308.Invoke_O__O(arg_2309) } else { tmp3 = linked_2307.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2306, arg_2309) }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_c2j_node_A_const_419) }

func A_arbace_c2j_node_clause_fn__400000391_A_New() *A_arbace_c2j_node_clause_fn__400000391_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000391_A{}; t.Ctor(); return t }
//line :531:1
func (t *A_arbace_c2j_node_clause_fn__400000391_A) Ctor() {}
//line :531:1
func (t *A_arbace_c2j_node_clause_fn__400000391_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any; var root_2321 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_2322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2321, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2323 lang.IFn; if linked_2322 == nil { ifn_2323 = lang.IFn_Cast(root_2321) } else { ifn_2323 = nil }; var arg_2324 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__1)).Ref(); if linked_2322 == nil { tmp2 = ifn_2323.Invoke_O__O(arg_2324) } else { tmp2 = linked_2322.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2321, arg_2324) }; return lang.Tuple_Create_O_O__IPersistentVector(f__1, tmp1.Invoke_O_O__O(tmp2, A_arbace_c2j_node_A_const_420)) }





func A_arbace_c2j_node_clause_fn__400000393_A_New() *A_arbace_c2j_node_clause_fn__400000393_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000393_A{}; t.Ctor(); return t }
//line :537:1
func (t *A_arbace_c2j_node_clause_fn__400000393_A) Ctor() {}
//line :537:1
func (t *A_arbace_c2j_node_clause_fn__400000393_A) Invoke_O_O__O(self, b__1 any) any { var G__400000394__2_ any = A_arbace_c2j_node_A_const_20.Invoke_O__O(b__1); switch
											lang.Util_Hash_O__I_NoInit(G__400000394__2_) >> 0 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__400000394__2_, A_arbace_c2j_node_A_const_424) { var tmp1 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp3 any = A_arbace_c2j_node_A_const_427; var tmp4 any = A_arbace_c2j_node_A_const_428; var tmp5 any; var root_2362 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2362, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2364 lang.IFn
												if linked_2363 == nil { ifn_2364 = lang.IFn_Cast(root_2362) } else { ifn_2364 = nil }; var arg_2365 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_2363 == nil { tmp5 = ifn_2364.Invoke_O__O(arg_2365) } else { tmp5 = linked_2363.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2362, arg_2365) }
//line :538:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp1, tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5)) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__400000394__2_, A_arbace_c2j_node_A_const_425) { var tmp6 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp7 any; var root_2366 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_2367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2366, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2368 lang.IFn

			if linked_2367 == nil { ifn_2368 = lang.IFn_Cast(root_2366) } else { ifn_2368 = nil }; var arg_2369 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_2367 == nil { tmp7 = ifn_2368.Invoke_O__O(arg_2369) } else { tmp7 = linked_2367.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2366, arg_2369) }
//line :538:1
			return lang.Tuple_Create_O_O__IPersistentVector(tmp6, tmp7) }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__400000394__2_, A_arbace_c2j_node_A_const_426) { var tmp8 any = A_arbace_c2j_node_A_const_19.Invoke_O__O(b__1); var tmp9 any; var root_2370 any = A_arbace_c2j_node_A_const_52.GetRawRoot__O(); var linked_2371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2370, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2372 lang.IFn

				if linked_2371 == nil { ifn_2372 = lang.IFn_Cast(root_2370) } else { ifn_2372 = nil }; var arg_2373 any = A_arbace_c2j_node_A_const_21.Invoke_O__O(b__1); if linked_2371 == nil { tmp9 = ifn_2372.Invoke_O__O(arg_2373) } else { tmp9 = linked_2371.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2370, arg_2373) }
//line :538:1
				return lang.Tuple_Create_O_O__IPersistentVector(tmp8, tmp9) }; default:}; return nil }






func A_arbace_c2j_node_clause_construct__400000397_A_New() *A_arbace_c2j_node_clause_construct__400000397_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_construct__400000397_A{}; t.Ctor(); return t }
//line :545:1
func (t *A_arbace_c2j_node_clause_construct__400000397_A) Ctor() {}
//line :545:1
func (t *A_arbace_c2j_node_clause_construct__400000397_A) Invoke_O_O__O(self, p__400000396__1 any) any { var vec__400000398__2 any = p__400000396__1; var v__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000398__2, lang.RT_IntCast_J__I_NoInit(0), nil); var fields__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000398__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2380 any = A_arbace_c2j_node_A_const_62.GetRawRoot__O(); var linked_2381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2380, aot_arbace_core.A_arbace_core_list_STAR__A_fn_class); var ifn_2382 lang.IFn; if linked_2381 == nil { ifn_2382 = lang.IFn_Cast(root_2380) } else { ifn_2382 = nil }; var arg_2383 any = A_arbace_c2j_node_A_const_430; var arg_2384 any; var root_2386 any = A_arbace_c2j_node_A_const_141.GetRawRoot__O(); var linked_2387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2386, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_2388 lang.IFn; if linked_2387 == nil { ifn_2388 = lang.IFn_Cast(root_2386) } else { ifn_2388 = nil }; var arg_2389 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_c2j_node_A_const_349.Invoke_O__O(v__3))).Ref(); if linked_2387 == nil { arg_2384 = ifn_2388.Invoke_O__O(arg_2389) } else { arg_2384 = linked_2387.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_2386, arg_2389) }; var arg_2385 any; var root_2390 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_2391 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2390, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2392 lang.IFn; if linked_2391 == nil { ifn_2392 = lang.IFn_Cast(root_2390) } else { ifn_2392 = nil }; var arg_2393 any = A_arbace_c2j_node_A_const_360; var arg_2394 any = fields__4; if linked_2391 == nil { arg_2385 = ifn_2392.Invoke_O_O__O(arg_2393, arg_2394) } else { arg_2385 = linked_2391.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2390, arg_2393, arg_2394) }; if linked_2381 == nil { return ifn_2382.Invoke_O_O_O__O(arg_2383, arg_2384, arg_2385) } else { return linked_2381.(*aot_arbace_core.A_arbace_core_list_STAR__A).Invoke_O_O_O_O__O(root_2380, arg_2383, arg_2384, arg_2385) } }
func A_arbace_c2j_node_clause_pick__400000402_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_clause_pick__400000402_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_pick__400000402_A{}; t.Ctor_O_O(p0, p1); return t }
//line :546:1
func (t *A_arbace_c2j_node_clause_pick__400000402_A) Ctor_O_O(c__construct, c__ss any) { t.F_construct = c__construct; t.F_ss = c__ss }
//line :546:1
func (t *A_arbace_c2j_node_clause_pick__400000402_A) Invoke_O_O__O(self, vfs__1 any) any { var body_go__2 *A_arbace_c2j_node_clause_pick__400000402_go__400000403_A = A_arbace_c2j_node_clause_pick__400000402_go__400000403_A_New_O(t.F_construct); var go__2 any; var fnbody__2440 any = any(body_go__2); var tmp1 *jrt.Class; var fncls__2439 *jrt.Class = A_arbace_c2j_node_clause_pick__400000402_go__400000403_A_fn_class; if fncls__2439 == nil { var fncls__2439d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_11, false, fnbody__2440); A_arbace_c2j_node_clause_pick__400000402_go__400000403_A_fn_class = fncls__2439d; tmp1 = fncls__2439d } else { tmp1 = fncls__2439 }; go__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2440, tmp1, nil); return /*line :555:1*/ lang.IFn_Cast(go__2).Invoke_O_O__O(t.F_ss, vfs__1) }
//line :548:1
func A_arbace_c2j_node_clause_pick__400000402_go__400000403_A_New_O(p0 any) *A_arbace_c2j_node_clause_pick__400000402_go__400000403_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_pick__400000402_go__400000403_A{}; t.Ctor_O(p0); return t }
//line :548:1
func (t *A_arbace_c2j_node_clause_pick__400000402_go__400000403_A) Ctor_O(c__construct any) { t.F_construct = c__construct }
//line :548:1
func (t *A_arbace_c2j_node_clause_pick__400000402_go__400000403_A) Invoke_O_O_O__O(self, ss__1, vfs__2 any) any {
	var tmp1 any; var root_2397 any = A_arbace_c2j_node_A_const_61.GetRawRoot__O(); var linked_2398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2397, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_2399 lang.IFn; if linked_2398 == nil { ifn_2399 = lang.IFn_Cast(root_2397) } else { ifn_2399 = nil }; var arg_2400 any = ss__1; if linked_2398 == nil { tmp1 = ifn_2399.Invoke_O__O(arg_2400) } else { tmp1 = linked_2398.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_2397, arg_2400) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(t.F_construct); var tmp3 any; var root_2405 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2405, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2407 lang.IFn; if linked_2406 == nil { ifn_2407 = lang.IFn_Cast(root_2405) } else { ifn_2407 = nil }; var arg_2408 any = vfs__2; if linked_2406 == nil { tmp3 = ifn_2407.Invoke_O__O(arg_2408) } else { tmp3 = linked_2406.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2405, arg_2408) }; return tmp2.Invoke_O__O(tmp3) } else {
//line :549:1
			var s__3 any; var root_2401 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2401, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2403 lang.IFn

			if linked_2402 == nil { ifn_2403 = lang.IFn_Cast(root_2401) } else { ifn_2403 = nil }; var arg_2404 any = ss__1; if linked_2402 == nil { s__3 = ifn_2403.Invoke_O__O(arg_2404) } else { s__3 = linked_2402.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2401, arg_2404) }
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp5 any = A_arbace_c2j_node_A_const_431; var tmp6 lang.IFn = lang.IFn_Cast(self); var tmp7 any; var root_2409 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2409, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2411 lang.IFn
			if linked_2410 == nil { ifn_2411 = lang.IFn_Cast(root_2409) } else { ifn_2411 = nil }; var arg_2412 any = ss__1; if linked_2410 == nil { tmp7 = ifn_2411.Invoke_O__O(arg_2412) } else { tmp7 = linked_2410.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2409, arg_2412) }
//line :552:1
			var tmp8 any = tmp7; var tmp9 any; var root_2413 any = A_arbace_c2j_node_A_const_32.GetRawRoot__O(); var linked_2414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2413, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_2415 lang.IFn
			if linked_2414 == nil { ifn_2415 = lang.IFn_Cast(root_2413) } else { ifn_2415 = nil }; var arg_2416 any; var fnbody__2423 any = A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000404_A_New_O(s__3); var tmp10 *jrt.Class; var fncls__2422 *jrt.Class = A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000404_A_fn_class; if fncls__2422 == nil { var fncls__2422d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_12, false, fnbody__2423); A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000404_A_fn_class = fncls__2422d; tmp10 = fncls__2422d } else { tmp10 = fncls__2422 }; arg_2416 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2423, tmp10, nil); var arg_2417 any = vfs__2; if linked_2414 == nil { tmp9 = ifn_2415.Invoke_O_O__O(arg_2416, arg_2417) } else { tmp9 = linked_2414.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_2413, arg_2416, arg_2417) }
//line :552:1
			var tmp11 any = tmp6.Invoke_O_O__O(tmp8, tmp9); var tmp12 lang.IFn = lang.IFn_Cast(self); var tmp13 any; var root_2424 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2424, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2426 lang.IFn

			if linked_2425 == nil { ifn_2426 = lang.IFn_Cast(root_2424) } else { ifn_2426 = nil }; var arg_2427 any = ss__1; if linked_2425 == nil { tmp13 = ifn_2426.Invoke_O__O(arg_2427) } else { tmp13 = linked_2425.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2424, arg_2427) }
//line :552:1
			var tmp14 any = tmp13; var tmp15 any; var root_2428 any = A_arbace_c2j_node_A_const_59.GetRawRoot__O(); var linked_2429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2428, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_2430 lang.IFn

			if linked_2429 == nil { ifn_2430 = lang.IFn_Cast(root_2428) } else { ifn_2430 = nil }; var arg_2431 any; var fnbody__2438 any = A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000406_A_New_O(s__3); var tmp16 *jrt.Class; var fncls__2437 *jrt.Class = A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000406_A_fn_class; if fncls__2437 == nil { var fncls__2437d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_13, false, fnbody__2438); A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000406_A_fn_class = fncls__2437d; tmp16 = fncls__2437d } else { tmp16 = fncls__2437 }; arg_2431 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2438, tmp16, nil); var arg_2432 any = vfs__2; if linked_2429 == nil { tmp15 = ifn_2430.Invoke_O_O__O(arg_2431, arg_2432) } else { tmp15 = linked_2429.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_2428, arg_2431, arg_2432) }
//line :552:1
			return tmp4.Invoke_O_O_O_O__O(tmp5, s__3, tmp11, tmp12.Invoke_O_O__O(tmp14, tmp15)) } }
func A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000404_A_New_O(p0 any) *A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000404_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000404_A{}; t.Ctor_O(p0); return t }
//line :553:1
func (t *A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000404_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :553:1
func (t *A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000404_A) Invoke_O_O__O(self, p1__400000387_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_239; var tmp2 any; var root_2418 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2419 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2418, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2420 lang.IFn; if linked_2419 == nil { ifn_2420 = lang.IFn_Cast(root_2418) } else { ifn_2420 = nil }; var arg_2421 any = p1__400000387_SHARP___1; if linked_2419 == nil { tmp2 = ifn_2420.Invoke_O__O(arg_2421) } else { tmp2 = linked_2419.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2418, arg_2421) }; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(tmp2), t.F_s) }
func A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000406_A_New_O(p0 any) *A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000406_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000406_A{}; t.Ctor_O(p0); return t }
//line :554:1
func (t *A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000406_A) Ctor_O(c__s any) { t.F_s = c__s }
//line :554:1
func (t *A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000406_A) Invoke_O_O__O(self, p1__400000388_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_c2j_node_A_const_239; var tmp2 any; var root_2433 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2433, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2435 lang.IFn; if linked_2434 == nil { ifn_2435 = lang.IFn_Cast(root_2433) } else { ifn_2435 = nil }; var arg_2436 any = p1__400000388_SHARP___1; if linked_2434 == nil { tmp2 = ifn_2435.Invoke_O__O(arg_2436) } else { tmp2 = linked_2434.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2433, arg_2436) }; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(tmp2), t.F_s) }







func A_arbace_c2j_node_clause_fn__400000411_A_New_O(p0 any) *A_arbace_c2j_node_clause_fn__400000411_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000411_A{}; t.Ctor_O(p0); return t }
//line :562:1
func (t *A_arbace_c2j_node_clause_fn__400000411_A) Ctor_O(c__pick any) { t.F_pick = c__pick }
//line :562:1
func (t *A_arbace_c2j_node_clause_fn__400000411_A) Invoke_O_O__O(self, p__400000410__1 any) any { var vec__400000412__2 any = p__400000410__1; var c__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000412__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000412__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_441, A_arbace_c2j_node_A_const_442, c__3), lang.IFn_Cast(t.F_pick).Invoke_O__O(vfs__4)) }


func A_arbace_c2j_node_clause_fn__400000417_A_New_O(p0 any) *A_arbace_c2j_node_clause_fn__400000417_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_clause_fn__400000417_A{}; t.Ctor_O(p0); return t }
//line :565:1
func (t *A_arbace_c2j_node_clause_fn__400000417_A) Ctor_O(c__pick any) { t.F_pick = c__pick }
//line :565:1
func (t *A_arbace_c2j_node_clause_fn__400000417_A) Invoke_O_O__O(self, p__400000416__1 any) any { var vec__400000418__2 any = p__400000416__1; var c__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000418__2, lang.RT_IntCast_J__I_NoInit(0), nil); var vfs__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000418__2, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_c2j_node_A_const_456, A_arbace_c2j_node_A_const_457, c__3), lang.IFn_Cast(t.F_pick).Invoke_O__O(vfs__4)) }







func A_arbace_c2j_node_code_forms_A_New() *A_arbace_c2j_node_code_forms_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_A{}; t.Ctor(); return t }
//line :573:1
func (t *A_arbace_c2j_node_code_forms_A) Ctor() {}
//line :573:1
func (t *A_arbace_c2j_node_code_forms_A) Invoke_O_O_O_O__O(self, helpers__0, domains__1, keys__2 any) any { var per__4 any; var iter__1927001039__auto____4 any; var fnbody__2632 any = A_arbace_c2j_node_code_forms_iter__400000423__400000427_A_New_O_O(helpers__0, domains__1); var tmp1 *jrt.Class; var fncls__2631 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000423__400000427_A_fn_class; if






	fncls__2631 == nil { var fncls__2631d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_14, false, fnbody__2632); A_arbace_c2j_node_code_forms_iter__400000423__400000427_A_fn_class = fncls__2631d; tmp1 = fncls__2631d } else { tmp1 = fncls__2631 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2632, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp3 any; var root_3099 any = A_arbace_c2j_node_A_const_5.GetRawRoot__O(); var linked_3100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3099, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_3101 lang.IFn; if linked_3100 == nil { ifn_3101 = lang.IFn_Cast(root_3099) } else { ifn_3101 = nil }; var arg_3102 any = A_arbace_c2j_node_A_const_10.GetRawRoot__O(); if linked_3100 == nil { tmp3 = ifn_3101.Invoke_O__O(arg_3102) } else { tmp3 = linked_3100.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_3099, arg_3102) }; per__4 = tmp2.Invoke_O__O(tmp3); var clauses__5 any; var tmp4 lang.IFn = /*line :573:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_99.GetRawRoot__O()); var tmp5 *lang.Compiler_AOTFn; var fnbody__2674 any = A_arbace_c2j_node_code_forms_fn__400000444_A_New(); var tmp6 *jrt.Class; var fncls__2673 *jrt.Class = A_arbace_c2j_node_code_forms_fn__400000444_A_fn_class; if











	fncls__2673 == nil { var fncls__2673d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, nil); A_arbace_c2j_node_code_forms_fn__400000444_A_fn_class = fncls__2673d; tmp6 = fncls__2673d } else { tmp6 = fncls__2673 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2674, tmp6, nil); clauses__5 = tmp4.Invoke_O_O__O(tmp5.Ref(), per__4); var table__6 any; var iter__1927001039__auto____6 any; var fnbody__2844 any = /*line :573:1*/A_arbace_c2j_node_code_forms_iter__400000448__400000456_A_New_O_O(domains__1, keys__2); var tmp7 *jrt.Class; var fncls__2843 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000448__400000456_A_fn_class; if












	fncls__2843 == nil { var fncls__2843d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__2844); A_arbace_c2j_node_code_forms_iter__400000448__400000456_A_fn_class = fncls__2843d; tmp7 = fncls__2843d } else { tmp7 = fncls__2843 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2844, tmp7, nil); table__6 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(per__4); var root_2845 any =



	A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2846 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2845, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2847 lang.IFn; if linked_2846 == nil { ifn_2847 = lang.IFn_Cast(root_2845) } else { ifn_2847 = nil }; var arg_2848 any; var iter__1927001039__auto____7 any; var fnbody__3044 any = A_arbace_c2j_node_code_forms_iter__400000481__400000487_A_New(); var tmp8 *jrt.Class; var fncls__3043 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000481__400000487_A_fn_class; if
	fncls__3043 == nil { var fncls__3043d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_c2j_node_code_forms_iter__400000481__400000487_A_fn_class = fncls__3043d; tmp8 = fncls__3043d } else { tmp8 = fncls__3043 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3044, tmp8, nil); arg_2848 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(per__4); var arg_2849 any; var tmp9 lang.IFn = /*line :590:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp10 any = A_arbace_c2j_node_A_const_479; var tmp11 any; var root_3045 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3045, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3047 lang.IFn; if







	linked_3046 == nil { ifn_3047 = lang.IFn_Cast(root_3045) } else { ifn_3047 = nil }; var arg_3048 any = A_arbace_c2j_node_A_const_480; var arg_3049 any = A_arbace_c2j_node_A_const_481; if linked_3046 == nil { tmp11 = ifn_3047.Invoke_O_O__O(arg_3048, arg_3049) } else { tmp11 = linked_3046.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3045, arg_3048, arg_3049) }; var tmp12 any = tmp11; var tmp13 lang.IFn = /*line :590:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp14 any = A_arbace_c2j_node_A_const_482; var tmp15 any; var root_3050 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3050, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3052 lang.IFn; if








	linked_3051 == nil { ifn_3052 = lang.IFn_Cast(root_3050) } else { ifn_3052 = nil }; var arg_3053 any = A_arbace_c2j_node_A_const_483; var arg_3054 any = A_arbace_c2j_node_A_const_484; if linked_3051 == nil { tmp15 = ifn_3052.Invoke_O_O__O(arg_3053, arg_3054) } else { tmp15 = linked_3051.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3050, arg_3053, arg_3054) }; var tmp16 any = tmp15; var tmp17 any; var root_3055 any = /*line :590:1*/A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3055, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3057 lang.IFn; if









	linked_3056 == nil { ifn_3057 = lang.IFn_Cast(root_3055) } else { ifn_3057 = nil }; var arg_3058 any; var tmp18 any; var root_3060 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3061 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3060, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3062 lang.IFn; if linked_3061 == nil { ifn_3062 = lang.IFn_Cast(root_3060) } else { ifn_3062 = nil }; var arg_3063 any = A_arbace_c2j_node_A_const_485; var arg_3064 any = A_arbace_c2j_node_A_const_486; if linked_3061 == nil { tmp18 = ifn_3062.Invoke_O_O__O(arg_3063, arg_3064) } else { tmp18 = linked_3061.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3060, arg_3063, arg_3064) }; var tmp19 any = tmp18; var tmp20 any; var root_3065 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3065, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3067 lang.IFn; if linked_3066 == nil { ifn_3067 = lang.IFn_Cast(root_3065) } else { ifn_3067 = nil }; var arg_3068 any = A_arbace_c2j_node_A_const_487; var arg_3069 any = A_arbace_c2j_node_A_const_488; if linked_3066 == nil { tmp20 = ifn_3067.Invoke_O_O__O(arg_3068, arg_3069) } else { tmp20 = linked_3066.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3065, arg_3068, arg_3069) }; arg_3058 = lang.Tuple_Create_O_O__IPersistentVector(tmp19, tmp20); var arg_3059 any = A_arbace_c2j_node_A_const_489; if linked_3056 == nil { tmp17 = ifn_3057.Invoke_O_O__O(arg_3058, arg_3059) } else { tmp17 = linked_3056.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3055, arg_3058, arg_3059) }; var tmp21 any = /*line :590:1*/tmp13.Invoke_O_O_O_O__O(tmp14, tmp16, tmp17, lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node_A_const_490), clauses__5, A_arbace_c2j_node_A_const_491)); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp23 any = A_arbace_c2j_node_A_const_492; var tmp24 any; var root_3076 any = A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3077 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3076, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3078 lang.IFn; if











	linked_3077 == nil { ifn_3078 = lang.IFn_Cast(root_3076) } else { ifn_3078 = nil }; var arg_3079 any = A_arbace_c2j_node_A_const_493; var arg_3080 any = A_arbace_c2j_node_A_const_494; if linked_3077 == nil { tmp24 = ifn_3078.Invoke_O_O__O(arg_3079, arg_3080) } else { tmp24 = linked_3077.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3076, arg_3079, arg_3080) }; var tmp25 any = tmp24; var tmp26 any; var root_3081 any = /*line :590:1*/A_arbace_c2j_node_A_const_37.GetRawRoot__O(); var linked_3082 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3081, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_3083 lang.IFn; if












	linked_3082 == nil { ifn_3083 = lang.IFn_Cast(root_3081) } else { ifn_3083 = nil }; var arg_3084 any = lang.PersistentVector_EMPTY.Ref(); var arg_3085 any = A_arbace_c2j_node_A_const_495; if linked_3082 == nil { tmp26 = ifn_3083.Invoke_O_O__O(arg_3084, arg_3085) } else { tmp26 = linked_3082.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_3081, arg_3084, arg_3085) }; var tmp27 any = tmp26; var tmp28 lang.IFn = /*line :590:1*/lang.IFn_Cast(A_arbace_c2j_node_A_const_28.GetRawRoot__O()); var tmp29 any = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_496, A_arbace_c2j_node_A_const_497); var tmp30 any; var root_3092 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_3093 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3092, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_3094 lang.IFn; if














	linked_3093 == nil { ifn_3094 = lang.IFn_Cast(root_3092) } else { ifn_3094 = nil }; var arg_3095 any; var fnbody__3098 any = A_arbace_c2j_node_code_forms_fn__400000516_A_New(); var tmp31 *jrt.Class; var fncls__3097 *jrt.Class = A_arbace_c2j_node_code_forms_fn__400000516_A_fn_class; if fncls__3097 == nil { var fncls__3097d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_c2j_node_code_forms_fn__400000516_A_fn_class = fncls__3097d; tmp31 = fncls__3097d } else { tmp31 = fncls__3097 }; arg_3095 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3098, tmp31, nil); var arg_3096 any = table__6; if linked_3093 == nil { tmp30 = ifn_3094.Invoke_O_O__O(arg_3095, arg_3096) } else { tmp30 = linked_3093.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_3092, arg_3095, arg_3096) }; arg_2849 = /*line :590:1*/lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(Lit_18, tmp9.Invoke_O_O_O_O__O(tmp10, tmp12, tmp21, tmp22.Invoke_O_O_O_O__O(tmp23, tmp25, tmp27, tmp28.Invoke_O_O_O__O(tmp29, tmp30, A_arbace_c2j_node_A_const_501))))); if linked_2846 == nil { return ifn_2847.Invoke_O_O__O(arg_2848, arg_2849) } else { return linked_2846.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2845, arg_2848, arg_2849) } }
//line :580:1
func A_arbace_c2j_node_code_forms_iter__400000423__400000427_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000423__400000427_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000423__400000427_A{}; t.Ctor_O_O(p0, p1); return t }
//line :580:1
func (t *A_arbace_c2j_node_code_forms_iter__400000423__400000427_A) Ctor_O_O(c__helpers, c__domains any) { t.F_helpers = c__helpers; t.F_domains = c__domains }
//line :580:1
func (t *A_arbace_c2j_node_code_forms_iter__400000423__400000427_A) Invoke_O_O__O(self, s__400000424__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2630 any = A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_A_New_O_O_O_O(self, t.F_helpers, s__400000424__1, t.F_domains); var tmp2 *jrt.Class; var fncls__2629 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_A_fn_class; if fncls__2629 == nil { var fncls__2629d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, fnbody__2630); A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_A_fn_class = fncls__2629d; tmp2 = fncls__2629d } else { tmp2 = fncls__2629 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2630, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :580:1
func A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :580:1
func (t *A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_A) Ctor_O_O_O_O(c__iter__400000423, c__helpers, c__s__400000424, c__domains any) { t.F_iter__400000423 = c__iter__400000423; t.F_helpers = c__helpers; t.F_s__400000424 = c__s__400000424; t.F_domains = c__domains }
//line :580:1
func (t *A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_A) Invoke_O__O(self any) any { { var s__400000424__1 any; var t_ any = t.F_s__400000424; t.F_s__400000424 = nil; s__400000424__1 = t_; for { var temp__1927000414__auto____2 any; var root_2525 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2525, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2527 lang.IFn; if linked_2526 == nil { ifn_2527 = lang.IFn_Cast(root_2525) } else { ifn_2527 = nil }; var arg_2528 any = s__400000424__1; if linked_2526 == nil { temp__1927000414__auto____2 = ifn_2527.Invoke_O__O(arg_2528) } else { temp__1927000414__auto____2 = linked_2526.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2525, arg_2528) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000424__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2529 any = A_arbace_c2j_node_A_const_400.GetRawRoot__O(); var linked_2530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2529, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2531 lang.IFn; if linked_2530 == nil { ifn_2531 = lang.IFn_Cast(root_2529) } else { ifn_2531 = nil }; var arg_2532 any = s__400000424__3; if linked_2530 == nil { tmp1 = ifn_2531.Invoke_O__O(arg_2532) } else { tmp1 = linked_2530.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2529, arg_2532) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2533 any = A_arbace_c2j_node_A_const_401.GetRawRoot__O(); var linked_2534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2533, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2535 lang.IFn; if linked_2534 == nil { ifn_2535 = lang.IFn_Cast(root_2533) } else { ifn_2535 = nil }; var arg_2536 any = s__400000424__3; if linked_2534 == nil { c__1927001037__auto____4 = ifn_2535.Invoke_O__O(arg_2536) } else { c__1927001037__auto____4 = linked_2534.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2533, arg_2536) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000426__6 any; var root_2537 any = A_arbace_c2j_node_A_const_402.GetRawRoot__O(); var linked_2538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2537, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2539 lang.IFn; if linked_2538 == nil { ifn_2539 = lang.IFn_Cast(root_2537) } else { ifn_2539 = nil }; var arg_2540 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2538 == nil { b__400000426__6 = ifn_2539.Invoke_O__O(arg_2540) } else { b__400000426__6 = linked_2538.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2537, arg_2540) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2570 any = A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_A_New_O_O_O_I_O(t.F_helpers, t.F_domains, b__400000426__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2569 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_A_fn_class; if fncls__2569 == nil { var fncls__2569d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, fnbody__2570); A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_A_fn_class = fncls__2569d; tmp3 = fncls__2569d } else { tmp3 = fncls__2569 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2570, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2571 any = A_arbace_c2j_node_A_const_404.GetRawRoot__O(); var linked_2572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2571, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2573 lang.IFn; if linked_2572 == nil { ifn_2573 = lang.IFn_Cast(root_2571) } else { ifn_2573 = nil }; var arg_2574 any; var root_2576 any = A_arbace_c2j_node_A_const_405.GetRawRoot__O(); var linked_2577 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2576, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2578 lang.IFn; if linked_2577 == nil { ifn_2578 = lang.IFn_Cast(root_2576) } else { ifn_2578 = nil }; var arg_2579 any = b__400000426__6; if linked_2577 == nil { arg_2574 = ifn_2578.Invoke_O__O(arg_2579) } else { arg_2574 = linked_2577.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2576, arg_2579) }; var arg_2575 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000423); var tmp5 any; var root_2580 any = A_arbace_c2j_node_A_const_406.GetRawRoot__O(); var linked_2581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2580, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2582 lang.IFn; if linked_2581 == nil { ifn_2582 = lang.IFn_Cast(root_2580) } else { ifn_2582 = nil }; var arg_2583 any = s__400000424__3; if linked_2581 == nil { tmp5 = ifn_2582.Invoke_O__O(arg_2583) } else { tmp5 = linked_2581.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2580, arg_2583) }; arg_2575 = tmp4.Invoke_O__O(tmp5); if linked_2572 == nil { return ifn_2573.Invoke_O_O__O(arg_2574, arg_2575) } else { return linked_2572.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2571, arg_2574, arg_2575) } } else { var root_2584 any = A_arbace_c2j_node_A_const_404.GetRawRoot__O(); var linked_2585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2584, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2586 lang.IFn; if linked_2585 == nil { ifn_2586 = lang.IFn_Cast(root_2584) } else { ifn_2586 = nil }; var arg_2587 any; var root_2589 any = A_arbace_c2j_node_A_const_405.GetRawRoot__O(); var linked_2590 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2589, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2591 lang.IFn; if linked_2590 == nil { ifn_2591 = lang.IFn_Cast(root_2589) } else { ifn_2591 = nil }; var arg_2592 any = b__400000426__6; if linked_2590 == nil { arg_2587 = ifn_2591.Invoke_O__O(arg_2592) } else { arg_2587 = linked_2590.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2589, arg_2592) }; var arg_2588 any; if linked_2585 == nil { return ifn_2586.Invoke_O_O__O(arg_2587, arg_2588) } else { return linked_2585.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2584, arg_2587, arg_2588) } } } else { var d__4 any; var root_2593 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2593, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2595 lang.IFn; if linked_2594 == nil { ifn_2595 = lang.IFn_Cast(root_2593) } else { ifn_2595 = nil }; var arg_2596 any = s__400000424__3; if linked_2594 == nil { d__4 = ifn_2595.Invoke_O__O(arg_2596) } else { d__4 = linked_2594.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2593, arg_2596) }; var root_2597 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2597, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2599 lang.IFn; if linked_2598 == nil { ifn_2599 = lang.IFn_Cast(root_2597) } else { ifn_2599 = nil }; var arg_2600 any; var tmp6 any = A_arbace_c2j_node_A_const_109; var tmp7 any = A_arbace_c2j_node_A_const_471; var tmp8 any; var root_2602 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_2603 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2602, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2604 lang.IFn
														if linked_2603 == nil { ifn_2604 = lang.IFn_Cast(root_2602) } else { ifn_2604 = nil }; var arg_2605 any; var fnbody__2619 any = A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000436_A_New_O_O(d__4, t.F_helpers); var tmp9 *jrt.Class; var fncls__2618 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000436_A_fn_class; if fncls__2618 == nil { var fncls__2618d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, fnbody__2619); A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000436_A_fn_class = fncls__2618d; tmp9 = fncls__2618d } else { tmp9 = fncls__2618 }; arg_2605 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2619, tmp9, nil); var arg_2606 any; var root_2620 any = A_arbace_c2j_node_A_const_474.GetRawRoot__O(); var linked_2621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2620, A_arbace_c2j_node_variants_A_fn_class); var ifn_2622 lang.IFn


	if linked_2621 == nil { ifn_2622 = lang.IFn_Cast(root_2620) } else { ifn_2622 = nil }; var arg_2623 any = d__4; var arg_2624 any = t.F_domains; if linked_2621 == nil { arg_2606 = ifn_2622.Invoke_O_O__O(arg_2623, arg_2624) } else { arg_2606 = linked_2621.(*A_arbace_c2j_node_variants_A).Invoke_O_O_O__O(root_2620, arg_2623, arg_2624) }
//line :581:1
	if linked_2603 == nil { tmp8 = ifn_2604.Invoke_O_O__O(arg_2605, arg_2606) } else { tmp8 = linked_2603.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2602, arg_2605, arg_2606) }
//line :580:1
	arg_2600 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, d__4, tmp7, tmp8)); var arg_2601 any; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__400000423); var tmp11 any; var root_2625 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2626 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2625, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2627 lang.IFn; if linked_2626 == nil { ifn_2627 = lang.IFn_Cast(root_2625) } else { ifn_2627 = nil }; var arg_2628 any = s__400000424__3; if linked_2626 == nil { tmp11 = ifn_2627.Invoke_O__O(arg_2628) } else { tmp11 = linked_2626.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2625, arg_2628) }; arg_2601 = tmp10.Invoke_O__O(tmp11); if linked_2598 == nil { return ifn_2599.Invoke_O_O__O(arg_2600, arg_2601) } else { return linked_2598.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2597, arg_2600, arg_2601) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :580:1
func A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :580:1
func (t *A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_A) Ctor_O_O_O_I_O(c__helpers, c__domains, c__b__400000426 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_helpers = c__helpers; t.F_domains = c__domains; t.F_b__400000426 = c__b__400000426; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :580:1
func (t *A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_A) Invoke_O__O(self any) any { { var i__400000425__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000425__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var d__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000425__1)); var root_2541 any = A_arbace_c2j_node_A_const_403.GetRawRoot__O(); var linked_2542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2541, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2543 lang.IFn; if linked_2542 == nil { ifn_2543 = lang.IFn_Cast(root_2541) } else { ifn_2543 = nil }; var arg_2544 any = t.F_b__400000426; var arg_2545 any; var tmp2 any = A_arbace_c2j_node_A_const_109; var tmp3 any = A_arbace_c2j_node_A_const_471; var tmp4 any; var root_2546 any = A_arbace_c2j_node_A_const_18.GetRawRoot__O(); var linked_2547 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2546, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_2548 lang.IFn
																if linked_2547 == nil { ifn_2548 = lang.IFn_Cast(root_2546) } else { ifn_2548 = nil }; var arg_2549 any; var fnbody__2563 any = A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_fn__400000430_A_New_O_O(d__2, t.F_helpers); var tmp5 *jrt.Class; var fncls__2562 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_fn__400000430_A_fn_class; if fncls__2562 == nil { var fncls__2562d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__2563); A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_fn__400000430_A_fn_class = fncls__2562d; tmp5 = fncls__2562d } else { tmp5 = fncls__2562 }; arg_2549 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2563, tmp5, nil); var arg_2550 any; var root_2564 any = A_arbace_c2j_node_A_const_474.GetRawRoot__O(); var linked_2565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2564, A_arbace_c2j_node_variants_A_fn_class); var ifn_2566 lang.IFn


	if linked_2565 == nil { ifn_2566 = lang.IFn_Cast(root_2564) } else { ifn_2566 = nil }; var arg_2567 any = d__2; var arg_2568 any = t.F_domains; if linked_2565 == nil { arg_2550 = ifn_2566.Invoke_O_O__O(arg_2567, arg_2568) } else { arg_2550 = linked_2565.(*A_arbace_c2j_node_variants_A).Invoke_O_O_O__O(root_2564, arg_2567, arg_2568) }
//line :581:1
	if linked_2547 == nil { tmp4 = ifn_2548.Invoke_O_O__O(arg_2549, arg_2550) } else { tmp4 = linked_2547.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_2546, arg_2549, arg_2550) }
//line :580:1
	arg_2545 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, d__2, tmp3, tmp4)); if linked_2542 == nil { ifn_2543.Invoke_O_O__O(arg_2544, arg_2545) } else { linked_2542.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2541, arg_2544, arg_2545) }; i__400000425__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000425__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_fn__400000430_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_fn__400000430_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_fn__400000430_A{}; t.Ctor_O_O(p0, p1); return t }
//line :581:1
func (t *A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_fn__400000430_A) Ctor_O_O(c__d, c__helpers any) { t.F_d = c__d; t.F_helpers = c__helpers }
//line :581:1
func (t *A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_fn__400000430_A) Invoke_O_O__O(self, v__1 any) any { var v__2 any; var root_2551 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_2552 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2551, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2553 lang.IFn; if linked_2552 == nil { ifn_2553 = lang.IFn_Cast(root_2551) } else { ifn_2553 = nil }; var arg_2554 any = v__1; var arg_2555 any = A_arbace_c2j_node_A_const_260; var arg_2556 any = t.F_helpers; if linked_2552 == nil { v__2 = ifn_2553.Invoke_O_O_O__O(arg_2554, arg_2555, arg_2556) } else { v__2 = linked_2552.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2551, arg_2554, arg_2555, arg_2556) }; var vec__400000431__3 any; var root_2557 any = A_arbace_c2j_node_A_const_472.GetRawRoot__O(); var linked_2558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2557, A_arbace_c2j_node_variant_class_A_fn_class); var ifn_2559 lang.IFn; if
																		linked_2558 == nil { ifn_2559 = lang.IFn_Cast(root_2557) } else { ifn_2559 = nil }; var arg_2560 any = t.F_d; var arg_2561 any = v__2; if linked_2558 == nil { vec__400000431__3 = ifn_2559.Invoke_O_O__O(arg_2560, arg_2561) } else { vec__400000431__3 = linked_2558.(*A_arbace_c2j_node_variant_class_A).Invoke_O_O_O__O(root_2557, arg_2560, arg_2561) }; var cf__4 any = /*line :581:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__400000431__3, lang.RT_IntCast_J__I_NoInit(0), nil); var fields__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000431__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_56, v__2, A_arbace_c2j_node_A_const_473, cf__4, A_arbace_c2j_node_A_const_31, fields__5)) }
//line :581:1
func A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000436_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000436_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000436_A{}; t.Ctor_O_O(p0, p1); return t }
//line :581:1
func (t *A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000436_A) Ctor_O_O(c__d, c__helpers any) { t.F_d = c__d; t.F_helpers = c__helpers }
//line :581:1
func (t *A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000436_A) Invoke_O_O__O(self, v__1 any) any { var v__2 any; var root_2607 any = A_arbace_c2j_node_A_const_14.GetRawRoot__O(); var linked_2608 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2607, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2609 lang.IFn; if linked_2608 == nil { ifn_2609 = lang.IFn_Cast(root_2607) } else { ifn_2609 = nil }; var arg_2610 any = v__1; var arg_2611 any = A_arbace_c2j_node_A_const_260; var arg_2612 any = t.F_helpers; if linked_2608 == nil { v__2 = ifn_2609.Invoke_O_O_O__O(arg_2610, arg_2611, arg_2612) } else { v__2 = linked_2608.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2607, arg_2610, arg_2611, arg_2612) }; var vec__400000437__3 any; var root_2613 any = A_arbace_c2j_node_A_const_472.GetRawRoot__O(); var linked_2614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2613, A_arbace_c2j_node_variant_class_A_fn_class); var ifn_2615 lang.IFn; if
																	linked_2614 == nil { ifn_2615 = lang.IFn_Cast(root_2613) } else { ifn_2615 = nil }; var arg_2616 any = t.F_d; var arg_2617 any = v__2; if linked_2614 == nil { vec__400000437__3 = ifn_2615.Invoke_O_O__O(arg_2616, arg_2617) } else { vec__400000437__3 = linked_2614.(*A_arbace_c2j_node_variant_class_A).Invoke_O_O_O__O(root_2613, arg_2616, arg_2617) }; var cf__4 any = /*line :581:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__400000437__3, lang.RT_IntCast_J__I_NoInit(0), nil); var fields__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000437__3, lang.RT_IntCast_J__I_NoInit(1), nil); return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_56, v__2, A_arbace_c2j_node_A_const_473, cf__4, A_arbace_c2j_node_A_const_31, fields__5)) }



func A_arbace_c2j_node_code_forms_fn__400000444_A_New() *A_arbace_c2j_node_code_forms_fn__400000444_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_fn__400000444_A{}; t.Ctor(); return t }
//line :585:1
func (t *A_arbace_c2j_node_code_forms_fn__400000444_A) Ctor() {}
//line :585:1
func (t *A_arbace_c2j_node_code_forms_fn__400000444_A) Invoke_O_O__O(self, p__400000443__1 any) any { var map__400000445__2 any = p__400000443__1; var map__400000445__3 any; if lang.ISeq_InstanceOf(map__400000445__2) { var tmp1 any; var root_2638 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2638, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2640 lang.IFn; if linked_2639 == nil { ifn_2640 = lang.IFn_Cast(root_2638) } else { ifn_2640 = nil }; var arg_2641 any = map__400000445__2; if linked_2639 == nil { tmp1 = ifn_2640.Invoke_O__O(arg_2641) } else { tmp1 = linked_2639.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2638, arg_2641) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2642 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_2643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2642, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2644 lang.IFn; if linked_2643 == nil { ifn_2644 = lang.IFn_Cast(root_2642) } else { ifn_2644 = nil }; var arg_2645 any = map__400000445__2; if linked_2643 == nil { tmp2 = ifn_2644.Invoke_O__O(arg_2645) } else { tmp2 = linked_2643.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2642, arg_2645) }; map__400000445__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2646 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2646, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2648 lang.IFn; if linked_2647 == nil { ifn_2648 = lang.IFn_Cast(root_2646) } else { ifn_2648 = nil }; var arg_2649 any = map__400000445__2; if linked_2647 == nil { tmp3 = ifn_2648.Invoke_O__O(arg_2649) } else { tmp3 = linked_2647.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2646, arg_2649) }; if jrt.J2g_Truth(tmp3) { var root_2650 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2650, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2652 lang.IFn; if linked_2651 == nil { ifn_2652 = lang.IFn_Cast(root_2650) } else { ifn_2652 = nil }; var arg_2653 any = map__400000445__2; if linked_2651 == nil { map__400000445__3 = ifn_2652.Invoke_O__O(arg_2653) } else { map__400000445__3 = linked_2651.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2650, arg_2653) } } else { map__400000445__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000445__3 = map__400000445__2 }; var d__4 any = lang.RT_Get_O_O__O_NoInit(map__400000445__3, A_arbace_c2j_node_A_const_109); var vs__5 any = lang.RT_Get_O_O__O_NoInit(map__400000445__3, A_arbace_c2j_node_A_const_471); var tmp4 any; var root_2654 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2654, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2656 lang.IFn; if linked_2655 == nil { ifn_2656 = lang.IFn_Cast(root_2654) } else { ifn_2656 = nil }; var tmp5 *lang.Keyword = A_arbace_c2j_node_A_const_416; var arg_2657 any = tmp5.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__4)); if linked_2655 == nil { tmp4 = ifn_2656.Invoke_O__O(arg_2657) } else { tmp4 = linked_2655.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2654, arg_2657) }; if jrt.J2g_Truth(tmp4) { var root_2658 any = A_arbace_c2j_node_A_const_475.GetRawRoot__O(); var linked_2659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2658, A_arbace_c2j_node_clause_A_fn_class); var ifn_2660 lang.IFn; if linked_2659 == nil { ifn_2660 = lang.IFn_Cast(root_2658) } else { ifn_2660 = nil }; var arg_2661 any = d__4; var arg_2662 any; var root_2663 any = A_arbace_c2j_node_A_const_40.GetRawRoot__O(); var linked_2664 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2663, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2665 lang.IFn; if linked_2664 == nil { ifn_2665 = lang.IFn_Cast(root_2663) } else { ifn_2665 = nil }; var arg_2666 any; var root_2668 any = A_arbace_c2j_node_A_const_476.GetRawRoot__O(); var linked_2669 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2668, aot_arbace_core.A_arbace_core_juxt_A_fn_class); var ifn_2670 lang.IFn; if linked_2669 == nil { ifn_2670 = lang.IFn_Cast(root_2668) } else { ifn_2670 = nil }; var arg_2671 any = A_arbace_c2j_node_A_const_56; var arg_2672 any = A_arbace_c2j_node_A_const_31; if linked_2669 == nil { arg_2666 = ifn_2670.Invoke_O_O__O(arg_2671, arg_2672) } else { arg_2666 = linked_2669.(*aot_arbace_core.A_arbace_core_juxt_A).Invoke_O_O_O__O(root_2668, arg_2671, arg_2672) }; var arg_2667 any = vs__5; if linked_2664 == nil { arg_2662 = ifn_2665.Invoke_O_O__O(arg_2666, arg_2667) } else { arg_2662 = linked_2664.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2663, arg_2666, arg_2667) }; if linked_2659 == nil { return ifn_2660.Invoke_O_O__O(arg_2661, arg_2662) } else { return linked_2659.(*A_arbace_c2j_node_clause_A).Invoke_O_O_O__O(root_2658, arg_2661, arg_2662) } } else { return nil } }
func A_arbace_c2j_node_code_forms_iter__400000448__400000456_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000448__400000456_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000448__400000456_A{}; t.Ctor_O_O(p0, p1); return t }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_A) Ctor_O_O(c__domains, c__keys any) { t.F_domains = c__domains; t.F_keys = c__keys }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_A) Invoke_O_O__O(self, s__400000449__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2842 any = A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_A_New_O_O_O_O(self, s__400000449__1, t.F_domains, t.F_keys); var tmp2 *jrt.Class; var fncls__2841 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_A_fn_class; if fncls__2841 == nil { var fncls__2841d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__2842); A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_A_fn_class = fncls__2841d; tmp2 = fncls__2841d } else { tmp2 = fncls__2841 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2842, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :586:1
func A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_A) Ctor_O_O_O_O(c__iter__400000448, c__s__400000449, c__domains, c__keys any) { t.F_iter__400000448 = c__iter__400000448; t.F_s__400000449 = c__s__400000449; t.F_domains = c__domains; t.F_keys = c__keys }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_A) Invoke_O__O(self any) any { { var s__400000449__1 any; var t_ any = t.F_s__400000449; t.F_s__400000449 = nil; s__400000449__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2675 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2675, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2677 lang.IFn; if linked_2676 == nil { ifn_2677 = lang.IFn_Cast(root_2675) } else { ifn_2677 = nil }; var arg_2678 any = s__400000449__1; if linked_2676 == nil { temp__1927000414__auto____2 = ifn_2677.Invoke_O__O(arg_2678) } else { temp__1927000414__auto____2 = linked_2676.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2675, arg_2678) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__400000458__4 any; var root_2679 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2679, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2681 lang.IFn; if linked_2680 == nil { ifn_2681 = lang.IFn_Cast(root_2679) } else { ifn_2681 = nil }; var arg_2682 any = xs__1927001018__auto____3; if linked_2680 == nil { map__400000458__4 = ifn_2681.Invoke_O__O(arg_2682) } else { map__400000458__4 = linked_2680.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2679, arg_2682) }; var map__400000458__5 any; if lang.ISeq_InstanceOf(map__400000458__4) { var tmp1 any; var root_2683 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2683, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2685 lang.IFn; if linked_2684 == nil { ifn_2685 = lang.IFn_Cast(root_2683) } else { ifn_2685 = nil }; var arg_2686 any = map__400000458__4; if linked_2684 == nil { tmp1 = ifn_2685.Invoke_O__O(arg_2686) } else { tmp1 = linked_2684.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2683, arg_2686) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2687 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_2688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2687, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2689 lang.IFn; if linked_2688 == nil { ifn_2689 = lang.IFn_Cast(root_2687) } else { ifn_2689 = nil }; var arg_2690 any = map__400000458__4; if linked_2688 == nil { tmp2 = ifn_2689.Invoke_O__O(arg_2690) } else { tmp2 = linked_2688.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2687, arg_2690) }; map__400000458__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2691 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2691, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2693 lang.IFn; if linked_2692 == nil { ifn_2693 = lang.IFn_Cast(root_2691) } else { ifn_2693 = nil }; var arg_2694 any = map__400000458__4; if linked_2692 == nil { tmp3 = ifn_2693.Invoke_O__O(arg_2694) } else { tmp3 = linked_2692.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2691, arg_2694) }; if jrt.J2g_Truth(tmp3) { var root_2695 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2695, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2697 lang.IFn; if linked_2696 == nil { ifn_2697 = lang.IFn_Cast(root_2695) } else { ifn_2697 = nil }; var arg_2698 any = map__400000458__4; if linked_2696 == nil { map__400000458__5 = ifn_2697.Invoke_O__O(arg_2698) } else { map__400000458__5 = linked_2696.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2695, arg_2698) } } else { map__400000458__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000458__5 = map__400000458__4 }; var d__6 any = lang.RT_Get_O_O__O_NoInit(map__400000458__5, A_arbace_c2j_node_A_const_109); var tmp4 *lang.Keyword = A_arbace_c2j_node_A_const_408; if jrt.J2g_Truth(tmp4.Invoke_O__O(A_arbace_c2j_node_A_const_16.Invoke_O__O(d__6))) { var iterys__1927001035__auto____7 any; var fnbody__2814 any = A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_A_New_O_O(t.F_keys, d__6); var tmp5 *jrt.Class; var fncls__2813 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_A_fn_class; if fncls__2813 == nil { var fncls__2813d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, fnbody__2814); A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_A_fn_class = fncls__2813d; tmp5 = fncls__2813d } else { tmp5 = fncls__2813 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2814, tmp5, nil); var fs__1927001036__auto____8 any; var root_2815 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2815, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2817 lang.IFn; if linked_2816 == nil { ifn_2817 = lang.IFn_Cast(root_2815) } else { ifn_2817 = nil }; var arg_2818 any; var tmp6 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp7 any; var root_2819 any = A_arbace_c2j_node_A_const_434.GetRawRoot__O(); var linked_2820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2819, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_2821 lang.IFn
														if linked_2820 == nil { ifn_2821 = lang.IFn_Cast(root_2819) } else { ifn_2821 = nil }; var arg_2822 any = A_arbace_c2j_node_A_const_435.GetRawRoot__O(); var tmp8 lang.IFn = lang.IFn_Cast(t.F_domains); var arg_2823 any = tmp8.Invoke_O__O(A_arbace_c2j_node_A_const_13.Invoke_O__O(d__6)); if linked_2820 == nil { tmp7 = ifn_2821.Invoke_O_O__O(arg_2822, arg_2823) } else { tmp7 = linked_2820.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_2819, arg_2822, arg_2823) }
//line :586:1
	arg_2818 = tmp6.Invoke_O__O(tmp7); if linked_2816 == nil { fs__1927001036__auto____8 = ifn_2817.Invoke_O__O(arg_2818) } else { fs__1927001036__auto____8 = linked_2816.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2815, arg_2818) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2824 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2825 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2824, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2826 lang.IFn; if linked_2825 == nil { ifn_2826 = lang.IFn_Cast(root_2824) } else { ifn_2826 = nil }; var arg_2827 any = fs__1927001036__auto____8; var arg_2828 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__400000448); var tmp10 any; var root_2829 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2829, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2831 lang.IFn; if linked_2830 == nil { ifn_2831 = lang.IFn_Cast(root_2829) } else { ifn_2831 = nil }; var arg_2832 any = s__400000449__1; if linked_2830 == nil { tmp10 = ifn_2831.Invoke_O__O(arg_2832) } else { tmp10 = linked_2830.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2829, arg_2832) }; arg_2828 = tmp9.Invoke_O__O(tmp10); if linked_2825 == nil { return ifn_2826.Invoke_O_O__O(arg_2827, arg_2828) } else { return linked_2825.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2824, arg_2827, arg_2828) } } else { var tmp11 any; var root_2833 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2833, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2835 lang.IFn; if linked_2834 == nil { ifn_2835 = lang.IFn_Cast(root_2833) } else { ifn_2835 = nil }; var arg_2836 any = s__400000449__1; if linked_2834 == nil { tmp11 = ifn_2835.Invoke_O__O(arg_2836) } else { tmp11 = linked_2834.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2833, arg_2836) }; s__400000449__1 = tmp11; continue L1 } } else { var tmp12 any; var root_2837 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2837, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2839 lang.IFn; if linked_2838 == nil { ifn_2839 = lang.IFn_Cast(root_2837) } else { ifn_2839 = nil }; var arg_2840 any = s__400000449__1; if linked_2838 == nil { tmp12 = ifn_2839.Invoke_O__O(arg_2840) } else { tmp12 = linked_2838.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2837, arg_2840) }; s__400000449__1 = tmp12; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :586:1
func A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_A{}; t.Ctor_O_O(p0, p1); return t }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_A) Ctor_O_O(c__keys, c__d any) { t.F_keys = c__keys; t.F_d = c__d }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_A) Invoke_O_O__O(self, s__400000451__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2812 any = A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_A_New_O_O_O_O(s__400000451__1, t.F_keys, self, t.F_d); var tmp2 *jrt.Class; var fncls__2811 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_A_fn_class; if fncls__2811 == nil { var fncls__2811d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__2812); A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_A_fn_class = fncls__2811d; tmp2 = fncls__2811d } else { tmp2 = fncls__2811 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2812, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :586:1
func A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_A) Ctor_O_O_O_O(c__s__400000451, c__keys, c__iter__400000450, c__d any) { t.F_s__400000451 = c__s__400000451; t.F_keys = c__keys; t.F_iter__400000450 = c__iter__400000450; t.F_d = c__d }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_A) Invoke_O__O(self any) any { { var s__400000451__1 any; var t_ any = t.F_s__400000451; t.F_s__400000451 = nil; s__400000451__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2699 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2699, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2701 lang.IFn; if linked_2700 == nil { ifn_2701 = lang.IFn_Cast(root_2699) } else { ifn_2701 = nil }; var arg_2702 any = s__400000451__1; if linked_2700 == nil { temp__1927000414__auto____2 = ifn_2701.Invoke_O__O(arg_2702) } else { temp__1927000414__auto____2 = linked_2700.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2699, arg_2702) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__400000462__4 any; var root_2703 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2703, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2705 lang.IFn; if linked_2704 == nil { ifn_2705 = lang.IFn_Cast(root_2703) } else { ifn_2705 = nil }; var arg_2706 any = xs__1927001018__auto____3; if linked_2704 == nil { vec__400000462__4 = ifn_2705.Invoke_O__O(arg_2706) } else { vec__400000462__4 = linked_2704.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2703, arg_2706) }; var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000462__4, lang.RT_IntCast_J__I_NoInit(0), nil); var ms__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000462__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var fnbody__2788 any = A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_A_New_O_O_O(k__5, t.F_keys, t.F_d); var tmp1 *jrt.Class; var fncls__2787 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_A_fn_class; if fncls__2787 == nil { var fncls__2787d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, fnbody__2788); A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_A_fn_class = fncls__2787d; tmp1 = fncls__2787d } else { tmp1 = fncls__2787 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2788, tmp1, nil); var fs__1927001036__auto____8 any; var root_2789 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2790 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2789, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2791 lang.IFn; if linked_2790 == nil { ifn_2791 = lang.IFn_Cast(root_2789) } else { ifn_2791 = nil }; var arg_2792 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____7); var tmp3 any; var root_2793 any = A_arbace_c2j_node_A_const_290.GetRawRoot__O(); var linked_2794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2793, aot_arbace_core.A_arbace_core_map_indexed_A_fn_class); var ifn_2795 lang.IFn

	if linked_2794 == nil { ifn_2795 = lang.IFn_Cast(root_2793) } else { ifn_2795 = nil }; var arg_2796 any = A_arbace_c2j_node_A_const_414.GetRawRoot__O(); var arg_2797 any = ms__6; if linked_2794 == nil { tmp3 = ifn_2795.Invoke_O_O__O(arg_2796, arg_2797) } else { tmp3 = linked_2794.(*aot_arbace_core.A_arbace_core_map_indexed_A).Invoke_O_O_O__O(root_2793, arg_2796, arg_2797) }
//line :586:1
	arg_2792 = tmp2.Invoke_O__O(tmp3); if linked_2790 == nil { fs__1927001036__auto____8 = ifn_2791.Invoke_O__O(arg_2792) } else { fs__1927001036__auto____8 = linked_2790.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2789, arg_2792) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_2798 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_2799 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2798, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2800 lang.IFn; if linked_2799 == nil { ifn_2800 = lang.IFn_Cast(root_2798) } else { ifn_2800 = nil }; var arg_2801 any = fs__1927001036__auto____8; var arg_2802 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000450); var tmp5 any; var root_2803 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2803, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2805 lang.IFn; if linked_2804 == nil { ifn_2805 = lang.IFn_Cast(root_2803) } else { ifn_2805 = nil }; var arg_2806 any = s__400000451__1; if linked_2804 == nil { tmp5 = ifn_2805.Invoke_O__O(arg_2806) } else { tmp5 = linked_2804.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2803, arg_2806) }; arg_2802 = tmp4.Invoke_O__O(tmp5); if linked_2799 == nil { return ifn_2800.Invoke_O_O__O(arg_2801, arg_2802) } else { return linked_2799.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2798, arg_2801, arg_2802) } } else { var tmp6 any; var root_2807 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2808 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2807, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2809 lang.IFn; if linked_2808 == nil { ifn_2809 = lang.IFn_Cast(root_2807) } else { ifn_2809 = nil }; var arg_2810 any = s__400000451__1; if linked_2808 == nil { tmp6 = ifn_2809.Invoke_O__O(arg_2810) } else { tmp6 = linked_2808.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2807, arg_2810) }; s__400000451__1 = tmp6; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :586:1
func A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_A) Ctor_O_O_O(c__k, c__keys, c__d any) { t.F_k = c__k; t.F_keys = c__keys; t.F_d = c__d }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_A) Invoke_O_O__O(self, s__400000453__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2786 any = A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_A_New_O_O_O_O_O(s__400000453__1, t.F_k, t.F_keys, self, t.F_d); var tmp2 *jrt.Class; var fncls__2785 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_A_fn_class; if fncls__2785 == nil { var fncls__2785d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, fnbody__2786); A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_A_fn_class = fncls__2785d; tmp2 = fncls__2785d } else { tmp2 = fncls__2785 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2786, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :586:1
func A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_A) Ctor_O_O_O_O_O(c__s__400000453, c__k, c__keys, c__iter__400000452, c__d any) { t.F_s__400000453 = c__s__400000453; t.F_k = c__k; t.F_keys = c__keys; t.F_iter__400000452 = c__iter__400000452; t.F_d = c__d }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_A) Invoke_O__O(self any) any { { var s__400000453__1 any; var t_ any = t.F_s__400000453; t.F_s__400000453 = nil; s__400000453__1 = t_; for { var temp__1927000414__auto____2 any; var root_2707 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2709 lang.IFn; if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any = s__400000453__1; if linked_2708 == nil { temp__1927000414__auto____2 = ifn_2709.Invoke_O__O(arg_2710) } else { temp__1927000414__auto____2 = linked_2708.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2707, arg_2710) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000453__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2711 any = A_arbace_c2j_node_A_const_400.GetRawRoot__O(); var linked_2712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2711, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2713 lang.IFn; if linked_2712 == nil { ifn_2713 = lang.IFn_Cast(root_2711) } else { ifn_2713 = nil }; var arg_2714 any = s__400000453__3; if linked_2712 == nil { tmp1 = ifn_2713.Invoke_O__O(arg_2714) } else { tmp1 = linked_2712.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2711, arg_2714) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2715 any = A_arbace_c2j_node_A_const_401.GetRawRoot__O(); var linked_2716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2715, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2717 lang.IFn; if linked_2716 == nil { ifn_2717 = lang.IFn_Cast(root_2715) } else { ifn_2717 = nil }; var arg_2718 any = s__400000453__3; if linked_2716 == nil { c__1927001037__auto____4 = ifn_2717.Invoke_O__O(arg_2718) } else { c__1927001037__auto____4 = linked_2716.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2715, arg_2718) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000455__6 any; var root_2719 any = A_arbace_c2j_node_A_const_402.GetRawRoot__O(); var linked_2720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2719, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2721 lang.IFn; if linked_2720 == nil { ifn_2721 = lang.IFn_Cast(root_2719) } else { ifn_2721 = nil }; var arg_2722 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2720 == nil { b__400000455__6 = ifn_2721.Invoke_O__O(arg_2722) } else { b__400000455__6 = linked_2720.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2719, arg_2722) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2739 any = A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_fn__400000467_A_New_O_O_O_I_O_O(t.F_k, b__400000455__6, t.F_keys, size__1927001038__auto____5, t.F_d, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2738 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_fn__400000467_A_fn_class; if fncls__2738 == nil { var fncls__2738d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, fnbody__2739); A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_fn__400000467_A_fn_class = fncls__2738d; tmp3 = fncls__2738d } else { tmp3 = fncls__2738 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2739, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2740 any = A_arbace_c2j_node_A_const_404.GetRawRoot__O(); var linked_2741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2740, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2742 lang.IFn; if linked_2741 == nil { ifn_2742 = lang.IFn_Cast(root_2740) } else { ifn_2742 = nil }; var arg_2743 any; var root_2745 any = A_arbace_c2j_node_A_const_405.GetRawRoot__O(); var linked_2746 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2745, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2747 lang.IFn; if linked_2746 == nil { ifn_2747 = lang.IFn_Cast(root_2745) } else { ifn_2747 = nil }; var arg_2748 any = b__400000455__6; if linked_2746 == nil { arg_2743 = ifn_2747.Invoke_O__O(arg_2748) } else { arg_2743 = linked_2746.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2745, arg_2748) }; var arg_2744 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000452); var tmp5 any; var root_2749 any = A_arbace_c2j_node_A_const_406.GetRawRoot__O(); var linked_2750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2749, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2751 lang.IFn; if linked_2750 == nil { ifn_2751 = lang.IFn_Cast(root_2749) } else { ifn_2751 = nil }; var arg_2752 any = s__400000453__3; if linked_2750 == nil { tmp5 = ifn_2751.Invoke_O__O(arg_2752) } else { tmp5 = linked_2750.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2749, arg_2752) }; arg_2744 = tmp4.Invoke_O__O(tmp5); if linked_2741 == nil { return ifn_2742.Invoke_O_O__O(arg_2743, arg_2744) } else { return linked_2741.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2740, arg_2743, arg_2744) } } else { var root_2753 any = A_arbace_c2j_node_A_const_404.GetRawRoot__O(); var linked_2754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2753, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2755 lang.IFn; if linked_2754 == nil { ifn_2755 = lang.IFn_Cast(root_2753) } else { ifn_2755 = nil }; var arg_2756 any; var root_2758 any = A_arbace_c2j_node_A_const_405.GetRawRoot__O(); var linked_2759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2758, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2760 lang.IFn; if linked_2759 == nil { ifn_2760 = lang.IFn_Cast(root_2758) } else { ifn_2760 = nil }; var arg_2761 any = b__400000455__6; if linked_2759 == nil { arg_2756 = ifn_2760.Invoke_O__O(arg_2761) } else { arg_2756 = linked_2759.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2758, arg_2761) }; var arg_2757 any; if linked_2754 == nil { return ifn_2755.Invoke_O_O__O(arg_2756, arg_2757) } else { return linked_2754.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2753, arg_2756, arg_2757) } } } else { var vec__400000472__4 any; var root_2762 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2762, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2764 lang.IFn; if linked_2763 == nil { ifn_2764 = lang.IFn_Cast(root_2762) } else { ifn_2764 = nil }; var arg_2765 any = s__400000453__3; if linked_2763 == nil { vec__400000472__4 = ifn_2764.Invoke_O__O(arg_2765) } else { vec__400000472__4 = linked_2763.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2762, arg_2765) }; var i__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000472__4, lang.RT_IntCast_J__I_NoInit(0), nil); var m__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000472__4, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2766 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2766, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2768 lang.IFn; if linked_2767 == nil { ifn_2768 = lang.IFn_Cast(root_2766) } else { ifn_2768 = nil }; var arg_2769 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_keys); var tmp7 any = lang.IFn_Cast(tmp6.Invoke_O__O(A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d))).Invoke_O__O(m__6); var tmp8 jrt.Number_I; var na_2771 any; var na_2773 any = t.F_k
																								var na_2774 int64 = 10000

	if jrt.Long_InstanceOf(na_2773) { var n0_2775 int64 = jrt.NN(jrt.Long_Cast(na_2773)).LongValue__J(); var n1_2776 int64 = na_2774; var nr_2777 int64 = n0_2775 * n1_2776; var tmp9 bool; var tmp10 bool; var tmp11 bool; var tmp12 bool; tmp12 = n0_2775 == -9223372036854775808; if tmp12 { tmp12 = n1_2776 < 0 }; tmp11 = tmp12; tmp10 = !tmp11; if tmp10 { var tmp13 bool; tmp13 = n1_2776 == 0; if !tmp13 { tmp13 = nr_2777/n1_2776 == n0_2775 }; tmp10 = tmp13 }; tmp9 = tmp10; if tmp9 { na_2771 = jrt.Long_ValueOf_J__Long_NoInit(nr_2777).Ref() } else { na_2771 = lang.Numbers_Multiply_O_J__Number_NoInit(na_2773, na_2774) } } else { na_2771 = lang.Numbers_Multiply_O_J__Number_NoInit(na_2773, na_2774) }; var na_2772 any = i__5; var tmp14 bool; var tmp15 bool; tmp15 = jrt.Long_InstanceOf(na_2771); if tmp15 { tmp15 = jrt.Long_InstanceOf(na_2772) }; tmp14 = tmp15; if tmp14 { var n0_2778 int64 = jrt.NN(jrt.Long_Cast(na_2771)).LongValue__J(); var n1_2779 int64 = jrt.NN(jrt.Long_Cast(na_2772)).LongValue__J(); var nr_2780 int64 = n0_2778 + n1_2779; if (n0_2778^nr_2780)&(n1_2779^nr_2780) >= 0 { tmp8 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2780)) } else { tmp8 = lang.Numbers_Add_O_O__Number_NoInit(na_2771, na_2772) } } else { var tmp16 bool; var tmp17 bool; tmp17 = jrt.Double_InstanceOf(na_2771); if tmp17 { tmp17 = jrt.Double_InstanceOf(na_2772) }; tmp16 = tmp17; if tmp16 { var n0_2778_2 float64 = jrt.NN(jrt.Double_Cast(na_2771)).DoubleValue__D(); var n1_2779_2 float64 = jrt.NN(jrt.Double_Cast(na_2772)).DoubleValue__D(); tmp8 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_2778_2 + n1_2779_2)) } else { tmp8 = lang.Numbers_Add_O_O__Number_NoInit(na_2771, na_2772) } }
//line :586:1
	arg_2769 = lang.Tuple_Create_O_O__IPersistentVector(tmp7, tmp8); var arg_2770 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__400000452); var tmp19 any; var root_2781 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_2782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2781, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2783 lang.IFn; if linked_2782 == nil { ifn_2783 = lang.IFn_Cast(root_2781) } else { ifn_2783 = nil }; var arg_2784 any = s__400000453__3; if linked_2782 == nil { tmp19 = ifn_2783.Invoke_O__O(arg_2784) } else { tmp19 = linked_2782.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2781, arg_2784) }; arg_2770 = tmp18.Invoke_O__O(tmp19); if linked_2767 == nil { return ifn_2768.Invoke_O_O__O(arg_2769, arg_2770) } else { return linked_2767.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2766, arg_2769, arg_2770) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :586:1
func A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_fn__400000467_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_fn__400000467_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_fn__400000467_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_fn__400000467_A) Ctor_O_O_O_I_O_O(c__k, c__b__400000455, c__keys any, c__size__1927001038__auto__ int32, c__d, c__c__1927001037__auto__ any) { t.F_k = c__k; t.F_b__400000455 = c__b__400000455; t.F_keys = c__keys; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_d = c__d; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :586:1
func (t *A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_fn__400000467_A) Invoke_O__O(self any) any { { var i__400000454__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000454__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__400000468__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000454__1)); var i__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000468__2, lang.RT_IntCast_J__I_NoInit(0), nil); var m__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000468__2, lang.RT_IntCast_J__I_NoInit(1), nil); var root_2723 any = A_arbace_c2j_node_A_const_403.GetRawRoot__O(); var linked_2724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2723, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2725 lang.IFn; if linked_2724 == nil { ifn_2725 = lang.IFn_Cast(root_2723) } else { ifn_2725 = nil }; var arg_2726 any = t.F_b__400000455; var arg_2727 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_keys); var tmp3 any = lang.IFn_Cast(tmp2.Invoke_O__O(A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d))).Invoke_O__O(m__4); var tmp4 jrt.Number_I; var na_2728 any; var na_2730 any = t.F_k
																										var na_2731 int64 = 10000

	if jrt.Long_InstanceOf(na_2730) { var n0_2732 int64 = jrt.NN(jrt.Long_Cast(na_2730)).LongValue__J(); var n1_2733 int64 = na_2731; var nr_2734 int64 = n0_2732 * n1_2733; var tmp5 bool; var tmp6 bool; var tmp7 bool; var tmp8 bool; tmp8 = n0_2732 == -9223372036854775808; if tmp8 { tmp8 = n1_2733 < 0 }; tmp7 = tmp8; tmp6 = !tmp7; if tmp6 { var tmp9 bool; tmp9 = n1_2733 == 0; if !tmp9 { tmp9 = nr_2734/n1_2733 == n0_2732 }; tmp6 = tmp9 }; tmp5 = tmp6; if tmp5 { na_2728 = jrt.Long_ValueOf_J__Long_NoInit(nr_2734).Ref() } else { na_2728 = lang.Numbers_Multiply_O_J__Number_NoInit(na_2730, na_2731) } } else { na_2728 = lang.Numbers_Multiply_O_J__Number_NoInit(na_2730, na_2731) }; var na_2729 any = i__3; var tmp10 bool; var tmp11 bool; tmp11 = jrt.Long_InstanceOf(na_2728); if tmp11 { tmp11 = jrt.Long_InstanceOf(na_2729) }; tmp10 = tmp11; if tmp10 { var n0_2735 int64 = jrt.NN(jrt.Long_Cast(na_2728)).LongValue__J(); var n1_2736 int64 = jrt.NN(jrt.Long_Cast(na_2729)).LongValue__J(); var nr_2737 int64 = n0_2735 + n1_2736; if (n0_2735^nr_2737)&(n1_2736^nr_2737) >= 0 { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_2737)) } else { tmp4 = lang.Numbers_Add_O_O__Number_NoInit(na_2728, na_2729) } } else { var tmp12 bool; var tmp13 bool; tmp13 = jrt.Double_InstanceOf(na_2728); if tmp13 { tmp13 = jrt.Double_InstanceOf(na_2729) }; tmp12 = tmp13; if tmp12 { var n0_2735_2 float64 = jrt.NN(jrt.Double_Cast(na_2728)).DoubleValue__D(); var n1_2736_2 float64 = jrt.NN(jrt.Double_Cast(na_2729)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_2735_2 + n1_2736_2)) } else { tmp4 = lang.Numbers_Add_O_O__Number_NoInit(na_2728, na_2729) } }
//line :586:1
	arg_2727 = lang.Tuple_Create_O_O__IPersistentVector(tmp3, tmp4); if linked_2724 == nil { ifn_2725.Invoke_O_O__O(arg_2726, arg_2727) } else { linked_2724.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2723, arg_2726, arg_2727) }; i__400000454__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000454__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_c2j_node_code_forms_iter__400000481__400000487_A_New() *A_arbace_c2j_node_code_forms_iter__400000481__400000487_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000481__400000487_A{}; t.Ctor(); return t }
//line :591:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_A) Ctor() {}
//line :591:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_A) Invoke_O_O__O(self, s__400000482__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3042 any = A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_A_New_O_O(self, s__400000482__1); var tmp2 *jrt.Class; var fncls__3041 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_A_fn_class; if fncls__3041 == nil { var fncls__3041d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, fnbody__3042); A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_A_fn_class = fncls__3041d; tmp2 = fncls__3041d } else { tmp2 = fncls__3041 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3042, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :591:1
func A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_A_New_O_O(p0, p1 any) *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_A{}; t.Ctor_O_O(p0, p1); return t }
//line :591:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_A) Ctor_O_O(c__iter__400000481, c__s__400000482 any) { t.F_iter__400000481 = c__iter__400000481; t.F_s__400000482 = c__s__400000482 }
//line :591:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_A) Invoke_O__O(self any) any { { var s__400000482__1 any; var t_ any = t.F_s__400000482; t.F_s__400000482 = nil; s__400000482__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_2850 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2850, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2852 lang.IFn; if linked_2851 == nil { ifn_2852 = lang.IFn_Cast(root_2850) } else { ifn_2852 = nil }; var arg_2853 any = s__400000482__1; if linked_2851 == nil { temp__1927000414__auto____2 = ifn_2852.Invoke_O__O(arg_2853) } else { temp__1927000414__auto____2 = linked_2851.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2850, arg_2853) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var map__400000489__4 any; var root_2854 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2854, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2856 lang.IFn; if linked_2855 == nil { ifn_2856 = lang.IFn_Cast(root_2854) } else { ifn_2856 = nil }; var arg_2857 any = xs__1927001018__auto____3; if linked_2855 == nil { map__400000489__4 = ifn_2856.Invoke_O__O(arg_2857) } else { map__400000489__4 = linked_2855.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2854, arg_2857) }; var map__400000489__5 any; if lang.ISeq_InstanceOf(map__400000489__4) { var tmp1 any; var root_2858 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2858, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2860 lang.IFn; if linked_2859 == nil { ifn_2860 = lang.IFn_Cast(root_2858) } else { ifn_2860 = nil }; var arg_2861 any = map__400000489__4; if linked_2859 == nil { tmp1 = ifn_2860.Invoke_O__O(arg_2861) } else { tmp1 = linked_2859.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2858, arg_2861) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2862 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_2863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2862, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2864 lang.IFn; if linked_2863 == nil { ifn_2864 = lang.IFn_Cast(root_2862) } else { ifn_2864 = nil }; var arg_2865 any = map__400000489__4; if linked_2863 == nil { tmp2 = ifn_2864.Invoke_O__O(arg_2865) } else { tmp2 = linked_2863.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2862, arg_2865) }; map__400000489__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2866 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2866, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2868 lang.IFn; if linked_2867 == nil { ifn_2868 = lang.IFn_Cast(root_2866) } else { ifn_2868 = nil }; var arg_2869 any = map__400000489__4; if linked_2867 == nil { tmp3 = ifn_2868.Invoke_O__O(arg_2869) } else { tmp3 = linked_2867.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2866, arg_2869) }; if jrt.J2g_Truth(tmp3) { var root_2870 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2870, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2872 lang.IFn; if linked_2871 == nil { ifn_2872 = lang.IFn_Cast(root_2870) } else { ifn_2872 = nil }; var arg_2873 any = map__400000489__4; if linked_2871 == nil { map__400000489__5 = ifn_2872.Invoke_O__O(arg_2873) } else { map__400000489__5 = linked_2871.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2870, arg_2873) } } else { map__400000489__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000489__5 = map__400000489__4 }; var d__6 any = lang.RT_Get_O_O__O_NoInit(map__400000489__5, A_arbace_c2j_node_A_const_109); var vs__7 any = lang.RT_Get_O_O__O_NoInit(map__400000489__5, A_arbace_c2j_node_A_const_471); var iterys__1927001035__auto____8 any; var fnbody__3023 any = A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_A_New_O(d__6); var tmp4 *jrt.Class; var fncls__3022 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_A_fn_class; if fncls__3022 == nil { var fncls__3022d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_31, false, fnbody__3023); A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_A_fn_class = fncls__3022d; tmp4 = fncls__3022d } else { tmp4 = fncls__3022 }; iterys__1927001035__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3023, tmp4, nil); var fs__1927001036__auto____9 any; var root_3024 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_3025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3024, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_3026 lang.IFn; if linked_3025 == nil { ifn_3026 = lang.IFn_Cast(root_3024) } else { ifn_3026 = nil }; var arg_3027 any = lang.IFn_Cast(iterys__1927001035__auto____8).Invoke_O__O(vs__7); if linked_3025 == nil { fs__1927001036__auto____9 = ifn_3026.Invoke_O__O(arg_3027) } else { fs__1927001036__auto____9 = linked_3025.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_3024, arg_3027) }; if jrt.J2g_Truth(fs__1927001036__auto____9) { var root_3028 any = A_arbace_c2j_node_A_const_28.GetRawRoot__O(); var linked_3029 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3028, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_3030 lang.IFn; if linked_3029 == nil { ifn_3030 = lang.IFn_Cast(root_3028) } else { ifn_3030 = nil }; var arg_3031 any = fs__1927001036__auto____9; var arg_3032 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__400000481); var tmp6 any; var root_3033 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_3034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3033, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3035 lang.IFn; if linked_3034 == nil { ifn_3035 = lang.IFn_Cast(root_3033) } else { ifn_3035 = nil }; var arg_3036 any = s__400000482__1; if linked_3034 == nil { tmp6 = ifn_3035.Invoke_O__O(arg_3036) } else { tmp6 = linked_3034.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3033, arg_3036) }; arg_3032 = tmp5.Invoke_O__O(tmp6); if linked_3029 == nil { return ifn_3030.Invoke_O_O__O(arg_3031, arg_3032) } else { return linked_3029.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_3028, arg_3031, arg_3032) } } else { var tmp7 any; var root_3037 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_3038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3037, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3039 lang.IFn; if linked_3038 == nil { ifn_3039 = lang.IFn_Cast(root_3037) } else { ifn_3039 = nil }; var arg_3040 any = s__400000482__1; if linked_3038 == nil { tmp7 = ifn_3039.Invoke_O__O(arg_3040) } else { tmp7 = linked_3038.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3037, arg_3040) }; s__400000482__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :591:1
func A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_A_New_O(p0 any) *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_A{}; t.Ctor_O(p0); return t }
//line :591:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_A) Ctor_O(c__d any) { t.F_d = c__d }
//line :591:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_A) Invoke_O_O__O(self, s__400000484__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__3021 any = A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_A_New_O_O_O(s__400000484__1, self, t.F_d); var tmp2 *jrt.Class; var fncls__3020 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_A_fn_class; if fncls__3020 == nil { var fncls__3020d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, fnbody__3021); A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_A_fn_class = fncls__3020d; tmp2 = fncls__3020d } else { tmp2 = fncls__3020 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3021, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :591:1
func A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :591:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_A) Ctor_O_O_O(c__s__400000484, c__iter__400000483, c__d any) { t.F_s__400000484 = c__s__400000484; t.F_iter__400000483 = c__iter__400000483; t.F_d = c__d }
//line :591:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_A) Invoke_O__O(self any) any { { var s__400000484__1 any; var t_ any = t.F_s__400000484; t.F_s__400000484 = nil; s__400000484__1 = t_; for { var temp__1927000414__auto____2 any; var root_2874 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2875 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2874, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2876 lang.IFn; if linked_2875 == nil { ifn_2876 = lang.IFn_Cast(root_2874) } else { ifn_2876 = nil }; var arg_2877 any = s__400000484__1; if linked_2875 == nil { temp__1927000414__auto____2 = ifn_2876.Invoke_O__O(arg_2877) } else { temp__1927000414__auto____2 = linked_2875.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2874, arg_2877) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__400000484__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2878 any = A_arbace_c2j_node_A_const_400.GetRawRoot__O(); var linked_2879 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2878, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2880 lang.IFn; if linked_2879 == nil { ifn_2880 = lang.IFn_Cast(root_2878) } else { ifn_2880 = nil }; var arg_2881 any = s__400000484__3; if linked_2879 == nil { tmp1 = ifn_2880.Invoke_O__O(arg_2881) } else { tmp1 = linked_2879.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2878, arg_2881) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2882 any = A_arbace_c2j_node_A_const_401.GetRawRoot__O(); var linked_2883 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2882, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2884 lang.IFn; if linked_2883 == nil { ifn_2884 = lang.IFn_Cast(root_2882) } else { ifn_2884 = nil }; var arg_2885 any = s__400000484__3; if linked_2883 == nil { c__1927001037__auto____4 = ifn_2884.Invoke_O__O(arg_2885) } else { c__1927001037__auto____4 = linked_2883.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2882, arg_2885) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__400000486__6 any; var root_2886 any = A_arbace_c2j_node_A_const_402.GetRawRoot__O(); var linked_2887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2886, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2888 lang.IFn; if linked_2887 == nil { ifn_2888 = lang.IFn_Cast(root_2886) } else { ifn_2888 = nil }; var arg_2889 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2887 == nil { b__400000486__6 = ifn_2888.Invoke_O__O(arg_2889) } else { b__400000486__6 = linked_2887.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2886, arg_2889) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2940 any = A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_A_New_O_I_O_O(b__400000486__6, size__1927001038__auto____5, t.F_d, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2939 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_A_fn_class; if fncls__2939 == nil { var fncls__2939d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__2940); A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_A_fn_class = fncls__2939d; tmp3 = fncls__2939d } else { tmp3 = fncls__2939 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2940, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2941 any = A_arbace_c2j_node_A_const_404.GetRawRoot__O(); var linked_2942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2941, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2943 lang.IFn; if linked_2942 == nil { ifn_2943 = lang.IFn_Cast(root_2941) } else { ifn_2943 = nil }; var arg_2944 any; var root_2946 any = A_arbace_c2j_node_A_const_405.GetRawRoot__O(); var linked_2947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2946, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2948 lang.IFn; if linked_2947 == nil { ifn_2948 = lang.IFn_Cast(root_2946) } else { ifn_2948 = nil }; var arg_2949 any = b__400000486__6; if linked_2947 == nil { arg_2944 = ifn_2948.Invoke_O__O(arg_2949) } else { arg_2944 = linked_2947.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2946, arg_2949) }; var arg_2945 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__400000483); var tmp5 any; var root_2950 any = A_arbace_c2j_node_A_const_406.GetRawRoot__O(); var linked_2951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2950, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2952 lang.IFn; if linked_2951 == nil { ifn_2952 = lang.IFn_Cast(root_2950) } else { ifn_2952 = nil }; var arg_2953 any = s__400000484__3; if linked_2951 == nil { tmp5 = ifn_2952.Invoke_O__O(arg_2953) } else { tmp5 = linked_2951.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2950, arg_2953) }; arg_2945 = tmp4.Invoke_O__O(tmp5); if linked_2942 == nil { return ifn_2943.Invoke_O_O__O(arg_2944, arg_2945) } else { return linked_2942.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2941, arg_2944, arg_2945) } } else { var root_2954 any = A_arbace_c2j_node_A_const_404.GetRawRoot__O(); var linked_2955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2954, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2956 lang.IFn; if linked_2955 == nil { ifn_2956 = lang.IFn_Cast(root_2954) } else { ifn_2956 = nil }; var arg_2957 any; var root_2959 any = A_arbace_c2j_node_A_const_405.GetRawRoot__O(); var linked_2960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2959, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2961 lang.IFn; if linked_2960 == nil { ifn_2961 = lang.IFn_Cast(root_2959) } else { ifn_2961 = nil }; var arg_2962 any = b__400000486__6; if linked_2960 == nil { arg_2957 = ifn_2961.Invoke_O__O(arg_2962) } else { arg_2957 = linked_2960.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2959, arg_2962) }; var arg_2958 any; if linked_2955 == nil { return ifn_2956.Invoke_O_O__O(arg_2957, arg_2958) } else { return linked_2955.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2954, arg_2957, arg_2958) } } } else { var map__400000503__4 any; var root_2963 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2963, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2965 lang.IFn; if linked_2964 == nil { ifn_2965 = lang.IFn_Cast(root_2963) } else { ifn_2965 = nil }; var arg_2966 any = s__400000484__3; if linked_2964 == nil { map__400000503__4 = ifn_2965.Invoke_O__O(arg_2966) } else { map__400000503__4 = linked_2964.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2963, arg_2966) }; var map__400000503__5 any; if lang.ISeq_InstanceOf(map__400000503__4) { var tmp6 any; var root_2967 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2968 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2967, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2969 lang.IFn; if linked_2968 == nil { ifn_2969 = lang.IFn_Cast(root_2967) } else { ifn_2969 = nil }; var arg_2970 any = map__400000503__4; if linked_2968 == nil { tmp6 = ifn_2969.Invoke_O__O(arg_2970) } else { tmp6 = linked_2968.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2967, arg_2970) }; if jrt.J2g_Truth(tmp6) { var tmp7 any; var root_2971 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_2972 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2971, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2973 lang.IFn; if linked_2972 == nil { ifn_2973 = lang.IFn_Cast(root_2971) } else { ifn_2973 = nil }; var arg_2974 any = map__400000503__4; if linked_2972 == nil { tmp7 = ifn_2973.Invoke_O__O(arg_2974) } else { tmp7 = linked_2972.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2971, arg_2974) }; map__400000503__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp7)).Ref() } else { var tmp8 any; var root_2975 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2975, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2977 lang.IFn; if linked_2976 == nil { ifn_2977 = lang.IFn_Cast(root_2975) } else { ifn_2977 = nil }; var arg_2978 any = map__400000503__4; if linked_2976 == nil { tmp8 = ifn_2977.Invoke_O__O(arg_2978) } else { tmp8 = linked_2976.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2975, arg_2978) }; if jrt.J2g_Truth(tmp8) { var root_2979 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2979, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2981 lang.IFn; if linked_2980 == nil { ifn_2981 = lang.IFn_Cast(root_2979) } else { ifn_2981 = nil }; var arg_2982 any = map__400000503__4; if linked_2980 == nil { map__400000503__5 = ifn_2981.Invoke_O__O(arg_2982) } else { map__400000503__5 = linked_2980.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2979, arg_2982) } } else { map__400000503__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000503__5 = map__400000503__4 }; var v__6 any = lang.RT_Get_O_O__O_NoInit(map__400000503__5, A_arbace_c2j_node_A_const_56); var cf__7 any = lang.RT_Get_O_O__O_NoInit(map__400000503__5, A_arbace_c2j_node_A_const_473); var root_2983 any = A_arbace_c2j_node_A_const_83.GetRawRoot__O(); var linked_2984 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2983, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2985 lang.IFn; if linked_2984 == nil { ifn_2985 = lang.IFn_Cast(root_2983) } else { ifn_2985 = nil }; var arg_2986 any; var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_34, nil, nil, nil, nil); var tmp10 any = A_arbace_c2j_node_A_const_349.Invoke_O__O(v__6); var tmp11 any = A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d); var tmp12 *jrt.String; var temp__1927000414__auto____14 any; var root_2988 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2988, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2990 lang.IFn

	if linked_2989 == nil { ifn_2990 = lang.IFn_Cast(root_2988) } else { ifn_2990 = nil }; var arg_2991 any; var root_2992 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_2993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2992, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2994 lang.IFn; if linked_2993 == nil { ifn_2994 = lang.IFn_Cast(root_2992) } else { ifn_2994 = nil }; var arg_2995 any; var fnbody__3002 any = A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000506_A_New(); var tmp13 *jrt.Class; var fncls__3001 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000506_A_fn_class; if fncls__3001 == nil { var fncls__3001d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000506_A_fn_class = fncls__3001d; tmp13 = fncls__3001d } else { tmp13 = fncls__3001 }; arg_2995 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3002, tmp13, nil); var arg_2996 any = A_arbace_c2j_node_A_const_239.Invoke_O__O(v__6); if linked_2993 == nil { arg_2991 = ifn_2994.Invoke_O_O__O(arg_2995, arg_2996) } else { arg_2991 = linked_2993.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2992, arg_2995, arg_2996) }; if linked_2989 == nil { temp__1927000414__auto____14 = ifn_2990.Invoke_O__O(arg_2991) } else { temp__1927000414__auto____14 = linked_2989.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2988, arg_2991) }; if jrt.J2g_Truth(temp__1927000414__auto____14) { var s__15 any = temp__1927000414__auto____14; var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp15 any; var root_3003 any = A_arbace_c2j_node_A_const_478.GetRawRoot__O(); var linked_3004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3003, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_3005 lang.IFn; if linked_3004 == nil { ifn_3005 = lang.IFn_Cast(root_3003) } else { ifn_3005 = nil }; var arg_3006 any = Lit_36; var arg_3007 any = s__15; if linked_3004 == nil { tmp15 = ifn_3005.Invoke_O_O__O(arg_3006, arg_3007) } else { tmp15 = linked_3004.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_3003, arg_3006, arg_3007) }; tmp12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15)) } else { tmp12 = nil }
//line :591:1
	var tmp16 any = tmp12.Ref(); var tmp17 *jrt.String; var tmp18 any; var root_3008 any = A_arbace_c2j_node_A_const_413.GetRawRoot__O(); var linked_3009 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3008, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_3010 lang.IFn


	if linked_3009 == nil { ifn_3010 = lang.IFn_Cast(root_3008) } else { ifn_3010 = nil }; var arg_3011 any = A_arbace_c2j_node_A_const_226.Invoke_O__O(v__6); if linked_3009 == nil { tmp18 = ifn_3010.Invoke_O__O(arg_3011) } else { tmp18 = linked_3009.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_3008, arg_3011) }; if jrt.J2g_Truth(tmp18) { var tmp19 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp20 *jrt.String; var tmp21 any = A_arbace_c2j_node_A_const_225; if lang.Util_Equiv_O_O__Z_NoInit(tmp21, A_arbace_c2j_node_A_const_226.Invoke_O__O(v__6)) { tmp20 = Lit_37 } else { tmp20 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_226.Invoke_O__O(v__6), nil)) }; tmp17 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp19, jrt.RefArrayOf(jrt.Object_class, nil, tmp20.Ref())) } else { tmp17 = nil }
//line :591:1
	var tmp22 any = tmp17.Ref(); var tmp23 *jrt.String



	if jrt.J2g_Truth(A_arbace_c2j_node_A_const_177.Invoke_O__O(v__6)) { var tmp24 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil, nil); var tmp25 any; var root_3012 any = A_arbace_c2j_node_A_const_477.GetRawRoot__O(); var linked_3013 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3012, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_3014 lang.IFn; if linked_3013 == nil { ifn_3014 = lang.IFn_Cast(root_3012) } else { ifn_3014 = nil }; var arg_3015 any = A_arbace_c2j_node_A_const_410.Invoke_O__O(v__6); if linked_3013 == nil { tmp25 = ifn_3014.Invoke_O__O(arg_3015) } else { tmp25 = linked_3013.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_3012, arg_3015) }; var tmp26 any = tmp25; var tmp27 *jrt.String; if jrt.J2g_Truth(A_arbace_c2j_node_A_const_73.Invoke_O__O(v__6)) { tmp27 = Lit_39 } else { tmp27 = nil }; tmp23 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp24, jrt.RefArrayOf(jrt.Object_class, nil, tmp26, tmp27.Ref())) } else { tmp23 = nil }
//line :591:1
	arg_2986 = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, tmp10, nil, tmp11, tmp16, tmp22, tmp23.Ref())).Ref(), cf__7); var arg_2987 any; var tmp28 lang.IFn = lang.IFn_Cast(t.F_iter__400000483); var tmp29 any; var root_3016 any = A_arbace_c2j_node_A_const_23.GetRawRoot__O(); var linked_3017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3016, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_3018 lang.IFn; if linked_3017 == nil { ifn_3018 = lang.IFn_Cast(root_3016) } else { ifn_3018 = nil }; var arg_3019 any = s__400000484__3; if linked_3017 == nil { tmp29 = ifn_3018.Invoke_O__O(arg_3019) } else { tmp29 = linked_3017.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_3016, arg_3019) }; arg_2987 = tmp28.Invoke_O__O(tmp29); if linked_2984 == nil { return ifn_2985.Invoke_O_O__O(arg_2986, arg_2987) } else { return linked_2984.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2983, arg_2986, arg_2987) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :591:1
func A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :591:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_A) Ctor_O_I_O_O(c__b__400000486 any, c__size__1927001038__auto__ int32, c__d, c__c__1927001037__auto__ any) { t.F_b__400000486 = c__b__400000486; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_d = c__d; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :591:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_A) Invoke_O__O(self any) any { { var i__400000485__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__400000485__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var map__400000494__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__400000485__1)); var map__400000494__3 any; if lang.ISeq_InstanceOf(map__400000494__2) { var tmp2 any; var root_2890 any = A_arbace_c2j_node_A_const_75.GetRawRoot__O(); var linked_2891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2890, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2892 lang.IFn; if linked_2891 == nil { ifn_2892 = lang.IFn_Cast(root_2890) } else { ifn_2892 = nil }; var arg_2893 any = map__400000494__2; if linked_2891 == nil { tmp2 = ifn_2892.Invoke_O__O(arg_2893) } else { tmp2 = linked_2891.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2890, arg_2893) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_2894 any = A_arbace_c2j_node_A_const_172.GetRawRoot__O(); var linked_2895 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2894, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2896 lang.IFn; if linked_2895 == nil { ifn_2896 = lang.IFn_Cast(root_2894) } else { ifn_2896 = nil }; var arg_2897 any = map__400000494__2; if linked_2895 == nil { tmp3 = ifn_2896.Invoke_O__O(arg_2897) } else { tmp3 = linked_2895.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2894, arg_2897) }; map__400000494__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp3)).Ref() } else { var tmp4 any; var root_2898 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2899 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2898, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2900 lang.IFn; if linked_2899 == nil { ifn_2900 = lang.IFn_Cast(root_2898) } else { ifn_2900 = nil }; var arg_2901 any = map__400000494__2; if linked_2899 == nil { tmp4 = ifn_2900.Invoke_O__O(arg_2901) } else { tmp4 = linked_2899.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2898, arg_2901) }; if jrt.J2g_Truth(tmp4) { var root_2902 any = A_arbace_c2j_node_A_const_11.GetRawRoot__O(); var linked_2903 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2902, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2904 lang.IFn; if linked_2903 == nil { ifn_2904 = lang.IFn_Cast(root_2902) } else { ifn_2904 = nil }; var arg_2905 any = map__400000494__2; if linked_2903 == nil { map__400000494__3 = ifn_2904.Invoke_O__O(arg_2905) } else { map__400000494__3 = linked_2903.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2902, arg_2905) } } else { map__400000494__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__400000494__3 = map__400000494__2 }; var v__4 any = lang.RT_Get_O_O__O_NoInit(map__400000494__3, A_arbace_c2j_node_A_const_56); var cf__5 any = lang.RT_Get_O_O__O_NoInit(map__400000494__3, A_arbace_c2j_node_A_const_473); var root_2906 any = A_arbace_c2j_node_A_const_403.GetRawRoot__O(); var linked_2907 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2906, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2908 lang.IFn; if linked_2907 == nil { ifn_2908 = lang.IFn_Cast(root_2906) } else { ifn_2908 = nil }; var arg_2909 any = t.F_b__400000486; var arg_2910 any; var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_34, nil, nil, nil, nil); var tmp6 any = A_arbace_c2j_node_A_const_349.Invoke_O__O(v__4); var tmp7 any = A_arbace_c2j_node_A_const_13.Invoke_O__O(t.F_d); var tmp8 *jrt.String; var temp__1927000414__auto____12 any; var root_2911 any = A_arbace_c2j_node_A_const_74.GetRawRoot__O(); var linked_2912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2911, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2913 lang.IFn

	if linked_2912 == nil { ifn_2913 = lang.IFn_Cast(root_2911) } else { ifn_2913 = nil }; var arg_2914 any; var root_2915 any = A_arbace_c2j_node_A_const_29.GetRawRoot__O(); var linked_2916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2915, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_2917 lang.IFn; if linked_2916 == nil { ifn_2917 = lang.IFn_Cast(root_2915) } else { ifn_2917 = nil }; var arg_2918 any; var fnbody__2925 any = A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_fn__400000497_A_New(); var tmp9 *jrt.Class; var fncls__2924 *jrt.Class = A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_fn__400000497_A_fn_class; if fncls__2924 == nil { var fncls__2924d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_fn__400000497_A_fn_class = fncls__2924d; tmp9 = fncls__2924d } else { tmp9 = fncls__2924 }; arg_2918 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2925, tmp9, nil); var arg_2919 any = A_arbace_c2j_node_A_const_239.Invoke_O__O(v__4); if linked_2916 == nil { arg_2914 = ifn_2917.Invoke_O_O__O(arg_2918, arg_2919) } else { arg_2914 = linked_2916.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_2915, arg_2918, arg_2919) }; if linked_2912 == nil { temp__1927000414__auto____12 = ifn_2913.Invoke_O__O(arg_2914) } else { temp__1927000414__auto____12 = linked_2912.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2911, arg_2914) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var s__13 any = temp__1927000414__auto____12; var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp11 any; var root_2926 any = A_arbace_c2j_node_A_const_478.GetRawRoot__O(); var linked_2927 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2926, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2928 lang.IFn; if linked_2927 == nil { ifn_2928 = lang.IFn_Cast(root_2926) } else { ifn_2928 = nil }; var arg_2929 any = Lit_36; var arg_2930 any = s__13; if linked_2927 == nil { tmp11 = ifn_2928.Invoke_O_O__O(arg_2929, arg_2930) } else { tmp11 = linked_2927.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2926, arg_2929, arg_2930) }; tmp8 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11)) } else { tmp8 = nil }
//line :591:1
	var tmp12 any = tmp8.Ref(); var tmp13 *jrt.String; var tmp14 any; var root_2931 any = A_arbace_c2j_node_A_const_413.GetRawRoot__O(); var linked_2932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2931, aot_arbace_core.A_arbace_core_some_QMARK__A_fn_class); var ifn_2933 lang.IFn


	if linked_2932 == nil { ifn_2933 = lang.IFn_Cast(root_2931) } else { ifn_2933 = nil }; var arg_2934 any = A_arbace_c2j_node_A_const_226.Invoke_O__O(v__4); if linked_2932 == nil { tmp14 = ifn_2933.Invoke_O__O(arg_2934) } else { tmp14 = linked_2932.(*aot_arbace_core.A_arbace_core_some_QMARK__A).Invoke_O_O__O(root_2931, arg_2934) }; if jrt.J2g_Truth(tmp14) { var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil); var tmp16 *jrt.String; var tmp17 any = A_arbace_c2j_node_A_const_225; if lang.Util_Equiv_O_O__Z_NoInit(tmp17, A_arbace_c2j_node_A_const_226.Invoke_O__O(v__4)) { tmp16 = Lit_37 } else { tmp16 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_38), jrt.RefArrayOf(jrt.Object_class, A_arbace_c2j_node_A_const_226.Invoke_O__O(v__4), nil)) }; tmp13 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16.Ref())) } else { tmp13 = nil }
//line :591:1
	var tmp18 any = tmp13.Ref(); var tmp19 *jrt.String



	if jrt.J2g_Truth(A_arbace_c2j_node_A_const_177.Invoke_O__O(v__4)) { var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_36, nil, nil); var tmp21 any; var root_2935 any = A_arbace_c2j_node_A_const_477.GetRawRoot__O(); var linked_2936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2935, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2937 lang.IFn; if linked_2936 == nil { ifn_2937 = lang.IFn_Cast(root_2935) } else { ifn_2937 = nil }; var arg_2938 any = A_arbace_c2j_node_A_const_410.Invoke_O__O(v__4); if linked_2936 == nil { tmp21 = ifn_2937.Invoke_O__O(arg_2938) } else { tmp21 = linked_2936.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2935, arg_2938) }; var tmp22 any = tmp21; var tmp23 *jrt.String; if jrt.J2g_Truth(A_arbace_c2j_node_A_const_73.Invoke_O__O(v__4)) { tmp23 = Lit_39 } else { tmp23 = nil }; tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp22, tmp23.Ref())) } else { tmp19 = nil }
//line :591:1
	arg_2910 = lang.Tuple_Create_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil, tmp7, tmp12, tmp18, tmp19.Ref())).Ref(), cf__5); if linked_2907 == nil { ifn_2908.Invoke_O_O__O(arg_2909, arg_2910) } else { linked_2907.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2906, arg_2909, arg_2910) }; i__400000485__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__400000485__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_fn__400000497_A_New() *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_fn__400000497_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_fn__400000497_A{}; t.Ctor(); return t }
//line :593:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_fn__400000497_A) Ctor() {}
//line :593:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_fn__400000497_A) Invoke_O_O__O(self, p__400000496__1 any) any { var vec__400000498__2 any = p__400000496__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000498__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000498__2, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(x__4) { var root_2920 any = A_arbace_c2j_node_A_const_477.GetRawRoot__O(); var linked_2921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2920, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2922 lang.IFn; if linked_2921 == nil { ifn_2922 = lang.IFn_Cast(root_2920) } else { ifn_2922 = nil }; var arg_2923 any = k__3; if linked_2921 == nil { return ifn_2922.Invoke_O__O(arg_2923) } else { return linked_2921.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2920, arg_2923) } } else { return nil } }
//line :593:1
func A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000506_A_New() *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000506_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000506_A{}; t.Ctor(); return t }
//line :593:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000506_A) Ctor() {}
//line :593:1
func (t *A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000506_A) Invoke_O_O__O(self, p__400000505__1 any) any { var vec__400000507__2 any = p__400000505__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000507__2, lang.RT_IntCast_J__I_NoInit(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000507__2, lang.RT_IntCast_J__I_NoInit(1), nil); if jrt.J2g_Truth(x__4) { var root_2997 any = A_arbace_c2j_node_A_const_477.GetRawRoot__O(); var linked_2998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2997, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_2999 lang.IFn; if linked_2998 == nil { ifn_2999 = lang.IFn_Cast(root_2997) } else { ifn_2999 = nil }; var arg_3000 any = k__3; if linked_2998 == nil { return ifn_2999.Invoke_O__O(arg_3000) } else { return linked_2998.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_2997, arg_3000) } } else { return nil } }











func A_arbace_c2j_node_code_forms_fn__400000516_A_New() *A_arbace_c2j_node_code_forms_fn__400000516_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_code_forms_fn__400000516_A{}; t.Ctor(); return t }
//line :605:1
func (t *A_arbace_c2j_node_code_forms_fn__400000516_A) Ctor() {}
//line :605:1
func (t *A_arbace_c2j_node_code_forms_fn__400000516_A) Invoke_O_O__O(self, p__400000515__1 any) any { var vec__400000517__2 any = p__400000515__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000517__2, lang.RT_IntCast_J__I_NoInit(0), nil); var i__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__400000517__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()); var tmp2 any = A_arbace_c2j_node_A_const_498; var tmp3 any = A_arbace_c2j_node_A_const_499; return tmp1.Invoke_O_O_O_O__O(tmp2, tmp3, k__3, lang.IFn_Cast(A_arbace_c2j_node_A_const_39.GetRawRoot__O()).Invoke_O_O__O(A_arbace_c2j_node_A_const_500, i__4)) }























































































































































































































































type A_arbace_c2j_node_A struct{ jrt.Object }

var A_arbace_c2j_node_A_const_pool *jrt.RefArray

var A_arbace_c2j_node_A_const_0 *lang.Var

var A_arbace_c2j_node_A_const_1 any

var A_arbace_c2j_node_A_const_2 *lang.Var

var A_arbace_c2j_node_A_const_3 any

var A_arbace_c2j_node_A_const_4 *lang.Var

var A_arbace_c2j_node_A_const_5 *lang.Var

var A_arbace_c2j_node_A_const_6 *lang.Var

var A_arbace_c2j_node_A_const_7 *lang.Var

var A_arbace_c2j_node_A_const_8 any

var A_arbace_c2j_node_A_const_9 *lang.Var

var A_arbace_c2j_node_A_const_10 *lang.Var

var A_arbace_c2j_node_A_const_11 *lang.Var

var A_arbace_c2j_node_A_const_12 *lang.Var

var A_arbace_c2j_node_A_const_13 *lang.Keyword

var A_arbace_c2j_node_A_const_14 *lang.Var

var A_arbace_c2j_node_A_const_15 *lang.Keyword

var A_arbace_c2j_node_A_const_16 *lang.Keyword

var A_arbace_c2j_node_A_const_17 *lang.Keyword

var A_arbace_c2j_node_A_const_18 *lang.Var

var A_arbace_c2j_node_A_const_19 *lang.Keyword

var A_arbace_c2j_node_A_const_20 *lang.Keyword

var A_arbace_c2j_node_A_const_21 *lang.Keyword

var A_arbace_c2j_node_A_const_22 *lang.Var

var A_arbace_c2j_node_A_const_23 *lang.Var

var A_arbace_c2j_node_A_const_24 *lang.Var

var A_arbace_c2j_node_A_const_25 any

var A_arbace_c2j_node_A_const_26 *lang.Keyword

var A_arbace_c2j_node_A_const_27 *lang.Var

var A_arbace_c2j_node_A_const_28 *lang.Var

var A_arbace_c2j_node_A_const_29 *lang.Var

var A_arbace_c2j_node_A_const_30 any

var A_arbace_c2j_node_A_const_31 *lang.Keyword

var A_arbace_c2j_node_A_const_32 *lang.Var

var A_arbace_c2j_node_A_const_33 any

var A_arbace_c2j_node_A_const_34 *lang.Var

var A_arbace_c2j_node_A_const_35 *lang.Var

var A_arbace_c2j_node_A_const_36 *lang.Var

var A_arbace_c2j_node_A_const_37 *lang.Var

var A_arbace_c2j_node_A_const_38 *lang.Var

var A_arbace_c2j_node_A_const_39 *lang.Var

var A_arbace_c2j_node_A_const_40 *lang.Var

var A_arbace_c2j_node_A_const_41 *lang.Var

var A_arbace_c2j_node_A_const_42 *lang.Var

var A_arbace_c2j_node_A_const_43 *lang.Var

var A_arbace_c2j_node_A_const_44 *lang.Var

var A_arbace_c2j_node_A_const_45 *lang.Keyword

var A_arbace_c2j_node_A_const_46 any

var A_arbace_c2j_node_A_const_47 *lang.Var

var A_arbace_c2j_node_A_const_48 *lang.Var

var A_arbace_c2j_node_A_const_49 *lang.Var

var A_arbace_c2j_node_A_const_50 *lang.Var

var A_arbace_c2j_node_A_const_51 any

var A_arbace_c2j_node_A_const_52 *lang.Var

var A_arbace_c2j_node_A_const_53 *lang.Var

var A_arbace_c2j_node_A_const_54 *lang.Var

var A_arbace_c2j_node_A_const_55 *lang.Keyword

var A_arbace_c2j_node_A_const_56 *lang.Keyword

var A_arbace_c2j_node_A_const_57 any

var A_arbace_c2j_node_A_const_58 *lang.Keyword

var A_arbace_c2j_node_A_const_59 *lang.Var

var A_arbace_c2j_node_A_const_60 *lang.Var

var A_arbace_c2j_node_A_const_61 *lang.Var

var A_arbace_c2j_node_A_const_62 *lang.Var

var A_arbace_c2j_node_A_const_63 any

var A_arbace_c2j_node_A_const_64 any

var A_arbace_c2j_node_A_const_65 any

var A_arbace_c2j_node_A_const_66 any

var A_arbace_c2j_node_A_const_67 any

var A_arbace_c2j_node_A_const_68 any

var A_arbace_c2j_node_A_const_69 any

var A_arbace_c2j_node_A_const_70 any

var A_arbace_c2j_node_A_const_71 *lang.Keyword

var A_arbace_c2j_node_A_const_72 any

var A_arbace_c2j_node_A_const_73 *lang.Keyword

var A_arbace_c2j_node_A_const_74 *lang.Var

var A_arbace_c2j_node_A_const_75 *lang.Var

var A_arbace_c2j_node_A_const_76 any

var A_arbace_c2j_node_A_const_77 any

var A_arbace_c2j_node_A_const_78 *lang.Var

var A_arbace_c2j_node_A_const_79 any

var A_arbace_c2j_node_A_const_80 any

var A_arbace_c2j_node_A_const_81 *lang.Var

var A_arbace_c2j_node_A_const_82 any

var A_arbace_c2j_node_A_const_83 *lang.Var

var A_arbace_c2j_node_A_const_84 any

var A_arbace_c2j_node_A_const_85 any

var A_arbace_c2j_node_A_const_86 any

var A_arbace_c2j_node_A_const_87 any

var A_arbace_c2j_node_A_const_88 any

var A_arbace_c2j_node_A_const_89 any

var A_arbace_c2j_node_A_const_90 any

var A_arbace_c2j_node_A_const_91 any

var A_arbace_c2j_node_A_const_92 any

var A_arbace_c2j_node_A_const_93 any

var A_arbace_c2j_node_A_const_94 any

var A_arbace_c2j_node_A_const_95 any

var A_arbace_c2j_node_A_const_96 any

var A_arbace_c2j_node_A_const_97 any

var A_arbace_c2j_node_A_const_98 *lang.Var

var A_arbace_c2j_node_A_const_99 *lang.Var

var A_arbace_c2j_node_A_const_100 any

var A_arbace_c2j_node_A_const_101 any

var A_arbace_c2j_node_A_const_102 any

var A_arbace_c2j_node_A_const_103 any

var A_arbace_c2j_node_A_const_104 any

var A_arbace_c2j_node_A_const_105 *lang.Keyword

var A_arbace_c2j_node_A_const_106 any

var A_arbace_c2j_node_A_const_107 *lang.Keyword

var A_arbace_c2j_node_A_const_108 any

var A_arbace_c2j_node_A_const_109 *lang.Keyword

var A_arbace_c2j_node_A_const_110 *lang.Keyword

var A_arbace_c2j_node_A_const_111 any

var A_arbace_c2j_node_A_const_112 any

var A_arbace_c2j_node_A_const_113 any

var A_arbace_c2j_node_A_const_114 any

var A_arbace_c2j_node_A_const_115 any

var A_arbace_c2j_node_A_const_116 any

var A_arbace_c2j_node_A_const_117 any

var A_arbace_c2j_node_A_const_118 any

var A_arbace_c2j_node_A_const_119 any

var A_arbace_c2j_node_A_const_120 *lang.Keyword

var A_arbace_c2j_node_A_const_121 any

var A_arbace_c2j_node_A_const_122 any

var A_arbace_c2j_node_A_const_123 any

var A_arbace_c2j_node_A_const_124 any

var A_arbace_c2j_node_A_const_125 any

var A_arbace_c2j_node_A_const_126 *lang.Keyword

var A_arbace_c2j_node_A_const_127 any

var A_arbace_c2j_node_A_const_128 any

var A_arbace_c2j_node_A_const_129 *lang.Var

var A_arbace_c2j_node_A_const_130 *lang.Var

var A_arbace_c2j_node_A_const_131 any

var A_arbace_c2j_node_A_const_132 *lang.Keyword

var A_arbace_c2j_node_A_const_133 any

var A_arbace_c2j_node_A_const_134 any

var A_arbace_c2j_node_A_const_135 any

var A_arbace_c2j_node_A_const_136 any

var A_arbace_c2j_node_A_const_137 *lang.Keyword

var A_arbace_c2j_node_A_const_138 any

var A_arbace_c2j_node_A_const_139 any

var A_arbace_c2j_node_A_const_140 any

var A_arbace_c2j_node_A_const_141 *lang.Var

var A_arbace_c2j_node_A_const_142 any

var A_arbace_c2j_node_A_const_143 any

var A_arbace_c2j_node_A_const_144 any

var A_arbace_c2j_node_A_const_145 any

var A_arbace_c2j_node_A_const_146 any

var A_arbace_c2j_node_A_const_147 any

var A_arbace_c2j_node_A_const_148 any

var A_arbace_c2j_node_A_const_149 any

var A_arbace_c2j_node_A_const_150 any

var A_arbace_c2j_node_A_const_151 any

var A_arbace_c2j_node_A_const_152 any

var A_arbace_c2j_node_A_const_153 any

var A_arbace_c2j_node_A_const_154 any

var A_arbace_c2j_node_A_const_155 any

var A_arbace_c2j_node_A_const_156 *lang.Keyword

var A_arbace_c2j_node_A_const_157 *lang.Var

var A_arbace_c2j_node_A_const_158 *lang.Var

var A_arbace_c2j_node_A_const_159 any

var A_arbace_c2j_node_A_const_160 any

var A_arbace_c2j_node_A_const_161 any

var A_arbace_c2j_node_A_const_162 *lang.Keyword

var A_arbace_c2j_node_A_const_163 any

var A_arbace_c2j_node_A_const_164 any

var A_arbace_c2j_node_A_const_165 any

var A_arbace_c2j_node_A_const_166 *lang.Var

var A_arbace_c2j_node_A_const_167 any

var A_arbace_c2j_node_A_const_168 *lang.Keyword

var A_arbace_c2j_node_A_const_169 any

var A_arbace_c2j_node_A_const_170 *lang.Keyword

var A_arbace_c2j_node_A_const_171 *lang.Keyword

var A_arbace_c2j_node_A_const_172 *lang.Var

var A_arbace_c2j_node_A_const_173 any

var A_arbace_c2j_node_A_const_174 any

var A_arbace_c2j_node_A_const_175 any

var A_arbace_c2j_node_A_const_176 any

var A_arbace_c2j_node_A_const_177 *lang.Keyword

var A_arbace_c2j_node_A_const_178 any

var A_arbace_c2j_node_A_const_179 any

var A_arbace_c2j_node_A_const_180 any

var A_arbace_c2j_node_A_const_181 *lang.Keyword

var A_arbace_c2j_node_A_const_182 any

var A_arbace_c2j_node_A_const_183 any

var A_arbace_c2j_node_A_const_184 any

var A_arbace_c2j_node_A_const_185 *lang.Keyword

var A_arbace_c2j_node_A_const_186 any

var A_arbace_c2j_node_A_const_187 *lang.Var

var A_arbace_c2j_node_A_const_188 *lang.Var

var A_arbace_c2j_node_A_const_189 any

var A_arbace_c2j_node_A_const_190 any

var A_arbace_c2j_node_A_const_191 any

var A_arbace_c2j_node_A_const_192 any

var A_arbace_c2j_node_A_const_193 any

var A_arbace_c2j_node_A_const_194 any

var A_arbace_c2j_node_A_const_195 any

var A_arbace_c2j_node_A_const_196 *lang.Keyword

var A_arbace_c2j_node_A_const_197 any

var A_arbace_c2j_node_A_const_198 any

var A_arbace_c2j_node_A_const_199 any

var A_arbace_c2j_node_A_const_200 any

var A_arbace_c2j_node_A_const_201 *lang.Var

var A_arbace_c2j_node_A_const_202 any

var A_arbace_c2j_node_A_const_203 *lang.Keyword

var A_arbace_c2j_node_A_const_204 *lang.Var

var A_arbace_c2j_node_A_const_205 any

var A_arbace_c2j_node_A_const_206 any

var A_arbace_c2j_node_A_const_207 any

var A_arbace_c2j_node_A_const_208 *lang.Var

var A_arbace_c2j_node_A_const_209 *lang.Keyword

var A_arbace_c2j_node_A_const_210 *lang.Keyword

var A_arbace_c2j_node_A_const_211 *lang.Keyword

var A_arbace_c2j_node_A_const_212 *lang.Keyword

var A_arbace_c2j_node_A_const_213 *lang.Keyword

var A_arbace_c2j_node_A_const_214 any

var A_arbace_c2j_node_A_const_215 any

var A_arbace_c2j_node_A_const_216 any

var A_arbace_c2j_node_A_const_217 any

var A_arbace_c2j_node_A_const_218 any

var A_arbace_c2j_node_A_const_219 *lang.Keyword

var A_arbace_c2j_node_A_const_220 *lang.Var

var A_arbace_c2j_node_A_const_221 *lang.Keyword

var A_arbace_c2j_node_A_const_222 *lang.Var

var A_arbace_c2j_node_A_const_223 *lang.Var

var A_arbace_c2j_node_A_const_224 any

var A_arbace_c2j_node_A_const_225 *lang.Keyword

var A_arbace_c2j_node_A_const_226 *lang.Keyword

var A_arbace_c2j_node_A_const_227 *lang.Keyword

var A_arbace_c2j_node_A_const_228 *lang.Keyword

var A_arbace_c2j_node_A_const_229 any

var A_arbace_c2j_node_A_const_230 any

var A_arbace_c2j_node_A_const_231 *lang.Var

var A_arbace_c2j_node_A_const_232 any

var A_arbace_c2j_node_A_const_233 any

var A_arbace_c2j_node_A_const_234 *lang.Var

var A_arbace_c2j_node_A_const_235 any

var A_arbace_c2j_node_A_const_236 *lang.Keyword

var A_arbace_c2j_node_A_const_237 *lang.Keyword

var A_arbace_c2j_node_A_const_238 any

var A_arbace_c2j_node_A_const_239 *lang.Keyword

var A_arbace_c2j_node_A_const_240 any

var A_arbace_c2j_node_A_const_241 any

var A_arbace_c2j_node_A_const_242 any

var A_arbace_c2j_node_A_const_243 any

var A_arbace_c2j_node_A_const_244 any

var A_arbace_c2j_node_A_const_245 any

var A_arbace_c2j_node_A_const_246 any

var A_arbace_c2j_node_A_const_247 *lang.Var

var A_arbace_c2j_node_A_const_248 any

var A_arbace_c2j_node_A_const_249 any

var A_arbace_c2j_node_A_const_250 *lang.Keyword

var A_arbace_c2j_node_A_const_251 any

var A_arbace_c2j_node_A_const_252 any

var A_arbace_c2j_node_A_const_253 *lang.Keyword

var A_arbace_c2j_node_A_const_254 any

var A_arbace_c2j_node_A_const_255 any

var A_arbace_c2j_node_A_const_256 any

var A_arbace_c2j_node_A_const_257 *lang.Var

var A_arbace_c2j_node_A_const_258 any

var A_arbace_c2j_node_A_const_259 *lang.Keyword

var A_arbace_c2j_node_A_const_260 *lang.Keyword

var A_arbace_c2j_node_A_const_261 *lang.Var

var A_arbace_c2j_node_A_const_262 any

var A_arbace_c2j_node_A_const_263 any

var A_arbace_c2j_node_A_const_264 *lang.Keyword

var A_arbace_c2j_node_A_const_265 *lang.Keyword

var A_arbace_c2j_node_A_const_266 *lang.Var

var A_arbace_c2j_node_A_const_267 any

var A_arbace_c2j_node_A_const_268 any

var A_arbace_c2j_node_A_const_269 any

var A_arbace_c2j_node_A_const_270 *lang.Keyword

var A_arbace_c2j_node_A_const_271 any

var A_arbace_c2j_node_A_const_272 any

var A_arbace_c2j_node_A_const_273 any

var A_arbace_c2j_node_A_const_274 *lang.Var

var A_arbace_c2j_node_A_const_275 any

var A_arbace_c2j_node_A_const_276 any

var A_arbace_c2j_node_A_const_277 any

var A_arbace_c2j_node_A_const_278 any

var A_arbace_c2j_node_A_const_279 any

var A_arbace_c2j_node_A_const_280 any

var A_arbace_c2j_node_A_const_281 any

var A_arbace_c2j_node_A_const_282 any

var A_arbace_c2j_node_A_const_283 any

var A_arbace_c2j_node_A_const_284 *lang.Var

var A_arbace_c2j_node_A_const_285 *lang.Var

var A_arbace_c2j_node_A_const_286 *lang.Keyword

var A_arbace_c2j_node_A_const_287 any

var A_arbace_c2j_node_A_const_288 any

var A_arbace_c2j_node_A_const_289 any

var A_arbace_c2j_node_A_const_290 *lang.Var

var A_arbace_c2j_node_A_const_291 *lang.Var

var A_arbace_c2j_node_A_const_292 any

var A_arbace_c2j_node_A_const_293 any

var A_arbace_c2j_node_A_const_294 any

var A_arbace_c2j_node_A_const_295 any

var A_arbace_c2j_node_A_const_296 any

var A_arbace_c2j_node_A_const_297 any

var A_arbace_c2j_node_A_const_298 any

var A_arbace_c2j_node_A_const_299 any

var A_arbace_c2j_node_A_const_300 any

var A_arbace_c2j_node_A_const_301 any

var A_arbace_c2j_node_A_const_302 any

var A_arbace_c2j_node_A_const_303 any

var A_arbace_c2j_node_A_const_304 any

var A_arbace_c2j_node_A_const_305 *jrt.Class

var A_arbace_c2j_node_A_const_306 any

var A_arbace_c2j_node_A_const_307 any

var A_arbace_c2j_node_A_const_308 any

var A_arbace_c2j_node_A_const_309 any

var A_arbace_c2j_node_A_const_310 any

var A_arbace_c2j_node_A_const_311 any

var A_arbace_c2j_node_A_const_312 any

var A_arbace_c2j_node_A_const_313 any

var A_arbace_c2j_node_A_const_314 any

var A_arbace_c2j_node_A_const_315 any

var A_arbace_c2j_node_A_const_316 any

var A_arbace_c2j_node_A_const_317 any

var A_arbace_c2j_node_A_const_318 any

var A_arbace_c2j_node_A_const_319 *lang.Var

var A_arbace_c2j_node_A_const_320 *lang.Var

var A_arbace_c2j_node_A_const_321 any

var A_arbace_c2j_node_A_const_322 any

var A_arbace_c2j_node_A_const_323 *lang.Var

var A_arbace_c2j_node_A_const_324 *lang.Var

var A_arbace_c2j_node_A_const_325 *lang.Var

var A_arbace_c2j_node_A_const_326 any

var A_arbace_c2j_node_A_const_327 *lang.Var

var A_arbace_c2j_node_A_const_328 any

var A_arbace_c2j_node_A_const_329 *lang.Var

var A_arbace_c2j_node_A_const_330 *lang.Keyword

var A_arbace_c2j_node_A_const_331 any

var A_arbace_c2j_node_A_const_332 any

var A_arbace_c2j_node_A_const_333 any

var A_arbace_c2j_node_A_const_334 any

var A_arbace_c2j_node_A_const_335 any

var A_arbace_c2j_node_A_const_336 any

var A_arbace_c2j_node_A_const_337 any

var A_arbace_c2j_node_A_const_338 *lang.Var

var A_arbace_c2j_node_A_const_339 *lang.Keyword

var A_arbace_c2j_node_A_const_340 any

var A_arbace_c2j_node_A_const_341 *lang.Keyword

var A_arbace_c2j_node_A_const_342 *lang.Keyword

var A_arbace_c2j_node_A_const_343 *lang.Var

var A_arbace_c2j_node_A_const_344 any

var A_arbace_c2j_node_A_const_345 any

var A_arbace_c2j_node_A_const_346 *lang.Var

var A_arbace_c2j_node_A_const_347 any

var A_arbace_c2j_node_A_const_348 any

var A_arbace_c2j_node_A_const_349 *lang.Keyword

var A_arbace_c2j_node_A_const_350 any

var A_arbace_c2j_node_A_const_351 any

var A_arbace_c2j_node_A_const_352 any

var A_arbace_c2j_node_A_const_353 any

var A_arbace_c2j_node_A_const_354 any

var A_arbace_c2j_node_A_const_355 *lang.Var

var A_arbace_c2j_node_A_const_356 *lang.Keyword

var A_arbace_c2j_node_A_const_357 *lang.Var

var A_arbace_c2j_node_A_const_358 any

var A_arbace_c2j_node_A_const_359 any

var A_arbace_c2j_node_A_const_360 *lang.Keyword

var A_arbace_c2j_node_A_const_361 any

var A_arbace_c2j_node_A_const_362 any

var A_arbace_c2j_node_A_const_363 any

var A_arbace_c2j_node_A_const_364 any

var A_arbace_c2j_node_A_const_365 any

var A_arbace_c2j_node_A_const_366 *lang.Var

var A_arbace_c2j_node_A_const_367 any

var A_arbace_c2j_node_A_const_368 any

var A_arbace_c2j_node_A_const_369 any

var A_arbace_c2j_node_A_const_370 any

var A_arbace_c2j_node_A_const_371 any

var A_arbace_c2j_node_A_const_372 any

var A_arbace_c2j_node_A_const_373 any

var A_arbace_c2j_node_A_const_374 any

var A_arbace_c2j_node_A_const_375 any

var A_arbace_c2j_node_A_const_376 any

var A_arbace_c2j_node_A_const_377 any

var A_arbace_c2j_node_A_const_378 any

var A_arbace_c2j_node_A_const_379 any

var A_arbace_c2j_node_A_const_380 any

var A_arbace_c2j_node_A_const_381 any

var A_arbace_c2j_node_A_const_382 any

var A_arbace_c2j_node_A_const_383 any

var A_arbace_c2j_node_A_const_384 *lang.Keyword

var A_arbace_c2j_node_A_const_385 any

var A_arbace_c2j_node_A_const_386 any

var A_arbace_c2j_node_A_const_387 *lang.Keyword

var A_arbace_c2j_node_A_const_388 *lang.Keyword

var A_arbace_c2j_node_A_const_389 any

var A_arbace_c2j_node_A_const_390 any

var A_arbace_c2j_node_A_const_391 any

var A_arbace_c2j_node_A_const_392 any

var A_arbace_c2j_node_A_const_393 any

var A_arbace_c2j_node_A_const_394 *lang.Keyword

var A_arbace_c2j_node_A_const_395 *lang.Var

var A_arbace_c2j_node_A_const_396 *lang.Var

var A_arbace_c2j_node_A_const_397 *lang.Var

var A_arbace_c2j_node_A_const_398 any

var A_arbace_c2j_node_A_const_399 any

var A_arbace_c2j_node_A_const_400 *lang.Var

var A_arbace_c2j_node_A_const_401 *lang.Var

var A_arbace_c2j_node_A_const_402 *lang.Var

var A_arbace_c2j_node_A_const_403 *lang.Var

var A_arbace_c2j_node_A_const_404 *lang.Var

var A_arbace_c2j_node_A_const_405 *lang.Var

var A_arbace_c2j_node_A_const_406 *lang.Var

var A_arbace_c2j_node_A_const_407 any

var A_arbace_c2j_node_A_const_408 *lang.Keyword

var A_arbace_c2j_node_A_const_409 any

var A_arbace_c2j_node_A_const_410 *lang.Keyword

var A_arbace_c2j_node_A_const_411 any

var A_arbace_c2j_node_A_const_412 any

var A_arbace_c2j_node_A_const_413 *lang.Var

var A_arbace_c2j_node_A_const_414 *lang.Var

var A_arbace_c2j_node_A_const_415 *lang.Var

var A_arbace_c2j_node_A_const_416 *lang.Keyword

var A_arbace_c2j_node_A_const_417 any

var A_arbace_c2j_node_A_const_418 any

var A_arbace_c2j_node_A_const_419 any

var A_arbace_c2j_node_A_const_420 any

var A_arbace_c2j_node_A_const_421 any

var A_arbace_c2j_node_A_const_422 any

var A_arbace_c2j_node_A_const_423 any

var A_arbace_c2j_node_A_const_424 any

var A_arbace_c2j_node_A_const_425 any

var A_arbace_c2j_node_A_const_426 any

var A_arbace_c2j_node_A_const_427 any

var A_arbace_c2j_node_A_const_428 any

var A_arbace_c2j_node_A_const_429 any

var A_arbace_c2j_node_A_const_430 any

var A_arbace_c2j_node_A_const_431 any

var A_arbace_c2j_node_A_const_432 *lang.Var

var A_arbace_c2j_node_A_const_433 *lang.Var

var A_arbace_c2j_node_A_const_434 *lang.Var

var A_arbace_c2j_node_A_const_435 *lang.Var

var A_arbace_c2j_node_A_const_436 *lang.Var

var A_arbace_c2j_node_A_const_437 any

var A_arbace_c2j_node_A_const_438 any

var A_arbace_c2j_node_A_const_439 any

var A_arbace_c2j_node_A_const_440 any

var A_arbace_c2j_node_A_const_441 any

var A_arbace_c2j_node_A_const_442 any

var A_arbace_c2j_node_A_const_443 any

var A_arbace_c2j_node_A_const_444 any

var A_arbace_c2j_node_A_const_445 any

var A_arbace_c2j_node_A_const_446 any

var A_arbace_c2j_node_A_const_447 any

var A_arbace_c2j_node_A_const_448 any

var A_arbace_c2j_node_A_const_449 any

var A_arbace_c2j_node_A_const_450 any

var A_arbace_c2j_node_A_const_451 any

var A_arbace_c2j_node_A_const_452 any

var A_arbace_c2j_node_A_const_453 any

var A_arbace_c2j_node_A_const_454 any

var A_arbace_c2j_node_A_const_455 any

var A_arbace_c2j_node_A_const_456 any

var A_arbace_c2j_node_A_const_457 any

var A_arbace_c2j_node_A_const_458 any

var A_arbace_c2j_node_A_const_459 any

var A_arbace_c2j_node_A_const_460 *lang.Keyword

var A_arbace_c2j_node_A_const_461 any

var A_arbace_c2j_node_A_const_462 any

var A_arbace_c2j_node_A_const_463 any

var A_arbace_c2j_node_A_const_464 any

var A_arbace_c2j_node_A_const_465 any

var A_arbace_c2j_node_A_const_466 any

var A_arbace_c2j_node_A_const_467 any

var A_arbace_c2j_node_A_const_468 any

var A_arbace_c2j_node_A_const_469 any

var A_arbace_c2j_node_A_const_470 any

var A_arbace_c2j_node_A_const_471 *lang.Keyword

var A_arbace_c2j_node_A_const_472 *lang.Var

var A_arbace_c2j_node_A_const_473 *lang.Keyword

var A_arbace_c2j_node_A_const_474 *lang.Var

var A_arbace_c2j_node_A_const_475 *lang.Var

var A_arbace_c2j_node_A_const_476 *lang.Var

var A_arbace_c2j_node_A_const_477 *lang.Var

var A_arbace_c2j_node_A_const_478 *lang.Var

var A_arbace_c2j_node_A_const_479 any

var A_arbace_c2j_node_A_const_480 any

var A_arbace_c2j_node_A_const_481 any

var A_arbace_c2j_node_A_const_482 any

var A_arbace_c2j_node_A_const_483 any

var A_arbace_c2j_node_A_const_484 any

var A_arbace_c2j_node_A_const_485 any

var A_arbace_c2j_node_A_const_486 any

var A_arbace_c2j_node_A_const_487 any

var A_arbace_c2j_node_A_const_488 any

var A_arbace_c2j_node_A_const_489 any

var A_arbace_c2j_node_A_const_490 any

var A_arbace_c2j_node_A_const_491 any

var A_arbace_c2j_node_A_const_492 any

var A_arbace_c2j_node_A_const_493 any

var A_arbace_c2j_node_A_const_494 any

var A_arbace_c2j_node_A_const_495 any

var A_arbace_c2j_node_A_const_496 any

var A_arbace_c2j_node_A_const_497 any

var A_arbace_c2j_node_A_const_498 any

var A_arbace_c2j_node_A_const_499 any

var A_arbace_c2j_node_A_const_500 any

var A_arbace_c2j_node_A_const_501 any

var A_arbace_c2j_node_A_init jrt.ClassInit

func A_arbace_c2j_node_A_Init() { if !A_arbace_c2j_node_A_init.Done() { A_arbace_c2j_node_A_init.Run(A_arbace_c2j_node_A_clinit) } }

func A_arbace_c2j_node_A_clinit() { A_arbace_c2j_node_A_clinit_p0(); A_arbace_c2j_node_A_clinit_p1(); A_arbace_c2j_node_A_clinit_p2(); A_arbace_c2j_node_A_clinit_p3(); A_arbace_c2j_node_A_clinit_p4(); A_arbace_c2j_node_A_clinit_p5(); A_arbace_c2j_node_A_clinit_p6(); A_arbace_c2j_node_A_clinit_p7(); A_arbace_c2j_node_A_clinit_p8(); A_arbace_c2j_node_A_clinit_p9(); A_arbace_c2j_node_A_clinit_p10(); A_arbace_c2j_node_A_clinit_p11(); A_arbace_c2j_node_A_clinit_p12(); A_arbace_c2j_node_A_clinit_p13(); A_arbace_c2j_node_A_clinit_p14(); A_arbace_c2j_node_A_clinit_p15(); A_arbace_c2j_node_A_clinit_p16(); A_arbace_c2j_node_A_clinit_p17(); A_arbace_c2j_node_A_clinit_p18(); A_arbace_c2j_node_A_clinit_p19(); A_arbace_c2j_node_A_clinit_p20(); A_arbace_c2j_node_A_clinit_p21(); A_arbace_c2j_node_A_clinit_p22(); A_arbace_c2j_node_A_clinit_p23(); A_arbace_c2j_node_A_clinit_p24(); A_arbace_c2j_node_A_clinit_p25(); A_arbace_c2j_node_A_clinit_p26(); A_arbace_c2j_node_A_clinit_p27(); A_arbace_c2j_node_A_clinit_p28(); A_arbace_c2j_node_A_clinit_p29(); A_arbace_c2j_node_A_clinit_p30(); A_arbace_c2j_node_A_clinit_p31(); A_arbace_c2j_node_A_clinit_p32(); A_arbace_c2j_node_A_clinit_p33(); A_arbace_c2j_node_A_clinit_p34(); A_arbace_c2j_node_A_clinit_p35(); A_arbace_c2j_node_A_clinit_p36() }

func A_arbace_c2j_node_A_clinit_p0() { jrt.StartCheck(); A_arbace_c2j_node_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 701); A_arbace_c2j_node_A_const_0 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[199]); A_arbace_c2j_node_A_const_1 = A_arbace_c2j_node_A_const_pool.A[200]; A_arbace_c2j_node_A_const_2 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[201]); A_arbace_c2j_node_A_const_3 = A_arbace_c2j_node_A_const_pool.A[202]; A_arbace_c2j_node_A_const_4 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[203]); A_arbace_c2j_node_A_const_5 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[204]); A_arbace_c2j_node_A_const_6 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[205]); A_arbace_c2j_node_A_const_7 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[206]); A_arbace_c2j_node_A_const_8 = A_arbace_c2j_node_A_const_pool.A[207]; A_arbace_c2j_node_A_const_9 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[208]); A_arbace_c2j_node_A_const_10 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[209]); A_arbace_c2j_node_A_const_11 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[210]) }

func A_arbace_c2j_node_A_clinit_p1() { A_arbace_c2j_node_A_const_12 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[211]); A_arbace_c2j_node_A_const_13 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[212]); A_arbace_c2j_node_A_const_14 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[213]); A_arbace_c2j_node_A_const_15 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[214]); A_arbace_c2j_node_A_const_16 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[215]); A_arbace_c2j_node_A_const_17 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[216]); A_arbace_c2j_node_A_const_18 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[217]); A_arbace_c2j_node_A_const_19 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[218]); A_arbace_c2j_node_A_const_20 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[219]); A_arbace_c2j_node_A_const_21 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[220]); A_arbace_c2j_node_A_const_22 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[221]); A_arbace_c2j_node_A_const_23 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[222]) }

func A_arbace_c2j_node_A_clinit_p2() { A_arbace_c2j_node_A_const_24 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[223]); A_arbace_c2j_node_A_const_25 = A_arbace_c2j_node_A_const_pool.A[224]; A_arbace_c2j_node_A_const_26 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[225]); A_arbace_c2j_node_A_const_27 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[226]); A_arbace_c2j_node_A_const_28 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[227]); A_arbace_c2j_node_A_const_29 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[228]); A_arbace_c2j_node_A_const_30 = A_arbace_c2j_node_A_const_pool.A[229]; A_arbace_c2j_node_A_const_31 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[230]); A_arbace_c2j_node_A_const_32 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[231]); A_arbace_c2j_node_A_const_33 = A_arbace_c2j_node_A_const_pool.A[232]; A_arbace_c2j_node_A_const_34 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[233]); A_arbace_c2j_node_A_const_35 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[234]) }

func A_arbace_c2j_node_A_clinit_p3() { A_arbace_c2j_node_A_const_36 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[235]); A_arbace_c2j_node_A_const_37 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[236]); A_arbace_c2j_node_A_const_38 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[237]); A_arbace_c2j_node_A_const_39 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[238]); A_arbace_c2j_node_A_const_40 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[239]); A_arbace_c2j_node_A_const_41 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[240]); A_arbace_c2j_node_A_const_42 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[241]); A_arbace_c2j_node_A_const_43 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[242]); A_arbace_c2j_node_A_const_44 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[243]); A_arbace_c2j_node_A_const_45 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[244]); A_arbace_c2j_node_A_const_46 = A_arbace_c2j_node_A_const_pool.A[245]; A_arbace_c2j_node_A_const_47 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[246]) }

func A_arbace_c2j_node_A_clinit_p4() { A_arbace_c2j_node_A_const_48 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[247]); A_arbace_c2j_node_A_const_49 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[248]); A_arbace_c2j_node_A_const_50 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[249]); A_arbace_c2j_node_A_const_51 = A_arbace_c2j_node_A_const_pool.A[250]; A_arbace_c2j_node_A_const_52 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[251]); A_arbace_c2j_node_A_const_53 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[252]); A_arbace_c2j_node_A_const_54 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[253]); A_arbace_c2j_node_A_const_55 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[254]); A_arbace_c2j_node_A_const_56 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[255]); A_arbace_c2j_node_A_const_57 = A_arbace_c2j_node_A_const_pool.A[256]; A_arbace_c2j_node_A_const_58 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[257]); A_arbace_c2j_node_A_const_59 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[258]) }

func A_arbace_c2j_node_A_clinit_p5() { A_arbace_c2j_node_A_const_60 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[259]); A_arbace_c2j_node_A_const_61 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[260]); A_arbace_c2j_node_A_const_62 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[261]); A_arbace_c2j_node_A_const_63 = A_arbace_c2j_node_A_const_pool.A[262]; A_arbace_c2j_node_A_const_64 = A_arbace_c2j_node_A_const_pool.A[263]; A_arbace_c2j_node_A_const_65 = A_arbace_c2j_node_A_const_pool.A[264]; A_arbace_c2j_node_A_const_66 = A_arbace_c2j_node_A_const_pool.A[265]; A_arbace_c2j_node_A_const_67 = A_arbace_c2j_node_A_const_pool.A[266]; A_arbace_c2j_node_A_const_68 = A_arbace_c2j_node_A_const_pool.A[267]; A_arbace_c2j_node_A_const_69 = A_arbace_c2j_node_A_const_pool.A[268]; A_arbace_c2j_node_A_const_70 = A_arbace_c2j_node_A_const_pool.A[269]; A_arbace_c2j_node_A_const_71 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[270]); A_arbace_c2j_node_A_const_72 = A_arbace_c2j_node_A_const_pool.A[271]; A_arbace_c2j_node_A_const_73 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[272]) }

func A_arbace_c2j_node_A_clinit_p6() { A_arbace_c2j_node_A_const_74 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[273]); A_arbace_c2j_node_A_const_75 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[274]); A_arbace_c2j_node_A_const_76 = A_arbace_c2j_node_A_const_pool.A[275]; A_arbace_c2j_node_A_const_77 = A_arbace_c2j_node_A_const_pool.A[276]; A_arbace_c2j_node_A_const_78 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[277]); A_arbace_c2j_node_A_const_79 = A_arbace_c2j_node_A_const_pool.A[278]; A_arbace_c2j_node_A_const_80 = A_arbace_c2j_node_A_const_pool.A[279]; A_arbace_c2j_node_A_const_81 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[280]); A_arbace_c2j_node_A_const_82 = A_arbace_c2j_node_A_const_pool.A[281]; A_arbace_c2j_node_A_const_83 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[282]); A_arbace_c2j_node_A_const_84 = A_arbace_c2j_node_A_const_pool.A[283]; A_arbace_c2j_node_A_const_85 = A_arbace_c2j_node_A_const_pool.A[284]; A_arbace_c2j_node_A_const_86 = A_arbace_c2j_node_A_const_pool.A[285]; A_arbace_c2j_node_A_const_87 = A_arbace_c2j_node_A_const_pool.A[286] }

func A_arbace_c2j_node_A_clinit_p7() { A_arbace_c2j_node_A_const_88 = A_arbace_c2j_node_A_const_pool.A[287]; A_arbace_c2j_node_A_const_89 = A_arbace_c2j_node_A_const_pool.A[288]; A_arbace_c2j_node_A_const_90 = A_arbace_c2j_node_A_const_pool.A[289]; A_arbace_c2j_node_A_const_91 = A_arbace_c2j_node_A_const_pool.A[290]; A_arbace_c2j_node_A_const_92 = A_arbace_c2j_node_A_const_pool.A[291]; A_arbace_c2j_node_A_const_93 = A_arbace_c2j_node_A_const_pool.A[292]; A_arbace_c2j_node_A_const_94 = A_arbace_c2j_node_A_const_pool.A[293]; A_arbace_c2j_node_A_const_95 = A_arbace_c2j_node_A_const_pool.A[294]; A_arbace_c2j_node_A_const_96 = A_arbace_c2j_node_A_const_pool.A[295]; A_arbace_c2j_node_A_const_97 = A_arbace_c2j_node_A_const_pool.A[296]; A_arbace_c2j_node_A_const_98 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[297]); A_arbace_c2j_node_A_const_99 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[298]); A_arbace_c2j_node_A_const_100 = A_arbace_c2j_node_A_const_pool.A[299]; A_arbace_c2j_node_A_const_101 = A_arbace_c2j_node_A_const_pool.A[300]; A_arbace_c2j_node_A_const_102 = A_arbace_c2j_node_A_const_pool.A[301] }

func A_arbace_c2j_node_A_clinit_p8() { A_arbace_c2j_node_A_const_103 = A_arbace_c2j_node_A_const_pool.A[302]; A_arbace_c2j_node_A_const_104 = A_arbace_c2j_node_A_const_pool.A[303]; A_arbace_c2j_node_A_const_105 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[304]); A_arbace_c2j_node_A_const_106 = A_arbace_c2j_node_A_const_pool.A[305]; A_arbace_c2j_node_A_const_107 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[306]); A_arbace_c2j_node_A_const_108 = A_arbace_c2j_node_A_const_pool.A[307]; A_arbace_c2j_node_A_const_109 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[308]); A_arbace_c2j_node_A_const_110 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[309]); A_arbace_c2j_node_A_const_111 = A_arbace_c2j_node_A_const_pool.A[310]; A_arbace_c2j_node_A_const_112 = A_arbace_c2j_node_A_const_pool.A[311]; A_arbace_c2j_node_A_const_113 = A_arbace_c2j_node_A_const_pool.A[312]; A_arbace_c2j_node_A_const_114 = A_arbace_c2j_node_A_const_pool.A[313]; A_arbace_c2j_node_A_const_115 = A_arbace_c2j_node_A_const_pool.A[314]; A_arbace_c2j_node_A_const_116 = A_arbace_c2j_node_A_const_pool.A[315] }

func A_arbace_c2j_node_A_clinit_p9() { A_arbace_c2j_node_A_const_117 = A_arbace_c2j_node_A_const_pool.A[316]; A_arbace_c2j_node_A_const_118 = A_arbace_c2j_node_A_const_pool.A[317]; A_arbace_c2j_node_A_const_119 = A_arbace_c2j_node_A_const_pool.A[318]; A_arbace_c2j_node_A_const_120 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[319]); A_arbace_c2j_node_A_const_121 = A_arbace_c2j_node_A_const_pool.A[320]; A_arbace_c2j_node_A_const_122 = A_arbace_c2j_node_A_const_pool.A[321]; A_arbace_c2j_node_A_const_123 = A_arbace_c2j_node_A_const_pool.A[322]; A_arbace_c2j_node_A_const_124 = A_arbace_c2j_node_A_const_pool.A[323]; A_arbace_c2j_node_A_const_125 = A_arbace_c2j_node_A_const_pool.A[324]; A_arbace_c2j_node_A_const_126 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[325]); A_arbace_c2j_node_A_const_127 = A_arbace_c2j_node_A_const_pool.A[326]; A_arbace_c2j_node_A_const_128 = A_arbace_c2j_node_A_const_pool.A[327]; A_arbace_c2j_node_A_const_129 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[328]); A_arbace_c2j_node_A_const_130 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[329]) }

func A_arbace_c2j_node_A_clinit_p10() { A_arbace_c2j_node_A_const_131 = A_arbace_c2j_node_A_const_pool.A[330]; A_arbace_c2j_node_A_const_132 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[331]); A_arbace_c2j_node_A_const_133 = A_arbace_c2j_node_A_const_pool.A[332]; A_arbace_c2j_node_A_const_134 = A_arbace_c2j_node_A_const_pool.A[333]; A_arbace_c2j_node_A_const_135 = A_arbace_c2j_node_A_const_pool.A[334]; A_arbace_c2j_node_A_const_136 = A_arbace_c2j_node_A_const_pool.A[335]; A_arbace_c2j_node_A_const_137 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[336]); A_arbace_c2j_node_A_const_138 = A_arbace_c2j_node_A_const_pool.A[337]; A_arbace_c2j_node_A_const_139 = A_arbace_c2j_node_A_const_pool.A[338]; A_arbace_c2j_node_A_const_140 = A_arbace_c2j_node_A_const_pool.A[339]; A_arbace_c2j_node_A_const_141 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[340]); A_arbace_c2j_node_A_const_142 = A_arbace_c2j_node_A_const_pool.A[341]; A_arbace_c2j_node_A_const_143 = A_arbace_c2j_node_A_const_pool.A[342]; A_arbace_c2j_node_A_const_144 = A_arbace_c2j_node_A_const_pool.A[343]; A_arbace_c2j_node_A_const_145 = A_arbace_c2j_node_A_const_pool.A[344] }

func A_arbace_c2j_node_A_clinit_p11() { A_arbace_c2j_node_A_const_146 = A_arbace_c2j_node_A_const_pool.A[345]; A_arbace_c2j_node_A_const_147 = A_arbace_c2j_node_A_const_pool.A[346]; A_arbace_c2j_node_A_const_148 = A_arbace_c2j_node_A_const_pool.A[347]; A_arbace_c2j_node_A_const_149 = A_arbace_c2j_node_A_const_pool.A[348]; A_arbace_c2j_node_A_const_150 = A_arbace_c2j_node_A_const_pool.A[349]; A_arbace_c2j_node_A_const_151 = A_arbace_c2j_node_A_const_pool.A[350]; A_arbace_c2j_node_A_const_152 = A_arbace_c2j_node_A_const_pool.A[351]; A_arbace_c2j_node_A_const_153 = A_arbace_c2j_node_A_const_pool.A[352]; A_arbace_c2j_node_A_const_154 = A_arbace_c2j_node_A_const_pool.A[353]; A_arbace_c2j_node_A_const_155 = A_arbace_c2j_node_A_const_pool.A[354]; A_arbace_c2j_node_A_const_156 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[355]); A_arbace_c2j_node_A_const_157 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[356]); A_arbace_c2j_node_A_const_158 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[357]); A_arbace_c2j_node_A_const_159 = A_arbace_c2j_node_A_const_pool.A[358]; A_arbace_c2j_node_A_const_160 = A_arbace_c2j_node_A_const_pool.A[359] }

func A_arbace_c2j_node_A_clinit_p12() { A_arbace_c2j_node_A_const_161 = A_arbace_c2j_node_A_const_pool.A[360]; A_arbace_c2j_node_A_const_162 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[361]); A_arbace_c2j_node_A_const_163 = A_arbace_c2j_node_A_const_pool.A[362]; A_arbace_c2j_node_A_const_164 = A_arbace_c2j_node_A_const_pool.A[363]; A_arbace_c2j_node_A_const_165 = A_arbace_c2j_node_A_const_pool.A[364]; A_arbace_c2j_node_A_const_166 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[365]); A_arbace_c2j_node_A_const_167 = A_arbace_c2j_node_A_const_pool.A[366]; A_arbace_c2j_node_A_const_168 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[367]); A_arbace_c2j_node_A_const_169 = A_arbace_c2j_node_A_const_pool.A[368]; A_arbace_c2j_node_A_const_170 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[369]); A_arbace_c2j_node_A_const_171 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[370]); A_arbace_c2j_node_A_const_172 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[371]); A_arbace_c2j_node_A_const_173 = A_arbace_c2j_node_A_const_pool.A[372]; A_arbace_c2j_node_A_const_174 = A_arbace_c2j_node_A_const_pool.A[373] }

func A_arbace_c2j_node_A_clinit_p13() { A_arbace_c2j_node_A_const_175 = A_arbace_c2j_node_A_const_pool.A[374]; A_arbace_c2j_node_A_const_176 = A_arbace_c2j_node_A_const_pool.A[375]; A_arbace_c2j_node_A_const_177 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[376]); A_arbace_c2j_node_A_const_178 = A_arbace_c2j_node_A_const_pool.A[377]; A_arbace_c2j_node_A_const_179 = A_arbace_c2j_node_A_const_pool.A[378]; A_arbace_c2j_node_A_const_180 = A_arbace_c2j_node_A_const_pool.A[379]; A_arbace_c2j_node_A_const_181 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[380]); A_arbace_c2j_node_A_const_182 = A_arbace_c2j_node_A_const_pool.A[381]; A_arbace_c2j_node_A_const_183 = A_arbace_c2j_node_A_const_pool.A[382]; A_arbace_c2j_node_A_const_184 = A_arbace_c2j_node_A_const_pool.A[383]; A_arbace_c2j_node_A_const_185 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[384]); A_arbace_c2j_node_A_const_186 = A_arbace_c2j_node_A_const_pool.A[385]; A_arbace_c2j_node_A_const_187 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[386]); A_arbace_c2j_node_A_const_188 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[387]) }

func A_arbace_c2j_node_A_clinit_p14() { A_arbace_c2j_node_A_const_189 = A_arbace_c2j_node_A_const_pool.A[388]; A_arbace_c2j_node_A_const_190 = A_arbace_c2j_node_A_const_pool.A[389]; A_arbace_c2j_node_A_const_191 = A_arbace_c2j_node_A_const_pool.A[390]; A_arbace_c2j_node_A_const_192 = A_arbace_c2j_node_A_const_pool.A[391]; A_arbace_c2j_node_A_const_193 = A_arbace_c2j_node_A_const_pool.A[392]; A_arbace_c2j_node_A_const_194 = A_arbace_c2j_node_A_const_pool.A[393]; A_arbace_c2j_node_A_const_195 = A_arbace_c2j_node_A_const_pool.A[394]; A_arbace_c2j_node_A_const_196 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[395]); A_arbace_c2j_node_A_const_197 = A_arbace_c2j_node_A_const_pool.A[396]; A_arbace_c2j_node_A_const_198 = A_arbace_c2j_node_A_const_pool.A[397]; A_arbace_c2j_node_A_const_199 = A_arbace_c2j_node_A_const_pool.A[398]; A_arbace_c2j_node_A_const_200 = A_arbace_c2j_node_A_const_pool.A[399]; A_arbace_c2j_node_A_const_201 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[400]); A_arbace_c2j_node_A_const_202 = A_arbace_c2j_node_A_const_pool.A[401]; A_arbace_c2j_node_A_const_203 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[402]) }

func A_arbace_c2j_node_A_clinit_p15() { A_arbace_c2j_node_A_const_204 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[403]); A_arbace_c2j_node_A_const_205 = A_arbace_c2j_node_A_const_pool.A[404]; A_arbace_c2j_node_A_const_206 = A_arbace_c2j_node_A_const_pool.A[405]; A_arbace_c2j_node_A_const_207 = A_arbace_c2j_node_A_const_pool.A[406]; A_arbace_c2j_node_A_const_208 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[407]); A_arbace_c2j_node_A_const_209 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[408]); A_arbace_c2j_node_A_const_210 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[409]); A_arbace_c2j_node_A_const_211 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[410]); A_arbace_c2j_node_A_const_212 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[411]); A_arbace_c2j_node_A_const_213 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[412]); A_arbace_c2j_node_A_const_214 = A_arbace_c2j_node_A_const_pool.A[413]; A_arbace_c2j_node_A_const_215 = A_arbace_c2j_node_A_const_pool.A[414]; A_arbace_c2j_node_A_const_216 = A_arbace_c2j_node_A_const_pool.A[415] }

func A_arbace_c2j_node_A_clinit_p16() { A_arbace_c2j_node_A_const_217 = A_arbace_c2j_node_A_const_pool.A[416]; A_arbace_c2j_node_A_const_218 = A_arbace_c2j_node_A_const_pool.A[417]; A_arbace_c2j_node_A_const_219 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[418]); A_arbace_c2j_node_A_const_220 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[419]); A_arbace_c2j_node_A_const_221 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[420]); A_arbace_c2j_node_A_const_222 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[421]); A_arbace_c2j_node_A_const_223 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[422]); A_arbace_c2j_node_A_const_224 = A_arbace_c2j_node_A_const_pool.A[423]; A_arbace_c2j_node_A_const_225 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[424]); A_arbace_c2j_node_A_const_226 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[425]); A_arbace_c2j_node_A_const_227 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[426]); A_arbace_c2j_node_A_const_228 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[427]); A_arbace_c2j_node_A_const_229 = A_arbace_c2j_node_A_const_pool.A[428] }

func A_arbace_c2j_node_A_clinit_p17() { A_arbace_c2j_node_A_const_230 = A_arbace_c2j_node_A_const_pool.A[429]; A_arbace_c2j_node_A_const_231 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[430]); A_arbace_c2j_node_A_const_232 = A_arbace_c2j_node_A_const_pool.A[431]; A_arbace_c2j_node_A_const_233 = A_arbace_c2j_node_A_const_pool.A[432]; A_arbace_c2j_node_A_const_234 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[433]); A_arbace_c2j_node_A_const_235 = A_arbace_c2j_node_A_const_pool.A[434]; A_arbace_c2j_node_A_const_236 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[435]); A_arbace_c2j_node_A_const_237 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[436]); A_arbace_c2j_node_A_const_238 = A_arbace_c2j_node_A_const_pool.A[437]; A_arbace_c2j_node_A_const_239 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[438]); A_arbace_c2j_node_A_const_240 = A_arbace_c2j_node_A_const_pool.A[439]; A_arbace_c2j_node_A_const_241 = A_arbace_c2j_node_A_const_pool.A[440]; A_arbace_c2j_node_A_const_242 = A_arbace_c2j_node_A_const_pool.A[441]; A_arbace_c2j_node_A_const_243 = A_arbace_c2j_node_A_const_pool.A[442] }

func A_arbace_c2j_node_A_clinit_p18() { A_arbace_c2j_node_A_const_244 = A_arbace_c2j_node_A_const_pool.A[443]; A_arbace_c2j_node_A_const_245 = A_arbace_c2j_node_A_const_pool.A[444]; A_arbace_c2j_node_A_const_246 = A_arbace_c2j_node_A_const_pool.A[445]; A_arbace_c2j_node_A_const_247 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[446]); A_arbace_c2j_node_A_const_248 = A_arbace_c2j_node_A_const_pool.A[447]; A_arbace_c2j_node_A_const_249 = A_arbace_c2j_node_A_const_pool.A[448]; A_arbace_c2j_node_A_const_250 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[449]); A_arbace_c2j_node_A_const_251 = A_arbace_c2j_node_A_const_pool.A[450]; A_arbace_c2j_node_A_const_252 = A_arbace_c2j_node_A_const_pool.A[451]; A_arbace_c2j_node_A_const_253 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[452]); A_arbace_c2j_node_A_const_254 = A_arbace_c2j_node_A_const_pool.A[453]; A_arbace_c2j_node_A_const_255 = A_arbace_c2j_node_A_const_pool.A[454]; A_arbace_c2j_node_A_const_256 = A_arbace_c2j_node_A_const_pool.A[455]; A_arbace_c2j_node_A_const_257 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[456]) }

func A_arbace_c2j_node_A_clinit_p19() { A_arbace_c2j_node_A_const_258 = A_arbace_c2j_node_A_const_pool.A[457]; A_arbace_c2j_node_A_const_259 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[458]); A_arbace_c2j_node_A_const_260 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[459]); A_arbace_c2j_node_A_const_261 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[460]); A_arbace_c2j_node_A_const_262 = A_arbace_c2j_node_A_const_pool.A[461]; A_arbace_c2j_node_A_const_263 = A_arbace_c2j_node_A_const_pool.A[462]; A_arbace_c2j_node_A_const_264 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[463]); A_arbace_c2j_node_A_const_265 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[464]); A_arbace_c2j_node_A_const_266 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[465]); A_arbace_c2j_node_A_const_267 = A_arbace_c2j_node_A_const_pool.A[466]; A_arbace_c2j_node_A_const_268 = A_arbace_c2j_node_A_const_pool.A[467]; A_arbace_c2j_node_A_const_269 = A_arbace_c2j_node_A_const_pool.A[468]; A_arbace_c2j_node_A_const_270 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[469]) }

func A_arbace_c2j_node_A_clinit_p20() { A_arbace_c2j_node_A_const_271 = A_arbace_c2j_node_A_const_pool.A[470]; A_arbace_c2j_node_A_const_272 = A_arbace_c2j_node_A_const_pool.A[471]; A_arbace_c2j_node_A_const_273 = A_arbace_c2j_node_A_const_pool.A[472]; A_arbace_c2j_node_A_const_274 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[473]); A_arbace_c2j_node_A_const_275 = A_arbace_c2j_node_A_const_pool.A[474]; A_arbace_c2j_node_A_const_276 = A_arbace_c2j_node_A_const_pool.A[475]; A_arbace_c2j_node_A_const_277 = A_arbace_c2j_node_A_const_pool.A[476]; A_arbace_c2j_node_A_const_278 = A_arbace_c2j_node_A_const_pool.A[477]; A_arbace_c2j_node_A_const_279 = A_arbace_c2j_node_A_const_pool.A[478]; A_arbace_c2j_node_A_const_280 = A_arbace_c2j_node_A_const_pool.A[479]; A_arbace_c2j_node_A_const_281 = A_arbace_c2j_node_A_const_pool.A[480]; A_arbace_c2j_node_A_const_282 = A_arbace_c2j_node_A_const_pool.A[481]; A_arbace_c2j_node_A_const_283 = A_arbace_c2j_node_A_const_pool.A[482]; A_arbace_c2j_node_A_const_284 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[483]); A_arbace_c2j_node_A_const_285 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[484]) }

func A_arbace_c2j_node_A_clinit_p21() { A_arbace_c2j_node_A_const_286 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[485]); A_arbace_c2j_node_A_const_287 = A_arbace_c2j_node_A_const_pool.A[486]; A_arbace_c2j_node_A_const_288 = A_arbace_c2j_node_A_const_pool.A[487]; A_arbace_c2j_node_A_const_289 = A_arbace_c2j_node_A_const_pool.A[488]; A_arbace_c2j_node_A_const_290 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[489]); A_arbace_c2j_node_A_const_291 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[490]); A_arbace_c2j_node_A_const_292 = A_arbace_c2j_node_A_const_pool.A[491]; A_arbace_c2j_node_A_const_293 = A_arbace_c2j_node_A_const_pool.A[492]; A_arbace_c2j_node_A_const_294 = A_arbace_c2j_node_A_const_pool.A[493]; A_arbace_c2j_node_A_const_295 = A_arbace_c2j_node_A_const_pool.A[494]; A_arbace_c2j_node_A_const_296 = A_arbace_c2j_node_A_const_pool.A[495]; A_arbace_c2j_node_A_const_297 = A_arbace_c2j_node_A_const_pool.A[496]; A_arbace_c2j_node_A_const_298 = A_arbace_c2j_node_A_const_pool.A[497]; A_arbace_c2j_node_A_const_299 = A_arbace_c2j_node_A_const_pool.A[498]; A_arbace_c2j_node_A_const_300 = A_arbace_c2j_node_A_const_pool.A[499] }

func A_arbace_c2j_node_A_clinit_p22() { A_arbace_c2j_node_A_const_301 = A_arbace_c2j_node_A_const_pool.A[500]; A_arbace_c2j_node_A_const_302 = A_arbace_c2j_node_A_const_pool.A[501]; A_arbace_c2j_node_A_const_303 = A_arbace_c2j_node_A_const_pool.A[502]; A_arbace_c2j_node_A_const_304 = A_arbace_c2j_node_A_const_pool.A[503]; A_arbace_c2j_node_A_const_305 = jrt.Class_Cast(A_arbace_c2j_node_A_const_pool.A[504]); A_arbace_c2j_node_A_const_306 = A_arbace_c2j_node_A_const_pool.A[505]; A_arbace_c2j_node_A_const_307 = A_arbace_c2j_node_A_const_pool.A[506]; A_arbace_c2j_node_A_const_308 = A_arbace_c2j_node_A_const_pool.A[507]; A_arbace_c2j_node_A_const_309 = A_arbace_c2j_node_A_const_pool.A[508]; A_arbace_c2j_node_A_const_310 = A_arbace_c2j_node_A_const_pool.A[509]; A_arbace_c2j_node_A_const_311 = A_arbace_c2j_node_A_const_pool.A[510]; A_arbace_c2j_node_A_const_312 = A_arbace_c2j_node_A_const_pool.A[511]; A_arbace_c2j_node_A_const_313 = A_arbace_c2j_node_A_const_pool.A[512]; A_arbace_c2j_node_A_const_314 = A_arbace_c2j_node_A_const_pool.A[513]; A_arbace_c2j_node_A_const_315 = A_arbace_c2j_node_A_const_pool.A[514] }

func A_arbace_c2j_node_A_clinit_p23() { A_arbace_c2j_node_A_const_316 = A_arbace_c2j_node_A_const_pool.A[515]; A_arbace_c2j_node_A_const_317 = A_arbace_c2j_node_A_const_pool.A[516]; A_arbace_c2j_node_A_const_318 = A_arbace_c2j_node_A_const_pool.A[517]; A_arbace_c2j_node_A_const_319 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[518]); A_arbace_c2j_node_A_const_320 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[519]); A_arbace_c2j_node_A_const_321 = A_arbace_c2j_node_A_const_pool.A[520]; A_arbace_c2j_node_A_const_322 = A_arbace_c2j_node_A_const_pool.A[521]; A_arbace_c2j_node_A_const_323 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[522]); A_arbace_c2j_node_A_const_324 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[523]); A_arbace_c2j_node_A_const_325 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[524]); A_arbace_c2j_node_A_const_326 = A_arbace_c2j_node_A_const_pool.A[525]; A_arbace_c2j_node_A_const_327 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[526]); A_arbace_c2j_node_A_const_328 = A_arbace_c2j_node_A_const_pool.A[527] }

func A_arbace_c2j_node_A_clinit_p24() { A_arbace_c2j_node_A_const_329 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[528]); A_arbace_c2j_node_A_const_330 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[529]); A_arbace_c2j_node_A_const_331 = A_arbace_c2j_node_A_const_pool.A[530]; A_arbace_c2j_node_A_const_332 = A_arbace_c2j_node_A_const_pool.A[531]; A_arbace_c2j_node_A_const_333 = A_arbace_c2j_node_A_const_pool.A[532]; A_arbace_c2j_node_A_const_334 = A_arbace_c2j_node_A_const_pool.A[533]; A_arbace_c2j_node_A_const_335 = A_arbace_c2j_node_A_const_pool.A[534]; A_arbace_c2j_node_A_const_336 = A_arbace_c2j_node_A_const_pool.A[535]; A_arbace_c2j_node_A_const_337 = A_arbace_c2j_node_A_const_pool.A[536]; A_arbace_c2j_node_A_const_338 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[537]); A_arbace_c2j_node_A_const_339 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[538]); A_arbace_c2j_node_A_const_340 = A_arbace_c2j_node_A_const_pool.A[539]; A_arbace_c2j_node_A_const_341 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[540]); A_arbace_c2j_node_A_const_342 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[541]) }

func A_arbace_c2j_node_A_clinit_p25() { A_arbace_c2j_node_A_const_343 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[542]); A_arbace_c2j_node_A_const_344 = A_arbace_c2j_node_A_const_pool.A[543]; A_arbace_c2j_node_A_const_345 = A_arbace_c2j_node_A_const_pool.A[544]; A_arbace_c2j_node_A_const_346 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[545]); A_arbace_c2j_node_A_const_347 = A_arbace_c2j_node_A_const_pool.A[546]; A_arbace_c2j_node_A_const_348 = A_arbace_c2j_node_A_const_pool.A[547]; A_arbace_c2j_node_A_const_349 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[548]); A_arbace_c2j_node_A_const_350 = A_arbace_c2j_node_A_const_pool.A[549]; A_arbace_c2j_node_A_const_351 = A_arbace_c2j_node_A_const_pool.A[550]; A_arbace_c2j_node_A_const_352 = A_arbace_c2j_node_A_const_pool.A[551]; A_arbace_c2j_node_A_const_353 = A_arbace_c2j_node_A_const_pool.A[552]; A_arbace_c2j_node_A_const_354 = A_arbace_c2j_node_A_const_pool.A[553]; A_arbace_c2j_node_A_const_355 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[554]); A_arbace_c2j_node_A_const_356 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[555]) }

func A_arbace_c2j_node_A_clinit_p26() { A_arbace_c2j_node_A_const_357 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[556]); A_arbace_c2j_node_A_const_358 = A_arbace_c2j_node_A_const_pool.A[557]; A_arbace_c2j_node_A_const_359 = A_arbace_c2j_node_A_const_pool.A[558]; A_arbace_c2j_node_A_const_360 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[559]); A_arbace_c2j_node_A_const_361 = A_arbace_c2j_node_A_const_pool.A[560]; A_arbace_c2j_node_A_const_362 = A_arbace_c2j_node_A_const_pool.A[561]; A_arbace_c2j_node_A_const_363 = A_arbace_c2j_node_A_const_pool.A[562]; A_arbace_c2j_node_A_const_364 = A_arbace_c2j_node_A_const_pool.A[563]; A_arbace_c2j_node_A_const_365 = A_arbace_c2j_node_A_const_pool.A[564]; A_arbace_c2j_node_A_const_366 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[565]); A_arbace_c2j_node_A_const_367 = A_arbace_c2j_node_A_const_pool.A[566]; A_arbace_c2j_node_A_const_368 = A_arbace_c2j_node_A_const_pool.A[567]; A_arbace_c2j_node_A_const_369 = A_arbace_c2j_node_A_const_pool.A[568]; A_arbace_c2j_node_A_const_370 = A_arbace_c2j_node_A_const_pool.A[569]; A_arbace_c2j_node_A_const_371 = A_arbace_c2j_node_A_const_pool.A[570] }

func A_arbace_c2j_node_A_clinit_p27() { A_arbace_c2j_node_A_const_372 = A_arbace_c2j_node_A_const_pool.A[571]; A_arbace_c2j_node_A_const_373 = A_arbace_c2j_node_A_const_pool.A[572]; A_arbace_c2j_node_A_const_374 = A_arbace_c2j_node_A_const_pool.A[573]; A_arbace_c2j_node_A_const_375 = A_arbace_c2j_node_A_const_pool.A[574]; A_arbace_c2j_node_A_const_376 = A_arbace_c2j_node_A_const_pool.A[575]; A_arbace_c2j_node_A_const_377 = A_arbace_c2j_node_A_const_pool.A[576]; A_arbace_c2j_node_A_const_378 = A_arbace_c2j_node_A_const_pool.A[577]; A_arbace_c2j_node_A_const_379 = A_arbace_c2j_node_A_const_pool.A[578]; A_arbace_c2j_node_A_const_380 = A_arbace_c2j_node_A_const_pool.A[579]; A_arbace_c2j_node_A_const_381 = A_arbace_c2j_node_A_const_pool.A[580]; A_arbace_c2j_node_A_const_382 = A_arbace_c2j_node_A_const_pool.A[581]; A_arbace_c2j_node_A_const_383 = A_arbace_c2j_node_A_const_pool.A[582]; A_arbace_c2j_node_A_const_384 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[583]); A_arbace_c2j_node_A_const_385 = A_arbace_c2j_node_A_const_pool.A[584]; A_arbace_c2j_node_A_const_386 = A_arbace_c2j_node_A_const_pool.A[585] }

func A_arbace_c2j_node_A_clinit_p28() { A_arbace_c2j_node_A_const_387 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[586]); A_arbace_c2j_node_A_const_388 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[587]); A_arbace_c2j_node_A_const_389 = A_arbace_c2j_node_A_const_pool.A[588]; A_arbace_c2j_node_A_const_390 = A_arbace_c2j_node_A_const_pool.A[589]; A_arbace_c2j_node_A_const_391 = A_arbace_c2j_node_A_const_pool.A[590]; A_arbace_c2j_node_A_const_392 = A_arbace_c2j_node_A_const_pool.A[591]; A_arbace_c2j_node_A_const_393 = A_arbace_c2j_node_A_const_pool.A[592]; A_arbace_c2j_node_A_const_394 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[593]); A_arbace_c2j_node_A_const_395 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[594]); A_arbace_c2j_node_A_const_396 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[595]); A_arbace_c2j_node_A_const_397 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[596]); A_arbace_c2j_node_A_const_398 = A_arbace_c2j_node_A_const_pool.A[597]; A_arbace_c2j_node_A_const_399 = A_arbace_c2j_node_A_const_pool.A[598] }

func A_arbace_c2j_node_A_clinit_p29() { A_arbace_c2j_node_A_const_400 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[599]); A_arbace_c2j_node_A_const_401 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[600]); A_arbace_c2j_node_A_const_402 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[601]); A_arbace_c2j_node_A_const_403 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[602]); A_arbace_c2j_node_A_const_404 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[603]); A_arbace_c2j_node_A_const_405 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[604]); A_arbace_c2j_node_A_const_406 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[605]); A_arbace_c2j_node_A_const_407 = A_arbace_c2j_node_A_const_pool.A[606]; A_arbace_c2j_node_A_const_408 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[607]); A_arbace_c2j_node_A_const_409 = A_arbace_c2j_node_A_const_pool.A[608]; A_arbace_c2j_node_A_const_410 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[609]); A_arbace_c2j_node_A_const_411 = A_arbace_c2j_node_A_const_pool.A[610]; A_arbace_c2j_node_A_const_412 = A_arbace_c2j_node_A_const_pool.A[611] }

func A_arbace_c2j_node_A_clinit_p30() { A_arbace_c2j_node_A_const_413 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[612]); A_arbace_c2j_node_A_const_414 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[613]); A_arbace_c2j_node_A_const_415 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[614]); A_arbace_c2j_node_A_const_416 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[615]); A_arbace_c2j_node_A_const_417 = A_arbace_c2j_node_A_const_pool.A[616]; A_arbace_c2j_node_A_const_418 = A_arbace_c2j_node_A_const_pool.A[617]; A_arbace_c2j_node_A_const_419 = A_arbace_c2j_node_A_const_pool.A[618]; A_arbace_c2j_node_A_const_420 = A_arbace_c2j_node_A_const_pool.A[619]; A_arbace_c2j_node_A_const_421 = A_arbace_c2j_node_A_const_pool.A[620]; A_arbace_c2j_node_A_const_422 = A_arbace_c2j_node_A_const_pool.A[621]; A_arbace_c2j_node_A_const_423 = A_arbace_c2j_node_A_const_pool.A[622]; A_arbace_c2j_node_A_const_424 = A_arbace_c2j_node_A_const_pool.A[623]; A_arbace_c2j_node_A_const_425 = A_arbace_c2j_node_A_const_pool.A[624]; A_arbace_c2j_node_A_const_426 = A_arbace_c2j_node_A_const_pool.A[625] }

func A_arbace_c2j_node_A_clinit_p31() { A_arbace_c2j_node_A_const_427 = A_arbace_c2j_node_A_const_pool.A[626]; A_arbace_c2j_node_A_const_428 = A_arbace_c2j_node_A_const_pool.A[627]; A_arbace_c2j_node_A_const_429 = A_arbace_c2j_node_A_const_pool.A[628]; A_arbace_c2j_node_A_const_430 = A_arbace_c2j_node_A_const_pool.A[629]; A_arbace_c2j_node_A_const_431 = A_arbace_c2j_node_A_const_pool.A[630]; A_arbace_c2j_node_A_const_432 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[631]); A_arbace_c2j_node_A_const_433 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[632]); A_arbace_c2j_node_A_const_434 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[633]); A_arbace_c2j_node_A_const_435 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[634]); A_arbace_c2j_node_A_const_436 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[635]); A_arbace_c2j_node_A_const_437 = A_arbace_c2j_node_A_const_pool.A[636]; A_arbace_c2j_node_A_const_438 = A_arbace_c2j_node_A_const_pool.A[637]; A_arbace_c2j_node_A_const_439 = A_arbace_c2j_node_A_const_pool.A[638]; A_arbace_c2j_node_A_const_440 = A_arbace_c2j_node_A_const_pool.A[639] }

func A_arbace_c2j_node_A_clinit_p32() { A_arbace_c2j_node_A_const_441 = A_arbace_c2j_node_A_const_pool.A[640]; A_arbace_c2j_node_A_const_442 = A_arbace_c2j_node_A_const_pool.A[641]; A_arbace_c2j_node_A_const_443 = A_arbace_c2j_node_A_const_pool.A[642]; A_arbace_c2j_node_A_const_444 = A_arbace_c2j_node_A_const_pool.A[643]; A_arbace_c2j_node_A_const_445 = A_arbace_c2j_node_A_const_pool.A[644]; A_arbace_c2j_node_A_const_446 = A_arbace_c2j_node_A_const_pool.A[645]; A_arbace_c2j_node_A_const_447 = A_arbace_c2j_node_A_const_pool.A[646]; A_arbace_c2j_node_A_const_448 = A_arbace_c2j_node_A_const_pool.A[647]; A_arbace_c2j_node_A_const_449 = A_arbace_c2j_node_A_const_pool.A[648]; A_arbace_c2j_node_A_const_450 = A_arbace_c2j_node_A_const_pool.A[649]; A_arbace_c2j_node_A_const_451 = A_arbace_c2j_node_A_const_pool.A[650]; A_arbace_c2j_node_A_const_452 = A_arbace_c2j_node_A_const_pool.A[651]; A_arbace_c2j_node_A_const_453 = A_arbace_c2j_node_A_const_pool.A[652]; A_arbace_c2j_node_A_const_454 = A_arbace_c2j_node_A_const_pool.A[653]; A_arbace_c2j_node_A_const_455 = A_arbace_c2j_node_A_const_pool.A[654]; A_arbace_c2j_node_A_const_456 = A_arbace_c2j_node_A_const_pool.A[655] }

func A_arbace_c2j_node_A_clinit_p33() { A_arbace_c2j_node_A_const_457 = A_arbace_c2j_node_A_const_pool.A[656]; A_arbace_c2j_node_A_const_458 = A_arbace_c2j_node_A_const_pool.A[657]; A_arbace_c2j_node_A_const_459 = A_arbace_c2j_node_A_const_pool.A[658]; A_arbace_c2j_node_A_const_460 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[659]); A_arbace_c2j_node_A_const_461 = A_arbace_c2j_node_A_const_pool.A[660]; A_arbace_c2j_node_A_const_462 = A_arbace_c2j_node_A_const_pool.A[661]; A_arbace_c2j_node_A_const_463 = A_arbace_c2j_node_A_const_pool.A[662]; A_arbace_c2j_node_A_const_464 = A_arbace_c2j_node_A_const_pool.A[663]; A_arbace_c2j_node_A_const_465 = A_arbace_c2j_node_A_const_pool.A[664]; A_arbace_c2j_node_A_const_466 = A_arbace_c2j_node_A_const_pool.A[665]; A_arbace_c2j_node_A_const_467 = A_arbace_c2j_node_A_const_pool.A[666]; A_arbace_c2j_node_A_const_468 = A_arbace_c2j_node_A_const_pool.A[667]; A_arbace_c2j_node_A_const_469 = A_arbace_c2j_node_A_const_pool.A[668]; A_arbace_c2j_node_A_const_470 = A_arbace_c2j_node_A_const_pool.A[669]; A_arbace_c2j_node_A_const_471 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[670]) }

func A_arbace_c2j_node_A_clinit_p34() { A_arbace_c2j_node_A_const_472 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[671]); A_arbace_c2j_node_A_const_473 = lang.Keyword_Cast(A_arbace_c2j_node_A_const_pool.A[672]); A_arbace_c2j_node_A_const_474 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[673]); A_arbace_c2j_node_A_const_475 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[674]); A_arbace_c2j_node_A_const_476 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[675]); A_arbace_c2j_node_A_const_477 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[676]); A_arbace_c2j_node_A_const_478 = lang.Var_Cast(A_arbace_c2j_node_A_const_pool.A[677]); A_arbace_c2j_node_A_const_479 = A_arbace_c2j_node_A_const_pool.A[678]; A_arbace_c2j_node_A_const_480 = A_arbace_c2j_node_A_const_pool.A[679]; A_arbace_c2j_node_A_const_481 = A_arbace_c2j_node_A_const_pool.A[680]; A_arbace_c2j_node_A_const_482 = A_arbace_c2j_node_A_const_pool.A[681]; A_arbace_c2j_node_A_const_483 = A_arbace_c2j_node_A_const_pool.A[682]; A_arbace_c2j_node_A_const_484 = A_arbace_c2j_node_A_const_pool.A[683] }

func A_arbace_c2j_node_A_clinit_p35() { A_arbace_c2j_node_A_const_485 = A_arbace_c2j_node_A_const_pool.A[684]; A_arbace_c2j_node_A_const_486 = A_arbace_c2j_node_A_const_pool.A[685]; A_arbace_c2j_node_A_const_487 = A_arbace_c2j_node_A_const_pool.A[686]; A_arbace_c2j_node_A_const_488 = A_arbace_c2j_node_A_const_pool.A[687]; A_arbace_c2j_node_A_const_489 = A_arbace_c2j_node_A_const_pool.A[688]; A_arbace_c2j_node_A_const_490 = A_arbace_c2j_node_A_const_pool.A[689]; A_arbace_c2j_node_A_const_491 = A_arbace_c2j_node_A_const_pool.A[690]; A_arbace_c2j_node_A_const_492 = A_arbace_c2j_node_A_const_pool.A[691]; A_arbace_c2j_node_A_const_493 = A_arbace_c2j_node_A_const_pool.A[692]; A_arbace_c2j_node_A_const_494 = A_arbace_c2j_node_A_const_pool.A[693]; A_arbace_c2j_node_A_const_495 = A_arbace_c2j_node_A_const_pool.A[694]; A_arbace_c2j_node_A_const_496 = A_arbace_c2j_node_A_const_pool.A[695]; A_arbace_c2j_node_A_const_497 = A_arbace_c2j_node_A_const_pool.A[696]; A_arbace_c2j_node_A_const_498 = A_arbace_c2j_node_A_const_pool.A[697]; A_arbace_c2j_node_A_const_499 = A_arbace_c2j_node_A_const_pool.A[698]; A_arbace_c2j_node_A_const_500 = A_arbace_c2j_node_A_const_pool.A[699] }

func A_arbace_c2j_node_A_clinit_p36() { A_arbace_c2j_node_A_const_501 = A_arbace_c2j_node_A_const_pool.A[700] }

func A_arbace_c2j_node_A_New() *A_arbace_c2j_node_A { A_arbace_c2j_node_A_Init(); t := &A_arbace_c2j_node_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_node_A) Ctor() {}

func (t *A_arbace_c2j_node_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_node_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_node_A_class }

func (t *A_arbace_c2j_node_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_node_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_node_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_node_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_node_A); return ok }

func A_arbace_c2j_node_A_Cast(x any) *A_arbace_c2j_node_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_node_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_node_A_class)) }; return v }



type A_arbace_c2j_node_arg_kind_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_arg_kind_A_fn_class *jrt.Class



type A_arbace_c2j_node_camel_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_camel_A_fn_class *jrt.Class



type A_arbace_c2j_node_children_bind_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_children_bind_A_fn_class *jrt.Class



type A_arbace_c2j_node_children_bind_fn__400000028_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_children_bind_fn__400000028_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_construct__400000397_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_construct__400000397_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000389_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_fn__400000389_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000391_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_fn__400000391_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000393_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_clause_fn__400000393_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000411_A struct{ j2g_header uint64; F_pick any }

var A_arbace_c2j_node_clause_fn__400000411_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_fn__400000417_A struct{ j2g_header uint64; F_pick any }

var A_arbace_c2j_node_clause_fn__400000417_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_pick__400000402_A struct{ j2g_header uint64; F_construct, F_ss any }

var A_arbace_c2j_node_clause_pick__400000402_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_pick__400000402_go__400000403_A struct{ j2g_header uint64; F_construct any }

var A_arbace_c2j_node_clause_pick__400000402_go__400000403_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000404_A struct{ j2g_header uint64; F_s any }

var A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000404_A_fn_class *jrt.Class



type A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000406_A struct{ j2g_header uint64; F_s any }

var A_arbace_c2j_node_clause_pick__400000402_go__400000403_fn__400000406_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_fn__400000444_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_fn__400000444_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_fn__400000516_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_fn__400000516_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000423__400000427_A struct{ j2g_header uint64; F_helpers, F_domains any }

var A_arbace_c2j_node_code_forms_iter__400000423__400000427_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_A struct{ j2g_header uint64; F_iter__400000423, F_helpers, F_s__400000424, F_domains any }

var A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_A struct{ j2g_header uint64; F_helpers, F_domains, F_b__400000426 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_fn__400000430_A struct{ j2g_header uint64; F_d, F_helpers any }

var A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000429_fn__400000430_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000436_A struct{ j2g_header uint64; F_d, F_helpers any }

var A_arbace_c2j_node_code_forms_iter__400000423__400000427_fn__400000428_fn__400000436_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000448__400000456_A struct{ j2g_header uint64; F_domains, F_keys any }

var A_arbace_c2j_node_code_forms_iter__400000448__400000456_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_A struct{ j2g_header uint64; F_iter__400000448, F_s__400000449, F_domains, F_keys any }

var A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_A struct{ j2g_header uint64; F_keys, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_A struct{ j2g_header uint64; F_s__400000451, F_keys, F_iter__400000450, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_A struct{ j2g_header uint64; F_k, F_keys, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_A struct{ j2g_header uint64; F_s__400000453, F_k, F_keys, F_iter__400000452, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_fn__400000467_A struct{ j2g_header uint64; F_k, F_b__400000455, F_keys any; F_size__1927001038__auto__ int32; F_d, F_c__1927001037__auto__ any }

var A_arbace_c2j_node_code_forms_iter__400000448__400000456_fn__400000457_iter__400000450__400000460_fn__400000461_iter__400000452__400000465_fn__400000466_fn__400000467_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000481__400000487_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_iter__400000481__400000487_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_A struct{ j2g_header uint64; F_iter__400000481, F_s__400000482 any }

var A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_A struct{ j2g_header uint64; F_d any }

var A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_A struct{ j2g_header uint64; F_s__400000484, F_iter__400000483, F_d any }

var A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_A struct{ j2g_header uint64; F_b__400000486 any; F_size__1927001038__auto__ int32; F_d, F_c__1927001037__auto__ any }

var A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_fn__400000497_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000493_fn__400000497_A_fn_class *jrt.Class



type A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000506_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_code_forms_iter__400000481__400000487_fn__400000488_iter__400000483__400000491_fn__400000492_fn__400000506_A_fn_class *jrt.Class



type A_arbace_c2j_node_defnode_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_defnode_A_fn_class *jrt.Class



type A_arbace_c2j_node_emit_fn_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_emit_fn_A_fn_class *jrt.Class



type A_arbace_c2j_node_emit_fn_fn__400000157_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_emit_fn_fn__400000157_A_fn_class *jrt.Class



type A_arbace_c2j_node_emit_fn_fn__400000161_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_emit_fn_fn__400000161_A_fn_class *jrt.Class



type A_arbace_c2j_node_emit_fn_fn__400000169_A struct{ j2g_header uint64; F_env0 any }

var A_arbace_c2j_node_emit_fn_fn__400000169_A_fn_class *jrt.Class



type A_arbace_c2j_node_eval400000004_A struct{ jrt.Object }

func A_arbace_c2j_node_eval400000004_A_New() *A_arbace_c2j_node_eval400000004_A { t := &A_arbace_c2j_node_eval400000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_node_eval400000004_A) Ctor() {}

func (t *A_arbace_c2j_node_eval400000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_node_eval400000004_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_node_eval400000004_A_class }

func (t *A_arbace_c2j_node_eval400000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_node_eval400000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_node_eval400000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_node_eval400000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_node_eval400000004_A); return ok }

func A_arbace_c2j_node_eval400000004_A_Cast(x any) *A_arbace_c2j_node_eval400000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_node_eval400000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_node_eval400000004_A_class)) }; return v }



type A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A_fn_class *jrt.Class



type A_arbace_c2j_node_eval400000008_A struct{ jrt.Object }

func A_arbace_c2j_node_eval400000008_A_New() *A_arbace_c2j_node_eval400000008_A { t := &A_arbace_c2j_node_eval400000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_node_eval400000008_A) Ctor() {}

func (t *A_arbace_c2j_node_eval400000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_node_eval400000008_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_node_eval400000008_A_class }

func (t *A_arbace_c2j_node_eval400000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_node_eval400000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_node_eval400000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_node_eval400000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_node_eval400000008_A); return ok }

func A_arbace_c2j_node_eval400000008_A_Cast(x any) *A_arbace_c2j_node_eval400000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_node_eval400000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_node_eval400000008_A_class)) }; return v }



type A_arbace_c2j_node_eval400000008_fn__400000009_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_eval400000008_fn__400000009_A_fn_class *jrt.Class



type A_arbace_c2j_node_field_names_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_field_names_A_fn_class *jrt.Class



type A_arbace_c2j_node_field_names_fn__400000024_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_field_names_fn__400000024_A_fn_class *jrt.Class



type A_arbace_c2j_node_head_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_head_A_fn_class *jrt.Class



type A_arbace_c2j_node_invalid_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_invalid_A_fn_class *jrt.Class



type A_arbace_c2j_node_parse_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_parse_A_fn_class *jrt.Class



type A_arbace_c2j_node_parse_fn__400000018_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_parse_fn__400000018_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_body_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_body_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_body_fn__400000056_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_body_fn__400000056_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_drop_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_drop_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_node_q_elems_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_elems_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_elems_fn__400000048_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_elems_fn__400000048_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_elems_fn__400000051_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_elems_fn__400000051_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_seq_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_fn__400000084_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_seq_fn__400000084_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_fn__400000113_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_q_seq_fn__400000113_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_fn__400000132_A struct{ j2g_header uint64; F_fresh any }

var A_arbace_c2j_node_q_seq_fn__400000132_A_fn_class *jrt.Class



type A_arbace_c2j_node_q_seq_fn__400000140_A struct{ j2g_header uint64; F_env any }

var A_arbace_c2j_node_q_seq_fn__400000140_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qe_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_elems_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qe_elems_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_elems_fn__400000181_A struct{ j2g_header uint64; F_env, F_v any }

var A_arbace_c2j_node_qe_elems_fn__400000181_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qe_seq_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000196_A struct{ j2g_header uint64; F_b any }

var A_arbace_c2j_node_qe_seq_fn__400000196_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000198_A struct{ j2g_header uint64; F_env, F_v any }

var A_arbace_c2j_node_qe_seq_fn__400000198_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000219_A struct{ j2g_header uint64; F_g any }

var A_arbace_c2j_node_qe_seq_fn__400000219_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000240_A struct{ j2g_header uint64; F_tmp, F_v any }

var A_arbace_c2j_node_qe_seq_fn__400000240_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000240_fn__400000247_A struct{ j2g_header uint64; F_tmp any }

var A_arbace_c2j_node_qe_seq_fn__400000240_fn__400000247_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000250_A struct{ j2g_header uint64; F_v, F_env any }

var A_arbace_c2j_node_qe_seq_fn__400000250_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000259_A struct{ j2g_header uint64; F_env, F_v any }

var A_arbace_c2j_node_qe_seq_fn__400000259_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000264_A struct{ j2g_header uint64; F_env, F_v any }

var A_arbace_c2j_node_qe_seq_fn__400000264_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_fn__400000269_A struct{ j2g_header uint64; F_ts, F_b any }

var A_arbace_c2j_node_qe_seq_fn__400000269_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_h_STAR___400000190_A struct{ j2g_header uint64; F_env, F_t, F_v any }

var A_arbace_c2j_node_qe_seq_h_STAR___400000190_A_fn_class *jrt.Class



type A_arbace_c2j_node_qe_seq_tmp__400000236_A struct{ j2g_header uint64; F_n any }

var A_arbace_c2j_node_qe_seq_tmp__400000236_A_fn_class *jrt.Class



type A_arbace_c2j_node_qs_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qs_A_fn_class *jrt.Class



type A_arbace_c2j_node_qs_fn__400000060_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_qs_fn__400000060_A_fn_class *jrt.Class



type A_arbace_c2j_node_realize_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_realize_A_fn_class *jrt.Class



type A_arbace_c2j_node_register_BANG__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_register_BANG__A_fn_class *jrt.Class



type A_arbace_c2j_node_register_BANG__fn__400000012_A struct{ j2g_header uint64; F_d any }

var A_arbace_c2j_node_register_BANG__fn__400000012_A_fn_class *jrt.Class



type A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A struct{ j2g_header uint64; F_d any }

var A_arbace_c2j_node_register_BANG__fn__400000012_fn__400000013_A_fn_class *jrt.Class



type A_arbace_c2j_node_ret_chans_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_ret_chans_A_fn_class *jrt.Class



type A_arbace_c2j_node_runs_children_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_runs_children_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_node_splits_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_splits_A_fn_class *jrt.Class



type A_arbace_c2j_node_splits_fn__400000277_A struct{ j2g_header uint64; F_tested any }

var A_arbace_c2j_node_splits_fn__400000277_A_fn_class *jrt.Class



type A_arbace_c2j_node_splits_w__400000275_A struct{ j2g_header uint64; F_tested any }

var A_arbace_c2j_node_splits_w__400000275_A_fn_class *jrt.Class



type A_arbace_c2j_node_sym_occurs_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_node_sym_occurs_QMARK__fn__400000285_A struct{ j2g_header uint64; F_s any }

var A_arbace_c2j_node_sym_occurs_QMARK__fn__400000285_A_fn_class *jrt.Class



type A_arbace_c2j_node_tag_sym_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_tag_sym_A_fn_class *jrt.Class



type A_arbace_c2j_node_uses_many_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2j_node_uses_many_QMARK__A_fn_class *jrt.Class



type A_arbace_c2j_node_uses_many_QMARK__w__400000280_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_node_uses_many_QMARK__w__400000280_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_bare__400000312_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_bare__400000312_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000289_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_fn__400000289_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000305_A struct{ j2g_header uint64; F_conv, F_methods, F_v any }

var A_arbace_c2j_node_variant_class_fn__400000305_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000305_fn__400000307_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_fn__400000305_fn__400000307_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000305_fn__400000309_A struct{ j2g_header uint64; F_b, F_conv, F_fld any }

var A_arbace_c2j_node_variant_class_fn__400000305_fn__400000309_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000315_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variant_class_fn__400000315_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_fn__400000320_A struct{ j2g_header uint64; F_bare any }

var A_arbace_c2j_node_variant_class_fn__400000320_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_method__400000292_A struct{ j2g_header uint64; F_d, F_env, F_v, F_domain any }

var A_arbace_c2j_node_variant_class_method__400000292_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_method__400000292_fn__400000299_A struct{ j2g_header uint64; F_c, F_try_qe, F_v any }

var A_arbace_c2j_node_variant_class_method__400000292_fn__400000299_A_fn_class *jrt.Class



type A_arbace_c2j_node_variant_class_method__400000292_try_qe__400000296_A struct{ j2g_header uint64; F_d, F_env any }

var A_arbace_c2j_node_variant_class_method__400000292_try_qe__400000296_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variants_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000326_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variants_fn__400000326_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_A struct{ j2g_header uint64; F_s any }

var A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_A struct{ j2g_header uint64; F_iter__400000327, F_s__400000328, F_s any }

var A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_A struct{ j2g_header uint64; F_m, F_s any }

var A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_A struct{ j2g_header uint64; F_s__400000330, F_iter__400000329, F_m, F_s any }

var A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_fn__400000337_A struct{ j2g_header uint64; F_m, F_b__400000332, F_s any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_node_variants_fn__400000326_iter__400000327__400000333_fn__400000334_iter__400000329__400000335_fn__400000336_fn__400000337_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_fn__400000344_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variants_fn__400000344_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000346__400000352_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_variants_iter__400000346__400000352_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_A struct{ j2g_header uint64; F_iter__400000346, F_s__400000347 any }

var A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_A struct{ j2g_header uint64; F_k, F_p any }

var A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_A struct{ j2g_header uint64; F_iter__400000348, F_k, F_s__400000349, F_p any }

var A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_fn__400000359_A struct{ j2g_header uint64; F_k, F_p, F_b__400000351 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_c2j_node_variants_iter__400000346__400000352_fn__400000353_iter__400000348__400000357_fn__400000358_fn__400000359_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000365__400000371_A struct{ j2g_header uint64; F_base, F_split_sets, F_dom, F_ss any }

var A_arbace_c2j_node_variants_iter__400000365__400000371_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_A struct{ j2g_header uint64; F_s__400000366, F_base, F_split_sets, F_dom, F_ss, F_iter__400000365 any }

var A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_A struct{ j2g_header uint64; F_base, F_dom, F_ss, F_c any }

var A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_A struct{ j2g_header uint64; F_iter__400000367, F_s__400000368, F_base, F_dom, F_ss, F_c any }

var A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_A struct{ j2g_header uint64; F_b__400000370, F_base, F_dom any; F_size__1927001038__auto__ int32; F_ss, F_c__1927001037__auto__, F_c any }

var A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_fn__400000376_A struct{ j2g_header uint64; F_sp any }

var A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000375_fn__400000376_A_fn_class *jrt.Class



type A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000379_A struct{ j2g_header uint64; F_sp any }

var A_arbace_c2j_node_variants_iter__400000365__400000371_fn__400000372_iter__400000367__400000373_fn__400000374_fn__400000379_A_fn_class *jrt.Class



type A_arbace_c2j_node_walk_syms_A struct{ j2g_header uint64 }

var A_arbace_c2j_node_walk_syms_A_fn_class *jrt.Class



type A_arbace_c2j_node_walk_syms_fn__400000033_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_node_walk_syms_fn__400000033_A_fn_class *jrt.Class



type A_arbace_c2j_node_walk_syms_fn__400000035_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_node_walk_syms_fn__400000035_A_fn_class *jrt.Class



type A_arbace_c2j_node_walk_syms_fn__400000038_A struct{ j2g_header uint64; F_r any }

var A_arbace_c2j_node_walk_syms_fn__400000038_A_fn_class *jrt.Class
