//line j2g_strings.ae:1
package aot_arbace_c2j_node

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn13,arbace.stringkn2,asyn3,stryn11,arbace.corekn3,dockn4,kindkn4,optskn5,bindskn3,symkn1,kkn4,argskn8,templateyn5,childyn8,childrenkn6,fieldskn4,elseyn3,runyn7,run-allyn8,run-argsyn6,splicekn8,cs-delaykn1,vyn5,derefks15,arbace.c2j.node4,dropyn4,listyn5,quoteyn2,doyn2,chyn5,many?yn7,clears?kn8,childrenkn5,placekn6,statickn5,fieldkn1,ekn5,childyn1,>kn3,maxyn5,countkn6,clearsyn8,array-ofyn9,static-ifyn5,list*yn3,mapyn2,fnyn1,xyn4,emityn3,ctxyn3,newys16,java.lang.Object1,1yn3,vecyn11,static-caseyn4,caseyn2,ifyn9,set-placeyn9,get-placeyn4,set!kn4,formkn1,zkn1,dkn1,jyn11,call-staticyn12,emit-unboxedyn8,unboxed?kn1,oyn9,eval-onlyyn7,at-lineyn9,call-sitekn2,csyn6,box-asyn3,letkn6,tlocalyn4,gsymyn1,=yn3,boxyn14,.getReturnTypeyn6,vectoryn5,delayyn10,typed-argsyn18,.getParameterTypesyn4,liftkn1,tyn6,concatkn2,chyn1,eyn5,placeyn11,eval-staticyn11,local-placeyn1,nyn6,statickn3,tagyn25,arbace.lang.Compiler$Exprkn4,selfyn9,prim-chanyn4,defnkn10,emit-firstyn2,orkn9,eval-onlyys15,arbace.c2j.node9,register!ks15,arbace.c2j.node7,invalidkn1,ikn1,bkn1,skn1,ckn1,fkn8,cs-arraykn5,tempskn4,manykn5,countkn5,arraykn5,multiyn4,.runyn1,fkn8,cs-multikn4,tempkn6,splitsys16,Compiler$CodeRun6,runAllys6,Object1,1yn1,%kn3,setkn3,getkn11,call-statickn7,helpersyn13,call-instancekn13,call-instancekn1,myn11,cast-targetyn4,castkn8,type-symyn6,.-linekn4,linekn6,columnyn4,at__kn3,boxyn14,unchecked-byteyn8,.runLongyn10,.runDoubleyn14,unchecked-charyn15,unchecked-floatyn13,unchecked-intyn15,unchecked-shortyn8,.runBoolyn6,Objectkn5,chanskn9,domain-msyn6,switchyn2,opyn5,throwyn22,IllegalStateException.kn4,nameyn4,thisyn14,Compiler$Frameyn6,methodkn6,publickn7,convertyn3,intkn3,valyn1,oyn13,Compiler$Codeyn13,Compiler$Expryn4,.nthyn8,.convertyn2,ccyn4,agetyn2,psyn8,.compileys13,Compiler$Code1,1yn11,.compileAllyn8,defclasskn7,extendsyn5,fieldkn5,finalyn11,constructorkn5,classkn6,domainkn10,place-kindkn5,exprsyn9,instance?yn4,condyn2,==yn1,kyn20,unchecked-divide-intyn22,unchecked-subtract-intyn22,unchecked-multiply-intyn2,ncyn6,.countkn5,indexyn1,<kn2,vskn2,cfyn9,CodeNodesyn7,compileyn21,Compiler$CodeCompileryn5,tableyn17,java.util.HashMapyn1,myn18,java.util.HashMap.yn4,.putys7,Integer7,valueOfv11,arbace.core7,requireV3,R0,R1,R2,v11,arbace.core5,referR3,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.c2j.nodem2,R4,s3418,Futamura F7 (doc/FUTAMURA-SURVEY.md, \"F7 as built\"): node kinds defined once and staged.\n  A definition (defnode) is read twice: as the back end's emitter of the kind (defnode's\n  expansion, a fn emit-KIND of the namespace using it, arbace.c2j.emit) and as the evaluator's\n  Code classes of the kind with their construction (code-file, run by test/c2j/gen_nodes.ae,\n  which writes arbace/lang/go/CompilerNodes.ae). The two halves of the kind are then one text.\n\n  (defnode KIND doc opts bindings template)\n\n  opts: :exprs, the analyzed node's classes (Compiler$IfExpr ...; the evaluator's dispatch);\n  :fields, the node's fields the static forms read (besides the children's); :chans, the\n  evaluator's channels (:o run, :j runLong, :d runDouble, :z runBool; all four by default);\n  :eval-only, a kind the evaluator alone has (no emitter: the back end's own code compiles\n  these nodes);\n  :class, the evaluator's class name (CodeKIND); :emit-first, a fn of [ctx n unboxed?] the\n  emitter tries first (a refinement of the back end's own: F5's linked calls), nil when it does\n  not apply; :domain {:index form}, a static of finite domain (a method): the evaluator makes one\n  class per arity with a switch over the domain (generation's :domains), the index form its\n  case (arity * 10000 + case, or -1: not this kind).\n\n  bindings, [sym spec ...], in order:\n  - (child F): the child node in field F (the emitter: its Expr; the evaluator: its Code);\n  - (children F max & {:convert ps}): the children in field F (a vector); the evaluator makes a\n    class per count up to max, and one holding an array past it; :convert, the evaluator's\n    children converted to the parameter classes ps (CodeCompiler.convert);\n  - (static T form): a value made when the node is (both halves, the same form: a Java form\n    the evaluator's construction runs, a Clojure form the emitter runs, over the fields, the\n    node e and earlier statics), of class T; in the template's dynamic code a field of the\n    evaluator's node and a literal or constant of the emitted code (lift);\n  - (eval-static T form): the evaluator's alone (the CodeCompiler cc in scope); nil emitting;\n  - (place): where a local lives, each half's own (the evaluator: eval-places; the emitter: its\n    local-place).\n\n  The template is a Java form, the node's value in channel ch, with these staged parts:\n  (run CH x) a child's value in channel CH (ch: the channel being made); (run-all :o xs) the\n  children's values, (run-args m xs) as method m's arguments, both spliced by (splice s) or\n  made an array by (array-of s); (call-site line [s init ...] body ...) a call: its operands\n  bound in order, then (the evaluator's) the frame's line, then the body; (eval-only form) the\n  evaluator's alone; (static-if c a b) chosen when the node is made (the evaluator: a class per\n  case, for a static boolean, (many? xs), (clears? at)); (static-case ch :o a :j b ...);\n  (box-as ch m form) a method's value boxed in channel :o; (call-static m as) the direct call\n  (with F3's fast paths for Numbers' boxed operations: one builder for both halves);\n  (cast-target m x) x cast to method m's class, (call-instance m t as) m's call on t (the\n  evaluator's alone: an :eval-only kind's);\n  (get-place at CH), (set-place at x); (at-line line x) x's value, the evaluator's frame's line\n  set after x; let. Any other form is copied: the emitter quotes it,\n  the evaluator runs it.v11,arbace.core5,swap!v15,arbace.c2j.node8,registryv11,arbace.core5,firstv11,arbace.core12,keep-indexedR5,v11,arbace.core5,assocR4,R6,R7,v11,arbace.core4,mapvR8,R9,R10,v11,arbace.core3,vecv11,arbace.core4,restv11,arbace.core9,partitionl2,R11,v11,arbace.core8,distinctv11,arbace.core6,concatv11,arbace.core4,keepS2,R12,R13,R14,v11,arbace.core6,filterR13,v11,arbace.core7,symbol?v11,arbace.core9,contains?v11,arbace.core4,seq?v11,arbace.core9,with-metav11,arbace.core5,applyv11,arbace.core4,listv11,arbace.core3,mapv15,arbace.c2j.node9,walk-symsv11,arbace.core7,vector?v11,arbace.core4,map?v11,arbace.core4,intoR15,S3,R16,R17,R18,v15,arbace.c2j.node4,headv11,arbace.core4,somev15,arbace.c2j.node14,runs-children?v11,arbace.core4,lastR19,v11,arbace.core6,secondv15,arbace.c2j.node1,qv11,arbace.core7,butlastR20,R21,R22,R23,v11,arbace.core6,removev15,arbace.c2j.node7,q-drop?v11,arbace.core6,empty?v11,arbace.core5,list*R24,L2,R25,R26,R27,R28,R29,S6,R30,R31,R32,R33,R34,R35,R27,R36,R37,R38,R39,v11,arbace.core3,seqv11,arbace.core4,nextR17,R26,v15,arbace.c2j.node6,q-bodyR40,R41,v15,arbace.c2j.node7,q-elemsR42,v11,arbace.core4,consR24,R43,R44,V1,R45,R46,R47,R45,R24,L2,R25,R48,L2,R25,R49,R50,R22,R51,R52,v15,arbace.c2j.node2,qsv11,arbace.core6,mapcatR53,R54,R55,R24,L2,R25,R56,R57,R16,R58,R27,R59,R60,R61,R62,R47,R53,R63,R62,R47,R46,R47,R64,R46,R47,R65,R61,R47,R30,R66,R67,v11,arbace.core6,reducev11,arbace.core6,gensymR18,R68,R69,R70,R70,R26,R71,R72,R47,R25,v11,arbace.core6,symbolR70,R53,R73,R74,R75,R18,R70,R24,L2,R25,R70,R76,R77,R78,R47,R79,R32,v11,arbace.core7,ex-infov15,arbace.c2j.node5,q-seqR80,R47,R25,R81,R25,R50,R82,v15,arbace.c2j.node11,field-namesR27,R83,R84,R34,R33,v11,arbace.core8,to-arrayR85,R86,R12,R13,R31,R87,R47,R88,R35,R89,R70,m2,R90,R91,R92,R88,v11,arbace.core7,keywordv11,arbace.core3,strR88,R53,R63,R93,R88,R94,V3,R47,R88,R63,R95,R96,R47,R88,R63,v15,arbace.c2j.node5,parseR26,R97,v15,arbace.c2j.node7,emit-fnR98,R25,m2,R99,Tv15,arbace.c2j.node7,realizeR100,R101,R102,R103,R104,S2,R64,R60,S2,R64,R59,S2,R64,R58,S1,R64,R19,R105,v15,arbace.c2j.node7,invalidR106,v15,arbace.c2j.node2,qev15,arbace.c2j.node8,qe-elemsR17,R107,R108,R109,R110,R111,R112,v11,arbace.core5,rangeR26,R26,v11,arbace.core4,nil?R40,R113,R114,R41,R115,R28,R29,R116,R112,R48,R117,R51,v11,arbace.core8,hash-mapR54,R118,R119,R55,R27,R120,R16,R27,R61,v11,arbace.core4,atoml0,R121,R122,v15,arbace.c2j.node12,chan-methodsR112,R123,R124,R125,v11,arbace.core3,incR126,R65,R127,R128,R66,R67,l-1,v11,arbace.core10,interleaveR70,R56,ML2,R129,R112,m4,R130,i349,R131,i57,R70,R132,R132,R56,ML2,R129,R112,m4,R130,i355,R131,i62,R69,v11,arbace.core3,notv15,arbace.c2j.node9,ret-chansR133,R70,R70,R18,v11,arbace.core11,map-indexedv15,arbace.c2j.node8,arg-kindR134,R135,R112,R136,R112,R137,R135,R112,R138,R136,R112,R135,R112,C16,java.lang.ObjectR139,R135,R112,R111,R112,R127,R111,R112,R140,R135,R112,R141,R112,v15,arbace.c2j.node6,qe-seqv11,arbace.core4,run!R41,R28,v11,arbace.core6,reset!v13,arbace.string10,upper-casev11,arbace.core4,subsl1,v15,arbace.c2j.node11,sym-occurs?R142,v11,arbace.core9,vary-metaR90,R85,m2,R9,R31,R86,R12,R13,R89,V1,R64,v11,arbace.core4,keysR143,V4,R64,R60,R59,R58,R144,R99,v11,arbace.core7,ex-dataR145,R146,v11,arbace.core8,identityR147,R148,R149,R150,R112,m2,R90,R151,R152,m2,R153,Tv15,arbace.c2j.node13,children-bindR154,v11,arbace.core4,dropR146,m2,R90,R155,R156,R157,R85,R86,R12,R13,v15,arbace.c2j.node7,tag-symR158,R127,R159,R160,R161,R162,R163,R164,R165,R162,R158,R89,R166,R167,R162,R168,m4,R153,TR32,TR169,R158,R170,R153,R171,R172,R150,m2,R153,TR56,R150,R173,v15,arbace.c2j.node5,camelv15,arbace.c2j.node6,splitsv15,arbace.c2j.node10,uses-many?V1,R107,V1,nv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restV2,FTR174,R85,R175,V2,FTV1,Fv11,arbace.core5,some?v11,arbace.core6,vectorv15,arbace.c2j.node11,eval-placesR176,R96,R177,R84,R45,R45,R127,R84,R12,R89,R86,R165,R162,R164,R48,R53,v11,arbace.core8,group-byv11,arbace.core4,compv11,arbace.core7,sort-byv11,arbace.core3,keyv11,arbace.core7,number?R177,R84,R70,R178,R179,R180,V2,R15,nR180,R157,R181,R146,l10000,R182,R146,R183,R180,l10000,R70,R178,R179,R184,R184,R185,R186,R70,R45,R127,R84,R146,R53,R187,R146,R70,R70,R188,v15,arbace.c2j.node13,variant-classR189,v15,arbace.c2j.node8,variantsv15,arbace.c2j.node6,clausev11,arbace.core4,juxtv11,arbace.core4,namev13,arbace.string4,joinR168,R190,m4,R153,TR32,TR152,R191,m4,R153,TR32,TR162,m2,R90,R192,R84,m2,R90,R159,m2,R90,R158,R178,V2,R15,nR152,R193,m4,R153,TR32,Tm2,R90,R194,R70,V2,R195,ML1,R196,m4,R130,i604,R131,i45,R197,R195,R198,V1,R195,")

var Lit_1 *jrt.String = jrt.Intern("arbace.c2j.node$children_bind$fn__400000028")

var Lit_2 *jrt.String = jrt.Intern("Compiler$")

var Lit_3 *jrt.String = jrt.Intern("arbace.c2j.node$clause$fn__400000389")

var Lit_4 *jrt.String = jrt.Intern("arbace.c2j.node$clause$fn__400000391")

var Lit_5 *jrt.String = jrt.Intern("arbace.c2j.node$clause$fn__400000393")

var Lit_6 *jrt.String = jrt.Intern("arbace.c2j.node$clause$construct__400000397")

var Lit_7 *jrt.String = jrt.Intern("arbace.c2j.node$clause$pick__400000402")

var Lit_8 *jrt.String = jrt.Intern("arbace.c2j.node$clause$fn__400000411")

var Lit_9 *jrt.String = jrt.Intern("arbace.c2j.node$clause$fn__400000417")

var Lit_10 *jrt.String = jrt.Intern(".-")

var Lit_11 *jrt.String = jrt.Intern("arbace.c2j.node$clause$pick__400000402$go__400000403")

var Lit_12 *jrt.String = jrt.Intern("arbace.c2j.node$clause$pick__400000402$go__400000403$fn__400000404")

var Lit_13 *jrt.String = jrt.Intern("arbace.c2j.node$clause$pick__400000402$go__400000403$fn__400000406")

var Lit_14 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000423__400000427")

var Lit_15 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$fn__400000444")

var Lit_16 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000448__400000456")

var Lit_17 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000481__400000487")

var Lit_18 *jrt.String = jrt.Intern("CodeNodes: the nodes of these kinds made (CodeCompiler.compile), the domains' cases")

var Lit_19 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$fn__400000516")

var Lit_20 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000423__400000427$fn__400000428")

var Lit_21 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000423__400000427$fn__400000428$fn__400000429")

var Lit_22 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000423__400000427$fn__400000428$fn__400000436")

var Lit_23 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000423__400000427$fn__400000428$fn__400000429$fn__400000430")

var Lit_24 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000448__400000456$fn__400000457")

var Lit_25 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000448__400000456$fn__400000457$iter__400000450__400000460")

var Lit_26 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000448__400000456$fn__400000457$iter__400000450__400000460$fn__400000461")

var Lit_27 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000448__400000456$fn__400000457$iter__400000450__400000460$fn__400000461$iter__400000452__400000465")

var Lit_28 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000448__400000456$fn__400000457$iter__400000450__400000460$fn__400000461$iter__400000452__400000465$fn__400000466")

var Lit_29 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000448__400000456$fn__400000457$iter__400000450__400000460$fn__400000461$iter__400000452__400000465$fn__400000466$fn__400000467")

var Lit_30 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000481__400000487$fn__400000488")

var Lit_31 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000481__400000487$fn__400000488$iter__400000483__400000491")

var Lit_32 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000481__400000487$fn__400000488$iter__400000483__400000491$fn__400000492")

var Lit_33 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000481__400000487$fn__400000488$iter__400000483__400000491$fn__400000492$fn__400000493")

var Lit_34 *jrt.String = jrt.Intern(": the evaluator's node of ")

var Lit_35 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000481__400000487$fn__400000488$iter__400000483__400000491$fn__400000492$fn__400000506")

var Lit_36 *jrt.String = jrt.Intern(", ")

var Lit_37 *jrt.String = jrt.Intern("more children")

var Lit_38 *jrt.String = jrt.Intern(" children")

var Lit_39 *jrt.String = jrt.Intern(", cleared")

var Lit_40 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms$iter__400000481__400000487$fn__400000488$iter__400000483__400000491$fn__400000492$fn__400000493$fn__400000497")

var Lit_41 *jrt.String = jrt.Intern("e_")

var Lit_42 *jrt.String = jrt.Intern("ch_")

var Lit_43 *jrt.String = jrt.Intern("arbace.c2j.node$emit_fn$fn__400000157")

var Lit_44 *jrt.String = jrt.Intern("arbace.c2j.node$emit_fn$fn__400000161")

var Lit_45 *jrt.String = jrt.Intern("arbace.c2j.node$emit_fn$fn__400000169")

var Lit_46 *jrt.String = jrt.Intern("emit-")

var Lit_47 *jrt.String = jrt.Intern("_")

var Lit_48 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_49 *jrt.String = jrt.Intern("arbace.c2j.node$field_names$fn__400000024")

var Lit_50 *jrt.String = jrt.Intern("defnode: no such channel")

var Lit_51 *jrt.String = jrt.Intern("arbace.c2j.node$parse$fn__400000018")

var Lit_52 *jrt.String = jrt.Intern("defnode: ")

var Lit_53 *jrt.String = jrt.Intern(" is not a value of the emitted code")

var Lit_54 *jrt.String = jrt.Intern("arbace.c2j.node$q_body$fn__400000056")

var Lit_55 *jrt.String = jrt.Intern("arbace.c2j.node$q_elems$fn__400000048")

var Lit_56 *jrt.String = jrt.Intern("arbace.c2j.node$q_elems$fn__400000051")

var Lit_57 *jrt.String = jrt.Intern("arbace.c2j.node$q_seq$fn__400000084")

var Lit_58 *jrt.String = jrt.Intern("arbace.c2j.node$q_seq$fn__400000113")

var Lit_59 *jrt.String = jrt.Intern("f_")

var Lit_60 *jrt.String = jrt.Intern("arbace.c2j.node$q_seq$fn__400000132")

var Lit_61 *jrt.String = jrt.Intern("arbace.c2j.node$q_seq$fn__400000140")

var Lit_62 *jrt.String = jrt.Intern("-")

var Lit_63 *jrt.String = jrt.Intern("arbace.c2j.node$qe_elems$fn__400000181")

var Lit_64 *jrt.String = jrt.Intern("arbace.c2j.node$qe_seq$h_STAR___400000190")

var Lit_65 *jrt.String = jrt.Intern("arbace.c2j.node$qe_seq$fn__400000196")

var Lit_66 *jrt.String = jrt.Intern("arbace.c2j.node$qe_seq$fn__400000198")

var Lit_67 *jrt.String = jrt.Intern("defnode: not a split: ")

var Lit_68 *jrt.String = jrt.Intern(".")

var Lit_69 *jrt.String = jrt.Intern("arbace.c2j.node$qe_seq$fn__400000219")

var Lit_70 *jrt.String = jrt.Intern("arbace.c2j.node$qe_seq$tmp__400000236")

var Lit_71 *jrt.String = jrt.Intern("arbace.c2j.node$qe_seq$fn__400000240")

var Lit_72 *jrt.String = jrt.Intern("arbace.c2j.node$qe_seq$fn__400000250")

var Lit_73 *jrt.String = jrt.Intern("arbace.c2j.node$qe_seq$fn__400000259")

var Lit_74 *jrt.String = jrt.Intern("arbace.c2j.node$qe_seq$fn__400000264")

var Lit_75 *jrt.String = jrt.Intern("arbace.c2j.node$qe_seq$fn__400000269")

var Lit_76 *jrt.String = jrt.Intern("arbace.c2j.node$qe_seq$fn__400000240$fn__400000247")

var Lit_77 *jrt.String = jrt.Intern("x")

var Lit_78 *jrt.String = jrt.Intern("arbace.c2j.node$qs$fn__400000060")

var Lit_79 *jrt.String = jrt.Intern("arbace.c2j.node$register_BANG_$fn__400000012")

var Lit_80 *jrt.String = jrt.Intern("arbace.c2j.node$register_BANG_$fn__400000012$fn__400000013")

var Lit_81 *jrt.String = jrt.Intern("arbace.c2j.node$splits$w__400000275")

var Lit_82 *jrt.String = jrt.Intern("arbace.c2j.node$splits$fn__400000277")

var Lit_83 *jrt.String = jrt.Intern("arbace.c2j.node$sym_occurs_QMARK_$fn__400000285")

var Lit_84 *jrt.String = jrt.Intern("arbace.c2j.node$uses_many_QMARK_$w__400000280")

var Lit_85 *jrt.String = jrt.Intern("arbace.c2j.node$variant_class$fn__400000289")

var Lit_86 *jrt.String = jrt.Intern("arbace.c2j.node$variant_class$method__400000292")

var Lit_87 *jrt.String = jrt.Intern("arbace.c2j.node$variant_class$fn__400000305")

var Lit_88 *jrt.String = jrt.Intern("arbace.c2j.node$variant_class$bare__400000312")

var Lit_89 *jrt.String = jrt.Intern("arbace.c2j.node$variant_class$fn__400000315")

var Lit_90 *jrt.String = jrt.Intern("arbace.c2j.node$variant_class$fn__400000320")

var Lit_91 *jrt.String = jrt.Intern("arbace.c2j.node$variant_class$fn__400000305$fn__400000307")

var Lit_92 *jrt.String = jrt.Intern("arbace.c2j.node$variant_class$fn__400000305$fn__400000309")

var Lit_93 *jrt.String = jrt.Intern("arbace.c2j.node$variant_class$method__400000292$try_qe__400000296")

var Lit_94 *jrt.String = jrt.Intern("arbace.c2j.node$variant_class$method__400000292$fn__400000299")

var Lit_95 *jrt.String = jrt.Intern(": not of this kind")

var Lit_96 *jrt.String = jrt.Intern("Code")

var Lit_97 *jrt.String = jrt.Intern("arbace.c2j.node$variants$fn__400000326")

var Lit_98 *jrt.String = jrt.Intern("arbace.c2j.node$variants$fn__400000344")

var Lit_99 *jrt.String = jrt.Intern("arbace.c2j.node$variants$iter__400000346__400000352")

var Lit_100 *jrt.String = jrt.Intern("arbace.c2j.node$variants$iter__400000365__400000371")

var Lit_101 *jrt.String = jrt.Intern("arbace.c2j.node$variants$fn__400000326$iter__400000327__400000333")

var Lit_102 *jrt.String = jrt.Intern("arbace.c2j.node$variants$fn__400000326$iter__400000327__400000333$fn__400000334")

var Lit_103 *jrt.String = jrt.Intern("arbace.c2j.node$variants$fn__400000326$iter__400000327__400000333$fn__400000334$iter__400000329__400000335")

var Lit_104 *jrt.String = jrt.Intern("arbace.c2j.node$variants$fn__400000326$iter__400000327__400000333$fn__400000334$iter__400000329__400000335$fn__400000336")

var Lit_105 *jrt.String = jrt.Intern("arbace.c2j.node$variants$fn__400000326$iter__400000327__400000333$fn__400000334$iter__400000329__400000335$fn__400000336$fn__400000337")

var Lit_106 *jrt.String = jrt.Intern("arbace.c2j.node$variants$iter__400000346__400000352$fn__400000353")

var Lit_107 *jrt.String = jrt.Intern("arbace.c2j.node$variants$iter__400000346__400000352$fn__400000353$iter__400000348__400000357")

var Lit_108 *jrt.String = jrt.Intern("arbace.c2j.node$variants$iter__400000346__400000352$fn__400000353$iter__400000348__400000357$fn__400000358")

var Lit_109 *jrt.String = jrt.Intern("arbace.c2j.node$variants$iter__400000346__400000352$fn__400000353$iter__400000348__400000357$fn__400000358$fn__400000359")

var Lit_110 *jrt.String = jrt.Intern("Clear")

var Lit_111 *jrt.String = jrt.Intern("arbace.c2j.node$variants$iter__400000365__400000371$fn__400000372")

var Lit_112 *jrt.String = jrt.Intern("arbace.c2j.node$variants$iter__400000365__400000371$fn__400000372$iter__400000367__400000373")

var Lit_113 *jrt.String = jrt.Intern("arbace.c2j.node$variants$iter__400000365__400000371$fn__400000372$iter__400000367__400000373$fn__400000374")

var Lit_114 *jrt.String = jrt.Intern("arbace.c2j.node$variants$iter__400000365__400000371$fn__400000372$iter__400000367__400000373$fn__400000374$fn__400000375")

var Lit_115 *jrt.String = jrt.Intern("N")

var Lit_116 *jrt.String = jrt.Intern("")

var Lit_117 *jrt.String = jrt.Intern("arbace.c2j.node$variants$iter__400000365__400000371$fn__400000372$iter__400000367__400000373$fn__400000374$fn__400000379")

var Lit_118 *jrt.String = jrt.Intern("arbace.c2j.node$variants$iter__400000365__400000371$fn__400000372$iter__400000367__400000373$fn__400000374$fn__400000375$fn__400000376")

var Lit_119 *jrt.String = jrt.Intern("arbace.c2j.node$walk_syms$fn__400000033")

var Lit_120 *jrt.String = jrt.Intern("arbace.c2j.node$walk_syms$fn__400000035")

var Lit_121 *jrt.String = jrt.Intern("arbace.c2j.node$walk_syms$fn__400000038")

var Lit_122 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn8,arglistsyn1,dyn4,kindyn3,docyn4,optsyn8,bindingsyn8,templatekn7,privateyn1,ryn1,fyn1,tkn8,declaredyn3,envyn2,xsyn1,xyn2,bskn4,slotkn5,classkn6,fieldskn3,tagyn3,intkn3,getkn1,oyn4,agetyn7,.-slotsyn1,ikn3,setyn4,asetyn1,%kn4,longys4,Long7,valueOfyn7,.-primskn1,jkn6,doubleys6,Double7,valueOfys6,Double16,longBitsToDoublekn1,dkn5,boxedys16,Compiler$CodeRun5,reboxyn1,kkn6,closedyn8,.-closedyn4,.-fnyn1,jyn10,.longValueyn4,castyn6,Numberyn12,.doubleValuekn5,fieldys3,Dyn8,getFieldyn6,.-selfyn3,runyn7,runLongyn4,longyn9,runDoubleyn6,doublekn1,zyn7,runBoolyn7,booleanyn5,Classyn1,vyn1,syn7,domainsyn2,vsyn7,helpersyn4,keysv11,arbace.core5,in-nsMyn15,arbace.c2j.nodem2,R0,s3418,Futamura F7 (doc/FUTAMURA-SURVEY.md, \"F7 as built\"): node kinds defined once and staged.\n  A definition (defnode) is read twice: as the back end's emitter of the kind (defnode's\n  expansion, a fn emit-KIND of the namespace using it, arbace.c2j.emit) and as the evaluator's\n  Code classes of the kind with their construction (code-file, run by test/c2j/gen_nodes.ae,\n  which writes arbace/lang/go/CompilerNodes.ae). The two halves of the kind are then one text.\n\n  (defnode KIND doc opts bindings template)\n\n  opts: :exprs, the analyzed node's classes (Compiler$IfExpr ...; the evaluator's dispatch);\n  :fields, the node's fields the static forms read (besides the children's); :chans, the\n  evaluator's channels (:o run, :j runLong, :d runDouble, :z runBool; all four by default);\n  :eval-only, a kind the evaluator alone has (no emitter: the back end's own code compiles\n  these nodes);\n  :class, the evaluator's class name (CodeKIND); :emit-first, a fn of [ctx n unboxed?] the\n  emitter tries first (a refinement of the back end's own: F5's linked calls), nil when it does\n  not apply; :domain {:index form}, a static of finite domain (a method): the evaluator makes one\n  class per arity with a switch over the domain (generation's :domains), the index form its\n  case (arity * 10000 + case, or -1: not this kind).\n\n  bindings, [sym spec ...], in order:\n  - (child F): the child node in field F (the emitter: its Expr; the evaluator: its Code);\n  - (children F max & {:convert ps}): the children in field F (a vector); the evaluator makes a\n    class per count up to max, and one holding an array past it; :convert, the evaluator's\n    children converted to the parameter classes ps (CodeCompiler.convert);\n  - (static T form): a value made when the node is (both halves, the same form: a Java form\n    the evaluator's construction runs, a Clojure form the emitter runs, over the fields, the\n    node e and earlier statics), of class T; in the template's dynamic code a field of the\n    evaluator's node and a literal or constant of the emitted code (lift);\n  - (eval-static T form): the evaluator's alone (the CodeCompiler cc in scope); nil emitting;\n  - (place): where a local lives, each half's own (the evaluator: eval-places; the emitter: its\n    local-place).\n\n  The template is a Java form, the node's value in channel ch, with these staged parts:\n  (run CH x) a child's value in channel CH (ch: the channel being made); (run-all :o xs) the\n  children's values, (run-args m xs) as method m's arguments, both spliced by (splice s) or\n  made an array by (array-of s); (call-site line [s init ...] body ...) a call: its operands\n  bound in order, then (the evaluator's) the frame's line, then the body; (eval-only form) the\n  evaluator's alone; (static-if c a b) chosen when the node is made (the evaluator: a class per\n  case, for a static boolean, (many? xs), (clears? at)); (static-case ch :o a :j b ...);\n  (box-as ch m form) a method's value boxed in channel :o; (call-static m as) the direct call\n  (with F3's fast paths for Numbers' boxed operations: one builder for both halves);\n  (cast-target m x) x cast to method m's class, (call-instance m t as) m's call on t (the\n  evaluator's alone: an :eval-only kind's);\n  (get-place at CH), (set-place at x); (at-line line x) x's value, the evaluator's frame's line\n  set after x; let. Any other form is copied: the emitter quotes it,\n  the evaluator runs it.m2,R0,s3418,Futamura F7 (doc/FUTAMURA-SURVEY.md, \"F7 as built\"): node kinds defined once and staged.\n  A definition (defnode) is read twice: as the back end's emitter of the kind (defnode's\n  expansion, a fn emit-KIND of the namespace using it, arbace.c2j.emit) and as the evaluator's\n  Code classes of the kind with their construction (code-file, run by test/c2j/gen_nodes.ae,\n  which writes arbace/lang/go/CompilerNodes.ae). The two halves of the kind are then one text.\n\n  (defnode KIND doc opts bindings template)\n\n  opts: :exprs, the analyzed node's classes (Compiler$IfExpr ...; the evaluator's dispatch);\n  :fields, the node's fields the static forms read (besides the children's); :chans, the\n  evaluator's channels (:o run, :j runLong, :d runDouble, :z runBool; all four by default);\n  :eval-only, a kind the evaluator alone has (no emitter: the back end's own code compiles\n  these nodes);\n  :class, the evaluator's class name (CodeKIND); :emit-first, a fn of [ctx n unboxed?] the\n  emitter tries first (a refinement of the back end's own: F5's linked calls), nil when it does\n  not apply; :domain {:index form}, a static of finite domain (a method): the evaluator makes one\n  class per arity with a switch over the domain (generation's :domains), the index form its\n  case (arity * 10000 + case, or -1: not this kind).\n\n  bindings, [sym spec ...], in order:\n  - (child F): the child node in field F (the emitter: its Expr; the evaluator: its Code);\n  - (children F max & {:convert ps}): the children in field F (a vector); the evaluator makes a\n    class per count up to max, and one holding an array past it; :convert, the evaluator's\n    children converted to the parameter classes ps (CodeCompiler.convert);\n  - (static T form): a value made when the node is (both halves, the same form: a Java form\n    the evaluator's construction runs, a Clojure form the emitter runs, over the fields, the\n    node e and earlier statics), of class T; in the template's dynamic code a field of the\n    evaluator's node and a literal or constant of the emitted code (lift);\n  - (eval-static T form): the evaluator's alone (the CodeCompiler cc in scope); nil emitting;\n  - (place): where a local lives, each half's own (the evaluator: eval-places; the emitter: its\n    local-place).\n\n  The template is a Java form, the node's value in channel ch, with these staged parts:\n  (run CH x) a child's value in channel CH (ch: the channel being made); (run-all :o xs) the\n  children's values, (run-args m xs) as method m's arguments, both spliced by (splice s) or\n  made an array by (array-of s); (call-site line [s init ...] body ...) a call: its operands\n  bound in order, then (the evaluator's) the frame's line, then the body; (eval-only form) the\n  evaluator's alone; (static-if c a b) chosen when the node is made (the evaluator: a class per\n  case, for a static boolean, (many? xs), (clears? at)); (static-case ch :o a :j b ...);\n  (box-as ch m form) a method's value boxed in channel :o; (call-static m as) the direct call\n  (with F3's fast paths for Numbers' boxed operations: one builder for both halves);\n  (cast-target m x) x cast to method m's class, (call-instance m t as) m's call on t (the\n  evaluator's alone: an :eval-only kind's);\n  (get-place at CH), (set-place at x); (at-line line x) x's value, the evaluator's frame's line\n  set after x; let. Any other form is copied: the emitter quotes it,\n  the evaluator runs it.R1,v15,arbace.c2j.node8,registryv11,arbace.core4,atomm8,R2,i53,R3,i1,R4,s18,arbace/c2j/node.aeR0,s86,The node kinds defined, in order of definition: [{:kind :doc :opts :binds :template}].v15,arbace.c2j.node9,register!m10,R5,L1,V1,R6,R0,s76,Records definition d (a kind defined again replaces its earlier definition).R2,i57,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node5,parsem10,R5,L1,V5,R7,R8,R9,R10,R11,R0,s36,defnode's arguments as a definition.R2,i63,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node11,field-namesm12,R12,TR5,L1,V1,R6,R0,s65,The node fields the definition reads: its children's and :fields.R2,i70,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node13,children-bindm10,R12,TR5,L1,V1,R6,R2,i76,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node9,walk-symsm12,R12,TR5,L1,V2,R13,R14,R0,s58,Form f with each symbol s replaced by (r s) when r has it.R2,i78,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node4,headm10,R12,TR5,L1,V1,R14,R2,i88,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node14,runs-children?m12,R12,TR5,L1,V1,R15,R0,s61,Does template t run a child (code of another node inside it)?R2,i90,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node1,qm8,R16,TR2,i106,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node7,q-elemsm12,R12,TR5,L1,V2,R17,R18,R0,s179,Code making the elements xs of a list or vector, (splice s) spliced: [fixed tail], the\n  fixed elements' codes and the code of the spliced tail (nil: none). A splice must be last.R2,i108,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node7,q-drop?m10,R12,TR5,L1,V1,R19,R2,i121,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node6,q-bodym12,R12,TR5,L1,V2,R17,R20,R0,s77,Code making body forms bs as one form (the forms the emitter drops left out).R2,i123,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node2,qsm12,R12,TR5,L1,V2,R17,R14,R0,s87,Static form f as emit-time code: the template's names replaced by the emitter's locals.R2,i132,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node5,q-seqm10,R12,TR5,L1,V2,R17,R15,R2,i141,R3,i1,R4,s18,arbace/c2j/node.aem12,R12,TR5,L1,V2,R17,R15,R0,s63,Code making template t's Java form (env: the template's names).R2,i194,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node7,emit-fnm10,R5,L1,V1,R6,R0,s67,The emitter of definition d: (defn emit-KIND [ctx n unboxed?] ...).R2,i209,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node7,defnodem10,R5,L1,V5,R7,R8,R9,R10,R11,R0,s148,Defines node kind KIND once (this namespace's doc): the emitter emit-KIND, and the\n  definition kept for the evaluator's half (registry, code-file).R2,i236,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node11,eval-placesv11,arbace.core9,array-mapR21,m8,R22,s9,CodeLocalR23,V1,Myn1,im2,R24,R25,R26,m2,R27,ML3,R28,ML2,R29,R14,m4,R2,i252,R3,i65,R30,m4,R2,i252,R3,i59,R31,ML4,R32,ML2,R29,R14,m4,R2,i252,R3,i93,R30,R33,m4,R2,i252,R3,i87,R34,m6,R22,s13,CodeLocalLongR23,V1,Myn1,im2,R24,R25,R26,m4,R27,ML2,R35,ML3,R28,ML2,R36,R14,m4,R2,i254,R3,i42,R30,m4,R2,i254,R3,i36,m4,R2,i254,R3,i22,R37,ML3,R28,ML2,R36,R14,m4,R2,i254,R3,i67,R30,m4,R2,i254,R3,i61,R38,m6,R22,s15,CodeLocalDoubleR23,V1,Myn1,im2,R24,R25,R26,m4,R27,ML2,R39,ML2,R40,ML3,R28,ML2,R36,R14,m4,R2,i256,R3,i71,R30,m4,R2,i256,R3,i65,m4,R2,i256,R3,i40,m4,R2,i256,R3,i24,R41,ML2,R40,ML3,R28,ML2,R36,R14,m4,R2,i257,R3,i55,R30,m4,R2,i257,R3,i49,m4,R2,i257,R3,i24,R42,m6,R22,s14,CodeLocalBoxedR23,V2,Myn1,im2,R24,R25,Myn1,km2,R24,R25,R26,m2,R27,ML3,R43,R44,ML3,R28,ML2,R29,R14,m4,R2,i258,R3,i104,R30,m4,R2,i258,R3,i98,m4,R2,i258,R3,i72,R45,m8,R22,s10,CodeClosedR23,V2,Myn1,jm2,R24,R25,Myn1,km2,R24,R25,R26,m6,R27,ML3,R43,R44,ML3,R28,ML2,R46,ML2,R47,R14,m4,R2,i260,R3,i66,m4,R2,i260,R3,i56,R48,m4,R2,i260,R3,i50,m4,R2,i260,R3,i24,R37,ML2,R49,ML3,R50,R51,ML3,R28,ML2,R46,ML2,R47,R14,m4,R2,i261,R3,i65,m4,R2,i261,R3,i55,R48,m4,R2,i261,R3,i49,m4,R2,i261,R3,i36,m4,R2,i261,R3,i24,R41,ML2,R52,ML3,R50,R51,ML3,R28,ML2,R46,ML2,R47,R14,m4,R2,i262,R3,i67,m4,R2,i262,R3,i57,R48,m4,R2,i262,R3,i51,m4,R2,i262,R3,i38,m4,R2,i262,R3,i24,R31,ML4,R32,ML2,R46,ML2,R47,R14,m4,R2,i263,R3,i36,m4,R2,i263,R3,i26,R48,R33,m4,R2,i263,R3,i20,R53,m6,R22,s9,CodeFieldR23,V2,Myn1,jm2,R24,R25,Myn1,km2,R24,R25,R26,m6,R27,ML3,R43,R44,ML3,R54,ML2,R55,R14,m4,R2,i265,R3,i63,R48,m4,R2,i265,R3,i49,m4,R2,i265,R3,i23,R37,ML2,R49,ML3,R50,R51,ML3,R54,ML2,R55,R14,m4,R2,i266,R3,i62,R48,m4,R2,i266,R3,i48,m4,R2,i266,R3,i35,m4,R2,i266,R3,i23,R41,ML2,R52,ML3,R50,R51,ML3,R54,ML2,R55,R14,m4,R2,i267,R3,i64,R48,m4,R2,i267,R3,i50,m4,R2,i267,R3,i37,m4,R2,i267,R3,i23,m8,R2,i248,R3,i1,R4,s18,arbace/c2j/node.aeR0,s170,The evaluator's places of a local (CodeCompiler.local and localUse choose them): its node's\n  class, fields, read by channel and write (% the value; none: never cleared).v15,arbace.c2j.node12,chan-methodsm8,R27,V2,R56,nR37,V2,R57,R58,R41,V2,R59,R60,R61,V2,R62,R63,m8,R12,TR2,i269,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node7,invalidm10,R12,TR5,L1,V0,R2,i272,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node7,realizem12,R12,TR5,L1,V1,R14,R0,s112,Form f realized throughout (lazy parts made now, inside the try that drops an invalid\n  channel), metadata kept.R2,i274,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node8,arg-kindm12,R12,TR5,L1,V1,Myn1,cm2,R24,R64,R0,s146,The evaluator's channel of a parameter of class c (:i an int, :b a byte, :s a short, :c a\n  char, through runLong; :f a float, through runDouble).R2,i283,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node9,ret-chansm12,R12,TR5,L1,V1,Myn1,cm2,R24,R64,R0,s147,The channels a method returning class c is made in: :o, and its primitive's (a byte's,\n  short's and char's runLong, widened; a float's runDouble).R2,i290,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node2,qem8,R16,TR2,i297,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node8,qe-elemsm10,R12,TR5,L1,V3,R17,R65,R18,R2,i299,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node6,qe-seqm10,R12,TR5,L1,V3,R17,R65,R15,R2,i306,R3,i1,R4,s18,arbace/c2j/node.aem12,R12,TR5,L1,V3,R17,R65,R15,R0,s64,Template t's Java form in variant v (env: the template's names).R2,i398,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node6,splitsm12,R12,TR5,L1,V1,R6,R0,s69,The static booleans the template's static-ifs test, in binding order.R2,i413,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node10,uses-many?m10,R12,TR5,L1,V1,R6,R2,i423,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node5,camelm10,R12,TR5,L1,V1,R66,R2,i430,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node11,sym-occurs?m10,R12,TR5,L1,V2,R66,R14,R2,i432,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node7,tag-symm10,R12,TR5,L1,V2,R66,R15,R2,i437,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node13,variant-classm12,R12,TR5,L1,V2,R6,R65,R0,s180,[class fields] of variant v of definition d: the Java form of the evaluator's class, and its\n  fields in the order its constructor takes them, [{:s field :val the clause's value}].R2,i439,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node8,variantsm12,R12,TR5,L1,V2,R6,R67,R0,s103,The variants of definition d's evaluator classes: [{:name :splits :count :place :clears\n  :domain-ms}].R2,i500,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node6,clausem12,R12,TR5,L1,V2,R6,R68,R0,s144,The evaluator's construction of definition d's node: [test expr] of CodeNodes/compile's\n  cond; vs, its variants with their fields ([v fields]).R2,i521,R3,i1,R4,s18,arbace/c2j/node.aev15,arbace.c2j.node10,code-formsm10,R5,L1,V3,R69,R67,R70,R0,s451,The evaluator's half of every definition, as Java forms of Compiler: the Code classes, and\n  CodeNodes (compile, the nodes' construction for CodeCompiler.compile, nil when the node is\n  not of these kinds; table, the domains' cases by key). helpers: {:box :call-static\n  :call-instance :type-sym}, the back end's builders the two halves share; domains: {kind\n  {arity [Method ...]}}; keys: {kind (fn [Method] key)}. Returns [[comment class-form] ...].R2,i573,R3,i1,R4,s18,arbace/c2j/node.ae")

var Lit_123 *jrt.String = jrt.Intern("arbace.c2j.node$eval400000004$loading__1927001464__auto____400000005")

var Lit_124 *jrt.String = jrt.Intern("arbace.c2j.node$eval400000008$fn__400000009")

var Lit_125 *jrt.String = jrt.Intern("arbace.c2j.node$register_BANG_")

var Lit_126 *jrt.String = jrt.Intern("arbace.c2j.node$parse")

var Lit_127 *jrt.String = jrt.Intern("arbace.c2j.node$field_names")

var Lit_128 *jrt.String = jrt.Intern("arbace.c2j.node$children_bind")

var Lit_129 *jrt.String = jrt.Intern("arbace.c2j.node$walk_syms")

var Lit_130 *jrt.String = jrt.Intern("arbace.c2j.node$head")

var Lit_131 *jrt.String = jrt.Intern("arbace.c2j.node$runs_children_QMARK_")

var Lit_132 *jrt.String = jrt.Intern("arbace.c2j.node$q_elems")

var Lit_133 *jrt.String = jrt.Intern("arbace.c2j.node$q_drop_QMARK_")

var Lit_134 *jrt.String = jrt.Intern("arbace.c2j.node$q_body")

var Lit_135 *jrt.String = jrt.Intern("arbace.c2j.node$qs")

var Lit_136 *jrt.String = jrt.Intern("arbace.c2j.node$q_seq")

var Lit_137 *jrt.String = jrt.Intern("arbace.c2j.node$q")

var Lit_138 *jrt.String = jrt.Intern("arbace.c2j.node$emit_fn")

var Lit_139 *jrt.String = jrt.Intern("arbace.c2j.node$defnode")

var Lit_140 *jrt.String = jrt.Intern("arbace.c2j.node$invalid")

var Lit_141 *jrt.String = jrt.Intern("arbace.c2j.node$realize")

var Lit_142 *jrt.String = jrt.Intern("arbace.c2j.node$arg_kind")

var Lit_143 *jrt.String = jrt.Intern("arbace.c2j.node$ret_chans")

var Lit_144 *jrt.String = jrt.Intern("arbace.c2j.node$qe_elems")

var Lit_145 *jrt.String = jrt.Intern("arbace.c2j.node$qe_seq")

var Lit_146 *jrt.String = jrt.Intern("arbace.c2j.node$qe")

var Lit_147 *jrt.String = jrt.Intern("arbace.c2j.node$splits")

var Lit_148 *jrt.String = jrt.Intern("arbace.c2j.node$uses_many_QMARK_")

var Lit_149 *jrt.String = jrt.Intern("arbace.c2j.node$camel")

var Lit_150 *jrt.String = jrt.Intern("arbace.c2j.node$sym_occurs_QMARK_")

var Lit_151 *jrt.String = jrt.Intern("arbace.c2j.node$tag_sym")

var Lit_152 *jrt.String = jrt.Intern("arbace.c2j.node$variant_class")

var Lit_153 *jrt.String = jrt.Intern("arbace.c2j.node$variants")

var Lit_154 *jrt.String = jrt.Intern("arbace.c2j.node$clause")

var Lit_155 *jrt.String = jrt.Intern("arbace.c2j.node$code_forms")
