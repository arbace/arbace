//line aot_arbace_c2j_node__init.ae:1
package aot_arbace_c2j_node

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2j_node__init_A_Unit0__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_c2j_node__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node__init_A_const_1) }
//line :1:1
func A_arbace_c2j_node__init_A_Unit1__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_c2j_node__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_2)) }
//line :1:1
func A_arbace_c2j_node__init_A_Unit2__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, nil); A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_c2j_node__init_A_Unit3__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c2j_node__init_A_const_1)).Equals_O__Z(A_arbace_c2j_node__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_c2j_node_eval400000008_fn__400000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_c2j_node_eval400000008_fn__400000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, nil); A_arbace_c2j_node_eval400000008_fn__400000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_c2j_node__init_A_Load__O() any { A_arbace_c2j_node__init_A_Init(); jrt.StartCheck(); A_arbace_c2j_node__init_A_Unit0__O(); A_arbace_c2j_node__init_A_Unit1__O(); A_arbace_c2j_node__init_A_Unit2__O(); A_arbace_c2j_node__init_A_Unit3__O(); A_arbace_c2j_node__init_A_Unit4__O(); A_arbace_c2j_node__init_A_Unit5__O(); A_arbace_c2j_node__init_A_Unit6__O(); A_arbace_c2j_node__init_A_Unit7__O(); A_arbace_c2j_node__init_A_Unit8__O(); A_arbace_c2j_node__init_A_Unit9__O(); A_arbace_c2j_node__init_A_Unit10__O(); A_arbace_c2j_node__init_A_Unit11__O(); A_arbace_c2j_node__init_A_Unit12__O(); A_arbace_c2j_node__init_A_Unit13__O(); A_arbace_c2j_node__init_A_Unit14__O(); A_arbace_c2j_node__init_A_Unit15__O(); A_arbace_c2j_node__init_A_Unit16__O(); A_arbace_c2j_node__init_A_Unit17__O(); A_arbace_c2j_node__init_A_Unit18__O(); A_arbace_c2j_node__init_A_Unit19__O(); A_arbace_c2j_node__init_A_Unit20__O(); A_arbace_c2j_node__init_A_Unit21__O(); A_arbace_c2j_node__init_A_Unit22__O(); A_arbace_c2j_node__init_A_Unit23__O(); A_arbace_c2j_node__init_A_Unit24__O(); A_arbace_c2j_node__init_A_Unit25__O(); A_arbace_c2j_node__init_A_Unit26__O(); A_arbace_c2j_node__init_A_Unit27__O(); A_arbace_c2j_node__init_A_Unit28__O(); A_arbace_c2j_node__init_A_Unit29__O(); A_arbace_c2j_node__init_A_Unit30__O(); A_arbace_c2j_node__init_A_Unit31__O(); A_arbace_c2j_node__init_A_Unit32__O(); A_arbace_c2j_node__init_A_Unit33__O(); A_arbace_c2j_node__init_A_Unit34__O(); A_arbace_c2j_node__init_A_Unit35__O(); A_arbace_c2j_node__init_A_Unit36__O(); A_arbace_c2j_node__init_A_Unit37__O(); A_arbace_c2j_node__init_A_Unit38__O(); A_arbace_c2j_node__init_A_Unit39__O(); A_arbace_c2j_node__init_A_Unit40__O(); A_arbace_c2j_node__init_A_Unit41__O(); return nil }











































func A_arbace_c2j_node__init_A_Unit4__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(49, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_4; var tmp2 any; var root_5 any = A_arbace_c2j_node__init_A_const_5.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_7 lang.IFn; if

	linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = lang.PersistentVector_EMPTY.Ref(); if linked_6 == nil { tmp2 = ifn_7.Invoke_O__O(arg_8) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_5, arg_8) }; /*line :49:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_c2j_node__init_A_const_4; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_6)); return A_arbace_c2j_node__init_A_const_4 }



func A_arbace_c2j_node__init_A_Unit5__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_7; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_c2j_node_register_BANG__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c2j_node_register_BANG__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, nil); A_arbace_c2j_node_register_BANG__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_8)); return A_arbace_c2j_node__init_A_const_7 }





func A_arbace_c2j_node__init_A_Unit6__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_9; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_c2j_node_parse_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c2j_node_parse_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, nil); A_arbace_c2j_node_parse_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_10)); return A_arbace_c2j_node__init_A_const_9 }






func A_arbace_c2j_node__init_A_Unit7__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(66, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_c2j_node_field_names_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c2j_node_field_names_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, nil); A_arbace_c2j_node_field_names_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_12)); return A_arbace_c2j_node__init_A_const_11 }





func A_arbace_c2j_node__init_A_Unit8__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_c2j_node_children_bind_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c2j_node_children_bind_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_128, false, nil); A_arbace_c2j_node_children_bind_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_14)); return A_arbace_c2j_node__init_A_const_13 }

func A_arbace_c2j_node__init_A_Unit9__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_c2j_node_walk_syms_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_c2j_node_walk_syms_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_129, false, nil); A_arbace_c2j_node_walk_syms_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_16)); return A_arbace_c2j_node__init_A_const_15 }









func A_arbace_c2j_node__init_A_Unit10__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(84, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_c2j_node_head_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_c2j_node_head_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_130, false, nil); A_arbace_c2j_node_head_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_18)); return A_arbace_c2j_node__init_A_const_17 }

func A_arbace_c2j_node__init_A_Unit11__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(86, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_c2j_node_runs_children_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c2j_node_runs_children_QMARK__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, nil); A_arbace_c2j_node_runs_children_QMARK__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_20)); return A_arbace_c2j_node__init_A_const_19 }















func A_arbace_c2j_node__init_A_Unit12__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_21; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_22)); return A_arbace_c2j_node__init_A_const_21 }

func A_arbace_c2j_node__init_A_Unit13__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(104, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_c2j_node_q_elems_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_c2j_node_q_elems_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, nil); A_arbace_c2j_node_q_elems_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_24)); return A_arbace_c2j_node__init_A_const_23 }












func A_arbace_c2j_node__init_A_Unit14__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_c2j_node_q_drop_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_c2j_node_q_drop_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_133, false, nil); A_arbace_c2j_node_q_drop_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_26)); return A_arbace_c2j_node__init_A_const_25 }

func A_arbace_c2j_node__init_A_Unit15__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(119, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_c2j_node_q_body_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_c2j_node_q_body_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, nil); A_arbace_c2j_node_q_body_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_28)); return A_arbace_c2j_node__init_A_const_27 }








func A_arbace_c2j_node__init_A_Unit16__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_c2j_node_qs_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_c2j_node_qs_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, nil); A_arbace_c2j_node_qs_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_30)); return A_arbace_c2j_node__init_A_const_29 }








func A_arbace_c2j_node__init_A_Unit17__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(137, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_c2j_node_q_seq_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_c2j_node_q_seq_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_136, false, nil); A_arbace_c2j_node_q_seq_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_32)); return A_arbace_c2j_node__init_A_const_31 }




















































func A_arbace_c2j_node__init_A_Unit18__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_c2j_node_q_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_c2j_node_q_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_137, false, nil); A_arbace_c2j_node_q_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_33)); return A_arbace_c2j_node__init_A_const_21 }














func A_arbace_c2j_node__init_A_Unit19__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(205, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_c2j_node_emit_fn_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_c2j_node_emit_fn_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_138, false, nil); A_arbace_c2j_node_emit_fn_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_35)); return A_arbace_c2j_node__init_A_const_34 }


























func A_arbace_c2j_node__init_A_Unit20__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_c2j_node_defnode_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_c2j_node_defnode_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_139, false, nil); A_arbace_c2j_node_defnode_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_37)); return A_arbace_c2j_node__init_A_const_36 }
//line :232:1
func A_arbace_c2j_node__init_A_Unit21__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); A_arbace_c2j_node__init_A_const_36.SetMacro__V(); return nil }
//line :232:1
func A_arbace_c2j_node__init_A_Unit22__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); return A_arbace_c2j_node__init_A_const_36 }











func A_arbace_c2j_node__init_A_Unit23__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(244, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_38; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_c2j_node__init_A_const_39.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O_O__O(A_arbace_c2j_node__init_A_const_40, A_arbace_c2j_node__init_A_const_41, A_arbace_c2j_node__init_A_const_42, A_arbace_c2j_node__init_A_const_43, A_arbace_c2j_node__init_A_const_44, A_arbace_c2j_node__init_A_const_45, A_arbace_c2j_node__init_A_const_46, A_arbace_c2j_node__init_A_const_47, A_arbace_c2j_node__init_A_const_48, A_arbace_c2j_node__init_A_const_49, A_arbace_c2j_node__init_A_const_50, A_arbace_c2j_node__init_A_const_51)); var tmp2 *lang.Var = A_arbace_c2j_node__init_A_const_38; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_52)); return A_arbace_c2j_node__init_A_const_38 }




















func A_arbace_c2j_node__init_A_Unit24__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(265, 1); A_arbace_c2j_node__init_A_const_53.BindRoot_O__V(A_arbace_c2j_node__init_A_const_54); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_53; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_55)); return A_arbace_c2j_node__init_A_const_53 }


func A_arbace_c2j_node__init_A_Unit25__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(268, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__55 any = A_arbace_c2j_node_invalid_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_c2j_node_invalid_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, false, nil); A_arbace_c2j_node_invalid_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__55, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_57)); return A_arbace_c2j_node__init_A_const_56 }

func A_arbace_c2j_node__init_A_Unit26__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(270, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__57 any = A_arbace_c2j_node_realize_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_c2j_node_realize_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, false, nil); A_arbace_c2j_node_realize_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__57, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_59)); return A_arbace_c2j_node__init_A_const_58 }








func A_arbace_c2j_node__init_A_Unit27__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(279, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__59 any = A_arbace_c2j_node_arg_kind_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_c2j_node_arg_kind_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_142, false, nil); A_arbace_c2j_node_arg_kind_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__59, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_61)); return A_arbace_c2j_node__init_A_const_60 }




func A_arbace_c2j_node__init_A_Unit28__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(284, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__61 any = A_arbace_c2j_node_ret_chans_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_c2j_node_ret_chans_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_143, false, nil); A_arbace_c2j_node_ret_chans_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__61, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_63)); return A_arbace_c2j_node__init_A_const_62 }




func A_arbace_c2j_node__init_A_Unit29__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(289, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_65)); return A_arbace_c2j_node__init_A_const_64 }

func A_arbace_c2j_node__init_A_Unit30__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(291, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__63 any = A_arbace_c2j_node_qe_elems_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_c2j_node_qe_elems_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_144, false, nil); A_arbace_c2j_node_qe_elems_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__63, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_67)); return A_arbace_c2j_node__init_A_const_66 }






func A_arbace_c2j_node__init_A_Unit31__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__65 any = A_arbace_c2j_node_qe_seq_A_New(); var tmp3 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_c2j_node_qe_seq_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_145, false, nil); A_arbace_c2j_node_qe_seq_A_fn_class = fncls__64d; tmp3 = fncls__64d } else { tmp3 = fncls__64 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__65, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_69)); return A_arbace_c2j_node__init_A_const_68 }


















































































func A_arbace_c2j_node__init_A_Unit32__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(381, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__67 any = A_arbace_c2j_node_qe_A_New(); var tmp3 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_c2j_node_qe_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_146, false, nil); A_arbace_c2j_node_qe_A_fn_class = fncls__66d; tmp3 = fncls__66d } else { tmp3 = fncls__66 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__67, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_70)); return A_arbace_c2j_node__init_A_const_64 }














func A_arbace_c2j_node__init_A_Unit33__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(396, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__69 any = A_arbace_c2j_node_splits_A_New(); var tmp3 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_c2j_node_splits_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, nil); A_arbace_c2j_node_splits_A_fn_class = fncls__68d; tmp3 = fncls__68d } else { tmp3 = fncls__68 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__69, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_72)); return A_arbace_c2j_node__init_A_const_71 }









func A_arbace_c2j_node__init_A_Unit34__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(406, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__71 any = A_arbace_c2j_node_uses_many_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_c2j_node_uses_many_QMARK__A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, nil); A_arbace_c2j_node_uses_many_QMARK__A_fn_class = fncls__70d; tmp3 = fncls__70d } else { tmp3 = fncls__70 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__71, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_74)); return A_arbace_c2j_node__init_A_const_73 }






func A_arbace_c2j_node__init_A_Unit35__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(413, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__73 any = A_arbace_c2j_node_camel_A_New(); var tmp3 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_c2j_node_camel_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_149, false, nil); A_arbace_c2j_node_camel_A_fn_class = fncls__72d; tmp3 = fncls__72d } else { tmp3 = fncls__72 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__73, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_76)); return A_arbace_c2j_node__init_A_const_75 }

func A_arbace_c2j_node__init_A_Unit36__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__75 any = A_arbace_c2j_node_sym_occurs_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, nil); A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__75, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_78)); return A_arbace_c2j_node__init_A_const_77 }




func A_arbace_c2j_node__init_A_Unit37__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(420, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__77 any = A_arbace_c2j_node_tag_sym_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_c2j_node_tag_sym_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, nil); A_arbace_c2j_node_tag_sym_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__77, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_80)); return A_arbace_c2j_node__init_A_const_79 }

func A_arbace_c2j_node__init_A_Unit38__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(422, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__79 any = A_arbace_c2j_node_variant_class_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_c2j_node_variant_class_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_152, false, nil); A_arbace_c2j_node_variant_class_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__79, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_82)); return A_arbace_c2j_node__init_A_const_81 }




























































func A_arbace_c2j_node__init_A_Unit39__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(483, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__81 any = A_arbace_c2j_node_variants_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_c2j_node_variants_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_153, false, nil); A_arbace_c2j_node_variants_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__81, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_84)); return A_arbace_c2j_node__init_A_const_83 }




















func A_arbace_c2j_node__init_A_Unit40__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(504, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__83 any = A_arbace_c2j_node_clause_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_c2j_node_clause_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_154, false, nil); A_arbace_c2j_node_clause_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__83, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_86)); return A_arbace_c2j_node__init_A_const_85 }



















































func A_arbace_c2j_node__init_A_Unit41__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(556, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__85 any = A_arbace_c2j_node_code_forms_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_c2j_node_code_forms_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_155, false, nil); A_arbace_c2j_node_code_forms_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__85, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_88)); return A_arbace_c2j_node__init_A_const_87 }



type A_arbace_c2j_node__init_A struct{ jrt.Object }

var A_arbace_c2j_node__init_A_const_pool *jrt.RefArray

var A_arbace_c2j_node__init_A_const_0 *lang.Var

var A_arbace_c2j_node__init_A_const_1 any

var A_arbace_c2j_node__init_A_const_2 any

var A_arbace_c2j_node__init_A_const_3 any

var A_arbace_c2j_node__init_A_const_4 *lang.Var

var A_arbace_c2j_node__init_A_const_5 *lang.Var

var A_arbace_c2j_node__init_A_const_6 any

var A_arbace_c2j_node__init_A_const_7 *lang.Var

var A_arbace_c2j_node__init_A_const_8 any

var A_arbace_c2j_node__init_A_const_9 *lang.Var

var A_arbace_c2j_node__init_A_const_10 any

var A_arbace_c2j_node__init_A_const_11 *lang.Var

var A_arbace_c2j_node__init_A_const_12 any

var A_arbace_c2j_node__init_A_const_13 *lang.Var

var A_arbace_c2j_node__init_A_const_14 any

var A_arbace_c2j_node__init_A_const_15 *lang.Var

var A_arbace_c2j_node__init_A_const_16 any

var A_arbace_c2j_node__init_A_const_17 *lang.Var

var A_arbace_c2j_node__init_A_const_18 any

var A_arbace_c2j_node__init_A_const_19 *lang.Var

var A_arbace_c2j_node__init_A_const_20 any

var A_arbace_c2j_node__init_A_const_21 *lang.Var

var A_arbace_c2j_node__init_A_const_22 any

var A_arbace_c2j_node__init_A_const_23 *lang.Var

var A_arbace_c2j_node__init_A_const_24 any

var A_arbace_c2j_node__init_A_const_25 *lang.Var

var A_arbace_c2j_node__init_A_const_26 any

var A_arbace_c2j_node__init_A_const_27 *lang.Var

var A_arbace_c2j_node__init_A_const_28 any

var A_arbace_c2j_node__init_A_const_29 *lang.Var

var A_arbace_c2j_node__init_A_const_30 any

var A_arbace_c2j_node__init_A_const_31 *lang.Var

var A_arbace_c2j_node__init_A_const_32 any

var A_arbace_c2j_node__init_A_const_33 any

var A_arbace_c2j_node__init_A_const_34 *lang.Var

var A_arbace_c2j_node__init_A_const_35 any

var A_arbace_c2j_node__init_A_const_36 *lang.Var

var A_arbace_c2j_node__init_A_const_37 any

var A_arbace_c2j_node__init_A_const_38 *lang.Var

var A_arbace_c2j_node__init_A_const_39 *lang.Var

var A_arbace_c2j_node__init_A_const_40 *lang.Keyword

var A_arbace_c2j_node__init_A_const_41 any

var A_arbace_c2j_node__init_A_const_42 *lang.Keyword

var A_arbace_c2j_node__init_A_const_43 any

var A_arbace_c2j_node__init_A_const_44 *lang.Keyword

var A_arbace_c2j_node__init_A_const_45 any

var A_arbace_c2j_node__init_A_const_46 *lang.Keyword

var A_arbace_c2j_node__init_A_const_47 any

var A_arbace_c2j_node__init_A_const_48 *lang.Keyword

var A_arbace_c2j_node__init_A_const_49 any

var A_arbace_c2j_node__init_A_const_50 *lang.Keyword

var A_arbace_c2j_node__init_A_const_51 any

var A_arbace_c2j_node__init_A_const_52 any

var A_arbace_c2j_node__init_A_const_53 *lang.Var

var A_arbace_c2j_node__init_A_const_54 any

var A_arbace_c2j_node__init_A_const_55 any

var A_arbace_c2j_node__init_A_const_56 *lang.Var

var A_arbace_c2j_node__init_A_const_57 any

var A_arbace_c2j_node__init_A_const_58 *lang.Var

var A_arbace_c2j_node__init_A_const_59 any

var A_arbace_c2j_node__init_A_const_60 *lang.Var

var A_arbace_c2j_node__init_A_const_61 any

var A_arbace_c2j_node__init_A_const_62 *lang.Var

var A_arbace_c2j_node__init_A_const_63 any

var A_arbace_c2j_node__init_A_const_64 *lang.Var

var A_arbace_c2j_node__init_A_const_65 any

var A_arbace_c2j_node__init_A_const_66 *lang.Var

var A_arbace_c2j_node__init_A_const_67 any

var A_arbace_c2j_node__init_A_const_68 *lang.Var

var A_arbace_c2j_node__init_A_const_69 any

var A_arbace_c2j_node__init_A_const_70 any

var A_arbace_c2j_node__init_A_const_71 *lang.Var

var A_arbace_c2j_node__init_A_const_72 any

var A_arbace_c2j_node__init_A_const_73 *lang.Var

var A_arbace_c2j_node__init_A_const_74 any

var A_arbace_c2j_node__init_A_const_75 *lang.Var

var A_arbace_c2j_node__init_A_const_76 any

var A_arbace_c2j_node__init_A_const_77 *lang.Var

var A_arbace_c2j_node__init_A_const_78 any

var A_arbace_c2j_node__init_A_const_79 *lang.Var

var A_arbace_c2j_node__init_A_const_80 any

var A_arbace_c2j_node__init_A_const_81 *lang.Var

var A_arbace_c2j_node__init_A_const_82 any

var A_arbace_c2j_node__init_A_const_83 *lang.Var

var A_arbace_c2j_node__init_A_const_84 any

var A_arbace_c2j_node__init_A_const_85 *lang.Var

var A_arbace_c2j_node__init_A_const_86 any

var A_arbace_c2j_node__init_A_const_87 *lang.Var

var A_arbace_c2j_node__init_A_const_88 any

var A_arbace_c2j_node__init_A_init jrt.ClassInit

func A_arbace_c2j_node__init_A_Init() { if !A_arbace_c2j_node__init_A_init.Done() { A_arbace_c2j_node__init_A_init.Run(A_arbace_c2j_node__init_A_clinit) } }

func A_arbace_c2j_node__init_A_clinit() { A_arbace_c2j_node__init_A_clinit_p0(); A_arbace_c2j_node__init_A_clinit_p1(); A_arbace_c2j_node__init_A_clinit_p2(); A_arbace_c2j_node__init_A_clinit_p3(); A_arbace_c2j_node__init_A_clinit_p4(); A_arbace_c2j_node__init_A_clinit_p5(); A_arbace_c2j_node__init_A_clinit_p6() }

func A_arbace_c2j_node__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_c2j_node__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_122, 160); A_arbace_c2j_node__init_A_const_0 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[71]); A_arbace_c2j_node__init_A_const_1 = A_arbace_c2j_node__init_A_const_pool.A[72]; A_arbace_c2j_node__init_A_const_2 = A_arbace_c2j_node__init_A_const_pool.A[73]; A_arbace_c2j_node__init_A_const_3 = A_arbace_c2j_node__init_A_const_pool.A[74]; A_arbace_c2j_node__init_A_const_4 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[75]); A_arbace_c2j_node__init_A_const_5 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[76]); A_arbace_c2j_node__init_A_const_6 = A_arbace_c2j_node__init_A_const_pool.A[77]; A_arbace_c2j_node__init_A_const_7 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[78]); A_arbace_c2j_node__init_A_const_8 = A_arbace_c2j_node__init_A_const_pool.A[79]; A_arbace_c2j_node__init_A_const_9 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[80]); A_arbace_c2j_node__init_A_const_10 = A_arbace_c2j_node__init_A_const_pool.A[81]; A_arbace_c2j_node__init_A_const_11 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[82]); A_arbace_c2j_node__init_A_const_12 = A_arbace_c2j_node__init_A_const_pool.A[83] }

func A_arbace_c2j_node__init_A_clinit_p1() { A_arbace_c2j_node__init_A_const_13 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[84]); A_arbace_c2j_node__init_A_const_14 = A_arbace_c2j_node__init_A_const_pool.A[85]; A_arbace_c2j_node__init_A_const_15 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[86]); A_arbace_c2j_node__init_A_const_16 = A_arbace_c2j_node__init_A_const_pool.A[87]; A_arbace_c2j_node__init_A_const_17 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[88]); A_arbace_c2j_node__init_A_const_18 = A_arbace_c2j_node__init_A_const_pool.A[89]; A_arbace_c2j_node__init_A_const_19 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[90]); A_arbace_c2j_node__init_A_const_20 = A_arbace_c2j_node__init_A_const_pool.A[91]; A_arbace_c2j_node__init_A_const_21 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[92]); A_arbace_c2j_node__init_A_const_22 = A_arbace_c2j_node__init_A_const_pool.A[93]; A_arbace_c2j_node__init_A_const_23 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[94]); A_arbace_c2j_node__init_A_const_24 = A_arbace_c2j_node__init_A_const_pool.A[95]; A_arbace_c2j_node__init_A_const_25 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[96]) }

func A_arbace_c2j_node__init_A_clinit_p2() { A_arbace_c2j_node__init_A_const_26 = A_arbace_c2j_node__init_A_const_pool.A[97]; A_arbace_c2j_node__init_A_const_27 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[98]); A_arbace_c2j_node__init_A_const_28 = A_arbace_c2j_node__init_A_const_pool.A[99]; A_arbace_c2j_node__init_A_const_29 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[100]); A_arbace_c2j_node__init_A_const_30 = A_arbace_c2j_node__init_A_const_pool.A[101]; A_arbace_c2j_node__init_A_const_31 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[102]); A_arbace_c2j_node__init_A_const_32 = A_arbace_c2j_node__init_A_const_pool.A[103]; A_arbace_c2j_node__init_A_const_33 = A_arbace_c2j_node__init_A_const_pool.A[104]; A_arbace_c2j_node__init_A_const_34 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[105]); A_arbace_c2j_node__init_A_const_35 = A_arbace_c2j_node__init_A_const_pool.A[106]; A_arbace_c2j_node__init_A_const_36 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[107]); A_arbace_c2j_node__init_A_const_37 = A_arbace_c2j_node__init_A_const_pool.A[108]; A_arbace_c2j_node__init_A_const_38 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[109]) }

func A_arbace_c2j_node__init_A_clinit_p3() { A_arbace_c2j_node__init_A_const_39 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[110]); A_arbace_c2j_node__init_A_const_40 = lang.Keyword_Cast(A_arbace_c2j_node__init_A_const_pool.A[111]); A_arbace_c2j_node__init_A_const_41 = A_arbace_c2j_node__init_A_const_pool.A[112]; A_arbace_c2j_node__init_A_const_42 = lang.Keyword_Cast(A_arbace_c2j_node__init_A_const_pool.A[113]); A_arbace_c2j_node__init_A_const_43 = A_arbace_c2j_node__init_A_const_pool.A[114]; A_arbace_c2j_node__init_A_const_44 = lang.Keyword_Cast(A_arbace_c2j_node__init_A_const_pool.A[115]); A_arbace_c2j_node__init_A_const_45 = A_arbace_c2j_node__init_A_const_pool.A[116]; A_arbace_c2j_node__init_A_const_46 = lang.Keyword_Cast(A_arbace_c2j_node__init_A_const_pool.A[117]); A_arbace_c2j_node__init_A_const_47 = A_arbace_c2j_node__init_A_const_pool.A[118]; A_arbace_c2j_node__init_A_const_48 = lang.Keyword_Cast(A_arbace_c2j_node__init_A_const_pool.A[119]); A_arbace_c2j_node__init_A_const_49 = A_arbace_c2j_node__init_A_const_pool.A[120]; A_arbace_c2j_node__init_A_const_50 = lang.Keyword_Cast(A_arbace_c2j_node__init_A_const_pool.A[121]); A_arbace_c2j_node__init_A_const_51 = A_arbace_c2j_node__init_A_const_pool.A[122] }

func A_arbace_c2j_node__init_A_clinit_p4() { A_arbace_c2j_node__init_A_const_52 = A_arbace_c2j_node__init_A_const_pool.A[123]; A_arbace_c2j_node__init_A_const_53 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[124]); A_arbace_c2j_node__init_A_const_54 = A_arbace_c2j_node__init_A_const_pool.A[125]; A_arbace_c2j_node__init_A_const_55 = A_arbace_c2j_node__init_A_const_pool.A[126]; A_arbace_c2j_node__init_A_const_56 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[127]); A_arbace_c2j_node__init_A_const_57 = A_arbace_c2j_node__init_A_const_pool.A[128]; A_arbace_c2j_node__init_A_const_58 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[129]); A_arbace_c2j_node__init_A_const_59 = A_arbace_c2j_node__init_A_const_pool.A[130]; A_arbace_c2j_node__init_A_const_60 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[131]); A_arbace_c2j_node__init_A_const_61 = A_arbace_c2j_node__init_A_const_pool.A[132]; A_arbace_c2j_node__init_A_const_62 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[133]); A_arbace_c2j_node__init_A_const_63 = A_arbace_c2j_node__init_A_const_pool.A[134]; A_arbace_c2j_node__init_A_const_64 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[135]); A_arbace_c2j_node__init_A_const_65 = A_arbace_c2j_node__init_A_const_pool.A[136] }

func A_arbace_c2j_node__init_A_clinit_p5() { A_arbace_c2j_node__init_A_const_66 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[137]); A_arbace_c2j_node__init_A_const_67 = A_arbace_c2j_node__init_A_const_pool.A[138]; A_arbace_c2j_node__init_A_const_68 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[139]); A_arbace_c2j_node__init_A_const_69 = A_arbace_c2j_node__init_A_const_pool.A[140]; A_arbace_c2j_node__init_A_const_70 = A_arbace_c2j_node__init_A_const_pool.A[141]; A_arbace_c2j_node__init_A_const_71 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[142]); A_arbace_c2j_node__init_A_const_72 = A_arbace_c2j_node__init_A_const_pool.A[143]; A_arbace_c2j_node__init_A_const_73 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[144]); A_arbace_c2j_node__init_A_const_74 = A_arbace_c2j_node__init_A_const_pool.A[145]; A_arbace_c2j_node__init_A_const_75 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[146]); A_arbace_c2j_node__init_A_const_76 = A_arbace_c2j_node__init_A_const_pool.A[147]; A_arbace_c2j_node__init_A_const_77 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[148]); A_arbace_c2j_node__init_A_const_78 = A_arbace_c2j_node__init_A_const_pool.A[149] }

func A_arbace_c2j_node__init_A_clinit_p6() { A_arbace_c2j_node__init_A_const_79 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[150]); A_arbace_c2j_node__init_A_const_80 = A_arbace_c2j_node__init_A_const_pool.A[151]; A_arbace_c2j_node__init_A_const_81 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[152]); A_arbace_c2j_node__init_A_const_82 = A_arbace_c2j_node__init_A_const_pool.A[153]; A_arbace_c2j_node__init_A_const_83 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[154]); A_arbace_c2j_node__init_A_const_84 = A_arbace_c2j_node__init_A_const_pool.A[155]; A_arbace_c2j_node__init_A_const_85 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[156]); A_arbace_c2j_node__init_A_const_86 = A_arbace_c2j_node__init_A_const_pool.A[157]; A_arbace_c2j_node__init_A_const_87 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[158]); A_arbace_c2j_node__init_A_const_88 = A_arbace_c2j_node__init_A_const_pool.A[159] }

func A_arbace_c2j_node__init_A_New() *A_arbace_c2j_node__init_A { A_arbace_c2j_node__init_A_Init(); t := &A_arbace_c2j_node__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_node__init_A) Ctor() {}

func (t *A_arbace_c2j_node__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_node__init_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_node__init_A_class }

func (t *A_arbace_c2j_node__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_node__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_node__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_node__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_node__init_A); return ok }

func A_arbace_c2j_node__init_A_Cast(x any) *A_arbace_c2j_node__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_node__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_node__init_A_class)) }; return v }
