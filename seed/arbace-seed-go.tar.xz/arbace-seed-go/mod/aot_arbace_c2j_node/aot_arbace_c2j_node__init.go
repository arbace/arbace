//line aot_arbace_c2j_node__init.ae:1
package aot_arbace_c2j_node

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2j_node__init_A_Unit0__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_c2j_node__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c2j_node__init_A_const_1) }
//line :1:1
func A_arbace_c2j_node__init_A_Unit1__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_c2j_node__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_2)) }
//line :1:1
func A_arbace_c2j_node__init_A_Unit2__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_c2j_node_eval400000004_loading__1927001464__auto____400000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_c2j_node__init_A_Unit3__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c2j_node__init_A_const_1)).Equals_O__Z(A_arbace_c2j_node__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_c2j_node_eval400000008_fn__400000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_c2j_node_eval400000008_fn__400000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_c2j_node_eval400000008_fn__400000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_c2j_node__init_A_Load__O() any { A_arbace_c2j_node__init_A_Init(); jrt.StartCheck(); A_arbace_c2j_node__init_A_Unit0__O(); A_arbace_c2j_node__init_A_Unit1__O(); A_arbace_c2j_node__init_A_Unit2__O(); A_arbace_c2j_node__init_A_Unit3__O(); A_arbace_c2j_node__init_A_Unit4__O(); A_arbace_c2j_node__init_A_Unit5__O(); A_arbace_c2j_node__init_A_Unit6__O(); A_arbace_c2j_node__init_A_Unit7__O(); A_arbace_c2j_node__init_A_Unit8__O(); A_arbace_c2j_node__init_A_Unit9__O(); A_arbace_c2j_node__init_A_Unit10__O(); A_arbace_c2j_node__init_A_Unit11__O(); A_arbace_c2j_node__init_A_Unit12__O(); A_arbace_c2j_node__init_A_Unit13__O(); A_arbace_c2j_node__init_A_Unit14__O(); A_arbace_c2j_node__init_A_Unit15__O(); A_arbace_c2j_node__init_A_Unit16__O(); A_arbace_c2j_node__init_A_Unit17__O(); A_arbace_c2j_node__init_A_Unit18__O(); A_arbace_c2j_node__init_A_Unit19__O(); A_arbace_c2j_node__init_A_Unit20__O(); A_arbace_c2j_node__init_A_Unit21__O(); A_arbace_c2j_node__init_A_Unit22__O(); A_arbace_c2j_node__init_A_Unit23__O(); A_arbace_c2j_node__init_A_Unit24__O(); A_arbace_c2j_node__init_A_Unit25__O(); A_arbace_c2j_node__init_A_Unit26__O(); A_arbace_c2j_node__init_A_Unit27__O(); A_arbace_c2j_node__init_A_Unit28__O(); A_arbace_c2j_node__init_A_Unit29__O(); A_arbace_c2j_node__init_A_Unit30__O(); A_arbace_c2j_node__init_A_Unit31__O(); A_arbace_c2j_node__init_A_Unit32__O(); A_arbace_c2j_node__init_A_Unit33__O(); A_arbace_c2j_node__init_A_Unit34__O(); A_arbace_c2j_node__init_A_Unit35__O(); A_arbace_c2j_node__init_A_Unit36__O(); A_arbace_c2j_node__init_A_Unit37__O(); A_arbace_c2j_node__init_A_Unit38__O(); A_arbace_c2j_node__init_A_Unit39__O(); A_arbace_c2j_node__init_A_Unit40__O(); A_arbace_c2j_node__init_A_Unit41__O(); return nil }










































func A_arbace_c2j_node__init_A_Unit4__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_4; var tmp2 any; var root_3 any = A_arbace_c2j_node__init_A_const_5.GetRawRoot__O(); var linked_4 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_5 lang.IFn; if

	linked_4 == nil { ifn_5 = lang.IFn_Cast(root_3) } else { ifn_5 = nil }; var arg_6 any = lang.PersistentVector_EMPTY.Ref(); if linked_4 == nil { tmp2 = ifn_5.Invoke_O__O(arg_6) } else { tmp2 = linked_4.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_3, arg_6) }; /*line :48:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_c2j_node__init_A_const_4; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_6)); return A_arbace_c2j_node__init_A_const_4 }



func A_arbace_c2j_node__init_A_Unit5__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(52, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_7; var tmp2 any = A_arbace_c2j_node_register_BANG__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_c2j_node_register_BANG__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_c2j_node_register_BANG__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_8)); return A_arbace_c2j_node__init_A_const_7 }





func A_arbace_c2j_node__init_A_Unit6__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_9; var tmp2 any = A_arbace_c2j_node_parse_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_c2j_node_parse_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_c2j_node_parse_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_9; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_10)); return A_arbace_c2j_node__init_A_const_9 }






func A_arbace_c2j_node__init_A_Unit7__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_11; var tmp2 any = A_arbace_c2j_node_field_names_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_c2j_node_field_names_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_c2j_node_field_names_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_12)); return A_arbace_c2j_node__init_A_const_11 }





func A_arbace_c2j_node__init_A_Unit8__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(71, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_13; var tmp2 any = A_arbace_c2j_node_children_bind_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_c2j_node_children_bind_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_c2j_node_children_bind_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_14)); return A_arbace_c2j_node__init_A_const_13 }

func A_arbace_c2j_node__init_A_Unit9__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_15; var tmp2 any = A_arbace_c2j_node_walk_syms_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_c2j_node_walk_syms_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_c2j_node_walk_syms_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_16)); return A_arbace_c2j_node__init_A_const_15 }









func A_arbace_c2j_node__init_A_Unit10__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_17; var tmp2 any = A_arbace_c2j_node_head_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_c2j_node_head_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_c2j_node_head_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_18)); return A_arbace_c2j_node__init_A_const_17 }

func A_arbace_c2j_node__init_A_Unit11__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(85, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_19; var tmp2 any = A_arbace_c2j_node_runs_children_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_c2j_node_runs_children_QMARK__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_c2j_node_runs_children_QMARK__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_20)); return A_arbace_c2j_node__init_A_const_19 }















func A_arbace_c2j_node__init_A_Unit12__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_21; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_22)); return A_arbace_c2j_node__init_A_const_21 }

func A_arbace_c2j_node__init_A_Unit13__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_23; var tmp2 any = A_arbace_c2j_node_q_elems_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_c2j_node_q_elems_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_c2j_node_q_elems_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_24)); return A_arbace_c2j_node__init_A_const_23 }












func A_arbace_c2j_node__init_A_Unit14__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_25; var tmp2 any = A_arbace_c2j_node_q_drop_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_c2j_node_q_drop_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_c2j_node_q_drop_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_26)); return A_arbace_c2j_node__init_A_const_25 }

func A_arbace_c2j_node__init_A_Unit15__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(118, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_27; var tmp2 any = A_arbace_c2j_node_q_body_A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_c2j_node_q_body_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_c2j_node_q_body_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_28)); return A_arbace_c2j_node__init_A_const_27 }








func A_arbace_c2j_node__init_A_Unit16__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(127, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_29; var tmp2 any = A_arbace_c2j_node_qs_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_c2j_node_qs_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_c2j_node_qs_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_30)); return A_arbace_c2j_node__init_A_const_29 }








func A_arbace_c2j_node__init_A_Unit17__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(136, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_31; var tmp2 any = A_arbace_c2j_node_q_seq_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_c2j_node_q_seq_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_c2j_node_q_seq_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_32)); return A_arbace_c2j_node__init_A_const_31 }


















































func A_arbace_c2j_node__init_A_Unit18__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(187, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_21; var tmp2 any = A_arbace_c2j_node_q_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_c2j_node_q_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_c2j_node_q_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_33)); return A_arbace_c2j_node__init_A_const_21 }














func A_arbace_c2j_node__init_A_Unit19__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_34; var tmp2 any = A_arbace_c2j_node_emit_fn_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_c2j_node_emit_fn_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_c2j_node_emit_fn_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_35)); return A_arbace_c2j_node__init_A_const_34 }


























func A_arbace_c2j_node__init_A_Unit20__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_36; var tmp2 any = A_arbace_c2j_node_defnode_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_c2j_node_defnode_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_c2j_node_defnode_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_37)); return A_arbace_c2j_node__init_A_const_36 }
//line :229:1
func A_arbace_c2j_node__init_A_Unit21__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); A_arbace_c2j_node__init_A_const_36.SetMacro__V(); return nil }
//line :229:1
func A_arbace_c2j_node__init_A_Unit22__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); return A_arbace_c2j_node__init_A_const_36 }











func A_arbace_c2j_node__init_A_Unit23__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(241, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_38; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_c2j_node__init_A_const_39.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O_O_O__O(A_arbace_c2j_node__init_A_const_40, A_arbace_c2j_node__init_A_const_41, A_arbace_c2j_node__init_A_const_42, A_arbace_c2j_node__init_A_const_43, A_arbace_c2j_node__init_A_const_44, A_arbace_c2j_node__init_A_const_45, A_arbace_c2j_node__init_A_const_46, A_arbace_c2j_node__init_A_const_47, A_arbace_c2j_node__init_A_const_48, A_arbace_c2j_node__init_A_const_49, A_arbace_c2j_node__init_A_const_50, A_arbace_c2j_node__init_A_const_51)); var tmp2 *lang.Var = A_arbace_c2j_node__init_A_const_38; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_52)); return A_arbace_c2j_node__init_A_const_38 }




















func A_arbace_c2j_node__init_A_Unit24__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(262, 1); A_arbace_c2j_node__init_A_const_53.BindRoot_O__V(A_arbace_c2j_node__init_A_const_54); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_53; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_55)); return A_arbace_c2j_node__init_A_const_53 }


func A_arbace_c2j_node__init_A_Unit25__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(265, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_56; var tmp2 any = A_arbace_c2j_node_invalid_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_c2j_node_invalid_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_c2j_node_invalid_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_57)); return A_arbace_c2j_node__init_A_const_56 }

func A_arbace_c2j_node__init_A_Unit26__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_58; var tmp2 any = A_arbace_c2j_node_realize_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_c2j_node_realize_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_c2j_node_realize_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_59)); return A_arbace_c2j_node__init_A_const_58 }








func A_arbace_c2j_node__init_A_Unit27__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(276, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_60; var tmp2 any = A_arbace_c2j_node_arg_kind_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_c2j_node_arg_kind_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_c2j_node_arg_kind_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_61)); return A_arbace_c2j_node__init_A_const_60 }




func A_arbace_c2j_node__init_A_Unit28__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(281, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_62; var tmp2 any = A_arbace_c2j_node_ret_chans_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_c2j_node_ret_chans_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_c2j_node_ret_chans_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_63)); return A_arbace_c2j_node__init_A_const_62 }




func A_arbace_c2j_node__init_A_Unit29__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(286, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_64; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_65)); return A_arbace_c2j_node__init_A_const_64 }

func A_arbace_c2j_node__init_A_Unit30__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_66; var tmp2 any = A_arbace_c2j_node_qe_elems_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_c2j_node_qe_elems_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_c2j_node_qe_elems_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_67)); return A_arbace_c2j_node__init_A_const_66 }






func A_arbace_c2j_node__init_A_Unit31__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(295, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_68; var tmp2 any = A_arbace_c2j_node_qe_seq_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_c2j_node_qe_seq_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_c2j_node_qe_seq_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_69)); return A_arbace_c2j_node__init_A_const_68 }














































































func A_arbace_c2j_node__init_A_Unit32__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(374, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_64; var tmp2 any = A_arbace_c2j_node_qe_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_c2j_node_qe_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_c2j_node_qe_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_70)); return A_arbace_c2j_node__init_A_const_64 }














func A_arbace_c2j_node__init_A_Unit33__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(389, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_71; var tmp2 any = A_arbace_c2j_node_splits_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_c2j_node_splits_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_c2j_node_splits_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_72)); return A_arbace_c2j_node__init_A_const_71 }









func A_arbace_c2j_node__init_A_Unit34__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(399, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_73; var tmp2 any = A_arbace_c2j_node_uses_many_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_c2j_node_uses_many_QMARK__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_c2j_node_uses_many_QMARK__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_74)); return A_arbace_c2j_node__init_A_const_73 }






func A_arbace_c2j_node__init_A_Unit35__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(406, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_75; var tmp2 any = A_arbace_c2j_node_camel_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_c2j_node_camel_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_c2j_node_camel_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_76)); return A_arbace_c2j_node__init_A_const_75 }

func A_arbace_c2j_node__init_A_Unit36__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(408, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_77; var tmp2 any = A_arbace_c2j_node_sym_occurs_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_c2j_node_sym_occurs_QMARK__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_78)); return A_arbace_c2j_node__init_A_const_77 }




func A_arbace_c2j_node__init_A_Unit37__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(413, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_79; var tmp2 any = A_arbace_c2j_node_tag_sym_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_c2j_node_tag_sym_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_c2j_node_tag_sym_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_80)); return A_arbace_c2j_node__init_A_const_79 }

func A_arbace_c2j_node__init_A_Unit38__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_81; var tmp2 any = A_arbace_c2j_node_variant_class_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_c2j_node_variant_class_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_c2j_node_variant_class_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_82)); return A_arbace_c2j_node__init_A_const_81 }




























































func A_arbace_c2j_node__init_A_Unit39__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(476, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_83; var tmp2 any = A_arbace_c2j_node_variants_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_c2j_node_variants_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_c2j_node_variants_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_84)); return A_arbace_c2j_node__init_A_const_83 }




















func A_arbace_c2j_node__init_A_Unit40__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(497, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_85; var tmp2 any = A_arbace_c2j_node_clause_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_c2j_node_clause_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_c2j_node_clause_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_86)); return A_arbace_c2j_node__init_A_const_85 }



















































func A_arbace_c2j_node__init_A_Unit41__O() any { A_arbace_c2j_node__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(549, 1); var tmp1 *lang.Var = A_arbace_c2j_node__init_A_const_87; var tmp2 any = A_arbace_c2j_node_code_forms_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_c2j_node_code_forms_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_c2j_node_code_forms_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2j_node__init_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2j_node__init_A_const_88)); return A_arbace_c2j_node__init_A_const_87 }



type A_arbace_c2j_node__init_A struct{ jrt.Object }

var A_arbace_c2j_node__init_A_const_pool *jrt.RefArray

var A_arbace_c2j_node__init_A_const_0 *lang.Var

var A_arbace_c2j_node__init_A_const_1 any

var A_arbace_c2j_node__init_A_const_2 any

var A_arbace_c2j_node__init_A_const_3 any

var A_arbace_c2j_node__init_A_const_4 *lang.Var

var A_arbace_c2j_node__init_A_const_5 *lang.Var

var A_arbace_c2j_node__init_A_const_6 any

var A_arbace_c2j_node__init_A_const_7 *lang.Var

var A_arbace_c2j_node__init_A_const_8 any

var A_arbace_c2j_node__init_A_const_9 *lang.Var

var A_arbace_c2j_node__init_A_const_10 any

var A_arbace_c2j_node__init_A_const_11 *lang.Var

var A_arbace_c2j_node__init_A_const_12 any

var A_arbace_c2j_node__init_A_const_13 *lang.Var

var A_arbace_c2j_node__init_A_const_14 any

var A_arbace_c2j_node__init_A_const_15 *lang.Var

var A_arbace_c2j_node__init_A_const_16 any

var A_arbace_c2j_node__init_A_const_17 *lang.Var

var A_arbace_c2j_node__init_A_const_18 any

var A_arbace_c2j_node__init_A_const_19 *lang.Var

var A_arbace_c2j_node__init_A_const_20 any

var A_arbace_c2j_node__init_A_const_21 *lang.Var

var A_arbace_c2j_node__init_A_const_22 any

var A_arbace_c2j_node__init_A_const_23 *lang.Var

var A_arbace_c2j_node__init_A_const_24 any

var A_arbace_c2j_node__init_A_const_25 *lang.Var

var A_arbace_c2j_node__init_A_const_26 any

var A_arbace_c2j_node__init_A_const_27 *lang.Var

var A_arbace_c2j_node__init_A_const_28 any

var A_arbace_c2j_node__init_A_const_29 *lang.Var

var A_arbace_c2j_node__init_A_const_30 any

var A_arbace_c2j_node__init_A_const_31 *lang.Var

var A_arbace_c2j_node__init_A_const_32 any

var A_arbace_c2j_node__init_A_const_33 any

var A_arbace_c2j_node__init_A_const_34 *lang.Var

var A_arbace_c2j_node__init_A_const_35 any

var A_arbace_c2j_node__init_A_const_36 *lang.Var

var A_arbace_c2j_node__init_A_const_37 any

var A_arbace_c2j_node__init_A_const_38 *lang.Var

var A_arbace_c2j_node__init_A_const_39 *lang.Var

var A_arbace_c2j_node__init_A_const_40 *lang.Keyword

var A_arbace_c2j_node__init_A_const_41 any

var A_arbace_c2j_node__init_A_const_42 *lang.Keyword

var A_arbace_c2j_node__init_A_const_43 any

var A_arbace_c2j_node__init_A_const_44 *lang.Keyword

var A_arbace_c2j_node__init_A_const_45 any

var A_arbace_c2j_node__init_A_const_46 *lang.Keyword

var A_arbace_c2j_node__init_A_const_47 any

var A_arbace_c2j_node__init_A_const_48 *lang.Keyword

var A_arbace_c2j_node__init_A_const_49 any

var A_arbace_c2j_node__init_A_const_50 *lang.Keyword

var A_arbace_c2j_node__init_A_const_51 any

var A_arbace_c2j_node__init_A_const_52 any

var A_arbace_c2j_node__init_A_const_53 *lang.Var

var A_arbace_c2j_node__init_A_const_54 any

var A_arbace_c2j_node__init_A_const_55 any

var A_arbace_c2j_node__init_A_const_56 *lang.Var

var A_arbace_c2j_node__init_A_const_57 any

var A_arbace_c2j_node__init_A_const_58 *lang.Var

var A_arbace_c2j_node__init_A_const_59 any

var A_arbace_c2j_node__init_A_const_60 *lang.Var

var A_arbace_c2j_node__init_A_const_61 any

var A_arbace_c2j_node__init_A_const_62 *lang.Var

var A_arbace_c2j_node__init_A_const_63 any

var A_arbace_c2j_node__init_A_const_64 *lang.Var

var A_arbace_c2j_node__init_A_const_65 any

var A_arbace_c2j_node__init_A_const_66 *lang.Var

var A_arbace_c2j_node__init_A_const_67 any

var A_arbace_c2j_node__init_A_const_68 *lang.Var

var A_arbace_c2j_node__init_A_const_69 any

var A_arbace_c2j_node__init_A_const_70 any

var A_arbace_c2j_node__init_A_const_71 *lang.Var

var A_arbace_c2j_node__init_A_const_72 any

var A_arbace_c2j_node__init_A_const_73 *lang.Var

var A_arbace_c2j_node__init_A_const_74 any

var A_arbace_c2j_node__init_A_const_75 *lang.Var

var A_arbace_c2j_node__init_A_const_76 any

var A_arbace_c2j_node__init_A_const_77 *lang.Var

var A_arbace_c2j_node__init_A_const_78 any

var A_arbace_c2j_node__init_A_const_79 *lang.Var

var A_arbace_c2j_node__init_A_const_80 any

var A_arbace_c2j_node__init_A_const_81 *lang.Var

var A_arbace_c2j_node__init_A_const_82 any

var A_arbace_c2j_node__init_A_const_83 *lang.Var

var A_arbace_c2j_node__init_A_const_84 any

var A_arbace_c2j_node__init_A_const_85 *lang.Var

var A_arbace_c2j_node__init_A_const_86 any

var A_arbace_c2j_node__init_A_const_87 *lang.Var

var A_arbace_c2j_node__init_A_const_88 any

var A_arbace_c2j_node__init_A_init jrt.ClassInit

func A_arbace_c2j_node__init_A_Init() { if !A_arbace_c2j_node__init_A_init.Done() { A_arbace_c2j_node__init_A_init.Run(A_arbace_c2j_node__init_A_clinit) } }

func A_arbace_c2j_node__init_A_clinit() { A_arbace_c2j_node__init_A_clinit_p0(); A_arbace_c2j_node__init_A_clinit_p1(); A_arbace_c2j_node__init_A_clinit_p2(); A_arbace_c2j_node__init_A_clinit_p3(); A_arbace_c2j_node__init_A_clinit_p4(); A_arbace_c2j_node__init_A_clinit_p5(); A_arbace_c2j_node__init_A_clinit_p6() }

func A_arbace_c2j_node__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_c2j_node__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_122, 160); A_arbace_c2j_node__init_A_const_0 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[71]); A_arbace_c2j_node__init_A_const_1 = A_arbace_c2j_node__init_A_const_pool.A[72]; A_arbace_c2j_node__init_A_const_2 = A_arbace_c2j_node__init_A_const_pool.A[73]; A_arbace_c2j_node__init_A_const_3 = A_arbace_c2j_node__init_A_const_pool.A[74]; A_arbace_c2j_node__init_A_const_4 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[75]); A_arbace_c2j_node__init_A_const_5 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[76]); A_arbace_c2j_node__init_A_const_6 = A_arbace_c2j_node__init_A_const_pool.A[77]; A_arbace_c2j_node__init_A_const_7 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[78]); A_arbace_c2j_node__init_A_const_8 = A_arbace_c2j_node__init_A_const_pool.A[79]; A_arbace_c2j_node__init_A_const_9 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[80]); A_arbace_c2j_node__init_A_const_10 = A_arbace_c2j_node__init_A_const_pool.A[81]; A_arbace_c2j_node__init_A_const_11 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[82]); A_arbace_c2j_node__init_A_const_12 = A_arbace_c2j_node__init_A_const_pool.A[83] }

func A_arbace_c2j_node__init_A_clinit_p1() { A_arbace_c2j_node__init_A_const_13 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[84]); A_arbace_c2j_node__init_A_const_14 = A_arbace_c2j_node__init_A_const_pool.A[85]; A_arbace_c2j_node__init_A_const_15 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[86]); A_arbace_c2j_node__init_A_const_16 = A_arbace_c2j_node__init_A_const_pool.A[87]; A_arbace_c2j_node__init_A_const_17 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[88]); A_arbace_c2j_node__init_A_const_18 = A_arbace_c2j_node__init_A_const_pool.A[89]; A_arbace_c2j_node__init_A_const_19 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[90]); A_arbace_c2j_node__init_A_const_20 = A_arbace_c2j_node__init_A_const_pool.A[91]; A_arbace_c2j_node__init_A_const_21 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[92]); A_arbace_c2j_node__init_A_const_22 = A_arbace_c2j_node__init_A_const_pool.A[93]; A_arbace_c2j_node__init_A_const_23 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[94]); A_arbace_c2j_node__init_A_const_24 = A_arbace_c2j_node__init_A_const_pool.A[95]; A_arbace_c2j_node__init_A_const_25 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[96]) }

func A_arbace_c2j_node__init_A_clinit_p2() { A_arbace_c2j_node__init_A_const_26 = A_arbace_c2j_node__init_A_const_pool.A[97]; A_arbace_c2j_node__init_A_const_27 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[98]); A_arbace_c2j_node__init_A_const_28 = A_arbace_c2j_node__init_A_const_pool.A[99]; A_arbace_c2j_node__init_A_const_29 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[100]); A_arbace_c2j_node__init_A_const_30 = A_arbace_c2j_node__init_A_const_pool.A[101]; A_arbace_c2j_node__init_A_const_31 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[102]); A_arbace_c2j_node__init_A_const_32 = A_arbace_c2j_node__init_A_const_pool.A[103]; A_arbace_c2j_node__init_A_const_33 = A_arbace_c2j_node__init_A_const_pool.A[104]; A_arbace_c2j_node__init_A_const_34 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[105]); A_arbace_c2j_node__init_A_const_35 = A_arbace_c2j_node__init_A_const_pool.A[106]; A_arbace_c2j_node__init_A_const_36 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[107]); A_arbace_c2j_node__init_A_const_37 = A_arbace_c2j_node__init_A_const_pool.A[108]; A_arbace_c2j_node__init_A_const_38 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[109]) }

func A_arbace_c2j_node__init_A_clinit_p3() { A_arbace_c2j_node__init_A_const_39 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[110]); A_arbace_c2j_node__init_A_const_40 = lang.Keyword_Cast(A_arbace_c2j_node__init_A_const_pool.A[111]); A_arbace_c2j_node__init_A_const_41 = A_arbace_c2j_node__init_A_const_pool.A[112]; A_arbace_c2j_node__init_A_const_42 = lang.Keyword_Cast(A_arbace_c2j_node__init_A_const_pool.A[113]); A_arbace_c2j_node__init_A_const_43 = A_arbace_c2j_node__init_A_const_pool.A[114]; A_arbace_c2j_node__init_A_const_44 = lang.Keyword_Cast(A_arbace_c2j_node__init_A_const_pool.A[115]); A_arbace_c2j_node__init_A_const_45 = A_arbace_c2j_node__init_A_const_pool.A[116]; A_arbace_c2j_node__init_A_const_46 = lang.Keyword_Cast(A_arbace_c2j_node__init_A_const_pool.A[117]); A_arbace_c2j_node__init_A_const_47 = A_arbace_c2j_node__init_A_const_pool.A[118]; A_arbace_c2j_node__init_A_const_48 = lang.Keyword_Cast(A_arbace_c2j_node__init_A_const_pool.A[119]); A_arbace_c2j_node__init_A_const_49 = A_arbace_c2j_node__init_A_const_pool.A[120]; A_arbace_c2j_node__init_A_const_50 = lang.Keyword_Cast(A_arbace_c2j_node__init_A_const_pool.A[121]); A_arbace_c2j_node__init_A_const_51 = A_arbace_c2j_node__init_A_const_pool.A[122] }

func A_arbace_c2j_node__init_A_clinit_p4() { A_arbace_c2j_node__init_A_const_52 = A_arbace_c2j_node__init_A_const_pool.A[123]; A_arbace_c2j_node__init_A_const_53 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[124]); A_arbace_c2j_node__init_A_const_54 = A_arbace_c2j_node__init_A_const_pool.A[125]; A_arbace_c2j_node__init_A_const_55 = A_arbace_c2j_node__init_A_const_pool.A[126]; A_arbace_c2j_node__init_A_const_56 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[127]); A_arbace_c2j_node__init_A_const_57 = A_arbace_c2j_node__init_A_const_pool.A[128]; A_arbace_c2j_node__init_A_const_58 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[129]); A_arbace_c2j_node__init_A_const_59 = A_arbace_c2j_node__init_A_const_pool.A[130]; A_arbace_c2j_node__init_A_const_60 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[131]); A_arbace_c2j_node__init_A_const_61 = A_arbace_c2j_node__init_A_const_pool.A[132]; A_arbace_c2j_node__init_A_const_62 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[133]); A_arbace_c2j_node__init_A_const_63 = A_arbace_c2j_node__init_A_const_pool.A[134]; A_arbace_c2j_node__init_A_const_64 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[135]); A_arbace_c2j_node__init_A_const_65 = A_arbace_c2j_node__init_A_const_pool.A[136] }

func A_arbace_c2j_node__init_A_clinit_p5() { A_arbace_c2j_node__init_A_const_66 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[137]); A_arbace_c2j_node__init_A_const_67 = A_arbace_c2j_node__init_A_const_pool.A[138]; A_arbace_c2j_node__init_A_const_68 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[139]); A_arbace_c2j_node__init_A_const_69 = A_arbace_c2j_node__init_A_const_pool.A[140]; A_arbace_c2j_node__init_A_const_70 = A_arbace_c2j_node__init_A_const_pool.A[141]; A_arbace_c2j_node__init_A_const_71 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[142]); A_arbace_c2j_node__init_A_const_72 = A_arbace_c2j_node__init_A_const_pool.A[143]; A_arbace_c2j_node__init_A_const_73 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[144]); A_arbace_c2j_node__init_A_const_74 = A_arbace_c2j_node__init_A_const_pool.A[145]; A_arbace_c2j_node__init_A_const_75 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[146]); A_arbace_c2j_node__init_A_const_76 = A_arbace_c2j_node__init_A_const_pool.A[147]; A_arbace_c2j_node__init_A_const_77 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[148]); A_arbace_c2j_node__init_A_const_78 = A_arbace_c2j_node__init_A_const_pool.A[149] }

func A_arbace_c2j_node__init_A_clinit_p6() { A_arbace_c2j_node__init_A_const_79 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[150]); A_arbace_c2j_node__init_A_const_80 = A_arbace_c2j_node__init_A_const_pool.A[151]; A_arbace_c2j_node__init_A_const_81 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[152]); A_arbace_c2j_node__init_A_const_82 = A_arbace_c2j_node__init_A_const_pool.A[153]; A_arbace_c2j_node__init_A_const_83 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[154]); A_arbace_c2j_node__init_A_const_84 = A_arbace_c2j_node__init_A_const_pool.A[155]; A_arbace_c2j_node__init_A_const_85 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[156]); A_arbace_c2j_node__init_A_const_86 = A_arbace_c2j_node__init_A_const_pool.A[157]; A_arbace_c2j_node__init_A_const_87 = lang.Var_Cast(A_arbace_c2j_node__init_A_const_pool.A[158]); A_arbace_c2j_node__init_A_const_88 = A_arbace_c2j_node__init_A_const_pool.A[159] }

func A_arbace_c2j_node__init_A_New() *A_arbace_c2j_node__init_A { A_arbace_c2j_node__init_A_Init(); t := &A_arbace_c2j_node__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c2j_node__init_A) Ctor() {}

func (t *A_arbace_c2j_node__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2j_node__init_A) GetClass__Class() *jrt.Class { return A_arbace_c2j_node__init_A_class }

func (t *A_arbace_c2j_node__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2j_node__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2j_node__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2j_node__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2j_node__init_A); return ok }

func A_arbace_c2j_node__init_A_Cast(x any) *A_arbace_c2j_node__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2j_node__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2j_node__init_A_class)) }; return v }
