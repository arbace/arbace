//line j2g_strings.ae:1
package aot_arbace_cpp_codegen

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn14,arbace.cpp.abikn2,asyn3,abiyn15,arbace.cpp.semayn4,semayn19,arbace.cpp.templateyn17,arbace.cpp.inlineyn3,inlyn22,arbace.repr.cpp.nativeyn6,nativeyn21,arbace.repr.cpp.parseyn2,psyn16,arbace.repr.llvmyn4,llvmyn16,arbace.cpp.loweryn5,loweryn13,arbace.stringyn3,stryn11,arbace.corekn3,docyn1,gkn5,formskn5,slotsks18,arbace.cpp.codegen4,slotkn4,vttskn6,groupskn5,groupkn2,fnkn2,vakn8,nounwindkn6,pattrskn8,declaredys4,llvm7,declareyn1,&kn5,attrskn7,stringsyn3,i16yn3,i32ys4,llvm6,globalyn15,zeroinitializeryn5,arraykn7,linkagekn7,privatekn12,unnamed-addrkn12,unnamed_addrkn8,constantkn5,alignkn5,unitskn1,wkn1,syn2,i8yn8,c-stringkn1,nkn6,blocksyn5,blockkn5,labelkn5,instskn4,termyn6,switchyn3,retyn11,unreachableyn2,bryn1,=yn2,i1kn7,allocasyn6,allocakn2,ofkn4,namekn4,pathkn6,va-tagyn13,getelementptrkn8,inboundskn3,nuwyn3,ptrkn4,elsekn2,bfkn5,shiftkn2,tyyn4,loadkn6,nonnegkn2,idyn3,shlyn4,ashryn4,lshryn3,andkn4,boolyn5,truncyn4,zextyn5,storeyn2,orkn6,fieldskn7,codegenkn4,bitskn7,bitoffsyn3,i64yn4,callyn4,voidyn4,nullyn8,x86_fp80yn6,doubleyn5,floatyn2,fpkn4,ctorkn4,dtorkn3,clskn4,kindkn3,ssekn6,memorykn3,indkn6,directkn4,sretkn6,ignorekn4,regskn1,kkn1,tkn7,integerkn5,partskn5,byvalkn3,retyn6,structkn5,ret-kkn9,ret-partskn2,pskn6,paramskn6,statickn4,linekn6,columnkn11,extern-instkn5,tinstkn5,outerkn6,parentkn2,c1kn6,wantedkn5,tbodykn8,implicitkn7,trivialkn9,defaultedkn6,tinitskn7,tassignkn13,always-inlinekn5,queuekn2,opkn5,fieldkn5,decaykn7,base-lvkn14,reinterpret-lvkn3,objkn1,ekn5,derefkn6,ptraddkn10,derived-lvkn1,pkn3,trykn9,terminatekn7,eh-onlykn6,deletekn11,guard-abortkn9,end-catchkn11,might-throwkn4,flagyn4,icmpkn2,nekn5,arraykn5,classkn4,addrkn3,vttkn12,entry-storesys11,arbace.core3,letyn22,ts__1801000164__auto__ys11,arbace.core4,atomyn21,r__1801000165__auto__ys11,arbace.core7,bindingys18,arbace.cpp.codegen7,*temps*ys18,arbace.cpp.codegen6,*cond*ys11,arbace.core5,doseqyn21,c__1801000166__auto__ys11,arbace.core7,reverseys11,arbace.core5,derefys18,arbace.cpp.codegen12,run-cleanup!kn8,cleanupskn8,handlerskn2,tikn8,eh-slotskn7,deallockn4,sizekn6,placesys4,llvm6,defineyn3,%a0kn12,linkonce_odrkn10,visibilitykn6,hiddenkn8,noinlinekn8,noreturnkn4,bodyyn3,%t1kn2,eqkn8,term-padyn11,insertvalueyn6,poisonyn6,resumekn12,term-pad-newyn6,invokekn2,tokn6,unwindyn10,landingpadyn5,catchyn12,extractvaluekn4,padskn11,personalitykn7,cleanupkn10,pad-blockskn14,noexcept-falsekn8,noexceptkn6,vtablekn1,vkn7,virtualkn4,zerokn1,ikn4,bindkn9,bind-tempkn4,initkn5,va-tyyn2,fnkn3,ftykn1,myn3,subyn8,inttoptryn3,phikn4,argskn6,calleekn13,member-statickn7,storagekn4,anonkn8,internalkn8,tls-defskn3,tlskn6,globalkn6,externkn7,definedkn11,pending-defkn8,linkoncekn8,tls-kindkn9,constinitkn7,tls-dynyn3,%trkn7,tls-extyn5,%exityn3,%t2yn5,%initkn11,extern_weakkn12,static-localkn5,fn-ofkn4,disckn4,lazykn8,externalyn4,sremyn4,uremyn3,mulyn3,addyn4,sdivyn4,udivyn3,xoryn4,fremyn4,fmulyn4,faddyn4,fsubyn4,fdivkn3,nswyn4,fcmpkn3,oltkn3,ogtkn3,unekn3,olekn3,oeqkn3,ogekn3,sltkn3,ultkn3,sgtkn3,ugtkn3,slekn3,ulekn3,sgekn3,ugekn5,floatkn7,ldoublekn7,float16kn8,float128yn4,sextkn4,fromkn4,hintkn2,ckkn7,to-boolkn7,nullptrkn7,fp->intyn6,fptosiyn6,fptouikn8,ptr->intyn8,ptrtointkn8,int->ptrkn7,derivedkn2,fpyn5,fpextyn7,fptrunckn4,basekn4,voidkn4,noopkn2,prkn3,catkn3,intkn7,int->fpyn6,sitofpyn6,uitofpkn1,lkn4,landkn1,rkn1,ckn4,thenkn5,itemskn2,xvkn2,lvks18,arbace.cpp.codegen4,nonekn1,okn4,postkn3,newkn3,symkn5,placekn9,monotonickn7,acquirekn7,releasekn7,acq_relkn7,seq_cstkn6,vbaseskn3,arrkn5,unionkn4,exprkn5,baseskn6,sfencekn5,whichyn5,fencekn9,syncscopekn2,ockn5,fencekn2,vtkn2,vpkn2,rpkn4,xchgyn9,atomicrmwkn5,storekn6,atomickn4,loadkn3,rmwkn3,minkn4,uminkn3,maxkn4,umaxkn3,subkn4,nandkn2,orkn3,xoryn6,selectkn3,andkn3,addkn5,clearkn3,taskn7,cmpxchgkn2,epkn2,wckn4,weakyn7,cmpxchgkn3,fockn2,fokn5,bswapkn5,ctpopkn4,uintkn2,fbkn9,mptr-datakn3,offkn8,va-startkn6,va-endkn7,va-copykn6,opaquekn5,mcallkn6,incdeckn5,binopkn4,nullkn5,commakn8,mptr-adjkn5,throwkn3,etykn4,thiskn9,this-slotkn3,cmpkn2,ctkn3,litkn7,ptrdiffkn5,exactkn9,stmt-exprkn7,mptr-fnkn5,icallkn6,fnaddrkn6,allocakn5,countkn11,bind-opaquekn5,bitopkn7,exn-ptrkn7,exn-adjkn3,varkn5,ginitkn3,rawkn6,cookiekn4,condkn7,dyncastkn6,va-argkn4,castkn7,cassignkn3,notkn8,zero-valkn13,clear-paddingkn4,unopyn4,fnegkn3,lorkn6,assignkn2,etkn9,placementkn5,allockn4,callkn4,listkn4,fillkn4,nonekn7,exn-objkn8,temp-objkn3,ptrkn9,ccompoundkn4,tempkn6,mfieldkn3,strkn5,cpartkn4,partkn6,typeidkn4,cmp3kn13,std-init-listkn4,elemkn3,ordkn7,complexkn10,copy-byteskn4,copykn9,zero-thenkn6,stringkn11,fields-usedkn8,agg-thiskn4,nrvokn5,sinitkn3,dsokn9,ret-labelkn6,void-ekn8,nrvo-varkn6,returnkn8,ret-slotkn4,declkn5,breakkn5,loopskn4,casekn6,labelskn5,depthkn3,dstkn3,srckn4,gotokn11,user-labelskn3,asmkn3,inskn8,clobbersyn3,asmkn10,sideeffectkn5,blockkn4,flatkn3,forkn2,dokn8,continuekn3,inckn6,switchkn7,defaultkn5,whilekn5,foldskn2,ifkn2,cqkn5,vrootkn3,anckn8,virtualskn5,vbasekn3,valkn7,primarykn7,methodskn5,vcallkn5,compskn6,vcallskn4,vboskn3,refkn4,rrefkn2,nvkn4,rttikn6,unusedkn4,purekn3,apskn3,grpkn7,entrieskn8,sub-vttskn3,seckn2,vbkn5,vboffkn3,d0skn2,d0kn6,inlinekn19,out-of-line-defaultyn6,%entryyn7,%returnkn6,ret-tykn8,delegatekn3,idxkn12,alwaysinlinekn7,aliasesys4,llvm5,aliaskn5,targskn4,herekn6,publickn6,accessyn3,%t3yn3,%t4yn3,%t5yn3,%t6yn3,%r1yn3,%r2yn3,%r3yn3,%r4yn3,%r5yn3,%r0yn5,%rendyn4,%rnnyn3,%r6kn1,byn6,packedkn13,init-prioritykn3,fnskn9,ctor-attrkn9,appendingkn5,orderkn12,thread-localkn8,weak_odrys4,llvm15,source-filenameys4,llvm10,datalayoutys4,llvm6,tripleys4,llvm4,typekn4,varskn7,classeskn5,enumskn7,vtableskn4,usedkn7,staticskn2,nskn8,declineskn5,parsekn7,reasonskn9,pp-errorskn2,ppkn7,messagekn5,nodeskn4,rootkn9,decltypeskn7,refusedks7,codegen7,refusedkn5,crashkn5,rangekn7,verdictkn6,statuskn7,missingkn5,totalkn4,passkn5,knownkn4,failkn5,stalekn3,genkn5,levelkn7,subjectkn9,referencev11,arbace.core7,requireV3,R0,R1,R2,V3,R3,R1,R4,V1,R5,V3,R6,R1,R7,V3,R8,R1,R9,V3,R10,R1,R11,V3,R12,R1,R13,V3,R14,R1,R15,V3,R16,R1,R17,v11,arbace.core5,referR18,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn18,arbace.cpp.codegenm2,R19,s1142,The code generator (doc/cpp/CODEGEN.md §4): arbace.cpp.sema's typed program written as LLVM forms (doc/cpp/LLVM.md)\n  as clang's CodeGen writes its IR at -O0 -- every local in an alloca of the entry block, loads and stores, the\n  objects' members at the Itanium layout's byte offsets, constructors (C2, C1 an alias of a strong one) and destructors\n  (D2, D0 the deleting one, D1 an alias), vtables and type_info objects, virtual calls through the vptr, new and\n  delete (an array cookie when the element has a destructor), the destructors of locals at their scope's exits and of\n  temporaries at their full-expression's end (a flag for a temporary made in a conditional branch), copy elision of\n  prvalues and the named return value, static locals behind their guard, namespace-scope variables' dynamic\n  initialization in a global constructor with their destructors registered by __cxa_atexit. The forms are lowered by\n  arbace.cpp.lower and run as cppi runs clang's (bin/cppi codegen, codegen-check). Calling convention: scalars as\n  clang passes them; a class argument or result by address (CODEGEN.md's P3: SysV's register classes later).v11,arbace.core10,re-matchesp25,[A-Za-z_$][A-Za-z0-9_$.]*v11,arbace.core3,notv13,arbace.string9,includes?v13,arbace.string10,ends-with?v11,arbace.core6,symbolv11,arbace.core4,listR20,v11,arbace.core5,swap!v18,arbace.cpp.codegen5,*top*v11,arbace.core6,updateR21,v11,arbace.core4,somev11,arbace.core9,contains?R22,v11,arbace.core8,assoc-inR23,R24,v18,arbace.cpp.codegen5,want!R25,R26,l0,v18,arbace.cpp.codegen8,conj-newv11,arbace.core5,assocv18,arbace.cpp.codegen8,add-top!R27,v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR28,R29,R30,R31,v11,arbace.core5,applyR32,v18,arbace.cpp.codegen4,gsymv11,arbace.core4,mapvv11,arbace.core4,intov11,arbace.core5,rangeR33,V2,R34,V1,R29,v11,arbace.core6,get-inR35,R36,R37,v11,arbace.core3,vecR38,v11,arbace.core6,every?v11,arbace.core5,zero?R39,R40,v11,arbace.core3,mapR41,R42,R43,R44,R45,R46,R40,R47,v18,arbace.cpp.codegen11,wide-globalR48,v18,arbace.cpp.codegen13,string-globalR49,R38,l1,R40,R50,R51,R52,v18,arbace.cpp.codegen3,*f*v11,arbace.core3,incR53,R54,R55,R56,R57,v18,arbace.cpp.codegen6,start!v18,arbace.cpp.codegen9,new-labelS4,R58,R59,R60,R61,v18,arbace.cpp.codegen12,close-block!v18,arbace.cpp.codegen3,tmpv18,arbace.cpp.codegen5,emit!R62,R61,R61,R61,R63,R64,R62,R65,v14,arbace.cpp.abi3,unqv14,arbace.cpp.abi4,arr?v14,arbace.cpp.abi6,class?R66,v14,arbace.cpp.abi6,cls-ofR67,v11,arbace.core6,empty?R68,v18,arbace.cpp.codegen6,va-tagR69,v18,arbace.cpp.codegen4,val!R70,R71,R72,v18,arbace.cpp.codegen7,va-tag!V2,R37,l0,R73,R37,v14,arbace.cpp.abi10,size-alignv18,arbace.cpp.codegen13,va-list-type?v18,arbace.cpp.codegen7,alloca!R40,l16,R74,v14,arbace.cpp.abi7,scalar?v14,arbace.cpp.abi9,llvm-typeR40,R50,R75,R76,R77,v14,arbace.cpp.abi7,size-ofR78,v14,arbace.cpp.abi8,align-ofR73,v14,arbace.cpp.abi7,signed?v14,arbace.cpp.abi5,enum?R79,v14,arbace.cpp.abi3,enmR80,R81,R82,R83,R84,R85,v14,arbace.cpp.abi2,bnv14,arbace.cpp.abi10,underlyingR86,R63,v11,arbace.core8,boolean?R87,R63,R78,R73,R84,R81,R84,R88,R89,R73,v11,arbace.core4,map?v18,arbace.cpp.codegen8,bf-load!R78,R73,R86,R50,R63,v18,arbace.cpp.codegen9,bf-store!R87,R63,R50,R88,R73,R90,v14,arbace.cpp.abi3,clsv18,arbace.cpp.codegen4,failR91,v14,arbace.cpp.abi6,layoutR92,v18,arbace.cpp.codegen7,offset!R93,R70,R50,R73,R94,R95,R96,V2,R63,FR73,R73,R94,v18,arbace.cpp.codegen8,declare!R96,V4,R73,R73,R94,R63,v14,arbace.cpp.abi12,empty-class?R95,R96,V2,R50,l0,V2,R63,FR73,R94,R96,V4,R73,R50,R94,R63,v14,arbace.cpp.abi4,ref?R40,R50,v14,arbace.cpp.abi8,mfn-ptr?R39,v14,arbace.cpp.abi5,mptr?l-1,R73,R97,S3,R98,R99,R100,R63,R101,v18,arbace.cpp.codegen7,zero-ofv11,arbace.core6,false?v14,arbace.cpp.abi11,has-vbases?S2,R102,R103,v18,arbace.cpp.codegen9,vb-class?R104,l2,R105,v15,arbace.cpp.sema3,fndv14,arbace.cpp.abi9,mangle-fnv18,arbace.cpp.codegen10,fn-variantS2,R102,R103,R106,R100,R99,i1,R50,i2,R36,i3,R37,i4,R94,v15,arbace.cpp.sema13,trivial-copy?v15,arbace.cpp.sema13,trivial-dtor?v14,arbace.cpp.abi14,classify-classR107,R108,v18,arbace.cpp.codegen10,class-passR109,R110,R111,R112,v11,arbace.core4,atoml8,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendm4,R113,R109,R114,R73,m2,R113,R111,v18,arbace.cpp.codegen12,byval-class?R113,R114,R73,R34,m4,R113,R108,R114,R73,v11,arbace.core6,filterR115,R116,R73,v11,arbace.core3,decR117,R40,R50,v11,arbace.core1,-R40,R50,S2,R99,R100,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consm4,R113,R109,R114,R73,m2,R113,R111,m4,R113,R108,R114,R73,S2,R99,R100,v11,arbace.core4,restR118,v18,arbace.cpp.codegen10,part-ltypeR119,R96,R73,R120,R121,R122,v11,arbace.core6,concatV1,R73,V1,R73,V1,R73,v11,arbace.core6,mapcatv11,arbace.core10,constantlyR123,v18,arbace.cpp.codegen8,sig-planR73,R124,v18,arbace.cpp.codegen10,takes-vtt?ML3,R40,l16,R50,m4,R125,i339,R126,i23,v11,arbace.core11,map-indexedR70,R50,V2,R94,l8,R73,R78,R73,v18,arbace.cpp.codegen7,memcpy!ML3,R40,l16,R50,m4,R125,i349,R126,i23,v11,arbace.core6,vectorR70,R50,V2,R94,l8,R73,R88,R73,V2,R94,l8,R127,R128,R129,R130,S2,R102,R103,v18,arbace.cpp.codegen7,fn-nameR131,v11,arbace.core4,fnilR132,R133,R134,R135,R136,R137,R138,v18,arbace.cpp.codegen12,extern-inst?R139,R140,v18,arbace.cpp.codegen6,fn-sigv18,arbace.cpp.codegen11,nothrow-fn?v18,arbace.cpp.codegen12,*eager-want*v18,arbace.cpp.codegen8,reserve!R141,R142,R143,R144,R145,R146,R147,R148,R149,R150,R151,R152,R153,R154,R155,R156,R157,v18,arbace.cpp.codegen10,call-insn!R96,R96,R158,R159,R78,R50,R73,R160,R161,R50,v18,arbace.cpp.codegen6,begin!R162,R163,v18,arbace.cpp.codegen10,call-dtor!R164,R165,R96,v18,arbace.cpp.codegen7,condbr!R88,V2,R50,l0,R73,v18,arbace.cpp.codegen16,nontrivial-dtor?v18,arbace.cpp.codegen8,*extend*v18,arbace.cpp.codegen12,*extend-now*v18,arbace.cpp.codegen6,*cond*R50,v18,arbace.cpp.codegen7,*temps*R166,R88,V2,R50,l0,R73,R88,V2,R50,l1,R73,R167,R168,R169,R170,R171,R172,R173,R174,R175,R176,R177,R178,R179,v11,arbace.core4,rseqR180,R181,v11,arbace.core10,take-whileV1,nR182,R73,R37,l4,R95,R96,V1,R29,R73,R183,v18,arbace.cpp.codegen13,dealloc-call!R184,R185,R95,R96,V1,R29,R73,R94,v18,arbace.cpp.codegen12,run-cleanup!R96,V1,R73,R96,V2,R73,R94,v18,arbace.cpp.codegen6,place!V2,R27,s22,__clang_call_terminateR186,R96,V1,V2,R73,R187,R188,R189,R190,V3,R191,R192,R29,R193,R54,ML1,R60,m4,R125,i513,R126,i35,R62,R194,R95,R73,V1,V2,R73,R187,V1,R29,R95,R96,V2,R192,R29,R73,V1,R73,R96,v18,arbace.cpp.codegen8,eh-walk!v18,arbace.cpp.codegen3,br!R37,V1,R73,R78,R37,R73,R95,R37,V1,R29,R73,R160,R195,R37,R78,R73,R73,ML1,R60,m4,R125,i536,R126,i32,R196,R78,R73,R73,R78,R37,R73,R197,V2,ML3,R119,R73,R37,m4,R125,i560,R126,i40,R198,R73,R197,ML3,R119,R73,R37,m4,R125,i561,R126,i40,R37,R199,ML3,R119,R73,R37,m4,R125,i562,R126,i29,R95,R96,v18,arbace.cpp.codegen21,clang-call-terminate!V2,R192,R29,R73,R200,R96,R201,R96,R202,R203,v11,arbace.core6,dissocR204,ML3,R119,R73,R37,m4,R125,i550,R126,i45,ML3,R205,R73,R97,m4,R125,i550,R126,i63,R206,ML3,R119,R73,R37,m4,R125,i551,R126,i47,ML1,R60,m4,R125,i553,R126,i21,R95,R96,V2,R192,R29,R73,v18,arbace.cpp.codegen15,run-cleanup-eh!v18,arbace.cpp.codegen8,pad-planR207,v11,arbace.core11,select-keysV4,R55,R56,R57,R53,v18,arbace.cpp.codegen9,eh-slots!R208,R37,R204,ML3,R119,R73,R37,m4,R125,i579,R126,i53,V1,R209,R205,R73,R97,R88,R37,R206,ML3,R119,R73,R37,m4,R125,i582,R126,i69,R73,v11,arbace.core19,pop-thread-bindingsv11,arbace.core5,mergeR210,R88,R73,R206,ML3,R119,R73,R37,m4,R125,i581,R126,i69,R73,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv18,arbace.cpp.codegen7,*no-eh*v18,arbace.cpp.codegen12,landing-pad!v18,arbace.cpp.codegen8,eh-stateR96,R95,V2,R34,V1,R29,R96,R201,R103,R211,R212,R213,v11,arbace.core12,keep-indexedR214,R215,v18,arbace.cpp.codegen5,slot!R216,R217,v18,arbace.cpp.codegen7,emit-rvR73,R218,v18,arbace.cpp.codegen7,emit-lvR219,v11,arbace.core6,secondv14,arbace.cpp.abi9,base-pathv18,arbace.cpp.codegen9,emit-initR220,v18,arbace.cpp.codegen18,push-temp-cleanup!R73,v11,arbace.core6,pr-strR78,R73,R73,R70,R73,R73,R94,v18,arbace.cpp.codegen12,vtable-indexR78,R73,R73,v11,arbace.core4,dropR221,v11,arbace.core5,some?v18,arbace.cpp.codegen10,arg-valuesv18,arbace.cpp.codegen11,coerce-out!R73,R73,R73,R206,R222,R33,v18,arbace.cpp.codegen10,coerce-in!S2,R102,R103,v18,arbace.cpp.codegen9,*as-base*R102,v18,arbace.cpp.codegen12,vcall-targetv18,arbace.cpp.codegen8,want-fn!v18,arbace.cpp.codegen10,emit-call!R192,v14,arbace.cpp.abi5,void?ML1,R60,m4,R125,i705,R126,i82,v18,arbace.cpp.codegen5,call!R223,R224,R206,ML3,R119,R94,R94,m4,R125,i723,R126,i39,R206,ML3,R119,R94,R94,m4,R125,i724,R126,i41,R70,R50,R73,R94,R160,R94,R84,R94,R78,R73,R73,R70,R50,R73,R94,R225,R94,R78,R73,R73,R226,R94,R73,R227,R73,R228,R229,v13,arbace.string12,starts-with?v11,arbace.core4,subsR230,R231,V1,R232,R233,R234,v11,arbace.core3,setR235,S2,R230,R236,R237,R238,R239,R240,v14,arbace.cpp.abi10,mangle-varS2,R230,R236,v15,arbace.cpp.sema6,*vars*R241,R242,v18,arbace.cpp.codegen17,tls-defined-here?S2,R230,R236,v18,arbace.cpp.codegen13,*in-tls-init*R243,v18,arbace.cpp.codegen22,tls-wrapped-elsewhere?ML3,R59,R73,R244,m4,R125,i806,R126,i58,R62,R244,R78,R73,R73,R59,R73,R245,v18,arbace.cpp.codegen16,tls-wrapper-nameR186,R73,R54,R246,R62,R247,R95,R73,R73,v18,arbace.cpp.codegen15,tls-wrapper-retR247,R54,R62,R194,R160,R73,R97,R61,R63,R194,R248,R246,R54,R248,R95,R96,R61,R246,R32,R96,R249,R73,V1,R73,v15,arbace.cpp.sema4,var*R236,R95,R73,R95,R73,R250,v14,arbace.cpp.abi19,mangle-local-staticR251,R252,R253,R38,R73,R254,R40,R50,v18,arbace.cpp.codegen19,extern-tls-wrapper!v18,arbace.cpp.codegen11,vbase-addr!R255,R256,R84,R257,R258,R225,R259,R260,R261,R89,R81,R82,R83,R262,R263,R264,R265,R266,v14,arbace.cpp.abi9,floating?v18,arbace.cpp.codegen5,fp-opv18,arbace.cpp.codegen6,int-opS4,R258,R81,R225,R257,R267,R268,R269,R270,R271,R272,R273,R274,R160,R275,R276,R277,R278,R279,R280,R281,R282,v13,arbace.string7,replacev11,arbace.core3,strp7,[lLfF]$v18,arbace.cpp.codegen4,pow2v11,arbace.core6,formatR283,R284,S2,R285,R286,v11,arbace.core4,nameR101,v13,arbace.string10,upper-caseR101,v18,arbace.cpp.codegen8,fp80-hexR101,R63,R63,R86,R63,R87,R287,R160,R73,R97,R70,R50,R73,R94,R227,R73,R97,R160,R73,R97,R227,R73,R97,R73,R73,R73,R73,v18,arbace.cpp.codegen12,eh-typeinfo!R288,R73,R94,R289,R73,V4,R73,R73,R73,R94,R290,R291,R160,R94,R206,ML3,R119,R94,R94,m4,R125,i968,R126,i99,R160,R94,R268,R101,v14,arbace.cpp.abi4,ptr?R160,R73,R97,R292,R63,R160,R293,R294,R295,R296,R297,R73,R298,R226,R73,R299,v18,arbace.cpp.codegen11,ptr-adjust!v18,arbace.cpp.codegen11,base-offsetR300,R301,R302,R303,R160,R73,R97,v18,arbace.cpp.codegen10,base-addr!R227,R73,R97,R304,R305,R306,R307,v18,arbace.cpp.codegen9,emit-intoR308,v18,arbace.cpp.codegen9,int-cast!R309,R310,R311,v18,arbace.cpp.codegen13,*extend-root*v18,arbace.cpp.codegen8,folds-toR312,R313,v18,arbace.cpp.codegen23,short-circuit-branches!R314,R227,R63,R315,v18,arbace.cpp.codegen15,cond-branches2!R316,R227,v18,arbace.cpp.codegen9,va-field!R78,R73,R73,R88,R73,R70,R50,R73,R37,R73,R78,R37,R73,R78,R37,R73,R160,R37,R160,R37,R84,R63,R78,R73,R73,l3,R70,R50,R73,R37,R70,R50,R73,R37,R40,R50,R227,R73,R78,R73,R88,R73,R88,R37,R258,R37,R73,R88,R37,R258,R37,R73,v18,arbace.cpp.codegen13,cleanup-depthv18,arbace.cpp.codegen5,load!R317,v18,arbace.cpp.codegen6,store!v18,arbace.cpp.codegen10,unwind-to!v11,arbace.core6,subvecv18,arbace.cpp.codegen9,emit-stmtv11,arbace.core7,reverseS2,R318,R319,v18,arbace.cpp.codegen8,*opaque*R320,R70,v18,arbace.cpp.codegen9,elem-typeR73,R94,R321,R264,R265,v18,arbace.cpp.codegen8,fp-constd4607182418800017408,v18,arbace.cpp.codegen6,arith!R322,R323,v18,arbace.cpp.codegen12,place-valuesR94,R94,R73,R73,R222,R73,v11,arbace.core6,repeatR73,R33,R324,V2,R94,R94,V1,R94,R73,R73,R73,R94,R94,R73,R94,R94,R325,R96,R96,R95,R96,V1,R29,R96,R326,R327,R328,R329,R330,v18,arbace.cpp.codegen10,atomic-ordV2,l1,l2,V1,l3,V1,l4,V1,l5,R58,R37,R37,R87,R63,R50,R331,R332,R333,R334,v14,arbace.cpp.abi8,dynamic?R335,v18,arbace.cpp.codegen15,occupied-bytes!R70,R50,R73,R37,R88,V2,R50,l0,R73,R336,R337,R338,R339,R338,R340,V2,l1,l2,V1,l3,V1,l4,V1,l5,R58,R37,R37,S2,R341,R336,v18,arbace.cpp.codegen11,emit-fence!R342,v18,arbace.cpp.codegen7,mem-valR78,R73,R343,R344,R88,R73,R88,R73,R345,v18,arbace.cpp.codegen9,by-order!R346,R73,R88,R73,R347,R88,R348,R73,R349,R78,R73,R88,R73,R350,R351,R352,R353,R354,R346,R73,R355,R225,R356,R261,R84,R357,R89,R358,R261,R88,R73,R160,R359,R63,R360,R84,R361,R258,R362,R88,V2,R50,l0,R73,R363,R346,V2,R50,l1,R73,R160,R50,v14,arbace.cpp.abi5,bool*R364,R365,R366,R78,R73,R367,R368,R73,R206,R119,R63,R206,R119,R63,R88,R73,v11,arbace.core6,reset!R369,R370,v18,arbace.cpp.codegen16,cmpxchg-fail-ordR58,R37,R37,R37,R37,l5,v18,arbace.cpp.codegen11,cabi-ordersR371,R50,R95,v11,arbace.core4,not=R372,R63,R95,V2,R63,Tv14,arbace.cpp.abi1,bR373,v14,arbace.cpp.abi4,int*R374,R160,R359,R63,R37,R37,R375,R376,R377,R378,R379,R73,R380,S2,R318,R319,v18,arbace.cpp.codegen9,opaque-ofS2,R318,R319,R96,R95,R96,V1,R29,R381,v18,arbace.cpp.codegen6,mcall!R382,v18,arbace.cpp.codegen7,incdec!R383,v18,arbace.cpp.codegen14,short-circuit!R384,R97,R385,R386,R206,ML3,R119,R94,R94,m4,R125,i1378,R126,i57,R197,ML3,R119,R94,R94,m4,R125,i1379,R126,i48,R94,R258,R94,R160,R94,R258,R94,R359,V2,R94,l-1,R63,R94,R387,R388,R73,V1,R94,R96,V3,R73,R73,R73,R95,R73,V1,R29,R94,R97,R389,v18,arbace.cpp.codegen10,*this-val*R78,R73,R73,R390,R96,R96,R73,R73,R73,ML1,R60,m4,R125,i1525,R126,i24,R96,R96,R96,ML1,R60,m4,R125,i1529,R126,i26,R391,R392,R206,ML3,R119,R94,R94,m4,R125,i1420,R126,i60,R160,R94,R160,R94,R160,R94,R84,R63,R89,R63,R261,R63,R160,R94,R160,R73,v18,arbace.cpp.codegen4,cmp!R393,R394,R297,R73,R94,R297,R73,R94,R225,R94,R259,R395,R94,v18,arbace.cpp.codegen12,emit-atomic!R63,R396,v18,arbace.cpp.codegen10,stmt-expr!R397,R297,R73,R94,R197,V2,ML3,R119,R94,R94,m4,R125,i1374,R126,i49,R198,R94,R197,V2,R94,l0,ML3,R119,R94,R94,m4,R125,i1375,R126,i43,R398,v18,arbace.cpp.codegen6,icall!R399,R400,R65,R50,R401,R94,R402,v18,arbace.cpp.codegen12,bind-opaque!R403,v18,arbace.cpp.codegen11,emit-bitop!R404,R405,R160,R73,R97,R406,R407,S2,R230,R236,S2,R308,R283,R408,S2,R230,R236,v18,arbace.cpp.codegen16,tls-via-wrapper?v18,arbace.cpp.codegen8,var-addrR78,R73,R73,R409,R78,R94,R73,l-8,R258,R94,R257,R94,R78,R94,R73,R94,R95,R96,R73,R94,R258,R94,R257,R94,R95,R96,R73,R95,R96,R73,R95,R96,R73,R94,R94,R88,R94,R73,R78,R94,R73,R160,R94,R225,R94,R88,R94,R73,R70,R73,R94,R88,R94,R73,R78,R94,R73,R160,R94,R225,R94,R96,V2,R73,R94,R88,R94,R73,R70,R73,R94,R96,V1,R73,R96,V2,R73,R94,R410,v18,arbace.cpp.codegen14,cond-branches!R411,v18,arbace.cpp.codegen13,null-guarded!R78,R73,R73,R70,R94,V2,R94,l-2,R73,R78,R94,R73,R70,R50,R73,R94,v18,arbace.cpp.codegen13,dyncast-call!R225,R94,R70,R73,R94,R412,R78,R37,R73,R160,R37,l160,l40,R78,R73,R73,R70,R50,R73,R37,R88,R37,R258,R37,R73,R78,R73,R73,R88,R73,R70,R50,V2,R37,l8,R73,R73,R227,R73,R413,v18,arbace.cpp.codegen5,cast!R414,R415,R261,R63,R416,R417,v18,arbace.cpp.codegen19,emit-clear-padding!R418,R419,R261,R420,R421,R422,R423,R257,R94,R258,R94,v18,arbace.cpp.codegen11,alloc-call!R424,R160,R73,R97,R227,R73,R97,R160,R73,R97,R227,R73,R97,R425,R88,R94,R73,R426,R427,S1,R428,R94,R78,R94,R73,R160,R94,R88,R94,R73,R70,R73,R94,R88,R94,R258,R94,R73,S3,R102,R334,R426,v18,arbace.cpp.codegen12,materialize!R429,R430,R431,R70,R73,R94,R225,R94,v14,arbace.cpp.abi9,integral?R432,S2,s1,*s1,/R433,R434,R70,R50,R73,R94,v18,arbace.cpp.codegen11,field-placeS2,R318,R319,R73,R435,v18,arbace.cpp.codegen10,str-globalR436,R437,R438,R160,R73,R97,R78,R73,R73,R70,R73,V2,R94,l-1,R73,R78,R73,R73,R96,R96,R96,ML1,R60,m4,R125,i1666,R126,i35,R160,R73,R97,R96,R96,R96,ML1,R60,m4,R125,i1680,R126,i24,R439,R359,V2,R50,l0,V2,R50,l2,R63,R359,V2,R50,l1,R63,R50,R359,V2,R50,l-1,R63,R50,R359,V2,R50,l0,V2,R50,l1,R63,R359,V2,R50,l-1,R63,R50,R88,R50,R73,R440,R441,R88,R94,R73,S2,R318,R319,v18,arbace.cpp.codegen10,empty-rec?v18,arbace.cpp.codegen8,*decl-e*R88,R73,R73,R442,R88,R50,R73,v18,arbace.cpp.codegen13,va-arg-class!R443,R444,R445,R428,v18,arbace.cpp.codegen7,memset!R446,R447,v11,arbace.core4,takev14,arbace.cpp.abi3,ptrv14,arbace.cpp.abi4,voidS1,R428,R448,R449,v18,arbace.cpp.codegen11,extend-rootR450,v18,arbace.cpp.codegen13,push-cleanup!R451,S2,R216,R428,v18,arbace.cpp.codegen8,zero-memR39,S3,R308,R283,R384,v18,arbace.cpp.codegen12,const-leavesV2,nnV2,nR39,v18,arbace.cpp.codegen15,leaves-constantR78,R50,R73,R160,R50,R95,R37,R73,R160,R37,R40,R50,R38,R39,R38,R94,R37,V1,R73,R96,V1,R73,R95,R37,R73,R73,R73,R95,R96,R73,R37,V3,R73,R73,R73,R452,R453,R454,R455,R456,R457,S3,R250,R458,R384,v18,arbace.cpp.codegen15,contains-label?v18,arbace.cpp.codegen10,emit-stmt*v18,arbace.cpp.codegen9,emit-try!R458,v18,arbace.cpp.codegen11,local-decl!R459,v11,arbace.core4,peekR460,R461,v11,arbace.core4,lastR462,R463,R464,R465,R466,R467,v18,arbace.cpp.codegen13,static-local!v18,arbace.cpp.codegen12,emit-return!R468,R469,v13,arbace.string4,joinv11,arbace.core4,keepR470,V3,s10,~{dirflag}s7,~{fpsr}s8,~{flags}R95,R96,V1,R29,R471,R472,R473,R474,R475,R476,R477,v11,arbace.core3,popR478,S2,R318,R319,S2,R318,R319,R479,R480,V4,R317,R316,R74,R193,v11,arbace.core7,vector?R58,R481,V2,R181,R55,R73,V1,R73,R78,R73,R73,R95,R73,V1,R29,R73,v14,arbace.cpp.abi7,non-refv18,arbace.cpp.codegen7,pop-to!V1,R73,V1,R29,v11,arbace.core4,valsv11,arbace.core11,sequential?R482,v18,arbace.cpp.codegen17,emit-if-branches!R483,v18,arbace.cpp.codegen8,emit-if!R484,R485,R486,v14,arbace.cpp.abi13,derived-from?v18,arbace.cpp.codegen13,contains-sub?v18,arbace.cpp.codegen13,overrides-fn?R487,R488,R489,R490,R491,v11,arbace.core8,not-any?v18,arbace.cpp.codegen15,final-overriderv18,arbace.cpp.codegen8,find-subR492,R493,R494,R495,v18,arbace.cpp.codegen12,offset-compsR78,R73,R73,R70,R50,R73,R94,v18,arbace.cpp.codegen19,vbase-offset-offsetR78,R94,R73,R70,R50,R73,R94,v18,arbace.cpp.codegen13,primary-chainS3,R496,R497,R431,R498,v18,arbace.cpp.codegen10,subobjectsR499,V1,R500,R501,V1,R501,v18,arbace.cpp.codegen19,vcall-offset-offsetv18,arbace.cpp.codegen17,return-adjustmentm2,R498,l0,V1,R500,V1,R501,m2,R498,l0,R502,v18,arbace.cpp.codegen8,vt-cachev18,arbace.cpp.codegen8,vt-groupv14,arbace.cpp.abi9,*classes*v14,arbace.cpp.abi16,mangle-type-namev14,arbace.cpp.abi23,mangle-ctor-vtable-namev18,arbace.cpp.codegen11,vtable-namev18,arbace.cpp.codegen16,ctor-vtable-namev18,arbace.cpp.codegen8,group-ofR70,V2,R94,l0,R40,R73,R73,v18,arbace.cpp.codegen10,group-nameR94,R503,R504,R505,R506,R70,R73,R73,R94,R70,V2,R94,l0,R40,v18,arbace.cpp.codegen10,vtt-layoutR73,R73,v18,arbace.cpp.codegen8,vtt-nameR94,R507,R508,v18,arbace.cpp.codegen9,vptr-listR78,R73,R73,v18,arbace.cpp.codegen7,vtt-refv18,arbace.cpp.codegen13,address-pointR88,R73,R73,v18,arbace.cpp.codegen11,init-vptrs!v18,arbace.cpp.codegen18,trivial-dtor-body?R509,R510,V2,R41,R233,R511,R512,V2,R41,R188,R513,R514,R54,R78,R73,R73,m2,R153,TR73,R96,R515,R88,V2,R37,l0,R73,R88,R73,R73,R73,v11,arbace.core1,+R88,R73,R73,R516,ML1,R60,m4,R125,i2502,R126,i27,v14,arbace.cpp.abi11,vbases-initR96,R514,ML1,R60,m4,R125,i2513,R126,i29,R514,R59,v11,arbace.core6,reduceR197,R198,R59,R96,ML2,R59,R96,m4,R125,i2524,R126,i45,R59,R517,R96,R95,R96,V2,R192,R29,R37,R186,R33,v18,arbace.cpp.codegen10,linkage-ofV1,R518,V1,R29,R73,S2,R102,R103,R519,R520,R222,R73,v15,arbace.cpp.sema12,dtor-deallocR513,R186,R96,V1,V2,R73,R187,V2,R41,R233,V2,R41,R188,R95,R96,V1,V2,R73,R187,R187,ML2,R59,R96,m4,R125,i2559,R126,i15,R521,v18,arbace.cpp.codegen6,key-fnR522,v18,arbace.cpp.codegen11,vtable-homeV2,R41,R188,v18,arbace.cpp.codegen15,external-class?R38,R73,R523,R524,R38,ML4,R119,R73,R73,R73,m4,R125,i2626,R126,i57,R119,R73,R73,v18,arbace.cpp.codegen10,vt-linkageV4,R45,TR46,l8,R38,ML3,R119,R73,R73,m4,R125,i2624,R126,i57,R119,R73,V4,R45,TR46,l8,v11,arbace.core11,frequenciesR38,R119,R73,R73,R37,R37,V2,R73,R94,R119,R73,R37,R37,R73,R94,V4,R45,TR46,l8,R38,R40,R50,R51,V4,R45,TR46,l1,R73,R70,R73,V2,R94,l2,R73,R38,ML3,R40,l0,R73,m4,R125,i2620,R126,i53,v18,arbace.cpp.codegen9,typeinfo!v18,arbace.cpp.codegen8,want-d0!v18,arbace.cpp.codegen10,class-ret?R62,R194,R70,R50,R73,R94,R62,R525,R78,R73,V2,R73,R194,R62,R526,R70,R50,V2,R73,R525,R94,R62,R527,R78,R94,V2,R73,R526,R62,R528,R70,R50,V2,R73,R194,V2,R94,R527,R528,R194,R186,V2,R34,V1,R29,R62,R529,R78,R73,V2,R73,R247,R62,R530,R70,R50,V2,R73,R529,R94,R62,R531,R78,R94,V2,R73,R530,R62,R532,R70,R50,V2,R73,R247,V2,R94,R531,R62,R533,R70,R50,R73,R532,R247,R94,R54,R62,R247,R59,R533,R54,R513,R62,R247,R62,R534,R160,R73,R247,R97,R61,R63,R534,R535,R536,R54,R536,V1,ML2,R61,R535,m4,R125,i2685,R126,i92,R54,R535,R62,R537,R227,R73,V2,R533,R536,V2,R97,R513,R59,R537,R54,R96,R96,ML2,R59,R96,m4,R125,i2690,R126,i79,R62,R247,R59,R247,R96,V1,R73,R95,R222,R33,R38,R40,R73,R500,V2,R73,R97,R73,R97,R226,R94,R73,R96,R73,R73,R73,v18,arbace.cpp.codegen6,thunk!R73,R73,V2,R73,R97,v18,arbace.cpp.codegen4,vtt!R38,R40,R73,R40,V4,R45,TR46,l8,R38,R40,R73,R40,R73,V4,R45,TR46,l8,v18,arbace.cpp.codegen6,group!R38,ML3,R40,l0,R73,m4,R125,i2733,R126,i47,R73,R70,R73,V2,R94,l2,R73,R538,R38,R73,v18,arbace.cpp.codegen17,abi-class-global!R38,ML5,R119,R73,R73,R37,R73,m4,R125,i2762,R126,i55,R119,R73,R37,R73,R38,ML3,R119,R73,R73,m4,R125,i2766,R126,i53,R119,R73,v14,arbace.cpp.abi3,fn?R38,ML3,R119,R73,R73,m4,R125,i2770,R126,i53,R119,R73,R38,R40,R50,R51,v18,arbace.cpp.codegen11,*const-top*R73,R36,R37,R50,S2,R216,R428,S2,R230,R236,R97,v11,arbace.core7,number?v11,arbace.core7,sort-byR36,R98,R94,R37,R40,R50,R39,R40,R50,R539,R539,R40,R50,R39,R40,R50,R73,R50,R99,R100,v11,arbace.core8,group-byR540,l65535,v11,arbace.core3,keyR541,R542,v11,arbace.core7,symbol?R38,R40,ML4,R119,R37,R73,R73,m4,R125,i2984,R126,i71,R119,V2,R73,R97,R37,R73,ML4,R119,R37,R73,R73,m4,R125,i2984,R126,i71,V2,R73,R97,R543,R40,ML4,R119,R37,R73,R73,m4,R125,i2983,R126,i95,R544,V2,R41,R233,V2,R41,R188,R38,R38,R38,R38,R73,R40,R50,R97,R39,V2,R41,R233,V2,R41,R188,R513,R514,R54,ML2,R59,R96,m4,R125,i2933,R126,i19,R78,R50,R73,R160,R50,R95,R37,R73,R73,R73,R38,R94,R88,V2,R50,l1,R73,R37,V3,R73,R73,R73,V2,R50,l1,V3,R73,R73,R73,R37,R186,R96,R73,ML2,R59,R96,m4,R125,i2933,R126,i19,V2,R50,l1,V3,R73,R73,R73,V2,R50,l1,V3,R73,R73,R73,R38,R50,R545,R513,R514,R54,R186,R96,R73,R73,V1,R73,R78,R50,R73,R160,R50,ML2,R59,R96,m4,R125,i2959,R126,i20,R88,V2,R50,l1,R73,R37,R520,ML3,R222,R96,V0,m4,R125,i2971,R126,i96,R73,v18,arbace.cpp.codegen13,tls-internal?V2,R41,R233,ML3,R222,R96,V0,m4,R125,i2971,R126,i96,V2,R41,R233,R186,R73,V2,R41,R233,V4,R41,R546,R189,R190,R54,R95,R96,R62,R194,R95,R73,R73,R194,V2,R41,R233,V4,R41,R546,R189,R190,R73,R70,R73,V2,R94,l2,R73,R38,R40,R50,R51,v18,arbace.cpp.codegen17,fundamental-codesR38,ML3,R40,l0,R73,m4,R125,i3008,R126,i48,V2,V2,s1,Pl0,V2,s2,PKl1,R38,ML3,R119,R73,R73,m4,R125,i3011,R126,i59,R119,R73,R38,ML5,R119,R73,R73,R37,R73,m4,R125,i3014,R126,i65,R119,R73,R37,R73,ML5,R119,R73,R73,R37,R73,m4,R125,i3014,R126,i65,V2,V2,s1,Pl0,V2,s2,PKl1,ML3,R119,R73,R73,m4,R125,i3011,R126,i59,ML5,R119,R73,R73,R37,R73,m4,R125,i3014,R126,i65,ML5,R119,R73,R73,R37,R73,m4,R125,i3014,R126,i65,R547,R548,R549,R550,ML5,R119,R37,R37,R73,R73,m4,R125,i3105,R126,i67,v15,arbace.cpp.sema5,*fns*R551,R552,v14,arbace.cpp.abi7,*enums*R553,R554,v14,arbace.cpp.abi9,*dollars*v13,arbace.string5,splitp1,,v18,arbace.cpp.codegen13,emit-globals!R555,S2,R102,R103,v18,arbace.cpp.codegen15,abstract-class?S2,R102,R103,v11,arbace.core4,sortv11,arbace.core4,keysv18,arbace.cpp.codegen8,emit-d0!v18,arbace.cpp.codegen8,emit-fn!v11,arbace.core7,filtervR38,R50,v11,arbace.core4,seq?R38,V2,R545,Tv17,arbace.cpp.inline13,always-inlineR556,v11,arbace.core7,printlnv11,arbace.core5,*out*v11,arbace.core5,*err*V1,V2,R557,s10,__cxxabiv1v18,arbace.cpp.codegen22,fundamental-typeinfos!V1,V2,R557,s10,__cxxabiv1v22,arbace.repr.cpp.native10,parse-fileR558,R559,R560,R561,R562,R563,p3,\\s+v16,arbace.repr.llvm6,latin1v15,arbace.cpp.sema15,analyze-programR564,R565,v18,arbace.cpp.codegen10,gen-modulev15,arbace.cpp.sema10,*cxx-year*v15,arbace.cpp.sema8,cxx-yearv15,arbace.cpp.sema11,*main-name*v15,arbace.cpp.sema10,*main-dir*v21,arbace.repr.cpp.parse14,*full-headers*v15,arbace.cpp.sema11,*decltypes*R566,v18,arbace.cpp.codegen8,gen-filep6,[\\t\\n]v11,arbace.core4,spitv11,arbace.core8,distinctv16,arbace.cpp.lower10,lower-fileR567,v18,arbace.cpp.codegen11,write-dropsv15,arbace.cpp.sema14,*header-drops*v15,arbace.cpp.sema4,*at*v16,arbace.repr.llvm11,module-textv16,arbace.repr.llvm10,ns-name-ofv16,arbace.repr.llvm11,spit-latin1v16,arbace.repr.llvm8,print-llp6,[\\t\\n]R568,v11,arbace.core7,ex-dataR569,p6,[\\t\\n]R570,v11,arbace.core7,re-findp35,^define [^@]*@(\\\"[^\\\"]+\\\"|[^ (]+)\\(p35,^@(\\\"[^\\\"]+\\\"|[^ ]+) = (?!external)p7,^\\\"|\\\"$v13,arbace.string11,split-linesv11,arbace.core5,slurpv18,arbace.cpp.codegen6,slurp?v11,arbace.core11,read-stringp2,\\tv13,arbace.string4,trimv11,arbace.core6,removev18,arbace.cpp.codegen13,defined-namesp2,\\tR571,R572,R573,R574,R575,R576,R577,R578,V1,R428,p2,\\tv18,arbace.cpp.codegen11,file-sha256p3,\\s+p2,\\tv18,arbace.cpp.codegen11,gen-outcomev18,arbace.cpp.codegen17,read-forms-recordv11,arbace.core10,sorted-mapR579,R580,R581,R582,v18,arbace.cpp.codegen7,gen-onev18,arbace.cpp.codegen9,gen-judgep2,\\tv18,arbace.cpp.codegen5,judgep2,\\tp4,^gnuv13,arbace.string6,blank?p3,\\s+v11,arbace.core5,flushv11,arbace.core15,shutdown-agentsv21,arbace.repr.cpp.parse12,*full-cache*")

var Lit_1 *jrt.String = jrt.Intern("gen")

var Lit_2 *jrt.String = jrt.Intern("--std")

var Lit_3 *jrt.String = jrt.Intern("c++23")

var Lit_4 *jrt.String = jrt.Intern("arbace.cpp.codegen$_main$fn__1801002110")

var Lit_5 *jrt.String = jrt.Intern("gen-judge")

var Lit_6 *jrt.String = jrt.Intern("--record")

var Lit_7 *jrt.String = jrt.Intern("gen-list")

var Lit_8 *jrt.String = jrt.Intern("/x.ll")

var Lit_9 *jrt.String = jrt.Intern("ref.c")

var Lit_10 *jrt.String = jrt.Intern("/ref.refused")

var Lit_11 *jrt.String = jrt.Intern("\n")

var Lit_12 *jrt.String = jrt.Intern("/ref.c")

var Lit_13 *jrt.String = jrt.Intern("generated")

var Lit_14 *jrt.String = jrt.Intern("gen-batch")

var Lit_15 *jrt.String = jrt.Intern("1")

var Lit_16 *jrt.String = jrt.Intern("CPP_GEN_FULL_CACHE")

var Lit_17 *jrt.String = jrt.Intern("arbace.cpp.codegen$_main$fn__1801002131")

var Lit_18 *jrt.String = jrt.Intern("judge")

var Lit_19 *jrt.String = jrt.Intern("codegen: gen FILE OUT [--std S], gen-list LIST")

var Lit_20 *jrt.String = jrt.Intern(": refused (")

var Lit_21 *jrt.String = jrt.Intern("): ")

var Lit_22 *jrt.String = jrt.Intern("/gen.refused")

var Lit_23 *jrt.String = jrt.Intern("c")

var Lit_24 *jrt.String = jrt.Intern("")

var Lit_25 *jrt.String = jrt.Intern("\t")

var Lit_26 *jrt.String = jrt.Intern("ok")

var Lit_27 *jrt.String = jrt.Intern("arbace.cpp.codegen$abstract_class_QMARK_$fn__1801001556")

var Lit_28 *jrt.String = jrt.Intern("no address point for ")

var Lit_29 *jrt.String = jrt.Intern("arbace.cpp.codegen$arg_values$fn__1801000205")

var Lit_30 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_31 *jrt.String = jrt.Intern("argument ")

var Lit_32 *jrt.String = jrt.Intern(" of type ")

var Lit_33 *jrt.String = jrt.Intern(" initialized as ")

var Lit_34 *jrt.String = jrt.Intern(" of ")

var Lit_35 *jrt.String = jrt.Intern("atomic.continue")

var Lit_36 *jrt.String = jrt.Intern("monotonic")

var Lit_37 *jrt.String = jrt.Intern("acquire")

var Lit_38 *jrt.String = jrt.Intern("release")

var Lit_39 *jrt.String = jrt.Intern("acqrel")

var Lit_40 *jrt.String = jrt.Intern("seqcst")

var Lit_41 *jrt.String = jrt.Intern("arbace.cpp.codegen$by_order_BANG_$iter__1801000365__1801000371")

var Lit_42 *jrt.String = jrt.Intern("arbace.cpp.codegen$by_order_BANG_$iter__1801000365__1801000371$fn__1801000372")

var Lit_43 *jrt.String = jrt.Intern("arbace.cpp.codegen$by_order_BANG_$iter__1801000365__1801000371$fn__1801000372$iter__1801000367__1801000376")

var Lit_44 *jrt.String = jrt.Intern("arbace.cpp.codegen$by_order_BANG_$iter__1801000365__1801000371$fn__1801000372$iter__1801000367__1801000376$fn__1801000377")

var Lit_45 *jrt.String = jrt.Intern("arbace.cpp.codegen$by_order_BANG_$iter__1801000365__1801000371$fn__1801000372$iter__1801000367__1801000376$fn__1801000377$fn__1801000378")

var Lit_46 *jrt.String = jrt.Intern("=")

var Lit_47 *jrt.String = jrt.Intern("arbace.cpp.codegen$call_BANG_$fn__1801000239")

var Lit_48 *jrt.String = jrt.Intern("invoke.cont")

var Lit_49 *jrt.String = jrt.Intern("0.000000e+00")

var Lit_50 *jrt.String = jrt.Intern("cast.notnull")

var Lit_51 *jrt.String = jrt.Intern("cast.end")

var Lit_52 *jrt.String = jrt.Intern("__clang_call_terminate")

var Lit_53 *jrt.String = jrt.Intern("__cxa_begin_catch")

var Lit_54 *jrt.String = jrt.Intern("_ZSt9terminatev")

var Lit_55 *jrt.String = jrt.Intern("arbace.cpp.codegen$close_block_BANG_$fn__1801000045")

var Lit_56 *jrt.String = jrt.Intern("<")

var Lit_57 *jrt.String = jrt.Intern(">")

var Lit_58 *jrt.String = jrt.Intern("!=")

var Lit_59 *jrt.String = jrt.Intern("<=")

var Lit_60 *jrt.String = jrt.Intern("==")

var Lit_61 *jrt.String = jrt.Intern(">=")

var Lit_62 *jrt.String = jrt.Intern("arbace.cpp.codegen$coerce_out_BANG_$fn__1801000130")

var Lit_63 *jrt.String = jrt.Intern("cond.true")

var Lit_64 *jrt.String = jrt.Intern("cond.false")

var Lit_65 *jrt.String = jrt.Intern("cond.end")

var Lit_66 *jrt.String = jrt.Intern("arbace.cpp.codegen$cond_branches2_BANG_$fn__1801000327")

var Lit_67 *jrt.String = jrt.Intern("arbace.cpp.codegen$cond_branches2_BANG_$fn__1801000329")

var Lit_68 *jrt.String = jrt.Intern("arbace.cpp.codegen$conj_new$fn__1801000017")

var Lit_69 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$fn__1801001331")

var Lit_70 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$fn__1801001335")

var Lit_71 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$iter__1801001339__1801001343")

var Lit_72 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$fn__1801001354")

var Lit_73 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$fn__1801001356")

var Lit_74 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$fn__1801001358")

var Lit_75 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$fn__1801001360")

var Lit_76 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$fn__1801001362")

var Lit_77 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$fn__1801001365")

var Lit_78 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$cv__1801001370")

var Lit_79 *jrt.String = jrt.Intern("-")

var Lit_80 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$fn__1801001331$fn__1801001332")

var Lit_81 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$fn__1801001335$fn__1801001336")

var Lit_82 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$iter__1801001339__1801001343$fn__1801001344")

var Lit_83 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves$iter__1801001339__1801001343$fn__1801001344$fn__1801001345")

var Lit_84 *jrt.String = jrt.Intern("arbace.cpp.codegen$contains_label_QMARK_$fn__1801000833")

var Lit_85 *jrt.String = jrt.Intern("arbace.cpp.codegen$contains_label_QMARK_$fn__1801000835")

var Lit_86 *jrt.String = jrt.Intern("arbace.cpp.codegen$contains_label_QMARK_$fn__1801000837")

var Lit_87 *jrt.String = jrt.Intern("arbace.cpp.codegen$contains_label_QMARK_$fn__1801000839")

var Lit_88 *jrt.String = jrt.Intern("arbace.cpp.codegen$contains_label_QMARK_$fn__1801000841")

var Lit_89 *jrt.String = jrt.Intern("arbace.cpp.codegen$declare_BANG_$fn__1801000034")

var Lit_90 *jrt.String = jrt.Intern("arbace.cpp.codegen$defined_names$iter__1801001832__1801001836")

var Lit_91 *jrt.String = jrt.Intern("arbace.cpp.codegen$defined_names$iter__1801001832__1801001836$fn__1801001837")

var Lit_92 *jrt.String = jrt.Intern("arbace.cpp.codegen$defined_names$iter__1801001832__1801001836$fn__1801001837$fn__1801001838")

var Lit_93 *jrt.String = jrt.Intern(".str")

var Lit_94 *jrt.String = jrt.Intern("llvm.")

var Lit_95 *jrt.String = jrt.Intern("_GLOBAL__sub_I_")

var Lit_96 *jrt.String = jrt.Intern("__cxx_global_var_init")

var Lit_97 *jrt.String = jrt.Intern("__dynamic_cast")

var Lit_98 *jrt.String = jrt.Intern("arbace.cpp.codegen$eh_typeinfo_BANG_$strip__1801001325")

var Lit_99 *jrt.String = jrt.Intern("arbace.cpp.codegen$eh_typeinfo_BANG_$fundamental_QMARK___1801001327")

var Lit_100 *jrt.String = jrt.Intern("_ZTI")

var Lit_101 *jrt.String = jrt.Intern("_ZTS")

var Lit_102 *jrt.String = jrt.Intern("_ZTVN10__cxxabiv119__pointer_type_infoE")

var Lit_103 *jrt.String = jrt.Intern("_ZTVN10__cxxabiv116__enum_type_infoE")

var Lit_104 *jrt.String = jrt.Intern("_ZTVN10__cxxabiv117__array_type_infoE")

var Lit_105 *jrt.String = jrt.Intern("_ZTVN10__cxxabiv120__function_type_infoE")

var Lit_106 *jrt.String = jrt.Intern("type_info of ")

var Lit_107 *jrt.String = jrt.Intern("arbace.cpp.codegen$eh_walk_BANG_$hs_BANG___1801000181")

var Lit_108 *jrt.String = jrt.Intern("terminate.lpad")

var Lit_109 *jrt.String = jrt.Intern("__cxa_end_catch")

var Lit_110 *jrt.String = jrt.Intern("llvm.eh.typeid.for.p0")

var Lit_111 *jrt.String = jrt.Intern("catch.next")

var Lit_112 *jrt.String = jrt.Intern("dead")

var Lit_113 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_atomic_BANG_$val_of__1801000464")

var Lit_114 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_atomic_BANG_$out_BANG___1801000466")

var Lit_115 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_atomic_BANG_$fn__1801000469")

var Lit_116 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_atomic_BANG_$fn__1801000471")

var Lit_117 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_atomic_BANG_$fn__1801000473")

var Lit_118 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_atomic_BANG_$fn__1801000476")

var Lit_119 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_atomic_BANG_$fn__1801000481")

var Lit_120 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_atomic_BANG_$fn__1801000483")

var Lit_121 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_atomic_BANG_$one_STAR___1801000485")

var Lit_122 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_atomic_BANG_$one__1801000488")

var Lit_123 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_atomic_BANG_$fails__1801000500")

var Lit_124 *jrt.String = jrt.Intern("monotonic_fail")

var Lit_125 *jrt.String = jrt.Intern("acquire_fail")

var Lit_126 *jrt.String = jrt.Intern("seqcst_fail")

var Lit_127 *jrt.String = jrt.Intern("cmpxchg.store_expected")

var Lit_128 *jrt.String = jrt.Intern("cmpxchg.continue")

var Lit_129 *jrt.String = jrt.Intern("cmxchg.weak")

var Lit_130 *jrt.String = jrt.Intern("cmpxchg.strong")

var Lit_131 *jrt.String = jrt.Intern("llvm.bswap.")

var Lit_132 *jrt.String = jrt.Intern(".")

var Lit_133 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_call_BANG_$fn__1801000215")

var Lit_134 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_call_BANG_$fn__1801000218")

var Lit_135 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_call_BANG_$iter__1801000225__1801000229")

var Lit_136 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_call_BANG_$iter__1801000225__1801000229$fn__1801000230")

var Lit_137 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_call_BANG_$iter__1801000225__1801000229$fn__1801000230$fn__1801000231")

var Lit_138 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_d0_BANG_$fn__1801001227")

var Lit_139 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_d0_BANG_$fn__1801001227$fn__1801001228")

var Lit_140 *jrt.String = jrt.Intern("singlethread")

var Lit_141 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fence_BANG_$f_BANG___1801000431")

var Lit_142 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fence_BANG_$iter__1801000433__1801000439")

var Lit_143 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fence_BANG_$iter__1801000433__1801000439$fn__1801000440")

var Lit_144 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fence_BANG_$iter__1801000433__1801000439$fn__1801000440$iter__1801000435__1801000444")

var Lit_145 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fence_BANG_$iter__1801000433__1801000439$fn__1801000440$iter__1801000435__1801000444$fn__1801000445")

var Lit_146 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fence_BANG_$iter__1801000433__1801000439$fn__1801000440$iter__1801000435__1801000444$fn__1801000445$fn__1801000446")

var Lit_147 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$fn__1801001111")

var Lit_148 *jrt.String = jrt.Intern("main")

var Lit_149 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$sub_vtt__1801001127")

var Lit_150 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$fn__1801001129")

var Lit_151 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$fn__1801001139")

var Lit_152 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$fn__1801001145")

var Lit_153 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$fn__1801001155")

var Lit_154 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$fn__1801001161")

var Lit_155 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$fn__1801001171")

var Lit_156 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$fn__1801001177")

var Lit_157 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$fn__1801001200")

var Lit_158 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$fn__1801001205")

var Lit_159 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$fn__1801001211")

var Lit_160 *jrt.String = jrt.Intern("llvm.trap")

var Lit_161 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$fn__1801001218")

var Lit_162 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_$fn__1801001223")

var Lit_163 *jrt.String = jrt.Intern("__gxx_personality_v0")

var Lit_164 *jrt.String = jrt.Intern("%a")

var Lit_165 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001398")

var Lit_166 *jrt.String = jrt.Intern("a thread-local variable with a destructor (")

var Lit_167 *jrt.String = jrt.Intern(")")

var Lit_168 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001403")

var Lit_169 *jrt.String = jrt.Intern("a template's thread-local static member with dynamic initialization (")

var Lit_170 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001411")

var Lit_171 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001416")

var Lit_172 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001419")

var Lit_173 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001428")

var Lit_174 *jrt.String = jrt.Intern("init")

var Lit_175 *jrt.String = jrt.Intern("_GLOBAL__I_%06d")

var Lit_176 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001443")

var Lit_177 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001470")

var Lit_178 *jrt.String = jrt.Intern("__tls_guard")

var Lit_179 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001494")

var Lit_180 *jrt.String = jrt.Intern("__tls_init")

var Lit_181 *jrt.String = jrt.Intern("_ZTH")

var Lit_182 *jrt.String = jrt.Intern("llvm.threadlocal.address.p0")

var Lit_183 *jrt.String = jrt.Intern("llvm.global_ctors")

var Lit_184 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$iter__1801001538__1801001542")

var Lit_185 *jrt.String = jrt.Intern("_ZGV")

var Lit_186 *jrt.String = jrt.Intern("init.done")

var Lit_187 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001443$fn__1801001451")

var Lit_188 *jrt.String = jrt.Intern("__cxa_atexit")

var Lit_189 *jrt.String = jrt.Intern("__dso_handle")

var Lit_190 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001443$fn__1801001460")

var Lit_191 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001470$fn__1801001478")

var Lit_192 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001470$fn__1801001487")

var Lit_193 *jrt.String = jrt.Intern("exit")

var Lit_194 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001494$fn__1801001502")

var Lit_195 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$fn__1801001494$fn__1801001511")

var Lit_196 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$iter__1801001538__1801001542$fn__1801001543")

var Lit_197 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_$iter__1801001538__1801001542$fn__1801001543$fn__1801001544")

var Lit_198 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_if_BANG_$fn__1801000849")

var Lit_199 *jrt.String = jrt.Intern("if.then")

var Lit_200 *jrt.String = jrt.Intern("if.else")

var Lit_201 *jrt.String = jrt.Intern("if.end")

var Lit_202 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_if_branches_BANG_$fn__1801000852")

var Lit_203 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_init$fn__1801000585")

var Lit_204 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_init$fn__1801000601")

var Lit_205 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_init$fn__1801000605")

var Lit_206 *jrt.String = jrt.Intern("an aggregate with a vptr")

var Lit_207 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_init$fn__1801000619")

var Lit_208 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_init$fn__1801000627")

var Lit_209 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_init$fn__1801000629")

var Lit_210 *jrt.String = jrt.Intern("initializer ")

var Lit_211 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_init$fn__1801000601$fn__1801000602")

var Lit_212 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_init$fn__1801000605$fn__1801000606")

var Lit_213 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_into$fn__1801000576")

var Lit_214 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_into$fn__1801000578")

var Lit_215 *jrt.String = jrt.Intern("class prvalue ")

var Lit_216 *jrt.String = jrt.Intern("raw as an lvalue")

var Lit_217 *jrt.String = jrt.Intern("postfix as an lvalue")

var Lit_218 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_lv$fn__1801000554")

var Lit_219 *jrt.String = jrt.Intern("an opaque prvalue as a glvalue")

var Lit_220 *jrt.String = jrt.Intern("typeid.bad_typeid")

var Lit_221 *jrt.String = jrt.Intern("typeid.end")

var Lit_222 *jrt.String = jrt.Intern("__cxa_bad_typeid")

var Lit_223 *jrt.String = jrt.Intern("dynamic_cast.bad")

var Lit_224 *jrt.String = jrt.Intern("dynamic_cast.end")

var Lit_225 *jrt.String = jrt.Intern("__cxa_bad_cast")

var Lit_226 *jrt.String = jrt.Intern("lvalue ")

var Lit_227 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_return_BANG_$fn__1801000674")

var Lit_228 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_return_BANG_$fn__1801000680")

var Lit_229 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_return_BANG_$fn__1801000686")

var Lit_230 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_return_BANG_$fn__1801000693")

var Lit_231 *jrt.String = jrt.Intern("a reference to a temporary")

var Lit_232 *jrt.String = jrt.Intern("llvm.va_start.p0")

var Lit_233 *jrt.String = jrt.Intern("llvm.va_end.p0")

var Lit_234 *jrt.String = jrt.Intern("llvm.va_copy.p0")

var Lit_235 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_rv$fn__1801000518")

var Lit_236 *jrt.String = jrt.Intern("an opaque glvalue as a prvalue")

var Lit_237 *jrt.String = jrt.Intern("__cxa_allocate_exception")

var Lit_238 *jrt.String = jrt.Intern("__cxa_throw")

var Lit_239 *jrt.String = jrt.Intern("__cxa_rethrow")

var Lit_240 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_rv$x__1801000520")

var Lit_241 *jrt.String = jrt.Intern("delete.notnull")

var Lit_242 *jrt.String = jrt.Intern("delete.end")

var Lit_243 *jrt.String = jrt.Intern("delete.loop")

var Lit_244 *jrt.String = jrt.Intern("delete.body")

var Lit_245 *jrt.String = jrt.Intern("delete.free")

var Lit_246 *jrt.String = jrt.Intern("_ZdaPvm")

var Lit_247 *jrt.String = jrt.Intern("_ZdaPv")

var Lit_248 *jrt.String = jrt.Intern("_ZdlPvm")

var Lit_249 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_rv$fn__1801000523")

var Lit_250 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_rv$fn__1801000525")

var Lit_251 *jrt.String = jrt.Intern("va_arg of a class as a scalar")

var Lit_252 *jrt.String = jrt.Intern("va_arg of ")

var Lit_253 *jrt.String = jrt.Intern("vaarg.in_reg")

var Lit_254 *jrt.String = jrt.Intern("vaarg.in_mem")

var Lit_255 *jrt.String = jrt.Intern("vaarg.end")

var Lit_256 *jrt.String = jrt.Intern("+")

var Lit_257 *jrt.String = jrt.Intern("~")

var Lit_258 *jrt.String = jrt.Intern("_Znam")

var Lit_259 *jrt.String = jrt.Intern("new.notnull")

var Lit_260 *jrt.String = jrt.Intern("new.cont")

var Lit_261 *jrt.String = jrt.Intern("new.loop")

var Lit_262 *jrt.String = jrt.Intern("new.body")

var Lit_263 *jrt.String = jrt.Intern("new.end")

var Lit_264 *jrt.String = jrt.Intern("_Znwm")

var Lit_265 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_rv$fn__1801000550")

var Lit_266 *jrt.String = jrt.Intern("rvalue ")

var Lit_267 *jrt.String = jrt.Intern("goto with destructors to run")

var Lit_268 *jrt.String = jrt.Intern("lbl.")

var Lit_269 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$fn__1801000710")

var Lit_270 *jrt.String = jrt.Intern(",")

var Lit_271 *jrt.String = jrt.Intern("r")

var Lit_272 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$fn__1801000712")

var Lit_273 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$fn__1801000722")

var Lit_274 *jrt.String = jrt.Intern("for.cond")

var Lit_275 *jrt.String = jrt.Intern("for.body")

var Lit_276 *jrt.String = jrt.Intern("for.inc")

var Lit_277 *jrt.String = jrt.Intern("for.end")

var Lit_278 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$fn__1801000724")

var Lit_279 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$fn__1801000730")

var Lit_280 *jrt.String = jrt.Intern("do.body")

var Lit_281 *jrt.String = jrt.Intern("do.cond")

var Lit_282 *jrt.String = jrt.Intern("do.end")

var Lit_283 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$fn__1801000736")

var Lit_284 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$fn__1801000742")

var Lit_285 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$fn__1801000748")

var Lit_286 *jrt.String = jrt.Intern("sw.end")

var Lit_287 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$walk__1801000754")

var Lit_288 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$fn__1801000770")

var Lit_289 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$iter__1801000775__1801000779")

var Lit_290 *jrt.String = jrt.Intern("while.cond")

var Lit_291 *jrt.String = jrt.Intern("while.body")

var Lit_292 *jrt.String = jrt.Intern("while.end")

var Lit_293 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$fn__1801000797")

var Lit_294 *jrt.String = jrt.Intern("statement ")

var Lit_295 *jrt.String = jrt.Intern("memory")

var Lit_296 *jrt.String = jrt.Intern("~{memory}")

var Lit_297 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$iter__1801000775__1801000779$fn__1801000780")

var Lit_298 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_$iter__1801000775__1801000779$fn__1801000780$fn__1801000781")

var Lit_299 *jrt.String = jrt.Intern("sw.default")

var Lit_300 *jrt.String = jrt.Intern("sw.bb")

var Lit_301 *jrt.String = jrt.Intern("try.cont")

var Lit_302 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_try_BANG_$fn__1801000807")

var Lit_303 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_try_BANG_$fn__1801000809")

var Lit_304 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_try_BANG_$fn__1801000811")

var Lit_305 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_try_BANG_$fn__1801000820")

var Lit_306 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_try_BANG_$fn__1801000825")

var Lit_307 *jrt.String = jrt.Intern("catch")

var Lit_308 *jrt.String = jrt.Intern("arbace.cpp.codegen$eval1801000557$fn__1801000558$fn__1801000559")

var Lit_309 *jrt.String = jrt.Intern("arbace.cpp.codegen$eval1801000859$fn__1801000860$fn__1801000861")

var Lit_310 *jrt.String = jrt.Intern("arbace.cpp.codegen$extern_inst_QMARK_$fn__1801000144")

var Lit_311 *jrt.String = jrt.Intern("no field ")

var Lit_312 *jrt.String = jrt.Intern("no laid-out field ")

var Lit_313 *jrt.String = jrt.Intern(" (")

var Lit_314 *jrt.String = jrt.Intern(" laid out)")

var Lit_315 *jrt.String = jrt.Intern("SHA-256")

var Lit_316 *jrt.String = jrt.Intern("UTF-8")

var Lit_317 *jrt.String = jrt.Intern("arbace.cpp.codegen$file_sha256$fn__1801001954")

var Lit_318 *jrt.String = jrt.Intern("%02x")

var Lit_319 *jrt.String = jrt.Intern("arbace.cpp.codegen$final_overrider$fn__1801000885")

var Lit_320 *jrt.String = jrt.Intern("arbace.cpp.codegen$final_overrider$fn__1801000890")

var Lit_321 *jrt.String = jrt.Intern("arbace.cpp.codegen$final_overrider$fn__1801000885$fn__1801000886")

var Lit_322 *jrt.String = jrt.Intern("arbace.cpp.codegen$final_overrider$fn__1801000890$fn__1801000895")

var Lit_323 *jrt.String = jrt.Intern("arbace.cpp.codegen$find_sub$fn__1801000881")

var Lit_324 *jrt.String = jrt.Intern("f0x80000000000000000000")

var Lit_325 *jrt.String = jrt.Intern("f0x00000000000000000000")

var Lit_326 *jrt.String = jrt.Intern("arbace.cpp.codegen$fp80_hex$fn__1801000302")

var Lit_327 *jrt.String = jrt.Intern("f0x%04X%016X")

var Lit_328 *jrt.String = jrt.Intern("a constant of ")

var Lit_329 *jrt.String = jrt.Intern("0x")

var Lit_330 *jrt.String = jrt.Intern("%016x")

var Lit_331 *jrt.String = jrt.Intern("%")

var Lit_332 *jrt.String = jrt.Intern("*")

var Lit_333 *jrt.String = jrt.Intern("/")

var Lit_334 *jrt.String = jrt.Intern("arbace.cpp.codegen$fundamental_typeinfos_BANG_$vt__1801001559")

var Lit_335 *jrt.String = jrt.Intern("_ZTVN10__cxxabiv123__fundamental_type_infoE")

var Lit_336 *jrt.String = jrt.Intern("arbace.cpp.codegen$fundamental_typeinfos_BANG_$name_BANG___1801001561")

var Lit_337 *jrt.String = jrt.Intern("_ZTIP")

var Lit_338 *jrt.String = jrt.Intern("_ZTIPK")

var Lit_339 *jrt.String = jrt.Intern("0")

var Lit_340 *jrt.String = jrt.Intern("CPP_FULL_HEADERS")

var Lit_341 *jrt.String = jrt.Intern("the native parser declined ")

var Lit_342 *jrt.String = jrt.Intern(" constructs")

var Lit_343 *jrt.String = jrt.Intern(": ")

var Lit_344 *jrt.String = jrt.Intern("; ")

var Lit_345 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_file$iter__1801001729__1801001733")

var Lit_346 *jrt.String = jrt.Intern("the preprocessor: ")

var Lit_347 *jrt.String = jrt.Intern(" ")

var Lit_348 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_file$fn__1801001745")

var Lit_349 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_file$iter__1801001729__1801001733$fn__1801001734")

var Lit_350 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_file$iter__1801001729__1801001733$fn__1801001734$fn__1801001735")

var Lit_351 *jrt.String = jrt.Intern(" x")

var Lit_352 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801001979__1801001983")

var Lit_353 *jrt.String = jrt.Intern("/list.tsv")

var Lit_354 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801001989__1801001993")

var Lit_355 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$expect__1801001999")

var Lit_356 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$verdict__1801002001")

var Lit_357 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002003__1801002007")

var Lit_358 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$fn__1801002013")

var Lit_359 *jrt.String = jrt.Intern("/results.tsv")

var Lit_360 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002015__1801002019")

var Lit_361 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002037__1801002041")

var Lit_362 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002053__1801002057")

var Lit_363 *jrt.String = jrt.Intern(";; CP302 (a): test/cpp/codegen's samples the code generator refuses, NAME -> the refusal's class (gen.refused's\n")

var Lit_364 *jrt.String = jrt.Intern(";; first field); bin/cppi codegen-gen --record writes it, with forms.sha256 (the others' forms.ae). Read with the Clojure reader.\n")

var Lit_365 *jrt.String = jrt.Intern("# CP302 (a): the SHA-256 of each generated sample's forms.ae (bin/cppi codegen-gen --record)\n")

var Lit_366 *jrt.String = jrt.Intern("codegen-gen: recorded %d samples, %d generated, %d refused")

var Lit_367 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$fn__1801002069")

var Lit_368 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002071__1801002075")

var Lit_369 *jrt.String = jrt.Intern("codegen-gen: %d samples, %d pass (%d generated, %d refused as recorded), %d failing%s")

var Lit_370 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$fn__1801002101")

var Lit_371 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$fn__1801002103")

var Lit_372 *jrt.String = jrt.Intern(", controls passing: ")

var Lit_373 *jrt.String = jrt.Intern("pass")

var Lit_374 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801001979__1801001983$fn__1801001984")

var Lit_375 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801001979__1801001983$fn__1801001984$fn__1801001985")

var Lit_376 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801001989__1801001993$fn__1801001994")

var Lit_377 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801001989__1801001993$fn__1801001994$fn__1801001995")

var Lit_378 *jrt.String = jrt.Intern("/files/")

var Lit_379 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002003__1801002007$fn__1801002008")

var Lit_380 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002003__1801002007$fn__1801002008$fn__1801002009")

var Lit_381 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002015__1801002019$fn__1801002020")

var Lit_382 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002015__1801002019$fn__1801002020$fn__1801002021")

var Lit_383 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002037__1801002041$fn__1801002042")

var Lit_384 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002037__1801002041$fn__1801002042$fn__1801002043")

var Lit_385 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002053__1801002057$fn__1801002058")

var Lit_386 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002053__1801002057$fn__1801002058$fn__1801002059")

var Lit_387 *jrt.String = jrt.Intern("  ")

var Lit_388 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002071__1801002075$fn__1801002076")

var Lit_389 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge$iter__1801002071__1801002075$fn__1801002076$fn__1801002077")

var Lit_390 *jrt.String = jrt.Intern("control ")

var Lit_391 *jrt.String = jrt.Intern(" left: the run lacks ")

var Lit_392 *jrt.String = jrt.Intern(" passed: the judge takes another sample's record")

var Lit_393 *jrt.String = jrt.Intern("not-recorded")

var Lit_394 *jrt.String = jrt.Intern("forms-differ")

var Lit_395 *jrt.String = jrt.Intern("refusal-differs")

var Lit_396 *jrt.String = jrt.Intern("refused")

var Lit_397 *jrt.String = jrt.Intern("CPP_LAYOUT_TRACE")

var Lit_398 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$fn__1801001615")

var Lit_399 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$fn__1801001622")

var Lit_400 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$fn__1801001626")

var Lit_401 *jrt.String = jrt.Intern("__fundamental_type_info")

var Lit_402 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$emit_item_BANG___1801001643")

var Lit_403 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$vt_todo__1801001648")

var Lit_404 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$vtables_BANG___1801001670")

var Lit_405 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$pending_QMARK___1801001682")

var Lit_406 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$deferred_BANG___1801001684")

var Lit_407 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$fn__1801001694")

var Lit_408 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$iter__1801001708__1801001712")

var Lit_409 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$fn__1801001724")

var Lit_410 *jrt.String = jrt.Intern("e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128")

var Lit_411 *jrt.String = jrt.Intern("x86_64-alpine-linux-musl")

var Lit_412 *jrt.String = jrt.Intern("layout")

var Lit_413 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$fn__1801001615$fn__1801001616")

var Lit_414 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$fn__1801001622$fn__1801001623")

var Lit_415 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$fn__1801001694$fn__1801001695")

var Lit_416 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$fn__1801001724$fn__1801001725")

var Lit_417 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$iter__1801001708__1801001712$fn__1801001713")

var Lit_418 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$iter__1801001708__1801001712$fn__1801001713$fn__1801001714")

var Lit_419 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$vt_todo__1801001648$iter__1801001649__1801001653")

var Lit_420 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$vt_todo__1801001648$iter__1801001659__1801001663")

var Lit_421 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$vt_todo__1801001648$iter__1801001649__1801001653$fn__1801001654")

var Lit_422 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$vt_todo__1801001648$iter__1801001649__1801001653$fn__1801001654$fn__1801001655")

var Lit_423 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$vt_todo__1801001648$iter__1801001659__1801001663$fn__1801001664")

var Lit_424 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module$vt_todo__1801001648$iter__1801001659__1801001663$fn__1801001664$fn__1801001665")

var Lit_425 *jrt.String = jrt.Intern("CPP_GEN_WHERE")

var Lit_426 *jrt.String = jrt.Intern("/forms.ae")

var Lit_427 *jrt.String = jrt.Intern("gen.ll")

var Lit_428 *jrt.String = jrt.Intern("/gen.ll")

var Lit_429 *jrt.String = jrt.Intern("gen.c")

var Lit_430 *jrt.String = jrt.Intern("lower-")

var Lit_431 *jrt.String = jrt.Intern("/gen.c")

var Lit_432 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_one$fn__1801001827")

var Lit_433 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_one$fn__1801001829")

var Lit_434 *jrt.String = jrt.Intern("/drops.tsv")

var Lit_435 *jrt.String = jrt.Intern("refused at")

var Lit_436 *jrt.String = jrt.Intern("2")

var Lit_437 *jrt.String = jrt.Intern("arbace.cpp.codegen$group_BANG_$iter__1801001291__1801001295")

var Lit_438 *jrt.String = jrt.Intern("arbace.cpp.codegen$group_BANG_$iter__1801001291__1801001295$fn__1801001296")

var Lit_439 *jrt.String = jrt.Intern("arbace.cpp.codegen$group_BANG_$iter__1801001291__1801001295$fn__1801001296$fn__1801001297")

var Lit_440 *jrt.String = jrt.Intern("__cxa_pure_virtual")

var Lit_441 *jrt.String = jrt.Intern("..")

var Lit_442 *jrt.String = jrt.Intern("g")

var Lit_443 *jrt.String = jrt.Intern("++")

var Lit_444 *jrt.String = jrt.Intern("&")

var Lit_445 *jrt.String = jrt.Intern("^")

var Lit_446 *jrt.String = jrt.Intern("|")

var Lit_447 *jrt.String = jrt.Intern("<<")

var Lit_448 *jrt.String = jrt.Intern(">>")

var Lit_449 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001850__1801001854")

var Lit_450 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001860__1801001864")

var Lit_451 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001900__1801001904")

var Lit_452 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001910__1801001914")

var Lit_453 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001930__1801001934")

var Lit_454 *jrt.String = jrt.Intern("/summary.edn")

var Lit_455 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$fn__1801001940")

var Lit_456 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$fn__1801001942")

var Lit_457 *jrt.String = jrt.Intern("%-28s %s%s")

var Lit_458 *jrt.String = jrt.Intern("codegen-check: %d of %d pass, %d known, %d failing%s")

var Lit_459 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$fn__1801001948")

var Lit_460 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$fn__1801001950")

var Lit_461 *jrt.String = jrt.Intern(", known but passing: ")

var Lit_462 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001850__1801001854$fn__1801001855")

var Lit_463 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001850__1801001854$fn__1801001855$fn__1801001856")

var Lit_464 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001860__1801001864$fn__1801001865")

var Lit_465 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001860__1801001864$fn__1801001865$fn__1801001866")

var Lit_466 *jrt.String = jrt.Intern("x.ll")

var Lit_467 *jrt.String = jrt.Intern("gen.refused")

var Lit_468 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001860__1801001864$fn__1801001865$run__1801001895")

var Lit_469 *jrt.String = jrt.Intern("ref")

var Lit_470 *jrt.String = jrt.Intern("nat")

var Lit_471 *jrt.String = jrt.Intern("no-reference")

var Lit_472 *jrt.String = jrt.Intern("reference-failed")

var Lit_473 *jrt.String = jrt.Intern("refused:")

var Lit_474 *jrt.String = jrt.Intern("gen-build-failed")

var Lit_475 *jrt.String = jrt.Intern("differs")

var Lit_476 *jrt.String = jrt.Intern("native-differs")

var Lit_477 *jrt.String = jrt.Intern("names-differ")

var Lit_478 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001860__1801001864$fn__1801001865$fn__1801001866$run__1801001879")

var Lit_479 *jrt.String = jrt.Intern(".status")

var Lit_480 *jrt.String = jrt.Intern(".out")

var Lit_481 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001900__1801001904$fn__1801001905")

var Lit_482 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001900__1801001904$fn__1801001905$fn__1801001906")

var Lit_483 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001910__1801001914$fn__1801001915")

var Lit_484 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001910__1801001914$fn__1801001915$fn__1801001916")

var Lit_485 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001910__1801001914$fn__1801001915$fn__1801001926")

var Lit_486 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001910__1801001914$fn__1801001915$fn__1801001916$fn__1801001920")

var Lit_487 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001930__1801001934$fn__1801001935")

var Lit_488 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge$iter__1801001930__1801001934$fn__1801001935$fn__1801001936")

var Lit_489 *jrt.String = jrt.Intern("arbace.cpp.codegen$key_fn$fn__1801001232")

var Lit_490 *jrt.String = jrt.Intern("lpad")

var Lit_491 *jrt.String = jrt.Intern("arbace.cpp.codegen$landing_pad_BANG_$fn__1801000193")

var Lit_492 *jrt.String = jrt.Intern("arbace.cpp.codegen$landing_pad_BANG_$fn__1801000195")

var Lit_493 *jrt.String = jrt.Intern("arbace.cpp.codegen$landing_pad_BANG_$fn__1801000197")

var Lit_494 *jrt.String = jrt.Intern("arbace.cpp.codegen$local_decl_BANG_$fn__1801000643")

var Lit_495 *jrt.String = jrt.Intern("arbace.cpp.codegen$local_decl_BANG_$fn__1801000653")

var Lit_496 *jrt.String = jrt.Intern("arbace.cpp.codegen$materialize_BANG_$fn__1801000319")

var Lit_497 *jrt.String = jrt.Intern("memptr.virtual")

var Lit_498 *jrt.String = jrt.Intern("memptr.nonvirtual")

var Lit_499 *jrt.String = jrt.Intern("memptr.end")

var Lit_500 *jrt.String = jrt.Intern("llvm.memcpy.p0.p0.i64")

var Lit_501 *jrt.String = jrt.Intern("llvm.memset.p0.i64")

var Lit_502 *jrt.String = jrt.Intern("dyn.notnull")

var Lit_503 *jrt.String = jrt.Intern("dyn.end")

var Lit_504 *jrt.String = jrt.Intern("__builtin_clear_padding of a union")

var Lit_505 *jrt.String = jrt.Intern("__builtin_clear_padding of a bit-field")

var Lit_506 *jrt.String = jrt.Intern("arbace.cpp.codegen$offset_comps$cur__1801000903")

var Lit_507 *jrt.String = jrt.Intern("arbace.cpp.codegen$offset_comps$vbase_offsets__1801000905")

var Lit_508 *jrt.String = jrt.Intern("arbace.cpp.codegen$offset_comps$vcall_offsets__1801000911")

var Lit_509 *jrt.String = jrt.Intern("arbace.cpp.codegen$offset_comps$both__1801000931")

var Lit_510 *jrt.String = jrt.Intern("arbace.cpp.codegen$offset_comps$vcall_offsets__1801000911$fn__1801000916")

var Lit_511 *jrt.String = jrt.Intern("arbace.cpp.codegen$offset_comps$vcall_offsets__1801000911$fn__1801000918")

var Lit_512 *jrt.String = jrt.Intern("an unbound opaque value")

var Lit_513 *jrt.String = jrt.Intern("arbace.cpp.codegen$pad_plan$fn__1801000174")

var Lit_514 *jrt.String = jrt.Intern("a class placement argument by value")

var Lit_515 *jrt.String = jrt.Intern("arbace.cpp.codegen$pop_to_BANG_$fn__1801000640")

var Lit_516 *jrt.String = jrt.Intern("arbace.cpp.codegen$read_forms_record$iter__1801001958__1801001962")

var Lit_517 *jrt.String = jrt.Intern("arbace.cpp.codegen$read_forms_record$iter__1801001958__1801001962$fn__1801001963")

var Lit_518 *jrt.String = jrt.Intern("arbace.cpp.codegen$read_forms_record$iter__1801001958__1801001962$fn__1801001963$fn__1801001964")

var Lit_519 *jrt.String = jrt.Intern("#")

var Lit_520 *jrt.String = jrt.Intern("arbace.cpp.codegen$reserve_BANG_$fn__1801000027")

var Lit_521 *jrt.String = jrt.Intern("arbace.cpp.codegen$return_adjustment$rc__1801000944")

var Lit_522 *jrt.String = jrt.Intern("cleanup")

var Lit_523 *jrt.String = jrt.Intern("cleanup.done")

var Lit_524 *jrt.String = jrt.Intern("__cxa_guard_abort")

var Lit_525 *jrt.String = jrt.Intern("land.rhs")

var Lit_526 *jrt.String = jrt.Intern("lor.rhs")

var Lit_527 *jrt.String = jrt.Intern("land.end")

var Lit_528 *jrt.String = jrt.Intern("lor.end")

var Lit_529 *jrt.String = jrt.Intern("arbace.cpp.codegen$short_circuit_branches_BANG_$fn__1801000323")

var Lit_530 *jrt.String = jrt.Intern("arbace.cpp.codegen$sig_plan$iter__1801000101__1801000105")

var Lit_531 *jrt.String = jrt.Intern("arbace.cpp.codegen$sig_plan$fn__1801000116")

var Lit_532 *jrt.String = jrt.Intern("arbace.cpp.codegen$sig_plan$fn__1801000119")

var Lit_533 *jrt.String = jrt.Intern("arbace.cpp.codegen$sig_plan$iter__1801000101__1801000105$fn__1801000106")

var Lit_534 *jrt.String = jrt.Intern("arbace.cpp.codegen$sig_plan$iter__1801000101__1801000105$fn__1801000106$fn__1801000107")

var Lit_535 *jrt.String = jrt.Intern("arbace.cpp.codegen$sig_plan$iter__1801000101__1801000105$fn__1801000106$fn__1801000111")

var Lit_536 *jrt.String = jrt.Intern("arbace.cpp.codegen$sig_plan$iter__1801000101__1801000105$fn__1801000106$fn__1801000107$fn__1801000108")

var Lit_537 *jrt.String = jrt.Intern("arbace.cpp.codegen$static_local_BANG_$fn__1801000663")

var Lit_538 *jrt.String = jrt.Intern("a thread-local static with dynamic initialization (")

var Lit_539 *jrt.String = jrt.Intern("init.check")

var Lit_540 *jrt.String = jrt.Intern("init.end")

var Lit_541 *jrt.String = jrt.Intern("__cxa_guard_acquire")

var Lit_542 *jrt.String = jrt.Intern("__cxa_guard_release")

var Lit_543 *jrt.String = jrt.Intern("arbace.cpp.codegen$static_local_BANG_$fn__1801000665")

var Lit_544 *jrt.String = jrt.Intern("arbace.cpp.codegen$static_local_BANG_$fn__1801000671")

var Lit_545 *jrt.String = jrt.Intern("arbace.cpp.codegen$stmt_expr_BANG_$fn__1801000343")

var Lit_546 *jrt.String = jrt.Intern("arbace.cpp.codegen$stmt_expr_BANG_$fn__1801000349")

var Lit_547 *jrt.String = jrt.Intern(".str.")

var Lit_548 *jrt.String = jrt.Intern("arbace.cpp.codegen$subobjects$nv__1801000866")

var Lit_549 *jrt.String = jrt.Intern("arbace.cpp.codegen$thunk_BANG_$num__1801001270")

var Lit_550 *jrt.String = jrt.Intern("arbace.cpp.codegen$thunk_BANG_$coff__1801001272")

var Lit_551 *jrt.String = jrt.Intern("_ZTc")

var Lit_552 *jrt.String = jrt.Intern("_ZTv")

var Lit_553 *jrt.String = jrt.Intern("_")

var Lit_554 *jrt.String = jrt.Intern("_ZTh")

var Lit_555 *jrt.String = jrt.Intern("arbace.cpp.codegen$thunk_BANG_$fn__1801001277")

var Lit_556 *jrt.String = jrt.Intern("arbace.cpp.codegen$thunk_BANG_$fn__1801001280")

var Lit_557 *jrt.String = jrt.Intern("arbace.cpp.codegen$thunk_BANG_$fn__1801001285")

var Lit_558 *jrt.String = jrt.Intern("v")

var Lit_559 *jrt.String = jrt.Intern("h")

var Lit_560 *jrt.String = jrt.Intern("n")

var Lit_561 *jrt.String = jrt.Intern("arbace.cpp.codegen$tls_defined_here_QMARK_$iter__1801000254__1801000258")

var Lit_562 *jrt.String = jrt.Intern("arbace.cpp.codegen$tls_defined_here_QMARK_$iter__1801000254__1801000258$fn__1801000259")

var Lit_563 *jrt.String = jrt.Intern("arbace.cpp.codegen$tls_defined_here_QMARK_$iter__1801000254__1801000258$fn__1801000259$fn__1801000260")

var Lit_564 *jrt.String = jrt.Intern("arbace.cpp.codegen$tls_internal_QMARK_$fn__1801000251")

var Lit_565 *jrt.String = jrt.Intern("arbace.cpp.codegen$tls_via_wrapper_QMARK_$fn__1801000273")

var Lit_566 *jrt.String = jrt.Intern("dynamic")

var Lit_567 *jrt.String = jrt.Intern("_ZTW")

var Lit_568 *jrt.String = jrt.Intern("_Z")

var Lit_569 *jrt.String = jrt.Intern("%t")

var Lit_570 *jrt.String = jrt.Intern("arbace.cpp.codegen$trivial_dtor_body_QMARK_$fn__1801001097")

var Lit_571 *jrt.String = jrt.Intern("arbace.cpp.codegen$trivial_dtor_body_QMARK_$fn__1801001097$fn__1801001098")

var Lit_572 *jrt.String = jrt.Intern("_ZTVN10__cxxabiv117__class_type_infoE")

var Lit_573 *jrt.String = jrt.Intern("_ZTVN10__cxxabiv120__si_class_type_infoE")

var Lit_574 *jrt.String = jrt.Intern("_ZTVN10__cxxabiv121__vmi_class_type_infoE")

var Lit_575 *jrt.String = jrt.Intern("arbace.cpp.codegen$typeinfo_BANG_$walk__1801001243")

var Lit_576 *jrt.String = jrt.Intern("arbace.cpp.codegen$typeinfo_BANG_$fn__1801001248")

var Lit_577 *jrt.String = jrt.Intern("arbace.cpp.codegen$typeinfo_BANG_$fn__1801001257")

var Lit_578 *jrt.String = jrt.Intern("arbace.cpp.codegen$typeinfo_BANG_$fn__1801001265")

var Lit_579 *jrt.String = jrt.Intern("arbace.cpp.codegen$typeinfo_BANG_$fn__1801001267")

var Lit_580 *jrt.String = jrt.Intern("arbace.cpp.codegen$typeinfo_BANG_$walk__1801001243$fn__1801001244")

var Lit_581 *jrt.String = jrt.Intern("va_arg of an empty class")

var Lit_582 *jrt.String = jrt.Intern("va_arg of a non-trivial class")

var Lit_583 *jrt.String = jrt.Intern("va_arg of an over-aligned class")

var Lit_584 *jrt.String = jrt.Intern("arbace.cpp.codegen$va_arg_class_BANG_$mem_BANG___1801000333")

var Lit_585 *jrt.String = jrt.Intern("arbace.cpp.codegen$va_arg_class_BANG_$fn__1801000335")

var Lit_586 *jrt.String = jrt.Intern("__va_list_tag")

var Lit_587 *jrt.String = jrt.Intern("arbace.cpp.codegen$var_addr$fn__1801000280")

var Lit_588 *jrt.String = jrt.Intern("arbace.cpp.codegen$var_addr$fn__1801000282")

var Lit_589 *jrt.String = jrt.Intern("no address for ")

var Lit_590 *jrt.String = jrt.Intern("no vbase offset")

var Lit_591 *jrt.String = jrt.Intern("arbace.cpp.codegen$vcall_offset_offset$fn__1801000937")

var Lit_592 *jrt.String = jrt.Intern("no vcall offset")

var Lit_593 *jrt.String = jrt.Intern("arbace.cpp.codegen$vptr_list$walk__1801001074")

var Lit_594 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$fn__1801000953")

var Lit_595 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$table_BANG___1801000955")

var Lit_596 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$secondary_BANG___1801001003")

var Lit_597 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$vbase_tables_BANG___1801001015")

var Lit_598 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$table_BANG___1801000955$fn__1801000958")

var Lit_599 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$table_BANG___1801000955$fn__1801000960")

var Lit_600 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$table_BANG___1801000955$iter__1801000962__1801000966")

var Lit_601 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$table_BANG___1801000955$iter__1801000962__1801000966$fn__1801000967")

var Lit_602 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$table_BANG___1801000955$iter__1801000962__1801000966$fn__1801000967$fn__1801000968")

var Lit_603 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$table_BANG___1801000955$iter__1801000962__1801000966$fn__1801000967$overridden__1801000986")

var Lit_604 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$table_BANG___1801000955$iter__1801000962__1801000966$fn__1801000967$fn__1801000968$overridden__1801000972")

var Lit_605 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$table_BANG___1801000955$iter__1801000962__1801000966$fn__1801000967$fn__1801000968$overridden__1801000972$fn__1801000973")

var Lit_606 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$table_BANG___1801000955$iter__1801000962__1801000966$fn__1801000967$fn__1801000968$overridden__1801000972$fn__1801000975")

var Lit_607 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$table_BANG___1801000955$iter__1801000962__1801000966$fn__1801000967$overridden__1801000986$fn__1801000987")

var Lit_608 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group$table_BANG___1801000955$iter__1801000962__1801000966$fn__1801000967$overridden__1801000986$fn__1801000989")

var Lit_609 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtable_index$fn__1801000202")

var Lit_610 *jrt.String = jrt.Intern("no vtable slot")

var Lit_611 *jrt.String = jrt.Intern("_ZTV")

var Lit_612 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtt_BANG_$iter__1801001312__1801001316")

var Lit_613 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtt_BANG_$iter__1801001312__1801001316$fn__1801001317")

var Lit_614 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtt_BANG_$iter__1801001312__1801001316$fn__1801001317$fn__1801001318")

var Lit_615 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtt_layout$add_BANG___1801001031")

var Lit_616 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtt_layout$layout_vtt__1801001033")

var Lit_617 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtt_layout$secondary_vtts__1801001035")

var Lit_618 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtt_layout$sec_vptrs__1801001047")

var Lit_619 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtt_layout$virtual_vtts__1801001065")

var Lit_620 *jrt.String = jrt.Intern("_ZTT")

var Lit_621 *jrt.String = jrt.Intern("arbace.cpp.codegen$want_BANG_$fn__1801000021")

var Lit_622 *jrt.String = jrt.Intern("arbace.cpp.codegen$want_BANG_$fn__1801000023")

var Lit_623 *jrt.String = jrt.Intern("arbace.cpp.codegen$want_d0_BANG_$fn__1801001103")

var Lit_624 *jrt.String = jrt.Intern("arbace.cpp.codegen$wide_global$fn__1801000038")

var Lit_625 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops$fn__1801001750")

var Lit_626 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops$fn__1801001756")

var Lit_627 *jrt.String = jrt.Intern("count\tclass\tmessage\texamples\n")

var Lit_628 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops$iter__1801001764__1801001768")

var Lit_629 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops$iter__1801001764__1801001768$fn__1801001769")

var Lit_630 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops$iter__1801001764__1801001768$fn__1801001769$fn__1801001770")

var Lit_631 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops$iter__1801001764__1801001768$fn__1801001769$iter__1801001802__1801001806")

var Lit_632 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops$iter__1801001764__1801001768$fn__1801001769$fn__1801001818")

var Lit_633 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops$iter__1801001764__1801001768$fn__1801001769$fn__1801001770$iter__1801001777__1801001781")

var Lit_634 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops$iter__1801001764__1801001768$fn__1801001769$fn__1801001770$fn__1801001793")

var Lit_635 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops$iter__1801001764__1801001768$fn__1801001769$fn__1801001770$iter__1801001777__1801001781$fn__1801001782")

var Lit_636 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops$iter__1801001764__1801001768$fn__1801001769$fn__1801001770$iter__1801001777__1801001781$fn__1801001782$fn__1801001783")

var Lit_637 *jrt.String = jrt.Intern(":")

var Lit_638 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops$iter__1801001764__1801001768$fn__1801001769$iter__1801001802__1801001806$fn__1801001807")

var Lit_639 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops$iter__1801001764__1801001768$fn__1801001769$iter__1801001802__1801001806$fn__1801001807$fn__1801001808")

var Lit_640 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn4,linekn6,columnkn4,filekn7,dynamickn8,arglistskn3,tagyn6,Stringkn7,privateyn1,fyn1,vyn1,xyn1,kyn4,skeyyn2,nmyn3,retyn2,psyn1,&kn4,keysyn2,vayn8,nounwindyn6,pattrskn8,declaredyn2,usyn4,longyn1,eyn1,lyn4,instyn4,formyn1,cyn1,tyn5,alignyn2,tyyn2,apyn2,bfyn5,shiftyn1,wyn4,addryn4,baseyn3,cidyn1,iyn3,dstyn3,srcyn3,fidyn16,java.lang.Stringyn5,ret-tyn4,ps-tyn5,this?yn4,vtt?yn5,partsyn2,vsyn4,bodyyn5,stateyn2,csyn2,esyn2,ssv11,arbace.core5,in-nsMyn18,arbace.cpp.codegenm2,R0,s1142,The code generator (doc/cpp/CODEGEN.md §4): arbace.cpp.sema's typed program written as LLVM forms (doc/cpp/LLVM.md)\n  as clang's CodeGen writes its IR at -O0 -- every local in an alloca of the entry block, loads and stores, the\n  objects' members at the Itanium layout's byte offsets, constructors (C2, C1 an alias of a strong one) and destructors\n  (D2, D0 the deleting one, D1 an alias), vtables and type_info objects, virtual calls through the vptr, new and\n  delete (an array cookie when the element has a destructor), the destructors of locals at their scope's exits and of\n  temporaries at their full-expression's end (a flag for a temporary made in a conditional branch), copy elision of\n  prvalues and the named return value, static locals behind their guard, namespace-scope variables' dynamic\n  initialization in a global constructor with their destructors registered by __cxa_atexit. The forms are lowered by\n  arbace.cpp.lower and run as cppi runs clang's (bin/cppi codegen, codegen-check). Calling convention: scalars as\n  clang passes them; a class argument or result by address (CODEGEN.md's P3: SysV's register classes later).m2,R0,s1142,The code generator (doc/cpp/CODEGEN.md §4): arbace.cpp.sema's typed program written as LLVM forms (doc/cpp/LLVM.md)\n  as clang's CodeGen writes its IR at -O0 -- every local in an alloca of the entry block, loads and stores, the\n  objects' members at the Itanium layout's byte offsets, constructors (C2, C1 an alias of a strong one) and destructors\n  (D2, D0 the deleting one, D1 an alias), vtables and type_info objects, virtual calls through the vptr, new and\n  delete (an array cookie when the element has a destructor), the destructors of locals at their scope's exits and of\n  temporaries at their full-expression's end (a flag for a temporary made in a conditional branch), copy elision of\n  prvalues and the named return value, static locals behind their guard, namespace-scope variables' dynamic\n  initialization in a global constructor with their destructors registered by __cxa_atexit. The forms are lowered by\n  arbace.cpp.lower and run as cppi runs clang's (bin/cppi codegen, codegen-check). Calling convention: scalars as\n  clang passes them; a class argument or result by address (CODEGEN.md's P3: SysV's register classes later).R1,v11,arbace.core20,*warn-on-reflection*v18,arbace.cpp.codegen4,failv14,arbace.cpp.abi4,failm6,R2,i24,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen5,*top*m8,R5,TR2,i29,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen4,gsymm8,R6,L1,V1,Myn1,sm2,R7,R8,R2,i31,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,add-top!m10,R9,TR6,L1,V1,R10,R2,i36,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,conj-newm10,R9,TR6,L1,V2,R11,R12,R2,i42,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen5,want!m12,R9,TR6,L1,V3,R13,R14,R12,R0,s115,Refers to the vtable group or VTT `x` (`k` :groups or :vtts; `skey` its slot's key): wanted, and its slot reserved.R2,i44,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,place!m12,R9,TR6,L1,V2,R14,R10,R0,s72,The form `f` of the global whose slot is `skey`: in its slot, else last.R2,i53,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,*eager-want*m8,R5,TR2,i58,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,reserve!m12,R9,TR6,L1,V1,R15,R0,s221,P23 (a): the function `nm`'s place among the module's forms taken now, at its first reference, as an llvm::Function\n  takes its place in the module's list when created (GetOrCreateLLVMFunction) and is defined there later.R2,i60,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,declare!m10,R9,TR6,L1,V5,Myn2,nmm2,R7,R8,R16,R17,R18,m2,R19,V3,R20,R21,R22,R2,i68,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,string-globalm8,R23,TR2,i75,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,wide-globalm10,R9,TR6,L1,V2,R24,Myn1,wm2,R7,R25,R2,i77,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,str-globalm12,R9,TR6,L1,V1,R26,R0,s31,A string literal node's global.R2,i90,R3,i1,R4,s21,arbace/cpp/codegen.aem10,R9,TR6,L1,V1,Myn1,sm2,R7,R8,R2,i95,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen3,*f*m8,R5,TR2,i107,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen3,tmpm10,R9,TR6,L1,V0,R2,i109,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,new-labelm10,R9,TR6,L1,V1,Myn4,hintm2,R7,R8,R2,i110,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,close-block!m10,R9,TR6,L1,V0,R2,i112,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,start!m10,R9,TR6,L1,V1,R27,R2,i116,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen5,emit!m10,R9,TR6,L1,V1,R28,R2,i118,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen4,val!m10,R9,TR6,L1,V1,R29,R2,i126,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,begin!m12,R9,TR6,L1,V1,R27,R0,s87,Ends the current block (with a branch to `l` unless it ended) and starts the block `l`.R2,i128,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen3,br!m10,R9,TR6,L1,V1,R27,R2,i134,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,condbr!m10,R9,TR6,L1,V3,R30,R31,R26,R2,i135,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,alloca!m10,R9,TR6,L1,V2,R31,R32,R2,i137,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,va-tagv11,arbace.core6,symbolm10,R9,TR2,i142,R3,i1,R4,s21,arbace/cpp/codegen.aeR0,s110,x86-64's va_list element as clang names it, %struct.__va_list_tag = type { i32, i32, ptr, ptr } (cpp-gatefix).v18,arbace.cpp.codegen13,va-list-type?m12,R9,TR6,L1,V1,R33,R0,s115,Whether the type `ty` is x86-64's va_list, sema's struct __va_list_tag[1] (sema's va-list-tag: a class of no path).R2,i146,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,va-tag!m12,R9,TR6,L1,V0,R0,s188,%struct.__va_list_tag, its definition among the module's types once (cpp-gatefix: the lowering knows a va_list by\n  this type, arbace.cpp.lower's va-field and :va-lists, as in clang's IR).R2,i153,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,va-field!m12,R9,TR6,L1,V2,R34,Myn1,km2,R7,R25,R0,s447,The address of field `k` of the va_list element at `ap` (gp_offset 0, fp_offset 1, overflow_arg_area 2, reg_save_area\n  3), as clang's X86_64ABIInfo::EmitVAArg writes it: a getelementptr over %struct.__va_list_tag, which the lowering reads\n  as the field (arbace.cpp.lower's va-field; on ci its va_list is one pointer, not this struct: cpp-gatefix, runtime/deferred.cpp's\n  vsum read gp_offset and reg_save_area as plain bytes and faulted at 0x0).R2,i160,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen5,slot!m10,R9,TR6,L1,V1,R33,R2,i168,R3,i1,R4,s21,arbace/cpp/codegen.aem8,R23,TR2,i178,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,bf-load!m12,R9,TR6,L1,V1,m2,R19,V4,R35,R36,R37,R33,R0,s158,A bit-field's value from its storage unit (a marker {:bf addr :shift :w :ty}): the unit loaded, the field's bits\n  extracted, sign-extended for a signed type.R2,i180,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,bf-store!m10,R9,TR6,L1,V2,m2,R19,V4,R35,R36,R37,R33,R11,R2,i193,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen5,load!m10,R9,TR6,L1,V2,R33,R38,R2,i205,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,store!m10,R9,TR6,L1,V3,R33,R11,R38,R2,i211,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,offset!m8,R23,TR2,i217,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,field-placem10,R6,L1,V3,R39,R40,R41,R0,s100,The place of field `i` of class `cid` in the object at `base`: its address, or a bit-field's marker.R2,i219,R3,i1,R4,s21,arbace/cpp/codegen.aem10,R9,TR6,L1,V2,R38,Myn3,offm2,R7,R25,R2,i229,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,memcpy!m10,R9,TR6,L1,V3,R42,R43,Myn1,nm2,R7,R25,R2,i232,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,empty-rec?m12,R9,TR6,L1,V1,R31,R0,s275,Whether `t` is an empty class, whose zero-initialization and copies clang leaves out (CodeGenFunction's\n  EmitNullInitialization and EmitAggregateCopy: \"Ignore empty classes in C++\"): its one byte may be another member's\n  ([[no_unique_address]], an empty base; cpp-gatefix).R2,i236,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,memset!m10,R9,TR6,L1,V2,R42,Myn1,nm2,R7,R25,R2,i243,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,elem-typem10,R9,TR6,L1,V1,R31,R2,i247,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,zero-ofm10,R9,TR6,L1,V1,R31,R2,i249,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,zero-memm12,R9,TR6,L1,V1,R31,R0,s50,A scalar's zero as memory holds it (bool an i8 0).R2,i251,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,vb-class?m8,R6,L1,V1,R40,R2,i256,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,fn-variantm12,R9,TR6,L1,V2,R10,R11,R0,s155,A constructor's or destructor's variant: 1 (complete object) or 2 (base object) for a class with virtual bases, else\n  2 (the complete one an alias of it).R2,i258,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,fn-namem10,R9,TR6,L1,MV3,R44,R18,V1,R11,m2,R7,R45,R2,i264,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,takes-vtt?m12,R9,TR6,L1,V2,R10,R11,R0,s90,The base-object constructor or destructor of a class with virtual bases: a VTT after this.R2,i266,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,part-ltypem10,R9,TR6,L1,V1,V2,R30,Myn1,bm2,R7,R25,R2,i275,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,class-passm12,R9,TR6,L1,V1,R31,R0,s86,How a class type passes by value: :ignore, :ind (by address) or the eightbytes' parts.R2,i278,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,byval-class?m10,R9,TR6,L1,V1,R31,R2,i286,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,sig-planm10,R6,L1,V5,R46,R47,R48,R18,V1,R49,R0,s209,{:ret llvm-type :ret-k :sret|:regs|:ignore|:direct :ret-parts :ps [llvm-types] :params [{:k :direct|:regs|:ind|:ignore\n  :parts}]} of a function type (`this?`: a method's object first; `vtt?`: a VTT after it).R2,i288,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,class-ret?m10,R9,TR6,L1,V1,R10,R2,i323,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,param-ltypem10,R9,TR6,L1,V1,R31,R2,i325,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,fn-sigm12,R9,TR6,L1,V3,R10,R18,V1,R11,R0,s146,[ret-type param-types variadic plan] of a function (its variant `v`) as this code generator calls it: sret first,\n  this, the VTT, the parameters.R2,i327,R3,i1,R4,s21,arbace/cpp/codegen.aem8,R23,TR2,i334,R3,i1,R4,s21,arbace/cpp/codegen.aem8,R23,TR2,i334,R3,i1,R4,s21,arbace/cpp/codegen.aem8,R23,TR2,i334,R3,i1,R4,s21,arbace/cpp/codegen.aem8,R23,TR2,i334,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,coerce-out!m12,R9,TR6,L1,V3,R38,R50,Myn4,sizem2,R7,R25,R0,s76,The eightbytes of the object at `addr` (`size` bytes) as [[type value] ...].R2,i336,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,coerce-in!m12,R9,TR6,L1,V4,R51,R50,R38,Myn4,sizem2,R7,R25,R0,s76,Stores the eightbytes' values `vs` into the object at `addr` (`size` bytes).R2,i346,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,nothrow-fn?m8,R23,TR2,i355,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,extern-inst?m12,R9,TR6,L1,V1,R10,R0,s605,Whether the function is a member of a class (or of a class nested in one) an explicit instantiation declaration\n  names (extern template class basic_ostream<char>): the library defines it. Not a member template's specialization:\n  the explicit instantiation names the class's members that are no templates ([temp.explicit]/11), so the specialization\n  is implicitly instantiated where used, as clang emits it, linkonce_odr (CP377 (a): libstdc++ 15's `__resize_and_overwrite`'s\n  `resize_and_overwrite<_Operation&>` of basic_string<char>, hello.cpp's std::to_string, had been declared and never\n  defined).R2,i357,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,want-fn!m12,R9,TR6,L1,V3,R44,R18,V1,R11,R0,s122,The function's symbol (a constructor's or destructor's variant `v`), its definition queued (or its declaration\n  written).R2,i372,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,*temps*m8,R5,TR2,i391,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,*cond*l0,m8,R5,TR2,i392,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,*extend*m8,R5,TR2,i393,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,*extend-now*m8,R5,TR2,i394,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,*extend-root*m8,R5,TR2,i396,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,*this-val*m8,R5,TR2,i397,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,*opaque*m8,R5,TR2,i398,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,*decl-e*m8,R5,TR2,i399,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,extend-rootm12,R9,TR6,L1,V1,R26,R0,s186,The expression whose temporary a reference bound to the glvalue `e` extends: `e` itself, or the object whose\n  subobject (a member, a base, an element of an array member) `e` designates.R2,i401,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,emit-rvm8,R23,TR2,i415,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,emit-lvm8,R23,TR2,i415,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,emit-intom8,R23,TR2,i415,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,emit-initm8,R23,TR2,i415,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,call-dtor!m8,R23,TR2,i415,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,eh-typeinfo!m8,R23,TR2,i415,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,dealloc-call!m8,R23,TR2,i415,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen16,nontrivial-dtor?m10,R9,TR6,L1,V1,R40,R2,i417,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,call-insn!m8,R23,TR2,i419,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,run-cleanup!m10,R9,TR6,L1,V1,R30,R2,i421,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen18,push-temp-cleanup!m10,R9,TR6,L1,V2,R40,R38,R2,i440,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,with-fullm12,R9,TR6,L1,V2,R18,R52,R0,s74,Emits a full-expression: its temporaries destroyed at its end, in reverse.R2,i451,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,*no-eh*m8,R5,TR2,i468,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,*as-base*m8,R5,TR2,i469,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,eh-statem10,R9,TR6,L1,V0,R2,i471,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,pad-planm12,R9,TR6,L1,V1,R53,R0,s114,[clauses cleanup?] of a landing pad for the cleanup stack `state` (clauses: type_info symbols, nil for catch-all).R2,i473,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,eh-slots!m10,R9,TR6,L1,V0,R2,i487,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen15,run-cleanup-eh!m10,R9,TR6,L1,V1,R30,R2,i490,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen21,clang-call-terminate!m10,R9,TR6,L1,V0,R2,i501,R3,i1,R4,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,eh-walk!m12,R9,TR6,L1,V3,R54,R55,R56,R0,s71,The landing pad's code from the cleanup entries `cs` (innermost first).R2,i516,R3,i1,R4,s21,arbace/cpp/codegen.ae")

var Lit_641 *jrt.String = jrt.Intern("arbace.cpp.codegen$eval1801000004$loading__1927001464__auto____1801000005")

var Lit_642 *jrt.String = jrt.Intern("arbace.cpp.codegen$eval1801000008$fn__1801000009")

var Lit_643 *jrt.String = jrt.Intern("arbace.cpp.codegen$gsym")

var Lit_644 *jrt.String = jrt.Intern("arbace.cpp.codegen$add_top_BANG_")

var Lit_645 *jrt.String = jrt.Intern("arbace.cpp.codegen$conj_new")

var Lit_646 *jrt.String = jrt.Intern("arbace.cpp.codegen$want_BANG_")

var Lit_647 *jrt.String = jrt.Intern("arbace.cpp.codegen$place_BANG_")

var Lit_648 *jrt.String = jrt.Intern("arbace.cpp.codegen$reserve_BANG_")

var Lit_649 *jrt.String = jrt.Intern("arbace.cpp.codegen$declare_BANG_")

var Lit_650 *jrt.String = jrt.Intern("arbace.cpp.codegen$wide_global")

var Lit_651 *jrt.String = jrt.Intern("arbace.cpp.codegen$str_global")

var Lit_652 *jrt.String = jrt.Intern("arbace.cpp.codegen$string_global")

var Lit_653 *jrt.String = jrt.Intern("arbace.cpp.codegen$tmp")

var Lit_654 *jrt.String = jrt.Intern("arbace.cpp.codegen$new_label")

var Lit_655 *jrt.String = jrt.Intern("arbace.cpp.codegen$close_block_BANG_")

var Lit_656 *jrt.String = jrt.Intern("arbace.cpp.codegen$start_BANG_")

var Lit_657 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_BANG_")

var Lit_658 *jrt.String = jrt.Intern("arbace.cpp.codegen$val_BANG_")

var Lit_659 *jrt.String = jrt.Intern("arbace.cpp.codegen$begin_BANG_")

var Lit_660 *jrt.String = jrt.Intern("arbace.cpp.codegen$br_BANG_")

var Lit_661 *jrt.String = jrt.Intern("arbace.cpp.codegen$condbr_BANG_")

var Lit_662 *jrt.String = jrt.Intern("arbace.cpp.codegen$alloca_BANG_")

var Lit_663 *jrt.String = jrt.Intern("%struct.__va_list_tag")

var Lit_664 *jrt.String = jrt.Intern("arbace.cpp.codegen$va_list_type_QMARK_")

var Lit_665 *jrt.String = jrt.Intern("arbace.cpp.codegen$va_tag_BANG_")

var Lit_666 *jrt.String = jrt.Intern("arbace.cpp.codegen$va_field_BANG_")

var Lit_667 *jrt.String = jrt.Intern("arbace.cpp.codegen$slot_BANG_")

var Lit_668 *jrt.String = jrt.Intern("arbace.cpp.codegen$bf_load_BANG_")

var Lit_669 *jrt.String = jrt.Intern("arbace.cpp.codegen$bf_store_BANG_")

var Lit_670 *jrt.String = jrt.Intern("arbace.cpp.codegen$load_BANG_")

var Lit_671 *jrt.String = jrt.Intern("arbace.cpp.codegen$store_BANG_")

var Lit_672 *jrt.String = jrt.Intern("arbace.cpp.codegen$field_place")

var Lit_673 *jrt.String = jrt.Intern("arbace.cpp.codegen$offset_BANG_")

var Lit_674 *jrt.String = jrt.Intern("arbace.cpp.codegen$memcpy_BANG_")

var Lit_675 *jrt.String = jrt.Intern("arbace.cpp.codegen$empty_rec_QMARK_")

var Lit_676 *jrt.String = jrt.Intern("arbace.cpp.codegen$memset_BANG_")

var Lit_677 *jrt.String = jrt.Intern("arbace.cpp.codegen$elem_type")

var Lit_678 *jrt.String = jrt.Intern("arbace.cpp.codegen$zero_of")

var Lit_679 *jrt.String = jrt.Intern("arbace.cpp.codegen$zero_mem")

var Lit_680 *jrt.String = jrt.Intern("arbace.cpp.codegen$vb_class_QMARK_")

var Lit_681 *jrt.String = jrt.Intern("arbace.cpp.codegen$fn_variant")

var Lit_682 *jrt.String = jrt.Intern("arbace.cpp.codegen$fn_name")

var Lit_683 *jrt.String = jrt.Intern("arbace.cpp.codegen$takes_vtt_QMARK_")

var Lit_684 *jrt.String = jrt.Intern("arbace.cpp.codegen$part_ltype")

var Lit_685 *jrt.String = jrt.Intern("arbace.cpp.codegen$class_pass")

var Lit_686 *jrt.String = jrt.Intern("arbace.cpp.codegen$byval_class_QMARK_")

var Lit_687 *jrt.String = jrt.Intern("arbace.cpp.codegen$sig_plan")

var Lit_688 *jrt.String = jrt.Intern("arbace.cpp.codegen$class_ret_QMARK_")

var Lit_689 *jrt.String = jrt.Intern("arbace.cpp.codegen$param_ltype")

var Lit_690 *jrt.String = jrt.Intern("arbace.cpp.codegen$fn_sig")

var Lit_691 *jrt.String = jrt.Intern("arbace.cpp.codegen$coerce_out_BANG_")

var Lit_692 *jrt.String = jrt.Intern("arbace.cpp.codegen$coerce_in_BANG_")

var Lit_693 *jrt.String = jrt.Intern("arbace.cpp.codegen$extern_inst_QMARK_")

var Lit_694 *jrt.String = jrt.Intern("arbace.cpp.codegen$want_fn_BANG_")

var Lit_695 *jrt.String = jrt.Intern("arbace.cpp.codegen$extend_root")

var Lit_696 *jrt.String = jrt.Intern("arbace.cpp.codegen$nontrivial_dtor_QMARK_")

var Lit_697 *jrt.String = jrt.Intern("arbace.cpp.codegen$run_cleanup_BANG_")

var Lit_698 *jrt.String = jrt.Intern("arbace.cpp.codegen$push_temp_cleanup_BANG_")

var Lit_699 *jrt.String = jrt.Intern("arbace.cpp.codegen$with_full")

var Lit_700 *jrt.String = jrt.Intern("arbace.cpp.codegen$eh_state")

var Lit_701 *jrt.String = jrt.Intern("arbace.cpp.codegen$pad_plan")

var Lit_702 *jrt.String = jrt.Intern("arbace.cpp.codegen$eh_slots_BANG_")

var Lit_703 *jrt.String = jrt.Intern("arbace.cpp.codegen$run_cleanup_eh_BANG_")

var Lit_704 *jrt.String = jrt.Intern("arbace.cpp.codegen$clang_call_terminate_BANG_")

var Lit_705 *jrt.String = jrt.Intern("arbace.cpp.codegen$eh_walk_BANG_")

var Lit_706 *jrt.String = jrt.Intern("kn7,privatekn8,arglistsyn5,statekn3,dockn4,linekn6,columnkn4,fileyn3,retyn2,tyyn6,calleeyn4,argsyn8,nounwindyn1,fyn3,cidyn3,fidyn7,variantyn4,f-psyn5,initsyn3,objyn4,planyn2,vayn2,ftyn4,destyn1,&yn3,vttyn7,virtualyn4,addryn1,ekn7,dynamickn3,tagyn6,Stringyn1,vyn4,ref?yn1,tyn2,idyn4,fromyn2,tokn8,declaredyn1,oyn6,signedyn1,ayn1,byn4,longyn20,java.math.BigDecimalyn1,xyn16,java.lang.Stringyn6,doubleyn3,lityn1,pyn2,psyn4,sizeyn1,dyn5,alignyn6,placeskn9,monotonickn7,acquirekn7,releasekn7,acq_relkn7,seq_cstyn5,load?yn6,store?yn2,ocyn2,oeyn8,booleansyn9,complete?yn4,inityn1,cyn1,syn3,vidyn9,in-switchyn1,gyn1,myn3,lidyn4,subsyn3,clsyn3,offyn3,gidyn4,baseyn4,virtyn2,vbv18,arbace.cpp.codegen12,landing-pad!m12,R0,TR1,L1,V1,R2,R3,s143,The label of the landing pad for the cleanup stack `state` (written out of line once per state), or nil when no\n  handler or cleanup is active.R4,i564,R5,i1,R6,s21,arbace/cpp/codegen.aem10,R1,L1,V5,R7,R8,R9,R10,R11,R3,s198,A call (`ty` the call's type: the return type or a fn type for a variadic callee) that is an invoke when it may\n  unwind inside a cleanup's or a handler's scope; its result's operand (nil for void).R4,i588,R5,i1,R6,s21,arbace/cpp/codegen.aem10,R0,TR1,L1,V1,R12,R4,i601,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,vtable-indexm10,R0,TR1,L1,V3,R13,R14,R15,R4,i606,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,arg-valuesm12,R0,TR1,L1,V2,R16,R17,R3,s55,The LLVM operands of a call's parameters' initializers.R4,i611,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,vcall-targetm10,R0,TR1,L1,V4,R13,R14,R15,R18,R4,i639,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,emit-call!m12,R0,TR1,L1,V10,R19,R9,R20,R21,R17,R18,R22,R11,R23,V1,R24,R3,s162,A call by the plan (sig-plan) of the function type `ft`: the parameters' initializers' operands coerced, the object\n  `obj`, the result's (a class's into `dest`).R4,i644,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen5,call!m12,R0,TR1,L1,V5,R14,R18,R17,R22,R25,R3,s188,Calls the function `fid` (the object's address `obj` for a method, `dest` for a class result) with the parameters'\n  initializers; the result's operand (an address for a reference result).R4,i680,R5,i1,R6,s21,arbace/cpp/codegen.aem10,R1,L1,V4,R13,R26,R23,V1,R24,R3,s183,Calls the class's complete destructor on the object at `addr` (nothing for a trivial one); with `vtt`, a base\n  subobject's (the base-object destructor of a class with virtual bases).R4,i708,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,mcall!m12,R0,TR1,L1,V2,R27,R22,R3,s177,A call through a pointer to member function (Itanium §2.3): this adjusted, then the function the pointer names, or\n  for an odd pointer the vtable's slot at its offset less one.R4,i716,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,icall!m10,R0,TR1,L1,V2,R27,R22,R4,i740,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,*in-tls-init*m10,R28,TR0,TR4,i748,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen16,tls-wrapper-namem12,R0,TR1,L1,V1,Myn2,nmm2,R29,R30,R3,s105,The thread-local wrapper's name of the variable whose symbol is `nm` (Itanium 5.1.4.1: TW <object name>).R4,i750,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,tls-internal?m12,R0,TR1,L1,V1,R31,R3,s521,review 1111 #1: whether the thread-local variable `v` has internal linkage ([basic.link]/4: `static` at namespace scope or\n  a member of an unnamed namespace), its _ZTH and _ZTW internal too. A static data member by its class's linkage alone\n  (pending review 1111 #5, cpp-s5b): internal when an unnamed namespace encloses its class, [basic.link]/4; sema's\n  :internal also holds for every member a class declares `static` (thread_local11.h's T::u3, whose global is emitted\n  internal: CP369), so it is not read for them.R4,i755,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen17,tls-defined-here?m12,R0,TR1,L1,V1,Myn2,nmm2,R29,R30,R3,s323,cpp-s5b (pending review 1111 #4): whether this unit defines the thread-local variable whose symbol is `nm`: a\n  definition after an `extern` declaration of it is a variable of its own in sema (`extern thread_local int t;` then\n  `thread_local int t = f();`), a static data member's out-of-line definition the member itself.R4,i766,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen22,tls-wrapped-elsewhere?m12,R0,TR1,L1,V2,R31,Myn2,nmm2,R29,R30,R3,s471,cpp-s5b (pending review 1111 #4): whether a use of the thread-local variable `v` (symbol `nm`) defined in another unit\n  goes through its wrapper, as clang's ItaniumCXXABI::usesThreadWrapperFunction decides: only C++'s dynamic TLS\n  (thread_local; __thread and _Thread_local are static TLS, read directly), not constinit (constant-initialized by\n  declaration, isEmittedWithConstantInitializer), for an extern variable or a static data member this unit does not\n  define.R4,i780,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen16,tls-via-wrapper?m12,R0,TR1,L1,V2,R31,Myn2,nmm2,R29,R30,R3,s208,Whether a use of the variable `v` (symbol `nm`) outside __tls_init goes through its thread-local wrapper _ZTW: one this\n  unit initializes dynamically, or one defined in another unit (tls-wrapped-elsewhere?).R4,i791,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen15,tls-wrapper-retm12,R0,TR1,L1,V2,R32,R33,R3,s375,CP371 (a): the instructions that return a thread-local wrapper's value from the variable's address `%t`: the address, or\n  for a reference the referent's, loaded (clang's ItaniumCXXABI::EmitThreadLocalInitFuncs: `if\n  (VD->getType()->isReferenceType()) Val = CreateAlignedLoad(...)`; its users take the call's value as the referent's address,\n  EmitThreadLocalVarDeclLValue).R4,i799,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen19,extern-tls-wrapper!m12,R0,TR1,L1,V2,Myn2,nmm2,R29,R30,R32,R3,s499,review 1111 #1: the wrapper of the thread-local variable `nm` defined in another unit (clang's\n  ItaniumCXXABI::EmitThreadLocalInitFuncs for a variable this unit does not define): _ZTW, linkonce_odr and hidden (the\n  defining unit's weak_odr one wins at link), calling the init function _ZTH, declared extern_weak (absent when the defining\n  unit needs no dynamic initialization of its thread-local variables), when it is there, then returning the variable's\n  address in this thread. Once per unit.R4,i809,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,var-addrm10,R0,TR1,L1,V1,R34,R4,i833,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,base-offsetm10,R0,TR1,L1,V2,R35,R36,R4,i866,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,vbase-addr!m8,R37,TR4,i868,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,base-addr!m12,R0,TR1,L1,V3,R26,R35,R36,R3,s117,The address of the base `to` of the object of class `from` at `addr` (a virtual base's by the vtable's vbase offset).R4,i870,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,int-opm10,R0,TR1,L1,V2,R38,R39,R4,i876,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen5,fp-opm10,R0,TR1,L1,V1,R38,R4,i879,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,arith!m10,R0,TR1,L1,V4,R38,R33,R40,R41,R4,i881,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen4,cmp!m10,R0,TR1,L1,V4,R38,R33,R40,R41,R4,i888,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen4,pow2m10,R0,TR1,L1,MV1,Myn1,em2,R29,R42,m2,R29,R43,R4,i895,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,fp80-hexm10,R1,L1,MV1,R44,m2,R29,R45,R3,s210,The x86 80-bit extended value nearest the decimal `s` (or the BigDecimal), as LLVM 23 writes it: f0x, then the sign\n  and the biased exponent (4 hex digits) and the 64-bit significand with its integer bit (16).R4,i900,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,fp-constm10,R0,TR1,L1,V4,R33,Myn1,vm2,R29,R46,R23,V1,R47,R4,i916,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,int-cast!m10,R0,TR1,L1,V3,R35,R36,R31,R4,i924,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,ptr-adjust!m12,R0,TR1,L1,V2,R31,Myn3,offm2,R29,R42,R3,s61,A pointer `v` moved by `off` bytes, a null pointer kept null.R4,i933,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,null-guarded!m12,R0,TR1,L1,V2,R48,R12,R3,s61,The value of (f) when the pointer `p` is not null, else null.R4,i946,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,dyncast-call!m10,R0,TR1,L1,V2,R27,R48,R4,i957,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen5,cast!m10,R0,TR1,L1,V1,R27,R4,i961,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,materialize!m12,R0,TR1,L1,V1,R27,R3,s82,A class prvalue's temporary: its address (destroyed at the full-expression's end).R4,i994,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,folds-tom8,R37,TR4,i1002,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen23,short-circuit-branches!m8,R37,TR4,i1002,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen15,cond-branches2!m8,R37,TR4,i1002,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen14,short-circuit!m10,R0,TR1,L1,V1,R27,R4,i1004,R5,i1,R6,s21,arbace/cpp/codegen.aem10,R0,TR1,L1,V1,R27,R4,i1012,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen14,cond-branches!m12,R0,TR1,L1,V3,R27,R12,R33,R3,s220,A conditional operator: the operands' values from each branch (by `f`), joined by a phi of type `t` (nil: no value);\n  a condition that folds: the live operand alone (ScalarExprEmitter::VisitAbstractConditionalOperator).R4,i1023,R5,i1,R6,s21,arbace/cpp/codegen.aem10,R0,TR1,L1,V3,R27,R12,R33,R4,i1031,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,va-arg-class!m12,R0,TR1,L1,V1,R27,R3,s423,The address of va_arg(ap, T)'s argument for a class T (clang's X86_64ABIInfo::EmitVAArg, the psABI's §3.5.7): a class\n  passed in registers read from the register save area (its eightbytes copied into a temporary unless they are one\n  register class's consecutive slots) when gp_offset and fp_offset leave room for all of them, else, as a MEMORY class,\n  from the overflow area, which advances by its size rounded to eight.R4,i1042,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,emit-stmtm8,R37,TR4,i1097,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,unwind-to!m8,R37,TR4,i1097,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,cleanup-depthm8,R37,TR4,i1097,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,stmt-expr!m12,R0,TR1,L1,V1,R27,R3,s238,GNU's statement expression (sema's :stmt-expr): its statements in a scope of their own, the last expression's value kept in\n  a temporary while the scope's cleanups run (clang's CodeGenFunction::EmitCompoundStmtWithoutScope's last value).R4,i1099,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,bind-opaque!m12,R0,TR1,L1,V2,R27,R12,R3,s182,GNU's `x ?: y` (sema's :bind-opaque): x emitted once, a glvalue as its address and a scalar as its value (clang's\n  OpaqueValueMapping), then the conditional operator over it by `f`.R4,i1111,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,opaque-ofm10,R0,TR1,L1,V1,R27,R4,i1118,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,incdec!m10,R0,TR1,L1,V1,R27,R4,i1120,R5,i1,R6,s21,arbace/cpp/codegen.aem8,R37,TR4,i1130,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,place-valuesm12,R0,TR1,L1,V2,R49,R17,R3,s142,The placement arguments' operands for the parameters `ps` (scalars, pointers and references: an allocation\n  function's placement parameters).R4,i1132,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,alloc-call!m12,R0,TR1,L1,V2,R40,R50,R3,s187,The call of the allocation function `a` (arbace.cpp.sema's choice) for `size` bytes: its result's operand and the\n  placement arguments' operands (for the matching deallocation function).R4,i1139,R5,i1,R6,s21,arbace/cpp/codegen.aem12,R0,TR1,L1,V5,R51,R48,R50,R52,R53,R3,s155,The call of the deallocation function `d` on `p` (`size` and `align` operands when it takes them, the placement\n  arguments' operands for a placement one).R4,i1153,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,cabi-ordersm12,l0,R54,l1,R55,l2,R55,l3,R56,l4,R57,l5,R58,m8,R0,TR4,i1171,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,atomic-ordm12,R0,TR1,L1,V3,R38,R59,R60,R3,s92,The LLVM ordering of the C ABI order `o` for an operation (nil: clang emits nothing for it).R4,i1173,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,by-order!m12,R0,TR1,L1,V5,R61,R62,R59,R60,R12,R3,s116,(f ordering) at the order `oc` (a constant) or the run-time value of `oe`: clang's switch, its blocks joining after.R4,i1184,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen16,cmpxchg-fail-ordm10,R0,TR1,L1,V1,R38,R4,i1201,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,mem-valm12,R0,TR1,L1,V2,R33,R31,R3,s52,A value of type `t` as memory holds it (bool an i8).R4,i1204,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen15,occupied-bytes!m12,R0,TR1,L1,V4,Myn3,occm2,R29,R63,R33,Myn3,offm2,R29,R42,R64,R3,s319,CP338 (a): the bytes of an object of type `t` at offset `off` that hold its value representation marked in `occ`: a\n  scalar's (x87's long double its first 10), an array's elements', a class's vptr, fields and non-virtual bases, its virtual\n  bases' in the complete object (`complete?`). A bit-field or a union refused.R4,i1209,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen19,emit-clear-padding!m12,R0,TR1,L1,V1,R27,R3,s260,CP338 (a): __builtin_clear_padding(p) as clang 23's EmitBuiltinClearPadding writes it at -O0: each byte of *p that holds\n  no part of its value a store of i8 0 through getelementptr i8 (an i32 offset), aligned as that offset is within the\n  object's alignment.R4,i1229,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,emit-fence!m12,R0,TR1,L1,V1,R27,R3,s272,CP338 (a): __atomic_thread_fence and __atomic_signal_fence as clang's EmitBuiltinExpr emits them: nothing for a relaxed\n  order, else a fence at the order (a signal fence's syncscope \"singlethread\"); an order known at run time a switch whose\n  default is the continuation.R4,i1245,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,emit-atomic!m10,R0,TR1,L1,V1,R27,R4,i1263,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,emit-bitop!m10,R0,TR1,L1,V1,R27,R4,i1344,R5,i1,R6,s21,arbace/cpp/codegen.aem10,R1,L1,V1,R27,R3,s38,The operand of the scalar prvalue `e`.R4,i1362,R5,i1,R6,s21,arbace/cpp/codegen.aem10,R1,L1,V1,R27,R3,s62,The address of the glvalue `e` (a class prvalue materialized).R4,i1641,R5,i1,R6,s21,arbace/cpp/codegen.aev11,arbace.core14,alter-var-rootm10,R1,L1,V2,R27,R26,R3,s57,Constructs the class prvalue `e` in the object at `addr`.R4,i1736,R5,i1,R6,s21,arbace/cpp/codegen.aem10,R1,L1,V3,R26,R33,R65,R3,s91,Initializes the object of type `t` at `addr` by the initializer `init` (arbace.cpp.sema's).R4,i1781,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,push-cleanup!m10,R0,TR1,L1,V1,R66,R4,i1827,R5,i1,R6,s21,arbace/cpp/codegen.aem10,R0,TR1,L1,V0,R4,i1828,R5,i1,R6,s21,arbace/cpp/codegen.aem10,R0,TR1,L1,V1,Myn5,depthm2,R29,R42,R4,i1829,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,pop-to!m10,R0,TR1,L1,V1,Myn5,depthm2,R29,R42,R4,i1839,R5,i1,R6,s21,arbace/cpp/codegen.aem8,R37,TR4,i1841,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,emit-d0!m8,R37,TR4,i1841,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,emit-try!m8,R37,TR4,i1841,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen17,emit-if-branches!m8,R37,TR4,i1841,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,local-decl!m10,R0,TR1,L1,V1,R67,R4,i1843,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,const-leavesm8,R37,TR4,i1859,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen15,leaves-constantm8,R37,TR4,i1859,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,static-local!m10,R0,TR1,L1,V1,R68,R4,i1861,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,emit-return!m10,R0,TR1,L1,V1,R67,R4,i1914,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen15,contains-label?m8,R37,TR4,i1928,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,emit-stmt*m8,R37,TR4,i1928,R5,i1,R6,s21,arbace/cpp/codegen.aem8,R1,L1,V1,R67,R4,i1930,R5,i1,R6,s21,arbace/cpp/codegen.aem10,R0,TR1,L1,V1,R67,R4,i1938,R5,i1,R6,s21,arbace/cpp/codegen.aem10,R0,TR1,L1,V1,R67,R4,i2025,R5,i1,R6,s21,arbace/cpp/codegen.aem12,R0,TR1,L2,V1,R67,V2,R67,R69,R3,s108,Whether a statement holds a label, or a case or default outside a switch of its own (clang's ContainsLabel).R4,i2053,R5,i1,R6,s21,arbace/cpp/codegen.aem12,R0,TR1,L1,V1,R66,R3,s86,The condition's folded value (arbace.cpp.sema/fold-mark's :folds): true, false or nil.R4,i2066,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,emit-if!m10,R0,TR1,L1,V1,R67,R4,i2071,R5,i1,R6,s21,arbace/cpp/codegen.aem10,R0,TR1,L1,V1,R67,R4,i2079,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,overrides-fn?m10,R0,TR1,L1,V2,R12,R70,R4,i2109,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,subobjectsm12,R0,TR1,L1,V3,R71,R72,Myn4,moffm2,R29,R42,R3,s193,The subobjects of class `m` placed at `moff` in the layout class `lid`: [{:cls :off (in lid) :vroot (the virtual\n  base it lies in, or nil) :anc #{[cls off] of its non-virtual ancestors}} ...].R4,i2114,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,contains-sub?m10,R0,TR1,L1,V2,R44,R67,R4,i2129,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,find-subm10,R0,TR1,L1,V3,R73,R74,R75,R4,i2134,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen15,final-overriderm12,R0,TR1,L1,V3,R73,R76,R67,R3,s91,[fid subobject] of the final overrider of `g` (declared in the subobject `s`) among `subs`.R4,i2136,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen12,offset-compsm12,R0,TR1,L1,V4,R73,R72,R77,R78,R3,s341,The vcall and vbase offsets of the vtable of the subobject `base` ({:cls :off}, in the layout class `lid`; `virt`:\n  a virtual base in it), closest to the address point first, and the vcall offsets' places: {:comps [{:k :vbase|:vcall\n  :val n}] :vcalls [[fid offset-offset] ...] :vbos {class-id offset-offset}}. `subs` nil: the places alone.R4,i2149,R5,i1,R6,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen19,vbase-offset-offsetm12,R0,TR1,L1,V2,R13,R79,R3,s105,Where the vtable of class `cid` holds the offset of its virtual base `vb` (bytes from the address point).R4,i2183,R5,i1,R6,s21,arbace/cpp/codegen.ae")

var Lit_707 *jrt.String = jrt.Intern("arbace.cpp.codegen$landing_pad_BANG_")

var Lit_708 *jrt.String = jrt.Intern("arbace.cpp.codegen$call_insn_BANG_")

var Lit_709 *jrt.String = jrt.Intern("arbace.cpp.codegen$nothrow_fn_QMARK_")

var Lit_710 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtable_index")

var Lit_711 *jrt.String = jrt.Intern("arbace.cpp.codegen$arg_values")

var Lit_712 *jrt.String = jrt.Intern("arbace.cpp.codegen$vcall_target")

var Lit_713 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_call_BANG_")

var Lit_714 *jrt.String = jrt.Intern("arbace.cpp.codegen$call_BANG_")

var Lit_715 *jrt.String = jrt.Intern("arbace.cpp.codegen$call_dtor_BANG_")

var Lit_716 *jrt.String = jrt.Intern("arbace.cpp.codegen$mcall_BANG_")

var Lit_717 *jrt.String = jrt.Intern("arbace.cpp.codegen$icall_BANG_")

var Lit_718 *jrt.String = jrt.Intern("arbace.cpp.codegen$tls_wrapper_name")

var Lit_719 *jrt.String = jrt.Intern("arbace.cpp.codegen$tls_internal_QMARK_")

var Lit_720 *jrt.String = jrt.Intern("arbace.cpp.codegen$tls_defined_here_QMARK_")

var Lit_721 *jrt.String = jrt.Intern("arbace.cpp.codegen$tls_wrapped_elsewhere_QMARK_")

var Lit_722 *jrt.String = jrt.Intern("arbace.cpp.codegen$tls_via_wrapper_QMARK_")

var Lit_723 *jrt.String = jrt.Intern("arbace.cpp.codegen$tls_wrapper_ret")

var Lit_724 *jrt.String = jrt.Intern("arbace.cpp.codegen$extern_tls_wrapper_BANG_")

var Lit_725 *jrt.String = jrt.Intern("arbace.cpp.codegen$var_addr")

var Lit_726 *jrt.String = jrt.Intern("arbace.cpp.codegen$base_offset")

var Lit_727 *jrt.String = jrt.Intern("arbace.cpp.codegen$base_addr_BANG_")

var Lit_728 *jrt.String = jrt.Intern("arbace.cpp.codegen$int_op")

var Lit_729 *jrt.String = jrt.Intern("arbace.cpp.codegen$fp_op")

var Lit_730 *jrt.String = jrt.Intern("arbace.cpp.codegen$arith_BANG_")

var Lit_731 *jrt.String = jrt.Intern("arbace.cpp.codegen$cmp_BANG_")

var Lit_732 *jrt.String = jrt.Intern("arbace.cpp.codegen$pow2")

var Lit_733 *jrt.String = jrt.Intern("arbace.cpp.codegen$fp80_hex")

var Lit_734 *jrt.String = jrt.Intern("arbace.cpp.codegen$fp_const")

var Lit_735 *jrt.String = jrt.Intern("arbace.cpp.codegen$int_cast_BANG_")

var Lit_736 *jrt.String = jrt.Intern("arbace.cpp.codegen$ptr_adjust_BANG_")

var Lit_737 *jrt.String = jrt.Intern("arbace.cpp.codegen$null_guarded_BANG_")

var Lit_738 *jrt.String = jrt.Intern("arbace.cpp.codegen$dyncast_call_BANG_")

var Lit_739 *jrt.String = jrt.Intern("arbace.cpp.codegen$cast_BANG_")

var Lit_740 *jrt.String = jrt.Intern("arbace.cpp.codegen$materialize_BANG_")

var Lit_741 *jrt.String = jrt.Intern("arbace.cpp.codegen$short_circuit_BANG_")

var Lit_742 *jrt.String = jrt.Intern("arbace.cpp.codegen$short_circuit_branches_BANG_")

var Lit_743 *jrt.String = jrt.Intern("arbace.cpp.codegen$cond_branches_BANG_")

var Lit_744 *jrt.String = jrt.Intern("arbace.cpp.codegen$cond_branches2_BANG_")

var Lit_745 *jrt.String = jrt.Intern("arbace.cpp.codegen$va_arg_class_BANG_")

var Lit_746 *jrt.String = jrt.Intern("arbace.cpp.codegen$stmt_expr_BANG_")

var Lit_747 *jrt.String = jrt.Intern("arbace.cpp.codegen$bind_opaque_BANG_")

var Lit_748 *jrt.String = jrt.Intern("arbace.cpp.codegen$opaque_of")

var Lit_749 *jrt.String = jrt.Intern("arbace.cpp.codegen$incdec_BANG_")

var Lit_750 *jrt.String = jrt.Intern("arbace.cpp.codegen$place_values")

var Lit_751 *jrt.String = jrt.Intern("arbace.cpp.codegen$alloc_call_BANG_")

var Lit_752 *jrt.String = jrt.Intern("arbace.cpp.codegen$dealloc_call_BANG_")

var Lit_753 *jrt.String = jrt.Intern("arbace.cpp.codegen$atomic_ord")

var Lit_754 *jrt.String = jrt.Intern("arbace.cpp.codegen$by_order_BANG_")

var Lit_755 *jrt.String = jrt.Intern("arbace.cpp.codegen$cmpxchg_fail_ord")

var Lit_756 *jrt.String = jrt.Intern("arbace.cpp.codegen$mem_val")

var Lit_757 *jrt.String = jrt.Intern("arbace.cpp.codegen$occupied_bytes_BANG_")

var Lit_758 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_clear_padding_BANG_")

var Lit_759 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fence_BANG_")

var Lit_760 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_atomic_BANG_")

var Lit_761 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_bitop_BANG_")

var Lit_762 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_rv")

var Lit_763 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_lv")

var Lit_764 *jrt.String = jrt.Intern("arbace.cpp.codegen$eval1801000557$fn__1801000558")

var Lit_765 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_into")

var Lit_766 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_init")

var Lit_767 *jrt.String = jrt.Intern("arbace.cpp.codegen$push_cleanup_BANG_")

var Lit_768 *jrt.String = jrt.Intern("arbace.cpp.codegen$cleanup_depth")

var Lit_769 *jrt.String = jrt.Intern("arbace.cpp.codegen$unwind_to_BANG_")

var Lit_770 *jrt.String = jrt.Intern("arbace.cpp.codegen$pop_to_BANG_")

var Lit_771 *jrt.String = jrt.Intern("arbace.cpp.codegen$local_decl_BANG_")

var Lit_772 *jrt.String = jrt.Intern("arbace.cpp.codegen$static_local_BANG_")

var Lit_773 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_return_BANG_")

var Lit_774 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt")

var Lit_775 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_stmt_STAR_")

var Lit_776 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_try_BANG_")

var Lit_777 *jrt.String = jrt.Intern("arbace.cpp.codegen$contains_label_QMARK_")

var Lit_778 *jrt.String = jrt.Intern("arbace.cpp.codegen$folds_to")

var Lit_779 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_if_BANG_")

var Lit_780 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_if_branches_BANG_")

var Lit_781 *jrt.String = jrt.Intern("arbace.cpp.codegen$eval1801000859$fn__1801000860")

var Lit_782 *jrt.String = jrt.Intern("arbace.cpp.codegen$overrides_fn_QMARK_")

var Lit_783 *jrt.String = jrt.Intern("arbace.cpp.codegen$subobjects")

var Lit_784 *jrt.String = jrt.Intern("arbace.cpp.codegen$contains_sub_QMARK_")

var Lit_785 *jrt.String = jrt.Intern("arbace.cpp.codegen$find_sub")

var Lit_786 *jrt.String = jrt.Intern("arbace.cpp.codegen$final_overrider")

var Lit_787 *jrt.String = jrt.Intern("arbace.cpp.codegen$offset_comps")

var Lit_788 *jrt.String = jrt.Intern("arbace.cpp.codegen$vbase_offset_offset")

var Lit_789 *jrt.String = jrt.Intern("kn8,arglistsyn4,addryn3,cidyn2,vbkn3,dockn4,linekn6,columnkn4,filekn7,privateyn3,gidyn1,xyn4,ofidyn1,myn3,lidkn3,tagyn4,longyn4,moffyn16,java.lang.Stringyn3,grpyn3,subyn3,vttyn1,iyn4,thisyn3,fidyn1,fyn1,vyn3,adjkn8,declaredyn6,Stringyn1,tkn7,dynamicyn4,inityn6,leavesyn4,progyn4,argsyn5,dropsyn1,&yn7,record?yn4,verbm10,R0,L1,V3,R1,R2,R3,R4,s111,The address of the virtual base `vb` of the object of class `cid` at `addr`: by the vbase offset of its vtable.R5,i2188,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen19,vcall-offset-offsetm12,R8,TR0,L1,V2,R3,R9,R4,s73,The place of `gid`'s vcall offset in the vtable of the virtual base `vb`.R5,i2196,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,primary-chainm10,R8,TR0,L1,V1,R10,R5,i2203,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen17,return-adjustmentm12,R8,TR0,L1,V2,R9,R11,R4,s223,The return adjustment of the overrider `ofid` for the slot of `gid` (a covariant return type): nil, {:nv n} or\n  {:nv n :v oo} (the base's offset in the derived class, `oo` where its vtable holds the virtual base's offset).R5,i2205,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,vt-groupm10,R0,L1,V3,R12,R13,Myn4,moffm2,R14,R15,R4,s306,The vtable group of class `m` at `moff` in the layout class `lid` (a construction vtable group when they differ):\n  {:items [component ...] :aps {[cls off] index of its address point}}; a component [:off n], [:rtti cid] or [:fn fid\n  variant adjustment] (adjustment nil, {:nv n} or {:nv n :v oo}), [:pure].R5,i2217,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,vt-cachev11,arbace.core4,atomm8,R8,TR5,i2280,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,group-ofm10,R8,TR0,L1,V3,R12,R13,R16,R5,i2281,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,vtable-namem10,R8,TR0,L1,MV1,R2,m2,R14,R17,R5,i2285,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen16,ctor-vtable-namem10,R8,TR0,L1,MV3,R12,R13,R16,m2,R14,R17,R5,i2286,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,group-namem10,R8,TR0,L1,V1,V3,R12,R13,R16,R5,i2288,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,address-pointm12,R8,TR0,L1,V2,R18,R19,R4,s103,The constant address of the address point of the subobject `sub` ([cls off]) in the group [m lid moff].R5,i2290,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,vtt-layoutm10,R0,L1,V1,R2,R4,s202,The VTT of class `cid` (§2.6.2, as clang's VTTBuilder): {:entries [{:grp [m lid moff] :sub [cls off]}] :sub-vtts\n  {[cls off] index} :sec {[cls off] index} (the top level's secondary virtual pointers)}.R5,i2298,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,vtt-namem10,R8,TR0,L1,MV1,R2,m2,R14,R17,R5,i2334,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,vtt-refm12,R8,TR0,L1,V3,R2,R20,R21,R4,s148,A pointer to the VTT entry `i` of class `cid`: in its own VTT (the complete object's constructor and destructor),\n  else at the VTT parameter `vtt`.R5,i2336,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,vptr-listm12,R8,TR0,L1,V1,R2,R4,s167,The vptrs a constructor of class `cid` sets (clang's getVTablePointers): [{:cls :off :vb :vboff}] (vb the nearest\n  virtual base on the way, vboff the offset from it).R5,i2345,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,init-vptrs!m12,R8,TR0,L1,V3,R2,R22,R20,R4,s151,Sets the vptrs of the object of class `cid` at `this` (in a base-object constructor or destructor of a class with\n  virtual bases, from the VTT `vtt`).R5,i2361,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,vptr-store!m10,R8,TR0,L1,V2,R2,R22,R5,i2374,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen18,trivial-dtor-body?m12,R8,TR0,L1,V1,R2,R4,s158,A destructor whose body is empty and whose members' destructors' are, recursively: its vptrs need not be reset\n  (clang's CanSkipVTablePointerInitialization).R5,i2376,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,want-d0!m12,R8,TR0,L1,V1,R23,R4,s167,A virtual destructor's deleting variant, written once (as clang, when a vtable refers to it): deferred among the\n  functions, in the order first referred to (P23 (a)).R5,i2387,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,linkage-ofm10,R8,TR0,L1,V1,R24,R5,i2396,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,emit-fn!m12,R8,TR0,L1,V2,R23,R25,R4,s149,The definition of the function `fid` (a constructor's or destructor's variant `v`; a virtual destructor's D0 with\n  its base-object or complete one).R5,i2402,R6,i1,R7,s21,arbace/cpp/codegen.aem10,R0,L1,V1,R24,R4,s73,The deleting destructor: D2, then operator delete with the object's size.R5,i2547,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,key-fnm12,R8,TR0,L1,V1,R2,R4,s420,The key function of the dynamic class `cid` (Itanium §5.2.3, clang's ASTContext::getCurrentKeyFunction): its first\n  virtual function, in declaration order, that is not pure and not inline (defined in the class, declared or later\n  defined inline: clang's setNonKeyFunction), not implicit or defaulted; nil for a class template's specialization (its\n  vtable is the instantiation's, linkonce_odr) or a class without one.R5,i2569,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,vtable-homem12,R8,TR0,L1,V1,R2,R4,s378,Where the vtable and type_info of the dynamic class `cid` are defined (clang's CodeGenVTables::isVTableExternal,\n  getVTableLinkage): :here, strong, when its key function is defined in this unit (G5c: libsupc++'s bad_alloc.cc\n  defines std::bad_alloc's); :external when it has a key function defined elsewhere (G4: std::exception's); else\n  :linkonce, in each unit that uses it.R5,i2580,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen15,external-class?m12,R8,TR0,L1,V1,R2,R4,s98,A dynamic class whose vtable and type_info are another unit's (its key function not defined here).R5,i2590,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,vt-linkagem12,R8,TR0,L1,V1,R2,R4,s110,The linkage options of the vtable, VTT and type_info of class `cid`: strong where its key function is defined.R5,i2595,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,typeinfo!m10,R8,TR0,L1,V1,R2,R5,i2600,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,thunk!m12,R8,TR0,L1,V3,R23,R25,R26,R4,s221,The this-adjusting thunk of the function `fid` (the destructor variant `v`): `_ZTh<nv>_` (this moved by nv bytes)\n  or `_ZTv<nv>_<oo>_` (moved by nv, then by the vcall offset at oo in its vtable), n for a negative number.R5,i2642,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen4,vtt!m8,R27,TR5,i2693,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,group!m10,R8,TR0,L1,V1,R18,R5,i2695,R6,i1,R7,s21,arbace/cpp/codegen.aem10,R8,TR0,L1,V1,R2,R5,i2722,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,vtable!m10,R8,TR0,L1,V1,R2,R5,i2728,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen17,abi-class-global!m10,R8,TR0,L1,V1,Myn4,kindm2,R14,R28,R5,i2730,R6,i1,R7,s21,arbace/cpp/codegen.aem10,R0,L1,V1,R29,R4,s225,The type_info object of the type `t` (a thrown or caught type): a class's own; a fundamental type's and a pointer\n  to one's in the runtime (external); a pointer to a class's or an enumeration's written here (Itanium §2.9.5).R5,i2736,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,*const-top*m8,R30,TR5,i2779,R6,i1,R7,s21,arbace/cpp/codegen.aem12,R8,TR0,L1,V3,R29,R31,Myn3,offm2,R14,R15,R4,s168,The initializer as constant leaves [[offset llvm-type value] ...] of an object of type `t` at `off`, or nil when it\n  is not a constant (a dynamic initialization then).R5,i2781,R6,i1,R7,s21,arbace/cpp/codegen.aem12,R8,TR0,L1,V2,R32,Myn4,sizem2,R14,R15,R4,s83,[type value] of a packed struct holding the leaves with byte padding, `size` bytes.R5,i2847,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,emit-globals!m12,R8,TR0,L1,V2,R33,Myn4,filem2,R14,R28,R4,s145,Each defined namespace-scope variable: a constant initializer, or zero and a dynamic initialization in\n  _GLOBAL__sub_I_FILE (llvm.global_ctors).R5,i2860,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen17,fundamental-codesV25,s1,vs2,Dns1,bs1,ws1,cs1,hs1,as1,ss1,ts1,is1,js1,ls1,ms1,xs1,ys1,ns1,os2,Dhs1,fs1,ds1,es1,gs2,Dus2,Dss2,Dim8,R8,TR5,i2995,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen15,abstract-class?m12,R8,TR0,L1,V1,R2,R4,s126,A class with a pure virtual function its final overriders leave pure ([class.abstract]/2): a [:pure] slot in its vtable group.R5,i2997,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen22,fundamental-typeinfos!m10,R8,TR0,L1,V0,R5,i3002,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen10,gen-modulem10,R0,L1,V2,R33,Myn4,filem2,R14,R28,R4,s98,The LLVM forms of the program `prog` (arbace.cpp.sema's analyze-program) of the file named `file`.R5,i3018,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen8,gen-filem10,R0,L2,V2,Myn4,pathm2,R14,R28,Myn3,stdm2,R14,R28,V3,Myn4,pathm2,R14,R28,Myn3,stdm2,R14,R28,R34,R4,s130,The LLVM forms of the C++ file at `path` (read by the native parser at `std`, with the preprocessor's options `args`: -I, -D ...).R5,i3108,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,write-dropsm12,R8,TR0,L1,V2,Myn4,pathm2,R14,R28,R35,R4,s230,CP364 (a): OUT/drops.tsv, the header declarations the analysis dropped (G4) by cause, the largest first: COUNT, the\n  refusal's class, its message, up to three of the declarations' names (KIND:NAME); nothing when none was dropped.R5,i3124,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen7,gen-onem10,R0,L1,V5,Myn4,pathm2,R14,R28,Myn3,stdm2,R14,R28,Myn3,outm2,R14,R28,R36,V1,R34,R4,s241,Writes OUT/forms.ae (the LLVM forms), OUT/gen.ll (their IR text) and OUT/gen.c (lowered by arbace.cpp.lower), or\n  OUT/gen.refused (the class and the message), and OUT/drops.tsv (the header declarations dropped, CP364 (a)); the class or nil.R5,i3138,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen13,defined-namesm12,R8,TR0,L1,V1,Myn2,llm2,R14,R28,R4,s126,The global names an IR text defines (functions, variables, aliases), but string literals, llvm.* and the global\n  constructor.R5,i3168,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen6,slurp?m10,R8,TR0,L1,V1,Myn1,pm2,R14,R28,R5,i3179,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen5,judgem10,R0,L1,V2,Myn4,workm2,R14,R28,Myn10,known-pathm2,R14,R28,R4,s334,Each sample of WORK/list.tsv: the code generator's lowered run against clang's IR lowered (status and stdout\n  equal), its IR run natively against the same, and the names it defines among clang's; the known file's names are\n  expected not to pass (their class given). Writes WORK/results.tsv and WORK/summary.edn; exit 1 on a failure.R5,i3181,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,file-sha256m10,R8,TR0,L1,MV1,Myn1,pm2,R14,R28,m2,R14,R17,R5,i3218,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen11,gen-outcomem12,R8,TR0,L1,V1,Myn3,dirm2,R14,R28,R4,s122,A sample's outcome in DIR after gen-one: [:refused CLASS] (gen.refused's class), [:forms SHA-256 of forms.ae], or [:none].R5,i3222,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen17,read-forms-recordm10,R8,TR0,L1,V1,Myn1,pm2,R14,R28,R5,i3229,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen9,gen-judgem10,R0,L1,V5,Myn4,workm2,R14,R28,Myn13,refusals-pathm2,R14,R28,Myn10,forms-pathm2,R14,R28,Myn13,controls-pathm2,R14,R28,R37,R4,s547,WORK/list.tsv's samples (NAME<tab>PATH), each generated into WORK/files/NAME by gen-list: a refused sample against REFUSALS\n  ({NAME CLASS}: its class the same), a generated one's forms.ae against FORMS (sha256sum's lines, DIGEST  NAME), a sample in\n  neither record failing. CONTROLS' :level :gen entries ({:id :subject NAME :reference NAME}) cross two samples: the subject's\n  outcome judged against the reference's record must fail. --record rewrites both records from the run (a whole run only).\n  Writes WORK/results.tsv; exit 1 on a failure.R5,i3236,R6,i1,R7,s21,arbace/cpp/codegen.aev18,arbace.cpp.codegen5,-mainm10,R0,L1,V3,R38,R36,R34,R4,s176,bin/cppi codegen FILE OUTDIR [--std S]: the file's LLVM forms by the code generator, their IR and their lowering;\n  bin/cppi codegen-list LIST (NAME<tab>PATH<tab>OUTDIR lines).R5,i3282,R6,i1,R7,s21,arbace/cpp/codegen.ae")

var Lit_790 *jrt.String = jrt.Intern("arbace.cpp.codegen$vbase_addr_BANG_")

var Lit_791 *jrt.String = jrt.Intern("arbace.cpp.codegen$vcall_offset_offset")

var Lit_792 *jrt.String = jrt.Intern("arbace.cpp.codegen$primary_chain")

var Lit_793 *jrt.String = jrt.Intern("arbace.cpp.codegen$return_adjustment")

var Lit_794 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_group")

var Lit_795 *jrt.String = jrt.Intern("arbace.cpp.codegen$group_of")

var Lit_796 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtable_name")

var Lit_797 *jrt.String = jrt.Intern("arbace.cpp.codegen$ctor_vtable_name")

var Lit_798 *jrt.String = jrt.Intern("arbace.cpp.codegen$group_name")

var Lit_799 *jrt.String = jrt.Intern("arbace.cpp.codegen$address_point")

var Lit_800 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtt_layout")

var Lit_801 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtt_name")

var Lit_802 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtt_ref")

var Lit_803 *jrt.String = jrt.Intern("arbace.cpp.codegen$vptr_list")

var Lit_804 *jrt.String = jrt.Intern("arbace.cpp.codegen$init_vptrs_BANG_")

var Lit_805 *jrt.String = jrt.Intern("arbace.cpp.codegen$vptr_store_BANG_")

var Lit_806 *jrt.String = jrt.Intern("arbace.cpp.codegen$trivial_dtor_body_QMARK_")

var Lit_807 *jrt.String = jrt.Intern("arbace.cpp.codegen$want_d0_BANG_")

var Lit_808 *jrt.String = jrt.Intern("arbace.cpp.codegen$linkage_of")

var Lit_809 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_fn_BANG_")

var Lit_810 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_d0_BANG_")

var Lit_811 *jrt.String = jrt.Intern("arbace.cpp.codegen$key_fn")

var Lit_812 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtable_home")

var Lit_813 *jrt.String = jrt.Intern("arbace.cpp.codegen$external_class_QMARK_")

var Lit_814 *jrt.String = jrt.Intern("arbace.cpp.codegen$vt_linkage")

var Lit_815 *jrt.String = jrt.Intern("arbace.cpp.codegen$typeinfo_BANG_")

var Lit_816 *jrt.String = jrt.Intern("arbace.cpp.codegen$thunk_BANG_")

var Lit_817 *jrt.String = jrt.Intern("arbace.cpp.codegen$group_BANG_")

var Lit_818 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtt_BANG_")

var Lit_819 *jrt.String = jrt.Intern("arbace.cpp.codegen$vtable_BANG_")

var Lit_820 *jrt.String = jrt.Intern("arbace.cpp.codegen$abi_class_global_BANG_")

var Lit_821 *jrt.String = jrt.Intern("arbace.cpp.codegen$eh_typeinfo_BANG_")

var Lit_822 *jrt.String = jrt.Intern("arbace.cpp.codegen$const_leaves")

var Lit_823 *jrt.String = jrt.Intern("arbace.cpp.codegen$leaves_constant")

var Lit_824 *jrt.String = jrt.Intern("arbace.cpp.codegen$emit_globals_BANG_")

var Lit_825 *jrt.String = jrt.Intern("arbace.cpp.codegen$abstract_class_QMARK_")

var Lit_826 *jrt.String = jrt.Intern("arbace.cpp.codegen$fundamental_typeinfos_BANG_")

var Lit_827 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_module")

var Lit_828 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_file")

var Lit_829 *jrt.String = jrt.Intern("arbace.cpp.codegen$write_drops")

var Lit_830 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_one")

var Lit_831 *jrt.String = jrt.Intern("arbace.cpp.codegen$defined_names")

var Lit_832 *jrt.String = jrt.Intern("arbace.cpp.codegen$slurp_QMARK_")

var Lit_833 *jrt.String = jrt.Intern("arbace.cpp.codegen$judge")

var Lit_834 *jrt.String = jrt.Intern("arbace.cpp.codegen$file_sha256")

var Lit_835 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_outcome")

var Lit_836 *jrt.String = jrt.Intern("arbace.cpp.codegen$read_forms_record")

var Lit_837 *jrt.String = jrt.Intern("arbace.cpp.codegen$gen_judge")

var Lit_838 *jrt.String = jrt.Intern("arbace.cpp.codegen$_main")
