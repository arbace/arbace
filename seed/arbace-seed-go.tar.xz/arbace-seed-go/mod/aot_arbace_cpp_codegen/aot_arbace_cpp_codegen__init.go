//line aot_arbace_cpp_codegen__init.ae:1
package aot_arbace_cpp_codegen

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_cpp_codegen__init_part0_A_Unit0__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_cpp_codegen__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_cpp_codegen__init_part0_A_const_1) }
//line :1:1
func A_arbace_cpp_codegen__init_part0_A_Unit1__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_cpp_codegen__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_2)) }
//line :1:1
func A_arbace_cpp_codegen__init_part0_A_Unit2__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_cpp_codegen_eval1801000004_loading__1927001464__auto____1801000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_cpp_codegen_eval1801000004_loading__1927001464__auto____1801000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_641, false, nil); A_arbace_cpp_codegen_eval1801000004_loading__1927001464__auto____1801000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_cpp_codegen__init_part0_A_Unit3__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_cpp_codegen__init_part0_A_const_1)).Equals_O__Z(A_arbace_cpp_codegen__init_part0_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_cpp_codegen_eval1801000008_fn__1801000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_cpp_codegen_eval1801000008_fn__1801000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_642, false, nil); A_arbace_cpp_codegen_eval1801000008_fn__1801000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }
//line :1:1
func A_arbace_cpp_codegen__init_part0_A_Init__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); return nil }
//line :1:1
func A_arbace_cpp_codegen__init_part0_A_Load__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); A_arbace_cpp_codegen__init_part0_A_Unit0__O(); A_arbace_cpp_codegen__init_part0_A_Unit1__O(); A_arbace_cpp_codegen__init_part0_A_Unit2__O(); A_arbace_cpp_codegen__init_part0_A_Unit3__O(); A_arbace_cpp_codegen__init_part0_A_Unit4__O(); A_arbace_cpp_codegen__init_part0_A_Unit5__O(); A_arbace_cpp_codegen__init_part0_A_Unit6__O(); A_arbace_cpp_codegen__init_part0_A_Unit7__O(); A_arbace_cpp_codegen__init_part0_A_Unit8__O(); A_arbace_cpp_codegen__init_part0_A_Unit9__O(); A_arbace_cpp_codegen__init_part0_A_Unit10__O(); A_arbace_cpp_codegen__init_part0_A_Unit11__O(); A_arbace_cpp_codegen__init_part0_A_Unit12__O(); A_arbace_cpp_codegen__init_part0_A_Unit13__O(); A_arbace_cpp_codegen__init_part0_A_Unit14__O(); A_arbace_cpp_codegen__init_part0_A_Unit15__O(); A_arbace_cpp_codegen__init_part0_A_Unit16__O(); A_arbace_cpp_codegen__init_part0_A_Unit17__O(); A_arbace_cpp_codegen__init_part0_A_Unit18__O(); A_arbace_cpp_codegen__init_part0_A_Unit19__O(); A_arbace_cpp_codegen__init_part0_A_Unit20__O(); A_arbace_cpp_codegen__init_part0_A_Unit21__O(); A_arbace_cpp_codegen__init_part0_A_Unit22__O(); A_arbace_cpp_codegen__init_part0_A_Unit23__O(); A_arbace_cpp_codegen__init_part0_A_Unit24__O(); A_arbace_cpp_codegen__init_part0_A_Unit25__O(); A_arbace_cpp_codegen__init_part0_A_Unit26__O(); A_arbace_cpp_codegen__init_part0_A_Unit27__O(); A_arbace_cpp_codegen__init_part0_A_Unit28__O(); A_arbace_cpp_codegen__init_part0_A_Unit29__O(); A_arbace_cpp_codegen__init_part0_A_Unit30__O(); A_arbace_cpp_codegen__init_part0_A_Unit31__O(); A_arbace_cpp_codegen__init_part0_A_Unit32__O(); A_arbace_cpp_codegen__init_part0_A_Unit33__O(); A_arbace_cpp_codegen__init_part0_A_Unit34__O(); A_arbace_cpp_codegen__init_part0_A_Unit35__O(); A_arbace_cpp_codegen__init_part0_A_Unit36__O(); A_arbace_cpp_codegen__init_part0_A_Unit37__O(); A_arbace_cpp_codegen__init_part0_A_Unit38__O(); A_arbace_cpp_codegen__init_part0_A_Unit39__O(); A_arbace_cpp_codegen__init_part0_A_Unit40__O(); A_arbace_cpp_codegen__init_part0_A_Unit41__O(); A_arbace_cpp_codegen__init_part0_A_Unit42__O(); A_arbace_cpp_codegen__init_part0_A_Unit43__O(); A_arbace_cpp_codegen__init_part0_A_Unit44__O(); A_arbace_cpp_codegen__init_part0_A_Unit45__O(); A_arbace_cpp_codegen__init_part0_A_Unit46__O(); A_arbace_cpp_codegen__init_part0_A_Unit47__O(); A_arbace_cpp_codegen__init_part0_A_Unit48__O(); A_arbace_cpp_codegen__init_part0_A_Unit49__O(); A_arbace_cpp_codegen__init_part0_A_Unit50__O(); A_arbace_cpp_codegen__init_part0_A_Unit51__O(); A_arbace_cpp_codegen__init_part0_A_Unit52__O(); A_arbace_cpp_codegen__init_part0_A_Unit53__O(); A_arbace_cpp_codegen__init_part0_A_Unit54__O(); A_arbace_cpp_codegen__init_part0_A_Unit55__O(); A_arbace_cpp_codegen__init_part0_A_Unit56__O(); A_arbace_cpp_codegen__init_part0_A_Unit57__O(); A_arbace_cpp_codegen__init_part0_A_Unit58__O(); A_arbace_cpp_codegen__init_part0_A_Unit59__O(); A_arbace_cpp_codegen__init_part0_A_Unit60__O(); A_arbace_cpp_codegen__init_part0_A_Unit61__O(); A_arbace_cpp_codegen__init_part0_A_Unit62__O(); A_arbace_cpp_codegen__init_part0_A_Unit63__O(); A_arbace_cpp_codegen__init_part0_A_Unit64__O(); A_arbace_cpp_codegen__init_part0_A_Unit65__O(); A_arbace_cpp_codegen__init_part0_A_Unit66__O(); A_arbace_cpp_codegen__init_part0_A_Unit67__O(); A_arbace_cpp_codegen__init_part0_A_Unit68__O(); A_arbace_cpp_codegen__init_part0_A_Unit69__O(); A_arbace_cpp_codegen__init_part0_A_Unit70__O(); A_arbace_cpp_codegen__init_part0_A_Unit71__O(); A_arbace_cpp_codegen__init_part0_A_Unit72__O(); A_arbace_cpp_codegen__init_part0_A_Unit73__O(); A_arbace_cpp_codegen__init_part0_A_Unit74__O(); A_arbace_cpp_codegen__init_part0_A_Unit75__O(); A_arbace_cpp_codegen__init_part0_A_Unit76__O(); A_arbace_cpp_codegen__init_part0_A_Unit77__O(); A_arbace_cpp_codegen__init_part0_A_Unit78__O(); A_arbace_cpp_codegen__init_part0_A_Unit79__O(); A_arbace_cpp_codegen__init_part0_A_Unit80__O(); A_arbace_cpp_codegen__init_part0_A_Unit81__O(); A_arbace_cpp_codegen__init_part0_A_Unit82__O(); A_arbace_cpp_codegen__init_part0_A_Unit83__O(); A_arbace_cpp_codegen__init_part0_A_Unit84__O(); A_arbace_cpp_codegen__init_part0_A_Unit85__O(); A_arbace_cpp_codegen__init_part0_A_Unit86__O(); A_arbace_cpp_codegen__init_part0_A_Unit87__O(); A_arbace_cpp_codegen__init_part0_A_Unit88__O(); A_arbace_cpp_codegen__init_part0_A_Unit89__O(); A_arbace_cpp_codegen__init_part0_A_Unit90__O(); A_arbace_cpp_codegen__init_part0_A_Unit91__O(); A_arbace_cpp_codegen__init_part0_A_Unit92__O(); A_arbace_cpp_codegen__init_part0_A_Unit93__O(); A_arbace_cpp_codegen__init_part0_A_Unit94__O(); A_arbace_cpp_codegen__init_part0_A_Unit95__O(); A_arbace_cpp_codegen__init_part0_A_Unit96__O(); A_arbace_cpp_codegen__init_part0_A_Unit97__O(); A_arbace_cpp_codegen__init_part0_A_Unit98__O(); A_arbace_cpp_codegen__init_part0_A_Unit99__O(); return nil }



func A_arbace_cpp_codegen__init_A_Load__O() any { jrt.StartCheck(); A_arbace_cpp_codegen__init_part0_A_Init__O(); A_arbace_cpp_codegen__init_part1_A_Init__O(); A_arbace_cpp_codegen__init_part2_A_Init__O(); A_arbace_cpp_codegen__init_part0_A_Load__O(); A_arbace_cpp_codegen__init_part1_A_Load__O(); A_arbace_cpp_codegen__init_part2_A_Load__O(); return nil }
















func A_arbace_cpp_codegen__init_part0_A_Unit4__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(22, 1); return A_arbace_cpp_codegen__init_part0_A_const_4.Set_O__O(jrt.Boolean_TRUE.Ref()) }

func A_arbace_cpp_codegen__init_part0_A_Unit5__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_5; tmp1.BindRoot_O__V(A_arbace_cpp_codegen__init_part0_A_const_6.GetRawRoot__O()); var tmp2 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_5; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_7)); return A_arbace_cpp_codegen__init_part0_A_const_5 }




func A_arbace_cpp_codegen__init_part0_A_Unit6__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(29, 1); A_arbace_cpp_codegen__init_part0_A_const_8.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_9)); return A_arbace_cpp_codegen__init_part0_A_const_8.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_codegen__init_part0_A_Unit7__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_cpp_codegen_gsym_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_cpp_codegen_gsym_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_643, false, nil); A_arbace_cpp_codegen_gsym_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_11)); return A_arbace_cpp_codegen__init_part0_A_const_10 }




func A_arbace_cpp_codegen__init_part0_A_Unit8__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_cpp_codegen_add_top_BANG__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_cpp_codegen_add_top_BANG__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_644, false, nil); A_arbace_cpp_codegen_add_top_BANG__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_13)); return A_arbace_cpp_codegen__init_part0_A_const_12 }





func A_arbace_cpp_codegen__init_part0_A_Unit9__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_cpp_codegen_conj_new_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_cpp_codegen_conj_new_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_645, false, nil); A_arbace_cpp_codegen_conj_new_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_15)); return A_arbace_cpp_codegen__init_part0_A_const_14 }

func A_arbace_cpp_codegen__init_part0_A_Unit10__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_cpp_codegen_want_BANG__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_cpp_codegen_want_BANG__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_646, false, nil); A_arbace_cpp_codegen_want_BANG__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_17)); return A_arbace_cpp_codegen__init_part0_A_const_16 }








func A_arbace_cpp_codegen__init_part0_A_Unit11__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_cpp_codegen_place_BANG__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_cpp_codegen_place_BANG__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_647, false, nil); A_arbace_cpp_codegen_place_BANG__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_19)); return A_arbace_cpp_codegen__init_part0_A_const_18 }




func A_arbace_cpp_codegen__init_part0_A_Unit12__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); A_arbace_cpp_codegen__init_part0_A_const_20.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_21)); return A_arbace_cpp_codegen__init_part0_A_const_20.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_codegen__init_part0_A_Unit13__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(60, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_cpp_codegen_reserve_BANG__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_cpp_codegen_reserve_BANG__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_648, false, nil); A_arbace_cpp_codegen_reserve_BANG__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_23)); return A_arbace_cpp_codegen__init_part0_A_const_22 }







func A_arbace_cpp_codegen__init_part0_A_Unit14__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(68, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_24; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__18 any = A_arbace_cpp_codegen_declare_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_cpp_codegen_declare_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_649, true, nil); A_arbace_cpp_codegen_declare_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__18, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_25)); return A_arbace_cpp_codegen__init_part0_A_const_24 }






func A_arbace_cpp_codegen__init_part0_A_Unit15__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(75, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_26; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_27)); return A_arbace_cpp_codegen__init_part0_A_const_26 }

func A_arbace_cpp_codegen__init_part0_A_Unit16__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(77, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_cpp_codegen_wide_global_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_cpp_codegen_wide_global_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_650, false, nil); A_arbace_cpp_codegen_wide_global_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_29)); return A_arbace_cpp_codegen__init_part0_A_const_28 }












func A_arbace_cpp_codegen__init_part0_A_Unit17__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(90, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_cpp_codegen_str_global_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_cpp_codegen_str_global_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_651, false, nil); A_arbace_cpp_codegen_str_global_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_31)); return A_arbace_cpp_codegen__init_part0_A_const_30 }




func A_arbace_cpp_codegen__init_part0_A_Unit18__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(95, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_cpp_codegen_string_global_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_cpp_codegen_string_global_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_652, false, nil); A_arbace_cpp_codegen_string_global_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_32)); return A_arbace_cpp_codegen__init_part0_A_const_26 }











func A_arbace_cpp_codegen__init_part0_A_Unit19__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); A_arbace_cpp_codegen__init_part0_A_const_33.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_33; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_34)); return A_arbace_cpp_codegen__init_part0_A_const_33.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_codegen__init_part0_A_Unit20__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_cpp_codegen_tmp_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_cpp_codegen_tmp_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_653, false, nil); A_arbace_cpp_codegen_tmp_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_36)); return A_arbace_cpp_codegen__init_part0_A_const_35 }
func A_arbace_cpp_codegen__init_part0_A_Unit21__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(110, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_cpp_codegen_new_label_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_cpp_codegen_new_label_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_654, false, nil); A_arbace_cpp_codegen_new_label_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_38)); return A_arbace_cpp_codegen__init_part0_A_const_37 }

func A_arbace_cpp_codegen__init_part0_A_Unit22__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_cpp_codegen_close_block_BANG__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_cpp_codegen_close_block_BANG__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_655, false, nil); A_arbace_cpp_codegen_close_block_BANG__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_40)); return A_arbace_cpp_codegen__init_part0_A_const_39 }



func A_arbace_cpp_codegen__init_part0_A_Unit23__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(116, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_cpp_codegen_start_BANG__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_cpp_codegen_start_BANG__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_656, false, nil); A_arbace_cpp_codegen_start_BANG__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_42)); return A_arbace_cpp_codegen__init_part0_A_const_41 }

func A_arbace_cpp_codegen__init_part0_A_Unit24__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(118, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_cpp_codegen_emit_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_cpp_codegen_emit_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_657, false, nil); A_arbace_cpp_codegen_emit_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_44)); return A_arbace_cpp_codegen__init_part0_A_const_43 }







func A_arbace_cpp_codegen__init_part0_A_Unit25__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(126, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_cpp_codegen_val_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_cpp_codegen_val_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_658, false, nil); A_arbace_cpp_codegen_val_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_46)); return A_arbace_cpp_codegen__init_part0_A_const_45 }

func A_arbace_cpp_codegen__init_part0_A_Unit26__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_cpp_codegen_begin_BANG__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_cpp_codegen_begin_BANG__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_659, false, nil); A_arbace_cpp_codegen_begin_BANG__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_48)); return A_arbace_cpp_codegen__init_part0_A_const_47 }





func A_arbace_cpp_codegen__init_part0_A_Unit27__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(134, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_cpp_codegen_br_BANG__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_cpp_codegen_br_BANG__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_660, false, nil); A_arbace_cpp_codegen_br_BANG__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_50)); return A_arbace_cpp_codegen__init_part0_A_const_49 }
func A_arbace_cpp_codegen__init_part0_A_Unit28__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(135, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_cpp_codegen_condbr_BANG__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_cpp_codegen_condbr_BANG__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_661, false, nil); A_arbace_cpp_codegen_condbr_BANG__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_52)); return A_arbace_cpp_codegen__init_part0_A_const_51 }

func A_arbace_cpp_codegen__init_part0_A_Unit29__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(137, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_cpp_codegen_alloca_BANG__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_cpp_codegen_alloca_BANG__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_662, false, nil); A_arbace_cpp_codegen_alloca_BANG__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_54)); return A_arbace_cpp_codegen__init_part0_A_const_53 }




func A_arbace_cpp_codegen__init_part0_A_Unit30__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(142, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_55; var tmp2 any; var root_45 any = A_arbace_cpp_codegen__init_part0_A_const_56.GetRawRoot__O(); var linked_46 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_45, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_47 lang.IFn; if

	linked_46 == nil { ifn_47 = lang.IFn_Cast(root_45) } else { ifn_47 = nil }; var arg_48 any = Lit_663; if linked_46 == nil { tmp2 = ifn_47.Invoke_O__O(arg_48) } else { tmp2 = linked_46.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_45, arg_48) }; /*line :142:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_55; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_57)); return A_arbace_cpp_codegen__init_part0_A_const_55 }



func A_arbace_cpp_codegen__init_part0_A_Unit31__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_cpp_codegen_va_list_type_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_cpp_codegen_va_list_type_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_664, false, nil); A_arbace_cpp_codegen_va_list_type_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_59)); return A_arbace_cpp_codegen__init_part0_A_const_58 }






func A_arbace_cpp_codegen__init_part0_A_Unit32__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(153, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_cpp_codegen_va_tag_BANG__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_cpp_codegen_va_tag_BANG__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_665, false, nil); A_arbace_cpp_codegen_va_tag_BANG__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_61)); return A_arbace_cpp_codegen__init_part0_A_const_60 }






func A_arbace_cpp_codegen__init_part0_A_Unit33__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_cpp_codegen_va_field_BANG__A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_cpp_codegen_va_field_BANG__A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_666, false, nil); A_arbace_cpp_codegen_va_field_BANG__A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_63)); return A_arbace_cpp_codegen__init_part0_A_const_62 }







func A_arbace_cpp_codegen__init_part0_A_Unit34__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(168, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_cpp_codegen_slot_BANG__A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_cpp_codegen_slot_BANG__A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_667, false, nil); A_arbace_cpp_codegen_slot_BANG__A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_65)); return A_arbace_cpp_codegen__init_part0_A_const_64 }









func A_arbace_cpp_codegen__init_part0_A_Unit35__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_45; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_66)); return A_arbace_cpp_codegen__init_part0_A_const_45 }

func A_arbace_cpp_codegen__init_part0_A_Unit36__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(180, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_67; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_cpp_codegen_bf_load_BANG__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_cpp_codegen_bf_load_BANG__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_668, false, nil); A_arbace_cpp_codegen_bf_load_BANG__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_68)); return A_arbace_cpp_codegen__init_part0_A_const_67 }












func A_arbace_cpp_codegen__init_part0_A_Unit37__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(193, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_69; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_cpp_codegen_bf_store_BANG__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_cpp_codegen_bf_store_BANG__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_669, false, nil); A_arbace_cpp_codegen_bf_store_BANG__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_70)); return A_arbace_cpp_codegen__init_part0_A_const_69 }











func A_arbace_cpp_codegen__init_part0_A_Unit38__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(205, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_71; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_cpp_codegen_load_BANG__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_cpp_codegen_load_BANG__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_670, false, nil); A_arbace_cpp_codegen_load_BANG__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_72)); return A_arbace_cpp_codegen__init_part0_A_const_71 }





func A_arbace_cpp_codegen__init_part0_A_Unit39__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(211, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_cpp_codegen_store_BANG__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_cpp_codegen_store_BANG__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_671, false, nil); A_arbace_cpp_codegen_store_BANG__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_74)); return A_arbace_cpp_codegen__init_part0_A_const_73 }





func A_arbace_cpp_codegen__init_part0_A_Unit40__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(217, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_75; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_76)); return A_arbace_cpp_codegen__init_part0_A_const_75 }

func A_arbace_cpp_codegen__init_part0_A_Unit41__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(219, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_77; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_cpp_codegen_field_place_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_cpp_codegen_field_place_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_672, false, nil); A_arbace_cpp_codegen_field_place_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_78)); return A_arbace_cpp_codegen__init_part0_A_const_77 }









func A_arbace_cpp_codegen__init_part0_A_Unit42__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_cpp_codegen_offset_BANG__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_cpp_codegen_offset_BANG__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_673, false, nil); A_arbace_cpp_codegen_offset_BANG__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_79)); return A_arbace_cpp_codegen__init_part0_A_const_75 }


func A_arbace_cpp_codegen__init_part0_A_Unit43__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_cpp_codegen_memcpy_BANG__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_cpp_codegen_memcpy_BANG__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_674, false, nil); A_arbace_cpp_codegen_memcpy_BANG__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_81)); return A_arbace_cpp_codegen__init_part0_A_const_80 }



func A_arbace_cpp_codegen__init_part0_A_Unit44__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(236, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_cpp_codegen_empty_rec_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_cpp_codegen_empty_rec_QMARK__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_675, false, nil); A_arbace_cpp_codegen_empty_rec_QMARK__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_83)); return A_arbace_cpp_codegen__init_part0_A_const_82 }






func A_arbace_cpp_codegen__init_part0_A_Unit45__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(243, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_cpp_codegen_memset_BANG__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_cpp_codegen_memset_BANG__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_676, false, nil); A_arbace_cpp_codegen_memset_BANG__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_85)); return A_arbace_cpp_codegen__init_part0_A_const_84 }



func A_arbace_cpp_codegen__init_part0_A_Unit46__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(247, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_cpp_codegen_elem_type_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_cpp_codegen_elem_type_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_677, false, nil); A_arbace_cpp_codegen_elem_type_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_87)); return A_arbace_cpp_codegen__init_part0_A_const_86 }

func A_arbace_cpp_codegen__init_part0_A_Unit47__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(249, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_88; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_cpp_codegen_zero_of_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_cpp_codegen_zero_of_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_678, false, nil); A_arbace_cpp_codegen_zero_of_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_89)); return A_arbace_cpp_codegen__init_part0_A_const_88 }

func A_arbace_cpp_codegen__init_part0_A_Unit48__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(251, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_90; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_cpp_codegen_zero_mem_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_cpp_codegen_zero_mem_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_679, false, nil); A_arbace_cpp_codegen_zero_mem_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_91)); return A_arbace_cpp_codegen__init_part0_A_const_90 }




func A_arbace_cpp_codegen__init_part0_A_Unit49__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_92; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_cpp_codegen_vb_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_cpp_codegen_vb_class_QMARK__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_680, false, nil); A_arbace_cpp_codegen_vb_class_QMARK__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_93)); return A_arbace_cpp_codegen__init_part0_A_const_92 }

func A_arbace_cpp_codegen__init_part0_A_Unit50__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_94; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_cpp_codegen_fn_variant_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_cpp_codegen_fn_variant_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_681, false, nil); A_arbace_cpp_codegen_fn_variant_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_95)); return A_arbace_cpp_codegen__init_part0_A_const_94 }





func A_arbace_cpp_codegen__init_part0_A_Unit51__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(264, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_96; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__86 any = A_arbace_cpp_codegen_fn_name_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_cpp_codegen_fn_name_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_682, true, nil); A_arbace_cpp_codegen_fn_name_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__86, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_97)); return A_arbace_cpp_codegen__init_part0_A_const_96 }

func A_arbace_cpp_codegen__init_part0_A_Unit52__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(266, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_cpp_codegen_takes_vtt_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_cpp_codegen_takes_vtt_QMARK__A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_683, false, nil); A_arbace_cpp_codegen_takes_vtt_QMARK__A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_99)); return A_arbace_cpp_codegen__init_part0_A_const_98 }








func A_arbace_cpp_codegen__init_part0_A_Unit53__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(275, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_cpp_codegen_part_ltype_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_cpp_codegen_part_ltype_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_684, false, nil); A_arbace_cpp_codegen_part_ltype_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_101)); return A_arbace_cpp_codegen__init_part0_A_const_100 }


func A_arbace_cpp_codegen__init_part0_A_Unit54__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(278, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_102; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_cpp_codegen_class_pass_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_cpp_codegen_class_pass_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_685, false, nil); A_arbace_cpp_codegen_class_pass_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_103)); return A_arbace_cpp_codegen__init_part0_A_const_102 }







func A_arbace_cpp_codegen__init_part0_A_Unit55__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(286, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_104; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_cpp_codegen_byval_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_cpp_codegen_byval_class_QMARK__A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_686, false, nil); A_arbace_cpp_codegen_byval_class_QMARK__A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_105)); return A_arbace_cpp_codegen__init_part0_A_const_104 }

func A_arbace_cpp_codegen__init_part0_A_Unit56__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_106; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__96 any = A_arbace_cpp_codegen_sig_plan_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_cpp_codegen_sig_plan_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_687, true, nil); A_arbace_cpp_codegen_sig_plan_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__96, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_107)); return A_arbace_cpp_codegen__init_part0_A_const_106 }


































func A_arbace_cpp_codegen__init_part0_A_Unit57__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(323, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_108; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_cpp_codegen_class_ret_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_cpp_codegen_class_ret_QMARK__A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_688, false, nil); A_arbace_cpp_codegen_class_ret_QMARK__A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_109)); return A_arbace_cpp_codegen__init_part0_A_const_108 }

func A_arbace_cpp_codegen__init_part0_A_Unit58__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(325, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_110; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_cpp_codegen_param_ltype_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_cpp_codegen_param_ltype_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_689, false, nil); A_arbace_cpp_codegen_param_ltype_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_111)); return A_arbace_cpp_codegen__init_part0_A_const_110 }

func A_arbace_cpp_codegen__init_part0_A_Unit59__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(327, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_112; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__102 any = A_arbace_cpp_codegen_fn_sig_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_cpp_codegen_fn_sig_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_690, true, nil); A_arbace_cpp_codegen_fn_sig_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__102, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_113)); return A_arbace_cpp_codegen__init_part0_A_const_112 }






func A_arbace_cpp_codegen__init_part0_A_Unit60__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(334, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_45; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_114)); return A_arbace_cpp_codegen__init_part0_A_const_45 }
//line :334:1
func A_arbace_cpp_codegen__init_part0_A_Unit61__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(334, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_115)); return A_arbace_cpp_codegen__init_part0_A_const_43 }
//line :334:1
func A_arbace_cpp_codegen__init_part0_A_Unit62__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(334, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_53; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_116)); return A_arbace_cpp_codegen__init_part0_A_const_53 }
//line :334:1
func A_arbace_cpp_codegen__init_part0_A_Unit63__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(334, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_80; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_117)); return A_arbace_cpp_codegen__init_part0_A_const_80 }

func A_arbace_cpp_codegen__init_part0_A_Unit64__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(336, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_118; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_cpp_codegen_coerce_out_BANG__A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_cpp_codegen_coerce_out_BANG__A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_691, false, nil); A_arbace_cpp_codegen_coerce_out_BANG__A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_119)); return A_arbace_cpp_codegen__init_part0_A_const_118 }









func A_arbace_cpp_codegen__init_part0_A_Unit65__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(346, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_120; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_cpp_codegen_coerce_in_BANG__A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_cpp_codegen_coerce_in_BANG__A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_692, false, nil); A_arbace_cpp_codegen_coerce_in_BANG__A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_121)); return A_arbace_cpp_codegen__init_part0_A_const_120 }








func A_arbace_cpp_codegen__init_part0_A_Unit66__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(355, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_122; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_123)); return A_arbace_cpp_codegen__init_part0_A_const_122 }

func A_arbace_cpp_codegen__init_part0_A_Unit67__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(357, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_124; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_cpp_codegen_extern_inst_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_cpp_codegen_extern_inst_QMARK__A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_693, false, nil); A_arbace_cpp_codegen_extern_inst_QMARK__A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_125)); return A_arbace_cpp_codegen__init_part0_A_const_124 }














func A_arbace_cpp_codegen__init_part0_A_Unit68__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(372, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_126; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__110 any = A_arbace_cpp_codegen_want_fn_BANG__A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_cpp_codegen_want_fn_BANG__A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_694, true, nil); A_arbace_cpp_codegen_want_fn_BANG__A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__110, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_127)); return A_arbace_cpp_codegen__init_part0_A_const_126 }


















func A_arbace_cpp_codegen__init_part0_A_Unit69__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(391, 1); A_arbace_cpp_codegen__init_part0_A_const_128.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_128; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_129)); return A_arbace_cpp_codegen__init_part0_A_const_128.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_codegen__init_part0_A_Unit70__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(392, 1); A_arbace_cpp_codegen__init_part0_A_const_130.BindRoot_O__V(A_arbace_cpp_codegen__init_part0_A_const_131); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_130; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_132)); return A_arbace_cpp_codegen__init_part0_A_const_130.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_codegen__init_part0_A_Unit71__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(393, 1); A_arbace_cpp_codegen__init_part0_A_const_133.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_133; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_134)); return A_arbace_cpp_codegen__init_part0_A_const_133.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_codegen__init_part0_A_Unit72__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(394, 1); A_arbace_cpp_codegen__init_part0_A_const_135.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_135; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_136)); return A_arbace_cpp_codegen__init_part0_A_const_135.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_codegen__init_part0_A_Unit73__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(396, 1); A_arbace_cpp_codegen__init_part0_A_const_137.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_137; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_138)); return A_arbace_cpp_codegen__init_part0_A_const_137.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_codegen__init_part0_A_Unit74__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(397, 1); A_arbace_cpp_codegen__init_part0_A_const_139.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_139; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_140)); return A_arbace_cpp_codegen__init_part0_A_const_139.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_codegen__init_part0_A_Unit75__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(398, 1); A_arbace_cpp_codegen__init_part0_A_const_141.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_141; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_142)); return A_arbace_cpp_codegen__init_part0_A_const_141.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_codegen__init_part0_A_Unit76__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(399, 1); A_arbace_cpp_codegen__init_part0_A_const_143.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_143; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_144)); return A_arbace_cpp_codegen__init_part0_A_const_143.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_codegen__init_part0_A_Unit77__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(401, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_145; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_cpp_codegen_extend_root_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_cpp_codegen_extend_root_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_695, false, nil); A_arbace_cpp_codegen_extend_root_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_146)); return A_arbace_cpp_codegen__init_part0_A_const_145 }













func A_arbace_cpp_codegen__init_part0_A_Unit78__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_147; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_148)); return A_arbace_cpp_codegen__init_part0_A_const_147 }
//line :415:1
func A_arbace_cpp_codegen__init_part0_A_Unit79__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_149; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_150)); return A_arbace_cpp_codegen__init_part0_A_const_149 }
//line :415:1
func A_arbace_cpp_codegen__init_part0_A_Unit80__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_151; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_152)); return A_arbace_cpp_codegen__init_part0_A_const_151 }
//line :415:1
func A_arbace_cpp_codegen__init_part0_A_Unit81__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_153; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_154)); return A_arbace_cpp_codegen__init_part0_A_const_153 }
//line :415:1
func A_arbace_cpp_codegen__init_part0_A_Unit82__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_155; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_156)); return A_arbace_cpp_codegen__init_part0_A_const_155 }
//line :415:1
func A_arbace_cpp_codegen__init_part0_A_Unit83__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_157; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_158)); return A_arbace_cpp_codegen__init_part0_A_const_157 }
//line :415:1
func A_arbace_cpp_codegen__init_part0_A_Unit84__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(415, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_159; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_160)); return A_arbace_cpp_codegen__init_part0_A_const_159 }

func A_arbace_cpp_codegen__init_part0_A_Unit85__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(417, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_161; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_cpp_codegen_nontrivial_dtor_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_cpp_codegen_nontrivial_dtor_QMARK__A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_696, false, nil); A_arbace_cpp_codegen_nontrivial_dtor_QMARK__A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_162)); return A_arbace_cpp_codegen__init_part0_A_const_161 }

func A_arbace_cpp_codegen__init_part0_A_Unit86__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(419, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_163; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_164)); return A_arbace_cpp_codegen__init_part0_A_const_163 }

func A_arbace_cpp_codegen__init_part0_A_Unit87__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(421, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_165; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_cpp_codegen_run_cleanup_BANG__A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_cpp_codegen_run_cleanup_BANG__A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_697, false, nil); A_arbace_cpp_codegen_run_cleanup_BANG__A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_166)); return A_arbace_cpp_codegen__init_part0_A_const_165 }


















func A_arbace_cpp_codegen__init_part0_A_Unit88__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(440, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_167; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_cpp_codegen_push_temp_cleanup_BANG__A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_cpp_codegen_push_temp_cleanup_BANG__A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_698, false, nil); A_arbace_cpp_codegen_push_temp_cleanup_BANG__A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_168)); return A_arbace_cpp_codegen__init_part0_A_const_167 }










func A_arbace_cpp_codegen__init_part0_A_Unit89__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(451, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_169; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__120 any = A_arbace_cpp_codegen_with_full_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_cpp_codegen_with_full_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_699, true, nil); A_arbace_cpp_codegen_with_full_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__120, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_170)); return A_arbace_cpp_codegen__init_part0_A_const_169 }
//line :451:1
func A_arbace_cpp_codegen__init_part0_A_Unit90__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(451, 1); A_arbace_cpp_codegen__init_part0_A_const_169.SetMacro__V(); return nil }
//line :451:1
func A_arbace_cpp_codegen__init_part0_A_Unit91__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(451, 1); return A_arbace_cpp_codegen__init_part0_A_const_169 }
















func A_arbace_cpp_codegen__init_part0_A_Unit92__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(468, 1); A_arbace_cpp_codegen__init_part0_A_const_171.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_171; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_172)); return A_arbace_cpp_codegen__init_part0_A_const_171.SetDynamic_Z__Var(true).Ref() }
func A_arbace_cpp_codegen__init_part0_A_Unit93__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(469, 1); A_arbace_cpp_codegen__init_part0_A_const_173.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_173; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_174)); return A_arbace_cpp_codegen__init_part0_A_const_173.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_codegen__init_part0_A_Unit94__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(471, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_175; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_cpp_codegen_eh_state_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_cpp_codegen_eh_state_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_700, false, nil); A_arbace_cpp_codegen_eh_state_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_175; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_176)); return A_arbace_cpp_codegen__init_part0_A_const_175 }

func A_arbace_cpp_codegen__init_part0_A_Unit95__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(473, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_177; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_cpp_codegen_pad_plan_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_cpp_codegen_pad_plan_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_701, false, nil); A_arbace_cpp_codegen_pad_plan_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_177; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_178)); return A_arbace_cpp_codegen__init_part0_A_const_177 }













func A_arbace_cpp_codegen__init_part0_A_Unit96__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(487, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_179; var tmp2 *lang.Compiler_AOTFn; var fnbody__126 any = A_arbace_cpp_codegen_eh_slots_BANG__A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_cpp_codegen_eh_slots_BANG__A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_702, false, nil); A_arbace_cpp_codegen_eh_slots_BANG__A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__126, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_179; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_180)); return A_arbace_cpp_codegen__init_part0_A_const_179 }


func A_arbace_cpp_codegen__init_part0_A_Unit97__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(490, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_181; var tmp2 *lang.Compiler_AOTFn; var fnbody__128 any = A_arbace_cpp_codegen_run_cleanup_eh_BANG__A_New(); var tmp3 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_cpp_codegen_run_cleanup_eh_BANG__A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_703, false, nil); A_arbace_cpp_codegen_run_cleanup_eh_BANG__A_fn_class = fncls__127d; tmp3 = fncls__127d } else { tmp3 = fncls__127 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__128, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_181; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_182)); return A_arbace_cpp_codegen__init_part0_A_const_181 }










func A_arbace_cpp_codegen__init_part0_A_Unit98__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(501, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_183; var tmp2 *lang.Compiler_AOTFn; var fnbody__130 any = A_arbace_cpp_codegen_clang_call_terminate_BANG__A_New(); var tmp3 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_cpp_codegen_clang_call_terminate_BANG__A_fn_class; if fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_704, false, nil); A_arbace_cpp_codegen_clang_call_terminate_BANG__A_fn_class = fncls__129d; tmp3 = fncls__129d } else { tmp3 = fncls__129 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__130, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_183; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_184)); return A_arbace_cpp_codegen__init_part0_A_const_183 }














func A_arbace_cpp_codegen__init_part0_A_Unit99__O() any { A_arbace_cpp_codegen__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(516, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_185; var tmp2 *lang.Compiler_AOTFn; var fnbody__132 any = A_arbace_cpp_codegen_eh_walk_BANG__A_New(); var tmp3 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_cpp_codegen_eh_walk_BANG__A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_705, false, nil); A_arbace_cpp_codegen_eh_walk_BANG__A_fn_class = fncls__131d; tmp3 = fncls__131d } else { tmp3 = fncls__131 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__132, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part0_A_const_185; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part0_A_const_186)); return A_arbace_cpp_codegen__init_part0_A_const_185 }















































func A_arbace_cpp_codegen__init_part1_A_Unit100__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(564, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_cpp_codegen_landing_pad_BANG__A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_cpp_codegen_landing_pad_BANG__A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_707, false, nil); A_arbace_cpp_codegen_landing_pad_BANG__A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_1)); return A_arbace_cpp_codegen__init_part1_A_const_0 }
//line :564:1
func A_arbace_cpp_codegen__init_part1_A_Init__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); return nil }
//line :564:1
func A_arbace_cpp_codegen__init_part1_A_Load__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); A_arbace_cpp_codegen__init_part1_A_Unit100__O(); A_arbace_cpp_codegen__init_part1_A_Unit101__O(); A_arbace_cpp_codegen__init_part1_A_Unit102__O(); A_arbace_cpp_codegen__init_part1_A_Unit103__O(); A_arbace_cpp_codegen__init_part1_A_Unit104__O(); A_arbace_cpp_codegen__init_part1_A_Unit105__O(); A_arbace_cpp_codegen__init_part1_A_Unit106__O(); A_arbace_cpp_codegen__init_part1_A_Unit107__O(); A_arbace_cpp_codegen__init_part1_A_Unit108__O(); A_arbace_cpp_codegen__init_part1_A_Unit109__O(); A_arbace_cpp_codegen__init_part1_A_Unit110__O(); A_arbace_cpp_codegen__init_part1_A_Unit111__O(); A_arbace_cpp_codegen__init_part1_A_Unit112__O(); A_arbace_cpp_codegen__init_part1_A_Unit113__O(); A_arbace_cpp_codegen__init_part1_A_Unit114__O(); A_arbace_cpp_codegen__init_part1_A_Unit115__O(); A_arbace_cpp_codegen__init_part1_A_Unit116__O(); A_arbace_cpp_codegen__init_part1_A_Unit117__O(); A_arbace_cpp_codegen__init_part1_A_Unit118__O(); A_arbace_cpp_codegen__init_part1_A_Unit119__O(); A_arbace_cpp_codegen__init_part1_A_Unit120__O(); A_arbace_cpp_codegen__init_part1_A_Unit121__O(); A_arbace_cpp_codegen__init_part1_A_Unit122__O(); A_arbace_cpp_codegen__init_part1_A_Unit123__O(); A_arbace_cpp_codegen__init_part1_A_Unit124__O(); A_arbace_cpp_codegen__init_part1_A_Unit125__O(); A_arbace_cpp_codegen__init_part1_A_Unit126__O(); A_arbace_cpp_codegen__init_part1_A_Unit127__O(); A_arbace_cpp_codegen__init_part1_A_Unit128__O(); A_arbace_cpp_codegen__init_part1_A_Unit129__O(); A_arbace_cpp_codegen__init_part1_A_Unit130__O(); A_arbace_cpp_codegen__init_part1_A_Unit131__O(); A_arbace_cpp_codegen__init_part1_A_Unit132__O(); A_arbace_cpp_codegen__init_part1_A_Unit133__O(); A_arbace_cpp_codegen__init_part1_A_Unit134__O(); A_arbace_cpp_codegen__init_part1_A_Unit135__O(); A_arbace_cpp_codegen__init_part1_A_Unit136__O(); A_arbace_cpp_codegen__init_part1_A_Unit137__O(); A_arbace_cpp_codegen__init_part1_A_Unit138__O(); A_arbace_cpp_codegen__init_part1_A_Unit139__O(); A_arbace_cpp_codegen__init_part1_A_Unit140__O(); A_arbace_cpp_codegen__init_part1_A_Unit141__O(); A_arbace_cpp_codegen__init_part1_A_Unit142__O(); A_arbace_cpp_codegen__init_part1_A_Unit143__O(); A_arbace_cpp_codegen__init_part1_A_Unit144__O(); A_arbace_cpp_codegen__init_part1_A_Unit145__O(); A_arbace_cpp_codegen__init_part1_A_Unit146__O(); A_arbace_cpp_codegen__init_part1_A_Unit147__O(); A_arbace_cpp_codegen__init_part1_A_Unit148__O(); A_arbace_cpp_codegen__init_part1_A_Unit149__O(); A_arbace_cpp_codegen__init_part1_A_Unit150__O(); A_arbace_cpp_codegen__init_part1_A_Unit151__O(); A_arbace_cpp_codegen__init_part1_A_Unit152__O(); A_arbace_cpp_codegen__init_part1_A_Unit153__O(); A_arbace_cpp_codegen__init_part1_A_Unit154__O(); A_arbace_cpp_codegen__init_part1_A_Unit155__O(); A_arbace_cpp_codegen__init_part1_A_Unit156__O(); A_arbace_cpp_codegen__init_part1_A_Unit157__O(); A_arbace_cpp_codegen__init_part1_A_Unit158__O(); A_arbace_cpp_codegen__init_part1_A_Unit159__O(); A_arbace_cpp_codegen__init_part1_A_Unit160__O(); A_arbace_cpp_codegen__init_part1_A_Unit161__O(); A_arbace_cpp_codegen__init_part1_A_Unit162__O(); A_arbace_cpp_codegen__init_part1_A_Unit163__O(); A_arbace_cpp_codegen__init_part1_A_Unit164__O(); A_arbace_cpp_codegen__init_part1_A_Unit165__O(); A_arbace_cpp_codegen__init_part1_A_Unit166__O(); A_arbace_cpp_codegen__init_part1_A_Unit167__O(); A_arbace_cpp_codegen__init_part1_A_Unit168__O(); A_arbace_cpp_codegen__init_part1_A_Unit169__O(); A_arbace_cpp_codegen__init_part1_A_Unit170__O(); A_arbace_cpp_codegen__init_part1_A_Unit171__O(); A_arbace_cpp_codegen__init_part1_A_Unit172__O(); A_arbace_cpp_codegen__init_part1_A_Unit173__O(); A_arbace_cpp_codegen__init_part1_A_Unit174__O(); A_arbace_cpp_codegen__init_part1_A_Unit175__O(); A_arbace_cpp_codegen__init_part1_A_Unit176__O(); A_arbace_cpp_codegen__init_part1_A_Unit177__O(); A_arbace_cpp_codegen__init_part1_A_Unit178__O(); A_arbace_cpp_codegen__init_part1_A_Unit179__O(); A_arbace_cpp_codegen__init_part1_A_Unit180__O(); A_arbace_cpp_codegen__init_part1_A_Unit181__O(); A_arbace_cpp_codegen__init_part1_A_Unit182__O(); A_arbace_cpp_codegen__init_part1_A_Unit183__O(); A_arbace_cpp_codegen__init_part1_A_Unit184__O(); A_arbace_cpp_codegen__init_part1_A_Unit185__O(); A_arbace_cpp_codegen__init_part1_A_Unit186__O(); A_arbace_cpp_codegen__init_part1_A_Unit187__O(); A_arbace_cpp_codegen__init_part1_A_Unit188__O(); A_arbace_cpp_codegen__init_part1_A_Unit189__O(); A_arbace_cpp_codegen__init_part1_A_Unit190__O(); A_arbace_cpp_codegen__init_part1_A_Unit191__O(); A_arbace_cpp_codegen__init_part1_A_Unit192__O(); A_arbace_cpp_codegen__init_part1_A_Unit193__O(); A_arbace_cpp_codegen__init_part1_A_Unit194__O(); A_arbace_cpp_codegen__init_part1_A_Unit195__O(); A_arbace_cpp_codegen__init_part1_A_Unit196__O(); A_arbace_cpp_codegen__init_part1_A_Unit197__O(); A_arbace_cpp_codegen__init_part1_A_Unit198__O(); A_arbace_cpp_codegen__init_part1_A_Unit199__O(); return nil }























func A_arbace_cpp_codegen__init_part1_A_Unit101__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(588, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_cpp_codegen_call_insn_BANG__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_cpp_codegen_call_insn_BANG__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_708, false, nil); A_arbace_cpp_codegen_call_insn_BANG__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_3)); return A_arbace_cpp_codegen__init_part1_A_const_2 }












func A_arbace_cpp_codegen__init_part1_A_Unit102__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(601, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_cpp_codegen_nothrow_fn_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_cpp_codegen_nothrow_fn_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_709, false, nil); A_arbace_cpp_codegen_nothrow_fn_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_5)); return A_arbace_cpp_codegen__init_part1_A_const_4 }




func A_arbace_cpp_codegen__init_part1_A_Unit103__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(606, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_cpp_codegen_vtable_index_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_cpp_codegen_vtable_index_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_710, false, nil); A_arbace_cpp_codegen_vtable_index_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_7)); return A_arbace_cpp_codegen__init_part1_A_const_6 }




func A_arbace_cpp_codegen__init_part1_A_Unit104__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(611, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_cpp_codegen_arg_values_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_cpp_codegen_arg_values_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_711, false, nil); A_arbace_cpp_codegen_arg_values_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_9)); return A_arbace_cpp_codegen__init_part1_A_const_8 }



























func A_arbace_cpp_codegen__init_part1_A_Unit105__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(639, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_cpp_codegen_vcall_target_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_cpp_codegen_vcall_target_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_712, false, nil); A_arbace_cpp_codegen_vcall_target_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_11)); return A_arbace_cpp_codegen__init_part1_A_const_10 }




func A_arbace_cpp_codegen__init_part1_A_Unit106__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(644, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_12; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__14 any = A_arbace_cpp_codegen_emit_call_BANG__A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_cpp_codegen_emit_call_BANG__A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_713, true, nil); A_arbace_cpp_codegen_emit_call_BANG__A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__14, tmp3, nil, 8); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_13)); return A_arbace_cpp_codegen__init_part1_A_const_12 }



































func A_arbace_cpp_codegen__init_part1_A_Unit107__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(680, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_cpp_codegen_call_BANG__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_cpp_codegen_call_BANG__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_714, false, nil); A_arbace_cpp_codegen_call_BANG__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_15)); return A_arbace_cpp_codegen__init_part1_A_const_14 }



























func A_arbace_cpp_codegen__init_part1_A_Unit108__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(708, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_16; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__18 any = A_arbace_cpp_codegen_call_dtor_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_cpp_codegen_call_dtor_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_715, true, nil); A_arbace_cpp_codegen_call_dtor_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__18, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_17)); return A_arbace_cpp_codegen__init_part1_A_const_16 }







func A_arbace_cpp_codegen__init_part1_A_Unit109__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(716, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_cpp_codegen_mcall_BANG__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_cpp_codegen_mcall_BANG__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_716, false, nil); A_arbace_cpp_codegen_mcall_BANG__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_19)); return A_arbace_cpp_codegen__init_part1_A_const_18 }























func A_arbace_cpp_codegen__init_part1_A_Unit110__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(740, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_cpp_codegen_icall_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_cpp_codegen_icall_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_717, false, nil); A_arbace_cpp_codegen_icall_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_21)); return A_arbace_cpp_codegen__init_part1_A_const_20 }







func A_arbace_cpp_codegen__init_part1_A_Unit111__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(748, 1); A_arbace_cpp_codegen__init_part1_A_const_22.BindRoot_O__V(jrt.Boolean_FALSE.Ref()); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_23)); return A_arbace_cpp_codegen__init_part1_A_const_22.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_codegen__init_part1_A_Unit112__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(750, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_cpp_codegen_tls_wrapper_name_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_cpp_codegen_tls_wrapper_name_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_718, false, nil); A_arbace_cpp_codegen_tls_wrapper_name_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_25)); return A_arbace_cpp_codegen__init_part1_A_const_24 }




func A_arbace_cpp_codegen__init_part1_A_Unit113__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(755, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_cpp_codegen_tls_internal_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_cpp_codegen_tls_internal_QMARK__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_719, false, nil); A_arbace_cpp_codegen_tls_internal_QMARK__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_27)); return A_arbace_cpp_codegen__init_part1_A_const_26 }










func A_arbace_cpp_codegen__init_part1_A_Unit114__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(766, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_cpp_codegen_tls_defined_here_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_cpp_codegen_tls_defined_here_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_720, false, nil); A_arbace_cpp_codegen_tls_defined_here_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_29)); return A_arbace_cpp_codegen__init_part1_A_const_28 }













func A_arbace_cpp_codegen__init_part1_A_Unit115__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(780, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_cpp_codegen_tls_wrapped_elsewhere_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_cpp_codegen_tls_wrapped_elsewhere_QMARK__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_721, false, nil); A_arbace_cpp_codegen_tls_wrapped_elsewhere_QMARK__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_31)); return A_arbace_cpp_codegen__init_part1_A_const_30 }










func A_arbace_cpp_codegen__init_part1_A_Unit116__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(791, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_cpp_codegen_tls_via_wrapper_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_cpp_codegen_tls_via_wrapper_QMARK__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_722, false, nil); A_arbace_cpp_codegen_tls_via_wrapper_QMARK__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_33)); return A_arbace_cpp_codegen__init_part1_A_const_32 }







func A_arbace_cpp_codegen__init_part1_A_Unit117__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(799, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_cpp_codegen_tls_wrapper_ret_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_cpp_codegen_tls_wrapper_ret_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_723, false, nil); A_arbace_cpp_codegen_tls_wrapper_ret_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_35)); return A_arbace_cpp_codegen__init_part1_A_const_34 }









func A_arbace_cpp_codegen__init_part1_A_Unit118__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(809, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_cpp_codegen_extern_tls_wrapper_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_cpp_codegen_extern_tls_wrapper_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_724, false, nil); A_arbace_cpp_codegen_extern_tls_wrapper_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_37)); return A_arbace_cpp_codegen__init_part1_A_const_36 }























func A_arbace_cpp_codegen__init_part1_A_Unit119__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(833, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_cpp_codegen_var_addr_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_cpp_codegen_var_addr_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_725, false, nil); A_arbace_cpp_codegen_var_addr_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_39)); return A_arbace_cpp_codegen__init_part1_A_const_38 }
































func A_arbace_cpp_codegen__init_part1_A_Unit120__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(866, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_cpp_codegen_base_offset_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_cpp_codegen_base_offset_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_726, false, nil); A_arbace_cpp_codegen_base_offset_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_41)); return A_arbace_cpp_codegen__init_part1_A_const_40 }

func A_arbace_cpp_codegen__init_part1_A_Unit121__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(868, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_42; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_43)); return A_arbace_cpp_codegen__init_part1_A_const_42 }

func A_arbace_cpp_codegen__init_part1_A_Unit122__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(870, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_cpp_codegen_base_addr_BANG__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_cpp_codegen_base_addr_BANG__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_727, false, nil); A_arbace_cpp_codegen_base_addr_BANG__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_45)); return A_arbace_cpp_codegen__init_part1_A_const_44 }





func A_arbace_cpp_codegen__init_part1_A_Unit123__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(876, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_46; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_cpp_codegen_int_op_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_cpp_codegen_int_op_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_728, false, nil); A_arbace_cpp_codegen_int_op_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_47)); return A_arbace_cpp_codegen__init_part1_A_const_46 }


func A_arbace_cpp_codegen__init_part1_A_Unit124__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(879, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_48; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_cpp_codegen_fp_op_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_cpp_codegen_fp_op_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_729, false, nil); A_arbace_cpp_codegen_fp_op_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_49)); return A_arbace_cpp_codegen__init_part1_A_const_48 }

func A_arbace_cpp_codegen__init_part1_A_Unit125__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(881, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_cpp_codegen_arith_BANG__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_cpp_codegen_arith_BANG__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_730, false, nil); A_arbace_cpp_codegen_arith_BANG__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_51)); return A_arbace_cpp_codegen__init_part1_A_const_50 }






func A_arbace_cpp_codegen__init_part1_A_Unit126__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(888, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_cpp_codegen_cmp_BANG__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_cpp_codegen_cmp_BANG__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_731, false, nil); A_arbace_cpp_codegen_cmp_BANG__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_53)); return A_arbace_cpp_codegen__init_part1_A_const_52 }






func A_arbace_cpp_codegen__init_part1_A_Unit127__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(895, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_cpp_codegen_pow2_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_cpp_codegen_pow2_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_732, false, nil); A_arbace_cpp_codegen_pow2_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_55)); return A_arbace_cpp_codegen__init_part1_A_const_54 }




func A_arbace_cpp_codegen__init_part1_A_Unit128__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(900, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_cpp_codegen_fp80_hex_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_cpp_codegen_fp80_hex_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_733, false, nil); A_arbace_cpp_codegen_fp80_hex_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_57)); return A_arbace_cpp_codegen__init_part1_A_const_56 }















func A_arbace_cpp_codegen__init_part1_A_Unit129__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(916, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_58; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__56 any = A_arbace_cpp_codegen_fp_const_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_cpp_codegen_fp_const_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_734, true, nil); A_arbace_cpp_codegen_fp_const_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__56, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_59)); return A_arbace_cpp_codegen__init_part1_A_const_58 }







func A_arbace_cpp_codegen__init_part1_A_Unit130__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(924, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_cpp_codegen_int_cast_BANG__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_cpp_codegen_int_cast_BANG__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_735, false, nil); A_arbace_cpp_codegen_int_cast_BANG__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_61)); return A_arbace_cpp_codegen__init_part1_A_const_60 }








func A_arbace_cpp_codegen__init_part1_A_Unit131__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(933, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_cpp_codegen_ptr_adjust_BANG__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_cpp_codegen_ptr_adjust_BANG__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_736, false, nil); A_arbace_cpp_codegen_ptr_adjust_BANG__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_63)); return A_arbace_cpp_codegen__init_part1_A_const_62 }












func A_arbace_cpp_codegen__init_part1_A_Unit132__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(946, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_cpp_codegen_null_guarded_BANG__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_cpp_codegen_null_guarded_BANG__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_737, false, nil); A_arbace_cpp_codegen_null_guarded_BANG__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_65)); return A_arbace_cpp_codegen__init_part1_A_const_64 }










func A_arbace_cpp_codegen__init_part1_A_Unit133__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(957, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_cpp_codegen_dyncast_call_BANG__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_cpp_codegen_dyncast_call_BANG__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_738, false, nil); A_arbace_cpp_codegen_dyncast_call_BANG__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_67)); return A_arbace_cpp_codegen__init_part1_A_const_66 }



func A_arbace_cpp_codegen__init_part1_A_Unit134__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(961, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_cpp_codegen_cast_BANG__A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_cpp_codegen_cast_BANG__A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_739, false, nil); A_arbace_cpp_codegen_cast_BANG__A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_69)); return A_arbace_cpp_codegen__init_part1_A_const_68 }
































func A_arbace_cpp_codegen__init_part1_A_Unit135__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(994, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_cpp_codegen_materialize_BANG__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_cpp_codegen_materialize_BANG__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_740, false, nil); A_arbace_cpp_codegen_materialize_BANG__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_71)); return A_arbace_cpp_codegen__init_part1_A_const_70 }







func A_arbace_cpp_codegen__init_part1_A_Unit136__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1002, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_72; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_73)); return A_arbace_cpp_codegen__init_part1_A_const_72 }
//line :1002:1
func A_arbace_cpp_codegen__init_part1_A_Unit137__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1002, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_74; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_75)); return A_arbace_cpp_codegen__init_part1_A_const_74 }
//line :1002:1
func A_arbace_cpp_codegen__init_part1_A_Unit138__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1002, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_77)); return A_arbace_cpp_codegen__init_part1_A_const_76 }

func A_arbace_cpp_codegen__init_part1_A_Unit139__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1004, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_cpp_codegen_short_circuit_BANG__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_cpp_codegen_short_circuit_BANG__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_741, false, nil); A_arbace_cpp_codegen_short_circuit_BANG__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_79)); return A_arbace_cpp_codegen__init_part1_A_const_78 }







func A_arbace_cpp_codegen__init_part1_A_Unit140__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1012, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_cpp_codegen_short_circuit_branches_BANG__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_cpp_codegen_short_circuit_branches_BANG__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_742, false, nil); A_arbace_cpp_codegen_short_circuit_branches_BANG__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_80)); return A_arbace_cpp_codegen__init_part1_A_const_74 }










func A_arbace_cpp_codegen__init_part1_A_Unit141__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1023, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_cpp_codegen_cond_branches_BANG__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_cpp_codegen_cond_branches_BANG__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_743, false, nil); A_arbace_cpp_codegen_cond_branches_BANG__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_82)); return A_arbace_cpp_codegen__init_part1_A_const_81 }







func A_arbace_cpp_codegen__init_part1_A_Unit142__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1031, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_cpp_codegen_cond_branches2_BANG__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_cpp_codegen_cond_branches2_BANG__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_744, false, nil); A_arbace_cpp_codegen_cond_branches2_BANG__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_83)); return A_arbace_cpp_codegen__init_part1_A_const_76 }










func A_arbace_cpp_codegen__init_part1_A_Unit143__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1042, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_cpp_codegen_va_arg_class_BANG__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_cpp_codegen_va_arg_class_BANG__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_745, false, nil); A_arbace_cpp_codegen_va_arg_class_BANG__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_85)); return A_arbace_cpp_codegen__init_part1_A_const_84 }






















































func A_arbace_cpp_codegen__init_part1_A_Unit144__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1097, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_86; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_87)); return A_arbace_cpp_codegen__init_part1_A_const_86 }
//line :1097:1
func A_arbace_cpp_codegen__init_part1_A_Unit145__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1097, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_88; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_89)); return A_arbace_cpp_codegen__init_part1_A_const_88 }
//line :1097:1
func A_arbace_cpp_codegen__init_part1_A_Unit146__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1097, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_91)); return A_arbace_cpp_codegen__init_part1_A_const_90 }

func A_arbace_cpp_codegen__init_part1_A_Unit147__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1099, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_92; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_cpp_codegen_stmt_expr_BANG__A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_cpp_codegen_stmt_expr_BANG__A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_746, false, nil); A_arbace_cpp_codegen_stmt_expr_BANG__A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_93)); return A_arbace_cpp_codegen__init_part1_A_const_92 }











func A_arbace_cpp_codegen__init_part1_A_Unit148__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1111, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_94; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_cpp_codegen_bind_opaque_BANG__A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_cpp_codegen_bind_opaque_BANG__A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_747, false, nil); A_arbace_cpp_codegen_bind_opaque_BANG__A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_95)); return A_arbace_cpp_codegen__init_part1_A_const_94 }






func A_arbace_cpp_codegen__init_part1_A_Unit149__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1118, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_96; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_cpp_codegen_opaque_of_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_cpp_codegen_opaque_of_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_748, false, nil); A_arbace_cpp_codegen_opaque_of_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_97)); return A_arbace_cpp_codegen__init_part1_A_const_96 }

func A_arbace_cpp_codegen__init_part1_A_Unit150__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1120, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_98; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_cpp_codegen_incdec_BANG__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_cpp_codegen_incdec_BANG__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_749, false, nil); A_arbace_cpp_codegen_incdec_BANG__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_99)); return A_arbace_cpp_codegen__init_part1_A_const_98 }









func A_arbace_cpp_codegen__init_part1_A_Unit151__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1130, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_100; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_101)); return A_arbace_cpp_codegen__init_part1_A_const_100 }

func A_arbace_cpp_codegen__init_part1_A_Unit152__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1132, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_102; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_cpp_codegen_place_values_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_cpp_codegen_place_values_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_750, false, nil); A_arbace_cpp_codegen_place_values_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_103)); return A_arbace_cpp_codegen__init_part1_A_const_102 }






func A_arbace_cpp_codegen__init_part1_A_Unit153__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1139, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_104; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_cpp_codegen_alloc_call_BANG__A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_cpp_codegen_alloc_call_BANG__A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_751, false, nil); A_arbace_cpp_codegen_alloc_call_BANG__A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_105)); return A_arbace_cpp_codegen__init_part1_A_const_104 }













func A_arbace_cpp_codegen__init_part1_A_Unit154__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1153, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_106; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_cpp_codegen_dealloc_call_BANG__A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_cpp_codegen_dealloc_call_BANG__A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_752, false, nil); A_arbace_cpp_codegen_dealloc_call_BANG__A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_107)); return A_arbace_cpp_codegen__init_part1_A_const_106 }

















func A_arbace_cpp_codegen__init_part1_A_Unit155__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1171, 1); A_arbace_cpp_codegen__init_part1_A_const_108.BindRoot_O__V(A_arbace_cpp_codegen__init_part1_A_const_109); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_108; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_110)); return A_arbace_cpp_codegen__init_part1_A_const_108 }

func A_arbace_cpp_codegen__init_part1_A_Unit156__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1173, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_cpp_codegen_atomic_ord_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_cpp_codegen_atomic_ord_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_753, false, nil); A_arbace_cpp_codegen_atomic_ord_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_112)); return A_arbace_cpp_codegen__init_part1_A_const_111 }










func A_arbace_cpp_codegen__init_part1_A_Unit157__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1184, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_cpp_codegen_by_order_BANG__A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_cpp_codegen_by_order_BANG__A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_754, false, nil); A_arbace_cpp_codegen_by_order_BANG__A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_114)); return A_arbace_cpp_codegen__init_part1_A_const_113 }
















func A_arbace_cpp_codegen__init_part1_A_Unit158__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1201, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_cpp_codegen_cmpxchg_fail_ord_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_cpp_codegen_cmpxchg_fail_ord_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_755, false, nil); A_arbace_cpp_codegen_cmpxchg_fail_ord_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_116)); return A_arbace_cpp_codegen__init_part1_A_const_115 }


func A_arbace_cpp_codegen__init_part1_A_Unit159__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1204, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_cpp_codegen_mem_val_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_cpp_codegen_mem_val_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_756, false, nil); A_arbace_cpp_codegen_mem_val_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_118)); return A_arbace_cpp_codegen__init_part1_A_const_117 }




func A_arbace_cpp_codegen__init_part1_A_Unit160__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1209, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_cpp_codegen_occupied_bytes_BANG__A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_cpp_codegen_occupied_bytes_BANG__A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_757, false, nil); A_arbace_cpp_codegen_occupied_bytes_BANG__A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_120)); return A_arbace_cpp_codegen__init_part1_A_const_119 }



















func A_arbace_cpp_codegen__init_part1_A_Unit161__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1229, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_cpp_codegen_emit_clear_padding_BANG__A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_cpp_codegen_emit_clear_padding_BANG__A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_758, false, nil); A_arbace_cpp_codegen_emit_clear_padding_BANG__A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_122)); return A_arbace_cpp_codegen__init_part1_A_const_121 }















func A_arbace_cpp_codegen__init_part1_A_Unit162__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1245, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_cpp_codegen_emit_fence_BANG__A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_cpp_codegen_emit_fence_BANG__A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_759, false, nil); A_arbace_cpp_codegen_emit_fence_BANG__A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_124)); return A_arbace_cpp_codegen__init_part1_A_const_123 }

















func A_arbace_cpp_codegen__init_part1_A_Unit163__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1263, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_cpp_codegen_emit_atomic_BANG__A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_cpp_codegen_emit_atomic_BANG__A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_760, false, nil); A_arbace_cpp_codegen_emit_atomic_BANG__A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_126)); return A_arbace_cpp_codegen__init_part1_A_const_125 }
















































































func A_arbace_cpp_codegen__init_part1_A_Unit164__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1344, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_cpp_codegen_emit_bitop_BANG__A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_cpp_codegen_emit_bitop_BANG__A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_761, false, nil); A_arbace_cpp_codegen_emit_bitop_BANG__A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_128)); return A_arbace_cpp_codegen__init_part1_A_const_127 }

















func A_arbace_cpp_codegen__init_part1_A_Unit165__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1362, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_100; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_cpp_codegen_emit_rv_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_cpp_codegen_emit_rv_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_762, false, nil); A_arbace_cpp_codegen_emit_rv_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_129)); return A_arbace_cpp_codegen__init_part1_A_const_100 }






















































































































































































































































































func A_arbace_cpp_codegen__init_part1_A_Unit166__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1641, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_130; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_cpp_codegen_emit_lv_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_cpp_codegen_emit_lv_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_763, false, nil); A_arbace_cpp_codegen_emit_lv_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_131)); return A_arbace_cpp_codegen__init_part1_A_const_130 }




























































































func A_arbace_cpp_codegen__init_part1_A_Unit167__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1734, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_codegen__init_part1_A_const_132.GetRawRoot__O()); var tmp2 any = A_arbace_cpp_codegen__init_part1_A_const_100; var tmp3 *lang.Compiler_AOTFn; var fnbody__121 any = A_arbace_cpp_codegen_eval1801000557_fn__1801000558_A_New(); var tmp4 *jrt.Class; var fncls__120 *jrt.Class = A_arbace_cpp_codegen_eval1801000557_fn__1801000558_A_fn_class; if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_764, false, nil); A_arbace_cpp_codegen_eval1801000557_fn__1801000558_A_fn_class = fncls__120d; tmp4 = fncls__120d } else { tmp4 = fncls__120 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__121, tmp4, nil); return tmp1.Invoke_O_O__O(tmp2, tmp3.Ref()) }

func A_arbace_cpp_codegen__init_part1_A_Unit168__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1736, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_133; var tmp2 *lang.Compiler_AOTFn; var fnbody__123 any = A_arbace_cpp_codegen_emit_into_A_New(); var tmp3 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_cpp_codegen_emit_into_A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_765, false, nil); A_arbace_cpp_codegen_emit_into_A_fn_class = fncls__122d; tmp3 = fncls__122d } else { tmp3 = fncls__122 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__123, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_134)); return A_arbace_cpp_codegen__init_part1_A_const_133 }












































func A_arbace_cpp_codegen__init_part1_A_Unit169__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1781, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_135; var tmp2 *lang.Compiler_AOTFn; var fnbody__125 any = A_arbace_cpp_codegen_emit_init_A_New(); var tmp3 *jrt.Class; var fncls__124 *jrt.Class = A_arbace_cpp_codegen_emit_init_A_fn_class; if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_766, false, nil); A_arbace_cpp_codegen_emit_init_A_fn_class = fncls__124d; tmp3 = fncls__124d } else { tmp3 = fncls__124 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__125, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_136)); return A_arbace_cpp_codegen__init_part1_A_const_135 }













































func A_arbace_cpp_codegen__init_part1_A_Unit170__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1827, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_137; var tmp2 *lang.Compiler_AOTFn; var fnbody__127 any = A_arbace_cpp_codegen_push_cleanup_BANG__A_New(); var tmp3 *jrt.Class; var fncls__126 *jrt.Class = A_arbace_cpp_codegen_push_cleanup_BANG__A_fn_class; if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_767, false, nil); A_arbace_cpp_codegen_push_cleanup_BANG__A_fn_class = fncls__126d; tmp3 = fncls__126d } else { tmp3 = fncls__126 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__127, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_138)); return A_arbace_cpp_codegen__init_part1_A_const_137 }
func A_arbace_cpp_codegen__init_part1_A_Unit171__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1828, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_90; var tmp2 *lang.Compiler_AOTFn; var fnbody__129 any = A_arbace_cpp_codegen_cleanup_depth_A_New(); var tmp3 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_cpp_codegen_cleanup_depth_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_768, false, nil); A_arbace_cpp_codegen_cleanup_depth_A_fn_class = fncls__128d; tmp3 = fncls__128d } else { tmp3 = fncls__128 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__129, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_139)); return A_arbace_cpp_codegen__init_part1_A_const_90 }
func A_arbace_cpp_codegen__init_part1_A_Unit172__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1829, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_88; var tmp2 *lang.Compiler_AOTFn; var fnbody__131 any = A_arbace_cpp_codegen_unwind_to_BANG__A_New(); var tmp3 *jrt.Class; var fncls__130 *jrt.Class = A_arbace_cpp_codegen_unwind_to_BANG__A_fn_class; if fncls__130 == nil { var fncls__130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_769, false, nil); A_arbace_cpp_codegen_unwind_to_BANG__A_fn_class = fncls__130d; tmp3 = fncls__130d } else { tmp3 = fncls__130 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__131, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_140)); return A_arbace_cpp_codegen__init_part1_A_const_88 }









func A_arbace_cpp_codegen__init_part1_A_Unit173__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1839, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_141; var tmp2 *lang.Compiler_AOTFn; var fnbody__133 any = A_arbace_cpp_codegen_pop_to_BANG__A_New(); var tmp3 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_cpp_codegen_pop_to_BANG__A_fn_class; if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_770, false, nil); A_arbace_cpp_codegen_pop_to_BANG__A_fn_class = fncls__132d; tmp3 = fncls__132d } else { tmp3 = fncls__132 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__133, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_142)); return A_arbace_cpp_codegen__init_part1_A_const_141 }

func A_arbace_cpp_codegen__init_part1_A_Unit174__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1841, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_86; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_143)); return A_arbace_cpp_codegen__init_part1_A_const_86 }
//line :1841:1
func A_arbace_cpp_codegen__init_part1_A_Unit175__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1841, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_144; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_145)); return A_arbace_cpp_codegen__init_part1_A_const_144 }
//line :1841:1
func A_arbace_cpp_codegen__init_part1_A_Unit176__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1841, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_146; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_147)); return A_arbace_cpp_codegen__init_part1_A_const_146 }
//line :1841:1
func A_arbace_cpp_codegen__init_part1_A_Unit177__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1841, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_148; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_149)); return A_arbace_cpp_codegen__init_part1_A_const_148 }

func A_arbace_cpp_codegen__init_part1_A_Unit178__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1843, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_150; var tmp2 *lang.Compiler_AOTFn; var fnbody__135 any = A_arbace_cpp_codegen_local_decl_BANG__A_New(); var tmp3 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_cpp_codegen_local_decl_BANG__A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_771, false, nil); A_arbace_cpp_codegen_local_decl_BANG__A_fn_class = fncls__134d; tmp3 = fncls__134d } else { tmp3 = fncls__134 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__135, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_151)); return A_arbace_cpp_codegen__init_part1_A_const_150 }















func A_arbace_cpp_codegen__init_part1_A_Unit179__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1859, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_152; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_153)); return A_arbace_cpp_codegen__init_part1_A_const_152 }
//line :1859:1
func A_arbace_cpp_codegen__init_part1_A_Unit180__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1859, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_154; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_155)); return A_arbace_cpp_codegen__init_part1_A_const_154 }

func A_arbace_cpp_codegen__init_part1_A_Unit181__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1861, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_156; var tmp2 *lang.Compiler_AOTFn; var fnbody__137 any = A_arbace_cpp_codegen_static_local_BANG__A_New(); var tmp3 *jrt.Class; var fncls__136 *jrt.Class = A_arbace_cpp_codegen_static_local_BANG__A_fn_class; if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_772, false, nil); A_arbace_cpp_codegen_static_local_BANG__A_fn_class = fncls__136d; tmp3 = fncls__136d } else { tmp3 = fncls__136 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__137, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_156; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_157)); return A_arbace_cpp_codegen__init_part1_A_const_156 }




















































func A_arbace_cpp_codegen__init_part1_A_Unit182__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1914, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_158; var tmp2 *lang.Compiler_AOTFn; var fnbody__139 any = A_arbace_cpp_codegen_emit_return_BANG__A_New(); var tmp3 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_cpp_codegen_emit_return_BANG__A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_773, false, nil); A_arbace_cpp_codegen_emit_return_BANG__A_fn_class = fncls__138d; tmp3 = fncls__138d } else { tmp3 = fncls__138 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__139, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_158; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_159)); return A_arbace_cpp_codegen__init_part1_A_const_158 }













func A_arbace_cpp_codegen__init_part1_A_Unit183__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1928, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_160; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_161)); return A_arbace_cpp_codegen__init_part1_A_const_160 }
//line :1928:1
func A_arbace_cpp_codegen__init_part1_A_Unit184__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1928, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_162; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_163)); return A_arbace_cpp_codegen__init_part1_A_const_162 }

func A_arbace_cpp_codegen__init_part1_A_Unit185__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1930, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__141 any = A_arbace_cpp_codegen_emit_stmt_A_New(); var tmp3 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_cpp_codegen_emit_stmt_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_774, false, nil); A_arbace_cpp_codegen_emit_stmt_A_fn_class = fncls__140d; tmp3 = fncls__140d } else { tmp3 = fncls__140 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__141, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_164)); return A_arbace_cpp_codegen__init_part1_A_const_86 }







func A_arbace_cpp_codegen__init_part1_A_Unit186__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1938, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_162; var tmp2 *lang.Compiler_AOTFn; var fnbody__143 any = A_arbace_cpp_codegen_emit_stmt_STAR__A_New(); var tmp3 *jrt.Class; var fncls__142 *jrt.Class = A_arbace_cpp_codegen_emit_stmt_STAR__A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_775, false, nil); A_arbace_cpp_codegen_emit_stmt_STAR__A_fn_class = fncls__142d; tmp3 = fncls__142d } else { tmp3 = fncls__142 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__143, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_162; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_165)); return A_arbace_cpp_codegen__init_part1_A_const_162 }






















































































func A_arbace_cpp_codegen__init_part1_A_Unit187__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2025, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_146; var tmp2 *lang.Compiler_AOTFn; var fnbody__145 any = A_arbace_cpp_codegen_emit_try_BANG__A_New(); var tmp3 *jrt.Class; var fncls__144 *jrt.Class = A_arbace_cpp_codegen_emit_try_BANG__A_fn_class; if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_776, false, nil); A_arbace_cpp_codegen_emit_try_BANG__A_fn_class = fncls__144d; tmp3 = fncls__144d } else { tmp3 = fncls__144 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__145, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_166)); return A_arbace_cpp_codegen__init_part1_A_const_146 }



























func A_arbace_cpp_codegen__init_part1_A_Unit188__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2053, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_160; var tmp2 *lang.Compiler_AOTFn; var fnbody__147 any = A_arbace_cpp_codegen_contains_label_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__146 *jrt.Class = A_arbace_cpp_codegen_contains_label_QMARK__A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_777, false, nil); A_arbace_cpp_codegen_contains_label_QMARK__A_fn_class = fncls__146d; tmp3 = fncls__146d } else { tmp3 = fncls__146 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__147, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_160; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_167)); return A_arbace_cpp_codegen__init_part1_A_const_160 }












func A_arbace_cpp_codegen__init_part1_A_Unit189__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2066, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__149 any = A_arbace_cpp_codegen_folds_to_A_New(); var tmp3 *jrt.Class; var fncls__148 *jrt.Class = A_arbace_cpp_codegen_folds_to_A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_778, false, nil); A_arbace_cpp_codegen_folds_to_A_fn_class = fncls__148d; tmp3 = fncls__148d } else { tmp3 = fncls__148 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__149, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_168)); return A_arbace_cpp_codegen__init_part1_A_const_72 }




func A_arbace_cpp_codegen__init_part1_A_Unit190__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2071, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_169; var tmp2 *lang.Compiler_AOTFn; var fnbody__151 any = A_arbace_cpp_codegen_emit_if_BANG__A_New(); var tmp3 *jrt.Class; var fncls__150 *jrt.Class = A_arbace_cpp_codegen_emit_if_BANG__A_fn_class; if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_779, false, nil); A_arbace_cpp_codegen_emit_if_BANG__A_fn_class = fncls__150d; tmp3 = fncls__150d } else { tmp3 = fncls__150 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__151, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_170)); return A_arbace_cpp_codegen__init_part1_A_const_169 }







func A_arbace_cpp_codegen__init_part1_A_Unit191__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2079, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_148; var tmp2 *lang.Compiler_AOTFn; var fnbody__153 any = A_arbace_cpp_codegen_emit_if_branches_BANG__A_New(); var tmp3 *jrt.Class; var fncls__152 *jrt.Class = A_arbace_cpp_codegen_emit_if_branches_BANG__A_fn_class; if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_780, false, nil); A_arbace_cpp_codegen_emit_if_branches_BANG__A_fn_class = fncls__152d; tmp3 = fncls__152d } else { tmp3 = fncls__152 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__153, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_171)); return A_arbace_cpp_codegen__init_part1_A_const_148 }















func A_arbace_cpp_codegen__init_part1_A_Unit192__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2095, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_cpp_codegen__init_part1_A_const_132.GetRawRoot__O()); var tmp2 any = A_arbace_cpp_codegen__init_part1_A_const_86; var tmp3 *lang.Compiler_AOTFn; var fnbody__160 any = A_arbace_cpp_codegen_eval1801000859_fn__1801000860_A_New(); var tmp4 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_cpp_codegen_eval1801000859_fn__1801000860_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_781, false, nil); A_arbace_cpp_codegen_eval1801000859_fn__1801000860_A_fn_class = fncls__159d; tmp4 = fncls__159d } else { tmp4 = fncls__159 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__160, tmp4, nil); return tmp1.Invoke_O_O__O(tmp2, tmp3.Ref()) }













func A_arbace_cpp_codegen__init_part1_A_Unit193__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2109, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_172; var tmp2 *lang.Compiler_AOTFn; var fnbody__162 any = A_arbace_cpp_codegen_overrides_fn_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_cpp_codegen_overrides_fn_QMARK__A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_782, false, nil); A_arbace_cpp_codegen_overrides_fn_QMARK__A_fn_class = fncls__161d; tmp3 = fncls__161d } else { tmp3 = fncls__161 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__162, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_172; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_173)); return A_arbace_cpp_codegen__init_part1_A_const_172 }




func A_arbace_cpp_codegen__init_part1_A_Unit194__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2114, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_174; var tmp2 *lang.Compiler_AOTFn; var fnbody__164 any = A_arbace_cpp_codegen_subobjects_A_New(); var tmp3 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_cpp_codegen_subobjects_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_783, false, nil); A_arbace_cpp_codegen_subobjects_A_fn_class = fncls__163d; tmp3 = fncls__163d } else { tmp3 = fncls__163 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__164, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_174; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_175)); return A_arbace_cpp_codegen__init_part1_A_const_174 }














func A_arbace_cpp_codegen__init_part1_A_Unit195__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2129, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_176; var tmp2 *lang.Compiler_AOTFn; var fnbody__166 any = A_arbace_cpp_codegen_contains_sub_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__165 *jrt.Class = A_arbace_cpp_codegen_contains_sub_QMARK__A_fn_class; if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_784, false, nil); A_arbace_cpp_codegen_contains_sub_QMARK__A_fn_class = fncls__165d; tmp3 = fncls__165d } else { tmp3 = fncls__165 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__166, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_176; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_177)); return A_arbace_cpp_codegen__init_part1_A_const_176 }




func A_arbace_cpp_codegen__init_part1_A_Unit196__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2134, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_178; var tmp2 *lang.Compiler_AOTFn; var fnbody__168 any = A_arbace_cpp_codegen_find_sub_A_New(); var tmp3 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_cpp_codegen_find_sub_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_785, false, nil); A_arbace_cpp_codegen_find_sub_A_fn_class = fncls__167d; tmp3 = fncls__167d } else { tmp3 = fncls__167 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__168, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_178; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_179)); return A_arbace_cpp_codegen__init_part1_A_const_178 }

func A_arbace_cpp_codegen__init_part1_A_Unit197__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2136, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_180; var tmp2 *lang.Compiler_AOTFn; var fnbody__170 any = A_arbace_cpp_codegen_final_overrider_A_New(); var tmp3 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_cpp_codegen_final_overrider_A_fn_class; if fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_786, false, nil); A_arbace_cpp_codegen_final_overrider_A_fn_class = fncls__169d; tmp3 = fncls__169d } else { tmp3 = fncls__169 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__170, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_180; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_181)); return A_arbace_cpp_codegen__init_part1_A_const_180 }












func A_arbace_cpp_codegen__init_part1_A_Unit198__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2149, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_182; var tmp2 *lang.Compiler_AOTFn; var fnbody__172 any = A_arbace_cpp_codegen_offset_comps_A_New(); var tmp3 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_cpp_codegen_offset_comps_A_fn_class; if fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_787, false, nil); A_arbace_cpp_codegen_offset_comps_A_fn_class = fncls__171d; tmp3 = fncls__171d } else { tmp3 = fncls__171 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__172, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_182; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_183)); return A_arbace_cpp_codegen__init_part1_A_const_182 }

































func A_arbace_cpp_codegen__init_part1_A_Unit199__O() any { A_arbace_cpp_codegen__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2183, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_184; var tmp2 *lang.Compiler_AOTFn; var fnbody__174 any = A_arbace_cpp_codegen_vbase_offset_offset_A_New(); var tmp3 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_cpp_codegen_vbase_offset_offset_A_fn_class; if fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_788, false, nil); A_arbace_cpp_codegen_vbase_offset_offset_A_fn_class = fncls__173d; tmp3 = fncls__173d } else { tmp3 = fncls__173 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__174, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part1_A_const_184; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part1_A_const_185)); return A_arbace_cpp_codegen__init_part1_A_const_184 }




func A_arbace_cpp_codegen__init_part2_A_Unit200__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2188, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_0; var tmp2 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_cpp_codegen_vbase_addr_BANG__A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_cpp_codegen_vbase_addr_BANG__A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_790, false, nil); A_arbace_cpp_codegen_vbase_addr_BANG__A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_1)); return A_arbace_cpp_codegen__init_part2_A_const_0 }
//line :2188:1
func A_arbace_cpp_codegen__init_part2_A_Init__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); return nil }
//line :2188:1
func A_arbace_cpp_codegen__init_part2_A_Load__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); A_arbace_cpp_codegen__init_part2_A_Unit200__O(); A_arbace_cpp_codegen__init_part2_A_Unit201__O(); A_arbace_cpp_codegen__init_part2_A_Unit202__O(); A_arbace_cpp_codegen__init_part2_A_Unit203__O(); A_arbace_cpp_codegen__init_part2_A_Unit204__O(); A_arbace_cpp_codegen__init_part2_A_Unit205__O(); A_arbace_cpp_codegen__init_part2_A_Unit206__O(); A_arbace_cpp_codegen__init_part2_A_Unit207__O(); A_arbace_cpp_codegen__init_part2_A_Unit208__O(); A_arbace_cpp_codegen__init_part2_A_Unit209__O(); A_arbace_cpp_codegen__init_part2_A_Unit210__O(); A_arbace_cpp_codegen__init_part2_A_Unit211__O(); A_arbace_cpp_codegen__init_part2_A_Unit212__O(); A_arbace_cpp_codegen__init_part2_A_Unit213__O(); A_arbace_cpp_codegen__init_part2_A_Unit214__O(); A_arbace_cpp_codegen__init_part2_A_Unit215__O(); A_arbace_cpp_codegen__init_part2_A_Unit216__O(); A_arbace_cpp_codegen__init_part2_A_Unit217__O(); A_arbace_cpp_codegen__init_part2_A_Unit218__O(); A_arbace_cpp_codegen__init_part2_A_Unit219__O(); A_arbace_cpp_codegen__init_part2_A_Unit220__O(); A_arbace_cpp_codegen__init_part2_A_Unit221__O(); A_arbace_cpp_codegen__init_part2_A_Unit222__O(); A_arbace_cpp_codegen__init_part2_A_Unit223__O(); A_arbace_cpp_codegen__init_part2_A_Unit224__O(); A_arbace_cpp_codegen__init_part2_A_Unit225__O(); A_arbace_cpp_codegen__init_part2_A_Unit226__O(); A_arbace_cpp_codegen__init_part2_A_Unit227__O(); A_arbace_cpp_codegen__init_part2_A_Unit228__O(); A_arbace_cpp_codegen__init_part2_A_Unit229__O(); A_arbace_cpp_codegen__init_part2_A_Unit230__O(); A_arbace_cpp_codegen__init_part2_A_Unit231__O(); A_arbace_cpp_codegen__init_part2_A_Unit232__O(); A_arbace_cpp_codegen__init_part2_A_Unit233__O(); A_arbace_cpp_codegen__init_part2_A_Unit234__O(); A_arbace_cpp_codegen__init_part2_A_Unit235__O(); A_arbace_cpp_codegen__init_part2_A_Unit236__O(); A_arbace_cpp_codegen__init_part2_A_Unit237__O(); A_arbace_cpp_codegen__init_part2_A_Unit238__O(); A_arbace_cpp_codegen__init_part2_A_Unit239__O(); A_arbace_cpp_codegen__init_part2_A_Unit240__O(); A_arbace_cpp_codegen__init_part2_A_Unit241__O(); A_arbace_cpp_codegen__init_part2_A_Unit242__O(); A_arbace_cpp_codegen__init_part2_A_Unit243__O(); A_arbace_cpp_codegen__init_part2_A_Unit244__O(); A_arbace_cpp_codegen__init_part2_A_Unit245__O(); A_arbace_cpp_codegen__init_part2_A_Unit246__O(); A_arbace_cpp_codegen__init_part2_A_Unit247__O(); A_arbace_cpp_codegen__init_part2_A_Unit248__O(); A_arbace_cpp_codegen__init_part2_A_Unit249__O(); A_arbace_cpp_codegen__init_part2_A_Unit250__O(); A_arbace_cpp_codegen__init_part2_A_Unit251__O(); A_arbace_cpp_codegen__init_part2_A_Unit252__O(); return nil }







func A_arbace_cpp_codegen__init_part2_A_Unit201__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2196, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_2; var tmp2 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_cpp_codegen_vcall_offset_offset_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_cpp_codegen_vcall_offset_offset_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_791, false, nil); A_arbace_cpp_codegen_vcall_offset_offset_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_3)); return A_arbace_cpp_codegen__init_part2_A_const_2 }






func A_arbace_cpp_codegen__init_part2_A_Unit202__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2203, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_cpp_codegen_primary_chain_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_cpp_codegen_primary_chain_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_792, false, nil); A_arbace_cpp_codegen_primary_chain_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_5)); return A_arbace_cpp_codegen__init_part2_A_const_4 }

func A_arbace_cpp_codegen__init_part2_A_Unit203__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2205, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_cpp_codegen_return_adjustment_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_cpp_codegen_return_adjustment_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_793, false, nil); A_arbace_cpp_codegen_return_adjustment_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_7)); return A_arbace_cpp_codegen__init_part2_A_const_6 }











func A_arbace_cpp_codegen__init_part2_A_Unit204__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2217, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_cpp_codegen_vt_group_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_cpp_codegen_vt_group_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_794, false, nil); A_arbace_cpp_codegen_vt_group_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_9)); return A_arbace_cpp_codegen__init_part2_A_const_8 }






























































func A_arbace_cpp_codegen__init_part2_A_Unit205__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2280, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_10; var tmp2 any; var root_11 any = A_arbace_cpp_codegen__init_part2_A_const_11.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_11, arg_14) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_10; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_12)); return A_arbace_cpp_codegen__init_part2_A_const_10 }
func A_arbace_cpp_codegen__init_part2_A_Unit206__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2281, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_cpp_codegen_group_of_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_cpp_codegen_group_of_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_795, false, nil); A_arbace_cpp_codegen_group_of_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_14)); return A_arbace_cpp_codegen__init_part2_A_const_13 }



func A_arbace_cpp_codegen__init_part2_A_Unit207__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2285, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_15; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_cpp_codegen_vtable_name_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_cpp_codegen_vtable_name_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_796, false, nil); A_arbace_cpp_codegen_vtable_name_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_16)); return A_arbace_cpp_codegen__init_part2_A_const_15 }
func A_arbace_cpp_codegen__init_part2_A_Unit208__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2286, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_17; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_cpp_codegen_ctor_vtable_name_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_cpp_codegen_ctor_vtable_name_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_797, false, nil); A_arbace_cpp_codegen_ctor_vtable_name_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_18)); return A_arbace_cpp_codegen__init_part2_A_const_17 }

func A_arbace_cpp_codegen__init_part2_A_Unit209__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2288, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_19; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_cpp_codegen_group_name_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_cpp_codegen_group_name_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_798, false, nil); A_arbace_cpp_codegen_group_name_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_19; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_20)); return A_arbace_cpp_codegen__init_part2_A_const_19 }

func A_arbace_cpp_codegen__init_part2_A_Unit210__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2290, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_21; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_cpp_codegen_address_point_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_cpp_codegen_address_point_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_799, false, nil); A_arbace_cpp_codegen_address_point_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_21; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_22)); return A_arbace_cpp_codegen__init_part2_A_const_21 }







func A_arbace_cpp_codegen__init_part2_A_Unit211__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2298, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_23; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_cpp_codegen_vtt_layout_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_cpp_codegen_vtt_layout_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_800, false, nil); A_arbace_cpp_codegen_vtt_layout_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_23; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_24)); return A_arbace_cpp_codegen__init_part2_A_const_23 }



































func A_arbace_cpp_codegen__init_part2_A_Unit212__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2334, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_25; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_cpp_codegen_vtt_name_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_cpp_codegen_vtt_name_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_801, false, nil); A_arbace_cpp_codegen_vtt_name_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_25; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_26)); return A_arbace_cpp_codegen__init_part2_A_const_25 }

func A_arbace_cpp_codegen__init_part2_A_Unit213__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2336, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_cpp_codegen_vtt_ref_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_cpp_codegen_vtt_ref_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_802, false, nil); A_arbace_cpp_codegen_vtt_ref_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_28)); return A_arbace_cpp_codegen__init_part2_A_const_27 }








func A_arbace_cpp_codegen__init_part2_A_Unit214__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2345, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_cpp_codegen_vptr_list_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_cpp_codegen_vptr_list_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_803, false, nil); A_arbace_cpp_codegen_vptr_list_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_30)); return A_arbace_cpp_codegen__init_part2_A_const_29 }















func A_arbace_cpp_codegen__init_part2_A_Unit215__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2361, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_31; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_cpp_codegen_init_vptrs_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_cpp_codegen_init_vptrs_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_804, false, nil); A_arbace_cpp_codegen_init_vptrs_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_31; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_32)); return A_arbace_cpp_codegen__init_part2_A_const_31 }












func A_arbace_cpp_codegen__init_part2_A_Unit216__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2374, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_cpp_codegen_vptr_store_BANG__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_cpp_codegen_vptr_store_BANG__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_805, false, nil); A_arbace_cpp_codegen_vptr_store_BANG__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_34)); return A_arbace_cpp_codegen__init_part2_A_const_33 }

func A_arbace_cpp_codegen__init_part2_A_Unit217__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2376, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_cpp_codegen_trivial_dtor_body_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_cpp_codegen_trivial_dtor_body_QMARK__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_806, false, nil); A_arbace_cpp_codegen_trivial_dtor_body_QMARK__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_36)); return A_arbace_cpp_codegen__init_part2_A_const_35 }










func A_arbace_cpp_codegen__init_part2_A_Unit218__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2387, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_cpp_codegen_want_d0_BANG__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_cpp_codegen_want_d0_BANG__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_807, false, nil); A_arbace_cpp_codegen_want_d0_BANG__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_38)); return A_arbace_cpp_codegen__init_part2_A_const_37 }








func A_arbace_cpp_codegen__init_part2_A_Unit219__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2396, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_cpp_codegen_linkage_of_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_cpp_codegen_linkage_of_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_808, false, nil); A_arbace_cpp_codegen_linkage_of_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_40)); return A_arbace_cpp_codegen__init_part2_A_const_39 }





func A_arbace_cpp_codegen__init_part2_A_Unit220__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2402, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_41; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_cpp_codegen_emit_fn_BANG__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_cpp_codegen_emit_fn_BANG__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_809, false, nil); A_arbace_cpp_codegen_emit_fn_BANG__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_42)); return A_arbace_cpp_codegen__init_part2_A_const_41 }
















































































































































func A_arbace_cpp_codegen__init_part2_A_Unit221__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2547, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_cpp_codegen_emit_d0_BANG__A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_cpp_codegen_emit_d0_BANG__A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_810, false, nil); A_arbace_cpp_codegen_emit_d0_BANG__A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_44)); return A_arbace_cpp_codegen__init_part2_A_const_43 }





















func A_arbace_cpp_codegen__init_part2_A_Unit222__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2569, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_cpp_codegen_key_fn_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_cpp_codegen_key_fn_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_811, false, nil); A_arbace_cpp_codegen_key_fn_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_46)); return A_arbace_cpp_codegen__init_part2_A_const_45 }










func A_arbace_cpp_codegen__init_part2_A_Unit223__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2580, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_cpp_codegen_vtable_home_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_cpp_codegen_vtable_home_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_812, false, nil); A_arbace_cpp_codegen_vtable_home_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_48)); return A_arbace_cpp_codegen__init_part2_A_const_47 }









func A_arbace_cpp_codegen__init_part2_A_Unit224__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2590, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_cpp_codegen_external_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_cpp_codegen_external_class_QMARK__A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_813, false, nil); A_arbace_cpp_codegen_external_class_QMARK__A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_50)); return A_arbace_cpp_codegen__init_part2_A_const_49 }




func A_arbace_cpp_codegen__init_part2_A_Unit225__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2595, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_cpp_codegen_vt_linkage_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_cpp_codegen_vt_linkage_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_814, false, nil); A_arbace_cpp_codegen_vt_linkage_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_52)); return A_arbace_cpp_codegen__init_part2_A_const_51 }




func A_arbace_cpp_codegen__init_part2_A_Unit226__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2600, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_cpp_codegen_typeinfo_BANG__A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_cpp_codegen_typeinfo_BANG__A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_815, false, nil); A_arbace_cpp_codegen_typeinfo_BANG__A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_54)); return A_arbace_cpp_codegen__init_part2_A_const_53 }









































func A_arbace_cpp_codegen__init_part2_A_Unit227__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2642, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_cpp_codegen_thunk_BANG__A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_cpp_codegen_thunk_BANG__A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_816, false, nil); A_arbace_cpp_codegen_thunk_BANG__A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_56)); return A_arbace_cpp_codegen__init_part2_A_const_55 }


















































func A_arbace_cpp_codegen__init_part2_A_Unit228__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2693, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_57; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_58)); return A_arbace_cpp_codegen__init_part2_A_const_57 }

func A_arbace_cpp_codegen__init_part2_A_Unit229__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2695, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_59; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_cpp_codegen_group_BANG__A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_cpp_codegen_group_BANG__A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_817, false, nil); A_arbace_cpp_codegen_group_BANG__A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_59; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_60)); return A_arbace_cpp_codegen__init_part2_A_const_59 }


























func A_arbace_cpp_codegen__init_part2_A_Unit230__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2722, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_cpp_codegen_vtt_BANG__A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_cpp_codegen_vtt_BANG__A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_818, false, nil); A_arbace_cpp_codegen_vtt_BANG__A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_61)); return A_arbace_cpp_codegen__init_part2_A_const_57 }





func A_arbace_cpp_codegen__init_part2_A_Unit231__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2728, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_cpp_codegen_vtable_BANG__A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_cpp_codegen_vtable_BANG__A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_819, false, nil); A_arbace_cpp_codegen_vtable_BANG__A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_63)); return A_arbace_cpp_codegen__init_part2_A_const_62 }

func A_arbace_cpp_codegen__init_part2_A_Unit232__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2730, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_cpp_codegen_abi_class_global_BANG__A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_cpp_codegen_abi_class_global_BANG__A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_820, false, nil); A_arbace_cpp_codegen_abi_class_global_BANG__A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_65)); return A_arbace_cpp_codegen__init_part2_A_const_64 }





func A_arbace_cpp_codegen__init_part2_A_Unit233__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2736, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_cpp_codegen_eh_typeinfo_BANG__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_cpp_codegen_eh_typeinfo_BANG__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_821, false, nil); A_arbace_cpp_codegen_eh_typeinfo_BANG__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_67)); return A_arbace_cpp_codegen__init_part2_A_const_66 }










































func A_arbace_cpp_codegen__init_part2_A_Unit234__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2779, 1); A_arbace_cpp_codegen__init_part2_A_const_68.BindRoot_O__V(jrt.Boolean_TRUE.Ref()); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_68; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_69)); return A_arbace_cpp_codegen__init_part2_A_const_68.SetDynamic_Z__Var(true).Ref() }

func A_arbace_cpp_codegen__init_part2_A_Unit235__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2781, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_cpp_codegen_const_leaves_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_cpp_codegen_const_leaves_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_822, false, nil); A_arbace_cpp_codegen_const_leaves_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_71)); return A_arbace_cpp_codegen__init_part2_A_const_70 }

































































func A_arbace_cpp_codegen__init_part2_A_Unit236__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2847, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_cpp_codegen_leaves_constant_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_cpp_codegen_leaves_constant_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_823, false, nil); A_arbace_cpp_codegen_leaves_constant_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_73)); return A_arbace_cpp_codegen__init_part2_A_const_72 }












func A_arbace_cpp_codegen__init_part2_A_Unit237__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2860, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_cpp_codegen_emit_globals_BANG__A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_cpp_codegen_emit_globals_BANG__A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_824, false, nil); A_arbace_cpp_codegen_emit_globals_BANG__A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_75)); return A_arbace_cpp_codegen__init_part2_A_const_74 }






































































































































func A_arbace_cpp_codegen__init_part2_A_Unit238__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2995, 1); A_arbace_cpp_codegen__init_part2_A_const_76.BindRoot_O__V(A_arbace_cpp_codegen__init_part2_A_const_77); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_78)); return A_arbace_cpp_codegen__init_part2_A_const_76 }

func A_arbace_cpp_codegen__init_part2_A_Unit239__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(2997, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_79; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_cpp_codegen_abstract_class_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_cpp_codegen_abstract_class_QMARK__A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_825, false, nil); A_arbace_cpp_codegen_abstract_class_QMARK__A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_79; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_80)); return A_arbace_cpp_codegen__init_part2_A_const_79 }




func A_arbace_cpp_codegen__init_part2_A_Unit240__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3002, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_81; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_cpp_codegen_fundamental_typeinfos_BANG__A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_cpp_codegen_fundamental_typeinfos_BANG__A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_826, false, nil); A_arbace_cpp_codegen_fundamental_typeinfos_BANG__A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_82)); return A_arbace_cpp_codegen__init_part2_A_const_81 }















func A_arbace_cpp_codegen__init_part2_A_Unit241__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3018, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_83; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_cpp_codegen_gen_module_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_cpp_codegen_gen_module_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_827, false, nil); A_arbace_cpp_codegen_gen_module_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_83; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_84)); return A_arbace_cpp_codegen__init_part2_A_const_83 }

























































































func A_arbace_cpp_codegen__init_part2_A_Unit242__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3108, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_85; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_cpp_codegen_gen_file_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_cpp_codegen_gen_file_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_828, false, nil); A_arbace_cpp_codegen_gen_file_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_85; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_86)); return A_arbace_cpp_codegen__init_part2_A_const_85 }















func A_arbace_cpp_codegen__init_part2_A_Unit243__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3124, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_87; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_cpp_codegen_write_drops_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_cpp_codegen_write_drops_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_829, false, nil); A_arbace_cpp_codegen_write_drops_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_87; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_88)); return A_arbace_cpp_codegen__init_part2_A_const_87 }













func A_arbace_cpp_codegen__init_part2_A_Unit244__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3138, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_89; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__86 any = A_arbace_cpp_codegen_gen_one_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_cpp_codegen_gen_one_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_830, true, nil); A_arbace_cpp_codegen_gen_one_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__86, tmp3, nil, 3); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_89; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_90)); return A_arbace_cpp_codegen__init_part2_A_const_89 }





























func A_arbace_cpp_codegen__init_part2_A_Unit245__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3168, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_91; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_cpp_codegen_defined_names_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_cpp_codegen_defined_names_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_831, false, nil); A_arbace_cpp_codegen_defined_names_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_91; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_92)); return A_arbace_cpp_codegen__init_part2_A_const_91 }










func A_arbace_cpp_codegen__init_part2_A_Unit246__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3179, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_cpp_codegen_slurp_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_cpp_codegen_slurp_QMARK__A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_832, false, nil); A_arbace_cpp_codegen_slurp_QMARK__A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_94)); return A_arbace_cpp_codegen__init_part2_A_const_93 }

func A_arbace_cpp_codegen__init_part2_A_Unit247__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3181, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_cpp_codegen_judge_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_cpp_codegen_judge_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_833, false, nil); A_arbace_cpp_codegen_judge_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_96)); return A_arbace_cpp_codegen__init_part2_A_const_95 }




































func A_arbace_cpp_codegen__init_part2_A_Unit248__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3218, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_cpp_codegen_file_sha256_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_cpp_codegen_file_sha256_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_834, false, nil); A_arbace_cpp_codegen_file_sha256_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_98)); return A_arbace_cpp_codegen__init_part2_A_const_97 }



func A_arbace_cpp_codegen__init_part2_A_Unit249__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3222, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_cpp_codegen_gen_outcome_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_cpp_codegen_gen_outcome_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_835, false, nil); A_arbace_cpp_codegen_gen_outcome_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_100)); return A_arbace_cpp_codegen__init_part2_A_const_99 }






func A_arbace_cpp_codegen__init_part2_A_Unit250__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3229, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_cpp_codegen_read_forms_record_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_cpp_codegen_read_forms_record_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_836, false, nil); A_arbace_cpp_codegen_read_forms_record_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_102)); return A_arbace_cpp_codegen__init_part2_A_const_101 }






func A_arbace_cpp_codegen__init_part2_A_Unit251__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3236, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_cpp_codegen_gen_judge_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_cpp_codegen_gen_judge_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_837, false, nil); A_arbace_cpp_codegen_gen_judge_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_104)); return A_arbace_cpp_codegen__init_part2_A_const_103 }













































func A_arbace_cpp_codegen__init_part2_A_Unit252__O() any { A_arbace_cpp_codegen__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(3282, 1); var tmp1 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_105; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__102 any = A_arbace_cpp_codegen__main_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_cpp_codegen__main_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_838, true, nil); A_arbace_cpp_codegen__main_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__102, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_cpp_codegen__init_part2_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_cpp_codegen__init_part2_A_const_106)); return A_arbace_cpp_codegen__init_part2_A_const_105 }



type A_arbace_cpp_codegen__init_A struct{ jrt.Object }

func A_arbace_cpp_codegen__init_A_New() *A_arbace_cpp_codegen__init_A { t := &A_arbace_cpp_codegen__init_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_codegen__init_A) Ctor() {}

func (t *A_arbace_cpp_codegen__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_codegen__init_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_codegen__init_A_class }

func (t *A_arbace_cpp_codegen__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_codegen__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_codegen__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_codegen__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_codegen__init_A); return ok }

func A_arbace_cpp_codegen__init_A_Cast(x any) *A_arbace_cpp_codegen__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_codegen__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_codegen__init_A_class)) }; return v }



type A_arbace_cpp_codegen__init_part0_A struct{ jrt.Object }

var A_arbace_cpp_codegen__init_part0_A_const_pool *jrt.RefArray

var A_arbace_cpp_codegen__init_part0_A_const_0 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_1 any

var A_arbace_cpp_codegen__init_part0_A_const_2 any

var A_arbace_cpp_codegen__init_part0_A_const_3 any

var A_arbace_cpp_codegen__init_part0_A_const_4 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_5 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_6 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_7 any

var A_arbace_cpp_codegen__init_part0_A_const_8 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_9 any

var A_arbace_cpp_codegen__init_part0_A_const_10 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_11 any

var A_arbace_cpp_codegen__init_part0_A_const_12 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_13 any

var A_arbace_cpp_codegen__init_part0_A_const_14 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_15 any

var A_arbace_cpp_codegen__init_part0_A_const_16 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_17 any

var A_arbace_cpp_codegen__init_part0_A_const_18 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_19 any

var A_arbace_cpp_codegen__init_part0_A_const_20 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_21 any

var A_arbace_cpp_codegen__init_part0_A_const_22 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_23 any

var A_arbace_cpp_codegen__init_part0_A_const_24 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_25 any

var A_arbace_cpp_codegen__init_part0_A_const_26 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_27 any

var A_arbace_cpp_codegen__init_part0_A_const_28 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_29 any

var A_arbace_cpp_codegen__init_part0_A_const_30 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_31 any

var A_arbace_cpp_codegen__init_part0_A_const_32 any

var A_arbace_cpp_codegen__init_part0_A_const_33 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_34 any

var A_arbace_cpp_codegen__init_part0_A_const_35 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_36 any

var A_arbace_cpp_codegen__init_part0_A_const_37 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_38 any

var A_arbace_cpp_codegen__init_part0_A_const_39 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_40 any

var A_arbace_cpp_codegen__init_part0_A_const_41 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_42 any

var A_arbace_cpp_codegen__init_part0_A_const_43 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_44 any

var A_arbace_cpp_codegen__init_part0_A_const_45 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_46 any

var A_arbace_cpp_codegen__init_part0_A_const_47 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_48 any

var A_arbace_cpp_codegen__init_part0_A_const_49 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_50 any

var A_arbace_cpp_codegen__init_part0_A_const_51 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_52 any

var A_arbace_cpp_codegen__init_part0_A_const_53 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_54 any

var A_arbace_cpp_codegen__init_part0_A_const_55 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_56 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_57 any

var A_arbace_cpp_codegen__init_part0_A_const_58 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_59 any

var A_arbace_cpp_codegen__init_part0_A_const_60 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_61 any

var A_arbace_cpp_codegen__init_part0_A_const_62 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_63 any

var A_arbace_cpp_codegen__init_part0_A_const_64 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_65 any

var A_arbace_cpp_codegen__init_part0_A_const_66 any

var A_arbace_cpp_codegen__init_part0_A_const_67 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_68 any

var A_arbace_cpp_codegen__init_part0_A_const_69 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_70 any

var A_arbace_cpp_codegen__init_part0_A_const_71 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_72 any

var A_arbace_cpp_codegen__init_part0_A_const_73 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_74 any

var A_arbace_cpp_codegen__init_part0_A_const_75 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_76 any

var A_arbace_cpp_codegen__init_part0_A_const_77 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_78 any

var A_arbace_cpp_codegen__init_part0_A_const_79 any

var A_arbace_cpp_codegen__init_part0_A_const_80 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_81 any

var A_arbace_cpp_codegen__init_part0_A_const_82 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_83 any

var A_arbace_cpp_codegen__init_part0_A_const_84 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_85 any

var A_arbace_cpp_codegen__init_part0_A_const_86 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_87 any

var A_arbace_cpp_codegen__init_part0_A_const_88 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_89 any

var A_arbace_cpp_codegen__init_part0_A_const_90 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_91 any

var A_arbace_cpp_codegen__init_part0_A_const_92 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_93 any

var A_arbace_cpp_codegen__init_part0_A_const_94 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_95 any

var A_arbace_cpp_codegen__init_part0_A_const_96 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_97 any

var A_arbace_cpp_codegen__init_part0_A_const_98 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_99 any

var A_arbace_cpp_codegen__init_part0_A_const_100 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_101 any

var A_arbace_cpp_codegen__init_part0_A_const_102 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_103 any

var A_arbace_cpp_codegen__init_part0_A_const_104 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_105 any

var A_arbace_cpp_codegen__init_part0_A_const_106 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_107 any

var A_arbace_cpp_codegen__init_part0_A_const_108 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_109 any

var A_arbace_cpp_codegen__init_part0_A_const_110 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_111 any

var A_arbace_cpp_codegen__init_part0_A_const_112 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_113 any

var A_arbace_cpp_codegen__init_part0_A_const_114 any

var A_arbace_cpp_codegen__init_part0_A_const_115 any

var A_arbace_cpp_codegen__init_part0_A_const_116 any

var A_arbace_cpp_codegen__init_part0_A_const_117 any

var A_arbace_cpp_codegen__init_part0_A_const_118 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_119 any

var A_arbace_cpp_codegen__init_part0_A_const_120 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_121 any

var A_arbace_cpp_codegen__init_part0_A_const_122 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_123 any

var A_arbace_cpp_codegen__init_part0_A_const_124 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_125 any

var A_arbace_cpp_codegen__init_part0_A_const_126 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_127 any

var A_arbace_cpp_codegen__init_part0_A_const_128 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_129 any

var A_arbace_cpp_codegen__init_part0_A_const_130 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_131 any

var A_arbace_cpp_codegen__init_part0_A_const_132 any

var A_arbace_cpp_codegen__init_part0_A_const_133 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_134 any

var A_arbace_cpp_codegen__init_part0_A_const_135 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_136 any

var A_arbace_cpp_codegen__init_part0_A_const_137 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_138 any

var A_arbace_cpp_codegen__init_part0_A_const_139 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_140 any

var A_arbace_cpp_codegen__init_part0_A_const_141 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_142 any

var A_arbace_cpp_codegen__init_part0_A_const_143 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_144 any

var A_arbace_cpp_codegen__init_part0_A_const_145 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_146 any

var A_arbace_cpp_codegen__init_part0_A_const_147 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_148 any

var A_arbace_cpp_codegen__init_part0_A_const_149 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_150 any

var A_arbace_cpp_codegen__init_part0_A_const_151 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_152 any

var A_arbace_cpp_codegen__init_part0_A_const_153 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_154 any

var A_arbace_cpp_codegen__init_part0_A_const_155 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_156 any

var A_arbace_cpp_codegen__init_part0_A_const_157 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_158 any

var A_arbace_cpp_codegen__init_part0_A_const_159 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_160 any

var A_arbace_cpp_codegen__init_part0_A_const_161 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_162 any

var A_arbace_cpp_codegen__init_part0_A_const_163 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_164 any

var A_arbace_cpp_codegen__init_part0_A_const_165 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_166 any

var A_arbace_cpp_codegen__init_part0_A_const_167 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_168 any

var A_arbace_cpp_codegen__init_part0_A_const_169 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_170 any

var A_arbace_cpp_codegen__init_part0_A_const_171 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_172 any

var A_arbace_cpp_codegen__init_part0_A_const_173 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_174 any

var A_arbace_cpp_codegen__init_part0_A_const_175 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_176 any

var A_arbace_cpp_codegen__init_part0_A_const_177 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_178 any

var A_arbace_cpp_codegen__init_part0_A_const_179 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_180 any

var A_arbace_cpp_codegen__init_part0_A_const_181 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_182 any

var A_arbace_cpp_codegen__init_part0_A_const_183 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_184 any

var A_arbace_cpp_codegen__init_part0_A_const_185 *lang.Var

var A_arbace_cpp_codegen__init_part0_A_const_186 any

var A_arbace_cpp_codegen__init_part0_A_init jrt.ClassInit

func A_arbace_cpp_codegen__init_part0_A_Init() { if !A_arbace_cpp_codegen__init_part0_A_init.Done() { A_arbace_cpp_codegen__init_part0_A_init.Run(A_arbace_cpp_codegen__init_part0_A_clinit) } }

func A_arbace_cpp_codegen__init_part0_A_clinit() { A_arbace_cpp_codegen__init_part0_A_clinit_p0(); A_arbace_cpp_codegen__init_part0_A_clinit_p1(); A_arbace_cpp_codegen__init_part0_A_clinit_p2(); A_arbace_cpp_codegen__init_part0_A_clinit_p3(); A_arbace_cpp_codegen__init_part0_A_clinit_p4(); A_arbace_cpp_codegen__init_part0_A_clinit_p5(); A_arbace_cpp_codegen__init_part0_A_clinit_p6(); A_arbace_cpp_codegen__init_part0_A_clinit_p7(); A_arbace_cpp_codegen__init_part0_A_clinit_p8(); A_arbace_cpp_codegen__init_part0_A_clinit_p9(); A_arbace_cpp_codegen__init_part0_A_clinit_p10(); A_arbace_cpp_codegen__init_part0_A_clinit_p11(); A_arbace_cpp_codegen__init_part0_A_clinit_p12(); A_arbace_cpp_codegen__init_part0_A_clinit_p13(); A_arbace_cpp_codegen__init_part0_A_clinit_p14() }

func A_arbace_cpp_codegen__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_codegen__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_640, 244); A_arbace_cpp_codegen__init_part0_A_const_0 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[57]); A_arbace_cpp_codegen__init_part0_A_const_1 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[58]; A_arbace_cpp_codegen__init_part0_A_const_2 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[59]; A_arbace_cpp_codegen__init_part0_A_const_3 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[60]; A_arbace_cpp_codegen__init_part0_A_const_4 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[61]); A_arbace_cpp_codegen__init_part0_A_const_5 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[62]); A_arbace_cpp_codegen__init_part0_A_const_6 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[63]); A_arbace_cpp_codegen__init_part0_A_const_7 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[64]; A_arbace_cpp_codegen__init_part0_A_const_8 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[65]); A_arbace_cpp_codegen__init_part0_A_const_9 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[66]; A_arbace_cpp_codegen__init_part0_A_const_10 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[67]); A_arbace_cpp_codegen__init_part0_A_const_11 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[68] }

func A_arbace_cpp_codegen__init_part0_A_clinit_p1() { A_arbace_cpp_codegen__init_part0_A_const_12 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[69]); A_arbace_cpp_codegen__init_part0_A_const_13 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[70]; A_arbace_cpp_codegen__init_part0_A_const_14 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[71]); A_arbace_cpp_codegen__init_part0_A_const_15 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[72]; A_arbace_cpp_codegen__init_part0_A_const_16 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[73]); A_arbace_cpp_codegen__init_part0_A_const_17 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[74]; A_arbace_cpp_codegen__init_part0_A_const_18 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[75]); A_arbace_cpp_codegen__init_part0_A_const_19 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[76]; A_arbace_cpp_codegen__init_part0_A_const_20 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[77]); A_arbace_cpp_codegen__init_part0_A_const_21 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[78]; A_arbace_cpp_codegen__init_part0_A_const_22 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[79]); A_arbace_cpp_codegen__init_part0_A_const_23 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[80]; A_arbace_cpp_codegen__init_part0_A_const_24 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[81]) }

func A_arbace_cpp_codegen__init_part0_A_clinit_p2() { A_arbace_cpp_codegen__init_part0_A_const_25 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[82]; A_arbace_cpp_codegen__init_part0_A_const_26 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[83]); A_arbace_cpp_codegen__init_part0_A_const_27 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[84]; A_arbace_cpp_codegen__init_part0_A_const_28 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[85]); A_arbace_cpp_codegen__init_part0_A_const_29 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[86]; A_arbace_cpp_codegen__init_part0_A_const_30 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[87]); A_arbace_cpp_codegen__init_part0_A_const_31 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[88]; A_arbace_cpp_codegen__init_part0_A_const_32 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[89]; A_arbace_cpp_codegen__init_part0_A_const_33 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[90]); A_arbace_cpp_codegen__init_part0_A_const_34 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[91]; A_arbace_cpp_codegen__init_part0_A_const_35 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[92]); A_arbace_cpp_codegen__init_part0_A_const_36 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[93]; A_arbace_cpp_codegen__init_part0_A_const_37 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[94]); A_arbace_cpp_codegen__init_part0_A_const_38 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[95] }

func A_arbace_cpp_codegen__init_part0_A_clinit_p3() { A_arbace_cpp_codegen__init_part0_A_const_39 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[96]); A_arbace_cpp_codegen__init_part0_A_const_40 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[97]; A_arbace_cpp_codegen__init_part0_A_const_41 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[98]); A_arbace_cpp_codegen__init_part0_A_const_42 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[99]; A_arbace_cpp_codegen__init_part0_A_const_43 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[100]); A_arbace_cpp_codegen__init_part0_A_const_44 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[101]; A_arbace_cpp_codegen__init_part0_A_const_45 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[102]); A_arbace_cpp_codegen__init_part0_A_const_46 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[103]; A_arbace_cpp_codegen__init_part0_A_const_47 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[104]); A_arbace_cpp_codegen__init_part0_A_const_48 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[105]; A_arbace_cpp_codegen__init_part0_A_const_49 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[106]); A_arbace_cpp_codegen__init_part0_A_const_50 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[107]; A_arbace_cpp_codegen__init_part0_A_const_51 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[108]) }

func A_arbace_cpp_codegen__init_part0_A_clinit_p4() { A_arbace_cpp_codegen__init_part0_A_const_52 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[109]; A_arbace_cpp_codegen__init_part0_A_const_53 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[110]); A_arbace_cpp_codegen__init_part0_A_const_54 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[111]; A_arbace_cpp_codegen__init_part0_A_const_55 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[112]); A_arbace_cpp_codegen__init_part0_A_const_56 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[113]); A_arbace_cpp_codegen__init_part0_A_const_57 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[114]; A_arbace_cpp_codegen__init_part0_A_const_58 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[115]); A_arbace_cpp_codegen__init_part0_A_const_59 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[116]; A_arbace_cpp_codegen__init_part0_A_const_60 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[117]); A_arbace_cpp_codegen__init_part0_A_const_61 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[118]; A_arbace_cpp_codegen__init_part0_A_const_62 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[119]); A_arbace_cpp_codegen__init_part0_A_const_63 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[120]; A_arbace_cpp_codegen__init_part0_A_const_64 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[121]) }

func A_arbace_cpp_codegen__init_part0_A_clinit_p5() { A_arbace_cpp_codegen__init_part0_A_const_65 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[122]; A_arbace_cpp_codegen__init_part0_A_const_66 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[123]; A_arbace_cpp_codegen__init_part0_A_const_67 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[124]); A_arbace_cpp_codegen__init_part0_A_const_68 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[125]; A_arbace_cpp_codegen__init_part0_A_const_69 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[126]); A_arbace_cpp_codegen__init_part0_A_const_70 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[127]; A_arbace_cpp_codegen__init_part0_A_const_71 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[128]); A_arbace_cpp_codegen__init_part0_A_const_72 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[129]; A_arbace_cpp_codegen__init_part0_A_const_73 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[130]); A_arbace_cpp_codegen__init_part0_A_const_74 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[131]; A_arbace_cpp_codegen__init_part0_A_const_75 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[132]); A_arbace_cpp_codegen__init_part0_A_const_76 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[133]; A_arbace_cpp_codegen__init_part0_A_const_77 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[134]); A_arbace_cpp_codegen__init_part0_A_const_78 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[135] }

func A_arbace_cpp_codegen__init_part0_A_clinit_p6() { A_arbace_cpp_codegen__init_part0_A_const_79 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[136]; A_arbace_cpp_codegen__init_part0_A_const_80 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[137]); A_arbace_cpp_codegen__init_part0_A_const_81 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[138]; A_arbace_cpp_codegen__init_part0_A_const_82 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[139]); A_arbace_cpp_codegen__init_part0_A_const_83 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[140]; A_arbace_cpp_codegen__init_part0_A_const_84 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[141]); A_arbace_cpp_codegen__init_part0_A_const_85 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[142]; A_arbace_cpp_codegen__init_part0_A_const_86 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[143]); A_arbace_cpp_codegen__init_part0_A_const_87 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[144]; A_arbace_cpp_codegen__init_part0_A_const_88 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[145]); A_arbace_cpp_codegen__init_part0_A_const_89 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[146]; A_arbace_cpp_codegen__init_part0_A_const_90 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[147]); A_arbace_cpp_codegen__init_part0_A_const_91 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[148] }

func A_arbace_cpp_codegen__init_part0_A_clinit_p7() { A_arbace_cpp_codegen__init_part0_A_const_92 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[149]); A_arbace_cpp_codegen__init_part0_A_const_93 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[150]; A_arbace_cpp_codegen__init_part0_A_const_94 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[151]); A_arbace_cpp_codegen__init_part0_A_const_95 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[152]; A_arbace_cpp_codegen__init_part0_A_const_96 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[153]); A_arbace_cpp_codegen__init_part0_A_const_97 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[154]; A_arbace_cpp_codegen__init_part0_A_const_98 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[155]); A_arbace_cpp_codegen__init_part0_A_const_99 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[156]; A_arbace_cpp_codegen__init_part0_A_const_100 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[157]); A_arbace_cpp_codegen__init_part0_A_const_101 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[158]; A_arbace_cpp_codegen__init_part0_A_const_102 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[159]); A_arbace_cpp_codegen__init_part0_A_const_103 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[160]; A_arbace_cpp_codegen__init_part0_A_const_104 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[161]) }

func A_arbace_cpp_codegen__init_part0_A_clinit_p8() { A_arbace_cpp_codegen__init_part0_A_const_105 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[162]; A_arbace_cpp_codegen__init_part0_A_const_106 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[163]); A_arbace_cpp_codegen__init_part0_A_const_107 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[164]; A_arbace_cpp_codegen__init_part0_A_const_108 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[165]); A_arbace_cpp_codegen__init_part0_A_const_109 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[166]; A_arbace_cpp_codegen__init_part0_A_const_110 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[167]); A_arbace_cpp_codegen__init_part0_A_const_111 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[168]; A_arbace_cpp_codegen__init_part0_A_const_112 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[169]); A_arbace_cpp_codegen__init_part0_A_const_113 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[170]; A_arbace_cpp_codegen__init_part0_A_const_114 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[171]; A_arbace_cpp_codegen__init_part0_A_const_115 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[172]; A_arbace_cpp_codegen__init_part0_A_const_116 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[173]; A_arbace_cpp_codegen__init_part0_A_const_117 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[174]; A_arbace_cpp_codegen__init_part0_A_const_118 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[175]) }

func A_arbace_cpp_codegen__init_part0_A_clinit_p9() { A_arbace_cpp_codegen__init_part0_A_const_119 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[176]; A_arbace_cpp_codegen__init_part0_A_const_120 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[177]); A_arbace_cpp_codegen__init_part0_A_const_121 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[178]; A_arbace_cpp_codegen__init_part0_A_const_122 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[179]); A_arbace_cpp_codegen__init_part0_A_const_123 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[180]; A_arbace_cpp_codegen__init_part0_A_const_124 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[181]); A_arbace_cpp_codegen__init_part0_A_const_125 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[182]; A_arbace_cpp_codegen__init_part0_A_const_126 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[183]); A_arbace_cpp_codegen__init_part0_A_const_127 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[184]; A_arbace_cpp_codegen__init_part0_A_const_128 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[185]); A_arbace_cpp_codegen__init_part0_A_const_129 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[186]; A_arbace_cpp_codegen__init_part0_A_const_130 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[187]); A_arbace_cpp_codegen__init_part0_A_const_131 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[188]; A_arbace_cpp_codegen__init_part0_A_const_132 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[189] }

func A_arbace_cpp_codegen__init_part0_A_clinit_p10() { A_arbace_cpp_codegen__init_part0_A_const_133 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[190]); A_arbace_cpp_codegen__init_part0_A_const_134 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[191]; A_arbace_cpp_codegen__init_part0_A_const_135 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[192]); A_arbace_cpp_codegen__init_part0_A_const_136 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[193]; A_arbace_cpp_codegen__init_part0_A_const_137 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[194]); A_arbace_cpp_codegen__init_part0_A_const_138 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[195]; A_arbace_cpp_codegen__init_part0_A_const_139 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[196]); A_arbace_cpp_codegen__init_part0_A_const_140 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[197]; A_arbace_cpp_codegen__init_part0_A_const_141 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[198]); A_arbace_cpp_codegen__init_part0_A_const_142 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[199]; A_arbace_cpp_codegen__init_part0_A_const_143 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[200]); A_arbace_cpp_codegen__init_part0_A_const_144 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[201]; A_arbace_cpp_codegen__init_part0_A_const_145 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[202]) }

func A_arbace_cpp_codegen__init_part0_A_clinit_p11() { A_arbace_cpp_codegen__init_part0_A_const_146 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[203]; A_arbace_cpp_codegen__init_part0_A_const_147 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[204]); A_arbace_cpp_codegen__init_part0_A_const_148 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[205]; A_arbace_cpp_codegen__init_part0_A_const_149 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[206]); A_arbace_cpp_codegen__init_part0_A_const_150 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[207]; A_arbace_cpp_codegen__init_part0_A_const_151 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[208]); A_arbace_cpp_codegen__init_part0_A_const_152 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[209]; A_arbace_cpp_codegen__init_part0_A_const_153 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[210]); A_arbace_cpp_codegen__init_part0_A_const_154 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[211]; A_arbace_cpp_codegen__init_part0_A_const_155 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[212]); A_arbace_cpp_codegen__init_part0_A_const_156 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[213]; A_arbace_cpp_codegen__init_part0_A_const_157 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[214]); A_arbace_cpp_codegen__init_part0_A_const_158 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[215] }

func A_arbace_cpp_codegen__init_part0_A_clinit_p12() { A_arbace_cpp_codegen__init_part0_A_const_159 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[216]); A_arbace_cpp_codegen__init_part0_A_const_160 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[217]; A_arbace_cpp_codegen__init_part0_A_const_161 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[218]); A_arbace_cpp_codegen__init_part0_A_const_162 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[219]; A_arbace_cpp_codegen__init_part0_A_const_163 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[220]); A_arbace_cpp_codegen__init_part0_A_const_164 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[221]; A_arbace_cpp_codegen__init_part0_A_const_165 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[222]); A_arbace_cpp_codegen__init_part0_A_const_166 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[223]; A_arbace_cpp_codegen__init_part0_A_const_167 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[224]); A_arbace_cpp_codegen__init_part0_A_const_168 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[225]; A_arbace_cpp_codegen__init_part0_A_const_169 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[226]); A_arbace_cpp_codegen__init_part0_A_const_170 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[227]; A_arbace_cpp_codegen__init_part0_A_const_171 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[228]) }

func A_arbace_cpp_codegen__init_part0_A_clinit_p13() { A_arbace_cpp_codegen__init_part0_A_const_172 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[229]; A_arbace_cpp_codegen__init_part0_A_const_173 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[230]); A_arbace_cpp_codegen__init_part0_A_const_174 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[231]; A_arbace_cpp_codegen__init_part0_A_const_175 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[232]); A_arbace_cpp_codegen__init_part0_A_const_176 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[233]; A_arbace_cpp_codegen__init_part0_A_const_177 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[234]); A_arbace_cpp_codegen__init_part0_A_const_178 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[235]; A_arbace_cpp_codegen__init_part0_A_const_179 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[236]); A_arbace_cpp_codegen__init_part0_A_const_180 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[237]; A_arbace_cpp_codegen__init_part0_A_const_181 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[238]); A_arbace_cpp_codegen__init_part0_A_const_182 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[239]; A_arbace_cpp_codegen__init_part0_A_const_183 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[240]); A_arbace_cpp_codegen__init_part0_A_const_184 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[241] }

func A_arbace_cpp_codegen__init_part0_A_clinit_p14() { A_arbace_cpp_codegen__init_part0_A_const_185 = lang.Var_Cast(A_arbace_cpp_codegen__init_part0_A_const_pool.A[242]); A_arbace_cpp_codegen__init_part0_A_const_186 = A_arbace_cpp_codegen__init_part0_A_const_pool.A[243] }

func A_arbace_cpp_codegen__init_part0_A_New() *A_arbace_cpp_codegen__init_part0_A { A_arbace_cpp_codegen__init_part0_A_Init(); t := &A_arbace_cpp_codegen__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_codegen__init_part0_A) Ctor() {}

func (t *A_arbace_cpp_codegen__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_codegen__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_codegen__init_part0_A_class }

func (t *A_arbace_cpp_codegen__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_codegen__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_codegen__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_codegen__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_codegen__init_part0_A); return ok }

func A_arbace_cpp_codegen__init_part0_A_Cast(x any) *A_arbace_cpp_codegen__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_codegen__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_codegen__init_part0_A_class)) }; return v }



type A_arbace_cpp_codegen__init_part1_A struct{ jrt.Object }

var A_arbace_cpp_codegen__init_part1_A_const_pool *jrt.RefArray

var A_arbace_cpp_codegen__init_part1_A_const_0 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_1 any

var A_arbace_cpp_codegen__init_part1_A_const_2 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_3 any

var A_arbace_cpp_codegen__init_part1_A_const_4 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_5 any

var A_arbace_cpp_codegen__init_part1_A_const_6 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_7 any

var A_arbace_cpp_codegen__init_part1_A_const_8 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_9 any

var A_arbace_cpp_codegen__init_part1_A_const_10 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_11 any

var A_arbace_cpp_codegen__init_part1_A_const_12 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_13 any

var A_arbace_cpp_codegen__init_part1_A_const_14 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_15 any

var A_arbace_cpp_codegen__init_part1_A_const_16 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_17 any

var A_arbace_cpp_codegen__init_part1_A_const_18 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_19 any

var A_arbace_cpp_codegen__init_part1_A_const_20 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_21 any

var A_arbace_cpp_codegen__init_part1_A_const_22 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_23 any

var A_arbace_cpp_codegen__init_part1_A_const_24 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_25 any

var A_arbace_cpp_codegen__init_part1_A_const_26 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_27 any

var A_arbace_cpp_codegen__init_part1_A_const_28 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_29 any

var A_arbace_cpp_codegen__init_part1_A_const_30 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_31 any

var A_arbace_cpp_codegen__init_part1_A_const_32 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_33 any

var A_arbace_cpp_codegen__init_part1_A_const_34 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_35 any

var A_arbace_cpp_codegen__init_part1_A_const_36 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_37 any

var A_arbace_cpp_codegen__init_part1_A_const_38 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_39 any

var A_arbace_cpp_codegen__init_part1_A_const_40 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_41 any

var A_arbace_cpp_codegen__init_part1_A_const_42 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_43 any

var A_arbace_cpp_codegen__init_part1_A_const_44 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_45 any

var A_arbace_cpp_codegen__init_part1_A_const_46 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_47 any

var A_arbace_cpp_codegen__init_part1_A_const_48 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_49 any

var A_arbace_cpp_codegen__init_part1_A_const_50 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_51 any

var A_arbace_cpp_codegen__init_part1_A_const_52 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_53 any

var A_arbace_cpp_codegen__init_part1_A_const_54 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_55 any

var A_arbace_cpp_codegen__init_part1_A_const_56 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_57 any

var A_arbace_cpp_codegen__init_part1_A_const_58 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_59 any

var A_arbace_cpp_codegen__init_part1_A_const_60 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_61 any

var A_arbace_cpp_codegen__init_part1_A_const_62 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_63 any

var A_arbace_cpp_codegen__init_part1_A_const_64 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_65 any

var A_arbace_cpp_codegen__init_part1_A_const_66 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_67 any

var A_arbace_cpp_codegen__init_part1_A_const_68 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_69 any

var A_arbace_cpp_codegen__init_part1_A_const_70 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_71 any

var A_arbace_cpp_codegen__init_part1_A_const_72 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_73 any

var A_arbace_cpp_codegen__init_part1_A_const_74 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_75 any

var A_arbace_cpp_codegen__init_part1_A_const_76 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_77 any

var A_arbace_cpp_codegen__init_part1_A_const_78 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_79 any

var A_arbace_cpp_codegen__init_part1_A_const_80 any

var A_arbace_cpp_codegen__init_part1_A_const_81 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_82 any

var A_arbace_cpp_codegen__init_part1_A_const_83 any

var A_arbace_cpp_codegen__init_part1_A_const_84 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_85 any

var A_arbace_cpp_codegen__init_part1_A_const_86 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_87 any

var A_arbace_cpp_codegen__init_part1_A_const_88 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_89 any

var A_arbace_cpp_codegen__init_part1_A_const_90 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_91 any

var A_arbace_cpp_codegen__init_part1_A_const_92 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_93 any

var A_arbace_cpp_codegen__init_part1_A_const_94 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_95 any

var A_arbace_cpp_codegen__init_part1_A_const_96 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_97 any

var A_arbace_cpp_codegen__init_part1_A_const_98 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_99 any

var A_arbace_cpp_codegen__init_part1_A_const_100 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_101 any

var A_arbace_cpp_codegen__init_part1_A_const_102 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_103 any

var A_arbace_cpp_codegen__init_part1_A_const_104 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_105 any

var A_arbace_cpp_codegen__init_part1_A_const_106 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_107 any

var A_arbace_cpp_codegen__init_part1_A_const_108 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_109 any

var A_arbace_cpp_codegen__init_part1_A_const_110 any

var A_arbace_cpp_codegen__init_part1_A_const_111 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_112 any

var A_arbace_cpp_codegen__init_part1_A_const_113 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_114 any

var A_arbace_cpp_codegen__init_part1_A_const_115 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_116 any

var A_arbace_cpp_codegen__init_part1_A_const_117 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_118 any

var A_arbace_cpp_codegen__init_part1_A_const_119 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_120 any

var A_arbace_cpp_codegen__init_part1_A_const_121 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_122 any

var A_arbace_cpp_codegen__init_part1_A_const_123 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_124 any

var A_arbace_cpp_codegen__init_part1_A_const_125 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_126 any

var A_arbace_cpp_codegen__init_part1_A_const_127 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_128 any

var A_arbace_cpp_codegen__init_part1_A_const_129 any

var A_arbace_cpp_codegen__init_part1_A_const_130 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_131 any

var A_arbace_cpp_codegen__init_part1_A_const_132 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_133 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_134 any

var A_arbace_cpp_codegen__init_part1_A_const_135 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_136 any

var A_arbace_cpp_codegen__init_part1_A_const_137 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_138 any

var A_arbace_cpp_codegen__init_part1_A_const_139 any

var A_arbace_cpp_codegen__init_part1_A_const_140 any

var A_arbace_cpp_codegen__init_part1_A_const_141 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_142 any

var A_arbace_cpp_codegen__init_part1_A_const_143 any

var A_arbace_cpp_codegen__init_part1_A_const_144 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_145 any

var A_arbace_cpp_codegen__init_part1_A_const_146 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_147 any

var A_arbace_cpp_codegen__init_part1_A_const_148 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_149 any

var A_arbace_cpp_codegen__init_part1_A_const_150 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_151 any

var A_arbace_cpp_codegen__init_part1_A_const_152 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_153 any

var A_arbace_cpp_codegen__init_part1_A_const_154 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_155 any

var A_arbace_cpp_codegen__init_part1_A_const_156 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_157 any

var A_arbace_cpp_codegen__init_part1_A_const_158 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_159 any

var A_arbace_cpp_codegen__init_part1_A_const_160 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_161 any

var A_arbace_cpp_codegen__init_part1_A_const_162 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_163 any

var A_arbace_cpp_codegen__init_part1_A_const_164 any

var A_arbace_cpp_codegen__init_part1_A_const_165 any

var A_arbace_cpp_codegen__init_part1_A_const_166 any

var A_arbace_cpp_codegen__init_part1_A_const_167 any

var A_arbace_cpp_codegen__init_part1_A_const_168 any

var A_arbace_cpp_codegen__init_part1_A_const_169 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_170 any

var A_arbace_cpp_codegen__init_part1_A_const_171 any

var A_arbace_cpp_codegen__init_part1_A_const_172 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_173 any

var A_arbace_cpp_codegen__init_part1_A_const_174 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_175 any

var A_arbace_cpp_codegen__init_part1_A_const_176 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_177 any

var A_arbace_cpp_codegen__init_part1_A_const_178 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_179 any

var A_arbace_cpp_codegen__init_part1_A_const_180 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_181 any

var A_arbace_cpp_codegen__init_part1_A_const_182 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_183 any

var A_arbace_cpp_codegen__init_part1_A_const_184 *lang.Var

var A_arbace_cpp_codegen__init_part1_A_const_185 any

var A_arbace_cpp_codegen__init_part1_A_init jrt.ClassInit

func A_arbace_cpp_codegen__init_part1_A_Init() { if !A_arbace_cpp_codegen__init_part1_A_init.Done() { A_arbace_cpp_codegen__init_part1_A_init.Run(A_arbace_cpp_codegen__init_part1_A_clinit) } }

func A_arbace_cpp_codegen__init_part1_A_clinit() { A_arbace_cpp_codegen__init_part1_A_clinit_p0(); A_arbace_cpp_codegen__init_part1_A_clinit_p1() }

func A_arbace_cpp_codegen__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_codegen__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_706, 258); A_arbace_cpp_codegen__init_part1_A_const_0 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[80]); A_arbace_cpp_codegen__init_part1_A_const_1 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[81] }

func A_arbace_cpp_codegen__init_part1_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_cpp_codegen__init_part0_A_Init(); tmp1 = A_arbace_cpp_codegen__init_part0_A_const_163; A_arbace_cpp_codegen__init_part1_A_const_2 = tmp1; A_arbace_cpp_codegen__init_part1_A_const_3 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[82]; var tmp2 *lang.Var; A_arbace_cpp_codegen__init_part0_A_Init(); tmp2 = A_arbace_cpp_codegen__init_part0_A_const_122; A_arbace_cpp_codegen__init_part1_A_const_4 = tmp2; A_arbace_cpp_codegen__init_part1_A_const_5 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[83]; A_arbace_cpp_codegen__init_part1_A_const_6 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[84]); A_arbace_cpp_codegen__init_part1_A_const_7 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[85]; A_arbace_cpp_codegen__init_part1_A_const_8 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[86]); A_arbace_cpp_codegen__init_part1_A_const_9 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[87]; A_arbace_cpp_codegen__init_part1_A_const_10 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[88]); A_arbace_cpp_codegen__init_part1_A_const_11 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[89]; A_arbace_cpp_codegen__init_part1_A_const_12 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[90]); A_arbace_cpp_codegen__init_part1_A_const_13 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[91]; A_arbace_cpp_codegen__init_part1_A_const_14 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[92]); A_arbace_cpp_codegen__init_part1_A_const_15 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[93]; var tmp3 *lang.Var; A_arbace_cpp_codegen__init_part0_A_Init(); tmp3 = A_arbace_cpp_codegen__init_part0_A_const_155; A_arbace_cpp_codegen__init_part1_A_const_16 = tmp3; A_arbace_cpp_codegen__init_part1_A_const_17 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[94]; A_arbace_cpp_codegen__init_part1_A_const_18 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[95]); A_arbace_cpp_codegen__init_part1_A_const_19 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[96]; A_arbace_cpp_codegen__init_part1_A_const_20 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[97]); A_arbace_cpp_codegen__init_part1_A_const_21 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[98]; A_arbace_cpp_codegen__init_part1_A_const_22 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[99]); A_arbace_cpp_codegen__init_part1_A_const_23 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[100]; A_arbace_cpp_codegen__init_part1_A_const_24 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[101]); A_arbace_cpp_codegen__init_part1_A_const_25 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[102]; A_arbace_cpp_codegen__init_part1_A_const_26 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[103]); A_arbace_cpp_codegen__init_part1_A_const_27 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[104]; A_arbace_cpp_codegen__init_part1_A_const_28 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[105]); A_arbace_cpp_codegen__init_part1_A_const_29 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[106]; A_arbace_cpp_codegen__init_part1_A_const_30 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[107]); A_arbace_cpp_codegen__init_part1_A_const_31 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[108]; A_arbace_cpp_codegen__init_part1_A_const_32 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[109]); A_arbace_cpp_codegen__init_part1_A_const_33 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[110]; A_arbace_cpp_codegen__init_part1_A_const_34 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[111]); A_arbace_cpp_codegen__init_part1_A_const_35 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[112]; A_arbace_cpp_codegen__init_part1_A_const_36 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[113]); A_arbace_cpp_codegen__init_part1_A_const_37 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[114]; A_arbace_cpp_codegen__init_part1_A_const_38 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[115]); A_arbace_cpp_codegen__init_part1_A_const_39 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[116]; A_arbace_cpp_codegen__init_part1_A_const_40 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[117]); A_arbace_cpp_codegen__init_part1_A_const_41 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[118]; A_arbace_cpp_codegen__init_part1_A_const_42 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[119]); A_arbace_cpp_codegen__init_part1_A_const_43 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[120]; A_arbace_cpp_codegen__init_part1_A_const_44 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[121]); A_arbace_cpp_codegen__init_part1_A_const_45 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[122]; A_arbace_cpp_codegen__init_part1_A_const_46 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[123]); A_arbace_cpp_codegen__init_part1_A_const_47 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[124]; A_arbace_cpp_codegen__init_part1_A_const_48 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[125]); A_arbace_cpp_codegen__init_part1_A_const_49 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[126]; A_arbace_cpp_codegen__init_part1_A_const_50 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[127]); A_arbace_cpp_codegen__init_part1_A_const_51 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[128]; A_arbace_cpp_codegen__init_part1_A_const_52 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[129]); A_arbace_cpp_codegen__init_part1_A_const_53 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[130]; A_arbace_cpp_codegen__init_part1_A_const_54 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[131]); A_arbace_cpp_codegen__init_part1_A_const_55 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[132]; A_arbace_cpp_codegen__init_part1_A_const_56 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[133]); A_arbace_cpp_codegen__init_part1_A_const_57 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[134]; A_arbace_cpp_codegen__init_part1_A_const_58 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[135]); A_arbace_cpp_codegen__init_part1_A_const_59 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[136]; A_arbace_cpp_codegen__init_part1_A_const_60 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[137]); A_arbace_cpp_codegen__init_part1_A_const_61 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[138]; A_arbace_cpp_codegen__init_part1_A_const_62 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[139]); A_arbace_cpp_codegen__init_part1_A_const_63 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[140]; A_arbace_cpp_codegen__init_part1_A_const_64 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[141]); A_arbace_cpp_codegen__init_part1_A_const_65 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[142]; A_arbace_cpp_codegen__init_part1_A_const_66 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[143]); A_arbace_cpp_codegen__init_part1_A_const_67 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[144]; A_arbace_cpp_codegen__init_part1_A_const_68 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[145]); A_arbace_cpp_codegen__init_part1_A_const_69 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[146]; A_arbace_cpp_codegen__init_part1_A_const_70 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[147]); A_arbace_cpp_codegen__init_part1_A_const_71 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[148]; A_arbace_cpp_codegen__init_part1_A_const_72 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[149]); A_arbace_cpp_codegen__init_part1_A_const_73 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[150]; A_arbace_cpp_codegen__init_part1_A_const_74 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[151]); A_arbace_cpp_codegen__init_part1_A_const_75 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[152]; A_arbace_cpp_codegen__init_part1_A_const_76 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[153]); A_arbace_cpp_codegen__init_part1_A_const_77 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[154]; A_arbace_cpp_codegen__init_part1_A_const_78 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[155]); A_arbace_cpp_codegen__init_part1_A_const_79 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[156]; A_arbace_cpp_codegen__init_part1_A_const_80 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[157]; A_arbace_cpp_codegen__init_part1_A_const_81 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[158]); A_arbace_cpp_codegen__init_part1_A_const_82 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[159]; A_arbace_cpp_codegen__init_part1_A_const_83 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[160]; A_arbace_cpp_codegen__init_part1_A_const_84 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[161]); A_arbace_cpp_codegen__init_part1_A_const_85 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[162]; A_arbace_cpp_codegen__init_part1_A_const_86 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[163]); A_arbace_cpp_codegen__init_part1_A_const_87 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[164]; A_arbace_cpp_codegen__init_part1_A_const_88 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[165]); A_arbace_cpp_codegen__init_part1_A_const_89 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[166]; A_arbace_cpp_codegen__init_part1_A_const_90 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[167]); A_arbace_cpp_codegen__init_part1_A_const_91 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[168]; A_arbace_cpp_codegen__init_part1_A_const_92 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[169]); A_arbace_cpp_codegen__init_part1_A_const_93 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[170]; A_arbace_cpp_codegen__init_part1_A_const_94 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[171]); A_arbace_cpp_codegen__init_part1_A_const_95 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[172]; A_arbace_cpp_codegen__init_part1_A_const_96 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[173]); A_arbace_cpp_codegen__init_part1_A_const_97 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[174]; A_arbace_cpp_codegen__init_part1_A_const_98 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[175]); A_arbace_cpp_codegen__init_part1_A_const_99 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[176]; var tmp4 *lang.Var; A_arbace_cpp_codegen__init_part0_A_Init(); tmp4 = A_arbace_cpp_codegen__init_part0_A_const_147; A_arbace_cpp_codegen__init_part1_A_const_100 = tmp4; A_arbace_cpp_codegen__init_part1_A_const_101 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[177]; A_arbace_cpp_codegen__init_part1_A_const_102 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[178]); A_arbace_cpp_codegen__init_part1_A_const_103 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[179]; A_arbace_cpp_codegen__init_part1_A_const_104 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[180]); A_arbace_cpp_codegen__init_part1_A_const_105 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[181]; var tmp5 *lang.Var; A_arbace_cpp_codegen__init_part0_A_Init(); tmp5 = A_arbace_cpp_codegen__init_part0_A_const_159; A_arbace_cpp_codegen__init_part1_A_const_106 = tmp5; A_arbace_cpp_codegen__init_part1_A_const_107 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[182]; A_arbace_cpp_codegen__init_part1_A_const_108 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[183]); A_arbace_cpp_codegen__init_part1_A_const_109 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[184]; A_arbace_cpp_codegen__init_part1_A_const_110 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[185]; A_arbace_cpp_codegen__init_part1_A_const_111 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[186]); A_arbace_cpp_codegen__init_part1_A_const_112 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[187]; A_arbace_cpp_codegen__init_part1_A_const_113 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[188]); A_arbace_cpp_codegen__init_part1_A_const_114 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[189]; A_arbace_cpp_codegen__init_part1_A_const_115 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[190]); A_arbace_cpp_codegen__init_part1_A_const_116 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[191]; A_arbace_cpp_codegen__init_part1_A_const_117 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[192]); A_arbace_cpp_codegen__init_part1_A_const_118 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[193]; A_arbace_cpp_codegen__init_part1_A_const_119 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[194]); A_arbace_cpp_codegen__init_part1_A_const_120 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[195]; A_arbace_cpp_codegen__init_part1_A_const_121 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[196]); A_arbace_cpp_codegen__init_part1_A_const_122 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[197]; A_arbace_cpp_codegen__init_part1_A_const_123 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[198]); A_arbace_cpp_codegen__init_part1_A_const_124 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[199]; A_arbace_cpp_codegen__init_part1_A_const_125 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[200]); A_arbace_cpp_codegen__init_part1_A_const_126 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[201]; A_arbace_cpp_codegen__init_part1_A_const_127 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[202]); A_arbace_cpp_codegen__init_part1_A_const_128 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[203]; A_arbace_cpp_codegen__init_part1_A_const_129 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[204]; var tmp6 *lang.Var; A_arbace_cpp_codegen__init_part0_A_Init(); tmp6 = A_arbace_cpp_codegen__init_part0_A_const_149; A_arbace_cpp_codegen__init_part1_A_const_130 = tmp6; A_arbace_cpp_codegen__init_part1_A_const_131 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[205]; A_arbace_cpp_codegen__init_part1_A_const_132 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[206]); var tmp7 *lang.Var; A_arbace_cpp_codegen__init_part0_A_Init(); tmp7 = A_arbace_cpp_codegen__init_part0_A_const_151; A_arbace_cpp_codegen__init_part1_A_const_133 = tmp7; A_arbace_cpp_codegen__init_part1_A_const_134 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[207]; var tmp8 *lang.Var; A_arbace_cpp_codegen__init_part0_A_Init(); tmp8 = A_arbace_cpp_codegen__init_part0_A_const_153; A_arbace_cpp_codegen__init_part1_A_const_135 = tmp8; A_arbace_cpp_codegen__init_part1_A_const_136 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[208]; A_arbace_cpp_codegen__init_part1_A_const_137 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[209]); A_arbace_cpp_codegen__init_part1_A_const_138 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[210]; A_arbace_cpp_codegen__init_part1_A_const_139 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[211]; A_arbace_cpp_codegen__init_part1_A_const_140 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[212]; A_arbace_cpp_codegen__init_part1_A_const_141 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[213]); A_arbace_cpp_codegen__init_part1_A_const_142 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[214]; A_arbace_cpp_codegen__init_part1_A_const_143 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[215]; A_arbace_cpp_codegen__init_part1_A_const_144 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[216]); A_arbace_cpp_codegen__init_part1_A_const_145 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[217]; A_arbace_cpp_codegen__init_part1_A_const_146 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[218]); A_arbace_cpp_codegen__init_part1_A_const_147 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[219]; A_arbace_cpp_codegen__init_part1_A_const_148 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[220]); A_arbace_cpp_codegen__init_part1_A_const_149 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[221]; A_arbace_cpp_codegen__init_part1_A_const_150 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[222]); A_arbace_cpp_codegen__init_part1_A_const_151 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[223]; A_arbace_cpp_codegen__init_part1_A_const_152 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[224]); A_arbace_cpp_codegen__init_part1_A_const_153 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[225]; A_arbace_cpp_codegen__init_part1_A_const_154 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[226]); A_arbace_cpp_codegen__init_part1_A_const_155 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[227]; A_arbace_cpp_codegen__init_part1_A_const_156 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[228]); A_arbace_cpp_codegen__init_part1_A_const_157 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[229]; A_arbace_cpp_codegen__init_part1_A_const_158 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[230]); A_arbace_cpp_codegen__init_part1_A_const_159 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[231]; A_arbace_cpp_codegen__init_part1_A_const_160 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[232]); A_arbace_cpp_codegen__init_part1_A_const_161 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[233]; A_arbace_cpp_codegen__init_part1_A_const_162 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[234]); A_arbace_cpp_codegen__init_part1_A_const_163 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[235]; A_arbace_cpp_codegen__init_part1_A_const_164 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[236]; A_arbace_cpp_codegen__init_part1_A_const_165 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[237]; A_arbace_cpp_codegen__init_part1_A_const_166 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[238]; A_arbace_cpp_codegen__init_part1_A_const_167 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[239]; A_arbace_cpp_codegen__init_part1_A_const_168 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[240]; A_arbace_cpp_codegen__init_part1_A_const_169 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[241]); A_arbace_cpp_codegen__init_part1_A_const_170 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[242]; A_arbace_cpp_codegen__init_part1_A_const_171 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[243]; A_arbace_cpp_codegen__init_part1_A_const_172 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[244]); A_arbace_cpp_codegen__init_part1_A_const_173 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[245]; A_arbace_cpp_codegen__init_part1_A_const_174 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[246]); A_arbace_cpp_codegen__init_part1_A_const_175 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[247]; A_arbace_cpp_codegen__init_part1_A_const_176 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[248]); A_arbace_cpp_codegen__init_part1_A_const_177 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[249]; A_arbace_cpp_codegen__init_part1_A_const_178 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[250]); A_arbace_cpp_codegen__init_part1_A_const_179 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[251]; A_arbace_cpp_codegen__init_part1_A_const_180 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[252]); A_arbace_cpp_codegen__init_part1_A_const_181 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[253]; A_arbace_cpp_codegen__init_part1_A_const_182 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[254]); A_arbace_cpp_codegen__init_part1_A_const_183 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[255]; A_arbace_cpp_codegen__init_part1_A_const_184 = lang.Var_Cast(A_arbace_cpp_codegen__init_part1_A_const_pool.A[256]); A_arbace_cpp_codegen__init_part1_A_const_185 = A_arbace_cpp_codegen__init_part1_A_const_pool.A[257] }

func A_arbace_cpp_codegen__init_part1_A_New() *A_arbace_cpp_codegen__init_part1_A { A_arbace_cpp_codegen__init_part1_A_Init(); t := &A_arbace_cpp_codegen__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_codegen__init_part1_A) Ctor() {}

func (t *A_arbace_cpp_codegen__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_codegen__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_codegen__init_part1_A_class }

func (t *A_arbace_cpp_codegen__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_codegen__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_codegen__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_codegen__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_codegen__init_part1_A); return ok }

func A_arbace_cpp_codegen__init_part1_A_Cast(x any) *A_arbace_cpp_codegen__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_codegen__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_codegen__init_part1_A_class)) }; return v }



type A_arbace_cpp_codegen__init_part2_A struct{ jrt.Object }

var A_arbace_cpp_codegen__init_part2_A_const_pool *jrt.RefArray

var A_arbace_cpp_codegen__init_part2_A_const_0 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_1 any

var A_arbace_cpp_codegen__init_part2_A_const_2 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_3 any

var A_arbace_cpp_codegen__init_part2_A_const_4 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_5 any

var A_arbace_cpp_codegen__init_part2_A_const_6 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_7 any

var A_arbace_cpp_codegen__init_part2_A_const_8 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_9 any

var A_arbace_cpp_codegen__init_part2_A_const_10 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_11 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_12 any

var A_arbace_cpp_codegen__init_part2_A_const_13 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_14 any

var A_arbace_cpp_codegen__init_part2_A_const_15 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_16 any

var A_arbace_cpp_codegen__init_part2_A_const_17 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_18 any

var A_arbace_cpp_codegen__init_part2_A_const_19 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_20 any

var A_arbace_cpp_codegen__init_part2_A_const_21 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_22 any

var A_arbace_cpp_codegen__init_part2_A_const_23 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_24 any

var A_arbace_cpp_codegen__init_part2_A_const_25 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_26 any

var A_arbace_cpp_codegen__init_part2_A_const_27 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_28 any

var A_arbace_cpp_codegen__init_part2_A_const_29 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_30 any

var A_arbace_cpp_codegen__init_part2_A_const_31 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_32 any

var A_arbace_cpp_codegen__init_part2_A_const_33 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_34 any

var A_arbace_cpp_codegen__init_part2_A_const_35 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_36 any

var A_arbace_cpp_codegen__init_part2_A_const_37 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_38 any

var A_arbace_cpp_codegen__init_part2_A_const_39 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_40 any

var A_arbace_cpp_codegen__init_part2_A_const_41 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_42 any

var A_arbace_cpp_codegen__init_part2_A_const_43 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_44 any

var A_arbace_cpp_codegen__init_part2_A_const_45 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_46 any

var A_arbace_cpp_codegen__init_part2_A_const_47 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_48 any

var A_arbace_cpp_codegen__init_part2_A_const_49 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_50 any

var A_arbace_cpp_codegen__init_part2_A_const_51 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_52 any

var A_arbace_cpp_codegen__init_part2_A_const_53 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_54 any

var A_arbace_cpp_codegen__init_part2_A_const_55 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_56 any

var A_arbace_cpp_codegen__init_part2_A_const_57 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_58 any

var A_arbace_cpp_codegen__init_part2_A_const_59 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_60 any

var A_arbace_cpp_codegen__init_part2_A_const_61 any

var A_arbace_cpp_codegen__init_part2_A_const_62 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_63 any

var A_arbace_cpp_codegen__init_part2_A_const_64 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_65 any

var A_arbace_cpp_codegen__init_part2_A_const_66 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_67 any

var A_arbace_cpp_codegen__init_part2_A_const_68 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_69 any

var A_arbace_cpp_codegen__init_part2_A_const_70 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_71 any

var A_arbace_cpp_codegen__init_part2_A_const_72 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_73 any

var A_arbace_cpp_codegen__init_part2_A_const_74 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_75 any

var A_arbace_cpp_codegen__init_part2_A_const_76 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_77 any

var A_arbace_cpp_codegen__init_part2_A_const_78 any

var A_arbace_cpp_codegen__init_part2_A_const_79 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_80 any

var A_arbace_cpp_codegen__init_part2_A_const_81 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_82 any

var A_arbace_cpp_codegen__init_part2_A_const_83 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_84 any

var A_arbace_cpp_codegen__init_part2_A_const_85 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_86 any

var A_arbace_cpp_codegen__init_part2_A_const_87 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_88 any

var A_arbace_cpp_codegen__init_part2_A_const_89 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_90 any

var A_arbace_cpp_codegen__init_part2_A_const_91 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_92 any

var A_arbace_cpp_codegen__init_part2_A_const_93 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_94 any

var A_arbace_cpp_codegen__init_part2_A_const_95 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_96 any

var A_arbace_cpp_codegen__init_part2_A_const_97 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_98 any

var A_arbace_cpp_codegen__init_part2_A_const_99 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_100 any

var A_arbace_cpp_codegen__init_part2_A_const_101 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_102 any

var A_arbace_cpp_codegen__init_part2_A_const_103 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_104 any

var A_arbace_cpp_codegen__init_part2_A_const_105 *lang.Var

var A_arbace_cpp_codegen__init_part2_A_const_106 any

var A_arbace_cpp_codegen__init_part2_A_init jrt.ClassInit

func A_arbace_cpp_codegen__init_part2_A_Init() { if !A_arbace_cpp_codegen__init_part2_A_init.Done() { A_arbace_cpp_codegen__init_part2_A_init.Run(A_arbace_cpp_codegen__init_part2_A_clinit) } }

func A_arbace_cpp_codegen__init_part2_A_clinit() { A_arbace_cpp_codegen__init_part2_A_clinit_p0(); A_arbace_cpp_codegen__init_part2_A_clinit_p1() }

func A_arbace_cpp_codegen__init_part2_A_clinit_p0() { jrt.StartCheck(); A_arbace_cpp_codegen__init_part2_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_789, 141) }

func A_arbace_cpp_codegen__init_part2_A_clinit_p1() { var tmp1 *lang.Var; A_arbace_cpp_codegen__init_part1_A_Init(); tmp1 = A_arbace_cpp_codegen__init_part1_A_const_42; A_arbace_cpp_codegen__init_part2_A_const_0 = tmp1; A_arbace_cpp_codegen__init_part2_A_const_1 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[39]; A_arbace_cpp_codegen__init_part2_A_const_2 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[40]); A_arbace_cpp_codegen__init_part2_A_const_3 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[41]; A_arbace_cpp_codegen__init_part2_A_const_4 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[42]); A_arbace_cpp_codegen__init_part2_A_const_5 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[43]; A_arbace_cpp_codegen__init_part2_A_const_6 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[44]); A_arbace_cpp_codegen__init_part2_A_const_7 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[45]; A_arbace_cpp_codegen__init_part2_A_const_8 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[46]); A_arbace_cpp_codegen__init_part2_A_const_9 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[47]; A_arbace_cpp_codegen__init_part2_A_const_10 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[48]); A_arbace_cpp_codegen__init_part2_A_const_11 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[49]); A_arbace_cpp_codegen__init_part2_A_const_12 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[50]; A_arbace_cpp_codegen__init_part2_A_const_13 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[51]); A_arbace_cpp_codegen__init_part2_A_const_14 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[52]; A_arbace_cpp_codegen__init_part2_A_const_15 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[53]); A_arbace_cpp_codegen__init_part2_A_const_16 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[54]; A_arbace_cpp_codegen__init_part2_A_const_17 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[55]); A_arbace_cpp_codegen__init_part2_A_const_18 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[56]; A_arbace_cpp_codegen__init_part2_A_const_19 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[57]); A_arbace_cpp_codegen__init_part2_A_const_20 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[58]; A_arbace_cpp_codegen__init_part2_A_const_21 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[59]); A_arbace_cpp_codegen__init_part2_A_const_22 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[60]; A_arbace_cpp_codegen__init_part2_A_const_23 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[61]); A_arbace_cpp_codegen__init_part2_A_const_24 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[62]; A_arbace_cpp_codegen__init_part2_A_const_25 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[63]); A_arbace_cpp_codegen__init_part2_A_const_26 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[64]; A_arbace_cpp_codegen__init_part2_A_const_27 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[65]); A_arbace_cpp_codegen__init_part2_A_const_28 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[66]; A_arbace_cpp_codegen__init_part2_A_const_29 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[67]); A_arbace_cpp_codegen__init_part2_A_const_30 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[68]; A_arbace_cpp_codegen__init_part2_A_const_31 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[69]); A_arbace_cpp_codegen__init_part2_A_const_32 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[70]; A_arbace_cpp_codegen__init_part2_A_const_33 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[71]); A_arbace_cpp_codegen__init_part2_A_const_34 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[72]; A_arbace_cpp_codegen__init_part2_A_const_35 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[73]); A_arbace_cpp_codegen__init_part2_A_const_36 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[74]; A_arbace_cpp_codegen__init_part2_A_const_37 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[75]); A_arbace_cpp_codegen__init_part2_A_const_38 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[76]; A_arbace_cpp_codegen__init_part2_A_const_39 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[77]); A_arbace_cpp_codegen__init_part2_A_const_40 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[78]; A_arbace_cpp_codegen__init_part2_A_const_41 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[79]); A_arbace_cpp_codegen__init_part2_A_const_42 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[80]; var tmp2 *lang.Var; A_arbace_cpp_codegen__init_part1_A_Init(); tmp2 = A_arbace_cpp_codegen__init_part1_A_const_144; A_arbace_cpp_codegen__init_part2_A_const_43 = tmp2; A_arbace_cpp_codegen__init_part2_A_const_44 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[81]; A_arbace_cpp_codegen__init_part2_A_const_45 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[82]); A_arbace_cpp_codegen__init_part2_A_const_46 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[83]; A_arbace_cpp_codegen__init_part2_A_const_47 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[84]); A_arbace_cpp_codegen__init_part2_A_const_48 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[85]; A_arbace_cpp_codegen__init_part2_A_const_49 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[86]); A_arbace_cpp_codegen__init_part2_A_const_50 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[87]; A_arbace_cpp_codegen__init_part2_A_const_51 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[88]); A_arbace_cpp_codegen__init_part2_A_const_52 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[89]; A_arbace_cpp_codegen__init_part2_A_const_53 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[90]); A_arbace_cpp_codegen__init_part2_A_const_54 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[91]; A_arbace_cpp_codegen__init_part2_A_const_55 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[92]); A_arbace_cpp_codegen__init_part2_A_const_56 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[93]; A_arbace_cpp_codegen__init_part2_A_const_57 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[94]); A_arbace_cpp_codegen__init_part2_A_const_58 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[95]; A_arbace_cpp_codegen__init_part2_A_const_59 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[96]); A_arbace_cpp_codegen__init_part2_A_const_60 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[97]; A_arbace_cpp_codegen__init_part2_A_const_61 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[98]; A_arbace_cpp_codegen__init_part2_A_const_62 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[99]); A_arbace_cpp_codegen__init_part2_A_const_63 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[100]; A_arbace_cpp_codegen__init_part2_A_const_64 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[101]); A_arbace_cpp_codegen__init_part2_A_const_65 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[102]; var tmp3 *lang.Var; A_arbace_cpp_codegen__init_part0_A_Init(); tmp3 = A_arbace_cpp_codegen__init_part0_A_const_157; A_arbace_cpp_codegen__init_part2_A_const_66 = tmp3; A_arbace_cpp_codegen__init_part2_A_const_67 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[103]; A_arbace_cpp_codegen__init_part2_A_const_68 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[104]); A_arbace_cpp_codegen__init_part2_A_const_69 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[105]; var tmp4 *lang.Var; A_arbace_cpp_codegen__init_part1_A_Init(); tmp4 = A_arbace_cpp_codegen__init_part1_A_const_152; A_arbace_cpp_codegen__init_part2_A_const_70 = tmp4; A_arbace_cpp_codegen__init_part2_A_const_71 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[106]; var tmp5 *lang.Var; A_arbace_cpp_codegen__init_part1_A_Init(); tmp5 = A_arbace_cpp_codegen__init_part1_A_const_154; A_arbace_cpp_codegen__init_part2_A_const_72 = tmp5; A_arbace_cpp_codegen__init_part2_A_const_73 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[107]; A_arbace_cpp_codegen__init_part2_A_const_74 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[108]); A_arbace_cpp_codegen__init_part2_A_const_75 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[109]; A_arbace_cpp_codegen__init_part2_A_const_76 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[110]); A_arbace_cpp_codegen__init_part2_A_const_77 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[111]; A_arbace_cpp_codegen__init_part2_A_const_78 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[112]; A_arbace_cpp_codegen__init_part2_A_const_79 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[113]); A_arbace_cpp_codegen__init_part2_A_const_80 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[114]; A_arbace_cpp_codegen__init_part2_A_const_81 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[115]); A_arbace_cpp_codegen__init_part2_A_const_82 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[116]; A_arbace_cpp_codegen__init_part2_A_const_83 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[117]); A_arbace_cpp_codegen__init_part2_A_const_84 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[118]; A_arbace_cpp_codegen__init_part2_A_const_85 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[119]); A_arbace_cpp_codegen__init_part2_A_const_86 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[120]; A_arbace_cpp_codegen__init_part2_A_const_87 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[121]); A_arbace_cpp_codegen__init_part2_A_const_88 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[122]; A_arbace_cpp_codegen__init_part2_A_const_89 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[123]); A_arbace_cpp_codegen__init_part2_A_const_90 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[124]; A_arbace_cpp_codegen__init_part2_A_const_91 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[125]); A_arbace_cpp_codegen__init_part2_A_const_92 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[126]; A_arbace_cpp_codegen__init_part2_A_const_93 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[127]); A_arbace_cpp_codegen__init_part2_A_const_94 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[128]; A_arbace_cpp_codegen__init_part2_A_const_95 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[129]); A_arbace_cpp_codegen__init_part2_A_const_96 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[130]; A_arbace_cpp_codegen__init_part2_A_const_97 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[131]); A_arbace_cpp_codegen__init_part2_A_const_98 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[132]; A_arbace_cpp_codegen__init_part2_A_const_99 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[133]); A_arbace_cpp_codegen__init_part2_A_const_100 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[134]; A_arbace_cpp_codegen__init_part2_A_const_101 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[135]); A_arbace_cpp_codegen__init_part2_A_const_102 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[136]; A_arbace_cpp_codegen__init_part2_A_const_103 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[137]); A_arbace_cpp_codegen__init_part2_A_const_104 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[138]; A_arbace_cpp_codegen__init_part2_A_const_105 = lang.Var_Cast(A_arbace_cpp_codegen__init_part2_A_const_pool.A[139]); A_arbace_cpp_codegen__init_part2_A_const_106 = A_arbace_cpp_codegen__init_part2_A_const_pool.A[140] }

func A_arbace_cpp_codegen__init_part2_A_New() *A_arbace_cpp_codegen__init_part2_A { A_arbace_cpp_codegen__init_part2_A_Init(); t := &A_arbace_cpp_codegen__init_part2_A{}; t.Ctor(); return t }

func (t *A_arbace_cpp_codegen__init_part2_A) Ctor() {}

func (t *A_arbace_cpp_codegen__init_part2_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_cpp_codegen__init_part2_A) GetClass__Class() *jrt.Class { return A_arbace_cpp_codegen__init_part2_A_class }

func (t *A_arbace_cpp_codegen__init_part2_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_cpp_codegen__init_part2_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_cpp_codegen__init_part2_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_cpp_codegen__init_part2_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_cpp_codegen__init_part2_A); return ok }

func A_arbace_cpp_codegen__init_part2_A_Cast(x any) *A_arbace_cpp_codegen__init_part2_A { if x == nil { return nil }; v, ok := x.(*A_arbace_cpp_codegen__init_part2_A); if !ok { panic(jrt.ClassCast(x, A_arbace_cpp_codegen__init_part2_A_class)) }; return v }
