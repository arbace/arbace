//line aot_arbace_repr_go_annotate__init.ae:1
package aot_arbace_repr_go_annotate

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_annotate__init_A_Unit0__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_repr_go_annotate__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_annotate__init_A_const_1) }
//line :1:1
func A_arbace_repr_go_annotate__init_A_Unit1__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_repr_go_annotate__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_2)) }
//line :1:1
func A_arbace_repr_go_annotate__init_A_Unit2__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 any = A_arbace_repr_go_annotate_eval1949000004_loading__1927001464__auto____1949000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_go_annotate_eval1949000004_loading__1927001464__auto____1949000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_285, false); A_arbace_repr_go_annotate_eval1949000004_loading__1927001464__auto____1949000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_repr_go_annotate__init_A_Unit3__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repr_go_annotate__init_A_const_1)).Equals_O__Z(A_arbace_repr_go_annotate__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_repr_go_annotate_eval1949000008_fn__1949000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_repr_go_annotate_eval1949000008_fn__1949000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_286, false); A_arbace_repr_go_annotate_eval1949000008_fn__1949000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_repr_go_annotate__init_A_Load__O() any { A_arbace_repr_go_annotate__init_A_Init(); jrt.StartCheck(); A_arbace_repr_go_annotate__init_A_Unit0__O(); A_arbace_repr_go_annotate__init_A_Unit1__O(); A_arbace_repr_go_annotate__init_A_Unit2__O(); A_arbace_repr_go_annotate__init_A_Unit3__O(); A_arbace_repr_go_annotate__init_A_Unit4__O(); A_arbace_repr_go_annotate__init_A_Unit5__O(); A_arbace_repr_go_annotate__init_A_Unit6__O(); A_arbace_repr_go_annotate__init_A_Unit7__O(); A_arbace_repr_go_annotate__init_A_Unit8__O(); A_arbace_repr_go_annotate__init_A_Unit9__O(); A_arbace_repr_go_annotate__init_A_Unit10__O(); A_arbace_repr_go_annotate__init_A_Unit11__O(); A_arbace_repr_go_annotate__init_A_Unit12__O(); A_arbace_repr_go_annotate__init_A_Unit13__O(); A_arbace_repr_go_annotate__init_A_Unit14__O(); A_arbace_repr_go_annotate__init_A_Unit15__O(); A_arbace_repr_go_annotate__init_A_Unit16__O(); A_arbace_repr_go_annotate__init_A_Unit17__O(); A_arbace_repr_go_annotate__init_A_Unit18__O(); A_arbace_repr_go_annotate__init_A_Unit19__O(); A_arbace_repr_go_annotate__init_A_Unit20__O(); A_arbace_repr_go_annotate__init_A_Unit21__O(); A_arbace_repr_go_annotate__init_A_Unit22__O(); A_arbace_repr_go_annotate__init_A_Unit23__O(); A_arbace_repr_go_annotate__init_A_Unit24__O(); A_arbace_repr_go_annotate__init_A_Unit25__O(); A_arbace_repr_go_annotate__init_A_Unit26__O(); A_arbace_repr_go_annotate__init_A_Unit27__O(); A_arbace_repr_go_annotate__init_A_Unit28__O(); A_arbace_repr_go_annotate__init_A_Unit29__O(); A_arbace_repr_go_annotate__init_A_Unit30__O(); A_arbace_repr_go_annotate__init_A_Unit31__O(); A_arbace_repr_go_annotate__init_A_Unit32__O(); A_arbace_repr_go_annotate__init_A_Unit33__O(); A_arbace_repr_go_annotate__init_A_Unit34__O(); A_arbace_repr_go_annotate__init_A_Unit35__O(); A_arbace_repr_go_annotate__init_A_Unit36__O(); A_arbace_repr_go_annotate__init_A_Unit37__O(); A_arbace_repr_go_annotate__init_A_Unit38__O(); A_arbace_repr_go_annotate__init_A_Unit39__O(); A_arbace_repr_go_annotate__init_A_Unit40__O(); A_arbace_repr_go_annotate__init_A_Unit41__O(); A_arbace_repr_go_annotate__init_A_Unit42__O(); A_arbace_repr_go_annotate__init_A_Unit43__O(); A_arbace_repr_go_annotate__init_A_Unit44__O(); A_arbace_repr_go_annotate__init_A_Unit45__O(); A_arbace_repr_go_annotate__init_A_Unit46__O(); A_arbace_repr_go_annotate__init_A_Unit47__O(); A_arbace_repr_go_annotate__init_A_Unit48__O(); A_arbace_repr_go_annotate__init_A_Unit49__O(); A_arbace_repr_go_annotate__init_A_Unit50__O(); A_arbace_repr_go_annotate__init_A_Unit51__O(); A_arbace_repr_go_annotate__init_A_Unit52__O(); A_arbace_repr_go_annotate__init_A_Unit53__O(); A_arbace_repr_go_annotate__init_A_Unit54__O(); A_arbace_repr_go_annotate__init_A_Unit55__O(); A_arbace_repr_go_annotate__init_A_Unit56__O(); A_arbace_repr_go_annotate__init_A_Unit57__O(); A_arbace_repr_go_annotate__init_A_Unit58__O(); A_arbace_repr_go_annotate__init_A_Unit59__O(); A_arbace_repr_go_annotate__init_A_Unit60__O(); return nil }



































func A_arbace_repr_go_annotate__init_A_Unit4__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(41, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_4; var tmp2 any = A_arbace_repr_go_annotate_private_key_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_go_annotate_private_key_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_287, false); A_arbace_repr_go_annotate_private_key_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_5)); return A_arbace_repr_go_annotate__init_A_const_4 }

func A_arbace_repr_go_annotate__init_A_Unit5__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_7)); return A_arbace_repr_go_annotate__init_A_const_6 }

func A_arbace_repr_go_annotate__init_A_Unit6__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_8; var tmp2 any = A_arbace_repr_go_annotate_cmeta_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_repr_go_annotate_cmeta_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_288, false); A_arbace_repr_go_annotate_cmeta_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_9)); return A_arbace_repr_go_annotate__init_A_const_8 }











func A_arbace_repr_go_annotate__init_A_Unit7__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(57, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_6; var tmp2 any = A_arbace_repr_go_annotate_cform_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_go_annotate_cform_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_289, false); A_arbace_repr_go_annotate_cform_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_10)); return A_arbace_repr_go_annotate__init_A_const_6 }













func A_arbace_repr_go_annotate__init_A_Unit8__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(71, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_11; var tmp2 any = A_arbace_repr_go_annotate_import_specs_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_repr_go_annotate_import_specs_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_290, false); A_arbace_repr_go_annotate_import_specs_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_12)); return A_arbace_repr_go_annotate__init_A_const_11 }




















func A_arbace_repr_go_annotate__init_A_Unit9__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_13; var tmp2 any = A_arbace_repr_go_annotate_raw_source_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repr_go_annotate_raw_source_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_291, false); A_arbace_repr_go_annotate_raw_source_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_14)); return A_arbace_repr_go_annotate__init_A_const_13 }














func A_arbace_repr_go_annotate__init_A_Unit10__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_15; var tmp2 any; var root_8 any = A_arbace_repr_go_annotate__init_A_const_16.GetRawRoot__O(); var linked_9 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_8, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_10 lang.IFn; if linked_9 == nil { ifn_10 = lang.IFn_Cast(root_8) } else { ifn_10 = nil }; var arg_11 any = Lit_292; if linked_9 == nil { tmp2 = ifn_10.Invoke_O__O(arg_11) } else { tmp2 = linked_9.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_8, arg_11) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_repr_go_annotate__init_A_const_15; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_17)); return A_arbace_repr_go_annotate__init_A_const_15 }

func A_arbace_repr_go_annotate__init_A_Unit11__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_18; var tmp2 any = A_arbace_repr_go_annotate_config_key_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_repr_go_annotate_config_key_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_293, false); A_arbace_repr_go_annotate_config_key_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_19)); return A_arbace_repr_go_annotate__init_A_const_18 }



func A_arbace_repr_go_annotate__init_A_Unit12__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(113, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_20; var tmp2 any = A_arbace_repr_go_annotate_prep_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repr_go_annotate_prep_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_294, false); A_arbace_repr_go_annotate_prep_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_21)); return A_arbace_repr_go_annotate__init_A_const_20 }














func A_arbace_repr_go_annotate__init_A_Unit13__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(128, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_22; var tmp2 any = A_arbace_repr_go_annotate_new_session_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_repr_go_annotate_new_session_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_295, false); A_arbace_repr_go_annotate_new_session_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_23)); return A_arbace_repr_go_annotate__init_A_const_22 }

















func A_arbace_repr_go_annotate__init_A_Unit14__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(146, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_24; var tmp2 any; var root_15 any = A_arbace_repr_go_annotate__init_A_const_16.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_15, arg_18) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_repr_go_annotate__init_A_const_24; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_25)); return A_arbace_repr_go_annotate__init_A_const_24 }

func A_arbace_repr_go_annotate__init_A_Unit15__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(148, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_26; var tmp2 any = A_arbace_repr_go_annotate_std_index_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_repr_go_annotate_std_index_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_296, false); A_arbace_repr_go_annotate_std_index_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_27)); return A_arbace_repr_go_annotate__init_A_const_26 }





func A_arbace_repr_go_annotate__init_A_Unit16__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(154, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_28; var tmp2 any = A_arbace_repr_go_annotate_std_session_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_repr_go_annotate_std_session_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_297, false); A_arbace_repr_go_annotate_std_session_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_29)); return A_arbace_repr_go_annotate__init_A_const_28 }









func A_arbace_repr_go_annotate__init_A_Unit17__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_30; var tmp2 any = A_arbace_repr_go_annotate_drop_std_sessions_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_repr_go_annotate_drop_std_sessions_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_298, false); A_arbace_repr_go_annotate_drop_std_sessions_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_31)); return A_arbace_repr_go_annotate__init_A_const_30 }








func A_arbace_repr_go_annotate__init_A_Unit18__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(173, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_32; var tmp2 any = A_arbace_repr_go_annotate_std_load_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_repr_go_annotate_std_load_QMARK__A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_299, false); A_arbace_repr_go_annotate_std_load_QMARK__A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_33)); return A_arbace_repr_go_annotate__init_A_const_32 }


func A_arbace_repr_go_annotate__init_A_Unit19__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(176, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_34; var tmp2 any = A_arbace_repr_go_annotate_variant_key_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_repr_go_annotate_variant_key_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_300, false); A_arbace_repr_go_annotate_variant_key_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_35)); return A_arbace_repr_go_annotate__init_A_const_34 }

func A_arbace_repr_go_annotate__init_A_Unit20__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(178, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_36; var tmp2 any = A_arbace_repr_go_annotate_job_key_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_repr_go_annotate_job_key_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_301, false); A_arbace_repr_go_annotate_job_key_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_37)); return A_arbace_repr_go_annotate__init_A_const_36 }











func A_arbace_repr_go_annotate__init_A_Unit21__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_38; var tmp2 any = A_arbace_repr_go_annotate_job_imports_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_repr_go_annotate_job_imports_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_302, false); A_arbace_repr_go_annotate_job_imports_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_39)); return A_arbace_repr_go_annotate__init_A_const_38 }









func A_arbace_repr_go_annotate__init_A_Unit22__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(200, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_40; var tmp2 any = A_arbace_repr_go_annotate_load_sessions_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_repr_go_annotate_load_sessions_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_303, false); A_arbace_repr_go_annotate_load_sessions_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_41)); return A_arbace_repr_go_annotate__init_A_const_40 }





























func A_arbace_repr_go_annotate__init_A_Unit23__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(230, 1); A_arbace_repr_go_annotate__init_A_const_42.BindRoot_O__V(A_arbace_repr_go_annotate__init_A_const_43); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_42; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_44)); return A_arbace_repr_go_annotate__init_A_const_42 }





func A_arbace_repr_go_annotate__init_A_Unit24__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(236, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_45; var tmp2 any = A_arbace_repr_go_annotate_node_index_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_repr_go_annotate_node_index_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_304, false); A_arbace_repr_go_annotate_node_index_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_46)); return A_arbace_repr_go_annotate__init_A_const_45 }



















func A_arbace_repr_go_annotate__init_A_Unit25__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(256, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_47; var tmp2 any = A_arbace_repr_go_annotate_node_of_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_repr_go_annotate_node_of_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_305, false); A_arbace_repr_go_annotate_node_of_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_48)); return A_arbace_repr_go_annotate__init_A_const_47 }










func A_arbace_repr_go_annotate__init_A_Unit26__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(267, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_49; var tmp2 any = A_arbace_repr_go_annotate_new_table_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_repr_go_annotate_new_table_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_306, false); A_arbace_repr_go_annotate_new_table_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_50)); return A_arbace_repr_go_annotate__init_A_const_49 }

func A_arbace_repr_go_annotate__init_A_Unit27__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(269, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_51; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_52)); return A_arbace_repr_go_annotate__init_A_const_51 }

func A_arbace_repr_go_annotate__init_A_Unit28__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(271, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_53; var tmp2 any = A_arbace_repr_go_annotate_entry_of_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_repr_go_annotate_entry_of_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_307, false); A_arbace_repr_go_annotate_entry_of_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_54)); return A_arbace_repr_go_annotate__init_A_const_53 }


























































func A_arbace_repr_go_annotate__init_A_Unit29__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(330, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_51; var tmp2 any = A_arbace_repr_go_annotate_type_id_BANG__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_repr_go_annotate_type_id_BANG__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_308, false); A_arbace_repr_go_annotate_type_id_BANG__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_55)); return A_arbace_repr_go_annotate__init_A_const_51 }





















func A_arbace_repr_go_annotate__init_A_Unit30__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(352, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_56; var tmp2 any = A_arbace_repr_go_annotate_float_shape_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_repr_go_annotate_float_shape_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_309, false); A_arbace_repr_go_annotate_float_shape_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_57)); return A_arbace_repr_go_annotate__init_A_const_56 }




func A_arbace_repr_go_annotate__init_A_Unit31__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(357, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_58; var tmp2 any = A_arbace_repr_go_annotate_val_shape_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_repr_go_annotate_val_shape_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_310, false); A_arbace_repr_go_annotate_val_shape_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_59)); return A_arbace_repr_go_annotate__init_A_const_58 }



















func A_arbace_repr_go_annotate__init_A_Unit32__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(377, 1); A_arbace_repr_go_annotate__init_A_const_60.BindRoot_O__V(A_arbace_repr_go_annotate__init_A_const_61); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_60; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_62)); return A_arbace_repr_go_annotate__init_A_const_60 }



func A_arbace_repr_go_annotate__init_A_Unit33__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(381, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_63; var tmp2 any = A_arbace_repr_go_annotate_obj_annotation_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_repr_go_annotate_obj_annotation_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_311, false); A_arbace_repr_go_annotate_obj_annotation_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_63; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_64)); return A_arbace_repr_go_annotate__init_A_const_63 }


















func A_arbace_repr_go_annotate__init_A_Unit34__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(400, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_65; var tmp2 any = A_arbace_repr_go_annotate_annotation_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_repr_go_annotate_annotation_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_312, false); A_arbace_repr_go_annotate_annotation_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_65; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_66)); return A_arbace_repr_go_annotate__init_A_const_65 }























func A_arbace_repr_go_annotate__init_A_Unit35__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(424, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_67; var tmp2 any = A_arbace_repr_go_annotate_rebuild_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_repr_go_annotate_rebuild_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_313, false); A_arbace_repr_go_annotate_rebuild_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_68)); return A_arbace_repr_go_annotate__init_A_const_67 }


























func A_arbace_repr_go_annotate__init_A_Unit36__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(451, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_69; var tmp2 any = A_arbace_repr_go_annotate_annotate_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_repr_go_annotate_annotate_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_314, false); A_arbace_repr_go_annotate_annotate_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_69; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_70)); return A_arbace_repr_go_annotate__init_A_const_69 }











































func A_arbace_repr_go_annotate__init_A_Unit37__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(495, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_71; var tmp2 any = A_arbace_repr_go_annotate_short_str_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_repr_go_annotate_short_str_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_315, false); A_arbace_repr_go_annotate_short_str_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_71; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_72)); return A_arbace_repr_go_annotate__init_A_const_71 }



func A_arbace_repr_go_annotate__init_A_Unit38__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(499, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_73; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_74)); return A_arbace_repr_go_annotate__init_A_const_73 }

func A_arbace_repr_go_annotate__init_A_Unit39__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(501, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_75; var tmp2 any = A_arbace_repr_go_annotate_same_meta_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_repr_go_annotate_same_meta_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_316, false); A_arbace_repr_go_annotate_same_meta_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_76)); return A_arbace_repr_go_annotate__init_A_const_75 }






func A_arbace_repr_go_annotate__init_A_Unit40__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(508, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_77; var tmp2 any = A_arbace_repr_go_annotate_same_seq_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_repr_go_annotate_same_seq_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_317, false); A_arbace_repr_go_annotate_same_seq_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_77; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_78)); return A_arbace_repr_go_annotate__init_A_const_77 }




func A_arbace_repr_go_annotate__init_A_Unit41__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(513, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_73; var tmp2 any = A_arbace_repr_go_annotate_same_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_repr_go_annotate_same_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_318, false); A_arbace_repr_go_annotate_same_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_79)); return A_arbace_repr_go_annotate__init_A_const_73 }














func A_arbace_repr_go_annotate__init_A_Unit42__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(528, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_80; var tmp2 any = A_arbace_repr_go_annotate_line_at_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_repr_go_annotate_line_at_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_319, false); A_arbace_repr_go_annotate_line_at_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_81)); return A_arbace_repr_go_annotate__init_A_const_80 }











func A_arbace_repr_go_annotate__init_A_Unit43__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(540, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_82; var tmp2 any = A_arbace_repr_go_annotate_same_package_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_repr_go_annotate_same_package_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_320, false); A_arbace_repr_go_annotate_same_package_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_83)); return A_arbace_repr_go_annotate__init_A_const_82 }















func A_arbace_repr_go_annotate__init_A_Unit44__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(556, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_84; var tmp2 any = A_arbace_repr_go_annotate_external_test_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_repr_go_annotate_external_test_QMARK__A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_321, false); A_arbace_repr_go_annotate_external_test_QMARK__A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_85)); return A_arbace_repr_go_annotate__init_A_const_84 }


func A_arbace_repr_go_annotate__init_A_Unit45__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(559, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_86; var tmp2 any = A_arbace_repr_go_annotate_xtest_session_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_repr_go_annotate_xtest_session_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_322, false); A_arbace_repr_go_annotate_xtest_session_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_87)); return A_arbace_repr_go_annotate__init_A_const_86 }






















func A_arbace_repr_go_annotate__init_A_Unit46__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(582, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_88; var tmp2 any = A_arbace_repr_go_annotate_checked_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_repr_go_annotate_checked_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_323, false); A_arbace_repr_go_annotate_checked_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_89)); return A_arbace_repr_go_annotate__init_A_const_88 }


















func A_arbace_repr_go_annotate__init_A_Unit47__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(601, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_90; var tmp2 any = A_arbace_repr_go_annotate_first_line_diff_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_repr_go_annotate_first_line_diff_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_324, false); A_arbace_repr_go_annotate_first_line_diff_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_91)); return A_arbace_repr_go_annotate__init_A_const_90 }






func A_arbace_repr_go_annotate__init_A_Unit48__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(608, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_92; var tmp2 any = A_arbace_repr_go_annotate_forms_diff_A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_repr_go_annotate_forms_diff_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_325, false); A_arbace_repr_go_annotate_forms_diff_A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_93)); return A_arbace_repr_go_annotate__init_A_const_92 }
















func A_arbace_repr_go_annotate__init_A_Unit49__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(625, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_94; var tmp2 any = A_arbace_repr_go_annotate_convert_full_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_repr_go_annotate_convert_full_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_326, false); A_arbace_repr_go_annotate_convert_full_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_95)); return A_arbace_repr_go_annotate__init_A_const_94 }


func A_arbace_repr_go_annotate__init_A_Unit50__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(628, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_96; var tmp2 any = A_arbace_repr_go_annotate_check_job_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_repr_go_annotate_check_job_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_327, false); A_arbace_repr_go_annotate_check_job_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_97)); return A_arbace_repr_go_annotate__init_A_const_96 }




































































func A_arbace_repr_go_annotate__init_A_Unit51__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(697, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_98; var tmp2 any = A_arbace_repr_go_annotate_read_spec_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_repr_go_annotate_read_spec_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_328, false); A_arbace_repr_go_annotate_read_spec_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_99)); return A_arbace_repr_go_annotate__init_A_const_98 }

func A_arbace_repr_go_annotate__init_A_Unit52__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(699, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_100; var tmp2 any = A_arbace_repr_go_annotate_spec_loads_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_repr_go_annotate_spec_loads_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_329, false); A_arbace_repr_go_annotate_spec_loads_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_101)); return A_arbace_repr_go_annotate__init_A_const_100 }








func A_arbace_repr_go_annotate__init_A_Unit53__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(708, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_102; var tmp2 any = A_arbace_repr_go_annotate_merge_counts_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_repr_go_annotate_merge_counts_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_330, false); A_arbace_repr_go_annotate_merge_counts_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_103)); return A_arbace_repr_go_annotate__init_A_const_102 }

func A_arbace_repr_go_annotate__init_A_Unit54__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(710, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_104; var tmp2 any = A_arbace_repr_go_annotate_helper_results_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_repr_go_annotate_helper_results_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_331, false); A_arbace_repr_go_annotate_helper_results_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_105)); return A_arbace_repr_go_annotate__init_A_const_104 }







func A_arbace_repr_go_annotate__init_A_Unit55__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(718, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_106; var tmp2 any = A_arbace_repr_go_annotate_check_corpus_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_repr_go_annotate_check_corpus_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_332, false); A_arbace_repr_go_annotate_check_corpus_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_107)); return A_arbace_repr_go_annotate__init_A_const_106 }



















































































func A_arbace_repr_go_annotate__init_A_Unit56__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(802, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_108; var tmp2 any = A_arbace_repr_go_annotate_tsv_line_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_repr_go_annotate_tsv_line_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_333, false); A_arbace_repr_go_annotate_tsv_line_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_109)); return A_arbace_repr_go_annotate__init_A_const_108 }






func A_arbace_repr_go_annotate__init_A_Unit57__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(809, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_110; var tmp2 any = A_arbace_repr_go_annotate_error_text_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_repr_go_annotate_error_text_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_334, false); A_arbace_repr_go_annotate_error_text_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_110; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_111)); return A_arbace_repr_go_annotate__init_A_const_110 }

func A_arbace_repr_go_annotate__init_A_Unit58__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(811, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_112; var tmp2 any = A_arbace_repr_go_annotate_read_job_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_repr_go_annotate_read_job_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_335, false); A_arbace_repr_go_annotate_read_job_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_112; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_113)); return A_arbace_repr_go_annotate__init_A_const_112 }




































func A_arbace_repr_go_annotate__init_A_Unit59__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(848, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_114; var tmp2 any = A_arbace_repr_go_annotate_read_corpus_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_repr_go_annotate_read_corpus_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_336, false); A_arbace_repr_go_annotate_read_corpus_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_115)); return A_arbace_repr_go_annotate__init_A_const_114 }


































func A_arbace_repr_go_annotate__init_A_Unit60__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(883, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_116; var tmp2 any = A_arbace_repr_go_annotate__main_A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_repr_go_annotate__main_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_337, true); A_arbace_repr_go_annotate__main_A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_117)); return A_arbace_repr_go_annotate__init_A_const_116 }



type A_arbace_repr_go_annotate__init_A struct{ jrt.Object }

var A_arbace_repr_go_annotate__init_A_const_pool *jrt.RefArray

var A_arbace_repr_go_annotate__init_A_const_0 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_1 any

var A_arbace_repr_go_annotate__init_A_const_2 any

var A_arbace_repr_go_annotate__init_A_const_3 any

var A_arbace_repr_go_annotate__init_A_const_4 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_5 any

var A_arbace_repr_go_annotate__init_A_const_6 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_7 any

var A_arbace_repr_go_annotate__init_A_const_8 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_9 any

var A_arbace_repr_go_annotate__init_A_const_10 any

var A_arbace_repr_go_annotate__init_A_const_11 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_12 any

var A_arbace_repr_go_annotate__init_A_const_13 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_14 any

var A_arbace_repr_go_annotate__init_A_const_15 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_16 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_17 any

var A_arbace_repr_go_annotate__init_A_const_18 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_19 any

var A_arbace_repr_go_annotate__init_A_const_20 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_21 any

var A_arbace_repr_go_annotate__init_A_const_22 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_23 any

var A_arbace_repr_go_annotate__init_A_const_24 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_25 any

var A_arbace_repr_go_annotate__init_A_const_26 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_27 any

var A_arbace_repr_go_annotate__init_A_const_28 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_29 any

var A_arbace_repr_go_annotate__init_A_const_30 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_31 any

var A_arbace_repr_go_annotate__init_A_const_32 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_33 any

var A_arbace_repr_go_annotate__init_A_const_34 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_35 any

var A_arbace_repr_go_annotate__init_A_const_36 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_37 any

var A_arbace_repr_go_annotate__init_A_const_38 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_39 any

var A_arbace_repr_go_annotate__init_A_const_40 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_41 any

var A_arbace_repr_go_annotate__init_A_const_42 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_43 any

var A_arbace_repr_go_annotate__init_A_const_44 any

var A_arbace_repr_go_annotate__init_A_const_45 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_46 any

var A_arbace_repr_go_annotate__init_A_const_47 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_48 any

var A_arbace_repr_go_annotate__init_A_const_49 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_50 any

var A_arbace_repr_go_annotate__init_A_const_51 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_52 any

var A_arbace_repr_go_annotate__init_A_const_53 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_54 any

var A_arbace_repr_go_annotate__init_A_const_55 any

var A_arbace_repr_go_annotate__init_A_const_56 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_57 any

var A_arbace_repr_go_annotate__init_A_const_58 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_59 any

var A_arbace_repr_go_annotate__init_A_const_60 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_61 any

var A_arbace_repr_go_annotate__init_A_const_62 any

var A_arbace_repr_go_annotate__init_A_const_63 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_64 any

var A_arbace_repr_go_annotate__init_A_const_65 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_66 any

var A_arbace_repr_go_annotate__init_A_const_67 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_68 any

var A_arbace_repr_go_annotate__init_A_const_69 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_70 any

var A_arbace_repr_go_annotate__init_A_const_71 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_72 any

var A_arbace_repr_go_annotate__init_A_const_73 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_74 any

var A_arbace_repr_go_annotate__init_A_const_75 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_76 any

var A_arbace_repr_go_annotate__init_A_const_77 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_78 any

var A_arbace_repr_go_annotate__init_A_const_79 any

var A_arbace_repr_go_annotate__init_A_const_80 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_81 any

var A_arbace_repr_go_annotate__init_A_const_82 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_83 any

var A_arbace_repr_go_annotate__init_A_const_84 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_85 any

var A_arbace_repr_go_annotate__init_A_const_86 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_87 any

var A_arbace_repr_go_annotate__init_A_const_88 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_89 any

var A_arbace_repr_go_annotate__init_A_const_90 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_91 any

var A_arbace_repr_go_annotate__init_A_const_92 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_93 any

var A_arbace_repr_go_annotate__init_A_const_94 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_95 any

var A_arbace_repr_go_annotate__init_A_const_96 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_97 any

var A_arbace_repr_go_annotate__init_A_const_98 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_99 any

var A_arbace_repr_go_annotate__init_A_const_100 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_101 any

var A_arbace_repr_go_annotate__init_A_const_102 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_103 any

var A_arbace_repr_go_annotate__init_A_const_104 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_105 any

var A_arbace_repr_go_annotate__init_A_const_106 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_107 any

var A_arbace_repr_go_annotate__init_A_const_108 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_109 any

var A_arbace_repr_go_annotate__init_A_const_110 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_111 any

var A_arbace_repr_go_annotate__init_A_const_112 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_113 any

var A_arbace_repr_go_annotate__init_A_const_114 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_115 any

var A_arbace_repr_go_annotate__init_A_const_116 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_117 any

var A_arbace_repr_go_annotate__init_A_init jrt.ClassInit

func A_arbace_repr_go_annotate__init_A_Init() { if !A_arbace_repr_go_annotate__init_A_init.Done() { A_arbace_repr_go_annotate__init_A_init.Run(A_arbace_repr_go_annotate__init_A_clinit) } }

func A_arbace_repr_go_annotate__init_A_clinit() { A_arbace_repr_go_annotate__init_A_clinit_p0(); A_arbace_repr_go_annotate__init_A_clinit_p1(); A_arbace_repr_go_annotate__init_A_clinit_p2(); A_arbace_repr_go_annotate__init_A_clinit_p3(); A_arbace_repr_go_annotate__init_A_clinit_p4(); A_arbace_repr_go_annotate__init_A_clinit_p5(); A_arbace_repr_go_annotate__init_A_clinit_p6(); A_arbace_repr_go_annotate__init_A_clinit_p7(); A_arbace_repr_go_annotate__init_A_clinit_p8() }

func A_arbace_repr_go_annotate__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_annotate__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_284, 214); A_arbace_repr_go_annotate__init_A_const_0 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[96]); A_arbace_repr_go_annotate__init_A_const_1 = A_arbace_repr_go_annotate__init_A_const_pool.A[97]; A_arbace_repr_go_annotate__init_A_const_2 = A_arbace_repr_go_annotate__init_A_const_pool.A[98]; A_arbace_repr_go_annotate__init_A_const_3 = A_arbace_repr_go_annotate__init_A_const_pool.A[99]; A_arbace_repr_go_annotate__init_A_const_4 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[100]); A_arbace_repr_go_annotate__init_A_const_5 = A_arbace_repr_go_annotate__init_A_const_pool.A[101]; A_arbace_repr_go_annotate__init_A_const_6 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[102]); A_arbace_repr_go_annotate__init_A_const_7 = A_arbace_repr_go_annotate__init_A_const_pool.A[103]; A_arbace_repr_go_annotate__init_A_const_8 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[104]); A_arbace_repr_go_annotate__init_A_const_9 = A_arbace_repr_go_annotate__init_A_const_pool.A[105]; A_arbace_repr_go_annotate__init_A_const_10 = A_arbace_repr_go_annotate__init_A_const_pool.A[106]; A_arbace_repr_go_annotate__init_A_const_11 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[107]); A_arbace_repr_go_annotate__init_A_const_12 = A_arbace_repr_go_annotate__init_A_const_pool.A[108] }

func A_arbace_repr_go_annotate__init_A_clinit_p1() { A_arbace_repr_go_annotate__init_A_const_13 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[109]); A_arbace_repr_go_annotate__init_A_const_14 = A_arbace_repr_go_annotate__init_A_const_pool.A[110]; A_arbace_repr_go_annotate__init_A_const_15 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[111]); A_arbace_repr_go_annotate__init_A_const_16 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[112]); A_arbace_repr_go_annotate__init_A_const_17 = A_arbace_repr_go_annotate__init_A_const_pool.A[113]; A_arbace_repr_go_annotate__init_A_const_18 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[114]); A_arbace_repr_go_annotate__init_A_const_19 = A_arbace_repr_go_annotate__init_A_const_pool.A[115]; A_arbace_repr_go_annotate__init_A_const_20 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[116]); A_arbace_repr_go_annotate__init_A_const_21 = A_arbace_repr_go_annotate__init_A_const_pool.A[117]; A_arbace_repr_go_annotate__init_A_const_22 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[118]); A_arbace_repr_go_annotate__init_A_const_23 = A_arbace_repr_go_annotate__init_A_const_pool.A[119]; A_arbace_repr_go_annotate__init_A_const_24 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[120]); A_arbace_repr_go_annotate__init_A_const_25 = A_arbace_repr_go_annotate__init_A_const_pool.A[121] }

func A_arbace_repr_go_annotate__init_A_clinit_p2() { A_arbace_repr_go_annotate__init_A_const_26 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[122]); A_arbace_repr_go_annotate__init_A_const_27 = A_arbace_repr_go_annotate__init_A_const_pool.A[123]; A_arbace_repr_go_annotate__init_A_const_28 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[124]); A_arbace_repr_go_annotate__init_A_const_29 = A_arbace_repr_go_annotate__init_A_const_pool.A[125]; A_arbace_repr_go_annotate__init_A_const_30 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[126]); A_arbace_repr_go_annotate__init_A_const_31 = A_arbace_repr_go_annotate__init_A_const_pool.A[127]; A_arbace_repr_go_annotate__init_A_const_32 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[128]); A_arbace_repr_go_annotate__init_A_const_33 = A_arbace_repr_go_annotate__init_A_const_pool.A[129]; A_arbace_repr_go_annotate__init_A_const_34 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[130]); A_arbace_repr_go_annotate__init_A_const_35 = A_arbace_repr_go_annotate__init_A_const_pool.A[131]; A_arbace_repr_go_annotate__init_A_const_36 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[132]); A_arbace_repr_go_annotate__init_A_const_37 = A_arbace_repr_go_annotate__init_A_const_pool.A[133]; A_arbace_repr_go_annotate__init_A_const_38 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[134]) }

func A_arbace_repr_go_annotate__init_A_clinit_p3() { A_arbace_repr_go_annotate__init_A_const_39 = A_arbace_repr_go_annotate__init_A_const_pool.A[135]; A_arbace_repr_go_annotate__init_A_const_40 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[136]); A_arbace_repr_go_annotate__init_A_const_41 = A_arbace_repr_go_annotate__init_A_const_pool.A[137]; A_arbace_repr_go_annotate__init_A_const_42 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[138]); A_arbace_repr_go_annotate__init_A_const_43 = A_arbace_repr_go_annotate__init_A_const_pool.A[139]; A_arbace_repr_go_annotate__init_A_const_44 = A_arbace_repr_go_annotate__init_A_const_pool.A[140]; A_arbace_repr_go_annotate__init_A_const_45 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[141]); A_arbace_repr_go_annotate__init_A_const_46 = A_arbace_repr_go_annotate__init_A_const_pool.A[142]; A_arbace_repr_go_annotate__init_A_const_47 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[143]); A_arbace_repr_go_annotate__init_A_const_48 = A_arbace_repr_go_annotate__init_A_const_pool.A[144]; A_arbace_repr_go_annotate__init_A_const_49 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[145]); A_arbace_repr_go_annotate__init_A_const_50 = A_arbace_repr_go_annotate__init_A_const_pool.A[146]; A_arbace_repr_go_annotate__init_A_const_51 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[147]); A_arbace_repr_go_annotate__init_A_const_52 = A_arbace_repr_go_annotate__init_A_const_pool.A[148] }

func A_arbace_repr_go_annotate__init_A_clinit_p4() { A_arbace_repr_go_annotate__init_A_const_53 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[149]); A_arbace_repr_go_annotate__init_A_const_54 = A_arbace_repr_go_annotate__init_A_const_pool.A[150]; A_arbace_repr_go_annotate__init_A_const_55 = A_arbace_repr_go_annotate__init_A_const_pool.A[151]; A_arbace_repr_go_annotate__init_A_const_56 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[152]); A_arbace_repr_go_annotate__init_A_const_57 = A_arbace_repr_go_annotate__init_A_const_pool.A[153]; A_arbace_repr_go_annotate__init_A_const_58 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[154]); A_arbace_repr_go_annotate__init_A_const_59 = A_arbace_repr_go_annotate__init_A_const_pool.A[155]; A_arbace_repr_go_annotate__init_A_const_60 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[156]); A_arbace_repr_go_annotate__init_A_const_61 = A_arbace_repr_go_annotate__init_A_const_pool.A[157]; A_arbace_repr_go_annotate__init_A_const_62 = A_arbace_repr_go_annotate__init_A_const_pool.A[158]; A_arbace_repr_go_annotate__init_A_const_63 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[159]); A_arbace_repr_go_annotate__init_A_const_64 = A_arbace_repr_go_annotate__init_A_const_pool.A[160]; A_arbace_repr_go_annotate__init_A_const_65 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[161]); A_arbace_repr_go_annotate__init_A_const_66 = A_arbace_repr_go_annotate__init_A_const_pool.A[162] }

func A_arbace_repr_go_annotate__init_A_clinit_p5() { A_arbace_repr_go_annotate__init_A_const_67 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[163]); A_arbace_repr_go_annotate__init_A_const_68 = A_arbace_repr_go_annotate__init_A_const_pool.A[164]; A_arbace_repr_go_annotate__init_A_const_69 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[165]); A_arbace_repr_go_annotate__init_A_const_70 = A_arbace_repr_go_annotate__init_A_const_pool.A[166]; A_arbace_repr_go_annotate__init_A_const_71 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[167]); A_arbace_repr_go_annotate__init_A_const_72 = A_arbace_repr_go_annotate__init_A_const_pool.A[168]; A_arbace_repr_go_annotate__init_A_const_73 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[169]); A_arbace_repr_go_annotate__init_A_const_74 = A_arbace_repr_go_annotate__init_A_const_pool.A[170]; A_arbace_repr_go_annotate__init_A_const_75 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[171]); A_arbace_repr_go_annotate__init_A_const_76 = A_arbace_repr_go_annotate__init_A_const_pool.A[172]; A_arbace_repr_go_annotate__init_A_const_77 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[173]); A_arbace_repr_go_annotate__init_A_const_78 = A_arbace_repr_go_annotate__init_A_const_pool.A[174]; A_arbace_repr_go_annotate__init_A_const_79 = A_arbace_repr_go_annotate__init_A_const_pool.A[175] }

func A_arbace_repr_go_annotate__init_A_clinit_p6() { A_arbace_repr_go_annotate__init_A_const_80 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[176]); A_arbace_repr_go_annotate__init_A_const_81 = A_arbace_repr_go_annotate__init_A_const_pool.A[177]; A_arbace_repr_go_annotate__init_A_const_82 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[178]); A_arbace_repr_go_annotate__init_A_const_83 = A_arbace_repr_go_annotate__init_A_const_pool.A[179]; A_arbace_repr_go_annotate__init_A_const_84 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[180]); A_arbace_repr_go_annotate__init_A_const_85 = A_arbace_repr_go_annotate__init_A_const_pool.A[181]; A_arbace_repr_go_annotate__init_A_const_86 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[182]); A_arbace_repr_go_annotate__init_A_const_87 = A_arbace_repr_go_annotate__init_A_const_pool.A[183]; A_arbace_repr_go_annotate__init_A_const_88 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[184]); A_arbace_repr_go_annotate__init_A_const_89 = A_arbace_repr_go_annotate__init_A_const_pool.A[185]; A_arbace_repr_go_annotate__init_A_const_90 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[186]); A_arbace_repr_go_annotate__init_A_const_91 = A_arbace_repr_go_annotate__init_A_const_pool.A[187]; A_arbace_repr_go_annotate__init_A_const_92 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[188]) }

func A_arbace_repr_go_annotate__init_A_clinit_p7() { A_arbace_repr_go_annotate__init_A_const_93 = A_arbace_repr_go_annotate__init_A_const_pool.A[189]; A_arbace_repr_go_annotate__init_A_const_94 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[190]); A_arbace_repr_go_annotate__init_A_const_95 = A_arbace_repr_go_annotate__init_A_const_pool.A[191]; A_arbace_repr_go_annotate__init_A_const_96 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[192]); A_arbace_repr_go_annotate__init_A_const_97 = A_arbace_repr_go_annotate__init_A_const_pool.A[193]; A_arbace_repr_go_annotate__init_A_const_98 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[194]); A_arbace_repr_go_annotate__init_A_const_99 = A_arbace_repr_go_annotate__init_A_const_pool.A[195]; A_arbace_repr_go_annotate__init_A_const_100 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[196]); A_arbace_repr_go_annotate__init_A_const_101 = A_arbace_repr_go_annotate__init_A_const_pool.A[197]; A_arbace_repr_go_annotate__init_A_const_102 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[198]); A_arbace_repr_go_annotate__init_A_const_103 = A_arbace_repr_go_annotate__init_A_const_pool.A[199]; A_arbace_repr_go_annotate__init_A_const_104 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[200]); A_arbace_repr_go_annotate__init_A_const_105 = A_arbace_repr_go_annotate__init_A_const_pool.A[201] }

func A_arbace_repr_go_annotate__init_A_clinit_p8() { A_arbace_repr_go_annotate__init_A_const_106 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[202]); A_arbace_repr_go_annotate__init_A_const_107 = A_arbace_repr_go_annotate__init_A_const_pool.A[203]; A_arbace_repr_go_annotate__init_A_const_108 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[204]); A_arbace_repr_go_annotate__init_A_const_109 = A_arbace_repr_go_annotate__init_A_const_pool.A[205]; A_arbace_repr_go_annotate__init_A_const_110 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[206]); A_arbace_repr_go_annotate__init_A_const_111 = A_arbace_repr_go_annotate__init_A_const_pool.A[207]; A_arbace_repr_go_annotate__init_A_const_112 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[208]); A_arbace_repr_go_annotate__init_A_const_113 = A_arbace_repr_go_annotate__init_A_const_pool.A[209]; A_arbace_repr_go_annotate__init_A_const_114 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[210]); A_arbace_repr_go_annotate__init_A_const_115 = A_arbace_repr_go_annotate__init_A_const_pool.A[211]; A_arbace_repr_go_annotate__init_A_const_116 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[212]); A_arbace_repr_go_annotate__init_A_const_117 = A_arbace_repr_go_annotate__init_A_const_pool.A[213] }

func A_arbace_repr_go_annotate__init_A_New() *A_arbace_repr_go_annotate__init_A { A_arbace_repr_go_annotate__init_A_Init(); t := &A_arbace_repr_go_annotate__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_annotate__init_A) Ctor() {}

func (t *A_arbace_repr_go_annotate__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_annotate__init_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_annotate__init_A_class }

func (t *A_arbace_repr_go_annotate__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_annotate__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_annotate__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_annotate__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_annotate__init_A); return ok }

func A_arbace_repr_go_annotate__init_A_Cast(x any) *A_arbace_repr_go_annotate__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_annotate__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_annotate__init_A_class)) }; return v }
