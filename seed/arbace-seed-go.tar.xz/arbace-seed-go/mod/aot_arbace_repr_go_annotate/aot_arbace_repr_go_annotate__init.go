//line aot_arbace_repr_go_annotate__init.ae:1
package aot_arbace_repr_go_annotate

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_repr_go_annotate__init_A_Unit0__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_repr_go_annotate__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_repr_go_annotate__init_A_const_1) }
//line :1:1
func A_arbace_repr_go_annotate__init_A_Unit1__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_repr_go_annotate__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_2)) }
//line :1:1
func A_arbace_repr_go_annotate__init_A_Unit2__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_repr_go_annotate_eval1950000004_loading__1927001464__auto____1950000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_repr_go_annotate_eval1950000004_loading__1927001464__auto____1950000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_297, false, nil); A_arbace_repr_go_annotate_eval1950000004_loading__1927001464__auto____1950000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_repr_go_annotate__init_A_Unit3__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_repr_go_annotate__init_A_const_1)).Equals_O__Z(A_arbace_repr_go_annotate__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_repr_go_annotate_eval1950000008_fn__1950000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_repr_go_annotate_eval1950000008_fn__1950000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_298, false, nil); A_arbace_repr_go_annotate_eval1950000008_fn__1950000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_repr_go_annotate__init_A_Load__O() any { A_arbace_repr_go_annotate__init_A_Init(); jrt.StartCheck(); A_arbace_repr_go_annotate__init_A_Unit0__O(); A_arbace_repr_go_annotate__init_A_Unit1__O(); A_arbace_repr_go_annotate__init_A_Unit2__O(); A_arbace_repr_go_annotate__init_A_Unit3__O(); A_arbace_repr_go_annotate__init_A_Unit4__O(); A_arbace_repr_go_annotate__init_A_Unit5__O(); A_arbace_repr_go_annotate__init_A_Unit6__O(); A_arbace_repr_go_annotate__init_A_Unit7__O(); A_arbace_repr_go_annotate__init_A_Unit8__O(); A_arbace_repr_go_annotate__init_A_Unit9__O(); A_arbace_repr_go_annotate__init_A_Unit10__O(); A_arbace_repr_go_annotate__init_A_Unit11__O(); A_arbace_repr_go_annotate__init_A_Unit12__O(); A_arbace_repr_go_annotate__init_A_Unit13__O(); A_arbace_repr_go_annotate__init_A_Unit14__O(); A_arbace_repr_go_annotate__init_A_Unit15__O(); A_arbace_repr_go_annotate__init_A_Unit16__O(); A_arbace_repr_go_annotate__init_A_Unit17__O(); A_arbace_repr_go_annotate__init_A_Unit18__O(); A_arbace_repr_go_annotate__init_A_Unit19__O(); A_arbace_repr_go_annotate__init_A_Unit20__O(); A_arbace_repr_go_annotate__init_A_Unit21__O(); A_arbace_repr_go_annotate__init_A_Unit22__O(); A_arbace_repr_go_annotate__init_A_Unit23__O(); A_arbace_repr_go_annotate__init_A_Unit24__O(); A_arbace_repr_go_annotate__init_A_Unit25__O(); A_arbace_repr_go_annotate__init_A_Unit26__O(); A_arbace_repr_go_annotate__init_A_Unit27__O(); A_arbace_repr_go_annotate__init_A_Unit28__O(); A_arbace_repr_go_annotate__init_A_Unit29__O(); A_arbace_repr_go_annotate__init_A_Unit30__O(); A_arbace_repr_go_annotate__init_A_Unit31__O(); A_arbace_repr_go_annotate__init_A_Unit32__O(); A_arbace_repr_go_annotate__init_A_Unit33__O(); A_arbace_repr_go_annotate__init_A_Unit34__O(); A_arbace_repr_go_annotate__init_A_Unit35__O(); A_arbace_repr_go_annotate__init_A_Unit36__O(); A_arbace_repr_go_annotate__init_A_Unit37__O(); A_arbace_repr_go_annotate__init_A_Unit38__O(); A_arbace_repr_go_annotate__init_A_Unit39__O(); A_arbace_repr_go_annotate__init_A_Unit40__O(); A_arbace_repr_go_annotate__init_A_Unit41__O(); A_arbace_repr_go_annotate__init_A_Unit42__O(); A_arbace_repr_go_annotate__init_A_Unit43__O(); A_arbace_repr_go_annotate__init_A_Unit44__O(); A_arbace_repr_go_annotate__init_A_Unit45__O(); A_arbace_repr_go_annotate__init_A_Unit46__O(); A_arbace_repr_go_annotate__init_A_Unit47__O(); A_arbace_repr_go_annotate__init_A_Unit48__O(); A_arbace_repr_go_annotate__init_A_Unit49__O(); A_arbace_repr_go_annotate__init_A_Unit50__O(); A_arbace_repr_go_annotate__init_A_Unit51__O(); A_arbace_repr_go_annotate__init_A_Unit52__O(); A_arbace_repr_go_annotate__init_A_Unit53__O(); A_arbace_repr_go_annotate__init_A_Unit54__O(); A_arbace_repr_go_annotate__init_A_Unit55__O(); A_arbace_repr_go_annotate__init_A_Unit56__O(); A_arbace_repr_go_annotate__init_A_Unit57__O(); A_arbace_repr_go_annotate__init_A_Unit58__O(); A_arbace_repr_go_annotate__init_A_Unit59__O(); A_arbace_repr_go_annotate__init_A_Unit60__O(); A_arbace_repr_go_annotate__init_A_Unit61__O(); A_arbace_repr_go_annotate__init_A_Unit62__O(); A_arbace_repr_go_annotate__init_A_Unit63__O(); A_arbace_repr_go_annotate__init_A_Unit64__O(); A_arbace_repr_go_annotate__init_A_Unit65__O(); A_arbace_repr_go_annotate__init_A_Unit66__O(); return nil }





































func A_arbace_repr_go_annotate__init_A_Unit4__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_repr_go_annotate_private_key_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_repr_go_annotate_private_key_QMARK__A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_299, false, nil); A_arbace_repr_go_annotate_private_key_QMARK__A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_5)); return A_arbace_repr_go_annotate__init_A_const_4 }

func A_arbace_repr_go_annotate__init_A_Unit5__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(45, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_6; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_7)); return A_arbace_repr_go_annotate__init_A_const_6 }

func A_arbace_repr_go_annotate__init_A_Unit6__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_repr_go_annotate_cmeta_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_repr_go_annotate_cmeta_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_300, false, nil); A_arbace_repr_go_annotate_cmeta_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_9)); return A_arbace_repr_go_annotate__init_A_const_8 }











func A_arbace_repr_go_annotate__init_A_Unit7__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(59, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_repr_go_annotate_cform_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_repr_go_annotate_cform_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_301, false, nil); A_arbace_repr_go_annotate_cform_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_10)); return A_arbace_repr_go_annotate__init_A_const_6 }













func A_arbace_repr_go_annotate__init_A_Unit8__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(73, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_11; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_repr_go_annotate_import_specs_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_repr_go_annotate_import_specs_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_302, false, nil); A_arbace_repr_go_annotate_import_specs_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_12)); return A_arbace_repr_go_annotate__init_A_const_11 }




















func A_arbace_repr_go_annotate__init_A_Unit9__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(94, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_13; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_repr_go_annotate_raw_source_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_repr_go_annotate_raw_source_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_303, false, nil); A_arbace_repr_go_annotate_raw_source_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_14)); return A_arbace_repr_go_annotate__init_A_const_13 }














func A_arbace_repr_go_annotate__init_A_Unit10__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(109, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_15; var tmp2 any; var root_15 any = A_arbace_repr_go_annotate__init_A_const_16.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = Lit_304; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_15, arg_18) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_repr_go_annotate__init_A_const_15; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_17)); return A_arbace_repr_go_annotate__init_A_const_15 }

func A_arbace_repr_go_annotate__init_A_Unit11__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_repr_go_annotate_config_key_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_repr_go_annotate_config_key_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_305, false, nil); A_arbace_repr_go_annotate_config_key_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_19)); return A_arbace_repr_go_annotate__init_A_const_18 }



func A_arbace_repr_go_annotate__init_A_Unit12__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(115, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_20; var tmp2 any = A_arbace_repr_go_annotate__init_A_const_21; var tmp3 any = jrt.LongAdder_New(); var tmp4 any = A_arbace_repr_go_annotate__init_A_const_22; var tmp5 any = jrt.LongAdder_New(); var tmp6 any = A_arbace_repr_go_annotate__init_A_const_23; var tmp7 any = jrt.LongAdder_New(); var tmp8 any = A_arbace_repr_go_annotate__init_A_const_24; var tmp9 any = jrt.LongAdder_New(); var tmp10 any = A_arbace_repr_go_annotate__init_A_const_25; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, jrt.LongAdder_New()))); var tmp11 *lang.Var = A_arbace_repr_go_annotate__init_A_const_20; tmp11.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_26)); return A_arbace_repr_go_annotate__init_A_const_20 }





func A_arbace_repr_go_annotate__init_A_Unit13__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(121, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_27; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_repr_go_annotate_phase_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_repr_go_annotate_phase_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_306, false, nil); A_arbace_repr_go_annotate_phase_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_27; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_28)); return A_arbace_repr_go_annotate__init_A_const_27 }

func A_arbace_repr_go_annotate__init_A_Unit14__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(123, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_29; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_repr_go_annotate_phases_text_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_repr_go_annotate_phases_text_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_307, false, nil); A_arbace_repr_go_annotate_phases_text_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_29; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_30)); return A_arbace_repr_go_annotate__init_A_const_29 }





func A_arbace_repr_go_annotate__init_A_Unit15__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(129, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_31; var tmp2 any; var root_25 any = A_arbace_repr_go_annotate__init_A_const_16.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_27 lang.IFn; if




	linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = jrt.Boolean_FALSE.Ref(); if linked_26 == nil { tmp2 = ifn_27.Invoke_O__O(arg_28) } else { tmp2 = linked_26.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_25, arg_28) }; /*line :129:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_repr_go_annotate__init_A_const_31; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_32)); return A_arbace_repr_go_annotate__init_A_const_31 }






func A_arbace_repr_go_annotate__init_A_Unit16__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(136, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_33; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_repr_go_annotate_prep_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_repr_go_annotate_prep_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_308, false, nil); A_arbace_repr_go_annotate_prep_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_33; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_34)); return A_arbace_repr_go_annotate__init_A_const_33 }
















func A_arbace_repr_go_annotate__init_A_Unit17__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(153, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_35; var tmp2 any; var root_31 any = A_arbace_repr_go_annotate__init_A_const_16.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_33 lang.IFn; if




	linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any; if linked_32 == nil { tmp2 = ifn_33.Invoke_O__O(arg_34) } else { tmp2 = linked_32.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_31, arg_34) }; /*line :153:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_repr_go_annotate__init_A_const_35; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_36)); return A_arbace_repr_go_annotate__init_A_const_35 }






func A_arbace_repr_go_annotate__init_A_Unit18__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(160, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_repr_go_annotate_run_task_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_repr_go_annotate_run_task_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_309, false, nil); A_arbace_repr_go_annotate_run_task_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_38)); return A_arbace_repr_go_annotate__init_A_const_37 }






func A_arbace_repr_go_annotate__init_A_Unit19__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_39; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_repr_go_annotate_new_session_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_repr_go_annotate_new_session_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_310, false, nil); A_arbace_repr_go_annotate_new_session_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_40)); return A_arbace_repr_go_annotate__init_A_const_39 }














































func A_arbace_repr_go_annotate__init_A_Unit20__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(214, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_41; var tmp2 any; var root_39 any = A_arbace_repr_go_annotate__init_A_const_16.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_40 == nil { tmp2 = ifn_41.Invoke_O__O(arg_42) } else { tmp2 = linked_40.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_39, arg_42) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_repr_go_annotate__init_A_const_41; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_42)); return A_arbace_repr_go_annotate__init_A_const_41 }

func A_arbace_repr_go_annotate__init_A_Unit21__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(216, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_43; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_repr_go_annotate_std_index_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_repr_go_annotate_std_index_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_311, false, nil); A_arbace_repr_go_annotate_std_index_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_44)); return A_arbace_repr_go_annotate__init_A_const_43 }





func A_arbace_repr_go_annotate__init_A_Unit22__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_45; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_repr_go_annotate_std_session_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_repr_go_annotate_std_session_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_312, false, nil); A_arbace_repr_go_annotate_std_session_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_46)); return A_arbace_repr_go_annotate__init_A_const_45 }









func A_arbace_repr_go_annotate__init_A_Unit23__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(232, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_47; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_repr_go_annotate_drop_std_sessions_BANG__A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_repr_go_annotate_drop_std_sessions_BANG__A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_313, false, nil); A_arbace_repr_go_annotate_drop_std_sessions_BANG__A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_48)); return A_arbace_repr_go_annotate__init_A_const_47 }








func A_arbace_repr_go_annotate__init_A_Unit24__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(241, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_49; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_repr_go_annotate_std_load_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_repr_go_annotate_std_load_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_314, false, nil); A_arbace_repr_go_annotate_std_load_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_50)); return A_arbace_repr_go_annotate__init_A_const_49 }


func A_arbace_repr_go_annotate__init_A_Unit25__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(244, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_51; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_repr_go_annotate_variant_key_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_repr_go_annotate_variant_key_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_315, false, nil); A_arbace_repr_go_annotate_variant_key_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_52)); return A_arbace_repr_go_annotate__init_A_const_51 }

func A_arbace_repr_go_annotate__init_A_Unit26__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(246, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_53; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_repr_go_annotate_job_key_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_repr_go_annotate_job_key_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_316, false, nil); A_arbace_repr_go_annotate_job_key_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_54)); return A_arbace_repr_go_annotate__init_A_const_53 }











func A_arbace_repr_go_annotate__init_A_Unit27__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(258, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_55; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_repr_go_annotate_job_imports_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_repr_go_annotate_job_imports_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_317, false, nil); A_arbace_repr_go_annotate_job_imports_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_55; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_56)); return A_arbace_repr_go_annotate__init_A_const_55 }









func A_arbace_repr_go_annotate__init_A_Unit28__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(268, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_57; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_repr_go_annotate_load_sessions_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_repr_go_annotate_load_sessions_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_318, false, nil); A_arbace_repr_go_annotate_load_sessions_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_57; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_58)); return A_arbace_repr_go_annotate__init_A_const_57 }





























func A_arbace_repr_go_annotate__init_A_Unit29__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); A_arbace_repr_go_annotate__init_A_const_59.BindRoot_O__V(A_arbace_repr_go_annotate__init_A_const_60); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_59; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_61)); return A_arbace_repr_go_annotate__init_A_const_59 }





func A_arbace_repr_go_annotate__init_A_Unit30__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(304, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_repr_go_annotate_node_index_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_repr_go_annotate_node_index_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_319, false, nil); A_arbace_repr_go_annotate_node_index_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_63)); return A_arbace_repr_go_annotate__init_A_const_62 }





















func A_arbace_repr_go_annotate__init_A_Unit31__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(326, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_repr_go_annotate_node_of_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_repr_go_annotate_node_of_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_320, false, nil); A_arbace_repr_go_annotate_node_of_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_65)); return A_arbace_repr_go_annotate__init_A_const_64 }










func A_arbace_repr_go_annotate__init_A_Unit32__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(337, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_repr_go_annotate_new_table_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_repr_go_annotate_new_table_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_321, false, nil); A_arbace_repr_go_annotate_new_table_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_67)); return A_arbace_repr_go_annotate__init_A_const_66 }

func A_arbace_repr_go_annotate__init_A_Unit33__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(339, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_68; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_69)); return A_arbace_repr_go_annotate__init_A_const_68 }

func A_arbace_repr_go_annotate__init_A_Unit34__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(341, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_repr_go_annotate_entry_of_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_repr_go_annotate_entry_of_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_322, false, nil); A_arbace_repr_go_annotate_entry_of_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_71)); return A_arbace_repr_go_annotate__init_A_const_70 }


























































func A_arbace_repr_go_annotate__init_A_Unit35__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(400, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_repr_go_annotate_type_id_BANG__A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_repr_go_annotate_type_id_BANG__A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_323, false, nil); A_arbace_repr_go_annotate_type_id_BANG__A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_72)); return A_arbace_repr_go_annotate__init_A_const_68 }





















func A_arbace_repr_go_annotate__init_A_Unit36__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(422, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_73; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_repr_go_annotate_float_shape_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_repr_go_annotate_float_shape_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_324, false, nil); A_arbace_repr_go_annotate_float_shape_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_73; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_74)); return A_arbace_repr_go_annotate__init_A_const_73 }




func A_arbace_repr_go_annotate__init_A_Unit37__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(427, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_75; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_repr_go_annotate_val_shape_A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_repr_go_annotate_val_shape_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_325, false, nil); A_arbace_repr_go_annotate_val_shape_A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_75; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_76)); return A_arbace_repr_go_annotate__init_A_const_75 }



















func A_arbace_repr_go_annotate__init_A_Unit38__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(447, 1); A_arbace_repr_go_annotate__init_A_const_77.BindRoot_O__V(A_arbace_repr_go_annotate__init_A_const_78); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_77; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_79)); return A_arbace_repr_go_annotate__init_A_const_77 }



func A_arbace_repr_go_annotate__init_A_Unit39__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(451, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_repr_go_annotate_obj_annotation_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_repr_go_annotate_obj_annotation_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_326, false, nil); A_arbace_repr_go_annotate_obj_annotation_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_81)); return A_arbace_repr_go_annotate__init_A_const_80 }


















func A_arbace_repr_go_annotate__init_A_Unit40__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(470, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_repr_go_annotate_annotation_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_repr_go_annotate_annotation_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_327, false, nil); A_arbace_repr_go_annotate_annotation_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_83)); return A_arbace_repr_go_annotate__init_A_const_82 }























func A_arbace_repr_go_annotate__init_A_Unit41__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(494, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_repr_go_annotate_rebuild_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_repr_go_annotate_rebuild_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_328, false, nil); A_arbace_repr_go_annotate_rebuild_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_85)); return A_arbace_repr_go_annotate__init_A_const_84 }




























func A_arbace_repr_go_annotate__init_A_Unit42__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(523, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_repr_go_annotate_annotate_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_repr_go_annotate_annotate_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_329, false, nil); A_arbace_repr_go_annotate_annotate_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_87)); return A_arbace_repr_go_annotate__init_A_const_86 }











































func A_arbace_repr_go_annotate__init_A_Unit43__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(567, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_88; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_repr_go_annotate_short_str_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_repr_go_annotate_short_str_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_330, false, nil); A_arbace_repr_go_annotate_short_str_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_89)); return A_arbace_repr_go_annotate__init_A_const_88 }



func A_arbace_repr_go_annotate__init_A_Unit44__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(571, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_91)); return A_arbace_repr_go_annotate__init_A_const_90 }

func A_arbace_repr_go_annotate__init_A_Unit45__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(573, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_92; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_repr_go_annotate_same_meta_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_repr_go_annotate_same_meta_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_331, false, nil); A_arbace_repr_go_annotate_same_meta_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_93)); return A_arbace_repr_go_annotate__init_A_const_92 }






func A_arbace_repr_go_annotate__init_A_Unit46__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(580, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_94; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_repr_go_annotate_same_seq_A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_repr_go_annotate_same_seq_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_332, false, nil); A_arbace_repr_go_annotate_same_seq_A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_95)); return A_arbace_repr_go_annotate__init_A_const_94 }




func A_arbace_repr_go_annotate__init_A_Unit47__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(585, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_90; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_repr_go_annotate_same_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_repr_go_annotate_same_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_333, false, nil); A_arbace_repr_go_annotate_same_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_96)); return A_arbace_repr_go_annotate__init_A_const_90 }














func A_arbace_repr_go_annotate__init_A_Unit48__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(600, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_repr_go_annotate_line_at_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_repr_go_annotate_line_at_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_334, false, nil); A_arbace_repr_go_annotate_line_at_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_98)); return A_arbace_repr_go_annotate__init_A_const_97 }











func A_arbace_repr_go_annotate__init_A_Unit49__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(612, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_repr_go_annotate_same_package_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_repr_go_annotate_same_package_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_335, false, nil); A_arbace_repr_go_annotate_same_package_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_100)); return A_arbace_repr_go_annotate__init_A_const_99 }















func A_arbace_repr_go_annotate__init_A_Unit50__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(628, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_repr_go_annotate_external_test_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_repr_go_annotate_external_test_QMARK__A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_336, false, nil); A_arbace_repr_go_annotate_external_test_QMARK__A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_102)); return A_arbace_repr_go_annotate__init_A_const_101 }


func A_arbace_repr_go_annotate__init_A_Unit51__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(631, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_repr_go_annotate_xtest_session_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_repr_go_annotate_xtest_session_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_337, false, nil); A_arbace_repr_go_annotate_xtest_session_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_104)); return A_arbace_repr_go_annotate__init_A_const_103 }






















func A_arbace_repr_go_annotate__init_A_Unit52__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(654, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_repr_go_annotate_checked_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_repr_go_annotate_checked_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_338, false, nil); A_arbace_repr_go_annotate_checked_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_106)); return A_arbace_repr_go_annotate__init_A_const_105 }


















func A_arbace_repr_go_annotate__init_A_Unit53__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(673, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_repr_go_annotate_first_line_diff_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_repr_go_annotate_first_line_diff_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_339, false, nil); A_arbace_repr_go_annotate_first_line_diff_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_108)); return A_arbace_repr_go_annotate__init_A_const_107 }






func A_arbace_repr_go_annotate__init_A_Unit54__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(680, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_repr_go_annotate_forms_diff_A_New(); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_repr_go_annotate_forms_diff_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_340, false, nil); A_arbace_repr_go_annotate_forms_diff_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_110)); return A_arbace_repr_go_annotate__init_A_const_109 }
















func A_arbace_repr_go_annotate__init_A_Unit55__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(697, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_111; var tmp2 *lang.Compiler_AOTFn; var fnbody__104 any = A_arbace_repr_go_annotate_convert_full_A_New(); var tmp3 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_repr_go_annotate_convert_full_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_341, false, nil); A_arbace_repr_go_annotate_convert_full_A_fn_class = fncls__103d; tmp3 = fncls__103d } else { tmp3 = fncls__103 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__104, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_112)); return A_arbace_repr_go_annotate__init_A_const_111 }


func A_arbace_repr_go_annotate__init_A_Unit56__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(700, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_113; var tmp2 *lang.Compiler_AOTFn; var fnbody__106 any = A_arbace_repr_go_annotate_check_job_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_repr_go_annotate_check_job_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_342, false, nil); A_arbace_repr_go_annotate_check_job_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__106, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_114)); return A_arbace_repr_go_annotate__init_A_const_113 }




































































func A_arbace_repr_go_annotate__init_A_Unit57__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(769, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_115; var tmp2 *lang.Compiler_AOTFn; var fnbody__108 any = A_arbace_repr_go_annotate_read_spec_A_New(); var tmp3 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_repr_go_annotate_read_spec_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_343, false, nil); A_arbace_repr_go_annotate_read_spec_A_fn_class = fncls__107d; tmp3 = fncls__107d } else { tmp3 = fncls__107 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__108, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_116)); return A_arbace_repr_go_annotate__init_A_const_115 }

func A_arbace_repr_go_annotate__init_A_Unit58__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(771, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_117; var tmp2 *lang.Compiler_AOTFn; var fnbody__110 any = A_arbace_repr_go_annotate_spec_loads_A_New(); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_repr_go_annotate_spec_loads_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_344, false, nil); A_arbace_repr_go_annotate_spec_loads_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__110, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_118)); return A_arbace_repr_go_annotate__init_A_const_117 }








func A_arbace_repr_go_annotate__init_A_Unit59__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(780, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_119; var tmp2 *lang.Compiler_AOTFn; var fnbody__112 any = A_arbace_repr_go_annotate_merge_counts_A_New(); var tmp3 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_repr_go_annotate_merge_counts_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_345, false, nil); A_arbace_repr_go_annotate_merge_counts_A_fn_class = fncls__111d; tmp3 = fncls__111d } else { tmp3 = fncls__111 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__112, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_120)); return A_arbace_repr_go_annotate__init_A_const_119 }

func A_arbace_repr_go_annotate__init_A_Unit60__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(782, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_121; var tmp2 *lang.Compiler_AOTFn; var fnbody__114 any = A_arbace_repr_go_annotate_helper_results_A_New(); var tmp3 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_repr_go_annotate_helper_results_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_346, false, nil); A_arbace_repr_go_annotate_helper_results_A_fn_class = fncls__113d; tmp3 = fncls__113d } else { tmp3 = fncls__113 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__114, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_122)); return A_arbace_repr_go_annotate__init_A_const_121 }







func A_arbace_repr_go_annotate__init_A_Unit61__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(790, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_123; var tmp2 *lang.Compiler_AOTFn; var fnbody__116 any = A_arbace_repr_go_annotate_check_corpus_A_New(); var tmp3 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_repr_go_annotate_check_corpus_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_347, false, nil); A_arbace_repr_go_annotate_check_corpus_A_fn_class = fncls__115d; tmp3 = fncls__115d } else { tmp3 = fncls__115 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_123; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_124)); return A_arbace_repr_go_annotate__init_A_const_123 }



















































































func A_arbace_repr_go_annotate__init_A_Unit62__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(874, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_125; var tmp2 *lang.Compiler_AOTFn; var fnbody__118 any = A_arbace_repr_go_annotate_tsv_line_A_New(); var tmp3 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_repr_go_annotate_tsv_line_A_fn_class; if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_348, false, nil); A_arbace_repr_go_annotate_tsv_line_A_fn_class = fncls__117d; tmp3 = fncls__117d } else { tmp3 = fncls__117 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__118, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_126)); return A_arbace_repr_go_annotate__init_A_const_125 }






func A_arbace_repr_go_annotate__init_A_Unit63__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(881, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_127; var tmp2 *lang.Compiler_AOTFn; var fnbody__120 any = A_arbace_repr_go_annotate_error_text_A_New(); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_repr_go_annotate_error_text_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_349, false, nil); A_arbace_repr_go_annotate_error_text_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_128)); return A_arbace_repr_go_annotate__init_A_const_127 }

func A_arbace_repr_go_annotate__init_A_Unit64__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(883, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_129; var tmp2 *lang.Compiler_AOTFn; var fnbody__122 any = A_arbace_repr_go_annotate_read_job_A_New(); var tmp3 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_repr_go_annotate_read_job_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_350, false, nil); A_arbace_repr_go_annotate_read_job_A_fn_class = fncls__121d; tmp3 = fncls__121d } else { tmp3 = fncls__121 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__122, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_130)); return A_arbace_repr_go_annotate__init_A_const_129 }














































func A_arbace_repr_go_annotate__init_A_Unit65__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(930, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_131; var tmp2 *lang.Compiler_AOTFn; var fnbody__124 any = A_arbace_repr_go_annotate_read_corpus_A_New(); var tmp3 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_repr_go_annotate_read_corpus_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_351, false, nil); A_arbace_repr_go_annotate_read_corpus_A_fn_class = fncls__123d; tmp3 = fncls__123d } else { tmp3 = fncls__123 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__124, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_131; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_132)); return A_arbace_repr_go_annotate__init_A_const_131 }



































func A_arbace_repr_go_annotate__init_A_Unit66__O() any { A_arbace_repr_go_annotate__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(966, 1); var tmp1 *lang.Var = A_arbace_repr_go_annotate__init_A_const_133; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__126 any = A_arbace_repr_go_annotate__main_A_New(); var tmp3 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_repr_go_annotate__main_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_352, true, nil); A_arbace_repr_go_annotate__main_A_fn_class = fncls__125d; tmp3 = fncls__125d } else { tmp3 = fncls__125 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__126, tmp3, nil, 0); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_repr_go_annotate__init_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_repr_go_annotate__init_A_const_134)); return A_arbace_repr_go_annotate__init_A_const_133 }



type A_arbace_repr_go_annotate__init_A struct{ jrt.Object }

var A_arbace_repr_go_annotate__init_A_const_pool *jrt.RefArray

var A_arbace_repr_go_annotate__init_A_const_0 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_1 any

var A_arbace_repr_go_annotate__init_A_const_2 any

var A_arbace_repr_go_annotate__init_A_const_3 any

var A_arbace_repr_go_annotate__init_A_const_4 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_5 any

var A_arbace_repr_go_annotate__init_A_const_6 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_7 any

var A_arbace_repr_go_annotate__init_A_const_8 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_9 any

var A_arbace_repr_go_annotate__init_A_const_10 any

var A_arbace_repr_go_annotate__init_A_const_11 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_12 any

var A_arbace_repr_go_annotate__init_A_const_13 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_14 any

var A_arbace_repr_go_annotate__init_A_const_15 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_16 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_17 any

var A_arbace_repr_go_annotate__init_A_const_18 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_19 any

var A_arbace_repr_go_annotate__init_A_const_20 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_21 *lang.Keyword

var A_arbace_repr_go_annotate__init_A_const_22 *lang.Keyword

var A_arbace_repr_go_annotate__init_A_const_23 *lang.Keyword

var A_arbace_repr_go_annotate__init_A_const_24 *lang.Keyword

var A_arbace_repr_go_annotate__init_A_const_25 *lang.Keyword

var A_arbace_repr_go_annotate__init_A_const_26 any

var A_arbace_repr_go_annotate__init_A_const_27 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_28 any

var A_arbace_repr_go_annotate__init_A_const_29 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_30 any

var A_arbace_repr_go_annotate__init_A_const_31 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_32 any

var A_arbace_repr_go_annotate__init_A_const_33 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_34 any

var A_arbace_repr_go_annotate__init_A_const_35 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_36 any

var A_arbace_repr_go_annotate__init_A_const_37 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_38 any

var A_arbace_repr_go_annotate__init_A_const_39 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_40 any

var A_arbace_repr_go_annotate__init_A_const_41 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_42 any

var A_arbace_repr_go_annotate__init_A_const_43 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_44 any

var A_arbace_repr_go_annotate__init_A_const_45 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_46 any

var A_arbace_repr_go_annotate__init_A_const_47 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_48 any

var A_arbace_repr_go_annotate__init_A_const_49 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_50 any

var A_arbace_repr_go_annotate__init_A_const_51 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_52 any

var A_arbace_repr_go_annotate__init_A_const_53 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_54 any

var A_arbace_repr_go_annotate__init_A_const_55 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_56 any

var A_arbace_repr_go_annotate__init_A_const_57 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_58 any

var A_arbace_repr_go_annotate__init_A_const_59 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_60 any

var A_arbace_repr_go_annotate__init_A_const_61 any

var A_arbace_repr_go_annotate__init_A_const_62 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_63 any

var A_arbace_repr_go_annotate__init_A_const_64 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_65 any

var A_arbace_repr_go_annotate__init_A_const_66 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_67 any

var A_arbace_repr_go_annotate__init_A_const_68 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_69 any

var A_arbace_repr_go_annotate__init_A_const_70 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_71 any

var A_arbace_repr_go_annotate__init_A_const_72 any

var A_arbace_repr_go_annotate__init_A_const_73 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_74 any

var A_arbace_repr_go_annotate__init_A_const_75 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_76 any

var A_arbace_repr_go_annotate__init_A_const_77 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_78 any

var A_arbace_repr_go_annotate__init_A_const_79 any

var A_arbace_repr_go_annotate__init_A_const_80 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_81 any

var A_arbace_repr_go_annotate__init_A_const_82 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_83 any

var A_arbace_repr_go_annotate__init_A_const_84 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_85 any

var A_arbace_repr_go_annotate__init_A_const_86 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_87 any

var A_arbace_repr_go_annotate__init_A_const_88 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_89 any

var A_arbace_repr_go_annotate__init_A_const_90 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_91 any

var A_arbace_repr_go_annotate__init_A_const_92 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_93 any

var A_arbace_repr_go_annotate__init_A_const_94 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_95 any

var A_arbace_repr_go_annotate__init_A_const_96 any

var A_arbace_repr_go_annotate__init_A_const_97 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_98 any

var A_arbace_repr_go_annotate__init_A_const_99 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_100 any

var A_arbace_repr_go_annotate__init_A_const_101 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_102 any

var A_arbace_repr_go_annotate__init_A_const_103 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_104 any

var A_arbace_repr_go_annotate__init_A_const_105 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_106 any

var A_arbace_repr_go_annotate__init_A_const_107 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_108 any

var A_arbace_repr_go_annotate__init_A_const_109 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_110 any

var A_arbace_repr_go_annotate__init_A_const_111 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_112 any

var A_arbace_repr_go_annotate__init_A_const_113 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_114 any

var A_arbace_repr_go_annotate__init_A_const_115 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_116 any

var A_arbace_repr_go_annotate__init_A_const_117 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_118 any

var A_arbace_repr_go_annotate__init_A_const_119 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_120 any

var A_arbace_repr_go_annotate__init_A_const_121 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_122 any

var A_arbace_repr_go_annotate__init_A_const_123 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_124 any

var A_arbace_repr_go_annotate__init_A_const_125 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_126 any

var A_arbace_repr_go_annotate__init_A_const_127 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_128 any

var A_arbace_repr_go_annotate__init_A_const_129 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_130 any

var A_arbace_repr_go_annotate__init_A_const_131 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_132 any

var A_arbace_repr_go_annotate__init_A_const_133 *lang.Var

var A_arbace_repr_go_annotate__init_A_const_134 any

var A_arbace_repr_go_annotate__init_A_init jrt.ClassInit

func A_arbace_repr_go_annotate__init_A_Init() { if !A_arbace_repr_go_annotate__init_A_init.Done() { A_arbace_repr_go_annotate__init_A_init.Run(A_arbace_repr_go_annotate__init_A_clinit) } }

func A_arbace_repr_go_annotate__init_A_clinit() { A_arbace_repr_go_annotate__init_A_clinit_p0(); A_arbace_repr_go_annotate__init_A_clinit_p1(); A_arbace_repr_go_annotate__init_A_clinit_p2(); A_arbace_repr_go_annotate__init_A_clinit_p3(); A_arbace_repr_go_annotate__init_A_clinit_p4(); A_arbace_repr_go_annotate__init_A_clinit_p5(); A_arbace_repr_go_annotate__init_A_clinit_p6(); A_arbace_repr_go_annotate__init_A_clinit_p7(); A_arbace_repr_go_annotate__init_A_clinit_p8(); A_arbace_repr_go_annotate__init_A_clinit_p9(); A_arbace_repr_go_annotate__init_A_clinit_p10() }

func A_arbace_repr_go_annotate__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_repr_go_annotate__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_296, 238); A_arbace_repr_go_annotate__init_A_const_0 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[103]); A_arbace_repr_go_annotate__init_A_const_1 = A_arbace_repr_go_annotate__init_A_const_pool.A[104]; A_arbace_repr_go_annotate__init_A_const_2 = A_arbace_repr_go_annotate__init_A_const_pool.A[105]; A_arbace_repr_go_annotate__init_A_const_3 = A_arbace_repr_go_annotate__init_A_const_pool.A[106]; A_arbace_repr_go_annotate__init_A_const_4 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[107]); A_arbace_repr_go_annotate__init_A_const_5 = A_arbace_repr_go_annotate__init_A_const_pool.A[108]; A_arbace_repr_go_annotate__init_A_const_6 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[109]); A_arbace_repr_go_annotate__init_A_const_7 = A_arbace_repr_go_annotate__init_A_const_pool.A[110]; A_arbace_repr_go_annotate__init_A_const_8 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[111]); A_arbace_repr_go_annotate__init_A_const_9 = A_arbace_repr_go_annotate__init_A_const_pool.A[112]; A_arbace_repr_go_annotate__init_A_const_10 = A_arbace_repr_go_annotate__init_A_const_pool.A[113]; A_arbace_repr_go_annotate__init_A_const_11 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[114]); A_arbace_repr_go_annotate__init_A_const_12 = A_arbace_repr_go_annotate__init_A_const_pool.A[115] }

func A_arbace_repr_go_annotate__init_A_clinit_p1() { A_arbace_repr_go_annotate__init_A_const_13 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[116]); A_arbace_repr_go_annotate__init_A_const_14 = A_arbace_repr_go_annotate__init_A_const_pool.A[117]; A_arbace_repr_go_annotate__init_A_const_15 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[118]); A_arbace_repr_go_annotate__init_A_const_16 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[119]); A_arbace_repr_go_annotate__init_A_const_17 = A_arbace_repr_go_annotate__init_A_const_pool.A[120]; A_arbace_repr_go_annotate__init_A_const_18 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[121]); A_arbace_repr_go_annotate__init_A_const_19 = A_arbace_repr_go_annotate__init_A_const_pool.A[122]; A_arbace_repr_go_annotate__init_A_const_20 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[123]); A_arbace_repr_go_annotate__init_A_const_21 = lang.Keyword_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[124]); A_arbace_repr_go_annotate__init_A_const_22 = lang.Keyword_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[125]); A_arbace_repr_go_annotate__init_A_const_23 = lang.Keyword_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[126]); A_arbace_repr_go_annotate__init_A_const_24 = lang.Keyword_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[127]) }

func A_arbace_repr_go_annotate__init_A_clinit_p2() { A_arbace_repr_go_annotate__init_A_const_25 = lang.Keyword_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[128]); A_arbace_repr_go_annotate__init_A_const_26 = A_arbace_repr_go_annotate__init_A_const_pool.A[129]; A_arbace_repr_go_annotate__init_A_const_27 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[130]); A_arbace_repr_go_annotate__init_A_const_28 = A_arbace_repr_go_annotate__init_A_const_pool.A[131]; A_arbace_repr_go_annotate__init_A_const_29 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[132]); A_arbace_repr_go_annotate__init_A_const_30 = A_arbace_repr_go_annotate__init_A_const_pool.A[133]; A_arbace_repr_go_annotate__init_A_const_31 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[134]); A_arbace_repr_go_annotate__init_A_const_32 = A_arbace_repr_go_annotate__init_A_const_pool.A[135]; A_arbace_repr_go_annotate__init_A_const_33 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[136]); A_arbace_repr_go_annotate__init_A_const_34 = A_arbace_repr_go_annotate__init_A_const_pool.A[137]; A_arbace_repr_go_annotate__init_A_const_35 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[138]); A_arbace_repr_go_annotate__init_A_const_36 = A_arbace_repr_go_annotate__init_A_const_pool.A[139]; A_arbace_repr_go_annotate__init_A_const_37 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[140]) }

func A_arbace_repr_go_annotate__init_A_clinit_p3() { A_arbace_repr_go_annotate__init_A_const_38 = A_arbace_repr_go_annotate__init_A_const_pool.A[141]; A_arbace_repr_go_annotate__init_A_const_39 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[142]); A_arbace_repr_go_annotate__init_A_const_40 = A_arbace_repr_go_annotate__init_A_const_pool.A[143]; A_arbace_repr_go_annotate__init_A_const_41 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[144]); A_arbace_repr_go_annotate__init_A_const_42 = A_arbace_repr_go_annotate__init_A_const_pool.A[145]; A_arbace_repr_go_annotate__init_A_const_43 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[146]); A_arbace_repr_go_annotate__init_A_const_44 = A_arbace_repr_go_annotate__init_A_const_pool.A[147]; A_arbace_repr_go_annotate__init_A_const_45 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[148]); A_arbace_repr_go_annotate__init_A_const_46 = A_arbace_repr_go_annotate__init_A_const_pool.A[149]; A_arbace_repr_go_annotate__init_A_const_47 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[150]); A_arbace_repr_go_annotate__init_A_const_48 = A_arbace_repr_go_annotate__init_A_const_pool.A[151]; A_arbace_repr_go_annotate__init_A_const_49 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[152]); A_arbace_repr_go_annotate__init_A_const_50 = A_arbace_repr_go_annotate__init_A_const_pool.A[153] }

func A_arbace_repr_go_annotate__init_A_clinit_p4() { A_arbace_repr_go_annotate__init_A_const_51 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[154]); A_arbace_repr_go_annotate__init_A_const_52 = A_arbace_repr_go_annotate__init_A_const_pool.A[155]; A_arbace_repr_go_annotate__init_A_const_53 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[156]); A_arbace_repr_go_annotate__init_A_const_54 = A_arbace_repr_go_annotate__init_A_const_pool.A[157]; A_arbace_repr_go_annotate__init_A_const_55 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[158]); A_arbace_repr_go_annotate__init_A_const_56 = A_arbace_repr_go_annotate__init_A_const_pool.A[159]; A_arbace_repr_go_annotate__init_A_const_57 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[160]); A_arbace_repr_go_annotate__init_A_const_58 = A_arbace_repr_go_annotate__init_A_const_pool.A[161]; A_arbace_repr_go_annotate__init_A_const_59 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[162]); A_arbace_repr_go_annotate__init_A_const_60 = A_arbace_repr_go_annotate__init_A_const_pool.A[163]; A_arbace_repr_go_annotate__init_A_const_61 = A_arbace_repr_go_annotate__init_A_const_pool.A[164]; A_arbace_repr_go_annotate__init_A_const_62 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[165]); A_arbace_repr_go_annotate__init_A_const_63 = A_arbace_repr_go_annotate__init_A_const_pool.A[166] }

func A_arbace_repr_go_annotate__init_A_clinit_p5() { A_arbace_repr_go_annotate__init_A_const_64 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[167]); A_arbace_repr_go_annotate__init_A_const_65 = A_arbace_repr_go_annotate__init_A_const_pool.A[168]; A_arbace_repr_go_annotate__init_A_const_66 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[169]); A_arbace_repr_go_annotate__init_A_const_67 = A_arbace_repr_go_annotate__init_A_const_pool.A[170]; A_arbace_repr_go_annotate__init_A_const_68 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[171]); A_arbace_repr_go_annotate__init_A_const_69 = A_arbace_repr_go_annotate__init_A_const_pool.A[172]; A_arbace_repr_go_annotate__init_A_const_70 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[173]); A_arbace_repr_go_annotate__init_A_const_71 = A_arbace_repr_go_annotate__init_A_const_pool.A[174]; A_arbace_repr_go_annotate__init_A_const_72 = A_arbace_repr_go_annotate__init_A_const_pool.A[175]; A_arbace_repr_go_annotate__init_A_const_73 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[176]); A_arbace_repr_go_annotate__init_A_const_74 = A_arbace_repr_go_annotate__init_A_const_pool.A[177]; A_arbace_repr_go_annotate__init_A_const_75 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[178]); A_arbace_repr_go_annotate__init_A_const_76 = A_arbace_repr_go_annotate__init_A_const_pool.A[179] }

func A_arbace_repr_go_annotate__init_A_clinit_p6() { A_arbace_repr_go_annotate__init_A_const_77 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[180]); A_arbace_repr_go_annotate__init_A_const_78 = A_arbace_repr_go_annotate__init_A_const_pool.A[181]; A_arbace_repr_go_annotate__init_A_const_79 = A_arbace_repr_go_annotate__init_A_const_pool.A[182]; A_arbace_repr_go_annotate__init_A_const_80 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[183]); A_arbace_repr_go_annotate__init_A_const_81 = A_arbace_repr_go_annotate__init_A_const_pool.A[184]; A_arbace_repr_go_annotate__init_A_const_82 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[185]); A_arbace_repr_go_annotate__init_A_const_83 = A_arbace_repr_go_annotate__init_A_const_pool.A[186]; A_arbace_repr_go_annotate__init_A_const_84 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[187]); A_arbace_repr_go_annotate__init_A_const_85 = A_arbace_repr_go_annotate__init_A_const_pool.A[188]; A_arbace_repr_go_annotate__init_A_const_86 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[189]); A_arbace_repr_go_annotate__init_A_const_87 = A_arbace_repr_go_annotate__init_A_const_pool.A[190]; A_arbace_repr_go_annotate__init_A_const_88 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[191]); A_arbace_repr_go_annotate__init_A_const_89 = A_arbace_repr_go_annotate__init_A_const_pool.A[192] }

func A_arbace_repr_go_annotate__init_A_clinit_p7() { A_arbace_repr_go_annotate__init_A_const_90 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[193]); A_arbace_repr_go_annotate__init_A_const_91 = A_arbace_repr_go_annotate__init_A_const_pool.A[194]; A_arbace_repr_go_annotate__init_A_const_92 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[195]); A_arbace_repr_go_annotate__init_A_const_93 = A_arbace_repr_go_annotate__init_A_const_pool.A[196]; A_arbace_repr_go_annotate__init_A_const_94 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[197]); A_arbace_repr_go_annotate__init_A_const_95 = A_arbace_repr_go_annotate__init_A_const_pool.A[198]; A_arbace_repr_go_annotate__init_A_const_96 = A_arbace_repr_go_annotate__init_A_const_pool.A[199]; A_arbace_repr_go_annotate__init_A_const_97 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[200]); A_arbace_repr_go_annotate__init_A_const_98 = A_arbace_repr_go_annotate__init_A_const_pool.A[201]; A_arbace_repr_go_annotate__init_A_const_99 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[202]); A_arbace_repr_go_annotate__init_A_const_100 = A_arbace_repr_go_annotate__init_A_const_pool.A[203]; A_arbace_repr_go_annotate__init_A_const_101 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[204]); A_arbace_repr_go_annotate__init_A_const_102 = A_arbace_repr_go_annotate__init_A_const_pool.A[205] }

func A_arbace_repr_go_annotate__init_A_clinit_p8() { A_arbace_repr_go_annotate__init_A_const_103 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[206]); A_arbace_repr_go_annotate__init_A_const_104 = A_arbace_repr_go_annotate__init_A_const_pool.A[207]; A_arbace_repr_go_annotate__init_A_const_105 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[208]); A_arbace_repr_go_annotate__init_A_const_106 = A_arbace_repr_go_annotate__init_A_const_pool.A[209]; A_arbace_repr_go_annotate__init_A_const_107 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[210]); A_arbace_repr_go_annotate__init_A_const_108 = A_arbace_repr_go_annotate__init_A_const_pool.A[211]; A_arbace_repr_go_annotate__init_A_const_109 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[212]); A_arbace_repr_go_annotate__init_A_const_110 = A_arbace_repr_go_annotate__init_A_const_pool.A[213]; A_arbace_repr_go_annotate__init_A_const_111 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[214]); A_arbace_repr_go_annotate__init_A_const_112 = A_arbace_repr_go_annotate__init_A_const_pool.A[215]; A_arbace_repr_go_annotate__init_A_const_113 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[216]); A_arbace_repr_go_annotate__init_A_const_114 = A_arbace_repr_go_annotate__init_A_const_pool.A[217]; A_arbace_repr_go_annotate__init_A_const_115 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[218]) }

func A_arbace_repr_go_annotate__init_A_clinit_p9() { A_arbace_repr_go_annotate__init_A_const_116 = A_arbace_repr_go_annotate__init_A_const_pool.A[219]; A_arbace_repr_go_annotate__init_A_const_117 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[220]); A_arbace_repr_go_annotate__init_A_const_118 = A_arbace_repr_go_annotate__init_A_const_pool.A[221]; A_arbace_repr_go_annotate__init_A_const_119 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[222]); A_arbace_repr_go_annotate__init_A_const_120 = A_arbace_repr_go_annotate__init_A_const_pool.A[223]; A_arbace_repr_go_annotate__init_A_const_121 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[224]); A_arbace_repr_go_annotate__init_A_const_122 = A_arbace_repr_go_annotate__init_A_const_pool.A[225]; A_arbace_repr_go_annotate__init_A_const_123 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[226]); A_arbace_repr_go_annotate__init_A_const_124 = A_arbace_repr_go_annotate__init_A_const_pool.A[227]; A_arbace_repr_go_annotate__init_A_const_125 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[228]); A_arbace_repr_go_annotate__init_A_const_126 = A_arbace_repr_go_annotate__init_A_const_pool.A[229]; A_arbace_repr_go_annotate__init_A_const_127 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[230]); A_arbace_repr_go_annotate__init_A_const_128 = A_arbace_repr_go_annotate__init_A_const_pool.A[231] }

func A_arbace_repr_go_annotate__init_A_clinit_p10() { A_arbace_repr_go_annotate__init_A_const_129 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[232]); A_arbace_repr_go_annotate__init_A_const_130 = A_arbace_repr_go_annotate__init_A_const_pool.A[233]; A_arbace_repr_go_annotate__init_A_const_131 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[234]); A_arbace_repr_go_annotate__init_A_const_132 = A_arbace_repr_go_annotate__init_A_const_pool.A[235]; A_arbace_repr_go_annotate__init_A_const_133 = lang.Var_Cast(A_arbace_repr_go_annotate__init_A_const_pool.A[236]); A_arbace_repr_go_annotate__init_A_const_134 = A_arbace_repr_go_annotate__init_A_const_pool.A[237] }

func A_arbace_repr_go_annotate__init_A_New() *A_arbace_repr_go_annotate__init_A { A_arbace_repr_go_annotate__init_A_Init(); t := &A_arbace_repr_go_annotate__init_A{}; t.Ctor(); return t }

func (t *A_arbace_repr_go_annotate__init_A) Ctor() {}

func (t *A_arbace_repr_go_annotate__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_repr_go_annotate__init_A) GetClass__Class() *jrt.Class { return A_arbace_repr_go_annotate__init_A_class }

func (t *A_arbace_repr_go_annotate__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_repr_go_annotate__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_repr_go_annotate__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_repr_go_annotate__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_repr_go_annotate__init_A); return ok }

func A_arbace_repr_go_annotate__init_A_Cast(x any) *A_arbace_repr_go_annotate__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_repr_go_annotate__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_repr_go_annotate__init_A_class)) }; return v }
