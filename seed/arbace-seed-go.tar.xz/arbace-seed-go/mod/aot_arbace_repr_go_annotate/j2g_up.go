//line j2g_up.ae:1
package aot_arbace_repr_go_annotate

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
func Up_ArraySeq_ISeq(p *lang.ArraySeq) lang.ISeq { if p == nil { return nil }; return p }

func Up_Compiler_AOTFn_IFn(p *lang.Compiler_AOTFn) lang.IFn { if p == nil { return nil }; return p }

func Up_Compiler_AOTFn_IObj(p *lang.Compiler_AOTFn) lang.IObj { if p == nil { return nil }; return p }

func Up_Compiler_AOTFn_Callable(p *lang.Compiler_AOTFn) jrt.Callable { if p == nil { return nil }; return p }

func Up_Namespace_AReference(p *lang.Namespace) lang.AReference_I { if p == nil { return nil }; return p }

func Up_Double_Number(p *jrt.Double) jrt.Number_I { if p == nil { return nil }; return p }

func Up_Long_Number(p *jrt.Long) jrt.Number_I { if p == nil { return nil }; return p }

func Up_ExecutionException_Throwable(p *jrt.ExecutionException) jrt.Throwable_I { if p == nil { return nil }; return p }
