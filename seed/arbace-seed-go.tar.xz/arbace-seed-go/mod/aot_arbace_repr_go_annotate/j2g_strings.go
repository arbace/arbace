//line j2g_strings.ae:1
package aot_arbace_repr_go_annotate

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn15,arbace.go.checkyn2,ckyn19,arbace.go.check.envyn1,eyn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn14,arbace.repr.goyn2,rgyn22,arbace.repr.go.convertyn2,cvyn18,arbace.repr.go.lityn3,lityn19,arbace.repr.go.loadyn2,ldyn20,arbace.repr.go.parseyn2,psyn20,arbace.repr.go.printyn2,rpyn18,arbace.repr.go.rawyn3,rawyn21,arbace.repr.go.syntaxyn3,synyn19,arbace.repr.go.readyn2,rdkn3,docks22,arbace.repr.go.convert1,lks22,arbace.repr.go.convert3,poskn4,lineks15,arbace.go.check2,atkn5,valueks22,arbace.repr.go.convert3,rawkn4,elseyn5,in-nsyn5,quoteys2,go4,filekn7,importskn3,poskn8,path-poskn7,packagekn4,namekn5,formskn5,fileskn4,langkn6,configkn4,pathkn4,optskn13,local-importskn7,answerskn6,gorootkn4,gooskn6,goarchkn5,levelkn4,tagskn6,nativekn3,rawkn8,annotatekn7,convertkn6,layoutkn5,errorkn3,jobkn1,nkn8,rejectedkn4,filekn3,keykn9,positionskn4,fullkn10,import-mapkn3,ctxkn2,rckn3,srckn9,native-mskn6,raw-mskn4,poolkn7,permitsks23,arbace.repr.go.annotate7,skippedkn3,tagkn6,start!kn4,donekn8,delegatekn2,ckkn5,localkn3,haskn4,recskn4,keepkn5,indexkn4,basekn8,fallbackkn7,goamd64kn7,goarm64kn4,modekn8,packageskn3,cwdkn4,argskn6,headerkn5,testskn8,for-testkn13,test-go-fileskn4,dirskn8,dir-testkn4,testkn4,depskn6,prefixkn11,import-speckn5,x-poskn3,dotkn8,name-poskn7,entrieskn3,idskn5,namedks21,arbace.go.check.types5,aliaskn4,kindkn5,aliaskn6,actualkn3,pkgkn14,unsafe-pointerkn5,basickn6,originkn5,targskn10,type-paramkn3,objkn5,tuplekn4,varskn1,tkn9,interfacekn9,embeddedskn7,methodskn4,typekn7,pointerkn4,elemkn5,arraykn3,lenkn3,mapkn5,slicekn4,chankn3,dirkn4,funckn6,paramskn7,resultskn8,variadickn5,unionkn5,termskn5,tildekn3,allkn6,structkn6,fieldskn8,embeddedks23,arbace.repr.go.annotate5,aliasks23,arbace.repr.go.annotate2,idkn5,floatkn7,unknownkn5,byteskn7,complexkn8,universekn9,pkg-levelkn5,constkn3,valkn5,fieldkn11,untyped-nilkn3,nilkn3,selkn7,invalidkn5,finalkn11,binary-exprkn3,defkn3,usekn9,field-objkn8,indirectkn3,viakn4,instkn8,implicitkn12,x-unrecordedkn2,opkn9,basic-litkn10,unary-exprkn1,xkn10,paren-exprkn3,astkn3,lhskn18,resolve-init-orderkn10,underlyingkn4,dumpkn10,init-orderkn5,typeskn10,type-tablekn8,unplacedkn4,metakn9,meta-keyskn5,countkn7,literalkn6,symbolkn8,map-keyskn2,nskn4,stemkn8,commentskn5,lineskn4,keyskn5,timeskn7,read-mskn8,check-mskn4,failkn5,nodeskn4,openkn5,extrakn4,diffkn10,final-failkn6,resultkn6,errorskn9,no-exportkn10,forms-diffkn3,reskn8,raw-diffkn8,ann-failkn10,error-msgskn3,msgkn6,ann-mskn8,ann-diffkn5,equalkn8,forms-mskn11,forms-equalkn5,tracekn3,subkn7,tsv-keykn6,statuskn5,loadskn5,dumpskn3,tsvkn7,missingkn6,corpuskn4,jobskn10,tree-equalkn12,raw-resolvedkn8,raw-onlykn9,ann-equalkn10,ann-differkn12,forms-differkn11,tree-differkn10,raw-differkn11,resolutionskn14,checker-errorskn6,load-skn7,parse-skn6,dump-skn6,read-skn7,check-skn5,ann-skn7,forms-skn6,wall-skn8,parse-mskn7,dump-mskn4,textkn13,syntax-errorskn3,outkn5,checkkn10,convert-mskn12,report-extrakn6,readerkn5,printkn10,text-knownkn5,quietkn5,knownkn6,reportkn7,corporav11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,V3,R18,R2,R19,V3,R20,R2,R21,V3,R22,R2,R23,V3,R24,R2,R25,V3,R26,R2,R27,V3,R28,R2,R29,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn23,arbace.repr.go.annotatem2,R30,s1649,repr/go's annotator (doc/go/GO-PARSER-SURVEY.md GP4, §4.2 steps 3-5): goi's checker\n  (arbace.go.check) in its resolve mode over the raw forms of the native reader's dumps\n  (arbace.repr.go.raw, GP3), each open decision answered by position; the answers put into the\n  native dump as go/types' annotations, in the helper's shape (doc/go/HELPER-NOTES.md, \"Output\n  format\": :mode, :t, :use, :def, :sel, :field, :inst, :implicit, :init-order, :types'\n  :underlying, :type-table), which the converter, unchanged, turns into the final forms.\n\n  The packages are checked in dependency order, as bin/goi annotations checks them: one session\n  of the standard library per configuration (its packages from the loader, std), a corpus's own\n  packages in a session over it (a module's, cmd's, a directory test's, test variants), each\n  package's imports by the loader's resolution. Raw forms are taken in memory (GPS26 (a)), as\n  the checker reads text: literals as values, lines as :line, and each node's positions as\n  :arbace.go.check/at [file {field [line col]}], the key of its answers.\n\n  bin/repr-go native-check runs -main check: per dump E-tree (arbace.repr.go.parse), the raw\n  forms against the final ones (arbace.repr.go.raw/conform, GPS23 (c)) and E-ann: the final\n  forms the converter makes of the annotated native dump equal, form for form, metadata and\n  positions included (mode :full), to those of the helper's dump: the annotations the converter\n  reads equal go/types', types compared by the type forms they give. bin/repr-go read --reader\n  native --forms runs -main read: the final forms written as bin/repr-go read writes the helper's.v11,arbace.core8,keyword?v11,arbace.core9,namespacev11,arbace.core11,persistent!v11,arbace.core9,reduce-kvv23,arbace.repr.go.annotate12,private-key?v11,arbace.core6,assoc!v23,arbace.repr.go.annotate5,cformv11,arbace.core9,transientR31,R32,v11,arbace.core5,assocR33,v11,arbace.core3,seqR34,v18,arbace.repr.go.lit4,lit?R35,v11,arbace.core4,seq?R36,v11,arbace.core4,listv11,arbace.core9,with-metav11,arbace.core5,applyv11,arbace.core3,mapv23,arbace.repr.go.annotate5,cmetav11,arbace.core7,vector?v11,arbace.core4,mapvv11,arbace.core4,map?v11,arbace.core4,intov11,arbace.core7,symbol?R37,R38,R39,v11,arbace.core6,secondR40,v11,arbace.core5,firstv11,arbace.core4,nextv11,arbace.core3,vecR41,v11,arbace.core6,updatev11,arbace.core4,peekR42,v11,arbace.core9,vary-metav11,arbace.core10,sorted-mapR43,v11,arbace.core6,concatR44,v11,arbace.core6,mapcatv23,arbace.repr.go.annotate12,import-specsR45,R46,R47,v20,arbace.repr.go.print13,collect-formsv11,arbace.core8,to-arrayv11,arbace.core5,mergem2,R48,s6,go1.27R49,R50,v20,arbace.repr.go.print9,name-textR51,R52,R53,v19,arbace.repr.go.load6,configR54,R55,R56,R57,R58,v23,arbace.repr.go.annotate6,phasesv13,arbace.string4,joinv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core6,formatv11,arbace.core4,namev11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restV5,R59,R60,R61,R62,R63,v20,arbace.repr.go.parse11,native-dumpv23,arbace.repr.go.annotate9,forms-dirv23,arbace.repr.go.annotate6,phase!R59,R64,R65,R66,R67,R68,v14,arbace.repr.go12,dump-contextR69,v22,arbace.repr.go.convert15,convert-packageR70,R71,R60,v23,arbace.repr.go.annotate10,raw-sourceR72,R73,R74,R75,R76,R77,v11,arbace.core8,distinctv11,arbace.core4,valsv11,arbace.core9,contains?v23,arbace.repr.go.annotate8,prefetchR78,R79,v23,arbace.repr.go.annotate4,prepR80,m2,R81,C29,java.util.concurrent.CallableR82,v23,arbace.repr.go.annotate8,run-taskR83,v15,arbace.go.check7,sessionR84,R85,R86,v11,arbace.core3,notR87,R88,R89,R90,R91,R92,v19,arbace.repr.go.load4,jobsv11,arbace.core11,select-keysV6,R54,R55,R56,R58,R93,R94,R95,R96,R97,R98,V1,s3,stdv11,arbace.core6,get-inV2,R99,R44,V2,R99,R44,v23,arbace.repr.go.annotate10,config-keyv23,arbace.repr.go.annotate12,std-sessionsv23,arbace.repr.go.annotate11,new-sessionv23,arbace.repr.go.annotate9,std-indexv11,arbace.core10,constantlyv11,arbace.core5,swap!v20,arbace.go.check.load12,clear-cache!v11,arbace.core6,reset!v20,arbace.go.check.decl16,clear-instances!v11,arbace.core7,keywordV1,s3,stdR100,R99,R101,R102,v23,arbace.repr.go.annotate11,variant-keyv11,arbace.core4,not=v23,arbace.repr.go.annotate11,std-sessionv23,arbace.repr.go.annotate9,std-load?R103,v11,arbace.core8,group-byV3,R99,R104,R105,V2,R99,R44,V2,R99,R44,V2,R99,R44,V2,R99,R44,v23,arbace.repr.go.annotate7,job-keyv13,arbace.string9,includes?v11,arbace.core6,filterR106,R107,v23,arbace.repr.go.annotate11,job-importsV3,R99,R104,R105,v22,arbace.repr.go.convert9,positionsv11,arbace.core11,map-indexedv11,arbace.core6,vectorR108,v22,arbace.repr.go.convert9,parse-posv22,arbace.repr.go.convert5,startl1,R109,R110,R111,v11,arbace.core4,somev23,arbace.repr.go.annotate7,anchorsR112,R113,R114,v23,arbace.repr.go.annotate8,type-id!R115,R116,R117,R118,R119,v21,arbace.go.check.types13,kw-alias-infoR120,m6,R116,R121,R45,s7,PointerR119,s6,unsafeR121,v21,arbace.go.check.types11,basic-namesv21,arbace.go.check.types6,named?v21,arbace.go.check.types4,infoR122,R123,v21,arbace.go.check.types7,tparam?R124,R125,v19,arbace.go.check.env1,oR126,R127,R128,R129,R130,v11,arbace.core3,setv21,arbace.go.check.types5,underv11,arbace.core6,removem2,R116,R129,R131,R132,R133,R134,R135,R136,m4,R116,R121,R45,s12,invalid typev11,arbace.core6,dissocR137,R138,R139,R140,R141,R142,R143,R144,R145,R146,R147,R148,v11,arbace.core7,sort-byv21,arbace.go.check.types8,type-strR149,R150,R151,R81,v21,arbace.go.check.const10,value-textv23,arbace.repr.go.annotate8,entry-ofR152,R153,v21,arbace.go.check.const3,bf?R154,v11,arbace.core6,ratio?v11,arbace.core8,integer?v21,arbace.go.check.const8,make-ratR155,v11,arbace.core8,boolean?v11,arbace.core7,string?v21,arbace.go.check.const11,value-bytesv21,arbace.go.check.const8,complex?v21,arbace.go.check.types11,float-type?v23,arbace.repr.go.annotate11,float-shapev21,arbace.go.check.types13,complex-type?R156,R157,l0,v19,arbace.go.check.env4,obj?R158,R159,R160,v11,arbace.core5,some?R161,v23,arbace.repr.go.annotate9,val-shapeR162,R163,R164,v23,arbace.repr.go.annotate7,mode-ofR165,v11,arbace.core9,not-emptyR166,R167,R168,S2,s2,>>s2,<<R169,v23,arbace.repr.go.annotate14,obj-annotationR170,R171,R172,R173,R174,R175,R176,R177,v23,arbace.repr.go.annotate7,rebuildv11,arbace.core5,nnextR178,m2,R95,R160,R179,S4,s1,!s1,-s1,^s1,+R180,m2,R95,R160,R181,V2,R95,R128,v23,arbace.repr.go.annotate9,new-tablev23,arbace.repr.go.annotate10,node-indexR182,v11,arbace.core9,volatile!v23,arbace.repr.go.annotate10,annotationv11,arbace.core6,ffirstR183,R184,R185,R186,R187,R188,R189,R190,v23,arbace.repr.go.annotate7,node-ofv11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsv11,arbace.core4,subsl400,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core12,*print-meta*v11,arbace.core14,*print-length*l20,v11,arbace.core13,*print-level*l6,v11,arbace.core4,keysv11,arbace.core4,keepv23,arbace.repr.go.annotate4,sameR191,v11,arbace.core3,strR192,v11,arbace.core8,identityR193,v23,arbace.repr.go.annotate9,short-strv23,arbace.repr.go.annotate9,same-metav23,arbace.repr.go.annotate8,same-seqR194,R195,R196,R197,V1,nV4,R45,R198,R199,R190,V4,R45,R198,R199,R190,v23,arbace.repr.go.annotate7,line-atV3,R45,R198,R190,V3,R45,R198,R190,V2,R99,R101,v11,arbace.core7,memoizev11,arbace.core4,disjv23,arbace.repr.go.annotate14,external-test?v15,arbace.go.check14,ensure-packagev23,arbace.repr.go.annotate13,xtest-sessionv15,arbace.go.check9,check-srcv13,arbace.string11,split-linesv11,arbace.core12,keep-indexedv14,arbace.repr.go13,package-textsv23,arbace.repr.go.annotate15,first-line-diffR200,V2,R99,R44,R201,V2,R99,R140,V2,R99,R140,v19,arbace.repr.go.read9,read-dumpv23,arbace.repr.go.annotate7,checkedR202,R203,R204,R205,R206,v11,arbace.core4,compv19,arbace.repr.go.read5,nodesR207,v22,arbace.repr.go.convert11,open-countsv20,arbace.repr.go.parse4,diffv20,arbace.repr.go.parse7,tree-ofR208,R209,v20,arbace.repr.go.parse7,file-atv23,arbace.repr.go.annotate12,convert-fullR210,v11,arbace.core5,classv23,arbace.repr.go.annotate8,annotateR211,R212,R213,R214,v11,arbace.core4,atomv18,arbace.repr.go.raw15,conform-packageR215,R216,R217,R218,R219,v11,arbace.core4,takel3,R220,v23,arbace.repr.go.annotate12,same-packageR221,v23,arbace.repr.go.annotate10,forms-diffR222,R223,R224,v18,arbace.repr.go.raw5,*res*R225,l16,v11,arbace.core11,read-stringv11,arbace.core5,slurpv11,arbace.core11,*read-eval*R226,R227,v11,arbace.core7,filtervR228,R229,v11,arbace.core10,merge-withv11,arbace.core1,+v13,arbace.string5,splitp2,\\tv13,arbace.string7,replaceR230,p3,/+$v23,arbace.repr.go.annotate10,spec-loadsp6,\\.edn$v19,arbace.repr.go.read10,dump-filesv23,arbace.repr.go.annotate14,helper-resultsR231,v23,arbace.repr.go.annotate13,load-sessionsv23,arbace.repr.go.annotate9,check-jobm2,R81,C29,java.util.concurrent.CallableR232,v11,arbace.core4,sortv11,arbace.core6,reduceR233,R234,R235,R236,R237,R238,R239,R240,R241,R242,v23,arbace.repr.go.annotate12,merge-countsR243,R244,R245,R246,R247,R248,R249,R250,R251,R252,v11,arbace.core7,printlnR253,R254,V2,R99,R44,R255,v21,arbace.repr.go.syntax11,errors-textR256,v23,arbace.repr.go.annotate8,tsv-linep3,/+$R61,v14,arbace.repr.go12,convert-dataR257,R258,l12,R259,R62,R63,V2,R202,R156,v23,arbace.repr.go.annotate10,error-textv23,arbace.repr.go.annotate8,read-jobm2,R81,C29,java.util.concurrent.Callablev14,arbace.repr.go6,reportR260,R261,v11,arbace.core4,spitp2,\\tv23,arbace.repr.go.annotate11,phases-textS2,s4,reads5,checkm6,R234,l1,R46,s13,tamago/gorootR257,s25,.tmp/repr-go/native-formsR262,R263,R264,R265,R266,v11,arbace.core10,parse-longR22,v20,arbace.repr.go.parse9,load-textv20,arbace.repr.go.parse5,load!v20,arbace.repr.go.parse11,forms-checkv20,arbace.repr.go.parse16,forms-check-textv23,arbace.repr.go.annotate9,read-specv11,arbace.core5,doallv23,arbace.repr.go.annotate11,read-corpusV7,R262,R255,R263,R264,R266,R231,R234,v23,arbace.repr.go.annotate12,check-corpusV7,R262,R255,R263,R264,R266,R231,R234,v23,arbace.repr.go.annotate18,drop-std-sessions!V7,R262,R255,R263,R264,R266,R231,R234,V7,R262,R255,R263,R264,R266,R231,R234,v11,arbace.core3,minv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core5,countv11,arbace.core3,prnR267,v11,arbace.core15,shutdown-agents")

var Lit_1 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000931")

var Lit_2 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000940")

var Lit_3 *jrt.String = jrt.Intern("read")

var Lit_4 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000946")

var Lit_5 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000948")

var Lit_6 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000954")

var Lit_7 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000956")

var Lit_8 *jrt.String = jrt.Intern("0")

var Lit_9 *jrt.String = jrt.Intern("REPR_GO_PREFETCH")

var Lit_10 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000958")

var Lit_11 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000960")

var Lit_12 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000963")

var Lit_13 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000968__1949000972")

var Lit_14 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949001010")

var Lit_15 *jrt.String = jrt.Intern("check")

var Lit_16 *jrt.String = jrt.Intern("native-check: %d corpora, %d dumps; E-tree %d equal; raw forms %d resolved, %d raw only; E-ann %d equal, %d differ, %d failed; E-forms %d equal, %d differ; %d not known")

var Lit_17 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949001013")

var Lit_18 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949001017")

var Lit_19 *jrt.String = jrt.Intern("usage: check|read [--full] [--jobs N] [--forms DIR] [--known FILE] [--out DIR] [--report FILE] SPEC...")

var Lit_20 *jrt.String = jrt.Intern("--print")

var Lit_21 *jrt.String = jrt.Intern("--full")

var Lit_22 *jrt.String = jrt.Intern("--tsv")

var Lit_23 *jrt.String = jrt.Intern("--text-known")

var Lit_24 *jrt.String = jrt.Intern("--forms")

var Lit_25 *jrt.String = jrt.Intern("--quiet")

var Lit_26 *jrt.String = jrt.Intern("--known")

var Lit_27 *jrt.String = jrt.Intern("--out")

var Lit_28 *jrt.String = jrt.Intern("--text")

var Lit_29 *jrt.String = jrt.Intern("--report")

var Lit_30 *jrt.String = jrt.Intern("--jobs")

var Lit_31 *jrt.String = jrt.Intern("read: one SPEC")

var Lit_32 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949001013$fn__1949001014")

var Lit_33 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000968__1949000972$fn__1949000973")

var Lit_34 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000968__1949000972$fn__1949000973$fn__1949000974")

var Lit_35 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000968__1949000972$fn__1949000973$iter__1949000992__1949000996")

var Lit_36 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000968__1949000972$fn__1949000973$fn__1949000974$iter__1949000975__1949000979")

var Lit_37 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000968__1949000972$fn__1949000973$fn__1949000974$iter__1949000975__1949000979$fn__1949000980")

var Lit_38 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000968__1949000972$fn__1949000973$fn__1949000974$iter__1949000975__1949000979$fn__1949000980$fn__1949000981")

var Lit_39 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000968__1949000972$fn__1949000973$iter__1949000992__1949000996$fn__1949000997")

var Lit_40 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000968__1949000972$fn__1949000973$iter__1949000992__1949000996$fn__1949000997$fn__1949000998")

var Lit_41 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000293__1949000297")

var Lit_42 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000331__1949000335")

var Lit_43 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$fn__1949000359")

var Lit_44 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000383__1949000387")

var Lit_45 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$fn__1949000405")

var Lit_46 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$fn__1949000359$iter__1949000360__1949000364")

var Lit_47 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$fn__1949000359$iter__1949000360__1949000364$fn__1949000365")

var Lit_48 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$fn__1949000359$iter__1949000360__1949000364$fn__1949000365$fn__1949000366")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000293__1949000297$fn__1949000298")

var Lit_50 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000293__1949000297$fn__1949000298$fn__1949000299")

var Lit_51 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000331__1949000335$fn__1949000336")

var Lit_52 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000331__1949000335$fn__1949000336$fn__1949000337")

var Lit_53 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000383__1949000387$fn__1949000388")

var Lit_54 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000383__1949000387$fn__1949000388$fn__1949000389")

var Lit_55 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000383__1949000387$fn__1949000388$fn__1949000398")

var Lit_56 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000383__1949000387$fn__1949000388$fn__1949000389$fn__1949000391")

var Lit_57 *jrt.String = jrt.Intern(":")

var Lit_58 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotation$fn__1949000281")

var Lit_59 *jrt.String = jrt.Intern("arbace.repr.go.annotate$cform$fn__1949000019")

var Lit_60 *jrt.String = jrt.Intern("arbace.repr.go.annotate$cform$fn__1949000021")

var Lit_61 *jrt.String = jrt.Intern("arbace.repr.go.annotate$cform$fn__1949000024")

var Lit_62 *jrt.String = jrt.Intern("")

var Lit_63 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000603__1949000607")

var Lit_64 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000614")

var Lit_65 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000632")

var Lit_66 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000634")

var Lit_67 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000637")

var Lit_68 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000644")

var Lit_69 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000646__1949000650")

var Lit_70 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$helper_failed_QMARK___1949000666")

var Lit_71 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$known_QMARK___1949000670")

var Lit_72 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$by__1949000674")

var Lit_73 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$sum__1949000676")

var Lit_74 *jrt.String = jrt.Intern("FAIL known")

var Lit_75 *jrt.String = jrt.Intern("FAIL")

var Lit_76 *jrt.String = jrt.Intern("    ")

var Lit_77 *jrt.String = jrt.Intern("E-TREE known")

var Lit_78 *jrt.String = jrt.Intern("E-TREE")

var Lit_79 *jrt.String = jrt.Intern("RAW known")

var Lit_80 *jrt.String = jrt.Intern("RAW")

var Lit_81 *jrt.String = jrt.Intern("E-ANN FAIL known")

var Lit_82 *jrt.String = jrt.Intern("E-ANN FAIL")

var Lit_83 *jrt.String = jrt.Intern("E-ANN known")

var Lit_84 *jrt.String = jrt.Intern("E-ANN")

var Lit_85 *jrt.String = jrt.Intern("E-FORMS known")

var Lit_86 *jrt.String = jrt.Intern("E-FORMS")

var Lit_87 *jrt.String = jrt.Intern("MISSING known")

var Lit_88 *jrt.String = jrt.Intern("MISSING")

var Lit_89 *jrt.String = jrt.Intern("CHECKER")

var Lit_90 *jrt.String = jrt.Intern("errors:")

var Lit_91 *jrt.String = jrt.Intern("EXTRA known")

var Lit_92 *jrt.String = jrt.Intern("EXTRA")

var Lit_93 *jrt.String = jrt.Intern("dumped natively, not by the helper")

var Lit_94 *jrt.String = jrt.Intern("%s: E-tree %d of %d dumps equal (%d files, %d nodes); raw forms %d resolved by the final ones (%d raw only: the helper's final conversion fails); E-ann %d of %d equal (%d differ, %d failed); E-forms %d of %d equal (:lines and :full), %d without an oracle (the helper's imports not built); %d failed, %d missing, %d extra (%d the helper's failures), %d rejected by both; %d not known; load %.1f s, parse %.1f s, dump %.1f s, read %.1f s, check %.1f s (CPU), %.1f s")

var Lit_95 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000724__1949000728")

var Lit_96 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000734__1949000738")

var Lit_97 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000744__1949000748")

var Lit_98 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000754__1949000758")

var Lit_99 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000764__1949000768")

var Lit_100 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000774__1949000778")

var Lit_101 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000784__1949000788")

var Lit_102 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000794__1949000798")

var Lit_103 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000804__1949000808")

var Lit_104 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000814__1949000818")

var Lit_105 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000828__1949000832")

var Lit_106 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000614$iter__1949000621__1949000625")

var Lit_107 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000614$iter__1949000621__1949000625$fn__1949000626")

var Lit_108 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000614$iter__1949000621__1949000625$fn__1949000626$fn__1949000627")

var Lit_109 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000637$fn__1949000641")

var Lit_110 *jrt.String = jrt.Intern("fail")

var Lit_111 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$helper_failed_QMARK___1949000666$fn__1949000667")

var Lit_112 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000603__1949000607$fn__1949000608")

var Lit_113 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000603__1949000607$fn__1949000608$fn__1949000609")

var Lit_114 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000646__1949000650$fn__1949000651")

var Lit_115 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000646__1949000650$fn__1949000651$fn__1949000652")

var Lit_116 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000646__1949000650$fn__1949000651$fn__1949000662")

var Lit_117 *jrt.String = jrt.Intern("the loader: ")

var Lit_118 *jrt.String = jrt.Intern(" ")

var Lit_119 *jrt.String = jrt.Intern("no such dump from the loader")

var Lit_120 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000646__1949000650$fn__1949000651$fn__1949000652$fn__1949000656")

var Lit_121 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000724__1949000728$fn__1949000729")

var Lit_122 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000724__1949000728$fn__1949000729$fn__1949000730")

var Lit_123 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000734__1949000738$fn__1949000739")

var Lit_124 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000734__1949000738$fn__1949000739$fn__1949000740")

var Lit_125 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000744__1949000748$fn__1949000749")

var Lit_126 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000744__1949000748$fn__1949000749$fn__1949000750")

var Lit_127 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000754__1949000758$fn__1949000759")

var Lit_128 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000754__1949000758$fn__1949000759$fn__1949000760")

var Lit_129 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000764__1949000768$fn__1949000769")

var Lit_130 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000764__1949000768$fn__1949000769$fn__1949000770")

var Lit_131 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000774__1949000778$fn__1949000779")

var Lit_132 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000774__1949000778$fn__1949000779$fn__1949000780")

var Lit_133 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000784__1949000788$fn__1949000789")

var Lit_134 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000784__1949000788$fn__1949000789$fn__1949000790")

var Lit_135 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000794__1949000798$fn__1949000799")

var Lit_136 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000794__1949000798$fn__1949000799$fn__1949000800")

var Lit_137 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000804__1949000808$fn__1949000809")

var Lit_138 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000804__1949000808$fn__1949000809$fn__1949000810")

var Lit_139 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000814__1949000818$fn__1949000819")

var Lit_140 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000814__1949000818$fn__1949000819$fn__1949000820")

var Lit_141 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000814__1949000818$fn__1949000819$fn__1949000824")

var Lit_142 *jrt.String = jrt.Intern("not the helper's failure")

var Lit_143 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000814__1949000818$fn__1949000819$fn__1949000820$fn__1949000821")

var Lit_144 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000828__1949000832$fn__1949000833")

var Lit_145 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000828__1949000832$fn__1949000833$fn__1949000834")

var Lit_146 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$known_QMARK___1949000670$fn__1949000671")

var Lit_147 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$sum__1949000676$fn__1949000677")

var Lit_148 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$iter__1949000497__1949000501")

var Lit_149 *jrt.String = jrt.Intern("go/parser: ")

var Lit_150 *jrt.String = jrt.Intern(".edn")

var Lit_151 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$fn__1949000510")

var Lit_152 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$fn__1949000514")

var Lit_153 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$fn__1949000517")

var Lit_154 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$fn__1949000519")

var Lit_155 *jrt.String = jrt.Intern("the native path converts it")

var Lit_156 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$fn__1949000521")

var Lit_157 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$fn__1949000525")

var Lit_158 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$iter__1949000527__1949000531")

var Lit_159 *jrt.String = jrt.Intern("not checked")

var Lit_160 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$fn__1949000538")

var Lit_161 *jrt.String = jrt.Intern(": ")

var Lit_162 *jrt.String = jrt.Intern("(no export data for ")

var Lit_163 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$iter__1949000497__1949000501$fn__1949000502")

var Lit_164 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$iter__1949000497__1949000501$fn__1949000502$fn__1949000503")

var Lit_165 *jrt.String = jrt.Intern("/")

var Lit_166 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$iter__1949000527__1949000531$fn__1949000532")

var Lit_167 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$iter__1949000527__1949000531$fn__1949000532$fn__1949000533")

var Lit_168 *jrt.String = jrt.Intern("arbace.repr.go.annotate$cmeta$fn__1949000013")

var Lit_169 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$id__1949000215")

var Lit_170 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000224")

var Lit_171 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$iter__1949000226__1949000232")

var Lit_172 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000242")

var Lit_173 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000245")

var Lit_174 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000252")

var Lit_175 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000254")

var Lit_176 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000257")

var Lit_177 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000263")

var Lit_178 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000265")

var Lit_179 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$iter__1949000226__1949000232$fn__1949000233")

var Lit_180 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$iter__1949000226__1949000232$fn__1949000233$iter__1949000228__1949000234")

var Lit_181 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$iter__1949000226__1949000232$fn__1949000233$iter__1949000228__1949000234$fn__1949000235")

var Lit_182 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$iter__1949000226__1949000232$fn__1949000233$iter__1949000228__1949000234$fn__1949000235$fn__1949000236")

var Lit_183 *jrt.String = jrt.Intern("java.io.File")

var Lit_184 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_185 *jrt.String = jrt.Intern("java.util.concurrent.ConcurrentHashMap")

var Lit_186 *jrt.String = jrt.Intern("java.util.concurrent.ExecutionException")

var Lit_187 *jrt.String = jrt.Intern("java.util.concurrent.Executors")

var Lit_188 *jrt.String = jrt.Intern("java.util.concurrent.FutureTask")

var Lit_189 *jrt.String = jrt.Intern("java.util.concurrent.Semaphore")

var Lit_190 *jrt.String = jrt.Intern("java.util.concurrent.TimeUnit")

var Lit_191 *jrt.String = jrt.Intern("java.util.concurrent.atomic.LongAdder")

var Lit_192 *jrt.String = jrt.Intern("arbace.repr.go.annotate$first_line_diff$fn__1949000463")

var Lit_193 *jrt.String = jrt.Intern("arbace.repr.go.annotate$forms_diff$fn__1949000470")

var Lit_194 *jrt.String = jrt.Intern("arbace.repr.go.annotate$forms_diff$fn__1949000482")

var Lit_195 *jrt.String = jrt.Intern("arbace.repr.go.annotate$helper_results$iter__1949000578__1949000582")

var Lit_196 *jrt.String = jrt.Intern("arbace.repr.go.annotate$helper_results$iter__1949000578__1949000582$fn__1949000583")

var Lit_197 *jrt.String = jrt.Intern("arbace.repr.go.annotate$helper_results$iter__1949000578__1949000582$fn__1949000583$fn__1949000584")

var Lit_198 *jrt.String = jrt.Intern("arbace.repr.go.annotate$import_specs$fn__1949000034")

var Lit_199 *jrt.String = jrt.Intern("arbace.repr.go.annotate$import_specs$fn__1949000034$fn__1949000035")

var Lit_200 *jrt.String = jrt.Intern("arbace.repr.go.annotate$import_specs$fn__1949000034$fn__1949000035$fn__1949000036")

var Lit_201 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$fn__1949000108")

var Lit_202 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000110__1949000114")

var Lit_203 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$fn__1949000146")

var Lit_204 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000148__1949000152")

var Lit_205 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$fallback__1949000158")

var Lit_206 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$fn__1949000160")

var Lit_207 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$fn__1949000162")

var Lit_208 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$fn__1949000164")

var Lit_209 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000110__1949000114$fn__1949000115")

var Lit_210 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000110__1949000114$fn__1949000115$fn__1949000116")

var Lit_211 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000110__1949000114$fn__1949000115$iter__1949000134__1949000138")

var Lit_212 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000110__1949000114$fn__1949000115$fn__1949000116$iter__1949000120__1949000124")

var Lit_213 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000110__1949000114$fn__1949000115$fn__1949000116$iter__1949000120__1949000124$fn__1949000125")

var Lit_214 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000110__1949000114$fn__1949000115$fn__1949000116$iter__1949000120__1949000124$fn__1949000125$fn__1949000126")

var Lit_215 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000110__1949000114$fn__1949000115$iter__1949000134__1949000138$fn__1949000139")

var Lit_216 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000110__1949000114$fn__1949000115$iter__1949000134__1949000138$fn__1949000139$fn__1949000140")

var Lit_217 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000148__1949000152$fn__1949000153")

var Lit_218 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000148__1949000152$fn__1949000153$fn__1949000154")

var Lit_219 *jrt.String = jrt.Intern("arbace.repr.go.annotate$new_session$deps__1949000069")

var Lit_220 *jrt.String = jrt.Intern("arbace.repr.go.annotate$new_session$start_BANG___1949000071")

var Lit_221 *jrt.String = jrt.Intern("arbace.repr.go.annotate$new_session$src_of__1949000081")

var Lit_222 *jrt.String = jrt.Intern("arbace.repr.go.annotate$new_session$fn__1949000083")

var Lit_223 *jrt.String = jrt.Intern("arbace.repr.go.annotate$new_session$fn__1949000085")

var Lit_224 *jrt.String = jrt.Intern("arbace.repr.go.annotate$new_session$start_BANG___1949000071$fn__1949000074")

var Lit_225 *jrt.String = jrt.Intern("arbace.repr.go.annotate$node_index$walk__1949000167")

var Lit_226 *jrt.String = jrt.Intern("arbace.repr.go.annotate$node_of$fn__1949000206")

var Lit_227 *jrt.String = jrt.Intern("arbace.repr.go.annotate$node_of$fn__1949000208")

var Lit_228 *jrt.String = jrt.Intern(", ")

var Lit_229 *jrt.String = jrt.Intern("arbace.repr.go.annotate$phases_text$iter__1949000054__1949000058")

var Lit_230 *jrt.String = jrt.Intern("arbace.repr.go.annotate$phases_text$iter__1949000054__1949000058$fn__1949000059")

var Lit_231 *jrt.String = jrt.Intern("arbace.repr.go.annotate$phases_text$iter__1949000054__1949000058$fn__1949000059$fn__1949000060")

var Lit_232 *jrt.String = jrt.Intern("%s %.1f")

var Lit_233 *jrt.String = jrt.Intern("arbace.repr.go.convert")

var Lit_234 *jrt.String = jrt.Intern("arbace.repr.go.annotate$raw_source$fn__1949000045")

var Lit_235 *jrt.String = jrt.Intern("main")

var Lit_236 *jrt.String = jrt.Intern("arbace.repr.go.annotate$raw_source$fn__1949000049")

var Lit_237 *jrt.String = jrt.Intern("arbace.repr.go.annotate$raw_source$fn__1949000045$fn__1949000046")

var Lit_238 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000857")

var Lit_239 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000876")

var Lit_240 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000883")

var Lit_241 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000885")

var Lit_242 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000887__1949000893")

var Lit_243 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000906__1949000910")

var Lit_244 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000916")

var Lit_245 *jrt.String = jrt.Intern("%s: native reader, %d dumps' final forms from the checker's annotations; %d rejected by go/parser, %d failed; checker errors in %d; %.1f s")

var Lit_246 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000918")

var Lit_247 *jrt.String = jrt.Intern(": phases (s summed over the jobs, the process's so far): ")

var Lit_248 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000857$iter__1949000864__1949000868")

var Lit_249 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000857$iter__1949000864__1949000868$fn__1949000869")

var Lit_250 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000857$iter__1949000864__1949000868$fn__1949000869$fn__1949000870")

var Lit_251 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000876$fn__1949000880")

var Lit_252 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000887__1949000893$fn__1949000894")

var Lit_253 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000887__1949000893$fn__1949000894$iter__1949000889__1949000898")

var Lit_254 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000887__1949000893$fn__1949000894$iter__1949000889__1949000898$fn__1949000899")

var Lit_255 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000887__1949000893$fn__1949000894$iter__1949000889__1949000898$fn__1949000899$fn__1949000900")

var Lit_256 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000906__1949000910$fn__1949000911")

var Lit_257 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000906__1949000910$fn__1949000911$fn__1949000912")

var Lit_258 *jrt.String = jrt.Intern("\n")

var Lit_259 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_job$fn__1949000845")

var Lit_260 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_job$fn__1949000849")

var Lit_261 *jrt.String = jrt.Intern("errors")

var Lit_262 *jrt.String = jrt.Intern("ok")

var Lit_263 *jrt.String = jrt.Intern("arbace.repr.go.annotate$rebuild$fn__1949000285")

var Lit_264 *jrt.String = jrt.Intern("arbace.repr.go.annotate$rebuild$fn__1949000288")

var Lit_265 *jrt.String = jrt.Intern("arbace.repr.go.annotate$rebuild$fn__1949000290")

var Lit_266 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same$fn__1949000424")

var Lit_267 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same_meta$fn__1949000414")

var Lit_268 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same_package$fn__1949000439")

var Lit_269 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same_seq$fn__1949000418")

var Lit_270 *jrt.String = jrt.Intern("arbace.repr.go.annotate$short_str$fn__1949000411")

var Lit_271 *jrt.String = jrt.Intern("...")

var Lit_272 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000542__1949000546")

var Lit_273 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000542__1949000546$fn__1949000547")

var Lit_274 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000542__1949000546$fn__1949000547$fn__1949000548")

var Lit_275 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000542__1949000546$fn__1949000547$iter__1949000562__1949000566")

var Lit_276 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000542__1949000546$fn__1949000547$fn__1949000548$iter__1949000549__1949000553")

var Lit_277 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000542__1949000546$fn__1949000547$fn__1949000548$iter__1949000549__1949000553$fn__1949000554")

var Lit_278 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000542__1949000546$fn__1949000547$fn__1949000548$iter__1949000549__1949000553$fn__1949000554$fn__1949000555")

var Lit_279 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000542__1949000546$fn__1949000547$iter__1949000562__1949000566$fn__1949000567")

var Lit_280 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000542__1949000546$fn__1949000547$iter__1949000562__1949000566$fn__1949000567$fn__1949000568")

var Lit_281 *jrt.String = jrt.Intern("/src")

var Lit_282 *jrt.String = jrt.Intern("arbace.repr.go.annotate$std_index$iter__1949000088__1949000092")

var Lit_283 *jrt.String = jrt.Intern("arbace.repr.go.annotate$std_index$iter__1949000088__1949000092$fn__1949000093")

var Lit_284 *jrt.String = jrt.Intern("arbace.repr.go.annotate$std_index$iter__1949000088__1949000092$fn__1949000093$fn__1949000094")

var Lit_285 *jrt.String = jrt.Intern("\t")

var Lit_286 *jrt.String = jrt.Intern(" | ")

var Lit_287 *jrt.String = jrt.Intern("arbace.repr.go.annotate$val_shape$fn__1949000272")

var Lit_288 *jrt.String = jrt.Intern(" [")

var Lit_289 *jrt.String = jrt.Intern(".test]")

var Lit_290 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session$job_of__1949000448")

var Lit_291 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session$fn__1949000450")

var Lit_292 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session$reaches__1949000452")

var Lit_293 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session$src_of__1949000456")

var Lit_294 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session$fn__1949000458")

var Lit_295 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session$reaches__1949000452$fn__1949000453")

var Lit_296 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn1,kkn4,linekn6,columnkn4,filekn8,declaredyn1,xyn4,fileyn1,fyn2,rcyn10,import-mapyn4,loadkn6,nativekn3,rawkn8,annotatekn7,convertkn6,layoutkn3,tagyn4,longyn1,jyn12,more-importsyn10,FutureTaskyn5,indexyn4,baseyn8,fallbackyn10,imports-ofyn1,pyn2,jskn8,path-poskn3,dotkn6,lbrackkn6,lparenkn4,starkn5,colonkn6,op-poskn9,value-poskn6,lbracekn3,mapkn5,beginkn4,funckn6,structkn9,interfacekn5,arrowkn8,name-posyn3,astyn7,HashMapyn2,pmyn2,ttyn1,Tyn1,vyn2,tykn7,typexprkn4,typekn7,builtinkn8,constantkn5,constkn7,novaluekn4,voidkn7,commaokkn8,mapindexkn8,variablekn3,varkn5,valueyn4,def?yn1,nyn1,ayn4,pathyn4,annsyn6,resultyn1,byn2,asyn2,bsyn2,xsyn2,nayn2,fbyn1,syn7,sess-ofyn6,Stringyn2,adyn4,actxyn1,dyn4,dctxyn2,ncyn2,fcyn3,ctxyn4,specyn2,msyn4,poolyn5,knownyn2,styn5,filesyn5,bytesyn4,errsyn3,msgyn2,nmyn3,outyn9,positionsyn4,optsyn1,&yn4,argsv11,arbace.core5,in-nsMyn23,arbace.repr.go.annotatem2,R0,s1649,repr/go's annotator (doc/go/GO-PARSER-SURVEY.md GP4, §4.2 steps 3-5): goi's checker\n  (arbace.go.check) in its resolve mode over the raw forms of the native reader's dumps\n  (arbace.repr.go.raw, GP3), each open decision answered by position; the answers put into the\n  native dump as go/types' annotations, in the helper's shape (doc/go/HELPER-NOTES.md, \"Output\n  format\": :mode, :t, :use, :def, :sel, :field, :inst, :implicit, :init-order, :types'\n  :underlying, :type-table), which the converter, unchanged, turns into the final forms.\n\n  The packages are checked in dependency order, as bin/goi annotations checks them: one session\n  of the standard library per configuration (its packages from the loader, std), a corpus's own\n  packages in a session over it (a module's, cmd's, a directory test's, test variants), each\n  package's imports by the loader's resolution. Raw forms are taken in memory (GPS26 (a)), as\n  the checker reads text: literals as values, lines as :line, and each node's positions as\n  :arbace.go.check/at [file {field [line col]}], the key of its answers.\n\n  bin/repr-go native-check runs -main check: per dump E-tree (arbace.repr.go.parse), the raw\n  forms against the final ones (arbace.repr.go.raw/conform, GPS23 (c)) and E-ann: the final\n  forms the converter makes of the annotated native dump equal, form for form, metadata and\n  positions included (mode :full), to those of the helper's dump: the annotations the converter\n  reads equal go/types', types compared by the type forms they give. bin/repr-go read --reader\n  native --forms runs -main read: the final forms written as bin/repr-go read writes the helper's.m2,R0,s1649,repr/go's annotator (doc/go/GO-PARSER-SURVEY.md GP4, §4.2 steps 3-5): goi's checker\n  (arbace.go.check) in its resolve mode over the raw forms of the native reader's dumps\n  (arbace.repr.go.raw, GP3), each open decision answered by position; the answers put into the\n  native dump as go/types' annotations, in the helper's shape (doc/go/HELPER-NOTES.md, \"Output\n  format\": :mode, :t, :use, :def, :sel, :field, :inst, :implicit, :init-order, :types'\n  :underlying, :type-table), which the converter, unchanged, turns into the final forms.\n\n  The packages are checked in dependency order, as bin/goi annotations checks them: one session\n  of the standard library per configuration (its packages from the loader, std), a corpus's own\n  packages in a session over it (a module's, cmd's, a directory test's, test variants), each\n  package's imports by the loader's resolution. Raw forms are taken in memory (GPS26 (a)), as\n  the checker reads text: literals as values, lines as :line, and each node's positions as\n  :arbace.go.check/at [file {field [line col]}], the key of its answers.\n\n  bin/repr-go native-check runs -main check: per dump E-tree (arbace.repr.go.parse), the raw\n  forms against the final ones (arbace.repr.go.raw/conform, GPS23 (c)) and E-ann: the final\n  forms the converter makes of the annotated native dump equal, form for form, metadata and\n  positions included (mode :full), to those of the helper's dump: the annotations the converter\n  reads equal go/types', types compared by the type forms they give. bin/repr-go read --reader\n  native --forms runs -main read: the final forms written as bin/repr-go read writes the helper's.R1,v23,arbace.repr.go.annotate12,private-key?m10,R2,TR3,L1,V1,R4,R5,i43,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate5,cformm8,R8,TR5,i45,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate5,cmetam12,R2,TR3,L1,V2,R9,R10,R0,s84,The metadata x reads back with (its public keys, :line), and the key of its answers.R5,i47,R6,i1,R7,s26,arbace/repr/go/annotate.aem10,R3,L1,V2,R9,R10,R0,s182,The in-memory raw form x of Go file file as the checker reads it: literals as their values,\n  each list, vector and symbol with its line and its positions' key (:arbace.go.check/at).R5,i59,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate12,import-specsm12,R2,TR3,L1,V1,R11,R0,s114,A go/file form whose import specs carry their path's position (:path-pos), the key of an\n  implicit name's answer.R5,i73,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate10,raw-sourcem10,R3,L1,V2,R12,R13,R0,s207,The checker's source (arbace.go.check/check-package's) of raw conversion rc (convert-package's\n  result, raw), its imports resolved by import-map ({as written -> key}), its answers in a\n  HashMap (:answers).R5,i94,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,forms-dirv11,arbace.core4,atomm8,R5,i109,R6,i1,R7,s26,arbace/repr/go/annotate.aeR0,s50,The forms of go/parser's packages (tamago/goroot).v23,arbace.repr.go.annotate10,config-keym10,R2,TR3,L1,V1,R14,R5,i111,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate6,phasesR15,R16,R17,R18,R19,m10,R2,TR5,i115,R6,i1,R7,s26,arbace/repr/go/annotate.aeR0,s253,The native read's time per phase, in ns summed over the jobs (bin/repr-go read's phases\n  line): the parse and dump, the raw conversion with the checker's source, the annotation of\n  the dump, the final conversion, its layout, write and read-back check.v23,arbace.repr.go.annotate6,phase!m10,R2,TR3,L1,V2,R4,Myn2,nsm2,R20,R21,R5,i121,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate11,phases-textm10,R3,L1,V0,R0,s41,The phases summed so far, as CPU-seconds.R5,i123,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate4,prepm12,R2,TR3,L1,V2,R22,R23,R0,s146,A loader job's native dump, raw conversion and checker source (import-map over the job's own),\n  or {:rejected msg} when go/parser rejects a file.R5,i129,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate8,prefetchm10,R2,TR5,i146,R6,i1,R7,s26,arbace/repr/go/annotate.aeR0,s350,The pool that prepares jobs (prep: their native dumps and raw conversions, which need no other\n  package) ahead of the checker, which asks for them in dependency order (GP7), and the permits\n  that bound the jobs prepared but not yet asked for (their trees and raw forms held): {:pool\n  :permits}; nil: each job prepared when the checker asks for it.v23,arbace.repr.go.annotate8,run-taskm12,R2,TR3,L1,V1,Myn2,ftm2,R20,R24,R0,s77,Runs FutureTask ft here unless it runs or ran already, and returns its value.R5,i153,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate11,new-sessionm12,R2,TR3,L1,V4,R25,R26,R27,R28,R0,s445,A session over index ({key job}): the checker's (arbace.go.check/session), delegating to\n  base for the keys index does not have (fallback: key -> a job, or nil), the records of the\n  keys kept (registered with keep!) for their jobs (:recs). With the prefetch pool, a job asked\n  for starts the preparation of the jobs it imports (:start!), each once, so that their native\n  dumps and raw conversions run in parallel ahead of the checker's walk.R5,i160,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate12,std-sessionsm8,R2,TR5,i207,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,std-indexm10,R2,TR3,L1,V1,R14,R5,i209,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate11,std-sessionm10,R3,L1,V1,R14,R0,s84,The session of the standard library of load's configuration (made once per process).R5,i215,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate18,drop-std-sessions!m10,R3,L1,V0,R0,s85,Forgets the standard library's sessions (and the generic types' instances they made).R5,i225,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,std-load?m10,R2,TR3,L1,V1,R14,R5,i234,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate11,variant-keym10,R2,TR3,L1,V1,R29,R5,i237,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,job-keym12,R2,TR3,L1,V2,R14,R22,R0,s122,The key a corpus job is checked under: its package path, a test variant's p [p.test]; nil for\n  a program (checked alone).R5,i239,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate11,job-importsm12,R2,TR3,L1,V3,R14,R25,R22,R0,s148,The imports of a corpus job beyond the loader's map: an external test's package as its test\n  variant (go list -test's ImportMap) when there is one.R5,i251,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate13,load-sessionsm10,R3,L1,V2,R14,R30,R0,s164,The sessions of a corpus load's jobs: [session-of-job keyed-jobs], session-of-job giving a\n  job's session (the standard library's, the load's, a directory test's).R5,i261,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,anchorsV16,R31,R32,R33,R34,R35,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,m10,R2,TR5,i291,R6,i1,R7,s26,arbace/repr/go/annotate.aeR0,s153,The position fields that name a node, in order, for an answer whose positions are not exactly\n  one node's (a form whose positions merge another node's).v23,arbace.repr.go.annotate10,node-indexm12,R2,TR3,L1,V1,R47,R0,s88,{[field [line col]] [node-path node]} and {positions [node-path node]} of a file's tree.R5,i297,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,node-ofm12,R2,TR3,L1,V2,V2,Myn8,by-fieldm2,R20,R48,Myn6,by-posm2,R20,R48,R49,R0,s87,The path of the node an answer's positions pm name, in index [by-field by-pos], or nil.R5,i317,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,new-tablem10,R2,TR3,L1,V0,R5,i328,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate8,type-id!m8,R8,TR5,i330,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate8,entry-ofm12,R2,TR3,L1,V2,R50,R51,R0,s66,The type table entry of checker type T, its parts' ids made first.R5,i332,R6,i1,R7,s26,arbace/repr/go/annotate.aem10,R3,L1,V2,R50,R51,R0,s78,The id of checker type T in the table tt (entered, its parts first, when new).R5,i391,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate11,float-shapem10,R2,TR3,L1,V1,R52,R5,i413,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,val-shapem10,R3,L1,V2,R52,R53,R0,s185,The helper's :val of a constant value v of checker type ty (go/constant's kind as go/types\n  computes it for the type: a float type's value a float, a complex type's a complex), or nil.R5,i418,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,mode-ofm16,R54,R55,R56,R56,R57,R58,R59,R60,R61,R61,R62,R62,R63,R64,R65,R65,m8,R2,TR5,i438,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate14,obj-annotationm12,R2,TR3,L1,V3,R50,R9,R66,R0,s111,An object (the checker's) as the helper writes it: {:kind :name [:universe] [:pkg-level]\n  [:pkg] [:t] [:val]}.R5,i442,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate10,annotationm12,R2,TR3,L1,V3,R50,R67,R68,R0,s77,The helper's annotations of node n from the answers a there (merged), or nil.R5,i461,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,rebuildm12,R2,TR3,L1,V3,R9,R69,R70,R0,s137,The tree x with metadata ann (by node path) merged into its nodes; basic literals are\n  constants, parentheses take their operand's mode.R5,i485,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate8,annotatem10,R3,L1,V3,R67,Myn7,answersm2,R20,R48,R71,R0,s262,Native dump n with the checker's answers (a HashMap, raw-source's) and package result as\n  go/types' annotations: the trees' metadata, :init-order, :types (the package's named types'\n  underlying types) and :type-table. {:dump :unplaced n-answers-not-on-a-node}.R5,i512,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,short-strm10,R2,TR3,L1,V1,R9,R5,i556,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate4,samem8,R8,TR5,i560,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,same-metam10,R2,TR3,L1,V3,R68,R72,R69,R5,i562,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate8,same-seqm10,R2,TR3,L1,V3,R73,R74,R69,R5,i569,R6,i1,R7,s26,arbace/repr/go/annotate.aem10,R3,L1,V3,R68,R72,R69,R0,s167,nil when the forms a (the native path's) and b (the helper's) are equal, metadata, positions\n  and literals' parts included; else the first difference [path what a b].R5,i574,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,line-atm12,R2,TR3,L1,V2,R75,R69,R0,s79,The Go line of the innermost form on path in forms xs (a difference's), or nil.R5,i589,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate12,same-packagem10,R3,L1,V2,R76,R77,R0,s149,nil when the conversions na (of the annotated native dump) and fb (of the helper's) are equal;\n  else the first difference [file line path what a b].R5,i601,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate14,external-test?m10,R2,TR3,L1,V2,R14,R22,R5,i617,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate13,xtest-sessionm12,R2,TR3,L1,V2,R78,R22,R0,s357,go list -test's world of external test j of a package p with in-package tests, over session s\n  (its load's): p is its test variant (p [p.test]), and the packages of the test's imports that\n  import p, directly or not, are checked anew against it (go list's recompiled q [p.test]); the\n  others are s's and the standard library's. nil when p has no variant.R5,i620,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,checkedm12,R2,TR3,L1,V3,R14,R79,R22,R0,s314,Corpus job j of load checked: [package record], the record prep's (its native dump, raw\n  forms, source and answers). A package is checked through its session (for its importers too);\n  a program alone; an external test alone, in its world (xtest-session); a package its session\n  checked before it was kept, anew.R5,i643,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate15,first-line-diffm12,R2,TR3,L1,V2,Myn1,am2,R20,R80,Myn1,bm2,R20,R80,R0,s55,The first line (from 1) where the texts a and b differ.R5,i662,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate10,forms-diffm10,R3,L1,V6,R81,R82,R83,R84,R85,R86,R0,s265,E-forms: the .ae texts of the native annotated dump ad (context actx) against the helper's\n  dump d (context dctx), in mode :full (of their conversions nc and fc, already made) and mode\n  :lines (converted here): nil when byte for byte equal, else [mode file line].R5,i669,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate12,convert-fullm10,R2,TR3,L1,V2,R83,R87,R5,i686,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,check-jobm12,R2,TR3,L1,V4,R14,R79,R22,Myn4,pathm2,R20,R80,R0,s131,A corpus job's checks against the helper's dump at path (nil: none): E-tree, the raw forms'\n  conformance to the final ones, E-ann.R5,i689,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,read-specm10,R2,TR3,L1,V1,Myn1,fm2,R20,R80,R5,i758,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate10,spec-loadsm12,R2,TR3,L1,V1,R88,R0,s86,The loads of corpus spec: [[load jobs results] ...], jobs keyed under the load's :sub.R5,i760,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate12,merge-countsm10,R2,TR3,L1,V1,R89,R5,i769,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate14,helper-resultsm10,R2,TR3,L1,V1,Myn3,tsvm2,R20,R80,R5,i771,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate12,check-corpusm10,R2,TR3,L1,V3,R88,R90,R91,R5,i779,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate8,tsv-linem12,R2,TR3,L1,V7,R92,R4,R93,R94,R89,R95,R96,R0,s222,A job's line of the conversion's summary, in the helper's format (tools/godump's: STATUS KEY\n  FILES BYTES MS ERRORS [MSG], tab-separated): ok, errors (the checker's, the first as MSG) or\n  fail (go/parser rejects a file).R5,i863,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate10,error-textm10,R2,TR3,L1,V1,R9,R5,i870,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate8,read-jobm12,R2,TR3,L1,V7,R97,R14,R79,R22,R98,R99,R100,R0,s273,The final forms of corpus job j (the checker's annotations, converted) written under out (mode\n  positions, opts :print :text as arbace.repr.go/convert-data's): convert-data's result with\n  :path NAME/KEY.edn, or {:rejected msg}, or {:fail msg}; and :tsv, its summary line.R5,i872,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate11,read-corpusm12,R2,TR3,L1,V5,R88,R90,R98,R99,R100,R0,s224,Corpus spec's final forms written into out as bin/repr-go read writes the helper's (each\n  job's convert-data result, arbace.repr.go/report); the summary in the helper's format to\n  opts :tsv. Returns {:status :results ...}.R5,i919,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate5,-mainm10,R3,L1,V2,R101,R102,R0,s1407,check [--jobs N] [--forms DIR] [--known FILE] [--report FILE] SPEC...\n  read [--full] [--jobs N] [--forms DIR] [--out DIR] [--print DIR] [--text] [--text-known FILE]\n       [--quiet] [--report FILE] [--tsv FILE] SPEC\n\n  read: the native reader (bin/repr-go read's default, GPS7): the final forms of the corpus\n  SPEC's dumps (the native reader's, annotated by goi's checker in its resolve mode, converted as\n  the helper's are), written into --out DIR as arbace.repr.go -main read writes the helper's\n  (mode :lines, --full :full), each file read back; --print, --text and --text-known as there\n  (the round trips); its output and --report as there (arbace.repr.go/report), and --tsv the\n  summary in the helper's format (tools/godump's: ok, errors with the checker's first error,\n  fail when go/parser rejects a file or the loader fails, excluded). Exits 1 when a conversion\n  fails, a file does not read back or (--text) a file differs that the known ones do not list.\n\n  check: per dump of each corpus SPEC (arbace.repr.go.parse's specs) against the helper's dumps\n  (:dumps): E-tree, the raw forms against the final ones (conform), E-ann (the final forms of the\n  annotated native dump equal the helper's), E-forms (their .ae text equal in modes :lines and\n  :full). Exits 1 on a difference or failure that the known differences (a map of dump key,\n  package path or file key to the reason) do not list.R5,i955,R6,i1,R7,s26,arbace/repr/go/annotate.ae")

var Lit_297 *jrt.String = jrt.Intern("arbace.repr.go.annotate$eval1949000004$loading__1927001464__auto____1949000005")

var Lit_298 *jrt.String = jrt.Intern("arbace.repr.go.annotate$eval1949000008$fn__1949000009")

var Lit_299 *jrt.String = jrt.Intern("arbace.repr.go.annotate$private_key_QMARK_")

var Lit_300 *jrt.String = jrt.Intern("arbace.repr.go.annotate$cmeta")

var Lit_301 *jrt.String = jrt.Intern("arbace.repr.go.annotate$cform")

var Lit_302 *jrt.String = jrt.Intern("arbace.repr.go.annotate$import_specs")

var Lit_303 *jrt.String = jrt.Intern("arbace.repr.go.annotate$raw_source")

var Lit_304 *jrt.String = jrt.Intern("tamago/goroot")

var Lit_305 *jrt.String = jrt.Intern("arbace.repr.go.annotate$config_key")

var Lit_306 *jrt.String = jrt.Intern("arbace.repr.go.annotate$phase_BANG_")

var Lit_307 *jrt.String = jrt.Intern("arbace.repr.go.annotate$phases_text")

var Lit_308 *jrt.String = jrt.Intern("arbace.repr.go.annotate$prep")

var Lit_309 *jrt.String = jrt.Intern("arbace.repr.go.annotate$run_task")

var Lit_310 *jrt.String = jrt.Intern("arbace.repr.go.annotate$new_session")

var Lit_311 *jrt.String = jrt.Intern("arbace.repr.go.annotate$std_index")

var Lit_312 *jrt.String = jrt.Intern("arbace.repr.go.annotate$std_session")

var Lit_313 *jrt.String = jrt.Intern("arbace.repr.go.annotate$drop_std_sessions_BANG_")

var Lit_314 *jrt.String = jrt.Intern("arbace.repr.go.annotate$std_load_QMARK_")

var Lit_315 *jrt.String = jrt.Intern("arbace.repr.go.annotate$variant_key")

var Lit_316 *jrt.String = jrt.Intern("arbace.repr.go.annotate$job_key")

var Lit_317 *jrt.String = jrt.Intern("arbace.repr.go.annotate$job_imports")

var Lit_318 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions")

var Lit_319 *jrt.String = jrt.Intern("arbace.repr.go.annotate$node_index")

var Lit_320 *jrt.String = jrt.Intern("arbace.repr.go.annotate$node_of")

var Lit_321 *jrt.String = jrt.Intern("arbace.repr.go.annotate$new_table")

var Lit_322 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of")

var Lit_323 *jrt.String = jrt.Intern("arbace.repr.go.annotate$type_id_BANG_")

var Lit_324 *jrt.String = jrt.Intern("arbace.repr.go.annotate$float_shape")

var Lit_325 *jrt.String = jrt.Intern("arbace.repr.go.annotate$val_shape")

var Lit_326 *jrt.String = jrt.Intern("arbace.repr.go.annotate$obj_annotation")

var Lit_327 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotation")

var Lit_328 *jrt.String = jrt.Intern("arbace.repr.go.annotate$rebuild")

var Lit_329 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate")

var Lit_330 *jrt.String = jrt.Intern("arbace.repr.go.annotate$short_str")

var Lit_331 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same_meta")

var Lit_332 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same_seq")

var Lit_333 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same")

var Lit_334 *jrt.String = jrt.Intern("arbace.repr.go.annotate$line_at")

var Lit_335 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same_package")

var Lit_336 *jrt.String = jrt.Intern("arbace.repr.go.annotate$external_test_QMARK_")

var Lit_337 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session")

var Lit_338 *jrt.String = jrt.Intern("arbace.repr.go.annotate$checked")

var Lit_339 *jrt.String = jrt.Intern("arbace.repr.go.annotate$first_line_diff")

var Lit_340 *jrt.String = jrt.Intern("arbace.repr.go.annotate$forms_diff")

var Lit_341 *jrt.String = jrt.Intern("arbace.repr.go.annotate$convert_full")

var Lit_342 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job")

var Lit_343 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_spec")

var Lit_344 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads")

var Lit_345 *jrt.String = jrt.Intern("arbace.repr.go.annotate$merge_counts")

var Lit_346 *jrt.String = jrt.Intern("arbace.repr.go.annotate$helper_results")

var Lit_347 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus")

var Lit_348 *jrt.String = jrt.Intern("arbace.repr.go.annotate$tsv_line")

var Lit_349 *jrt.String = jrt.Intern("arbace.repr.go.annotate$error_text")

var Lit_350 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_job")

var Lit_351 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus")

var Lit_352 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main")
