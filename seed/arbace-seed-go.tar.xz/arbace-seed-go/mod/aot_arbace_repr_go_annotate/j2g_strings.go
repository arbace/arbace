//line j2g_strings.ae:1
package aot_arbace_repr_go_annotate

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn15,arbace.go.checkyn2,ckyn19,arbace.go.check.envyn1,eyn21,arbace.go.check.typesyn1,tyn21,arbace.go.check.constyn1,cyn14,arbace.repr.goyn2,rgyn22,arbace.repr.go.convertyn2,cvyn18,arbace.repr.go.lityn3,lityn19,arbace.repr.go.loadyn2,ldyn20,arbace.repr.go.parseyn2,psyn20,arbace.repr.go.printyn2,rpyn18,arbace.repr.go.rawyn3,rawyn19,arbace.repr.go.readyn2,rdkn3,docks22,arbace.repr.go.convert1,lks22,arbace.repr.go.convert3,poskn4,lineks15,arbace.go.check2,atkn5,valueks22,arbace.repr.go.convert3,rawkn4,elseyn5,in-nsyn5,quoteys2,go4,filekn7,importskn3,poskn8,path-poskn7,packagekn4,namekn5,formskn5,fileskn4,langkn6,configkn4,pathkn4,optskn13,local-importskn7,answerskn6,gorootkn4,gooskn6,goarchkn5,levelkn4,tagskn5,errorkn3,jobkn1,nkn8,rejectedkn4,filekn3,keykn9,positionskn4,fullkn3,rawkn10,import-mapkn3,ctxkn2,rckn3,srckn9,native-mskn6,raw-mskn8,delegatekn2,ckkn5,localkn3,haskn4,recskn4,keepkn5,indexkn4,basekn8,fallbackkn7,goamd64kn7,goarm64kn4,modekn8,packageskn3,cwdkn4,argskn6,headerkn5,testskn8,for-testkn13,test-go-fileskn4,dirskn8,dir-testkn4,testkn4,depskn6,prefixkn11,import-speckn5,x-poskn3,dotkn8,name-poskn7,entrieskn3,idskn5,namedks21,arbace.go.check.types5,aliaskn4,kindkn5,aliaskn6,actualkn3,pkgkn14,unsafe-pointerkn5,basickn6,originkn5,targskn10,type-paramkn3,objkn5,tuplekn4,varskn1,tkn9,interfacekn9,embeddedskn7,methodskn4,typekn7,pointerkn4,elemkn5,arraykn3,lenkn3,mapkn5,slicekn4,chankn3,dirkn4,funckn6,paramskn7,resultskn8,variadickn5,unionkn5,termskn5,tildekn3,allkn6,structkn6,fieldskn8,embeddedkn3,tagks23,arbace.repr.go.annotate5,aliasks23,arbace.repr.go.annotate2,idkn5,floatkn7,unknownkn5,byteskn7,complexkn8,universekn9,pkg-levelkn5,constkn7,invalidkn3,valkn5,fieldkn11,untyped-nilkn3,nilkn3,selkn5,finalkn11,binary-exprkn3,defkn3,usekn9,field-objkn8,indirectkn3,viakn4,instkn8,implicitkn12,x-unrecordedkn2,opkn9,basic-litkn10,unary-exprkn1,xkn10,paren-exprkn3,astkn3,lhskn18,resolve-init-orderkn10,underlyingkn4,dumpkn10,init-orderkn5,typeskn10,type-tablekn8,unplacedkn4,metakn9,meta-keyskn5,countkn7,literalkn6,symbolkn8,map-keyskn2,nskn4,stemkn8,commentskn4,keyskn5,timeskn7,read-mskn8,check-mskn4,failkn5,nodeskn4,openkn5,extrakn4,diffkn10,final-failkn3,reskn8,raw-diffkn6,resultkn8,ann-failkn6,errorskn10,error-msgskn3,msgkn6,ann-mskn8,ann-diffkn5,equalkn5,tracekn3,subkn7,tsv-keykn6,statuskn5,loadskn5,dumpskn3,tsvkn7,missingkn6,corpuskn4,jobskn10,tree-equalkn12,raw-resolvedkn8,raw-onlykn9,ann-equalkn10,ann-differkn11,tree-differkn10,raw-differkn11,resolutionskn14,checker-errorskn6,load-skn7,parse-skn6,dump-skn6,read-skn7,check-skn5,ann-skn6,wall-skn8,parse-mskn7,dump-mskn3,outkn5,checkkn3,badkn2,mskn6,failedkn5,knownkn6,reportkn5,lineskn7,corporav11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,V3,R18,R2,R19,V3,R20,R2,R21,V3,R22,R2,R23,V3,R24,R2,R25,V3,R26,R2,R27,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn23,arbace.repr.go.annotatem2,R28,s1649,repr/go's annotator (doc/go/GO-PARSER-SURVEY.md GP4, §4.2 steps 3-5): goi's checker\n  (arbace.go.check) in its resolve mode over the raw forms of the native reader's dumps\n  (arbace.repr.go.raw, GP3), each open decision answered by position; the answers put into the\n  native dump as go/types' annotations, in the helper's shape (doc/go/HELPER-NOTES.md, \"Output\n  format\": :mode, :t, :use, :def, :sel, :field, :inst, :implicit, :init-order, :types'\n  :underlying, :type-table), which the converter, unchanged, turns into the final forms.\n\n  The packages are checked in dependency order, as bin/goi annotations checks them: one session\n  of the standard library per configuration (its packages from the loader, std), a corpus's own\n  packages in a session over it (a module's, cmd's, a directory test's, test variants), each\n  package's imports by the loader's resolution. Raw forms are taken in memory (GPS26 (a)), as\n  the checker reads text: literals as values, lines as :line, and each node's positions as\n  :arbace.go.check/at [file {field [line col]}], the key of its answers.\n\n  bin/repr-go native-check runs -main check: per dump E-tree (arbace.repr.go.parse), the raw\n  forms against the final ones (arbace.repr.go.raw/conform, GPS23 (c)) and E-ann: the final\n  forms the converter makes of the annotated native dump equal, form for form, metadata and\n  positions included (mode :full), to those of the helper's dump: the annotations the converter\n  reads equal go/types', types compared by the type forms they give. bin/repr-go read --reader\n  native --forms runs -main read: the final forms written as bin/repr-go read writes the helper's.v11,arbace.core8,keyword?v11,arbace.core9,namespacev11,arbace.core11,persistent!v11,arbace.core9,reduce-kvv23,arbace.repr.go.annotate12,private-key?v11,arbace.core6,assoc!v23,arbace.repr.go.annotate5,cformv11,arbace.core9,transientR29,R30,v11,arbace.core5,assocR31,v11,arbace.core3,seqR32,v18,arbace.repr.go.lit4,lit?R33,v11,arbace.core4,seq?R34,v11,arbace.core4,listv11,arbace.core9,with-metav11,arbace.core5,applyv11,arbace.core3,mapv23,arbace.repr.go.annotate5,cmetav11,arbace.core7,vector?v11,arbace.core4,mapvv11,arbace.core4,map?v11,arbace.core4,intov11,arbace.core7,symbol?R35,R36,R37,v11,arbace.core6,secondR38,v11,arbace.core5,firstv11,arbace.core4,nextv11,arbace.core3,vecR39,v11,arbace.core6,updatev11,arbace.core4,peekR40,v11,arbace.core9,vary-metav11,arbace.core10,sorted-mapR41,v11,arbace.core6,concatR42,v11,arbace.core6,mapcatv23,arbace.repr.go.annotate12,import-specsR43,R44,R45,v20,arbace.repr.go.print13,collect-formsv11,arbace.core8,to-arrayv11,arbace.core5,mergem2,R46,s6,go1.27R47,R48,v20,arbace.repr.go.print9,name-textR49,R50,R51,v19,arbace.repr.go.load6,configR52,R53,R54,R55,R56,v20,arbace.repr.go.parse11,native-dumpv23,arbace.repr.go.annotate9,forms-dirR57,R58,R59,R60,R61,v14,arbace.repr.go12,dump-contextR62,v22,arbace.repr.go.convert15,convert-packageR63,R64,R65,v23,arbace.repr.go.annotate10,raw-sourceR66,R67,R68,R69,R70,R71,v23,arbace.repr.go.annotate4,prepv15,arbace.go.check7,sessionR72,R73,R74,v11,arbace.core9,contains?v11,arbace.core3,notR75,R76,R77,R78,R79,R80,v19,arbace.repr.go.load4,jobsv11,arbace.core11,select-keysV6,R52,R53,R54,R56,R81,R82,R83,R84,R85,R86,V1,s3,stdv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core6,get-inV2,R87,R42,v11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consV2,R87,R42,v11,arbace.core4,restv23,arbace.repr.go.annotate10,config-keyv23,arbace.repr.go.annotate12,std-sessionsv23,arbace.repr.go.annotate11,new-sessionv23,arbace.repr.go.annotate9,std-indexv11,arbace.core10,constantlyv11,arbace.core5,swap!v20,arbace.go.check.load12,clear-cache!v11,arbace.core6,reset!v20,arbace.go.check.decl16,clear-instances!v11,arbace.core7,keywordv11,arbace.core4,nameV1,s3,stdR88,R87,R89,R90,v23,arbace.repr.go.annotate11,variant-keyv11,arbace.core4,not=v23,arbace.repr.go.annotate11,std-sessionv23,arbace.repr.go.annotate9,std-load?R91,v11,arbace.core8,group-byV3,R87,R92,R93,V2,R87,R42,V2,R87,R42,V2,R87,R42,V2,R87,R42,v23,arbace.repr.go.annotate7,job-keyv13,arbace.string9,includes?v11,arbace.core6,filterR94,R95,v23,arbace.repr.go.annotate11,job-importsV3,R87,R92,R93,v22,arbace.repr.go.convert9,positionsv11,arbace.core11,map-indexedv11,arbace.core6,vectorR96,v22,arbace.repr.go.convert9,parse-posv22,arbace.repr.go.convert5,startl1,R97,R98,R99,v11,arbace.core4,somev23,arbace.repr.go.annotate7,anchorsR100,R101,R102,v23,arbace.repr.go.annotate8,type-id!R103,R104,R105,R106,R107,v21,arbace.go.check.types13,kw-alias-infoR108,m6,R104,R109,R43,s7,PointerR107,s6,unsafeR109,v21,arbace.go.check.types11,basic-namesv21,arbace.go.check.types6,named?v21,arbace.go.check.types4,infoR110,R111,v21,arbace.go.check.types7,tparam?R112,R113,v19,arbace.go.check.env1,oR114,R115,R116,R117,R118,v11,arbace.core3,setv21,arbace.go.check.types5,underv11,arbace.core6,removem2,R104,R117,R119,R120,R121,R122,R123,R124,m4,R104,R109,R43,s12,invalid typev11,arbace.core6,dissocR125,R126,R127,R128,R129,R130,R131,R132,R133,R134,R135,R136,v11,arbace.core7,sort-byv21,arbace.go.check.types8,type-strR137,R138,R139,R140,v21,arbace.go.check.const10,value-textv23,arbace.repr.go.annotate8,entry-ofR141,R142,v21,arbace.go.check.const3,bf?R143,v11,arbace.core6,ratio?v11,arbace.core8,integer?v21,arbace.go.check.const8,make-ratR144,v11,arbace.core8,boolean?v11,arbace.core7,string?v21,arbace.go.check.const11,value-bytesv21,arbace.go.check.const8,complex?v21,arbace.go.check.types11,float-type?v23,arbace.repr.go.annotate11,float-shapev21,arbace.go.check.types13,complex-type?R145,R146,l0,v19,arbace.go.check.env4,obj?R147,R148,R149,v11,arbace.core5,some?R150,v23,arbace.repr.go.annotate9,val-shapeR151,R152,R153,R154,v23,arbace.repr.go.annotate7,mode-ofR155,v11,arbace.core9,not-emptyR156,R157,S2,s2,>>s2,<<R158,v23,arbace.repr.go.annotate14,obj-annotationR159,R160,R161,R162,R163,R164,R165,R166,v23,arbace.repr.go.annotate7,rebuildv11,arbace.core5,nnextR167,m2,R83,R149,R168,S4,s1,!s1,-s1,^s1,+R169,m2,R83,R149,R170,V2,R83,R116,v23,arbace.repr.go.annotate9,new-tablev23,arbace.repr.go.annotate10,node-indexR171,v11,arbace.core9,volatile!v23,arbace.repr.go.annotate10,annotationv11,arbace.core6,ffirstR172,R173,R174,R175,R176,R177,R178,R179,v23,arbace.repr.go.annotate7,node-ofv11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsv11,arbace.core4,subsl400,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core12,*print-meta*v11,arbace.core14,*print-length*l20,v11,arbace.core13,*print-level*l6,v11,arbace.core4,keysv11,arbace.core4,keepv23,arbace.repr.go.annotate4,sameR180,v11,arbace.core3,strR181,v11,arbace.core8,identityR182,v23,arbace.repr.go.annotate9,short-strv23,arbace.repr.go.annotate9,same-metav23,arbace.repr.go.annotate8,same-seqR183,R184,R185,R186,V1,nV4,R43,R187,R188,R179,V4,R43,R187,R188,R179,v23,arbace.repr.go.annotate7,line-atV3,R43,R187,R179,V3,R43,R187,R179,V2,R87,R89,v11,arbace.core7,memoizev11,arbace.core4,disjv11,arbace.core4,valsv23,arbace.repr.go.annotate14,external-test?v15,arbace.go.check14,ensure-packagev23,arbace.repr.go.annotate13,xtest-sessionv15,arbace.go.check9,check-srcV2,R87,R42,R189,V2,R87,R128,V2,R87,R128,v19,arbace.repr.go.read9,read-dumpv23,arbace.repr.go.annotate7,checkedR190,R191,R192,R193,R194,v11,arbace.core4,compv19,arbace.repr.go.read5,nodesR195,v22,arbace.repr.go.convert11,open-countsv20,arbace.repr.go.parse4,diffv20,arbace.repr.go.parse7,tree-ofR196,R197,v20,arbace.repr.go.parse7,file-atv23,arbace.repr.go.annotate12,convert-fullR198,v11,arbace.core5,classv11,arbace.core4,atomv18,arbace.repr.go.raw15,conform-packageR199,R200,v23,arbace.repr.go.annotate8,annotateR201,R202,R203,R204,R205,v11,arbace.core4,takel3,R206,v23,arbace.repr.go.annotate12,same-packageR207,R208,v18,arbace.repr.go.raw5,*res*R209,l16,v11,arbace.core11,read-stringv11,arbace.core5,slurpv11,arbace.core11,*read-eval*R210,R211,v11,arbace.core7,filtervR212,R213,v11,arbace.core10,merge-withv11,arbace.core1,+v13,arbace.string5,splitp2,\\tv13,arbace.string11,split-linesv13,arbace.string7,replaceR214,p3,/+$v23,arbace.repr.go.annotate10,spec-loadsp6,\\.edn$v19,arbace.repr.go.read10,dump-filesv23,arbace.repr.go.annotate14,helper-resultsR215,v23,arbace.repr.go.annotate13,load-sessionsv23,arbace.repr.go.annotate9,check-jobm2,R140,C29,java.util.concurrent.CallableR216,v11,arbace.core4,sortv11,arbace.core6,reduceR217,R218,R219,R220,R221,R222,R223,R224,R225,v23,arbace.repr.go.annotate12,merge-countsR226,R227,R228,R229,R230,R231,R232,R233,R234,v11,arbace.core7,printlnv11,arbace.core6,formatR235,R236,V2,R87,R42,v14,arbace.repr.go12,convert-dataR237,R238,V4,R45,R145,R239,R240,v23,arbace.repr.go.annotate8,read-jobm2,R140,C29,java.util.concurrent.CallableR239,R241,S2,s4,reads5,checkm6,R218,l1,R44,s13,tamago/gorootR237,s25,.tmp/repr-go/native-formsR242,R243,v11,arbace.core10,parse-longv20,arbace.repr.go.parse5,load!R240,v20,arbace.repr.go.parse11,forms-checkv23,arbace.repr.go.annotate9,read-specv11,arbace.core8,distinctv11,arbace.core5,doallv23,arbace.repr.go.annotate11,read-corpusR244,v23,arbace.repr.go.annotate12,check-corpusv23,arbace.repr.go.annotate18,drop-std-sessions!v11,arbace.core3,minv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core5,countv11,arbace.core4,spitv11,arbace.core3,prnR245,v11,arbace.core15,shutdown-agents")

var Lit_1 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000848")

var Lit_2 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000857")

var Lit_3 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000863")

var Lit_4 *jrt.String = jrt.Intern("the dumper generated from go/ast's forms and loaded with go/parser by goi in %.2f s")

var Lit_5 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000869")

var Lit_6 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000877")

var Lit_7 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000879")

var Lit_8 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000881")

var Lit_9 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000884")

var Lit_10 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000889__1949000893")

var Lit_11 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000931")

var Lit_12 *jrt.String = jrt.Intern("check")

var Lit_13 *jrt.String = jrt.Intern("native-check: %d corpora, %d dumps; E-tree %d equal; raw forms %d resolved, %d raw only; E-ann %d equal, %d differ, %d failed; %d not known")

var Lit_14 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000933")

var Lit_15 *jrt.String = jrt.Intern("usage: check|read [--full] [--jobs N] [--forms DIR] [--known FILE] [--out DIR] [--report FILE] SPEC...")

var Lit_16 *jrt.String = jrt.Intern("--known")

var Lit_17 *jrt.String = jrt.Intern("--report")

var Lit_18 *jrt.String = jrt.Intern("--out")

var Lit_19 *jrt.String = jrt.Intern("--forms")

var Lit_20 *jrt.String = jrt.Intern("--jobs")

var Lit_21 *jrt.String = jrt.Intern("--full")

var Lit_22 *jrt.String = jrt.Intern("%s: %d declarations, the digest's %s tamago/goroot's")

var Lit_23 *jrt.String = jrt.Intern("equal to")

var Lit_24 *jrt.String = jrt.Intern("NOT equal to")

var Lit_25 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$fn__1949000933$fn__1949000934")

var Lit_26 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000889__1949000893$fn__1949000894")

var Lit_27 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000889__1949000893$fn__1949000894$fn__1949000895")

var Lit_28 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000889__1949000893$fn__1949000894$iter__1949000913__1949000917")

var Lit_29 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000889__1949000893$fn__1949000894$fn__1949000895$iter__1949000896__1949000900")

var Lit_30 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000889__1949000893$fn__1949000894$fn__1949000895$iter__1949000896__1949000900$fn__1949000901")

var Lit_31 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000889__1949000893$fn__1949000894$fn__1949000895$iter__1949000896__1949000900$fn__1949000901$fn__1949000902")

var Lit_32 *jrt.String = jrt.Intern("read")

var Lit_33 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000889__1949000893$fn__1949000894$iter__1949000913__1949000917$fn__1949000918")

var Lit_34 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main$iter__1949000889__1949000893$fn__1949000894$iter__1949000913__1949000917$fn__1949000918$fn__1949000919")

var Lit_35 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000268__1949000272")

var Lit_36 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000306__1949000310")

var Lit_37 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$fn__1949000334")

var Lit_38 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000358__1949000362")

var Lit_39 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$fn__1949000380")

var Lit_40 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$fn__1949000334$iter__1949000335__1949000339")

var Lit_41 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$fn__1949000334$iter__1949000335__1949000339$fn__1949000340")

var Lit_42 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$fn__1949000334$iter__1949000335__1949000339$fn__1949000340$fn__1949000341")

var Lit_43 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000268__1949000272$fn__1949000273")

var Lit_44 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000268__1949000272$fn__1949000273$fn__1949000274")

var Lit_45 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000306__1949000310$fn__1949000311")

var Lit_46 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000306__1949000310$fn__1949000311$fn__1949000312")

var Lit_47 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000358__1949000362$fn__1949000363")

var Lit_48 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000358__1949000362$fn__1949000363$fn__1949000364")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000358__1949000362$fn__1949000363$fn__1949000373")

var Lit_50 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate$iter__1949000358__1949000362$fn__1949000363$fn__1949000364$fn__1949000366")

var Lit_51 *jrt.String = jrt.Intern(":")

var Lit_52 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotation$fn__1949000256")

var Lit_53 *jrt.String = jrt.Intern("arbace.repr.go.annotate$cform$fn__1949000019")

var Lit_54 *jrt.String = jrt.Intern("arbace.repr.go.annotate$cform$fn__1949000021")

var Lit_55 *jrt.String = jrt.Intern("arbace.repr.go.annotate$cform$fn__1949000024")

var Lit_56 *jrt.String = jrt.Intern("")

var Lit_57 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000534__1949000538")

var Lit_58 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000545")

var Lit_59 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000563")

var Lit_60 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000565")

var Lit_61 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000568")

var Lit_62 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000575")

var Lit_63 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000577__1949000581")

var Lit_64 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$helper_failed_QMARK___1949000597")

var Lit_65 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$known_QMARK___1949000601")

var Lit_66 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$by__1949000605")

var Lit_67 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$sum__1949000607")

var Lit_68 *jrt.String = jrt.Intern("FAIL known")

var Lit_69 *jrt.String = jrt.Intern("FAIL")

var Lit_70 *jrt.String = jrt.Intern("    ")

var Lit_71 *jrt.String = jrt.Intern("E-TREE known")

var Lit_72 *jrt.String = jrt.Intern("E-TREE")

var Lit_73 *jrt.String = jrt.Intern("RAW known")

var Lit_74 *jrt.String = jrt.Intern("RAW")

var Lit_75 *jrt.String = jrt.Intern("E-ANN FAIL known")

var Lit_76 *jrt.String = jrt.Intern("E-ANN FAIL")

var Lit_77 *jrt.String = jrt.Intern("E-ANN known")

var Lit_78 *jrt.String = jrt.Intern("E-ANN")

var Lit_79 *jrt.String = jrt.Intern("MISSING known")

var Lit_80 *jrt.String = jrt.Intern("MISSING")

var Lit_81 *jrt.String = jrt.Intern("CHECKER")

var Lit_82 *jrt.String = jrt.Intern("errors:")

var Lit_83 *jrt.String = jrt.Intern("EXTRA known")

var Lit_84 *jrt.String = jrt.Intern("EXTRA")

var Lit_85 *jrt.String = jrt.Intern("dumped natively, not by the helper")

var Lit_86 *jrt.String = jrt.Intern("%s: E-tree %d of %d dumps equal (%d files, %d nodes); raw forms %d resolved by the final ones (%d raw only: the helper's final conversion fails); E-ann %d of %d equal (%d differ, %d failed); %d failed, %d missing, %d extra (%d the helper's failures), %d rejected by both; %d not known; load %.1f s, parse %.1f s, dump %.1f s, read %.1f s, check %.1f s (CPU), %.1f s")

var Lit_87 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000651__1949000655")

var Lit_88 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000661__1949000665")

var Lit_89 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000671__1949000675")

var Lit_90 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000681__1949000685")

var Lit_91 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000691__1949000695")

var Lit_92 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000701__1949000705")

var Lit_93 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000711__1949000715")

var Lit_94 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000721__1949000725")

var Lit_95 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000735__1949000739")

var Lit_96 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000545$iter__1949000552__1949000556")

var Lit_97 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000545$iter__1949000552__1949000556$fn__1949000557")

var Lit_98 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000545$iter__1949000552__1949000556$fn__1949000557$fn__1949000558")

var Lit_99 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$fn__1949000568$fn__1949000572")

var Lit_100 *jrt.String = jrt.Intern("fail")

var Lit_101 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$helper_failed_QMARK___1949000597$fn__1949000598")

var Lit_102 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000534__1949000538$fn__1949000539")

var Lit_103 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000534__1949000538$fn__1949000539$fn__1949000540")

var Lit_104 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000577__1949000581$fn__1949000582")

var Lit_105 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000577__1949000581$fn__1949000582$fn__1949000583")

var Lit_106 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000577__1949000581$fn__1949000582$fn__1949000593")

var Lit_107 *jrt.String = jrt.Intern("the loader: ")

var Lit_108 *jrt.String = jrt.Intern(" ")

var Lit_109 *jrt.String = jrt.Intern("no such dump from the loader")

var Lit_110 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000577__1949000581$fn__1949000582$fn__1949000583$fn__1949000587")

var Lit_111 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000651__1949000655$fn__1949000656")

var Lit_112 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000651__1949000655$fn__1949000656$fn__1949000657")

var Lit_113 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000661__1949000665$fn__1949000666")

var Lit_114 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000661__1949000665$fn__1949000666$fn__1949000667")

var Lit_115 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000671__1949000675$fn__1949000676")

var Lit_116 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000671__1949000675$fn__1949000676$fn__1949000677")

var Lit_117 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000681__1949000685$fn__1949000686")

var Lit_118 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000681__1949000685$fn__1949000686$fn__1949000687")

var Lit_119 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000691__1949000695$fn__1949000696")

var Lit_120 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000691__1949000695$fn__1949000696$fn__1949000697")

var Lit_121 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000701__1949000705$fn__1949000706")

var Lit_122 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000701__1949000705$fn__1949000706$fn__1949000707")

var Lit_123 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000711__1949000715$fn__1949000716")

var Lit_124 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000711__1949000715$fn__1949000716$fn__1949000717")

var Lit_125 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000721__1949000725$fn__1949000726")

var Lit_126 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000721__1949000725$fn__1949000726$fn__1949000727")

var Lit_127 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000721__1949000725$fn__1949000726$fn__1949000731")

var Lit_128 *jrt.String = jrt.Intern("not the helper's failure")

var Lit_129 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000721__1949000725$fn__1949000726$fn__1949000727$fn__1949000728")

var Lit_130 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000735__1949000739$fn__1949000740")

var Lit_131 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$iter__1949000735__1949000739$fn__1949000740$fn__1949000741")

var Lit_132 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$known_QMARK___1949000601$fn__1949000602")

var Lit_133 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus$sum__1949000607$fn__1949000608")

var Lit_134 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$iter__1949000438__1949000442")

var Lit_135 *jrt.String = jrt.Intern("go/parser: ")

var Lit_136 *jrt.String = jrt.Intern(".edn")

var Lit_137 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$fn__1949000451")

var Lit_138 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$fn__1949000453")

var Lit_139 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$fn__1949000457")

var Lit_140 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$iter__1949000459__1949000463")

var Lit_141 *jrt.String = jrt.Intern("not checked")

var Lit_142 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$fn__1949000469")

var Lit_143 *jrt.String = jrt.Intern(": ")

var Lit_144 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$iter__1949000438__1949000442$fn__1949000443")

var Lit_145 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$iter__1949000438__1949000442$fn__1949000443$fn__1949000444")

var Lit_146 *jrt.String = jrt.Intern("/")

var Lit_147 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$iter__1949000459__1949000463$fn__1949000464")

var Lit_148 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job$iter__1949000459__1949000463$fn__1949000464$fn__1949000465")

var Lit_149 *jrt.String = jrt.Intern("arbace.repr.go.annotate$cmeta$fn__1949000013")

var Lit_150 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$id__1949000190")

var Lit_151 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000199")

var Lit_152 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$iter__1949000201__1949000207")

var Lit_153 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000217")

var Lit_154 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000220")

var Lit_155 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000227")

var Lit_156 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000229")

var Lit_157 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000232")

var Lit_158 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000238")

var Lit_159 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$fn__1949000240")

var Lit_160 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$iter__1949000201__1949000207$fn__1949000208")

var Lit_161 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$iter__1949000201__1949000207$fn__1949000208$iter__1949000203__1949000209")

var Lit_162 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$iter__1949000201__1949000207$fn__1949000208$iter__1949000203__1949000209$fn__1949000210")

var Lit_163 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of$iter__1949000201__1949000207$fn__1949000208$iter__1949000203__1949000209$fn__1949000210$fn__1949000211")

var Lit_164 *jrt.String = jrt.Intern("java.io.File")

var Lit_165 *jrt.String = jrt.Intern("java.util.HashMap")

var Lit_166 *jrt.String = jrt.Intern("java.util.concurrent.ConcurrentHashMap")

var Lit_167 *jrt.String = jrt.Intern("java.util.concurrent.Executors")

var Lit_168 *jrt.String = jrt.Intern("java.util.concurrent.TimeUnit")

var Lit_169 *jrt.String = jrt.Intern("arbace.repr.go.annotate$helper_results$iter__1949000509__1949000513")

var Lit_170 *jrt.String = jrt.Intern("arbace.repr.go.annotate$helper_results$iter__1949000509__1949000513$fn__1949000514")

var Lit_171 *jrt.String = jrt.Intern("arbace.repr.go.annotate$helper_results$iter__1949000509__1949000513$fn__1949000514$fn__1949000515")

var Lit_172 *jrt.String = jrt.Intern("arbace.repr.go.annotate$import_specs$fn__1949000034")

var Lit_173 *jrt.String = jrt.Intern("arbace.repr.go.annotate$import_specs$fn__1949000034$fn__1949000035")

var Lit_174 *jrt.String = jrt.Intern("arbace.repr.go.annotate$import_specs$fn__1949000034$fn__1949000035$fn__1949000036")

var Lit_175 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$fn__1949000083")

var Lit_176 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000085__1949000089")

var Lit_177 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$fn__1949000121")

var Lit_178 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000123__1949000127")

var Lit_179 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$fallback__1949000133")

var Lit_180 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$fn__1949000135")

var Lit_181 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$fn__1949000137")

var Lit_182 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$fn__1949000139")

var Lit_183 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000085__1949000089$fn__1949000090")

var Lit_184 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000085__1949000089$fn__1949000090$fn__1949000091")

var Lit_185 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000085__1949000089$fn__1949000090$iter__1949000109__1949000113")

var Lit_186 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000085__1949000089$fn__1949000090$fn__1949000091$iter__1949000095__1949000099")

var Lit_187 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000085__1949000089$fn__1949000090$fn__1949000091$iter__1949000095__1949000099$fn__1949000100")

var Lit_188 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000085__1949000089$fn__1949000090$fn__1949000091$iter__1949000095__1949000099$fn__1949000100$fn__1949000101")

var Lit_189 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000085__1949000089$fn__1949000090$iter__1949000109__1949000113$fn__1949000114")

var Lit_190 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000085__1949000089$fn__1949000090$iter__1949000109__1949000113$fn__1949000114$fn__1949000115")

var Lit_191 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000123__1949000127$fn__1949000128")

var Lit_192 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions$iter__1949000123__1949000127$fn__1949000128$fn__1949000129")

var Lit_193 *jrt.String = jrt.Intern("arbace.repr.go.annotate$new_session$src_of__1949000056")

var Lit_194 *jrt.String = jrt.Intern("arbace.repr.go.annotate$new_session$fn__1949000058")

var Lit_195 *jrt.String = jrt.Intern("arbace.repr.go.annotate$new_session$fn__1949000060")

var Lit_196 *jrt.String = jrt.Intern("arbace.repr.go.annotate$node_index$walk__1949000142")

var Lit_197 *jrt.String = jrt.Intern("arbace.repr.go.annotate$node_of$fn__1949000181")

var Lit_198 *jrt.String = jrt.Intern("arbace.repr.go.annotate$node_of$fn__1949000183")

var Lit_199 *jrt.String = jrt.Intern("arbace.repr.go.convert")

var Lit_200 *jrt.String = jrt.Intern("arbace.repr.go.annotate$raw_source$fn__1949000045")

var Lit_201 *jrt.String = jrt.Intern("main")

var Lit_202 *jrt.String = jrt.Intern("arbace.repr.go.annotate$raw_source$fn__1949000049")

var Lit_203 *jrt.String = jrt.Intern("arbace.repr.go.annotate$raw_source$fn__1949000045$fn__1949000046")

var Lit_204 *jrt.String = jrt.Intern("-full")

var Lit_205 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000756")

var Lit_206 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000775")

var Lit_207 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000782")

var Lit_208 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000784")

var Lit_209 *jrt.String = jrt.Intern("BAD")

var Lit_210 *jrt.String = jrt.Intern("%s: %d dumps' final forms from the checker's annotations (%d files, %.1f MB of forms), read back: %d; %d rejected by go/parser, %d failed; checker errors in %d; %.1f s")

var Lit_211 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000814")

var Lit_212 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000816__1949000820")

var Lit_213 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000826__1949000830")

var Lit_214 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000756$iter__1949000763__1949000767")

var Lit_215 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000756$iter__1949000763__1949000767$fn__1949000768")

var Lit_216 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000756$iter__1949000763__1949000767$fn__1949000768$fn__1949000769")

var Lit_217 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$fn__1949000775$fn__1949000779")

var Lit_218 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000816__1949000820$fn__1949000821")

var Lit_219 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000816__1949000820$fn__1949000821$fn__1949000822")

var Lit_220 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000826__1949000830$fn__1949000831")

var Lit_221 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus$iter__1949000826__1949000830$fn__1949000831$fn__1949000832")

var Lit_222 *jrt.String = jrt.Intern("arbace.repr.go.annotate$rebuild$fn__1949000260")

var Lit_223 *jrt.String = jrt.Intern("arbace.repr.go.annotate$rebuild$fn__1949000263")

var Lit_224 *jrt.String = jrt.Intern("arbace.repr.go.annotate$rebuild$fn__1949000265")

var Lit_225 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same$fn__1949000399")

var Lit_226 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same_meta$fn__1949000389")

var Lit_227 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same_package$fn__1949000414")

var Lit_228 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same_seq$fn__1949000393")

var Lit_229 *jrt.String = jrt.Intern("arbace.repr.go.annotate$short_str$fn__1949000386")

var Lit_230 *jrt.String = jrt.Intern("...")

var Lit_231 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000473__1949000477")

var Lit_232 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000473__1949000477$fn__1949000478")

var Lit_233 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000473__1949000477$fn__1949000478$fn__1949000479")

var Lit_234 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000473__1949000477$fn__1949000478$iter__1949000493__1949000497")

var Lit_235 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000473__1949000477$fn__1949000478$fn__1949000479$iter__1949000480__1949000484")

var Lit_236 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000473__1949000477$fn__1949000478$fn__1949000479$iter__1949000480__1949000484$fn__1949000485")

var Lit_237 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000473__1949000477$fn__1949000478$fn__1949000479$iter__1949000480__1949000484$fn__1949000485$fn__1949000486")

var Lit_238 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000473__1949000477$fn__1949000478$iter__1949000493__1949000497$fn__1949000498")

var Lit_239 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads$iter__1949000473__1949000477$fn__1949000478$iter__1949000493__1949000497$fn__1949000498$fn__1949000499")

var Lit_240 *jrt.String = jrt.Intern("/src")

var Lit_241 *jrt.String = jrt.Intern("arbace.repr.go.annotate$std_index$iter__1949000063__1949000067")

var Lit_242 *jrt.String = jrt.Intern("arbace.repr.go.annotate$std_index$iter__1949000063__1949000067$fn__1949000068")

var Lit_243 *jrt.String = jrt.Intern("arbace.repr.go.annotate$std_index$iter__1949000063__1949000067$fn__1949000068$fn__1949000069")

var Lit_244 *jrt.String = jrt.Intern("arbace.repr.go.annotate$val_shape$fn__1949000247")

var Lit_245 *jrt.String = jrt.Intern(" [")

var Lit_246 *jrt.String = jrt.Intern(".test]")

var Lit_247 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session$job_of__1949000423")

var Lit_248 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session$fn__1949000425")

var Lit_249 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session$reaches__1949000427")

var Lit_250 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session$src_of__1949000431")

var Lit_251 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session$fn__1949000433")

var Lit_252 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session$reaches__1949000427$fn__1949000428")

var Lit_253 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn1,kkn4,linekn6,columnkn4,filekn8,declaredyn1,xyn4,fileyn1,fyn2,rcyn10,import-mapyn4,loadyn1,jyn12,more-importsyn5,indexyn4,baseyn8,fallbackyn10,imports-ofyn1,pyn2,jskn8,path-poskn3,dotkn6,lbrackkn6,lparenkn4,starkn5,colonkn6,op-poskn9,value-poskn6,lbracekn3,mapkn5,beginkn4,funckn6,structkn9,interfacekn5,arrowkn8,name-posyn3,astkn3,tagyn7,HashMapyn2,pmyn2,ttyn1,Tyn1,vyn2,tykn7,typexprkn4,typekn7,builtinkn8,constantkn5,constkn7,novaluekn4,voidkn7,commaokkn8,mapindexkn8,variablekn3,varkn5,valueyn4,def?yn1,nyn1,ayn4,pathyn4,annsyn6,resultyn1,byn2,asyn2,bsyn2,xsyn2,nayn2,fbyn1,syn7,sess-ofyn1,dyn3,ctxyn6,Stringyn4,specyn2,msyn4,poolyn5,knownyn3,outyn9,positionsyn1,&yn4,argsv11,arbace.core5,in-nsMyn23,arbace.repr.go.annotatem2,R0,s1649,repr/go's annotator (doc/go/GO-PARSER-SURVEY.md GP4, §4.2 steps 3-5): goi's checker\n  (arbace.go.check) in its resolve mode over the raw forms of the native reader's dumps\n  (arbace.repr.go.raw, GP3), each open decision answered by position; the answers put into the\n  native dump as go/types' annotations, in the helper's shape (doc/go/HELPER-NOTES.md, \"Output\n  format\": :mode, :t, :use, :def, :sel, :field, :inst, :implicit, :init-order, :types'\n  :underlying, :type-table), which the converter, unchanged, turns into the final forms.\n\n  The packages are checked in dependency order, as bin/goi annotations checks them: one session\n  of the standard library per configuration (its packages from the loader, std), a corpus's own\n  packages in a session over it (a module's, cmd's, a directory test's, test variants), each\n  package's imports by the loader's resolution. Raw forms are taken in memory (GPS26 (a)), as\n  the checker reads text: literals as values, lines as :line, and each node's positions as\n  :arbace.go.check/at [file {field [line col]}], the key of its answers.\n\n  bin/repr-go native-check runs -main check: per dump E-tree (arbace.repr.go.parse), the raw\n  forms against the final ones (arbace.repr.go.raw/conform, GPS23 (c)) and E-ann: the final\n  forms the converter makes of the annotated native dump equal, form for form, metadata and\n  positions included (mode :full), to those of the helper's dump: the annotations the converter\n  reads equal go/types', types compared by the type forms they give. bin/repr-go read --reader\n  native --forms runs -main read: the final forms written as bin/repr-go read writes the helper's.m2,R0,s1649,repr/go's annotator (doc/go/GO-PARSER-SURVEY.md GP4, §4.2 steps 3-5): goi's checker\n  (arbace.go.check) in its resolve mode over the raw forms of the native reader's dumps\n  (arbace.repr.go.raw, GP3), each open decision answered by position; the answers put into the\n  native dump as go/types' annotations, in the helper's shape (doc/go/HELPER-NOTES.md, \"Output\n  format\": :mode, :t, :use, :def, :sel, :field, :inst, :implicit, :init-order, :types'\n  :underlying, :type-table), which the converter, unchanged, turns into the final forms.\n\n  The packages are checked in dependency order, as bin/goi annotations checks them: one session\n  of the standard library per configuration (its packages from the loader, std), a corpus's own\n  packages in a session over it (a module's, cmd's, a directory test's, test variants), each\n  package's imports by the loader's resolution. Raw forms are taken in memory (GPS26 (a)), as\n  the checker reads text: literals as values, lines as :line, and each node's positions as\n  :arbace.go.check/at [file {field [line col]}], the key of its answers.\n\n  bin/repr-go native-check runs -main check: per dump E-tree (arbace.repr.go.parse), the raw\n  forms against the final ones (arbace.repr.go.raw/conform, GPS23 (c)) and E-ann: the final\n  forms the converter makes of the annotated native dump equal, form for form, metadata and\n  positions included (mode :full), to those of the helper's dump: the annotations the converter\n  reads equal go/types', types compared by the type forms they give. bin/repr-go read --reader\n  native --forms runs -main read: the final forms written as bin/repr-go read writes the helper's.R1,v23,arbace.repr.go.annotate12,private-key?m10,R2,TR3,L1,V1,R4,R5,i41,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate5,cformm8,R8,TR5,i43,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate5,cmetam12,R2,TR3,L1,V2,R9,R10,R0,s84,The metadata x reads back with (its public keys, :line), and the key of its answers.R5,i45,R6,i1,R7,s26,arbace/repr/go/annotate.aem10,R3,L1,V2,R9,R10,R0,s182,The in-memory raw form x of Go file file as the checker reads it: literals as their values,\n  each list, vector and symbol with its line and its positions' key (:arbace.go.check/at).R5,i57,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate12,import-specsm12,R2,TR3,L1,V1,R11,R0,s114,A go/file form whose import specs carry their path's position (:path-pos), the key of an\n  implicit name's answer.R5,i71,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate10,raw-sourcem10,R3,L1,V2,R12,R13,R0,s207,The checker's source (arbace.go.check/check-package's) of raw conversion rc (convert-package's\n  result, raw), its imports resolved by import-map ({as written -> key}), its answers in a\n  HashMap (:answers).R5,i92,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,forms-dirv11,arbace.core4,atomm8,R5,i107,R6,i1,R7,s26,arbace/repr/go/annotate.aeR0,s50,The forms of go/parser's packages (tamago/goroot).v23,arbace.repr.go.annotate10,config-keym10,R2,TR3,L1,V1,R14,R5,i109,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate4,prepm12,R2,TR3,L1,V2,R15,R16,R0,s146,A loader job's native dump, raw conversion and checker source (import-map over the job's own),\n  or {:rejected msg} when go/parser rejects a file.R5,i113,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate11,new-sessionm12,R2,TR3,L1,V4,R17,R18,R19,R20,R0,s241,A session over index ({key job}): the checker's (arbace.go.check/session), delegating to\n  base for the keys index does not have (fallback: key -> a job, or nil), the records of the\n  keys kept (registered with keep!) for their jobs (:recs).R5,i128,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate12,std-sessionsm8,R2,TR5,i146,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,std-indexm10,R2,TR3,L1,V1,R14,R5,i148,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate11,std-sessionm10,R3,L1,V1,R14,R0,s84,The session of the standard library of load's configuration (made once per process).R5,i154,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate18,drop-std-sessions!m10,R3,L1,V0,R0,s85,Forgets the standard library's sessions (and the generic types' instances they made).R5,i164,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,std-load?m10,R2,TR3,L1,V1,R14,R5,i173,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate11,variant-keym10,R2,TR3,L1,V1,R21,R5,i176,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,job-keym12,R2,TR3,L1,V2,R14,R15,R0,s122,The key a corpus job is checked under: its package path, a test variant's p [p.test]; nil for\n  a program (checked alone).R5,i178,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate11,job-importsm12,R2,TR3,L1,V3,R14,R17,R15,R0,s148,The imports of a corpus job beyond the loader's map: an external test's package as its test\n  variant (go list -test's ImportMap) when there is one.R5,i190,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate13,load-sessionsm10,R3,L1,V2,R14,R22,R0,s164,The sessions of a corpus load's jobs: [session-of-job keyed-jobs], session-of-job giving a\n  job's session (the standard library's, the load's, a directory test's).R5,i200,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,anchorsV16,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,R35,R36,R37,R38,m10,R2,TR5,i230,R6,i1,R7,s26,arbace/repr/go/annotate.aeR0,s153,The position fields that name a node, in order, for an answer whose positions are not exactly\n  one node's (a form whose positions merge another node's).v23,arbace.repr.go.annotate10,node-indexm12,R2,TR3,L1,V1,R39,R0,s88,{[field [line col]] [node-path node]} and {positions [node-path node]} of a file's tree.R5,i236,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,node-ofm12,R2,TR3,L1,V2,V2,Myn8,by-fieldm2,R40,R41,Myn6,by-posm2,R40,R41,R42,R0,s87,The path of the node an answer's positions pm name, in index [by-field by-pos], or nil.R5,i256,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,new-tablem10,R2,TR3,L1,V0,R5,i267,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate8,type-id!m8,R8,TR5,i269,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate8,entry-ofm12,R2,TR3,L1,V2,R43,R44,R0,s66,The type table entry of checker type T, its parts' ids made first.R5,i271,R6,i1,R7,s26,arbace/repr/go/annotate.aem10,R3,L1,V2,R43,R44,R0,s78,The id of checker type T in the table tt (entered, its parts first, when new).R5,i330,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate11,float-shapem10,R2,TR3,L1,V1,R45,R5,i352,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,val-shapem10,R3,L1,V2,R45,R46,R0,s185,The helper's :val of a constant value v of checker type ty (go/constant's kind as go/types\n  computes it for the type: a float type's value a float, a complex type's a complex), or nil.R5,i357,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,mode-ofm16,R47,R48,R49,R49,R50,R51,R52,R53,R54,R54,R55,R55,R56,R57,R58,R58,m8,R2,TR5,i377,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate14,obj-annotationm12,R2,TR3,L1,V3,R43,R9,R59,R0,s111,An object (the checker's) as the helper writes it: {:kind :name [:universe] [:pkg-level]\n  [:pkg] [:t] [:val]}.R5,i381,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate10,annotationm12,R2,TR3,L1,V3,R43,R60,R61,R0,s77,The helper's annotations of node n from the answers a there (merged), or nil.R5,i397,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,rebuildm12,R2,TR3,L1,V3,R9,R62,R63,R0,s137,The tree x with metadata ann (by node path) merged into its nodes; basic literals are\n  constants, parentheses take their operand's mode.R5,i421,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate8,annotatem10,R3,L1,V3,R60,Myn7,answersm2,R40,R41,R64,R0,s262,Native dump n with the checker's answers (a HashMap, raw-source's) and package result as\n  go/types' annotations: the trees' metadata, :init-order, :types (the package's named types'\n  underlying types) and :type-table. {:dump :unplaced n-answers-not-on-a-node}.R5,i448,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,short-strm10,R2,TR3,L1,V1,R9,R5,i492,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate4,samem8,R8,TR5,i496,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,same-metam10,R2,TR3,L1,V3,R61,R65,R62,R5,i498,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate8,same-seqm10,R2,TR3,L1,V3,R66,R67,R62,R5,i505,R6,i1,R7,s26,arbace/repr/go/annotate.aem10,R3,L1,V3,R61,R65,R62,R0,s167,nil when the forms a (the native path's) and b (the helper's) are equal, metadata, positions\n  and literals' parts included; else the first difference [path what a b].R5,i510,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,line-atm12,R2,TR3,L1,V2,R68,R62,R0,s79,The Go line of the innermost form on path in forms xs (a difference's), or nil.R5,i525,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate12,same-packagem10,R3,L1,V2,R69,R70,R0,s149,nil when the conversions na (of the annotated native dump) and fb (of the helper's) are equal;\n  else the first difference [file line path what a b].R5,i537,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate14,external-test?m10,R2,TR3,L1,V2,R14,R15,R5,i553,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate13,xtest-sessionm12,R2,TR3,L1,V2,R71,R15,R0,s357,go list -test's world of external test j of a package p with in-package tests, over session s\n  (its load's): p is its test variant (p [p.test]), and the packages of the test's imports that\n  import p, directly or not, are checked anew against it (go list's recompiled q [p.test]); the\n  others are s's and the standard library's. nil when p has no variant.R5,i556,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate7,checkedm12,R2,TR3,L1,V3,R14,R72,R15,R0,s314,Corpus job j of load checked: [package record], the record prep's (its native dump, raw\n  forms, source and answers). A package is checked through its session (for its importers too);\n  a program alone; an external test alone, in its world (xtest-session); a package its session\n  checked before it was kept, anew.R5,i579,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate12,convert-fullm10,R2,TR3,L1,V2,R73,R74,R5,i598,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,check-jobm12,R2,TR3,L1,V4,R14,R72,R15,Myn4,pathm2,R40,R75,R0,s131,A corpus job's checks against the helper's dump at path (nil: none): E-tree, the raw forms'\n  conformance to the final ones, E-ann.R5,i601,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate9,read-specm10,R2,TR3,L1,V1,Myn1,fm2,R40,R75,R5,i655,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate10,spec-loadsm12,R2,TR3,L1,V1,R76,R0,s86,The loads of corpus spec: [[load jobs results] ...], jobs keyed under the load's :sub.R5,i657,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate12,merge-countsm10,R2,TR3,L1,V1,R77,R5,i666,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate14,helper-resultsm10,R2,TR3,L1,V1,Myn3,tsvm2,R40,R75,R5,i668,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate12,check-corpusm10,R2,TR3,L1,V3,R76,R78,R79,R5,i676,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate8,read-jobm12,R2,TR3,L1,V5,R14,R72,R15,R80,R81,R0,s169,The final forms of corpus job j (the checker's annotations, converted) written under out (mode\n  positions): arbace.repr.go/convert-data's result, or :rejected or :fail.R5,i755,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate11,read-corpusm10,R2,TR3,L1,V4,R76,R78,R80,R81,R5,i773,R6,i1,R7,s26,arbace/repr/go/annotate.aev23,arbace.repr.go.annotate5,-mainm10,R3,L1,V2,R82,R83,R0,s882,check [--jobs N] [--forms DIR] [--known FILE] [--report FILE] SPEC...\n  read [--full] [--jobs N] [--forms DIR] [--out DIR] [--report FILE] SPEC...\n\n  read: the final forms of each corpus SPEC's dumps (the native reader's, annotated by goi's\n  checker in its resolve mode, converted as the helper's are), written as bin/repr-go read\n  --corpus writes the helper's (mode :lines, --full :full) under --out DIR/NAME[-full], each file\n  read back. Exits 1 when a conversion fails or a file does not read back.\n\n\n  check: per dump of each corpus SPEC (arbace.repr.go.parse's specs) against the helper's dumps\n  (:dumps): E-tree, the raw forms against the final ones (conform), E-ann (the final forms of the\n  annotated native dump equal the helper's). Exits 1 on a difference or failure that the known\n  differences (a map of dump key, package path or file key to the reason) do not list.R5,i801,R6,i1,R7,s26,arbace/repr/go/annotate.ae")

var Lit_254 *jrt.String = jrt.Intern("arbace.repr.go.annotate$eval1949000004$loading__1927001464__auto____1949000005")

var Lit_255 *jrt.String = jrt.Intern("arbace.repr.go.annotate$eval1949000008$fn__1949000009")

var Lit_256 *jrt.String = jrt.Intern("arbace.repr.go.annotate$private_key_QMARK_")

var Lit_257 *jrt.String = jrt.Intern("arbace.repr.go.annotate$cmeta")

var Lit_258 *jrt.String = jrt.Intern("arbace.repr.go.annotate$cform")

var Lit_259 *jrt.String = jrt.Intern("arbace.repr.go.annotate$import_specs")

var Lit_260 *jrt.String = jrt.Intern("arbace.repr.go.annotate$raw_source")

var Lit_261 *jrt.String = jrt.Intern("tamago/goroot")

var Lit_262 *jrt.String = jrt.Intern("arbace.repr.go.annotate$config_key")

var Lit_263 *jrt.String = jrt.Intern("arbace.repr.go.annotate$prep")

var Lit_264 *jrt.String = jrt.Intern("arbace.repr.go.annotate$new_session")

var Lit_265 *jrt.String = jrt.Intern("arbace.repr.go.annotate$std_index")

var Lit_266 *jrt.String = jrt.Intern("arbace.repr.go.annotate$std_session")

var Lit_267 *jrt.String = jrt.Intern("arbace.repr.go.annotate$drop_std_sessions_BANG_")

var Lit_268 *jrt.String = jrt.Intern("arbace.repr.go.annotate$std_load_QMARK_")

var Lit_269 *jrt.String = jrt.Intern("arbace.repr.go.annotate$variant_key")

var Lit_270 *jrt.String = jrt.Intern("arbace.repr.go.annotate$job_key")

var Lit_271 *jrt.String = jrt.Intern("arbace.repr.go.annotate$job_imports")

var Lit_272 *jrt.String = jrt.Intern("arbace.repr.go.annotate$load_sessions")

var Lit_273 *jrt.String = jrt.Intern("arbace.repr.go.annotate$node_index")

var Lit_274 *jrt.String = jrt.Intern("arbace.repr.go.annotate$node_of")

var Lit_275 *jrt.String = jrt.Intern("arbace.repr.go.annotate$new_table")

var Lit_276 *jrt.String = jrt.Intern("arbace.repr.go.annotate$entry_of")

var Lit_277 *jrt.String = jrt.Intern("arbace.repr.go.annotate$type_id_BANG_")

var Lit_278 *jrt.String = jrt.Intern("arbace.repr.go.annotate$float_shape")

var Lit_279 *jrt.String = jrt.Intern("arbace.repr.go.annotate$val_shape")

var Lit_280 *jrt.String = jrt.Intern("arbace.repr.go.annotate$obj_annotation")

var Lit_281 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotation")

var Lit_282 *jrt.String = jrt.Intern("arbace.repr.go.annotate$rebuild")

var Lit_283 *jrt.String = jrt.Intern("arbace.repr.go.annotate$annotate")

var Lit_284 *jrt.String = jrt.Intern("arbace.repr.go.annotate$short_str")

var Lit_285 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same_meta")

var Lit_286 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same_seq")

var Lit_287 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same")

var Lit_288 *jrt.String = jrt.Intern("arbace.repr.go.annotate$line_at")

var Lit_289 *jrt.String = jrt.Intern("arbace.repr.go.annotate$same_package")

var Lit_290 *jrt.String = jrt.Intern("arbace.repr.go.annotate$external_test_QMARK_")

var Lit_291 *jrt.String = jrt.Intern("arbace.repr.go.annotate$xtest_session")

var Lit_292 *jrt.String = jrt.Intern("arbace.repr.go.annotate$checked")

var Lit_293 *jrt.String = jrt.Intern("arbace.repr.go.annotate$convert_full")

var Lit_294 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_job")

var Lit_295 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_spec")

var Lit_296 *jrt.String = jrt.Intern("arbace.repr.go.annotate$spec_loads")

var Lit_297 *jrt.String = jrt.Intern("arbace.repr.go.annotate$merge_counts")

var Lit_298 *jrt.String = jrt.Intern("arbace.repr.go.annotate$helper_results")

var Lit_299 *jrt.String = jrt.Intern("arbace.repr.go.annotate$check_corpus")

var Lit_300 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_job")

var Lit_301 *jrt.String = jrt.Intern("arbace.repr.go.annotate$read_corpus")

var Lit_302 *jrt.String = jrt.Intern("arbace.repr.go.annotate$_main")
