//line aot_arbace_spec_alpha_Spec.ae:1
package aot_arbace_spec_alpha

import "arbace/jrt"




type A_arbace_spec_alpha_Spec_A interface{ jrt.Object_I; Is_A_arbace_spec_alpha_Spec_A(); Conform_STAR__O__O(p0 any) any; Unform_STAR__O__O(p0 any) any; Explain_STAR__O_O_O_O__O(p0, p1, p2, p3 any) any; Gen_STAR__O_O_O__O(p0, p1, p2 any) any; With_gen_STAR__O__O(p0 any) any; Describe_STAR___O() any }

func A_arbace_spec_alpha_Spec_A_InstanceOf(x any) bool { _, ok := x.(A_arbace_spec_alpha_Spec_A); if !ok && x != nil && jrt.IsDynamic(x) { d, dyn := x.(jrt.Dynamic); if dyn { ok = d.DynImplements(A_arbace_spec_alpha_Spec_A_class) } }; return ok }

func A_arbace_spec_alpha_Spec_A_Cast(x any) A_arbace_spec_alpha_Spec_A { if x == nil { return nil }; v, ok := x.(A_arbace_spec_alpha_Spec_A); if ok && jrt.IsDynamic(x) { d, dyn := x.(jrt.Dynamic); if dyn { ok = d.DynImplements(A_arbace_spec_alpha_Spec_A_class) } }; if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_Spec_A_class)) }; return v }
