//line a2g_strings.ae:1
package aot_arbace_spec_alpha

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("exclude")

var Lit_4 *jrt.String = jrt.Intern("+")

var Lit_5 *jrt.String = jrt.Intern("*")

var Lit_6 *jrt.String = jrt.Intern("and")

var Lit_7 *jrt.String = jrt.Intern("assert")

var Lit_8 *jrt.String = jrt.Intern("or")

var Lit_9 *jrt.String = jrt.Intern("cat")

var Lit_10 *jrt.String = jrt.Intern("def")

var Lit_11 *jrt.String = jrt.Intern("keys")

var Lit_12 *jrt.String = jrt.Intern("merge")

var Lit_13 *jrt.String = jrt.Intern("arbace.walk")

var Lit_14 *jrt.String = jrt.Intern("as")

var Lit_15 *jrt.String = jrt.Intern("walk")

var Lit_16 *jrt.String = jrt.Intern("arbace.spec.gen.alpha")

var Lit_17 *jrt.String = jrt.Intern("gen")

var Lit_18 *jrt.String = jrt.Intern("arbace.string")

var Lit_19 *jrt.String = jrt.Intern("str")

var Lit_20 *jrt.String = jrt.Intern("commute")

var Lit_21 *jrt.String = jrt.Intern("deref")

var Lit_22 *jrt.String = jrt.Intern("conj")

var Lit_23 *jrt.String = jrt.Intern("arbace.spec.alpha")

var Lit_24 *jrt.String = jrt.Intern("doc")

var Lit_25 *jrt.String = jrt.Intern("The spec library specifies the structure of data or functions and provides\n  operations to validate, conform, explain, describe, and generate data based on\n  the specs.\n\n  Rationale: https://clojure.org/about/spec\n  Guide: https://clojure.org/guides/spec")

var Lit_26 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_27 *jrt.String = jrt.Intern("-cache-protocol-fn")

var Lit_28 *jrt.String = jrt.Intern("arbace.spec.alpha.Spec")

var Lit_29 *jrt.String = jrt.Intern("ident?")

var Lit_30 *jrt.String = jrt.Intern("not")

var Lit_31 *jrt.String = jrt.Intern("deep-resolve")

var Lit_32 *jrt.String = jrt.Intern("registry-ref")

var Lit_33 *jrt.String = jrt.Intern("reg-resolve")

var Lit_34 *jrt.String = jrt.Intern("op")

var Lit_35 *jrt.String = jrt.Intern("regex?")

var Lit_36 *jrt.String = jrt.Intern("assoc")

var Lit_37 *jrt.String = jrt.Intern("with-meta")

var Lit_38 *jrt.String = jrt.Intern("name")

var Lit_39 *jrt.String = jrt.Intern("spec?")

var Lit_40 *jrt.String = jrt.Intern("with-name")

var Lit_41 *jrt.String = jrt.Intern("regex-spec-impl")

var Lit_42 *jrt.String = jrt.Intern("spec-name")

var Lit_43 *jrt.String = jrt.Intern("maybe-spec")

var Lit_44 *jrt.String = jrt.Intern("arbace.spec.alpha.Specize")

var Lit_45 *jrt.String = jrt.Intern("re-matches")

var Lit_46 *jrt.String = jrt.Intern("not=")

var Lit_47 *jrt.String = jrt.Intern("symbol")

var Lit_48 *jrt.String = jrt.Intern("(.*)\\$(.*?)(__[0-9]+)?")

var Lit_49 *jrt.String = jrt.Intern("reg-resolve!")

var Lit_50 *jrt.String = jrt.Intern("specize*")

var Lit_51 *jrt.String = jrt.Intern("spec-impl")

var Lit_52 *jrt.String = jrt.Intern("ifn?")

var Lit_53 *jrt.String = jrt.Intern("fn-sym")

var Lit_54 *jrt.String = jrt.Intern("map?")

var Lit_55 *jrt.String = jrt.Intern("unknown")

var Lit_56 *jrt.String = jrt.Intern("invalid")

var Lit_57 *jrt.String = jrt.Intern("specize")

var Lit_58 *jrt.String = jrt.Intern("conform*")

var Lit_59 *jrt.String = jrt.Intern("unform*")

var Lit_60 *jrt.String = jrt.Intern("describe*")

var Lit_61 *jrt.String = jrt.Intern("seq?")

var Lit_62 *jrt.String = jrt.Intern("postwalk")

var Lit_63 *jrt.String = jrt.Intern("symbol?")

var Lit_64 *jrt.String = jrt.Intern("namespace")

var Lit_65 *jrt.String = jrt.Intern("else")

var Lit_66 *jrt.String = jrt.Intern("fn")

var Lit_67 *jrt.String = jrt.Intern("first")

var Lit_68 *jrt.String = jrt.Intern("%")

var Lit_69 *jrt.String = jrt.Intern("second")

var Lit_70 *jrt.String = jrt.Intern("last")

var Lit_71 *jrt.String = jrt.Intern("abbrev")

var Lit_72 *jrt.String = jrt.Intern("form")

var Lit_73 *jrt.String = jrt.Intern("with-gen*")

var Lit_74 *jrt.String = jrt.Intern("gfn")

var Lit_75 *jrt.String = jrt.Intern("explain*")

var Lit_76 *jrt.String = jrt.Intern("empty?")

var Lit_77 *jrt.String = jrt.Intern("problems")

var Lit_78 *jrt.String = jrt.Intern("spec")

var Lit_79 *jrt.String = jrt.Intern("value")

var Lit_80 *jrt.String = jrt.Intern("explain-data*")

var Lit_81 *jrt.String = jrt.Intern("sort-by")

var Lit_82 *jrt.String = jrt.Intern("seq")

var Lit_83 *jrt.String = jrt.Intern("next")

var Lit_84 *jrt.String = jrt.Intern("to-array")

var Lit_85 *jrt.String = jrt.Intern("path")

var Lit_86 *jrt.String = jrt.Intern("pred")

var Lit_87 *jrt.String = jrt.Intern("val")

var Lit_88 *jrt.String = jrt.Intern("reason")

var Lit_89 *jrt.String = jrt.Intern("via")

var Lit_90 *jrt.String = jrt.Intern("in")

var Lit_91 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_92 *jrt.String = jrt.Intern("chunk-first")

var Lit_93 *jrt.String = jrt.Intern("println")

var Lit_94 *jrt.String = jrt.Intern("newline")

var Lit_95 *jrt.String = jrt.Intern("pr")

var Lit_96 *jrt.String = jrt.Intern("print")

var Lit_97 *jrt.String = jrt.Intern("pr-str")

var Lit_98 *jrt.String = jrt.Intern("chunk-rest")

var Lit_99 *jrt.String = jrt.Intern("*explain-out*")

var Lit_100 *jrt.String = jrt.Intern("explain-out")

var Lit_101 *jrt.String = jrt.Intern("explain-data")

var Lit_102 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_103 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_104 *jrt.String = jrt.Intern("hash-map")

var Lit_105 *jrt.String = jrt.Intern("*out*")

var Lit_106 *jrt.String = jrt.Intern("explain")

var Lit_107 *jrt.String = jrt.Intern("gen*")

var Lit_108 *jrt.String = jrt.Intern("such-that")

var Lit_109 *jrt.String = jrt.Intern("ex-info")

var Lit_110 *jrt.String = jrt.Intern("valid?")

var Lit_111 *jrt.String = jrt.Intern("failure")

var Lit_112 *jrt.String = jrt.Intern("no-gen")

var Lit_113 *jrt.String = jrt.Intern("gensub")

var Lit_114 *jrt.String = jrt.Intern("recursion-limit")

var Lit_115 *jrt.String = jrt.Intern("*recursion-limit*")

var Lit_116 *jrt.String = jrt.Intern("var?")

var Lit_117 *jrt.String = jrt.Intern("rest")

var Lit_118 *jrt.String = jrt.Intern("postwalk-replace")

var Lit_119 *jrt.String = jrt.Intern("keyword?")

var Lit_120 *jrt.String = jrt.Intern("->sym")

var Lit_121 *jrt.String = jrt.Intern("sequential?")

var Lit_122 *jrt.String = jrt.Intern("resolve")

var Lit_123 *jrt.String = jrt.Intern("res")

var Lit_124 *jrt.String = jrt.Intern("unfn")

var Lit_125 *jrt.String = jrt.Intern("swap!")

var Lit_126 *jrt.String = jrt.Intern("c")

var Lit_127 *jrt.String = jrt.Intern("k")

var Lit_128 *jrt.String = jrt.Intern("line")

var Lit_129 *jrt.String = jrt.Intern("column")

var Lit_130 *jrt.String = jrt.Intern("dissoc")

var Lit_131 *jrt.String = jrt.Intern("ns-aliases")

var Lit_132 *jrt.String = jrt.Intern("*ns*")

var Lit_133 *jrt.String = jrt.Intern("ns-qualify")

var Lit_134 *jrt.String = jrt.Intern("concat")

var Lit_135 *jrt.String = jrt.Intern("list")

var Lit_136 *jrt.String = jrt.Intern("def-impl")

var Lit_137 *jrt.String = jrt.Intern("quote")

var Lit_138 *jrt.String = jrt.Intern("registry")

var Lit_139 *jrt.String = jrt.Intern("multi-spec-impl")

var Lit_140 *jrt.String = jrt.Intern("var")

var Lit_141 *jrt.String = jrt.Intern("req")

var Lit_142 *jrt.String = jrt.Intern("req-un")

var Lit_143 *jrt.String = jrt.Intern("opt")

var Lit_144 *jrt.String = jrt.Intern("opt-un")

var Lit_145 *jrt.String = jrt.Intern("keyword")

var Lit_146 *jrt.String = jrt.Intern("filterv")

var Lit_147 *jrt.String = jrt.Intern("every?")

var Lit_148 *jrt.String = jrt.Intern("into")

var Lit_149 *jrt.String = jrt.Intern("gensym")

var Lit_150 *jrt.String = jrt.Intern("map")

var Lit_151 *jrt.String = jrt.Intern("contains?")

var Lit_152 *jrt.String = jrt.Intern("mapv")

var Lit_153 *jrt.String = jrt.Intern("flatten")

var Lit_154 *jrt.String = jrt.Intern("fn*")

var Lit_155 *jrt.String = jrt.Intern("p1__1740000257#")

var Lit_156 *jrt.String = jrt.Intern("req-keys")

var Lit_157 *jrt.String = jrt.Intern("req-un-specs")

var Lit_158 *jrt.String = jrt.Intern("vec")

var Lit_159 *jrt.String = jrt.Intern("identity")

var Lit_160 *jrt.String = jrt.Intern("apply")

var Lit_161 *jrt.String = jrt.Intern("vector")

var Lit_162 *jrt.String = jrt.Intern("map-spec-impl")

var Lit_163 *jrt.String = jrt.Intern("req-specs")

var Lit_164 *jrt.String = jrt.Intern("opt-keys")

var Lit_165 *jrt.String = jrt.Intern("opt-specs")

var Lit_166 *jrt.String = jrt.Intern("pred-forms")

var Lit_167 *jrt.String = jrt.Intern("pred-exprs")

var Lit_168 *jrt.String = jrt.Intern("keys-pred")

var Lit_169 *jrt.String = jrt.Intern("partition")

var Lit_170 *jrt.String = jrt.Intern("even?")

var Lit_171 *jrt.String = jrt.Intern("count")

var Lit_172 *jrt.String = jrt.Intern("key-pred-forms")

var Lit_173 *jrt.String = jrt.Intern("or-spec-impl")

var Lit_174 *jrt.String = jrt.Intern("and-spec-impl")

var Lit_175 *jrt.String = jrt.Intern("merge-spec-impl")

var Lit_176 *jrt.String = jrt.Intern("kind")

var Lit_177 *jrt.String = jrt.Intern("mapcat")

var Lit_178 *jrt.String = jrt.Intern("max-count")

var Lit_179 *jrt.String = jrt.Intern("min-count")

var Lit_180 *jrt.String = jrt.Intern("distinct")

var Lit_181 *jrt.String = jrt.Intern("gen-max")

var Lit_182 *jrt.String = jrt.Intern("describe")

var Lit_183 *jrt.String = jrt.Intern("kind-form")

var Lit_184 *jrt.String = jrt.Intern("res-kind")

var Lit_185 *jrt.String = jrt.Intern("every")

var Lit_186 *jrt.String = jrt.Intern("coll?")

var Lit_187 *jrt.String = jrt.Intern("=")

var Lit_188 *jrt.String = jrt.Intern("bounded-count")

var Lit_189 *jrt.String = jrt.Intern("<=")

var Lit_190 *jrt.String = jrt.Intern("if")

var Lit_191 *jrt.String = jrt.Intern("inc")

var Lit_192 *jrt.String = jrt.Intern("java.lang.Integer")

var Lit_193 *jrt.String = jrt.Intern("MAX_VALUE")

var Lit_194 *jrt.String = jrt.Intern("distinct?")

var Lit_195 *jrt.String = jrt.Intern("every-impl")

var Lit_196 *jrt.String = jrt.Intern("cpred")

var Lit_197 *jrt.String = jrt.Intern("every-kv")

var Lit_198 *jrt.String = jrt.Intern("tuple")

var Lit_199 *jrt.String = jrt.Intern("kfn")

var Lit_200 *jrt.String = jrt.Intern("i__1740000305__auto__")

var Lit_201 *jrt.String = jrt.Intern("v__1740000306__auto__")

var Lit_202 *jrt.String = jrt.Intern("nth")

var Lit_203 *jrt.String = jrt.Intern("coll-of")

var Lit_204 *jrt.String = jrt.Intern("conform-all")

var Lit_205 *jrt.String = jrt.Intern("map-of")

var Lit_206 *jrt.String = jrt.Intern("rep-impl")

var Lit_207 *jrt.String = jrt.Intern("rep+impl")

var Lit_208 *jrt.String = jrt.Intern("maybe-impl")

var Lit_209 *jrt.String = jrt.Intern("alt-impl")

var Lit_210 *jrt.String = jrt.Intern("cat-impl")

var Lit_211 *jrt.String = jrt.Intern("amp-impl")

var Lit_212 *jrt.String = jrt.Intern("conformer")

var Lit_213 *jrt.String = jrt.Intern("any?")

var Lit_214 *jrt.String = jrt.Intern("args")

var Lit_215 *jrt.String = jrt.Intern("ret")

var Lit_216 *jrt.String = jrt.Intern("fspec-impl")

var Lit_217 *jrt.String = jrt.Intern("preds")

var Lit_218 *jrt.String = jrt.Intern("tuple-impl")

var Lit_219 *jrt.String = jrt.Intern("get-spec")

var Lit_220 *jrt.String = jrt.Intern("invalid?")

var Lit_221 *jrt.String = jrt.Intern("conform")

var Lit_222 *jrt.String = jrt.Intern("fspec")

var Lit_223 *jrt.String = jrt.Intern("set")

var Lit_224 *jrt.String = jrt.Intern("the-spec")

var Lit_225 *jrt.String = jrt.Intern("dt")

var Lit_226 *jrt.String = jrt.Intern("return")

var Lit_227 *jrt.String = jrt.Intern("or-k-gen")

var Lit_228 *jrt.String = jrt.Intern("and-k-gen")

var Lit_229 *jrt.String = jrt.Intern("bind")

var Lit_230 *jrt.String = jrt.Intern("take")

var Lit_231 *jrt.String = jrt.Intern("choose")

var Lit_232 *jrt.String = jrt.Intern("shuffle")

var Lit_233 *jrt.String = jrt.Intern("k-gen")

var Lit_234 *jrt.String = jrt.Intern("zipmap")

var Lit_235 *jrt.String = jrt.Intern("cons")

var Lit_236 *jrt.String = jrt.Intern("inck")

var Lit_237 *jrt.String = jrt.Intern("recur-limit?")

var Lit_238 *jrt.String = jrt.Intern("delay-impl")

var Lit_239 *jrt.String = jrt.Intern("remove")

var Lit_240 *jrt.String = jrt.Intern("nil?")

var Lit_241 *jrt.String = jrt.Intern("comp")

var Lit_242 *jrt.String = jrt.Intern("filter")

var Lit_243 *jrt.String = jrt.Intern("keep")

var Lit_244 *jrt.String = jrt.Intern("pvalid?")

var Lit_245 *jrt.String = jrt.Intern("explain-1")

var Lit_246 *jrt.String = jrt.Intern("unform")

var Lit_247 *jrt.String = jrt.Intern("with-gen")

var Lit_248 *jrt.String = jrt.Intern("gen-for-pred")

var Lit_249 *jrt.String = jrt.Intern("multi-spec")

var Lit_250 *jrt.String = jrt.Intern("fmap")

var Lit_251 *jrt.String = jrt.Intern("method")

var Lit_252 *jrt.String = jrt.Intern("one-of")

var Lit_253 *jrt.String = jrt.Intern("methods")

var Lit_254 *jrt.String = jrt.Intern("range")

var Lit_255 *jrt.String = jrt.Intern("vector?")

var Lit_256 *jrt.String = jrt.Intern("x")

var Lit_257 *jrt.String = jrt.Intern("tagged-ret")

var Lit_258 *jrt.String = jrt.Intern("explain-pred-list")

var Lit_259 *jrt.String = jrt.Intern("reduce")

var Lit_260 *jrt.String = jrt.Intern("reverse")

var Lit_261 *jrt.String = jrt.Intern("some")

var Lit_262 *jrt.String = jrt.Intern("Integer")

var Lit_263 *jrt.String = jrt.Intern("conform-keys")

var Lit_264 *jrt.String = jrt.Intern("empty")

var Lit_265 *jrt.String = jrt.Intern("empty-coll")

var Lit_266 *jrt.String = jrt.Intern("list?")

var Lit_267 *jrt.String = jrt.Intern("constantly")

var Lit_268 *jrt.String = jrt.Intern("vector-distinct")

var Lit_269 *jrt.String = jrt.Intern("num-elements")

var Lit_270 *jrt.String = jrt.Intern("max-tries")

var Lit_271 *jrt.String = jrt.Intern("min-elements")

var Lit_272 *jrt.String = jrt.Intern("max-elements")

var Lit_273 *jrt.String = jrt.Intern("coll-prob")

var Lit_274 *jrt.String = jrt.Intern("partial")

var Lit_275 *jrt.String = jrt.Intern("*coll-error-limit*")

var Lit_276 *jrt.String = jrt.Intern("indexed?")

var Lit_277 *jrt.String = jrt.Intern("*coll-check-limit*")

var Lit_278 *jrt.String = jrt.Intern("accept")

var Lit_279 *jrt.String = jrt.Intern("ps")

var Lit_280 *jrt.String = jrt.Intern("ks")

var Lit_281 *jrt.String = jrt.Intern("forms")

var Lit_282 *jrt.String = jrt.Intern("rep+")

var Lit_283 *jrt.String = jrt.Intern("accept?")

var Lit_284 *jrt.String = jrt.Intern("pcat*")

var Lit_285 *jrt.String = jrt.Intern("pcat")

var Lit_286 *jrt.String = jrt.Intern("rep")

var Lit_287 *jrt.String = jrt.Intern("p2")

var Lit_288 *jrt.String = jrt.Intern("splice")

var Lit_289 *jrt.String = jrt.Intern("id")

var Lit_290 *jrt.String = jrt.Intern("p1")

var Lit_291 *jrt.String = jrt.Intern("rep*")

var Lit_292 *jrt.String = jrt.Intern("amp")

var Lit_293 *jrt.String = jrt.Intern("repeat")

var Lit_294 *jrt.String = jrt.Intern("filter-alt")

var Lit_295 *jrt.String = jrt.Intern("alt")

var Lit_296 *jrt.String = jrt.Intern("alt*")

var Lit_297 *jrt.String = jrt.Intern("alts")

var Lit_298 *jrt.String = jrt.Intern("maybe")

var Lit_299 *jrt.String = jrt.Intern("nil")

var Lit_300 *jrt.String = jrt.Intern("accept-nil?")

var Lit_301 *jrt.String = jrt.Intern("and-preds")

var Lit_302 *jrt.String = jrt.Intern("preturn")

var Lit_303 *jrt.String = jrt.Intern("noret?")

var Lit_304 *jrt.String = jrt.Intern("add-ret")

var Lit_305 *jrt.String = jrt.Intern("op-unform")

var Lit_306 *jrt.String = jrt.Intern("deriv")

var Lit_307 *jrt.String = jrt.Intern("alt2")

var Lit_308 *jrt.String = jrt.Intern("list*")

var Lit_309 *jrt.String = jrt.Intern("&")

var Lit_310 *jrt.String = jrt.Intern("_")

var Lit_311 *jrt.String = jrt.Intern("?")

var Lit_312 *jrt.String = jrt.Intern("op-explain")

var Lit_313 *jrt.String = jrt.Intern("op-describe")

var Lit_314 *jrt.String = jrt.Intern("re-gen")

var Lit_315 *jrt.String = jrt.Intern("re-explain")

var Lit_316 *jrt.String = jrt.Intern("p1__1740000844__1740000845__auto__")

var Lit_317 *jrt.String = jrt.Intern("re-conform")

var Lit_318 *jrt.String = jrt.Intern("for-all*")

var Lit_319 *jrt.String = jrt.Intern("quick-check")

var Lit_320 *jrt.String = jrt.Intern("smallest")

var Lit_321 *jrt.String = jrt.Intern("shrunk")

var Lit_322 *jrt.String = jrt.Intern("call-valid?")

var Lit_323 *jrt.String = jrt.Intern("generate")

var Lit_324 *jrt.String = jrt.Intern("argspec")

var Lit_325 *jrt.String = jrt.Intern("validate-fn")

var Lit_326 *jrt.String = jrt.Intern("*fspec-iterations*")

var Lit_327 *jrt.String = jrt.Intern("v")

var Lit_328 *jrt.String = jrt.Intern("let")

var Lit_329 *jrt.String = jrt.Intern("mspec__1740000878__auto__")

var Lit_330 *jrt.String = jrt.Intern("kvs->map")

var Lit_331 *jrt.String = jrt.Intern("m__1740000879__auto__")

var Lit_332 *jrt.String = jrt.Intern("nonconforming")

var Lit_333 *jrt.String = jrt.Intern("nilable")

var Lit_334 *jrt.String = jrt.Intern("nilable-impl")

var Lit_335 *jrt.String = jrt.Intern("frequency")

var Lit_336 *jrt.String = jrt.Intern("sample")

var Lit_337 *jrt.String = jrt.Intern("exercise")

var Lit_338 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_339 *jrt.String = jrt.Intern("chunk-append")

var Lit_340 *jrt.String = jrt.Intern("chunk-cons")

var Lit_341 *jrt.String = jrt.Intern("chunk")

var Lit_342 *jrt.String = jrt.Intern("exercise-fn")

var Lit_343 *jrt.String = jrt.Intern("inst?")

var Lit_344 *jrt.String = jrt.Intern("inst-ms")

var Lit_345 *jrt.String = jrt.Intern("st__1740000921__auto__")

var Lit_346 *jrt.String = jrt.Intern("et__1740000922__auto__")

var Lit_347 *jrt.String = jrt.Intern("mkdate__1740000923__auto__")

var Lit_348 *jrt.String = jrt.Intern("d__1740000924__auto__")

var Lit_349 *jrt.String = jrt.Intern("java.util.Date.")

var Lit_350 *jrt.String = jrt.Intern("tag")

var Lit_351 *jrt.String = jrt.Intern("long")

var Lit_352 *jrt.String = jrt.Intern("p1__1740000920__1740000925__auto__")

var Lit_353 *jrt.String = jrt.Intern("inst-in-range?")

var Lit_354 *jrt.String = jrt.Intern("large-integer*")

var Lit_355 *jrt.String = jrt.Intern("min")

var Lit_356 *jrt.String = jrt.Intern("max")

var Lit_357 *jrt.String = jrt.Intern("int?")

var Lit_358 *jrt.String = jrt.Intern("p1__1740000932__1740000933__auto__")

var Lit_359 *jrt.String = jrt.Intern("int-in-range?")

var Lit_360 *jrt.String = jrt.Intern("dec")

var Lit_361 *jrt.String = jrt.Intern("infinite?")

var Lit_362 *jrt.String = jrt.Intern("NaN?")

var Lit_363 *jrt.String = jrt.Intern("p1__1740000939#")

var Lit_364 *jrt.String = jrt.Intern("Double")

var Lit_365 *jrt.String = jrt.Intern("isInfinite")

var Lit_366 *jrt.String = jrt.Intern("p1__1740000940#")

var Lit_367 *jrt.String = jrt.Intern("isNaN")

var Lit_368 *jrt.String = jrt.Intern("double?")

var Lit_369 *jrt.String = jrt.Intern("p1__1740000941__1740000942__auto__")

var Lit_370 *jrt.String = jrt.Intern("p1__1740000943__1740000944__auto__")

var Lit_371 *jrt.String = jrt.Intern("double*")

var Lit_372 *jrt.String = jrt.Intern("assertion-failed")

var Lit_373 *jrt.String = jrt.Intern("*compile-asserts*")

var Lit_374 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_375 *jrt.String = jrt.Intern("checkSpecAsserts")

var Lit_376 *jrt.String = jrt.Intern("assert*")

var Lit_377 *jrt.String = jrt.Intern("arbace.spec.alpha$_AMPERSAND_")

var Lit_378 *jrt.String = jrt.Intern("arbace.spec.alpha$_PLUS_")

var Lit_379 *jrt.String = jrt.Intern("arbace.spec.alpha$_QMARK_")

var Lit_380 *jrt.String = jrt.Intern("arbace.spec.alpha$_STAR_")

var Lit_381 *jrt.String = jrt.Intern("arbace.spec.alpha$__GT_sym")

var Lit_382 *jrt.String = jrt.Intern("arbace.spec.alpha$abbrev")

var Lit_383 *jrt.String = jrt.Intern("arbace.spec.alpha$abbrev$fn__1740000170")

var Lit_384 *jrt.String = jrt.Intern("arbace.spec.alpha$accept")

var Lit_385 *jrt.String = jrt.Intern("arbace.spec.alpha$accept_QMARK_")

var Lit_386 *jrt.String = jrt.Intern("arbace.spec.alpha$accept_nil_QMARK_")

var Lit_387 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_388 *jrt.String = jrt.Intern("arbace.spec.alpha$add_ret")

var Lit_389 *jrt.String = jrt.Intern("arbace.spec.alpha$add_ret$prop__1740000773")

var Lit_390 *jrt.String = jrt.Intern("arbace.spec.alpha$alt")

var Lit_391 *jrt.String = jrt.Intern("Assert failed: ")

var Lit_392 *jrt.String = jrt.Intern("alt expects k1 p1 k2 p2..., where ks are keywords")

var Lit_393 *jrt.String = jrt.Intern("\n")

var Lit_394 *jrt.String = jrt.Intern("arbace.spec.alpha$alt2")

var Lit_395 *jrt.String = jrt.Intern("arbace.spec.alpha$alt_STAR_")

var Lit_396 *jrt.String = jrt.Intern("arbace.spec.alpha$alt_impl")

var Lit_397 *jrt.String = jrt.Intern("arbace.spec.alpha$alts")

var Lit_398 *jrt.String = jrt.Intern("arbace.spec.alpha$amp_impl")

var Lit_399 *jrt.String = jrt.Intern("arbace.spec.alpha$and")

var Lit_400 *jrt.String = jrt.Intern("arbace.spec.alpha$and_k_gen")

var Lit_401 *jrt.String = jrt.Intern("arbace.spec.alpha$and_preds")

var Lit_402 *jrt.String = jrt.Intern("arbace.spec.alpha$and_spec_impl")

var Lit_403 *jrt.String = jrt.Intern("arbace.spec.alpha$and_spec_impl$fn__1740000569")

var Lit_404 *jrt.String = jrt.Intern("arbace.spec.alpha$and_spec_impl$fn__1740000572")

var Lit_405 *jrt.String = jrt.Intern("arbace.spec.alpha$and_spec_impl$fn__1740000574")

var Lit_406 *jrt.String = jrt.Intern("arbace.spec.alpha$and_spec_impl$fn__1740000576")

var Lit_407 *jrt.String = jrt.Intern("arbace.spec.alpha$and_spec_impl$reify__1740000578$fn__1740000579")

var Lit_408 *jrt.String = jrt.Intern("arbace.spec.alpha$assert")

var Lit_409 *jrt.String = jrt.Intern("arbace.spec.alpha$assert_STAR_")

var Lit_410 *jrt.String = jrt.Intern("Spec assertion failed\n")

var Lit_411 *jrt.String = jrt.Intern("arbace.spec.alpha$assert_STAR_$fn__1740000960")

var Lit_412 *jrt.String = jrt.Intern("arbace.spec.alpha$call_valid_QMARK_")

var Lit_413 *jrt.String = jrt.Intern("arbace.spec.alpha$cat")

var Lit_414 *jrt.String = jrt.Intern("cat expects k1 p1 k2 p2..., where ks are keywords")

var Lit_415 *jrt.String = jrt.Intern("arbace.spec.alpha$cat_impl")

var Lit_416 *jrt.String = jrt.Intern("arbace.spec.alpha$check_asserts")

var Lit_417 *jrt.String = jrt.Intern("arbace.spec.alpha$check_asserts_QMARK_")

var Lit_418 *jrt.String = jrt.Intern("arbace.spec.alpha$coll_of")

var Lit_419 *jrt.String = jrt.Intern("arbace.spec.alpha$coll_prob")

var Lit_420 *jrt.String = jrt.Intern("arbace.spec.alpha$conform")

var Lit_421 *jrt.String = jrt.Intern("arbace.spec.alpha$conformer")

var Lit_422 *jrt.String = jrt.Intern("arbace.spec.alpha$deep_resolve")

var Lit_423 *jrt.String = jrt.Intern("arbace.spec.alpha$def")

var Lit_424 *jrt.String = jrt.Intern("arbace.spec.alpha$def_impl")

var Lit_425 *jrt.String = jrt.Intern("k must be namespaced keyword or resolvable symbol")

var Lit_426 *jrt.String = jrt.Intern("arbace.spec.alpha$deriv")

var Lit_427 *jrt.String = jrt.Intern("arbace.spec.alpha$deriv$fn__1740000787")

var Lit_428 *jrt.String = jrt.Intern("arbace.spec.alpha$describe")

var Lit_429 *jrt.String = jrt.Intern("arbace.spec.alpha$double_in")

var Lit_430 *jrt.String = jrt.Intern("arbace.spec.alpha$dt")

var Lit_431 *jrt.String = jrt.Intern(" is not a fn, expected predicate fn")

var Lit_432 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000004$loading__1927001464__auto____1740000005")

var Lit_433 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000008$fn__1740000009")

var Lit_434 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000035")

var Lit_435 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000035$G__1740000020__1740000048")

var Lit_436 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000035$G__1740000021__1740000041")

var Lit_437 *jrt.String = jrt.Intern("explain_STAR_")

var Lit_438 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000051")

var Lit_439 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000051$G__1740000024__1740000058")

var Lit_440 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000051$G__1740000025__1740000054")

var Lit_441 *jrt.String = jrt.Intern("with_gen_STAR_")

var Lit_442 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000061")

var Lit_443 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000061$G__1740000022__1740000072")

var Lit_444 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000061$G__1740000023__1740000066")

var Lit_445 *jrt.String = jrt.Intern("gen_STAR_")

var Lit_446 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000075")

var Lit_447 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000075$G__1740000016__1740000082")

var Lit_448 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000075$G__1740000017__1740000078")

var Lit_449 *jrt.String = jrt.Intern("conform_STAR_")

var Lit_450 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000085")

var Lit_451 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000085$G__1740000026__1740000090")

var Lit_452 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000085$G__1740000027__1740000087")

var Lit_453 *jrt.String = jrt.Intern("describe_STAR_")

var Lit_454 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000093")

var Lit_455 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000093$G__1740000018__1740000100")

var Lit_456 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000093$G__1740000019__1740000096")

var Lit_457 *jrt.String = jrt.Intern("unform_STAR_")

var Lit_458 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000127$fn__1740000128")

var Lit_459 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000127$fn__1740000128$G__1740000119__1740000137")

var Lit_460 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000127$fn__1740000128$G__1740000120__1740000132")

var Lit_461 *jrt.String = jrt.Intern("specize_STAR_")

var Lit_462 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000149$fn__1740000150")

var Lit_463 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000153$fn__1740000154")

var Lit_464 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000157$fn__1740000158")

var Lit_465 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000161$fn__1740000162")

var Lit_466 *jrt.String = jrt.Intern("arbace.spec.alpha$every")

var Lit_467 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl")

var Lit_468 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$addcv__1740000620")

var Lit_469 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$cfns__1740000622")

var Lit_470 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$cfns__1740000622$fn__1740000623")

var Lit_471 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$cfns__1740000622$fn__1740000625")

var Lit_472 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$cfns__1740000622$fn__1740000627")

var Lit_473 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$check_QMARK___1740000616")

var Lit_474 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$fn__1740000614")

var Lit_475 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$fn__1740000618")

var Lit_476 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$reify__1740000630$fn__1740000667")

var Lit_477 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$reify__1740000630$fn__1740000669")

var Lit_478 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$reify__1740000630$fn__1740000671")

var Lit_479 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$reify__1740000630$fn__1740000671$fn__1740000672")

var Lit_480 *jrt.String = jrt.Intern("arbace.spec.alpha$every_kv")

var Lit_481 *jrt.String = jrt.Intern("arbace.spec.alpha$exercise")

var Lit_482 *jrt.String = jrt.Intern("arbace.spec.alpha$exercise$fn__1740000905")

var Lit_483 *jrt.String = jrt.Intern("arbace.spec.alpha$exercise_fn")

var Lit_484 *jrt.String = jrt.Intern("No :args spec found, can't generate")

var Lit_485 *jrt.String = jrt.Intern("arbace.spec.alpha$exercise_fn$iter__1740000908__1740000912")

var Lit_486 *jrt.String = jrt.Intern("arbace.spec.alpha$exercise_fn$iter__1740000908__1740000912$fn__1740000913")

var Lit_487 *jrt.String = jrt.Intern("arbace.spec.alpha$exercise_fn$iter__1740000908__1740000912$fn__1740000913$fn__1740000914")

var Lit_488 *jrt.String = jrt.Intern("arbace.spec.alpha$explain")

var Lit_489 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_1")

var Lit_490 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_data")

var Lit_491 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_data_STAR_")

var Lit_492 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_out")

var Lit_493 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_pred_list")

var Lit_494 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_printer")

var Lit_495 *jrt.String = jrt.Intern(" - failed: ")

var Lit_496 *jrt.String = jrt.Intern(" in: ")

var Lit_497 *jrt.String = jrt.Intern(" at: ")

var Lit_498 *jrt.String = jrt.Intern(" spec: ")

var Lit_499 *jrt.String = jrt.Intern("\n\t")

var Lit_500 *jrt.String = jrt.Intern(" ")

var Lit_501 *jrt.String = jrt.Intern("Success!")

var Lit_502 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_printer$fn__1740000179")

var Lit_503 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_printer$fn__1740000181")

var Lit_504 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_str")

var Lit_505 *jrt.String = jrt.Intern("arbace.spec.alpha$fdef")

var Lit_506 *jrt.String = jrt.Intern("arbace.spec.alpha$filter_alt")

var Lit_507 *jrt.String = jrt.Intern("arbace.spec.alpha$filter_alt$fn__1740000703")

var Lit_508 *jrt.String = jrt.Intern("arbace.spec.alpha$filter_alt$fn__1740000705")

var Lit_509 *jrt.String = jrt.Intern("arbace.spec.alpha$fn__1740000868")

var Lit_510 *jrt.String = jrt.Intern("arbace.spec.alpha$fn__1740000870")

var Lit_511 *jrt.String = jrt.Intern("arbace.spec.alpha$fn__1740000870$fn__1740000872")

var Lit_512 *jrt.String = jrt.Intern("arbace.spec.alpha$fn_sym")

var Lit_513 *jrt.String = jrt.Intern("arbace.spec.alpha$form")

var Lit_514 *jrt.String = jrt.Intern("arbace.spec.alpha$fspec")

var Lit_515 *jrt.String = jrt.Intern("arbace.spec.alpha$fspec_impl")

var Lit_516 *jrt.String = jrt.Intern("Can't conform fspec without args spec: ")

var Lit_517 *jrt.String = jrt.Intern("arbace.spec.alpha$fspec_impl$reify__1740000857$fn__1740000858")

var Lit_518 *jrt.String = jrt.Intern("arbace.spec.alpha$fspec_impl$reify__1740000857$fn__1740000860")

var Lit_519 *jrt.String = jrt.Intern("arbace.spec.alpha$fspec_impl$reify__1740000857$fn__1740000860$fn__1740000861")

var Lit_520 *jrt.String = jrt.Intern("arbace.spec.alpha$gen")

var Lit_521 *jrt.String = jrt.Intern("arbace.spec.alpha$gensub")

var Lit_522 *jrt.String = jrt.Intern("Unable to construct gen at: ")

var Lit_523 *jrt.String = jrt.Intern(" for: ")

var Lit_524 *jrt.String = jrt.Intern("arbace.spec.alpha$gensub$fn__1740000216")

var Lit_525 *jrt.String = jrt.Intern("arbace.spec.alpha$get_spec")

var Lit_526 *jrt.String = jrt.Intern("arbace.spec.alpha$inck")

var Lit_527 *jrt.String = jrt.Intern("arbace.spec.alpha$inst_in")

var Lit_528 *jrt.String = jrt.Intern("arbace.spec.alpha$inst_in_range_QMARK_")

var Lit_529 *jrt.String = jrt.Intern("arbace.spec.alpha$int_in")

var Lit_530 *jrt.String = jrt.Intern("arbace.spec.alpha$int_in_range_QMARK_")

var Lit_531 *jrt.String = jrt.Intern("arbace.spec.alpha$invalid_QMARK_")

var Lit_532 *jrt.String = jrt.Intern("arbace.spec.alpha$k_gen")

var Lit_533 *jrt.String = jrt.Intern("arbace.spec.alpha$keys")

var Lit_534 *jrt.String = jrt.Intern("all keys must be namespace-qualified keywords")

var Lit_535 *jrt.String = jrt.Intern("arbace.spec.alpha$keys$fn__1740000263")

var Lit_536 *jrt.String = jrt.Intern("arbace.spec.alpha$keys$fn__1740000271")

var Lit_537 *jrt.String = jrt.Intern("arbace.spec.alpha$keys$parse_req__1740000265")

var Lit_538 *jrt.String = jrt.Intern("arbace.spec.alpha$keys$parse_req__1740000265$fn__1740000266")

var Lit_539 *jrt.String = jrt.Intern("arbace.spec.alpha$keys$parse_req__1740000265$fn__1740000266$fn__1740000267")

var Lit_540 *jrt.String = jrt.Intern("arbace.spec.alpha$keys$unk__1740000261")

var Lit_541 *jrt.String = jrt.Intern("arbace.spec.alpha$keys_STAR_")

var Lit_542 *jrt.String = jrt.Intern("arbace.spec.alpha$macroexpand_check")

var Lit_543 *jrt.String = jrt.Intern("Call to ")

var Lit_544 *jrt.String = jrt.Intern(" did not conform to spec.")

var Lit_545 *jrt.String = jrt.Intern("arbace.spec.alpha$map_of")

var Lit_546 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl")

var Lit_547 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$keys__GT_specnames__1740000399")

var Lit_548 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000431")

var Lit_549 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000433")

var Lit_550 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000436")

var Lit_551 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000448")

var Lit_552 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000448$fn__1740000452")

var Lit_553 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$ogen__1740000443")

var Lit_554 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$ogen__1740000443$fn__1740000444")

var Lit_555 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$rgen__1740000441")

var Lit_556 *jrt.String = jrt.Intern("arbace.spec.alpha$maybe_impl")

var Lit_557 *jrt.String = jrt.Intern("arbace.spec.alpha$maybe_spec")

var Lit_558 *jrt.String = jrt.Intern("arbace.spec.alpha$merge")

var Lit_559 *jrt.String = jrt.Intern("arbace.spec.alpha$merge_spec_impl")

var Lit_560 *jrt.String = jrt.Intern("arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000592")

var Lit_561 *jrt.String = jrt.Intern("arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000594")

var Lit_562 *jrt.String = jrt.Intern("arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000596")

var Lit_563 *jrt.String = jrt.Intern("arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000598")

var Lit_564 *jrt.String = jrt.Intern("arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000600")

var Lit_565 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec")

var Lit_566 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl")

var Lit_567 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$dval__1740000470")

var Lit_568 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$fn__1740000472")

var Lit_569 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$predx__1740000468")

var Lit_570 *jrt.String = jrt.Intern("no method")

var Lit_571 *jrt.String = jrt.Intern("No method of: ")

var Lit_572 *jrt.String = jrt.Intern(" for dispatch value: ")

var Lit_573 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$reify__1740000474$fn__1740000486")

var Lit_574 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$reify__1740000474$gen__1740000476")

var Lit_575 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$reify__1740000474$gen__1740000476$fn__1740000480")

var Lit_576 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$reify__1740000474$gen__1740000476$fn__1740000480$fn__1740000481")

var Lit_577 *jrt.String = jrt.Intern("arbace.spec.alpha$nilable")

var Lit_578 *jrt.String = jrt.Intern("arbace.spec.alpha$nilable_impl")

var Lit_579 *jrt.String = jrt.Intern("arbace.spec.alpha$nilable_impl$fn__1740000890")

var Lit_580 *jrt.String = jrt.Intern("arbace.spec.alpha$nilable_impl$reify__1740000892$fn__1740000893")

var Lit_581 *jrt.String = jrt.Intern("arbace.spec.alpha$nilable_impl$reify__1740000892$fn__1740000895")

var Lit_582 *jrt.String = jrt.Intern("arbace.spec.alpha$nonconforming")

var Lit_583 *jrt.String = jrt.Intern("arbace.spec.alpha$nonconforming$fn__1740000885")

var Lit_584 *jrt.String = jrt.Intern("arbace.spec.alpha$noret_QMARK_")

var Lit_585 *jrt.String = jrt.Intern("arbace.spec.alpha$ns_qualify")

var Lit_586 *jrt.String = jrt.Intern("arbace.spec.alpha$op_describe")

var Lit_587 *jrt.String = jrt.Intern("arbace.spec.alpha$op_explain")

var Lit_588 *jrt.String = jrt.Intern("arbace.spec.alpha$op_explain$fn__1740000806")

var Lit_589 *jrt.String = jrt.Intern("arbace.spec.alpha$op_explain$fn__1740000811")

var Lit_590 *jrt.String = jrt.Intern("arbace.spec.alpha$op_explain$insufficient__1740000799")

var Lit_591 *jrt.String = jrt.Intern("Insufficient input")

var Lit_592 *jrt.String = jrt.Intern("arbace.spec.alpha$op_unform")

var Lit_593 *jrt.String = jrt.Intern("arbace.spec.alpha$op_unform$fn__1740000759")

var Lit_594 *jrt.String = jrt.Intern("arbace.spec.alpha$op_unform$fn__1740000761")

var Lit_595 *jrt.String = jrt.Intern("arbace.spec.alpha$op_unform$fn__1740000763")

var Lit_596 *jrt.String = jrt.Intern("arbace.spec.alpha$op_unform$fn__1740000765")

var Lit_597 *jrt.String = jrt.Intern("arbace.spec.alpha$or")

var Lit_598 *jrt.String = jrt.Intern("spec/or expects k1 p1 k2 p2..., where ks are keywords")

var Lit_599 *jrt.String = jrt.Intern("arbace.spec.alpha$or_k_gen")

var Lit_600 *jrt.String = jrt.Intern("arbace.spec.alpha$or_k_gen$fn__1740000386")

var Lit_601 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl")

var Lit_602 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$fn__1740000503")

var Lit_603 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$fn__1740000506")

var Lit_604 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$fn__1740000508")

var Lit_605 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$fn__1740000510")

var Lit_606 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$reify__1740000513$fn__1740000517")

var Lit_607 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$reify__1740000513$gen__1740000519")

var Lit_608 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$reify__1740000513$gen__1740000519$fn__1740000520")

var Lit_609 *jrt.String = jrt.Intern("arbace.spec.alpha$pcat")

var Lit_610 *jrt.String = jrt.Intern("arbace.spec.alpha$pcat_STAR_")

var Lit_611 *jrt.String = jrt.Intern("arbace.spec.alpha$preturn")

var Lit_612 *jrt.String = jrt.Intern("arbace.spec.alpha$pvalid_QMARK_")

var Lit_613 *jrt.String = jrt.Intern("arbace.spec.alpha$re_conform")

var Lit_614 *jrt.String = jrt.Intern("arbace.spec.alpha$re_explain")

var Lit_615 *jrt.String = jrt.Intern("Extra input")

var Lit_616 *jrt.String = jrt.Intern("arbace.spec.alpha$re_gen")

var Lit_617 *jrt.String = jrt.Intern("arbace.spec.alpha$re_gen$fn__1740000825")

var Lit_618 *jrt.String = jrt.Intern("arbace.spec.alpha$re_gen$ggens__1740000817")

var Lit_619 *jrt.String = jrt.Intern("arbace.spec.alpha$re_gen$ggens__1740000817$gen__1740000818")

var Lit_620 *jrt.String = jrt.Intern("arbace.spec.alpha$re_gen$ggens__1740000817$gen__1740000818$fn__1740000819")

var Lit_621 *jrt.String = jrt.Intern("arbace.spec.alpha$recur_limit_QMARK_")

var Lit_622 *jrt.String = jrt.Intern("arbace.spec.alpha$reg_resolve")

var Lit_623 *jrt.String = jrt.Intern("arbace.spec.alpha$reg_resolve_BANG_")

var Lit_624 *jrt.String = jrt.Intern("Unable to resolve spec: ")

var Lit_625 *jrt.String = jrt.Intern("arbace.spec.alpha$regex_QMARK_")

var Lit_626 *jrt.String = jrt.Intern("arbace.spec.alpha$regex_spec_impl")

var Lit_627 *jrt.String = jrt.Intern("arbace.spec.alpha$registry")

var Lit_628 *jrt.String = jrt.Intern("arbace.spec.alpha$rep_PLUS_impl")

var Lit_629 *jrt.String = jrt.Intern("arbace.spec.alpha$rep_STAR_")

var Lit_630 *jrt.String = jrt.Intern("arbace.spec.alpha$rep_impl")

var Lit_631 *jrt.String = jrt.Intern("arbace.spec.alpha$res")

var Lit_632 *jrt.String = jrt.Intern("arbace.spec.alpha$res$fn__1740000229")

var Lit_633 *jrt.String = jrt.Intern("arbace.spec.alpha$res_kind")

var Lit_634 *jrt.String = jrt.Intern("arbace.spec.alpha$spec")

var Lit_635 *jrt.String = jrt.Intern("arbace.spec.alpha$spec_QMARK_")

var Lit_636 *jrt.String = jrt.Intern("arbace.spec.alpha$spec_impl")

var Lit_637 *jrt.String = jrt.Intern("no unform fn for conformer")

var Lit_638 *jrt.String = jrt.Intern("arbace.spec.alpha$spec_name")

var Lit_639 *jrt.String = jrt.Intern("arbace.spec.alpha$specize")

var Lit_640 *jrt.String = jrt.Intern("arbace.spec.alpha$tagged_ret")

var Lit_641 *jrt.String = jrt.Intern("arbace.spec.alpha$the_spec")

var Lit_642 *jrt.String = jrt.Intern("arbace.spec.alpha$tuple")

var Lit_643 *jrt.String = jrt.Intern("arbace.spec.alpha$tuple_impl")

var Lit_644 *jrt.String = jrt.Intern("arbace.spec.alpha$tuple_impl$fn__1740000493")

var Lit_645 *jrt.String = jrt.Intern("arbace.spec.alpha$tuple_impl$reify__1740000495$fn__1740000496")

var Lit_646 *jrt.String = jrt.Intern("arbace.spec.alpha$tuple_impl$reify__1740000495$gen__1740000498")

var Lit_647 *jrt.String = jrt.Intern("arbace.spec.alpha$unfn")

var Lit_648 *jrt.String = jrt.Intern("arbace.spec.alpha$unform")

var Lit_649 *jrt.String = jrt.Intern("arbace.spec.alpha$valid_QMARK_")

var Lit_650 *jrt.String = jrt.Intern("arbace.spec.alpha$validate_fn")

var Lit_651 *jrt.String = jrt.Intern("arbace.spec.alpha$validate_fn$fn__1740000851")

var Lit_652 *jrt.String = jrt.Intern("arbace.spec.alpha$with_gen")

var Lit_653 *jrt.String = jrt.Intern("arbace.spec.alpha$with_name")

var Lit_654 *jrt.String = jrt.Intern("in-ns")

var Lit_655 *jrt.String = jrt.Intern("alias")

var Lit_656 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_657 *jrt.String = jrt.Intern("dynamic")

var Lit_658 *jrt.String = jrt.Intern("file")

var Lit_659 *jrt.String = jrt.Intern("arbace/spec/alpha.ae")

var Lit_660 *jrt.String = jrt.Intern("A soft limit on how many times a branching spec (or/alt/*/opt-keys/multi-spec)\n  can be recursed through during generation. After this a\n  non-recursive branch will be chosen.")

var Lit_661 *jrt.String = jrt.Intern("The number of times an anonymous fn specified by fspec will be (generatively) tested during conform")

var Lit_662 *jrt.String = jrt.Intern("The number of elements validated in a collection spec'ed with 'every'")

var Lit_663 *jrt.String = jrt.Intern("The number of errors reported by explain in a collection spec'ed with 'every'")

var Lit_664 *jrt.String = jrt.Intern("Spec")

var Lit_665 *jrt.String = jrt.Intern("alter-meta!")

var Lit_666 *jrt.String = jrt.Intern("assert-same-protocol")

var Lit_667 *jrt.String = jrt.Intern("arglists")

var Lit_668 *jrt.String = jrt.Intern("y")

var Lit_669 *jrt.String = jrt.Intern("overrides")

var Lit_670 *jrt.String = jrt.Intern("rmap")

var Lit_671 *jrt.String = jrt.Intern("alter-var-root")

var Lit_672 *jrt.String = jrt.Intern("on")

var Lit_673 *jrt.String = jrt.Intern("on-interface")

var Lit_674 *jrt.String = jrt.Intern("sigs")

var Lit_675 *jrt.String = jrt.Intern("method-map")

var Lit_676 *jrt.String = jrt.Intern("method-builders")

var Lit_677 *jrt.String = jrt.Intern("intern")

var Lit_678 *jrt.String = jrt.Intern("protocol")

var Lit_679 *jrt.String = jrt.Intern("-reset-methods")

var Lit_680 *jrt.String = jrt.Intern("private")

var Lit_681 *jrt.String = jrt.Intern("atom")

var Lit_682 *jrt.String = jrt.Intern("reg")

var Lit_683 *jrt.String = jrt.Intern("returns the spec/regex at end of alias chain starting with k, nil if not found, k if k not ident")

var Lit_684 *jrt.String = jrt.Intern("returns the spec/regex at end of alias chain starting with k, throws if not found, k if k not ident")

var Lit_685 *jrt.String = jrt.Intern("returns x if x is a spec object, else logical false")

var Lit_686 *jrt.String = jrt.Intern("returns x if x is a (arbace.spec) regex op, else logical false")

var Lit_687 *jrt.String = jrt.Intern("declared")

var Lit_688 *jrt.String = jrt.Intern("spec-or-k")

var Lit_689 *jrt.String = jrt.Intern("spec-or-k must be a spec, regex or resolvable kw/sym, else returns nil.")

var Lit_690 *jrt.String = jrt.Intern("spec-or-k must be a spec, regex or kw/sym, else returns nil. Throws if unresolvable kw/sym")

var Lit_691 *jrt.String = jrt.Intern("Specize")

var Lit_692 *jrt.String = jrt.Intern("f")

var Lit_693 *jrt.String = jrt.Intern("Object")

var Lit_694 *jrt.String = jrt.Intern("extend")

var Lit_695 *jrt.String = jrt.Intern("arbace.lang.Keyword")

var Lit_696 *jrt.String = jrt.Intern("arbace.lang.Symbol")

var Lit_697 *jrt.String = jrt.Intern("arbace.lang.IPersistentSet")

var Lit_698 *jrt.String = jrt.Intern("java.lang.Object")

var Lit_699 *jrt.String = jrt.Intern("s")

var Lit_700 *jrt.String = jrt.Intern("tests the validity of a conform return value")

var Lit_701 *jrt.String = jrt.Intern("Given a spec and a value, returns :arbace.spec.alpha/invalid \n\tif value does not match spec, else the (possibly destructured) value.")

var Lit_702 *jrt.String = jrt.Intern("Given a spec and a value created by or compliant with a call to\n  'conform' with the same spec, returns a value with all conform\n  destructuring undone.")

var Lit_703 *jrt.String = jrt.Intern("returns the spec as data")

var Lit_704 *jrt.String = jrt.Intern("returns an abbreviated description of the spec as data")

var Lit_705 *jrt.String = jrt.Intern("gen-fn")

var Lit_706 *jrt.String = jrt.Intern("Takes a spec and a no-arg, generator-returning fn and returns a version of that spec that uses that generator")

var Lit_707 *jrt.String = jrt.Intern("Given a spec and a value x which ought to conform, returns nil if x\n  conforms, else a map with at least the key ::problems whose value is\n  a collection of problem-maps, where problem-map has at least :path :pred and :val\n  keys describing the predicate and the value that failed at that\n  path.")

var Lit_708 *jrt.String = jrt.Intern("explain-printer")

var Lit_709 *jrt.String = jrt.Intern("ed")

var Lit_710 *jrt.String = jrt.Intern("Default printer for explain-data. nil indicates a successful validation.")

var Lit_711 *jrt.String = jrt.Intern("Prints explanation data (per 'explain-data') to *out* using the printer in *explain-out*,\n   by default explain-printer.")

var Lit_712 *jrt.String = jrt.Intern("Given a spec and a value that fails to conform, prints an explanation to *out*.")

var Lit_713 *jrt.String = jrt.Intern("explain-str")

var Lit_714 *jrt.String = jrt.Intern("java.lang.String")

var Lit_715 *jrt.String = jrt.Intern("Given a spec and a value that fails to conform, returns an explanation as a string.")

var Lit_716 *jrt.String = jrt.Intern("Given a spec, returns the generator for it, or throws if none can\n  be constructed. Optionally an overrides map can be provided which\n  should map spec names or paths (vectors of keywords) to no-arg\n  generator-creating fns. These will be used instead of the generators at those\n  names/paths. Note that parent generator (in the spec or overrides\n  map) will supersede those of any subtrees. A generator for a regex\n  op must always return a sequential collection (i.e. a generator for\n  s/? should return either an empty sequence/vector or a\n  sequence/vector with one item in it)")

var Lit_717 *jrt.String = jrt.Intern("Returns a symbol from a symbol or var")

var Lit_718 *jrt.String = jrt.Intern("expr")

var Lit_719 *jrt.String = jrt.Intern("skip-wiki")

var Lit_720 *jrt.String = jrt.Intern("Do not call this directly, use 'def'")

var Lit_721 *jrt.String = jrt.Intern("Qualify symbol s by resolving it or using the current *ns*.")

var Lit_722 *jrt.String = jrt.Intern("spec-form")

var Lit_723 *jrt.String = jrt.Intern("Given a namespace-qualified keyword or resolvable symbol k, and a\n  spec, spec-name, predicate or regex-op makes an entry in the\n  registry mapping k to the spec. Use nil to remove an entry in\n  the registry for k.")

var Lit_724 *jrt.String = jrt.Intern("returns the registry map, prefer 'get-spec' to lookup a spec by name")

var Lit_725 *jrt.String = jrt.Intern("Returns spec registered for keyword/symbol/var k, or nil.")

var Lit_726 *jrt.String = jrt.Intern("Takes a single predicate form, e.g. can be the name of a predicate,\n  like even?, or a fn literal like #(< % 42). Note that it is not\n  generally necessary to wrap predicates in spec when using the rest\n  of the spec macros, only to attach a unique generator\n\n  Can also be passed the result of one of the regex ops -\n  cat, alt, *, +, ?, in which case it will return a regex-conforming\n  spec, useful when nesting an independent regex.\n  ---\n\n  Optionally takes :gen generator-fn, which must be a fn of no args that\n  returns a test.check generator.\n\n  Returns a spec.")

var Lit_727 *jrt.String = jrt.Intern("mm")

var Lit_728 *jrt.String = jrt.Intern("retag")

var Lit_729 *jrt.String = jrt.Intern("Takes the name of a spec/predicate-returning multimethod and a\n  tag-restoring keyword or fn (retag).  Returns a spec that when\n  conforming or explaining data will pass it to the multimethod to get\n  an appropriate spec. You can e.g. use multi-spec to dynamically and\n  extensibly associate specs with 'tagged' data (i.e. data where one\n  of the fields indicates the shape of the rest of the structure).\n\n  (defmulti mspec :tag)\n\n  The methods should ignore their argument and return a predicate/spec:\n  (defmethod mspec :int [_] (s/keys :req-un [::tag ::i]))\n\n  retag is used during generation to retag generated values with\n  matching tags. retag can either be a keyword, at which key the\n  dispatch-tag will be assoc'ed, or a fn of generated value and\n  dispatch-tag that should return an appropriately retagged value.\n\n  Note that because the tags themselves comprise an open set,\n  the tag key spec cannot enumerate the values, but can e.g.\n  test for keyword?.\n\n  Note also that the dispatch values of the multimethod will be\n  included in the path, i.e. in reporting and gen overrides, even\n  though those values are not evident in the spec.\n")

var Lit_730 *jrt.String = jrt.Intern("Creates and returns a map validating spec. :req and :opt are both\n  vectors of namespaced-qualified keywords. The validator will ensure\n  the :req keys are present. The :opt keys serve as documentation and\n  may be used by the generator.\n\n  The :req key vector supports 'and' and 'or' for key groups:\n\n  (s/keys :req [::x ::y (or ::secret (and ::user ::pwd))] :opt [::z])\n\n  There are also -un versions of :req and :opt. These allow\n  you to connect unqualified keys to specs.  In each case, fully\n  qualified keywords are passed, which name the specs, but unqualified\n  keys (with the same name component) are expected and checked at\n  conform-time, and generated during gen:\n\n  (s/keys :req-un [:my.ns/x :my.ns/y])\n\n  The above says keys :x and :y are required, and will be validated\n  and generated by specs (if they exist) named :my.ns/x :my.ns/y \n  respectively.\n\n  In addition, the values of *all* namespace-qualified keys will be validated\n  (and possibly destructured) by any registered specs. Note: there is\n  no support for inline value specification, by design.\n\n  Optionally takes :gen generator-fn, which must be a fn of no args that\n  returns a test.check generator.")

var Lit_731 *jrt.String = jrt.Intern("Takes key+pred pairs, e.g.\n\n  (s/or :even even? :small #(< % 42))\n\n  Returns a destructuring spec that returns a map entry containing the\n  key of the first matching pred and the corresponding value. Thus the\n  'key' and 'val' functions can be used to refer generically to the\n  components of the tagged return.")

var Lit_732 *jrt.String = jrt.Intern("Takes predicate/spec-forms, e.g.\n\n  (s/and even? #(< % 42))\n\n  Returns a spec that returns the conformed value. Successive\n  conformed values propagate through rest of predicates.")

var Lit_733 *jrt.String = jrt.Intern("Takes map-validating specs (e.g. 'keys' specs) and\n  returns a spec that returns a conformed map satisfying all of the\n  specs.  Unlike 'and', merge can generate maps satisfying the\n  union of the predicates.")

var Lit_734 *jrt.String = jrt.Intern("opts")

var Lit_735 *jrt.String = jrt.Intern("takes a pred and validates collection elements against that pred.\n\n  Note that 'every' does not do exhaustive checking, rather it samples\n  *coll-check-limit* elements. Nor (as a result) does it do any\n  conforming of elements. 'explain' will report at most *coll-error-limit*\n  problems.  Thus 'every' should be suitable for potentially large\n  collections.\n\n  Takes several kwargs options that further constrain the collection:\n\n  :kind - a pred that the collection type must satisfy, e.g. vector?\n        (default nil) Note that if :kind is specified and :into is\n        not, this pred must generate in order for every to generate.\n  :count - specifies coll has exactly this count (default nil)\n  :min-count, :max-count - coll has count (<= min-count count max-count) (defaults nil)\n  :distinct - all the elements are distinct (default nil)\n\n  And additional args that control gen\n\n  :gen-max - the maximum coll size to generate (default 20)\n  :into - one of [], (), {}, #{} - the default collection to generate into\n      (default: empty coll as generated by :kind pred if supplied, else [])\n  \n  Optionally takes :gen generator-fn, which must be a fn of no args that\n  returns a test.check generator\n\n  See also - coll-of, every-kv\n")

var Lit_736 *jrt.String = jrt.Intern("kpred")

var Lit_737 *jrt.String = jrt.Intern("vpred")

var Lit_738 *jrt.String = jrt.Intern("like 'every' but takes separate key and val preds and works on associative collections.\n\n  Same options as 'every', :into defaults to {}\n\n  See also - map-of")

var Lit_739 *jrt.String = jrt.Intern("Returns a spec for a collection of items satisfying pred. Unlike\n  'every', coll-of will exhaustively conform every value.\n\n  Same options as 'every'. conform will produce a collection\n  corresponding to :into if supplied, else will match the input collection,\n  avoiding rebuilding when possible.\n\n  See also - every, map-of")

var Lit_740 *jrt.String = jrt.Intern("Returns a spec for a map whose keys satisfy kpred and vals satisfy\n  vpred. Unlike 'every-kv', map-of will exhaustively conform every\n  value.\n\n  Same options as 'every', :kind defaults to map?, with the addition of:\n\n  :conform-keys - conform keys as well as values (default false)\n\n  See also - every-kv")

var Lit_741 *jrt.String = jrt.Intern("pred-form")

var Lit_742 *jrt.String = jrt.Intern("Returns a regex op that matches zero or more values matching\n  pred. Produces a vector of matches iff there is at least one match")

var Lit_743 *jrt.String = jrt.Intern("Returns a regex op that matches one or more values matching\n  pred. Produces a vector of matches")

var Lit_744 *jrt.String = jrt.Intern("Returns a regex op that matches zero or one value matching\n  pred. Produces a single value (not a collection) if matched.")

var Lit_745 *jrt.String = jrt.Intern("Takes key+pred pairs, e.g.\n\n  (s/alt :even even? :small #(< % 42))\n\n  Returns a regex op that returns a map entry containing the key of the\n  first matching pred and the corresponding value. Thus the\n  'key' and 'val' functions can be used to refer generically to the\n  components of the tagged return")

var Lit_746 *jrt.String = jrt.Intern("Takes key+pred pairs, e.g.\n\n  (s/cat :e even? :o odd?)\n\n  Returns a regex op that matches (all) values in sequence, returning a map\n  containing the keys of each pred and the corresponding value.")

var Lit_747 *jrt.String = jrt.Intern("re")

var Lit_748 *jrt.String = jrt.Intern("takes a regex op re, and predicates. Returns a regex-op that consumes\n  input as per re but subjects the resulting value to the\n  conjunction of the predicates, and any conforming they might perform.")

var Lit_749 *jrt.String = jrt.Intern("unf")

var Lit_750 *jrt.String = jrt.Intern("takes a predicate function with the semantics of conform i.e. it should return either a\n  (possibly converted) value or :arbace.spec.alpha/invalid, and returns a\n  spec that uses it as a predicate/conformer. Optionally takes a\n  second fn that does unform of result of first")

var Lit_751 *jrt.String = jrt.Intern("takes :args :ret and (optional) :fn kwargs whose values are preds\n  and returns a spec whose conform/explain take a fn and validates it\n  using generative testing. The conformed value is always the fn itself.\n\n  See 'fdef' for a single operation that creates an fspec and\n  registers it, as well as a full description of :args, :ret and :fn\n\n  fspecs can generate functions that validate the arguments and\n  fabricate a return value compliant with the :ret spec, ignoring\n  the :fn spec if present.\n\n  Optionally takes :gen generator-fn, which must be a fn of no args\n  that returns a test.check generator.")

var Lit_752 *jrt.String = jrt.Intern("takes one or more preds and returns a spec for a tuple, a vector\n  where each element conforms to the corresponding pred. Each element\n  will be referred to in paths using its ordinal.")

var Lit_753 *jrt.String = jrt.Intern("macroexpand-check")

var Lit_754 *jrt.String = jrt.Intern("fdef")

var Lit_755 *jrt.String = jrt.Intern("specs")

var Lit_756 *jrt.String = jrt.Intern("Takes a symbol naming a function, and one or more of the following:\n\n  :args A regex spec for the function arguments as they were a list to be\n    passed to apply - in this way, a single spec can handle functions with\n    multiple arities\n  :ret A spec for the function's return value\n  :fn A spec of the relationship between args and ret - the\n    value passed is {:args conformed-args :ret conformed-ret} and is\n    expected to contain predicates that relate those values\n\n  Qualifies fn-sym with resolve, or using *ns* if no resolution found.\n  Registers an fspec in the global registry, where it can be retrieved\n  by calling get-spec with the var or fully-qualified symbol.\n\n  Once registered, function specs are included in doc, checked by\n  instrument, tested by the runner arbace.spec.test.alpha/check, and (if\n  a macro) used to explain errors during macroexpansion.\n\n  Note that :fn specs require the presence of :args and :ret specs to\n  conform values, and so :fn specs will be ignored if :args or :ret\n  are missing.\n\n  Returns the qualified fn-sym.\n\n  For example, to register function specs for the symbol function:\n\n  (s/fdef arbace.core/symbol\n    :args (s/alt :separate (s/cat :ns string? :n string?)\n                 :str string?\n                 :sym symbol?)\n    :ret symbol?)")

var Lit_757 *jrt.String = jrt.Intern("m")

var Lit_758 *jrt.String = jrt.Intern("cpred?")

var Lit_759 *jrt.String = jrt.Intern("Helper function that returns true when x is valid for spec.")

var Lit_760 *jrt.String = jrt.Intern("internal helper function that returns true when x is valid for spec.")

var Lit_761 *jrt.String = jrt.Intern("returns a generator for form f, which can be a keyword or a list\n  starting with 'or or 'and.")

var Lit_762 *jrt.String = jrt.Intern("returns a tuple generator made up of generators for a random subset\n  of min-count (default 0) to all elements in s.")

var Lit_763 *jrt.String = jrt.Intern("returns a tuple generator made up of generators for every element\n  in s.")

var Lit_764 *jrt.String = jrt.Intern("argm")

var Lit_765 *jrt.String = jrt.Intern("Do not call this directly, use 'spec' with a map argument")

var Lit_766 *jrt.String = jrt.Intern("unc")

var Lit_767 *jrt.String = jrt.Intern("Do not call this directly, use 'spec'")

var Lit_768 *jrt.String = jrt.Intern("mmvar")

var Lit_769 *jrt.String = jrt.Intern("Do not call this directly, use 'multi-spec'")

var Lit_770 *jrt.String = jrt.Intern("Do not call this directly, use 'tuple'")

var Lit_771 *jrt.String = jrt.Intern("Do not call this directly, use 'or'")

var Lit_772 *jrt.String = jrt.Intern("Do not call this directly, use 'and'")

var Lit_773 *jrt.String = jrt.Intern("Do not call this directly, use 'merge'")

var Lit_774 *jrt.String = jrt.Intern("kform")

var Lit_775 *jrt.String = jrt.Intern("set?")

var Lit_776 *jrt.String = jrt.Intern("conform-into")

var Lit_777 *jrt.String = jrt.Intern("describe-form")

var Lit_778 *jrt.String = jrt.Intern("Do not call this directly, use 'every', 'every-kv', 'coll-of' or 'map-of'")

var Lit_779 *jrt.String = jrt.Intern("k1")

var Lit_780 *jrt.String = jrt.Intern("kr")

var Lit_781 *jrt.String = jrt.Intern("f1")

var Lit_782 *jrt.String = jrt.Intern("fr")

var Lit_783 *jrt.String = jrt.Intern("Do not call this directly, use 'cat'")

var Lit_784 *jrt.String = jrt.Intern("p")

var Lit_785 *jrt.String = jrt.Intern("Do not call this directly, use '*'")

var Lit_786 *jrt.String = jrt.Intern("Do not call this directly, use '+'")

var Lit_787 *jrt.String = jrt.Intern("re-form")

var Lit_788 *jrt.String = jrt.Intern("Do not call this directly, use '&'")

var Lit_789 *jrt.String = jrt.Intern("Do not call this directly, use 'alt'")

var Lit_790 *jrt.String = jrt.Intern("Do not call this directly, use '?'")

var Lit_791 *jrt.String = jrt.Intern("pret")

var Lit_792 *jrt.String = jrt.Intern("r")

var Lit_793 *jrt.String = jrt.Intern("input")

var Lit_794 *jrt.String = jrt.Intern("xs")

var Lit_795 *jrt.String = jrt.Intern("data")

var Lit_796 *jrt.String = jrt.Intern("Do not call this directly, use 'spec' with a regex op argument")

var Lit_797 *jrt.String = jrt.Intern("iters")

var Lit_798 *jrt.String = jrt.Intern("returns f if valid, else smallest")

var Lit_799 *jrt.String = jrt.Intern("aform")

var Lit_800 *jrt.String = jrt.Intern("retspec")

var Lit_801 *jrt.String = jrt.Intern("rform")

var Lit_802 *jrt.String = jrt.Intern("fnspec")

var Lit_803 *jrt.String = jrt.Intern("fform")

var Lit_804 *jrt.String = jrt.Intern("Do not call this directly, use 'fspec'")

var Lit_805 *jrt.String = jrt.Intern("p1__1740000866#")

var Lit_806 *jrt.String = jrt.Intern("p1__1740000867#")

var Lit_807 *jrt.String = jrt.Intern("keys*")

var Lit_808 *jrt.String = jrt.Intern("kspecs")

var Lit_809 *jrt.String = jrt.Intern("takes the same arguments as spec/keys and returns a regex op that matches sequences of key/values,\n  converts them into a map, and conforms that map with a corresponding\n  spec/keys call:\n\n  user=> (s/conform (s/keys :req-un [::a ::c]) {:a 1 :c 2})\n  {:a 1, :c 2}\n  user=> (s/conform (s/keys* :req-un [::a ::c]) [:a 1 :c 2])\n  {:a 1, :c 2}\n\n  the resulting regex op can be composed into a larger regex:\n\n  user=> (s/conform (s/cat :i1 integer? :m (s/keys* :req-un [::a ::c]) :i2 integer?) [42 :a 1 :c 2 :d 4 99])\n  {:i1 42, :m {:a 1, :c 2, :d 4}, :i2 99}")

var Lit_810 *jrt.String = jrt.Intern("takes a spec and returns a spec that has the same properties except\n  'conform' returns the original (not the conformed) value. Note, will specize regex ops.")

var Lit_811 *jrt.String = jrt.Intern("Do not call this directly, use 'nilable'")

var Lit_812 *jrt.String = jrt.Intern("returns a spec that accepts nil and values satisfying pred")

var Lit_813 *jrt.String = jrt.Intern("n")

var Lit_814 *jrt.String = jrt.Intern("generates a number (default 10) of values compatible with spec and maps conform over them,\n  returning a sequence of [val conformed-val] tuples. Optionally takes\n  a generator overrides map as per gen")

var Lit_815 *jrt.String = jrt.Intern("sym")

var Lit_816 *jrt.String = jrt.Intern("sym-or-f")

var Lit_817 *jrt.String = jrt.Intern("exercises the fn named by sym (a symbol) by applying it to\n  n (default 10) generated samples of its args spec. When fspec is\n  supplied its arg spec is used, and sym-or-f can be a fn.  Returns a\n  sequence of tuples of [args ret]. ")

var Lit_818 *jrt.String = jrt.Intern("start")

var Lit_819 *jrt.String = jrt.Intern("end")

var Lit_820 *jrt.String = jrt.Intern("inst")

var Lit_821 *jrt.String = jrt.Intern("Return true if inst at or after start and before end")

var Lit_822 *jrt.String = jrt.Intern("inst-in")

var Lit_823 *jrt.String = jrt.Intern("Returns a spec that validates insts in the range from start\n(inclusive) to end (exclusive).")

var Lit_824 *jrt.String = jrt.Intern("Return true if start <= val, val < end and val is a fixed\n  precision integer.")

var Lit_825 *jrt.String = jrt.Intern("int-in")

var Lit_826 *jrt.String = jrt.Intern("Returns a spec that validates fixed precision integers in the\n  range from start (inclusive) to end (exclusive).")

var Lit_827 *jrt.String = jrt.Intern("double-in")

var Lit_828 *jrt.String = jrt.Intern("Specs a 64-bit floating point number. Options:\n\n    :infinite? - whether +/- infinity allowed (default true)\n    :NaN?      - whether NaN allowed (default true)\n    :min       - minimum value (inclusive, default none)\n    :max       - maximum value (inclusive, default none)")

var Lit_829 *jrt.String = jrt.Intern("If true, compiler will enable spec asserts, which are then\nsubject to runtime control via check-asserts? If false, compiler\nwill eliminate all spec assert overhead. See 'assert'.\n\nInitially set to boolean value of arbace.spec.compile-asserts\nsystem property. Defaults to true.")

var Lit_830 *jrt.String = jrt.Intern("check-asserts?")

var Lit_831 *jrt.String = jrt.Intern("Returns the value set by check-asserts.")

var Lit_832 *jrt.String = jrt.Intern("check-asserts")

var Lit_833 *jrt.String = jrt.Intern("flag")

var Lit_834 *jrt.String = jrt.Intern("Enable or disable spec asserts that have been compiled\nwith '*compile-asserts*' true.  See 'assert'.\n\nInitially set to boolean value of arbace.spec.check-asserts\nsystem property. Defaults to false.")

var Lit_835 *jrt.String = jrt.Intern("Do not call this directly, use 'assert'.")

var Lit_836 *jrt.String = jrt.Intern("spec-checking assert expression. Returns x if x is valid? according\nto spec, else throws an ex-info with explain-data plus ::failure of\n:assertion-failed.\n\nCan be disabled at either compile time or runtime:\n\nIf *compile-asserts* is false at compile time, compiles to x. Defaults\nto value of 'arbace.spec.compile-asserts' system property, or true if\nnot set.\n\nIf (check-asserts?) is false at runtime, always returns x. Defaults to\nvalue of 'arbace.spec.check-asserts' system property, or false if not\nset. You can toggle check-asserts? with (check-asserts bool).")

var Lit_837 *jrt.String = jrt.Intern("false")

var Lit_838 *jrt.String = jrt.Intern("arbace.spec.compile-asserts")
