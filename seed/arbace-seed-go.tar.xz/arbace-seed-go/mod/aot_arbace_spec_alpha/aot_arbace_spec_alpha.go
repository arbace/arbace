//line aot_arbace_spec_alpha.ae:1
package aot_arbace_spec_alpha

import (
	"arbace/jrt"
	"arbace/lang"
)






func A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_New() *A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A) Ctor() {}
//line :13:1
func (t *A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_spec_alpha_A_const_1.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_spec_alpha_A_const_2, A_arbace_spec_alpha_A_const_3, A_arbace_spec_alpha_A_const_4); tmp3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_0.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_spec_alpha_A_const_5, A_arbace_spec_alpha_A_const_6, A_arbace_spec_alpha_A_const_7); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :13:1
func A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_New() *A_arbace_spec_alpha_eval1740000008_fn__1740000009_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000008_fn__1740000009_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_spec_alpha_eval1740000008_fn__1740000009_A) Ctor() {}
//line :13:1
func (t *A_arbace_spec_alpha_eval1740000008_fn__1740000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_8.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_12), A_arbace_spec_alpha_A_const_10.GetRawRoot__O(), A_arbace_spec_alpha_A_const_11) }


































func A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_New() *A_arbace_spec_alpha_eval1740000034_fn__1740000035_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000035_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000035_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000035_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1740000021__2_ any; var tmp1 any = A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; G__1740000021__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_New_O(G__1740000021__2_); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_New_O(p0 any) *A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A) Ctor_O(c__G__1740000021 any) { t.F_G__1740000021 = c__G__1740000021 }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A) Invoke_O_O_O_O_O_O__O(self, gf__spec__1740000043__1, gf__path__1740000044__2, gf__via__1740000045__3, gf__in__1740000046__4, gf__x__1740000047__5 any) any { var cache__231000236__auto____6 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____7 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____6)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__spec__1740000043__1)); if jrt.J2g_Truth(f__231000237__auto____7) { return lang.IFn_Cast(f__231000237__auto____7).Invoke_O_O_O_O_O__O(gf__spec__1740000043__1, gf__path__1740000044__2, gf__via__1740000045__3, gf__in__1740000046__4, gf__x__1740000047__5) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_spec_alpha_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__spec__1740000043__1, A_arbace_spec_alpha_A_const_14, t.F_G__1740000021)).Invoke_O_O_O_O_O__O(gf__spec__1740000043__1, gf__path__1740000044__2, gf__via__1740000045__3, gf__in__1740000046__4, gf__x__1740000047__5) } }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_New() *A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A) Invoke_O_O_O_O_O_O__O(self, gf__spec__1740000036__1, gf__path__1740000037__2, gf__via__1740000038__3, gf__in__1740000039__4, gf__x__1740000040__5 any) any { var target_1 any = gf__spec__1740000036__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_1 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_1) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_1, Lit_20, jrt.RefArrayOf(jrt.Object_class, gf__path__1740000037__2, gf__via__1740000038__3, gf__in__1740000039__4, gf__x__1740000040__5)) } else { return A_arbace_spec_alpha_Spec_A_Cast(target_1).Explain_STAR__O_O_O_O__O(gf__path__1740000037__2, gf__via__1740000038__3, gf__in__1740000039__4, gf__x__1740000040__5) } }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_New() *A_arbace_spec_alpha_eval1740000034_fn__1740000051_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000051_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000051_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000051_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1740000025__2_ any; var tmp1 any = A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_New(); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; G__1740000025__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_New_O(G__1740000025__2_); var tmp4 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_fn_class = fncls__6d; tmp4 = fncls__6d } else { tmp4 = fncls__6 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_New_O(p0 any) *A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A) Ctor_O(c__G__1740000025 any) { t.F_G__1740000025 = c__G__1740000025 }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A) Invoke_O_O_O__O(self, gf__spec__1740000056__1, gf__gfn__1740000057__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__spec__1740000056__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__spec__1740000056__1, gf__gfn__1740000057__2) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_spec_alpha_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__spec__1740000056__1, A_arbace_spec_alpha_A_const_14, t.F_G__1740000025)).Invoke_O_O__O(gf__spec__1740000056__1, gf__gfn__1740000057__2) } }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_New() *A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A) Invoke_O_O_O__O(self, gf__spec__1740000052__1, gf__gfn__1740000053__2 any) any { var target_4 any = gf__spec__1740000052__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_4 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_4) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_4, Lit_23, jrt.RefArrayOf(jrt.Object_class, gf__gfn__1740000053__2)) } else { return A_arbace_spec_alpha_Spec_A_Cast(target_4).With_gen_STAR__O__O(gf__gfn__1740000053__2) } }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_New() *A_arbace_spec_alpha_eval1740000034_fn__1740000061_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000061_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000061_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000061_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1740000023__2_ any; var tmp1 any = A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_New(); var tmp2 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; G__1740000023__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_New_O(G__1740000023__2_); var tmp4 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_fn_class = fncls__9d; tmp4 = fncls__9d } else { tmp4 = fncls__9 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_New_O(p0 any) *A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A) Ctor_O(c__G__1740000023 any) { t.F_G__1740000023 = c__G__1740000023 }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A) Invoke_O_O_O_O_O__O(self, gf__spec__1740000068__1, gf__overrides__1740000069__2, gf__path__1740000070__3, gf__rmap__1740000071__4 any) any { var cache__231000236__auto____5 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____6 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____5)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__spec__1740000068__1)); if jrt.J2g_Truth(f__231000237__auto____6) { return lang.IFn_Cast(f__231000237__auto____6).Invoke_O_O_O_O__O(gf__spec__1740000068__1, gf__overrides__1740000069__2, gf__path__1740000070__3, gf__rmap__1740000071__4) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_spec_alpha_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__spec__1740000068__1, A_arbace_spec_alpha_A_const_14, t.F_G__1740000023)).Invoke_O_O_O_O__O(gf__spec__1740000068__1, gf__overrides__1740000069__2, gf__path__1740000070__3, gf__rmap__1740000071__4) } }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_New() *A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A) Invoke_O_O_O_O_O__O(self, gf__spec__1740000062__1, gf__overrides__1740000063__2, gf__path__1740000064__3, gf__rmap__1740000065__4 any) any { var target_7 any = gf__spec__1740000062__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_7 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_7) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_7, Lit_26, jrt.RefArrayOf(jrt.Object_class, gf__overrides__1740000063__2, gf__path__1740000064__3, gf__rmap__1740000065__4)) } else { return A_arbace_spec_alpha_Spec_A_Cast(target_7).Gen_STAR__O_O_O__O(gf__overrides__1740000063__2, gf__path__1740000064__3, gf__rmap__1740000065__4) } }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_New() *A_arbace_spec_alpha_eval1740000034_fn__1740000075_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000075_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000075_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000075_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1740000017__2_ any; var tmp1 any = A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_New(); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; G__1740000017__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_New_O(G__1740000017__2_); var tmp4 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_fn_class = fncls__12d; tmp4 = fncls__12d } else { tmp4 = fncls__12 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_New_O(p0 any) *A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A) Ctor_O(c__G__1740000017 any) { t.F_G__1740000017 = c__G__1740000017 }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A) Invoke_O_O_O__O(self, gf__spec__1740000080__1, gf__x__1740000081__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__spec__1740000080__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__spec__1740000080__1, gf__x__1740000081__2) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_spec_alpha_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__spec__1740000080__1, A_arbace_spec_alpha_A_const_14, t.F_G__1740000017)).Invoke_O_O__O(gf__spec__1740000080__1, gf__x__1740000081__2) } }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_New() *A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A) Invoke_O_O_O__O(self, gf__spec__1740000076__1, gf__x__1740000077__2 any) any { var target_10 any = gf__spec__1740000076__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_10 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_10) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_10, Lit_29, jrt.RefArrayOf(jrt.Object_class, gf__x__1740000077__2)) } else { return A_arbace_spec_alpha_Spec_A_Cast(target_10).Conform_STAR__O__O(gf__x__1740000077__2) } }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_New() *A_arbace_spec_alpha_eval1740000034_fn__1740000085_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000085_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000085_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000085_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1740000027__2_ any; var tmp1 any = A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_New(); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; G__1740000027__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_New_O(G__1740000027__2_); var tmp4 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_fn_class = fncls__15d; tmp4 = fncls__15d } else { tmp4 = fncls__15 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_New_O(p0 any) *A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A) Ctor_O(c__G__1740000027 any) { t.F_G__1740000027 = c__G__1740000027 }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A) Invoke_O_O__O(self, gf__spec__1740000089__1 any) any { var cache__231000236__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__spec__1740000089__1)); if jrt.J2g_Truth(f__231000237__auto____3) { return lang.IFn_Cast(f__231000237__auto____3).Invoke_O__O(gf__spec__1740000089__1) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_spec_alpha_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__spec__1740000089__1, A_arbace_spec_alpha_A_const_14, t.F_G__1740000027)).Invoke_O__O(gf__spec__1740000089__1) } }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_New() *A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A) Invoke_O_O__O(self, gf__spec__1740000086__1 any) any { var target_13 any = gf__spec__1740000086__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_13 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_13) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_13, Lit_32, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_spec_alpha_Spec_A_Cast(target_13).Describe_STAR___O() } }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_New() *A_arbace_spec_alpha_eval1740000034_fn__1740000093_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000093_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000093_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000093_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1740000019__2_ any; var tmp1 any = A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_New(); var tmp2 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_fn_class = fncls__17d; tmp2 = fncls__17d } else { tmp2 = fncls__17 }; G__1740000019__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_New_O(G__1740000019__2_); var tmp4 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_fn_class = fncls__18d; tmp4 = fncls__18d } else { tmp4 = fncls__18 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_New_O(p0 any) *A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A{}; t.Ctor_O(p0); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A) Ctor_O(c__G__1740000019 any) { t.F_G__1740000019 = c__G__1740000019 }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A) Invoke_O_O_O__O(self, gf__spec__1740000098__1, gf__y__1740000099__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__spec__1740000098__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__spec__1740000098__1, gf__y__1740000099__2) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_spec_alpha_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf__spec__1740000098__1, A_arbace_spec_alpha_A_const_14, t.F_G__1740000019)).Invoke_O_O__O(gf__spec__1740000098__1, gf__y__1740000099__2) } }
//line :48:1
func A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_New() *A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A) Invoke_O_O_O__O(self, gf__spec__1740000094__1, gf__y__1740000095__2 any) any { var target_16 any = gf__spec__1740000094__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_16 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_16) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_16, Lit_35, jrt.RefArrayOf(jrt.Object_class, gf__y__1740000095__2)) } else { return A_arbace_spec_alpha_Spec_A_Cast(target_16).Unform_STAR__O__O(gf__y__1740000095__2) } }









func A_arbace_spec_alpha_deep_resolve_A_New() *A_arbace_spec_alpha_deep_resolve_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_deep_resolve_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_spec_alpha_deep_resolve_A) Ctor() {}
//line :58:1
func (t *A_arbace_spec_alpha_deep_resolve_A) Invoke_O_O_O__O(self, reg__0, k__1 any) any { { var spec__3 any = k__1; L1: for {

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_15.GetRawRoot__O()).Invoke_O__O(spec__3)) {
		spec__3 = lang.RT_Get_O_O__O(reg__0, spec__3); continue L1 } else {
//line :60:1
			return spec__3 } } }; /*line :58:1*/panic("j2g: unreachable") }





func A_arbace_spec_alpha_reg_resolve_A_New() *A_arbace_spec_alpha_reg_resolve_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_reg_resolve_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_spec_alpha_reg_resolve_A) Ctor() {}
//line :64:1
func (t *A_arbace_spec_alpha_reg_resolve_A) Invoke_O_O__O(self, k__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_15.GetRawRoot__O()).Invoke_O__O(k__0)) { var reg__2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_18.GetRawRoot__O()); var spec__3 any = lang.RT_Get_O_O__O(reg__2, k__0)


		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_15.GetRawRoot__O()).Invoke_O__O(spec__3))) { return spec__3 } else {

			return lang.IFn_Cast(A_arbace_spec_alpha_A_const_17.GetRawRoot__O()).Invoke_O_O__O(reg__2, spec__3) } } else {
//line :67:1
				return k__0
			}
}





func A_arbace_spec_alpha_reg_resolve_BANG__A_New() *A_arbace_spec_alpha_reg_resolve_BANG__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_reg_resolve_BANG__A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_spec_alpha_reg_resolve_BANG__A) Ctor() {}
//line :75:1
func (t *A_arbace_spec_alpha_reg_resolve_BANG__A) Invoke_O_O__O(self, k__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_15.GetRawRoot__O()).Invoke_O__O(k__0)) { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(k__0)
		if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { panic(jrt.Thrown(jrt.Exception_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_135, nil), jrt.RefArrayOf(jrt.Object_class, nil, k__0))))) } } else {
//line :78:1
			return k__0
		}
}


func A_arbace_spec_alpha_spec_QMARK__A_New() *A_arbace_spec_alpha_spec_QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_spec_QMARK__A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_spec_alpha_spec_QMARK__A) Ctor() {}
//line :83:1
func (t *A_arbace_spec_alpha_spec_QMARK__A) Invoke_O_O__O(self, x__0 any) any {


	if A_arbace_spec_alpha_Spec_A_InstanceOf(x__0) { return x__0 } else { return nil
	}
}
func A_arbace_spec_alpha_regex_QMARK__A_New() *A_arbace_spec_alpha_regex_QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_regex_QMARK__A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_spec_alpha_regex_QMARK__A) Ctor() {}
//line :89:1
func (t *A_arbace_spec_alpha_regex_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any = A_arbace_spec_alpha_A_const_20.Invoke_O__O(x__0); if


	jrt.J2g_Truth(and__1927000168__auto____2) { return x__0 } else { return and__1927000168__auto____2 } }

func A_arbace_spec_alpha_with_name_A_New() *A_arbace_spec_alpha_with_name_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_with_name_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_spec_alpha_with_name_A) Ctor() {}
//line :94:1
func (t *A_arbace_spec_alpha_with_name_A) Invoke_O_O_O__O(self, spec__0, name__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_15.GetRawRoot__O()).Invoke_O__O(spec__0)) { return spec__0 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_21.GetRawRoot__O()).Invoke_O__O(spec__0)) {

		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(spec__0, A_arbace_spec_alpha_A_const_24, name__1) } else {
//line :95:1
			if lang.IObj_InstanceOf(spec__0) {




				return lang.IFn_Cast(A_arbace_spec_alpha_A_const_23.GetRawRoot__O()).Invoke_O_O__O(spec__0, lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(lang.RT_Meta_O__IPersistentMap(spec__0), A_arbace_spec_alpha_A_const_24, name__1)) } else {
//line :95:1
					return nil
				}
		}
	}
}


func A_arbace_spec_alpha_spec_name_A_New() *A_arbace_spec_alpha_spec_name_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_spec_name_A{}; t.Ctor(); return t }
//line :102:1
func (t *A_arbace_spec_alpha_spec_name_A) Ctor() {}
//line :102:1
func (t *A_arbace_spec_alpha_spec_name_A) Invoke_O_O__O(self, spec__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_15.GetRawRoot__O()).Invoke_O__O(spec__0)) { return spec__0 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_21.GetRawRoot__O()).Invoke_O__O(spec__0)) {


		return A_arbace_spec_alpha_A_const_24.Invoke_O__O(spec__0) } else {
//line :103:1
			if lang.IObj_InstanceOf(spec__0) {





				var tmp1 *lang.Keyword = A_arbace_spec_alpha_A_const_24; return tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap(spec__0)) } else {
//line :103:1
					return nil
				}
		}
	}
}






func A_arbace_spec_alpha_maybe_spec_A_New() *A_arbace_spec_alpha_maybe_spec_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_maybe_spec_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_spec_alpha_maybe_spec_A) Ctor() {}
//line :114:1
func (t *A_arbace_spec_alpha_maybe_spec_A) Invoke_O_O__O(self, spec_or_k__0 any) any { var s__2 any; var or__1927000174__auto____2 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_15.GetRawRoot__O()).Invoke_O__O(spec_or_k__0); if


	jrt.J2g_Truth(and__1927000168__auto____2) { or__1927000174__auto____2 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(spec_or_k__0) } else { or__1927000174__auto____2 = and__1927000168__auto____2 }; if jrt.J2g_Truth(or__1927000174__auto____2) { s__2 = or__1927000174__auto____2 } else { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_25.GetRawRoot__O()).Invoke_O__O(spec_or_k__0); if jrt.J2g_Truth(or__1927000174__auto____3) { s__2 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_21.GetRawRoot__O()).Invoke_O__O(spec_or_k__0); if jrt.J2g_Truth(or__1927000174__auto____4) { s__2 = or__1927000174__auto____4 } else { s__2 = nil } } }; if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_21.GetRawRoot__O()).Invoke_O__O(s__2)) {
		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_26.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_27.GetRawRoot__O()).Invoke_O_O__O(s__2, nil), lang.IFn_Cast(A_arbace_spec_alpha_A_const_28.GetRawRoot__O()).Invoke_O__O(s__2)) } else {
//line :121:1
			return s__2 } }



func A_arbace_spec_alpha_the_spec_A_New() *A_arbace_spec_alpha_the_spec_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_the_spec_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_spec_alpha_the_spec_A) Ctor() {}
//line :125:1
func (t *A_arbace_spec_alpha_the_spec_A) Invoke_O_O__O(self, spec_or_k__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(spec_or_k__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else {
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_15.GetRawRoot__O()).Invoke_O__O(spec_or_k__0)) { panic(jrt.Thrown(jrt.Exception_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_135, nil), jrt.RefArrayOf(jrt.Object_class, nil, spec_or_k__0))))) } else { return nil } } }


func A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_New() *A_arbace_spec_alpha_eval1740000127_fn__1740000128_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000127_fn__1740000128_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_spec_alpha_eval1740000127_fn__1740000128_A) Ctor() {}
//line :132:1
func (t *A_arbace_spec_alpha_eval1740000127_fn__1740000128_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1740000120__2_ any; var tmp1 any = A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_New(); var tmp2 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_fn_class = fncls__21d; tmp2 = fncls__21d } else { tmp2 = fncls__21 }; G__1740000120__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_New_O(G__1740000120__2_); var tmp4 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_fn_class = fncls__22d; tmp4 = fncls__22d } else { tmp4 = fncls__22 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :132:1
func A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_New_O(p0 any) *A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A{}; t.Ctor_O(p0); return t }
//line :132:1
func (t *A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A) Ctor_O(c__G__1740000120 any) { t.F_G__1740000120 = c__G__1740000120 }
//line :132:1
func (t *A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A) Invoke_O_O_O__O(self, gf_____1740000135__1, gf__form__1740000136__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf_____1740000135__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf_____1740000135__1, gf__form__1740000136__2) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_spec_alpha_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf_____1740000135__1, A_arbace_spec_alpha_A_const_30, t.F_G__1740000120)).Invoke_O_O__O(gf_____1740000135__1, gf__form__1740000136__2) } }
//line :132:1
func (t *A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A) Invoke_O_O__O(self, gf_____1740000134__1 any) any { var cache__231000236__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf_____1740000134__1)); if jrt.J2g_Truth(f__231000237__auto____3) { return lang.IFn_Cast(f__231000237__auto____3).Invoke_O__O(gf_____1740000134__1) } else { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_spec_alpha_A_const_13.GetRawRoot__O()).Invoke_O_O_O_O__O(self, gf_____1740000134__1, A_arbace_spec_alpha_A_const_30, t.F_G__1740000120)).Invoke_O__O(gf_____1740000134__1) } }
//line :132:1
func A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_New() *A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A) Ctor() {}
//line :132:1
func (t *A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A) Invoke_O_O_O__O(self, gf_____1740000130__1, gf__form__1740000131__2 any) any { var target_19 any = gf_____1740000130__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_19 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_19) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_19, Lit_38, jrt.RefArrayOf(jrt.Object_class, gf__form__1740000131__2)) } else { return A_arbace_spec_alpha_Specize_A_Cast(target_19).Specize_STAR__O__O(gf__form__1740000131__2) } }
//line :132:1
func (t *A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A) Invoke_O_O__O(self, gf_____1740000129__1 any) any { var target_20 any = gf_____1740000129__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_20 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_20) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_20, Lit_38, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_spec_alpha_Specize_A_Cast(target_20).Specize_STAR___O() } }


func A_arbace_spec_alpha_fn_sym_A_New() *A_arbace_spec_alpha_fn_sym_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_fn_sym_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_spec_alpha_fn_sym_A) Ctor() {}
//line :135:1
func (t *A_arbace_spec_alpha_fn_sym_A) Invoke_O_O__O(self, f__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_31.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_A_const_34; var vec__1740000145__2 any = tmp1.Invoke_O_O__O(tmp2, jrt.NN(jrt.GetClass(f__0)).GetName__String().Ref()); var ___3 any = lang.RT_Nth_O_I_O__O(vec__1740000145__2, lang.RT_IntCast_J__I(0), nil); var f_ns__4 any = lang.RT_Nth_O_I_O__O(vec__1740000145__2, lang.RT_IntCast_J__I(1), nil); var f_n__5 any = lang.RT_Nth_O_I_O__O(vec__1740000145__2, lang.RT_IntCast_J__I(2), nil); _ = ___3; if


	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_32.GetRawRoot__O()).Invoke_O_O__O(Lit_68, f_n__5)) {
		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_Demunge_String__String(jrt.String_Cast(f_ns__4)).Ref(), lang.Compiler_Demunge_String__String(jrt.String_Cast(f_n__5)).Ref()) } else {
//line :138:1
			return nil } }


func A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_New() *A_arbace_spec_alpha_eval1740000149_fn__1740000150_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000149_fn__1740000150_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_spec_alpha_eval1740000149_fn__1740000150_A) Ctor() {}
//line :141:1
func (t *A_arbace_spec_alpha_eval1740000149_fn__1740000150_A) Invoke_O_O_O__O(self, k__1, ___2 any) any {


	var target_23 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_35.GetRawRoot__O()).Invoke_O__O(k__1); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_spec_alpha_Specize_A_InstanceOf(target_23); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_23) }; tmp1 = tmp2; if tmp1 { return A_arbace_spec_alpha_Specize_A_Cast(target_23).Specize_STAR___O() } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_36.GetRawRoot__O()).Invoke_O__O(target_23) } }
//line :141:1
func (t *A_arbace_spec_alpha_eval1740000149_fn__1740000150_A) Invoke_O_O__O(self, k__1 any) any {

	var target_24 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_35.GetRawRoot__O()).Invoke_O__O(k__1); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_spec_alpha_Specize_A_InstanceOf(target_24); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_24) }; tmp1 = tmp2; if tmp1 { return A_arbace_spec_alpha_Specize_A_Cast(target_24).Specize_STAR___O() } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_36.GetRawRoot__O()).Invoke_O__O(target_24) } }
//line :141:1
func A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_New() *A_arbace_spec_alpha_eval1740000153_fn__1740000154_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000153_fn__1740000154_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_spec_alpha_eval1740000153_fn__1740000154_A) Ctor() {}
//line :141:1
func (t *A_arbace_spec_alpha_eval1740000153_fn__1740000154_A) Invoke_O_O_O__O(self, s__1, ___2 any) any {






	var target_25 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_spec_alpha_Specize_A_InstanceOf(target_25); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_25) }; tmp1 = tmp2; if tmp1 { return A_arbace_spec_alpha_Specize_A_Cast(target_25).Specize_STAR___O() } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_36.GetRawRoot__O()).Invoke_O__O(target_25) } }
//line :141:1
func (t *A_arbace_spec_alpha_eval1740000153_fn__1740000154_A) Invoke_O_O__O(self, s__1 any) any {





	var target_26 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_35.GetRawRoot__O()).Invoke_O__O(s__1); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_spec_alpha_Specize_A_InstanceOf(target_26); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_26) }; tmp1 = tmp2; if tmp1 { return A_arbace_spec_alpha_Specize_A_Cast(target_26).Specize_STAR___O() } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_36.GetRawRoot__O()).Invoke_O__O(target_26) } }
//line :141:1
func A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_New() *A_arbace_spec_alpha_eval1740000157_fn__1740000158_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000157_fn__1740000158_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_spec_alpha_eval1740000157_fn__1740000158_A) Ctor() {}
//line :141:1
func (t *A_arbace_spec_alpha_eval1740000157_fn__1740000158_A) Invoke_O_O_O__O(self, s__1, form__2 any) any {










	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(form__2, s__1, nil, nil) }
//line :141:1
func (t *A_arbace_spec_alpha_eval1740000157_fn__1740000158_A) Invoke_O_O__O(self, s__1 any) any {









	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(s__1, s__1, nil, nil) }
//line :141:1
func A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_New() *A_arbace_spec_alpha_eval1740000161_fn__1740000162_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_eval1740000161_fn__1740000162_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_spec_alpha_eval1740000161_fn__1740000162_A) Ctor() {}
//line :141:1
func (t *A_arbace_spec_alpha_eval1740000161_fn__1740000162_A) Invoke_O_O_O__O(self, o__1, form__2 any) any {


















	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(form__2, o__1, nil, nil) }
//line :141:1
func (t *A_arbace_spec_alpha_eval1740000161_fn__1740000162_A) Invoke_O_O__O(self, o__1 any) any {













	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_40.GetRawRoot__O()).Invoke_O__O(o__1)); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_38.GetRawRoot__O()).Invoke_O__O(o__1) } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var temp__1927000408__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_39.GetRawRoot__O()).Invoke_O__O(o__1)
		if jrt.J2g_Truth(temp__1927000408__auto____2) { var s__3 any = temp__1927000408__auto____2
			return lang.IFn_Cast(A_arbace_spec_alpha_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(s__3, o__1, nil, nil) } else {
				return lang.IFn_Cast(A_arbace_spec_alpha_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_spec_alpha_A_const_41, o__1, nil, nil) } } else {
					return lang.IFn_Cast(A_arbace_spec_alpha_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_spec_alpha_A_const_41, o__1, nil, nil)
				}
}
func A_arbace_spec_alpha_specize_A_New() *A_arbace_spec_alpha_specize_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_specize_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_spec_alpha_specize_A) Ctor() {}
//line :162:1
func (t *A_arbace_spec_alpha_specize_A) Invoke_O_O_O__O(self, s__0, form__1 any) any { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_25.GetRawRoot__O()).Invoke_O__O(s__0); if

	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var target_27 any = s__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_spec_alpha_Specize_A_InstanceOf(target_27); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_27) }; tmp1 = tmp2; if tmp1 { return A_arbace_spec_alpha_Specize_A_Cast(target_27).Specize_STAR__O__O(form__1) } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_36.GetRawRoot__O()).Invoke_O_O__O(target_27, form__1) } } }
//line :162:1
func (t *A_arbace_spec_alpha_specize_A) Invoke_O_O__O(self, s__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_25.GetRawRoot__O()).Invoke_O__O(s__0); if
										jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var target_28 any = s__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_spec_alpha_Specize_A_InstanceOf(target_28); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_28) }; tmp1 = tmp2; if tmp1 { return A_arbace_spec_alpha_Specize_A_Cast(target_28).Specize_STAR___O() } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_36.GetRawRoot__O()).Invoke_O__O(target_28) } } }


func A_arbace_spec_alpha_invalid_QMARK__A_New() *A_arbace_spec_alpha_invalid_QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_invalid_QMARK__A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_spec_alpha_invalid_QMARK__A) Ctor() {}
//line :166:1
func (t *A_arbace_spec_alpha_invalid_QMARK__A) Invoke_O_O__O(self, ret__0 any) any {


	return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(A_arbace_spec_alpha_A_const_42, ret__0)).Ref()
}
func A_arbace_spec_alpha_conform_A_New() *A_arbace_spec_alpha_conform_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_conform_A{}; t.Ctor(); return t }
//line :171:1
func (t *A_arbace_spec_alpha_conform_A) Ctor() {}
//line :171:1
func (t *A_arbace_spec_alpha_conform_A) Invoke_O_O_O__O(self, spec__0, x__1 any) any {



	var target_29 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_43.GetRawRoot__O()).Invoke_O__O(spec__0); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_29); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_29) }; tmp1 = tmp2; if tmp1 { return A_arbace_spec_alpha_Spec_A_Cast(target_29).Conform_STAR__O__O(x__1) } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_29, x__1)
	} }
func A_arbace_spec_alpha_unform_A_New() *A_arbace_spec_alpha_unform_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_unform_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_spec_alpha_unform_A) Ctor() {}
//line :177:1
func (t *A_arbace_spec_alpha_unform_A) Invoke_O_O_O__O(self, spec__0, x__1 any) any {




	var target_30 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_43.GetRawRoot__O()).Invoke_O__O(spec__0); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_30); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_30) }; tmp1 = tmp2; if tmp1 { return A_arbace_spec_alpha_Spec_A_Cast(target_30).Unform_STAR__O__O(x__1) } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_45.GetRawRoot__O()).Invoke_O_O__O(target_30, x__1)
	} }
func A_arbace_spec_alpha_form_A_New() *A_arbace_spec_alpha_form_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_form_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_spec_alpha_form_A) Ctor() {}
//line :184:1
func (t *A_arbace_spec_alpha_form_A) Invoke_O_O__O(self, spec__0 any) any {



	var target_31 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_43.GetRawRoot__O()).Invoke_O__O(spec__0); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_31); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_31) }; tmp1 = tmp2; if tmp1 { return A_arbace_spec_alpha_Spec_A_Cast(target_31).Describe_STAR___O() } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_46.GetRawRoot__O()).Invoke_O__O(target_31)
	} }
func A_arbace_spec_alpha_abbrev_A_New() *A_arbace_spec_alpha_abbrev_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_abbrev_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_spec_alpha_abbrev_A) Ctor() {}
//line :190:1
func (t *A_arbace_spec_alpha_abbrev_A) Invoke_O_O__O(self, form__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_47.GetRawRoot__O()).Invoke_O__O(form__0)) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_48.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_abbrev_fn__1740000170_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_spec_alpha_abbrev_fn__1740000170_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_spec_alpha_abbrev_fn__1740000170_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), form__0) } else {
//line :191:1
			var tmp4 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_49.GetRawRoot__O()).Invoke_O__O(form__0)












			if jrt.J2g_Truth(and__1927000168__auto____2) { tmp4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_50.GetRawRoot__O()).Invoke_O__O(form__0) } else { tmp4 = and__1927000168__auto____2 }
//line :191:1
			if jrt.J2g_Truth(tmp4) {













				return lang.IFn_Cast(A_arbace_spec_alpha_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_57.GetRawRoot__O()).Invoke_O__O(form__0)) } else {
//line :191:1
					if A_arbace_spec_alpha_A_const_51 != nil { return form__0 } else { return nil
					} } } }
func A_arbace_spec_alpha_abbrev_fn__1740000170_A_New() *A_arbace_spec_alpha_abbrev_fn__1740000170_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_abbrev_fn__1740000170_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_spec_alpha_abbrev_fn__1740000170_A) Ctor() {}
//line :193:1
func (t *A_arbace_spec_alpha_abbrev_fn__1740000170_A) Invoke_O_O__O(self, form__1 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_49.GetRawRoot__O()).Invoke_O__O(form__1)
	if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_50.GetRawRoot__O()).Invoke_O__O(form__1) } else { tmp1 = and__1927000168__auto____2 }
//line :194:1
	if jrt.J2g_Truth(tmp1) {

		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_33.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_57.GetRawRoot__O()).Invoke_O__O(form__1)) } else {
//line :194:1
			var tmp2 any; var and__1927000168__auto____2_2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_47.GetRawRoot__O()).Invoke_O__O(form__1)



			if jrt.J2g_Truth(and__1927000168__auto____2_2) { var tmp3 any = A_arbace_spec_alpha_A_const_52; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(form__1)); if and__1927000168__auto____3 { var tmp4 any = A_arbace_spec_alpha_A_const_54; tmp2 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_spec_alpha_A_const_55.GetRawRoot__O()).Invoke_O__O(form__1))).Ref() } else { tmp2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { tmp2 = and__1927000168__auto____2_2 }
//line :194:1
			if jrt.J2g_Truth(tmp2) {




				return lang.IFn_Cast(A_arbace_spec_alpha_A_const_56.GetRawRoot__O()).Invoke_O__O(form__1) } else {
//line :194:1
					if A_arbace_spec_alpha_A_const_51 != nil { return form__1 } else { return nil
					}
				}
		}
}










func A_arbace_spec_alpha_describe_A_New() *A_arbace_spec_alpha_describe_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_describe_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_spec_alpha_describe_A) Ctor() {}
//line :209:1
func (t *A_arbace_spec_alpha_describe_A) Invoke_O_O__O(self, spec__0 any) any {


	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_59.GetRawRoot__O()).Invoke_O__O(spec__0))
}
func A_arbace_spec_alpha_with_gen_A_New() *A_arbace_spec_alpha_with_gen_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_with_gen_A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_spec_alpha_with_gen_A) Ctor() {}
//line :214:1
func (t *A_arbace_spec_alpha_with_gen_A) Invoke_O_O_O__O(self, spec__0, gen_fn__1 any) any { var spec__3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(spec__0); if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_21.GetRawRoot__O()).Invoke_O__O(spec__3)) {
		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(spec__3, A_arbace_spec_alpha_A_const_61, gen_fn__1) } else {
			var target_33 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_43.GetRawRoot__O()).Invoke_O__O(spec__3); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_33); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_33) }; tmp1 = tmp2; if tmp1 { return A_arbace_spec_alpha_Spec_A_Cast(target_33).With_gen_STAR__O__O(gen_fn__1) } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_60.GetRawRoot__O()).Invoke_O_O__O(target_33, gen_fn__1) } } }

func A_arbace_spec_alpha_explain_data_STAR__A_New() *A_arbace_spec_alpha_explain_data_STAR__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_explain_data_STAR__A{}; t.Ctor(); return t }
//line :222:1
func (t *A_arbace_spec_alpha_explain_data_STAR__A) Ctor() {}
//line :222:1
func (t *A_arbace_spec_alpha_explain_data_STAR__A) Invoke_O_O_O_O_O_O__O(self, spec__0, path__1, via__2, in__3, x__4 any) any { var probs__6 any; var target_34 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_43.GetRawRoot__O()).Invoke_O__O(spec__0); var tmp1 bool; var tmp2 bool; tmp2 =
																A_arbace_spec_alpha_Spec_A_InstanceOf(target_34); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_34) }; tmp1 = tmp2; if tmp1 { probs__6 = A_arbace_spec_alpha_Spec_A_Cast(target_34).Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, x__4) } else { probs__6 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_62.GetRawRoot__O()).Invoke_O_O_O_O_O__O(target_34, path__1, via__2, in__3, x__4) }; if
																jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(probs__6)) { return nil } else { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_64, probs__6, A_arbace_spec_alpha_A_const_65, spec__0, A_arbace_spec_alpha_A_const_66, x__4)) } }




func A_arbace_spec_alpha_explain_data_A_New() *A_arbace_spec_alpha_explain_data_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_explain_data_A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_spec_alpha_explain_data_A) Ctor() {}
//line :229:1
func (t *A_arbace_spec_alpha_explain_data_A) Invoke_O_O_O__O(self, spec__0, x__1 any) any {






	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_67.GetRawRoot__O()); var tmp2 *lang.PersistentVector; lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 lang.IPersistentVector; var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_28.GetRawRoot__O()).Invoke_O__O(spec__0); if jrt.J2g_Truth(temp__1927000408__auto____3) { var name__4 any = temp__1927000408__auto____3; tmp4 = lang.Tuple_Create_O__IPersistentVector(name__4) } else { lang.PersistentVector_Init(); tmp4 = Up_PersistentVector_IPersistentVector(lang.PersistentVector_EMPTY) }; var tmp5 any = tmp4; var tmp6 *lang.PersistentVector; lang.PersistentVector_Init(); tmp6 = lang.PersistentVector_EMPTY; return tmp1.Invoke_O_O_O_O_O__O(spec__0, tmp3, tmp5, tmp6.Ref(), x__1)
}
func A_arbace_spec_alpha_explain_printer_A_New() *A_arbace_spec_alpha_explain_printer_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_explain_printer_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_spec_alpha_explain_printer_A) Ctor() {}
//line :238:1
func (t *A_arbace_spec_alpha_explain_printer_A) Invoke_O_O__O(self, ed__0 any) any {


	if jrt.J2g_Truth(ed__0) { var problems__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_68.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_explain_printer_fn__1740000179_A_New(); var tmp3 *jrt.Class
		var fncls__35 /*line :241:1*/*jrt.Class = A_arbace_spec_alpha_explain_printer_fn__1740000179_A_fn_class


		if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_spec_alpha_explain_printer_fn__1740000179_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_68.GetRawRoot__O()); var tmp6 any = A_arbace_spec_alpha_explain_printer_fn__1740000181_A_New(); var tmp7 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_spec_alpha_explain_printer_fn__1740000181_A_fn_class
//line :243:1
		if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_spec_alpha_explain_printer_fn__1740000181_A_fn_class = fncls__36d; tmp7 = fncls__36d } else { tmp7 = fncls__36 }
		problems__2 = tmp1.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), A_arbace_spec_alpha_A_const_64.Invoke_O__O(ed__0)))
//line :241:1
		var seq_1740000183__3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(problems__2); var chunk_1740000184__4 any; var count_1740000185__5 int64 = 0; var i_1740000186__6 int64 = 0; L1: for {




			if lang.Numbers_Lt_J_J__Z(i_1740000186__6, count_1740000185__5) { var map__1740000187__7 any = lang.Indexed_Cast(chunk_1740000184__4).Nth_I__O(lang.RT_IntCast_J__I(i_1740000186__6)); var map__1740000187__8 any; if lang.ISeq_InstanceOf(map__1740000187__7) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000187__7)) { map__1740000187__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000187__7), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000187__7)) { map__1740000187__8 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000187__7) } else { lang.PersistentArrayMap_Init(); map__1740000187__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000187__8 = map__1740000187__7 }; var prob__9 any = map__1740000187__8; var path__10 any = lang.RT_Get_O_O__O(map__1740000187__8, A_arbace_spec_alpha_A_const_72); var pred__11 any = lang.RT_Get_O_O__O(map__1740000187__8, A_arbace_spec_alpha_A_const_73); var val__12 any = lang.RT_Get_O_O__O(map__1740000187__8, A_arbace_spec_alpha_A_const_74); var reason__13 any = lang.RT_Get_O_O__O(map__1740000187__8, A_arbace_spec_alpha_A_const_75); var via__14 any = lang.RT_Get_O_O__O(map__1740000187__8, A_arbace_spec_alpha_A_const_76); var in__15 any = lang.RT_Get_O_O__O(map__1740000187__8, A_arbace_spec_alpha_A_const_77)
				lang.IFn_Cast(A_arbace_spec_alpha_A_const_82.Get__O()).Invoke_O__O(val__12)
				lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O__O(Lit_58)
				if jrt.J2g_Truth(reason__13) { lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O__O(reason__13) } else { lang.IFn_Cast(A_arbace_spec_alpha_A_const_82.Get__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_58.GetRawRoot__O()).Invoke_O__O(pred__11)) }
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(in__15)) { } else {
					lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(in__15))).Ref()) }
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(path__10)) { } else {
					lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_60, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(path__10))).Ref()) }
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(via__14)) { } else {
					lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_56.GetRawRoot__O()).Invoke_O__O(via__14)))).Ref()) }
//line :246:1
				var seq_1740000189__16 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(prob__9); var chunk_1740000190__17 any; var count_1740000191__18 int64 = 0; var i_1740000192__19 int64 = 0; L2: for {









					if lang.Numbers_Lt_J_J__Z(i_1740000192__19, count_1740000191__18) { var vec__1740000193__20 any = lang.Indexed_Cast(chunk_1740000190__17).Nth_I__O(lang.RT_IntCast_J__I(i_1740000192__19)); var k__21 any = lang.RT_Nth_O_I_O__O(vec__1740000193__20, lang.RT_IntCast_J__I(0), nil); var v__22 any = lang.RT_Nth_O_I_O__O(vec__1740000193__20, lang.RT_IntCast_J__I(1), nil)
						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_85).Invoke_O__O(k__21)) { } else {
							lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O_O_O__O(Lit_62, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(k__21), Lit_63)
							lang.IFn_Cast(A_arbace_spec_alpha_A_const_82.Get__O()).Invoke_O__O(v__22) }
//line :256:1
						seq_1740000189__16, chunk_1740000190__17, count_1740000191__18, i_1740000192__19 = seq_1740000189__16, chunk_1740000190__17, count_1740000191__18, lang.Numbers_Unchecked_inc_J__J(i_1740000192__19); continue L2 } else { var temp__1927000414__auto____20 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(seq_1740000189__16); if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1740000189__21 any = temp__1927000414__auto____20; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1740000189__21)) { var c__1927000678__auto____22 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_79.GetRawRoot__O()).Invoke_O__O(seq_1740000189__21); seq_1740000189__16, chunk_1740000190__17, count_1740000191__18, i_1740000192__19 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_86.GetRawRoot__O()).Invoke_O__O(seq_1740000189__21), c__1927000678__auto____22, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var vec__1740000196__22 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_1740000189__21); var k__23 any = lang.RT_Nth_O_I_O__O(vec__1740000196__22, lang.RT_IntCast_J__I(0), nil); var v__24 any = lang.RT_Nth_O_I_O__O(vec__1740000196__22, lang.RT_IntCast_J__I(1), nil)
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_87).Invoke_O__O(k__23)) { } else {
								lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O_O_O__O(Lit_62, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(k__23), Lit_63)
								lang.IFn_Cast(A_arbace_spec_alpha_A_const_82.Get__O()).Invoke_O__O(v__24) }
//line :256:1
							seq_1740000189__16, chunk_1740000190__17, count_1740000191__18, i_1740000192__19 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq_1740000189__21), nil, 0, 0; continue L2 } } }
//line :246:1
					break L2
				}












				lang.IFn_Cast(A_arbace_spec_alpha_A_const_81.GetRawRoot__O()).Invoke__O()
//line :246:1
				seq_1740000183__3, chunk_1740000184__4, count_1740000185__5, i_1740000186__6 = seq_1740000183__3, chunk_1740000184__4, count_1740000185__5, lang.Numbers_Unchecked_inc_J__J(i_1740000186__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(seq_1740000183__3); if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1740000183__8 any = temp__1927000414__auto____7; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1740000183__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_79.GetRawRoot__O()).Invoke_O__O(seq_1740000183__8); seq_1740000183__3, chunk_1740000184__4, count_1740000185__5, i_1740000186__6 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_86.GetRawRoot__O()).Invoke_O__O(seq_1740000183__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var map__1740000199__9 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_1740000183__8); var map__1740000199__10 any; if lang.ISeq_InstanceOf(map__1740000199__9) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000199__9)) { map__1740000199__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000199__9), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000199__9)) { map__1740000199__10 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000199__9) } else { lang.PersistentArrayMap_Init(); map__1740000199__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000199__10 = map__1740000199__9 }; var prob__11 any = map__1740000199__10; var path__12 any = lang.RT_Get_O_O__O(map__1740000199__10, A_arbace_spec_alpha_A_const_72); var pred__13 any = lang.RT_Get_O_O__O(map__1740000199__10, A_arbace_spec_alpha_A_const_73); var val__14 any = lang.RT_Get_O_O__O(map__1740000199__10, A_arbace_spec_alpha_A_const_74); var reason__15 any = lang.RT_Get_O_O__O(map__1740000199__10, A_arbace_spec_alpha_A_const_75); var via__16 any = lang.RT_Get_O_O__O(map__1740000199__10, A_arbace_spec_alpha_A_const_76); var in__17 any = lang.RT_Get_O_O__O(map__1740000199__10, A_arbace_spec_alpha_A_const_77)
					lang.IFn_Cast(A_arbace_spec_alpha_A_const_82.Get__O()).Invoke_O__O(val__14)
					lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O__O(Lit_58)
					if jrt.J2g_Truth(reason__15) { lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O__O(reason__15) } else { lang.IFn_Cast(A_arbace_spec_alpha_A_const_82.Get__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_58.GetRawRoot__O()).Invoke_O__O(pred__13)) }
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(in__17)) { } else {
						lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_59, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(in__17))).Ref()) }
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(path__12)) { } else {
						lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_60, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(path__12))).Ref()) }
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(via__16)) { } else {
						lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_61, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_56.GetRawRoot__O()).Invoke_O__O(via__16)))).Ref()) }
//line :246:1
					var seq_1740000201__18 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(prob__11); var chunk_1740000202__19 any; var count_1740000203__20 int64 = 0; var i_1740000204__21 int64 = 0; L3: for {









						if lang.Numbers_Lt_J_J__Z(i_1740000204__21, count_1740000203__20) { var vec__1740000205__22 any = lang.Indexed_Cast(chunk_1740000202__19).Nth_I__O(lang.RT_IntCast_J__I(i_1740000204__21)); var k__23_2 any = lang.RT_Nth_O_I_O__O(vec__1740000205__22, lang.RT_IntCast_J__I(0), nil); var v__24_2 any = lang.RT_Nth_O_I_O__O(vec__1740000205__22, lang.RT_IntCast_J__I(1), nil)
							if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_88).Invoke_O__O(k__23_2)) { } else {
								lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O_O_O__O(Lit_62, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(k__23_2), Lit_63)
								lang.IFn_Cast(A_arbace_spec_alpha_A_const_82.Get__O()).Invoke_O__O(v__24_2) }
//line :256:1
							seq_1740000201__18, chunk_1740000202__19, count_1740000203__20, i_1740000204__21 = seq_1740000201__18, chunk_1740000202__19, count_1740000203__20, lang.Numbers_Unchecked_inc_J__J(i_1740000204__21); continue L3 } else { var temp__1927000414__auto____22 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(seq_1740000201__18); if jrt.J2g_Truth(temp__1927000414__auto____22) { var seq_1740000201__23 any = temp__1927000414__auto____22; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1740000201__23)) { var c__1927000678__auto____24 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_79.GetRawRoot__O()).Invoke_O__O(seq_1740000201__23); seq_1740000201__18, chunk_1740000202__19, count_1740000203__20, i_1740000204__21 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_86.GetRawRoot__O()).Invoke_O__O(seq_1740000201__23), c__1927000678__auto____24, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____24))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var vec__1740000208__24 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq_1740000201__23); var k__25 any = lang.RT_Nth_O_I_O__O(vec__1740000208__24, lang.RT_IntCast_J__I(0), nil); var v__26 any = lang.RT_Nth_O_I_O__O(vec__1740000208__24, lang.RT_IntCast_J__I(1), nil)
								if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_89).Invoke_O__O(k__25)) { } else {
									lang.IFn_Cast(A_arbace_spec_alpha_A_const_83.GetRawRoot__O()).Invoke_O_O_O__O(Lit_62, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(k__25), Lit_63)
									lang.IFn_Cast(A_arbace_spec_alpha_A_const_82.Get__O()).Invoke_O__O(v__26) }
//line :256:1
								seq_1740000201__18, chunk_1740000202__19, count_1740000203__20, i_1740000204__21 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq_1740000201__23), nil, 0, 0; continue L3 } } }
//line :246:1
						break L3
					}












					lang.IFn_Cast(A_arbace_spec_alpha_A_const_81.GetRawRoot__O()).Invoke__O()
//line :246:1
					seq_1740000183__3, chunk_1740000184__4, count_1740000185__5, i_1740000186__6 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq_1740000183__8), nil, 0, 0; continue L1 } } else { return nil } } } } else {














						return lang.IFn_Cast(A_arbace_spec_alpha_A_const_80.GetRawRoot__O()).Invoke_O__O(Lit_64) }
//line :238:1
	panic("j2g: unreachable")
}



func A_arbace_spec_alpha_explain_printer_fn__1740000181_A_New() *A_arbace_spec_alpha_explain_printer_fn__1740000181_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_explain_printer_fn__1740000181_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_spec_alpha_explain_printer_fn__1740000181_A) Ctor() {}
//line :243:1
func (t *A_arbace_spec_alpha_explain_printer_fn__1740000181_A) Invoke_O_O__O(self, p1__1740000177_SHARP___1 any) any { return jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J__J(int64(lang.RT_Count_O__I(A_arbace_spec_alpha_A_const_77.Invoke_O__O(p1__1740000177_SHARP___1))))).Ref() }
func A_arbace_spec_alpha_explain_printer_fn__1740000179_A_New() *A_arbace_spec_alpha_explain_printer_fn__1740000179_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_explain_printer_fn__1740000179_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_spec_alpha_explain_printer_fn__1740000179_A) Ctor() {}
//line :244:1
func (t *A_arbace_spec_alpha_explain_printer_fn__1740000179_A) Invoke_O_O__O(self, p1__1740000178_SHARP___1 any) any { return jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J__J(int64(lang.RT_Count_O__I(A_arbace_spec_alpha_A_const_72.Invoke_O__O(p1__1740000178_SHARP___1))))).Ref() }




















func A_arbace_spec_alpha_explain_out_A_New() *A_arbace_spec_alpha_explain_out_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_explain_out_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_spec_alpha_explain_out_A) Ctor() {}
//line :265:1
func (t *A_arbace_spec_alpha_explain_out_A) Invoke_O_O__O(self, ed__0 any) any {



	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_90.Get__O()).Invoke_O__O(ed__0)
}
func A_arbace_spec_alpha_explain_A_New() *A_arbace_spec_alpha_explain_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_explain_A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_spec_alpha_explain_A) Ctor() {}
//line :271:1
func (t *A_arbace_spec_alpha_explain_A) Invoke_O_O_O__O(self, spec__0, x__1 any) any {


	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_91.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_92.GetRawRoot__O()).Invoke_O_O__O(spec__0, x__1))
}
func A_arbace_spec_alpha_explain_str_A_New() *A_arbace_spec_alpha_explain_str_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_explain_str_A{}; t.Ctor(); return t }
//line :276:1
func (t *A_arbace_spec_alpha_explain_str_A) Ctor() {}
//line :276:1
func (t *A_arbace_spec_alpha_explain_str_A) Invoke_O_O_O__O(self, spec__0, x__1 any) any { var s__1927001093__auto____3 any = jrt.StringWriter_New();


	lang.IFn_Cast(A_arbace_spec_alpha_A_const_95.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_96.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_97, s__1927001093__auto____3)); var tmp1 any; tmp2 := /*line :276:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


		lang.IFn_Cast(A_arbace_spec_alpha_A_const_98.GetRawRoot__O()).Invoke_O_O__O(spec__0, x__1); tmp1 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_93.GetRawRoot__O()).Invoke_O__O(s__1927001093__auto____3)
//line :276:1
		return nil }();


	lang.IFn_Cast(A_arbace_spec_alpha_A_const_94.GetRawRoot__O()).Invoke__O(); if /*line :276:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }






func A_arbace_spec_alpha_gensub_A_New() *A_arbace_spec_alpha_gensub_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_gensub_A{}; t.Ctor(); return t }
//line :283:1
func (t *A_arbace_spec_alpha_gensub_A) Ctor() {}
//line :283:1
func (t *A_arbace_spec_alpha_gensub_A) Invoke_O_O_O_O_O_O__O(self, spec__0, overrides__1, path__2, rmap__3, form__4 any) any { var spec__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_43.GetRawRoot__O()).Invoke_O__O(spec__0); var temp__1927000408__auto____7 any; var or__1927000174__auto____7 any; var temp__1927000414__auto____7 any; var or__1927000174__auto____7_2 any; var tmp1 any; var or__1927000174__auto____7_3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_28.GetRawRoot__O()).Invoke_O__O(spec__6); if



	jrt.J2g_Truth(or__1927000174__auto____7_3) { tmp1 = or__1927000174__auto____7_3 } else { tmp1 = spec__6 }; or__1927000174__auto____7_2 = lang.RT_Get_O_O__O(overrides__1, tmp1); if jrt.J2g_Truth(or__1927000174__auto____7_2) { temp__1927000414__auto____7 = or__1927000174__auto____7_2 } else {
		temp__1927000414__auto____7 = lang.RT_Get_O_O__O(overrides__1, path__2) }; if /*line :287:1*/ jrt.J2g_Truth(temp__1927000414__auto____7) { var gfn__8 any = temp__1927000414__auto____7

			or__1927000174__auto____7 = lang.IFn_Cast(gfn__8).Invoke__O() } else {
//line :287:1
				or__1927000174__auto____7 = nil }; if jrt.J2g_Truth(or__1927000174__auto____7) { temp__1927000408__auto____7 = or__1927000174__auto____7 } else {


					var target_37 any = spec__6; var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_37); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z(target_37) }; tmp2 = tmp3; if tmp2 { temp__1927000408__auto____7 = A_arbace_spec_alpha_Spec_A_Cast(target_37).Gen_STAR__O_O_O__O(overrides__1, path__2, rmap__3) } else { temp__1927000408__auto____7 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_99.GetRawRoot__O()).Invoke_O_O_O_O__O(target_37, overrides__1, path__2, rmap__3) } }; if /*line :287:1*/ jrt.J2g_Truth(temp__1927000408__auto____7) { var g__8 any = temp__1927000408__auto____7; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_100.GetRawRoot__O()); var tmp5 any = A_arbace_spec_alpha_gensub_fn__1740000216_A_New_O(spec__6); var tmp6 *jrt.Class
						var fncls__38 /*line :287:1*/*jrt.Class = A_arbace_spec_alpha_gensub_fn__1740000216_A_fn_class



						if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_73, false); A_arbace_spec_alpha_gensub_fn__1740000216_A_fn_class = fncls__38d; tmp6 = fncls__38d } else { tmp6 = fncls__38 }; return tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), g__8, A_arbace_spec_alpha_A_const_103) } else {
//line :287:1
							var abbr__8 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_58.GetRawRoot__O()).Invoke_O__O(form__4); panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_spec_alpha_A_const_101.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_74, nil, Lit_75, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__2, nil, abbr__8)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_104, path__2, A_arbace_spec_alpha_A_const_105, form__4, A_arbace_spec_alpha_A_const_106, A_arbace_spec_alpha_A_const_107)))))) } }



func A_arbace_spec_alpha_gensub_fn__1740000216_A_New_O(p0 any) *A_arbace_spec_alpha_gensub_fn__1740000216_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_gensub_fn__1740000216_A{}; t.Ctor_O(p0); return t }
//line :291:1
func (t *A_arbace_spec_alpha_gensub_fn__1740000216_A) Ctor_O(c__spec any) { t.F_spec = c__spec }
//line :291:1
func (t *A_arbace_spec_alpha_gensub_fn__1740000216_A) Invoke_O_O__O(self, p1__1740000215_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_102.GetRawRoot__O()).Invoke_O_O__O(t.F_spec, p1__1740000215_SHARP___1) }




func A_arbace_spec_alpha_gen_A_New() *A_arbace_spec_alpha_gen_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_gen_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_spec_alpha_gen_A) Ctor() {}
//line :296:1
func (t *A_arbace_spec_alpha_gen_A) Invoke_O_O_O__O(self, spec__0, overrides__1 any) any {










	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_108.GetRawRoot__O()); var tmp2 *lang.PersistentVector; lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 any = A_arbace_spec_alpha_A_const_109; return tmp1.Invoke_O_O_O_O_O__O(spec__0, overrides__1, tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, A_arbace_spec_alpha_A_const_110.Get__O())), spec__0) }
//line :296:1
func (t *A_arbace_spec_alpha_gen_A) Invoke_O_O__O(self, spec__0 any) any {









	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_111.GetRawRoot__O()).Invoke_O_O__O(spec__0, nil)
}

func A_arbace_spec_alpha___GT_sym_A_New() *A_arbace_spec_alpha___GT_sym_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha___GT_sym_A{}; t.Ctor(); return t }
//line :309:1
func (t *A_arbace_spec_alpha___GT_sym_A) Ctor() {}
//line :309:1
func (t *A_arbace_spec_alpha___GT_sym_A) Invoke_O_O__O(self, x__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_112.GetRawRoot__O()).Invoke_O__O(x__0)) {
		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_33.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :312:1
			return x__0
		}
}

func A_arbace_spec_alpha_unfn_A_New() *A_arbace_spec_alpha_unfn_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_unfn_A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_spec_alpha_unfn_A) Ctor() {}
//line :316:1
func (t *A_arbace_spec_alpha_unfn_A) Invoke_O_O__O(self, expr__0 any) any {
	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_47.GetRawRoot__O()).Invoke_O__O(expr__0); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(expr__0)); if jrt.J2g_Truth(and__1927000168__auto____3) {

		tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_141, lang.IFn_Cast(A_arbace_spec_alpha_A_const_57.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(expr__0)))).Ref() } else {
//line :317:1
			tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var vec__1740000221__2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_113.GetRawRoot__O()).Invoke_O__O(expr__0); var seq__1740000222__3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000221__2); var first__1740000223__4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000222__3); var seq__1740000222__5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000222__3); var vec__1740000224__6 any = first__1740000223__4; var s__7 any = lang.RT_Nth_O_I_O__O(vec__1740000224__6, lang.RT_IntCast_J__I(0), nil)
				var form__8 any = seq__1740000222__5


				return lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_114.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, s__7, A_arbace_spec_alpha_A_const_117)), form__8), A_arbace_spec_alpha_A_const_115, A_arbace_spec_alpha_A_const_116) } else {
//line :317:1
					return expr__0
				}
}




func A_arbace_spec_alpha_res_A_New() *A_arbace_spec_alpha_res_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_res_A{}; t.Ctor(); return t }
//line :324:1
func (t *A_arbace_spec_alpha_res_A) Ctor() {}
//line :324:1
func (t *A_arbace_spec_alpha_res_A) Invoke_O_O__O(self, form__0 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(form__0)) { return form__0 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_49.GetRawRoot__O()).Invoke_O__O(form__0)) { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_119.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_121.GetRawRoot__O()).Invoke_O__O(form__0))

		if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return form__0 } } else {
//line :325:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_120.GetRawRoot__O()).Invoke_O__O(form__0)) {


				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_48.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_res_fn__1740000229_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_spec_alpha_res_fn__1740000229_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_136, false); A_arbace_spec_alpha_res_fn__1740000229_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_spec_alpha_A_const_123.GetRawRoot__O()).Invoke_O__O(form__0)) } else {
//line :325:1
					if A_arbace_spec_alpha_A_const_51 != nil { return form__0 } else { return nil
					}
				} } } }
func A_arbace_spec_alpha_res_fn__1740000229_A_New() *A_arbace_spec_alpha_res_fn__1740000229_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_res_fn__1740000229_A{}; t.Ctor(); return t }
//line :328:1
func (t *A_arbace_spec_alpha_res_fn__1740000229_A) Ctor() {}
//line :328:1
func (t *A_arbace_spec_alpha_res_fn__1740000229_A) Invoke_O_O__O(self, p1__1740000228_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_49.GetRawRoot__O()).Invoke_O__O(p1__1740000228_SHARP___1)) { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(p1__1740000228_SHARP___1) } else { return p1__1740000228_SHARP___1 } }


func A_arbace_spec_alpha_def_impl_A_New() *A_arbace_spec_alpha_def_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_def_impl_A{}; t.Ctor(); return t }
//line :331:1
func (t *A_arbace_spec_alpha_def_impl_A) Ctor() {}
//line :331:1
func (t *A_arbace_spec_alpha_def_impl_A) Invoke_O_O_O_O__O(self, k__0, form__1, spec__2 any) any {


	var tmp1 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_15.GetRawRoot__O()).Invoke_O__O(k__0); if jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_50.GetRawRoot__O()).Invoke_O__O(k__0) } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_4, Lit_15, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_125))).Ref()))) }
	if lang.Util_Identical_O_O__Z(spec__2, nil) {
		lang.IFn_Cast(A_arbace_spec_alpha_A_const_124.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_spec_alpha_A_const_18.GetRawRoot__O(), A_arbace_spec_alpha_A_const_126.GetRawRoot__O(), k__0) } else {
//line :335:1
			var spec__4 any; var tmp2 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_25.GetRawRoot__O()).Invoke_O__O(spec__2)

			if jrt.J2g_Truth(or__1927000174__auto____4) { tmp2 = or__1927000174__auto____4 } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_21.GetRawRoot__O()).Invoke_O__O(spec__2); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp2 = or__1927000174__auto____5 } else { tmp2 = lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_18.GetRawRoot__O()), spec__2) } }; if jrt.J2g_Truth(tmp2) { spec__4 = spec__2 } else {

				spec__4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O__O(form__1, spec__2, nil, nil) }
			lang.IFn_Cast(A_arbace_spec_alpha_A_const_124.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_spec_alpha_A_const_18.GetRawRoot__O(), A_arbace_spec_alpha_A_const_22.GetRawRoot__O(), k__0, lang.IFn_Cast(A_arbace_spec_alpha_A_const_26.GetRawRoot__O()).Invoke_O_O__O(spec__4, k__0)) }
//line :331:1
	return k__0
}










func A_arbace_spec_alpha_ns_qualify_A_New() *A_arbace_spec_alpha_ns_qualify_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_ns_qualify_A{}; t.Ctor(); return t }
//line :343:1
func (t *A_arbace_spec_alpha_ns_qualify_A) Ctor() {}
//line :343:1
func (t *A_arbace_spec_alpha_ns_qualify_A) Invoke_O_O__O(self, s__0 any) any { var temp__1927000408__auto____2 any; var G__1740000233__2_ any = s__0; var G__1740000233__3_ any; if


	lang.Util_Identical_O_O__Z(G__1740000233__2_, nil) { G__1740000233__3_ = nil } else { G__1740000233__3_ = lang.IFn_Cast(A_arbace_spec_alpha_A_const_50.GetRawRoot__O()).Invoke_O__O(G__1740000233__2_) }; if lang.Util_Identical_O_O__Z(G__1740000233__3_, nil) { temp__1927000408__auto____2 = nil } else { temp__1927000408__auto____2 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_33.GetRawRoot__O()).Invoke_O__O(G__1740000233__3_) }; if jrt.J2g_Truth(temp__1927000408__auto____2) { var ns_sym__3 any = temp__1927000408__auto____2; var or__1927000174__auto____4 any; var G__1740000234__4_ any = lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_127.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_128.Get__O()), ns_sym__3); var G__1740000234__5_ any
		if lang.Util_Identical_O_O__Z(G__1740000234__4_, nil) { G__1740000234__5_ = nil } else { G__1740000234__5_ = lang.IFn_Cast(A_arbace_spec_alpha_A_const_93.GetRawRoot__O()).Invoke_O__O(G__1740000234__4_) }; if lang.Util_Identical_O_O__Z(G__1740000234__5_, nil) { or__1927000174__auto____4 = nil } else { or__1927000174__auto____4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_33.GetRawRoot__O()).Invoke_O_O__O(G__1740000234__5_, lang.IFn_Cast(A_arbace_spec_alpha_A_const_57.GetRawRoot__O()).Invoke_O__O(s__0)) }; if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return s__0 } } else {

			return lang.IFn_Cast(A_arbace_spec_alpha_A_const_33.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_93.GetRawRoot__O()).Invoke_O__O(lang.Namespace_Cast(A_arbace_spec_alpha_A_const_128.Get__O()).F_name.Ref()), lang.IFn_Cast(A_arbace_spec_alpha_A_const_93.GetRawRoot__O()).Invoke_O__O(s__0)) } }

func A_arbace_spec_alpha_def_A_New() *A_arbace_spec_alpha_def_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_def_A{}; t.Ctor(); return t }
//line :351:1
func (t *A_arbace_spec_alpha_def_A) Ctor() {}
//line :351:1
func (t *A_arbace_spec_alpha_def_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, k__2, spec_form__3 any) any { var k__5 any; if





	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_49.GetRawRoot__O()).Invoke_O__O(k__2)) { k__5 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_129.GetRawRoot__O()).Invoke_O__O(k__2) } else { k__5 = k__2 }; return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_132), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(k__5)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(spec_form__3))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(spec_form__3))) }


func A_arbace_spec_alpha_registry_A_New() *A_arbace_spec_alpha_registry_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_registry_A{}; t.Ctor(); return t }
//line :360:1
func (t *A_arbace_spec_alpha_registry_A) Ctor() {}
//line :360:1
func (t *A_arbace_spec_alpha_registry_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_18.GetRawRoot__O()) }




func A_arbace_spec_alpha_get_spec_A_New() *A_arbace_spec_alpha_get_spec_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_get_spec_A{}; t.Ctor(); return t }
//line :365:1
func (t *A_arbace_spec_alpha_get_spec_A) Ctor() {}
//line :365:1
func (t *A_arbace_spec_alpha_get_spec_A) Invoke_O_O__O(self, k__0 any) any {


	var tmp1 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_134.GetRawRoot__O()).Invoke__O(); var tmp2 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(k__0)) { tmp2 = k__0 } else { tmp2 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_119.GetRawRoot__O()).Invoke_O__O(k__0) }; return lang.RT_Get_O_O__O(tmp1, tmp2)
}
func A_arbace_spec_alpha_spec_A_New() *A_arbace_spec_alpha_spec_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_spec_A{}; t.Ctor(); return t }
//line :370:1
func (t *A_arbace_spec_alpha_spec_A) Ctor() {}
//line :370:1
func (t *A_arbace_spec_alpha_spec_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, form__2, p__1740000243__3 any) any { var map__1740000244__5 any = p__1740000243__3; var map__1740000244__6 any; if lang.ISeq_InstanceOf(map__1740000244__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000244__5)) { map__1740000244__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000244__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000244__5)) { map__1740000244__6 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000244__5) } else { lang.PersistentArrayMap_Init(); map__1740000244__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000244__6 = map__1740000244__5 }; var gen__7 any = lang.RT_Get_O_O__O(map__1740000244__6, A_arbace_spec_alpha_A_const_135); if















	jrt.J2g_Truth(form__2) { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_136), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(form__2))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(form__2), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(gen__7), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(nil))) } else { return nil } }


func A_arbace_spec_alpha_multi_spec_A_New() *A_arbace_spec_alpha_multi_spec_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_multi_spec_A{}; t.Ctor(); return t }
//line :389:1
func (t *A_arbace_spec_alpha_multi_spec_A) Ctor() {}
//line :389:1
func (t *A_arbace_spec_alpha_multi_spec_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, mm__2, retag__3 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_137), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(mm__2))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_138), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(mm__2)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(retag__3))) }




























func A_arbace_spec_alpha_keys_A_New() *A_arbace_spec_alpha_keys_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_keys_A{}; t.Ctor(); return t }
//line :418:1
func (t *A_arbace_spec_alpha_keys_A) Ctor() {}
//line :418:1
func (t *A_arbace_spec_alpha_keys_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, p__1740000258__2 any) any { var map__1740000259__4 any = p__1740000258__2; var map__1740000259__5 any; if lang.ISeq_InstanceOf(map__1740000259__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000259__4)) { map__1740000259__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000259__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000259__4)) { map__1740000259__5 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000259__4) } else { lang.PersistentArrayMap_Init(); map__1740000259__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000259__5 = map__1740000259__4 }; var req__6 any = lang.RT_Get_O_O__O(map__1740000259__5, A_arbace_spec_alpha_A_const_139); var req_un__7 any = lang.RT_Get_O_O__O(map__1740000259__5, A_arbace_spec_alpha_A_const_140); var opt__8 any = lang.RT_Get_O_O__O(map__1740000259__5, A_arbace_spec_alpha_A_const_141); var opt_un__9 any = lang.RT_Get_O_O__O(map__1740000259__5, A_arbace_spec_alpha_A_const_142); var gen__10 any = lang.RT_Get_O_O__O(map__1740000259__5, A_arbace_spec_alpha_A_const_135); var unk__11 any; var tmp1 any = A_arbace_spec_alpha_keys_unk__1740000261_A_New(); var tmp2 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_spec_alpha_keys_unk__1740000261_A_fn_class; if




























	fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_76, false); A_arbace_spec_alpha_keys_unk__1740000261_A_fn_class = fncls__40d; tmp2 = fncls__40d } else { tmp2 = fncls__40 }; unk__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var req_keys__12 any = /*line :418:1*/lang.IFn_Cast(A_arbace_spec_alpha_A_const_144.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_118.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_152.GetRawRoot__O()).Invoke_O__O(req__6)); var req_un_specs__13 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_144.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_118.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_152.GetRawRoot__O()).Invoke_O__O(req_un__7)); var ___14 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_145.GetRawRoot__O()); var tmp4 any = A_arbace_spec_alpha_keys_fn__1740000263_A_New(); var tmp5 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_spec_alpha_keys_fn__1740000263_A_fn_class; _ = ___14; if































	fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); A_arbace_spec_alpha_keys_fn__1740000263_A_fn_class = fncls__44d; tmp5 = fncls__44d } else { tmp5 = fncls__44 }; if jrt.J2g_Truth(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(req_keys__12, req_un_specs__13, opt__8, opt_un__9))) { ___14 = nil } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_4, Lit_78, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_153))).Ref()))) }; var req_specs__15 any = /*line :418:1*/lang.IFn_Cast(A_arbace_spec_alpha_A_const_146.GetRawRoot__O()).Invoke_O_O__O(req_keys__12, req_un_specs__13); var req_keys__16 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_146.GetRawRoot__O()).Invoke_O_O__O(req_keys__12, lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()).Invoke_O_O__O(unk__11, req_un_specs__13)); var opt_keys__17 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_146.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_154.GetRawRoot__O()).Invoke_O__O(opt__8), lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()).Invoke_O_O__O(unk__11, opt_un__9)); var opt_specs__18 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_146.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_154.GetRawRoot__O()).Invoke_O__O(opt__8), opt_un__9); var gx__19 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_147.GetRawRoot__O()).Invoke__O(); var parse_req__20 any; var tmp6 any = A_arbace_spec_alpha_keys_parse_req__1740000265_A_New_O(gx__19); var tmp7 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_spec_alpha_keys_parse_req__1740000265_A_fn_class; if






































	fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_79, false); A_arbace_spec_alpha_keys_parse_req__1740000265_A_fn_class = fncls__43d; tmp7 = fncls__43d } else { tmp7 = fncls__43 }; parse_req__20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var pred_exprs__21 any = /*line :418:1*/lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_155), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(gx__19)))); var pred_exprs__22 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_146.GetRawRoot__O()).Invoke_O_O__O(pred_exprs__21, lang.IFn_Cast(parse_req__20).Invoke_O_O__O(req__6, A_arbace_spec_alpha_A_const_156.GetRawRoot__O())); var pred_exprs__23 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_146.GetRawRoot__O()).Invoke_O_O__O(pred_exprs__22, lang.IFn_Cast(parse_req__20).Invoke_O_O__O(req_un__7, unk__11)); var keys_pred__24 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_157), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(gx__19))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_160), pred_exprs__23))))); var pred_exprs__25 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()); var tmp9 any = A_arbace_spec_alpha_keys_fn__1740000271_A_New_O(gx__19); var tmp10 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_spec_alpha_keys_fn__1740000271_A_fn_class; if


















































	fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_spec_alpha_keys_fn__1740000271_A_fn_class = fncls__45d; tmp10 = fncls__45d } else { tmp10 = fncls__45 }; pred_exprs__25 = tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), pred_exprs__23); var pred_forms__26 any = /*line :418:1*/lang.IFn_Cast(A_arbace_spec_alpha_A_const_48.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_122.GetRawRoot__O(), pred_exprs__25); return /*line :447:1*/ lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_162), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_96.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).ApplyTo_ISeq__O(Up_ArraySeq_ISeq(lang.ArraySeq_Create_O1__ArraySeq(jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_139), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(req__6)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_141), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(opt__8)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_140), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(req_un__7)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_142), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(opt_un__9)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_163), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(req_keys__16)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_164), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(req_specs__15)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_165), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(opt_keys__17)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_166), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(opt_specs__18)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_167), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pred_forms__26)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_168), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pred_exprs__25), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_169), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(keys_pred__24), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_170), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(gen__10)))))))))) }
//line :447:1
func A_arbace_spec_alpha_keys_unk__1740000261_A_New() *A_arbace_spec_alpha_keys_unk__1740000261_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_keys_unk__1740000261_A{}; t.Ctor(); return t }
//line :447:1
func (t *A_arbace_spec_alpha_keys_unk__1740000261_A) Ctor() {}
//line :447:1
func (t *A_arbace_spec_alpha_keys_unk__1740000261_A) Invoke_O_O__O(self, p1__1740000256_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_143.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_57.GetRawRoot__O()).Invoke_O__O(p1__1740000256_SHARP___1)) }


func A_arbace_spec_alpha_keys_fn__1740000263_A_New() *A_arbace_spec_alpha_keys_fn__1740000263_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_keys_fn__1740000263_A{}; t.Ctor(); return t }
//line :450:1
func (t *A_arbace_spec_alpha_keys_fn__1740000263_A) Ctor() {}
//line :450:1
func (t *A_arbace_spec_alpha_keys_fn__1740000263_A) Invoke_O_O__O(self, p1__1740000257_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(p1__1740000257_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_50.GetRawRoot__O()).Invoke_O__O(p1__1740000257_SHARP___1) } else { return and__1927000168__auto____2 } }






func A_arbace_spec_alpha_keys_parse_req__1740000265_A_New_O(p0 any) *A_arbace_spec_alpha_keys_parse_req__1740000265_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_keys_parse_req__1740000265_A{}; t.Ctor_O(p0); return t }
//line :457:1
func (t *A_arbace_spec_alpha_keys_parse_req__1740000265_A) Ctor_O(c__gx any) { t.F_gx = c__gx }
//line :457:1
func (t *A_arbace_spec_alpha_keys_parse_req__1740000265_A) Invoke_O_O_O__O(self, rk__1, f__2 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_New_O_O(f__2, t.F_gx); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), rk__1) }
//line :458:1
func A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A{}; t.Ctor_O_O(p0, p1); return t }
//line :458:1
func (t *A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A) Ctor_O_O(c__f, c__gx any) { t.F_f = c__f; t.F_gx = c__gx }
//line :458:1
func (t *A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A) Invoke_O_O__O(self, x__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(x__1)) { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_149), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(t.F_gx), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_f).Invoke_O__O(x__1)))) } else {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_48.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_New_O_O(t.F_f, t.F_gx); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_fn_class
		if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_82, false); A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }
//line :461:1
		return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), x__1) } }
func A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A{}; t.Ctor_O_O(p0, p1); return t }
//line :462:1
func (t *A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A) Ctor_O_O(c__f, c__gx any) { t.F_f = c__f; t.F_gx = c__gx }
//line :462:1
func (t *A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A) Invoke_O_O__O(self, y__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(y__1)) { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_150), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(t.F_gx), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_f).Invoke_O__O(y__1)))) } else { return y__1 } }






func A_arbace_spec_alpha_keys_fn__1740000271_A_New_O(p0 any) *A_arbace_spec_alpha_keys_fn__1740000271_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_keys_fn__1740000271_A{}; t.Ctor_O(p0); return t }
//line :469:1
func (t *A_arbace_spec_alpha_keys_fn__1740000271_A) Ctor_O(c__gx any) { t.F_gx = c__gx }
//line :469:1
func (t *A_arbace_spec_alpha_keys_fn__1740000271_A) Invoke_O_O__O(self, e__1 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_161), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(t.F_gx))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(e__1))) }










func A_arbace_spec_alpha_or_A_New() *A_arbace_spec_alpha_or_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_or_A{}; t.Ctor(); return t }
//line :480:1
func (t *A_arbace_spec_alpha_or_A) Ctor() {}
//line :480:1
func (t *A_arbace_spec_alpha_or_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, key_pred_forms__2 any) any { var pairs__4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_171.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_172, key_pred_forms__2); var keys__5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_53.GetRawRoot__O(), pairs__4); var pred_forms__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_55.GetRawRoot__O(), pairs__4); var pf__7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_122.GetRawRoot__O(), pred_forms__6); var tmp1 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_173.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(key_pred_forms__2)).Ref()); if













	jrt.J2g_Truth(and__1927000168__auto____8) { tmp1 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_145.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_118.GetRawRoot__O(), keys__5) } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_4, Lit_121, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_174))).Ref()))) }; return /*line :490:1*/ lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_175), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(keys__5), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pf__7)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pred_forms__6), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(nil))) }






func A_arbace_spec_alpha_and_A_New() *A_arbace_spec_alpha_and_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_and_A{}; t.Ctor(); return t }
//line :497:1
func (t *A_arbace_spec_alpha_and_A) Ctor() {}
//line :497:1
func (t *A_arbace_spec_alpha_and_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, pred_forms__2 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_176), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_122.GetRawRoot__O(), pred_forms__2))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_154.GetRawRoot__O()).Invoke_O__O(pred_forms__2)), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(nil))) }









func A_arbace_spec_alpha_merge_A_New() *A_arbace_spec_alpha_merge_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_merge_A{}; t.Ctor(); return t }
//line :507:1
func (t *A_arbace_spec_alpha_merge_A) Ctor() {}
//line :507:1
func (t *A_arbace_spec_alpha_merge_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, pred_forms__2 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_177), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_122.GetRawRoot__O(), pred_forms__2))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_154.GetRawRoot__O()).Invoke_O__O(pred_forms__2)), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(nil))) }







func A_arbace_spec_alpha_res_kind_A_New() *A_arbace_spec_alpha_res_kind_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_res_kind_A{}; t.Ctor(); return t }
//line :515:1
func (t *A_arbace_spec_alpha_res_kind_A) Ctor() {}
//line :515:1
func (t *A_arbace_spec_alpha_res_kind_A) Invoke_O_O__O(self, opts__0 any) any { var map__1740000293__2 any = opts__0; var map__1740000293__3 any; if

	lang.ISeq_InstanceOf(map__1740000293__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000293__2)) { map__1740000293__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000293__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000293__2)) { map__1740000293__3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000293__2) } else { lang.PersistentArrayMap_Init(); map__1740000293__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000293__3 = map__1740000293__2 }; var mopts__4 any = map__1740000293__3; var kind__5 any = /*line :515:1*/lang.RT_Get_O_O__O(map__1740000293__3, A_arbace_spec_alpha_A_const_178); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_179.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_A_const_156.GetRawRoot__O(); var tmp3 any; if



	jrt.J2g_Truth(kind__5) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()); var tmp5 any = A_arbace_spec_alpha_A_const_178; tmp3 = tmp4.Invoke_O_O_O__O(mopts__4, tmp5, lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(kind__5)) } else {
//line :519:1
			tmp3 = mopts__4 }; return /*line :522:1*/ tmp1.Invoke_O_O__O(tmp2, tmp3) }

func A_arbace_spec_alpha_every_A_New() *A_arbace_spec_alpha_every_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_A{}; t.Ctor(); return t }
//line :524:1
func (t *A_arbace_spec_alpha_every_A) Ctor() {}
//line :524:1
func (t *A_arbace_spec_alpha_every_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, pred__2, p__1740000296__3 any) any { var map__1740000297__5 any = p__1740000296__3; var map__1740000297__6 any; if lang.ISeq_InstanceOf(map__1740000297__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000297__5)) { map__1740000297__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000297__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000297__5)) { map__1740000297__6 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000297__5) } else { lang.PersistentArrayMap_Init(); map__1740000297__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000297__6 = map__1740000297__5 }; var opts__7 any = map__1740000297__6; var into__8 any = lang.RT_Get_O_O__O(map__1740000297__6, A_arbace_spec_alpha_A_const_180); var kind__9 any = lang.RT_Get_O_O__O(map__1740000297__6, A_arbace_spec_alpha_A_const_178); var count__10 any = lang.RT_Get_O_O__O(map__1740000297__6, A_arbace_spec_alpha_A_const_181); var max_count__11 any = lang.RT_Get_O_O__O(map__1740000297__6, A_arbace_spec_alpha_A_const_182); var min_count__12 any = lang.RT_Get_O_O__O(map__1740000297__6, A_arbace_spec_alpha_A_const_183); var distinct__13 any = lang.RT_Get_O_O__O(map__1740000297__6, A_arbace_spec_alpha_A_const_184); var gen_max__14 any = lang.RT_Get_O_O__O(map__1740000297__6, A_arbace_spec_alpha_A_const_185); var gen__15 any = lang.RT_Get_O_O__O(map__1740000297__6, A_arbace_spec_alpha_A_const_135); var desc__16 any = A_arbace_spec_alpha_A_const_186.Invoke_O__O(opts__7); var nopts__17 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_126.GetRawRoot__O()).Invoke_O_O_O__O(opts__7, A_arbace_spec_alpha_A_const_135, A_arbace_spec_alpha_A_const_186); var tmp3 any = A_arbace_spec_alpha_A_const_187; var tmp4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_178.Invoke_O__O(opts__7))))); var tmp5 any = A_arbace_spec_alpha_A_const_186; var tmp6 any; var or__1927000174__auto____17 any = desc__16; _ = into__8; _ = gen_max__14; if

































	jrt.J2g_Truth(or__1927000174__auto____17) { tmp6 = or__1927000174__auto____17 } else { tmp6 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_189), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(pred__2)), lang.IFn_Cast(A_arbace_spec_alpha_A_const_188.GetRawRoot__O()).Invoke_O__O(opts__7)))))) }; nopts__17 = /*line :557:1*/tmp1.Invoke_O_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5, tmp6); var gx__18 any = /*line :524:1*/lang.IFn_Cast(A_arbace_spec_alpha_A_const_147.GetRawRoot__O()).Invoke__O(); var cpreds__19 any; var G__1740000299__19_ any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()); var tmp8 any; var or__1927000174__auto____19 any = kind__9; if



































	jrt.J2g_Truth(or__1927000174__auto____19) { tmp8 = or__1927000174__auto____19 } else { tmp8 = A_arbace_spec_alpha_A_const_190 }; G__1740000299__19_ = /*line :524:1*/lang.Tuple_Create_O__IPersistentVector(tmp7.Invoke_O_O__O(tmp8, gx__18)); var G__1740000299__20_ any; if



































	jrt.J2g_Truth(count__10) {
		G__1740000299__20_ = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(G__1740000299__19_, lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_191), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(count__10), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_192), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(count__10), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(gx__18))))))) } else {
//line :560:1
			G__1740000299__20_ = G__1740000299__19_ }; var G__1740000299__21_ any; var tmp9 any; var or__1927000174__auto____21 any = min_count__12; if


	jrt.J2g_Truth(or__1927000174__auto____21) { tmp9 = or__1927000174__auto____21 } else { tmp9 = max_count__11 }; if /*line :560:1*/ jrt.J2g_Truth(tmp9) {



		G__1740000299__21_ = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(G__1740000299__20_, lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_193), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_194), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(min_count__12), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_195)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_196), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_197), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(max_count__11), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_198), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(max_count__11)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(min_count__12)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(gx__18)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_199), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(max_count__11), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_200))))))) } else {
//line :560:1
			G__1740000299__21_ = G__1740000299__20_ }; if jrt.J2g_Truth(distinct__13) {








				cpreds__19 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(G__1740000299__21_, lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_201), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_202), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(gx__18)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_203), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_204), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(gx__18))))))) } else {
//line :560:1
					cpreds__19 = G__1740000299__21_ }; var tmp10 lang.IFn = /*line :554:1*/lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()); var tmp11 any = A_arbace_spec_alpha_A_const_206; return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_205), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pred__2)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pred__2), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(tmp10.Invoke_O_O_O__O(nopts__17, tmp11, lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_207), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(gx__18))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_208), cpreds__19))))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(gen__15))) }

















func A_arbace_spec_alpha_every_kv_A_New() *A_arbace_spec_alpha_every_kv_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_kv_A{}; t.Ctor(); return t }
//line :572:1
func (t *A_arbace_spec_alpha_every_kv_A) Ctor() {}
//line :572:1
func (t *A_arbace_spec_alpha_every_kv_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, kpred__2, vpred__3, opts__4 any) any { var desc__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_209), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(kpred__2)), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(vpred__3)), lang.IFn_Cast(A_arbace_spec_alpha_A_const_188.GetRawRoot__O()).Invoke_O__O(opts__4))); return /*line :580:1*/ lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_210), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_211), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(kpred__2), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(vpred__3)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_212), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_213), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_214), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_215))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_216), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_215), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_195))))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_180), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_96.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke__O()))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_186), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(desc__6)))), opts__4)) }


func A_arbace_spec_alpha_coll_of_A_New() *A_arbace_spec_alpha_coll_of_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_coll_of_A{}; t.Ctor(); return t }
//line :583:1
func (t *A_arbace_spec_alpha_coll_of_A) Ctor() {}
//line :583:1
func (t *A_arbace_spec_alpha_coll_of_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, pred__2, opts__3 any) any { var desc__5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_217), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(pred__2)), lang.IFn_Cast(A_arbace_spec_alpha_A_const_188.GetRawRoot__O()).Invoke_O__O(opts__3))); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_218); var tmp4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pred__2); var tmp5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_219); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()); var tmp7 *jrt.Boolean;









	jrt.Boolean_Init(); tmp7 = jrt.Boolean_TRUE; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6.Invoke_O__O(tmp7.Ref()), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_186), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(desc__5)))), opts__3)) }


func A_arbace_spec_alpha_map_of_A_New() *A_arbace_spec_alpha_map_of_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_map_of_A{}; t.Ctor(); return t }
//line :596:1
func (t *A_arbace_spec_alpha_map_of_A) Ctor() {}
//line :596:1
func (t *A_arbace_spec_alpha_map_of_A) DoInvoke_O_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, kpred__2, vpred__3, opts__4 any) any { var desc__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_220), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(kpred__2)), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(vpred__3)), lang.IFn_Cast(A_arbace_spec_alpha_A_const_188.GetRawRoot__O()).Invoke_O__O(opts__4))); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_221); var tmp4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(kpred__2); var tmp5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(vpred__3); var tmp6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_219); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()); var tmp8 *jrt.Boolean;










	jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6, tmp7.Invoke_O__O(tmp8.Ref()), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_178), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_222), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_186), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(desc__6)))), opts__4)) }



func A_arbace_spec_alpha__STAR__A_New() *A_arbace_spec_alpha__STAR__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha__STAR__A{}; t.Ctor(); return t }
//line :611:1
func (t *A_arbace_spec_alpha__STAR__A) Ctor() {}
//line :611:1
func (t *A_arbace_spec_alpha__STAR__A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, pred_form__2 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_223), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(pred_form__2))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pred_form__2))) }





func A_arbace_spec_alpha__PLUS__A_New() *A_arbace_spec_alpha__PLUS__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha__PLUS__A{}; t.Ctor(); return t }
//line :617:1
func (t *A_arbace_spec_alpha__PLUS__A) Ctor() {}
//line :617:1
func (t *A_arbace_spec_alpha__PLUS__A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, pred_form__2 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_224), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(pred_form__2))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pred_form__2))) }





func A_arbace_spec_alpha__QMARK__A_New() *A_arbace_spec_alpha__QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha__QMARK__A{}; t.Ctor(); return t }
//line :623:1
func (t *A_arbace_spec_alpha__QMARK__A) Ctor() {}
//line :623:1
func (t *A_arbace_spec_alpha__QMARK__A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, pred_form__2 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_225), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pred_form__2), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(pred_form__2))))))) }





func A_arbace_spec_alpha_alt_A_New() *A_arbace_spec_alpha_alt_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_alt_A{}; t.Ctor(); return t }
//line :629:1
func (t *A_arbace_spec_alpha_alt_A) Ctor() {}
//line :629:1
func (t *A_arbace_spec_alpha_alt_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, key_pred_forms__2 any) any { var pairs__4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_171.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_172, key_pred_forms__2); var keys__5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_53.GetRawRoot__O(), pairs__4); var pred_forms__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_55.GetRawRoot__O(), pairs__4); var pf__7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_122.GetRawRoot__O(), pred_forms__6); var tmp1 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_173.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(key_pred_forms__2)).Ref()); if













	jrt.J2g_Truth(and__1927000168__auto____8) { tmp1 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_145.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_118.GetRawRoot__O(), keys__5) } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_4, Lit_5, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_226))).Ref()))) }; return /*line :639:1*/ lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_227), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(keys__5), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pred_forms__6), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pf__7)))))) }






func A_arbace_spec_alpha_cat_A_New() *A_arbace_spec_alpha_cat_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_cat_A{}; t.Ctor(); return t }
//line :646:1
func (t *A_arbace_spec_alpha_cat_A) Ctor() {}
//line :646:1
func (t *A_arbace_spec_alpha_cat_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, key_pred_forms__2 any) any { var pairs__4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_171.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_172, key_pred_forms__2); var keys__5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_53.GetRawRoot__O(), pairs__4); var pred_forms__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_55.GetRawRoot__O(), pairs__4); var pf__7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_122.GetRawRoot__O(), pred_forms__6); var tmp1 any; var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_173.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(key_pred_forms__2)).Ref()); if












	jrt.J2g_Truth(and__1927000168__auto____8) { tmp1 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_145.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_118.GetRawRoot__O(), keys__5) } else { tmp1 = and__1927000168__auto____8 }; if jrt.J2g_Truth(tmp1) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_4, Lit_14, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_228))).Ref()))) }; return /*line :654:1*/ lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_229), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(keys__5), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pred_forms__6), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pf__7)))))) }







func A_arbace_spec_alpha__AMPERSAND__A_New() *A_arbace_spec_alpha__AMPERSAND__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha__AMPERSAND__A{}; t.Ctor(); return t }
//line :662:1
func (t *A_arbace_spec_alpha__AMPERSAND__A) Ctor() {}
//line :662:1
func (t *A_arbace_spec_alpha__AMPERSAND__A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, re__2, preds__3 any) any { var pv__5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_154.GetRawRoot__O()).Invoke_O__O(preds__3); return /*line :667:1*/ lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_230), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(re__2), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(re__2))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pv__5), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_122.GetRawRoot__O(), pv__5))))))) }


func A_arbace_spec_alpha_conformer_A_New() *A_arbace_spec_alpha_conformer_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_conformer_A{}; t.Ctor(); return t }
//line :670:1
func (t *A_arbace_spec_alpha_conformer_A) Ctor() {}
//line :670:1
func (t *A_arbace_spec_alpha_conformer_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, f__2, unf__3 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_231); var tmp4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_232), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(f__2)), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(unf__3)))))))); var tmp5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(f__2); var tmp6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(nil); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6, tmp7.Invoke_O__O(tmp8.Ref()), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(unf__3))) }
//line :670:1
func (t *A_arbace_spec_alpha_conformer_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, f__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_233); var tmp4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_234), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(f__2)))))))); var tmp5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(f__2); var tmp6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(nil); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6, tmp7.Invoke_O__O(tmp8.Ref()))) }







func A_arbace_spec_alpha_fspec_A_New() *A_arbace_spec_alpha_fspec_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_fspec_A{}; t.Ctor(); return t }
//line :678:1
func (t *A_arbace_spec_alpha_fspec_A) Ctor() {}
//line :678:1
func (t *A_arbace_spec_alpha_fspec_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, p__1740000357__2 any) any { var default__1740000360__4 any = A_arbace_spec_alpha_A_const_235; var map__1740000358__5 any = p__1740000357__2; var map__1740000358__6 any; if lang.ISeq_InstanceOf(map__1740000358__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000358__5)) { map__1740000358__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000358__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000358__5)) { map__1740000358__6 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000358__5) } else { lang.PersistentArrayMap_Init(); map__1740000358__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000358__6 = map__1740000358__5 }; var args__7 any = lang.RT_Get_O_O__O(map__1740000358__6, A_arbace_spec_alpha_A_const_236); var ret__8 any = lang.RT_Get_O_O_O__O(map__1740000358__6, A_arbace_spec_alpha_A_const_237, default__1740000360__4); var fn__9 any = lang.RT_Get_O_O__O(map__1740000358__6, A_arbace_spec_alpha_A_const_238); var gen__10 any = lang.RT_Get_O_O__O(map__1740000358__6, A_arbace_spec_alpha_A_const_135); return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_239), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_240), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(args__7)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(args__7))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_241), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(ret__8)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(ret__8))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_242), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(fn__9)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(fn__9))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(gen__10))) }



















func A_arbace_spec_alpha_tuple_A_New() *A_arbace_spec_alpha_tuple_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_tuple_A{}; t.Ctor(); return t }
//line :698:1
func (t *A_arbace_spec_alpha_tuple_A) Ctor() {}
//line :698:1
func (t *A_arbace_spec_alpha_tuple_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, preds__2 any) any {




	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(preds__2))) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_243))).Ref()))) }
//line :698:1
	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_244), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_122.GetRawRoot__O(), preds__2))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_154.GetRawRoot__O()).Invoke_O__O(preds__2))))
}






func A_arbace_spec_alpha_macroexpand_check_A_New() *A_arbace_spec_alpha_macroexpand_check_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_macroexpand_check_A{}; t.Ctor(); return t }
//line :706:1
func (t *A_arbace_spec_alpha_macroexpand_check_A) Ctor() {}
//line :706:1
func (t *A_arbace_spec_alpha_macroexpand_check_A) Invoke_O_O_O__O(self, v__0, args__1 any) any { var fn_spec__3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_245.GetRawRoot__O()).Invoke_O__O(v__0); var temp__1927000414__auto____4 any = A_arbace_spec_alpha_A_const_236.Invoke_O__O(fn_spec__3); if


	jrt.J2g_Truth(temp__1927000414__auto____4) { var arg_spec__5 any = temp__1927000414__auto____4
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_247.GetRawRoot__O()).Invoke_O_O__O(arg_spec__5, args__1))) { var ed__6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_67.GetRawRoot__O()); var tmp3 *lang.PersistentVector
			lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 lang.IPersistentVector; var temp__1927000408__auto____6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_28.GetRawRoot__O()).Invoke_O__O(arg_spec__5)
			if jrt.J2g_Truth(temp__1927000408__auto____6) { var name__7 any = temp__1927000408__auto____6; tmp5 = lang.Tuple_Create_O__IPersistentVector(name__7) } else { lang.PersistentVector_Init(); tmp5 = Up_PersistentVector_IPersistentVector(lang.PersistentVector_EMPTY) }
//line :711:1
			var tmp6 any = tmp5; var tmp7 *lang.PersistentVector; lang.PersistentVector_Init(); tmp7 = lang.PersistentVector_EMPTY; ed__6 = tmp1.Invoke_O_O_O__O(tmp2.Invoke_O_O_O_O_O__O(arg_spec__5, tmp4, tmp6, tmp7.Ref(), args__1), A_arbace_spec_alpha_A_const_248, args__1)
//line :710:1
			panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_spec_alpha_A_const_101.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_83, nil, Lit_84), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_119.GetRawRoot__O()).Invoke_O__O(v__0), nil)).Ref(), ed__6)))) } else { return nil } } else {
//line :709:1
				return nil } }








func A_arbace_spec_alpha_fdef_A_New() *A_arbace_spec_alpha_fdef_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_fdef_A{}; t.Ctor(); return t }
//line :718:1
func (t *A_arbace_spec_alpha_fdef_A) Ctor() {}
//line :718:1
func (t *A_arbace_spec_alpha_fdef_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, fn_sym__2, specs__3 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_249), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(fn_sym__2), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_250), specs__3))))) }



































func A_arbace_spec_alpha_recur_limit_QMARK__A_New() *A_arbace_spec_alpha_recur_limit_QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_recur_limit_QMARK__A{}; t.Ctor(); return t }
//line :754:1
func (t *A_arbace_spec_alpha_recur_limit_QMARK__A) Ctor() {}
//line :754:1
func (t *A_arbace_spec_alpha_recur_limit_QMARK__A) Invoke_O_O_O_O_O__O(self, rmap__0, id__1, path__2, k__3 any) any { var and__1927000168__auto____5 bool = lang.Numbers_Gt_O_O__Z(lang.RT_Get_O_O__O(rmap__0, id__1), A_arbace_spec_alpha_A_const_109.Invoke_O__O(rmap__0)); if and__1927000168__auto____5 {

	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_251.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_252.GetRawRoot__O()).Invoke_O__O(path__2), k__3) } else {
//line :755:1
		return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } }


func A_arbace_spec_alpha_inck_A_New() *A_arbace_spec_alpha_inck_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_inck_A{}; t.Ctor(); return t }
//line :758:1
func (t *A_arbace_spec_alpha_inck_A) Ctor() {}
//line :758:1
func (t *A_arbace_spec_alpha_inck_A) Invoke_O_O_O__O(self, m__0, k__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____3 any = lang.RT_Get_O_O__O(m__0, k__1); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp2 = or__1927000174__auto____3 } else { tmp2 = A_arbace_spec_alpha_A_const_195 }; return tmp1.Invoke_O_O_O__O(m__0, k__1, lang.Numbers_Inc_O__Number(tmp2))
}
func A_arbace_spec_alpha_dt_A_New() *A_arbace_spec_alpha_dt_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_dt_A{}; t.Ctor(); return t }
//line :761:1
func (t *A_arbace_spec_alpha_dt_A) Ctor() {}
//line :761:1
func (t *A_arbace_spec_alpha_dt_A) Invoke_O_O_O_O_O__O(self, pred__0, x__1, form__2, cpred_QMARK___3 any) any {


	if jrt.J2g_Truth(pred__0) { var temp__1927000408__auto____5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_253.GetRawRoot__O()).Invoke_O__O(pred__0)
		if jrt.J2g_Truth(temp__1927000408__auto____5) { var spec__6 any = temp__1927000408__auto____5
			return lang.IFn_Cast(A_arbace_spec_alpha_A_const_247.GetRawRoot__O()).Invoke_O_O__O(spec__6, x__1) } else {
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_38.GetRawRoot__O()).Invoke_O__O(pred__0)) {
					if jrt.J2g_Truth(cpred_QMARK___3) {
						return lang.IFn_Cast(pred__0).Invoke_O__O(x__1) } else {
							if jrt.J2g_Truth(lang.IFn_Cast(pred__0).Invoke_O__O(x__1)) { return x__1 } else { return A_arbace_spec_alpha_A_const_42 } } } else {
//line :767:1
								panic(jrt.Thrown(jrt.Exception_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_17), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(form__2), nil))))) } } } else {
//line :764:1
									return x__1 } }
//line :761:1
func (t *A_arbace_spec_alpha_dt_A) Invoke_O_O_O_O__O(self, pred__0, x__1, form__2 any) any {
	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_254.GetRawRoot__O()).Invoke_O_O_O_O__O(pred__0, x__1, form__2, nil)
}










func A_arbace_spec_alpha_valid_QMARK__A_New() *A_arbace_spec_alpha_valid_QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_valid_QMARK__A{}; t.Ctor(); return t }
//line :774:1
func (t *A_arbace_spec_alpha_valid_QMARK__A) Ctor() {}
//line :774:1
func (t *A_arbace_spec_alpha_valid_QMARK__A) Invoke_O_O_O_O__O(self, spec__0, x__1, form__2 any) any { var spec__4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_43.GetRawRoot__O()).Invoke_O_O__O(spec__0, form__2); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()); var tmp3 any; var target_46 any = spec__4; var tmp4 bool; var tmp5 bool; tmp5 =






	A_arbace_spec_alpha_Spec_A_InstanceOf(target_46); if tmp5 { tmp5 = !lang.Compiler_AOT_IsDyn_O__Z(target_46) }; tmp4 = tmp5; if tmp4 { tmp3 = A_arbace_spec_alpha_Spec_A_Cast(target_46).Conform_STAR__O__O(x__1) } else { tmp3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_46, x__1) }; return tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3)) }
//line :774:1
func (t *A_arbace_spec_alpha_valid_QMARK__A) Invoke_O_O_O__O(self, spec__0, x__1 any) any { var spec__3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_43.GetRawRoot__O()).Invoke_O__O(spec__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()); var tmp3 any; var target_47 any = spec__3; var tmp4 bool; var tmp5 bool; tmp5 =



	A_arbace_spec_alpha_Spec_A_InstanceOf(target_47); if tmp5 { tmp5 = !lang.Compiler_AOT_IsDyn_O__Z(target_47) }; tmp4 = tmp5; if tmp4 { tmp3 = A_arbace_spec_alpha_Spec_A_Cast(target_47).Conform_STAR__O__O(x__1) } else { tmp3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_47, x__1) }; return tmp1.Invoke_O__O(tmp2.Invoke_O__O(tmp3)) }




func A_arbace_spec_alpha_pvalid_QMARK__A_New() *A_arbace_spec_alpha_pvalid_QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_pvalid_QMARK__A{}; t.Ctor(); return t }
//line :783:1
func (t *A_arbace_spec_alpha_pvalid_QMARK__A) Ctor() {}
//line :783:1
func (t *A_arbace_spec_alpha_pvalid_QMARK__A) Invoke_O_O_O_O__O(self, pred__0, x__1, form__2 any) any {




	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_254.GetRawRoot__O()).Invoke_O_O_O__O(pred__0, x__1, form__2))) }
//line :783:1
func (t *A_arbace_spec_alpha_pvalid_QMARK__A) Invoke_O_O_O__O(self, pred__0, x__1 any) any {


	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_254.GetRawRoot__O()).Invoke_O_O_O__O(pred__0, x__1, A_arbace_spec_alpha_A_const_41)))
}


func A_arbace_spec_alpha_explain_1_A_New() *A_arbace_spec_alpha_explain_1_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_explain_1_A{}; t.Ctor(); return t }
//line :790:1
func (t *A_arbace_spec_alpha_explain_1_A) Ctor() {}
//line :790:1
func (t *A_arbace_spec_alpha_explain_1_A) Invoke_O_O_O_O_O_O_O__O(self, form__0, pred__1, path__2, via__3, in__4, v__5 any) any { var pred__7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_29.GetRawRoot__O()).Invoke_O__O(pred__1); if


	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_25.GetRawRoot__O()).Invoke_O__O(pred__7)) {
		var target_48 any = pred__7; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_48); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_48) }; tmp1 = tmp2; if tmp1 { var tmp3 A_arbace_spec_alpha_Spec_A = A_arbace_spec_alpha_Spec_A_Cast(target_48); var tmp4 any; var temp__1927000408__auto____8 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_28.GetRawRoot__O()).Invoke_O__O(pred__7); if jrt.J2g_Truth(temp__1927000408__auto____8) { var name__9 any = temp__1927000408__auto____8; tmp4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(via__3, name__9) } else { tmp4 = via__3 }; return tmp3.Explain_STAR__O_O_O_O__O(path__2, tmp4, in__4, v__5) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_62.GetRawRoot__O()); var tmp6 any; var temp__1927000408__auto____8_2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_28.GetRawRoot__O()).Invoke_O__O(pred__7); if jrt.J2g_Truth(temp__1927000408__auto____8_2) { var name__9_2 any = temp__1927000408__auto____8_2; tmp6 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(via__3, name__9_2) } else { tmp6 = via__3 }; return tmp5.Invoke_O_O_O_O_O__O(target_48, path__2, tmp6, in__4, v__5) } } else {
//line :793:1
			return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_72, path__2, A_arbace_spec_alpha_A_const_73, form__0, A_arbace_spec_alpha_A_const_74, v__5, A_arbace_spec_alpha_A_const_76, via__3, A_arbace_spec_alpha_A_const_77, in__4))) } }





func A_arbace_spec_alpha_k_gen_A_New() *A_arbace_spec_alpha_k_gen_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_k_gen_A{}; t.Ctor(); return t }
//line :799:1
func (t *A_arbace_spec_alpha_k_gen_A) Ctor() {}
//line :799:1
func (t *A_arbace_spec_alpha_k_gen_A) Invoke_O_O__O(self, f__0 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(f__0)) {
		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_255.GetRawRoot__O()).Invoke_O__O(f__0) } else {
//line :803:1
			var tmp1 any = A_arbace_spec_alpha_A_const_256; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(f__0)) {

				var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_257.GetRawRoot__O()); var tmp3 any = A_arbace_spec_alpha_A_const_260; return tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_spec_alpha_A_const_113.GetRawRoot__O()).Invoke_O__O(f__0)) } else {
//line :803:1
					var tmp4 any = A_arbace_spec_alpha_A_const_258; if lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(f__0)) {


						return lang.IFn_Cast(A_arbace_spec_alpha_A_const_259.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_113.GetRawRoot__O()).Invoke_O__O(f__0)) } else {
//line :803:1
							return nil
						}
				}
		}
}
func A_arbace_spec_alpha_or_k_gen_A_New() *A_arbace_spec_alpha_or_k_gen_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_or_k_gen_A{}; t.Ctor(); return t }
//line :808:1
func (t *A_arbace_spec_alpha_or_k_gen_A) Ctor() {}
//line :808:1
func (t *A_arbace_spec_alpha_or_k_gen_A) Invoke_O_O_O__O(self, min_count__0, s__1 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_261.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_262.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_264.GetRawRoot__O()).Invoke_O_O__O(min_count__0, jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(s__1)).Ref()), lang.IFn_Cast(A_arbace_spec_alpha_A_const_265.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_266.GetRawRoot__O(), s__1))); var tmp3 any = A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_New(); var tmp4 *jrt.Class
	var fncls__49 /*line :813:1*/*jrt.Class = A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_fn_class


	if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_122, false); A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_fn_class = fncls__49d; tmp4 = fncls__49d } else { tmp4 = fncls__49 }
//line :813:1
	return tmp1.Invoke_O_O__O(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :808:1
func (t *A_arbace_spec_alpha_or_k_gen_A) Invoke_O_O__O(self, s__0 any) any {


	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_257.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_195, s__0)
}



func A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_New() *A_arbace_spec_alpha_or_k_gen_fn__1740000386_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_or_k_gen_fn__1740000386_A{}; t.Ctor(); return t }
//line :816:1
func (t *A_arbace_spec_alpha_or_k_gen_fn__1740000386_A) Ctor() {}
//line :816:1
func (t *A_arbace_spec_alpha_or_k_gen_fn__1740000386_A) Invoke_O_O__O(self, p__1740000385__1 any) any { var vec__1740000387__2 any = p__1740000385__1; var n__3 any = lang.RT_Nth_O_I_O__O(vec__1740000387__2, lang.RT_IntCast_J__I(0), nil); var gens__4 any = lang.RT_Nth_O_I_O__O(vec__1740000387__2, lang.RT_IntCast_J__I(1), nil); return /*line :817:1*/ lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_262.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_263.GetRawRoot__O()).Invoke_O_O__O(n__3, gens__4)) }

func A_arbace_spec_alpha_and_k_gen_A_New() *A_arbace_spec_alpha_and_k_gen_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_and_k_gen_A{}; t.Ctor(); return t }
//line :819:1
func (t *A_arbace_spec_alpha_and_k_gen_A) Ctor() {}
//line :819:1
func (t *A_arbace_spec_alpha_and_k_gen_A) Invoke_O_O__O(self, s__0 any) any {



	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_262.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_266.GetRawRoot__O(), s__0))
}

func A_arbace_spec_alpha_map_spec_impl_A_New() *A_arbace_spec_alpha_map_spec_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_map_spec_impl_A{}; t.Ctor(); return t }
//line :826:1
func (t *A_arbace_spec_alpha_map_spec_impl_A) Ctor() {}
//line :826:1
func (t *A_arbace_spec_alpha_map_spec_impl_A) Invoke_O_O__O(self, p__1740000396__0 any) any { var map__1740000397__2 any = p__1740000396__0; var map__1740000397__3 any; if lang.ISeq_InstanceOf(map__1740000397__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000397__2)) { map__1740000397__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000397__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000397__2)) { map__1740000397__3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000397__2) } else { lang.PersistentArrayMap_Init(); map__1740000397__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000397__3 = map__1740000397__2 }; var argm__4 any = map__1740000397__3; var req_un__5 any = lang.RT_Get_O_O__O(map__1740000397__3, A_arbace_spec_alpha_A_const_140); var opt_un__6 any = lang.RT_Get_O_O__O(map__1740000397__3, A_arbace_spec_alpha_A_const_142); var keys_pred__7 any = lang.RT_Get_O_O__O(map__1740000397__3, A_arbace_spec_alpha_A_const_169); var pred_exprs__8 any = lang.RT_Get_O_O__O(map__1740000397__3, A_arbace_spec_alpha_A_const_168); var opt_keys__9 any = lang.RT_Get_O_O__O(map__1740000397__3, A_arbace_spec_alpha_A_const_165); var req_specs__10 any = lang.RT_Get_O_O__O(map__1740000397__3, A_arbace_spec_alpha_A_const_164); var req__11 any = lang.RT_Get_O_O__O(map__1740000397__3, A_arbace_spec_alpha_A_const_139); var req_keys__12 any = lang.RT_Get_O_O__O(map__1740000397__3, A_arbace_spec_alpha_A_const_163); var opt_specs__13 any = lang.RT_Get_O_O__O(map__1740000397__3, A_arbace_spec_alpha_A_const_166); var pred_forms__14 any = lang.RT_Get_O_O__O(map__1740000397__3, A_arbace_spec_alpha_A_const_167); var opt__15 any = lang.RT_Get_O_O__O(map__1740000397__3, A_arbace_spec_alpha_A_const_141); var gfn__16 any = lang.RT_Get_O_O__O(map__1740000397__3, A_arbace_spec_alpha_A_const_170); var k__GT_s__17 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_267.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(req_keys__12, opt_keys__9), lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(req_specs__10, opt_specs__13)); var keys__GT_specnames__18 any; var tmp1 any = A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_New_O(k__GT_s__17); var tmp2 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_fn_class; if



	fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_85, false); A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_fn_class = fncls__50d; tmp2 = fncls__50d } else { tmp2 = fncls__50 }; keys__GT_specnames__18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var id__19 any = /*line :826:1*/jrt.UUID_RandomUUID__UUID().Ref(); return /*line :833:1*/ A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_New_IPersistentMap_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(nil, pred_forms__14, opt__15, keys_pred__7, id__19, req_keys__12, req_specs__10, argm__4, req__11, req_un__5, opt_keys__9, pred_exprs__8, keys__GT_specnames__18, opt_un__6, opt_specs__13, gfn__16) }
//line :830:1
func A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_New_O(p0 any) *A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A{}; t.Ctor_O(p0); return t }
//line :830:1
func (t *A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A) Ctor_O(c__k__GT_s any) { t.F_k__GT_s = c__k__GT_s }
//line :830:1
func (t *A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A) Invoke_O_O__O(self, p1__1740000393_SHARP___1 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(t.F_k__GT_s).Invoke_O__O(p1__1740000393_SHARP___1); if
																	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return p1__1740000393_SHARP___1 } }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_New_IPersistentMap_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(p0 lang.IPersistentMap, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15 any) *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A { t := &A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A{}; t.Ctor_IPersistentMap_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15); return t }
//line :833:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Ctor_IPersistentMap_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(meta__ lang.IPersistentMap, c__pred_forms, c__opt, c__keys_pred, c__id, c__req_keys, c__req_specs, c__argm, c__req, c__req_un, c__opt_keys, c__pred_exprs, c__keys__GT_specnames, c__opt_un, c__opt_specs, c__gfn any) { t.F___meta = meta__; t.F_pred_forms = c__pred_forms; t.F_opt = c__opt; t.F_keys_pred = c__keys_pred; t.F_id = c__id; t.F_req_keys = c__req_keys; t.F_req_specs = c__req_specs; t.F_argm = c__argm; t.F_req = c__req; t.F_req_un = c__req_un; t.F_opt_keys = c__opt_keys; t.F_pred_exprs = c__pred_exprs; t.F_keys__GT_specnames = c__keys__GT_specnames; t.F_opt_un = c__opt_un; t.F_opt_specs = c__opt_specs; t.F_gfn = c__gfn }
//line :833:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Describe_STAR___O() any {









































































	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_268; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_269; var tmp4 any = tmp3; var tmp5 any; var G__1740000455__1_ any; lang.PersistentVector_Init(); G__1740000455__1_ = lang.PersistentVector_EMPTY.Ref(); var G__1740000455__2_ any
	if jrt.J2g_Truth(t.F_req) {
		var tmp6 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_10; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_139; G__1740000455__2_ = tmp7.Invoke_O_O_O__O(G__1740000455__1_, tmp8.Ref(), t.F_req) } else {
//line :908:1
			G__1740000455__2_ = G__1740000455__1_ }
//line :907:1
	var G__1740000455__3_ any
	if jrt.J2g_Truth(t.F_opt) {

		var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_10; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_141; G__1740000455__3_ = tmp10.Invoke_O_O_O__O(G__1740000455__2_, tmp11.Ref(), t.F_opt) } else {
//line :908:1
			G__1740000455__3_ = G__1740000455__2_ }
//line :907:1
	var G__1740000455__4_ any
	if jrt.J2g_Truth(t.F_req_un) {


		var tmp12 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp12 = A_arbace_spec_alpha_A_const_10; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp14 = A_arbace_spec_alpha_A_const_140; G__1740000455__4_ = tmp13.Invoke_O_O_O__O(G__1740000455__3_, tmp14.Ref(), t.F_req_un) } else {
//line :908:1
			G__1740000455__4_ = G__1740000455__3_ }; if jrt.J2g_Truth(t.F_opt_un) {



				var tmp15 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp15 = A_arbace_spec_alpha_A_const_10; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp17 = A_arbace_spec_alpha_A_const_142; tmp5 = tmp16.Invoke_O_O_O__O(G__1740000455__4_, tmp17.Ref(), t.F_opt_un) } else {
//line :908:1
					tmp5 = G__1740000455__4_ }
//line :907:1
	return tmp2.Invoke_O_O__O(tmp4, tmp5) }
//line :833:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) With_gen_STAR__O__O(gfn__1 any) any {








































































	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_270; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_22; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_argm; var tmp6 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_170; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp5, tmp6.Ref(), gfn__1)) }
//line :833:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Gen_STAR__O_O_O__O(overrides__1, path__2, rmap__3 any) any {

















































	if jrt.J2g_Truth(t.F_gfn) {
		return lang.IFn_Cast(t.F_gfn).Invoke__O() } else {
//line :883:1
			var rmap__4 any; var tmp1 *lang.Var

			A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_271; rmap__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(rmap__3, t.F_id)
//line :883:1
			var rgen__5 any; var tmp2 any = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_New_O_O_O(path__2, rmap__4, overrides__1); var tmp3 *jrt.Class
			var fncls__51 /*line :883:1*/*jrt.Class = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_fn_class


			if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_86, false); A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; rgen__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)
//line :883:1
			var ogen__6 any; var tmp4 any = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_New_O_O_O_O(path__2, rmap__4, overrides__1, t.F_id); var tmp5 *jrt.Class
			var fncls__53 /*line :883:1*/*jrt.Class = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_fn_class



			if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_fn_class = fncls__53d; tmp5 = fncls__53d } else { tmp5 = fncls__53 }; ogen__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)
//line :883:1
			var reqs__7 any; var tmp6 *lang.Var






			A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_148; reqs__7 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O_O__O(rgen__5, t.F_req_keys, t.F_req_specs)
//line :883:1
			var opts__8 any; var tmp7 *lang.Var







			A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_274; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_275; var tmp10 any = jrt.NN(tmp9).GetRawRoot__O(); var tmp11 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_148; opts__8 = tmp8.Invoke_O_O__O(tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O_O__O(ogen__6, t.F_opt_keys, t.F_opt_specs))
			var tmp12 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp12 = A_arbace_spec_alpha_A_const_145; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp14 = A_arbace_spec_alpha_A_const_156; var tmp15 any = jrt.NN(tmp14).GetRawRoot__O(); var tmp16 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp16 = A_arbace_spec_alpha_A_const_130; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp18 = A_arbace_spec_alpha_A_const_148; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp20 = A_arbace_spec_alpha_A_const_55; var tmp21 any = tmp19.Invoke_O_O__O(jrt.NN(tmp20).GetRawRoot__O(), reqs__7); var tmp22 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp22 = A_arbace_spec_alpha_A_const_148; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp24 = A_arbace_spec_alpha_A_const_55; if jrt.J2g_Truth(tmp13.Invoke_O_O__O(tmp15, tmp17.Invoke_O_O__O(tmp21, tmp23.Invoke_O_O__O(jrt.NN(tmp24).GetRawRoot__O(), opts__8)))) {
				var tmp25 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp25 = A_arbace_spec_alpha_A_const_261; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp27 = A_arbace_spec_alpha_A_const_262; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp29 = A_arbace_spec_alpha_A_const_259; var tmp30 any = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(t.F_req); var tmp31 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp31 = A_arbace_spec_alpha_A_const_257; var tmp32 any = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(t.F_opt); var tmp33 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp33 = A_arbace_spec_alpha_A_const_259; var tmp34 any = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(t.F_req_un); var tmp35 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp35 = A_arbace_spec_alpha_A_const_257; var tmp36 any = tmp28.Invoke_O_O_O_O__O(tmp30, tmp32, tmp34, lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(t.F_opt_un)); var tmp37 any = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_New_O_O(reqs__7, opts__8); var tmp38 *jrt.Class
				var fncls__55 /*line :893:1*/*jrt.Class = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_fn_class





				if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_88, false); A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_fn_class = fncls__55d; tmp38 = fncls__55d } else { tmp38 = fncls__55 }
//line :893:1
				return tmp26.Invoke_O_O__O(tmp36, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil)) } else {
//line :892:1
					return nil } } }
//line :833:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, x__4 any) any {
































	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_40; if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__4))) { var tmp4 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_72; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_73; var tmp7 any = tmp6.Ref(); var tmp8 any; A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_279; var tmp9 any = tmp8; var tmp10 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp10 = A_arbace_spec_alpha_A_const_74; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp12 = A_arbace_spec_alpha_A_const_76; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp14 = A_arbace_spec_alpha_A_const_77; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, path__1, tmp7, tmp9, tmp11, x__4, tmp13, via__2, tmp14.Ref(), in__3))) } else { var reg__5 any; var tmp15 *lang.Var

		A_arbace_spec_alpha_A_Init(); tmp15 = A_arbace_spec_alpha_A_const_134; reg__5 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke__O()
		var tmp16 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp16 = A_arbace_spec_alpha_A_const_158; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp18 = A_arbace_spec_alpha_A_const_130; var tmp19 any = jrt.NN(tmp18).GetRawRoot__O(); var tmp20 any; var temp__1927000414__auto____6 any; var tmp21 *lang.Var
		A_arbace_spec_alpha_A_Init(); tmp21 = A_arbace_spec_alpha_A_const_69; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp23 = A_arbace_spec_alpha_A_const_280; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp25 = A_arbace_spec_alpha_A_const_156; var tmp26 any = jrt.NN(tmp25).GetRawRoot__O(); var tmp27 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp27 = A_arbace_spec_alpha_A_const_148; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 any = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_New_O(x__4); var tmp30 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_fn_class = fncls__56d; tmp30 = fncls__56d } else { tmp30 = fncls__56 }; temp__1927000414__auto____6 = tmp22.Invoke_O__O(tmp24.Invoke_O_O__O(tmp26, tmp28.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil), t.F_pred_exprs, t.F_pred_forms))); if jrt.J2g_Truth(temp__1927000414__auto____6) { var probs__7 any = temp__1927000414__auto____6; var tmp31 *lang.Var



			A_arbace_spec_alpha_A_Init(); tmp31 = A_arbace_spec_alpha_A_const_148; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_New_O_O_O_O(in__3, path__1, via__2, x__4); var tmp34 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_fn_class = fncls__57d; tmp34 = fncls__57d } else { tmp34 = fncls__57 }; tmp20 = tmp32.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil), probs__7) } else {
//line :870:1
				tmp20 = nil }
//line :869:1
		var tmp35 any = tmp20; var tmp36 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp36 = A_arbace_spec_alpha_A_const_148; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 any = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_New_O_O_O_O_O(in__3, path__1, via__2, reg__5, t.F_keys__GT_specnames); var tmp39 *jrt.Class
		var fncls__58 /*line :869:1*/*jrt.Class = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_fn_class







		if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_91, false); A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_fn_class = fncls__58d; tmp39 = fncls__58d } else { tmp39 = fncls__58 }
//line :869:1
		var tmp40 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil); var tmp41 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp41 = A_arbace_spec_alpha_A_const_69; return tmp17.Invoke_O_O_O__O(tmp19, tmp35, tmp37.Invoke_O_O__O(tmp40, lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(x__4))) } }
//line :833:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Unform_STAR__O__O(m__1 any) any { { var reg__2 any; var tmp1 *lang.Var





















	A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_134; reg__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke__O()
//line :833:1
	var ret__3 any = m__1; var G__1740000424__4_ any; var tmp2 *lang.Var






















	A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_283; G__1740000424__4_ = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(m__1)
//line :833:1
	var vec__1740000425__5 any = G__1740000424__4_; var seq__1740000426__6 any; var tmp3 *lang.Var






















	A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_69; seq__1740000426__6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(vec__1740000425__5)
//line :833:1
	var first__1740000427__7 any; var tmp4 *lang.Var






















	A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_53; first__1740000427__7 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__1740000426__6)
//line :833:1
	var seq__1740000426__8 any; var tmp5 *lang.Var






















	A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_70; seq__1740000426__8 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1740000426__6)
//line :833:1
	var k__9 any = first__1740000427__7; var ks__10 any = seq__1740000426__8; var keys__11 any = vec__1740000425__5; var ret__12 any = ret__3; var G__1740000424__13_ any = G__1740000424__4_; _ = k__9; _ = ks__10; _ = keys__11; L1: for { var ret__14 any = ret__12; var vec__1740000428__15 any = G__1740000424__13_; var seq__1740000429__16 any; var tmp6 *lang.Var






















		A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_69; seq__1740000429__16 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(vec__1740000428__15)
//line :833:1
		var first__1740000430__17 any; var tmp7 *lang.Var






















		A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_53; first__1740000430__17 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq__1740000429__16)
//line :833:1
		var seq__1740000429__18 any; var tmp8 *lang.Var






















		A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_70; seq__1740000429__18 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq__1740000429__16)
//line :833:1
		var k__19 any = first__1740000430__17
		var ks__20 any = seq__1740000429__18
		var keys__21 any = vec__1740000428__15





















		if jrt.J2g_Truth(keys__21) {
			var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_251; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O__O(reg__2, lang.IFn_Cast(t.F_keys__GT_specnames).Invoke_O__O(k__19))) { var cv__22 any = lang.RT_Get_O_O__O(m__1, k__19); var v__23 any; var tmp10 *lang.Var

				A_arbace_spec_alpha_A_Init(); tmp10 = A_arbace_spec_alpha_A_const_284; v__23 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_keys__GT_specnames).Invoke_O__O(k__19), cv__22)
				var tmp11 any; if lang.Util_Identical_O_O__Z(cv__22, v__23) { tmp11 = ret__14 } else { var tmp12 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp12 = A_arbace_spec_alpha_A_const_22; tmp11 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O_O__O(ret__14, k__19, v__23) }; ret__12, G__1740000424__13_ = tmp11, ks__20; continue L1 } else {

					ret__12, G__1740000424__13_ = ret__14, ks__20; continue L1 } } else {
//line :857:1
						return ret__14 } } }; /*line :833:1*/panic("j2g: unreachable") }
//line :833:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Conform_STAR__O__O(m__1 any) any {






	if jrt.J2g_Truth(lang.IFn_Cast(t.F_keys_pred).Invoke_O__O(m__1)) { var reg__2 any; var tmp1 *lang.Var
		A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_134; reg__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke__O()
//line :840:1
		var ret__3 any = m__1; var G__1740000408__4_ any = m__1; var vec__1740000409__5 any = G__1740000408__4_; var seq__1740000410__6 any; var tmp2 *lang.Var

		A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_69; seq__1740000410__6 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(vec__1740000409__5)
//line :840:1
		var first__1740000411__7 any; var tmp3 *lang.Var

		A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_53; first__1740000411__7 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__1740000410__6)
//line :840:1
		var seq__1740000410__8 any; var tmp4 *lang.Var

		A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_70; seq__1740000410__8 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__1740000410__6)
//line :840:1
		var vec__1740000412__9 any = first__1740000411__7; var k__10 any = lang.RT_Nth_O_I_O__O(vec__1740000412__9, lang.RT_IntCast_J__I(0), nil); var v__11 any = lang.RT_Nth_O_I_O__O(vec__1740000412__9, lang.RT_IntCast_J__I(1), nil); var ks__12 any = seq__1740000410__8; var keys__13 any = vec__1740000409__5; var ret__14 any = ret__3; var G__1740000408__15_ any = G__1740000408__4_; _ = k__10; _ = v__11; _ = ks__12; _ = keys__13; L1: for { var ret__16 any = ret__14; var vec__1740000415__17 any = G__1740000408__15_; var seq__1740000416__18 any; var tmp5 *lang.Var

			A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_69; seq__1740000416__18 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(vec__1740000415__17)
//line :840:1
			var first__1740000417__19 any; var tmp6 *lang.Var

			A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_53; first__1740000417__19 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq__1740000416__18)
//line :840:1
			var seq__1740000416__20 any; var tmp7 *lang.Var

			A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_70; seq__1740000416__20 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq__1740000416__18)
//line :840:1
			var vec__1740000418__21 any = first__1740000417__19; var k__22 any = lang.RT_Nth_O_I_O__O(vec__1740000418__21, lang.RT_IntCast_J__I(0), nil); var v__23 any = lang.RT_Nth_O_I_O__O(vec__1740000418__21, lang.RT_IntCast_J__I(1), nil)
			var ks__24 any = seq__1740000416__20
			var keys__25 any = vec__1740000415__17
			if jrt.J2g_Truth(keys__25) { var sname__26 any = lang.IFn_Cast(t.F_keys__GT_specnames).Invoke_O__O(k__22); var temp__1927000408__auto____27 any = lang.RT_Get_O_O__O(reg__2, sname__26)

				if jrt.J2g_Truth(temp__1927000408__auto____27) { var s__28 any = temp__1927000408__auto____27; var cv__29 any; var tmp8 *lang.Var
					A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_247; cv__29 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(s__28, v__23)
					var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_246; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(cv__29)) { A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } else {

						var tmp10 any; if lang.Util_Identical_O_O__Z(cv__29, v__23) { tmp10 = ret__16 } else { var tmp11 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_22; tmp10 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O_O__O(ret__16, k__22, cv__29) }; ret__14, G__1740000408__15_ = tmp10, ks__24; continue L1 } } else {

							ret__14, G__1740000408__15_ = ret__16, ks__24; continue L1 } } else {
//line :843:1
								return ret__16 } } } else {
//line :840:1
									A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 }
//line :833:1
	panic("j2g: unreachable") }
//line :833:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Specize_STAR__O__O(___1 any) any { return t }
//line :833:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Specize_STAR___O() any { return t }
//line :833:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :833:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_New_IPersistentMap_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(m, t.F_pred_forms, t.F_opt, t.F_keys_pred, t.F_id, t.F_req_keys, t.F_req_specs, t.F_argm, t.F_req, t.F_req_un, t.F_opt_keys, t.F_pred_exprs, t.F_keys__GT_specnames, t.F_opt_un, t.F_opt_specs, t.F_gfn) }




































func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_New_O(p0 any) *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A{}; t.Ctor_O(p0); return t }
//line :870:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :870:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A) Invoke_O_O_O__O(self, pred__1, form__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(pred__1).Invoke_O__O(t.F_x)) { return nil } else { return form__2 } }



func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :874:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A) Ctor_O_O_O_O(c__in, c__path, c__via, c__x any) { t.F_in = c__in; t.F_path = c__path; t.F_via = c__via; t.F_x = c__x }
//line :874:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A) Invoke_O_O__O(self, p1__1740000394_SHARP___1 any) any {
	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_156.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_72, t.F_path, A_arbace_spec_alpha_A_const_73, p1__1740000394_SHARP___1, A_arbace_spec_alpha_A_const_74, t.F_x, A_arbace_spec_alpha_A_const_76, t.F_via, A_arbace_spec_alpha_A_const_77, t.F_in)))
}
func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :877:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A) Ctor_O_O_O_O_O(c__in, c__path, c__via, c__reg, c__keys__GT_specnames any) { t.F_in = c__in; t.F_path = c__path; t.F_via = c__via; t.F_reg = c__reg; t.F_keys__GT_specnames = c__keys__GT_specnames }
//line :877:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A) Invoke_O_O__O(self, p__1740000435__1 any) any { var vec__1740000437__2 any = p__1740000435__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1740000437__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1740000437__2, lang.RT_IntCast_J__I(1), nil); var tmp1 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_251.GetRawRoot__O()); var tmp3 any = t.F_reg; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(t.F_keys__GT_specnames).Invoke_O__O(k__3))); if
																jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else {
																	tmp1 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_281.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(t.F_keys__GT_specnames).Invoke_O__O(k__3), v__4, k__3) }; if /*line :878:1*/ jrt.J2g_Truth(tmp1) { return nil } else {

			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_282.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(t.F_keys__GT_specnames).Invoke_O__O(k__3); var tmp6 any = lang.IFn_Cast(t.F_keys__GT_specnames).Invoke_O__O(k__3); var tmp7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(t.F_path, k__3); var tmp8 any = t.F_via; return tmp4.Invoke_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(t.F_in, k__3), v__4) } }





func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_New_O_O_O(p0, p1, p2 any) *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :886:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A) Ctor_O_O_O(c__path, c__rmap, c__overrides any) { t.F_path = c__path; t.F_rmap = c__rmap; t.F_overrides = c__overrides }
//line :886:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A) Invoke_O_O_O__O(self, k__1, s__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_108.GetRawRoot__O()); var tmp2 any = t.F_overrides; return lang.Tuple_Create_O_O__IPersistentVector(k__1, tmp1.Invoke_O_O_O_O_O__O(s__2, tmp2, lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(t.F_path, k__1), t.F_rmap, k__1)) }
func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :887:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A) Ctor_O_O_O_O(c__path, c__rmap, c__overrides, c__id any) { t.F_path = c__path; t.F_rmap = c__rmap; t.F_overrides = c__overrides; t.F_id = c__id }
//line :887:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A) Invoke_O_O_O__O(self, k__1, s__2 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_272.GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_rmap, t.F_id, t.F_path, k__1)) { return nil } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_273.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_New_O_O_O_O_O(t.F_path, t.F_rmap, t.F_overrides, k__1, s__2); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_fn_class
		if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_93, false); A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }
//line :888:1
		return lang.Tuple_Create_O_O__IPersistentVector(k__1, tmp1.Invoke_O__O(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)))) } }
func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :889:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A) Ctor_O_O_O_O_O(c__path, c__rmap, c__overrides, c__k, c__s any) { t.F_path = c__path; t.F_rmap = c__rmap; t.F_overrides = c__overrides; t.F_k = c__k; t.F_s = c__s }
//line :889:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_108.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_s; t.F_s = nil; tmp2 = t_; var tmp3 any = tmp2; var tmp4 any; var t__2 any = t.F_overrides; t.F_overrides = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()); var tmp7 any; var t__3 any = t.F_path; t.F_path = nil; tmp7 = t__3; var tmp8 any = tmp6.Invoke_O_O__O(tmp7, t.F_k); var tmp9 any; var t__4 any = t.F_rmap; t.F_rmap = nil; tmp9 = t__4; var tmp10 any = tmp9; var tmp11 any; var t__5 any = t.F_k; t.F_k = nil; tmp11 = t__5; return tmp1.Invoke_O_O_O_O_O__O(tmp3, tmp5, tmp8, tmp10, tmp11) }









func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A{}; t.Ctor_O_O(p0, p1); return t }
//line :899:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A) Ctor_O_O(c__reqs, c__opts any) { t.F_reqs = c__reqs; t.F_opts = c__opts }
//line :899:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A) Invoke_O_O__O(self, p__1740000447__1 any) any { var vec__1740000449__2 any = p__1740000447__1; var req_ks__3 any = lang.RT_Nth_O_I_O__O(vec__1740000449__2, lang.RT_IntCast_J__I(0), nil); var opt_ks__4 any = lang.RT_Nth_O_I_O__O(vec__1740000449__2, lang.RT_IntCast_J__I(1), nil); var req_un_ks__5 any = lang.RT_Nth_O_I_O__O(vec__1740000449__2, lang.RT_IntCast_J__I(2), nil); var opt_un_ks__6 any = lang.RT_Nth_O_I_O__O(vec__1740000449__2, lang.RT_IntCast_J__I(3), nil); var qks__7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_152.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(req_ks__3, opt_ks__4)); var unqks__8 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_276.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_143.GetRawRoot__O(), A_arbace_spec_alpha_A_const_57.GetRawRoot__O()), lang.IFn_Cast(A_arbace_spec_alpha_A_const_152.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(req_un_ks__5, opt_un_ks__6))); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_A_const_277.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()); var tmp4 any = A_arbace_spec_alpha_A_const_130.GetRawRoot__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_278.GetRawRoot__O()); var tmp6 any = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_New_O_O(qks__7, unqks__8); var tmp7 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_fn_class; if



	fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_92, false); A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_fn_class = fncls__54d; tmp7 = fncls__54d } else { tmp7 = fncls__54 }; return /*line :905:1*/ tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), lang.IFn_Cast(A_arbace_spec_alpha_A_const_146.GetRawRoot__O()).Invoke_O_O__O(t.F_reqs, t.F_opts)))) }
//line :903:1
func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A{}; t.Ctor_O_O(p0, p1); return t }
//line :903:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A) Ctor_O_O(c__qks, c__unqks any) { t.F_qks = c__qks; t.F_unqks = c__unqks }
//line :903:1
func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A) Invoke_O_O__O(self, p1__1740000395_SHARP___1 any) any { return lang.IFn_Cast(lang.IFn_Cast(A_arbace_spec_alpha_A_const_252.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(t.F_qks, t.F_unqks))).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(p1__1740000395_SHARP___1)) }













func A_arbace_spec_alpha_spec_impl_A_New() *A_arbace_spec_alpha_spec_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_spec_impl_A{}; t.Ctor(); return t }
//line :917:1
func (t *A_arbace_spec_alpha_spec_impl_A) Ctor() {}
//line :917:1
func (t *A_arbace_spec_alpha_spec_impl_A) Invoke_O_O_O_O_O_O__O(self, form__0, pred__1, gfn__2, cpred_QMARK___3, unc__4 any) any {



	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_25.GetRawRoot__O()).Invoke_O__O(pred__1)) { var G__1740000458__6_ any = pred__1
		if jrt.J2g_Truth(gfn__2) { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_285.GetRawRoot__O()).Invoke_O_O__O(G__1740000458__6_, gfn__2) } else { return G__1740000458__6_ } } else {
//line :921:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_21.GetRawRoot__O()).Invoke_O__O(pred__1)) {

				return lang.IFn_Cast(A_arbace_spec_alpha_A_const_27.GetRawRoot__O()).Invoke_O_O__O(pred__1, gfn__2) } else {
//line :921:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_15.GetRawRoot__O()).Invoke_O__O(pred__1)) { var G__1740000459__6_ any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_253.GetRawRoot__O()).Invoke_O__O(pred__1)


						if jrt.J2g_Truth(gfn__2) { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_285.GetRawRoot__O()).Invoke_O_O__O(G__1740000459__6_, gfn__2) } else { return G__1740000459__6_ } } else {
//line :921:1
							if A_arbace_spec_alpha_A_const_51 != nil {




								return A_arbace_spec_alpha_spec_impl_reify__1740000460_A_New_IPersistentMap_O_O_O_O_O(nil, form__0, unc__4, gfn__2, cpred_QMARK___3, pred__1) } else {
//line :921:1
									return nil } } } } }
//line :917:1
func (t *A_arbace_spec_alpha_spec_impl_A) Invoke_O_O_O_O_O__O(self, form__0, pred__1, gfn__2, cpred_QMARK___3 any) any {

	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_37.GetRawRoot__O()).Invoke_O_O_O_O_O__O(form__0, pred__1, gfn__2, cpred_QMARK___3, nil)
}





func A_arbace_spec_alpha_spec_impl_reify__1740000460_A_New_IPersistentMap_O_O_O_O_O(p0 lang.IPersistentMap, p1, p2, p3, p4, p5 any) *A_arbace_spec_alpha_spec_impl_reify__1740000460_A { t := &A_arbace_spec_alpha_spec_impl_reify__1740000460_A{}; t.Ctor_IPersistentMap_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :926:1
func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Ctor_IPersistentMap_O_O_O_O_O(meta__ lang.IPersistentMap, c__form, c__unc, c__gfn, c__cpred_QMARK_, c__pred any) { t.F___meta = meta__; t.F_form = c__form; t.F_unc = c__unc; t.F_gfn = c__gfn; t.F_cpred_QMARK_ = c__cpred_QMARK_; t.F_pred = c__pred }
//line :926:1
func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Describe_STAR___O() any { return t.F_form }
//line :926:1
func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) With_gen_STAR__O__O(gfn__1 any) any {




















	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_37; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O_O_O__O(t.F_form, t.F_pred, gfn__1, t.F_cpred_QMARK_, t.F_unc) }
//line :926:1
func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Gen_STAR__O_O_O__O(___1, ___2, ___3 any) any {

















	if jrt.J2g_Truth(t.F_gfn) {
		return lang.IFn_Cast(t.F_gfn).Invoke__O() } else {
			var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_286; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_pred) } }
//line :926:1
func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, x__4 any) any {















	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_246; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_254; if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_pred, x__4, t.F_form, t.F_cpred_QMARK_))) { var tmp4 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_72; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_73; var tmp7 any = tmp6.Ref(); var tmp8 any = t.F_form; var tmp9 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_74; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_76; var tmp12 any = tmp11.Ref(); var tmp13 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp13 = A_arbace_spec_alpha_A_const_77; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, path__1, tmp7, tmp8, tmp10, x__4, tmp12, via__2, tmp13.Ref(), in__3))) } else { return nil } }
//line :926:1
func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Unform_STAR__O__O(x__1 any) any {









	if jrt.J2g_Truth(t.F_cpred_QMARK_) {
		if jrt.J2g_Truth(t.F_unc) {
			return lang.IFn_Cast(t.F_unc).Invoke_O__O(x__1) } else {
//line :937:1
				panic(jrt.Thrown(jrt.IllegalStateException_New_String(Lit_137))) } } else {
//line :936:1
					return x__1 } }
//line :926:1
func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Conform_STAR__O__O(x__1 any) any { var ret__2 any = lang.IFn_Cast(t.F_pred).Invoke_O__O(x__1); if






	jrt.J2g_Truth(t.F_cpred_QMARK_) { return ret__2 } else {

		if jrt.J2g_Truth(ret__2) { return x__1 } else { A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } } }
//line :926:1
func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Specize_STAR__O__O(___1 any) any { return t }
//line :926:1
func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Specize_STAR___O() any { return t }
//line :926:1
func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :926:1
func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_spec_alpha_spec_impl_reify__1740000460_A_New_IPersistentMap_O_O_O_O_O(m, t.F_form, t.F_unc, t.F_gfn, t.F_cpred_QMARK_, t.F_pred) }























func A_arbace_spec_alpha_multi_spec_impl_A_New() *A_arbace_spec_alpha_multi_spec_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_multi_spec_impl_A{}; t.Ctor(); return t }
//line :950:1
func (t *A_arbace_spec_alpha_multi_spec_impl_A) Ctor() {}
//line :950:1
func (t *A_arbace_spec_alpha_multi_spec_impl_A) Invoke_O_O_O_O_O__O(self, form__0, mmvar__1, retag__2, gfn__3 any) any { var id__5 any = jrt.UUID_RandomUUID__UUID().Ref(); var predx__6 any; var tmp1 any = A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_New_O(mmvar__1); var tmp2 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_fn_class; if



	fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_99, false); A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_fn_class = fncls__59d; tmp2 = fncls__59d } else { tmp2 = fncls__59 }; predx__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var dval__7 any; var tmp3 any = /*line :950:1*/A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_New_O(mmvar__1); var tmp4 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_fn_class; if



	fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_100, false); A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_fn_class = fncls__60d; tmp4 = fncls__60d } else { tmp4 = fncls__60 }; dval__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tag__8 any; if




	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(retag__2)) { var tmp5 any = A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_New_O(retag__2); var tmp6 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_101, false); A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_fn_class = fncls__61d; tmp6 = fncls__61d } else { tmp6 = fncls__61 }; tag__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil) } else { tag__8 = retag__2 }; return /*line :962:1*/ A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_New_IPersistentMap_O_O_O_O_O_O_O_O(nil, form__0, retag__2, mmvar__1, gfn__3, predx__6, tag__8, dval__7, id__5) }
//line :950:1
func (t *A_arbace_spec_alpha_multi_spec_impl_A) Invoke_O_O_O_O__O(self, form__0, mmvar__1, retag__2 any) any {

	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_288.GetRawRoot__O()).Invoke_O_O_O_O__O(form__0, mmvar__1, retag__2, nil)
}
func A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_New_O(p0 any) *A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A{}; t.Ctor_O(p0); return t }
//line :954:1
func (t *A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A) Ctor_O(c__mmvar any) { t.F_mmvar = c__mmvar }
//line :954:1
func (t *A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A) Invoke_O_O__O(self, p1__1740000464_SHARP___1 any) any {



	return lang.MultiFn_Cast(lang.IFn_Cast(A_arbace_spec_alpha_A_const_9.GetRawRoot__O()).Invoke_O__O(t.F_mmvar)).F_dispatchFn.Invoke_O__O(p1__1740000464_SHARP___1) }
//line :954:1
func A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_New_O(p0 any) *A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A{}; t.Ctor_O(p0); return t }
//line :954:1
func (t *A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A) Ctor_O(c__mmvar any) { t.F_mmvar = c__mmvar }
//line :954:1
func (t *A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A) Invoke_O_O__O(self, p1__1740000463_SHARP___1 any) any { var mm__2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_9.GetRawRoot__O()).Invoke_O__O(t.F_mmvar); var and__1927000168__auto____3 any = jrt.NN(lang.MultiFn_Cast(mm__2)).GetMethod_O__IFn(lang.MultiFn_Cast(mm__2).F_dispatchFn.Invoke_O__O(p1__1740000463_SHARP___1)); if

	jrt.J2g_Truth(and__1927000168__auto____3) {
		return lang.IFn_Cast(mm__2).Invoke_O__O(p1__1740000463_SHARP___1) } else {
//line :956:1
			return and__1927000168__auto____3 } }


func A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_New_O(p0 any) *A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A{}; t.Ctor_O(p0); return t }
//line :959:1
func (t *A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A) Ctor_O(c__retag any) { t.F_retag = c__retag }
//line :959:1
func (t *A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A) Invoke_O_O_O__O(self, p1__1740000465_SHARP___1, p2__1740000466_SHARP___2 any) any {
	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(p1__1740000465_SHARP___1, t.F_retag, p2__1740000466_SHARP___2)
}
func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_New_IPersistentMap_O_O_O_O_O_O_O_O(p0 lang.IPersistentMap, p1, p2, p3, p4, p5, p6, p7, p8 any) *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A { t := &A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A{}; t.Ctor_IPersistentMap_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :962:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Ctor_IPersistentMap_O_O_O_O_O_O_O_O(meta__ lang.IPersistentMap, c__form, c__retag, c__mmvar, c__gfn, c__predx, c__tag, c__dval, c__id any) { t.F___meta = meta__; t.F_form = c__form; t.F_retag = c__retag; t.F_mmvar = c__mmvar; t.F_gfn = c__gfn; t.F_predx = c__predx; t.F_tag = c__tag; t.F_dval = c__dval; t.F_id = c__id }
//line :962:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Describe_STAR___O() any { var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_69; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_130; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_131; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_287; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_131; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(t.F_form); var tmp11 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_131; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(t.F_retag))) }
//line :962:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) With_gen_STAR__O__O(gfn__1 any) any {


































	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_288; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_form, t.F_mmvar, t.F_retag, gfn__1) }
//line :962:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Gen_STAR__O_O_O__O(overrides__1, path__2, rmap__3 any) any {


















	if jrt.J2g_Truth(t.F_gfn) {
		return lang.IFn_Cast(t.F_gfn).Invoke__O() } else {
//line :981:1
			var gen__4 any; var tmp1 any = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_New_O_O_O_O_O_O(path__2, t.F_form, overrides__1, rmap__3, t.F_tag, t.F_id); var tmp2 *jrt.Class
			var fncls__64 /*line :981:1*/*jrt.Class = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_fn_class

			if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_102, false); A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_fn_class = fncls__64d; tmp2 = fncls__64d } else { tmp2 = fncls__64 }; gen__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :981:1
			var gs__5 any; var tmp3 *lang.Var












			A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_274; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_275; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_148; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_274; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_New(); var tmp12 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_fn_class
//line :992:1
			if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_103, false); A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_fn_class = fncls__65d; tmp12 = fncls__65d } else { tmp12 = fncls__65
			}
			var tmp13 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var tmp14 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp14 = A_arbace_spec_alpha_A_const_292; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp16 = A_arbace_spec_alpha_A_const_9; gs__5 = tmp4.Invoke_O_O__O(tmp6, tmp8.Invoke_O_O__O(gen__4, tmp10.Invoke_O_O__O(tmp13, tmp15.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(t.F_mmvar)))))
			var tmp17 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp17 = A_arbace_spec_alpha_A_const_145; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp19 = A_arbace_spec_alpha_A_const_156; if jrt.J2g_Truth(tmp18.Invoke_O_O__O(jrt.NN(tmp19).GetRawRoot__O(), gs__5)) {
				var tmp20 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp20 = A_arbace_spec_alpha_A_const_291; return lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(gs__5) } else {
//line :995:1
					return nil } } }
//line :962:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, x__4 any) any { var dv__5 any = lang.IFn_Cast(t.F_dval).Invoke_O__O(x__4); var path__6 any; var tmp1 *lang.Var;













	A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_10; path__6 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(path__1, dv__5); var temp__1927000408__auto____7 any = /*line :962:1*/lang.IFn_Cast(t.F_predx).Invoke_O__O(x__4); if














	jrt.J2g_Truth(temp__1927000408__auto____7) { var pred__8 any = temp__1927000408__auto____7; var tmp2 *lang.Var
		A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_282; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(t.F_form, pred__8, path__6, via__2, in__3, x__4) } else {
//line :977:1
			var tmp3 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_72; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_73; var tmp6 any = tmp5.Ref(); var tmp7 any = t.F_form; var tmp8 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_74; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp10 = A_arbace_spec_alpha_A_const_75; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp12 = A_arbace_spec_alpha_A_const_76; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp14 = A_arbace_spec_alpha_A_const_77; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, path__6, tmp6, tmp7, tmp9, x__4, tmp11, Lit_104, tmp13, via__2, tmp14.Ref(), in__3))) } }
//line :962:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Unform_STAR__O__O(x__1 any) any { var temp__1927000408__auto____2 any = lang.IFn_Cast(t.F_predx).Invoke_O__O(x__1); if








	jrt.J2g_Truth(temp__1927000408__auto____2) { var pred__3 any = temp__1927000408__auto____2; var tmp1 *lang.Var
		A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_284; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(pred__3, x__1) } else {
//line :971:1
			var tmp2 any = t.F_form; panic(jrt.Thrown(jrt.IllegalStateException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_105, nil, Lit_106, nil), jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil, lang.IFn_Cast(t.F_dval).Invoke_O__O(x__1)))))) } }
//line :962:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Conform_STAR__O__O(x__1 any) any { var temp__1927000408__auto____2 any = lang.IFn_Cast(t.F_predx).Invoke_O__O(x__1); if





	jrt.J2g_Truth(temp__1927000408__auto____2) { var pred__3 any = temp__1927000408__auto____2; var tmp1 *lang.Var
		A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_254; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(pred__3, x__1, t.F_form) } else {
//line :968:1
			A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } }
//line :962:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Specize_STAR__O__O(___1 any) any { return t }
//line :962:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Specize_STAR___O() any { return t }
//line :962:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :962:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_New_IPersistentMap_O_O_O_O_O_O_O_O(m, t.F_form, t.F_retag, t.F_mmvar, t.F_gfn, t.F_predx, t.F_tag, t.F_dval, t.F_id) }




















func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :983:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A) Ctor_O_O_O_O_O_O(c__path, c__form, c__overrides, c__rmap, c__tag, c__id any) { t.F_path = c__path; t.F_form = c__form; t.F_overrides = c__overrides; t.F_rmap = c__rmap; t.F_tag = c__tag; t.F_id = c__id }
//line :983:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A) Invoke_O_O__O(self, p__1740000475__1 any) any { var vec__1740000477__2 any = p__1740000475__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1740000477__2, lang.RT_IntCast_J__I(0), nil); var f__4 any = lang.RT_Nth_O_I_O__O(vec__1740000477__2, lang.RT_IntCast_J__I(1), nil); var p__5 any = lang.IFn_Cast(f__4).Invoke_O__O(nil); var rmap__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_271.GetRawRoot__O()).Invoke_O_O__O(t.F_rmap, t.F_id); if


	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_272.GetRawRoot__O()).Invoke_O_O_O_O__O(rmap__6, t.F_id, t.F_path, k__3)) { return nil } else {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_273.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_New_O_O_O_O_O_O_O(t.F_path, t.F_form, rmap__6, t.F_overrides, k__3, p__5, t.F_tag); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_107, false); A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; return tmp1.Invoke_O__O(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))) } }
//line :987:1
func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :987:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A) Ctor_O_O_O_O_O_O_O(c__path, c__form, c__rmap, c__overrides, c__k, c__p, c__tag any) { t.F_path = c__path; t.F_form = c__form; t.F_rmap = c__rmap; t.F_overrides = c__overrides; t.F_k = c__k; t.F_p = c__p; t.F_tag = c__tag }
//line :987:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A) Invoke_O__O(self any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_289.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_New_O_O(t.F_k, t.F_tag); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_108, false); A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_108.GetRawRoot__O()); var tmp6 any; var t_ any = t.F_p

	t.F_p = nil; tmp6 = t_
//line :988:1
	var tmp7 any = tmp6; var tmp8 any; var t__2 any = t.F_overrides

	t.F_overrides = nil; tmp8 = t__2
//line :988:1
	var tmp9 any = tmp8; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()); var tmp11 any; var t__3 any = t.F_path

	t.F_path = nil; tmp11 = t__3
//line :988:1
	var tmp12 any = tmp10.Invoke_O_O__O(tmp11, t.F_k); var tmp13 any; var t__4 any = t.F_rmap

	t.F_rmap = nil; tmp13 = t__4
//line :988:1
	var tmp14 any = tmp13; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()); var tmp16 any = A_arbace_spec_alpha_A_const_290; var tmp17 any; var t__5 any = t.F_form

	t.F_form = nil; tmp17 = t__5
//line :988:1
	var tmp18 any = tmp17; var tmp19 any; var t__6 any = t.F_k

	t.F_k = nil; tmp19 = t__6
//line :988:1
	return tmp1.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O_O_O_O__O(tmp7, tmp9, tmp12, tmp14, tmp15.Invoke_O_O_O__O(tmp16, tmp18, tmp19))) }
//line :988:1
func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A{}; t.Ctor_O_O(p0, p1); return t }
//line :988:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A) Ctor_O_O(c__k, c__tag any) { t.F_k = c__k; t.F_tag = c__tag }
//line :988:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A) Invoke_O_O__O(self, p1__1740000467_SHARP___1 any) any {
	return lang.IFn_Cast(t.F_tag).Invoke_O_O__O(p1__1740000467_SHARP___1, t.F_k)
}

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_New() *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A{}; t.Ctor(); return t }
//line :992:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A) Ctor() {}
//line :992:1
func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A) Invoke_O_O__O(self, p__1740000485__1 any) any { var vec__1740000487__2 any = p__1740000485__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1740000487__2, lang.RT_IntCast_J__I(0), nil); return lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(k__3) }







func A_arbace_spec_alpha_tuple_impl_A_New() *A_arbace_spec_alpha_tuple_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_tuple_impl_A{}; t.Ctor(); return t }
//line :1000:1
func (t *A_arbace_spec_alpha_tuple_impl_A) Ctor() {}
//line :1000:1
func (t *A_arbace_spec_alpha_tuple_impl_A) Invoke_O_O_O_O__O(self, forms__0, preds__1, gfn__2 any) any { var specs__4 any; var tmp1 any = A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_New_O_O(forms__0, preds__1); var tmp2 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_fn_class; if



	fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_138, false); A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_fn_class = fncls__66d; tmp2 = fncls__66d } else { tmp2 = fncls__66 }; specs__4 = /*line :1000:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var cnt__5 int32 = lang.RT_Count_O__I(preds__1); return /*line :1006:1*/ A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_New_IPersistentMap_I_O_O_O_O(nil, cnt__5, gfn__2, forms__0, preds__1, specs__4) }
//line :1000:1
func (t *A_arbace_spec_alpha_tuple_impl_A) Invoke_O_O_O__O(self, forms__0, preds__1 any) any {

	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_294.GetRawRoot__O()).Invoke_O_O_O__O(forms__0, preds__1, nil)
}
func A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_tuple_impl_fn__1740000493_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_tuple_impl_fn__1740000493_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1004:1
func (t *A_arbace_spec_alpha_tuple_impl_fn__1740000493_A) Ctor_O_O(c__forms, c__preds any) { t.F_forms = c__forms; t.F_preds = c__preds }
//line :1004:1
func (t *A_arbace_spec_alpha_tuple_impl_fn__1740000493_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_A_const_43.GetRawRoot__O(); var tmp3 any; var t_ any = t.F_preds; t.F_preds = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_forms; t.F_forms = nil; tmp5 = t__2; return tmp1.Invoke_O_O_O__O(tmp2, tmp4, tmp5) }

func A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_New_IPersistentMap_I_O_O_O_O(p0 lang.IPersistentMap, p1 int32, p2, p3, p4, p5 any) *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A { t := &A_arbace_spec_alpha_tuple_impl_reify__1740000495_A{}; t.Ctor_IPersistentMap_I_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :1006:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Ctor_IPersistentMap_I_O_O_O_O(meta__ lang.IPersistentMap, c__cnt int32, c__gfn, c__forms, c__preds, c__specs any) { t.F___meta = meta__; t.F_cnt = c__cnt; t.F_gfn = c__gfn; t.F_forms = c__forms; t.F_preds = c__preds; t.F_specs = c__specs }
//line :1006:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Describe_STAR___O() any { var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_69; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_130; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_131; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_293; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6.Invoke_O__O(tmp7), t.F_forms)) }
//line :1006:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) With_gen_STAR__O__O(gfn__1 any) any {




















































	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_294; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_forms, t.F_preds, gfn__1) }
//line :1006:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Gen_STAR__O_O_O__O(overrides__1, path__2, rmap__3 any) any {













































	if jrt.J2g_Truth(t.F_gfn) {
		return lang.IFn_Cast(t.F_gfn).Invoke__O() } else {
//line :1052:1
			var gen__4 any; var tmp1 any = A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_New_O_O_O(path__2, overrides__1, rmap__3); var tmp2 *jrt.Class
			var fncls__67 /*line :1052:1*/*jrt.Class = A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_fn_class

			if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_139, false); A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_fn_class = fncls__67d; tmp2 = fncls__67d } else { tmp2 = fncls__67 }; gen__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :1052:1
			var gs__5 any; var tmp3 *lang.Var



			A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_148; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_295; gs__5 = tmp4.Invoke_O_O_O_O__O(gen__4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(t.F_preds)).Ref()), t.F_preds, t.F_forms)
			var tmp6 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_145; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_156; if jrt.J2g_Truth(tmp7.Invoke_O_O__O(jrt.NN(tmp8).GetRawRoot__O(), gs__5)) {
				var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_158; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_262; return tmp10.Invoke_O_O__O(jrt.NN(tmp11).GetRawRoot__O(), gs__5) } else {
//line :1057:1
					return nil } } }
//line :1006:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, x__4 any) any {






























	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_16; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_296; if jrt.J2g_Truth(tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__4))) { var tmp4 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_72; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_73; var tmp7 any = tmp6.Ref(); var tmp8 any; A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_297; var tmp9 any = tmp8; var tmp10 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp10 = A_arbace_spec_alpha_A_const_74; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp12 = A_arbace_spec_alpha_A_const_76; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp14 = A_arbace_spec_alpha_A_const_77; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, path__1, tmp7, tmp9, tmp11, x__4, tmp13, via__2, tmp14.Ref(), in__3))) } else { var tmp15 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp15 = A_arbace_spec_alpha_A_const_32; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(x__4)).Ref(), jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(t.F_preds)).Ref())) { var tmp16 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp16 = A_arbace_spec_alpha_A_const_72; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp18 = A_arbace_spec_alpha_A_const_73; var tmp19 any = tmp18.Ref(); var tmp20 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp20 = A_arbace_spec_alpha_A_const_69; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp22 = A_arbace_spec_alpha_A_const_130; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp24 = A_arbace_spec_alpha_A_const_131; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 any; A_arbace_spec_alpha_A_Init(); tmp26 = A_arbace_spec_alpha_A_const_298; var tmp27 any = tmp25.Invoke_O__O(tmp26); var tmp28 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp28 = A_arbace_spec_alpha_A_const_131; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp30 = A_arbace_spec_alpha_A_const_69; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp32 = A_arbace_spec_alpha_A_const_130; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp34 = A_arbace_spec_alpha_A_const_131; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 any; A_arbace_spec_alpha_A_Init(); tmp36 = A_arbace_spec_alpha_A_const_299; var tmp37 any = tmp35.Invoke_O__O(tmp36); var tmp38 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp38 = A_arbace_spec_alpha_A_const_131; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 any; A_arbace_spec_alpha_A_Init(); tmp40 = A_arbace_spec_alpha_A_const_300; var tmp41 any = tmp29.Invoke_O__O(tmp31.Invoke_O__O(tmp33.Invoke_O_O__O(tmp37, tmp39.Invoke_O__O(tmp40)))); var tmp42 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp42 = A_arbace_spec_alpha_A_const_131; var tmp43 any = tmp21.Invoke_O__O(tmp23.Invoke_O_O_O__O(tmp27, tmp41, lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(t.F_preds)).Ref()))); var tmp44 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp44 = A_arbace_spec_alpha_A_const_74; var tmp45 any = tmp44.Ref(); var tmp46 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp46 = A_arbace_spec_alpha_A_const_76; var tmp47 any = tmp46.Ref(); var tmp48 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp48 = A_arbace_spec_alpha_A_const_77; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, path__1, tmp19, tmp43, tmp45, x__4, tmp47, via__2, tmp48.Ref(), in__3))) } else { var tmp49 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp49 = A_arbace_spec_alpha_A_const_51; if tmp49 != nil {







		var tmp50 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp50 = A_arbace_spec_alpha_A_const_158; var tmp51 lang.IFn = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()); var tmp52 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp52 = A_arbace_spec_alpha_A_const_130; var tmp53 any = jrt.NN(tmp52).GetRawRoot__O(); var tmp54 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp54 = A_arbace_spec_alpha_A_const_148; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 any = A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_New_O_O_O_O(in__3, path__1, via__2, x__4); var tmp57 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_fn_class
		if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_140, false); A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_fn_class = fncls__68d; tmp57 = fncls__68d } else { tmp57 = fncls__68 }
//line :1045:1
		var tmp58 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp56, tmp57, nil); var tmp59 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp59 = A_arbace_spec_alpha_A_const_295; return tmp51.Invoke_O_O__O(tmp53, tmp55.Invoke_O_O_O_O__O(tmp58, lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(t.F_preds)).Ref()), t.F_forms, t.F_preds)) } else {
//line :1037:1
			return nil } } } }
//line :1006:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Unform_STAR__O__O(x__1 any) any {




















	{ var tmp1 any; var and__1927000168__auto____2 any; var tmp2 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_296; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__1); if jrt.J2g_Truth(and__1927000168__auto____2) {
		tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(int64(lang.RT_Count_O__I(x__1)), int64(lang.RT_Count_O__I(t.F_preds)))).Ref() } else {
//line :1027:1
			tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { } else { var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil); var tmp4 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_84; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_301; panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, tmp5.Invoke_O__O(tmp6))).Ref()))) }
//line :1006:1
		var ret__2 any = x__1; var i__3 int64 = 0; L1: for {























			if lang.Util_Equiv_J_J__Z(i__3, int64(lang.RT_Count_O__I(x__1))) { return ret__2 } else { var cv__4 any = lang.IFn_Cast(x__1).Invoke_O__O(jrt.Long_ValueOf_J__Long(i__3).Ref()); var v__5 any; var tmp7 *lang.Var


				A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_284; var tmp8 lang.IFn = lang.IFn_Cast(t.F_preds); v__5 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(tmp8.Invoke_O__O(jrt.Long_ValueOf_J__Long(i__3).Ref()), cv__4)
				var tmp9 any; if lang.Util_Identical_O_O__Z(cv__4, v__5) { tmp9 = ret__2 } else { var tmp10 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp10 = A_arbace_spec_alpha_A_const_22; tmp9 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O_O__O(ret__2, jrt.Long_ValueOf_J__Long(i__3).Ref(), v__5) }; ret__2, i__3 = tmp9, lang.Numbers_Inc_J__J(i__3); continue L1 } } }
//line :1006:1
	panic("j2g: unreachable") }
//line :1006:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Conform_STAR__O__O(x__1 any) any { { var specs__2 any; var tmp1 *lang.Var






	A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_9; specs__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_specs)
	var tmp2 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_16; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var and__1927000168__auto____3 any; var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_296; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(x__1); if jrt.J2g_Truth(and__1927000168__auto____3) {
		tmp4 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_J_J__Z(int64(lang.RT_Count_O__I(x__1)), int64(t.F_cnt))).Ref() } else {
//line :1014:1
			tmp4 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp3.Invoke_O__O(tmp4)) { A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } else { var ret__3 any = x__1; var i__4 int64 = 0; L1: for {



				if lang.Util_Equiv_J_J__Z(i__4, int64(t.F_cnt)) { return ret__3 } else { var v__5 any = lang.IFn_Cast(x__1).Invoke_O__O(jrt.Long_ValueOf_J__Long(i__4).Ref()); var cv__6 any; var target_69 any = lang.IFn_Cast(specs__2).Invoke_O__O(jrt.Long_ValueOf_J__Long(i__4).Ref()); var tmp6 bool; var tmp7 bool


					tmp7 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_69); if tmp7 { tmp7 = !lang.Compiler_AOT_IsDyn_O__Z(target_69) }; tmp6 = tmp7; if tmp6 { cv__6 = A_arbace_spec_alpha_Spec_A_Cast(target_69).Conform_STAR__O__O(v__5) } else { var tmp8 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_44; cv__6 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(target_69, v__5) }
					var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_246; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(cv__6)) { A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } else {

						var tmp10 any; if lang.Util_Identical_O_O__Z(cv__6, v__5) { tmp10 = ret__3 } else { var tmp11 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_22; tmp10 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O_O__O(ret__3, jrt.Long_ValueOf_J__Long(i__4).Ref(), cv__6) }; ret__3, i__4 = tmp10, lang.Numbers_Inc_J__J(i__4); continue L1 } } } } }; /*line :1006:1*/panic("j2g: unreachable") }
//line :1006:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Specize_STAR__O__O(___1 any) any { return t }
//line :1006:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Specize_STAR___O() any { return t }
//line :1006:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :1006:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_New_IPersistentMap_I_O_O_O_O(m, t.F_cnt, t.F_gfn, t.F_forms, t.F_preds, t.F_specs) }







































func A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1046:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A) Ctor_O_O_O_O(c__in, c__path, c__via, c__x any) { t.F_in = c__in; t.F_path = c__path; t.F_via = c__via; t.F_x = c__x }
//line :1046:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A) Invoke_O_O_O_O__O(self, i__1, form__2, pred__3 any) any { var v__4 any = lang.IFn_Cast(t.F_x).Invoke_O__O(i__1); if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_281.GetRawRoot__O()).Invoke_O_O__O(pred__3, v__4)) { return nil } else {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_282.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(t.F_path, i__1); var tmp3 any = t.F_via; return tmp1.Invoke_O_O_O_O_O_O__O(form__2, pred__3, tmp2, tmp3, lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(t.F_in, i__1), v__4) } }




func A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_New_O_O_O(p0, p1, p2 any) *A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1054:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A) Ctor_O_O_O(c__path, c__overrides, c__rmap any) { t.F_path = c__path; t.F_overrides = c__overrides; t.F_rmap = c__rmap }
//line :1054:1
func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A) Invoke_O_O_O_O__O(self, i__1, p__2, f__3 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_108.GetRawRoot__O()); var tmp2 any = t.F_overrides; return tmp1.Invoke_O_O_O_O_O__O(p__2, tmp2, lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(t.F_path, i__1), t.F_rmap, f__3)
}





func A_arbace_spec_alpha_tagged_ret_A_New() *A_arbace_spec_alpha_tagged_ret_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_tagged_ret_A{}; t.Ctor(); return t }
//line :1062:1
func (t *A_arbace_spec_alpha_tagged_ret_A) Ctor() {}
//line :1062:1
func (t *A_arbace_spec_alpha_tagged_ret_A) Invoke_O_O_O__O(self, tag__0, ret__1 any) any { return lang.MapEntry_New_O_O(tag__0, ret__1) }


func A_arbace_spec_alpha_or_spec_impl_A_New() *A_arbace_spec_alpha_or_spec_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_or_spec_impl_A{}; t.Ctor(); return t }
//line :1065:1
func (t *A_arbace_spec_alpha_or_spec_impl_A) Ctor() {}
//line :1065:1
func (t *A_arbace_spec_alpha_or_spec_impl_A) Invoke_O_O_O_O_O__O(self, keys__0, forms__1, preds__2, gfn__3 any) any { var id__5 any = jrt.UUID_RandomUUID__UUID().Ref(); var kps__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_267.GetRawRoot__O()).Invoke_O_O__O(keys__0, preds__2); var specs__7 any; var tmp1 any = A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_New_O_O(forms__1, preds__2); var tmp2 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_fn_class; if




	fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_123, false); A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_fn_class = fncls__70d; tmp2 = fncls__70d } else { tmp2 = fncls__70 }; specs__7 = /*line :1065:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var cform__8 any; var G__1740000505__8_ int32 = lang.RT_Count_O__I(preds__2); L1:





	switch { default: switch G__1740000505__8_ { case 2:
		var tmp3 any = A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_New_O_O(specs__7, keys__0); var tmp4 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_124, false); A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_fn_class = fncls__74d; tmp4 = fncls__74d } else { tmp4 = fncls__74 }; cform__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
//line :1071:1
		break L1; case 3:









		var tmp5 any = A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_New_O_O(specs__7, keys__0); var tmp6 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_125, false); A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_fn_class = fncls__78d; tmp6 = fncls__78d } else { tmp6 = fncls__78 }; cform__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)
//line :1071:1
		break L1; default:
	}




















		var tmp7 any = A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_New_O_O(specs__7, keys__0); var tmp8 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_126, false); A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_fn_class = fncls__80d; tmp8 = fncls__80d } else { tmp8 = fncls__80 }; cform__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)}; return /*line :1103:1*/ A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_New_IPersistentMap_O_O_O_O_O_O_O(nil, kps__6, gfn__3, forms__1, preds__2, keys__0, id__5, cform__8) }
//line :1070:1
func A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1070:1
func (t *A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A) Ctor_O_O(c__forms, c__preds any) { t.F_forms = c__forms; t.F_preds = c__preds }
//line :1070:1
func (t *A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_A_const_43.GetRawRoot__O(); var tmp3 any; var t_ any = t.F_preds; t.F_preds = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_forms; t.F_forms = nil; tmp5 = t__2; return tmp1.Invoke_O_O_O__O(tmp2, tmp4, tmp5) }

func A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1072:1
func (t *A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A) Ctor_O_O(c__specs, c__keys any) { t.F_specs = c__specs; t.F_keys = c__keys }
//line :1072:1
func (t *A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A) Invoke_O_O__O(self, x__1 any) any { var specs__2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_9.GetRawRoot__O()).Invoke_O__O(t.F_specs); var ret__3 any; var target_72 any = lang.IFn_Cast(specs__2).Invoke_O__O(A_arbace_spec_alpha_A_const_195); var tmp1 bool; var tmp2 bool; tmp2 =

	A_arbace_spec_alpha_Spec_A_InstanceOf(target_72); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_72) }; tmp1 = tmp2; if tmp1 { ret__3 = A_arbace_spec_alpha_Spec_A_Cast(target_72).Conform_STAR__O__O(x__1) } else { ret__3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_72, x__1) }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(ret__3)) { var ret__4 any; var target_73 any = lang.IFn_Cast(specs__2).Invoke_O__O(A_arbace_spec_alpha_A_const_260); var tmp3 bool; var tmp4 bool
		tmp4 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_73); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z(target_73) }; tmp3 = tmp4; if tmp3 { ret__4 = A_arbace_spec_alpha_Spec_A_Cast(target_73).Conform_STAR__O__O(x__1) } else { ret__4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_73, x__1) }
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(ret__4)) { return A_arbace_spec_alpha_A_const_42 } else {

			return lang.IFn_Cast(A_arbace_spec_alpha_A_const_302.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_keys).Invoke_O__O(A_arbace_spec_alpha_A_const_260), ret__4) } } else {
				return lang.IFn_Cast(A_arbace_spec_alpha_A_const_302.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_keys).Invoke_O__O(A_arbace_spec_alpha_A_const_195), ret__3) } }
func A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1081:1
func (t *A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A) Ctor_O_O(c__specs, c__keys any) { t.F_specs = c__specs; t.F_keys = c__keys }
//line :1081:1
func (t *A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A) Invoke_O_O__O(self, x__1 any) any { var specs__2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_9.GetRawRoot__O()).Invoke_O__O(t.F_specs); var ret__3 any; var target_75 any = lang.IFn_Cast(specs__2).Invoke_O__O(A_arbace_spec_alpha_A_const_195); var tmp1 bool; var tmp2 bool; tmp2 =

	A_arbace_spec_alpha_Spec_A_InstanceOf(target_75); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_75) }; tmp1 = tmp2; if tmp1 { ret__3 = A_arbace_spec_alpha_Spec_A_Cast(target_75).Conform_STAR__O__O(x__1) } else { ret__3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_75, x__1) }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(ret__3)) { var ret__4 any; var target_76 any = lang.IFn_Cast(specs__2).Invoke_O__O(A_arbace_spec_alpha_A_const_260); var tmp3 bool; var tmp4 bool
		tmp4 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_76); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z(target_76) }; tmp3 = tmp4; if tmp3 { ret__4 = A_arbace_spec_alpha_Spec_A_Cast(target_76).Conform_STAR__O__O(x__1) } else { ret__4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_76, x__1) }
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(ret__4)) { var ret__5 any; var target_77 any = lang.IFn_Cast(specs__2).Invoke_O__O(A_arbace_spec_alpha_A_const_172); var tmp5 bool; var tmp6 bool
			tmp6 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_77); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z(target_77) }; tmp5 = tmp6; if tmp5 { ret__5 = A_arbace_spec_alpha_Spec_A_Cast(target_77).Conform_STAR__O__O(x__1) } else { ret__5 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_77, x__1) }
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(ret__5)) { return A_arbace_spec_alpha_A_const_42 } else {

				return lang.IFn_Cast(A_arbace_spec_alpha_A_const_302.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_keys).Invoke_O__O(A_arbace_spec_alpha_A_const_172), ret__5) } } else {
					return lang.IFn_Cast(A_arbace_spec_alpha_A_const_302.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_keys).Invoke_O__O(A_arbace_spec_alpha_A_const_260), ret__4) } } else {
						return lang.IFn_Cast(A_arbace_spec_alpha_A_const_302.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_keys).Invoke_O__O(A_arbace_spec_alpha_A_const_195), ret__3) } }
func A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1093:1
func (t *A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A) Ctor_O_O(c__specs, c__keys any) { t.F_specs = c__specs; t.F_keys = c__keys }
//line :1093:1
func (t *A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A) Invoke_O_O__O(self, x__1 any) any { { var specs__2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_9.GetRawRoot__O()).Invoke_O__O(t.F_specs); var i__3 int64 = 0; L1: for {


	if lang.Numbers_Lt_J_J__Z(i__3, int64(lang.RT_Count_O__I(specs__2))) { var spec__4 any = lang.IFn_Cast(specs__2).Invoke_O__O(jrt.Long_ValueOf_J__Long(i__3).Ref()); var ret__5 any; var target_79 any = spec__4; var tmp1 bool; var tmp2 bool

		tmp2 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_79); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_79) }; tmp1 = tmp2; if tmp1 { ret__5 = A_arbace_spec_alpha_Spec_A_Cast(target_79).Conform_STAR__O__O(x__1) } else { ret__5 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_79, x__1) }
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(ret__5)) {
			i__3 = lang.Numbers_Inc_J__J(i__3); continue L1 } else {
				var tmp3 lang.IFn = lang.IFn_Cast(t.F_keys); return lang.IFn_Cast(A_arbace_spec_alpha_A_const_302.GetRawRoot__O()).Invoke_O_O__O(tmp3.Invoke_O__O(jrt.Long_ValueOf_J__Long(i__3).Ref()), ret__5) } } else {
//line :1096:1
					return A_arbace_spec_alpha_A_const_42 } } }; /*line :1093:1*/panic("j2g: unreachable") }









func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_New_IPersistentMap_O_O_O_O_O_O_O(p0 lang.IPersistentMap, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A { t := &A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A{}; t.Ctor_IPersistentMap_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :1103:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Ctor_IPersistentMap_O_O_O_O_O_O_O(meta__ lang.IPersistentMap, c__kps, c__gfn, c__forms, c__preds, c__keys, c__id, c__cform any) { t.F___meta = meta__; t.F_kps = c__kps; t.F_gfn = c__gfn; t.F_forms = c__forms; t.F_preds = c__preds; t.F_keys = c__keys; t.F_id = c__id; t.F_cform = c__cform }
//line :1103:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Describe_STAR___O() any { var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_69; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_130; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_131; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_303; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_179; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_159; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O_O_O__O(jrt.NN(tmp11).GetRawRoot__O(), t.F_keys, t.F_forms))) }
//line :1103:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) With_gen_STAR__O__O(gfn__1 any) any {

























	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_304; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_keys, t.F_forms, t.F_preds, gfn__1) }
//line :1103:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Gen_STAR__O_O_O__O(overrides__1, path__2, rmap__3 any) any {















	if jrt.J2g_Truth(t.F_gfn) {
		return lang.IFn_Cast(t.F_gfn).Invoke__O() } else {
//line :1119:1
			var gen__4 any; var tmp1 any = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_New_O_O_O_O(path__2, overrides__1, rmap__3, t.F_id); var tmp2 *jrt.Class
			var fncls__82 /*line :1119:1*/*jrt.Class = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_fn_class

			if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_127, false); A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_fn_class = fncls__82d; tmp2 = fncls__82d } else { tmp2 = fncls__82 }; gen__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :1119:1
			var gs__5 any; var tmp3 *lang.Var






			A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_274; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_275; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_148; gs__5 = tmp4.Invoke_O_O__O(tmp6, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O_O_O__O(gen__4, t.F_keys, t.F_preds, t.F_forms))
			var tmp8 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_63; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(gs__5)) { return nil } else {
				var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_291; return lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(gs__5) } } }
//line :1103:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, x__4 any) any {








	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_281; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t, x__4)) { return nil } else {
		var tmp2 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_158; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_130; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_148; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_New_O_O_O_O(in__3, path__1, via__2, x__4); var tmp9 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_fn_class
		if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_128, false); A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_fn_class = fncls__83d; tmp9 = fncls__83d } else { tmp9 = fncls__83 }
//line :1113:1
		return tmp3.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), t.F_keys, t.F_forms, t.F_preds)) } }
//line :1103:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Unform_STAR__O__O(p__1740000512__1 any) any { var vec__1740000514__2 any = p__1740000512__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1740000514__2, lang.RT_IntCast_J__I(0), nil); var x__4 any = lang.RT_Nth_O_I_O__O(vec__1740000514__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var;






	A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_284; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_kps).Invoke_O__O(k__3), x__4) }
//line :1103:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Conform_STAR__O__O(x__1 any) any {





	return lang.IFn_Cast(t.F_cform).Invoke_O__O(x__1) }
//line :1103:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Specize_STAR__O__O(___1 any) any { return t }
//line :1103:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Specize_STAR___O() any { return t }
//line :1103:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :1103:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_New_IPersistentMap_O_O_O_O_O_O_O(m, t.F_kps, t.F_gfn, t.F_forms, t.F_preds, t.F_keys, t.F_id, t.F_cform) }










func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1114:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A) Ctor_O_O_O_O(c__in, c__path, c__via, c__x any) { t.F_in = c__in; t.F_path = c__path; t.F_via = c__via; t.F_x = c__x }
//line :1114:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A) Invoke_O_O_O_O__O(self, k__1, form__2, pred__3 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_281.GetRawRoot__O()).Invoke_O_O__O(pred__3, t.F_x)) { return nil } else {
		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_282.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(form__2, pred__3, lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(t.F_path, k__1), t.F_via, t.F_in, t.F_x)
	}
}


func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1121:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A) Ctor_O_O_O_O(c__path, c__overrides, c__rmap, c__id any) { t.F_path = c__path; t.F_overrides = c__overrides; t.F_rmap = c__rmap; t.F_id = c__id }
//line :1121:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A) Invoke_O_O_O_O__O(self, k__1, p__2, f__3 any) any { var rmap__4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_271.GetRawRoot__O()).Invoke_O_O__O(t.F_rmap, t.F_id); if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_272.GetRawRoot__O()).Invoke_O_O_O_O__O(rmap__4, t.F_id, t.F_path, k__1)) { return nil } else {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_273.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_New_O_O_O_O_O_O(t.F_path, f__3, rmap__4, t.F_overrides, k__1, p__2); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_129, false); A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; return tmp1.Invoke_O__O(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil))) } }
//line :1124:1
func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :1124:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A) Ctor_O_O_O_O_O_O(c__path, c__f, c__rmap, c__overrides, c__k, c__p any) { t.F_path = c__path; t.F_f = c__f; t.F_rmap = c__rmap; t.F_overrides = c__overrides; t.F_k = c__k; t.F_p = c__p }
//line :1124:1
func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A) Invoke_O__O(self any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_108.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_p; t.F_p = nil; tmp2 = t_; var tmp3 any = tmp2; var tmp4 any; var t__2 any = t.F_overrides; t.F_overrides = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()); var tmp7 any; var t__3 any = t.F_path; t.F_path = nil; tmp7 = t__3; var tmp8 any = tmp7; var tmp9 any; var t__4 any = t.F_k; t.F_k = nil; tmp9 = t__4; var tmp10 any = tmp6.Invoke_O_O__O(tmp8, tmp9); var tmp11 any; var t__5 any = t.F_rmap; t.F_rmap = nil; tmp11 = t__5; var tmp12 any = tmp11; var tmp13 any; var t__6 any = t.F_f; t.F_f = nil; tmp13 = t__6; return tmp1.Invoke_O_O_O_O_O__O(tmp3, tmp5, tmp10, tmp12, tmp13)
}





func A_arbace_spec_alpha_and_preds_A_New() *A_arbace_spec_alpha_and_preds_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_and_preds_A{}; t.Ctor(); return t }
//line :1132:1
func (t *A_arbace_spec_alpha_and_preds_A) Ctor() {}
//line :1132:1
func (t *A_arbace_spec_alpha_and_preds_A) Invoke_O_O_O_O__O(self, x__0, preds__1, forms__2 any) any { { var ret__4 any = x__0; var G__1740000531__5_ any = preds__1; var vec__1740000533__6 any = G__1740000531__5_; var seq__1740000534__7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000533__6); var first__1740000535__8 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000534__7); var seq__1740000534__9 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000534__7); var pred__10 any = first__1740000535__8; var preds__11 any = seq__1740000534__9; var G__1740000532__12_ any = forms__2; var vec__1740000536__13 any = G__1740000532__12_; var seq__1740000537__14 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000536__13); var first__1740000538__15 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000537__14); var seq__1740000537__16 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000537__14); var form__17 any = first__1740000538__15; var forms__18 any = seq__1740000537__16; var ret__19 any = ret__4; var G__1740000531__20_ any = G__1740000531__5_; var G__1740000532__21_ any = G__1740000532__12_; _ = pred__10; _ = preds__11; _ = form__17; _ = forms__18; L1: for { var ret__22 any = ret__19; var vec__1740000539__23 any = G__1740000531__20_; var seq__1740000540__24 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000539__23); var first__1740000541__25 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000540__24); var seq__1740000540__26 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000540__24); var pred__27 any = first__1740000541__25; var preds__28 any = seq__1740000540__26; var vec__1740000542__29 any = G__1740000532__21_; var seq__1740000543__30 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000542__29); var first__1740000544__31 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000543__30); var seq__1740000543__32 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000543__30)
													var form__33 any = first__1740000544__31
													var forms__34 any = seq__1740000543__32

	if jrt.J2g_Truth(pred__27) { var nret__35 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_254.GetRawRoot__O()).Invoke_O_O_O__O(pred__27, ret__22, form__33)

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(nret__35)) { return A_arbace_spec_alpha_A_const_42 } else {


			ret__19, G__1740000531__20_, G__1740000532__21_ = nret__35, preds__28, forms__34; continue L1 } } else {
//line :1136:1
				return ret__22 } } }; /*line :1132:1*/panic("j2g: unreachable") }











func A_arbace_spec_alpha_explain_pred_list_A_New() *A_arbace_spec_alpha_explain_pred_list_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_explain_pred_list_A{}; t.Ctor(); return t }
//line :1144:1
func (t *A_arbace_spec_alpha_explain_pred_list_A) Ctor() {}
//line :1144:1
func (t *A_arbace_spec_alpha_explain_pred_list_A) Invoke_O_O_O_O_O_O_O__O(self, forms__0, preds__1, path__2, via__3, in__4, x__5 any) any { { var ret__7 any = x__5; var G__1740000552__8_ any = forms__0; var vec__1740000554__9 any = G__1740000552__8_; var seq__1740000555__10 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000554__9); var first__1740000556__11 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000555__10); var seq__1740000555__12 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000555__10); var form__13 any = first__1740000556__11; var forms__14 any = seq__1740000555__12; var G__1740000553__15_ any = preds__1; var vec__1740000557__16 any = G__1740000553__15_; var seq__1740000558__17 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000557__16); var first__1740000559__18 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000558__17); var seq__1740000558__19 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000558__17); var pred__20 any = first__1740000559__18; var preds__21 any = seq__1740000558__19; var ret__22 any = ret__7; var G__1740000552__23_ any = G__1740000552__8_; var G__1740000553__24_ any = G__1740000553__15_; _ = form__13; _ = forms__14; _ = pred__20; _ = preds__21; L1: for { var ret__25 any = ret__22; var vec__1740000560__26 any = G__1740000552__23_; var seq__1740000561__27 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000560__26); var first__1740000562__28 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000561__27); var seq__1740000561__29 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000561__27); var form__30 any = first__1740000562__28; var forms__31 any = seq__1740000561__29; var vec__1740000563__32 any = G__1740000553__24_; var seq__1740000564__33 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000563__32); var first__1740000565__34 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000564__33); var seq__1740000564__35 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000564__33)
																		var pred__36 any = first__1740000565__34
																		var preds__37 any = seq__1740000564__35


	if jrt.J2g_Truth(pred__36) { var nret__38 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_254.GetRawRoot__O()).Invoke_O_O_O__O(pred__36, ret__25, form__30)

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(nret__38)) {
			return lang.IFn_Cast(A_arbace_spec_alpha_A_const_282.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(form__30, pred__36, path__2, via__3, in__4, ret__25) } else {
				ret__22, G__1740000552__23_, G__1740000553__24_ = nret__38, forms__31, preds__37; continue L1 } } else {
//line :1149:1
					return nil } } }; /*line :1144:1*/panic("j2g: unreachable") }










func A_arbace_spec_alpha_and_spec_impl_A_New() *A_arbace_spec_alpha_and_spec_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_and_spec_impl_A{}; t.Ctor(); return t }
//line :1155:1
func (t *A_arbace_spec_alpha_and_spec_impl_A) Ctor() {}
//line :1155:1
func (t *A_arbace_spec_alpha_and_spec_impl_A) Invoke_O_O_O_O__O(self, forms__0, preds__1, gfn__2 any) any { var specs__4 any; var tmp1 any = A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_New_O_O(forms__0, preds__1); var tmp2 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_fn_class; if


	fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_fn_class = fncls__84d; tmp2 = fncls__84d } else { tmp2 = fncls__84 }; specs__4 = /*line :1155:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); var cform__5 any; var G__1740000571__5_ int32 = lang.RT_Count_O__I(preds__1); L1:




	switch { default: switch G__1740000571__5_ { case 2:
		var tmp3 any = A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_New_O(specs__4); var tmp4 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_fn_class = fncls__88d; tmp4 = fncls__88d } else { tmp4 = fncls__88 }; cform__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)
//line :1160:1
		break L1; case 3:






		var tmp5 any = A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_New_O(specs__4); var tmp6 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_fn_class = fncls__92d; tmp6 = fncls__92d } else { tmp6 = fncls__92 }; cform__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)
//line :1160:1
		break L1; default:
	}














		var tmp7 any = A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_New_O(specs__4); var tmp8 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_fn_class = fncls__94d; tmp8 = fncls__94d } else { tmp8 = fncls__94 }; cform__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)}; return /*line :1186:1*/ A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_New_IPersistentMap_O_O_O_O(nil, cform__5, gfn__2, forms__0, preds__1) }
//line :1158:1
func A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1158:1
func (t *A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A) Ctor_O_O(c__forms, c__preds any) { t.F_forms = c__forms; t.F_preds = c__preds }
//line :1158:1
func (t *A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_151.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_A_const_43.GetRawRoot__O(); var tmp3 any; var t_ any = t.F_preds; t.F_preds = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_forms; t.F_forms = nil; tmp5 = t__2; return tmp1.Invoke_O_O_O__O(tmp2, tmp4, tmp5) }


func A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_New_O(p0 any) *A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A{}; t.Ctor_O(p0); return t }
//line :1161:1
func (t *A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A) Ctor_O(c__specs any) { t.F_specs = c__specs }
//line :1161:1
func (t *A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A) Invoke_O_O__O(self, x__1 any) any { var specs__2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_9.GetRawRoot__O()).Invoke_O__O(t.F_specs); var ret__3 any; var target_86 any = lang.IFn_Cast(specs__2).Invoke_O__O(A_arbace_spec_alpha_A_const_195); var tmp1 bool; var tmp2 bool; tmp2 =

	A_arbace_spec_alpha_Spec_A_InstanceOf(target_86); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_86) }; tmp1 = tmp2; if tmp1 { ret__3 = A_arbace_spec_alpha_Spec_A_Cast(target_86).Conform_STAR__O__O(x__1) } else { ret__3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_86, x__1) }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(ret__3)) { return A_arbace_spec_alpha_A_const_42 } else {

		var target_87 any = lang.IFn_Cast(specs__2).Invoke_O__O(A_arbace_spec_alpha_A_const_260); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_87); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z(target_87) }; tmp3 = tmp4; if tmp3 { return A_arbace_spec_alpha_Spec_A_Cast(target_87).Conform_STAR__O__O(ret__3) } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_87, ret__3) } } }
func A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_New_O(p0 any) *A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A{}; t.Ctor_O(p0); return t }
//line :1167:1
func (t *A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A) Ctor_O(c__specs any) { t.F_specs = c__specs }
//line :1167:1
func (t *A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A) Invoke_O_O__O(self, x__1 any) any { var specs__2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_9.GetRawRoot__O()).Invoke_O__O(t.F_specs); var ret__3 any; var target_89 any = lang.IFn_Cast(specs__2).Invoke_O__O(A_arbace_spec_alpha_A_const_195); var tmp1 bool; var tmp2 bool; tmp2 =

	A_arbace_spec_alpha_Spec_A_InstanceOf(target_89); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_89) }; tmp1 = tmp2; if tmp1 { ret__3 = A_arbace_spec_alpha_Spec_A_Cast(target_89).Conform_STAR__O__O(x__1) } else { ret__3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_89, x__1) }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(ret__3)) { return A_arbace_spec_alpha_A_const_42 } else { var ret__4 any; var target_90 any = lang.IFn_Cast(specs__2).Invoke_O__O(A_arbace_spec_alpha_A_const_260); var tmp3 bool; var tmp4 bool

		tmp4 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_90); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z(target_90) }; tmp3 = tmp4; if tmp3 { ret__4 = A_arbace_spec_alpha_Spec_A_Cast(target_90).Conform_STAR__O__O(ret__3) } else { ret__4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_90, ret__3) }
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(ret__4)) { return A_arbace_spec_alpha_A_const_42 } else {

			var target_91 any = lang.IFn_Cast(specs__2).Invoke_O__O(A_arbace_spec_alpha_A_const_172); var tmp5 bool; var tmp6 bool; tmp6 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_91); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z(target_91) }; tmp5 = tmp6; if tmp5 { return A_arbace_spec_alpha_Spec_A_Cast(target_91).Conform_STAR__O__O(ret__4) } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_91, ret__4) } } } }
func A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_New_O(p0 any) *A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A{}; t.Ctor_O(p0); return t }
//line :1176:1
func (t *A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A) Ctor_O(c__specs any) { t.F_specs = c__specs }
//line :1176:1
func (t *A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A) Invoke_O_O__O(self, x__1 any) any { { var specs__2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_9.GetRawRoot__O()).Invoke_O__O(t.F_specs); var ret__3 any = x__1; var i__4 int64 = 0; L1: for {


	if lang.Numbers_Lt_J_J__Z(i__4, int64(lang.RT_Count_O__I(specs__2))) { var nret__5 any; var target_93 any = lang.IFn_Cast(specs__2).Invoke_O__O(jrt.Long_ValueOf_J__Long(i__4).Ref()); var tmp1 bool; var tmp2 bool
		tmp2 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_93); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_93) }; tmp1 = tmp2; if tmp1 { nret__5 = A_arbace_spec_alpha_Spec_A_Cast(target_93).Conform_STAR__O__O(ret__3) } else { nret__5 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_44.GetRawRoot__O()).Invoke_O_O__O(target_93, ret__3) }
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(nret__5)) { return A_arbace_spec_alpha_A_const_42 } else {


			ret__3, i__4 = nret__5, lang.Numbers_Inc_J__J(i__4); continue L1 } } else {
//line :1179:1
				return ret__3 } } }; /*line :1176:1*/panic("j2g: unreachable") }









func A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_New_IPersistentMap_O_O_O_O(p0 lang.IPersistentMap, p1, p2, p3, p4 any) *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A { t := &A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A{}; t.Ctor_IPersistentMap_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1186:1
func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Ctor_IPersistentMap_O_O_O_O(meta__ lang.IPersistentMap, c__cform, c__gfn, c__forms, c__preds any) { t.F___meta = meta__; t.F_cform = c__cform; t.F_gfn = c__gfn; t.F_forms = c__forms; t.F_preds = c__preds }
//line :1186:1
func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Describe_STAR___O() any { var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_69; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_130; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_131; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_305; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6.Invoke_O__O(tmp7), t.F_forms)) }
//line :1186:1
func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) With_gen_STAR__O__O(gfn__1 any) any {









	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_306; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_forms, t.F_preds, gfn__1) }
//line :1186:1
func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Gen_STAR__O_O_O__O(overrides__1, path__2, rmap__3 any) any {








	if jrt.J2g_Truth(t.F_gfn) { return lang.IFn_Cast(t.F_gfn).Invoke__O() } else { var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_108; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_53; var tmp4 any = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_preds); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_53; return tmp2.Invoke_O_O_O_O_O__O(tmp4, overrides__1, path__2, rmap__3, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(t.F_forms)) } }
//line :1186:1
func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, x__4 any) any {







	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_307; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(t.F_forms, t.F_preds, path__1, via__2, in__3, x__4) }
//line :1186:1
func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Unform_STAR__O__O(x__1 any) any {






	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_308; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_New(); var tmp4 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_11, false); A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_fn_class = fncls__95d; tmp4 = fncls__95d } else { tmp4 = fncls__95 }; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_309; return tmp2.Invoke_O_O_O__O(tmp5, x__1, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(t.F_preds)) }
//line :1186:1
func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Conform_STAR__O__O(x__1 any) any {





	return lang.IFn_Cast(t.F_cform).Invoke_O__O(x__1) }
//line :1186:1
func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Specize_STAR__O__O(___1 any) any { return t }
//line :1186:1
func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Specize_STAR___O() any { return t }
//line :1186:1
func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :1186:1
func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_New_IPersistentMap_O_O_O_O(m, t.F_cform, t.F_gfn, t.F_forms, t.F_preds) }






func A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_New() *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A{}; t.Ctor(); return t }
//line :1193:1
func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A) Ctor() {}
//line :1193:1
func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A) Invoke_O_O_O__O(self, p1__1740000568_SHARP___1, p2__1740000567_SHARP___2 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_284.GetRawRoot__O()).Invoke_O_O__O(p2__1740000567_SHARP___2, p1__1740000568_SHARP___1) }





func A_arbace_spec_alpha_merge_spec_impl_A_New() *A_arbace_spec_alpha_merge_spec_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_merge_spec_impl_A{}; t.Ctor(); return t }
//line :1199:1
func (t *A_arbace_spec_alpha_merge_spec_impl_A) Ctor() {}
//line :1199:1
func (t *A_arbace_spec_alpha_merge_spec_impl_A) Invoke_O_O_O_O__O(self, forms__0, preds__1, gfn__2 any) any {


	return A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_New_IPersistentMap_O_O_O(nil, gfn__2, forms__0, preds__1) }
//line :1202:1
func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_New_IPersistentMap_O_O_O(p0 lang.IPersistentMap, p1, p2, p3 any) *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A { t := &A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A{}; t.Ctor_IPersistentMap_O_O_O(p0, p1, p2, p3); return t }
//line :1202:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Ctor_IPersistentMap_O_O_O(meta__ lang.IPersistentMap, c__gfn, c__forms, c__preds any) { t.F___meta = meta__; t.F_gfn = c__gfn; t.F_forms = c__forms; t.F_preds = c__preds }
//line :1202:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Describe_STAR___O() any { var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_69; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_130; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_131; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_310; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6.Invoke_O__O(tmp7), t.F_forms)) }
//line :1202:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) With_gen_STAR__O__O(gfn__1 any) any {





















	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_311; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_forms, t.F_preds, gfn__1) }
//line :1202:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Gen_STAR__O_O_O__O(overrides__1, path__2, rmap__3 any) any {















	if jrt.J2g_Truth(t.F_gfn) {
		return lang.IFn_Cast(t.F_gfn).Invoke__O() } else {
			var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_289; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_New(); var tmp4 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_94, false); A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_fn_class = fncls__96d; tmp4 = fncls__96d } else { tmp4 = fncls__96 }; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_158; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_262; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp10 = A_arbace_spec_alpha_A_const_148; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_New_O_O_O(path__2, overrides__1, rmap__3); var tmp13 *jrt.Class
			var fncls__97 /*line :1220:1*/*jrt.Class = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_fn_class

			if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_95, false); A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_fn_class = fncls__97d; tmp13 = fncls__97d } else { tmp13 = fncls__97 }
//line :1220:1
			return tmp2.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(tmp9, tmp11.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), t.F_preds, t.F_forms))) } }
//line :1202:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, x__4 any) any {











	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_158; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_130; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_148; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_New_O_O_O_O(in__3, path__1, via__2, x__4); var tmp8 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_fn_class
	if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, false); A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_fn_class = fncls__98d; tmp8 = fncls__98d } else { tmp8 = fncls__98 }
//line :1214:1
	return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), t.F_forms, t.F_preds)) }
//line :1202:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Unform_STAR__O__O(x__1 any) any {









	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_158; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_312; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_148; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_New_O(x__1); var tmp8 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_97, false); A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_fn_class = fncls__99d; tmp8 = fncls__99d } else { tmp8 = fncls__99 }; var tmp9 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp10 = A_arbace_spec_alpha_A_const_309; return tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O_O__O(tmp9, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(t.F_preds))) }
//line :1202:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Conform_STAR__O__O(x__1 any) any { var ms__2 any; var tmp1 *lang.Var;





	A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_148; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_New_O(x__1); var tmp4 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_98, false); A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_fn_class = fncls__100d; tmp4 = fncls__100d } else { tmp4 = fncls__100 }; ms__2 = tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), t.F_preds, t.F_forms); var tmp5 /*line :1209:1*/*lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_313; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_246; if jrt.J2g_Truth(tmp6.Invoke_O_O__O(jrt.NN(tmp7).GetRawRoot__O(), ms__2)) { A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } else {

		var tmp8 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_158; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp10 = A_arbace_spec_alpha_A_const_312; return tmp9.Invoke_O_O__O(jrt.NN(tmp10).GetRawRoot__O(), ms__2) } }
//line :1202:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Specize_STAR__O__O(___1 any) any { return t }
//line :1202:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Specize_STAR___O() any { return t }
//line :1202:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :1202:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_New_IPersistentMap_O_O_O(m, t.F_gfn, t.F_forms, t.F_preds) }





func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_New_O(p0 any) *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A{}; t.Ctor_O(p0); return t }
//line :1208:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :1208:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A) Invoke_O_O_O__O(self, p1__1740000583_SHARP___1, p2__1740000584_SHARP___2 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_254.GetRawRoot__O()).Invoke_O_O_O__O(p1__1740000583_SHARP___1, t.F_x, p2__1740000584_SHARP___2) }



func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_New_O(p0 any) *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A{}; t.Ctor_O(p0); return t }
//line :1212:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :1212:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A) Invoke_O_O__O(self, p1__1740000585_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_284.GetRawRoot__O()).Invoke_O_O__O(p1__1740000585_SHARP___1, t.F_x) }


func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1215:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A) Ctor_O_O_O_O(c__in, c__path, c__via, c__x any) { t.F_in = c__in; t.F_path = c__path; t.F_via = c__via; t.F_x = c__x }
//line :1215:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A) Invoke_O_O_O__O(self, p1__1740000586_SHARP___1, p2__1740000587_SHARP___2 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_282.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(p1__1740000586_SHARP___1, p2__1740000587_SHARP___2, t.F_path, t.F_via, t.F_in, t.F_x) }




func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_New() *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A{}; t.Ctor(); return t }
//line :1220:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A) Ctor() {}
//line :1220:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A) Invoke_O_O__O(self, p1__1740000588_SHARP___1 any) any {
	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_312.GetRawRoot__O(), p1__1740000588_SHARP___1) }
func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_New_O_O_O(p0, p1, p2 any) *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1222:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A) Ctor_O_O_O(c__path, c__overrides, c__rmap any) { t.F_path = c__path; t.F_overrides = c__overrides; t.F_rmap = c__rmap }
//line :1222:1
func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A) Invoke_O_O_O__O(self, p1__1740000589_SHARP___1, p2__1740000590_SHARP___2 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_108.GetRawRoot__O()).Invoke_O_O_O_O_O__O(p1__1740000589_SHARP___1, t.F_overrides, t.F_path, t.F_rmap, p2__1740000590_SHARP___2) }




func A_arbace_spec_alpha_coll_prob_A_New() *A_arbace_spec_alpha_coll_prob_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_coll_prob_A{}; t.Ctor(); return t }
//line :1227:1
func (t *A_arbace_spec_alpha_coll_prob_A) Ctor() {}
//line :1227:1
func (t *A_arbace_spec_alpha_coll_prob_A) Invoke_O_O_O_O_O_O_O_O_O_O_O__O(self, x__0, kfn__1, kform__2, distinct__3, count__4, min_count__5, max_count__6, path__7, via__8, in__9 any) any { var pred__11 any; var or__1927000174__auto____11 any = kfn__1; if

	jrt.J2g_Truth(or__1927000174__auto____11) { pred__11 = or__1927000174__auto____11 } else { pred__11 = A_arbace_spec_alpha_A_const_314.GetRawRoot__O() }; var kform__12 any; var or__1927000174__auto____12 any = kform__2; if
	jrt.J2g_Truth(or__1927000174__auto____12) { kform__12 = or__1927000174__auto____12 } else { kform__12 = A_arbace_spec_alpha_A_const_315 }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_281.GetRawRoot__O()).Invoke_O_O__O(pred__11, x__0))) {

		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_282.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(kform__12, pred__11, path__7, via__8, in__9, x__0) } else {
//line :1231:1
			var tmp1 any
			var and__1927000168__auto____13 any = count__4


			if jrt.J2g_Truth(and__1927000168__auto____13) { tmp1 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_32.GetRawRoot__O()).Invoke_O_O__O(count__4, lang.IFn_Cast(A_arbace_spec_alpha_A_const_316.GetRawRoot__O()).Invoke_O_O__O(count__4, x__0)) } else { tmp1 = and__1927000168__auto____13 }
//line :1231:1
			if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_spec_alpha_A_const_72; var tmp3 any = A_arbace_spec_alpha_A_const_73; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, path__7, tmp3, lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_317), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(count__4), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_318), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_319)))))), A_arbace_spec_alpha_A_const_74, x__0, A_arbace_spec_alpha_A_const_76, via__8, A_arbace_spec_alpha_A_const_77, in__9))) } else { var tmp4 any; var and__1927000168__auto____13_2 any
				var or__1927000174__auto____13 any = min_count__5





				if jrt.J2g_Truth(or__1927000174__auto____13) { and__1927000168__auto____13_2 = or__1927000174__auto____13 } else { and__1927000168__auto____13_2 = max_count__6 }; if jrt.J2g_Truth(and__1927000168__auto____13_2) {
					var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_320.GetRawRoot__O()); var tmp7 any; var or__1927000174__auto____14 any = min_count__5; if jrt.J2g_Truth(or__1927000174__auto____14) { tmp7 = or__1927000174__auto____14 } else { tmp7 = A_arbace_spec_alpha_A_const_195 }; var tmp8 any = tmp7; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_316.GetRawRoot__O()); var tmp10 any
					if jrt.J2g_Truth(max_count__6) { tmp10 = lang.Numbers_Inc_O__Number(max_count__6) } else { tmp10 = min_count__5 }
//line :1239:1
					var tmp11 any = tmp9.Invoke_O_O__O(tmp10, x__0); var tmp12 any
					var or__1927000174__auto____14_2 any = max_count__6
					if jrt.J2g_Truth(or__1927000174__auto____14_2) { tmp12 = or__1927000174__auto____14_2 } else { tmp12 = jrt.Integer_ValueOf_I__Integer(2147483647).Ref() }
//line :1239:1
					tmp4 = tmp5.Invoke_O__O(tmp6.Invoke_O_O_O__O(tmp8, tmp11, tmp12)) } else {
//line :1238:1
						tmp4 = and__1927000168__auto____13_2 }
//line :1231:1
				if jrt.J2g_Truth(tmp4) { var tmp13 any = A_arbace_spec_alpha_A_const_72; var tmp14 any = A_arbace_spec_alpha_A_const_73; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()); var tmp17 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_321); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()); var tmp19 any
					var or__1927000174__auto____13_2 any = min_count__5









					if jrt.J2g_Truth(or__1927000174__auto____13_2) { tmp19 = or__1927000174__auto____13_2 } else { tmp19 = A_arbace_spec_alpha_A_const_195 }
//line :1231:1
					var tmp20 any = tmp18.Invoke_O__O(tmp19); var tmp21 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_322), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_323)))); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()); var tmp23 any
					var or__1927000174__auto____13_3 any = max_count__6









					if jrt.J2g_Truth(or__1927000174__auto____13_3) { tmp23 = or__1927000174__auto____13_3 } else { tmp23 = A_arbace_spec_alpha_A_const_324 }
//line :1231:1
					return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, path__7, tmp14, tmp15.Invoke_O__O(tmp16.Invoke_O_O_O_O__O(tmp17, tmp20, tmp21, tmp22.Invoke_O__O(tmp23))), A_arbace_spec_alpha_A_const_74, x__0, A_arbace_spec_alpha_A_const_76, via__8, A_arbace_spec_alpha_A_const_77, in__9))) } else { var tmp24 any
						var and__1927000168__auto____13_3 any = distinct__3











						if jrt.J2g_Truth(and__1927000168__auto____13_3) { var and__1927000168__auto____14 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(x__0)); if jrt.J2g_Truth(and__1927000168__auto____14) { tmp24 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_325.GetRawRoot__O(), x__0)) } else { tmp24 = and__1927000168__auto____14 } } else { tmp24 = and__1927000168__auto____13_3 }
//line :1231:1
						if jrt.J2g_Truth(tmp24) { return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_72, path__7, A_arbace_spec_alpha_A_const_73, A_arbace_spec_alpha_A_const_326, A_arbace_spec_alpha_A_const_74, x__0, A_arbace_spec_alpha_A_const_76, via__8, A_arbace_spec_alpha_A_const_77, in__9))) } else { return nil } } } } }

















func A_arbace_spec_alpha_every_impl_A_New() *A_arbace_spec_alpha_every_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_impl_A{}; t.Ctor(); return t }
//line :1249:1
func (t *A_arbace_spec_alpha_every_impl_A) Ctor() {}
//line :1249:1
func (t *A_arbace_spec_alpha_every_impl_A) Invoke_O_O_O_O_O__O(self, form__0, pred__1, p__1740000609__2, gfn__3 any) any { var default__1740000612__5 int64 = 20; var map__1740000610__6 any = p__1740000609__2; var map__1740000610__7 any; if lang.ISeq_InstanceOf(map__1740000610__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000610__6)) { map__1740000610__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000610__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000610__6)) { map__1740000610__7 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000610__6) } else { lang.PersistentArrayMap_Init(); map__1740000610__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000610__7 = map__1740000610__6 }; var opts__8 any = map__1740000610__7; var conform_into__9 any = lang.RT_Get_O_O__O(map__1740000610__7, A_arbace_spec_alpha_A_const_180); var describe_form__10 any = lang.RT_Get_O_O__O(map__1740000610__7, A_arbace_spec_alpha_A_const_186); var kind__11 any = lang.RT_Get_O_O__O(map__1740000610__7, A_arbace_spec_alpha_A_const_178); var kind_form__12 any = lang.RT_Get_O_O__O(map__1740000610__7, A_arbace_spec_alpha_A_const_187); var count__13 any = lang.RT_Get_O_O__O(map__1740000610__7, A_arbace_spec_alpha_A_const_181); var max_count__14 any = lang.RT_Get_O_O__O(map__1740000610__7, A_arbace_spec_alpha_A_const_182); var min_count__15 any = lang.RT_Get_O_O__O(map__1740000610__7, A_arbace_spec_alpha_A_const_183); var distinct__16 any = lang.RT_Get_O_O__O(map__1740000610__7, A_arbace_spec_alpha_A_const_184); var tmp1 any = A_arbace_spec_alpha_A_const_185; var gen_max__17 any = lang.RT_Get_O_O_O__O(map__1740000610__7, tmp1, jrt.Long_ValueOf_J__Long(default__1740000612__5).Ref()); var kfn__18 any = lang.RT_Get_O_O__O(map__1740000610__7, A_arbace_spec_alpha_A_const_212); var cpred__19 any = lang.RT_Get_O_O__O(map__1740000610__7, A_arbace_spec_alpha_A_const_206); var conform_keys__20 any = lang.RT_Get_O_O__O(map__1740000610__7, A_arbace_spec_alpha_A_const_327); var conform_all__21 any = lang.RT_Get_O_O__O(map__1740000610__7, A_arbace_spec_alpha_A_const_219); var gen_into__22 any; if









	jrt.J2g_Truth(conform_into__9) { gen_into__22 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_328.GetRawRoot__O()).Invoke_O__O(conform_into__9) } else { gen_into__22 = lang.RT_Get_O_O__O(A_arbace_spec_alpha_A_const_329.GetRawRoot__O(), kind_form__12) }; var spec__23 any; var tmp2 any = /*line :1249:1*/A_arbace_spec_alpha_every_impl_fn__1740000614_A_New_O(pred__1); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_spec_alpha_every_impl_fn__1740000614_A_fn_class; if










	fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_spec_alpha_every_impl_fn__1740000614_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; spec__23 = /*line :1249:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var check_QMARK___24 any; var tmp4 any = A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_New_O(spec__23); var tmp5 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_fn_class; if









	fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_fn_class = fncls__102d; tmp5 = fncls__102d } else { tmp5 = fncls__102 }; check_QMARK___24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var kfn__25 any; var or__1927000174__auto____25 any = kfn__18; if


	jrt.J2g_Truth(or__1927000174__auto____25) { kfn__25 = or__1927000174__auto____25 } else { var tmp6 any = A_arbace_spec_alpha_every_impl_fn__1740000618_A_New(); var tmp7 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_spec_alpha_every_impl_fn__1740000618_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_spec_alpha_every_impl_fn__1740000618_A_fn_class = fncls__103d; tmp7 = fncls__103d } else { tmp7 = fncls__103 }; kfn__25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil) }; var addcv__26 any; var tmp8 any = /*line :1249:1*/A_arbace_spec_alpha_every_impl_addcv__1740000620_A_New(); var tmp9 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_spec_alpha_every_impl_addcv__1740000620_A_fn_class; if













	fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_spec_alpha_every_impl_addcv__1740000620_A_fn_class = fncls__104d; tmp9 = fncls__104d } else { tmp9 = fncls__104 }; addcv__26 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var cfns__27 any; var tmp10 any = /*line :1249:1*/A_arbace_spec_alpha_every_impl_cfns__1740000622_A_New_O_O_O_O(kind__11, conform_into__9, conform_keys__20, addcv__26); var tmp11 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_spec_alpha_every_impl_cfns__1740000622_A_fn_class; if














	fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_spec_alpha_every_impl_cfns__1740000622_A_fn_class = fncls__108d; tmp11 = fncls__108d } else { tmp11 = fncls__108 }; cfns__27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); return /*line :1287:1*/ A_arbace_spec_alpha_every_impl_reify__1740000630_A_New_IPersistentMap_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(nil, check_QMARK___24, count__13, kind_form__12, form__0, gen_max__17, spec__23, max_count__14, kind__11, gfn__3, distinct__16, cfns__27, describe_form__10, cpred__19, conform_all__21, min_count__15, opts__8, gen_into__22, kfn__25, pred__1) }
//line :1249:1
func (t *A_arbace_spec_alpha_every_impl_A) Invoke_O_O_O_O__O(self, form__0, pred__1, opts__2 any) any {

	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_333.GetRawRoot__O()).Invoke_O_O_O_O__O(form__0, pred__1, opts__2, nil)
}






func A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_New_O(p0 any) *A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A{}; t.Ctor_O(p0); return t }
//line :1259:1
func (t *A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A) Ctor_O(c__spec any) { t.F_spec = c__spec }
//line :1259:1
func (t *A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A) Invoke_O_O__O(self, p1__1740000605_SHARP___1 any) any {

	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_102.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_9.GetRawRoot__O()).Invoke_O__O(t.F_spec), p1__1740000605_SHARP___1) }
//line :1260:1
func A_arbace_spec_alpha_every_impl_fn__1740000614_A_New_O(p0 any) *A_arbace_spec_alpha_every_impl_fn__1740000614_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_impl_fn__1740000614_A{}; t.Ctor_O(p0); return t }
//line :1260:1
func (t *A_arbace_spec_alpha_every_impl_fn__1740000614_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :1260:1
func (t *A_arbace_spec_alpha_every_impl_fn__1740000614_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_43.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_pred; t.F_pred = nil; tmp2 = t_; return tmp1.Invoke_O__O(tmp2) }

func A_arbace_spec_alpha_every_impl_fn__1740000618_A_New() *A_arbace_spec_alpha_every_impl_fn__1740000618_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_impl_fn__1740000618_A{}; t.Ctor(); return t }
//line :1262:1
func (t *A_arbace_spec_alpha_every_impl_fn__1740000618_A) Ctor() {}
//line :1262:1
func (t *A_arbace_spec_alpha_every_impl_fn__1740000618_A) Invoke_O_O_O__O(self, i__1, v__2 any) any { return i__1 }
func A_arbace_spec_alpha_every_impl_addcv__1740000620_A_New() *A_arbace_spec_alpha_every_impl_addcv__1740000620_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_impl_addcv__1740000620_A{}; t.Ctor(); return t }
//line :1263:1
func (t *A_arbace_spec_alpha_every_impl_addcv__1740000620_A) Ctor() {}
//line :1263:1
func (t *A_arbace_spec_alpha_every_impl_addcv__1740000620_A) Invoke_O_O_O_O_O__O(self, ret__1, i__2, v__3, cv__4 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(ret__1, cv__4) }
func A_arbace_spec_alpha_every_impl_cfns__1740000622_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_alpha_every_impl_cfns__1740000622_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_impl_cfns__1740000622_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1264:1
func (t *A_arbace_spec_alpha_every_impl_cfns__1740000622_A) Ctor_O_O_O_O(c__kind, c__conform_into, c__conform_keys, c__addcv any) { t.F_kind = c__kind; t.F_conform_into = c__conform_into; t.F_conform_keys = c__conform_keys; t.F_addcv = c__addcv }
//line :1264:1
func (t *A_arbace_spec_alpha_every_impl_cfns__1740000622_A) Invoke_O_O__O(self, x__1 any) any {

	var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_296.GetRawRoot__O()).Invoke_O__O(x__1)
	if jrt.J2g_Truth(and__1927000168__auto____2) { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(t.F_conform_into); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_296.GetRawRoot__O()).Invoke_O__O(t.F_conform_into) } } else { tmp1 = and__1927000168__auto____2 }
//line :1266:1
	if jrt.J2g_Truth(tmp1) { var tmp2 any = A_arbace_spec_alpha_A_const_156.GetRawRoot__O(); var tmp3 any = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_New(); var tmp4 *jrt.Class
		var fncls__105 /*line :1266:1*/*jrt.Class = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_fn_class


		if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_fn_class = fncls__105d; tmp4 = fncls__105d } else { tmp4 = fncls__105 }
//line :1266:1
		return lang.Tuple_Create_O_O_O__IPersistentVector(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), A_arbace_spec_alpha_A_const_156.GetRawRoot__O()) } else { var tmp5 any; var and__1927000168__auto____2_2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_40.GetRawRoot__O()).Invoke_O__O(x__1)








			if jrt.J2g_Truth(and__1927000168__auto____2_2) { var or__1927000174__auto____3_2 any; var and__1927000168__auto____3 any = t.F_kind; if jrt.J2g_Truth(and__1927000168__auto____3) { or__1927000174__auto____3_2 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(t.F_conform_into) } else { or__1927000174__auto____3_2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp5 = or__1927000174__auto____3_2 } else { tmp5 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_40.GetRawRoot__O()).Invoke_O__O(t.F_conform_into) } } else { tmp5 = and__1927000168__auto____2_2 }
//line :1266:1
			if jrt.J2g_Truth(tmp5) { var tmp6 any









				if jrt.J2g_Truth(t.F_conform_keys) { tmp6 = A_arbace_spec_alpha_A_const_328.GetRawRoot__O() } else { tmp6 = A_arbace_spec_alpha_A_const_156.GetRawRoot__O() }
//line :1266:1
				var tmp7 any = tmp6; var tmp8 any = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_New_O(t.F_conform_keys); var tmp9 *jrt.Class
				var fncls__106 /*line :1266:1*/*jrt.Class = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_fn_class










				if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_fn_class = fncls__106d; tmp9 = fncls__106d } else { tmp9 = fncls__106 }
//line :1266:1
				return lang.Tuple_Create_O_O_O__IPersistentVector(tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), A_arbace_spec_alpha_A_const_156.GetRawRoot__O()) } else { var tmp10 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_330.GetRawRoot__O()).Invoke_O__O(t.F_conform_into)
















					if jrt.J2g_Truth(or__1927000174__auto____2) { tmp10 = or__1927000174__auto____2 } else { var or__1927000174__auto____3_3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_47.GetRawRoot__O()).Invoke_O__O(t.F_conform_into); if jrt.J2g_Truth(or__1927000174__auto____3_3) { tmp10 = or__1927000174__auto____3_3 } else { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(t.F_conform_into); if jrt.J2g_Truth(and__1927000168__auto____4) { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_330.GetRawRoot__O()).Invoke_O__O(x__1); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp10 = or__1927000174__auto____5 } else { tmp10 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_47.GetRawRoot__O()).Invoke_O__O(x__1) } } else { tmp10 = and__1927000168__auto____4 } } }
//line :1266:1
					if jrt.J2g_Truth(tmp10) { var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_331.GetRawRoot__O()); var tmp12 *lang.PersistentList_EmptyList; lang.PersistentList_Init(); tmp12 = lang.PersistentList_EMPTY; var tmp13 any = tmp11.Invoke_O__O(tmp12.Ref()); var tmp14 any = t.F_addcv; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp13, tmp14, A_arbace_spec_alpha_A_const_309.GetRawRoot__O()) } else { if A_arbace_spec_alpha_A_const_51 != nil { var tmp15 any = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_New_O(t.F_conform_into); var tmp16 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_fn_class = fncls__107d; tmp16 = fncls__107d } else { tmp16 = fncls__107 }; var tmp17 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var tmp18 any = t.F_addcv; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp17, tmp18, A_arbace_spec_alpha_A_const_156.GetRawRoot__O()) } else { return nil } } } } }
//line :1266:1
func A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_New_O(p0 any) *A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A{}; t.Ctor_O(p0); return t }
//line :1266:1
func (t *A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A) Ctor_O(c__conform_into any) { t.F_conform_into = c__conform_into }
//line :1266:1
func (t *A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A) Invoke_O_O__O(self, p1__1740000606_SHARP___1 any) any {



















	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_328.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____2 any = t.F_conform_into; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp2 = or__1927000174__auto____2 } else { tmp2 = p1__1740000606_SHARP___1 }; return tmp1.Invoke_O__O(tmp2) }
//line :1269:1
func A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_New() *A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A{}; t.Ctor(); return t }
//line :1269:1
func (t *A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A) Ctor() {}
//line :1269:1
func (t *A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A) Invoke_O_O_O_O_O__O(self, ret__1, i__2, v__3, cv__4 any) any {
	if lang.Util_Identical_O_O__Z(v__3, cv__4) { return ret__1 } else {

		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(ret__1, i__2, cv__4)
	}
}


func A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_New_O(p0 any) *A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A{}; t.Ctor_O(p0); return t }
//line :1277:1
func (t *A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A) Ctor_O(c__conform_keys any) { t.F_conform_keys = c__conform_keys }
//line :1277:1
func (t *A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A) Invoke_O_O_O_O_O__O(self, ret__1, i__2, v__3, cv__4 any) any {
	var tmp1 any; var and__1927000168__auto____5 bool = lang.Util_Identical_O_O__Z(v__3, cv__4); if and__1927000168__auto____5 { tmp1 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(t.F_conform_keys) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp1) { return ret__1 } else {

		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()); var tmp3 any; if jrt.J2g_Truth(t.F_conform_keys) { tmp3 = cv__4 } else { tmp3 = v__3 }; return tmp2.Invoke_O_O_O__O(ret__1, lang.RT_Nth_O_I__O(tmp3, lang.RT_IntCast_J__I(0)), lang.RT_Nth_O_I__O(cv__4, lang.RT_IntCast_J__I(1)))
	}
}




func A_arbace_spec_alpha_every_impl_reify__1740000630_A_New_IPersistentMap_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(p0 lang.IPersistentMap, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19 any) *A_arbace_spec_alpha_every_impl_reify__1740000630_A { t := &A_arbace_spec_alpha_every_impl_reify__1740000630_A{}; t.Ctor_IPersistentMap_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19); return t }
//line :1287:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Ctor_IPersistentMap_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(meta__ lang.IPersistentMap, c__check_QMARK_, c__count, c__kind_form, c__form, c__gen_max, c__spec, c__max_count, c__kind, c__gfn, c__distinct, c__cfns, c__describe_form, c__cpred, c__conform_all, c__min_count, c__opts, c__gen_into, c__kfn, c__pred any) { t.F___meta = meta__; t.F_check_QMARK_ = c__check_QMARK_; t.F_count = c__count; t.F_kind_form = c__kind_form; t.F_form = c__form; t.F_gen_max = c__gen_max; t.F_spec = c__spec; t.F_max_count = c__max_count; t.F_kind = c__kind; t.F_gfn = c__gfn; t.F_distinct = c__distinct; t.F_cfns = c__cfns; t.F_describe_form = c__describe_form; t.F_cpred = c__cpred; t.F_conform_all = c__conform_all; t.F_min_count = c__min_count; t.F_opts = c__opts; t.F_gen_into = c__gen_into; t.F_kfn = c__kfn; t.F_pred = c__pred }
//line :1287:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Describe_STAR___O() any { var or__1927000174__auto____1 any = t.F_describe_form; if
























































































	jrt.J2g_Truth(or__1927000174__auto____1) { return or__1927000174__auto____1 } else { var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_69; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_130; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_131; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_332; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_131; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_122; var tmp12 any = tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(t.F_form)); var tmp13 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp13 = A_arbace_spec_alpha_A_const_179; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp15 = A_arbace_spec_alpha_A_const_156; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp12, tmp14.Invoke_O_O__O(jrt.NN(tmp15).GetRawRoot__O(), t.F_opts))) } }
//line :1287:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) With_gen_STAR__O__O(gfn__1 any) any {























































































	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_333; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_form, t.F_pred, t.F_opts, gfn__1) }
//line :1287:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Gen_STAR__O_O_O__O(overrides__1, path__2, rmap__3 any) any {


























































	if jrt.J2g_Truth(t.F_gfn) {
		return lang.IFn_Cast(t.F_gfn).Invoke__O() } else {
//line :1346:1
			var pgen__4 any; var tmp1 *lang.Var

			A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_108; pgen__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O_O_O__O(t.F_pred, overrides__1, path__2, rmap__3, t.F_form)
			var tmp2 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_261; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any
			if jrt.J2g_Truth(t.F_gen_into) {
				var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_255; tmp4 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(t.F_gen_into) } else {
//line :1350:1
					if jrt.J2g_Truth(t.F_kind) {

						var tmp6 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_289; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_New(); var tmp9 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_fn_class = fncls__111d; tmp9 = fncls__111d } else { tmp9 = fncls__111 }; var tmp10 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp11 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_108; tmp4 = tmp7.Invoke_O_O__O(tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O_O_O_O__O(t.F_kind, overrides__1, path__2, rmap__3, t.F_form)) } else {
//line :1350:1
							var tmp12 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp12 = A_arbace_spec_alpha_A_const_51; if tmp12 != nil {



								var tmp13 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp13 = A_arbace_spec_alpha_A_const_255; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.PersistentVector; lang.PersistentVector_Init(); tmp15 = lang.PersistentVector_EMPTY; tmp4 = tmp14.Invoke_O__O(tmp15.Ref()) } else {
//line :1350:1
									tmp4 = nil } } }
//line :1349:1
			var tmp16 any = tmp4; var tmp17 any = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_New_O_O_O_O_O_O(t.F_count, t.F_gen_max, t.F_max_count, t.F_distinct, t.F_min_count, pgen__4); var tmp18 *jrt.Class
			var fncls__110 /*line :1349:1*/*jrt.Class = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_fn_class





			if fncls__110 == nil { var fncls__110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_fn_class = fncls__110d; tmp18 = fncls__110d } else { tmp18 = fncls__110 }
//line :1349:1
			return tmp3.Invoke_O_O__O(tmp16, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil)) } }
//line :1287:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, x__4 any) any { var or__1927000174__auto____5 any; var tmp1 *lang.Var;














































	A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_340; or__1927000174__auto____5 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(x__4, t.F_kind, t.F_kind_form, t.F_distinct, t.F_count, t.F_min_count, t.F_max_count, path__1, via__2, in__3); if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else {

		var tmp2 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_158; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_130; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 any
		if jrt.J2g_Truth(t.F_conform_all) { var tmp7 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_156; tmp6 = jrt.NN(tmp7).GetRawRoot__O() } else { var tmp8 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_341; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp10 = A_arbace_spec_alpha_A_const_263; var tmp11 any = jrt.NN(tmp10).GetRawRoot__O(); var tmp12 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp12 = A_arbace_spec_alpha_A_const_342; tmp6 = tmp9.Invoke_O_O__O(tmp11, jrt.NN(tmp12).Get__O()) }
//line :1336:1
		var tmp13 lang.IFn = lang.IFn_Cast(tmp6); var tmp14 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp14 = A_arbace_spec_alpha_A_const_280; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp16 = A_arbace_spec_alpha_A_const_156; var tmp17 any = jrt.NN(tmp16).GetRawRoot__O(); var tmp18 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp18 = A_arbace_spec_alpha_A_const_148; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_New_O_O_O_O_O_O_O(t.F_check_QMARK_, in__3, t.F_form, path__1, via__2, t.F_kfn, t.F_pred); var tmp21 *jrt.Class
		var fncls__112 /*line :1336:1*/*jrt.Class = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_fn_class


		if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_fn_class = fncls__112d; tmp21 = fncls__112d } else { tmp21 = fncls__112 }
//line :1336:1
		var tmp22 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var tmp23 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp23 = A_arbace_spec_alpha_A_const_295; return tmp3.Invoke_O_O__O(tmp5, tmp13.Invoke_O__O(tmp15.Invoke_O_O__O(tmp17, tmp19.Invoke_O_O_O__O(tmp22, lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke__O(), x__4)))) } }
//line :1287:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Unform_STAR__O__O(x__1 any) any {





































	if jrt.J2g_Truth(t.F_conform_all) { var spec__2 any; var tmp1 *lang.Var
		A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_9; spec__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_spec)
//line :1325:1
		var vec__1740000654__3 any = lang.IFn_Cast(t.F_cfns).Invoke_O__O(x__1); var init__4 any = lang.RT_Nth_O_I_O__O(vec__1740000654__3, lang.RT_IntCast_J__I(0), nil); var add__5 any = lang.RT_Nth_O_I_O__O(vec__1740000654__3, lang.RT_IntCast_J__I(1), nil); var complete__6 any = lang.RT_Nth_O_I_O__O(vec__1740000654__3, lang.RT_IntCast_J__I(2), nil); var ret__7 any = lang.IFn_Cast(init__4).Invoke_O__O(x__1); var i__8 int64 = 0; var G__1740000660__9_ any; var tmp2 *lang.Var


		A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_69; G__1740000660__9_ = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__1)
//line :1325:1
		var vec__1740000661__10 any = G__1740000660__9_; var seq__1740000662__11 any; var tmp3 *lang.Var


		A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_69; seq__1740000662__11 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(vec__1740000661__10)
//line :1325:1
		var first__1740000663__12 any; var tmp4 *lang.Var


		A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_53; first__1740000663__12 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__1740000662__11)
//line :1325:1
		var seq__1740000662__13 any; var tmp5 *lang.Var


		A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_70; seq__1740000662__13 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1740000662__11)
//line :1325:1
		var v__14 any = first__1740000663__12; var vs__15 any = seq__1740000662__13; var vseq__16 any = vec__1740000661__10; var ret__17 any = ret__7; var i__18 int64 = i__8; var G__1740000660__19_ any = G__1740000660__9_; _ = v__14; _ = vs__15; _ = vseq__16; L1: for { var ret__20 any = ret__17; var i__21 int64 = i__18; var vec__1740000664__22 any = G__1740000660__19_; var seq__1740000665__23 any; var tmp6 *lang.Var


			A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_69; seq__1740000665__23 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(vec__1740000664__22)
//line :1325:1
			var first__1740000666__24 any; var tmp7 *lang.Var


			A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_53; first__1740000666__24 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq__1740000665__23)
//line :1325:1
			var seq__1740000665__25 any; var tmp8 *lang.Var


			A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_70; seq__1740000665__25 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq__1740000665__23)
//line :1325:1
			var v__26 any = first__1740000666__24; var vs__27 any = seq__1740000665__25; var vseq__28 any = vec__1740000664__22; _ = vseq__28



			if lang.Numbers_Gte_J_J__Z(i__21, int64(lang.RT_Count_O__I(x__1))) {
				return lang.IFn_Cast(complete__6).Invoke_O__O(ret__20) } else {
					var tmp9 lang.IFn = lang.IFn_Cast(add__5); var tmp10 any = jrt.Long_ValueOf_J__Long(i__21).Ref(); var tmp11 any; var target_113 any = spec__2; var tmp12 bool; var tmp13 bool; tmp13 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_113); if tmp13 { tmp13 = !lang.Compiler_AOT_IsDyn_O__Z(target_113) }; tmp12 = tmp13; if tmp12 { tmp11 = A_arbace_spec_alpha_Spec_A_Cast(target_113).Unform_STAR__O__O(v__26) } else { var tmp14 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp14 = A_arbace_spec_alpha_A_const_45; tmp11 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O_O__O(target_113, v__26) }; ret__17, i__18, G__1740000660__19_ = tmp9.Invoke_O_O_O_O__O(ret__20, tmp10, v__26, tmp11), lang.Numbers_Inc_J__J(i__21), vs__27; continue L1 } } } else {
//line :1325:1
						return x__1 }
//line :1287:1
	panic("j2g: unreachable") }
//line :1287:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Conform_STAR__O__O(x__1 any) any { { var spec__2 any; var tmp1 *lang.Var






	A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_9; spec__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_spec)
	var tmp2 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_16; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_cpred).Invoke_O__O(x__1))) { A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } else { if jrt.J2g_Truth(t.F_conform_all) { var vec__1740000631__3 any = lang.IFn_Cast(t.F_cfns).Invoke_O__O(x__1); var init__4 any = lang.RT_Nth_O_I_O__O(vec__1740000631__3, lang.RT_IntCast_J__I(0), nil); var add__5 any = lang.RT_Nth_O_I_O__O(vec__1740000631__3, lang.RT_IntCast_J__I(1), nil); var complete__6 any = lang.RT_Nth_O_I_O__O(vec__1740000631__3, lang.RT_IntCast_J__I(2), nil); var ret__7 any = lang.IFn_Cast(init__4).Invoke_O__O(x__1); var i__8 int64 = 0; var G__1740000637__9_ any; var tmp3 *lang.Var




		A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_69; G__1740000637__9_ = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__1)
//line :1295:1
		var vec__1740000638__10 any = G__1740000637__9_; var seq__1740000639__11 any; var tmp4 *lang.Var




		A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_69; seq__1740000639__11 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(vec__1740000638__10)
//line :1295:1
		var first__1740000640__12 any; var tmp5 *lang.Var




		A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_53; first__1740000640__12 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__1740000639__11)
//line :1295:1
		var seq__1740000639__13 any; var tmp6 *lang.Var




		A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_70; seq__1740000639__13 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq__1740000639__11)
//line :1295:1
		var v__14 any = first__1740000640__12; var vs__15 any = seq__1740000639__13; var vseq__16 any = vec__1740000638__10; var ret__17 any = ret__7; var i__18 int64 = i__8; var G__1740000637__19_ any = G__1740000637__9_; _ = v__14; _ = vs__15; _ = vseq__16; L1: for { var ret__20 any = ret__17; var i__21 int64 = i__18; var vec__1740000641__22 any = G__1740000637__19_; var seq__1740000642__23 any; var tmp7 *lang.Var




			A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_69; seq__1740000642__23 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(vec__1740000641__22)
//line :1295:1
			var first__1740000643__24 any; var tmp8 *lang.Var




			A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_53; first__1740000643__24 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq__1740000642__23)
//line :1295:1
			var seq__1740000642__25 any; var tmp9 *lang.Var




			A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_70; seq__1740000642__25 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq__1740000642__23)
//line :1295:1
			var v__26 any = first__1740000643__24
			var vs__27 any = seq__1740000642__25
			var vseq__28 any = vec__1740000641__22



			if jrt.J2g_Truth(vseq__28) { var cv__29 any; var target_114 any = spec__2; var tmp10 bool; var tmp11 bool
				tmp11 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_114); if tmp11 { tmp11 = !lang.Compiler_AOT_IsDyn_O__Z(target_114) }; tmp10 = tmp11; if tmp10 { cv__29 = A_arbace_spec_alpha_Spec_A_Cast(target_114).Conform_STAR__O__O(v__26) } else { var tmp12 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp12 = A_arbace_spec_alpha_A_const_44; cv__29 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(target_114, v__26) }
				var tmp13 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp13 = A_arbace_spec_alpha_A_const_246; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(cv__29)) { A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } else {

					ret__17, i__18, G__1740000637__19_ = lang.IFn_Cast(add__5).Invoke_O_O_O_O__O(ret__20, jrt.Long_ValueOf_J__Long(i__21).Ref(), v__26, cv__29), lang.Numbers_Inc_J__J(i__21), vs__27; continue L1 } } else {
						return lang.IFn_Cast(complete__6).Invoke_O__O(ret__20) } } } else {
//line :1295:1
							var tmp14 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp14 = A_arbace_spec_alpha_A_const_51; if tmp14 != nil {














								var tmp15 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp15 = A_arbace_spec_alpha_A_const_343; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(x__1)) { var step__3 int64; var tmp16 int64 = int64(lang.RT_Count_O__I(x__1)); var tmp17 *lang.Var
									A_arbace_spec_alpha_A_Init(); tmp17 = A_arbace_spec_alpha_A_const_344; step__3 = lang.Numbers_Max_J_J__J(1, lang.RT_LongCast_O__J(lang.Numbers_Divide_J_O__Number(tmp16, jrt.NN(tmp17).Get__O())))
//line :1310:1
									var i__4 int64 = 0; L2: for {


										if lang.Numbers_Gte_J_J__Z(i__4, int64(lang.RT_Count_O__I(x__1))) { return x__1 } else {

											var tmp18 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp18 = A_arbace_spec_alpha_A_const_102; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(spec__2, lang.RT_Nth_O_I__O(x__1, lang.RT_IntCast_J__I(i__4)))) {
												i__4 = lang.Numbers_Add_J_J__J(i__4, step__3); continue L2 } else {
//line :1315:1
													A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } } } } else {
//line :1310:1
														var limit__3 any; var tmp19 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp19 = A_arbace_spec_alpha_A_const_344; limit__3 = jrt.NN(tmp19).Get__O(); var i__4_2 int64 = 0; var G__1740000647__5_ any; var tmp20 *lang.Var








														A_arbace_spec_alpha_A_Init(); tmp20 = A_arbace_spec_alpha_A_const_69; G__1740000647__5_ = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(x__1)
//line :1310:1
														var vec__1740000648__6 any = G__1740000647__5_; var seq__1740000649__7 any; var tmp21 *lang.Var








														A_arbace_spec_alpha_A_Init(); tmp21 = A_arbace_spec_alpha_A_const_69; seq__1740000649__7 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(vec__1740000648__6)
//line :1310:1
														var first__1740000650__8 any; var tmp22 *lang.Var








														A_arbace_spec_alpha_A_Init(); tmp22 = A_arbace_spec_alpha_A_const_53; first__1740000650__8 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq__1740000649__7)
//line :1310:1
														var seq__1740000649__9 any; var tmp23 *lang.Var








														A_arbace_spec_alpha_A_Init(); tmp23 = A_arbace_spec_alpha_A_const_70; seq__1740000649__9 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(seq__1740000649__7)
//line :1310:1
														var v__10 any = first__1740000650__8; var vs__11 any = seq__1740000649__9; var vseq__12 any = vec__1740000648__6; var i__13 int64 = i__4_2; var G__1740000647__14_ any = G__1740000647__5_; _ = v__10; _ = vs__11; _ = vseq__12; L3: for { var i__15 int64 = i__13; var vec__1740000651__16 any = G__1740000647__14_; var seq__1740000652__17 any; var tmp24 *lang.Var








															A_arbace_spec_alpha_A_Init(); tmp24 = A_arbace_spec_alpha_A_const_69; seq__1740000652__17 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(vec__1740000651__16)
//line :1310:1
															var first__1740000653__18 any; var tmp25 *lang.Var








															A_arbace_spec_alpha_A_Init(); tmp25 = A_arbace_spec_alpha_A_const_53; first__1740000653__18 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seq__1740000652__17)
//line :1310:1
															var seq__1740000652__19 any; var tmp26 *lang.Var








															A_arbace_spec_alpha_A_Init(); tmp26 = A_arbace_spec_alpha_A_const_70; seq__1740000652__19 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(seq__1740000652__17)
//line :1310:1
															var v__20 any = first__1740000653__18; var vs__21 any = seq__1740000652__19; var vseq__22 any = vec__1740000651__16; var tmp27 bool; var or__1927000174__auto____23 bool = lang.Util_Identical_O_O__Z(vseq__22, nil)










															if or__1927000174__auto____23 { tmp27 = or__1927000174__auto____23 } else { tmp27 = lang.Util_Equiv_J_O__Z(i__15, limit__3) }
//line :1320:1
															if tmp27 { return x__1 } else { var tmp28 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp28 = A_arbace_spec_alpha_A_const_102; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O_O__O(spec__2, v__20)) {

																i__13, G__1740000647__14_ = lang.Numbers_Inc_J__J(i__15), vs__21; continue L3 } else {
//line :1320:1
																	var tmp29 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp29 = A_arbace_spec_alpha_A_const_51; if tmp29 != nil { A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } else { return nil } } } } } } else {
//line :1295:1
																		return nil } } } }; /*line :1287:1*/panic("j2g: unreachable") }
//line :1287:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Specize_STAR__O__O(___1 any) any { return t }
//line :1287:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Specize_STAR___O() any { return t }
//line :1287:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :1287:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_spec_alpha_every_impl_reify__1740000630_A_New_IPersistentMap_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(m, t.F_check_QMARK_, t.F_count, t.F_kind_form, t.F_form, t.F_gen_max, t.F_spec, t.F_max_count, t.F_kind, t.F_gfn, t.F_distinct, t.F_cfns, t.F_describe_form, t.F_cpred, t.F_conform_all, t.F_min_count, t.F_opts, t.F_gen_into, t.F_kfn, t.F_pred) }



















































func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :1339:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A) Ctor_O_O_O_O_O_O_O(c__check_QMARK_, c__in, c__form, c__path, c__via, c__kfn, c__pred any) { t.F_check_QMARK_ = c__check_QMARK_; t.F_in = c__in; t.F_form = c__form; t.F_path = c__path; t.F_via = c__via; t.F_kfn = c__kfn; t.F_pred = c__pred }
//line :1339:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A) Invoke_O_O_O__O(self, i__1, v__2 any) any { var k__3 any = lang.IFn_Cast(t.F_kfn).Invoke_O_O__O(i__1, v__2); if

	jrt.J2g_Truth(lang.IFn_Cast(t.F_check_QMARK_).Invoke_O__O(v__2)) { return nil } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_282.GetRawRoot__O()); var tmp2 any = t.F_form; var tmp3 any = t.F_pred; var tmp4 any = t.F_path; var tmp5 any = t.F_via; var prob__4 any = tmp1.Invoke_O_O_O_O_O_O__O(tmp2, tmp3, tmp4, tmp5, lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(t.F_in, k__3), v__2); return prob__4 } }










func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_New() *A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A{}; t.Ctor(); return t }
//line :1352:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A) Ctor() {}
//line :1352:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A) Invoke_O_O__O(self, p1__1740000607_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(p1__1740000607_SHARP___1)) { return p1__1740000607_SHARP___1 } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_328.GetRawRoot__O()).Invoke_O__O(p1__1740000607_SHARP___1) } }


func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :1355:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A) Ctor_O_O_O_O_O_O(c__count, c__gen_max, c__max_count, c__distinct, c__min_count, c__pgen any) { t.F_count = c__count; t.F_gen_max = c__gen_max; t.F_max_count = c__max_count; t.F_distinct = c__distinct; t.F_min_count = c__min_count; t.F_pgen = c__pgen }
//line :1355:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A) Invoke_O_O__O(self, init__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_289.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_New_O(init__1); var tmp3 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_fn_class = fncls__109d; tmp3 = fncls__109d } else { tmp3 = fncls__109 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 any

	if jrt.J2g_Truth(t.F_distinct) {

		if jrt.J2g_Truth(t.F_count) {
			var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_334.GetRawRoot__O()); var tmp7 any = t.F_pgen; tmp5 = tmp6.Invoke_O_O__O(tmp7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_336, t.F_count, A_arbace_spec_alpha_A_const_337, A_arbace_spec_alpha_A_const_103))) } else {
				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_334.GetRawRoot__O()); var tmp9 any = t.F_pgen; var tmp10 any = A_arbace_spec_alpha_A_const_338; var tmp11 any; var or__1927000174__auto____2 any = t.F_min_count; if jrt.J2g_Truth(or__1927000174__auto____2) { tmp11 = or__1927000174__auto____2 } else { tmp11 = A_arbace_spec_alpha_A_const_195 }; var tmp12 any = tmp11; var tmp13 any = A_arbace_spec_alpha_A_const_339; var tmp14 any; var or__1927000174__auto____2_2 any = t.F_max_count
				if jrt.J2g_Truth(or__1927000174__auto____2_2) { tmp14 = or__1927000174__auto____2_2 } else { var tmp15 any = t.F_gen_max; var tmp16 any; var or__1927000174__auto____3 any = t.F_min_count; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp16 = or__1927000174__auto____3 } else { tmp16 = A_arbace_spec_alpha_A_const_195 }; tmp14 = lang.Numbers_Max_O_O__O(tmp15, lang.Numbers_Multiply_J_O__Number(2, tmp16)) }
//line :1362:1
				tmp5 = tmp8.Invoke_O_O__O(tmp9, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp13, tmp14, A_arbace_spec_alpha_A_const_337, A_arbace_spec_alpha_A_const_103))) } } else {
//line :1358:1
					if jrt.J2g_Truth(t.F_count) {








						tmp5 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_335.GetRawRoot__O()).Invoke_O_O__O(t.F_pgen, t.F_count) } else {
//line :1358:1
							var tmp17 any; var or__1927000174__auto____2_3 any = t.F_min_count










							if jrt.J2g_Truth(or__1927000174__auto____2_3) { tmp17 = or__1927000174__auto____2_3 } else { tmp17 = t.F_max_count }
//line :1358:1
							if jrt.J2g_Truth(tmp17) {











								var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_335.GetRawRoot__O()); var tmp19 any = t.F_pgen; var tmp20 any; var or__1927000174__auto____2_4 any = t.F_min_count; if jrt.J2g_Truth(or__1927000174__auto____2_4) { tmp20 = or__1927000174__auto____2_4 } else { tmp20 = A_arbace_spec_alpha_A_const_195 }; var tmp21 any = tmp20; var tmp22 any; var or__1927000174__auto____2_5 any = t.F_max_count; if jrt.J2g_Truth(or__1927000174__auto____2_5) { tmp22 = or__1927000174__auto____2_5 } else { var tmp23 any = t.F_gen_max; var tmp24 any; var or__1927000174__auto____3_2 any = t.F_min_count; if jrt.J2g_Truth(or__1927000174__auto____3_2) { tmp24 = or__1927000174__auto____3_2 } else { tmp24 = A_arbace_spec_alpha_A_const_195 }; tmp22 = lang.Numbers_Max_O_O__O(tmp23, lang.Numbers_Multiply_J_O__Number(2, tmp24)) }; tmp5 = tmp18.Invoke_O_O_O__O(tmp19, tmp21, tmp22) } else {
//line :1358:1
									if A_arbace_spec_alpha_A_const_51 != nil {














										tmp5 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_335.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pgen, A_arbace_spec_alpha_A_const_195, t.F_gen_max) } else {
//line :1358:1
											tmp5 = nil } } } }
//line :1356:1
	return tmp1.Invoke_O_O__O(tmp4, tmp5) }
//line :1356:1
func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_New_O(p0 any) *A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A{}; t.Ctor_O(p0); return t }
//line :1356:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A) Ctor_O(c__init any) { t.F_init = c__init }
//line :1356:1
func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A) Invoke_O_O__O(self, p1__1740000608_SHARP___1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_296.GetRawRoot__O()).Invoke_O__O(t.F_init)) { return p1__1740000608_SHARP___1 } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_146.GetRawRoot__O()).Invoke_O_O__O(t.F_init, p1__1740000608_SHARP___1)
	}
}
























func A_arbace_spec_alpha_accept_A_New() *A_arbace_spec_alpha_accept_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_accept_A{}; t.Ctor(); return t }
//line :1384:1
func (t *A_arbace_spec_alpha_accept_A) Ctor() {}
//line :1384:1
func (t *A_arbace_spec_alpha_accept_A) Invoke_O_O__O(self, x__0 any) any { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_20, A_arbace_spec_alpha_A_const_345, A_arbace_spec_alpha_A_const_237, x__0)) }

func A_arbace_spec_alpha_accept_QMARK__A_New() *A_arbace_spec_alpha_accept_QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_accept_QMARK__A{}; t.Ctor(); return t }
//line :1386:1
func (t *A_arbace_spec_alpha_accept_QMARK__A) Ctor() {}
//line :1386:1
func (t *A_arbace_spec_alpha_accept_QMARK__A) Invoke_O_O__O(self, p__1740000678__0 any) any { var map__1740000679__2 any = p__1740000678__0; var map__1740000679__3 any; if lang.ISeq_InstanceOf(map__1740000679__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000679__2)) { map__1740000679__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000679__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000679__2)) { map__1740000679__3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000679__2) } else { lang.PersistentArrayMap_Init(); map__1740000679__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000679__3 = map__1740000679__2 }; var op__4 any = lang.RT_Get_O_O__O(map__1740000679__3, A_arbace_spec_alpha_A_const_20); return /*line :1387:1*/ jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_spec_alpha_A_const_345, op__4)).Ref() }

func A_arbace_spec_alpha_pcat_STAR__A_New() *A_arbace_spec_alpha_pcat_STAR__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_pcat_STAR__A{}; t.Ctor(); return t }
//line :1389:1
func (t *A_arbace_spec_alpha_pcat_STAR__A) Ctor() {}
//line :1389:1
func (t *A_arbace_spec_alpha_pcat_STAR__A) Invoke_O_O__O(self, p__1740000682__0 any) any { var map__1740000683__2 any = p__1740000682__0; var map__1740000683__3 any; if lang.ISeq_InstanceOf(map__1740000683__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000683__2)) { map__1740000683__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000683__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000683__2)) { map__1740000683__3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000683__2) } else { lang.PersistentArrayMap_Init(); map__1740000683__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000683__3 = map__1740000683__2 }; var vec__1740000685__4 any = lang.RT_Get_O_O__O(map__1740000683__3, A_arbace_spec_alpha_A_const_346); var seq__1740000686__5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000685__4); var first__1740000687__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000686__5); var seq__1740000686__7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000686__5); var p1__8 any = first__1740000687__6; var pr__9 any = seq__1740000686__7; var ps__10 any = vec__1740000685__4; var vec__1740000688__11 any = lang.RT_Get_O_O__O(map__1740000683__3, A_arbace_spec_alpha_A_const_347); var seq__1740000689__12 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000688__11); var first__1740000690__13 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000689__12); var seq__1740000689__14 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000689__12); var k1__15 any = first__1740000690__13; var kr__16 any = seq__1740000689__14; var ks__17 any = vec__1740000688__11; var vec__1740000691__18 any = lang.RT_Get_O_O__O(map__1740000683__3, A_arbace_spec_alpha_A_const_348); var seq__1740000692__19 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000691__18); var first__1740000693__20 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000692__19); var seq__1740000692__21 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000692__19); var f1__22 any = first__1740000693__20; var fr__23 any = seq__1740000692__21; var forms__24 any = vec__1740000691__18; var ret__25 any = lang.RT_Get_O_O__O(map__1740000683__3, A_arbace_spec_alpha_A_const_237); var rep_PLUS___26 any = lang.RT_Get_O_O__O(map__1740000683__3, A_arbace_spec_alpha_A_const_349); _ = f1__22; if
												jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_145.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_156.GetRawRoot__O(), ps__10)) {
													if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_350.GetRawRoot__O()).Invoke_O__O(p1__8)) { var rp__27 any = A_arbace_spec_alpha_A_const_237.Invoke_O__O(p1__8); var ret__28 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()); var tmp2 any

			if jrt.J2g_Truth(ks__17) { tmp2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, k1__15, rp__27)) } else { tmp2 = rp__27 }; ret__28 = tmp1.Invoke_O_O__O(ret__25, tmp2)
			if jrt.J2g_Truth(pr__9) {
				return lang.IFn_Cast(A_arbace_spec_alpha_A_const_351.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_346, pr__9, A_arbace_spec_alpha_A_const_347, kr__16, A_arbace_spec_alpha_A_const_348, fr__23, A_arbace_spec_alpha_A_const_237, ret__28))) } else {
					return lang.IFn_Cast(A_arbace_spec_alpha_A_const_352.GetRawRoot__O()).Invoke_O__O(ret__28) } } else {
//line :1391:1
						return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_20, A_arbace_spec_alpha_A_const_353, A_arbace_spec_alpha_A_const_346, ps__10, A_arbace_spec_alpha_A_const_237, ret__25, A_arbace_spec_alpha_A_const_347, ks__17, A_arbace_spec_alpha_A_const_348, forms__24, A_arbace_spec_alpha_A_const_349, rep_PLUS___26)) } } else {
//line :1390:1
							return nil } }








func A_arbace_spec_alpha_pcat_A_New() *A_arbace_spec_alpha_pcat_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_pcat_A{}; t.Ctor(); return t }
//line :1399:1
func (t *A_arbace_spec_alpha_pcat_A) Ctor() {}
//line :1399:1
func (t *A_arbace_spec_alpha_pcat_A) DoInvoke_O_O__O(self, ps__0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_351.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_A_const_346; var tmp3 any = A_arbace_spec_alpha_A_const_237; var tmp4 *lang.PersistentVector; lang.PersistentVector_Init(); tmp4 = lang.PersistentVector_EMPTY; return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, ps__0, tmp3, tmp4.Ref()))) }

func A_arbace_spec_alpha_cat_impl_A_New() *A_arbace_spec_alpha_cat_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_cat_impl_A{}; t.Ctor(); return t }
//line :1401:1
func (t *A_arbace_spec_alpha_cat_impl_A) Ctor() {}
//line :1401:1
func (t *A_arbace_spec_alpha_cat_impl_A) Invoke_O_O_O_O__O(self, ks__0, ps__1, forms__2 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_351.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_A_const_347; var tmp3 any = A_arbace_spec_alpha_A_const_346; var tmp4 any = A_arbace_spec_alpha_A_const_348; var tmp5 any = A_arbace_spec_alpha_A_const_237; var tmp6 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp6 = lang.PersistentArrayMap_EMPTY; return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, ks__0, tmp3, ps__1, tmp4, forms__2, tmp5, tmp6.Ref())))
}
func A_arbace_spec_alpha_rep_STAR__A_New() *A_arbace_spec_alpha_rep_STAR__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_rep_STAR__A{}; t.Ctor(); return t }
//line :1406:1
func (t *A_arbace_spec_alpha_rep_STAR__A) Ctor() {}
//line :1406:1
func (t *A_arbace_spec_alpha_rep_STAR__A) Invoke_O_O_O_O_O_O__O(self, p1__0, p2__1, ret__2, splice__3, form__4 any) any {
	if jrt.J2g_Truth(p1__0) { var tmp1 any = A_arbace_spec_alpha_A_const_20; var tmp2 any = A_arbace_spec_alpha_A_const_354; var tmp3 any = A_arbace_spec_alpha_A_const_355; var tmp4 any = A_arbace_spec_alpha_A_const_356; var tmp5 any = A_arbace_spec_alpha_A_const_348; var tmp6 any = A_arbace_spec_alpha_A_const_357; var r__6 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp2, tmp3, p2__1, tmp4, splice__3, tmp5, form__4, tmp6, jrt.UUID_RandomUUID__UUID().Ref()))

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_350.GetRawRoot__O()).Invoke_O__O(p1__0)) {
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()); var tmp8 any = A_arbace_spec_alpha_A_const_358; var tmp9 any = A_arbace_spec_alpha_A_const_237; return tmp7.Invoke_O_O_O_O_O__O(r__6, tmp8, p2__1, tmp9, lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(ret__2, A_arbace_spec_alpha_A_const_237.Invoke_O__O(p1__0))) } else {
				return lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()).Invoke_O_O_O_O_O__O(r__6, A_arbace_spec_alpha_A_const_358, p1__0, A_arbace_spec_alpha_A_const_237, ret__2) } } else {
//line :1407:1
					return nil
				}
}



func A_arbace_spec_alpha_rep_impl_A_New() *A_arbace_spec_alpha_rep_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_rep_impl_A{}; t.Ctor(); return t }
//line :1413:1
func (t *A_arbace_spec_alpha_rep_impl_A) Ctor() {}
//line :1413:1
func (t *A_arbace_spec_alpha_rep_impl_A) Invoke_O_O_O__O(self, form__0, p__1 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_359.GetRawRoot__O()); var tmp2 *lang.PersistentVector; lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; var tmp3 any = tmp2.Ref(); var tmp4 *jrt.Boolean; jrt.Boolean_Init(); tmp4 = jrt.Boolean_FALSE; return tmp1.Invoke_O_O_O_O_O__O(p__1, p__1, tmp3, tmp4.Ref(), form__0)
}
func A_arbace_spec_alpha_rep_PLUS_impl_A_New() *A_arbace_spec_alpha_rep_PLUS_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_rep_PLUS_impl_A{}; t.Ctor(); return t }
//line :1417:1
func (t *A_arbace_spec_alpha_rep_PLUS_impl_A) Ctor() {}
//line :1417:1
func (t *A_arbace_spec_alpha_rep_PLUS_impl_A) Invoke_O_O_O__O(self, form__0, p__1 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_351.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_A_const_346; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_359.GetRawRoot__O()); var tmp4 *lang.PersistentVector; lang.PersistentVector_Init(); tmp4 = lang.PersistentVector_EMPTY; var tmp5 any = tmp4.Ref(); var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; var tmp7 any = lang.Tuple_Create_O_O__IPersistentVector(p__1, tmp3.Invoke_O_O_O_O_O__O(p__1, p__1, tmp5, tmp6.Ref(), form__0)); var tmp8 any = A_arbace_spec_alpha_A_const_348; var tmp9 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(form__0), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_360), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(form__0))))))); var tmp10 any = A_arbace_spec_alpha_A_const_237; var tmp11 *lang.PersistentVector; lang.PersistentVector_Init(); tmp11 = lang.PersistentVector_EMPTY; return tmp1.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp7, tmp8, tmp9, tmp10, tmp11.Ref(), A_arbace_spec_alpha_A_const_349, form__0)))
}
func A_arbace_spec_alpha_amp_impl_A_New() *A_arbace_spec_alpha_amp_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_amp_impl_A{}; t.Ctor(); return t }
//line :1422:1
func (t *A_arbace_spec_alpha_amp_impl_A) Ctor() {}
//line :1422:1
func (t *A_arbace_spec_alpha_amp_impl_A) Invoke_O_O_O_O_O__O(self, re__0, re_form__1, preds__2, pred_forms__3 any) any { return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_20, A_arbace_spec_alpha_A_const_361, A_arbace_spec_alpha_A_const_358, re__0, A_arbace_spec_alpha_A_const_362, re_form__1, A_arbace_spec_alpha_A_const_346, preds__2, A_arbace_spec_alpha_A_const_348, pred_forms__3)) }




func A_arbace_spec_alpha_filter_alt_A_New() *A_arbace_spec_alpha_filter_alt_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_filter_alt_A{}; t.Ctor(); return t }
//line :1427:1
func (t *A_arbace_spec_alpha_filter_alt_A) Ctor() {}
//line :1427:1
func (t *A_arbace_spec_alpha_filter_alt_A) Invoke_O_O_O_O_O__O(self, ps__0, ks__1, forms__2, f__3 any) any {
	var tmp1 any; var or__1927000174__auto____5 any = ks__1; if jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = forms__2 }; if jrt.J2g_Truth(tmp1) { var pks__5 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_278.GetRawRoot__O()); var tmp3 any = A_arbace_spec_alpha_filter_alt_fn__1740000703_A_New_O(f__3); var tmp4 *jrt.Class
		var fncls__115 /*line :1428:1*/*jrt.Class = A_arbace_spec_alpha_filter_alt_fn__1740000703_A_fn_class



		if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_spec_alpha_filter_alt_fn__1740000703_A_fn_class = fncls__115d; tmp4 = fncls__115d } else { tmp4 = fncls__115 }; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()); var tmp7 any = A_arbace_spec_alpha_A_const_159.GetRawRoot__O(); var tmp8 any; var or__1927000174__auto____5_2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(ks__1)
//line :1430:1
		if jrt.J2g_Truth(or__1927000174__auto____5_2) { tmp8 = or__1927000174__auto____5_2 } else { tmp8 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_363.GetRawRoot__O()).Invoke_O__O(nil)
		}
		var tmp9 any = tmp8; var tmp10 any; var or__1927000174__auto____5_3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(forms__2)
//line :1431:1
		if jrt.J2g_Truth(or__1927000174__auto____5_3) { tmp10 = or__1927000174__auto____5_3 } else { tmp10 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_363.GetRawRoot__O()).Invoke_O__O(nil) }
		pks__5 = tmp2.Invoke_O_O__O(tmp5, tmp6.Invoke_O_O_O_O__O(tmp7, ps__0, tmp9, tmp10))
//line :1428:1
		var tmp11 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_53.GetRawRoot__O(), pks__5)); var tmp12 any




		if jrt.J2g_Truth(ks__1) { tmp12 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_55.GetRawRoot__O(), pks__5)) } else { tmp12 = nil }
//line :1428:1
		var tmp13 any = tmp12; var tmp14 any




		if jrt.J2g_Truth(forms__2) { var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()); var tmp17 any = A_arbace_spec_alpha_filter_alt_fn__1740000705_A_New(); var tmp18 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_spec_alpha_filter_alt_fn__1740000705_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_spec_alpha_filter_alt_fn__1740000705_A_fn_class = fncls__116d; tmp18 = fncls__116d } else { tmp18 = fncls__116 }; tmp14 = tmp15.Invoke_O__O(tmp16.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil), pks__5)) } else { tmp14 = nil }
//line :1428:1
		return lang.Tuple_Create_O_O_O__IPersistentVector(tmp11, tmp13, tmp14) } else { return lang.Tuple_Create_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_278.GetRawRoot__O()).Invoke_O_O__O(f__3, ps__0)), ks__1, forms__2)
		}
}

func A_arbace_spec_alpha_filter_alt_fn__1740000703_A_New_O(p0 any) *A_arbace_spec_alpha_filter_alt_fn__1740000703_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_filter_alt_fn__1740000703_A{}; t.Ctor_O(p0); return t }
//line :1432:1
func (t *A_arbace_spec_alpha_filter_alt_fn__1740000703_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :1432:1
func (t *A_arbace_spec_alpha_filter_alt_fn__1740000703_A) Invoke_O_O__O(self, p1__1740000701_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_f); return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(p1__1740000701_SHARP___1)) }
func A_arbace_spec_alpha_filter_alt_fn__1740000705_A_New() *A_arbace_spec_alpha_filter_alt_fn__1740000705_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_filter_alt_fn__1740000705_A{}; t.Ctor(); return t }
//line :1433:1
func (t *A_arbace_spec_alpha_filter_alt_fn__1740000705_A) Ctor() {}
//line :1433:1
func (t *A_arbace_spec_alpha_filter_alt_fn__1740000705_A) Invoke_O_O__O(self, p1__1740000702_SHARP___1 any) any { return lang.RT_Nth_O_I__O(p1__1740000702_SHARP___1, lang.RT_IntCast_J__I(2)) }


func A_arbace_spec_alpha_alt_STAR__A_New() *A_arbace_spec_alpha_alt_STAR__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_alt_STAR__A{}; t.Ctor(); return t }
//line :1436:1
func (t *A_arbace_spec_alpha_alt_STAR__A) Ctor() {}
//line :1436:1
func (t *A_arbace_spec_alpha_alt_STAR__A) Invoke_O_O_O_O__O(self, ps__0, ks__1, forms__2 any) any { var vec__1740000708__4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_364.GetRawRoot__O()).Invoke_O_O_O_O__O(ps__0, ks__1, forms__2, A_arbace_spec_alpha_A_const_156.GetRawRoot__O()); var vec__1740000711__5 any = lang.RT_Nth_O_I_O__O(vec__1740000708__4, lang.RT_IntCast_J__I(0), nil); var seq__1740000712__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000711__5); var first__1740000713__7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000712__6); var seq__1740000712__8 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000712__6); var p1__9 any = first__1740000713__7; var pr__10 any = seq__1740000712__8; var ps__11 any = vec__1740000711__5; var vec__1740000714__12 any = lang.RT_Nth_O_I_O__O(vec__1740000708__4, lang.RT_IntCast_J__I(1), nil); var k1__13 any = lang.RT_Nth_O_I_O__O(vec__1740000714__12, lang.RT_IntCast_J__I(0), nil); var ks__14 any = vec__1740000714__12; var forms__15 any = lang.RT_Nth_O_I_O__O(vec__1740000708__4, lang.RT_IntCast_J__I(2), nil); if

	jrt.J2g_Truth(ps__11) { var ret__16 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_20, A_arbace_spec_alpha_A_const_365, A_arbace_spec_alpha_A_const_346, ps__11, A_arbace_spec_alpha_A_const_347, ks__14, A_arbace_spec_alpha_A_const_348, forms__15))

		if lang.Util_Identical_O_O__Z(pr__10, nil) {
			if jrt.J2g_Truth(k1__13) {
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_350.GetRawRoot__O()).Invoke_O__O(p1__9)) {
					return lang.IFn_Cast(A_arbace_spec_alpha_A_const_352.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_302.GetRawRoot__O()).Invoke_O_O__O(k1__13, A_arbace_spec_alpha_A_const_237.Invoke_O__O(p1__9))) } else {
//line :1442:1
						return ret__16 } } else {
//line :1441:1
							return p1__9 } } else {
//line :1440:1
								return ret__16 } } else {
//line :1438:1
									return nil } }









func A_arbace_spec_alpha_alts_A_New() *A_arbace_spec_alpha_alts_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_alts_A{}; t.Ctor(); return t }
//line :1448:1
func (t *A_arbace_spec_alpha_alts_A) Ctor() {}
//line :1448:1
func (t *A_arbace_spec_alpha_alts_A) DoInvoke_O_O__O(self, ps__0 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_366.GetRawRoot__O()).Invoke_O_O_O__O(ps__0, nil, nil) }
func A_arbace_spec_alpha_alt2_A_New() *A_arbace_spec_alpha_alt2_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_alt2_A{}; t.Ctor(); return t }
//line :1449:1
func (t *A_arbace_spec_alpha_alt2_A) Ctor() {}
//line :1449:1
func (t *A_arbace_spec_alpha_alt2_A) Invoke_O_O_O__O(self, p1__0, p2__1 any) any { var tmp1 any; var and__1927000168__auto____3 any = p1__0; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = p2__1 } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_367.GetRawRoot__O()).Invoke_O_O__O(p1__0, p2__1) } else { var or__1927000174__auto____3 any = p1__0; if jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { return p2__1 } } }

func A_arbace_spec_alpha_alt_impl_A_New() *A_arbace_spec_alpha_alt_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_alt_impl_A{}; t.Ctor(); return t }
//line :1451:1
func (t *A_arbace_spec_alpha_alt_impl_A) Ctor() {}
//line :1451:1
func (t *A_arbace_spec_alpha_alt_impl_A) Invoke_O_O_O_O__O(self, ks__0, ps__1, forms__2 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_366.GetRawRoot__O()).Invoke_O_O_O__O(ps__1, ks__0, forms__2); var tmp3 any = A_arbace_spec_alpha_A_const_357; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, jrt.UUID_RandomUUID__UUID().Ref())
}
func A_arbace_spec_alpha_maybe_impl_A_New() *A_arbace_spec_alpha_maybe_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_maybe_impl_A{}; t.Ctor(); return t }
//line :1455:1
func (t *A_arbace_spec_alpha_maybe_impl_A) Ctor() {}
//line :1455:1
func (t *A_arbace_spec_alpha_maybe_impl_A) Invoke_O_O_O__O(self, p__0, form__1 any) any {

	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_366.GetRawRoot__O()).Invoke_O_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(p__0, lang.IFn_Cast(A_arbace_spec_alpha_A_const_352.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_369)), nil, lang.Tuple_Create_O_O__IPersistentVector(form__1, A_arbace_spec_alpha_A_const_369)), A_arbace_spec_alpha_A_const_368, form__1)
}
func A_arbace_spec_alpha_noret_QMARK__A_New() *A_arbace_spec_alpha_noret_QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_noret_QMARK__A{}; t.Ctor(); return t }
//line :1459:1
func (t *A_arbace_spec_alpha_noret_QMARK__A) Ctor() {}
//line :1459:1
func (t *A_arbace_spec_alpha_noret_QMARK__A) Invoke_O_O_O__O(self, p1__0, pret__1 any) any { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z(pret__1, A_arbace_spec_alpha_A_const_369); if or__1927000174__auto____3 {
												return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var or__1927000174__auto____4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_370); var tmp2 *lang.Keyword = A_arbace_spec_alpha_A_const_20; var and__1927000168__auto____4 any = tmp1.Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_35.GetRawRoot__O()).Invoke_O__O(p1__0)))
													if jrt.J2g_Truth(and__1927000168__auto____4) {
														or__1927000174__auto____4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(pret__1) } else {
//line :1461:1
				or__1927000174__auto____4 = and__1927000168__auto____4 }
//line :1460:1
		if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return nil } } }






func A_arbace_spec_alpha_accept_nil_QMARK__A_New() *A_arbace_spec_alpha_accept_nil_QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_accept_nil_QMARK__A{}; t.Ctor(); return t }
//line :1467:1
func (t *A_arbace_spec_alpha_accept_nil_QMARK__A) Ctor() {}
//line :1467:1
func (t *A_arbace_spec_alpha_accept_nil_QMARK__A) Invoke_O_O__O(self, p__0 any) any { var map__1740000723__2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_35.GetRawRoot__O()).Invoke_O__O(p__0); var map__1740000723__3 any; if
											lang.ISeq_InstanceOf(map__1740000723__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000723__2)) { map__1740000723__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000723__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000723__2)) { map__1740000723__3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000723__2) } else { lang.PersistentArrayMap_Init(); map__1740000723__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000723__3 = map__1740000723__2 }; var p__4 any = map__1740000723__3; var op__5 any = /*line :1467:1*/lang.RT_Get_O_O__O(map__1740000723__3, A_arbace_spec_alpha_A_const_20); var ps__6 any = lang.RT_Get_O_O__O(map__1740000723__3, A_arbace_spec_alpha_A_const_346); var p1__7 any = lang.RT_Get_O_O__O(map__1740000723__3, A_arbace_spec_alpha_A_const_358); var p2__8 any = lang.RT_Get_O_O__O(map__1740000723__3, A_arbace_spec_alpha_A_const_355); var forms__9 any = lang.RT_Get_O_O__O(map__1740000723__3, A_arbace_spec_alpha_A_const_348); var G__1740000725__10_ any = op__5; _ = p__4; switch

	lang.Util_Hash_O__I(G__1740000725__10_) >> 1 & 15 { case 0: if lang.Util_Equiv_O_O__Z(G__1740000725__10_, nil) { return nil }; case 1: if lang.Util_Equiv_O_O__Z(G__1740000725__10_, A_arbace_spec_alpha_A_const_345) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 7: if lang.Util_Equiv_O_O__Z(G__1740000725__10_, A_arbace_spec_alpha_A_const_361) { var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_371.GetRawRoot__O()).Invoke_O__O(p1__7)


		if jrt.J2g_Truth(and__1927000168__auto____11) { var ret__12 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_372.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_373.GetRawRoot__O()).Invoke_O__O(p1__7), ps__6, lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(forms__9))

			return lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(ret__12)) } else {
//line :1472:1
				return and__1927000168__auto____11 } }
//line :1469:1
	case 9: if lang.Util_Equiv_O_O__Z(G__1740000725__10_, A_arbace_spec_alpha_A_const_354) { var or__1927000174__auto____11 bool = lang.Util_Identical_O_O__Z(p1__7, p2__8)





		if or__1927000174__auto____11 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____11).Ref() } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_371.GetRawRoot__O()).Invoke_O__O(p1__7) } }
//line :1469:1
	case 12: if lang.Util_Equiv_O_O__Z(G__1740000725__10_, A_arbace_spec_alpha_A_const_353) {






		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_145.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_371.GetRawRoot__O(), ps__6) }
//line :1469:1
	case 14: if lang.Util_Equiv_O_O__Z(G__1740000725__10_, A_arbace_spec_alpha_A_const_365) {







		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_313.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_371.GetRawRoot__O(), ps__6) }
//line :1469:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1740000725__10_))))) }











func A_arbace_spec_alpha_preturn_A_New() *A_arbace_spec_alpha_preturn_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_preturn_A{}; t.Ctor(); return t }
//line :1481:1
func (t *A_arbace_spec_alpha_preturn_A) Ctor() {}
//line :1481:1
func (t *A_arbace_spec_alpha_preturn_A) Invoke_O_O__O(self, p__0 any) any { var map__1740000727__2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_35.GetRawRoot__O()).Invoke_O__O(p__0); var map__1740000727__3 any; if
										lang.ISeq_InstanceOf(map__1740000727__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000727__2)) { map__1740000727__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000727__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000727__2)) { map__1740000727__3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000727__2) } else { lang.PersistentArrayMap_Init(); map__1740000727__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000727__3 = map__1740000727__2 }; var p__4 any = map__1740000727__3; var vec__1740000729__5 any = /*line :1481:1*/lang.RT_Get_O_O__O(map__1740000727__3, A_arbace_spec_alpha_A_const_346); var seq__1740000730__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000729__5); var first__1740000731__7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000730__6); var seq__1740000730__8 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000730__6); var p0__9 any = first__1740000731__7; var pr__10 any = seq__1740000730__8; var ps__11 any = vec__1740000729__5; var vec__1740000732__12 any = lang.RT_Get_O_O__O(map__1740000727__3, A_arbace_spec_alpha_A_const_347); var k__13 any = lang.RT_Nth_O_I_O__O(vec__1740000732__12, lang.RT_IntCast_J__I(0), nil); var ks__14 any = vec__1740000732__12; var op__15 any = lang.RT_Get_O_O__O(map__1740000727__3, A_arbace_spec_alpha_A_const_20); var p1__16 any = lang.RT_Get_O_O__O(map__1740000727__3, A_arbace_spec_alpha_A_const_358); var ret__17 any = lang.RT_Get_O_O__O(map__1740000727__3, A_arbace_spec_alpha_A_const_237); var forms__18 any = lang.RT_Get_O_O__O(map__1740000727__3, A_arbace_spec_alpha_A_const_348); var G__1740000735__19_ any = op__15; _ = p__4; _ = pr__10; switch

	lang.Util_Hash_O__I(G__1740000735__19_) >> 1 & 15 { case 0: if lang.Util_Equiv_O_O__Z(G__1740000735__19_, nil) { return nil }; case 1: if lang.Util_Equiv_O_O__Z(G__1740000735__19_, A_arbace_spec_alpha_A_const_345) { return ret__17 }; case 7: if lang.Util_Equiv_O_O__Z(G__1740000735__19_, A_arbace_spec_alpha_A_const_361) { var pret__20 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_373.GetRawRoot__O()).Invoke_O__O(p1__16)



		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_374.GetRawRoot__O()).Invoke_O_O__O(p1__16, pret__20)) { return A_arbace_spec_alpha_A_const_369 } else {

			return lang.IFn_Cast(A_arbace_spec_alpha_A_const_372.GetRawRoot__O()).Invoke_O_O_O__O(pret__20, ps__11, forms__18) } }
//line :1483:1
	case 9: if lang.Util_Equiv_O_O__Z(G__1740000735__19_, A_arbace_spec_alpha_A_const_354) {






		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_375.GetRawRoot__O()).Invoke_O_O_O__O(p1__16, ret__17, k__13) }
//line :1483:1
	case 12: if lang.Util_Equiv_O_O__Z(G__1740000735__19_, A_arbace_spec_alpha_A_const_353) {







		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_375.GetRawRoot__O()).Invoke_O_O_O__O(p0__9, ret__17, k__13) }
//line :1483:1
	case 14: if lang.Util_Equiv_O_O__Z(G__1740000735__19_, A_arbace_spec_alpha_A_const_365) { var vec__1740000736__20 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_364.GetRawRoot__O()).Invoke_O_O_O_O__O(ps__11, ks__14, forms__18, A_arbace_spec_alpha_A_const_371.GetRawRoot__O()); var vec__1740000739__21 any = lang.RT_Nth_O_I_O__O(vec__1740000736__20, lang.RT_IntCast_J__I(0), nil); var p0__22 any = lang.RT_Nth_O_I_O__O(vec__1740000739__21, lang.RT_IntCast_J__I(0), nil); var vec__1740000742__23 any = lang.RT_Nth_O_I_O__O(vec__1740000736__20, lang.RT_IntCast_J__I(1), nil); var k0__24 any = lang.RT_Nth_O_I_O__O(vec__1740000742__23, lang.RT_IntCast_J__I(0), nil); var r__25 any









		if lang.Util_Identical_O_O__Z(p0__22, nil) { r__25 = A_arbace_spec_alpha_A_const_369 } else { r__25 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_373.GetRawRoot__O()).Invoke_O__O(p0__22) }
		if jrt.J2g_Truth(k0__24) { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_302.GetRawRoot__O()).Invoke_O_O__O(k0__24, r__25) } else { return r__25 } }
//line :1483:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1740000735__19_))))) }












func A_arbace_spec_alpha_op_unform_A_New() *A_arbace_spec_alpha_op_unform_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_op_unform_A{}; t.Ctor(); return t }
//line :1496:1
func (t *A_arbace_spec_alpha_op_unform_A) Ctor() {}
//line :1496:1
func (t *A_arbace_spec_alpha_op_unform_A) Invoke_O_O_O__O(self, p__0, x__1 any) any { var map__1740000750__3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_35.GetRawRoot__O()).Invoke_O__O(p__0); var map__1740000750__4 any; if

	lang.ISeq_InstanceOf(map__1740000750__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000750__3)) { map__1740000750__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000750__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000750__3)) { map__1740000750__4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000750__3) } else { lang.PersistentArrayMap_Init(); map__1740000750__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000750__4 = map__1740000750__3 }; var p__5 any = map__1740000750__4; var vec__1740000752__6 any = /*line :1496:1*/lang.RT_Get_O_O__O(map__1740000750__4, A_arbace_spec_alpha_A_const_346); var seq__1740000753__7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000752__6); var first__1740000754__8 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000753__7); var seq__1740000753__9 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000753__7); var p0__10 any = first__1740000754__8; var pr__11 any = seq__1740000753__9; var ps__12 any = vec__1740000752__6; var vec__1740000755__13 any = lang.RT_Get_O_O__O(map__1740000750__4, A_arbace_spec_alpha_A_const_347); var k__14 any = lang.RT_Nth_O_I_O__O(vec__1740000755__13, lang.RT_IntCast_J__I(0), nil); var ks__15 any = vec__1740000755__13; var op__16 any = lang.RT_Get_O_O__O(map__1740000750__4, A_arbace_spec_alpha_A_const_20); var p1__17 any = lang.RT_Get_O_O__O(map__1740000750__4, A_arbace_spec_alpha_A_const_358); var ret__18 any = lang.RT_Get_O_O__O(map__1740000750__4, A_arbace_spec_alpha_A_const_237); var forms__19 any = lang.RT_Get_O_O__O(map__1740000750__4, A_arbace_spec_alpha_A_const_348); var rep_PLUS___20 any = lang.RT_Get_O_O__O(map__1740000750__4, A_arbace_spec_alpha_A_const_349); var maybe__21 any = lang.RT_Get_O_O__O(map__1740000750__4, A_arbace_spec_alpha_A_const_368); var kps__22 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_267.GetRawRoot__O()).Invoke_O_O__O(ks__15, ps__12); var G__1740000758__23_ any = op__16; _ = pr__11; _ = k__14; _ = forms__19; switch



	lang.Util_Hash_O__I(G__1740000758__23_) >> 1 & 15 { case 0: if lang.Util_Equiv_O_O__Z(G__1740000758__23_, nil) { return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_alpha_A_const_284.GetRawRoot__O()).Invoke_O_O__O(p__5, x__1)) }; case 1: if lang.Util_Equiv_O_O__Z(G__1740000758__23_, A_arbace_spec_alpha_A_const_345) { return lang.Tuple_Create_O__IPersistentVector(ret__18) }; case 7: if lang.Util_Equiv_O_O__Z(G__1740000758__23_, A_arbace_spec_alpha_A_const_361) { var px__24 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_308.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_op_unform_fn__1740000759_A_New(); var tmp3 *jrt.Class
		var fncls__120 /*line :1500:1*/*jrt.Class = A_arbace_spec_alpha_op_unform_fn__1740000759_A_fn_class


		if fncls__120 == nil { var fncls__120d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_117, false); A_arbace_spec_alpha_op_unform_fn__1740000759_A_fn_class = fncls__120d; tmp3 = fncls__120d } else { tmp3 = fncls__120 }; px__24 = tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), x__1, lang.IFn_Cast(A_arbace_spec_alpha_A_const_309.GetRawRoot__O()).Invoke_O__O(ps__12))
		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_376.GetRawRoot__O()).Invoke_O_O__O(p1__17, px__24) }
//line :1500:1
	case 9: if lang.Util_Equiv_O_O__Z(G__1740000758__23_, A_arbace_spec_alpha_A_const_354) {




		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_179.GetRawRoot__O()); var tmp5 any = A_arbace_spec_alpha_op_unform_fn__1740000761_A_New_O(p1__17); var tmp6 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_spec_alpha_op_unform_fn__1740000761_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_118, false); A_arbace_spec_alpha_op_unform_fn__1740000761_A_fn_class = fncls__121d; tmp6 = fncls__121d } else { tmp6 = fncls__121 }; return tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), x__1) }
//line :1500:1
	case 12: if lang.Util_Equiv_O_O__Z(G__1740000758__23_, A_arbace_spec_alpha_A_const_353) {





		if jrt.J2g_Truth(rep_PLUS___20) {
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_179.GetRawRoot__O()); var tmp8 any = A_arbace_spec_alpha_op_unform_fn__1740000763_A_New_O(p0__10); var tmp9 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_spec_alpha_op_unform_fn__1740000763_A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_119, false); A_arbace_spec_alpha_op_unform_fn__1740000763_A_fn_class = fncls__122d; tmp9 = fncls__122d } else { tmp9 = fncls__122 }; return tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), x__1) } else {
				var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_179.GetRawRoot__O()); var tmp11 any = A_arbace_spec_alpha_op_unform_fn__1740000765_A_New_O_O(x__1, kps__22); var tmp12 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_spec_alpha_op_unform_fn__1740000765_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_120, false); A_arbace_spec_alpha_op_unform_fn__1740000765_A_fn_class = fncls__123d; tmp12 = fncls__123d } else { tmp12 = fncls__123 }; return tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), ks__15) } }
//line :1500:1
	case 14: if lang.Util_Equiv_O_O__Z(G__1740000758__23_, A_arbace_spec_alpha_A_const_365) {











		if jrt.J2g_Truth(maybe__21) { return lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_alpha_A_const_284.GetRawRoot__O()).Invoke_O_O__O(p0__10, x__1)) } else { var vec__1740000767__24 any = x__1; var k__25 any = lang.RT_Nth_O_I_O__O(vec__1740000767__24, lang.RT_IntCast_J__I(0), nil); var v__26 any = lang.RT_Nth_O_I_O__O(vec__1740000767__24, lang.RT_IntCast_J__I(1), nil)


			return lang.IFn_Cast(A_arbace_spec_alpha_A_const_376.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(kps__22).Invoke_O__O(k__25), v__26) } }
//line :1500:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1740000758__23_))))) }


func A_arbace_spec_alpha_op_unform_fn__1740000759_A_New() *A_arbace_spec_alpha_op_unform_fn__1740000759_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_op_unform_fn__1740000759_A{}; t.Ctor(); return t }
//line :1503:1
func (t *A_arbace_spec_alpha_op_unform_fn__1740000759_A) Ctor() {}
//line :1503:1
func (t *A_arbace_spec_alpha_op_unform_fn__1740000759_A) Invoke_O_O_O__O(self, p1__1740000747_SHARP___1, p2__1740000746_SHARP___2 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_284.GetRawRoot__O()).Invoke_O_O__O(p2__1740000746_SHARP___2, p1__1740000747_SHARP___1) }

func A_arbace_spec_alpha_op_unform_fn__1740000761_A_New_O(p0 any) *A_arbace_spec_alpha_op_unform_fn__1740000761_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_op_unform_fn__1740000761_A{}; t.Ctor_O(p0); return t }
//line :1505:1
func (t *A_arbace_spec_alpha_op_unform_fn__1740000761_A) Ctor_O(c__p1 any) { t.F_p1 = c__p1 }
//line :1505:1
func (t *A_arbace_spec_alpha_op_unform_fn__1740000761_A) Invoke_O_O__O(self, p1__1740000748_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_376.GetRawRoot__O()).Invoke_O_O__O(t.F_p1, p1__1740000748_SHARP___1) }

func A_arbace_spec_alpha_op_unform_fn__1740000763_A_New_O(p0 any) *A_arbace_spec_alpha_op_unform_fn__1740000763_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_op_unform_fn__1740000763_A{}; t.Ctor_O(p0); return t }
//line :1507:1
func (t *A_arbace_spec_alpha_op_unform_fn__1740000763_A) Ctor_O(c__p0 any) { t.F_p0 = c__p0 }
//line :1507:1
func (t *A_arbace_spec_alpha_op_unform_fn__1740000763_A) Invoke_O_O__O(self, p1__1740000749_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_376.GetRawRoot__O()).Invoke_O_O__O(t.F_p0, p1__1740000749_SHARP___1) }
func A_arbace_spec_alpha_op_unform_fn__1740000765_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_op_unform_fn__1740000765_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_op_unform_fn__1740000765_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1508:1
func (t *A_arbace_spec_alpha_op_unform_fn__1740000765_A) Ctor_O_O(c__x, c__kps any) { t.F_x = c__x; t.F_kps = c__kps }
//line :1508:1
func (t *A_arbace_spec_alpha_op_unform_fn__1740000765_A) Invoke_O_O__O(self, k__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_251.GetRawRoot__O()).Invoke_O_O__O(t.F_x, k__1)) {
		return lang.IFn_Cast(A_arbace_spec_alpha_A_const_376.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_kps).Invoke_O__O(k__1), lang.RT_Get_O_O__O(t.F_x, k__1)) } else {
//line :1509:1
			return nil
		}
}





func A_arbace_spec_alpha_add_ret_A_New() *A_arbace_spec_alpha_add_ret_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_add_ret_A{}; t.Ctor(); return t }
//line :1517:1
func (t *A_arbace_spec_alpha_add_ret_A) Ctor() {}
//line :1517:1
func (t *A_arbace_spec_alpha_add_ret_A) Invoke_O_O_O_O__O(self, p__0, r__1, k__2 any) any { var map__1740000771__4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_35.GetRawRoot__O()).Invoke_O__O(p__0); var map__1740000771__5 any; if
												lang.ISeq_InstanceOf(map__1740000771__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000771__4)) { map__1740000771__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000771__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000771__4)) { map__1740000771__5 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000771__4) } else { lang.PersistentArrayMap_Init(); map__1740000771__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000771__5 = map__1740000771__4 }; var p__6 any = map__1740000771__5; var op__7 any = /*line :1517:1*/lang.RT_Get_O_O__O(map__1740000771__5, A_arbace_spec_alpha_A_const_20); var ps__8 any = lang.RT_Get_O_O__O(map__1740000771__5, A_arbace_spec_alpha_A_const_346); var splice__9 any = lang.RT_Get_O_O__O(map__1740000771__5, A_arbace_spec_alpha_A_const_356); var prop__10 any; var tmp1 any = A_arbace_spec_alpha_add_ret_prop__1740000773_A_New_O_O_O_O(k__2, p__6, r__1, splice__9); var tmp2 *jrt.Class; var fncls__124 *jrt.Class = A_arbace_spec_alpha_add_ret_prop__1740000773_A_fn_class; _ = ps__8; if
												fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_spec_alpha_add_ret_prop__1740000773_A_fn_class = fncls__124d; tmp2 = fncls__124d } else { tmp2 = fncls__124 }; prop__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var G__1740000775__11_ any = op__7; switch


	lang.Util_Hash_O__I(G__1740000775__11_) >> 1 & 15 { case 0: if lang.Util_Equiv_O_O__Z(G__1740000775__11_, nil) { return r__1 }; case 1: if lang.Util_Equiv_O_O__Z(G__1740000775__11_, A_arbace_spec_alpha_A_const_345) { var ret__12 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_373.GetRawRoot__O()).Invoke_O__O(p__6)




		if lang.Util_Equiv_O_O__Z(ret__12, A_arbace_spec_alpha_A_const_369) { return r__1 } else { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()); var tmp4 any; if jrt.J2g_Truth(k__2) { tmp4 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, k__2, ret__12)) } else { tmp4 = ret__12 }; return tmp3.Invoke_O_O__O(r__1, tmp4) } }
//line :1521:1
	case 7: if lang.Util_Equiv_O_O__Z(G__1740000775__11_, A_arbace_spec_alpha_A_const_361) { var ret__12_2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_373.GetRawRoot__O()).Invoke_O__O(p__6)




		if lang.Util_Equiv_O_O__Z(ret__12_2, A_arbace_spec_alpha_A_const_369) { return r__1 } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()); var tmp6 any; if jrt.J2g_Truth(k__2) { tmp6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, k__2, ret__12_2)) } else { tmp6 = ret__12_2 }; return tmp5.Invoke_O_O__O(r__1, tmp6) } }
//line :1521:1
	case 9: if lang.Util_Equiv_O_O__Z(G__1740000775__11_, A_arbace_spec_alpha_A_const_354) {






		return lang.IFn_Cast(prop__10).Invoke__O() }
//line :1521:1
	case 12: if lang.Util_Equiv_O_O__Z(G__1740000775__11_, A_arbace_spec_alpha_A_const_353) {






		return lang.IFn_Cast(prop__10).Invoke__O() }
//line :1521:1
	case 14: if lang.Util_Equiv_O_O__Z(G__1740000775__11_, A_arbace_spec_alpha_A_const_365) { var ret__12_3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_373.GetRawRoot__O()).Invoke_O__O(p__6)




		if lang.Util_Equiv_O_O__Z(ret__12_3, A_arbace_spec_alpha_A_const_369) { return r__1 } else { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()); var tmp8 any; if jrt.J2g_Truth(k__2) { tmp8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, k__2, ret__12_3)) } else { tmp8 = ret__12_3 }; return tmp7.Invoke_O_O__O(r__1, tmp8) } }
//line :1521:1
	default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1740000775__11_))))) }
//line :1518:1
func A_arbace_spec_alpha_add_ret_prop__1740000773_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_alpha_add_ret_prop__1740000773_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_add_ret_prop__1740000773_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1518:1
func (t *A_arbace_spec_alpha_add_ret_prop__1740000773_A) Ctor_O_O_O_O(c__k, c__p, c__r, c__splice any) { t.F_k = c__k; t.F_p = c__p; t.F_r = c__r; t.F_splice = c__splice }
//line :1518:1
func (t *A_arbace_spec_alpha_add_ret_prop__1740000773_A) Invoke_O__O(self any) any { var ret__1 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_373.GetRawRoot__O()).Invoke_O__O(t.F_p); if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(ret__1)) { return t.F_r } else { var tmp1 any; if jrt.J2g_Truth(t.F_splice) { tmp1 = A_arbace_spec_alpha_A_const_146.GetRawRoot__O() } else { tmp1 = A_arbace_spec_alpha_A_const_10.GetRawRoot__O() }; var tmp2 lang.IFn = lang.IFn_Cast(tmp1); var tmp3 any = t.F_r; var tmp4 any; if jrt.J2g_Truth(t.F_k) { tmp4 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, t.F_k, ret__1)) } else { tmp4 = ret__1 }; return tmp2.Invoke_O_O__O(tmp3, tmp4) } }









func A_arbace_spec_alpha_deriv_A_New() *A_arbace_spec_alpha_deriv_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_deriv_A{}; t.Ctor(); return t }
//line :1530:1
func (t *A_arbace_spec_alpha_deriv_A) Ctor() {}
//line :1530:1
func (t *A_arbace_spec_alpha_deriv_A) Invoke_O_O_O__O(self, p__0, x__1 any) any { var map__1740000778__3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_35.GetRawRoot__O()).Invoke_O__O(p__0); var map__1740000778__4 any; if

	lang.ISeq_InstanceOf(map__1740000778__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000778__3)) { map__1740000778__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000778__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000778__3)) { map__1740000778__4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000778__3) } else { lang.PersistentArrayMap_Init(); map__1740000778__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000778__4 = map__1740000778__3 }; var p__5 any = map__1740000778__4; var vec__1740000780__6 any = /*line :1530:1*/lang.RT_Get_O_O__O(map__1740000778__4, A_arbace_spec_alpha_A_const_346); var seq__1740000781__7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000780__6); var first__1740000782__8 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000781__7); var seq__1740000781__9 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000781__7); var p0__10 any = first__1740000782__8; var pr__11 any = seq__1740000781__9; var ps__12 any = vec__1740000780__6; var vec__1740000783__13 any = lang.RT_Get_O_O__O(map__1740000778__4, A_arbace_spec_alpha_A_const_347); var seq__1740000784__14 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000783__13); var first__1740000785__15 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000784__14); var seq__1740000784__16 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000784__14); var k0__17 any = first__1740000785__15; var kr__18 any = seq__1740000784__16; var ks__19 any = vec__1740000783__13; var op__20 any = lang.RT_Get_O_O__O(map__1740000778__4, A_arbace_spec_alpha_A_const_20); var p1__21 any = lang.RT_Get_O_O__O(map__1740000778__4, A_arbace_spec_alpha_A_const_358); var p2__22 any = lang.RT_Get_O_O__O(map__1740000778__4, A_arbace_spec_alpha_A_const_355); var ret__23 any = lang.RT_Get_O_O__O(map__1740000778__4, A_arbace_spec_alpha_A_const_237); var splice__24 any = lang.RT_Get_O_O__O(map__1740000778__4, A_arbace_spec_alpha_A_const_356); var forms__25 any = lang.RT_Get_O_O__O(map__1740000778__4, A_arbace_spec_alpha_A_const_348); var amp__26 any = lang.RT_Get_O_O__O(map__1740000778__4, A_arbace_spec_alpha_A_const_362); if


	jrt.J2g_Truth(p__5) { var G__1740000786__27_ any = op__20
		switch lang.Util_Hash_O__I(G__1740000786__27_) >> 1 & 15 { case 0: if lang.Util_Equiv_O_O__Z(G__1740000786__27_, nil) { var ret__28 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_254.GetRawRoot__O()).Invoke_O_O_O__O(p__5, x__1, p__5)


			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(ret__28)) { return nil } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_352.GetRawRoot__O()).Invoke_O__O(ret__28) } }
//line :1534:1
		case 1: if lang.Util_Equiv_O_O__Z(G__1740000786__27_, A_arbace_spec_alpha_A_const_345) { return nil }; case 7: if lang.Util_Equiv_O_O__Z(G__1740000786__27_, A_arbace_spec_alpha_A_const_361) { var temp__1927000414__auto____28 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_377.GetRawRoot__O()).Invoke_O_O__O(p1__21, x__1)



			if jrt.J2g_Truth(temp__1927000414__auto____28) { var p1__29 any = temp__1927000414__auto____28; var tmp1 any = A_arbace_spec_alpha_A_const_345
				if lang.Util_Equiv_O_O__Z(tmp1, A_arbace_spec_alpha_A_const_20.Invoke_O__O(p1__29)) { var ret__30 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_372.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_373.GetRawRoot__O()).Invoke_O__O(p1__29), ps__12, lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(forms__25))

					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(ret__30)) { return nil } else {
						return lang.IFn_Cast(A_arbace_spec_alpha_A_const_352.GetRawRoot__O()).Invoke_O__O(ret__30) } } else {
							return lang.IFn_Cast(A_arbace_spec_alpha_A_const_378.GetRawRoot__O()).Invoke_O_O_O_O__O(p1__29, amp__26, ps__12, forms__25) } } else {
//line :1538:1
								return nil } }
//line :1534:1
		case 9: if lang.Util_Equiv_O_O__Z(G__1740000786__27_, A_arbace_spec_alpha_A_const_354) {












			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_379.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_359.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_377.GetRawRoot__O()).Invoke_O_O__O(p1__21, x__1), p2__22, ret__23, splice__24, forms__25); var tmp4 any
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_371.GetRawRoot__O()).Invoke_O__O(p1__21)) { tmp4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_377.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_359.GetRawRoot__O()).Invoke_O_O_O_O_O__O(p2__22, p2__22, lang.IFn_Cast(A_arbace_spec_alpha_A_const_375.GetRawRoot__O()).Invoke_O_O_O__O(p1__21, ret__23, nil), splice__24, forms__25), x__1) } else { tmp4 = nil }
//line :1547:1
			return tmp2.Invoke_O_O__O(tmp3, tmp4) }
//line :1534:1
		case 12: if lang.Util_Equiv_O_O__Z(G__1740000786__27_, A_arbace_spec_alpha_A_const_353) {









			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_379.GetRawRoot__O()); var tmp6 any = A_arbace_spec_alpha_A_const_346; var tmp7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_351.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, lang.IFn_Cast(A_arbace_spec_alpha_A_const_268.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_377.GetRawRoot__O()).Invoke_O_O__O(p0__10, x__1), pr__11), A_arbace_spec_alpha_A_const_347, ks__19, A_arbace_spec_alpha_A_const_348, forms__25, A_arbace_spec_alpha_A_const_237, ret__23))); var tmp8 any
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_371.GetRawRoot__O()).Invoke_O__O(p0__10)) { var tmp9 any = A_arbace_spec_alpha_A_const_346; var tmp10 any = A_arbace_spec_alpha_A_const_347; var tmp11 any = A_arbace_spec_alpha_A_const_348; var tmp12 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(forms__25); var tmp13 any = A_arbace_spec_alpha_A_const_237; tmp8 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_377.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_351.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, pr__11, tmp10, kr__18, tmp11, tmp12, tmp13, lang.IFn_Cast(A_arbace_spec_alpha_A_const_375.GetRawRoot__O()).Invoke_O_O_O__O(p0__10, ret__23, k0__17)))), x__1) } else { tmp8 = nil }
//line :1544:1
			return tmp5.Invoke_O_O__O(tmp7, tmp8) }
//line :1534:1
		case 14: if lang.Util_Equiv_O_O__Z(G__1740000786__27_, A_arbace_spec_alpha_A_const_365) {











			var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_366.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()); var tmp16 any = A_arbace_spec_alpha_deriv_fn__1740000787_A_New_O(x__1); var tmp17 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_spec_alpha_deriv_fn__1740000787_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_spec_alpha_deriv_fn__1740000787_A_fn_class = fncls__127d; tmp17 = fncls__127d } else { tmp17 = fncls__127 }; return tmp14.Invoke_O_O_O__O(tmp15.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil), ps__12), ks__19, forms__25) }
//line :1534:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1740000786__27_))))) } else {
//line :1533:1
			return nil } }












func A_arbace_spec_alpha_deriv_fn__1740000787_A_New_O(p0 any) *A_arbace_spec_alpha_deriv_fn__1740000787_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_deriv_fn__1740000787_A{}; t.Ctor_O(p0); return t }
//line :1546:1
func (t *A_arbace_spec_alpha_deriv_fn__1740000787_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :1546:1
func (t *A_arbace_spec_alpha_deriv_fn__1740000787_A) Invoke_O_O__O(self, p1__1740000777_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_377.GetRawRoot__O()).Invoke_O_O__O(p1__1740000777_SHARP___1, t.F_x) }



func A_arbace_spec_alpha_op_describe_A_New() *A_arbace_spec_alpha_op_describe_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_op_describe_A{}; t.Ctor(); return t }
//line :1550:1
func (t *A_arbace_spec_alpha_op_describe_A) Ctor() {}
//line :1550:1
func (t *A_arbace_spec_alpha_op_describe_A) Invoke_O_O__O(self, p__0 any) any { var map__1740000790__2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_35.GetRawRoot__O()).Invoke_O__O(p__0); var map__1740000790__3 any; if
										lang.ISeq_InstanceOf(map__1740000790__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000790__2)) { map__1740000790__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000790__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000790__2)) { map__1740000790__3 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000790__2) } else { lang.PersistentArrayMap_Init(); map__1740000790__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000790__3 = map__1740000790__2 }; var p__4 any = map__1740000790__3; var op__5 any = /*line :1550:1*/lang.RT_Get_O_O__O(map__1740000790__3, A_arbace_spec_alpha_A_const_20); var ps__6 any = lang.RT_Get_O_O__O(map__1740000790__3, A_arbace_spec_alpha_A_const_346); var ks__7 any = lang.RT_Get_O_O__O(map__1740000790__3, A_arbace_spec_alpha_A_const_347); var forms__8 any = lang.RT_Get_O_O__O(map__1740000790__3, A_arbace_spec_alpha_A_const_348); var splice__9 any = lang.RT_Get_O_O__O(map__1740000790__3, A_arbace_spec_alpha_A_const_356); var p1__10 any = lang.RT_Get_O_O__O(map__1740000790__3, A_arbace_spec_alpha_A_const_358); var rep_PLUS___11 any = lang.RT_Get_O_O__O(map__1740000790__3, A_arbace_spec_alpha_A_const_349); var maybe__12 any = lang.RT_Get_O_O__O(map__1740000790__3, A_arbace_spec_alpha_A_const_368); var amp__13 any = lang.RT_Get_O_O__O(map__1740000790__3, A_arbace_spec_alpha_A_const_362); _ = ps__6; _ = p1__10; if


	jrt.J2g_Truth(p__4) { var G__1740000792__14_ any = op__5
		switch lang.Util_Hash_O__I(G__1740000792__14_) >> 1 & 15 { case 0: if lang.Util_Equiv_O_O__Z(G__1740000792__14_, nil) { return p__4 }; case 1: if lang.Util_Equiv_O_O__Z(G__1740000792__14_, A_arbace_spec_alpha_A_const_345) { return nil }; case 7: if lang.Util_Equiv_O_O__Z(G__1740000792__14_, A_arbace_spec_alpha_A_const_361) {


			return lang.IFn_Cast(A_arbace_spec_alpha_A_const_380.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_spec_alpha_A_const_381, amp__13, forms__8) }
//line :1554:1
		case 9: if lang.Util_Equiv_O_O__Z(G__1740000792__14_, A_arbace_spec_alpha_A_const_354) {









			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()); var tmp2 any; if jrt.J2g_Truth(splice__9) { tmp2 = A_arbace_spec_alpha_A_const_382 } else { tmp2 = A_arbace_spec_alpha_A_const_383 }; return tmp1.Invoke_O_O__O(tmp2, forms__8) }
//line :1554:1
		case 12: if lang.Util_Equiv_O_O__Z(G__1740000792__14_, A_arbace_spec_alpha_A_const_353) {



			if jrt.J2g_Truth(rep_PLUS___11) {
				return lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_384, rep_PLUS___11) } else {
					var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_268.GetRawRoot__O()); var tmp4 any = A_arbace_spec_alpha_A_const_385; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_179.GetRawRoot__O()); var tmp6 any = A_arbace_spec_alpha_A_const_159.GetRawRoot__O(); var tmp7 any; var or__1927000174__auto____15 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(ks__7); if jrt.J2g_Truth(or__1927000174__auto____15) { tmp7 = or__1927000174__auto____15 } else { tmp7 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_363.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_386) }; return tmp3.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O_O__O(tmp6, tmp7, forms__8)) } }
//line :1554:1
		case 14: if lang.Util_Equiv_O_O__Z(G__1740000792__14_, A_arbace_spec_alpha_A_const_365) {






			if jrt.J2g_Truth(maybe__12) {
				return lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_387, maybe__12) } else {
					var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_268.GetRawRoot__O()); var tmp9 any = A_arbace_spec_alpha_A_const_388; return tmp8.Invoke_O_O__O(tmp9, lang.IFn_Cast(A_arbace_spec_alpha_A_const_179.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), ks__7, forms__8)) } }
//line :1554:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1740000792__14_))))) } else {
//line :1553:1
			return nil } }












func A_arbace_spec_alpha_op_explain_A_New() *A_arbace_spec_alpha_op_explain_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_op_explain_A{}; t.Ctor(); return t }
//line :1566:1
func (t *A_arbace_spec_alpha_op_explain_A) Ctor() {}
//line :1566:1
func (t *A_arbace_spec_alpha_op_explain_A) Invoke_O_O_O_O_O_O_O__O(self, form__0, p__1, path__2, via__3, in__4, input__5 any) any { var vec__1740000794__7 any = input__5; var x__8 any = lang.RT_Nth_O_I_O__O(vec__1740000794__7, lang.RT_IntCast_J__I(0), nil); var input__9 any = vec__1740000794__7; var map__1740000797__10 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_35.GetRawRoot__O()).Invoke_O__O(p__1); var map__1740000797__11 any; if

	lang.ISeq_InstanceOf(map__1740000797__10) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000797__10)) { map__1740000797__11 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000797__10), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000797__10)) { map__1740000797__11 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000797__10) } else { lang.PersistentArrayMap_Init(); map__1740000797__11 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000797__11 = map__1740000797__10 }; var p__12 any = map__1740000797__11; var op__13 any = /*line :1566:1*/lang.RT_Get_O_O__O(map__1740000797__11, A_arbace_spec_alpha_A_const_20); var ps__14 any = lang.RT_Get_O_O__O(map__1740000797__11, A_arbace_spec_alpha_A_const_346); var ks__15 any = lang.RT_Get_O_O__O(map__1740000797__11, A_arbace_spec_alpha_A_const_347); var forms__16 any = lang.RT_Get_O_O__O(map__1740000797__11, A_arbace_spec_alpha_A_const_348); var splice__17 any = lang.RT_Get_O_O__O(map__1740000797__11, A_arbace_spec_alpha_A_const_356); var p1__18 any = lang.RT_Get_O_O__O(map__1740000797__11, A_arbace_spec_alpha_A_const_358); var p2__19 any = lang.RT_Get_O_O__O(map__1740000797__11, A_arbace_spec_alpha_A_const_355); var via__20 any; var temp__1927000408__auto____20 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_28.GetRawRoot__O()).Invoke_O__O(p__12); _ = splice__17; if



	jrt.J2g_Truth(temp__1927000408__auto____20) { var name__21 any = temp__1927000408__auto____20; via__20 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(via__3, name__21) } else { via__20 = via__3 }; var insufficient__21 any; var tmp1 any = /*line :1566:1*/A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_New_O_O(in__4, via__20); var tmp2 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_fn_class; if




	fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_113, false); A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_fn_class = fncls__129d; tmp2 = fncls__129d } else { tmp2 = fncls__129 }; insufficient__21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if






	jrt.J2g_Truth(p__12) { var G__1740000801__22_ any = op__13
		switch lang.Util_Hash_O__I(G__1740000801__22_) >> 1 & 15 { case 0: if lang.Util_Equiv_O_O__Z(G__1740000801__22_, nil) {

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(input__9)) {
				return lang.IFn_Cast(insufficient__21).Invoke_O_O__O(path__2, form__0) } else {
					return lang.IFn_Cast(A_arbace_spec_alpha_A_const_282.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(form__0, p__12, path__2, via__20, in__4, x__8) } }
//line :1579:1
		case 1: if lang.Util_Equiv_O_O__Z(G__1740000801__22_, A_arbace_spec_alpha_A_const_345) { return nil }; case 7: if lang.Util_Equiv_O_O__Z(G__1740000801__22_, A_arbace_spec_alpha_A_const_361) {




			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(input__9)) {
				if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_371.GetRawRoot__O()).Invoke_O__O(p1__18)) {
					return lang.IFn_Cast(A_arbace_spec_alpha_A_const_307.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(forms__16, ps__14, path__2, via__20, in__4, lang.IFn_Cast(A_arbace_spec_alpha_A_const_373.GetRawRoot__O()).Invoke_O__O(p1__18)) } else {
						return lang.IFn_Cast(insufficient__21).Invoke_O_O__O(path__2, A_arbace_spec_alpha_A_const_362.Invoke_O__O(p__12)) } } else {
//line :1584:1
							var temp__1927000408__auto____23 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_377.GetRawRoot__O()).Invoke_O_O__O(p1__18, x__8)



							if jrt.J2g_Truth(temp__1927000408__auto____23) { var p1__24 any = temp__1927000408__auto____23
								return lang.IFn_Cast(A_arbace_spec_alpha_A_const_307.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(forms__16, ps__14, path__2, via__20, in__4, lang.IFn_Cast(A_arbace_spec_alpha_A_const_373.GetRawRoot__O()).Invoke_O__O(p1__24)) } else {
									return lang.IFn_Cast(A_arbace_spec_alpha_A_const_389.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_spec_alpha_A_const_362.Invoke_O__O(p__12), p1__18, path__2, via__20, in__4, input__9) } } }
//line :1579:1
		case 9: if lang.Util_Equiv_O_O__Z(G__1740000801__22_, A_arbace_spec_alpha_A_const_354) {




































			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_389.GetRawRoot__O()); var tmp4 any; if lang.Util_Identical_O_O__Z(p1__18, p2__19) { tmp4 = forms__16 } else {

				tmp4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_390.GetRawRoot__O()).Invoke_O__O(p1__18) }
//line :1616:1
			return tmp3.Invoke_O_O_O_O_O_O__O(tmp4, p1__18, path__2, via__20, in__4, input__9) }
//line :1579:1
		case 12: if lang.Util_Equiv_O_O__Z(G__1740000801__22_, A_arbace_spec_alpha_A_const_353) { var pkfs__23 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()); var tmp6 any = A_arbace_spec_alpha_A_const_159.GetRawRoot__O(); var tmp7 any; var or__1927000174__auto____23 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(ks__15)













			if jrt.J2g_Truth(or__1927000174__auto____23) { tmp7 = or__1927000174__auto____23 } else { tmp7 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_363.GetRawRoot__O()).Invoke_O__O(nil) }
//line :1591:1
			var tmp8 any = tmp7; var tmp9 any; var or__1927000174__auto____23_2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(forms__16)


			if jrt.J2g_Truth(or__1927000174__auto____23_2) { tmp9 = or__1927000174__auto____23_2 } else { tmp9 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_363.GetRawRoot__O()).Invoke_O__O(nil) }
//line :1591:1
			pkfs__23 = tmp5.Invoke_O_O_O_O__O(tmp6, ps__14, tmp8, tmp9)
//line :1579:1
			var vec__1740000802__24 any















			if lang.Util_Equiv_J_J__Z(1, int64(lang.RT_Count_O__I(pkfs__23))) {
				vec__1740000802__24 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(pkfs__23) } else {
					var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_274.GetRawRoot__O()); var tmp12 any = A_arbace_spec_alpha_op_explain_fn__1740000806_A_New(); var tmp13 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_spec_alpha_op_explain_fn__1740000806_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_114, false); A_arbace_spec_alpha_op_explain_fn__1740000806_A_fn_class = fncls__131d; tmp13 = fncls__131d } else { tmp13 = fncls__131 }; vec__1740000802__24 = tmp10.Invoke_O__O(tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), pkfs__23)) }
//line :1579:1
			var pred__25 any = lang.RT_Nth_O_I_O__O(vec__1740000802__24, lang.RT_IntCast_J__I(0), nil); var k__26 any = lang.RT_Nth_O_I_O__O(vec__1740000802__24, lang.RT_IntCast_J__I(1), nil); var form__27 any = lang.RT_Nth_O_I_O__O(vec__1740000802__24, lang.RT_IntCast_J__I(2), nil); var path__28 any


















			if jrt.J2g_Truth(k__26) { path__28 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(path__2, k__26) } else { path__28 = path__2 }
//line :1579:1
			var form__29 any
			var or__1927000174__auto____29 any = form__27


















			if jrt.J2g_Truth(or__1927000174__auto____29) { form__29 = or__1927000174__auto____29 } else { form__29 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_390.GetRawRoot__O()).Invoke_O__O(pred__25) }
			var tmp14 any; var and__1927000168__auto____30 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(input__9); if jrt.J2g_Truth(and__1927000168__auto____30) { tmp14 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(pred__25) } else { tmp14 = and__1927000168__auto____30 }; if jrt.J2g_Truth(tmp14) {
				return lang.IFn_Cast(insufficient__21).Invoke_O_O__O(path__28, form__29) } else {
					return lang.IFn_Cast(A_arbace_spec_alpha_A_const_389.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(form__29, pred__25, path__28, via__20, in__4, input__9) } }
//line :1579:1
		case 14: if lang.Util_Equiv_O_O__Z(G__1740000801__22_, A_arbace_spec_alpha_A_const_365) {























			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(input__9)) {
				return lang.IFn_Cast(insufficient__21).Invoke_O_O__O(path__2, lang.IFn_Cast(A_arbace_spec_alpha_A_const_390.GetRawRoot__O()).Invoke_O__O(p__12)) } else {
					var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()); var tmp16 any = A_arbace_spec_alpha_A_const_130.GetRawRoot__O(); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()); var tmp18 any = A_arbace_spec_alpha_op_explain_fn__1740000811_A_New_O_O_O_O(in__4, input__9, path__2, via__20); var tmp19 *jrt.Class; var fncls__132 *jrt.Class = A_arbace_spec_alpha_op_explain_fn__1740000811_A_fn_class
					if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_115, false); A_arbace_spec_alpha_op_explain_fn__1740000811_A_fn_class = fncls__132d; tmp19 = fncls__132d } else { tmp19 = fncls__132 }
//line :1605:1
					var tmp20 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var tmp21 any; var or__1927000174__auto____23_3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(ks__15)







					if jrt.J2g_Truth(or__1927000174__auto____23_3) { tmp21 = or__1927000174__auto____23_3 } else { tmp21 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_363.GetRawRoot__O()).Invoke_O__O(nil) }
//line :1605:1
					var tmp22 any = tmp21; var tmp23 any; var or__1927000174__auto____23_4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(forms__16)








					if jrt.J2g_Truth(or__1927000174__auto____23_4) { tmp23 = or__1927000174__auto____23_4 } else { tmp23 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_363.GetRawRoot__O()).Invoke_O__O(nil) }
//line :1605:1
					return tmp15.Invoke_O_O__O(tmp16, tmp17.Invoke_O_O_O_O__O(tmp20, tmp22, tmp23, ps__14)) } }
//line :1579:1
		default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1740000801__22_))))) } else {
//line :1578:1
			return nil } }
//line :1571:1
func A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_op_explain_insufficient__1740000799_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_op_explain_insufficient__1740000799_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1571:1
func (t *A_arbace_spec_alpha_op_explain_insufficient__1740000799_A) Ctor_O_O(c__in, c__via any) { t.F_in = c__in; t.F_via = c__via }
//line :1571:1
func (t *A_arbace_spec_alpha_op_explain_insufficient__1740000799_A) Invoke_O_O_O__O(self, path__1, form__2 any) any { var tmp1 any = A_arbace_spec_alpha_A_const_72; var tmp2 any = A_arbace_spec_alpha_A_const_75; var tmp3 any = A_arbace_spec_alpha_A_const_73; var tmp4 any = A_arbace_spec_alpha_A_const_74; var tmp5 *lang.PersistentList_EmptyList; lang.PersistentList_Init(); tmp5 = lang.PersistentList_EMPTY; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, path__1, tmp2, Lit_116, tmp3, form__2, tmp4, tmp5.Ref(), A_arbace_spec_alpha_A_const_76, t.F_via, A_arbace_spec_alpha_A_const_77, t.F_in))) }

























func A_arbace_spec_alpha_op_explain_fn__1740000806_A_New() *A_arbace_spec_alpha_op_explain_fn__1740000806_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_op_explain_fn__1740000806_A{}; t.Ctor(); return t }
//line :1597:1
func (t *A_arbace_spec_alpha_op_explain_fn__1740000806_A) Ctor() {}
//line :1597:1
func (t *A_arbace_spec_alpha_op_explain_fn__1740000806_A) Invoke_O_O__O(self, p__1740000805__1 any) any { var vec__1740000807__2 any = p__1740000805__1; var p__3 any = lang.RT_Nth_O_I_O__O(vec__1740000807__2, lang.RT_IntCast_J__I(0), nil); return lang.IFn_Cast(A_arbace_spec_alpha_A_const_371.GetRawRoot__O()).Invoke_O__O(p__3) }








func A_arbace_spec_alpha_op_explain_fn__1740000811_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_alpha_op_explain_fn__1740000811_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_op_explain_fn__1740000811_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1606:1
func (t *A_arbace_spec_alpha_op_explain_fn__1740000811_A) Ctor_O_O_O_O(c__in, c__input, c__path, c__via any) { t.F_in = c__in; t.F_input = c__input; t.F_path = c__path; t.F_via = c__via }
//line :1606:1
func (t *A_arbace_spec_alpha_op_explain_fn__1740000811_A) Invoke_O_O_O_O__O(self, k__1, form__2, pred__3 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_389.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____4 any = form__2; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp2 = or__1927000174__auto____4 } else { tmp2 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_390.GetRawRoot__O()).Invoke_O__O(pred__3) }; var tmp3 any = tmp2; var tmp4 any

	if jrt.J2g_Truth(k__1) { tmp4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(t.F_path, k__1) } else { tmp4 = t.F_path }
//line :1607:1
	return tmp1.Invoke_O_O_O_O_O_O__O(tmp3, pred__3, tmp4, t.F_via, t.F_in, t.F_input)
}












func A_arbace_spec_alpha_re_gen_A_New() *A_arbace_spec_alpha_re_gen_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_re_gen_A{}; t.Ctor(); return t }
//line :1621:1
func (t *A_arbace_spec_alpha_re_gen_A) Ctor() {}
//line :1621:1
func (t *A_arbace_spec_alpha_re_gen_A) Invoke_O_O_O_O_O_O__O(self, p__0, overrides__1, path__2, rmap__3, f__4 any) any { var origp__6 any = p__0; var map__1740000815__7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_35.GetRawRoot__O()).Invoke_O__O(p__0); var map__1740000815__8 any; if

	lang.ISeq_InstanceOf(map__1740000815__7) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000815__7)) { map__1740000815__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000815__7), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000815__7)) { map__1740000815__8 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000815__7) } else { lang.PersistentArrayMap_Init(); map__1740000815__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000815__8 = map__1740000815__7 }; var p__9 any = map__1740000815__8; var op__10 any = /*line :1621:1*/lang.RT_Get_O_O__O(map__1740000815__8, A_arbace_spec_alpha_A_const_20); var ps__11 any = lang.RT_Get_O_O__O(map__1740000815__8, A_arbace_spec_alpha_A_const_346); var ks__12 any = lang.RT_Get_O_O__O(map__1740000815__8, A_arbace_spec_alpha_A_const_347); var p1__13 any = lang.RT_Get_O_O__O(map__1740000815__8, A_arbace_spec_alpha_A_const_358); var p2__14 any = lang.RT_Get_O_O__O(map__1740000815__8, A_arbace_spec_alpha_A_const_355); var forms__15 any = lang.RT_Get_O_O__O(map__1740000815__8, A_arbace_spec_alpha_A_const_348); var splice__16 any = lang.RT_Get_O_O__O(map__1740000815__8, A_arbace_spec_alpha_A_const_356); var ret__17 any = lang.RT_Get_O_O__O(map__1740000815__8, A_arbace_spec_alpha_A_const_237); var id__18 any = lang.RT_Get_O_O__O(map__1740000815__8, A_arbace_spec_alpha_A_const_357); var gfn__19 any = lang.RT_Get_O_O__O(map__1740000815__8, A_arbace_spec_alpha_A_const_61); var rmap__20 any; _ = splice__16; if



	jrt.J2g_Truth(id__18) { rmap__20 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_271.GetRawRoot__O()).Invoke_O_O__O(rmap__3, id__18) } else { rmap__20 = rmap__3 }; var ggens__21 any; var tmp1 any = /*line :1621:1*/A_arbace_spec_alpha_re_gen_ggens__1740000817_A_New_O_O_O_O(path__2, overrides__1, id__18, rmap__20); var tmp2 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_spec_alpha_re_gen_ggens__1740000817_A_fn_class; if




	fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_131, false); A_arbace_spec_alpha_re_gen_ggens__1740000817_A_fn_class = fncls__135d; tmp2 = fncls__135d } else { tmp2 = fncls__135 }; ggens__21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var or__1927000174__auto____22 any; var temp__1927000414__auto____22 any; var or__1927000174__auto____22_2 any = /*line :1621:1*/lang.RT_Get_O_O__O(overrides__1, lang.IFn_Cast(A_arbace_spec_alpha_A_const_28.GetRawRoot__O()).Invoke_O__O(origp__6)); if












	jrt.J2g_Truth(or__1927000174__auto____22_2) { temp__1927000414__auto____22 = or__1927000174__auto____22_2 } else { var or__1927000174__auto____23 any = lang.RT_Get_O_O__O(overrides__1, lang.IFn_Cast(A_arbace_spec_alpha_A_const_28.GetRawRoot__O()).Invoke_O__O(p__9)); if jrt.J2g_Truth(or__1927000174__auto____23) { temp__1927000414__auto____22 = or__1927000174__auto____23 } else {

		temp__1927000414__auto____22 = lang.RT_Get_O_O__O(overrides__1, path__2) } }; if /*line :1634:1*/ jrt.J2g_Truth(temp__1927000414__auto____22) { var gfn__23 any = temp__1927000414__auto____22
			var G__1740000823__24_ any = op__10

		L1: switch { default: switch lang.Util_Hash_O__I(G__1740000823__24_) >> 2 & 1 { case 0: if lang.Util_Equiv_O_O__Z(G__1740000823__24_, nil) {
			or__1927000174__auto____22 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_289.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(gfn__23).Invoke__O())
//line :1637:1
			break L1 }; case 1: if lang.Util_Equiv_O_O__Z(G__1740000823__24_, A_arbace_spec_alpha_A_const_392) {
				or__1927000174__auto____22 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_289.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(gfn__23).Invoke__O())
//line :1637:1
				break L1 }; default:
		}
			or__1927000174__auto____22 = lang.IFn_Cast(gfn__23).Invoke__O()} } else {
//line :1634:1
				or__1927000174__auto____22 = nil }; if jrt.J2g_Truth(or__1927000174__auto____22) { return or__1927000174__auto____22 } else { var or__1927000174__auto____23_2 any





					if jrt.J2g_Truth(gfn__19) {
						or__1927000174__auto____23_2 = lang.IFn_Cast(gfn__19).Invoke__O() } else {
//line :1640:1
							or__1927000174__auto____23_2 = nil }
//line :1634:1
					if jrt.J2g_Truth(or__1927000174__auto____23_2) { return or__1927000174__auto____23_2 } else {







						if jrt.J2g_Truth(p__9) { var G__1740000824__24_ any = op__10
							switch lang.Util_Hash_O__I(G__1740000824__24_) >> 1 & 15 { case 0: if lang.Util_Equiv_O_O__Z(G__1740000824__24_, nil) { var temp__1927000414__auto____25 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_108.GetRawRoot__O()).Invoke_O_O_O_O_O__O(p__9, overrides__1, path__2, rmap__20, f__4)



								if jrt.J2g_Truth(temp__1927000414__auto____25) { var g__26 any = temp__1927000414__auto____25
									return lang.IFn_Cast(A_arbace_spec_alpha_A_const_289.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), g__26) } else {
//line :1647:1
										return nil } }
//line :1643:1
							case 1: if lang.Util_Equiv_O_O__Z(G__1740000824__24_, A_arbace_spec_alpha_A_const_345) {
								if lang.Util_Equiv_O_O__Z(ret__17, A_arbace_spec_alpha_A_const_369) {
									var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_255.GetRawRoot__O()); var tmp4 *lang.PersistentVector; lang.PersistentVector_Init(); tmp4 = lang.PersistentVector_EMPTY; return tmp3.Invoke_O__O(tmp4.Ref()) } else {
										return lang.IFn_Cast(A_arbace_spec_alpha_A_const_255.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O__IPersistentVector(ret__17)) } }
//line :1643:1
							case 7: if lang.Util_Equiv_O_O__Z(G__1740000824__24_, A_arbace_spec_alpha_A_const_361) {





								return lang.IFn_Cast(A_arbace_spec_alpha_A_const_391.GetRawRoot__O()).Invoke_O_O_O_O_O__O(p1__13, overrides__1, path__2, rmap__20, lang.IFn_Cast(A_arbace_spec_alpha_A_const_390.GetRawRoot__O()).Invoke_O__O(p1__13)) }
//line :1643:1
							case 9: if lang.Util_Equiv_O_O__Z(G__1740000824__24_, A_arbace_spec_alpha_A_const_354) {












								if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_272.GetRawRoot__O()).Invoke_O_O_O_O__O(rmap__20, id__18, lang.Tuple_Create_O__IPersistentVector(id__18), id__18)) {
									var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_255.GetRawRoot__O()); var tmp6 *lang.PersistentVector; lang.PersistentVector_Init(); tmp6 = lang.PersistentVector_EMPTY; return tmp5.Invoke_O__O(tmp6.Ref()) } else {
//line :1656:1
										var temp__1927000414__auto____25_2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_391.GetRawRoot__O()).Invoke_O_O_O_O_O__O(p2__14, overrides__1, path__2, rmap__20, forms__15)

										if jrt.J2g_Truth(temp__1927000414__auto____25_2) { var g__26_2 any = temp__1927000414__auto____25_2; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_289.GetRawRoot__O()); var tmp8 any = A_arbace_spec_alpha_re_gen_fn__1740000825_A_New(); var tmp9 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_spec_alpha_re_gen_fn__1740000825_A_fn_class
											if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_132, false); A_arbace_spec_alpha_re_gen_fn__1740000825_A_fn_class = fncls__138d; tmp9 = fncls__138d } else { tmp9 = fncls__138 }; return tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), lang.IFn_Cast(A_arbace_spec_alpha_A_const_335.GetRawRoot__O()).Invoke_O__O(g__26_2)) } else {
//line :1658:1
												return nil } } }
//line :1643:1
							case 12: if lang.Util_Equiv_O_O__Z(G__1740000824__24_, A_arbace_spec_alpha_A_const_353) { var gens__25 any = lang.IFn_Cast(ggens__21).Invoke_O_O_O__O(ps__11, ks__12, forms__15)







								if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_145.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_156.GetRawRoot__O(), gens__25)) {
									return lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_393.GetRawRoot__O(), gens__25) } else {
//line :1651:1
										return nil } }
//line :1643:1
							case 14: if lang.Util_Equiv_O_O__Z(G__1740000824__24_, A_arbace_spec_alpha_A_const_365) { var gens__25_2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_274.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_275.GetRawRoot__O(), lang.IFn_Cast(ggens__21).Invoke_O_O_O__O(ps__11, ks__12, forms__15))










								if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(gens__25_2)) { return nil } else {
									return lang.IFn_Cast(A_arbace_spec_alpha_A_const_291.GetRawRoot__O()).Invoke_O__O(gens__25_2) } }
//line :1643:1
							default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1740000824__24_))))) } else {
//line :1642:1
								return nil } } } }
//line :1626:1
func A_arbace_spec_alpha_re_gen_ggens__1740000817_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_alpha_re_gen_ggens__1740000817_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_re_gen_ggens__1740000817_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1626:1
func (t *A_arbace_spec_alpha_re_gen_ggens__1740000817_A) Ctor_O_O_O_O(c__path, c__overrides, c__id, c__rmap any) { t.F_path = c__path; t.F_overrides = c__overrides; t.F_id = c__id; t.F_rmap = c__rmap }
//line :1626:1
func (t *A_arbace_spec_alpha_re_gen_ggens__1740000817_A) Invoke_O_O_O_O__O(self, ps__1, ks__2, forms__3 any) any { var gen__4 any; var tmp1 any = A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_New_O_O_O_O(t.F_path, t.F_overrides, t.F_id, t.F_rmap); var tmp2 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_fn_class; if
															fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_133, false); A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_fn_class = fncls__134d; tmp2 = fncls__134d } else { tmp2 = fncls__134 }; gen__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn =





	lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()); var tmp4 any; var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(ks__2); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp4 = or__1927000174__auto____5 } else { tmp4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_363.GetRawRoot__O()).Invoke_O__O(nil) }; var tmp5 any = tmp4; var tmp6 any; var or__1927000174__auto____5_2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(forms__3); if jrt.J2g_Truth(or__1927000174__auto____5_2) { tmp6 = or__1927000174__auto____5_2 } else { tmp6 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_363.GetRawRoot__O()).Invoke_O__O(nil) }; return tmp3.Invoke_O_O_O_O__O(gen__4, ps__1, tmp5, tmp6) }
//line :1627:1
func A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :1627:1
func (t *A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A) Ctor_O_O_O_O(c__path, c__overrides, c__id, c__rmap any) { t.F_path = c__path; t.F_overrides = c__overrides; t.F_id = c__id; t.F_rmap = c__rmap }
//line :1627:1
func (t *A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A) Invoke_O_O_O_O__O(self, p__1, k__2, f__3 any) any {

	var tmp1 any; var and__1927000168__auto____4 any = t.F_rmap; if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = t.F_id; if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = k__2; if jrt.J2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_272.GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_rmap, t.F_id, t.F_path, k__2) } else { tmp1 = and__1927000168__auto____6 } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { return nil } else {
		if jrt.J2g_Truth(t.F_id) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_273.GetRawRoot__O()); var tmp3 any = A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_New_O_O_O_O_O_O(t.F_path, f__3, t.F_overrides, k__2, p__1, t.F_rmap); var tmp4 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_134, false); A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_fn_class = fncls__133d; tmp4 = fncls__133d } else { tmp4 = fncls__133 }; return tmp2.Invoke_O__O(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil))) } else {
				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_391.GetRawRoot__O()); var tmp6 any = t.F_overrides; var tmp7 any; if jrt.J2g_Truth(k__2) { tmp7 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(t.F_path, k__2) } else { tmp7 = t.F_path }; var tmp8 any = tmp7; var tmp9 any = t.F_rmap; var tmp10 any; var or__1927000174__auto____4 any = f__3; if jrt.J2g_Truth(or__1927000174__auto____4) { tmp10 = or__1927000174__auto____4 } else { tmp10 = p__1 }; return tmp5.Invoke_O_O_O_O_O__O(p__1, tmp6, tmp8, tmp9, tmp10) } } }
//line :1631:1
func A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :1631:1
func (t *A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A) Ctor_O_O_O_O_O_O(c__path, c__f, c__overrides, c__k, c__p, c__rmap any) { t.F_path = c__path; t.F_f = c__f; t.F_overrides = c__overrides; t.F_k = c__k; t.F_p = c__p; t.F_rmap = c__rmap }
//line :1631:1
func (t *A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_391.GetRawRoot__O()); var tmp2 any = t.F_p; var tmp3 any; var t_ any = t.F_overrides; t.F_overrides = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; if jrt.J2g_Truth(t.F_k) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()); var tmp7 any; var t__2 any = t.F_path; t.F_path = nil; tmp7 = t__2; var tmp8 any = tmp7; var tmp9 any; var t__3 any = t.F_k; t.F_k = nil; tmp9 = t__3; tmp5 = tmp6.Invoke_O_O__O(tmp8, tmp9) } else { var t__4 any = t.F_path; t.F_path = nil; tmp5 = t__4 }; var tmp10 any = tmp5; var tmp11 any; var t__5 any = t.F_rmap; t.F_rmap = nil; tmp11 = t__5; var tmp12 any = tmp11; var tmp13 any; var or__1927000174__auto____1 any; var t__6 any = t.F_f; t.F_f = nil; or__1927000174__auto____1 = t__6; if jrt.J2g_Truth(or__1927000174__auto____1) { tmp13 = or__1927000174__auto____1 } else { var t__7 any = t.F_p; t.F_p = nil; tmp13 = t__7 }; return tmp1.Invoke_O_O_O_O_O__O(tmp2, tmp4, tmp10, tmp12, tmp13) }



























func A_arbace_spec_alpha_re_gen_fn__1740000825_A_New() *A_arbace_spec_alpha_re_gen_fn__1740000825_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_re_gen_fn__1740000825_A{}; t.Ctor(); return t }
//line :1659:1
func (t *A_arbace_spec_alpha_re_gen_fn__1740000825_A) Ctor() {}
//line :1659:1
func (t *A_arbace_spec_alpha_re_gen_fn__1740000825_A) Invoke_O_O__O(self, p1__1740000814_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_130.GetRawRoot__O(), p1__1740000814_SHARP___1) }


func A_arbace_spec_alpha_re_conform_A_New() *A_arbace_spec_alpha_re_conform_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_re_conform_A{}; t.Ctor(); return t }
//line :1662:1
func (t *A_arbace_spec_alpha_re_conform_A) Ctor() {}
//line :1662:1
func (t *A_arbace_spec_alpha_re_conform_A) Invoke_O_O_O__O(self, p__0, p__1740000828__1 any) any { { var p__0_2 any = p__0; var p__1740000828__1_2 any = p__1740000828__1; L1: for { var vec__1740000829__3 any = p__1740000828__1_2; var seq__1740000830__4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000829__3); var first__1740000831__5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000830__4); var seq__1740000830__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000830__4)
													var x__7 any = first__1740000831__5; var xs__8 any = seq__1740000830__6; var data__9 any = vec__1740000829__3
													if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(data__9)) {
														if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_371.GetRawRoot__O()).Invoke_O__O(p__0_2)) { var ret__10 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_373.GetRawRoot__O()).Invoke_O__O(p__0_2)

			if lang.Util_Equiv_O_O__Z(ret__10, A_arbace_spec_alpha_A_const_369) { return nil } else { return ret__10 } } else {
//line :1665:1
				return A_arbace_spec_alpha_A_const_42 } } else {
//line :1664:1
					var temp__1927000408__auto____10 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_377.GetRawRoot__O()).Invoke_O_O__O(p__0_2, x__7)






					if jrt.J2g_Truth(temp__1927000408__auto____10) { var dp__11 any = temp__1927000408__auto____10
						p__0_2, p__1740000828__1_2 = dp__11, xs__8; continue L1 } else {
//line :1671:1
							return A_arbace_spec_alpha_A_const_42 } } } }; /*line :1662:1*/panic("j2g: unreachable") }












func A_arbace_spec_alpha_re_explain_A_New() *A_arbace_spec_alpha_re_explain_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_re_explain_A{}; t.Ctor(); return t }
//line :1675:1
func (t *A_arbace_spec_alpha_re_explain_A) Ctor() {}
//line :1675:1
func (t *A_arbace_spec_alpha_re_explain_A) Invoke_O_O_O_O_O_O__O(self, path__0, via__1, in__2, re__3, input__4 any) any { { var p__6 any = re__3; var G__1740000836__7_ any = input__4; var vec__1740000837__8 any = G__1740000836__7_; var seq__1740000838__9 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000837__8); var first__1740000839__10 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000838__9); var seq__1740000838__11 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000838__9); var x__12 any = first__1740000839__10; var xs__13 any = seq__1740000838__11; var data__14 any = vec__1740000837__8; var i__15 int64 = 0; var p__16 any = p__6; var G__1740000836__17_ any = G__1740000836__7_; var i__18 int64 = i__15; _ = x__12; _ = xs__13; _ = data__14; L1: for { var p__19 any = p__16; var vec__1740000840__20 any = G__1740000836__17_; var seq__1740000841__21 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(vec__1740000840__20); var first__1740000842__22 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(seq__1740000841__21); var seq__1740000841__23 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(seq__1740000841__21)
															var x__24 any = first__1740000842__22
															var xs__25 any = seq__1740000841__23; var data__26 any = vec__1740000840__20; var i__27 int64 = i__18
															if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_63.GetRawRoot__O()).Invoke_O__O(data__26)) {
																if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_371.GetRawRoot__O()).Invoke_O__O(p__19)) { return nil } else {

			return lang.IFn_Cast(A_arbace_spec_alpha_A_const_389.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_390.GetRawRoot__O()).Invoke_O__O(p__19), p__19, path__0, via__1, in__2, nil) } } else {
//line :1678:1
				var temp__1927000408__auto____28 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_377.GetRawRoot__O()).Invoke_O_O__O(p__19, x__24)



				if jrt.J2g_Truth(temp__1927000408__auto____28) { var dp__29 any = temp__1927000408__auto____28
					p__16, G__1740000836__17_, i__18 = dp__29, xs__25, lang.Numbers_Inc_J__J(i__27); continue L1 } else {
						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_350.GetRawRoot__O()).Invoke_O__O(p__19)) {
							if lang.Util_Equiv_O_O__Z(A_arbace_spec_alpha_A_const_20.Invoke_O__O(p__19), A_arbace_spec_alpha_A_const_353) {
								return lang.IFn_Cast(A_arbace_spec_alpha_A_const_389.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_390.GetRawRoot__O()).Invoke_O__O(p__19), p__19, path__0, via__1, lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(in__2, jrt.Long_ValueOf_J__Long(i__27).Ref()), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(data__26)) } else {
//line :1685:1
									var tmp1 any = A_arbace_spec_alpha_A_const_72; var tmp2 any = A_arbace_spec_alpha_A_const_75; var tmp3 any = A_arbace_spec_alpha_A_const_73; var tmp4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_390.GetRawRoot__O()).Invoke_O__O(re__3); var tmp5 any = A_arbace_spec_alpha_A_const_74; var tmp6 any = A_arbace_spec_alpha_A_const_76; var tmp7 any = A_arbace_spec_alpha_A_const_77; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, path__0, tmp2, Lit_130, tmp3, tmp4, tmp5, data__26, tmp6, via__1, tmp7, lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(in__2, jrt.Long_ValueOf_J__Long(i__27).Ref())))) } } else {
//line :1684:1
										var or__1927000174__auto____29 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_389.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_390.GetRawRoot__O()).Invoke_O__O(p__19), p__19, path__0, via__1, lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(in__2, jrt.Long_ValueOf_J__Long(i__27).Ref()), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(data__26))








										if jrt.J2g_Truth(or__1927000174__auto____29) { return or__1927000174__auto____29 } else { var tmp8 any = A_arbace_spec_alpha_A_const_72; var tmp9 any = A_arbace_spec_alpha_A_const_75; var tmp10 any = A_arbace_spec_alpha_A_const_73; var tmp11 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_390.GetRawRoot__O()).Invoke_O__O(p__19); var tmp12 any = A_arbace_spec_alpha_A_const_74; var tmp13 any = A_arbace_spec_alpha_A_const_76; var tmp14 any = A_arbace_spec_alpha_A_const_77; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, path__0, tmp9, Lit_130, tmp10, tmp11, tmp12, data__26, tmp13, via__1, tmp14, lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()).Invoke_O_O__O(in__2, jrt.Long_ValueOf_J__Long(i__27).Ref())))) } } } } } }; /*line :1675:1*/panic("j2g: unreachable") }

























func A_arbace_spec_alpha_regex_spec_impl_A_New() *A_arbace_spec_alpha_regex_spec_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_regex_spec_impl_A{}; t.Ctor(); return t }
//line :1701:1
func (t *A_arbace_spec_alpha_regex_spec_impl_A) Ctor() {}
//line :1701:1
func (t *A_arbace_spec_alpha_regex_spec_impl_A) Invoke_O_O_O__O(self, re__0, gfn__1 any) any {


	return A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_New_IPersistentMap_O_O(nil, gfn__1, re__0) }
//line :1704:1
func A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_New_IPersistentMap_O_O(p0 lang.IPersistentMap, p1, p2 any) *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A { t := &A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A{}; t.Ctor_IPersistentMap_O_O(p0, p1, p2); return t }
//line :1704:1
func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Ctor_IPersistentMap_O_O(meta__ lang.IPersistentMap, c__gfn, c__re any) { t.F___meta = meta__; t.F_gfn = c__gfn; t.F_re = c__re }
//line :1704:1
func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Describe_STAR___O() any {



















	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_390; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_re) }
//line :1704:1
func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) With_gen_STAR__O__O(gfn__1 any) any {


















	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_27; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_re, gfn__1) }
//line :1704:1
func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Gen_STAR__O_O_O__O(overrides__1, path__2, rmap__3 any) any {















	if jrt.J2g_Truth(t.F_gfn) {
		return lang.IFn_Cast(t.F_gfn).Invoke__O() } else {
			var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_391; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = t.F_re; var tmp4 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_390; return tmp2.Invoke_O_O_O_O_O__O(tmp3, overrides__1, path__2, rmap__3, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(t.F_re)) } }
//line :1704:1
func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, x__4 any) any {











	var tmp1 any; var or__1927000174__auto____5 bool = lang.Util_Identical_O_O__Z(x__4, nil); if or__1927000174__auto____5 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var tmp2 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_120; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__4) }; if jrt.J2g_Truth(tmp1) {
		var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_394; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_re; var tmp6 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_69; return tmp4.Invoke_O_O_O_O_O__O(path__1, via__2, in__3, tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(x__4)) } else {
//line :1716:1
			var tmp7 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_72; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_73; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_122; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp13 = A_arbace_spec_alpha_A_const_69; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp15 = A_arbace_spec_alpha_A_const_130; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp17 = A_arbace_spec_alpha_A_const_131; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any; A_arbace_spec_alpha_A_Init(); tmp19 = A_arbace_spec_alpha_A_const_395; var tmp20 any = tmp18.Invoke_O__O(tmp19); var tmp21 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp21 = A_arbace_spec_alpha_A_const_131; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp23 = A_arbace_spec_alpha_A_const_158; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp25 = A_arbace_spec_alpha_A_const_159; var tmp26 any = jrt.NN(tmp25).GetRawRoot__O(); var tmp27 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp27 = A_arbace_spec_alpha_A_const_69; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp29 = A_arbace_spec_alpha_A_const_130; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp31 = A_arbace_spec_alpha_A_const_131; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any; A_arbace_spec_alpha_A_Init(); tmp33 = A_arbace_spec_alpha_A_const_396; var tmp34 any = tmp22.Invoke_O__O(tmp24.Invoke_O_O__O(tmp26, tmp28.Invoke_O__O(tmp30.Invoke_O__O(tmp32.Invoke_O__O(tmp33))))); var tmp35 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp35 = A_arbace_spec_alpha_A_const_131; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp37 = A_arbace_spec_alpha_A_const_69; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp39 = A_arbace_spec_alpha_A_const_130; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp41 = A_arbace_spec_alpha_A_const_131; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 any; A_arbace_spec_alpha_A_Init(); tmp43 = A_arbace_spec_alpha_A_const_397; var tmp44 any = tmp42.Invoke_O__O(tmp43); var tmp45 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp45 = A_arbace_spec_alpha_A_const_131; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp47 = A_arbace_spec_alpha_A_const_69; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp49 = A_arbace_spec_alpha_A_const_130; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp51 = A_arbace_spec_alpha_A_const_131; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 any; A_arbace_spec_alpha_A_Init(); tmp53 = A_arbace_spec_alpha_A_const_398; var tmp54 any = tmp52.Invoke_O__O(tmp53); var tmp55 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp55 = A_arbace_spec_alpha_A_const_131; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 any; A_arbace_spec_alpha_A_Init(); tmp57 = A_arbace_spec_alpha_A_const_396; var tmp58 any = tmp46.Invoke_O__O(tmp48.Invoke_O__O(tmp50.Invoke_O_O__O(tmp54, tmp56.Invoke_O__O(tmp57)))); var tmp59 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp59 = A_arbace_spec_alpha_A_const_131; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp61 = A_arbace_spec_alpha_A_const_69; var tmp62 lang.IFn = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()); var tmp63 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp63 = A_arbace_spec_alpha_A_const_130; var tmp64 lang.IFn = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()); var tmp65 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp65 = A_arbace_spec_alpha_A_const_131; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 any; A_arbace_spec_alpha_A_Init(); tmp67 = A_arbace_spec_alpha_A_const_399; var tmp68 any = tmp66.Invoke_O__O(tmp67); var tmp69 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp69 = A_arbace_spec_alpha_A_const_131; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 any; A_arbace_spec_alpha_A_Init(); tmp71 = A_arbace_spec_alpha_A_const_396; var tmp72 any = tmp12.Invoke_O__O(tmp14.Invoke_O__O(tmp16.Invoke_O_O_O__O(tmp20, tmp34, tmp36.Invoke_O__O(tmp38.Invoke_O__O(tmp40.Invoke_O_O_O__O(tmp44, tmp58, tmp60.Invoke_O__O(tmp62.Invoke_O__O(tmp64.Invoke_O_O__O(tmp68, tmp70.Invoke_O__O(tmp71)))))))))); var tmp73 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp73 = A_arbace_spec_alpha_A_const_74; var tmp74 any = tmp73.Ref(); var tmp75 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp75 = A_arbace_spec_alpha_A_const_76; var tmp76 any = tmp75.Ref(); var tmp77 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp77 = A_arbace_spec_alpha_A_const_77; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, path__1, tmp10, tmp72, tmp74, x__4, tmp76, via__2, tmp77.Ref(), in__3))) } }
//line :1704:1
func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Unform_STAR__O__O(x__1 any) any {









	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_376; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_re, x__1) }
//line :1704:1
func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Conform_STAR__O__O(x__1 any) any {






	var tmp1 any; var or__1927000174__auto____2 bool = lang.Util_Identical_O_O__Z(x__1, nil); if or__1927000174__auto____2 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { var tmp2 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_120; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__1) }; if jrt.J2g_Truth(tmp1) {
		var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_400; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_re; var tmp6 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp6 = A_arbace_spec_alpha_A_const_69; return tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :1711:1
			A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } }
//line :1704:1
func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Specize_STAR__O__O(___1 any) any { return t }
//line :1704:1
func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Specize_STAR___O() any { return t }
//line :1704:1
func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :1704:1
func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_New_IPersistentMap_O_O(m, t.F_gfn, t.F_re) }























func A_arbace_spec_alpha_call_valid_QMARK__A_New() *A_arbace_spec_alpha_call_valid_QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_call_valid_QMARK__A{}; t.Ctor(); return t }
//line :1728:1
func (t *A_arbace_spec_alpha_call_valid_QMARK__A) Ctor() {}
//line :1728:1
func (t *A_arbace_spec_alpha_call_valid_QMARK__A) Invoke_O_O_O_O__O(self, f__0, specs__1, args__2 any) any { var cargs__4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_247.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_236.Invoke_O__O(specs__1), args__2); if


	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(cargs__4)) { return nil } else { var ret__5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(f__0, args__2); var cret__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_247.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_237.Invoke_O__O(specs__1), ret__5); var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_246.GetRawRoot__O()).Invoke_O__O(cret__6))


		if jrt.J2g_Truth(and__1927000168__auto____7) {
			if jrt.J2g_Truth(A_arbace_spec_alpha_A_const_238.Invoke_O__O(specs__1)) {
				return lang.IFn_Cast(A_arbace_spec_alpha_A_const_281.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_238.Invoke_O__O(specs__1), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_236, cargs__4, A_arbace_spec_alpha_A_const_237, cret__6))) } else {
//line :1735:1
					jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } else {
//line :1734:1
						return and__1927000168__auto____7 } } }




func A_arbace_spec_alpha_validate_fn_A_New() *A_arbace_spec_alpha_validate_fn_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_validate_fn_A{}; t.Ctor(); return t }
//line :1739:1
func (t *A_arbace_spec_alpha_validate_fn_A) Ctor() {}
//line :1739:1
func (t *A_arbace_spec_alpha_validate_fn_A) Invoke_O_O_O_O__O(self, f__0, specs__1, iters__2 any) any { var g__4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_111.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_236.Invoke_O__O(specs__1)); var prop__5 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_401.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O__IPersistentVector(g__4); var tmp3 any = A_arbace_spec_alpha_validate_fn_fn__1740000851_A_New_O_O(f__0, specs__1); var tmp4 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_spec_alpha_validate_fn_fn__1740000851_A_fn_class; if



	fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_142, false); A_arbace_spec_alpha_validate_fn_fn__1740000851_A_fn_class = fncls__139d; tmp4 = fncls__139d } else { tmp4 = fncls__139 }; prop__5 = tmp1.Invoke_O_O__O(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)); var ret__6 any = /*line :1739:1*/lang.IFn_Cast(A_arbace_spec_alpha_A_const_402.GetRawRoot__O()).Invoke_O_O__O(iters__2, prop__5); var tmp5 *lang.Keyword = A_arbace_spec_alpha_A_const_403; var temp__1927000408__auto____7 any = tmp5.Invoke_O__O(A_arbace_spec_alpha_A_const_404.Invoke_O__O(ret__6)); if





	jrt.J2g_Truth(temp__1927000408__auto____7) { var vec__1740000853__8 any = temp__1927000408__auto____7; var smallest__9 any = lang.RT_Nth_O_I_O__O(vec__1740000853__8, lang.RT_IntCast_J__I(0), nil); return smallest__9 } else { return f__0 } }
//line :1743:1
func A_arbace_spec_alpha_validate_fn_fn__1740000851_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_validate_fn_fn__1740000851_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_validate_fn_fn__1740000851_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1743:1
func (t *A_arbace_spec_alpha_validate_fn_fn__1740000851_A) Ctor_O_O(c__f, c__specs any) { t.F_f = c__f; t.F_specs = c__specs }
//line :1743:1
func (t *A_arbace_spec_alpha_validate_fn_fn__1740000851_A) Invoke_O_O__O(self, p1__1740000850_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_405.GetRawRoot__O()).Invoke_O_O_O__O(t.F_f, t.F_specs, p1__1740000850_SHARP___1) }





func A_arbace_spec_alpha_fspec_impl_A_New() *A_arbace_spec_alpha_fspec_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_fspec_impl_A{}; t.Ctor(); return t }
//line :1749:1
func (t *A_arbace_spec_alpha_fspec_impl_A) Ctor() {}
//line :1749:1
func (t *A_arbace_spec_alpha_fspec_impl_A) Invoke_O_O_O_O_O_O_O_O__O(self, argspec__0, aform__1, retspec__2, rform__3, fnspec__4, fform__5, gfn__6 any) any { var specs__8 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_236, argspec__0, A_arbace_spec_alpha_A_const_237, retspec__2, A_arbace_spec_alpha_A_const_238, fnspec__4)); return /*line :1753:1*/ A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_New_IPersistentMap_O_O_O_O_O_O_O_O(nil, aform__1, fform__5, gfn__6, specs__8, argspec__0, rform__3, retspec__2, fnspec__4) }
//line :1753:1
func A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_New_IPersistentMap_O_O_O_O_O_O_O_O(p0 lang.IPersistentMap, p1, p2, p3, p4, p5, p6, p7, p8 any) *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A { t := &A_arbace_spec_alpha_fspec_impl_reify__1740000857_A{}; t.Ctor_IPersistentMap_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8); return t }
//line :1753:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Ctor_IPersistentMap_O_O_O_O_O_O_O_O(meta__ lang.IPersistentMap, c__aform, c__fform, c__gfn, c__specs, c__argspec, c__rform, c__retspec, c__fnspec any) { t.F___meta = meta__; t.F_aform = c__aform; t.F_fform = c__fform; t.F_gfn = c__gfn; t.F_specs = c__specs; t.F_argspec = c__argspec; t.F_rform = c__rform; t.F_retspec = c__retspec; t.F_fnspec = c__fnspec }
//line :1753:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Describe_STAR___O() any { var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_69; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_130; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_131; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_406; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_131; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_236; var tmp12 any = tmp10.Invoke_O__O(tmp11.Ref()); var tmp13 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp13 = A_arbace_spec_alpha_A_const_131; var tmp14 any = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(t.F_aform); var tmp15 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp15 = A_arbace_spec_alpha_A_const_131; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp17 = A_arbace_spec_alpha_A_const_237; var tmp18 any = tmp16.Invoke_O__O(tmp17.Ref()); var tmp19 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp19 = A_arbace_spec_alpha_A_const_131; var tmp20 any = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(t.F_rform); var tmp21 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp21 = A_arbace_spec_alpha_A_const_131; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp23 = A_arbace_spec_alpha_A_const_238; var tmp24 any = tmp22.Invoke_O__O(tmp23.Ref()); var tmp25 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp25 = A_arbace_spec_alpha_A_const_131; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O_O_O_O_O__O(tmp8, tmp12, tmp14, tmp18, tmp20, tmp24, lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(t.F_fform))) }
//line :1753:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) With_gen_STAR__O__O(gfn__1 any) any {






































	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_407; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(t.F_argspec, t.F_aform, t.F_retspec, t.F_rform, t.F_fnspec, t.F_fform, gfn__1) }
//line :1753:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Gen_STAR__O_O_O__O(overrides__1, ___2, ___3 any) any {
































	if jrt.J2g_Truth(t.F_gfn) {
		return lang.IFn_Cast(t.F_gfn).Invoke__O() } else {
			var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_255; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_New_O_O_O(overrides__1, t.F_argspec, t.F_retspec); var tmp4 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_fn_class
			if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, true); A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_fn_class = fncls__141d; tmp4 = fncls__141d } else { tmp4 = fncls__141 }
//line :1788:1
			return tmp2.Invoke_O__O(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp3, tmp4, nil, 0)) } }
//line :1753:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, f__4 any) any {
















	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_38; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__4)) { var args__5 any; var tmp2 *lang.Var
		A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_410; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_specs; var tmp5 any; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_103; args__5 = tmp3.Invoke_O_O_O__O(f__4, tmp4, tmp5)
		if lang.Util_Identical_O_O__Z(f__4, args__5) { return nil } else { var ret__6 any; var tmp6 any = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_New_O_O(f__4, args__5); var tmp7 *jrt.Class
			var fncls__142 /*line :1772:1*/*jrt.Class = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_fn_class

			if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_fn_class = fncls__142d; tmp7 = fncls__142d } else { tmp7 = fncls__142 }; ret__6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil).Invoke__O()
			if jrt.Throwable_InstanceOf(ret__6) { var tmp8 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp8 = A_arbace_spec_alpha_A_const_72; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp10 = A_arbace_spec_alpha_A_const_73; var tmp11 any = tmp10.Ref(); var tmp12 any; A_arbace_spec_alpha_A_Init(); tmp12 = A_arbace_spec_alpha_A_const_411; var tmp13 any = tmp12; var tmp14 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp14 = A_arbace_spec_alpha_A_const_74; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp16 = A_arbace_spec_alpha_A_const_75; var tmp17 any = tmp16.Ref(); var tmp18 any = jrt.Throwable_Cast(ret__6).GetMessage__String().Ref(); var tmp19 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp19 = A_arbace_spec_alpha_A_const_76; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp21 = A_arbace_spec_alpha_A_const_77; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9, path__1, tmp11, tmp13, tmp15, args__5, tmp17, tmp18, tmp20, via__2, tmp21.Ref(), in__3))) } else { var cret__7 any; var tmp22 *lang.Var



				A_arbace_spec_alpha_A_Init(); tmp22 = A_arbace_spec_alpha_A_const_254; cret__7 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O_O_O__O(t.F_retspec, ret__6, t.F_rform)
				var tmp23 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp23 = A_arbace_spec_alpha_A_const_246; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(cret__7)) {
					var tmp24 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp24 = A_arbace_spec_alpha_A_const_282; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 any = t.F_rform; var tmp27 any = t.F_retspec; var tmp28 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp28 = A_arbace_spec_alpha_A_const_10; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp30 = A_arbace_spec_alpha_A_const_237; return tmp25.Invoke_O_O_O_O_O_O__O(tmp26, tmp27, tmp29.Invoke_O_O__O(path__1, tmp30.Ref()), via__2, in__3, ret__6) } else {
						if jrt.J2g_Truth(t.F_fnspec) { var cargs__8 any; var tmp31 *lang.Var
							A_arbace_spec_alpha_A_Init(); tmp31 = A_arbace_spec_alpha_A_const_247; cargs__8 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O_O__O(t.F_argspec, args__5)
							var tmp32 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp32 = A_arbace_spec_alpha_A_const_282; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 any = t.F_fform; var tmp35 any = t.F_fnspec; var tmp36 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp36 = A_arbace_spec_alpha_A_const_10; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp38 = A_arbace_spec_alpha_A_const_238; var tmp39 any = tmp37.Invoke_O_O__O(path__1, tmp38.Ref()); var tmp40 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp40 = A_arbace_spec_alpha_A_const_236; var tmp41 any = tmp40.Ref(); var tmp42 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp42 = A_arbace_spec_alpha_A_const_237; return tmp33.Invoke_O_O_O_O_O_O__O(tmp34, tmp35, tmp39, via__2, in__3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp41, cargs__8, tmp42.Ref(), cret__7))) } else {
//line :1782:1
								return nil } } } } } else {
//line :1770:1
									var tmp43 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp43 = A_arbace_spec_alpha_A_const_72; var tmp44 any = tmp43.Ref(); var tmp45 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp45 = A_arbace_spec_alpha_A_const_73; var tmp46 any = tmp45.Ref(); var tmp47 any; A_arbace_spec_alpha_A_Init(); tmp47 = A_arbace_spec_alpha_A_const_412; var tmp48 any = tmp47; var tmp49 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp49 = A_arbace_spec_alpha_A_const_74; var tmp50 any = tmp49.Ref(); var tmp51 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp51 = A_arbace_spec_alpha_A_const_76; var tmp52 any = tmp51.Ref(); var tmp53 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp53 = A_arbace_spec_alpha_A_const_77; return lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp44, path__1, tmp46, tmp48, tmp50, f__4, tmp52, via__2, tmp53.Ref(), in__3))) } }
//line :1753:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Unform_STAR__O__O(f__1 any) any { return f__1 }
//line :1753:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Conform_STAR__O__O(f__1 any) any {









	if jrt.J2g_Truth(t.F_argspec) {
		var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_38; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__1)) {
			var tmp2 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_410; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = t.F_specs; var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_413; if lang.Util_Identical_O_O__Z(f__1, tmp3.Invoke_O_O_O__O(f__1, tmp4, jrt.NN(tmp5).Get__O())) { return f__1 } else { A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } } else {
//line :1764:1
				A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } } else {
//line :1763:1
					var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_71, nil); var tmp7 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_84; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_414; panic(jrt.Thrown(jrt.Exception_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(t))))))) } }
//line :1753:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Specize_STAR__O__O(___1 any) any { return t }
//line :1753:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Specize_STAR___O() any { return t }
//line :1753:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) ValAt_O_O__O(k__1, not_found__2 any) any {


	return lang.RT_Get_O_O_O__O(t.F_specs, k__1, not_found__2) }
//line :1753:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) ValAt_O__O(k__1 any) any {

	return lang.RT_Get_O_O__O(t.F_specs, k__1) }
//line :1753:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :1753:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_New_IPersistentMap_O_O_O_O_O_O_O_O(m, t.F_aform, t.F_fform, t.F_gfn, t.F_specs, t.F_argspec, t.F_rform, t.F_retspec, t.F_fnspec) }




















func A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1774:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A) Ctor_O_O(c__f, c__args any) { t.F_f = c__f; t.F_args = c__args }
//line :1774:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_f; t.F_f = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_args; t.F_args = nil; tmp5 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp4, tmp5) }; return nil }(); if tmp6 != nil { if true { var t__3 jrt.Throwable_I = tmp6; tmp1 = t__3 } }; return tmp1 }














func A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_New_O_O_O(p0, p1, p2 any) *A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1789:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A) Ctor_O_O_O(c__overrides, c__argspec, c__retspec any) { t.F_overrides = c__overrides; t.F_argspec = c__argspec; t.F_retspec = c__retspec }
//line :1789:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A) DoInvoke_O_O__O(self, args__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_281.GetRawRoot__O()).Invoke_O_O__O(t.F_argspec, args__1)) { } else { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_4, nil, Lit_6, nil); var tmp2 any; var s__1927001093__auto____6 any = jrt.StringWriter_New(); lang.IFn_Cast(A_arbace_spec_alpha_A_const_95.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_96.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_97, s__1927001093__auto____6)); var tmp3 any = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_New_O_O_O(s__1927001093__auto____6, t.F_argspec, args__1); var tmp4 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_fn_class = fncls__140d; tmp4 = fncls__140d } else { tmp4 = fncls__140 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O(); panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2, nil, lang.IFn_Cast(A_arbace_spec_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_409))).Ref()))) }
	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_408.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_111.GetRawRoot__O()).Invoke_O_O__O(t.F_retspec, t.F_overrides)) }
//line :1790:1
func A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_New_O_O_O(p0, p1, p2 any) *A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1790:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A) Ctor_O_O_O(c__s__1927001093__auto__, c__argspec, c__args any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_argspec = c__argspec; t.F_args = c__args }
//line :1790:1
func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A) Invoke_O__O(self any) any { var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_98.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_argspec; t.F_argspec = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_args; t.F_args = nil; tmp5 = t__2; tmp2.Invoke_O_O__O(tmp4, tmp5); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_93.GetRawRoot__O()); var tmp7 any; var t__3 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; tmp7 = t__3; tmp1 = tmp6.Invoke_O__O(tmp7) }; return nil }(); lang.IFn_Cast(A_arbace_spec_alpha_A_const_94.GetRawRoot__O()).Invoke__O(); if tmp8 != nil { panic(tmp8) }; return tmp1 }





func A_arbace_spec_alpha_fn__1740000868_A_New() *A_arbace_spec_alpha_fn__1740000868_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_fn__1740000868_A{}; t.Ctor(); return t }
//line :1796:1
func (t *A_arbace_spec_alpha_fn__1740000868_A) Ctor() {}
//line :1796:1
func (t *A_arbace_spec_alpha_fn__1740000868_A) Invoke_O_O__O(self, p1__1740000866_SHARP___0 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_267.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_415, p1__1740000866_SHARP___0), lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_416, p1__1740000866_SHARP___0)) }
//line :1796:1
func A_arbace_spec_alpha_fn__1740000870_A_New() *A_arbace_spec_alpha_fn__1740000870_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_fn__1740000870_A{}; t.Ctor(); return t }
//line :1796:1
func (t *A_arbace_spec_alpha_fn__1740000870_A) Ctor() {}
//line :1796:1
func (t *A_arbace_spec_alpha_fn__1740000870_A) Invoke_O_O__O(self, p1__1740000867_SHARP___0 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), p1__1740000867_SHARP___0) }
//line :1796:1
func A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_New() *A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A{}; t.Ctor(); return t }
//line :1796:1
func (t *A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A) Ctor() {}
//line :1796:1
func (t *A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A) Invoke_O_O__O(self, p__1740000871__1 any) any { var vec__1740000873__2 any = p__1740000871__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1740000873__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1740000873__2, lang.RT_IntCast_J__I(1), nil); return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha_A_const_415, k__3, A_arbace_spec_alpha_A_const_416, v__4)) }

func A_arbace_spec_alpha_keys_STAR__A_New() *A_arbace_spec_alpha_keys_STAR__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_keys_STAR__A{}; t.Ctor(); return t }
//line :1798:1
func (t *A_arbace_spec_alpha_keys_STAR__A) Ctor() {}
//line :1798:1
func (t *A_arbace_spec_alpha_keys_STAR__A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, kspecs__2 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_417), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_418), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_419), kspecs__2))))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_420), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_421), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_422), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_423), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_415), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_424), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_416), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_425))))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_426), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_418)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_427), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke__O()))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_428), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_429), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_430))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_431), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_432), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_430))))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_433), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_418))))))))))))))) }


















func A_arbace_spec_alpha_nonconforming_A_New() *A_arbace_spec_alpha_nonconforming_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_nonconforming_A{}; t.Ctor(); return t }
//line :1817:1
func (t *A_arbace_spec_alpha_nonconforming_A) Ctor() {}
//line :1817:1
func (t *A_arbace_spec_alpha_nonconforming_A) Invoke_O_O__O(self, spec__0 any) any { var spec__2 any; var tmp1 any = A_arbace_spec_alpha_nonconforming_fn__1740000885_A_New_O(spec__0); var tmp2 *jrt.Class; var fncls__144 *jrt.Class = A_arbace_spec_alpha_nonconforming_fn__1740000885_A_fn_class; if



	fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_112, false); A_arbace_spec_alpha_nonconforming_fn__1740000885_A_fn_class = fncls__144d; tmp2 = fncls__144d } else { tmp2 = fncls__144 }; spec__2 = /*line :1817:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return /*line :1822:1*/ A_arbace_spec_alpha_nonconforming_reify__1740000887_A_New_IPersistentMap_O(nil, spec__2) }
//line :1821:1
func A_arbace_spec_alpha_nonconforming_fn__1740000885_A_New_O(p0 any) *A_arbace_spec_alpha_nonconforming_fn__1740000885_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_nonconforming_fn__1740000885_A{}; t.Ctor_O(p0); return t }
//line :1821:1
func (t *A_arbace_spec_alpha_nonconforming_fn__1740000885_A) Ctor_O(c__spec any) { t.F_spec = c__spec }
//line :1821:1
func (t *A_arbace_spec_alpha_nonconforming_fn__1740000885_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_43.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_spec; t.F_spec = nil; tmp2 = t_; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_spec_alpha_nonconforming_reify__1740000887_A_New_IPersistentMap_O(p0 lang.IPersistentMap, p1 any) *A_arbace_spec_alpha_nonconforming_reify__1740000887_A { t := &A_arbace_spec_alpha_nonconforming_reify__1740000887_A{}; t.Ctor_IPersistentMap_O(p0, p1); return t }
//line :1822:1
func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Ctor_IPersistentMap_O(meta__ lang.IPersistentMap, c__spec any) { t.F___meta = meta__; t.F_spec = c__spec }
//line :1822:1
func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Describe_STAR___O() any { var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_69; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_130; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_131; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_434; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_131; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; var target_145 any; var tmp12 *lang.Var;













	A_arbace_spec_alpha_A_Init(); tmp12 = A_arbace_spec_alpha_A_const_9; target_145 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(t.F_spec); var tmp13 bool; var tmp14 bool; tmp14 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_145); if tmp14 { tmp14 = !lang.Compiler_AOT_IsDyn_O__Z(target_145) }; tmp13 = tmp14; if tmp13 { tmp11 = A_arbace_spec_alpha_Spec_A_Cast(target_145).Describe_STAR___O() } else { var tmp15 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp15 = A_arbace_spec_alpha_A_const_46; tmp11 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(target_145) }; return /*line :1822:1*/ tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp11))) }
//line :1822:1
func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) With_gen_STAR__O__O(gfn__1 any) any {












	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_435; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var target_146 any; var tmp4 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_9; target_146 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(t.F_spec); var tmp5 bool; var tmp6 bool; tmp6 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_146); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z(target_146) }; tmp5 = tmp6; if tmp5 { tmp3 = A_arbace_spec_alpha_Spec_A_Cast(target_146).With_gen_STAR__O__O(gfn__1) } else { var tmp7 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_60; tmp3 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(target_146, gfn__1) }; return tmp2.Invoke_O__O(tmp3) }
//line :1822:1
func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Gen_STAR__O_O_O__O(overrides__1, path__2, rmap__3 any) any {











	var target_147 any; var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_9; target_147 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_spec); var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_147); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z(target_147) }; tmp2 = tmp3; if tmp2 { return A_arbace_spec_alpha_Spec_A_Cast(target_147).Gen_STAR__O_O_O__O(overrides__1, path__2, rmap__3) } else { var tmp4 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_99; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O_O_O__O(target_147, overrides__1, path__2, rmap__3) } }
//line :1822:1
func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, x__4 any) any {










	var target_148 any; var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_9; target_148 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_spec); var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_148); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z(target_148) }; tmp2 = tmp3; if tmp2 { return A_arbace_spec_alpha_Spec_A_Cast(target_148).Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, x__4) } else { var tmp4 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_62; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O_O_O_O__O(target_148, path__1, via__2, in__3, x__4) } }
//line :1822:1
func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Unform_STAR__O__O(x__1 any) any { return x__1 }
//line :1822:1
func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Conform_STAR__O__O(x__1 any) any { var ret__2 any; var target_149 any; var tmp1 *lang.Var;





	A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_9; target_149 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_spec); var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_149); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z(target_149) }; tmp2 = tmp3; if tmp2 { ret__2 = A_arbace_spec_alpha_Spec_A_Cast(target_149).Conform_STAR__O__O(x__1) } else { var tmp4 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_44; ret__2 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(target_149, x__1) }; var tmp5 /*line :1829:1*/*lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_246; if jrt.J2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(ret__2)) { A_arbace_spec_alpha_A_Init(); return A_arbace_spec_alpha_A_const_42 } else { return x__1 } }
//line :1822:1
func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Specize_STAR__O__O(___1 any) any { return t }
//line :1822:1
func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Specize_STAR___O() any { return t }
//line :1822:1
func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :1822:1
func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_spec_alpha_nonconforming_reify__1740000887_A_New_IPersistentMap_O(m, t.F_spec) }















func A_arbace_spec_alpha_nilable_impl_A_New() *A_arbace_spec_alpha_nilable_impl_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_nilable_impl_A{}; t.Ctor(); return t }
//line :1838:1
func (t *A_arbace_spec_alpha_nilable_impl_A) Ctor() {}
//line :1838:1
func (t *A_arbace_spec_alpha_nilable_impl_A) Invoke_O_O_O_O__O(self, form__0, pred__1, gfn__2 any) any { var spec__4 any; var tmp1 any = A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_New_O_O(form__0, pred__1); var tmp2 *jrt.Class; var fncls__150 *jrt.Class = A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_fn_class; if


	fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_109, false); A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_fn_class = fncls__150d; tmp2 = fncls__150d } else { tmp2 = fncls__150 }; spec__4 = /*line :1838:1*/lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return /*line :1842:1*/ A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_New_IPersistentMap_O_O_O_O(nil, form__0, gfn__2, spec__4, pred__1) }
//line :1841:1
func A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_nilable_impl_fn__1740000890_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_nilable_impl_fn__1740000890_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1841:1
func (t *A_arbace_spec_alpha_nilable_impl_fn__1740000890_A) Ctor_O_O(c__form, c__pred any) { t.F_form = c__form; t.F_pred = c__pred }
//line :1841:1
func (t *A_arbace_spec_alpha_nilable_impl_fn__1740000890_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_43.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_pred; t.F_pred = nil; tmp2 = t_; var tmp3 any = tmp2; var tmp4 any; var t__2 any = t.F_form; t.F_form = nil; tmp4 = t__2; return tmp1.Invoke_O_O__O(tmp3, tmp4) }
func A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_New_IPersistentMap_O_O_O_O(p0 lang.IPersistentMap, p1, p2, p3, p4 any) *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A { t := &A_arbace_spec_alpha_nilable_impl_reify__1740000892_A{}; t.Ctor_IPersistentMap_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1842:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Ctor_IPersistentMap_O_O_O_O(meta__ lang.IPersistentMap, c__form, c__gfn, c__spec, c__pred any) { t.F___meta = meta__; t.F_form = c__form; t.F_gfn = c__gfn; t.F_spec = c__spec; t.F_pred = c__pred }
//line :1842:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Describe_STAR___O() any { var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_69; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_130; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_131; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_436; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp9 = A_arbace_spec_alpha_A_const_131; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_122; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(t.F_form)))) }
//line :1842:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) With_gen_STAR__O__O(gfn__1 any) any {


















	var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_437; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_form, t.F_pred, gfn__1) }
//line :1842:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Gen_STAR__O_O_O__O(overrides__1, path__2, rmap__3 any) any {













	if jrt.J2g_Truth(t.F_gfn) {
		return lang.IFn_Cast(t.F_gfn).Invoke__O() } else {
			var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_438; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_alpha_A_Init(); tmp3 = A_arbace_spec_alpha_A_const_260; var tmp4 any = tmp3; var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_273; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_New(); var tmp8 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_fn_class
			if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_110, false); A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_fn_class = fncls__151d; tmp8 = fncls__151d } else { tmp8 = fncls__151 }
//line :1858:1
			var tmp9 any = lang.Tuple_Create_O_O__IPersistentVector(tmp4, tmp6.Invoke_O__O(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)))); var tmp10 any; A_arbace_spec_alpha_A_Init(); tmp10 = A_arbace_spec_alpha_A_const_439; var tmp11 any = tmp10; var tmp12 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp12 = A_arbace_spec_alpha_A_const_273; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_New_O_O_O_O_O(path__2, t.F_form, overrides__1, rmap__3, t.F_pred); var tmp15 *jrt.Class
			var fncls__152 /*line :1858:1*/*jrt.Class = A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_fn_class

			if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_111, false); A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_fn_class = fncls__152d; tmp15 = fncls__152d } else { tmp15 = fncls__152 }
//line :1858:1
			return tmp2.Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp9, lang.Tuple_Create_O_O__IPersistentVector(tmp11, tmp13.Invoke_O__O(lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil)))))) } }
//line :1842:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Explain_STAR__O_O_O_O__O(path__1, via__2, in__3, x__4 any) any {








	var tmp1 any; var or__1927000174__auto____5 any; var tmp2 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp2 = A_arbace_spec_alpha_A_const_281; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_9; or__1927000174__auto____5 = tmp3.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(t.F_spec), x__4); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp1 = or__1927000174__auto____5 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(x__4, nil)).Ref() }; if jrt.J2g_Truth(tmp1) { return nil } else {
		var tmp5 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp5 = A_arbace_spec_alpha_A_const_10; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp7 = A_arbace_spec_alpha_A_const_282; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = t.F_form; var tmp10 any = t.F_pred; var tmp11 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp11 = A_arbace_spec_alpha_A_const_10; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp13 = A_arbace_spec_alpha_A_const_440; var tmp14 any = tmp8.Invoke_O_O_O_O_O_O__O(tmp9, tmp10, tmp12.Invoke_O_O__O(path__1, tmp13.Ref()), via__2, in__3, x__4); var tmp15 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp15 = A_arbace_spec_alpha_A_const_72; var tmp16 any = tmp15.Ref(); var tmp17 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp17 = A_arbace_spec_alpha_A_const_10; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp19 = A_arbace_spec_alpha_A_const_369; var tmp20 any = tmp18.Invoke_O_O__O(path__1, tmp19.Ref()); var tmp21 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp21 = A_arbace_spec_alpha_A_const_73; var tmp22 any = tmp21.Ref(); var tmp23 any; A_arbace_spec_alpha_A_Init(); tmp23 = A_arbace_spec_alpha_A_const_441; var tmp24 any = tmp23; var tmp25 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp25 = A_arbace_spec_alpha_A_const_74; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp27 = A_arbace_spec_alpha_A_const_76; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Keyword; A_arbace_spec_alpha_A_Init(); tmp29 = A_arbace_spec_alpha_A_const_77; return tmp6.Invoke_O_O__O(tmp14, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp20, tmp22, tmp24, tmp26, x__4, tmp28, via__2, tmp29.Ref(), in__3))) } }
//line :1842:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Unform_STAR__O__O(x__1 any) any {






	if lang.Util_Identical_O_O__Z(x__1, nil) { return nil } else { var target_153 any; var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_9; target_153 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_spec); var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_153); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z(target_153) }; tmp2 = tmp3; if tmp2 { return A_arbace_spec_alpha_Spec_A_Cast(target_153).Unform_STAR__O__O(x__1) } else { var tmp4 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_45; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(target_153, x__1) } } }
//line :1842:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Conform_STAR__O__O(x__1 any) any {





	if lang.Util_Identical_O_O__Z(x__1, nil) { return nil } else { var target_154 any; var tmp1 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp1 = A_arbace_spec_alpha_A_const_9; target_154 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(t.F_spec); var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_spec_alpha_Spec_A_InstanceOf(target_154); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z(target_154) }; tmp2 = tmp3; if tmp2 { return A_arbace_spec_alpha_Spec_A_Cast(target_154).Conform_STAR__O__O(x__1) } else { var tmp4 *lang.Var; A_arbace_spec_alpha_A_Init(); tmp4 = A_arbace_spec_alpha_A_const_44; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(target_154, x__1) } } }
//line :1842:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Specize_STAR__O__O(___1 any) any { return t }
//line :1842:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Specize_STAR___O() any { return t }
//line :1842:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Meta__IPersistentMap() lang.IPersistentMap { return t.F___meta }
//line :1842:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) WithMeta_IPersistentMap__IObj(m lang.IPersistentMap) lang.IObj { return A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_New_IPersistentMap_O_O_O_O(m, t.F_form, t.F_gfn, t.F_spec, t.F_pred) }
















func A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_New() *A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A{}; t.Ctor(); return t }
//line :1859:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A) Ctor() {}
//line :1859:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_255.GetRawRoot__O()).Invoke_O__O(nil) }
func A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :1860:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A) Ctor_O_O_O_O_O(c__path, c__form, c__overrides, c__rmap, c__pred any) { t.F_path = c__path; t.F_form = c__form; t.F_overrides = c__overrides; t.F_rmap = c__rmap; t.F_pred = c__pred }
//line :1860:1
func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_108.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_pred; t.F_pred = nil; tmp2 = t_; var tmp3 any = tmp2; var tmp4 any; var t__2 any = t.F_overrides; t.F_overrides = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_10.GetRawRoot__O()); var tmp7 any; var t__3 any = t.F_path; t.F_path = nil; tmp7 = t__3; var tmp8 any = tmp6.Invoke_O_O__O(tmp7, A_arbace_spec_alpha_A_const_440); var tmp9 any; var t__4 any = t.F_rmap; t.F_rmap = nil; tmp9 = t__4; var tmp10 any = tmp9; var tmp11 any; var t__5 any = t.F_form; t.F_form = nil; tmp11 = t__5; return tmp1.Invoke_O_O_O_O_O__O(tmp3, tmp5, tmp8, tmp10, tmp11) }



func A_arbace_spec_alpha_nilable_A_New() *A_arbace_spec_alpha_nilable_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_nilable_A{}; t.Ctor(); return t }
//line :1864:1
func (t *A_arbace_spec_alpha_nilable_A) Ctor() {}
//line :1864:1
func (t *A_arbace_spec_alpha_nilable_A) Invoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, pred__2 any) any { var pf__4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(pred__2); return /*line :1867:1*/ lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_442), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_133), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pf__4)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(pred__2), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(nil))) }


func A_arbace_spec_alpha_exercise_A_New() *A_arbace_spec_alpha_exercise_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_exercise_A{}; t.Ctor(); return t }
//line :1870:1
func (t *A_arbace_spec_alpha_exercise_A) Ctor() {}
//line :1870:1
func (t *A_arbace_spec_alpha_exercise_A) Invoke_O_O_O_O__O(self, spec__0, n__1, overrides__2 any) any {






	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_148.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_exercise_fn__1740000905_A_New_O(spec__0); var tmp3 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_spec_alpha_exercise_fn__1740000905_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_spec_alpha_exercise_fn__1740000905_A_fn_class = fncls__155d; tmp3 = fncls__155d } else { tmp3 = fncls__155 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_spec_alpha_A_const_443.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_111.GetRawRoot__O()).Invoke_O_O__O(spec__0, overrides__2), n__1)) }
//line :1870:1
func (t *A_arbace_spec_alpha_exercise_A) Invoke_O_O_O__O(self, spec__0, n__1 any) any {




	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_444.GetRawRoot__O()).Invoke_O_O_O__O(spec__0, n__1, nil) }
//line :1870:1
func (t *A_arbace_spec_alpha_exercise_A) Invoke_O_O__O(self, spec__0 any) any {



	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_444.GetRawRoot__O()).Invoke_O_O__O(spec__0, A_arbace_spec_alpha_A_const_445)
}

func A_arbace_spec_alpha_exercise_fn__1740000905_A_New_O(p0 any) *A_arbace_spec_alpha_exercise_fn__1740000905_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_exercise_fn__1740000905_A{}; t.Ctor_O(p0); return t }
//line :1877:1
func (t *A_arbace_spec_alpha_exercise_fn__1740000905_A) Ctor_O(c__spec any) { t.F_spec = c__spec }
//line :1877:1
func (t *A_arbace_spec_alpha_exercise_fn__1740000905_A) Invoke_O_O__O(self, p1__1740000904_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_159.GetRawRoot__O()).Invoke_O_O__O(p1__1740000904_SHARP___1, lang.IFn_Cast(A_arbace_spec_alpha_A_const_247.GetRawRoot__O()).Invoke_O_O__O(t.F_spec, p1__1740000904_SHARP___1)) }

func A_arbace_spec_alpha_exercise_fn_A_New() *A_arbace_spec_alpha_exercise_fn_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_exercise_fn_A{}; t.Ctor(); return t }
//line :1879:1
func (t *A_arbace_spec_alpha_exercise_fn_A) Ctor() {}
//line :1879:1
func (t *A_arbace_spec_alpha_exercise_fn_A) Invoke_O_O_O_O__O(self, sym_or_f__0, n__1, fspec__2 any) any { var f__4 any; if







	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_49.GetRawRoot__O()).Invoke_O__O(sym_or_f__0)) { f__4 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_121.GetRawRoot__O()).Invoke_O__O(sym_or_f__0) } else { f__4 = sym_or_f__0 }; var temp__1927000408__auto____5 any; var and__1927000168__auto____5 any = fspec__2; if
	jrt.J2g_Truth(and__1927000168__auto____5) { temp__1927000408__auto____5 = A_arbace_spec_alpha_A_const_236.Invoke_O__O(fspec__2) } else { temp__1927000408__auto____5 = and__1927000168__auto____5 }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var arg_spec__6 any = temp__1927000408__auto____5; var iter__1927001039__auto____7 any; var tmp1 any = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_New_O(f__4); var tmp2 *jrt.Class; var fncls__158 *jrt.Class = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_fn_class
		if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_fn_class = fncls__158d; tmp2 = fncls__158d } else { tmp2 = fncls__158 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_443.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_111.GetRawRoot__O()).Invoke_O__O(arg_spec__6), n__1)) } else {
//line :1888:1
			panic(jrt.Thrown(jrt.Exception_New_String(Lit_53))) } }
//line :1879:1
func (t *A_arbace_spec_alpha_exercise_fn_A) Invoke_O_O_O__O(self, sym__0, n__1 any) any {





	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_450.GetRawRoot__O()).Invoke_O_O_O__O(sym__0, n__1, lang.IFn_Cast(A_arbace_spec_alpha_A_const_245.GetRawRoot__O()).Invoke_O__O(sym__0)) }
//line :1879:1
func (t *A_arbace_spec_alpha_exercise_fn_A) Invoke_O_O__O(self, sym__0 any) any {




	return lang.IFn_Cast(A_arbace_spec_alpha_A_const_450.GetRawRoot__O()).Invoke_O_O__O(sym__0, A_arbace_spec_alpha_A_const_445)
}



func A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_New_O(p0 any) *A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A{}; t.Ctor_O(p0); return t }
//line :1889:1
func (t *A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :1889:1
func (t *A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A) Invoke_O_O__O(self, s__1740000909__1 any) any { var tmp1 any = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_New_O_O_O(t.F_f, s__1740000909__1, self); var tmp2 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_fn_class = fncls__157d; tmp2 = fncls__157d } else { tmp2 = fncls__157 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :1889:1
func A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_New_O_O_O(p0, p1, p2 any) *A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :1889:1
func (t *A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A) Ctor_O_O_O(c__f, c__s__1740000909, c__iter__1740000908 any) { t.F_f = c__f; t.F_s__1740000909 = c__s__1740000909; t.F_iter__1740000908 = c__iter__1740000908 }
//line :1889:1
func (t *A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A) Invoke_O__O(self any) any { { var s__1740000909__1 any; var t_ any = t.F_s__1740000909; t.F_s__1740000909 = nil; s__1740000909__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(s__1740000909__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1740000909__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1740000909__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1740000909__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1740000911__6 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_446.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_New_O_O_I_O(t.F_f, b__1740000911__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__156 *jrt.Class = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_fn_class; if fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_fn_class = fncls__156d; tmp2 = fncls__156d } else { tmp2 = fncls__156 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1740000908); return lang.IFn_Cast(A_arbace_spec_alpha_A_const_448.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_449.GetRawRoot__O()).Invoke_O__O(b__1740000911__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_86.GetRawRoot__O()).Invoke_O__O(s__1740000909__3))) } else { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_448.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_449.GetRawRoot__O()).Invoke_O__O(b__1740000911__6), nil) } } else { var args__4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(s__1740000909__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1740000908); return lang.IFn_Cast(A_arbace_spec_alpha_A_const_268.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(args__4, lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(t.F_f, args__4)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_113.GetRawRoot__O()).Invoke_O__O(s__1740000909__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :1889:1
func A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :1889:1
func (t *A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A) Ctor_O_O_I_O(c__f, c__b__1740000911 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_f = c__f; t.F_b__1740000911 = c__b__1740000911; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :1889:1
func (t *A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A) Invoke_O__O(self any) any { { var i__1740000910__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1740000910__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var args__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1740000910__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_447.GetRawRoot__O()); var tmp3 any = t.F_b__1740000911; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(args__2, lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(t.F_f, args__2))); i__1740000910__1 = lang.Numbers_Unchecked_inc_J__J(i__1740000910__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_spec_alpha_inst_in_range_QMARK__A_New() *A_arbace_spec_alpha_inst_in_range_QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_inst_in_range_QMARK__A{}; t.Ctor(); return t }
//line :1893:1
func (t *A_arbace_spec_alpha_inst_in_range_QMARK__A) Ctor() {}
//line :1893:1
func (t *A_arbace_spec_alpha_inst_in_range_QMARK__A) Invoke_O_O_O_O__O(self, start__0, end__1, inst__2 any) any { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_451.GetRawRoot__O()).Invoke_O__O(inst__2); if


	jrt.J2g_Truth(and__1927000168__auto____4) { var t__5 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_452.GetRawRoot__O()).Invoke_O__O(inst__2); var and__1927000168__auto____6 bool = lang.Numbers_Lte_O_O__Z(lang.IFn_Cast(A_arbace_spec_alpha_A_const_452.GetRawRoot__O()).Invoke_O__O(start__0), t__5)

		if and__1927000168__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_O_O__Z(t__5, lang.IFn_Cast(A_arbace_spec_alpha_A_const_452.GetRawRoot__O()).Invoke_O__O(end__1))).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() } } else {
//line :1896:1
			return and__1927000168__auto____4 } }



func A_arbace_spec_alpha_inst_in_A_New() *A_arbace_spec_alpha_inst_in_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_inst_in_A{}; t.Ctor(); return t }
//line :1900:1
func (t *A_arbace_spec_alpha_inst_in_A) Ctor() {}
//line :1900:1
func (t *A_arbace_spec_alpha_inst_in_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, start__2, end__3 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_23.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha_A_const_460; return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_453), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_454), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_455), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(start__2)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_456), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_457), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(end__3)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_458), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_459), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_460))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_461), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_96.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_462), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_463)))))))))))))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_464), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_465), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_466), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_395), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_467))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_468), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(start__2), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(end__3), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_467)))))))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_135), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_469), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke__O()))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_470), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_458), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_471), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_96.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_472), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_454), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_473), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_456))))))))))))))))))) }











func A_arbace_spec_alpha_int_in_range_QMARK__A_New() *A_arbace_spec_alpha_int_in_range_QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_int_in_range_QMARK__A{}; t.Ctor(); return t }
//line :1912:1
func (t *A_arbace_spec_alpha_int_in_range_QMARK__A) Ctor() {}
//line :1912:1
func (t *A_arbace_spec_alpha_int_in_range_QMARK__A) Invoke_O_O_O_O__O(self, start__0, end__1, val__2 any) any { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_474.GetRawRoot__O()).Invoke_O__O(val__2); if



	jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 bool = lang.Numbers_Lte_O_O__Z(start__0, val__2); if and__1927000168__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Lt_O_O__Z(val__2, end__1)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() } } else { return and__1927000168__auto____4 } }

func A_arbace_spec_alpha_int_in_A_New() *A_arbace_spec_alpha_int_in_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_int_in_A{}; t.Ctor(); return t }
//line :1918:1
func (t *A_arbace_spec_alpha_int_in_A) Ctor() {}
//line :1918:1
func (t *A_arbace_spec_alpha_int_in_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, start__2, end__3 any) any { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_475), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_476), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_477), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_395), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_478))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_479), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(start__2), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(end__3), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_478)))))))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_135), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_395), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke__O()))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_480), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_96.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_472), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(start__2), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_473), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_481), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(end__3)))))))))))))))) }






func A_arbace_spec_alpha_double_in_A_New() *A_arbace_spec_alpha_double_in_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_double_in_A{}; t.Ctor(); return t }
//line :1925:1
func (t *A_arbace_spec_alpha_double_in_A) Ctor() {}
//line :1925:1
func (t *A_arbace_spec_alpha_double_in_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, p__1740000945__2 any) any { var default__1740000948__4 any; jrt.Boolean_Init(); default__1740000948__4 = jrt.Boolean_TRUE.Ref(); var default__1740000949__5 any; jrt.Boolean_Init(); default__1740000949__5 = jrt.Boolean_TRUE.Ref(); var map__1740000946__6 any = p__1740000945__2; var map__1740000946__7 any; if lang.ISeq_InstanceOf(map__1740000946__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_70.GetRawRoot__O()).Invoke_O__O(map__1740000946__6)) { map__1740000946__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_alpha_A_const_71.GetRawRoot__O()).Invoke_O__O(map__1740000946__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(map__1740000946__6)) { map__1740000946__7 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(map__1740000946__6) } else { lang.PersistentArrayMap_Init(); map__1740000946__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1740000946__7 = map__1740000946__6 }; var m__8 any = map__1740000946__7; var infinite_QMARK___9 any = lang.RT_Get_O_O_O__O(map__1740000946__7, A_arbace_spec_alpha_A_const_482, default__1740000948__4); var NaN_QMARK___10_ any = lang.RT_Get_O_O_O__O(map__1740000946__7, A_arbace_spec_alpha_A_const_483, default__1740000949__5); var min__11 any = lang.RT_Get_O_O__O(map__1740000946__7, A_arbace_spec_alpha_A_const_472); var max__12 any = lang.RT_Get_O_O__O(map__1740000946__7, A_arbace_spec_alpha_A_const_473); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_484); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()); var tmp7 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_487); var tmp8 any = lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_488); var tmp9 any; if










	jrt.J2g_Truth(infinite_QMARK___9) { tmp9 = nil } else { tmp9 = A_arbace_spec_alpha_A_const_485 }; var tmp10 any = tmp9; var tmp11 any; if
	jrt.J2g_Truth(NaN_QMARK___10_) { tmp11 = nil } else { tmp11 = A_arbace_spec_alpha_A_const_486 }; var tmp12 any = tmp11; var tmp13 any; if
	jrt.J2g_Truth(max__12) { tmp13 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_395), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_489))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_490), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_489), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(max__12)))))))))) } else { tmp13 = nil }; var tmp14 any = tmp13; var tmp15 any; if
	jrt.J2g_Truth(min__11) { tmp15 = lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_395), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_491))))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_492), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(min__11), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_491)))))))))) } else { tmp15 = nil }; return /*line :1925:1*/ tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O__O(tmp3, tmp4.Invoke_O__O(tmp5.Invoke_O__O(tmp6.Invoke_O_O_O_O_O_O__O(tmp7, tmp8, tmp10, tmp12, tmp14, tmp15))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_135), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_395), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_158.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_159.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke__O()))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_493), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(m__8))))))))) }




























func A_arbace_spec_alpha_check_asserts_QMARK__A_New() *A_arbace_spec_alpha_check_asserts_QMARK__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_check_asserts_QMARK__A{}; t.Ctor(); return t }
//line :1954:1
func (t *A_arbace_spec_alpha_check_asserts_QMARK__A) Ctor() {}
//line :1954:1
func (t *A_arbace_spec_alpha_check_asserts_QMARK__A) Invoke_O__O(self any) any { var tmp1 bool; lang.RT_Init(); tmp1 = lang.RT_checkSpecAsserts; return jrt.Boolean_ValueOf_Z__Boolean(tmp1).Ref() }




func A_arbace_spec_alpha_check_asserts_A_New() *A_arbace_spec_alpha_check_asserts_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_check_asserts_A{}; t.Ctor(); return t }
//line :1959:1
func (t *A_arbace_spec_alpha_check_asserts_A) Ctor() {}
//line :1959:1
func (t *A_arbace_spec_alpha_check_asserts_A) Invoke_O_O__O(self, flag__0 any) any { var tmp1 bool; var tmp2 bool = jrt.NN(jrt.Boolean_Cast(flag__0)).BooleanValue__Z(); var tmp3 bool = tmp2; lang.RT_Init(); lang.RT_checkSpecAsserts = tmp3; tmp1 = tmp2; return jrt.Boolean_ValueOf_Z__Boolean(tmp1) }








func A_arbace_spec_alpha_assert_STAR__A_New() *A_arbace_spec_alpha_assert_STAR__A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_assert_STAR__A{}; t.Ctor(); return t }
//line :1968:1
func (t *A_arbace_spec_alpha_assert_STAR__A) Ctor() {}
//line :1968:1
func (t *A_arbace_spec_alpha_assert_STAR__A) Invoke_O_O_O__O(self, spec__0, x__1 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_alpha_A_const_102.GetRawRoot__O()).Invoke_O_O__O(spec__0, x__1)) { return x__1 } else { var ed__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_312.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_22.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_67.GetRawRoot__O()); var tmp4 *lang.PersistentVector

		lang.PersistentVector_Init(); tmp4 = lang.PersistentVector_EMPTY; var tmp5 any = tmp4.Ref(); var tmp6 *lang.PersistentVector; lang.PersistentVector_Init(); tmp6 = lang.PersistentVector_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 *lang.PersistentVector; lang.PersistentVector_Init(); tmp8 = lang.PersistentVector_EMPTY; ed__3 = tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(tmp3.Invoke_O_O_O_O_O__O(spec__0, tmp5, tmp7, tmp8.Ref(), x__1), A_arbace_spec_alpha_A_const_106, A_arbace_spec_alpha_A_const_494))
//line :1971:1
		var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_101.GetRawRoot__O()); var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_12, nil); var tmp11 any; var s__1927001093__auto____6 any = jrt.StringWriter_New()




		lang.IFn_Cast(A_arbace_spec_alpha_A_const_95.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_96.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_alpha_A_const_97, s__1927001093__auto____6)); var tmp12 any = A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_New_O_O(s__1927001093__auto____6, ed__3); var tmp13 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_fn_class; if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, false); A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_fn_class = fncls__159d; tmp13 = fncls__159d } else { tmp13 = fncls__159 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil).Invoke__O()
//line :1971:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp9.Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11)).Ref(), ed__3))))
	}
}


func A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_New_O_O(p0, p1 any) *A_arbace_spec_alpha_assert_STAR__fn__1740000960_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_assert_STAR__fn__1740000960_A{}; t.Ctor_O_O(p0, p1); return t }
//line :1976:1
func (t *A_arbace_spec_alpha_assert_STAR__fn__1740000960_A) Ctor_O_O(c__s__1927001093__auto__, c__ed any) { t.F_s__1927001093__auto__ = c__s__1927001093__auto__; t.F_ed = c__ed }
//line :1976:1
func (t *A_arbace_spec_alpha_assert_STAR__fn__1740000960_A) Invoke_O__O(self any) any { var tmp1 any; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_91.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_ed; t.F_ed = nil; tmp3 = t_; tmp2.Invoke_O__O(tmp3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha_A_const_93.GetRawRoot__O()); var tmp5 any; var t__2 any = t.F_s__1927001093__auto__; t.F_s__1927001093__auto__ = nil; tmp5 = t__2; tmp1 = tmp4.Invoke_O__O(tmp5) }; return nil }(); lang.IFn_Cast(A_arbace_spec_alpha_A_const_94.GetRawRoot__O()).Invoke__O(); if tmp6 != nil { panic(tmp6) }; return tmp1 }


func A_arbace_spec_alpha_assert_A_New() *A_arbace_spec_alpha_assert_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_assert_A{}; t.Ctor(); return t }
//line :1979:1
func (t *A_arbace_spec_alpha_assert_A) Ctor() {}
//line :1979:1
func (t *A_arbace_spec_alpha_assert_A) Invoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, spec__2, x__3 any) any {














	if jrt.J2g_Truth(A_arbace_spec_alpha_A_const_495.Get__O()) { return lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_496), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_497), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha_A_const_498), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(spec__2), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(x__3)))), lang.IFn_Cast(A_arbace_spec_alpha_A_const_131.GetRawRoot__O()).Invoke_O__O(x__3))) } else { return x__3
	}
}


























type A_arbace_spec_alpha_A struct{ jrt.Object }

var A_arbace_spec_alpha_A_const_pool *jrt.RefArray

var A_arbace_spec_alpha_A_const_0 *lang.Var

var A_arbace_spec_alpha_A_const_1 *lang.Var

var A_arbace_spec_alpha_A_const_2 any

var A_arbace_spec_alpha_A_const_3 *lang.Keyword

var A_arbace_spec_alpha_A_const_4 any

var A_arbace_spec_alpha_A_const_5 any

var A_arbace_spec_alpha_A_const_6 any

var A_arbace_spec_alpha_A_const_7 any

var A_arbace_spec_alpha_A_const_8 *lang.Var

var A_arbace_spec_alpha_A_const_9 *lang.Var

var A_arbace_spec_alpha_A_const_10 *lang.Var

var A_arbace_spec_alpha_A_const_11 any

var A_arbace_spec_alpha_A_const_12 *lang.Var

var A_arbace_spec_alpha_A_const_13 *lang.Var

var A_arbace_spec_alpha_A_const_14 *jrt.Class

var A_arbace_spec_alpha_A_const_15 *lang.Var

var A_arbace_spec_alpha_A_const_16 *lang.Var

var A_arbace_spec_alpha_A_const_17 *lang.Var

var A_arbace_spec_alpha_A_const_18 *lang.Var

var A_arbace_spec_alpha_A_const_19 *lang.Var

var A_arbace_spec_alpha_A_const_20 *lang.Keyword

var A_arbace_spec_alpha_A_const_21 *lang.Var

var A_arbace_spec_alpha_A_const_22 *lang.Var

var A_arbace_spec_alpha_A_const_23 *lang.Var

var A_arbace_spec_alpha_A_const_24 *lang.Keyword

var A_arbace_spec_alpha_A_const_25 *lang.Var

var A_arbace_spec_alpha_A_const_26 *lang.Var

var A_arbace_spec_alpha_A_const_27 *lang.Var

var A_arbace_spec_alpha_A_const_28 *lang.Var

var A_arbace_spec_alpha_A_const_29 *lang.Var

var A_arbace_spec_alpha_A_const_30 *jrt.Class

var A_arbace_spec_alpha_A_const_31 *lang.Var

var A_arbace_spec_alpha_A_const_32 *lang.Var

var A_arbace_spec_alpha_A_const_33 *lang.Var

var A_arbace_spec_alpha_A_const_34 any

var A_arbace_spec_alpha_A_const_35 *lang.Var

var A_arbace_spec_alpha_A_const_36 *lang.Var

var A_arbace_spec_alpha_A_const_37 *lang.Var

var A_arbace_spec_alpha_A_const_38 *lang.Var

var A_arbace_spec_alpha_A_const_39 *lang.Var

var A_arbace_spec_alpha_A_const_40 *lang.Var

var A_arbace_spec_alpha_A_const_41 *lang.Keyword

var A_arbace_spec_alpha_A_const_42 *lang.Keyword

var A_arbace_spec_alpha_A_const_43 *lang.Var

var A_arbace_spec_alpha_A_const_44 *lang.Var

var A_arbace_spec_alpha_A_const_45 *lang.Var

var A_arbace_spec_alpha_A_const_46 *lang.Var

var A_arbace_spec_alpha_A_const_47 *lang.Var

var A_arbace_spec_alpha_A_const_48 *lang.Var

var A_arbace_spec_alpha_A_const_49 *lang.Var

var A_arbace_spec_alpha_A_const_50 *lang.Var

var A_arbace_spec_alpha_A_const_51 *lang.Keyword

var A_arbace_spec_alpha_A_const_52 any

var A_arbace_spec_alpha_A_const_53 *lang.Var

var A_arbace_spec_alpha_A_const_54 any

var A_arbace_spec_alpha_A_const_55 *lang.Var

var A_arbace_spec_alpha_A_const_56 *lang.Var

var A_arbace_spec_alpha_A_const_57 *lang.Var

var A_arbace_spec_alpha_A_const_58 *lang.Var

var A_arbace_spec_alpha_A_const_59 *lang.Var

var A_arbace_spec_alpha_A_const_60 *lang.Var

var A_arbace_spec_alpha_A_const_61 *lang.Keyword

var A_arbace_spec_alpha_A_const_62 *lang.Var

var A_arbace_spec_alpha_A_const_63 *lang.Var

var A_arbace_spec_alpha_A_const_64 *lang.Keyword

var A_arbace_spec_alpha_A_const_65 *lang.Keyword

var A_arbace_spec_alpha_A_const_66 *lang.Keyword

var A_arbace_spec_alpha_A_const_67 *lang.Var

var A_arbace_spec_alpha_A_const_68 *lang.Var

var A_arbace_spec_alpha_A_const_69 *lang.Var

var A_arbace_spec_alpha_A_const_70 *lang.Var

var A_arbace_spec_alpha_A_const_71 *lang.Var

var A_arbace_spec_alpha_A_const_72 *lang.Keyword

var A_arbace_spec_alpha_A_const_73 *lang.Keyword

var A_arbace_spec_alpha_A_const_74 *lang.Keyword

var A_arbace_spec_alpha_A_const_75 *lang.Keyword

var A_arbace_spec_alpha_A_const_76 *lang.Keyword

var A_arbace_spec_alpha_A_const_77 *lang.Keyword

var A_arbace_spec_alpha_A_const_78 *lang.Var

var A_arbace_spec_alpha_A_const_79 *lang.Var

var A_arbace_spec_alpha_A_const_80 *lang.Var

var A_arbace_spec_alpha_A_const_81 *lang.Var

var A_arbace_spec_alpha_A_const_82 *lang.Var

var A_arbace_spec_alpha_A_const_83 *lang.Var

var A_arbace_spec_alpha_A_const_84 *lang.Var

var A_arbace_spec_alpha_A_const_85 any

var A_arbace_spec_alpha_A_const_86 *lang.Var

var A_arbace_spec_alpha_A_const_87 any

var A_arbace_spec_alpha_A_const_88 any

var A_arbace_spec_alpha_A_const_89 any

var A_arbace_spec_alpha_A_const_90 *lang.Var

var A_arbace_spec_alpha_A_const_91 *lang.Var

var A_arbace_spec_alpha_A_const_92 *lang.Var

var A_arbace_spec_alpha_A_const_93 *lang.Var

var A_arbace_spec_alpha_A_const_94 *lang.Var

var A_arbace_spec_alpha_A_const_95 *lang.Var

var A_arbace_spec_alpha_A_const_96 *lang.Var

var A_arbace_spec_alpha_A_const_97 *lang.Var

var A_arbace_spec_alpha_A_const_98 *lang.Var

var A_arbace_spec_alpha_A_const_99 *lang.Var

var A_arbace_spec_alpha_A_const_100 *lang.Var

var A_arbace_spec_alpha_A_const_101 *lang.Var

var A_arbace_spec_alpha_A_const_102 *lang.Var

var A_arbace_spec_alpha_A_const_103 any

var A_arbace_spec_alpha_A_const_104 *lang.Keyword

var A_arbace_spec_alpha_A_const_105 *lang.Keyword

var A_arbace_spec_alpha_A_const_106 *lang.Keyword

var A_arbace_spec_alpha_A_const_107 *lang.Keyword

var A_arbace_spec_alpha_A_const_108 *lang.Var

var A_arbace_spec_alpha_A_const_109 *lang.Keyword

var A_arbace_spec_alpha_A_const_110 *lang.Var

var A_arbace_spec_alpha_A_const_111 *lang.Var

var A_arbace_spec_alpha_A_const_112 *lang.Var

var A_arbace_spec_alpha_A_const_113 *lang.Var

var A_arbace_spec_alpha_A_const_114 *lang.Var

var A_arbace_spec_alpha_A_const_115 any

var A_arbace_spec_alpha_A_const_116 any

var A_arbace_spec_alpha_A_const_117 any

var A_arbace_spec_alpha_A_const_118 *lang.Var

var A_arbace_spec_alpha_A_const_119 *lang.Var

var A_arbace_spec_alpha_A_const_120 *lang.Var

var A_arbace_spec_alpha_A_const_121 *lang.Var

var A_arbace_spec_alpha_A_const_122 *lang.Var

var A_arbace_spec_alpha_A_const_123 *lang.Var

var A_arbace_spec_alpha_A_const_124 *lang.Var

var A_arbace_spec_alpha_A_const_125 any

var A_arbace_spec_alpha_A_const_126 *lang.Var

var A_arbace_spec_alpha_A_const_127 *lang.Var

var A_arbace_spec_alpha_A_const_128 *lang.Var

var A_arbace_spec_alpha_A_const_129 *lang.Var

var A_arbace_spec_alpha_A_const_130 *lang.Var

var A_arbace_spec_alpha_A_const_131 *lang.Var

var A_arbace_spec_alpha_A_const_132 any

var A_arbace_spec_alpha_A_const_133 any

var A_arbace_spec_alpha_A_const_134 *lang.Var

var A_arbace_spec_alpha_A_const_135 *lang.Keyword

var A_arbace_spec_alpha_A_const_136 any

var A_arbace_spec_alpha_A_const_137 any

var A_arbace_spec_alpha_A_const_138 any

var A_arbace_spec_alpha_A_const_139 *lang.Keyword

var A_arbace_spec_alpha_A_const_140 *lang.Keyword

var A_arbace_spec_alpha_A_const_141 *lang.Keyword

var A_arbace_spec_alpha_A_const_142 *lang.Keyword

var A_arbace_spec_alpha_A_const_143 *lang.Var

var A_arbace_spec_alpha_A_const_144 *lang.Var

var A_arbace_spec_alpha_A_const_145 *lang.Var

var A_arbace_spec_alpha_A_const_146 *lang.Var

var A_arbace_spec_alpha_A_const_147 *lang.Var

var A_arbace_spec_alpha_A_const_148 *lang.Var

var A_arbace_spec_alpha_A_const_149 any

var A_arbace_spec_alpha_A_const_150 any

var A_arbace_spec_alpha_A_const_151 *lang.Var

var A_arbace_spec_alpha_A_const_152 *lang.Var

var A_arbace_spec_alpha_A_const_153 any

var A_arbace_spec_alpha_A_const_154 *lang.Var

var A_arbace_spec_alpha_A_const_155 any

var A_arbace_spec_alpha_A_const_156 *lang.Var

var A_arbace_spec_alpha_A_const_157 any

var A_arbace_spec_alpha_A_const_158 *lang.Var

var A_arbace_spec_alpha_A_const_159 *lang.Var

var A_arbace_spec_alpha_A_const_160 any

var A_arbace_spec_alpha_A_const_161 any

var A_arbace_spec_alpha_A_const_162 any

var A_arbace_spec_alpha_A_const_163 *lang.Keyword

var A_arbace_spec_alpha_A_const_164 *lang.Keyword

var A_arbace_spec_alpha_A_const_165 *lang.Keyword

var A_arbace_spec_alpha_A_const_166 *lang.Keyword

var A_arbace_spec_alpha_A_const_167 *lang.Keyword

var A_arbace_spec_alpha_A_const_168 *lang.Keyword

var A_arbace_spec_alpha_A_const_169 *lang.Keyword

var A_arbace_spec_alpha_A_const_170 *lang.Keyword

var A_arbace_spec_alpha_A_const_171 *lang.Var

var A_arbace_spec_alpha_A_const_172 any

var A_arbace_spec_alpha_A_const_173 *lang.Var

var A_arbace_spec_alpha_A_const_174 any

var A_arbace_spec_alpha_A_const_175 any

var A_arbace_spec_alpha_A_const_176 any

var A_arbace_spec_alpha_A_const_177 any

var A_arbace_spec_alpha_A_const_178 *lang.Keyword

var A_arbace_spec_alpha_A_const_179 *lang.Var

var A_arbace_spec_alpha_A_const_180 *lang.Keyword

var A_arbace_spec_alpha_A_const_181 *lang.Keyword

var A_arbace_spec_alpha_A_const_182 *lang.Keyword

var A_arbace_spec_alpha_A_const_183 *lang.Keyword

var A_arbace_spec_alpha_A_const_184 *lang.Keyword

var A_arbace_spec_alpha_A_const_185 *lang.Keyword

var A_arbace_spec_alpha_A_const_186 *lang.Keyword

var A_arbace_spec_alpha_A_const_187 *lang.Keyword

var A_arbace_spec_alpha_A_const_188 *lang.Var

var A_arbace_spec_alpha_A_const_189 any

var A_arbace_spec_alpha_A_const_190 any

var A_arbace_spec_alpha_A_const_191 any

var A_arbace_spec_alpha_A_const_192 any

var A_arbace_spec_alpha_A_const_193 any

var A_arbace_spec_alpha_A_const_194 any

var A_arbace_spec_alpha_A_const_195 any

var A_arbace_spec_alpha_A_const_196 any

var A_arbace_spec_alpha_A_const_197 any

var A_arbace_spec_alpha_A_const_198 any

var A_arbace_spec_alpha_A_const_199 any

var A_arbace_spec_alpha_A_const_200 any

var A_arbace_spec_alpha_A_const_201 any

var A_arbace_spec_alpha_A_const_202 any

var A_arbace_spec_alpha_A_const_203 any

var A_arbace_spec_alpha_A_const_204 any

var A_arbace_spec_alpha_A_const_205 any

var A_arbace_spec_alpha_A_const_206 *lang.Keyword

var A_arbace_spec_alpha_A_const_207 any

var A_arbace_spec_alpha_A_const_208 any

var A_arbace_spec_alpha_A_const_209 any

var A_arbace_spec_alpha_A_const_210 any

var A_arbace_spec_alpha_A_const_211 any

var A_arbace_spec_alpha_A_const_212 *lang.Keyword

var A_arbace_spec_alpha_A_const_213 any

var A_arbace_spec_alpha_A_const_214 any

var A_arbace_spec_alpha_A_const_215 any

var A_arbace_spec_alpha_A_const_216 any

var A_arbace_spec_alpha_A_const_217 any

var A_arbace_spec_alpha_A_const_218 any

var A_arbace_spec_alpha_A_const_219 *lang.Keyword

var A_arbace_spec_alpha_A_const_220 any

var A_arbace_spec_alpha_A_const_221 any

var A_arbace_spec_alpha_A_const_222 any

var A_arbace_spec_alpha_A_const_223 any

var A_arbace_spec_alpha_A_const_224 any

var A_arbace_spec_alpha_A_const_225 any

var A_arbace_spec_alpha_A_const_226 any

var A_arbace_spec_alpha_A_const_227 any

var A_arbace_spec_alpha_A_const_228 any

var A_arbace_spec_alpha_A_const_229 any

var A_arbace_spec_alpha_A_const_230 any

var A_arbace_spec_alpha_A_const_231 any

var A_arbace_spec_alpha_A_const_232 any

var A_arbace_spec_alpha_A_const_233 any

var A_arbace_spec_alpha_A_const_234 any

var A_arbace_spec_alpha_A_const_235 any

var A_arbace_spec_alpha_A_const_236 *lang.Keyword

var A_arbace_spec_alpha_A_const_237 *lang.Keyword

var A_arbace_spec_alpha_A_const_238 *lang.Keyword

var A_arbace_spec_alpha_A_const_239 any

var A_arbace_spec_alpha_A_const_240 any

var A_arbace_spec_alpha_A_const_241 any

var A_arbace_spec_alpha_A_const_242 any

var A_arbace_spec_alpha_A_const_243 any

var A_arbace_spec_alpha_A_const_244 any

var A_arbace_spec_alpha_A_const_245 *lang.Var

var A_arbace_spec_alpha_A_const_246 *lang.Var

var A_arbace_spec_alpha_A_const_247 *lang.Var

var A_arbace_spec_alpha_A_const_248 *lang.Keyword

var A_arbace_spec_alpha_A_const_249 any

var A_arbace_spec_alpha_A_const_250 any

var A_arbace_spec_alpha_A_const_251 *lang.Var

var A_arbace_spec_alpha_A_const_252 *lang.Var

var A_arbace_spec_alpha_A_const_253 *lang.Var

var A_arbace_spec_alpha_A_const_254 *lang.Var

var A_arbace_spec_alpha_A_const_255 *lang.Var

var A_arbace_spec_alpha_A_const_256 any

var A_arbace_spec_alpha_A_const_257 *lang.Var

var A_arbace_spec_alpha_A_const_258 any

var A_arbace_spec_alpha_A_const_259 *lang.Var

var A_arbace_spec_alpha_A_const_260 any

var A_arbace_spec_alpha_A_const_261 *lang.Var

var A_arbace_spec_alpha_A_const_262 *lang.Var

var A_arbace_spec_alpha_A_const_263 *lang.Var

var A_arbace_spec_alpha_A_const_264 *lang.Var

var A_arbace_spec_alpha_A_const_265 *lang.Var

var A_arbace_spec_alpha_A_const_266 *lang.Var

var A_arbace_spec_alpha_A_const_267 *lang.Var

var A_arbace_spec_alpha_A_const_268 *lang.Var

var A_arbace_spec_alpha_A_const_269 any

var A_arbace_spec_alpha_A_const_270 *lang.Var

var A_arbace_spec_alpha_A_const_271 *lang.Var

var A_arbace_spec_alpha_A_const_272 *lang.Var

var A_arbace_spec_alpha_A_const_273 *lang.Var

var A_arbace_spec_alpha_A_const_274 *lang.Var

var A_arbace_spec_alpha_A_const_275 *lang.Var

var A_arbace_spec_alpha_A_const_276 *lang.Var

var A_arbace_spec_alpha_A_const_277 *lang.Var

var A_arbace_spec_alpha_A_const_278 *lang.Var

var A_arbace_spec_alpha_A_const_279 any

var A_arbace_spec_alpha_A_const_280 *lang.Var

var A_arbace_spec_alpha_A_const_281 *lang.Var

var A_arbace_spec_alpha_A_const_282 *lang.Var

var A_arbace_spec_alpha_A_const_283 *lang.Var

var A_arbace_spec_alpha_A_const_284 *lang.Var

var A_arbace_spec_alpha_A_const_285 *lang.Var

var A_arbace_spec_alpha_A_const_286 *lang.Var

var A_arbace_spec_alpha_A_const_287 any

var A_arbace_spec_alpha_A_const_288 *lang.Var

var A_arbace_spec_alpha_A_const_289 *lang.Var

var A_arbace_spec_alpha_A_const_290 any

var A_arbace_spec_alpha_A_const_291 *lang.Var

var A_arbace_spec_alpha_A_const_292 *lang.Var

var A_arbace_spec_alpha_A_const_293 any

var A_arbace_spec_alpha_A_const_294 *lang.Var

var A_arbace_spec_alpha_A_const_295 *lang.Var

var A_arbace_spec_alpha_A_const_296 *lang.Var

var A_arbace_spec_alpha_A_const_297 any

var A_arbace_spec_alpha_A_const_298 any

var A_arbace_spec_alpha_A_const_299 any

var A_arbace_spec_alpha_A_const_300 any

var A_arbace_spec_alpha_A_const_301 any

var A_arbace_spec_alpha_A_const_302 *lang.Var

var A_arbace_spec_alpha_A_const_303 any

var A_arbace_spec_alpha_A_const_304 *lang.Var

var A_arbace_spec_alpha_A_const_305 any

var A_arbace_spec_alpha_A_const_306 *lang.Var

var A_arbace_spec_alpha_A_const_307 *lang.Var

var A_arbace_spec_alpha_A_const_308 *lang.Var

var A_arbace_spec_alpha_A_const_309 *lang.Var

var A_arbace_spec_alpha_A_const_310 any

var A_arbace_spec_alpha_A_const_311 *lang.Var

var A_arbace_spec_alpha_A_const_312 *lang.Var

var A_arbace_spec_alpha_A_const_313 *lang.Var

var A_arbace_spec_alpha_A_const_314 *lang.Var

var A_arbace_spec_alpha_A_const_315 any

var A_arbace_spec_alpha_A_const_316 *lang.Var

var A_arbace_spec_alpha_A_const_317 any

var A_arbace_spec_alpha_A_const_318 any

var A_arbace_spec_alpha_A_const_319 any

var A_arbace_spec_alpha_A_const_320 *lang.Var

var A_arbace_spec_alpha_A_const_321 any

var A_arbace_spec_alpha_A_const_322 any

var A_arbace_spec_alpha_A_const_323 any

var A_arbace_spec_alpha_A_const_324 any

var A_arbace_spec_alpha_A_const_325 *lang.Var

var A_arbace_spec_alpha_A_const_326 any

var A_arbace_spec_alpha_A_const_327 *lang.Keyword

var A_arbace_spec_alpha_A_const_328 *lang.Var

var A_arbace_spec_alpha_A_const_329 *lang.Var

var A_arbace_spec_alpha_A_const_330 *lang.Var

var A_arbace_spec_alpha_A_const_331 *lang.Var

var A_arbace_spec_alpha_A_const_332 any

var A_arbace_spec_alpha_A_const_333 *lang.Var

var A_arbace_spec_alpha_A_const_334 *lang.Var

var A_arbace_spec_alpha_A_const_335 *lang.Var

var A_arbace_spec_alpha_A_const_336 *lang.Keyword

var A_arbace_spec_alpha_A_const_337 *lang.Keyword

var A_arbace_spec_alpha_A_const_338 *lang.Keyword

var A_arbace_spec_alpha_A_const_339 *lang.Keyword

var A_arbace_spec_alpha_A_const_340 *lang.Var

var A_arbace_spec_alpha_A_const_341 *lang.Var

var A_arbace_spec_alpha_A_const_342 *lang.Var

var A_arbace_spec_alpha_A_const_343 *lang.Var

var A_arbace_spec_alpha_A_const_344 *lang.Var

var A_arbace_spec_alpha_A_const_345 *lang.Keyword

var A_arbace_spec_alpha_A_const_346 *lang.Keyword

var A_arbace_spec_alpha_A_const_347 *lang.Keyword

var A_arbace_spec_alpha_A_const_348 *lang.Keyword

var A_arbace_spec_alpha_A_const_349 *lang.Keyword

var A_arbace_spec_alpha_A_const_350 *lang.Var

var A_arbace_spec_alpha_A_const_351 *lang.Var

var A_arbace_spec_alpha_A_const_352 *lang.Var

var A_arbace_spec_alpha_A_const_353 *lang.Keyword

var A_arbace_spec_alpha_A_const_354 *lang.Keyword

var A_arbace_spec_alpha_A_const_355 *lang.Keyword

var A_arbace_spec_alpha_A_const_356 *lang.Keyword

var A_arbace_spec_alpha_A_const_357 *lang.Keyword

var A_arbace_spec_alpha_A_const_358 *lang.Keyword

var A_arbace_spec_alpha_A_const_359 *lang.Var

var A_arbace_spec_alpha_A_const_360 any

var A_arbace_spec_alpha_A_const_361 *lang.Keyword

var A_arbace_spec_alpha_A_const_362 *lang.Keyword

var A_arbace_spec_alpha_A_const_363 *lang.Var

var A_arbace_spec_alpha_A_const_364 *lang.Var

var A_arbace_spec_alpha_A_const_365 *lang.Keyword

var A_arbace_spec_alpha_A_const_366 *lang.Var

var A_arbace_spec_alpha_A_const_367 *lang.Var

var A_arbace_spec_alpha_A_const_368 *lang.Keyword

var A_arbace_spec_alpha_A_const_369 *lang.Keyword

var A_arbace_spec_alpha_A_const_370 any

var A_arbace_spec_alpha_A_const_371 *lang.Var

var A_arbace_spec_alpha_A_const_372 *lang.Var

var A_arbace_spec_alpha_A_const_373 *lang.Var

var A_arbace_spec_alpha_A_const_374 *lang.Var

var A_arbace_spec_alpha_A_const_375 *lang.Var

var A_arbace_spec_alpha_A_const_376 *lang.Var

var A_arbace_spec_alpha_A_const_377 *lang.Var

var A_arbace_spec_alpha_A_const_378 *lang.Var

var A_arbace_spec_alpha_A_const_379 *lang.Var

var A_arbace_spec_alpha_A_const_380 *lang.Var

var A_arbace_spec_alpha_A_const_381 any

var A_arbace_spec_alpha_A_const_382 any

var A_arbace_spec_alpha_A_const_383 any

var A_arbace_spec_alpha_A_const_384 any

var A_arbace_spec_alpha_A_const_385 any

var A_arbace_spec_alpha_A_const_386 *lang.Keyword

var A_arbace_spec_alpha_A_const_387 any

var A_arbace_spec_alpha_A_const_388 any

var A_arbace_spec_alpha_A_const_389 *lang.Var

var A_arbace_spec_alpha_A_const_390 *lang.Var

var A_arbace_spec_alpha_A_const_391 *lang.Var

var A_arbace_spec_alpha_A_const_392 *lang.Keyword

var A_arbace_spec_alpha_A_const_393 *lang.Var

var A_arbace_spec_alpha_A_const_394 *lang.Var

var A_arbace_spec_alpha_A_const_395 any

var A_arbace_spec_alpha_A_const_396 any

var A_arbace_spec_alpha_A_const_397 any

var A_arbace_spec_alpha_A_const_398 any

var A_arbace_spec_alpha_A_const_399 any

var A_arbace_spec_alpha_A_const_400 *lang.Var

var A_arbace_spec_alpha_A_const_401 *lang.Var

var A_arbace_spec_alpha_A_const_402 *lang.Var

var A_arbace_spec_alpha_A_const_403 *lang.Keyword

var A_arbace_spec_alpha_A_const_404 *lang.Keyword

var A_arbace_spec_alpha_A_const_405 *lang.Var

var A_arbace_spec_alpha_A_const_406 any

var A_arbace_spec_alpha_A_const_407 *lang.Var

var A_arbace_spec_alpha_A_const_408 *lang.Var

var A_arbace_spec_alpha_A_const_409 any

var A_arbace_spec_alpha_A_const_410 *lang.Var

var A_arbace_spec_alpha_A_const_411 any

var A_arbace_spec_alpha_A_const_412 any

var A_arbace_spec_alpha_A_const_413 *lang.Var

var A_arbace_spec_alpha_A_const_414 *lang.Var

var A_arbace_spec_alpha_A_const_415 *lang.Keyword

var A_arbace_spec_alpha_A_const_416 *lang.Keyword

var A_arbace_spec_alpha_A_const_417 any

var A_arbace_spec_alpha_A_const_418 any

var A_arbace_spec_alpha_A_const_419 any

var A_arbace_spec_alpha_A_const_420 any

var A_arbace_spec_alpha_A_const_421 any

var A_arbace_spec_alpha_A_const_422 any

var A_arbace_spec_alpha_A_const_423 any

var A_arbace_spec_alpha_A_const_424 any

var A_arbace_spec_alpha_A_const_425 any

var A_arbace_spec_alpha_A_const_426 *lang.Keyword

var A_arbace_spec_alpha_A_const_427 any

var A_arbace_spec_alpha_A_const_428 any

var A_arbace_spec_alpha_A_const_429 any

var A_arbace_spec_alpha_A_const_430 any

var A_arbace_spec_alpha_A_const_431 any

var A_arbace_spec_alpha_A_const_432 any

var A_arbace_spec_alpha_A_const_433 any

var A_arbace_spec_alpha_A_const_434 any

var A_arbace_spec_alpha_A_const_435 *lang.Var

var A_arbace_spec_alpha_A_const_436 any

var A_arbace_spec_alpha_A_const_437 *lang.Var

var A_arbace_spec_alpha_A_const_438 *lang.Var

var A_arbace_spec_alpha_A_const_439 any

var A_arbace_spec_alpha_A_const_440 *lang.Keyword

var A_arbace_spec_alpha_A_const_441 any

var A_arbace_spec_alpha_A_const_442 any

var A_arbace_spec_alpha_A_const_443 *lang.Var

var A_arbace_spec_alpha_A_const_444 *lang.Var

var A_arbace_spec_alpha_A_const_445 any

var A_arbace_spec_alpha_A_const_446 *lang.Var

var A_arbace_spec_alpha_A_const_447 *lang.Var

var A_arbace_spec_alpha_A_const_448 *lang.Var

var A_arbace_spec_alpha_A_const_449 *lang.Var

var A_arbace_spec_alpha_A_const_450 *lang.Var

var A_arbace_spec_alpha_A_const_451 *lang.Var

var A_arbace_spec_alpha_A_const_452 *lang.Var

var A_arbace_spec_alpha_A_const_453 any

var A_arbace_spec_alpha_A_const_454 any

var A_arbace_spec_alpha_A_const_455 any

var A_arbace_spec_alpha_A_const_456 any

var A_arbace_spec_alpha_A_const_457 any

var A_arbace_spec_alpha_A_const_458 any

var A_arbace_spec_alpha_A_const_459 any

var A_arbace_spec_alpha_A_const_460 any

var A_arbace_spec_alpha_A_const_461 any

var A_arbace_spec_alpha_A_const_462 *lang.Keyword

var A_arbace_spec_alpha_A_const_463 any

var A_arbace_spec_alpha_A_const_464 any

var A_arbace_spec_alpha_A_const_465 any

var A_arbace_spec_alpha_A_const_466 any

var A_arbace_spec_alpha_A_const_467 any

var A_arbace_spec_alpha_A_const_468 any

var A_arbace_spec_alpha_A_const_469 any

var A_arbace_spec_alpha_A_const_470 any

var A_arbace_spec_alpha_A_const_471 any

var A_arbace_spec_alpha_A_const_472 *lang.Keyword

var A_arbace_spec_alpha_A_const_473 *lang.Keyword

var A_arbace_spec_alpha_A_const_474 *lang.Var

var A_arbace_spec_alpha_A_const_475 any

var A_arbace_spec_alpha_A_const_476 any

var A_arbace_spec_alpha_A_const_477 any

var A_arbace_spec_alpha_A_const_478 any

var A_arbace_spec_alpha_A_const_479 any

var A_arbace_spec_alpha_A_const_480 any

var A_arbace_spec_alpha_A_const_481 any

var A_arbace_spec_alpha_A_const_482 *lang.Keyword

var A_arbace_spec_alpha_A_const_483 *lang.Keyword

var A_arbace_spec_alpha_A_const_484 any

var A_arbace_spec_alpha_A_const_485 any

var A_arbace_spec_alpha_A_const_486 any

var A_arbace_spec_alpha_A_const_487 any

var A_arbace_spec_alpha_A_const_488 any

var A_arbace_spec_alpha_A_const_489 any

var A_arbace_spec_alpha_A_const_490 any

var A_arbace_spec_alpha_A_const_491 any

var A_arbace_spec_alpha_A_const_492 any

var A_arbace_spec_alpha_A_const_493 any

var A_arbace_spec_alpha_A_const_494 *lang.Keyword

var A_arbace_spec_alpha_A_const_495 *lang.Var

var A_arbace_spec_alpha_A_const_496 any

var A_arbace_spec_alpha_A_const_497 any

var A_arbace_spec_alpha_A_const_498 any

var A_arbace_spec_alpha_A_init jrt.ClassInit

func A_arbace_spec_alpha_A_Init() { if !A_arbace_spec_alpha_A_init.Done() { A_arbace_spec_alpha_A_init.Run(A_arbace_spec_alpha_A_clinit) } }

func A_arbace_spec_alpha_A_clinit() { A_arbace_spec_alpha_A_clinit_p0(); A_arbace_spec_alpha_A_clinit_p1(); A_arbace_spec_alpha_A_clinit_p2(); A_arbace_spec_alpha_A_clinit_p3(); A_arbace_spec_alpha_A_clinit_p4(); A_arbace_spec_alpha_A_clinit_p5(); A_arbace_spec_alpha_A_clinit_p6(); A_arbace_spec_alpha_A_clinit_p7(); A_arbace_spec_alpha_A_clinit_p8(); A_arbace_spec_alpha_A_clinit_p9(); A_arbace_spec_alpha_A_clinit_p10(); A_arbace_spec_alpha_A_clinit_p11(); A_arbace_spec_alpha_A_clinit_p12(); A_arbace_spec_alpha_A_clinit_p13(); A_arbace_spec_alpha_A_clinit_p14(); A_arbace_spec_alpha_A_clinit_p15(); A_arbace_spec_alpha_A_clinit_p16(); A_arbace_spec_alpha_A_clinit_p17(); A_arbace_spec_alpha_A_clinit_p18(); A_arbace_spec_alpha_A_clinit_p19(); A_arbace_spec_alpha_A_clinit_p20(); A_arbace_spec_alpha_A_clinit_p21(); A_arbace_spec_alpha_A_clinit_p22(); A_arbace_spec_alpha_A_clinit_p23(); A_arbace_spec_alpha_A_clinit_p24(); A_arbace_spec_alpha_A_clinit_p25(); A_arbace_spec_alpha_A_clinit_p26(); A_arbace_spec_alpha_A_clinit_p27(); A_arbace_spec_alpha_A_clinit_p28(); A_arbace_spec_alpha_A_clinit_p29(); A_arbace_spec_alpha_A_clinit_p30(); A_arbace_spec_alpha_A_clinit_p31(); A_arbace_spec_alpha_A_clinit_p32(); A_arbace_spec_alpha_A_clinit_p33(); A_arbace_spec_alpha_A_clinit_p34(); A_arbace_spec_alpha_A_clinit_p35(); A_arbace_spec_alpha_A_clinit_p36(); A_arbace_spec_alpha_A_clinit_p37(); A_arbace_spec_alpha_A_clinit_p38() }

func A_arbace_spec_alpha_A_clinit_p0() { A_arbace_spec_alpha_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 735); A_arbace_spec_alpha_A_const_0 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[236]); A_arbace_spec_alpha_A_const_1 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[237]); A_arbace_spec_alpha_A_const_2 = A_arbace_spec_alpha_A_const_pool.A[238]; A_arbace_spec_alpha_A_const_3 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[239]); A_arbace_spec_alpha_A_const_4 = A_arbace_spec_alpha_A_const_pool.A[240]; A_arbace_spec_alpha_A_const_5 = A_arbace_spec_alpha_A_const_pool.A[241]; A_arbace_spec_alpha_A_const_6 = A_arbace_spec_alpha_A_const_pool.A[242]; A_arbace_spec_alpha_A_const_7 = A_arbace_spec_alpha_A_const_pool.A[243]; A_arbace_spec_alpha_A_const_8 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[244]); A_arbace_spec_alpha_A_const_9 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[245]); A_arbace_spec_alpha_A_const_10 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[246]); A_arbace_spec_alpha_A_const_11 = A_arbace_spec_alpha_A_const_pool.A[247]; A_arbace_spec_alpha_A_const_12 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[248]) }

func A_arbace_spec_alpha_A_clinit_p1() { A_arbace_spec_alpha_A_const_13 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[249]); A_arbace_spec_alpha_A_const_14 = jrt.Class_Cast(A_arbace_spec_alpha_A_const_pool.A[250]); A_arbace_spec_alpha_A_const_15 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[251]); A_arbace_spec_alpha_A_const_16 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[252]); A_arbace_spec_alpha_A_const_17 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[253]); A_arbace_spec_alpha_A_const_18 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[254]); A_arbace_spec_alpha_A_const_19 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[255]); A_arbace_spec_alpha_A_const_20 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[256]); A_arbace_spec_alpha_A_const_21 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[257]); A_arbace_spec_alpha_A_const_22 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[258]); A_arbace_spec_alpha_A_const_23 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[259]); A_arbace_spec_alpha_A_const_24 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[260]) }

func A_arbace_spec_alpha_A_clinit_p2() { A_arbace_spec_alpha_A_const_25 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[261]); A_arbace_spec_alpha_A_const_26 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[262]); A_arbace_spec_alpha_A_const_27 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[263]); A_arbace_spec_alpha_A_const_28 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[264]); A_arbace_spec_alpha_A_const_29 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[265]); A_arbace_spec_alpha_A_const_30 = jrt.Class_Cast(A_arbace_spec_alpha_A_const_pool.A[266]); A_arbace_spec_alpha_A_const_31 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[267]); A_arbace_spec_alpha_A_const_32 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[268]); A_arbace_spec_alpha_A_const_33 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[269]); A_arbace_spec_alpha_A_const_34 = A_arbace_spec_alpha_A_const_pool.A[270]; A_arbace_spec_alpha_A_const_35 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[271]); A_arbace_spec_alpha_A_const_36 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[272]) }

func A_arbace_spec_alpha_A_clinit_p3() { A_arbace_spec_alpha_A_const_37 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[273]); A_arbace_spec_alpha_A_const_38 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[274]); A_arbace_spec_alpha_A_const_39 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[275]); A_arbace_spec_alpha_A_const_40 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[276]); A_arbace_spec_alpha_A_const_41 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[277]); A_arbace_spec_alpha_A_const_42 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[278]); A_arbace_spec_alpha_A_const_43 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[279]); A_arbace_spec_alpha_A_const_44 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[280]); A_arbace_spec_alpha_A_const_45 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[281]); A_arbace_spec_alpha_A_const_46 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[282]); A_arbace_spec_alpha_A_const_47 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[283]); A_arbace_spec_alpha_A_const_48 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[284]) }

func A_arbace_spec_alpha_A_clinit_p4() { A_arbace_spec_alpha_A_const_49 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[285]); A_arbace_spec_alpha_A_const_50 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[286]); A_arbace_spec_alpha_A_const_51 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[287]); A_arbace_spec_alpha_A_const_52 = A_arbace_spec_alpha_A_const_pool.A[288]; A_arbace_spec_alpha_A_const_53 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[289]); A_arbace_spec_alpha_A_const_54 = A_arbace_spec_alpha_A_const_pool.A[290]; A_arbace_spec_alpha_A_const_55 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[291]); A_arbace_spec_alpha_A_const_56 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[292]); A_arbace_spec_alpha_A_const_57 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[293]); A_arbace_spec_alpha_A_const_58 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[294]); A_arbace_spec_alpha_A_const_59 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[295]); A_arbace_spec_alpha_A_const_60 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[296]) }

func A_arbace_spec_alpha_A_clinit_p5() { A_arbace_spec_alpha_A_const_61 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[297]); A_arbace_spec_alpha_A_const_62 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[298]); A_arbace_spec_alpha_A_const_63 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[299]); A_arbace_spec_alpha_A_const_64 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[300]); A_arbace_spec_alpha_A_const_65 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[301]); A_arbace_spec_alpha_A_const_66 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[302]); A_arbace_spec_alpha_A_const_67 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[303]); A_arbace_spec_alpha_A_const_68 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[304]); A_arbace_spec_alpha_A_const_69 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[305]); A_arbace_spec_alpha_A_const_70 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[306]); A_arbace_spec_alpha_A_const_71 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[307]); A_arbace_spec_alpha_A_const_72 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[308]) }

func A_arbace_spec_alpha_A_clinit_p6() { A_arbace_spec_alpha_A_const_73 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[309]); A_arbace_spec_alpha_A_const_74 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[310]); A_arbace_spec_alpha_A_const_75 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[311]); A_arbace_spec_alpha_A_const_76 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[312]); A_arbace_spec_alpha_A_const_77 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[313]); A_arbace_spec_alpha_A_const_78 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[314]); A_arbace_spec_alpha_A_const_79 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[315]); A_arbace_spec_alpha_A_const_80 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[316]); A_arbace_spec_alpha_A_const_81 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[317]); A_arbace_spec_alpha_A_const_82 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[318]); A_arbace_spec_alpha_A_const_83 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[319]); A_arbace_spec_alpha_A_const_84 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[320]) }

func A_arbace_spec_alpha_A_clinit_p7() { A_arbace_spec_alpha_A_const_85 = A_arbace_spec_alpha_A_const_pool.A[321]; A_arbace_spec_alpha_A_const_86 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[322]); A_arbace_spec_alpha_A_const_87 = A_arbace_spec_alpha_A_const_pool.A[323]; A_arbace_spec_alpha_A_const_88 = A_arbace_spec_alpha_A_const_pool.A[324]; A_arbace_spec_alpha_A_const_89 = A_arbace_spec_alpha_A_const_pool.A[325]; A_arbace_spec_alpha_A_const_90 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[326]); A_arbace_spec_alpha_A_const_91 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[327]); A_arbace_spec_alpha_A_const_92 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[328]); A_arbace_spec_alpha_A_const_93 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[329]); A_arbace_spec_alpha_A_const_94 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[330]); A_arbace_spec_alpha_A_const_95 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[331]); A_arbace_spec_alpha_A_const_96 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[332]); A_arbace_spec_alpha_A_const_97 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[333]) }

func A_arbace_spec_alpha_A_clinit_p8() { A_arbace_spec_alpha_A_const_98 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[334]); A_arbace_spec_alpha_A_const_99 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[335]); A_arbace_spec_alpha_A_const_100 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[336]); A_arbace_spec_alpha_A_const_101 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[337]); A_arbace_spec_alpha_A_const_102 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[338]); A_arbace_spec_alpha_A_const_103 = A_arbace_spec_alpha_A_const_pool.A[339]; A_arbace_spec_alpha_A_const_104 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[340]); A_arbace_spec_alpha_A_const_105 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[341]); A_arbace_spec_alpha_A_const_106 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[342]); A_arbace_spec_alpha_A_const_107 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[343]); A_arbace_spec_alpha_A_const_108 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[344]); A_arbace_spec_alpha_A_const_109 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[345]) }

func A_arbace_spec_alpha_A_clinit_p9() { A_arbace_spec_alpha_A_const_110 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[346]); A_arbace_spec_alpha_A_const_111 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[347]); A_arbace_spec_alpha_A_const_112 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[348]); A_arbace_spec_alpha_A_const_113 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[349]); A_arbace_spec_alpha_A_const_114 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[350]); A_arbace_spec_alpha_A_const_115 = A_arbace_spec_alpha_A_const_pool.A[351]; A_arbace_spec_alpha_A_const_116 = A_arbace_spec_alpha_A_const_pool.A[352]; A_arbace_spec_alpha_A_const_117 = A_arbace_spec_alpha_A_const_pool.A[353]; A_arbace_spec_alpha_A_const_118 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[354]); A_arbace_spec_alpha_A_const_119 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[355]); A_arbace_spec_alpha_A_const_120 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[356]); A_arbace_spec_alpha_A_const_121 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[357]) }

func A_arbace_spec_alpha_A_clinit_p10() { A_arbace_spec_alpha_A_const_122 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[358]); A_arbace_spec_alpha_A_const_123 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[359]); A_arbace_spec_alpha_A_const_124 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[360]); A_arbace_spec_alpha_A_const_125 = A_arbace_spec_alpha_A_const_pool.A[361]; A_arbace_spec_alpha_A_const_126 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[362]); A_arbace_spec_alpha_A_const_127 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[363]); A_arbace_spec_alpha_A_const_128 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[364]); A_arbace_spec_alpha_A_const_129 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[365]); A_arbace_spec_alpha_A_const_130 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[366]); A_arbace_spec_alpha_A_const_131 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[367]); A_arbace_spec_alpha_A_const_132 = A_arbace_spec_alpha_A_const_pool.A[368]; A_arbace_spec_alpha_A_const_133 = A_arbace_spec_alpha_A_const_pool.A[369] }

func A_arbace_spec_alpha_A_clinit_p11() { A_arbace_spec_alpha_A_const_134 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[370]); A_arbace_spec_alpha_A_const_135 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[371]); A_arbace_spec_alpha_A_const_136 = A_arbace_spec_alpha_A_const_pool.A[372]; A_arbace_spec_alpha_A_const_137 = A_arbace_spec_alpha_A_const_pool.A[373]; A_arbace_spec_alpha_A_const_138 = A_arbace_spec_alpha_A_const_pool.A[374]; A_arbace_spec_alpha_A_const_139 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[375]); A_arbace_spec_alpha_A_const_140 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[376]); A_arbace_spec_alpha_A_const_141 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[377]); A_arbace_spec_alpha_A_const_142 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[378]); A_arbace_spec_alpha_A_const_143 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[379]); A_arbace_spec_alpha_A_const_144 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[380]); A_arbace_spec_alpha_A_const_145 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[381]) }

func A_arbace_spec_alpha_A_clinit_p12() { A_arbace_spec_alpha_A_const_146 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[382]); A_arbace_spec_alpha_A_const_147 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[383]); A_arbace_spec_alpha_A_const_148 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[384]); A_arbace_spec_alpha_A_const_149 = A_arbace_spec_alpha_A_const_pool.A[385]; A_arbace_spec_alpha_A_const_150 = A_arbace_spec_alpha_A_const_pool.A[386]; A_arbace_spec_alpha_A_const_151 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[387]); A_arbace_spec_alpha_A_const_152 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[388]); A_arbace_spec_alpha_A_const_153 = A_arbace_spec_alpha_A_const_pool.A[389]; A_arbace_spec_alpha_A_const_154 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[390]); A_arbace_spec_alpha_A_const_155 = A_arbace_spec_alpha_A_const_pool.A[391]; A_arbace_spec_alpha_A_const_156 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[392]); A_arbace_spec_alpha_A_const_157 = A_arbace_spec_alpha_A_const_pool.A[393]; A_arbace_spec_alpha_A_const_158 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[394]) }

func A_arbace_spec_alpha_A_clinit_p13() { A_arbace_spec_alpha_A_const_159 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[395]); A_arbace_spec_alpha_A_const_160 = A_arbace_spec_alpha_A_const_pool.A[396]; A_arbace_spec_alpha_A_const_161 = A_arbace_spec_alpha_A_const_pool.A[397]; A_arbace_spec_alpha_A_const_162 = A_arbace_spec_alpha_A_const_pool.A[398]; A_arbace_spec_alpha_A_const_163 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[399]); A_arbace_spec_alpha_A_const_164 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[400]); A_arbace_spec_alpha_A_const_165 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[401]); A_arbace_spec_alpha_A_const_166 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[402]); A_arbace_spec_alpha_A_const_167 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[403]); A_arbace_spec_alpha_A_const_168 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[404]); A_arbace_spec_alpha_A_const_169 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[405]); A_arbace_spec_alpha_A_const_170 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[406]) }

func A_arbace_spec_alpha_A_clinit_p14() { A_arbace_spec_alpha_A_const_171 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[407]); A_arbace_spec_alpha_A_const_172 = A_arbace_spec_alpha_A_const_pool.A[408]; A_arbace_spec_alpha_A_const_173 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[409]); A_arbace_spec_alpha_A_const_174 = A_arbace_spec_alpha_A_const_pool.A[410]; A_arbace_spec_alpha_A_const_175 = A_arbace_spec_alpha_A_const_pool.A[411]; A_arbace_spec_alpha_A_const_176 = A_arbace_spec_alpha_A_const_pool.A[412]; A_arbace_spec_alpha_A_const_177 = A_arbace_spec_alpha_A_const_pool.A[413]; A_arbace_spec_alpha_A_const_178 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[414]); A_arbace_spec_alpha_A_const_179 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[415]); A_arbace_spec_alpha_A_const_180 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[416]); A_arbace_spec_alpha_A_const_181 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[417]); A_arbace_spec_alpha_A_const_182 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[418]); A_arbace_spec_alpha_A_const_183 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[419]) }

func A_arbace_spec_alpha_A_clinit_p15() { A_arbace_spec_alpha_A_const_184 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[420]); A_arbace_spec_alpha_A_const_185 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[421]); A_arbace_spec_alpha_A_const_186 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[422]); A_arbace_spec_alpha_A_const_187 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[423]); A_arbace_spec_alpha_A_const_188 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[424]); A_arbace_spec_alpha_A_const_189 = A_arbace_spec_alpha_A_const_pool.A[425]; A_arbace_spec_alpha_A_const_190 = A_arbace_spec_alpha_A_const_pool.A[426]; A_arbace_spec_alpha_A_const_191 = A_arbace_spec_alpha_A_const_pool.A[427]; A_arbace_spec_alpha_A_const_192 = A_arbace_spec_alpha_A_const_pool.A[428]; A_arbace_spec_alpha_A_const_193 = A_arbace_spec_alpha_A_const_pool.A[429]; A_arbace_spec_alpha_A_const_194 = A_arbace_spec_alpha_A_const_pool.A[430]; A_arbace_spec_alpha_A_const_195 = A_arbace_spec_alpha_A_const_pool.A[431]; A_arbace_spec_alpha_A_const_196 = A_arbace_spec_alpha_A_const_pool.A[432]; A_arbace_spec_alpha_A_const_197 = A_arbace_spec_alpha_A_const_pool.A[433] }

func A_arbace_spec_alpha_A_clinit_p16() { A_arbace_spec_alpha_A_const_198 = A_arbace_spec_alpha_A_const_pool.A[434]; A_arbace_spec_alpha_A_const_199 = A_arbace_spec_alpha_A_const_pool.A[435]; A_arbace_spec_alpha_A_const_200 = A_arbace_spec_alpha_A_const_pool.A[436]; A_arbace_spec_alpha_A_const_201 = A_arbace_spec_alpha_A_const_pool.A[437]; A_arbace_spec_alpha_A_const_202 = A_arbace_spec_alpha_A_const_pool.A[438]; A_arbace_spec_alpha_A_const_203 = A_arbace_spec_alpha_A_const_pool.A[439]; A_arbace_spec_alpha_A_const_204 = A_arbace_spec_alpha_A_const_pool.A[440]; A_arbace_spec_alpha_A_const_205 = A_arbace_spec_alpha_A_const_pool.A[441]; A_arbace_spec_alpha_A_const_206 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[442]); A_arbace_spec_alpha_A_const_207 = A_arbace_spec_alpha_A_const_pool.A[443]; A_arbace_spec_alpha_A_const_208 = A_arbace_spec_alpha_A_const_pool.A[444]; A_arbace_spec_alpha_A_const_209 = A_arbace_spec_alpha_A_const_pool.A[445]; A_arbace_spec_alpha_A_const_210 = A_arbace_spec_alpha_A_const_pool.A[446]; A_arbace_spec_alpha_A_const_211 = A_arbace_spec_alpha_A_const_pool.A[447]; A_arbace_spec_alpha_A_const_212 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[448]) }

func A_arbace_spec_alpha_A_clinit_p17() { A_arbace_spec_alpha_A_const_213 = A_arbace_spec_alpha_A_const_pool.A[449]; A_arbace_spec_alpha_A_const_214 = A_arbace_spec_alpha_A_const_pool.A[450]; A_arbace_spec_alpha_A_const_215 = A_arbace_spec_alpha_A_const_pool.A[451]; A_arbace_spec_alpha_A_const_216 = A_arbace_spec_alpha_A_const_pool.A[452]; A_arbace_spec_alpha_A_const_217 = A_arbace_spec_alpha_A_const_pool.A[453]; A_arbace_spec_alpha_A_const_218 = A_arbace_spec_alpha_A_const_pool.A[454]; A_arbace_spec_alpha_A_const_219 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[455]); A_arbace_spec_alpha_A_const_220 = A_arbace_spec_alpha_A_const_pool.A[456]; A_arbace_spec_alpha_A_const_221 = A_arbace_spec_alpha_A_const_pool.A[457]; A_arbace_spec_alpha_A_const_222 = A_arbace_spec_alpha_A_const_pool.A[458]; A_arbace_spec_alpha_A_const_223 = A_arbace_spec_alpha_A_const_pool.A[459]; A_arbace_spec_alpha_A_const_224 = A_arbace_spec_alpha_A_const_pool.A[460]; A_arbace_spec_alpha_A_const_225 = A_arbace_spec_alpha_A_const_pool.A[461]; A_arbace_spec_alpha_A_const_226 = A_arbace_spec_alpha_A_const_pool.A[462]; A_arbace_spec_alpha_A_const_227 = A_arbace_spec_alpha_A_const_pool.A[463] }

func A_arbace_spec_alpha_A_clinit_p18() { A_arbace_spec_alpha_A_const_228 = A_arbace_spec_alpha_A_const_pool.A[464]; A_arbace_spec_alpha_A_const_229 = A_arbace_spec_alpha_A_const_pool.A[465]; A_arbace_spec_alpha_A_const_230 = A_arbace_spec_alpha_A_const_pool.A[466]; A_arbace_spec_alpha_A_const_231 = A_arbace_spec_alpha_A_const_pool.A[467]; A_arbace_spec_alpha_A_const_232 = A_arbace_spec_alpha_A_const_pool.A[468]; A_arbace_spec_alpha_A_const_233 = A_arbace_spec_alpha_A_const_pool.A[469]; A_arbace_spec_alpha_A_const_234 = A_arbace_spec_alpha_A_const_pool.A[470]; A_arbace_spec_alpha_A_const_235 = A_arbace_spec_alpha_A_const_pool.A[471]; A_arbace_spec_alpha_A_const_236 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[472]); A_arbace_spec_alpha_A_const_237 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[473]); A_arbace_spec_alpha_A_const_238 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[474]); A_arbace_spec_alpha_A_const_239 = A_arbace_spec_alpha_A_const_pool.A[475]; A_arbace_spec_alpha_A_const_240 = A_arbace_spec_alpha_A_const_pool.A[476]; A_arbace_spec_alpha_A_const_241 = A_arbace_spec_alpha_A_const_pool.A[477]; A_arbace_spec_alpha_A_const_242 = A_arbace_spec_alpha_A_const_pool.A[478] }

func A_arbace_spec_alpha_A_clinit_p19() { A_arbace_spec_alpha_A_const_243 = A_arbace_spec_alpha_A_const_pool.A[479]; A_arbace_spec_alpha_A_const_244 = A_arbace_spec_alpha_A_const_pool.A[480]; A_arbace_spec_alpha_A_const_245 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[481]); A_arbace_spec_alpha_A_const_246 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[482]); A_arbace_spec_alpha_A_const_247 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[483]); A_arbace_spec_alpha_A_const_248 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[484]); A_arbace_spec_alpha_A_const_249 = A_arbace_spec_alpha_A_const_pool.A[485]; A_arbace_spec_alpha_A_const_250 = A_arbace_spec_alpha_A_const_pool.A[486]; A_arbace_spec_alpha_A_const_251 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[487]); A_arbace_spec_alpha_A_const_252 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[488]); A_arbace_spec_alpha_A_const_253 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[489]); A_arbace_spec_alpha_A_const_254 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[490]); A_arbace_spec_alpha_A_const_255 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[491]) }

func A_arbace_spec_alpha_A_clinit_p20() { A_arbace_spec_alpha_A_const_256 = A_arbace_spec_alpha_A_const_pool.A[492]; A_arbace_spec_alpha_A_const_257 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[493]); A_arbace_spec_alpha_A_const_258 = A_arbace_spec_alpha_A_const_pool.A[494]; A_arbace_spec_alpha_A_const_259 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[495]); A_arbace_spec_alpha_A_const_260 = A_arbace_spec_alpha_A_const_pool.A[496]; A_arbace_spec_alpha_A_const_261 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[497]); A_arbace_spec_alpha_A_const_262 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[498]); A_arbace_spec_alpha_A_const_263 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[499]); A_arbace_spec_alpha_A_const_264 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[500]); A_arbace_spec_alpha_A_const_265 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[501]); A_arbace_spec_alpha_A_const_266 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[502]); A_arbace_spec_alpha_A_const_267 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[503]) }

func A_arbace_spec_alpha_A_clinit_p21() { A_arbace_spec_alpha_A_const_268 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[504]); A_arbace_spec_alpha_A_const_269 = A_arbace_spec_alpha_A_const_pool.A[505]; A_arbace_spec_alpha_A_const_270 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[506]); A_arbace_spec_alpha_A_const_271 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[507]); A_arbace_spec_alpha_A_const_272 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[508]); A_arbace_spec_alpha_A_const_273 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[509]); A_arbace_spec_alpha_A_const_274 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[510]); A_arbace_spec_alpha_A_const_275 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[511]); A_arbace_spec_alpha_A_const_276 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[512]); A_arbace_spec_alpha_A_const_277 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[513]); A_arbace_spec_alpha_A_const_278 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[514]); A_arbace_spec_alpha_A_const_279 = A_arbace_spec_alpha_A_const_pool.A[515] }

func A_arbace_spec_alpha_A_clinit_p22() { A_arbace_spec_alpha_A_const_280 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[516]); A_arbace_spec_alpha_A_const_281 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[517]); A_arbace_spec_alpha_A_const_282 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[518]); A_arbace_spec_alpha_A_const_283 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[519]); A_arbace_spec_alpha_A_const_284 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[520]); A_arbace_spec_alpha_A_const_285 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[521]); A_arbace_spec_alpha_A_const_286 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[522]); A_arbace_spec_alpha_A_const_287 = A_arbace_spec_alpha_A_const_pool.A[523]; A_arbace_spec_alpha_A_const_288 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[524]); A_arbace_spec_alpha_A_const_289 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[525]); A_arbace_spec_alpha_A_const_290 = A_arbace_spec_alpha_A_const_pool.A[526]; A_arbace_spec_alpha_A_const_291 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[527]) }

func A_arbace_spec_alpha_A_clinit_p23() { A_arbace_spec_alpha_A_const_292 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[528]); A_arbace_spec_alpha_A_const_293 = A_arbace_spec_alpha_A_const_pool.A[529]; A_arbace_spec_alpha_A_const_294 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[530]); A_arbace_spec_alpha_A_const_295 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[531]); A_arbace_spec_alpha_A_const_296 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[532]); A_arbace_spec_alpha_A_const_297 = A_arbace_spec_alpha_A_const_pool.A[533]; A_arbace_spec_alpha_A_const_298 = A_arbace_spec_alpha_A_const_pool.A[534]; A_arbace_spec_alpha_A_const_299 = A_arbace_spec_alpha_A_const_pool.A[535]; A_arbace_spec_alpha_A_const_300 = A_arbace_spec_alpha_A_const_pool.A[536]; A_arbace_spec_alpha_A_const_301 = A_arbace_spec_alpha_A_const_pool.A[537]; A_arbace_spec_alpha_A_const_302 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[538]); A_arbace_spec_alpha_A_const_303 = A_arbace_spec_alpha_A_const_pool.A[539]; A_arbace_spec_alpha_A_const_304 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[540]); A_arbace_spec_alpha_A_const_305 = A_arbace_spec_alpha_A_const_pool.A[541] }

func A_arbace_spec_alpha_A_clinit_p24() { A_arbace_spec_alpha_A_const_306 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[542]); A_arbace_spec_alpha_A_const_307 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[543]); A_arbace_spec_alpha_A_const_308 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[544]); A_arbace_spec_alpha_A_const_309 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[545]); A_arbace_spec_alpha_A_const_310 = A_arbace_spec_alpha_A_const_pool.A[546]; A_arbace_spec_alpha_A_const_311 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[547]); A_arbace_spec_alpha_A_const_312 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[548]); A_arbace_spec_alpha_A_const_313 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[549]); A_arbace_spec_alpha_A_const_314 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[550]); A_arbace_spec_alpha_A_const_315 = A_arbace_spec_alpha_A_const_pool.A[551]; A_arbace_spec_alpha_A_const_316 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[552]); A_arbace_spec_alpha_A_const_317 = A_arbace_spec_alpha_A_const_pool.A[553]; A_arbace_spec_alpha_A_const_318 = A_arbace_spec_alpha_A_const_pool.A[554] }

func A_arbace_spec_alpha_A_clinit_p25() { A_arbace_spec_alpha_A_const_319 = A_arbace_spec_alpha_A_const_pool.A[555]; A_arbace_spec_alpha_A_const_320 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[556]); A_arbace_spec_alpha_A_const_321 = A_arbace_spec_alpha_A_const_pool.A[557]; A_arbace_spec_alpha_A_const_322 = A_arbace_spec_alpha_A_const_pool.A[558]; A_arbace_spec_alpha_A_const_323 = A_arbace_spec_alpha_A_const_pool.A[559]; A_arbace_spec_alpha_A_const_324 = A_arbace_spec_alpha_A_const_pool.A[560]; A_arbace_spec_alpha_A_const_325 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[561]); A_arbace_spec_alpha_A_const_326 = A_arbace_spec_alpha_A_const_pool.A[562]; A_arbace_spec_alpha_A_const_327 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[563]); A_arbace_spec_alpha_A_const_328 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[564]); A_arbace_spec_alpha_A_const_329 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[565]); A_arbace_spec_alpha_A_const_330 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[566]); A_arbace_spec_alpha_A_const_331 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[567]) }

func A_arbace_spec_alpha_A_clinit_p26() { A_arbace_spec_alpha_A_const_332 = A_arbace_spec_alpha_A_const_pool.A[568]; A_arbace_spec_alpha_A_const_333 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[569]); A_arbace_spec_alpha_A_const_334 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[570]); A_arbace_spec_alpha_A_const_335 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[571]); A_arbace_spec_alpha_A_const_336 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[572]); A_arbace_spec_alpha_A_const_337 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[573]); A_arbace_spec_alpha_A_const_338 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[574]); A_arbace_spec_alpha_A_const_339 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[575]); A_arbace_spec_alpha_A_const_340 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[576]); A_arbace_spec_alpha_A_const_341 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[577]); A_arbace_spec_alpha_A_const_342 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[578]); A_arbace_spec_alpha_A_const_343 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[579]) }

func A_arbace_spec_alpha_A_clinit_p27() { A_arbace_spec_alpha_A_const_344 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[580]); A_arbace_spec_alpha_A_const_345 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[581]); A_arbace_spec_alpha_A_const_346 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[582]); A_arbace_spec_alpha_A_const_347 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[583]); A_arbace_spec_alpha_A_const_348 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[584]); A_arbace_spec_alpha_A_const_349 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[585]); A_arbace_spec_alpha_A_const_350 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[586]); A_arbace_spec_alpha_A_const_351 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[587]); A_arbace_spec_alpha_A_const_352 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[588]); A_arbace_spec_alpha_A_const_353 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[589]); A_arbace_spec_alpha_A_const_354 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[590]); A_arbace_spec_alpha_A_const_355 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[591]) }

func A_arbace_spec_alpha_A_clinit_p28() { A_arbace_spec_alpha_A_const_356 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[592]); A_arbace_spec_alpha_A_const_357 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[593]); A_arbace_spec_alpha_A_const_358 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[594]); A_arbace_spec_alpha_A_const_359 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[595]); A_arbace_spec_alpha_A_const_360 = A_arbace_spec_alpha_A_const_pool.A[596]; A_arbace_spec_alpha_A_const_361 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[597]); A_arbace_spec_alpha_A_const_362 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[598]); A_arbace_spec_alpha_A_const_363 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[599]); A_arbace_spec_alpha_A_const_364 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[600]); A_arbace_spec_alpha_A_const_365 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[601]); A_arbace_spec_alpha_A_const_366 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[602]); A_arbace_spec_alpha_A_const_367 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[603]) }

func A_arbace_spec_alpha_A_clinit_p29() { A_arbace_spec_alpha_A_const_368 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[604]); A_arbace_spec_alpha_A_const_369 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[605]); A_arbace_spec_alpha_A_const_370 = A_arbace_spec_alpha_A_const_pool.A[606]; A_arbace_spec_alpha_A_const_371 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[607]); A_arbace_spec_alpha_A_const_372 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[608]); A_arbace_spec_alpha_A_const_373 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[609]); A_arbace_spec_alpha_A_const_374 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[610]); A_arbace_spec_alpha_A_const_375 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[611]); A_arbace_spec_alpha_A_const_376 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[612]); A_arbace_spec_alpha_A_const_377 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[613]); A_arbace_spec_alpha_A_const_378 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[614]); A_arbace_spec_alpha_A_const_379 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[615]) }

func A_arbace_spec_alpha_A_clinit_p30() { A_arbace_spec_alpha_A_const_380 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[616]); A_arbace_spec_alpha_A_const_381 = A_arbace_spec_alpha_A_const_pool.A[617]; A_arbace_spec_alpha_A_const_382 = A_arbace_spec_alpha_A_const_pool.A[618]; A_arbace_spec_alpha_A_const_383 = A_arbace_spec_alpha_A_const_pool.A[619]; A_arbace_spec_alpha_A_const_384 = A_arbace_spec_alpha_A_const_pool.A[620]; A_arbace_spec_alpha_A_const_385 = A_arbace_spec_alpha_A_const_pool.A[621]; A_arbace_spec_alpha_A_const_386 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[622]); A_arbace_spec_alpha_A_const_387 = A_arbace_spec_alpha_A_const_pool.A[623]; A_arbace_spec_alpha_A_const_388 = A_arbace_spec_alpha_A_const_pool.A[624]; A_arbace_spec_alpha_A_const_389 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[625]); A_arbace_spec_alpha_A_const_390 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[626]); A_arbace_spec_alpha_A_const_391 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[627]); A_arbace_spec_alpha_A_const_392 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[628]) }

func A_arbace_spec_alpha_A_clinit_p31() { A_arbace_spec_alpha_A_const_393 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[629]); A_arbace_spec_alpha_A_const_394 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[630]); A_arbace_spec_alpha_A_const_395 = A_arbace_spec_alpha_A_const_pool.A[631]; A_arbace_spec_alpha_A_const_396 = A_arbace_spec_alpha_A_const_pool.A[632]; A_arbace_spec_alpha_A_const_397 = A_arbace_spec_alpha_A_const_pool.A[633]; A_arbace_spec_alpha_A_const_398 = A_arbace_spec_alpha_A_const_pool.A[634]; A_arbace_spec_alpha_A_const_399 = A_arbace_spec_alpha_A_const_pool.A[635]; A_arbace_spec_alpha_A_const_400 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[636]); A_arbace_spec_alpha_A_const_401 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[637]); A_arbace_spec_alpha_A_const_402 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[638]); A_arbace_spec_alpha_A_const_403 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[639]); A_arbace_spec_alpha_A_const_404 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[640]); A_arbace_spec_alpha_A_const_405 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[641]) }

func A_arbace_spec_alpha_A_clinit_p32() { A_arbace_spec_alpha_A_const_406 = A_arbace_spec_alpha_A_const_pool.A[642]; A_arbace_spec_alpha_A_const_407 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[643]); A_arbace_spec_alpha_A_const_408 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[644]); A_arbace_spec_alpha_A_const_409 = A_arbace_spec_alpha_A_const_pool.A[645]; A_arbace_spec_alpha_A_const_410 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[646]); A_arbace_spec_alpha_A_const_411 = A_arbace_spec_alpha_A_const_pool.A[647]; A_arbace_spec_alpha_A_const_412 = A_arbace_spec_alpha_A_const_pool.A[648]; A_arbace_spec_alpha_A_const_413 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[649]); A_arbace_spec_alpha_A_const_414 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[650]); A_arbace_spec_alpha_A_const_415 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[651]); A_arbace_spec_alpha_A_const_416 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[652]); A_arbace_spec_alpha_A_const_417 = A_arbace_spec_alpha_A_const_pool.A[653]; A_arbace_spec_alpha_A_const_418 = A_arbace_spec_alpha_A_const_pool.A[654] }

func A_arbace_spec_alpha_A_clinit_p33() { A_arbace_spec_alpha_A_const_419 = A_arbace_spec_alpha_A_const_pool.A[655]; A_arbace_spec_alpha_A_const_420 = A_arbace_spec_alpha_A_const_pool.A[656]; A_arbace_spec_alpha_A_const_421 = A_arbace_spec_alpha_A_const_pool.A[657]; A_arbace_spec_alpha_A_const_422 = A_arbace_spec_alpha_A_const_pool.A[658]; A_arbace_spec_alpha_A_const_423 = A_arbace_spec_alpha_A_const_pool.A[659]; A_arbace_spec_alpha_A_const_424 = A_arbace_spec_alpha_A_const_pool.A[660]; A_arbace_spec_alpha_A_const_425 = A_arbace_spec_alpha_A_const_pool.A[661]; A_arbace_spec_alpha_A_const_426 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[662]); A_arbace_spec_alpha_A_const_427 = A_arbace_spec_alpha_A_const_pool.A[663]; A_arbace_spec_alpha_A_const_428 = A_arbace_spec_alpha_A_const_pool.A[664]; A_arbace_spec_alpha_A_const_429 = A_arbace_spec_alpha_A_const_pool.A[665]; A_arbace_spec_alpha_A_const_430 = A_arbace_spec_alpha_A_const_pool.A[666]; A_arbace_spec_alpha_A_const_431 = A_arbace_spec_alpha_A_const_pool.A[667]; A_arbace_spec_alpha_A_const_432 = A_arbace_spec_alpha_A_const_pool.A[668]; A_arbace_spec_alpha_A_const_433 = A_arbace_spec_alpha_A_const_pool.A[669] }

func A_arbace_spec_alpha_A_clinit_p34() { A_arbace_spec_alpha_A_const_434 = A_arbace_spec_alpha_A_const_pool.A[670]; A_arbace_spec_alpha_A_const_435 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[671]); A_arbace_spec_alpha_A_const_436 = A_arbace_spec_alpha_A_const_pool.A[672]; A_arbace_spec_alpha_A_const_437 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[673]); A_arbace_spec_alpha_A_const_438 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[674]); A_arbace_spec_alpha_A_const_439 = A_arbace_spec_alpha_A_const_pool.A[675]; A_arbace_spec_alpha_A_const_440 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[676]); A_arbace_spec_alpha_A_const_441 = A_arbace_spec_alpha_A_const_pool.A[677]; A_arbace_spec_alpha_A_const_442 = A_arbace_spec_alpha_A_const_pool.A[678]; A_arbace_spec_alpha_A_const_443 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[679]); A_arbace_spec_alpha_A_const_444 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[680]); A_arbace_spec_alpha_A_const_445 = A_arbace_spec_alpha_A_const_pool.A[681]; A_arbace_spec_alpha_A_const_446 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[682]) }

func A_arbace_spec_alpha_A_clinit_p35() { A_arbace_spec_alpha_A_const_447 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[683]); A_arbace_spec_alpha_A_const_448 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[684]); A_arbace_spec_alpha_A_const_449 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[685]); A_arbace_spec_alpha_A_const_450 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[686]); A_arbace_spec_alpha_A_const_451 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[687]); A_arbace_spec_alpha_A_const_452 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[688]); A_arbace_spec_alpha_A_const_453 = A_arbace_spec_alpha_A_const_pool.A[689]; A_arbace_spec_alpha_A_const_454 = A_arbace_spec_alpha_A_const_pool.A[690]; A_arbace_spec_alpha_A_const_455 = A_arbace_spec_alpha_A_const_pool.A[691]; A_arbace_spec_alpha_A_const_456 = A_arbace_spec_alpha_A_const_pool.A[692]; A_arbace_spec_alpha_A_const_457 = A_arbace_spec_alpha_A_const_pool.A[693]; A_arbace_spec_alpha_A_const_458 = A_arbace_spec_alpha_A_const_pool.A[694]; A_arbace_spec_alpha_A_const_459 = A_arbace_spec_alpha_A_const_pool.A[695]; A_arbace_spec_alpha_A_const_460 = A_arbace_spec_alpha_A_const_pool.A[696] }

func A_arbace_spec_alpha_A_clinit_p36() { A_arbace_spec_alpha_A_const_461 = A_arbace_spec_alpha_A_const_pool.A[697]; A_arbace_spec_alpha_A_const_462 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[698]); A_arbace_spec_alpha_A_const_463 = A_arbace_spec_alpha_A_const_pool.A[699]; A_arbace_spec_alpha_A_const_464 = A_arbace_spec_alpha_A_const_pool.A[700]; A_arbace_spec_alpha_A_const_465 = A_arbace_spec_alpha_A_const_pool.A[701]; A_arbace_spec_alpha_A_const_466 = A_arbace_spec_alpha_A_const_pool.A[702]; A_arbace_spec_alpha_A_const_467 = A_arbace_spec_alpha_A_const_pool.A[703]; A_arbace_spec_alpha_A_const_468 = A_arbace_spec_alpha_A_const_pool.A[704]; A_arbace_spec_alpha_A_const_469 = A_arbace_spec_alpha_A_const_pool.A[705]; A_arbace_spec_alpha_A_const_470 = A_arbace_spec_alpha_A_const_pool.A[706]; A_arbace_spec_alpha_A_const_471 = A_arbace_spec_alpha_A_const_pool.A[707]; A_arbace_spec_alpha_A_const_472 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[708]); A_arbace_spec_alpha_A_const_473 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[709]); A_arbace_spec_alpha_A_const_474 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[710]) }

func A_arbace_spec_alpha_A_clinit_p37() { A_arbace_spec_alpha_A_const_475 = A_arbace_spec_alpha_A_const_pool.A[711]; A_arbace_spec_alpha_A_const_476 = A_arbace_spec_alpha_A_const_pool.A[712]; A_arbace_spec_alpha_A_const_477 = A_arbace_spec_alpha_A_const_pool.A[713]; A_arbace_spec_alpha_A_const_478 = A_arbace_spec_alpha_A_const_pool.A[714]; A_arbace_spec_alpha_A_const_479 = A_arbace_spec_alpha_A_const_pool.A[715]; A_arbace_spec_alpha_A_const_480 = A_arbace_spec_alpha_A_const_pool.A[716]; A_arbace_spec_alpha_A_const_481 = A_arbace_spec_alpha_A_const_pool.A[717]; A_arbace_spec_alpha_A_const_482 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[718]); A_arbace_spec_alpha_A_const_483 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[719]); A_arbace_spec_alpha_A_const_484 = A_arbace_spec_alpha_A_const_pool.A[720]; A_arbace_spec_alpha_A_const_485 = A_arbace_spec_alpha_A_const_pool.A[721]; A_arbace_spec_alpha_A_const_486 = A_arbace_spec_alpha_A_const_pool.A[722]; A_arbace_spec_alpha_A_const_487 = A_arbace_spec_alpha_A_const_pool.A[723]; A_arbace_spec_alpha_A_const_488 = A_arbace_spec_alpha_A_const_pool.A[724]; A_arbace_spec_alpha_A_const_489 = A_arbace_spec_alpha_A_const_pool.A[725] }

func A_arbace_spec_alpha_A_clinit_p38() { A_arbace_spec_alpha_A_const_490 = A_arbace_spec_alpha_A_const_pool.A[726]; A_arbace_spec_alpha_A_const_491 = A_arbace_spec_alpha_A_const_pool.A[727]; A_arbace_spec_alpha_A_const_492 = A_arbace_spec_alpha_A_const_pool.A[728]; A_arbace_spec_alpha_A_const_493 = A_arbace_spec_alpha_A_const_pool.A[729]; A_arbace_spec_alpha_A_const_494 = lang.Keyword_Cast(A_arbace_spec_alpha_A_const_pool.A[730]); A_arbace_spec_alpha_A_const_495 = lang.Var_Cast(A_arbace_spec_alpha_A_const_pool.A[731]); A_arbace_spec_alpha_A_const_496 = A_arbace_spec_alpha_A_const_pool.A[732]; A_arbace_spec_alpha_A_const_497 = A_arbace_spec_alpha_A_const_pool.A[733]; A_arbace_spec_alpha_A_const_498 = A_arbace_spec_alpha_A_const_pool.A[734] }

func A_arbace_spec_alpha_A_New() *A_arbace_spec_alpha_A { A_arbace_spec_alpha_A_Init(); t := &A_arbace_spec_alpha_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_alpha_A) Ctor() {}

func (t *A_arbace_spec_alpha_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_A_class }

func (t *A_arbace_spec_alpha_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_A); return ok }

func A_arbace_spec_alpha_A_Cast(x any) *A_arbace_spec_alpha_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_A_class)) }; return v }



type A_arbace_spec_alpha__AMPERSAND__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha__AMPERSAND__A_fn_class *jrt.Class



type A_arbace_spec_alpha__PLUS__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha__PLUS__A_fn_class *jrt.Class



type A_arbace_spec_alpha__QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha__QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha__STAR__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha__STAR__A_fn_class *jrt.Class



type A_arbace_spec_alpha___GT_sym_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha___GT_sym_A_fn_class *jrt.Class



type A_arbace_spec_alpha_abbrev_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_abbrev_A_fn_class *jrt.Class



type A_arbace_spec_alpha_abbrev_fn__1740000170_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_abbrev_fn__1740000170_A_fn_class *jrt.Class



type A_arbace_spec_alpha_accept_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_accept_A_fn_class *jrt.Class



type A_arbace_spec_alpha_accept_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_accept_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha_accept_nil_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_accept_nil_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha_add_ret_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_add_ret_A_fn_class *jrt.Class



type A_arbace_spec_alpha_add_ret_prop__1740000773_A struct{ j2g_header uint64; F_k, F_p, F_r, F_splice any }

var A_arbace_spec_alpha_add_ret_prop__1740000773_A_fn_class *jrt.Class



type A_arbace_spec_alpha_alt_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_alt_A_fn_class *jrt.Class



type A_arbace_spec_alpha_alt2_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_alt2_A_fn_class *jrt.Class



type A_arbace_spec_alpha_alt_STAR__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_alt_STAR__A_fn_class *jrt.Class



type A_arbace_spec_alpha_alt_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_alt_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_alts_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_alts_A_fn_class *jrt.Class



type A_arbace_spec_alpha_amp_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_amp_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_and_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_and_A_fn_class *jrt.Class



type A_arbace_spec_alpha_and_k_gen_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_and_k_gen_A_fn_class *jrt.Class



type A_arbace_spec_alpha_and_preds_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_and_preds_A_fn_class *jrt.Class



type A_arbace_spec_alpha_and_spec_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_and_spec_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A struct{ j2g_header uint64; F_forms, F_preds any }

var A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_fn_class *jrt.Class



type A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A struct{ j2g_header uint64; F_specs any }

var A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_fn_class *jrt.Class



type A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A struct{ j2g_header uint64; F_specs any }

var A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_fn_class *jrt.Class



type A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A struct{ j2g_header uint64; F_specs any }

var A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_fn_class *jrt.Class



type A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A struct{ jrt.Object; F_cform, F_gfn, F_forms, F_preds any; F___meta lang.IPersistentMap }

func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Is_A_arbace_spec_alpha_Specize_A() {}

func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Is_A_arbace_spec_alpha_Spec_A() {}

func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Is_IObj() {}

func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Is_IMeta() {}

func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_class }

func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A); return ok }

func A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_Cast(x any) *A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_class)) }; return v }



type A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_fn_class *jrt.Class



type A_arbace_spec_alpha_assert_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_assert_A_fn_class *jrt.Class



type A_arbace_spec_alpha_assert_STAR__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_assert_STAR__A_fn_class *jrt.Class



type A_arbace_spec_alpha_assert_STAR__fn__1740000960_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_ed any }

var A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_fn_class *jrt.Class



type A_arbace_spec_alpha_call_valid_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_call_valid_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha_cat_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_cat_A_fn_class *jrt.Class



type A_arbace_spec_alpha_cat_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_cat_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_check_asserts_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_check_asserts_A_fn_class *jrt.Class



type A_arbace_spec_alpha_check_asserts_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_check_asserts_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha_coll_of_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_coll_of_A_fn_class *jrt.Class



type A_arbace_spec_alpha_coll_prob_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_coll_prob_A_fn_class *jrt.Class



type A_arbace_spec_alpha_conform_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_conform_A_fn_class *jrt.Class



type A_arbace_spec_alpha_conformer_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_conformer_A_fn_class *jrt.Class



type A_arbace_spec_alpha_deep_resolve_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_deep_resolve_A_fn_class *jrt.Class



type A_arbace_spec_alpha_def_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_def_A_fn_class *jrt.Class



type A_arbace_spec_alpha_def_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_def_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_deriv_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_deriv_A_fn_class *jrt.Class



type A_arbace_spec_alpha_deriv_fn__1740000787_A struct{ j2g_header uint64; F_x any }

var A_arbace_spec_alpha_deriv_fn__1740000787_A_fn_class *jrt.Class



type A_arbace_spec_alpha_describe_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_describe_A_fn_class *jrt.Class



type A_arbace_spec_alpha_double_in_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_double_in_A_fn_class *jrt.Class



type A_arbace_spec_alpha_dt_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_dt_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000004_A struct{ jrt.Object }

func A_arbace_spec_alpha_eval1740000004_A_New() *A_arbace_spec_alpha_eval1740000004_A { t := &A_arbace_spec_alpha_eval1740000004_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_alpha_eval1740000004_A) Ctor() {}

func (t *A_arbace_spec_alpha_eval1740000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_eval1740000004_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_eval1740000004_A_class }

func (t *A_arbace_spec_alpha_eval1740000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_eval1740000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_eval1740000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_eval1740000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_eval1740000004_A); return ok }

func A_arbace_spec_alpha_eval1740000004_A_Cast(x any) *A_arbace_spec_alpha_eval1740000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_eval1740000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_eval1740000004_A_class)) }; return v }



type A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000008_A struct{ jrt.Object }

func A_arbace_spec_alpha_eval1740000008_A_New() *A_arbace_spec_alpha_eval1740000008_A { t := &A_arbace_spec_alpha_eval1740000008_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_alpha_eval1740000008_A) Ctor() {}

func (t *A_arbace_spec_alpha_eval1740000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_eval1740000008_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_eval1740000008_A_class }

func (t *A_arbace_spec_alpha_eval1740000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_eval1740000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_eval1740000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_eval1740000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_eval1740000008_A); return ok }

func A_arbace_spec_alpha_eval1740000008_A_Cast(x any) *A_arbace_spec_alpha_eval1740000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_eval1740000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_eval1740000008_A_class)) }; return v }



type A_arbace_spec_alpha_eval1740000008_fn__1740000009_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_A struct{ jrt.Object }

func A_arbace_spec_alpha_eval1740000034_A_New() *A_arbace_spec_alpha_eval1740000034_A { t := &A_arbace_spec_alpha_eval1740000034_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_alpha_eval1740000034_A) Ctor() {}

func (t *A_arbace_spec_alpha_eval1740000034_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_eval1740000034_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_eval1740000034_A_class }

func (t *A_arbace_spec_alpha_eval1740000034_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_eval1740000034_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_eval1740000034_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_eval1740000034_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_eval1740000034_A); return ok }

func A_arbace_spec_alpha_eval1740000034_A_Cast(x any) *A_arbace_spec_alpha_eval1740000034_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_eval1740000034_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_eval1740000034_A_class)) }; return v }



type A_arbace_spec_alpha_eval1740000034_fn__1740000035_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A struct{ j2g_header uint64; F_G__1740000021 any }

var A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000051_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A struct{ j2g_header uint64; F_G__1740000025 any }

var A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000061_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A struct{ j2g_header uint64; F_G__1740000023 any }

var A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000075_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A struct{ j2g_header uint64; F_G__1740000017 any }

var A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000085_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A struct{ j2g_header uint64; F_G__1740000027 any }

var A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000093_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A struct{ j2g_header uint64; F_G__1740000019 any }

var A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000127_A struct{ jrt.Object }

func A_arbace_spec_alpha_eval1740000127_A_New() *A_arbace_spec_alpha_eval1740000127_A { t := &A_arbace_spec_alpha_eval1740000127_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_alpha_eval1740000127_A) Ctor() {}

func (t *A_arbace_spec_alpha_eval1740000127_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_eval1740000127_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_eval1740000127_A_class }

func (t *A_arbace_spec_alpha_eval1740000127_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_eval1740000127_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_eval1740000127_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_eval1740000127_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_eval1740000127_A); return ok }

func A_arbace_spec_alpha_eval1740000127_A_Cast(x any) *A_arbace_spec_alpha_eval1740000127_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_eval1740000127_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_eval1740000127_A_class)) }; return v }



type A_arbace_spec_alpha_eval1740000127_fn__1740000128_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A struct{ j2g_header uint64; F_G__1740000120 any }

var A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000149_A struct{ jrt.Object }

func A_arbace_spec_alpha_eval1740000149_A_New() *A_arbace_spec_alpha_eval1740000149_A { t := &A_arbace_spec_alpha_eval1740000149_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_alpha_eval1740000149_A) Ctor() {}

func (t *A_arbace_spec_alpha_eval1740000149_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_eval1740000149_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_eval1740000149_A_class }

func (t *A_arbace_spec_alpha_eval1740000149_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_eval1740000149_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_eval1740000149_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_eval1740000149_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_eval1740000149_A); return ok }

func A_arbace_spec_alpha_eval1740000149_A_Cast(x any) *A_arbace_spec_alpha_eval1740000149_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_eval1740000149_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_eval1740000149_A_class)) }; return v }



type A_arbace_spec_alpha_eval1740000149_fn__1740000150_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000153_A struct{ jrt.Object }

func A_arbace_spec_alpha_eval1740000153_A_New() *A_arbace_spec_alpha_eval1740000153_A { t := &A_arbace_spec_alpha_eval1740000153_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_alpha_eval1740000153_A) Ctor() {}

func (t *A_arbace_spec_alpha_eval1740000153_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_eval1740000153_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_eval1740000153_A_class }

func (t *A_arbace_spec_alpha_eval1740000153_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_eval1740000153_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_eval1740000153_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_eval1740000153_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_eval1740000153_A); return ok }

func A_arbace_spec_alpha_eval1740000153_A_Cast(x any) *A_arbace_spec_alpha_eval1740000153_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_eval1740000153_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_eval1740000153_A_class)) }; return v }



type A_arbace_spec_alpha_eval1740000153_fn__1740000154_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000157_A struct{ jrt.Object }

func A_arbace_spec_alpha_eval1740000157_A_New() *A_arbace_spec_alpha_eval1740000157_A { t := &A_arbace_spec_alpha_eval1740000157_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_alpha_eval1740000157_A) Ctor() {}

func (t *A_arbace_spec_alpha_eval1740000157_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_eval1740000157_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_eval1740000157_A_class }

func (t *A_arbace_spec_alpha_eval1740000157_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_eval1740000157_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_eval1740000157_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_eval1740000157_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_eval1740000157_A); return ok }

func A_arbace_spec_alpha_eval1740000157_A_Cast(x any) *A_arbace_spec_alpha_eval1740000157_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_eval1740000157_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_eval1740000157_A_class)) }; return v }



type A_arbace_spec_alpha_eval1740000157_fn__1740000158_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_fn_class *jrt.Class



type A_arbace_spec_alpha_eval1740000161_A struct{ jrt.Object }

func A_arbace_spec_alpha_eval1740000161_A_New() *A_arbace_spec_alpha_eval1740000161_A { t := &A_arbace_spec_alpha_eval1740000161_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_alpha_eval1740000161_A) Ctor() {}

func (t *A_arbace_spec_alpha_eval1740000161_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_eval1740000161_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_eval1740000161_A_class }

func (t *A_arbace_spec_alpha_eval1740000161_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_eval1740000161_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_eval1740000161_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_eval1740000161_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_eval1740000161_A); return ok }

func A_arbace_spec_alpha_eval1740000161_A_Cast(x any) *A_arbace_spec_alpha_eval1740000161_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_eval1740000161_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_eval1740000161_A_class)) }; return v }



type A_arbace_spec_alpha_eval1740000161_fn__1740000162_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_every_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_every_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_impl_addcv__1740000620_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_every_impl_addcv__1740000620_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_impl_cfns__1740000622_A struct{ j2g_header uint64; F_kind, F_conform_into, F_conform_keys, F_addcv any }

var A_arbace_spec_alpha_every_impl_cfns__1740000622_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A struct{ j2g_header uint64; F_conform_keys any }

var A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A struct{ j2g_header uint64; F_conform_into any }

var A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A struct{ j2g_header uint64; F_spec any }

var A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_impl_fn__1740000614_A struct{ j2g_header uint64; F_pred any }

var A_arbace_spec_alpha_every_impl_fn__1740000614_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_impl_fn__1740000618_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_every_impl_fn__1740000618_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_impl_reify__1740000630_A struct{ jrt.Object; F_check_QMARK_, F_count, F_kind_form, F_form, F_gen_max, F_spec, F_max_count, F_kind, F_gfn, F_distinct, F_cfns, F_describe_form, F_cpred, F_conform_all, F_min_count, F_opts, F_gen_into, F_kfn, F_pred any; F___meta lang.IPersistentMap }

func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Is_A_arbace_spec_alpha_Specize_A() {}

func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Is_A_arbace_spec_alpha_Spec_A() {}

func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Is_IObj() {}

func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Is_IMeta() {}

func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_every_impl_reify__1740000630_A_class }

func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_every_impl_reify__1740000630_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_every_impl_reify__1740000630_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_every_impl_reify__1740000630_A); return ok }

func A_arbace_spec_alpha_every_impl_reify__1740000630_A_Cast(x any) *A_arbace_spec_alpha_every_impl_reify__1740000630_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_every_impl_reify__1740000630_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_every_impl_reify__1740000630_A_class)) }; return v }



type A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A struct{ j2g_header uint64; F_check_QMARK_, F_in, F_form, F_path, F_via, F_kfn, F_pred any }

var A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A struct{ j2g_header uint64; F_count, F_gen_max, F_max_count, F_distinct, F_min_count, F_pgen any }

var A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A struct{ j2g_header uint64; F_init any }

var A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_fn_class *jrt.Class



type A_arbace_spec_alpha_every_kv_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_every_kv_A_fn_class *jrt.Class



type A_arbace_spec_alpha_exercise_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_exercise_A_fn_class *jrt.Class



type A_arbace_spec_alpha_exercise_fn__1740000905_A struct{ j2g_header uint64; F_spec any }

var A_arbace_spec_alpha_exercise_fn__1740000905_A_fn_class *jrt.Class



type A_arbace_spec_alpha_exercise_fn_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_exercise_fn_A_fn_class *jrt.Class



type A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A struct{ j2g_header uint64; F_f any }

var A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_fn_class *jrt.Class



type A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A struct{ j2g_header uint64; F_f, F_s__1740000909, F_iter__1740000908 any }

var A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_fn_class *jrt.Class



type A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A struct{ j2g_header uint64; F_f, F_b__1740000911 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_fn_class *jrt.Class



type A_arbace_spec_alpha_explain_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_explain_A_fn_class *jrt.Class



type A_arbace_spec_alpha_explain_1_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_explain_1_A_fn_class *jrt.Class



type A_arbace_spec_alpha_explain_data_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_explain_data_A_fn_class *jrt.Class



type A_arbace_spec_alpha_explain_data_STAR__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_explain_data_STAR__A_fn_class *jrt.Class



type A_arbace_spec_alpha_explain_out_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_explain_out_A_fn_class *jrt.Class



type A_arbace_spec_alpha_explain_pred_list_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_explain_pred_list_A_fn_class *jrt.Class



type A_arbace_spec_alpha_explain_printer_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_explain_printer_A_fn_class *jrt.Class



type A_arbace_spec_alpha_explain_printer_fn__1740000179_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_explain_printer_fn__1740000179_A_fn_class *jrt.Class



type A_arbace_spec_alpha_explain_printer_fn__1740000181_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_explain_printer_fn__1740000181_A_fn_class *jrt.Class



type A_arbace_spec_alpha_explain_str_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_explain_str_A_fn_class *jrt.Class



type A_arbace_spec_alpha_fdef_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_fdef_A_fn_class *jrt.Class



type A_arbace_spec_alpha_filter_alt_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_filter_alt_A_fn_class *jrt.Class



type A_arbace_spec_alpha_filter_alt_fn__1740000703_A struct{ j2g_header uint64; F_f any }

var A_arbace_spec_alpha_filter_alt_fn__1740000703_A_fn_class *jrt.Class



type A_arbace_spec_alpha_filter_alt_fn__1740000705_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_filter_alt_fn__1740000705_A_fn_class *jrt.Class



type A_arbace_spec_alpha_fn__1740000868_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_fn__1740000868_A_fn_class *jrt.Class



type A_arbace_spec_alpha_fn__1740000870_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_fn__1740000870_A_fn_class *jrt.Class



type A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_fn_class *jrt.Class



type A_arbace_spec_alpha_fn_sym_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_fn_sym_A_fn_class *jrt.Class



type A_arbace_spec_alpha_form_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_form_A_fn_class *jrt.Class



type A_arbace_spec_alpha_fspec_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_fspec_A_fn_class *jrt.Class



type A_arbace_spec_alpha_fspec_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_fspec_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_fspec_impl_reify__1740000857_A struct{ jrt.Object; F_aform, F_fform, F_gfn, F_specs, F_argspec, F_rform, F_retspec, F_fnspec any; F___meta lang.IPersistentMap }

func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Is_ILookup() {}

func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Is_A_arbace_spec_alpha_Specize_A() {}

func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Is_A_arbace_spec_alpha_Spec_A() {}

func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Is_IObj() {}

func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Is_IMeta() {}

func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_class }

func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A); return ok }

func A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_Cast(x any) *A_arbace_spec_alpha_fspec_impl_reify__1740000857_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_class)) }; return v }



type A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A struct{ j2g_header uint64; F_f, F_args any }

var A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_fn_class *jrt.Class



type A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A struct{ j2g_header uint64; F_overrides, F_argspec, F_retspec any }

var A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_fn_class *jrt.Class



type A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A struct{ j2g_header uint64; F_s__1927001093__auto__, F_argspec, F_args any }

var A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_fn_class *jrt.Class



type A_arbace_spec_alpha_gen_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_gen_A_fn_class *jrt.Class



type A_arbace_spec_alpha_gensub_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_gensub_A_fn_class *jrt.Class



type A_arbace_spec_alpha_gensub_fn__1740000216_A struct{ j2g_header uint64; F_spec any }

var A_arbace_spec_alpha_gensub_fn__1740000216_A_fn_class *jrt.Class



type A_arbace_spec_alpha_get_spec_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_get_spec_A_fn_class *jrt.Class



type A_arbace_spec_alpha_inck_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_inck_A_fn_class *jrt.Class



type A_arbace_spec_alpha_inst_in_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_inst_in_A_fn_class *jrt.Class



type A_arbace_spec_alpha_inst_in_range_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_inst_in_range_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha_int_in_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_int_in_A_fn_class *jrt.Class



type A_arbace_spec_alpha_int_in_range_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_int_in_range_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha_invalid_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_invalid_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha_k_gen_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_k_gen_A_fn_class *jrt.Class



type A_arbace_spec_alpha_keys_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_keys_A_fn_class *jrt.Class



type A_arbace_spec_alpha_keys_fn__1740000263_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_keys_fn__1740000263_A_fn_class *jrt.Class



type A_arbace_spec_alpha_keys_fn__1740000271_A struct{ j2g_header uint64; F_gx any }

var A_arbace_spec_alpha_keys_fn__1740000271_A_fn_class *jrt.Class



type A_arbace_spec_alpha_keys_parse_req__1740000265_A struct{ j2g_header uint64; F_gx any }

var A_arbace_spec_alpha_keys_parse_req__1740000265_A_fn_class *jrt.Class



type A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A struct{ j2g_header uint64; F_f, F_gx any }

var A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_fn_class *jrt.Class



type A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A struct{ j2g_header uint64; F_f, F_gx any }

var A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_fn_class *jrt.Class



type A_arbace_spec_alpha_keys_unk__1740000261_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_keys_unk__1740000261_A_fn_class *jrt.Class



type A_arbace_spec_alpha_keys_STAR__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_keys_STAR__A_fn_class *jrt.Class



type A_arbace_spec_alpha_macroexpand_check_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_macroexpand_check_A_fn_class *jrt.Class



type A_arbace_spec_alpha_map_of_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_map_of_A_fn_class *jrt.Class



type A_arbace_spec_alpha_map_spec_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_map_spec_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A struct{ j2g_header uint64; F_k__GT_s any }

var A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_fn_class *jrt.Class



type A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A struct{ jrt.Object; F_pred_forms, F_opt, F_keys_pred, F_id, F_req_keys, F_req_specs, F_argm, F_req, F_req_un, F_opt_keys, F_pred_exprs, F_keys__GT_specnames, F_opt_un, F_opt_specs, F_gfn any; F___meta lang.IPersistentMap }

func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Is_A_arbace_spec_alpha_Specize_A() {}

func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Is_A_arbace_spec_alpha_Spec_A() {}

func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Is_IObj() {}

func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Is_IMeta() {}

func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_class }

func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A); return ok }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_Cast(x any) *A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_class)) }; return v }



type A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A struct{ j2g_header uint64; F_x any }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_fn_class *jrt.Class



type A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A struct{ j2g_header uint64; F_in, F_path, F_via, F_x any }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_fn_class *jrt.Class



type A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A struct{ j2g_header uint64; F_in, F_path, F_via, F_reg, F_keys__GT_specnames any }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_fn_class *jrt.Class



type A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A struct{ j2g_header uint64; F_reqs, F_opts any }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_fn_class *jrt.Class



type A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A struct{ j2g_header uint64; F_qks, F_unqks any }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_fn_class *jrt.Class



type A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A struct{ j2g_header uint64; F_path, F_rmap, F_overrides, F_id any }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_fn_class *jrt.Class



type A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A struct{ j2g_header uint64; F_path, F_rmap, F_overrides, F_k, F_s any }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_fn_class *jrt.Class



type A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A struct{ j2g_header uint64; F_path, F_rmap, F_overrides any }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_fn_class *jrt.Class



type A_arbace_spec_alpha_maybe_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_maybe_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_maybe_spec_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_maybe_spec_A_fn_class *jrt.Class



type A_arbace_spec_alpha_merge_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_merge_A_fn_class *jrt.Class



type A_arbace_spec_alpha_merge_spec_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_merge_spec_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A struct{ jrt.Object; F_gfn, F_forms, F_preds any; F___meta lang.IPersistentMap }

func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Is_A_arbace_spec_alpha_Specize_A() {}

func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Is_A_arbace_spec_alpha_Spec_A() {}

func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Is_IObj() {}

func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Is_IMeta() {}

func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_class }

func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A); return ok }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_Cast(x any) *A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_class)) }; return v }



type A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A struct{ j2g_header uint64; F_x any }

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_fn_class *jrt.Class



type A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A struct{ j2g_header uint64; F_x any }

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_fn_class *jrt.Class



type A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A struct{ j2g_header uint64; F_in, F_path, F_via, F_x any }

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_fn_class *jrt.Class



type A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_fn_class *jrt.Class



type A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A struct{ j2g_header uint64; F_path, F_overrides, F_rmap any }

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_fn_class *jrt.Class



type A_arbace_spec_alpha_multi_spec_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_multi_spec_A_fn_class *jrt.Class



type A_arbace_spec_alpha_multi_spec_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_multi_spec_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A struct{ j2g_header uint64; F_mmvar any }

var A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_fn_class *jrt.Class



type A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A struct{ j2g_header uint64; F_retag any }

var A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_fn_class *jrt.Class



type A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A struct{ j2g_header uint64; F_mmvar any }

var A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_fn_class *jrt.Class



type A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A struct{ jrt.Object; F_form, F_retag, F_mmvar, F_gfn, F_predx, F_tag, F_dval, F_id any; F___meta lang.IPersistentMap }

func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Is_A_arbace_spec_alpha_Specize_A() {}

func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Is_A_arbace_spec_alpha_Spec_A() {}

func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Is_IObj() {}

func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Is_IMeta() {}

func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_class }

func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A); return ok }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_Cast(x any) *A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_class)) }; return v }



type A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_fn_class *jrt.Class



type A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A struct{ j2g_header uint64; F_path, F_form, F_overrides, F_rmap, F_tag, F_id any }

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_fn_class *jrt.Class



type A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A struct{ j2g_header uint64; F_path, F_form, F_rmap, F_overrides, F_k, F_p, F_tag any }

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_fn_class *jrt.Class



type A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A struct{ j2g_header uint64; F_k, F_tag any }

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_fn_class *jrt.Class



type A_arbace_spec_alpha_nilable_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_nilable_A_fn_class *jrt.Class



type A_arbace_spec_alpha_nilable_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_nilable_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_nilable_impl_fn__1740000890_A struct{ j2g_header uint64; F_form, F_pred any }

var A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_fn_class *jrt.Class



type A_arbace_spec_alpha_nilable_impl_reify__1740000892_A struct{ jrt.Object; F_form, F_gfn, F_spec, F_pred any; F___meta lang.IPersistentMap }

func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Is_A_arbace_spec_alpha_Specize_A() {}

func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Is_A_arbace_spec_alpha_Spec_A() {}

func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Is_IObj() {}

func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Is_IMeta() {}

func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_class }

func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_A); return ok }

func A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_Cast(x any) *A_arbace_spec_alpha_nilable_impl_reify__1740000892_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_class)) }; return v }



type A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_fn_class *jrt.Class



type A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A struct{ j2g_header uint64; F_path, F_form, F_overrides, F_rmap, F_pred any }

var A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_fn_class *jrt.Class



type A_arbace_spec_alpha_nonconforming_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_nonconforming_A_fn_class *jrt.Class



type A_arbace_spec_alpha_nonconforming_fn__1740000885_A struct{ j2g_header uint64; F_spec any }

var A_arbace_spec_alpha_nonconforming_fn__1740000885_A_fn_class *jrt.Class



type A_arbace_spec_alpha_nonconforming_reify__1740000887_A struct{ jrt.Object; F_spec any; F___meta lang.IPersistentMap }

func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Is_A_arbace_spec_alpha_Specize_A() {}

func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Is_A_arbace_spec_alpha_Spec_A() {}

func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Is_IObj() {}

func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Is_IMeta() {}

func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_nonconforming_reify__1740000887_A_class }

func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_nonconforming_reify__1740000887_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_nonconforming_reify__1740000887_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_nonconforming_reify__1740000887_A); return ok }

func A_arbace_spec_alpha_nonconforming_reify__1740000887_A_Cast(x any) *A_arbace_spec_alpha_nonconforming_reify__1740000887_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_nonconforming_reify__1740000887_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_nonconforming_reify__1740000887_A_class)) }; return v }



type A_arbace_spec_alpha_noret_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_noret_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha_ns_qualify_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_ns_qualify_A_fn_class *jrt.Class



type A_arbace_spec_alpha_op_describe_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_op_describe_A_fn_class *jrt.Class



type A_arbace_spec_alpha_op_explain_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_op_explain_A_fn_class *jrt.Class



type A_arbace_spec_alpha_op_explain_fn__1740000806_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_op_explain_fn__1740000806_A_fn_class *jrt.Class



type A_arbace_spec_alpha_op_explain_fn__1740000811_A struct{ j2g_header uint64; F_in, F_input, F_path, F_via any }

var A_arbace_spec_alpha_op_explain_fn__1740000811_A_fn_class *jrt.Class



type A_arbace_spec_alpha_op_explain_insufficient__1740000799_A struct{ j2g_header uint64; F_in, F_via any }

var A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_fn_class *jrt.Class



type A_arbace_spec_alpha_op_unform_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_op_unform_A_fn_class *jrt.Class



type A_arbace_spec_alpha_op_unform_fn__1740000759_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_op_unform_fn__1740000759_A_fn_class *jrt.Class



type A_arbace_spec_alpha_op_unform_fn__1740000761_A struct{ j2g_header uint64; F_p1 any }

var A_arbace_spec_alpha_op_unform_fn__1740000761_A_fn_class *jrt.Class



type A_arbace_spec_alpha_op_unform_fn__1740000763_A struct{ j2g_header uint64; F_p0 any }

var A_arbace_spec_alpha_op_unform_fn__1740000763_A_fn_class *jrt.Class



type A_arbace_spec_alpha_op_unform_fn__1740000765_A struct{ j2g_header uint64; F_x, F_kps any }

var A_arbace_spec_alpha_op_unform_fn__1740000765_A_fn_class *jrt.Class



type A_arbace_spec_alpha_or_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_or_A_fn_class *jrt.Class



type A_arbace_spec_alpha_or_k_gen_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_or_k_gen_A_fn_class *jrt.Class



type A_arbace_spec_alpha_or_k_gen_fn__1740000386_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_fn_class *jrt.Class



type A_arbace_spec_alpha_or_spec_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_or_spec_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A struct{ j2g_header uint64; F_forms, F_preds any }

var A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_fn_class *jrt.Class



type A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A struct{ j2g_header uint64; F_specs, F_keys any }

var A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_fn_class *jrt.Class



type A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A struct{ j2g_header uint64; F_specs, F_keys any }

var A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_fn_class *jrt.Class



type A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A struct{ j2g_header uint64; F_specs, F_keys any }

var A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_fn_class *jrt.Class



type A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A struct{ jrt.Object; F_kps, F_gfn, F_forms, F_preds, F_keys, F_id, F_cform any; F___meta lang.IPersistentMap }

func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Is_A_arbace_spec_alpha_Specize_A() {}

func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Is_A_arbace_spec_alpha_Spec_A() {}

func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Is_IObj() {}

func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Is_IMeta() {}

func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_class }

func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A); return ok }

func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_Cast(x any) *A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_class)) }; return v }



type A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A struct{ j2g_header uint64; F_in, F_path, F_via, F_x any }

var A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_fn_class *jrt.Class



type A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A struct{ j2g_header uint64; F_path, F_overrides, F_rmap, F_id any }

var A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_fn_class *jrt.Class



type A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A struct{ j2g_header uint64; F_path, F_f, F_rmap, F_overrides, F_k, F_p any }

var A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_fn_class *jrt.Class



type A_arbace_spec_alpha_pcat_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_pcat_A_fn_class *jrt.Class



type A_arbace_spec_alpha_pcat_STAR__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_pcat_STAR__A_fn_class *jrt.Class



type A_arbace_spec_alpha_preturn_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_preturn_A_fn_class *jrt.Class



type A_arbace_spec_alpha_pvalid_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_pvalid_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha_re_conform_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_re_conform_A_fn_class *jrt.Class



type A_arbace_spec_alpha_re_explain_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_re_explain_A_fn_class *jrt.Class



type A_arbace_spec_alpha_re_gen_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_re_gen_A_fn_class *jrt.Class



type A_arbace_spec_alpha_re_gen_fn__1740000825_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_re_gen_fn__1740000825_A_fn_class *jrt.Class



type A_arbace_spec_alpha_re_gen_ggens__1740000817_A struct{ j2g_header uint64; F_path, F_overrides, F_id, F_rmap any }

var A_arbace_spec_alpha_re_gen_ggens__1740000817_A_fn_class *jrt.Class



type A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A struct{ j2g_header uint64; F_path, F_overrides, F_id, F_rmap any }

var A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_fn_class *jrt.Class



type A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A struct{ j2g_header uint64; F_path, F_f, F_overrides, F_k, F_p, F_rmap any }

var A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_fn_class *jrt.Class



type A_arbace_spec_alpha_recur_limit_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_recur_limit_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha_reg_resolve_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_reg_resolve_A_fn_class *jrt.Class



type A_arbace_spec_alpha_reg_resolve_BANG__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_reg_resolve_BANG__A_fn_class *jrt.Class



type A_arbace_spec_alpha_regex_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_regex_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha_regex_spec_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_regex_spec_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A struct{ jrt.Object; F_gfn, F_re any; F___meta lang.IPersistentMap }

func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Is_A_arbace_spec_alpha_Specize_A() {}

func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Is_A_arbace_spec_alpha_Spec_A() {}

func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Is_IObj() {}

func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Is_IMeta() {}

func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_class }

func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A); return ok }

func A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_Cast(x any) *A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_class)) }; return v }



type A_arbace_spec_alpha_registry_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_registry_A_fn_class *jrt.Class



type A_arbace_spec_alpha_rep_PLUS_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_rep_PLUS_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_rep_STAR__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_rep_STAR__A_fn_class *jrt.Class



type A_arbace_spec_alpha_rep_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_rep_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_res_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_res_A_fn_class *jrt.Class



type A_arbace_spec_alpha_res_fn__1740000229_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_res_fn__1740000229_A_fn_class *jrt.Class



type A_arbace_spec_alpha_res_kind_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_res_kind_A_fn_class *jrt.Class



type A_arbace_spec_alpha_spec_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_spec_A_fn_class *jrt.Class



type A_arbace_spec_alpha_spec_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_spec_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha_spec_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_spec_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_spec_impl_reify__1740000460_A struct{ jrt.Object; F_form, F_unc, F_gfn, F_cpred_QMARK_, F_pred any; F___meta lang.IPersistentMap }

func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Is_A_arbace_spec_alpha_Specize_A() {}

func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Is_A_arbace_spec_alpha_Spec_A() {}

func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Is_IObj() {}

func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Is_IMeta() {}

func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_spec_impl_reify__1740000460_A_class }

func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_spec_impl_reify__1740000460_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_spec_impl_reify__1740000460_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_spec_impl_reify__1740000460_A); return ok }

func A_arbace_spec_alpha_spec_impl_reify__1740000460_A_Cast(x any) *A_arbace_spec_alpha_spec_impl_reify__1740000460_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_spec_impl_reify__1740000460_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_spec_impl_reify__1740000460_A_class)) }; return v }



type A_arbace_spec_alpha_spec_name_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_spec_name_A_fn_class *jrt.Class



type A_arbace_spec_alpha_specize_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_specize_A_fn_class *jrt.Class



type A_arbace_spec_alpha_tagged_ret_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_tagged_ret_A_fn_class *jrt.Class



type A_arbace_spec_alpha_the_spec_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_the_spec_A_fn_class *jrt.Class



type A_arbace_spec_alpha_tuple_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_tuple_A_fn_class *jrt.Class



type A_arbace_spec_alpha_tuple_impl_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_tuple_impl_A_fn_class *jrt.Class



type A_arbace_spec_alpha_tuple_impl_fn__1740000493_A struct{ j2g_header uint64; F_forms, F_preds any }

var A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_fn_class *jrt.Class



type A_arbace_spec_alpha_tuple_impl_reify__1740000495_A struct{ jrt.Object; F_cnt int32; F_gfn, F_forms, F_preds, F_specs any; F___meta lang.IPersistentMap }

func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Is_A_arbace_spec_alpha_Specize_A() {}

func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Is_A_arbace_spec_alpha_Spec_A() {}

func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Is_IObj() {}

func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Is_IMeta() {}

func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_class }

func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_A); return ok }

func A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_Cast(x any) *A_arbace_spec_alpha_tuple_impl_reify__1740000495_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_class)) }; return v }



type A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A struct{ j2g_header uint64; F_in, F_path, F_via, F_x any }

var A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_fn_class *jrt.Class



type A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A struct{ j2g_header uint64; F_path, F_overrides, F_rmap any }

var A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_fn_class *jrt.Class



type A_arbace_spec_alpha_unfn_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_unfn_A_fn_class *jrt.Class



type A_arbace_spec_alpha_unform_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_unform_A_fn_class *jrt.Class



type A_arbace_spec_alpha_valid_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_valid_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_alpha_validate_fn_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_validate_fn_A_fn_class *jrt.Class



type A_arbace_spec_alpha_validate_fn_fn__1740000851_A struct{ j2g_header uint64; F_f, F_specs any }

var A_arbace_spec_alpha_validate_fn_fn__1740000851_A_fn_class *jrt.Class



type A_arbace_spec_alpha_with_gen_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_with_gen_A_fn_class *jrt.Class



type A_arbace_spec_alpha_with_name_A struct{ j2g_header uint64 }

var A_arbace_spec_alpha_with_name_A_fn_class *jrt.Class
