//line j2g_strings.ae:1
package aot_arbace_spec_alpha

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn7,excludeyn1,+yn1,*yn3,andyn6,assertyn2,oryn3,catyn3,defyn4,keysyn5,mergeyn11,arbace.walkkn2,asyn4,walkyn21,arbace.spec.gen.alphayn3,genyn13,arbace.stringyn3,strkn3,docks17,arbace.spec.alpha2,opks17,arbace.spec.alpha4,nameks17,arbace.spec.alpha7,unknownks17,arbace.spec.alpha7,invalidkn4,elseyn2,fnyn1,%ks17,arbace.spec.alpha3,gfnks17,arbace.spec.alpha8,problemsks17,arbace.spec.alpha4,specks17,arbace.spec.alpha5,valuekn4,pathkn4,predkn3,valkn6,reasonkn3,viakn2,inks17,arbace.spec.alpha4,pathks17,arbace.spec.alpha4,formks17,arbace.spec.alpha7,failurekn6,no-genks17,arbace.spec.alpha15,recursion-limitys1,c3,andyn6,ident?yn1,kkn4,linekn6,columnyn9,namespaceys17,arbace.spec.alpha8,def-implyn5,quotekn3,genys17,arbace.spec.alpha9,spec-implys17,arbace.spec.alpha15,multi-spec-implyn3,varkn3,reqkn6,req-unkn3,optkn6,opt-unys11,arbace.core9,contains?yn6,every?yn3,fn*yn15,p1__1740000257#yn8,keyword?yn6,concatyn8,req-keysyn12,req-un-specsyn3,optyn6,opt-unys11,arbace.core4,map?ys11,arbace.core3,andys17,arbace.spec.alpha13,map-spec-implkn8,req-keyskn9,req-specskn8,opt-keyskn9,opt-specskn10,pred-formskn10,pred-exprskn9,keys-predkn3,gfnyn5,even?yn5,countyn14,key-pred-formsys17,arbace.spec.alpha12,or-spec-implys17,arbace.spec.alpha13,and-spec-implys17,arbace.spec.alpha15,merge-spec-implkn4,kindkn4,intokn5,countkn9,max-countkn9,min-countkn8,distinctkn7,gen-maxks17,arbace.spec.alpha8,describeks17,arbace.spec.alpha9,kind-formys17,arbace.spec.alpha5,everyys11,arbace.core5,coll?ys11,arbace.core1,=ys11,arbace.core13,bounded-countys11,arbace.core2,<=ys11,arbace.core2,oryn2,ifys11,arbace.core3,incys17,java.lang.Integer9,MAX_VALUEys11,arbace.core6,empty?ys11,arbace.core5,applyys11,arbace.core9,distinct?ys17,arbace.spec.alpha10,every-implks17,arbace.spec.alpha5,cpredys17,arbace.spec.alpha8,every-kvys17,arbace.spec.alpha5,tupleks17,arbace.spec.alpha3,kfnys11,arbace.core2,fnyn21,i__1740000305__auto__yn21,v__1740000306__auto__ys11,arbace.core3,nthys17,arbace.spec.alpha7,coll-ofks17,arbace.spec.alpha11,conform-allys17,arbace.spec.alpha6,map-ofys17,arbace.spec.alpha8,rep-implys17,arbace.spec.alpha8,rep+implys17,arbace.spec.alpha10,maybe-implys17,arbace.spec.alpha8,alt-implys17,arbace.spec.alpha8,cat-implys17,arbace.spec.alpha8,amp-implys17,arbace.spec.alpha9,conformerys11,arbace.core4,any?kn4,argskn3,retkn2,fnys17,arbace.spec.alpha10,fspec-implys17,arbace.spec.alpha4,specyn3,notyn6,empty?yn5,predsys17,arbace.spec.alpha10,tuple-implks17,arbace.spec.alpha4,argsys17,arbace.spec.alpha3,defys17,arbace.spec.alpha5,fspecys17,arbace.spec.alpha4,keysys17,arbace.spec.alpha10,multi-specyn6,methodys11,arbace.core7,vector?ys11,arbace.core5,countyn7,vector?yn1,xyn1,=ys17,arbace.spec.alpha2,orys17,arbace.spec.alpha3,andys17,arbace.spec.alpha5,mergeys7,Integer9,MAX_VALUEyn9,distinct?kn12,conform-keyskn12,num-elementskn9,max-trieskn12,min-elementskn12,max-elementsks17,arbace.spec.alpha6,acceptkn2,pskn2,kskn5,formskn4,rep+ks17,arbace.spec.alpha4,pcatks17,arbace.spec.alpha3,repkn2,p2kn6,splicekn2,idkn2,p1ys17,arbace.spec.alpha1,*ks17,arbace.spec.alpha3,ampkn3,ampks17,arbace.spec.alpha3,altkn5,maybeks17,arbace.spec.alpha3,nilys17,arbace.spec.alpha1,&ys17,arbace.spec.alpha1,+ys17,arbace.spec.alpha3,catkn1,_ys17,arbace.spec.alpha1,?ys17,arbace.spec.alpha3,altkn6,acceptyn34,p1__1740000844__1740000845__auto__ys11,arbace.core4,nil?ys11,arbace.core11,sequential?kn8,smallestkn6,shrunkyn7,pvalid?yn7,argspecyn4,argsyn5,applyyn4,ifn?ks17,arbace.spec.alpha1,kks17,arbace.spec.alpha1,vys11,arbace.core3,letyn25,mspec__1740000878__auto__ys17,arbace.spec.alpha8,with-genys11,arbace.core8,keyword?ks17,arbace.spec.alpha8,kvs->mapys21,arbace.spec.gen.alpha4,fmapyn21,m__1740000879__auto__ys11,arbace.core6,concatys17,arbace.spec.alpha3,genys17,arbace.spec.alpha13,nonconformingys17,arbace.spec.alpha7,nilableks17,arbace.spec.alpha4,predyn4,nil?ys17,arbace.spec.alpha12,nilable-implyn22,st__1740000921__auto__ys11,arbace.core7,inst-msyn22,et__1740000922__auto__yn26,mkdate__1740000923__auto__yn21,d__1740000924__auto__yn15,java.util.Date.kn3,tagyn4,longys11,arbace.core5,inst?yn34,p1__1740000920__1740000925__auto__ys17,arbace.spec.alpha14,inst-in-range?ys21,arbace.spec.gen.alpha14,large-integer*kn3,minkn3,maxys11,arbace.core4,int?yn34,p1__1740000932__1740000933__auto__ys17,arbace.spec.alpha13,int-in-range?ys11,arbace.core3,deckn9,infinite?kn4,NaN?yn15,p1__1740000939#ys6,Double10,isInfiniteyn15,p1__1740000940#ys6,Double5,isNaNys11,arbace.core7,double?yn34,p1__1740000941__1740000942__auto__yn34,p1__1740000943__1740000944__auto__ys21,arbace.spec.gen.alpha7,double*kn16,assertion-failedys14,arbace.lang.RT16,checkSpecAssertsys17,arbace.spec.alpha7,assert*v11,arbace.core7,requirev11,arbace.core5,referR0,R1,V9,R2,R3,R4,R5,R6,R7,R8,R9,R10,V3,R11,R12,R13,V3,R14,R12,R15,V3,R16,R12,R17,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn17,arbace.spec.alpham2,R18,s254,The spec library specifies the structure of data or functions and provides\n  operations to validate, conform, explain, describe, and generate data based on\n  the specs.\n\n  Rationale: https://clojure.org/about/spec\n  Guide: https://clojure.org/guides/specv11,arbace.core13,*loaded-libs*v11,arbace.core18,-cache-protocol-fnC22,arbace.spec.alpha.Specv11,arbace.core6,ident?v11,arbace.core3,notv17,arbace.spec.alpha12,deep-resolvev17,arbace.spec.alpha12,registry-refv17,arbace.spec.alpha11,reg-resolveR19,v17,arbace.spec.alpha6,regex?v11,arbace.core5,assocv11,arbace.core9,with-metaR20,v17,arbace.spec.alpha5,spec?v17,arbace.spec.alpha9,with-namev17,arbace.spec.alpha15,regex-spec-implv17,arbace.spec.alpha9,spec-namev17,arbace.spec.alpha10,maybe-specC25,arbace.spec.alpha.Specizev11,arbace.core10,re-matchesv11,arbace.core4,not=v11,arbace.core6,symbolp22,(.*)\\$(.*?)(__[0-9]+)?v17,arbace.spec.alpha12,reg-resolve!v17,arbace.spec.alpha8,specize*v17,arbace.spec.alpha9,spec-implv11,arbace.core4,ifn?v17,arbace.spec.alpha6,fn-symv11,arbace.core4,map?R21,R22,v17,arbace.spec.alpha7,specizev17,arbace.spec.alpha8,conform*v17,arbace.spec.alpha7,unform*v17,arbace.spec.alpha9,describe*v11,arbace.core4,seq?v11,arbace.walk8,postwalkv11,arbace.core7,symbol?v11,arbace.core9,namespaceR23,R24,v11,arbace.core5,firstV1,R25,v11,arbace.core6,secondv11,arbace.core4,lastv11,arbace.core4,namev17,arbace.spec.alpha6,abbrevv17,arbace.spec.alpha4,formv17,arbace.spec.alpha9,with-gen*R26,v17,arbace.spec.alpha8,explain*v11,arbace.core6,empty?R27,R28,R29,v17,arbace.spec.alpha13,explain-data*v11,arbace.core7,sort-byv11,arbace.core3,seqv11,arbace.core4,nextv11,arbace.core8,to-arrayR30,R31,R32,R33,R34,R35,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core7,printlnv11,arbace.core7,newlinev11,arbace.core2,prv11,arbace.core5,printv11,arbace.core6,pr-strS6,R30,R31,R34,R32,R33,R35,v11,arbace.core10,chunk-restS6,R30,R31,R34,R32,R33,R35,S6,R30,R31,R34,R32,R33,R35,S6,R30,R31,R34,R32,R33,R35,v17,arbace.spec.alpha13,*explain-out*v17,arbace.spec.alpha11,explain-outv17,arbace.spec.alpha12,explain-datav11,arbace.core3,strv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v17,arbace.spec.alpha7,explainv17,arbace.spec.alpha4,gen*v21,arbace.spec.gen.alpha9,such-thatv11,arbace.core7,ex-infov17,arbace.spec.alpha6,valid?l100,R36,R37,R38,R39,v17,arbace.spec.alpha6,gensubR40,v17,arbace.spec.alpha17,*recursion-limit*v17,arbace.spec.alpha3,genv11,arbace.core4,var?v11,arbace.core4,restv11,arbace.walk16,postwalk-replaceV1,R25,R24,R25,v11,arbace.core8,keyword?v17,arbace.spec.alpha5,->symv11,arbace.core11,sequential?v11,arbace.core7,resolvev17,arbace.spec.alpha3,resv17,arbace.spec.alpha4,unfnv11,arbace.core5,swap!ML3,R41,ML2,R42,R43,m4,R44,i334,R45,i20,ML2,R46,R43,m4,R44,i334,R45,i31,m4,R44,i334,R45,i13,v11,arbace.core6,dissocv11,arbace.core10,ns-aliasesv11,arbace.core4,*ns*v17,arbace.spec.alpha10,ns-qualifyv11,arbace.core6,concatv11,arbace.core4,listR47,R48,v17,arbace.spec.alpha8,registryR49,R50,R51,R52,R53,R54,R55,R56,v11,arbace.core7,keywordv11,arbace.core7,filtervv11,arbace.core6,every?v11,arbace.core4,intov11,arbace.core6,gensymv11,arbace.core3,mapR57,R57,v11,arbace.core4,mapvv11,arbace.core7,flattenML3,R58,L3,R59,V1,R60,ML3,R41,ML2,R61,R60,m4,R44,i450,R45,i37,ML2,R46,R60,m4,R44,i450,R45,i50,m4,R44,i450,R45,i30,ML5,R62,R63,R64,R65,R66,m4,R44,i450,R45,i65,m4,R44,i450,R45,i21,v11,arbace.core3,vecR67,v11,arbace.core8,identityR59,v11,arbace.core5,applyv11,arbace.core6,vectorR68,R59,R69,R70,R71,R72,R73,R74,R75,R76,R77,v11,arbace.core9,partitionl2,v11,arbace.core5,even?ML3,R41,ML2,R78,ML2,R79,R80,m4,R44,i494,R45,i29,m4,R44,i494,R45,i22,ML3,R58,R61,R9,m4,R44,i494,R45,i53,m4,R44,i494,R45,i15,R81,R82,R83,R84,v11,arbace.core6,mapcatR85,R86,R87,R88,R89,R90,R91,R92,v17,arbace.spec.alpha8,res-kindR93,R94,R95,R96,R97,R98,l0,R96,R99,R100,R98,R101,R98,R102,R103,R104,R105,R106,R59,R68,R107,R93,R108,R109,R110,R111,R112,R113,R114,R93,R115,R116,R107,R67,R117,R118,R119,ML3,R41,ML2,R78,ML2,R79,R80,m4,R44,i643,R45,i29,m4,R44,i643,R45,i22,ML3,R58,R61,R9,m4,R44,i643,R45,i53,m4,R44,i643,R45,i15,R120,ML3,R41,ML2,R78,ML2,R79,R80,m4,R44,i659,R45,i29,m4,R44,i659,R45,i22,ML3,R58,R61,R9,m4,R44,i659,R45,i53,m4,R44,i659,R45,i15,R121,R122,R50,R123,R50,R123,R124,R125,R126,R127,R128,R129,R129,R129,ML2,R130,ML2,R131,R132,m4,R44,i703,R45,i18,m4,R44,i703,R45,i13,R133,v17,arbace.spec.alpha8,get-specv17,arbace.spec.alpha8,invalid?v17,arbace.spec.alpha7,conformR134,R135,R136,v11,arbace.core9,contains?v11,arbace.core3,setv17,arbace.spec.alpha8,the-specv17,arbace.spec.alpha2,dtv21,arbace.spec.gen.alpha6,returnR6,v17,arbace.spec.alpha8,or-k-genR4,v17,arbace.spec.alpha9,and-k-genl1,v21,arbace.spec.gen.alpha4,bindv21,arbace.spec.gen.alpha5,tuplev11,arbace.core4,takev21,arbace.spec.gen.alpha6,choosev21,arbace.spec.gen.alpha7,shufflev17,arbace.spec.alpha5,k-genv11,arbace.core6,zipmapv11,arbace.core4,consR137,v17,arbace.spec.alpha13,map-spec-implv17,arbace.spec.alpha4,inckv17,arbace.spec.alpha12,recur-limit?v21,arbace.spec.gen.alpha10,delay-implv11,arbace.core6,removev11,arbace.core4,nil?v11,arbace.core4,compv21,arbace.spec.gen.alpha8,hash-mapv11,arbace.core6,filterR67,v11,arbace.core4,keepv17,arbace.spec.alpha7,pvalid?v17,arbace.spec.alpha9,explain-1v11,arbace.core4,keysv17,arbace.spec.alpha6,unformv17,arbace.spec.alpha8,with-genv21,arbace.spec.gen.alpha12,gen-for-predR138,v17,arbace.spec.alpha15,multi-spec-implv21,arbace.spec.gen.alpha4,fmapR139,v21,arbace.spec.gen.alpha6,one-ofv11,arbace.core7,methodsR108,v17,arbace.spec.alpha10,tuple-implv11,arbace.core5,rangev11,arbace.core7,vector?R140,R95,R141,R25,ML3,R41,ML2,R142,R143,m4,R44,i1027,R45,i35,ML3,R144,ML2,R79,R143,m4,R44,i1028,R45,i38,ML2,R79,R132,m4,R44,i1028,R45,i48,m4,R44,i1028,R45,i35,m4,R44,i1027,R45,i28,v17,arbace.spec.alpha10,tagged-retR145,v17,arbace.spec.alpha12,or-spec-implR146,v17,arbace.spec.alpha13,and-spec-implv17,arbace.spec.alpha17,explain-pred-listv11,arbace.core6,reducev11,arbace.core7,reverseR147,v17,arbace.spec.alpha15,merge-spec-implv11,arbace.core5,mergev11,arbace.core4,somev11,arbace.core5,coll?R94,v11,arbace.core13,bounded-countR95,R141,R25,v11,arbace.core2,<=R97,R141,R25,R148,v11,arbace.core9,distinct?R149,R150,v11,arbace.core5,emptyv17,arbace.spec.alpha10,empty-collv11,arbace.core5,list?v11,arbace.core10,constantlyR93,v17,arbace.spec.alpha10,every-implv21,arbace.spec.gen.alpha15,vector-distinctv21,arbace.spec.gen.alpha6,vectorR151,R152,R153,R154,v17,arbace.spec.alpha9,coll-probv11,arbace.core7,partialv17,arbace.spec.alpha18,*coll-error-limit*v11,arbace.core8,indexed?v17,arbace.spec.alpha18,*coll-check-limit*R155,R156,R157,R158,R159,v17,arbace.spec.alpha7,accept?v17,arbace.spec.alpha5,pcat*v17,arbace.spec.alpha6,acceptR160,R161,R162,R163,R164,R165,v17,arbace.spec.alpha4,rep*R166,R167,R168,v11,arbace.core6,repeatv17,arbace.spec.alpha10,filter-altR169,v17,arbace.spec.alpha4,alt*v17,arbace.spec.alpha4,altsR170,R171,S2,R161,R160,v17,arbace.spec.alpha11,accept-nil?v17,arbace.spec.alpha9,and-predsv17,arbace.spec.alpha7,preturnv17,arbace.spec.alpha6,noret?v17,arbace.spec.alpha7,add-retv17,arbace.spec.alpha9,op-unformv17,arbace.spec.alpha5,derivv17,arbace.spec.alpha8,amp-implv17,arbace.spec.alpha4,alt2v11,arbace.core5,list*R172,R173,R166,R173,R174,R175,R176,R177,v17,arbace.spec.alpha10,op-explainv17,arbace.spec.alpha11,op-describev17,arbace.spec.alpha6,re-genR178,v21,arbace.spec.gen.alpha3,catv17,arbace.spec.alpha10,re-explainR59,R179,R98,R180,R181,v17,arbace.spec.alpha10,re-conformv21,arbace.spec.gen.alpha8,for-all*v21,arbace.spec.gen.alpha11,quick-checkR182,R183,v17,arbace.spec.alpha11,call-valid?R136,v17,arbace.spec.alpha10,fspec-implv21,arbace.spec.gen.alpha8,generateML3,R184,R185,R186,m4,R44,i1790,R45,i27,v17,arbace.spec.alpha11,validate-fnML2,R187,R24,m4,R44,i1777,R45,i46,R188,v17,arbace.spec.alpha18,*fspec-iterations*v17,arbace.spec.alpha8,describeR189,R190,R191,R192,R137,R193,R172,R166,R174,R194,R124,R195,R110,R196,R110,R197,R103,R198,R199,R200,v17,arbace.spec.alpha13,nonconformingR201,v17,arbace.spec.alpha12,nilable-implv21,arbace.spec.gen.alpha9,frequencyl9,R202,R203,R204,v21,arbace.spec.gen.alpha6,samplev17,arbace.spec.alpha8,exercisel10,v11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv17,arbace.spec.alpha11,exercise-fnv11,arbace.core5,inst?v11,arbace.core7,inst-msR191,R205,R206,R207,R206,R208,R110,R209,R210,R211,R212,R129,R146,R213,R214,R215,R110,R196,R216,R217,R218,v11,arbace.core4,int?R129,R146,R219,R220,R221,R216,R222,R223,R224,R129,V1,L3,R59,V1,R225,ML2,R130,ML2,R226,R225,m4,R44,i1936,R45,i45,m4,R44,i1936,R45,i40,V1,L3,R59,V1,R227,ML2,R130,ML2,R228,R227,m4,R44,i1937,R45,i40,m4,R44,i1937,R45,i35,R146,R229,R230,R97,R231,R97,R232,R233,v17,arbace.spec.alpha17,*compile-asserts*R99,R234,R235,")

var Lit_1 *jrt.String = jrt.Intern("arbace.spec.alpha$abbrev$fn__1740000170")

var Lit_2 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_3 *jrt.String = jrt.Intern("arbace.spec.alpha$add_ret$prop__1740000773")

var Lit_4 *jrt.String = jrt.Intern("Assert failed: ")

var Lit_5 *jrt.String = jrt.Intern("alt expects k1 p1 k2 p2..., where ks are keywords")

var Lit_6 *jrt.String = jrt.Intern("\n")

var Lit_7 *jrt.String = jrt.Intern("arbace.spec.alpha$and_spec_impl$fn__1740000569")

var Lit_8 *jrt.String = jrt.Intern("arbace.spec.alpha$and_spec_impl$fn__1740000572")

var Lit_9 *jrt.String = jrt.Intern("arbace.spec.alpha$and_spec_impl$fn__1740000574")

var Lit_10 *jrt.String = jrt.Intern("arbace.spec.alpha$and_spec_impl$fn__1740000576")

var Lit_11 *jrt.String = jrt.Intern("arbace.spec.alpha$and_spec_impl$reify__1740000578$fn__1740000579")

var Lit_12 *jrt.String = jrt.Intern("Spec assertion failed\n")

var Lit_13 *jrt.String = jrt.Intern("arbace.spec.alpha$assert_STAR_$fn__1740000960")

var Lit_14 *jrt.String = jrt.Intern("cat expects k1 p1 k2 p2..., where ks are keywords")

var Lit_15 *jrt.String = jrt.Intern("k must be namespaced keyword or resolvable symbol")

var Lit_16 *jrt.String = jrt.Intern("arbace.spec.alpha$deriv$fn__1740000787")

var Lit_17 *jrt.String = jrt.Intern(" is not a fn, expected predicate fn")

var Lit_18 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000035$G__1740000021__1740000041")

var Lit_19 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000035$G__1740000020__1740000048")

var Lit_20 *jrt.String = jrt.Intern("explain_STAR_")

var Lit_21 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000051$G__1740000025__1740000054")

var Lit_22 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000051$G__1740000024__1740000058")

var Lit_23 *jrt.String = jrt.Intern("with_gen_STAR_")

var Lit_24 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000061$G__1740000023__1740000066")

var Lit_25 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000061$G__1740000022__1740000072")

var Lit_26 *jrt.String = jrt.Intern("gen_STAR_")

var Lit_27 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000075$G__1740000017__1740000078")

var Lit_28 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000075$G__1740000016__1740000082")

var Lit_29 *jrt.String = jrt.Intern("conform_STAR_")

var Lit_30 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000085$G__1740000027__1740000087")

var Lit_31 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000085$G__1740000026__1740000090")

var Lit_32 *jrt.String = jrt.Intern("describe_STAR_")

var Lit_33 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000093$G__1740000019__1740000096")

var Lit_34 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000093$G__1740000018__1740000100")

var Lit_35 *jrt.String = jrt.Intern("unform_STAR_")

var Lit_36 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000127$fn__1740000128$G__1740000120__1740000132")

var Lit_37 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000127$fn__1740000128$G__1740000119__1740000137")

var Lit_38 *jrt.String = jrt.Intern("specize_STAR_")

var Lit_39 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$fn__1740000614")

var Lit_40 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$check_QMARK___1740000616")

var Lit_41 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$fn__1740000618")

var Lit_42 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$addcv__1740000620")

var Lit_43 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$cfns__1740000622")

var Lit_44 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$cfns__1740000622$fn__1740000623")

var Lit_45 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$cfns__1740000622$fn__1740000625")

var Lit_46 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$cfns__1740000622$fn__1740000627")

var Lit_47 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$reify__1740000630$fn__1740000669")

var Lit_48 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$reify__1740000630$fn__1740000671")

var Lit_49 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$reify__1740000630$fn__1740000667")

var Lit_50 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl$reify__1740000630$fn__1740000671$fn__1740000672")

var Lit_51 *jrt.String = jrt.Intern("arbace.spec.alpha$exercise$fn__1740000905")

var Lit_52 *jrt.String = jrt.Intern("arbace.spec.alpha$exercise_fn$iter__1740000908__1740000912")

var Lit_53 *jrt.String = jrt.Intern("No :args spec found, can't generate")

var Lit_54 *jrt.String = jrt.Intern("arbace.spec.alpha$exercise_fn$iter__1740000908__1740000912$fn__1740000913")

var Lit_55 *jrt.String = jrt.Intern("arbace.spec.alpha$exercise_fn$iter__1740000908__1740000912$fn__1740000913$fn__1740000914")

var Lit_56 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_printer$fn__1740000179")

var Lit_57 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_printer$fn__1740000181")

var Lit_58 *jrt.String = jrt.Intern(" - failed: ")

var Lit_59 *jrt.String = jrt.Intern(" in: ")

var Lit_60 *jrt.String = jrt.Intern(" at: ")

var Lit_61 *jrt.String = jrt.Intern(" spec: ")

var Lit_62 *jrt.String = jrt.Intern("\n\t")

var Lit_63 *jrt.String = jrt.Intern(" ")

var Lit_64 *jrt.String = jrt.Intern("Success!")

var Lit_65 *jrt.String = jrt.Intern("arbace.spec.alpha$filter_alt$fn__1740000703")

var Lit_66 *jrt.String = jrt.Intern("arbace.spec.alpha$filter_alt$fn__1740000705")

var Lit_67 *jrt.String = jrt.Intern("arbace.spec.alpha$fn__1740000870$fn__1740000872")

var Lit_68 *jrt.String = jrt.Intern("fn")

var Lit_69 *jrt.String = jrt.Intern("arbace.spec.alpha$fspec_impl$reify__1740000857$fn__1740000860")

var Lit_70 *jrt.String = jrt.Intern("arbace.spec.alpha$fspec_impl$reify__1740000857$fn__1740000858")

var Lit_71 *jrt.String = jrt.Intern("Can't conform fspec without args spec: ")

var Lit_72 *jrt.String = jrt.Intern("arbace.spec.alpha$fspec_impl$reify__1740000857$fn__1740000860$fn__1740000861")

var Lit_73 *jrt.String = jrt.Intern("arbace.spec.alpha$gensub$fn__1740000216")

var Lit_74 *jrt.String = jrt.Intern("Unable to construct gen at: ")

var Lit_75 *jrt.String = jrt.Intern(" for: ")

var Lit_76 *jrt.String = jrt.Intern("arbace.spec.alpha$keys$unk__1740000261")

var Lit_77 *jrt.String = jrt.Intern("arbace.spec.alpha$keys$fn__1740000263")

var Lit_78 *jrt.String = jrt.Intern("all keys must be namespace-qualified keywords")

var Lit_79 *jrt.String = jrt.Intern("arbace.spec.alpha$keys$parse_req__1740000265")

var Lit_80 *jrt.String = jrt.Intern("arbace.spec.alpha$keys$fn__1740000271")

var Lit_81 *jrt.String = jrt.Intern("arbace.spec.alpha$keys$parse_req__1740000265$fn__1740000266")

var Lit_82 *jrt.String = jrt.Intern("arbace.spec.alpha$keys$parse_req__1740000265$fn__1740000266$fn__1740000267")

var Lit_83 *jrt.String = jrt.Intern("Call to ")

var Lit_84 *jrt.String = jrt.Intern(" did not conform to spec.")

var Lit_85 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$keys__GT_specnames__1740000399")

var Lit_86 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$rgen__1740000441")

var Lit_87 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$ogen__1740000443")

var Lit_88 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000448")

var Lit_89 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000431")

var Lit_90 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000433")

var Lit_91 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000436")

var Lit_92 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000448$fn__1740000452")

var Lit_93 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl$reify__1740000401$ogen__1740000443$fn__1740000444")

var Lit_94 *jrt.String = jrt.Intern("arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000598")

var Lit_95 *jrt.String = jrt.Intern("arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000600")

var Lit_96 *jrt.String = jrt.Intern("arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000596")

var Lit_97 *jrt.String = jrt.Intern("arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000594")

var Lit_98 *jrt.String = jrt.Intern("arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000592")

var Lit_99 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$predx__1740000468")

var Lit_100 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$dval__1740000470")

var Lit_101 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$fn__1740000472")

var Lit_102 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$reify__1740000474$gen__1740000476")

var Lit_103 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$reify__1740000474$fn__1740000486")

var Lit_104 *jrt.String = jrt.Intern("no method")

var Lit_105 *jrt.String = jrt.Intern("No method of: ")

var Lit_106 *jrt.String = jrt.Intern(" for dispatch value: ")

var Lit_107 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$reify__1740000474$gen__1740000476$fn__1740000480")

var Lit_108 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl$reify__1740000474$gen__1740000476$fn__1740000480$fn__1740000481")

var Lit_109 *jrt.String = jrt.Intern("arbace.spec.alpha$nilable_impl$fn__1740000890")

var Lit_110 *jrt.String = jrt.Intern("arbace.spec.alpha$nilable_impl$reify__1740000892$fn__1740000893")

var Lit_111 *jrt.String = jrt.Intern("arbace.spec.alpha$nilable_impl$reify__1740000892$fn__1740000895")

var Lit_112 *jrt.String = jrt.Intern("arbace.spec.alpha$nonconforming$fn__1740000885")

var Lit_113 *jrt.String = jrt.Intern("arbace.spec.alpha$op_explain$insufficient__1740000799")

var Lit_114 *jrt.String = jrt.Intern("arbace.spec.alpha$op_explain$fn__1740000806")

var Lit_115 *jrt.String = jrt.Intern("arbace.spec.alpha$op_explain$fn__1740000811")

var Lit_116 *jrt.String = jrt.Intern("Insufficient input")

var Lit_117 *jrt.String = jrt.Intern("arbace.spec.alpha$op_unform$fn__1740000759")

var Lit_118 *jrt.String = jrt.Intern("arbace.spec.alpha$op_unform$fn__1740000761")

var Lit_119 *jrt.String = jrt.Intern("arbace.spec.alpha$op_unform$fn__1740000763")

var Lit_120 *jrt.String = jrt.Intern("arbace.spec.alpha$op_unform$fn__1740000765")

var Lit_121 *jrt.String = jrt.Intern("spec/or expects k1 p1 k2 p2..., where ks are keywords")

var Lit_122 *jrt.String = jrt.Intern("arbace.spec.alpha$or_k_gen$fn__1740000386")

var Lit_123 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$fn__1740000503")

var Lit_124 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$fn__1740000506")

var Lit_125 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$fn__1740000508")

var Lit_126 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$fn__1740000510")

var Lit_127 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$reify__1740000513$gen__1740000519")

var Lit_128 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$reify__1740000513$fn__1740000517")

var Lit_129 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl$reify__1740000513$gen__1740000519$fn__1740000520")

var Lit_130 *jrt.String = jrt.Intern("Extra input")

var Lit_131 *jrt.String = jrt.Intern("arbace.spec.alpha$re_gen$ggens__1740000817")

var Lit_132 *jrt.String = jrt.Intern("arbace.spec.alpha$re_gen$fn__1740000825")

var Lit_133 *jrt.String = jrt.Intern("arbace.spec.alpha$re_gen$ggens__1740000817$gen__1740000818")

var Lit_134 *jrt.String = jrt.Intern("arbace.spec.alpha$re_gen$ggens__1740000817$gen__1740000818$fn__1740000819")

var Lit_135 *jrt.String = jrt.Intern("Unable to resolve spec: ")

var Lit_136 *jrt.String = jrt.Intern("arbace.spec.alpha$res$fn__1740000229")

var Lit_137 *jrt.String = jrt.Intern("no unform fn for conformer")

var Lit_138 *jrt.String = jrt.Intern("arbace.spec.alpha$tuple_impl$fn__1740000493")

var Lit_139 *jrt.String = jrt.Intern("arbace.spec.alpha$tuple_impl$reify__1740000495$gen__1740000498")

var Lit_140 *jrt.String = jrt.Intern("arbace.spec.alpha$tuple_impl$reify__1740000495$fn__1740000496")

var Lit_141 *jrt.String = jrt.Intern("fn*")

var Lit_142 *jrt.String = jrt.Intern("arbace.spec.alpha$validate_fn$fn__1740000851")

var Lit_143 *jrt.String = jrt.Intern("kn3,docyn11,arbace.coreyn1,ckn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn4,specyn1,xyn1,yyn4,pathyn3,viayn2,inyn9,overridesyn4,rmapyn3,gfnkn2,onyn22,arbace.spec.alpha.Speckn12,on-interfacekn4,sigskn8,conform*kn3,tagkn4,namekn7,unform*kn8,explain*kn4,gen*kn9,with-gen*kn9,describe*kn3,varkn10,method-mapkn15,method-builderskn8,protocolyn4,Speckn7,privateyn3,regyn1,kyn4,namekn8,declaredyn9,spec-or-kyn1,_yn4,formyn25,arbace.spec.alpha.Specizekn8,specize*yn7,Specizeyn6,Objectyn1,syn3,retyn6,gen-fnyn2,edyn16,java.lang.Stringyn4,exprkn9,skip-wikiyn9,spec-formyn1,&kn4,keysyn3,genyn2,mmyn5,retagyn3,reqyn6,req-unyn3,optyn6,opt-unyn14,key-pred-formsyn10,pred-formsyn4,optsyn4,predyn4,intoyn4,kindyn5,countyn9,max-countyn9,min-countyn8,distinctyn7,gen-maxkn2,asyn5,kpredyn5,vpredv11,arbace.core5,in-nsMyn17,arbace.spec.alpham2,R0,s254,The spec library specifies the structure of data or functions and provides\n  operations to validate, conform, explain, describe, and generate data based on\n  the specs.\n\n  Rationale: https://clojure.org/about/spec\n  Guide: https://clojure.org/guides/specm2,R0,s254,The spec library specifies the structure of data or functions and provides\n  operations to validate, conform, explain, describe, and generate data based on\n  the specs.\n\n  Rationale: https://clojure.org/about/spec\n  Guide: https://clojure.org/guides/specR1,v11,arbace.core5,aliasR2,R1,v11,arbace.core20,*warn-on-reflection*v17,arbace.spec.alpha17,*recursion-limit*l4,m10,R3,TR4,i30,R5,i1,R6,s20,arbace/spec/alpha.aeR0,s175,A soft limit on how many times a branching spec (or/alt/*/opt-keys/multi-spec)\n  can be recursed through during generation. After this a\n  non-recursive branch will be chosen.v17,arbace.spec.alpha18,*fspec-iterations*l21,m10,R3,TR4,i36,R5,i1,R6,s20,arbace/spec/alpha.aeR0,s99,The number of times an anonymous fn specified by fspec will be (generatively) tested during conformv17,arbace.spec.alpha18,*coll-check-limit*l101,m10,R3,TR4,i40,R5,i1,R6,s20,arbace/spec/alpha.aeR0,s69,The number of elements validated in a collection spec'ed with 'every'v17,arbace.spec.alpha18,*coll-error-limit*l20,m10,R3,TR4,i44,R5,i1,R6,s20,arbace/spec/alpha.aeR0,s77,The number of errors reported by explain in a collection spec'ed with 'every'v17,arbace.spec.alpha4,Specm6,R4,i48,R5,i1,R6,s20,arbace/spec/alpha.aem6,R4,i48,R5,i1,R6,s20,arbace/spec/alpha.aeC22,arbace.spec.alpha.Specv11,arbace.core11,alter-meta!v11,arbace.core5,assocR0,v11,arbace.core20,assert-same-protocolL6,Myn8,conform*m4,R0,nR7,L1,V2,R8,R9,Myn7,unform*m4,R0,nR7,L1,V2,R8,R10,Myn8,explain*m4,R0,nR7,L1,V5,R8,R11,R12,R13,R9,Myn4,gen*m4,R0,nR7,L1,V4,R8,R14,R11,R15,Myn9,with-gen*m4,R0,nR7,L1,V2,R8,R16,Myn9,describe*m4,R0,nR7,L1,V1,R8,v11,arbace.core14,alter-var-rootv11,arbace.core5,mergem4,R17,R18,R19,C22,arbace.spec.alpha.SpecR20,m12,R21,m8,R22,nR23,Myn8,conform*m4,R0,nR7,L1,V2,R8,R9,R7,L1,V2,R8,R9,R0,nR24,m8,R22,nR23,Myn7,unform*m4,R0,nR7,L1,V2,R8,R10,R7,L1,V2,R8,R10,R0,nR25,m8,R22,nR23,Myn8,explain*m4,R0,nR7,L1,V5,R8,R11,R12,R13,R9,R7,L1,V5,R8,R11,R12,R13,R9,R0,nR26,m8,R22,nR23,Myn4,gen*m4,R0,nR7,L1,V4,R8,R14,R11,R15,R7,L1,V4,R8,R14,R11,R15,R0,nR27,m8,R22,nR23,Myn9,with-gen*m4,R0,nR7,L1,V2,R8,R16,R7,L1,V2,R8,R16,R0,nR28,m8,R22,nR23,Myn9,describe*m4,R0,nR7,L1,V1,R8,R7,L1,V1,R8,R0,nR29,R30,m12,R27,R27,R24,R24,R26,R26,R21,R21,R25,R25,R28,R28,R31,v11,arbace.core6,internv11,arbace.core4,*ns*v11,arbace.core9,with-metaMyn8,explain*m4,R0,nR7,L1,V5,R8,R11,R12,R13,R9,m8,R22,nR23,Myn8,explain*m4,R0,nR7,L1,V5,R8,R11,R12,R13,R9,R7,L1,V5,R8,R11,R12,R13,R9,R0,nR32,Myn9,with-gen*m4,R0,nR7,L1,V2,R8,R16,m8,R22,nR23,Myn9,with-gen*m4,R0,nR7,L1,V2,R8,R16,R7,L1,V2,R8,R16,R0,nMyn4,gen*m4,R0,nR7,L1,V4,R8,R14,R11,R15,m8,R22,nR23,Myn4,gen*m4,R0,nR7,L1,V4,R8,R14,R11,R15,R7,L1,V4,R8,R14,R11,R15,R0,nMyn8,conform*m4,R0,nR7,L1,V2,R8,R9,m8,R22,nR23,Myn8,conform*m4,R0,nR7,L1,V2,R8,R9,R7,L1,V2,R8,R9,R0,nMyn9,describe*m4,R0,nR7,L1,V1,R8,m8,R22,nR23,Myn9,describe*m4,R0,nR7,L1,V1,R8,R7,L1,V1,R8,R0,nMyn7,unform*m4,R0,nR7,L1,V2,R8,R10,m8,R22,nR23,Myn7,unform*m4,R0,nR7,L1,V2,R8,R10,R7,L1,V2,R8,R10,R0,nv11,arbace.core14,-reset-methodsR33,v17,arbace.spec.alpha12,registry-refm8,R34,TR4,i56,R5,i1,R6,s20,arbace/spec/alpha.aev11,arbace.core4,atomm8,R34,TR4,i56,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha12,deep-resolvem10,R34,TR7,L1,V2,R35,R36,R4,i58,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha11,reg-resolvem12,R34,TR7,L1,V1,R36,R0,s96,returns the spec/regex at end of alias chain starting with k, nil if not found, k if k not identR4,i64,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha12,reg-resolve!m12,R34,TR7,L1,V1,R36,R0,s99,returns the spec/regex at end of alias chain starting with k, throws if not found, k if k not identR4,i75,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha5,spec?m10,R7,L1,V1,R9,R0,s51,returns x if x is a spec object, else logical falseR4,i83,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha6,regex?m10,R7,L1,V1,R9,R0,s62,returns x if x is a (arbace.spec) regex op, else logical falseR4,i89,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha9,with-namem10,R34,TR7,L1,V2,R8,R37,R4,i94,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha9,spec-namem10,R34,TR7,L1,V1,R8,R4,i102,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha9,spec-implm8,R38,TR4,i111,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha15,regex-spec-implm8,R38,TR4,i112,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha10,maybe-specm12,R34,TR7,L1,V1,R39,R0,s71,spec-or-k must be a spec, regex or resolvable kw/sym, else returns nil.R4,i114,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,the-specm12,R34,TR7,L1,V1,R39,R0,s90,spec-or-k must be a spec, regex or kw/sym, else returns nil. Throws if unresolvable kw/symR4,i125,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha7,Specizem6,R4,i132,R5,i1,R6,s20,arbace/spec/alpha.aem6,R4,i132,R5,i1,R6,s20,arbace/spec/alpha.aeC25,arbace.spec.alpha.SpecizeL1,Myn8,specize*m4,R0,nR7,L2,V1,R40,V2,R40,R41,m4,R17,R42,R19,C25,arbace.spec.alpha.Specizem2,R43,m8,R22,nR23,Myn8,specize*m4,R0,nR7,L2,V1,R40,V2,R40,R41,R7,L2,V1,R40,V2,R40,R41,R0,nm2,R43,R43,Myn8,specize*m4,R0,nR7,L2,V1,R40,V2,R40,R41,m8,R22,nR23,Myn8,specize*m4,R0,nR7,L2,V1,R40,V2,R40,R41,R7,L2,V1,R40,V2,R40,R41,R0,nR44,v17,arbace.spec.alpha6,fn-symm10,R34,TR7,L1,V1,Myn1,fm2,R22,R45,R4,i135,R5,i1,R6,s20,arbace/spec/alpha.aev11,arbace.core6,extendC19,arbace.lang.KeywordR43,C18,arbace.lang.SymbolC26,arbace.lang.IPersistentSetC16,java.lang.Objectv17,arbace.spec.alpha7,specizem10,R34,TR7,L2,V1,R46,V2,R46,R41,R4,i162,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,invalid?m10,R7,L1,V1,R47,R0,s44,tests the validity of a conform return valueR4,i166,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha7,conformm10,R7,L1,V2,R8,R9,R0,s132,Given a spec and a value, returns :arbace.spec.alpha/invalid \n\tif value does not match spec, else the (possibly destructured) value.R4,i171,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha6,unformm10,R7,L1,V2,R8,R9,R0,s152,Given a spec and a value created by or compliant with a call to\n  'conform' with the same spec, returns a value with all conform\n  destructuring undone.R4,i177,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha4,formm10,R7,L1,V1,R8,R0,s24,returns the spec as dataR4,i184,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha6,abbrevm8,R7,L1,V1,R41,R4,i190,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,describem10,R7,L1,V1,R8,R0,s54,returns an abbreviated description of the spec as dataR4,i209,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,with-genm10,R7,L1,V2,R8,R48,R0,s109,Takes a spec and a no-arg, generator-returning fn and returns a version of that spec that uses that generatorR4,i214,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha13,explain-data*m8,R7,L1,V5,R8,R11,R12,R13,R9,R4,i222,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha12,explain-datam10,R7,L1,V2,R8,R9,R0,s296,Given a spec and a value x which ought to conform, returns nil if x\n  conforms, else a map with at least the key ::problems whose value is\n  a collection of problem-maps, where problem-map has at least :path :pred and :val\n  keys describing the predicate and the value that failed at that\n  path.R4,i229,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha15,explain-printerm10,R7,L1,V1,R49,R0,s72,Default printer for explain-data. nil indicates a successful validation.R4,i238,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha13,*explain-out*m8,R3,TR4,i263,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha11,explain-outm10,R7,L1,V1,R49,R0,s120,Prints explanation data (per 'explain-data') to *out* using the printer in *explain-out*,\n   by default explain-printer.R4,i265,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha7,explainm10,R7,L1,V2,R8,R9,R0,s79,Given a spec and a value that fails to conform, prints an explanation to *out*.R4,i271,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha11,explain-strm10,R7,L1,MV2,R8,R9,m2,R22,R50,R0,s83,Given a spec and a value that fails to conform, returns an explanation as a string.R4,i276,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha6,valid?m8,R38,TR4,i281,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha6,gensubm10,R34,TR7,L1,V5,R8,R14,R11,R15,R41,R4,i283,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha3,genm10,R7,L2,V1,R8,V2,R8,R14,R0,s581,Given a spec, returns the generator for it, or throws if none can\n  be constructed. Optionally an overrides map can be provided which\n  should map spec names or paths (vectors of keywords) to no-arg\n  generator-creating fns. These will be used instead of the generators at those\n  names/paths. Note that parent generator (in the spec or overrides\n  map) will supersede those of any subtrees. A generator for a regex\n  op must always return a sequential collection (i.e. a generator for\n  s/? should return either an empty sequence/vector or a\n  sequence/vector with one item in it)R4,i296,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha5,->symm12,R34,TR7,L1,V1,R9,R0,s37,Returns a symbol from a symbol or varR4,i309,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha4,unfnm10,R34,TR7,L1,V1,R51,R4,i316,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha3,resm10,R34,TR7,L1,V1,R41,R4,i324,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,def-implm12,R52,TR7,L1,V3,R36,R41,R8,R0,s36,Do not call this directly, use 'def'R4,i331,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha10,ns-qualifym12,R34,TR7,L1,V1,R46,R0,s59,Qualify symbol s by resolving it or using the current *ns*.R4,i343,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha3,defm10,R7,L1,V2,R36,R53,R0,s214,Given a namespace-qualified keyword or resolvable symbol k, and a\n  spec, spec-name, predicate or regex-op makes an entry in the\n  registry mapping k to the spec. Use nil to remove an entry in\n  the registry for k.R4,i351,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,registrym10,R7,L1,V0,R0,s68,returns the registry map, prefer 'get-spec' to lookup a spec by nameR4,i360,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,get-specm10,R7,L1,V1,R36,R0,s57,Returns spec registered for keyword/symbol/var k, or nil.R4,i365,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha4,specm10,R7,L1,V3,R41,R54,m2,R55,V1,R56,R0,s569,Takes a single predicate form, e.g. can be the name of a predicate,\n  like even?, or a fn literal like #(< % 42). Note that it is not\n  generally necessary to wrap predicates in spec when using the rest\n  of the spec macros, only to attach a unique generator\n\n  Can also be passed the result of one of the regex ops -\n  cat, alt, *, +, ?, in which case it will return a regex-conforming\n  spec, useful when nesting an independent regex.\n  ---\n\n  Optionally takes :gen generator-fn, which must be a fn of no args that\n  returns a test.check generator.\n\n  Returns a spec.R4,i370,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha10,multi-specm10,R7,L1,V2,R57,R58,R0,s1150,Takes the name of a spec/predicate-returning multimethod and a\n  tag-restoring keyword or fn (retag).  Returns a spec that when\n  conforming or explaining data will pass it to the multimethod to get\n  an appropriate spec. You can e.g. use multi-spec to dynamically and\n  extensibly associate specs with 'tagged' data (i.e. data where one\n  of the fields indicates the shape of the rest of the structure).\n\n  (defmulti mspec :tag)\n\n  The methods should ignore their argument and return a predicate/spec:\n  (defmethod mspec :int [_] (s/keys :req-un [::tag ::i]))\n\n  retag is used during generation to retag generated values with\n  matching tags. retag can either be a keyword, at which key the\n  dispatch-tag will be assoc'ed, or a fn of generated value and\n  dispatch-tag that should return an appropriately retagged value.\n\n  Note that because the tags themselves comprise an open set,\n  the tag key spec cannot enumerate the values, but can e.g.\n  test for keyword?.\n\n  Note also that the dispatch values of the multimethod will be\n  included in the path, i.e. in reporting and gen overrides, even\n  though those values are not evident in the spec.\nR4,i389,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha4,keysm10,R7,L1,V2,R54,m2,R55,V5,R59,R60,R61,R62,R56,R0,s1180,Creates and returns a map validating spec. :req and :opt are both\n  vectors of namespaced-qualified keywords. The validator will ensure\n  the :req keys are present. The :opt keys serve as documentation and\n  may be used by the generator.\n\n  The :req key vector supports 'and' and 'or' for key groups:\n\n  (s/keys :req [::x ::y (or ::secret (and ::user ::pwd))] :opt [::z])\n\n  There are also -un versions of :req and :opt. These allow\n  you to connect unqualified keys to specs.  In each case, fully\n  qualified keywords are passed, which name the specs, but unqualified\n  keys (with the same name component) are expected and checked at\n  conform-time, and generated during gen:\n\n  (s/keys :req-un [:my.ns/x :my.ns/y])\n\n  The above says keys :x and :y are required, and will be validated\n  and generated by specs (if they exist) named :my.ns/x :my.ns/y \n  respectively.\n\n  In addition, the values of *all* namespace-qualified keys will be validated\n  (and possibly destructured) by any registered specs. Note: there is\n  no support for inline value specification, by design.\n\n  Optionally takes :gen generator-fn, which must be a fn of no args that\n  returns a test.check generator.R4,i418,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha2,orm10,R7,L1,V2,R54,R63,R0,s311,Takes key+pred pairs, e.g.\n\n  (s/or :even even? :small #(< % 42))\n\n  Returns a destructuring spec that returns a map entry containing the\n  key of the first matching pred and the corresponding value. Thus the\n  'key' and 'val' functions can be used to refer generically to the\n  components of the tagged return.R4,i480,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha3,andm10,R7,L1,V2,R54,R64,R0,s179,Takes predicate/spec-forms, e.g.\n\n  (s/and even? #(< % 42))\n\n  Returns a spec that returns the conformed value. Successive\n  conformed values propagate through rest of predicates.R4,i497,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha5,mergem10,R7,L1,V2,R54,R64,R0,s208,Takes map-validating specs (e.g. 'keys' specs) and\n  returns a spec that returns a conformed map satisfying all of the\n  specs.  Unlike 'and', merge can generate maps satisfying the\n  union of the predicates.R4,i507,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,res-kindm10,R34,TR7,L1,V1,R65,R4,i515,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha5,everym10,R7,L1,V3,R66,R54,m4,R55,V8,R67,R68,R69,R70,R71,R72,R73,R56,R74,R65,R0,s1238,takes a pred and validates collection elements against that pred.\n\n  Note that 'every' does not do exhaustive checking, rather it samples\n  *coll-check-limit* elements. Nor (as a result) does it do any\n  conforming of elements. 'explain' will report at most *coll-error-limit*\n  problems.  Thus 'every' should be suitable for potentially large\n  collections.\n\n  Takes several kwargs options that further constrain the collection:\n\n  :kind - a pred that the collection type must satisfy, e.g. vector?\n        (default nil) Note that if :kind is specified and :into is\n        not, this pred must generate in order for every to generate.\n  :count - specifies coll has exactly this count (default nil)\n  :min-count, :max-count - coll has count (<= min-count count max-count) (defaults nil)\n  :distinct - all the elements are distinct (default nil)\n\n  And additional args that control gen\n\n  :gen-max - the maximum coll size to generate (default 20)\n  :into - one of [], (), {}, #{} - the default collection to generate into\n      (default: empty coll as generated by :kind pred if supplied, else [])\n  \n  Optionally takes :gen generator-fn, which must be a fn of no args that\n  returns a test.check generator\n\n  See also - coll-of, every-kv\nR4,i524,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,every-kvm10,R7,L1,V4,R75,R76,R54,R65,R0,s157,like 'every' but takes separate key and val preds and works on associative collections.\n\n  Same options as 'every', :into defaults to {}\n\n  See also - map-ofR4,i572,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha7,coll-ofm10,R7,L1,V3,R66,R54,R65,R0,s325,Returns a spec for a collection of items satisfying pred. Unlike\n  'every', coll-of will exhaustively conform every value.\n\n  Same options as 'every'. conform will produce a collection\n  corresponding to :into if supplied, else will match the input collection,\n  avoiding rebuilding when possible.\n\n  See also - every, map-ofR4,i583,R5,i1,R6,s20,arbace/spec/alpha.aev17,arbace.spec.alpha6,map-ofm10,R7,L1,V4,R75,R76,R54,R65,R0,s305,Returns a spec for a map whose keys satisfy kpred and vals satisfy\n  vpred. Unlike 'every-kv', map-of will exhaustively conform every\n  value.\n\n  Same options as 'every', :kind defaults to map?, with the addition of:\n\n  :conform-keys - conform keys as well as values (default false)\n\n  See also - every-kvR4,i596,R5,i1,R6,s20,arbace/spec/alpha.ae")

var Lit_144 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000004$loading__1927001464__auto____1740000005")

var Lit_145 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000008$fn__1740000009")

var Lit_146 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000035")

var Lit_147 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000051")

var Lit_148 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000061")

var Lit_149 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000075")

var Lit_150 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000085")

var Lit_151 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000034$fn__1740000093")

var Lit_152 *jrt.String = jrt.Intern("arbace.spec.alpha$deep_resolve")

var Lit_153 *jrt.String = jrt.Intern("arbace.spec.alpha$reg_resolve")

var Lit_154 *jrt.String = jrt.Intern("arbace.spec.alpha$reg_resolve_BANG_")

var Lit_155 *jrt.String = jrt.Intern("arbace.spec.alpha$spec_QMARK_")

var Lit_156 *jrt.String = jrt.Intern("arbace.spec.alpha$regex_QMARK_")

var Lit_157 *jrt.String = jrt.Intern("arbace.spec.alpha$with_name")

var Lit_158 *jrt.String = jrt.Intern("arbace.spec.alpha$spec_name")

var Lit_159 *jrt.String = jrt.Intern("arbace.spec.alpha$maybe_spec")

var Lit_160 *jrt.String = jrt.Intern("arbace.spec.alpha$the_spec")

var Lit_161 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000127$fn__1740000128")

var Lit_162 *jrt.String = jrt.Intern("arbace.spec.alpha$fn_sym")

var Lit_163 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000149$fn__1740000150")

var Lit_164 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000153$fn__1740000154")

var Lit_165 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000157$fn__1740000158")

var Lit_166 *jrt.String = jrt.Intern("arbace.spec.alpha$eval1740000161$fn__1740000162")

var Lit_167 *jrt.String = jrt.Intern("arbace.spec.alpha$specize")

var Lit_168 *jrt.String = jrt.Intern("arbace.spec.alpha$invalid_QMARK_")

var Lit_169 *jrt.String = jrt.Intern("arbace.spec.alpha$conform")

var Lit_170 *jrt.String = jrt.Intern("arbace.spec.alpha$unform")

var Lit_171 *jrt.String = jrt.Intern("arbace.spec.alpha$form")

var Lit_172 *jrt.String = jrt.Intern("arbace.spec.alpha$abbrev")

var Lit_173 *jrt.String = jrt.Intern("arbace.spec.alpha$describe")

var Lit_174 *jrt.String = jrt.Intern("arbace.spec.alpha$with_gen")

var Lit_175 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_data_STAR_")

var Lit_176 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_data")

var Lit_177 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_printer")

var Lit_178 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_out")

var Lit_179 *jrt.String = jrt.Intern("arbace.spec.alpha$explain")

var Lit_180 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_str")

var Lit_181 *jrt.String = jrt.Intern("arbace.spec.alpha$gensub")

var Lit_182 *jrt.String = jrt.Intern("arbace.spec.alpha$gen")

var Lit_183 *jrt.String = jrt.Intern("arbace.spec.alpha$__GT_sym")

var Lit_184 *jrt.String = jrt.Intern("arbace.spec.alpha$unfn")

var Lit_185 *jrt.String = jrt.Intern("arbace.spec.alpha$res")

var Lit_186 *jrt.String = jrt.Intern("arbace.spec.alpha$def_impl")

var Lit_187 *jrt.String = jrt.Intern("arbace.spec.alpha$ns_qualify")

var Lit_188 *jrt.String = jrt.Intern("arbace.spec.alpha$def")

var Lit_189 *jrt.String = jrt.Intern("arbace.spec.alpha$registry")

var Lit_190 *jrt.String = jrt.Intern("arbace.spec.alpha$get_spec")

var Lit_191 *jrt.String = jrt.Intern("arbace.spec.alpha$spec")

var Lit_192 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec")

var Lit_193 *jrt.String = jrt.Intern("arbace.spec.alpha$keys")

var Lit_194 *jrt.String = jrt.Intern("arbace.spec.alpha$or")

var Lit_195 *jrt.String = jrt.Intern("arbace.spec.alpha$and")

var Lit_196 *jrt.String = jrt.Intern("arbace.spec.alpha$merge")

var Lit_197 *jrt.String = jrt.Intern("arbace.spec.alpha$res_kind")

var Lit_198 *jrt.String = jrt.Intern("arbace.spec.alpha$every")

var Lit_199 *jrt.String = jrt.Intern("arbace.spec.alpha$every_kv")

var Lit_200 *jrt.String = jrt.Intern("arbace.spec.alpha$coll_of")

var Lit_201 *jrt.String = jrt.Intern("arbace.spec.alpha$map_of")

var Lit_202 *jrt.String = jrt.Intern("kn8,arglistsyn9,pred-formkn3,dockn4,linekn6,columnkn4,fileyn1,&yn14,key-pred-formsyn2,reyn5,predsyn1,fyn3,unfkn4,keysyn4,argsyn3,retyn2,fnyn3,genkn2,oryn5,quoteys11,arbace.core4,any?kn7,privateyn1,vyn6,fn-symyn5,specsyn4,rmapyn2,idyn4,pathyn1,kyn1,myn4,predyn1,xyn4,formyn6,cpred?yn4,specyn3,viayn2,inkn8,declaredyn1,syn9,min-countkn9,skip-wikiyn6,req-unyn6,opt-unyn9,keys-predyn10,pred-exprsyn8,opt-keysyn9,req-specsyn3,reqyn8,req-keysyn9,opt-specsyn10,pred-formsyn3,optyn3,gfnkn2,asyn4,argmyn3,uncyn5,mmvaryn5,retagyn5,formsyn3,tagyn4,keysyn3,kfnyn5,kformyn8,distinctyn5,countyn9,max-countys11,arbace.core7,vector?ys11,arbace.core4,set?ys11,arbace.core5,list?ys11,arbace.core4,map?yn4,optsyn12,conform-intokn4,intoyn13,describe-formks17,arbace.spec.alpha8,describeyn4,kindks17,arbace.spec.alpha9,kind-formyn7,gen-maxks17,arbace.spec.alpha3,kfnks17,arbace.spec.alpha5,cpredyn12,conform-keysks17,arbace.spec.alpha11,conform-allks17,arbace.spec.alpha2,opyn2,p1yn2,pryn2,pskn2,psyn2,k1yn2,kryn2,kskn2,ksyn2,f1yn2,frkn5,formskn3,retyn4,rep+kn4,rep+yn2,p2yn6,spliceyn1,pyn7,re-formyn4,pretyn1,ryn5,inputyn9,overridesyn2,xsyn4,datayn5,itersyn7,argspecyn5,aformyn7,retspecyn5,rformyn6,fnspecyn5,fformks17,arbace.spec.alpha8,kvs->mapys17,arbace.spec.alpha9,conformeryn3,fn*yn15,p1__1740000866#ys11,arbace.core6,zipmapys11,arbace.core3,mapks17,arbace.spec.alpha1,kks17,arbace.spec.alpha1,vyn15,p1__1740000867#ys11,arbace.core2,fnyn1,%yn6,kspecsyn1,nyn3,symyn8,sym-or-fyn5,fspecyn5,startyn3,endyn4,instv17,arbace.spec.alpha1,*m10,R0,L1,V1,R1,R2,s129,Returns a regex op that matches zero or more values matching\n  pred. Produces a vector of matches iff there is at least one matchR3,i611,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha1,+m10,R0,L1,V1,R1,R2,s96,Returns a regex op that matches one or more values matching\n  pred. Produces a vector of matchesR3,i617,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha1,?m10,R0,L1,V1,R1,R2,s121,Returns a regex op that matches zero or one value matching\n  pred. Produces a single value (not a collection) if matched.R3,i623,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha3,altm10,R0,L1,V2,R6,R7,R2,s301,Takes key+pred pairs, e.g.\n\n  (s/alt :even even? :small #(< % 42))\n\n  Returns a regex op that returns a map entry containing the key of the\n  first matching pred and the corresponding value. Thus the\n  'key' and 'val' functions can be used to refer generically to the\n  components of the tagged returnR3,i629,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha3,catm10,R0,L1,V2,R6,R7,R2,s195,Takes key+pred pairs, e.g.\n\n  (s/cat :e even? :o odd?)\n\n  Returns a regex op that matches (all) values in sequence, returning a map\n  containing the keys of each pred and the corresponding value.R3,i646,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha1,&m10,R0,L1,V3,R8,R6,R9,R2,s199,takes a regex op re, and predicates. Returns a regex-op that consumes\n  input as per re but subjects the resulting value to the\n  conjunction of the predicates, and any conforming they might perform.R3,i662,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha9,conformerm10,R0,L2,V1,R10,V2,R10,R11,R2,s274,takes a predicate function with the semantics of conform i.e. it should return either a\n  (possibly converted) value or :arbace.spec.alpha/invalid, and returns a\n  spec that uses it as a predicate/conformer. Optionally takes a\n  second fn that does unform of result of firstR3,i670,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha5,fspecm10,R0,L1,V2,R6,m4,R12,V4,R13,R14,R15,R16,R17,m2,R14,L2,R18,R19,R2,s606,takes :args :ret and (optional) :fn kwargs whose values are preds\n  and returns a spec whose conform/explain take a fn and validates it\n  using generative testing. The conformed value is always the fn itself.\n\n  See 'fdef' for a single operation that creates an fspec and\n  registers it, as well as a full description of :args, :ret and :fn\n\n  fspecs can generate functions that validate the arguments and\n  fabricate a return value compliant with the :ret spec, ignoring\n  the :fn spec if present.\n\n  Optionally takes :gen generator-fn, which must be a fn of no args\n  that returns a test.check generator.R3,i678,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha5,tuplem10,R0,L1,V2,R6,R9,R2,s184,takes one or more preds and returns a spec for a tuple, a vector\n  where each element conforms to the corresponding pred. Each element\n  will be referred to in paths using its ordinal.R3,i698,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha17,macroexpand-checkm10,R20,TR0,L1,V2,R21,R13,R3,i706,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha4,fdefm10,R0,L1,V3,R22,R6,R23,R2,s1297,Takes a symbol naming a function, and one or more of the following:\n\n  :args A regex spec for the function arguments as they were a list to be\n    passed to apply - in this way, a single spec can handle functions with\n    multiple arities\n  :ret A spec for the function's return value\n  :fn A spec of the relationship between args and ret - the\n    value passed is {:args conformed-args :ret conformed-ret} and is\n    expected to contain predicates that relate those values\n\n  Qualifies fn-sym with resolve, or using *ns* if no resolution found.\n  Registers an fspec in the global registry, where it can be retrieved\n  by calling get-spec with the var or fully-qualified symbol.\n\n  Once registered, function specs are included in doc, checked by\n  instrument, tested by the runner arbace.spec.test.alpha/check, and (if\n  a macro) used to explain errors during macroexpansion.\n\n  Note that :fn specs require the presence of :args and :ret specs to\n  conform values, and so :fn specs will be ignored if :args or :ret\n  are missing.\n\n  Returns the qualified fn-sym.\n\n  For example, to register function specs for the symbol function:\n\n  (s/fdef arbace.core/symbol\n    :args (s/alt :separate (s/cat :ns string? :n string?)\n                 :str string?\n                 :sym symbol?)\n    :ret symbol?)R3,i718,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha12,recur-limit?m10,R20,TR0,L1,V4,R24,R25,R26,R27,R3,i754,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha4,inckm10,R20,TR0,L1,V2,R28,R27,R3,i758,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha2,dtm10,R20,TR0,L2,V3,R29,R30,R31,V4,R29,R30,R31,R32,R3,i761,R4,i1,R5,s20,arbace/spec/alpha.aem10,R0,L2,V2,R33,R30,V3,R33,R30,R31,R2,s59,Helper function that returns true when x is valid for spec.R3,i774,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha7,pvalid?m12,R20,TR0,L2,V2,R29,R30,V3,R29,R30,R31,R2,s68,internal helper function that returns true when x is valid for spec.R3,i783,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha9,explain-1m10,R20,TR0,L1,V6,R31,R29,R26,R34,R35,R21,R3,i790,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,or-k-genm8,R36,TR3,i797,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha9,and-k-genm8,R36,TR3,i797,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha5,k-genm12,R20,TR0,L1,V1,R10,R2,s93,returns a generator for form f, which can be a keyword or a list\n  starting with 'or or 'and.R3,i799,R4,i1,R5,s20,arbace/spec/alpha.aem12,R20,TR0,L2,V1,R37,V2,R38,R37,R2,s116,returns a tuple generator made up of generators for a random subset\n  of min-count (default 0) to all elements in s.R3,i808,R4,i1,R5,s20,arbace/spec/alpha.aem12,R20,TR0,L1,V1,R37,R2,s73,returns a tuple generator made up of generators for every element\n  in s.R3,i819,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha13,map-spec-implm12,R39,TR0,L1,V1,m4,R12,V12,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,R2,s57,Do not call this directly, use 'spec' with a map argumentR3,i826,R4,i1,R5,s20,arbace/spec/alpha.aem12,R39,TR0,L2,V4,R31,R29,R51,R32,V5,R31,R29,R51,R32,R54,R2,s37,Do not call this directly, use 'spec'R3,i917,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha15,multi-spec-implm12,R39,TR0,L2,V3,R31,R55,R56,V4,R31,R55,R56,R51,R2,s43,Do not call this directly, use 'multi-spec'R3,i950,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha10,tuple-implm12,R39,TR0,L2,V2,R57,R9,V3,R57,R9,R51,R2,s38,Do not call this directly, use 'tuple'R3,i1000,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha10,tagged-retm10,R20,TR0,L1,V2,R58,R14,R3,i1062,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha12,or-spec-implm12,R39,TR0,L1,V4,R59,R57,R9,R51,R2,s35,Do not call this directly, use 'or'R3,i1065,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha9,and-predsm10,R20,TR0,L1,V3,R30,R9,R57,R3,i1132,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha17,explain-pred-listm10,R20,TR0,L1,V6,R57,R9,R26,R34,R35,R30,R3,i1144,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha13,and-spec-implm12,R39,TR0,L1,V3,R57,R9,R51,R2,s36,Do not call this directly, use 'and'R3,i1155,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha15,merge-spec-implm12,R39,TR0,L1,V3,R57,R9,R51,R2,s38,Do not call this directly, use 'merge'R3,i1199,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha9,coll-probm10,R20,TR0,L1,V10,R30,R60,R61,R62,R63,R38,R64,R26,R34,R35,R3,i1227,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha10,empty-collR65,R66,R67,R68,m8,R20,TR3,i1247,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha10,every-implm12,R39,TR0,L2,V3,R31,R29,R69,V4,R31,R29,m10,R70,R71,R72,R73,R12,V11,R74,R75,R63,R64,R38,R62,R76,R77,R78,R79,R80,R17,m2,R76,l20,R52,R69,R51,R2,s73,Do not call this directly, use 'every', 'every-kv', 'coll-of' or 'map-of'R3,i1249,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha6,acceptm10,R20,TR0,L1,V1,R30,R3,i1384,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha7,accept?m10,R20,TR0,L1,V1,m2,R12,V1,R81,R3,i1386,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha5,pcat*m10,R20,TR0,L1,V1,m10,V5,R82,R6,R83,R52,R84,R85,V5,R86,R6,R87,R52,R88,R89,V5,R90,R6,R91,R52,R57,R92,R14,R93,R94,R95,R3,i1389,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha4,pcatm10,R20,TR0,L1,V2,R6,R84,R3,i1399,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,cat-implm12,R39,TR0,L1,V3,R88,R84,R57,R2,s36,Do not call this directly, use 'cat'R3,i1401,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha4,rep*m10,R20,TR0,L1,V5,R82,R96,R14,R97,R31,R3,i1406,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,rep-implm12,R39,TR0,L1,V2,R31,R98,R2,s34,Do not call this directly, use '*'R3,i1413,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,rep+implm12,R39,TR0,L1,V2,R31,R98,R2,s34,Do not call this directly, use '+'R3,i1417,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,amp-implm12,R39,TR0,L1,V4,R8,R99,R9,R49,R2,s34,Do not call this directly, use '&'R3,i1422,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha10,filter-altm10,R20,TR0,L1,V4,R84,R88,R57,R10,R3,i1427,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha4,alt*m10,R20,TR0,L1,V3,R84,R88,R57,R3,i1436,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha4,altsm10,R20,TR0,L1,V2,R6,R84,R3,i1448,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha4,alt2m10,R20,TR0,L1,V2,R82,R96,R3,i1449,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,alt-implm12,R39,TR0,L1,V3,R88,R84,R57,R2,s36,Do not call this directly, use 'alt'R3,i1451,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha10,maybe-implm12,R39,TR0,L1,V2,R98,R31,R2,s34,Do not call this directly, use '?'R3,i1455,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha6,noret?m10,R20,TR0,L1,V2,R82,R100,R3,i1459,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha7,preturnm8,R36,TR3,i1465,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha11,accept-nil?m10,R20,TR0,L1,V1,R98,R3,i1467,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha7,add-retm8,R36,TR3,i1479,R4,i1,R5,s20,arbace/spec/alpha.aem10,R20,TR0,L1,V1,R98,R3,i1481,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha9,op-unformm10,R20,TR0,L1,V2,R98,R30,R3,i1496,R4,i1,R5,s20,arbace/spec/alpha.aem10,R20,TR0,L1,V3,R98,R101,R27,R3,i1517,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha5,derivm10,R20,TR0,L1,V2,R98,R30,R3,i1530,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha11,op-describem10,R20,TR0,L1,V1,R98,R3,i1550,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha10,op-explainm10,R20,TR0,L1,V6,R31,R98,R26,R34,R35,R102,R3,i1566,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha6,re-genm10,R20,TR0,L1,V5,R98,R103,R26,R24,R10,R3,i1621,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha10,re-conformm10,R20,TR0,L1,V2,R98,V5,R30,R6,R104,R52,R105,R3,i1662,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha10,re-explainm10,R20,TR0,L1,V5,R26,R34,R35,R8,R102,R3,i1675,R4,i1,R5,s20,arbace/spec/alpha.aem12,R39,TR0,L1,V2,R8,R51,R2,s62,Do not call this directly, use 'spec' with a regex op argumentR3,i1701,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha11,call-valid?m10,R20,TR0,L1,V3,R10,R23,R13,R3,i1728,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha11,validate-fnm12,R20,TR0,L1,V3,R10,R23,R106,R2,s33,returns f if valid, else smallestR3,i1739,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha10,fspec-implm12,R39,TR0,L1,V7,R107,R108,R109,R110,R111,R112,R51,R2,s38,Do not call this directly, use 'fspec'R3,i1749,R4,i1,R5,s20,arbace/spec/alpha.aeR113,ML3,R114,L3,R115,V1,R116,ML3,R117,ML3,R118,R119,R116,m4,R3,i1796,R4,i55,ML3,R118,R120,R116,m4,R3,i1796,R4,i67,m4,R3,i1796,R4,i47,L3,R115,V1,R121,ML3,R118,ML3,R122,V1,V2,R27,R21,m4,R119,R27,R120,R21,m4,R3,i1796,R4,i86,R121,m4,R3,i1796,R4,i81,m4,R3,i1796,R4,i35,L3,R114,L3,R122,V1,R123,ML3,R117,ML3,R118,R119,R123,m4,R3,i1796,R4,i55,ML3,R118,R120,R123,m4,R3,i1796,R4,i67,m4,R3,i1796,R4,i47,L3,R122,V1,R123,ML3,R118,ML3,R122,V1,V2,R27,R21,m4,R119,R27,R120,R21,m4,R3,i1796,R4,i86,R123,m4,R3,i1796,R4,i81,v17,arbace.spec.alpha5,keys*m10,R0,L1,V2,R6,R124,R2,s554,takes the same arguments as spec/keys and returns a regex op that matches sequences of key/values,\n  converts them into a map, and conforms that map with a corresponding\n  spec/keys call:\n\n  user=> (s/conform (s/keys :req-un [::a ::c]) {:a 1 :c 2})\n  {:a 1, :c 2}\n  user=> (s/conform (s/keys* :req-un [::a ::c]) [:a 1 :c 2])\n  {:a 1, :c 2}\n\n  the resulting regex op can be composed into a larger regex:\n\n  user=> (s/conform (s/cat :i1 integer? :m (s/keys* :req-un [::a ::c]) :i2 integer?) [42 :a 1 :c 2 :d 4 99])\n  {:i1 42, :m {:a 1, :c 2, :d 4}, :i2 99}R3,i1798,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha13,nonconformingm12,R39,TR0,L1,V1,R33,R2,s157,takes a spec and returns a spec that has the same properties except\n  'conform' returns the original (not the conformed) value. Note, will specize regex ops.R3,i1817,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha12,nilable-implm12,R39,TR0,L1,V3,R31,R29,R51,R2,s40,Do not call this directly, use 'nilable'R3,i1838,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha7,nilablem10,R0,L1,V1,R29,R2,s58,returns a spec that accepts nil and values satisfying predR3,i1864,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha8,exercisem10,R0,L3,V1,R33,V2,R33,R125,V3,R33,R125,R103,R2,s200,generates a number (default 10) of values compatible with spec and maps conform over them,\n  returning a sequence of [val conformed-val] tuples. Optionally takes\n  a generator overrides map as per genR3,i1870,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha11,exercise-fnm10,R0,L3,V1,R126,V2,R126,R125,V3,R127,R125,R128,R2,s232,exercises the fn named by sym (a symbol) by applying it to\n  n (default 10) generated samples of its args spec. When fspec is\n  supplied its arg spec is used, and sym-or-f can be a fn.  Returns a\n  sequence of tuples of [args ret]. R3,i1879,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha14,inst-in-range?m10,R0,L1,V3,R129,R130,R131,R2,s52,Return true if inst at or after start and before endR3,i1893,R4,i1,R5,s20,arbace/spec/alpha.aev17,arbace.spec.alpha7,inst-inm10,R0,L1,V2,R129,R130,R2,s91,Returns a spec that validates insts in the range from start\n(inclusive) to end (exclusive).R3,i1900,R4,i1,R5,s20,arbace/spec/alpha.ae")

var Lit_203 *jrt.String = jrt.Intern("arbace.spec.alpha$_STAR_")

var Lit_204 *jrt.String = jrt.Intern("arbace.spec.alpha$_PLUS_")

var Lit_205 *jrt.String = jrt.Intern("arbace.spec.alpha$_QMARK_")

var Lit_206 *jrt.String = jrt.Intern("arbace.spec.alpha$alt")

var Lit_207 *jrt.String = jrt.Intern("arbace.spec.alpha$cat")

var Lit_208 *jrt.String = jrt.Intern("arbace.spec.alpha$_AMPERSAND_")

var Lit_209 *jrt.String = jrt.Intern("arbace.spec.alpha$conformer")

var Lit_210 *jrt.String = jrt.Intern("arbace.spec.alpha$fspec")

var Lit_211 *jrt.String = jrt.Intern("arbace.spec.alpha$tuple")

var Lit_212 *jrt.String = jrt.Intern("arbace.spec.alpha$macroexpand_check")

var Lit_213 *jrt.String = jrt.Intern("arbace.spec.alpha$fdef")

var Lit_214 *jrt.String = jrt.Intern("arbace.spec.alpha$recur_limit_QMARK_")

var Lit_215 *jrt.String = jrt.Intern("arbace.spec.alpha$inck")

var Lit_216 *jrt.String = jrt.Intern("arbace.spec.alpha$dt")

var Lit_217 *jrt.String = jrt.Intern("arbace.spec.alpha$valid_QMARK_")

var Lit_218 *jrt.String = jrt.Intern("arbace.spec.alpha$pvalid_QMARK_")

var Lit_219 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_1")

var Lit_220 *jrt.String = jrt.Intern("arbace.spec.alpha$k_gen")

var Lit_221 *jrt.String = jrt.Intern("arbace.spec.alpha$or_k_gen")

var Lit_222 *jrt.String = jrt.Intern("arbace.spec.alpha$and_k_gen")

var Lit_223 *jrt.String = jrt.Intern("arbace.spec.alpha$map_spec_impl")

var Lit_224 *jrt.String = jrt.Intern("arbace.spec.alpha$spec_impl")

var Lit_225 *jrt.String = jrt.Intern("arbace.spec.alpha$multi_spec_impl")

var Lit_226 *jrt.String = jrt.Intern("arbace.spec.alpha$tuple_impl")

var Lit_227 *jrt.String = jrt.Intern("arbace.spec.alpha$tagged_ret")

var Lit_228 *jrt.String = jrt.Intern("arbace.spec.alpha$or_spec_impl")

var Lit_229 *jrt.String = jrt.Intern("arbace.spec.alpha$and_preds")

var Lit_230 *jrt.String = jrt.Intern("arbace.spec.alpha$explain_pred_list")

var Lit_231 *jrt.String = jrt.Intern("arbace.spec.alpha$and_spec_impl")

var Lit_232 *jrt.String = jrt.Intern("arbace.spec.alpha$merge_spec_impl")

var Lit_233 *jrt.String = jrt.Intern("arbace.spec.alpha$coll_prob")

var Lit_234 *jrt.String = jrt.Intern("arbace.spec.alpha$every_impl")

var Lit_235 *jrt.String = jrt.Intern("arbace.spec.alpha$accept")

var Lit_236 *jrt.String = jrt.Intern("arbace.spec.alpha$accept_QMARK_")

var Lit_237 *jrt.String = jrt.Intern("arbace.spec.alpha$pcat_STAR_")

var Lit_238 *jrt.String = jrt.Intern("arbace.spec.alpha$pcat")

var Lit_239 *jrt.String = jrt.Intern("arbace.spec.alpha$cat_impl")

var Lit_240 *jrt.String = jrt.Intern("arbace.spec.alpha$rep_STAR_")

var Lit_241 *jrt.String = jrt.Intern("arbace.spec.alpha$rep_impl")

var Lit_242 *jrt.String = jrt.Intern("arbace.spec.alpha$rep_PLUS_impl")

var Lit_243 *jrt.String = jrt.Intern("arbace.spec.alpha$amp_impl")

var Lit_244 *jrt.String = jrt.Intern("arbace.spec.alpha$filter_alt")

var Lit_245 *jrt.String = jrt.Intern("arbace.spec.alpha$alt_STAR_")

var Lit_246 *jrt.String = jrt.Intern("arbace.spec.alpha$alts")

var Lit_247 *jrt.String = jrt.Intern("arbace.spec.alpha$alt2")

var Lit_248 *jrt.String = jrt.Intern("arbace.spec.alpha$alt_impl")

var Lit_249 *jrt.String = jrt.Intern("arbace.spec.alpha$maybe_impl")

var Lit_250 *jrt.String = jrt.Intern("arbace.spec.alpha$noret_QMARK_")

var Lit_251 *jrt.String = jrt.Intern("arbace.spec.alpha$accept_nil_QMARK_")

var Lit_252 *jrt.String = jrt.Intern("arbace.spec.alpha$preturn")

var Lit_253 *jrt.String = jrt.Intern("arbace.spec.alpha$op_unform")

var Lit_254 *jrt.String = jrt.Intern("arbace.spec.alpha$add_ret")

var Lit_255 *jrt.String = jrt.Intern("arbace.spec.alpha$deriv")

var Lit_256 *jrt.String = jrt.Intern("arbace.spec.alpha$op_describe")

var Lit_257 *jrt.String = jrt.Intern("arbace.spec.alpha$op_explain")

var Lit_258 *jrt.String = jrt.Intern("arbace.spec.alpha$re_gen")

var Lit_259 *jrt.String = jrt.Intern("arbace.spec.alpha$re_conform")

var Lit_260 *jrt.String = jrt.Intern("arbace.spec.alpha$re_explain")

var Lit_261 *jrt.String = jrt.Intern("arbace.spec.alpha$regex_spec_impl")

var Lit_262 *jrt.String = jrt.Intern("arbace.spec.alpha$call_valid_QMARK_")

var Lit_263 *jrt.String = jrt.Intern("arbace.spec.alpha$validate_fn")

var Lit_264 *jrt.String = jrt.Intern("arbace.spec.alpha$fspec_impl")

var Lit_265 *jrt.String = jrt.Intern("arbace.spec.alpha$fn__1740000868")

var Lit_266 *jrt.String = jrt.Intern("arbace.spec.alpha$fn__1740000870")

var Lit_267 *jrt.String = jrt.Intern("arbace.spec.alpha$keys_STAR_")

var Lit_268 *jrt.String = jrt.Intern("arbace.spec.alpha$nonconforming")

var Lit_269 *jrt.String = jrt.Intern("arbace.spec.alpha$nilable_impl")

var Lit_270 *jrt.String = jrt.Intern("arbace.spec.alpha$nilable")

var Lit_271 *jrt.String = jrt.Intern("arbace.spec.alpha$exercise")

var Lit_272 *jrt.String = jrt.Intern("arbace.spec.alpha$exercise_fn")

var Lit_273 *jrt.String = jrt.Intern("arbace.spec.alpha$inst_in_range_QMARK_")

var Lit_274 *jrt.String = jrt.Intern("arbace.spec.alpha$inst_in")

var Lit_275 *jrt.String = jrt.Intern("kn8,arglistsyn5,startyn3,endyn3,valkn3,dockn4,linekn6,columnkn4,fileyn1,&kn4,keysyn9,infinite?yn4,NaN?yn3,minyn3,maxkn2,orkn2,asyn1,mkn7,dynamicyn4,flagyn4,specyn1,xv17,arbace.spec.alpha13,int-in-range?m10,R0,L1,V3,R1,R2,R3,R4,s78,Return true if start <= val, val < end and val is a fixed\n  precision integer.R5,i1912,R6,i1,R7,s20,arbace/spec/alpha.aev17,arbace.spec.alpha6,int-inm10,R0,L1,V2,R1,R2,R4,s112,Returns a spec that validates fixed precision integers in the\n  range from start (inclusive) to end (exclusive).R5,i1918,R6,i1,R7,s20,arbace/spec/alpha.aev17,arbace.spec.alpha9,double-inm10,R0,L1,V2,R8,m6,R9,V4,R10,R11,R12,R13,R14,m4,R10,TR11,TR15,R16,R4,s274,Specs a 64-bit floating point number. Options:\n\n    :infinite? - whether +/- infinity allowed (default true)\n    :NaN?      - whether NaN allowed (default true)\n    :min       - minimum value (inclusive, default none)\n    :max       - maximum value (inclusive, default none)R5,i1925,R6,i1,R7,s20,arbace/spec/alpha.aev17,arbace.spec.alpha17,*compile-asserts*m10,R17,TR4,s276,If true, compiler will enable spec asserts, which are then\nsubject to runtime control via check-asserts? If false, compiler\nwill eliminate all spec assert overhead. See 'assert'.\n\nInitially set to boolean value of arbace.spec.compile-asserts\nsystem property. Defaults to true.R5,i1943,R6,i1,R7,s20,arbace/spec/alpha.aev11,arbace.core4,not=m10,R17,TR4,s276,If true, compiler will enable spec asserts, which are then\nsubject to runtime control via check-asserts? If false, compiler\nwill eliminate all spec assert overhead. See 'assert'.\n\nInitially set to boolean value of arbace.spec.compile-asserts\nsystem property. Defaults to true.R5,i1943,R6,i1,R7,s20,arbace/spec/alpha.aev17,arbace.spec.alpha14,check-asserts?m10,R0,L1,V0,R4,s39,Returns the value set by check-asserts.R5,i1954,R6,i1,R7,s20,arbace/spec/alpha.aev17,arbace.spec.alpha13,check-assertsm10,R0,L1,V1,R18,R4,s197,Enable or disable spec asserts that have been compiled\nwith '*compile-asserts*' true.  See 'assert'.\n\nInitially set to boolean value of arbace.spec.check-asserts\nsystem property. Defaults to false.R5,i1959,R6,i1,R7,s20,arbace/spec/alpha.aev17,arbace.spec.alpha7,assert*m10,R0,L1,V2,R19,R20,R4,s40,Do not call this directly, use 'assert'.R5,i1968,R6,i1,R7,s20,arbace/spec/alpha.aev17,arbace.spec.alpha6,assertm10,R0,L1,V2,R19,R20,R4,s561,spec-checking assert expression. Returns x if x is valid? according\nto spec, else throws an ex-info with explain-data plus ::failure of\n:assertion-failed.\n\nCan be disabled at either compile time or runtime:\n\nIf *compile-asserts* is false at compile time, compiles to x. Defaults\nto value of 'arbace.spec.compile-asserts' system property, or true if\nnot set.\n\nIf (check-asserts?) is false at runtime, always returns x. Defaults to\nvalue of 'arbace.spec.check-asserts' system property, or false if not\nset. You can toggle check-asserts? with (check-asserts bool).R5,i1979,R6,i1,R7,s20,arbace/spec/alpha.ae")

var Lit_276 *jrt.String = jrt.Intern("arbace.spec.alpha$int_in_range_QMARK_")

var Lit_277 *jrt.String = jrt.Intern("arbace.spec.alpha$int_in")

var Lit_278 *jrt.String = jrt.Intern("arbace.spec.alpha$double_in")

var Lit_279 *jrt.String = jrt.Intern("false")

var Lit_280 *jrt.String = jrt.Intern("arbace.spec.compile-asserts")

var Lit_281 *jrt.String = jrt.Intern("arbace.spec.alpha$check_asserts_QMARK_")

var Lit_282 *jrt.String = jrt.Intern("arbace.spec.alpha$check_asserts")

var Lit_283 *jrt.String = jrt.Intern("arbace.spec.alpha$assert_STAR_")

var Lit_284 *jrt.String = jrt.Intern("arbace.spec.alpha$assert")
