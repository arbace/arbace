//line aot_arbace_spec_alpha__init.ae:1
package aot_arbace_spec_alpha

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_spec_alpha__init_A_Load__O() any { jrt.StartCheck(); A_arbace_spec_alpha__init_part0_A_Init__O(); A_arbace_spec_alpha__init_part1_A_Init__O(); A_arbace_spec_alpha__init_part2_A_Init__O(); A_arbace_spec_alpha__init_part0_A_Load__O(); A_arbace_spec_alpha__init_part1_A_Load__O(); A_arbace_spec_alpha__init_part2_A_Load__O(); return nil }







func A_arbace_spec_alpha__init_part0_A_Unit0__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); return lang.IFn_Cast(A_arbace_spec_alpha__init_part0_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_alpha__init_part0_A_const_1) }
//line :13:1
func A_arbace_spec_alpha__init_part0_A_Unit1__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_spec_alpha__init_part0_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_2)) }
//line :13:1
func A_arbace_spec_alpha__init_part0_A_Unit2__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); var tmp1 any = A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :13:1
func A_arbace_spec_alpha__init_part0_A_Unit3__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(13, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_spec_alpha__init_part0_A_const_1)).Equals_O__Z(A_arbace_spec_alpha__init_part0_A_const_3) { return nil } else { var tmp1 any = A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
//line :13:1
func A_arbace_spec_alpha__init_part0_A_Init__O() any { A_arbace_spec_alpha__init_part0_A_Init(); return nil }
//line :13:1
func A_arbace_spec_alpha__init_part0_A_Load__O() any { A_arbace_spec_alpha__init_part0_A_Init(); A_arbace_spec_alpha__init_part0_A_Unit0__O(); A_arbace_spec_alpha__init_part0_A_Unit1__O(); A_arbace_spec_alpha__init_part0_A_Unit2__O(); A_arbace_spec_alpha__init_part0_A_Unit3__O(); A_arbace_spec_alpha__init_part0_A_Unit4__O(); A_arbace_spec_alpha__init_part0_A_Unit5__O(); A_arbace_spec_alpha__init_part0_A_Unit6__O(); A_arbace_spec_alpha__init_part0_A_Unit7__O(); A_arbace_spec_alpha__init_part0_A_Unit8__O(); A_arbace_spec_alpha__init_part0_A_Unit9__O(); A_arbace_spec_alpha__init_part0_A_Unit10__O(); A_arbace_spec_alpha__init_part0_A_Unit11__O(); A_arbace_spec_alpha__init_part0_A_Unit12__O(); A_arbace_spec_alpha__init_part0_A_Unit13__O(); A_arbace_spec_alpha__init_part0_A_Unit14__O(); A_arbace_spec_alpha__init_part0_A_Unit15__O(); A_arbace_spec_alpha__init_part0_A_Unit16__O(); A_arbace_spec_alpha__init_part0_A_Unit17__O(); A_arbace_spec_alpha__init_part0_A_Unit18__O(); A_arbace_spec_alpha__init_part0_A_Unit19__O(); A_arbace_spec_alpha__init_part0_A_Unit20__O(); A_arbace_spec_alpha__init_part0_A_Unit21__O(); A_arbace_spec_alpha__init_part0_A_Unit22__O(); A_arbace_spec_alpha__init_part0_A_Unit23__O(); A_arbace_spec_alpha__init_part0_A_Unit24__O(); A_arbace_spec_alpha__init_part0_A_Unit25__O(); A_arbace_spec_alpha__init_part0_A_Unit26__O(); A_arbace_spec_alpha__init_part0_A_Unit27__O(); A_arbace_spec_alpha__init_part0_A_Unit28__O(); A_arbace_spec_alpha__init_part0_A_Unit29__O(); A_arbace_spec_alpha__init_part0_A_Unit30__O(); A_arbace_spec_alpha__init_part0_A_Unit31__O(); A_arbace_spec_alpha__init_part0_A_Unit32__O(); A_arbace_spec_alpha__init_part0_A_Unit33__O(); A_arbace_spec_alpha__init_part0_A_Unit34__O(); A_arbace_spec_alpha__init_part0_A_Unit35__O(); A_arbace_spec_alpha__init_part0_A_Unit36__O(); A_arbace_spec_alpha__init_part0_A_Unit37__O(); A_arbace_spec_alpha__init_part0_A_Unit38__O(); A_arbace_spec_alpha__init_part0_A_Unit39__O(); A_arbace_spec_alpha__init_part0_A_Unit40__O(); A_arbace_spec_alpha__init_part0_A_Unit41__O(); A_arbace_spec_alpha__init_part0_A_Unit42__O(); A_arbace_spec_alpha__init_part0_A_Unit43__O(); A_arbace_spec_alpha__init_part0_A_Unit44__O(); A_arbace_spec_alpha__init_part0_A_Unit45__O(); A_arbace_spec_alpha__init_part0_A_Unit46__O(); A_arbace_spec_alpha__init_part0_A_Unit47__O(); A_arbace_spec_alpha__init_part0_A_Unit48__O(); A_arbace_spec_alpha__init_part0_A_Unit49__O(); A_arbace_spec_alpha__init_part0_A_Unit50__O(); A_arbace_spec_alpha__init_part0_A_Unit51__O(); A_arbace_spec_alpha__init_part0_A_Unit52__O(); A_arbace_spec_alpha__init_part0_A_Unit53__O(); A_arbace_spec_alpha__init_part0_A_Unit54__O(); A_arbace_spec_alpha__init_part0_A_Unit55__O(); A_arbace_spec_alpha__init_part0_A_Unit56__O(); A_arbace_spec_alpha__init_part0_A_Unit57__O(); A_arbace_spec_alpha__init_part0_A_Unit58__O(); A_arbace_spec_alpha__init_part0_A_Unit59__O(); A_arbace_spec_alpha__init_part0_A_Unit60__O(); A_arbace_spec_alpha__init_part0_A_Unit61__O(); A_arbace_spec_alpha__init_part0_A_Unit62__O(); A_arbace_spec_alpha__init_part0_A_Unit63__O(); A_arbace_spec_alpha__init_part0_A_Unit64__O(); A_arbace_spec_alpha__init_part0_A_Unit65__O(); A_arbace_spec_alpha__init_part0_A_Unit66__O(); A_arbace_spec_alpha__init_part0_A_Unit67__O(); A_arbace_spec_alpha__init_part0_A_Unit68__O(); A_arbace_spec_alpha__init_part0_A_Unit69__O(); A_arbace_spec_alpha__init_part0_A_Unit70__O(); A_arbace_spec_alpha__init_part0_A_Unit71__O(); A_arbace_spec_alpha__init_part0_A_Unit72__O(); A_arbace_spec_alpha__init_part0_A_Unit73__O(); A_arbace_spec_alpha__init_part0_A_Unit74__O(); A_arbace_spec_alpha__init_part0_A_Unit75__O(); A_arbace_spec_alpha__init_part0_A_Unit76__O(); A_arbace_spec_alpha__init_part0_A_Unit77__O(); A_arbace_spec_alpha__init_part0_A_Unit78__O(); A_arbace_spec_alpha__init_part0_A_Unit79__O(); A_arbace_spec_alpha__init_part0_A_Unit80__O(); A_arbace_spec_alpha__init_part0_A_Unit81__O(); A_arbace_spec_alpha__init_part0_A_Unit82__O(); A_arbace_spec_alpha__init_part0_A_Unit83__O(); A_arbace_spec_alpha__init_part0_A_Unit84__O(); A_arbace_spec_alpha__init_part0_A_Unit85__O(); A_arbace_spec_alpha__init_part0_A_Unit86__O(); A_arbace_spec_alpha__init_part0_A_Unit87__O(); A_arbace_spec_alpha__init_part0_A_Unit88__O(); A_arbace_spec_alpha__init_part0_A_Unit89__O(); A_arbace_spec_alpha__init_part0_A_Unit90__O(); A_arbace_spec_alpha__init_part0_A_Unit91__O(); A_arbace_spec_alpha__init_part0_A_Unit92__O(); A_arbace_spec_alpha__init_part0_A_Unit93__O(); A_arbace_spec_alpha__init_part0_A_Unit94__O(); A_arbace_spec_alpha__init_part0_A_Unit95__O(); A_arbace_spec_alpha__init_part0_A_Unit96__O(); A_arbace_spec_alpha__init_part0_A_Unit97__O(); A_arbace_spec_alpha__init_part0_A_Unit98__O(); A_arbace_spec_alpha__init_part0_A_Unit99__O(); return nil }












func A_arbace_spec_alpha__init_part0_A_Unit4__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); var root_3 any = A_arbace_spec_alpha__init_part0_A_const_4.GetRawRoot__O(); var linked_4 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3, aot_arbace_core.A_arbace_core_alias_A_fn_class); var ifn_5 lang.IFn; if linked_4 == nil { ifn_5 = lang.IFn_Cast(root_3) } else { ifn_5 = nil }; var arg_6 any = A_arbace_spec_alpha__init_part0_A_const_5; var arg_7 any = A_arbace_spec_alpha__init_part0_A_const_6; if linked_4 == nil { return ifn_5.Invoke_O_O__O(arg_6, arg_7) } else { return linked_4.(*aot_arbace_core.A_arbace_core_alias_A).Invoke_O_O_O__O(root_3, arg_6, arg_7) } }

func A_arbace_spec_alpha__init_part0_A_Unit5__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); return A_arbace_spec_alpha__init_part0_A_const_7.Set_O__O(jrt.Boolean_TRUE.Ref()) }

func A_arbace_spec_alpha__init_part0_A_Unit6__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); A_arbace_spec_alpha__init_part0_A_const_8.BindRoot_O__V(A_arbace_spec_alpha__init_part0_A_const_9); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_10)); return A_arbace_spec_alpha__init_part0_A_const_8.SetDynamic_Z__Var(true).Ref() }





func A_arbace_spec_alpha__init_part0_A_Unit7__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); A_arbace_spec_alpha__init_part0_A_const_11.BindRoot_O__V(A_arbace_spec_alpha__init_part0_A_const_12); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_11; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_13)); return A_arbace_spec_alpha__init_part0_A_const_11.SetDynamic_Z__Var(true).Ref() }



func A_arbace_spec_alpha__init_part0_A_Unit8__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); A_arbace_spec_alpha__init_part0_A_const_14.BindRoot_O__V(A_arbace_spec_alpha__init_part0_A_const_15); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_16)); return A_arbace_spec_alpha__init_part0_A_const_14.SetDynamic_Z__Var(true).Ref() }



func A_arbace_spec_alpha__init_part0_A_Unit9__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(44, 1); A_arbace_spec_alpha__init_part0_A_const_17.BindRoot_O__V(A_arbace_spec_alpha__init_part0_A_const_18); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_17; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_19)); return A_arbace_spec_alpha__init_part0_A_const_17.SetDynamic_Z__Var(true).Ref() }



func A_arbace_spec_alpha__init_part0_A_Unit10__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_20; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_21)); v__1927001498__auto____1 = A_arbace_spec_alpha__init_part0_A_const_20; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_20; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_22)); A_arbace_spec_alpha__init_part0_A_const_20.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_spec_alpha__init_part0_A_const_20 } }
//line :48:1
func A_arbace_spec_alpha__init_part0_A_Unit11__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_spec_alpha__init_part0_A_const_23 }
//line :48:1
func A_arbace_spec_alpha__init_part0_A_Unit12__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha__init_part0_A_const_24.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha__init_part0_A_const_20; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_spec_alpha__init_part0_A_const_25.GetRawRoot__O(), A_arbace_spec_alpha__init_part0_A_const_26, nil) }
//line :48:1
func A_arbace_spec_alpha__init_part0_A_Unit13__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_spec_alpha__init_part0_A_const_27.Invoke_O_O__O(A_arbace_spec_alpha__init_part0_A_const_20, A_arbace_spec_alpha__init_part0_A_const_28) }
//line :48:1
func A_arbace_spec_alpha__init_part0_A_Unit14__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha__init_part0_A_const_29.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha__init_part0_A_const_20; var tmp3 any = A_arbace_spec_alpha__init_part0_A_const_30.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha__init_part0_A_const_25.GetRawRoot__O()); var tmp5 any = A_arbace_spec_alpha__init_part0_A_const_31; var tmp6 any = A_arbace_spec_alpha__init_part0_A_const_32; var tmp7 any = A_arbace_spec_alpha__init_part0_A_const_33; var tmp8 any = A_arbace_spec_alpha__init_part0_A_const_34; var tmp9 any = A_arbace_spec_alpha__init_part0_A_const_20; var tmp10 any = A_arbace_spec_alpha__init_part0_A_const_35; var tmp11 any = A_arbace_spec_alpha__init_part0_A_const_36; var tmp12 any = A_arbace_spec_alpha__init_part0_A_const_37; var tmp13 any; var root_33 any = A_arbace_spec_alpha__init_part0_A_const_38.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = A_arbace_spec_alpha__init_part0_A_const_39.Get__O(); var arg_37 any; var root_38 any = A_arbace_spec_alpha__init_part0_A_const_40.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = A_arbace_spec_alpha__init_part0_A_const_41; var arg_42 any; var root_43 any = A_arbace_spec_alpha__init_part0_A_const_30.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = A_arbace_spec_alpha__init_part0_A_const_42; var arg_47 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha__init_part0_A_const_43, A_arbace_spec_alpha__init_part0_A_const_20)); if linked_44 == nil { arg_42 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { arg_42 = linked_44.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_43, arg_46, arg_47) }; if linked_39 == nil { arg_37 = ifn_40.Invoke_O_O__O(arg_41, arg_42) } else { arg_37 = linked_39.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_38, arg_41, arg_42) }; if linked_34 == nil { tmp13 = ifn_35.Invoke_O_O__O(arg_36, arg_37) } else { tmp13 = linked_34.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_33, arg_36, arg_37) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_New(); var tmp16 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_fn_class = fncls__48d; tmp16 = fncls__48d } else { tmp16 = fncls__48 }; var tmp17 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var tmp18 any; var root_49 any = A_arbace_spec_alpha__init_part0_A_const_38.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = A_arbace_spec_alpha__init_part0_A_const_39.Get__O(); var arg_53 any; var root_54 any = A_arbace_spec_alpha__init_part0_A_const_40.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = A_arbace_spec_alpha__init_part0_A_const_44; var arg_58 any; var root_59 any = A_arbace_spec_alpha__init_part0_A_const_30.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = A_arbace_spec_alpha__init_part0_A_const_45; var arg_63 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha__init_part0_A_const_43, A_arbace_spec_alpha__init_part0_A_const_20)); if linked_60 == nil { arg_58 = ifn_61.Invoke_O_O__O(arg_62, arg_63) } else { arg_58 = linked_60.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_59, arg_62, arg_63) }; if linked_55 == nil { arg_53 = ifn_56.Invoke_O_O__O(arg_57, arg_58) } else { arg_53 = linked_55.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_54, arg_57, arg_58) }; if linked_50 == nil { tmp18 = ifn_51.Invoke_O_O__O(arg_52, arg_53) } else { tmp18 = linked_50.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_49, arg_52, arg_53) }; var tmp19 any = tmp18; var tmp20 any = A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_New(); var tmp21 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_fn_class = fncls__64d; tmp21 = fncls__64d } else { tmp21 = fncls__64 }; var tmp22 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var tmp23 any; var root_65 any = A_arbace_spec_alpha__init_part0_A_const_38.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = A_arbace_spec_alpha__init_part0_A_const_39.Get__O(); var arg_69 any; var root_70 any = A_arbace_spec_alpha__init_part0_A_const_40.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = A_arbace_spec_alpha__init_part0_A_const_46; var arg_74 any; var root_75 any = A_arbace_spec_alpha__init_part0_A_const_30.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = A_arbace_spec_alpha__init_part0_A_const_47; var arg_79 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha__init_part0_A_const_43, A_arbace_spec_alpha__init_part0_A_const_20)); if linked_76 == nil { arg_74 = ifn_77.Invoke_O_O__O(arg_78, arg_79) } else { arg_74 = linked_76.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_75, arg_78, arg_79) }; if linked_71 == nil { arg_69 = ifn_72.Invoke_O_O__O(arg_73, arg_74) } else { arg_69 = linked_71.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_70, arg_73, arg_74) }; if linked_66 == nil { tmp23 = ifn_67.Invoke_O_O__O(arg_68, arg_69) } else { tmp23 = linked_66.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_65, arg_68, arg_69) }; var tmp24 any = tmp23; var tmp25 any = A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_New(); var tmp26 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_fn_class = fncls__80d; tmp26 = fncls__80d } else { tmp26 = fncls__80 }; var tmp27 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); var tmp28 any; var root_81 any = A_arbace_spec_alpha__init_part0_A_const_38.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = A_arbace_spec_alpha__init_part0_A_const_39.Get__O(); var arg_85 any; var root_86 any = A_arbace_spec_alpha__init_part0_A_const_40.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = A_arbace_spec_alpha__init_part0_A_const_48; var arg_90 any; var root_91 any = A_arbace_spec_alpha__init_part0_A_const_30.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = A_arbace_spec_alpha__init_part0_A_const_49; var arg_95 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha__init_part0_A_const_43, A_arbace_spec_alpha__init_part0_A_const_20)); if linked_92 == nil { arg_90 = ifn_93.Invoke_O_O__O(arg_94, arg_95) } else { arg_90 = linked_92.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_91, arg_94, arg_95) }; if linked_87 == nil { arg_85 = ifn_88.Invoke_O_O__O(arg_89, arg_90) } else { arg_85 = linked_87.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_86, arg_89, arg_90) }; if linked_82 == nil { tmp28 = ifn_83.Invoke_O_O__O(arg_84, arg_85) } else { tmp28 = linked_82.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_81, arg_84, arg_85) }; var tmp29 any = tmp28; var tmp30 any = A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_New(); var tmp31 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_fn_class = fncls__96d; tmp31 = fncls__96d } else { tmp31 = fncls__96 }; var tmp32 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil); var tmp33 any; var root_97 any = A_arbace_spec_alpha__init_part0_A_const_38.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = A_arbace_spec_alpha__init_part0_A_const_39.Get__O(); var arg_101 any; var root_102 any = A_arbace_spec_alpha__init_part0_A_const_40.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = A_arbace_spec_alpha__init_part0_A_const_50; var arg_106 any; var root_107 any = A_arbace_spec_alpha__init_part0_A_const_30.GetRawRoot__O(); var linked_108 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_107, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_109 lang.IFn; if linked_108 == nil { ifn_109 = lang.IFn_Cast(root_107) } else { ifn_109 = nil }; var arg_110 any = A_arbace_spec_alpha__init_part0_A_const_51; var arg_111 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha__init_part0_A_const_43, A_arbace_spec_alpha__init_part0_A_const_20)); if linked_108 == nil { arg_106 = ifn_109.Invoke_O_O__O(arg_110, arg_111) } else { arg_106 = linked_108.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_107, arg_110, arg_111) }; if linked_103 == nil { arg_101 = ifn_104.Invoke_O_O__O(arg_105, arg_106) } else { arg_101 = linked_103.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_102, arg_105, arg_106) }; if linked_98 == nil { tmp33 = ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { tmp33 = linked_98.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_97, arg_100, arg_101) }; var tmp34 any = tmp33; var tmp35 any = A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_New(); var tmp36 *jrt.Class; var fncls__112 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_fn_class; if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_fn_class = fncls__112d; tmp36 = fncls__112d } else { tmp36 = fncls__112 }; var tmp37 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil); var tmp38 any; var root_113 any = A_arbace_spec_alpha__init_part0_A_const_38.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = A_arbace_spec_alpha__init_part0_A_const_39.Get__O(); var arg_117 any; var root_118 any = A_arbace_spec_alpha__init_part0_A_const_40.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = A_arbace_spec_alpha__init_part0_A_const_52; var arg_122 any; var root_123 any = A_arbace_spec_alpha__init_part0_A_const_30.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = A_arbace_spec_alpha__init_part0_A_const_53; var arg_127 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha__init_part0_A_const_43, A_arbace_spec_alpha__init_part0_A_const_20)); if linked_124 == nil { arg_122 = ifn_125.Invoke_O_O__O(arg_126, arg_127) } else { arg_122 = linked_124.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_123, arg_126, arg_127) }; if linked_119 == nil { arg_117 = ifn_120.Invoke_O_O__O(arg_121, arg_122) } else { arg_117 = linked_119.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_118, arg_121, arg_122) }; if linked_114 == nil { tmp38 = ifn_115.Invoke_O_O__O(arg_116, arg_117) } else { tmp38 = linked_114.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_113, arg_116, arg_117) }; var tmp39 any = tmp38; var tmp40 any = A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_New(); var tmp41 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_fn_class = fncls__128d; tmp41 = fncls__128d } else { tmp41 = fncls__128 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp17, tmp19, tmp22, tmp24, tmp27, tmp29, tmp32, tmp34, tmp37, tmp39, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil))))) }
//line :48:1
func A_arbace_spec_alpha__init_part0_A_Unit15__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); var root_129 any = A_arbace_spec_alpha__init_part0_A_const_54.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = A_arbace_spec_alpha__init_part0_A_const_20.GetRawRoot__O(); if linked_130 == nil { return ifn_131.Invoke_O__O(arg_132) } else { return linked_130.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_129, arg_132) } }
//line :48:1
func A_arbace_spec_alpha__init_part0_A_Unit16__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(48, 1); return A_arbace_spec_alpha__init_part0_A_const_55 }







func A_arbace_spec_alpha__init_part0_A_Unit17__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_56; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_57)); v__1927001498__auto____1 = A_arbace_spec_alpha__init_part0_A_const_56; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_56; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_59)); var tmp3 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_56; var tmp4 any; var root_133 any = A_arbace_spec_alpha__init_part0_A_const_58.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_133, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_134 == nil { tmp4 = ifn_135.Invoke_O__O(arg_136) } else { tmp4 = linked_134.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_133, arg_136) }; tmp3.BindRoot_O__V(tmp4); return A_arbace_spec_alpha__init_part0_A_const_56 } }

func A_arbace_spec_alpha__init_part0_A_Unit18__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(58, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_60; var tmp2 any = A_arbace_spec_alpha_deep_resolve_A_New(); var tmp3 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_spec_alpha_deep_resolve_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_spec_alpha_deep_resolve_A_fn_class = fncls__137d; tmp3 = fncls__137d } else { tmp3 = fncls__137 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_61)); return A_arbace_spec_alpha__init_part0_A_const_60 }





func A_arbace_spec_alpha__init_part0_A_Unit19__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_62; var tmp2 any = A_arbace_spec_alpha_reg_resolve_A_New(); var tmp3 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_spec_alpha_reg_resolve_A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_spec_alpha_reg_resolve_A_fn_class = fncls__138d; tmp3 = fncls__138d } else { tmp3 = fncls__138 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_63)); return A_arbace_spec_alpha__init_part0_A_const_62 }










func A_arbace_spec_alpha__init_part0_A_Unit20__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(75, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_64; var tmp2 any = A_arbace_spec_alpha_reg_resolve_BANG__A_New(); var tmp3 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_spec_alpha_reg_resolve_BANG__A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_spec_alpha_reg_resolve_BANG__A_fn_class = fncls__139d; tmp3 = fncls__139d } else { tmp3 = fncls__139 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_65)); return A_arbace_spec_alpha__init_part0_A_const_64 }







func A_arbace_spec_alpha__init_part0_A_Unit21__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(83, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_66; var tmp2 any = A_arbace_spec_alpha_spec_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_spec_alpha_spec_QMARK__A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_spec_alpha_spec_QMARK__A_fn_class = fncls__140d; tmp3 = fncls__140d } else { tmp3 = fncls__140 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_67)); return A_arbace_spec_alpha__init_part0_A_const_66 }





func A_arbace_spec_alpha__init_part0_A_Unit22__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_68; var tmp2 any = A_arbace_spec_alpha_regex_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_spec_alpha_regex_QMARK__A_fn_class; if fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_spec_alpha_regex_QMARK__A_fn_class = fncls__141d; tmp3 = fncls__141d } else { tmp3 = fncls__141 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_69)); return A_arbace_spec_alpha__init_part0_A_const_68 }




func A_arbace_spec_alpha__init_part0_A_Unit23__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(94, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_70; var tmp2 any = A_arbace_spec_alpha_with_name_A_New(); var tmp3 *jrt.Class; var fncls__142 *jrt.Class = A_arbace_spec_alpha_with_name_A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_spec_alpha_with_name_A_fn_class = fncls__142d; tmp3 = fncls__142d } else { tmp3 = fncls__142 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_71)); return A_arbace_spec_alpha__init_part0_A_const_70 }







func A_arbace_spec_alpha__init_part0_A_Unit24__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(102, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_72; var tmp2 any = A_arbace_spec_alpha_spec_name_A_New(); var tmp3 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_spec_alpha_spec_name_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_spec_alpha_spec_name_A_fn_class = fncls__143d; tmp3 = fncls__143d } else { tmp3 = fncls__143 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_73)); return A_arbace_spec_alpha__init_part0_A_const_72 }








func A_arbace_spec_alpha__init_part0_A_Unit25__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(111, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_74; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_75)); return A_arbace_spec_alpha__init_part0_A_const_74 }
func A_arbace_spec_alpha__init_part0_A_Unit26__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_76; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_77)); return A_arbace_spec_alpha__init_part0_A_const_76 }

func A_arbace_spec_alpha__init_part0_A_Unit27__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(114, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_78; var tmp2 any = A_arbace_spec_alpha_maybe_spec_A_New(); var tmp3 *jrt.Class; var fncls__144 *jrt.Class = A_arbace_spec_alpha_maybe_spec_A_fn_class; if fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_159, false); A_arbace_spec_alpha_maybe_spec_A_fn_class = fncls__144d; tmp3 = fncls__144d } else { tmp3 = fncls__144 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_79)); return A_arbace_spec_alpha__init_part0_A_const_78 }










func A_arbace_spec_alpha__init_part0_A_Unit28__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(125, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_80; var tmp2 any = A_arbace_spec_alpha_the_spec_A_New(); var tmp3 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_spec_alpha_the_spec_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_160, false); A_arbace_spec_alpha_the_spec_A_fn_class = fncls__145d; tmp3 = fncls__145d } else { tmp3 = fncls__145 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_81)); return A_arbace_spec_alpha__init_part0_A_const_80 }






func A_arbace_spec_alpha__init_part0_A_Unit29__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_82; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_83)); v__1927001498__auto____1 = A_arbace_spec_alpha__init_part0_A_const_82; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_82; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_84)); A_arbace_spec_alpha__init_part0_A_const_82.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_spec_alpha__init_part0_A_const_82 } }
//line :132:1
func A_arbace_spec_alpha__init_part0_A_Unit30__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); return A_arbace_spec_alpha__init_part0_A_const_85 }
//line :132:1
func A_arbace_spec_alpha__init_part0_A_Unit31__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha__init_part0_A_const_24.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha__init_part0_A_const_82; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_spec_alpha__init_part0_A_const_25.GetRawRoot__O(), A_arbace_spec_alpha__init_part0_A_const_26, nil) }
//line :132:1
func A_arbace_spec_alpha__init_part0_A_Unit32__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); return A_arbace_spec_alpha__init_part0_A_const_27.Invoke_O_O__O(A_arbace_spec_alpha__init_part0_A_const_82, A_arbace_spec_alpha__init_part0_A_const_86) }
//line :132:1
func A_arbace_spec_alpha__init_part0_A_Unit33__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha__init_part0_A_const_29.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha__init_part0_A_const_82; var tmp3 any = A_arbace_spec_alpha__init_part0_A_const_30.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha__init_part0_A_const_25.GetRawRoot__O()); var tmp5 any = A_arbace_spec_alpha__init_part0_A_const_87; var tmp6 any = A_arbace_spec_alpha__init_part0_A_const_32; var tmp7 any = A_arbace_spec_alpha__init_part0_A_const_88; var tmp8 any = A_arbace_spec_alpha__init_part0_A_const_34; var tmp9 any = A_arbace_spec_alpha__init_part0_A_const_82; var tmp10 any = A_arbace_spec_alpha__init_part0_A_const_35; var tmp11 any = A_arbace_spec_alpha__init_part0_A_const_89; var tmp12 any = A_arbace_spec_alpha__init_part0_A_const_37; var tmp13 any; var root_171 any = A_arbace_spec_alpha__init_part0_A_const_38.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any = A_arbace_spec_alpha__init_part0_A_const_39.Get__O(); var arg_175 any; var root_176 any = A_arbace_spec_alpha__init_part0_A_const_40.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = A_arbace_spec_alpha__init_part0_A_const_90; var arg_180 any; var root_181 any = A_arbace_spec_alpha__init_part0_A_const_30.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = A_arbace_spec_alpha__init_part0_A_const_91; var arg_185 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha__init_part0_A_const_43, A_arbace_spec_alpha__init_part0_A_const_82)); if linked_182 == nil { arg_180 = ifn_183.Invoke_O_O__O(arg_184, arg_185) } else { arg_180 = linked_182.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_181, arg_184, arg_185) }; if linked_177 == nil { arg_175 = ifn_178.Invoke_O_O__O(arg_179, arg_180) } else { arg_175 = linked_177.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_176, arg_179, arg_180) }; if linked_172 == nil { tmp13 = ifn_173.Invoke_O_O__O(arg_174, arg_175) } else { tmp13 = linked_172.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_171, arg_174, arg_175) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_New(); var tmp16 *jrt.Class; var fncls__186 *jrt.Class = A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_fn_class; if fncls__186 == nil { var fncls__186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_fn_class = fncls__186d; tmp16 = fncls__186d } else { tmp16 = fncls__186 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil))))) }
//line :132:1
func A_arbace_spec_alpha__init_part0_A_Unit34__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); var root_187 any = A_arbace_spec_alpha__init_part0_A_const_54.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = A_arbace_spec_alpha__init_part0_A_const_82.GetRawRoot__O(); if linked_188 == nil { return ifn_189.Invoke_O__O(arg_190) } else { return linked_188.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_187, arg_190) } }
//line :132:1
func A_arbace_spec_alpha__init_part0_A_Unit35__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(132, 1); return A_arbace_spec_alpha__init_part0_A_const_92 }


func A_arbace_spec_alpha__init_part0_A_Unit36__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(135, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_93; var tmp2 any = A_arbace_spec_alpha_fn_sym_A_New(); var tmp3 *jrt.Class; var fncls__191 *jrt.Class = A_arbace_spec_alpha_fn_sym_A_fn_class; if fncls__191 == nil { var fncls__191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_162, false); A_arbace_spec_alpha_fn_sym_A_fn_class = fncls__191d; tmp3 = fncls__191d } else { tmp3 = fncls__191 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_94)); return A_arbace_spec_alpha__init_part0_A_const_93 }





func A_arbace_spec_alpha__init_part0_A_Unit37__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha__init_part0_A_const_95.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha__init_part0_A_const_96; var tmp3 any = A_arbace_spec_alpha__init_part0_A_const_82.GetRawRoot__O(); var tmp4 any = A_arbace_spec_alpha__init_part0_A_const_97; var tmp5 any = A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_New(); var tmp6 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_fn_class; if fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_fn_class = fncls__198d; tmp6 = fncls__198d } else { tmp6 = fncls__198 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :141:1
func A_arbace_spec_alpha__init_part0_A_Unit38__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha__init_part0_A_const_95.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha__init_part0_A_const_98; var tmp3 any = A_arbace_spec_alpha__init_part0_A_const_82.GetRawRoot__O(); var tmp4 any = A_arbace_spec_alpha__init_part0_A_const_97; var tmp5 any = A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_New(); var tmp6 *jrt.Class; var fncls__205 *jrt.Class = A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_fn_class; if fncls__205 == nil { var fncls__205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_164, false); A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_fn_class = fncls__205d; tmp6 = fncls__205d } else { tmp6 = fncls__205 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :141:1
func A_arbace_spec_alpha__init_part0_A_Unit39__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha__init_part0_A_const_95.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha__init_part0_A_const_99; var tmp3 any = A_arbace_spec_alpha__init_part0_A_const_82.GetRawRoot__O(); var tmp4 any = A_arbace_spec_alpha__init_part0_A_const_97; var tmp5 any = A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_New(); var tmp6 *jrt.Class; var fncls__212 *jrt.Class = A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_fn_class; if fncls__212 == nil { var fncls__212d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_165, false); A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_fn_class = fncls__212d; tmp6 = fncls__212d } else { tmp6 = fncls__212 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }
//line :141:1
func A_arbace_spec_alpha__init_part0_A_Unit40__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_alpha__init_part0_A_const_95.GetRawRoot__O()); var tmp2 any = A_arbace_spec_alpha__init_part0_A_const_100; var tmp3 any = A_arbace_spec_alpha__init_part0_A_const_82.GetRawRoot__O(); var tmp4 any = A_arbace_spec_alpha__init_part0_A_const_97; var tmp5 any = A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_New(); var tmp6 *jrt.Class; var fncls__219 *jrt.Class = A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_fn_class; if fncls__219 == nil { var fncls__219d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_166, false); A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_fn_class = fncls__219d; tmp6 = fncls__219d } else { tmp6 = fncls__219 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)))) }




















func A_arbace_spec_alpha__init_part0_A_Unit41__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(162, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_101; var tmp2 any = A_arbace_spec_alpha_specize_A_New(); var tmp3 *jrt.Class; var fncls__220 *jrt.Class = A_arbace_spec_alpha_specize_A_fn_class; if fncls__220 == nil { var fncls__220d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_167, false); A_arbace_spec_alpha_specize_A_fn_class = fncls__220d; tmp3 = fncls__220d } else { tmp3 = fncls__220 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_102)); return A_arbace_spec_alpha__init_part0_A_const_101 }



func A_arbace_spec_alpha__init_part0_A_Unit42__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(166, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_103; var tmp2 any = A_arbace_spec_alpha_invalid_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__221 *jrt.Class = A_arbace_spec_alpha_invalid_QMARK__A_fn_class; if fncls__221 == nil { var fncls__221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_168, false); A_arbace_spec_alpha_invalid_QMARK__A_fn_class = fncls__221d; tmp3 = fncls__221d } else { tmp3 = fncls__221 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_104)); return A_arbace_spec_alpha__init_part0_A_const_103 }




func A_arbace_spec_alpha__init_part0_A_Unit43__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(171, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_105; var tmp2 any = A_arbace_spec_alpha_conform_A_New(); var tmp3 *jrt.Class; var fncls__222 *jrt.Class = A_arbace_spec_alpha_conform_A_fn_class; if fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_169, false); A_arbace_spec_alpha_conform_A_fn_class = fncls__222d; tmp3 = fncls__222d } else { tmp3 = fncls__222 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_106)); return A_arbace_spec_alpha__init_part0_A_const_105 }





func A_arbace_spec_alpha__init_part0_A_Unit44__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_107; var tmp2 any = A_arbace_spec_alpha_unform_A_New(); var tmp3 *jrt.Class; var fncls__223 *jrt.Class = A_arbace_spec_alpha_unform_A_fn_class; if fncls__223 == nil { var fncls__223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_170, false); A_arbace_spec_alpha_unform_A_fn_class = fncls__223d; tmp3 = fncls__223d } else { tmp3 = fncls__223 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_108)); return A_arbace_spec_alpha__init_part0_A_const_107 }






func A_arbace_spec_alpha__init_part0_A_Unit45__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_109; var tmp2 any = A_arbace_spec_alpha_form_A_New(); var tmp3 *jrt.Class; var fncls__224 *jrt.Class = A_arbace_spec_alpha_form_A_fn_class; if fncls__224 == nil { var fncls__224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_171, false); A_arbace_spec_alpha_form_A_fn_class = fncls__224d; tmp3 = fncls__224d } else { tmp3 = fncls__224 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_110)); return A_arbace_spec_alpha__init_part0_A_const_109 }





func A_arbace_spec_alpha__init_part0_A_Unit46__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_111; var tmp2 any = A_arbace_spec_alpha_abbrev_A_New(); var tmp3 *jrt.Class; var fncls__225 *jrt.Class = A_arbace_spec_alpha_abbrev_A_fn_class; if fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_172, false); A_arbace_spec_alpha_abbrev_A_fn_class = fncls__225d; tmp3 = fncls__225d } else { tmp3 = fncls__225 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_112)); return A_arbace_spec_alpha__init_part0_A_const_111 }


















func A_arbace_spec_alpha__init_part0_A_Unit47__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(209, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_113; var tmp2 any = A_arbace_spec_alpha_describe_A_New(); var tmp3 *jrt.Class; var fncls__226 *jrt.Class = A_arbace_spec_alpha_describe_A_fn_class; if fncls__226 == nil { var fncls__226d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_173, false); A_arbace_spec_alpha_describe_A_fn_class = fncls__226d; tmp3 = fncls__226d } else { tmp3 = fncls__226 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_114)); return A_arbace_spec_alpha__init_part0_A_const_113 }




func A_arbace_spec_alpha__init_part0_A_Unit48__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(214, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_115; var tmp2 any = A_arbace_spec_alpha_with_gen_A_New(); var tmp3 *jrt.Class; var fncls__227 *jrt.Class = A_arbace_spec_alpha_with_gen_A_fn_class; if fncls__227 == nil { var fncls__227d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_174, false); A_arbace_spec_alpha_with_gen_A_fn_class = fncls__227d; tmp3 = fncls__227d } else { tmp3 = fncls__227 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_116)); return A_arbace_spec_alpha__init_part0_A_const_115 }







func A_arbace_spec_alpha__init_part0_A_Unit49__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(222, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_117; var tmp2 any = A_arbace_spec_alpha_explain_data_STAR__A_New(); var tmp3 *jrt.Class; var fncls__228 *jrt.Class = A_arbace_spec_alpha_explain_data_STAR__A_fn_class; if fncls__228 == nil { var fncls__228d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_175, false); A_arbace_spec_alpha_explain_data_STAR__A_fn_class = fncls__228d; tmp3 = fncls__228d } else { tmp3 = fncls__228 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_118)); return A_arbace_spec_alpha__init_part0_A_const_117 }






func A_arbace_spec_alpha__init_part0_A_Unit50__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_119; var tmp2 any = A_arbace_spec_alpha_explain_data_A_New(); var tmp3 *jrt.Class; var fncls__229 *jrt.Class = A_arbace_spec_alpha_explain_data_A_fn_class; if fncls__229 == nil { var fncls__229d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_176, false); A_arbace_spec_alpha_explain_data_A_fn_class = fncls__229d; tmp3 = fncls__229d } else { tmp3 = fncls__229 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_120)); return A_arbace_spec_alpha__init_part0_A_const_119 }








func A_arbace_spec_alpha__init_part0_A_Unit51__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(238, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_121; var tmp2 any = A_arbace_spec_alpha_explain_printer_A_New(); var tmp3 *jrt.Class; var fncls__230 *jrt.Class = A_arbace_spec_alpha_explain_printer_A_fn_class; if fncls__230 == nil { var fncls__230d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_177, false); A_arbace_spec_alpha_explain_printer_A_fn_class = fncls__230d; tmp3 = fncls__230d } else { tmp3 = fncls__230 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_122)); return A_arbace_spec_alpha__init_part0_A_const_121 }
























func A_arbace_spec_alpha__init_part0_A_Unit52__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(263, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_123; tmp1.BindRoot_O__V(A_arbace_spec_alpha__init_part0_A_const_121.GetRawRoot__O()); var tmp2 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_123; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_124)); return A_arbace_spec_alpha__init_part0_A_const_123.SetDynamic_Z__Var(true).Ref() }

func A_arbace_spec_alpha__init_part0_A_Unit53__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(265, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_125; var tmp2 any = A_arbace_spec_alpha_explain_out_A_New(); var tmp3 *jrt.Class; var fncls__231 *jrt.Class = A_arbace_spec_alpha_explain_out_A_fn_class; if fncls__231 == nil { var fncls__231d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_178, false); A_arbace_spec_alpha_explain_out_A_fn_class = fncls__231d; tmp3 = fncls__231d } else { tmp3 = fncls__231 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_125; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_126)); return A_arbace_spec_alpha__init_part0_A_const_125 }





func A_arbace_spec_alpha__init_part0_A_Unit54__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(271, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_127; var tmp2 any = A_arbace_spec_alpha_explain_A_New(); var tmp3 *jrt.Class; var fncls__232 *jrt.Class = A_arbace_spec_alpha_explain_A_fn_class; if fncls__232 == nil { var fncls__232d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_179, false); A_arbace_spec_alpha_explain_A_fn_class = fncls__232d; tmp3 = fncls__232d } else { tmp3 = fncls__232 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_127; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_128)); return A_arbace_spec_alpha__init_part0_A_const_127 }




func A_arbace_spec_alpha__init_part0_A_Unit55__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(276, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_129; var tmp2 any = A_arbace_spec_alpha_explain_str_A_New(); var tmp3 *jrt.Class; var fncls__233 *jrt.Class = A_arbace_spec_alpha_explain_str_A_fn_class; if fncls__233 == nil { var fncls__233d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_180, false); A_arbace_spec_alpha_explain_str_A_fn_class = fncls__233d; tmp3 = fncls__233d } else { tmp3 = fncls__233 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_129; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_130)); return A_arbace_spec_alpha__init_part0_A_const_129 }




func A_arbace_spec_alpha__init_part0_A_Unit56__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(281, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_131; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_132)); return A_arbace_spec_alpha__init_part0_A_const_131 }

func A_arbace_spec_alpha__init_part0_A_Unit57__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(283, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_133; var tmp2 any = A_arbace_spec_alpha_gensub_A_New(); var tmp3 *jrt.Class; var fncls__234 *jrt.Class = A_arbace_spec_alpha_gensub_A_fn_class; if fncls__234 == nil { var fncls__234d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_181, false); A_arbace_spec_alpha_gensub_A_fn_class = fncls__234d; tmp3 = fncls__234d } else { tmp3 = fncls__234 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_133; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_134)); return A_arbace_spec_alpha__init_part0_A_const_133 }












func A_arbace_spec_alpha__init_part0_A_Unit58__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(296, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_135; var tmp2 any = A_arbace_spec_alpha_gen_A_New(); var tmp3 *jrt.Class; var fncls__235 *jrt.Class = A_arbace_spec_alpha_gen_A_fn_class; if fncls__235 == nil { var fncls__235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_182, false); A_arbace_spec_alpha_gen_A_fn_class = fncls__235d; tmp3 = fncls__235d } else { tmp3 = fncls__235 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_135; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_136)); return A_arbace_spec_alpha__init_part0_A_const_135 }












func A_arbace_spec_alpha__init_part0_A_Unit59__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(309, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_137; var tmp2 any = A_arbace_spec_alpha___GT_sym_A_New(); var tmp3 *jrt.Class; var fncls__236 *jrt.Class = A_arbace_spec_alpha___GT_sym_A_fn_class; if fncls__236 == nil { var fncls__236d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_183, false); A_arbace_spec_alpha___GT_sym_A_fn_class = fncls__236d; tmp3 = fncls__236d } else { tmp3 = fncls__236 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_137; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_138)); return A_arbace_spec_alpha__init_part0_A_const_137 }






func A_arbace_spec_alpha__init_part0_A_Unit60__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(316, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_139; var tmp2 any = A_arbace_spec_alpha_unfn_A_New(); var tmp3 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_spec_alpha_unfn_A_fn_class; if fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_184, false); A_arbace_spec_alpha_unfn_A_fn_class = fncls__237d; tmp3 = fncls__237d } else { tmp3 = fncls__237 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_139; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_140)); return A_arbace_spec_alpha__init_part0_A_const_139 }







func A_arbace_spec_alpha__init_part0_A_Unit61__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(324, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_141; var tmp2 any = A_arbace_spec_alpha_res_A_New(); var tmp3 *jrt.Class; var fncls__238 *jrt.Class = A_arbace_spec_alpha_res_A_fn_class; if fncls__238 == nil { var fncls__238d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_185, false); A_arbace_spec_alpha_res_A_fn_class = fncls__238d; tmp3 = fncls__238d } else { tmp3 = fncls__238 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_141; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_142)); return A_arbace_spec_alpha__init_part0_A_const_141 }






func A_arbace_spec_alpha__init_part0_A_Unit62__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(331, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_143; var tmp2 any = A_arbace_spec_alpha_def_impl_A_New(); var tmp3 *jrt.Class; var fncls__239 *jrt.Class = A_arbace_spec_alpha_def_impl_A_fn_class; if fncls__239 == nil { var fncls__239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_186, false); A_arbace_spec_alpha_def_impl_A_fn_class = fncls__239d; tmp3 = fncls__239d } else { tmp3 = fncls__239 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_143; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_144)); return A_arbace_spec_alpha__init_part0_A_const_143 }











func A_arbace_spec_alpha__init_part0_A_Unit63__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(343, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_145; var tmp2 any = A_arbace_spec_alpha_ns_qualify_A_New(); var tmp3 *jrt.Class; var fncls__240 *jrt.Class = A_arbace_spec_alpha_ns_qualify_A_fn_class; if fncls__240 == nil { var fncls__240d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_187, false); A_arbace_spec_alpha_ns_qualify_A_fn_class = fncls__240d; tmp3 = fncls__240d } else { tmp3 = fncls__240 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_145; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_146)); return A_arbace_spec_alpha__init_part0_A_const_145 }







func A_arbace_spec_alpha__init_part0_A_Unit64__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(351, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_147; var tmp2 any = A_arbace_spec_alpha_def_A_New(); var tmp3 *jrt.Class; var fncls__241 *jrt.Class = A_arbace_spec_alpha_def_A_fn_class; if fncls__241 == nil { var fncls__241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_188, false); A_arbace_spec_alpha_def_A_fn_class = fncls__241d; tmp3 = fncls__241d } else { tmp3 = fncls__241 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_147; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_148)); return A_arbace_spec_alpha__init_part0_A_const_147 }
//line :351:1
func A_arbace_spec_alpha__init_part0_A_Unit65__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(351, 1); A_arbace_spec_alpha__init_part0_A_const_147.SetMacro__V(); return nil }
//line :351:1
func A_arbace_spec_alpha__init_part0_A_Unit66__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(351, 1); return A_arbace_spec_alpha__init_part0_A_const_147 }








func A_arbace_spec_alpha__init_part0_A_Unit67__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(360, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_149; var tmp2 any = A_arbace_spec_alpha_registry_A_New(); var tmp3 *jrt.Class; var fncls__242 *jrt.Class = A_arbace_spec_alpha_registry_A_fn_class; if fncls__242 == nil { var fncls__242d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_189, false); A_arbace_spec_alpha_registry_A_fn_class = fncls__242d; tmp3 = fncls__242d } else { tmp3 = fncls__242 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_149; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_150)); return A_arbace_spec_alpha__init_part0_A_const_149 }




func A_arbace_spec_alpha__init_part0_A_Unit68__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(365, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_151; var tmp2 any = A_arbace_spec_alpha_get_spec_A_New(); var tmp3 *jrt.Class; var fncls__243 *jrt.Class = A_arbace_spec_alpha_get_spec_A_fn_class; if fncls__243 == nil { var fncls__243d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_190, false); A_arbace_spec_alpha_get_spec_A_fn_class = fncls__243d; tmp3 = fncls__243d } else { tmp3 = fncls__243 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_151; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_152)); return A_arbace_spec_alpha__init_part0_A_const_151 }




func A_arbace_spec_alpha__init_part0_A_Unit69__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_153; var tmp2 any = A_arbace_spec_alpha_spec_A_New(); var tmp3 *jrt.Class; var fncls__244 *jrt.Class = A_arbace_spec_alpha_spec_A_fn_class; if fncls__244 == nil { var fncls__244d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_191, true); A_arbace_spec_alpha_spec_A_fn_class = fncls__244d; tmp3 = fncls__244d } else { tmp3 = fncls__244 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_153; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_154)); return A_arbace_spec_alpha__init_part0_A_const_153 }
//line :370:1
func A_arbace_spec_alpha__init_part0_A_Unit70__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); A_arbace_spec_alpha__init_part0_A_const_153.SetMacro__V(); return nil }
//line :370:1
func A_arbace_spec_alpha__init_part0_A_Unit71__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(370, 1); return A_arbace_spec_alpha__init_part0_A_const_153 }


















func A_arbace_spec_alpha__init_part0_A_Unit72__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(389, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_155; var tmp2 any = A_arbace_spec_alpha_multi_spec_A_New(); var tmp3 *jrt.Class; var fncls__245 *jrt.Class = A_arbace_spec_alpha_multi_spec_A_fn_class; if fncls__245 == nil { var fncls__245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_192, false); A_arbace_spec_alpha_multi_spec_A_fn_class = fncls__245d; tmp3 = fncls__245d } else { tmp3 = fncls__245 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_155; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_156)); return A_arbace_spec_alpha__init_part0_A_const_155 }
//line :389:1
func A_arbace_spec_alpha__init_part0_A_Unit73__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(389, 1); A_arbace_spec_alpha__init_part0_A_const_155.SetMacro__V(); return nil }
//line :389:1
func A_arbace_spec_alpha__init_part0_A_Unit74__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(389, 1); return A_arbace_spec_alpha__init_part0_A_const_155 }




























func A_arbace_spec_alpha__init_part0_A_Unit75__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(418, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_157; var tmp2 any = A_arbace_spec_alpha_keys_A_New(); var tmp3 *jrt.Class; var fncls__246 *jrt.Class = A_arbace_spec_alpha_keys_A_fn_class; if fncls__246 == nil { var fncls__246d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_193, true); A_arbace_spec_alpha_keys_A_fn_class = fncls__246d; tmp3 = fncls__246d } else { tmp3 = fncls__246 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_157; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_158)); return A_arbace_spec_alpha__init_part0_A_const_157 }
//line :418:1
func A_arbace_spec_alpha__init_part0_A_Unit76__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(418, 1); A_arbace_spec_alpha__init_part0_A_const_157.SetMacro__V(); return nil }
//line :418:1
func A_arbace_spec_alpha__init_part0_A_Unit77__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(418, 1); return A_arbace_spec_alpha__init_part0_A_const_157 }





























































func A_arbace_spec_alpha__init_part0_A_Unit78__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(480, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_159; var tmp2 any = A_arbace_spec_alpha_or_A_New(); var tmp3 *jrt.Class; var fncls__247 *jrt.Class = A_arbace_spec_alpha_or_A_fn_class; if fncls__247 == nil { var fncls__247d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_194, true); A_arbace_spec_alpha_or_A_fn_class = fncls__247d; tmp3 = fncls__247d } else { tmp3 = fncls__247 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_159; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_160)); return A_arbace_spec_alpha__init_part0_A_const_159 }
//line :480:1
func A_arbace_spec_alpha__init_part0_A_Unit79__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(480, 1); A_arbace_spec_alpha__init_part0_A_const_159.SetMacro__V(); return nil }
//line :480:1
func A_arbace_spec_alpha__init_part0_A_Unit80__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(480, 1); return A_arbace_spec_alpha__init_part0_A_const_159 }
















func A_arbace_spec_alpha__init_part0_A_Unit81__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(497, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_161; var tmp2 any = A_arbace_spec_alpha_and_A_New(); var tmp3 *jrt.Class; var fncls__248 *jrt.Class = A_arbace_spec_alpha_and_A_fn_class; if fncls__248 == nil { var fncls__248d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_195, true); A_arbace_spec_alpha_and_A_fn_class = fncls__248d; tmp3 = fncls__248d } else { tmp3 = fncls__248 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_161; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_162)); return A_arbace_spec_alpha__init_part0_A_const_161 }
//line :497:1
func A_arbace_spec_alpha__init_part0_A_Unit82__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(497, 1); A_arbace_spec_alpha__init_part0_A_const_161.SetMacro__V(); return nil }
//line :497:1
func A_arbace_spec_alpha__init_part0_A_Unit83__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(497, 1); return A_arbace_spec_alpha__init_part0_A_const_161 }









func A_arbace_spec_alpha__init_part0_A_Unit84__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(507, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_163; var tmp2 any = A_arbace_spec_alpha_merge_A_New(); var tmp3 *jrt.Class; var fncls__249 *jrt.Class = A_arbace_spec_alpha_merge_A_fn_class; if fncls__249 == nil { var fncls__249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_196, true); A_arbace_spec_alpha_merge_A_fn_class = fncls__249d; tmp3 = fncls__249d } else { tmp3 = fncls__249 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_163; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_164)); return A_arbace_spec_alpha__init_part0_A_const_163 }
//line :507:1
func A_arbace_spec_alpha__init_part0_A_Unit85__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(507, 1); A_arbace_spec_alpha__init_part0_A_const_163.SetMacro__V(); return nil }
//line :507:1
func A_arbace_spec_alpha__init_part0_A_Unit86__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(507, 1); return A_arbace_spec_alpha__init_part0_A_const_163 }







func A_arbace_spec_alpha__init_part0_A_Unit87__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(515, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_165; var tmp2 any = A_arbace_spec_alpha_res_kind_A_New(); var tmp3 *jrt.Class; var fncls__250 *jrt.Class = A_arbace_spec_alpha_res_kind_A_fn_class; if fncls__250 == nil { var fncls__250d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_197, false); A_arbace_spec_alpha_res_kind_A_fn_class = fncls__250d; tmp3 = fncls__250d } else { tmp3 = fncls__250 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_165; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_166)); return A_arbace_spec_alpha__init_part0_A_const_165 }








func A_arbace_spec_alpha__init_part0_A_Unit88__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(524, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_167; var tmp2 any = A_arbace_spec_alpha_every_A_New(); var tmp3 *jrt.Class; var fncls__251 *jrt.Class = A_arbace_spec_alpha_every_A_fn_class; if fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_198, true); A_arbace_spec_alpha_every_A_fn_class = fncls__251d; tmp3 = fncls__251d } else { tmp3 = fncls__251 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_167; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_168)); return A_arbace_spec_alpha__init_part0_A_const_167 }
//line :524:1
func A_arbace_spec_alpha__init_part0_A_Unit89__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(524, 1); A_arbace_spec_alpha__init_part0_A_const_167.SetMacro__V(); return nil }
//line :524:1
func A_arbace_spec_alpha__init_part0_A_Unit90__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(524, 1); return A_arbace_spec_alpha__init_part0_A_const_167 }















































func A_arbace_spec_alpha__init_part0_A_Unit91__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(572, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_169; var tmp2 any = A_arbace_spec_alpha_every_kv_A_New(); var tmp3 *jrt.Class; var fncls__252 *jrt.Class = A_arbace_spec_alpha_every_kv_A_fn_class; if fncls__252 == nil { var fncls__252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_199, true); A_arbace_spec_alpha_every_kv_A_fn_class = fncls__252d; tmp3 = fncls__252d } else { tmp3 = fncls__252 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_169; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_170)); return A_arbace_spec_alpha__init_part0_A_const_169 }
//line :572:1
func A_arbace_spec_alpha__init_part0_A_Unit92__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(572, 1); A_arbace_spec_alpha__init_part0_A_const_169.SetMacro__V(); return nil }
//line :572:1
func A_arbace_spec_alpha__init_part0_A_Unit93__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(572, 1); return A_arbace_spec_alpha__init_part0_A_const_169 }










func A_arbace_spec_alpha__init_part0_A_Unit94__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(583, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_171; var tmp2 any = A_arbace_spec_alpha_coll_of_A_New(); var tmp3 *jrt.Class; var fncls__253 *jrt.Class = A_arbace_spec_alpha_coll_of_A_fn_class; if fncls__253 == nil { var fncls__253d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_200, true); A_arbace_spec_alpha_coll_of_A_fn_class = fncls__253d; tmp3 = fncls__253d } else { tmp3 = fncls__253 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_171; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_172)); return A_arbace_spec_alpha__init_part0_A_const_171 }
//line :583:1
func A_arbace_spec_alpha__init_part0_A_Unit95__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(583, 1); A_arbace_spec_alpha__init_part0_A_const_171.SetMacro__V(); return nil }
//line :583:1
func A_arbace_spec_alpha__init_part0_A_Unit96__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(583, 1); return A_arbace_spec_alpha__init_part0_A_const_171 }












func A_arbace_spec_alpha__init_part0_A_Unit97__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(596, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_173; var tmp2 any = A_arbace_spec_alpha_map_of_A_New(); var tmp3 *jrt.Class; var fncls__254 *jrt.Class = A_arbace_spec_alpha_map_of_A_fn_class; if fncls__254 == nil { var fncls__254d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_201, true); A_arbace_spec_alpha_map_of_A_fn_class = fncls__254d; tmp3 = fncls__254d } else { tmp3 = fncls__254 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 4)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part0_A_const_173; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part0_A_const_174)); return A_arbace_spec_alpha__init_part0_A_const_173 }
//line :596:1
func A_arbace_spec_alpha__init_part0_A_Unit98__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(596, 1); A_arbace_spec_alpha__init_part0_A_const_173.SetMacro__V(); return nil }
//line :596:1
func A_arbace_spec_alpha__init_part0_A_Unit99__O() any { A_arbace_spec_alpha__init_part0_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(596, 1); return A_arbace_spec_alpha__init_part0_A_const_173 }














func A_arbace_spec_alpha__init_part1_A_Unit100__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(611, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_0; var tmp2 any = A_arbace_spec_alpha__STAR__A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_spec_alpha__STAR__A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_203, false); A_arbace_spec_alpha__STAR__A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_0; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_1)); return A_arbace_spec_alpha__init_part1_A_const_0 }
//line :611:1
func A_arbace_spec_alpha__init_part1_A_Unit101__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(611, 1); A_arbace_spec_alpha__init_part1_A_const_0.SetMacro__V(); return nil }
//line :611:1
func A_arbace_spec_alpha__init_part1_A_Unit102__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(611, 1); return A_arbace_spec_alpha__init_part1_A_const_0 }
//line :611:1
func A_arbace_spec_alpha__init_part1_A_Init__O() any { A_arbace_spec_alpha__init_part1_A_Init(); return nil }
//line :611:1
func A_arbace_spec_alpha__init_part1_A_Load__O() any { A_arbace_spec_alpha__init_part1_A_Init(); A_arbace_spec_alpha__init_part1_A_Unit100__O(); A_arbace_spec_alpha__init_part1_A_Unit101__O(); A_arbace_spec_alpha__init_part1_A_Unit102__O(); A_arbace_spec_alpha__init_part1_A_Unit103__O(); A_arbace_spec_alpha__init_part1_A_Unit104__O(); A_arbace_spec_alpha__init_part1_A_Unit105__O(); A_arbace_spec_alpha__init_part1_A_Unit106__O(); A_arbace_spec_alpha__init_part1_A_Unit107__O(); A_arbace_spec_alpha__init_part1_A_Unit108__O(); A_arbace_spec_alpha__init_part1_A_Unit109__O(); A_arbace_spec_alpha__init_part1_A_Unit110__O(); A_arbace_spec_alpha__init_part1_A_Unit111__O(); A_arbace_spec_alpha__init_part1_A_Unit112__O(); A_arbace_spec_alpha__init_part1_A_Unit113__O(); A_arbace_spec_alpha__init_part1_A_Unit114__O(); A_arbace_spec_alpha__init_part1_A_Unit115__O(); A_arbace_spec_alpha__init_part1_A_Unit116__O(); A_arbace_spec_alpha__init_part1_A_Unit117__O(); A_arbace_spec_alpha__init_part1_A_Unit118__O(); A_arbace_spec_alpha__init_part1_A_Unit119__O(); A_arbace_spec_alpha__init_part1_A_Unit120__O(); A_arbace_spec_alpha__init_part1_A_Unit121__O(); A_arbace_spec_alpha__init_part1_A_Unit122__O(); A_arbace_spec_alpha__init_part1_A_Unit123__O(); A_arbace_spec_alpha__init_part1_A_Unit124__O(); A_arbace_spec_alpha__init_part1_A_Unit125__O(); A_arbace_spec_alpha__init_part1_A_Unit126__O(); A_arbace_spec_alpha__init_part1_A_Unit127__O(); A_arbace_spec_alpha__init_part1_A_Unit128__O(); A_arbace_spec_alpha__init_part1_A_Unit129__O(); A_arbace_spec_alpha__init_part1_A_Unit130__O(); A_arbace_spec_alpha__init_part1_A_Unit131__O(); A_arbace_spec_alpha__init_part1_A_Unit132__O(); A_arbace_spec_alpha__init_part1_A_Unit133__O(); A_arbace_spec_alpha__init_part1_A_Unit134__O(); A_arbace_spec_alpha__init_part1_A_Unit135__O(); A_arbace_spec_alpha__init_part1_A_Unit136__O(); A_arbace_spec_alpha__init_part1_A_Unit137__O(); A_arbace_spec_alpha__init_part1_A_Unit138__O(); A_arbace_spec_alpha__init_part1_A_Unit139__O(); A_arbace_spec_alpha__init_part1_A_Unit140__O(); A_arbace_spec_alpha__init_part1_A_Unit141__O(); A_arbace_spec_alpha__init_part1_A_Unit142__O(); A_arbace_spec_alpha__init_part1_A_Unit143__O(); A_arbace_spec_alpha__init_part1_A_Unit144__O(); A_arbace_spec_alpha__init_part1_A_Unit145__O(); A_arbace_spec_alpha__init_part1_A_Unit146__O(); A_arbace_spec_alpha__init_part1_A_Unit147__O(); A_arbace_spec_alpha__init_part1_A_Unit148__O(); A_arbace_spec_alpha__init_part1_A_Unit149__O(); A_arbace_spec_alpha__init_part1_A_Unit150__O(); A_arbace_spec_alpha__init_part1_A_Unit151__O(); A_arbace_spec_alpha__init_part1_A_Unit152__O(); A_arbace_spec_alpha__init_part1_A_Unit153__O(); A_arbace_spec_alpha__init_part1_A_Unit154__O(); A_arbace_spec_alpha__init_part1_A_Unit155__O(); A_arbace_spec_alpha__init_part1_A_Unit156__O(); A_arbace_spec_alpha__init_part1_A_Unit157__O(); A_arbace_spec_alpha__init_part1_A_Unit158__O(); A_arbace_spec_alpha__init_part1_A_Unit159__O(); A_arbace_spec_alpha__init_part1_A_Unit160__O(); A_arbace_spec_alpha__init_part1_A_Unit161__O(); A_arbace_spec_alpha__init_part1_A_Unit162__O(); A_arbace_spec_alpha__init_part1_A_Unit163__O(); A_arbace_spec_alpha__init_part1_A_Unit164__O(); A_arbace_spec_alpha__init_part1_A_Unit165__O(); A_arbace_spec_alpha__init_part1_A_Unit166__O(); A_arbace_spec_alpha__init_part1_A_Unit167__O(); A_arbace_spec_alpha__init_part1_A_Unit168__O(); A_arbace_spec_alpha__init_part1_A_Unit169__O(); A_arbace_spec_alpha__init_part1_A_Unit170__O(); A_arbace_spec_alpha__init_part1_A_Unit171__O(); A_arbace_spec_alpha__init_part1_A_Unit172__O(); A_arbace_spec_alpha__init_part1_A_Unit173__O(); A_arbace_spec_alpha__init_part1_A_Unit174__O(); A_arbace_spec_alpha__init_part1_A_Unit175__O(); A_arbace_spec_alpha__init_part1_A_Unit176__O(); A_arbace_spec_alpha__init_part1_A_Unit177__O(); A_arbace_spec_alpha__init_part1_A_Unit178__O(); A_arbace_spec_alpha__init_part1_A_Unit179__O(); A_arbace_spec_alpha__init_part1_A_Unit180__O(); A_arbace_spec_alpha__init_part1_A_Unit181__O(); A_arbace_spec_alpha__init_part1_A_Unit182__O(); A_arbace_spec_alpha__init_part1_A_Unit183__O(); A_arbace_spec_alpha__init_part1_A_Unit184__O(); A_arbace_spec_alpha__init_part1_A_Unit185__O(); A_arbace_spec_alpha__init_part1_A_Unit186__O(); A_arbace_spec_alpha__init_part1_A_Unit187__O(); A_arbace_spec_alpha__init_part1_A_Unit188__O(); A_arbace_spec_alpha__init_part1_A_Unit189__O(); A_arbace_spec_alpha__init_part1_A_Unit190__O(); A_arbace_spec_alpha__init_part1_A_Unit191__O(); A_arbace_spec_alpha__init_part1_A_Unit192__O(); A_arbace_spec_alpha__init_part1_A_Unit193__O(); A_arbace_spec_alpha__init_part1_A_Unit194__O(); A_arbace_spec_alpha__init_part1_A_Unit195__O(); A_arbace_spec_alpha__init_part1_A_Unit196__O(); A_arbace_spec_alpha__init_part1_A_Unit197__O(); A_arbace_spec_alpha__init_part1_A_Unit198__O(); A_arbace_spec_alpha__init_part1_A_Unit199__O(); return nil }





func A_arbace_spec_alpha__init_part1_A_Unit103__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(617, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_2; var tmp2 any = A_arbace_spec_alpha__PLUS__A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_spec_alpha__PLUS__A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_204, false); A_arbace_spec_alpha__PLUS__A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_2; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_3)); return A_arbace_spec_alpha__init_part1_A_const_2 }
//line :617:1
func A_arbace_spec_alpha__init_part1_A_Unit104__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(617, 1); A_arbace_spec_alpha__init_part1_A_const_2.SetMacro__V(); return nil }
//line :617:1
func A_arbace_spec_alpha__init_part1_A_Unit105__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(617, 1); return A_arbace_spec_alpha__init_part1_A_const_2 }





func A_arbace_spec_alpha__init_part1_A_Unit106__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(623, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_4; var tmp2 any = A_arbace_spec_alpha__QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_spec_alpha__QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_205, false); A_arbace_spec_alpha__QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_5)); return A_arbace_spec_alpha__init_part1_A_const_4 }
//line :623:1
func A_arbace_spec_alpha__init_part1_A_Unit107__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(623, 1); A_arbace_spec_alpha__init_part1_A_const_4.SetMacro__V(); return nil }
//line :623:1
func A_arbace_spec_alpha__init_part1_A_Unit108__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(623, 1); return A_arbace_spec_alpha__init_part1_A_const_4 }





func A_arbace_spec_alpha__init_part1_A_Unit109__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(629, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_6; var tmp2 any = A_arbace_spec_alpha_alt_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_spec_alpha_alt_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_206, true); A_arbace_spec_alpha_alt_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_7)); return A_arbace_spec_alpha__init_part1_A_const_6 }
//line :629:1
func A_arbace_spec_alpha__init_part1_A_Unit110__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(629, 1); A_arbace_spec_alpha__init_part1_A_const_6.SetMacro__V(); return nil }
//line :629:1
func A_arbace_spec_alpha__init_part1_A_Unit111__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(629, 1); return A_arbace_spec_alpha__init_part1_A_const_6 }
















func A_arbace_spec_alpha__init_part1_A_Unit112__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(646, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_8; var tmp2 any = A_arbace_spec_alpha_cat_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_spec_alpha_cat_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_207, true); A_arbace_spec_alpha_cat_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_9)); return A_arbace_spec_alpha__init_part1_A_const_8 }
//line :646:1
func A_arbace_spec_alpha__init_part1_A_Unit113__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(646, 1); A_arbace_spec_alpha__init_part1_A_const_8.SetMacro__V(); return nil }
//line :646:1
func A_arbace_spec_alpha__init_part1_A_Unit114__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(646, 1); return A_arbace_spec_alpha__init_part1_A_const_8 }















func A_arbace_spec_alpha__init_part1_A_Unit115__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(662, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_10; var tmp2 any = A_arbace_spec_alpha__AMPERSAND__A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_spec_alpha__AMPERSAND__A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_208, true); A_arbace_spec_alpha__AMPERSAND__A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_11)); return A_arbace_spec_alpha__init_part1_A_const_10 }
//line :662:1
func A_arbace_spec_alpha__init_part1_A_Unit116__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(662, 1); A_arbace_spec_alpha__init_part1_A_const_10.SetMacro__V(); return nil }
//line :662:1
func A_arbace_spec_alpha__init_part1_A_Unit117__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(662, 1); return A_arbace_spec_alpha__init_part1_A_const_10 }







func A_arbace_spec_alpha__init_part1_A_Unit118__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(670, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_12; var tmp2 any = A_arbace_spec_alpha_conformer_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_spec_alpha_conformer_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_209, false); A_arbace_spec_alpha_conformer_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_13)); return A_arbace_spec_alpha__init_part1_A_const_12 }
//line :670:1
func A_arbace_spec_alpha__init_part1_A_Unit119__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(670, 1); A_arbace_spec_alpha__init_part1_A_const_12.SetMacro__V(); return nil }
//line :670:1
func A_arbace_spec_alpha__init_part1_A_Unit120__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(670, 1); return A_arbace_spec_alpha__init_part1_A_const_12 }







func A_arbace_spec_alpha__init_part1_A_Unit121__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(678, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_14; var tmp2 any = A_arbace_spec_alpha_fspec_A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_spec_alpha_fspec_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_210, true); A_arbace_spec_alpha_fspec_A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_15)); return A_arbace_spec_alpha__init_part1_A_const_14 }
//line :678:1
func A_arbace_spec_alpha__init_part1_A_Unit122__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(678, 1); A_arbace_spec_alpha__init_part1_A_const_14.SetMacro__V(); return nil }
//line :678:1
func A_arbace_spec_alpha__init_part1_A_Unit123__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(678, 1); return A_arbace_spec_alpha__init_part1_A_const_14 }



















func A_arbace_spec_alpha__init_part1_A_Unit124__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(698, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_16; var tmp2 any = A_arbace_spec_alpha_tuple_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_spec_alpha_tuple_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_211, true); A_arbace_spec_alpha_tuple_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_17)); return A_arbace_spec_alpha__init_part1_A_const_16 }
//line :698:1
func A_arbace_spec_alpha__init_part1_A_Unit125__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(698, 1); A_arbace_spec_alpha__init_part1_A_const_16.SetMacro__V(); return nil }
//line :698:1
func A_arbace_spec_alpha__init_part1_A_Unit126__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(698, 1); return A_arbace_spec_alpha__init_part1_A_const_16 }







func A_arbace_spec_alpha__init_part1_A_Unit127__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(706, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_18; var tmp2 any = A_arbace_spec_alpha_macroexpand_check_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_spec_alpha_macroexpand_check_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_212, false); A_arbace_spec_alpha_macroexpand_check_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_19)); return A_arbace_spec_alpha__init_part1_A_const_18 }











func A_arbace_spec_alpha__init_part1_A_Unit128__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(718, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_20; var tmp2 any = A_arbace_spec_alpha_fdef_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_spec_alpha_fdef_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_213, true); A_arbace_spec_alpha_fdef_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 3)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_21)); return A_arbace_spec_alpha__init_part1_A_const_20 }
//line :718:1
func A_arbace_spec_alpha__init_part1_A_Unit129__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(718, 1); A_arbace_spec_alpha__init_part1_A_const_20.SetMacro__V(); return nil }
//line :718:1
func A_arbace_spec_alpha__init_part1_A_Unit130__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(718, 1); return A_arbace_spec_alpha__init_part1_A_const_20 }



































func A_arbace_spec_alpha__init_part1_A_Unit131__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(754, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_22; var tmp2 any = A_arbace_spec_alpha_recur_limit_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_spec_alpha_recur_limit_QMARK__A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_214, false); A_arbace_spec_alpha_recur_limit_QMARK__A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_23)); return A_arbace_spec_alpha__init_part1_A_const_22 }



func A_arbace_spec_alpha__init_part1_A_Unit132__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(758, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_24; var tmp2 any = A_arbace_spec_alpha_inck_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_spec_alpha_inck_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_215, false); A_arbace_spec_alpha_inck_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_25)); return A_arbace_spec_alpha__init_part1_A_const_24 }


func A_arbace_spec_alpha__init_part1_A_Unit133__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(761, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_26; var tmp2 any = A_arbace_spec_alpha_dt_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_spec_alpha_dt_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_216, false); A_arbace_spec_alpha_dt_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_27)); return A_arbace_spec_alpha__init_part1_A_const_26 }












func A_arbace_spec_alpha__init_part1_A_Unit134__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(774, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_28; var tmp2 any = A_arbace_spec_alpha_valid_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_spec_alpha_valid_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_217, false); A_arbace_spec_alpha_valid_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_29)); return A_arbace_spec_alpha__init_part1_A_const_28 }








func A_arbace_spec_alpha__init_part1_A_Unit135__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(783, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_30; var tmp2 any = A_arbace_spec_alpha_pvalid_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_spec_alpha_pvalid_QMARK__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_218, false); A_arbace_spec_alpha_pvalid_QMARK__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_31)); return A_arbace_spec_alpha__init_part1_A_const_30 }






func A_arbace_spec_alpha__init_part1_A_Unit136__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(790, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_32; var tmp2 any = A_arbace_spec_alpha_explain_1_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_spec_alpha_explain_1_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_219, false); A_arbace_spec_alpha_explain_1_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_33)); return A_arbace_spec_alpha__init_part1_A_const_32 }






func A_arbace_spec_alpha__init_part1_A_Unit137__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(797, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_34; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_35)); return A_arbace_spec_alpha__init_part1_A_const_34 }
//line :797:1
func A_arbace_spec_alpha__init_part1_A_Unit138__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(797, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_36; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_37)); return A_arbace_spec_alpha__init_part1_A_const_36 }

func A_arbace_spec_alpha__init_part1_A_Unit139__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(799, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_38; var tmp2 any = A_arbace_spec_alpha_k_gen_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_spec_alpha_k_gen_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_220, false); A_arbace_spec_alpha_k_gen_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_39)); return A_arbace_spec_alpha__init_part1_A_const_38 }








func A_arbace_spec_alpha__init_part1_A_Unit140__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(808, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_34; var tmp2 any = A_arbace_spec_alpha_or_k_gen_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_spec_alpha_or_k_gen_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_221, false); A_arbace_spec_alpha_or_k_gen_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_40)); return A_arbace_spec_alpha__init_part1_A_const_34 }










func A_arbace_spec_alpha__init_part1_A_Unit141__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(819, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_36; var tmp2 any = A_arbace_spec_alpha_and_k_gen_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_spec_alpha_and_k_gen_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_222, false); A_arbace_spec_alpha_and_k_gen_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_41)); return A_arbace_spec_alpha__init_part1_A_const_36 }






func A_arbace_spec_alpha__init_part1_A_Unit142__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(826, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_42; var tmp2 any = A_arbace_spec_alpha_map_spec_impl_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_spec_alpha_map_spec_impl_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_223, false); A_arbace_spec_alpha_map_spec_impl_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_43)); return A_arbace_spec_alpha__init_part1_A_const_42 }


























































































func A_arbace_spec_alpha__init_part1_A_Unit143__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(917, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_44; var tmp2 any = A_arbace_spec_alpha_spec_impl_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_spec_alpha_spec_impl_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_224, false); A_arbace_spec_alpha_spec_impl_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_45)); return A_arbace_spec_alpha__init_part1_A_const_44 }
































func A_arbace_spec_alpha__init_part1_A_Unit144__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(950, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_46; var tmp2 any = A_arbace_spec_alpha_multi_spec_impl_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_spec_alpha_multi_spec_impl_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_225, false); A_arbace_spec_alpha_multi_spec_impl_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_47)); return A_arbace_spec_alpha__init_part1_A_const_46 }

















































func A_arbace_spec_alpha__init_part1_A_Unit145__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1000, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_48; var tmp2 any = A_arbace_spec_alpha_tuple_impl_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_spec_alpha_tuple_impl_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_226, false); A_arbace_spec_alpha_tuple_impl_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_49)); return A_arbace_spec_alpha__init_part1_A_const_48 }





























































func A_arbace_spec_alpha__init_part1_A_Unit146__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1062, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_50; var tmp2 any = A_arbace_spec_alpha_tagged_ret_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_spec_alpha_tagged_ret_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_227, false); A_arbace_spec_alpha_tagged_ret_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_51)); return A_arbace_spec_alpha__init_part1_A_const_50 }


func A_arbace_spec_alpha__init_part1_A_Unit147__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1065, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_52; var tmp2 any = A_arbace_spec_alpha_or_spec_impl_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_spec_alpha_or_spec_impl_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_228, false); A_arbace_spec_alpha_or_spec_impl_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_53)); return A_arbace_spec_alpha__init_part1_A_const_52 }


































































func A_arbace_spec_alpha__init_part1_A_Unit148__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1132, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_54; var tmp2 any = A_arbace_spec_alpha_and_preds_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_spec_alpha_and_preds_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_229, false); A_arbace_spec_alpha_and_preds_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_55)); return A_arbace_spec_alpha__init_part1_A_const_54 }











func A_arbace_spec_alpha__init_part1_A_Unit149__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1144, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_56; var tmp2 any = A_arbace_spec_alpha_explain_pred_list_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_spec_alpha_explain_pred_list_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_230, false); A_arbace_spec_alpha_explain_pred_list_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_57)); return A_arbace_spec_alpha__init_part1_A_const_56 }










func A_arbace_spec_alpha__init_part1_A_Unit150__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1155, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_58; var tmp2 any = A_arbace_spec_alpha_and_spec_impl_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_spec_alpha_and_spec_impl_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_231, false); A_arbace_spec_alpha_and_spec_impl_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_59)); return A_arbace_spec_alpha__init_part1_A_const_58 }











































func A_arbace_spec_alpha__init_part1_A_Unit151__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1199, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_60; var tmp2 any = A_arbace_spec_alpha_merge_spec_impl_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_spec_alpha_merge_spec_impl_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_232, false); A_arbace_spec_alpha_merge_spec_impl_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_61)); return A_arbace_spec_alpha__init_part1_A_const_60 }



























func A_arbace_spec_alpha__init_part1_A_Unit152__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1227, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_62; var tmp2 any = A_arbace_spec_alpha_coll_prob_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_spec_alpha_coll_prob_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_233, false); A_arbace_spec_alpha_coll_prob_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_63)); return A_arbace_spec_alpha__init_part1_A_const_62 }



















func A_arbace_spec_alpha__init_part1_A_Unit153__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1247, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_64; tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_alpha__init_part1_A_const_65, lang.PersistentVector_EMPTY.Ref(), A_arbace_spec_alpha__init_part1_A_const_66, lang.PersistentHashSet_EMPTY.Ref(), A_arbace_spec_alpha__init_part1_A_const_67, lang.PersistentList_EMPTY.Ref(), A_arbace_spec_alpha__init_part1_A_const_68, lang.PersistentArrayMap_EMPTY.Ref()))); var tmp2 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_64; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_69)); return A_arbace_spec_alpha__init_part1_A_const_64 }

func A_arbace_spec_alpha__init_part1_A_Unit154__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1249, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_70; var tmp2 any = A_arbace_spec_alpha_every_impl_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_spec_alpha_every_impl_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_234, false); A_arbace_spec_alpha_every_impl_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_71)); return A_arbace_spec_alpha__init_part1_A_const_70 }






































































































































func A_arbace_spec_alpha__init_part1_A_Unit155__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1384, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_72; var tmp2 any = A_arbace_spec_alpha_accept_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_spec_alpha_accept_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_235, false); A_arbace_spec_alpha_accept_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_73)); return A_arbace_spec_alpha__init_part1_A_const_72 }

func A_arbace_spec_alpha__init_part1_A_Unit156__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1386, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_74; var tmp2 any = A_arbace_spec_alpha_accept_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_spec_alpha_accept_QMARK__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_236, false); A_arbace_spec_alpha_accept_QMARK__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_75)); return A_arbace_spec_alpha__init_part1_A_const_74 }


func A_arbace_spec_alpha__init_part1_A_Unit157__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1389, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_76; var tmp2 any = A_arbace_spec_alpha_pcat_STAR__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_spec_alpha_pcat_STAR__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_237, false); A_arbace_spec_alpha_pcat_STAR__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_77)); return A_arbace_spec_alpha__init_part1_A_const_76 }









func A_arbace_spec_alpha__init_part1_A_Unit158__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1399, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_78; var tmp2 any = A_arbace_spec_alpha_pcat_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_spec_alpha_pcat_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_238, true); A_arbace_spec_alpha_pcat_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_79)); return A_arbace_spec_alpha__init_part1_A_const_78 }

func A_arbace_spec_alpha__init_part1_A_Unit159__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1401, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_80; var tmp2 any = A_arbace_spec_alpha_cat_impl_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_spec_alpha_cat_impl_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_239, false); A_arbace_spec_alpha_cat_impl_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_81)); return A_arbace_spec_alpha__init_part1_A_const_80 }




func A_arbace_spec_alpha__init_part1_A_Unit160__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1406, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_82; var tmp2 any = A_arbace_spec_alpha_rep_STAR__A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_spec_alpha_rep_STAR__A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_240, false); A_arbace_spec_alpha_rep_STAR__A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_83)); return A_arbace_spec_alpha__init_part1_A_const_82 }






func A_arbace_spec_alpha__init_part1_A_Unit161__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1413, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_84; var tmp2 any = A_arbace_spec_alpha_rep_impl_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_spec_alpha_rep_impl_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_241, false); A_arbace_spec_alpha_rep_impl_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_85)); return A_arbace_spec_alpha__init_part1_A_const_84 }



func A_arbace_spec_alpha__init_part1_A_Unit162__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1417, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_86; var tmp2 any = A_arbace_spec_alpha_rep_PLUS_impl_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_spec_alpha_rep_PLUS_impl_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_242, false); A_arbace_spec_alpha_rep_PLUS_impl_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_87)); return A_arbace_spec_alpha__init_part1_A_const_86 }




func A_arbace_spec_alpha__init_part1_A_Unit163__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1422, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_88; var tmp2 any = A_arbace_spec_alpha_amp_impl_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_spec_alpha_amp_impl_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_243, false); A_arbace_spec_alpha_amp_impl_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_89)); return A_arbace_spec_alpha__init_part1_A_const_88 }




func A_arbace_spec_alpha__init_part1_A_Unit164__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1427, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_90; var tmp2 any = A_arbace_spec_alpha_filter_alt_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_spec_alpha_filter_alt_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_244, false); A_arbace_spec_alpha_filter_alt_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_91)); return A_arbace_spec_alpha__init_part1_A_const_90 }








func A_arbace_spec_alpha__init_part1_A_Unit165__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1436, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_92; var tmp2 any = A_arbace_spec_alpha_alt_STAR__A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_spec_alpha_alt_STAR__A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_245, false); A_arbace_spec_alpha_alt_STAR__A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_93)); return A_arbace_spec_alpha__init_part1_A_const_92 }











func A_arbace_spec_alpha__init_part1_A_Unit166__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1448, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_94; var tmp2 any = A_arbace_spec_alpha_alts_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_spec_alpha_alts_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_246, true); A_arbace_spec_alpha_alts_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_95)); return A_arbace_spec_alpha__init_part1_A_const_94 }
func A_arbace_spec_alpha__init_part1_A_Unit167__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1449, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_96; var tmp2 any = A_arbace_spec_alpha_alt2_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_spec_alpha_alt2_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_247, false); A_arbace_spec_alpha_alt2_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_97)); return A_arbace_spec_alpha__init_part1_A_const_96 }

func A_arbace_spec_alpha__init_part1_A_Unit168__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1451, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_98; var tmp2 any = A_arbace_spec_alpha_alt_impl_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_spec_alpha_alt_impl_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_248, false); A_arbace_spec_alpha_alt_impl_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_99)); return A_arbace_spec_alpha__init_part1_A_const_98 }



func A_arbace_spec_alpha__init_part1_A_Unit169__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1455, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_100; var tmp2 any = A_arbace_spec_alpha_maybe_impl_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_spec_alpha_maybe_impl_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_249, false); A_arbace_spec_alpha_maybe_impl_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_101)); return A_arbace_spec_alpha__init_part1_A_const_100 }



func A_arbace_spec_alpha__init_part1_A_Unit170__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1459, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_102; var tmp2 any = A_arbace_spec_alpha_noret_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_spec_alpha_noret_QMARK__A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_250, false); A_arbace_spec_alpha_noret_QMARK__A_fn_class = fncls__48d; tmp3 = fncls__48d } else { tmp3 = fncls__48 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_103)); return A_arbace_spec_alpha__init_part1_A_const_102 }





func A_arbace_spec_alpha__init_part1_A_Unit171__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1465, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_104; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_105)); return A_arbace_spec_alpha__init_part1_A_const_104 }

func A_arbace_spec_alpha__init_part1_A_Unit172__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1467, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_106; var tmp2 any = A_arbace_spec_alpha_accept_nil_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_spec_alpha_accept_nil_QMARK__A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_251, false); A_arbace_spec_alpha_accept_nil_QMARK__A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_106; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_107)); return A_arbace_spec_alpha__init_part1_A_const_106 }











func A_arbace_spec_alpha__init_part1_A_Unit173__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1479, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_108; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_109)); return A_arbace_spec_alpha__init_part1_A_const_108 }

func A_arbace_spec_alpha__init_part1_A_Unit174__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1481, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_104; var tmp2 any = A_arbace_spec_alpha_preturn_A_New(); var tmp3 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_spec_alpha_preturn_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_252, false); A_arbace_spec_alpha_preturn_A_fn_class = fncls__50d; tmp3 = fncls__50d } else { tmp3 = fncls__50 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_104; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_110)); return A_arbace_spec_alpha__init_part1_A_const_104 }














func A_arbace_spec_alpha__init_part1_A_Unit175__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1496, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_111; var tmp2 any = A_arbace_spec_alpha_op_unform_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_spec_alpha_op_unform_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_253, false); A_arbace_spec_alpha_op_unform_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_112)); return A_arbace_spec_alpha__init_part1_A_const_111 }




















func A_arbace_spec_alpha__init_part1_A_Unit176__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1517, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_108; var tmp2 any = A_arbace_spec_alpha_add_ret_A_New(); var tmp3 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_spec_alpha_add_ret_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_254, false); A_arbace_spec_alpha_add_ret_A_fn_class = fncls__52d; tmp3 = fncls__52d } else { tmp3 = fncls__52 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_108; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_113)); return A_arbace_spec_alpha__init_part1_A_const_108 }












func A_arbace_spec_alpha__init_part1_A_Unit177__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1530, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_114; var tmp2 any = A_arbace_spec_alpha_deriv_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_spec_alpha_deriv_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_255, false); A_arbace_spec_alpha_deriv_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_114; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_115)); return A_arbace_spec_alpha__init_part1_A_const_114 }



















func A_arbace_spec_alpha__init_part1_A_Unit178__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1550, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_116; var tmp2 any = A_arbace_spec_alpha_op_describe_A_New(); var tmp3 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_spec_alpha_op_describe_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_256, false); A_arbace_spec_alpha_op_describe_A_fn_class = fncls__54d; tmp3 = fncls__54d } else { tmp3 = fncls__54 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_116; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_117)); return A_arbace_spec_alpha__init_part1_A_const_116 }















func A_arbace_spec_alpha__init_part1_A_Unit179__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1566, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_118; var tmp2 any = A_arbace_spec_alpha_op_explain_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_spec_alpha_op_explain_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_257, false); A_arbace_spec_alpha_op_explain_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_119)); return A_arbace_spec_alpha__init_part1_A_const_118 }






















































func A_arbace_spec_alpha__init_part1_A_Unit180__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1621, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_120; var tmp2 any = A_arbace_spec_alpha_re_gen_A_New(); var tmp3 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_spec_alpha_re_gen_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_258, false); A_arbace_spec_alpha_re_gen_A_fn_class = fncls__56d; tmp3 = fncls__56d } else { tmp3 = fncls__56 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_121)); return A_arbace_spec_alpha__init_part1_A_const_120 }








































func A_arbace_spec_alpha__init_part1_A_Unit181__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1662, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_122; var tmp2 any = A_arbace_spec_alpha_re_conform_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_spec_alpha_re_conform_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_259, false); A_arbace_spec_alpha_re_conform_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_123)); return A_arbace_spec_alpha__init_part1_A_const_122 }












func A_arbace_spec_alpha__init_part1_A_Unit182__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1675, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_124; var tmp2 any = A_arbace_spec_alpha_re_explain_A_New(); var tmp3 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_spec_alpha_re_explain_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_260, false); A_arbace_spec_alpha_re_explain_A_fn_class = fncls__58d; tmp3 = fncls__58d } else { tmp3 = fncls__58 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_125)); return A_arbace_spec_alpha__init_part1_A_const_124 }

























func A_arbace_spec_alpha__init_part1_A_Unit183__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1701, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_126; var tmp2 any = A_arbace_spec_alpha_regex_spec_impl_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_spec_alpha_regex_spec_impl_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_261, false); A_arbace_spec_alpha_regex_spec_impl_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_127)); return A_arbace_spec_alpha__init_part1_A_const_126 }


























func A_arbace_spec_alpha__init_part1_A_Unit184__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1728, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_128; var tmp2 any = A_arbace_spec_alpha_call_valid_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_spec_alpha_call_valid_QMARK__A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_262, false); A_arbace_spec_alpha_call_valid_QMARK__A_fn_class = fncls__60d; tmp3 = fncls__60d } else { tmp3 = fncls__60 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_129)); return A_arbace_spec_alpha__init_part1_A_const_128 }










func A_arbace_spec_alpha__init_part1_A_Unit185__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1739, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_130; var tmp2 any = A_arbace_spec_alpha_validate_fn_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_spec_alpha_validate_fn_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_263, false); A_arbace_spec_alpha_validate_fn_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_130; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_131)); return A_arbace_spec_alpha__init_part1_A_const_130 }









func A_arbace_spec_alpha__init_part1_A_Unit186__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1749, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_132; var tmp2 any = A_arbace_spec_alpha_fspec_impl_A_New(); var tmp3 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_spec_alpha_fspec_impl_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_264, false); A_arbace_spec_alpha_fspec_impl_A_fn_class = fncls__62d; tmp3 = fncls__62d } else { tmp3 = fncls__62 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_132; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_133)); return A_arbace_spec_alpha__init_part1_A_const_132 }














































func A_arbace_spec_alpha__init_part1_A_Unit187__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1796, 1); var root_63 any = A_arbace_spec_alpha__init_part1_A_const_134.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, A_arbace_spec_alpha_def_impl_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = A_arbace_spec_alpha__init_part1_A_const_135; var arg_67 any = A_arbace_spec_alpha__init_part1_A_const_136; var arg_68 any; var root_69 any = A_arbace_spec_alpha__init_part1_A_const_44.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, A_arbace_spec_alpha_spec_impl_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = A_arbace_spec_alpha__init_part1_A_const_137; var arg_73 any; var tmp1 any = A_arbace_spec_alpha_fn__1740000868_A_New(); var tmp2 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_spec_alpha_fn__1740000868_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_265, false); A_arbace_spec_alpha_fn__1740000868_A_fn_class = fncls__77d; tmp2 = fncls__77d } else { tmp2 = fncls__77 }; arg_73 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_74 any; var arg_75 any = jrt.Boolean_TRUE.Ref(); var arg_76 any; var tmp3 any = A_arbace_spec_alpha_fn__1740000870_A_New(); var tmp4 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_spec_alpha_fn__1740000870_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_266, false); A_arbace_spec_alpha_fn__1740000870_A_fn_class = fncls__78d; tmp4 = fncls__78d } else { tmp4 = fncls__78 }; arg_76 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); if linked_70 == nil { arg_68 = ifn_71.Invoke_O_O_O_O_O__O(arg_72, arg_73, arg_74, arg_75, arg_76) } else { arg_68 = linked_70.(*A_arbace_spec_alpha_spec_impl_A).Invoke_O_O_O_O_O_O__O(root_69, arg_72, arg_73, arg_74, arg_75, arg_76) }; if linked_64 == nil { return ifn_65.Invoke_O_O_O__O(arg_66, arg_67, arg_68) } else { return linked_64.(*A_arbace_spec_alpha_def_impl_A).Invoke_O_O_O_O__O(root_63, arg_66, arg_67, arg_68) } }

func A_arbace_spec_alpha__init_part1_A_Unit188__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1798, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_138; var tmp2 any = A_arbace_spec_alpha_keys_STAR__A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_spec_alpha_keys_STAR__A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_267, true); A_arbace_spec_alpha_keys_STAR__A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_138; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_139)); return A_arbace_spec_alpha__init_part1_A_const_138 }
//line :1798:1
func A_arbace_spec_alpha__init_part1_A_Unit189__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1798, 1); A_arbace_spec_alpha__init_part1_A_const_138.SetMacro__V(); return nil }
//line :1798:1
func A_arbace_spec_alpha__init_part1_A_Unit190__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1798, 1); return A_arbace_spec_alpha__init_part1_A_const_138 }


















func A_arbace_spec_alpha__init_part1_A_Unit191__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1817, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_140; var tmp2 any = A_arbace_spec_alpha_nonconforming_A_New(); var tmp3 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_spec_alpha_nonconforming_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_268, false); A_arbace_spec_alpha_nonconforming_A_fn_class = fncls__80d; tmp3 = fncls__80d } else { tmp3 = fncls__80 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_140; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_141)); return A_arbace_spec_alpha__init_part1_A_const_140 }




















func A_arbace_spec_alpha__init_part1_A_Unit192__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1838, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_142; var tmp2 any = A_arbace_spec_alpha_nilable_impl_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_spec_alpha_nilable_impl_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_269, false); A_arbace_spec_alpha_nilable_impl_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_142; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_143)); return A_arbace_spec_alpha__init_part1_A_const_142 }

























func A_arbace_spec_alpha__init_part1_A_Unit193__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1864, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_144; var tmp2 any = A_arbace_spec_alpha_nilable_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_spec_alpha_nilable_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_270, false); A_arbace_spec_alpha_nilable_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_144; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_145)); return A_arbace_spec_alpha__init_part1_A_const_144 }
//line :1864:1
func A_arbace_spec_alpha__init_part1_A_Unit194__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1864, 1); A_arbace_spec_alpha__init_part1_A_const_144.SetMacro__V(); return nil }
//line :1864:1
func A_arbace_spec_alpha__init_part1_A_Unit195__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1864, 1); return A_arbace_spec_alpha__init_part1_A_const_144 }





func A_arbace_spec_alpha__init_part1_A_Unit196__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1870, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_146; var tmp2 any = A_arbace_spec_alpha_exercise_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_spec_alpha_exercise_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_271, false); A_arbace_spec_alpha_exercise_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_146; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_147)); return A_arbace_spec_alpha__init_part1_A_const_146 }








func A_arbace_spec_alpha__init_part1_A_Unit197__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1879, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_148; var tmp2 any = A_arbace_spec_alpha_exercise_fn_A_New(); var tmp3 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_spec_alpha_exercise_fn_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_272, false); A_arbace_spec_alpha_exercise_fn_A_fn_class = fncls__84d; tmp3 = fncls__84d } else { tmp3 = fncls__84 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_148; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_149)); return A_arbace_spec_alpha__init_part1_A_const_148 }













func A_arbace_spec_alpha__init_part1_A_Unit198__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1893, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_150; var tmp2 any = A_arbace_spec_alpha_inst_in_range_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_spec_alpha_inst_in_range_QMARK__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_273, false); A_arbace_spec_alpha_inst_in_range_QMARK__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_150; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_151)); return A_arbace_spec_alpha__init_part1_A_const_150 }






func A_arbace_spec_alpha__init_part1_A_Unit199__O() any { A_arbace_spec_alpha__init_part1_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1900, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_152; var tmp2 any = A_arbace_spec_alpha_inst_in_A_New(); var tmp3 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_spec_alpha_inst_in_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_274, false); A_arbace_spec_alpha_inst_in_A_fn_class = fncls__86d; tmp3 = fncls__86d } else { tmp3 = fncls__86 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part1_A_const_152; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part1_A_const_153)); return A_arbace_spec_alpha__init_part1_A_const_152 }
//line :1900:1
func A_arbace_spec_alpha__init_part2_A_Unit200__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1900, 1); A_arbace_spec_alpha__init_part2_A_const_0.SetMacro__V(); return nil }
//line :1900:1
func A_arbace_spec_alpha__init_part2_A_Unit201__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1900, 1); return A_arbace_spec_alpha__init_part2_A_const_0 }
//line :1900:1
func A_arbace_spec_alpha__init_part2_A_Init__O() any { A_arbace_spec_alpha__init_part2_A_Init(); return nil }
//line :1900:1
func A_arbace_spec_alpha__init_part2_A_Load__O() any { A_arbace_spec_alpha__init_part2_A_Init(); A_arbace_spec_alpha__init_part2_A_Unit200__O(); A_arbace_spec_alpha__init_part2_A_Unit201__O(); A_arbace_spec_alpha__init_part2_A_Unit202__O(); A_arbace_spec_alpha__init_part2_A_Unit203__O(); A_arbace_spec_alpha__init_part2_A_Unit204__O(); A_arbace_spec_alpha__init_part2_A_Unit205__O(); A_arbace_spec_alpha__init_part2_A_Unit206__O(); A_arbace_spec_alpha__init_part2_A_Unit207__O(); A_arbace_spec_alpha__init_part2_A_Unit208__O(); A_arbace_spec_alpha__init_part2_A_Unit209__O(); A_arbace_spec_alpha__init_part2_A_Unit210__O(); A_arbace_spec_alpha__init_part2_A_Unit211__O(); A_arbace_spec_alpha__init_part2_A_Unit212__O(); A_arbace_spec_alpha__init_part2_A_Unit213__O(); A_arbace_spec_alpha__init_part2_A_Unit214__O(); A_arbace_spec_alpha__init_part2_A_Unit215__O(); return nil }











func A_arbace_spec_alpha__init_part2_A_Unit202__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1912, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_1; var tmp2 any = A_arbace_spec_alpha_int_in_range_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_spec_alpha_int_in_range_QMARK__A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_276, false); A_arbace_spec_alpha_int_in_range_QMARK__A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_1; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part2_A_const_2)); return A_arbace_spec_alpha__init_part2_A_const_1 }





func A_arbace_spec_alpha__init_part2_A_Unit203__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1918, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_3; var tmp2 any = A_arbace_spec_alpha_int_in_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_spec_alpha_int_in_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_277, false); A_arbace_spec_alpha_int_in_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_3; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part2_A_const_4)); return A_arbace_spec_alpha__init_part2_A_const_3 }
//line :1918:1
func A_arbace_spec_alpha__init_part2_A_Unit204__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1918, 1); A_arbace_spec_alpha__init_part2_A_const_3.SetMacro__V(); return nil }
//line :1918:1
func A_arbace_spec_alpha__init_part2_A_Unit205__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1918, 1); return A_arbace_spec_alpha__init_part2_A_const_3 }






func A_arbace_spec_alpha__init_part2_A_Unit206__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1925, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_5; var tmp2 any = A_arbace_spec_alpha_double_in_A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_spec_alpha_double_in_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_278, true); A_arbace_spec_alpha_double_in_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_5; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part2_A_const_6)); return A_arbace_spec_alpha__init_part2_A_const_5 }
//line :1925:1
func A_arbace_spec_alpha__init_part2_A_Unit207__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1925, 1); A_arbace_spec_alpha__init_part2_A_const_5.SetMacro__V(); return nil }
//line :1925:1
func A_arbace_spec_alpha__init_part2_A_Unit208__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1925, 1); return A_arbace_spec_alpha__init_part2_A_const_5 }

















func A_arbace_spec_alpha__init_part2_A_Unit209__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1943, 1); var v__1927001498__auto____1 any; A_arbace_spec_alpha__init_part2_A_const_7.SetDynamic_Z__Var(true); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_7; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part2_A_const_8)); v__1927001498__auto____1 = A_arbace_spec_alpha__init_part2_A_const_7; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { A_arbace_spec_alpha__init_part2_A_const_7.SetDynamic_Z__Var(true); var tmp2 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_7; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part2_A_const_10)); var tmp3 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_7; var tmp4 any; var root_4 any = A_arbace_spec_alpha__init_part2_A_const_9.GetRawRoot__O(); var linked_5 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_4, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_6 lang.IFn








	if linked_5 == nil { ifn_6 = lang.IFn_Cast(root_4) } else { ifn_6 = nil }; var arg_7 any = Lit_279; var arg_8 any = jrt.System_GetProperty_String__String(Lit_280).Ref(); if linked_5 == nil { tmp4 = ifn_6.Invoke_O_O__O(arg_7, arg_8) } else { tmp4 = linked_5.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_4, arg_7, arg_8) }
//line :1943:1
	tmp3.BindRoot_O__V(tmp4); return A_arbace_spec_alpha__init_part2_A_const_7 } }










func A_arbace_spec_alpha__init_part2_A_Unit210__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1954, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_11; var tmp2 any = A_arbace_spec_alpha_check_asserts_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_spec_alpha_check_asserts_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_281, false); A_arbace_spec_alpha_check_asserts_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_11; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part2_A_const_12)); return A_arbace_spec_alpha__init_part2_A_const_11 }




func A_arbace_spec_alpha__init_part2_A_Unit211__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1959, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_13; var tmp2 any = A_arbace_spec_alpha_check_asserts_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_spec_alpha_check_asserts_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_282, false); A_arbace_spec_alpha_check_asserts_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_13; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part2_A_const_14)); return A_arbace_spec_alpha__init_part2_A_const_13 }








func A_arbace_spec_alpha__init_part2_A_Unit212__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1968, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_15; var tmp2 any = A_arbace_spec_alpha_assert_STAR__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_spec_alpha_assert_STAR__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_283, false); A_arbace_spec_alpha_assert_STAR__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_15; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part2_A_const_16)); return A_arbace_spec_alpha__init_part2_A_const_15 }










func A_arbace_spec_alpha__init_part2_A_Unit213__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1979, 1); var tmp1 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_17; var tmp2 any = A_arbace_spec_alpha_assert_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_spec_alpha_assert_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_284, false); A_arbace_spec_alpha_assert_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_alpha__init_part2_A_const_17; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_alpha__init_part2_A_const_18)); return A_arbace_spec_alpha__init_part2_A_const_17 }
//line :1979:1
func A_arbace_spec_alpha__init_part2_A_Unit214__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1979, 1); A_arbace_spec_alpha__init_part2_A_const_17.SetMacro__V(); return nil }
//line :1979:1
func A_arbace_spec_alpha__init_part2_A_Unit215__O() any { A_arbace_spec_alpha__init_part2_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1979, 1); return A_arbace_spec_alpha__init_part2_A_const_17 }







type A_arbace_spec_alpha__init_A struct{ jrt.Object }

func A_arbace_spec_alpha__init_A_New() *A_arbace_spec_alpha__init_A { t := &A_arbace_spec_alpha__init_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_alpha__init_A) Ctor() {}

func (t *A_arbace_spec_alpha__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha__init_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha__init_A_class }

func (t *A_arbace_spec_alpha__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha__init_A); return ok }

func A_arbace_spec_alpha__init_A_Cast(x any) *A_arbace_spec_alpha__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha__init_A_class)) }; return v }



type A_arbace_spec_alpha__init_part0_A struct{ jrt.Object }

var A_arbace_spec_alpha__init_part0_A_const_pool *jrt.RefArray

var A_arbace_spec_alpha__init_part0_A_const_0 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_1 any

var A_arbace_spec_alpha__init_part0_A_const_2 any

var A_arbace_spec_alpha__init_part0_A_const_3 any

var A_arbace_spec_alpha__init_part0_A_const_4 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_5 any

var A_arbace_spec_alpha__init_part0_A_const_6 any

var A_arbace_spec_alpha__init_part0_A_const_7 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_8 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_9 any

var A_arbace_spec_alpha__init_part0_A_const_10 any

var A_arbace_spec_alpha__init_part0_A_const_11 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_12 any

var A_arbace_spec_alpha__init_part0_A_const_13 any

var A_arbace_spec_alpha__init_part0_A_const_14 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_15 any

var A_arbace_spec_alpha__init_part0_A_const_16 any

var A_arbace_spec_alpha__init_part0_A_const_17 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_18 any

var A_arbace_spec_alpha__init_part0_A_const_19 any

var A_arbace_spec_alpha__init_part0_A_const_20 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_21 any

var A_arbace_spec_alpha__init_part0_A_const_22 any

var A_arbace_spec_alpha__init_part0_A_const_23 *jrt.Class

var A_arbace_spec_alpha__init_part0_A_const_24 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_25 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_26 *lang.Keyword

var A_arbace_spec_alpha__init_part0_A_const_27 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_28 any

var A_arbace_spec_alpha__init_part0_A_const_29 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_30 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_31 any

var A_arbace_spec_alpha__init_part0_A_const_32 *lang.Keyword

var A_arbace_spec_alpha__init_part0_A_const_33 any

var A_arbace_spec_alpha__init_part0_A_const_34 *lang.Keyword

var A_arbace_spec_alpha__init_part0_A_const_35 *lang.Keyword

var A_arbace_spec_alpha__init_part0_A_const_36 any

var A_arbace_spec_alpha__init_part0_A_const_37 *lang.Keyword

var A_arbace_spec_alpha__init_part0_A_const_38 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_39 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_40 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_41 any

var A_arbace_spec_alpha__init_part0_A_const_42 any

var A_arbace_spec_alpha__init_part0_A_const_43 *lang.Keyword

var A_arbace_spec_alpha__init_part0_A_const_44 any

var A_arbace_spec_alpha__init_part0_A_const_45 any

var A_arbace_spec_alpha__init_part0_A_const_46 any

var A_arbace_spec_alpha__init_part0_A_const_47 any

var A_arbace_spec_alpha__init_part0_A_const_48 any

var A_arbace_spec_alpha__init_part0_A_const_49 any

var A_arbace_spec_alpha__init_part0_A_const_50 any

var A_arbace_spec_alpha__init_part0_A_const_51 any

var A_arbace_spec_alpha__init_part0_A_const_52 any

var A_arbace_spec_alpha__init_part0_A_const_53 any

var A_arbace_spec_alpha__init_part0_A_const_54 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_55 any

var A_arbace_spec_alpha__init_part0_A_const_56 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_57 any

var A_arbace_spec_alpha__init_part0_A_const_58 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_59 any

var A_arbace_spec_alpha__init_part0_A_const_60 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_61 any

var A_arbace_spec_alpha__init_part0_A_const_62 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_63 any

var A_arbace_spec_alpha__init_part0_A_const_64 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_65 any

var A_arbace_spec_alpha__init_part0_A_const_66 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_67 any

var A_arbace_spec_alpha__init_part0_A_const_68 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_69 any

var A_arbace_spec_alpha__init_part0_A_const_70 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_71 any

var A_arbace_spec_alpha__init_part0_A_const_72 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_73 any

var A_arbace_spec_alpha__init_part0_A_const_74 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_75 any

var A_arbace_spec_alpha__init_part0_A_const_76 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_77 any

var A_arbace_spec_alpha__init_part0_A_const_78 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_79 any

var A_arbace_spec_alpha__init_part0_A_const_80 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_81 any

var A_arbace_spec_alpha__init_part0_A_const_82 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_83 any

var A_arbace_spec_alpha__init_part0_A_const_84 any

var A_arbace_spec_alpha__init_part0_A_const_85 *jrt.Class

var A_arbace_spec_alpha__init_part0_A_const_86 any

var A_arbace_spec_alpha__init_part0_A_const_87 any

var A_arbace_spec_alpha__init_part0_A_const_88 any

var A_arbace_spec_alpha__init_part0_A_const_89 any

var A_arbace_spec_alpha__init_part0_A_const_90 any

var A_arbace_spec_alpha__init_part0_A_const_91 any

var A_arbace_spec_alpha__init_part0_A_const_92 any

var A_arbace_spec_alpha__init_part0_A_const_93 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_94 any

var A_arbace_spec_alpha__init_part0_A_const_95 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_96 *jrt.Class

var A_arbace_spec_alpha__init_part0_A_const_97 *lang.Keyword

var A_arbace_spec_alpha__init_part0_A_const_98 *jrt.Class

var A_arbace_spec_alpha__init_part0_A_const_99 *jrt.Class

var A_arbace_spec_alpha__init_part0_A_const_100 *jrt.Class

var A_arbace_spec_alpha__init_part0_A_const_101 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_102 any

var A_arbace_spec_alpha__init_part0_A_const_103 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_104 any

var A_arbace_spec_alpha__init_part0_A_const_105 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_106 any

var A_arbace_spec_alpha__init_part0_A_const_107 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_108 any

var A_arbace_spec_alpha__init_part0_A_const_109 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_110 any

var A_arbace_spec_alpha__init_part0_A_const_111 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_112 any

var A_arbace_spec_alpha__init_part0_A_const_113 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_114 any

var A_arbace_spec_alpha__init_part0_A_const_115 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_116 any

var A_arbace_spec_alpha__init_part0_A_const_117 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_118 any

var A_arbace_spec_alpha__init_part0_A_const_119 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_120 any

var A_arbace_spec_alpha__init_part0_A_const_121 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_122 any

var A_arbace_spec_alpha__init_part0_A_const_123 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_124 any

var A_arbace_spec_alpha__init_part0_A_const_125 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_126 any

var A_arbace_spec_alpha__init_part0_A_const_127 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_128 any

var A_arbace_spec_alpha__init_part0_A_const_129 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_130 any

var A_arbace_spec_alpha__init_part0_A_const_131 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_132 any

var A_arbace_spec_alpha__init_part0_A_const_133 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_134 any

var A_arbace_spec_alpha__init_part0_A_const_135 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_136 any

var A_arbace_spec_alpha__init_part0_A_const_137 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_138 any

var A_arbace_spec_alpha__init_part0_A_const_139 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_140 any

var A_arbace_spec_alpha__init_part0_A_const_141 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_142 any

var A_arbace_spec_alpha__init_part0_A_const_143 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_144 any

var A_arbace_spec_alpha__init_part0_A_const_145 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_146 any

var A_arbace_spec_alpha__init_part0_A_const_147 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_148 any

var A_arbace_spec_alpha__init_part0_A_const_149 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_150 any

var A_arbace_spec_alpha__init_part0_A_const_151 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_152 any

var A_arbace_spec_alpha__init_part0_A_const_153 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_154 any

var A_arbace_spec_alpha__init_part0_A_const_155 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_156 any

var A_arbace_spec_alpha__init_part0_A_const_157 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_158 any

var A_arbace_spec_alpha__init_part0_A_const_159 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_160 any

var A_arbace_spec_alpha__init_part0_A_const_161 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_162 any

var A_arbace_spec_alpha__init_part0_A_const_163 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_164 any

var A_arbace_spec_alpha__init_part0_A_const_165 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_166 any

var A_arbace_spec_alpha__init_part0_A_const_167 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_168 any

var A_arbace_spec_alpha__init_part0_A_const_169 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_170 any

var A_arbace_spec_alpha__init_part0_A_const_171 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_172 any

var A_arbace_spec_alpha__init_part0_A_const_173 *lang.Var

var A_arbace_spec_alpha__init_part0_A_const_174 any

var A_arbace_spec_alpha__init_part0_A_init jrt.ClassInit

func A_arbace_spec_alpha__init_part0_A_Init() { if !A_arbace_spec_alpha__init_part0_A_init.Done() { A_arbace_spec_alpha__init_part0_A_init.Run(A_arbace_spec_alpha__init_part0_A_clinit) } }

func A_arbace_spec_alpha__init_part0_A_clinit() { A_arbace_spec_alpha__init_part0_A_clinit_p0(); A_arbace_spec_alpha__init_part0_A_clinit_p1(); A_arbace_spec_alpha__init_part0_A_clinit_p2(); A_arbace_spec_alpha__init_part0_A_clinit_p3(); A_arbace_spec_alpha__init_part0_A_clinit_p4(); A_arbace_spec_alpha__init_part0_A_clinit_p5(); A_arbace_spec_alpha__init_part0_A_clinit_p6(); A_arbace_spec_alpha__init_part0_A_clinit_p7(); A_arbace_spec_alpha__init_part0_A_clinit_p8(); A_arbace_spec_alpha__init_part0_A_clinit_p9(); A_arbace_spec_alpha__init_part0_A_clinit_p10(); A_arbace_spec_alpha__init_part0_A_clinit_p11(); A_arbace_spec_alpha__init_part0_A_clinit_p12(); A_arbace_spec_alpha__init_part0_A_clinit_p13() }

func A_arbace_spec_alpha__init_part0_A_clinit_p0() { jrt.StartCheck(); A_arbace_spec_alpha__init_part0_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_143, 252); A_arbace_spec_alpha__init_part0_A_const_0 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[77]); A_arbace_spec_alpha__init_part0_A_const_1 = A_arbace_spec_alpha__init_part0_A_const_pool.A[78]; A_arbace_spec_alpha__init_part0_A_const_2 = A_arbace_spec_alpha__init_part0_A_const_pool.A[79]; A_arbace_spec_alpha__init_part0_A_const_3 = A_arbace_spec_alpha__init_part0_A_const_pool.A[80]; A_arbace_spec_alpha__init_part0_A_const_4 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[81]); A_arbace_spec_alpha__init_part0_A_const_5 = A_arbace_spec_alpha__init_part0_A_const_pool.A[82]; A_arbace_spec_alpha__init_part0_A_const_6 = A_arbace_spec_alpha__init_part0_A_const_pool.A[83]; A_arbace_spec_alpha__init_part0_A_const_7 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[84]); A_arbace_spec_alpha__init_part0_A_const_8 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[85]); A_arbace_spec_alpha__init_part0_A_const_9 = A_arbace_spec_alpha__init_part0_A_const_pool.A[86]; A_arbace_spec_alpha__init_part0_A_const_10 = A_arbace_spec_alpha__init_part0_A_const_pool.A[87]; A_arbace_spec_alpha__init_part0_A_const_11 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[88]); A_arbace_spec_alpha__init_part0_A_const_12 = A_arbace_spec_alpha__init_part0_A_const_pool.A[89] }

func A_arbace_spec_alpha__init_part0_A_clinit_p1() { A_arbace_spec_alpha__init_part0_A_const_13 = A_arbace_spec_alpha__init_part0_A_const_pool.A[90]; A_arbace_spec_alpha__init_part0_A_const_14 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[91]); A_arbace_spec_alpha__init_part0_A_const_15 = A_arbace_spec_alpha__init_part0_A_const_pool.A[92]; A_arbace_spec_alpha__init_part0_A_const_16 = A_arbace_spec_alpha__init_part0_A_const_pool.A[93]; A_arbace_spec_alpha__init_part0_A_const_17 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[94]); A_arbace_spec_alpha__init_part0_A_const_18 = A_arbace_spec_alpha__init_part0_A_const_pool.A[95]; A_arbace_spec_alpha__init_part0_A_const_19 = A_arbace_spec_alpha__init_part0_A_const_pool.A[96]; A_arbace_spec_alpha__init_part0_A_const_20 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[97]); A_arbace_spec_alpha__init_part0_A_const_21 = A_arbace_spec_alpha__init_part0_A_const_pool.A[98]; A_arbace_spec_alpha__init_part0_A_const_22 = A_arbace_spec_alpha__init_part0_A_const_pool.A[99]; A_arbace_spec_alpha__init_part0_A_const_23 = jrt.Class_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[100]); A_arbace_spec_alpha__init_part0_A_const_24 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[101]); A_arbace_spec_alpha__init_part0_A_const_25 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[102]) }

func A_arbace_spec_alpha__init_part0_A_clinit_p2() { A_arbace_spec_alpha__init_part0_A_const_26 = lang.Keyword_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[103]); A_arbace_spec_alpha__init_part0_A_const_27 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[104]); A_arbace_spec_alpha__init_part0_A_const_28 = A_arbace_spec_alpha__init_part0_A_const_pool.A[105]; A_arbace_spec_alpha__init_part0_A_const_29 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[106]); A_arbace_spec_alpha__init_part0_A_const_30 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[107]); A_arbace_spec_alpha__init_part0_A_const_31 = A_arbace_spec_alpha__init_part0_A_const_pool.A[108]; A_arbace_spec_alpha__init_part0_A_const_32 = lang.Keyword_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[109]); A_arbace_spec_alpha__init_part0_A_const_33 = A_arbace_spec_alpha__init_part0_A_const_pool.A[110]; A_arbace_spec_alpha__init_part0_A_const_34 = lang.Keyword_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[111]); A_arbace_spec_alpha__init_part0_A_const_35 = lang.Keyword_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[112]); A_arbace_spec_alpha__init_part0_A_const_36 = A_arbace_spec_alpha__init_part0_A_const_pool.A[113]; A_arbace_spec_alpha__init_part0_A_const_37 = lang.Keyword_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[114]); A_arbace_spec_alpha__init_part0_A_const_38 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[115]) }

func A_arbace_spec_alpha__init_part0_A_clinit_p3() { A_arbace_spec_alpha__init_part0_A_const_39 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[116]); A_arbace_spec_alpha__init_part0_A_const_40 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[117]); A_arbace_spec_alpha__init_part0_A_const_41 = A_arbace_spec_alpha__init_part0_A_const_pool.A[118]; A_arbace_spec_alpha__init_part0_A_const_42 = A_arbace_spec_alpha__init_part0_A_const_pool.A[119]; A_arbace_spec_alpha__init_part0_A_const_43 = lang.Keyword_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[120]); A_arbace_spec_alpha__init_part0_A_const_44 = A_arbace_spec_alpha__init_part0_A_const_pool.A[121]; A_arbace_spec_alpha__init_part0_A_const_45 = A_arbace_spec_alpha__init_part0_A_const_pool.A[122]; A_arbace_spec_alpha__init_part0_A_const_46 = A_arbace_spec_alpha__init_part0_A_const_pool.A[123]; A_arbace_spec_alpha__init_part0_A_const_47 = A_arbace_spec_alpha__init_part0_A_const_pool.A[124]; A_arbace_spec_alpha__init_part0_A_const_48 = A_arbace_spec_alpha__init_part0_A_const_pool.A[125]; A_arbace_spec_alpha__init_part0_A_const_49 = A_arbace_spec_alpha__init_part0_A_const_pool.A[126]; A_arbace_spec_alpha__init_part0_A_const_50 = A_arbace_spec_alpha__init_part0_A_const_pool.A[127]; A_arbace_spec_alpha__init_part0_A_const_51 = A_arbace_spec_alpha__init_part0_A_const_pool.A[128]; A_arbace_spec_alpha__init_part0_A_const_52 = A_arbace_spec_alpha__init_part0_A_const_pool.A[129]; A_arbace_spec_alpha__init_part0_A_const_53 = A_arbace_spec_alpha__init_part0_A_const_pool.A[130] }

func A_arbace_spec_alpha__init_part0_A_clinit_p4() { A_arbace_spec_alpha__init_part0_A_const_54 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[131]); A_arbace_spec_alpha__init_part0_A_const_55 = A_arbace_spec_alpha__init_part0_A_const_pool.A[132]; A_arbace_spec_alpha__init_part0_A_const_56 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[133]); A_arbace_spec_alpha__init_part0_A_const_57 = A_arbace_spec_alpha__init_part0_A_const_pool.A[134]; A_arbace_spec_alpha__init_part0_A_const_58 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[135]); A_arbace_spec_alpha__init_part0_A_const_59 = A_arbace_spec_alpha__init_part0_A_const_pool.A[136]; A_arbace_spec_alpha__init_part0_A_const_60 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[137]); A_arbace_spec_alpha__init_part0_A_const_61 = A_arbace_spec_alpha__init_part0_A_const_pool.A[138]; A_arbace_spec_alpha__init_part0_A_const_62 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[139]); A_arbace_spec_alpha__init_part0_A_const_63 = A_arbace_spec_alpha__init_part0_A_const_pool.A[140]; A_arbace_spec_alpha__init_part0_A_const_64 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[141]); A_arbace_spec_alpha__init_part0_A_const_65 = A_arbace_spec_alpha__init_part0_A_const_pool.A[142]; A_arbace_spec_alpha__init_part0_A_const_66 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[143]) }

func A_arbace_spec_alpha__init_part0_A_clinit_p5() { A_arbace_spec_alpha__init_part0_A_const_67 = A_arbace_spec_alpha__init_part0_A_const_pool.A[144]; A_arbace_spec_alpha__init_part0_A_const_68 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[145]); A_arbace_spec_alpha__init_part0_A_const_69 = A_arbace_spec_alpha__init_part0_A_const_pool.A[146]; A_arbace_spec_alpha__init_part0_A_const_70 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[147]); A_arbace_spec_alpha__init_part0_A_const_71 = A_arbace_spec_alpha__init_part0_A_const_pool.A[148]; A_arbace_spec_alpha__init_part0_A_const_72 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[149]); A_arbace_spec_alpha__init_part0_A_const_73 = A_arbace_spec_alpha__init_part0_A_const_pool.A[150]; A_arbace_spec_alpha__init_part0_A_const_74 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[151]); A_arbace_spec_alpha__init_part0_A_const_75 = A_arbace_spec_alpha__init_part0_A_const_pool.A[152]; A_arbace_spec_alpha__init_part0_A_const_76 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[153]); A_arbace_spec_alpha__init_part0_A_const_77 = A_arbace_spec_alpha__init_part0_A_const_pool.A[154]; A_arbace_spec_alpha__init_part0_A_const_78 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[155]); A_arbace_spec_alpha__init_part0_A_const_79 = A_arbace_spec_alpha__init_part0_A_const_pool.A[156] }

func A_arbace_spec_alpha__init_part0_A_clinit_p6() { A_arbace_spec_alpha__init_part0_A_const_80 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[157]); A_arbace_spec_alpha__init_part0_A_const_81 = A_arbace_spec_alpha__init_part0_A_const_pool.A[158]; A_arbace_spec_alpha__init_part0_A_const_82 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[159]); A_arbace_spec_alpha__init_part0_A_const_83 = A_arbace_spec_alpha__init_part0_A_const_pool.A[160]; A_arbace_spec_alpha__init_part0_A_const_84 = A_arbace_spec_alpha__init_part0_A_const_pool.A[161]; A_arbace_spec_alpha__init_part0_A_const_85 = jrt.Class_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[162]); A_arbace_spec_alpha__init_part0_A_const_86 = A_arbace_spec_alpha__init_part0_A_const_pool.A[163]; A_arbace_spec_alpha__init_part0_A_const_87 = A_arbace_spec_alpha__init_part0_A_const_pool.A[164]; A_arbace_spec_alpha__init_part0_A_const_88 = A_arbace_spec_alpha__init_part0_A_const_pool.A[165]; A_arbace_spec_alpha__init_part0_A_const_89 = A_arbace_spec_alpha__init_part0_A_const_pool.A[166]; A_arbace_spec_alpha__init_part0_A_const_90 = A_arbace_spec_alpha__init_part0_A_const_pool.A[167]; A_arbace_spec_alpha__init_part0_A_const_91 = A_arbace_spec_alpha__init_part0_A_const_pool.A[168]; A_arbace_spec_alpha__init_part0_A_const_92 = A_arbace_spec_alpha__init_part0_A_const_pool.A[169]; A_arbace_spec_alpha__init_part0_A_const_93 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[170]) }

func A_arbace_spec_alpha__init_part0_A_clinit_p7() { A_arbace_spec_alpha__init_part0_A_const_94 = A_arbace_spec_alpha__init_part0_A_const_pool.A[171]; A_arbace_spec_alpha__init_part0_A_const_95 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[172]); A_arbace_spec_alpha__init_part0_A_const_96 = jrt.Class_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[173]); A_arbace_spec_alpha__init_part0_A_const_97 = lang.Keyword_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[174]); A_arbace_spec_alpha__init_part0_A_const_98 = jrt.Class_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[175]); A_arbace_spec_alpha__init_part0_A_const_99 = jrt.Class_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[176]); A_arbace_spec_alpha__init_part0_A_const_100 = jrt.Class_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[177]); A_arbace_spec_alpha__init_part0_A_const_101 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[178]); A_arbace_spec_alpha__init_part0_A_const_102 = A_arbace_spec_alpha__init_part0_A_const_pool.A[179]; A_arbace_spec_alpha__init_part0_A_const_103 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[180]); A_arbace_spec_alpha__init_part0_A_const_104 = A_arbace_spec_alpha__init_part0_A_const_pool.A[181]; A_arbace_spec_alpha__init_part0_A_const_105 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[182]); A_arbace_spec_alpha__init_part0_A_const_106 = A_arbace_spec_alpha__init_part0_A_const_pool.A[183] }

func A_arbace_spec_alpha__init_part0_A_clinit_p8() { A_arbace_spec_alpha__init_part0_A_const_107 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[184]); A_arbace_spec_alpha__init_part0_A_const_108 = A_arbace_spec_alpha__init_part0_A_const_pool.A[185]; A_arbace_spec_alpha__init_part0_A_const_109 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[186]); A_arbace_spec_alpha__init_part0_A_const_110 = A_arbace_spec_alpha__init_part0_A_const_pool.A[187]; A_arbace_spec_alpha__init_part0_A_const_111 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[188]); A_arbace_spec_alpha__init_part0_A_const_112 = A_arbace_spec_alpha__init_part0_A_const_pool.A[189]; A_arbace_spec_alpha__init_part0_A_const_113 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[190]); A_arbace_spec_alpha__init_part0_A_const_114 = A_arbace_spec_alpha__init_part0_A_const_pool.A[191]; A_arbace_spec_alpha__init_part0_A_const_115 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[192]); A_arbace_spec_alpha__init_part0_A_const_116 = A_arbace_spec_alpha__init_part0_A_const_pool.A[193]; A_arbace_spec_alpha__init_part0_A_const_117 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[194]); A_arbace_spec_alpha__init_part0_A_const_118 = A_arbace_spec_alpha__init_part0_A_const_pool.A[195]; A_arbace_spec_alpha__init_part0_A_const_119 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[196]) }

func A_arbace_spec_alpha__init_part0_A_clinit_p9() { A_arbace_spec_alpha__init_part0_A_const_120 = A_arbace_spec_alpha__init_part0_A_const_pool.A[197]; A_arbace_spec_alpha__init_part0_A_const_121 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[198]); A_arbace_spec_alpha__init_part0_A_const_122 = A_arbace_spec_alpha__init_part0_A_const_pool.A[199]; A_arbace_spec_alpha__init_part0_A_const_123 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[200]); A_arbace_spec_alpha__init_part0_A_const_124 = A_arbace_spec_alpha__init_part0_A_const_pool.A[201]; A_arbace_spec_alpha__init_part0_A_const_125 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[202]); A_arbace_spec_alpha__init_part0_A_const_126 = A_arbace_spec_alpha__init_part0_A_const_pool.A[203]; A_arbace_spec_alpha__init_part0_A_const_127 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[204]); A_arbace_spec_alpha__init_part0_A_const_128 = A_arbace_spec_alpha__init_part0_A_const_pool.A[205]; A_arbace_spec_alpha__init_part0_A_const_129 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[206]); A_arbace_spec_alpha__init_part0_A_const_130 = A_arbace_spec_alpha__init_part0_A_const_pool.A[207]; A_arbace_spec_alpha__init_part0_A_const_131 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[208]); A_arbace_spec_alpha__init_part0_A_const_132 = A_arbace_spec_alpha__init_part0_A_const_pool.A[209] }

func A_arbace_spec_alpha__init_part0_A_clinit_p10() { A_arbace_spec_alpha__init_part0_A_const_133 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[210]); A_arbace_spec_alpha__init_part0_A_const_134 = A_arbace_spec_alpha__init_part0_A_const_pool.A[211]; A_arbace_spec_alpha__init_part0_A_const_135 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[212]); A_arbace_spec_alpha__init_part0_A_const_136 = A_arbace_spec_alpha__init_part0_A_const_pool.A[213]; A_arbace_spec_alpha__init_part0_A_const_137 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[214]); A_arbace_spec_alpha__init_part0_A_const_138 = A_arbace_spec_alpha__init_part0_A_const_pool.A[215]; A_arbace_spec_alpha__init_part0_A_const_139 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[216]); A_arbace_spec_alpha__init_part0_A_const_140 = A_arbace_spec_alpha__init_part0_A_const_pool.A[217]; A_arbace_spec_alpha__init_part0_A_const_141 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[218]); A_arbace_spec_alpha__init_part0_A_const_142 = A_arbace_spec_alpha__init_part0_A_const_pool.A[219]; A_arbace_spec_alpha__init_part0_A_const_143 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[220]); A_arbace_spec_alpha__init_part0_A_const_144 = A_arbace_spec_alpha__init_part0_A_const_pool.A[221]; A_arbace_spec_alpha__init_part0_A_const_145 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[222]) }

func A_arbace_spec_alpha__init_part0_A_clinit_p11() { A_arbace_spec_alpha__init_part0_A_const_146 = A_arbace_spec_alpha__init_part0_A_const_pool.A[223]; A_arbace_spec_alpha__init_part0_A_const_147 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[224]); A_arbace_spec_alpha__init_part0_A_const_148 = A_arbace_spec_alpha__init_part0_A_const_pool.A[225]; A_arbace_spec_alpha__init_part0_A_const_149 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[226]); A_arbace_spec_alpha__init_part0_A_const_150 = A_arbace_spec_alpha__init_part0_A_const_pool.A[227]; A_arbace_spec_alpha__init_part0_A_const_151 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[228]); A_arbace_spec_alpha__init_part0_A_const_152 = A_arbace_spec_alpha__init_part0_A_const_pool.A[229]; A_arbace_spec_alpha__init_part0_A_const_153 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[230]); A_arbace_spec_alpha__init_part0_A_const_154 = A_arbace_spec_alpha__init_part0_A_const_pool.A[231]; A_arbace_spec_alpha__init_part0_A_const_155 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[232]); A_arbace_spec_alpha__init_part0_A_const_156 = A_arbace_spec_alpha__init_part0_A_const_pool.A[233]; A_arbace_spec_alpha__init_part0_A_const_157 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[234]); A_arbace_spec_alpha__init_part0_A_const_158 = A_arbace_spec_alpha__init_part0_A_const_pool.A[235] }

func A_arbace_spec_alpha__init_part0_A_clinit_p12() { A_arbace_spec_alpha__init_part0_A_const_159 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[236]); A_arbace_spec_alpha__init_part0_A_const_160 = A_arbace_spec_alpha__init_part0_A_const_pool.A[237]; A_arbace_spec_alpha__init_part0_A_const_161 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[238]); A_arbace_spec_alpha__init_part0_A_const_162 = A_arbace_spec_alpha__init_part0_A_const_pool.A[239]; A_arbace_spec_alpha__init_part0_A_const_163 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[240]); A_arbace_spec_alpha__init_part0_A_const_164 = A_arbace_spec_alpha__init_part0_A_const_pool.A[241]; A_arbace_spec_alpha__init_part0_A_const_165 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[242]); A_arbace_spec_alpha__init_part0_A_const_166 = A_arbace_spec_alpha__init_part0_A_const_pool.A[243]; A_arbace_spec_alpha__init_part0_A_const_167 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[244]); A_arbace_spec_alpha__init_part0_A_const_168 = A_arbace_spec_alpha__init_part0_A_const_pool.A[245]; A_arbace_spec_alpha__init_part0_A_const_169 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[246]); A_arbace_spec_alpha__init_part0_A_const_170 = A_arbace_spec_alpha__init_part0_A_const_pool.A[247]; A_arbace_spec_alpha__init_part0_A_const_171 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[248]) }

func A_arbace_spec_alpha__init_part0_A_clinit_p13() { A_arbace_spec_alpha__init_part0_A_const_172 = A_arbace_spec_alpha__init_part0_A_const_pool.A[249]; A_arbace_spec_alpha__init_part0_A_const_173 = lang.Var_Cast(A_arbace_spec_alpha__init_part0_A_const_pool.A[250]); A_arbace_spec_alpha__init_part0_A_const_174 = A_arbace_spec_alpha__init_part0_A_const_pool.A[251] }

func A_arbace_spec_alpha__init_part0_A_New() *A_arbace_spec_alpha__init_part0_A { A_arbace_spec_alpha__init_part0_A_Init(); t := &A_arbace_spec_alpha__init_part0_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_alpha__init_part0_A) Ctor() {}

func (t *A_arbace_spec_alpha__init_part0_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha__init_part0_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha__init_part0_A_class }

func (t *A_arbace_spec_alpha__init_part0_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha__init_part0_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha__init_part0_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha__init_part0_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha__init_part0_A); return ok }

func A_arbace_spec_alpha__init_part0_A_Cast(x any) *A_arbace_spec_alpha__init_part0_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha__init_part0_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha__init_part0_A_class)) }; return v }



type A_arbace_spec_alpha__init_part1_A struct{ jrt.Object }

var A_arbace_spec_alpha__init_part1_A_const_pool *jrt.RefArray

var A_arbace_spec_alpha__init_part1_A_const_0 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_1 any

var A_arbace_spec_alpha__init_part1_A_const_2 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_3 any

var A_arbace_spec_alpha__init_part1_A_const_4 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_5 any

var A_arbace_spec_alpha__init_part1_A_const_6 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_7 any

var A_arbace_spec_alpha__init_part1_A_const_8 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_9 any

var A_arbace_spec_alpha__init_part1_A_const_10 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_11 any

var A_arbace_spec_alpha__init_part1_A_const_12 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_13 any

var A_arbace_spec_alpha__init_part1_A_const_14 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_15 any

var A_arbace_spec_alpha__init_part1_A_const_16 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_17 any

var A_arbace_spec_alpha__init_part1_A_const_18 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_19 any

var A_arbace_spec_alpha__init_part1_A_const_20 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_21 any

var A_arbace_spec_alpha__init_part1_A_const_22 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_23 any

var A_arbace_spec_alpha__init_part1_A_const_24 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_25 any

var A_arbace_spec_alpha__init_part1_A_const_26 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_27 any

var A_arbace_spec_alpha__init_part1_A_const_28 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_29 any

var A_arbace_spec_alpha__init_part1_A_const_30 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_31 any

var A_arbace_spec_alpha__init_part1_A_const_32 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_33 any

var A_arbace_spec_alpha__init_part1_A_const_34 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_35 any

var A_arbace_spec_alpha__init_part1_A_const_36 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_37 any

var A_arbace_spec_alpha__init_part1_A_const_38 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_39 any

var A_arbace_spec_alpha__init_part1_A_const_40 any

var A_arbace_spec_alpha__init_part1_A_const_41 any

var A_arbace_spec_alpha__init_part1_A_const_42 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_43 any

var A_arbace_spec_alpha__init_part1_A_const_44 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_45 any

var A_arbace_spec_alpha__init_part1_A_const_46 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_47 any

var A_arbace_spec_alpha__init_part1_A_const_48 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_49 any

var A_arbace_spec_alpha__init_part1_A_const_50 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_51 any

var A_arbace_spec_alpha__init_part1_A_const_52 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_53 any

var A_arbace_spec_alpha__init_part1_A_const_54 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_55 any

var A_arbace_spec_alpha__init_part1_A_const_56 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_57 any

var A_arbace_spec_alpha__init_part1_A_const_58 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_59 any

var A_arbace_spec_alpha__init_part1_A_const_60 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_61 any

var A_arbace_spec_alpha__init_part1_A_const_62 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_63 any

var A_arbace_spec_alpha__init_part1_A_const_64 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_65 any

var A_arbace_spec_alpha__init_part1_A_const_66 any

var A_arbace_spec_alpha__init_part1_A_const_67 any

var A_arbace_spec_alpha__init_part1_A_const_68 any

var A_arbace_spec_alpha__init_part1_A_const_69 any

var A_arbace_spec_alpha__init_part1_A_const_70 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_71 any

var A_arbace_spec_alpha__init_part1_A_const_72 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_73 any

var A_arbace_spec_alpha__init_part1_A_const_74 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_75 any

var A_arbace_spec_alpha__init_part1_A_const_76 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_77 any

var A_arbace_spec_alpha__init_part1_A_const_78 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_79 any

var A_arbace_spec_alpha__init_part1_A_const_80 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_81 any

var A_arbace_spec_alpha__init_part1_A_const_82 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_83 any

var A_arbace_spec_alpha__init_part1_A_const_84 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_85 any

var A_arbace_spec_alpha__init_part1_A_const_86 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_87 any

var A_arbace_spec_alpha__init_part1_A_const_88 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_89 any

var A_arbace_spec_alpha__init_part1_A_const_90 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_91 any

var A_arbace_spec_alpha__init_part1_A_const_92 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_93 any

var A_arbace_spec_alpha__init_part1_A_const_94 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_95 any

var A_arbace_spec_alpha__init_part1_A_const_96 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_97 any

var A_arbace_spec_alpha__init_part1_A_const_98 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_99 any

var A_arbace_spec_alpha__init_part1_A_const_100 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_101 any

var A_arbace_spec_alpha__init_part1_A_const_102 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_103 any

var A_arbace_spec_alpha__init_part1_A_const_104 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_105 any

var A_arbace_spec_alpha__init_part1_A_const_106 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_107 any

var A_arbace_spec_alpha__init_part1_A_const_108 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_109 any

var A_arbace_spec_alpha__init_part1_A_const_110 any

var A_arbace_spec_alpha__init_part1_A_const_111 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_112 any

var A_arbace_spec_alpha__init_part1_A_const_113 any

var A_arbace_spec_alpha__init_part1_A_const_114 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_115 any

var A_arbace_spec_alpha__init_part1_A_const_116 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_117 any

var A_arbace_spec_alpha__init_part1_A_const_118 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_119 any

var A_arbace_spec_alpha__init_part1_A_const_120 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_121 any

var A_arbace_spec_alpha__init_part1_A_const_122 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_123 any

var A_arbace_spec_alpha__init_part1_A_const_124 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_125 any

var A_arbace_spec_alpha__init_part1_A_const_126 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_127 any

var A_arbace_spec_alpha__init_part1_A_const_128 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_129 any

var A_arbace_spec_alpha__init_part1_A_const_130 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_131 any

var A_arbace_spec_alpha__init_part1_A_const_132 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_133 any

var A_arbace_spec_alpha__init_part1_A_const_134 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_135 *lang.Keyword

var A_arbace_spec_alpha__init_part1_A_const_136 any

var A_arbace_spec_alpha__init_part1_A_const_137 any

var A_arbace_spec_alpha__init_part1_A_const_138 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_139 any

var A_arbace_spec_alpha__init_part1_A_const_140 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_141 any

var A_arbace_spec_alpha__init_part1_A_const_142 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_143 any

var A_arbace_spec_alpha__init_part1_A_const_144 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_145 any

var A_arbace_spec_alpha__init_part1_A_const_146 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_147 any

var A_arbace_spec_alpha__init_part1_A_const_148 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_149 any

var A_arbace_spec_alpha__init_part1_A_const_150 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_151 any

var A_arbace_spec_alpha__init_part1_A_const_152 *lang.Var

var A_arbace_spec_alpha__init_part1_A_const_153 any

var A_arbace_spec_alpha__init_part1_A_init jrt.ClassInit

func A_arbace_spec_alpha__init_part1_A_Init() { if !A_arbace_spec_alpha__init_part1_A_init.Done() { A_arbace_spec_alpha__init_part1_A_init.Run(A_arbace_spec_alpha__init_part1_A_clinit) } }

func A_arbace_spec_alpha__init_part1_A_clinit() { A_arbace_spec_alpha__init_part1_A_clinit_p0(); A_arbace_spec_alpha__init_part1_A_clinit_p1(); A_arbace_spec_alpha__init_part1_A_clinit_p2(); A_arbace_spec_alpha__init_part1_A_clinit_p3() }

func A_arbace_spec_alpha__init_part1_A_clinit_p0() { jrt.StartCheck(); A_arbace_spec_alpha__init_part1_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_202, 282); A_arbace_spec_alpha__init_part1_A_const_0 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[132]); A_arbace_spec_alpha__init_part1_A_const_1 = A_arbace_spec_alpha__init_part1_A_const_pool.A[133]; A_arbace_spec_alpha__init_part1_A_const_2 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[134]); A_arbace_spec_alpha__init_part1_A_const_3 = A_arbace_spec_alpha__init_part1_A_const_pool.A[135]; A_arbace_spec_alpha__init_part1_A_const_4 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[136]); A_arbace_spec_alpha__init_part1_A_const_5 = A_arbace_spec_alpha__init_part1_A_const_pool.A[137]; A_arbace_spec_alpha__init_part1_A_const_6 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[138]); A_arbace_spec_alpha__init_part1_A_const_7 = A_arbace_spec_alpha__init_part1_A_const_pool.A[139]; A_arbace_spec_alpha__init_part1_A_const_8 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[140]); A_arbace_spec_alpha__init_part1_A_const_9 = A_arbace_spec_alpha__init_part1_A_const_pool.A[141]; A_arbace_spec_alpha__init_part1_A_const_10 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[142]); A_arbace_spec_alpha__init_part1_A_const_11 = A_arbace_spec_alpha__init_part1_A_const_pool.A[143] }

func A_arbace_spec_alpha__init_part1_A_clinit_p1() { A_arbace_spec_alpha__init_part1_A_const_12 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[144]); A_arbace_spec_alpha__init_part1_A_const_13 = A_arbace_spec_alpha__init_part1_A_const_pool.A[145]; A_arbace_spec_alpha__init_part1_A_const_14 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[146]); A_arbace_spec_alpha__init_part1_A_const_15 = A_arbace_spec_alpha__init_part1_A_const_pool.A[147]; A_arbace_spec_alpha__init_part1_A_const_16 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[148]); A_arbace_spec_alpha__init_part1_A_const_17 = A_arbace_spec_alpha__init_part1_A_const_pool.A[149]; A_arbace_spec_alpha__init_part1_A_const_18 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[150]); A_arbace_spec_alpha__init_part1_A_const_19 = A_arbace_spec_alpha__init_part1_A_const_pool.A[151]; A_arbace_spec_alpha__init_part1_A_const_20 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[152]); A_arbace_spec_alpha__init_part1_A_const_21 = A_arbace_spec_alpha__init_part1_A_const_pool.A[153]; A_arbace_spec_alpha__init_part1_A_const_22 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[154]); A_arbace_spec_alpha__init_part1_A_const_23 = A_arbace_spec_alpha__init_part1_A_const_pool.A[155]; A_arbace_spec_alpha__init_part1_A_const_24 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[156]) }

func A_arbace_spec_alpha__init_part1_A_clinit_p2() { A_arbace_spec_alpha__init_part1_A_const_25 = A_arbace_spec_alpha__init_part1_A_const_pool.A[157]; A_arbace_spec_alpha__init_part1_A_const_26 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[158]); A_arbace_spec_alpha__init_part1_A_const_27 = A_arbace_spec_alpha__init_part1_A_const_pool.A[159] }

func A_arbace_spec_alpha__init_part1_A_clinit_p3() { var tmp1 *lang.Var; A_arbace_spec_alpha__init_part0_A_Init(); tmp1 = A_arbace_spec_alpha__init_part0_A_const_131; A_arbace_spec_alpha__init_part1_A_const_28 = tmp1; A_arbace_spec_alpha__init_part1_A_const_29 = A_arbace_spec_alpha__init_part1_A_const_pool.A[160]; A_arbace_spec_alpha__init_part1_A_const_30 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[161]); A_arbace_spec_alpha__init_part1_A_const_31 = A_arbace_spec_alpha__init_part1_A_const_pool.A[162]; A_arbace_spec_alpha__init_part1_A_const_32 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[163]); A_arbace_spec_alpha__init_part1_A_const_33 = A_arbace_spec_alpha__init_part1_A_const_pool.A[164]; A_arbace_spec_alpha__init_part1_A_const_34 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[165]); A_arbace_spec_alpha__init_part1_A_const_35 = A_arbace_spec_alpha__init_part1_A_const_pool.A[166]; A_arbace_spec_alpha__init_part1_A_const_36 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[167]); A_arbace_spec_alpha__init_part1_A_const_37 = A_arbace_spec_alpha__init_part1_A_const_pool.A[168]; A_arbace_spec_alpha__init_part1_A_const_38 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[169]); A_arbace_spec_alpha__init_part1_A_const_39 = A_arbace_spec_alpha__init_part1_A_const_pool.A[170]; A_arbace_spec_alpha__init_part1_A_const_40 = A_arbace_spec_alpha__init_part1_A_const_pool.A[171]; A_arbace_spec_alpha__init_part1_A_const_41 = A_arbace_spec_alpha__init_part1_A_const_pool.A[172]; A_arbace_spec_alpha__init_part1_A_const_42 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[173]); A_arbace_spec_alpha__init_part1_A_const_43 = A_arbace_spec_alpha__init_part1_A_const_pool.A[174]; var tmp2 *lang.Var; A_arbace_spec_alpha__init_part0_A_Init(); tmp2 = A_arbace_spec_alpha__init_part0_A_const_74; A_arbace_spec_alpha__init_part1_A_const_44 = tmp2; A_arbace_spec_alpha__init_part1_A_const_45 = A_arbace_spec_alpha__init_part1_A_const_pool.A[175]; A_arbace_spec_alpha__init_part1_A_const_46 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[176]); A_arbace_spec_alpha__init_part1_A_const_47 = A_arbace_spec_alpha__init_part1_A_const_pool.A[177]; A_arbace_spec_alpha__init_part1_A_const_48 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[178]); A_arbace_spec_alpha__init_part1_A_const_49 = A_arbace_spec_alpha__init_part1_A_const_pool.A[179]; A_arbace_spec_alpha__init_part1_A_const_50 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[180]); A_arbace_spec_alpha__init_part1_A_const_51 = A_arbace_spec_alpha__init_part1_A_const_pool.A[181]; A_arbace_spec_alpha__init_part1_A_const_52 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[182]); A_arbace_spec_alpha__init_part1_A_const_53 = A_arbace_spec_alpha__init_part1_A_const_pool.A[183]; A_arbace_spec_alpha__init_part1_A_const_54 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[184]); A_arbace_spec_alpha__init_part1_A_const_55 = A_arbace_spec_alpha__init_part1_A_const_pool.A[185]; A_arbace_spec_alpha__init_part1_A_const_56 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[186]); A_arbace_spec_alpha__init_part1_A_const_57 = A_arbace_spec_alpha__init_part1_A_const_pool.A[187]; A_arbace_spec_alpha__init_part1_A_const_58 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[188]); A_arbace_spec_alpha__init_part1_A_const_59 = A_arbace_spec_alpha__init_part1_A_const_pool.A[189]; A_arbace_spec_alpha__init_part1_A_const_60 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[190]); A_arbace_spec_alpha__init_part1_A_const_61 = A_arbace_spec_alpha__init_part1_A_const_pool.A[191]; A_arbace_spec_alpha__init_part1_A_const_62 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[192]); A_arbace_spec_alpha__init_part1_A_const_63 = A_arbace_spec_alpha__init_part1_A_const_pool.A[193]; A_arbace_spec_alpha__init_part1_A_const_64 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[194]); A_arbace_spec_alpha__init_part1_A_const_65 = A_arbace_spec_alpha__init_part1_A_const_pool.A[195]; A_arbace_spec_alpha__init_part1_A_const_66 = A_arbace_spec_alpha__init_part1_A_const_pool.A[196]; A_arbace_spec_alpha__init_part1_A_const_67 = A_arbace_spec_alpha__init_part1_A_const_pool.A[197]; A_arbace_spec_alpha__init_part1_A_const_68 = A_arbace_spec_alpha__init_part1_A_const_pool.A[198]; A_arbace_spec_alpha__init_part1_A_const_69 = A_arbace_spec_alpha__init_part1_A_const_pool.A[199]; A_arbace_spec_alpha__init_part1_A_const_70 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[200]); A_arbace_spec_alpha__init_part1_A_const_71 = A_arbace_spec_alpha__init_part1_A_const_pool.A[201]; A_arbace_spec_alpha__init_part1_A_const_72 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[202]); A_arbace_spec_alpha__init_part1_A_const_73 = A_arbace_spec_alpha__init_part1_A_const_pool.A[203]; A_arbace_spec_alpha__init_part1_A_const_74 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[204]); A_arbace_spec_alpha__init_part1_A_const_75 = A_arbace_spec_alpha__init_part1_A_const_pool.A[205]; A_arbace_spec_alpha__init_part1_A_const_76 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[206]); A_arbace_spec_alpha__init_part1_A_const_77 = A_arbace_spec_alpha__init_part1_A_const_pool.A[207]; A_arbace_spec_alpha__init_part1_A_const_78 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[208]); A_arbace_spec_alpha__init_part1_A_const_79 = A_arbace_spec_alpha__init_part1_A_const_pool.A[209]; A_arbace_spec_alpha__init_part1_A_const_80 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[210]); A_arbace_spec_alpha__init_part1_A_const_81 = A_arbace_spec_alpha__init_part1_A_const_pool.A[211]; A_arbace_spec_alpha__init_part1_A_const_82 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[212]); A_arbace_spec_alpha__init_part1_A_const_83 = A_arbace_spec_alpha__init_part1_A_const_pool.A[213]; A_arbace_spec_alpha__init_part1_A_const_84 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[214]); A_arbace_spec_alpha__init_part1_A_const_85 = A_arbace_spec_alpha__init_part1_A_const_pool.A[215]; A_arbace_spec_alpha__init_part1_A_const_86 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[216]); A_arbace_spec_alpha__init_part1_A_const_87 = A_arbace_spec_alpha__init_part1_A_const_pool.A[217]; A_arbace_spec_alpha__init_part1_A_const_88 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[218]); A_arbace_spec_alpha__init_part1_A_const_89 = A_arbace_spec_alpha__init_part1_A_const_pool.A[219]; A_arbace_spec_alpha__init_part1_A_const_90 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[220]); A_arbace_spec_alpha__init_part1_A_const_91 = A_arbace_spec_alpha__init_part1_A_const_pool.A[221]; A_arbace_spec_alpha__init_part1_A_const_92 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[222]); A_arbace_spec_alpha__init_part1_A_const_93 = A_arbace_spec_alpha__init_part1_A_const_pool.A[223]; A_arbace_spec_alpha__init_part1_A_const_94 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[224]); A_arbace_spec_alpha__init_part1_A_const_95 = A_arbace_spec_alpha__init_part1_A_const_pool.A[225]; A_arbace_spec_alpha__init_part1_A_const_96 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[226]); A_arbace_spec_alpha__init_part1_A_const_97 = A_arbace_spec_alpha__init_part1_A_const_pool.A[227]; A_arbace_spec_alpha__init_part1_A_const_98 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[228]); A_arbace_spec_alpha__init_part1_A_const_99 = A_arbace_spec_alpha__init_part1_A_const_pool.A[229]; A_arbace_spec_alpha__init_part1_A_const_100 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[230]); A_arbace_spec_alpha__init_part1_A_const_101 = A_arbace_spec_alpha__init_part1_A_const_pool.A[231]; A_arbace_spec_alpha__init_part1_A_const_102 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[232]); A_arbace_spec_alpha__init_part1_A_const_103 = A_arbace_spec_alpha__init_part1_A_const_pool.A[233]; A_arbace_spec_alpha__init_part1_A_const_104 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[234]); A_arbace_spec_alpha__init_part1_A_const_105 = A_arbace_spec_alpha__init_part1_A_const_pool.A[235]; A_arbace_spec_alpha__init_part1_A_const_106 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[236]); A_arbace_spec_alpha__init_part1_A_const_107 = A_arbace_spec_alpha__init_part1_A_const_pool.A[237]; A_arbace_spec_alpha__init_part1_A_const_108 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[238]); A_arbace_spec_alpha__init_part1_A_const_109 = A_arbace_spec_alpha__init_part1_A_const_pool.A[239]; A_arbace_spec_alpha__init_part1_A_const_110 = A_arbace_spec_alpha__init_part1_A_const_pool.A[240]; A_arbace_spec_alpha__init_part1_A_const_111 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[241]); A_arbace_spec_alpha__init_part1_A_const_112 = A_arbace_spec_alpha__init_part1_A_const_pool.A[242]; A_arbace_spec_alpha__init_part1_A_const_113 = A_arbace_spec_alpha__init_part1_A_const_pool.A[243]; A_arbace_spec_alpha__init_part1_A_const_114 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[244]); A_arbace_spec_alpha__init_part1_A_const_115 = A_arbace_spec_alpha__init_part1_A_const_pool.A[245]; A_arbace_spec_alpha__init_part1_A_const_116 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[246]); A_arbace_spec_alpha__init_part1_A_const_117 = A_arbace_spec_alpha__init_part1_A_const_pool.A[247]; A_arbace_spec_alpha__init_part1_A_const_118 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[248]); A_arbace_spec_alpha__init_part1_A_const_119 = A_arbace_spec_alpha__init_part1_A_const_pool.A[249]; A_arbace_spec_alpha__init_part1_A_const_120 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[250]); A_arbace_spec_alpha__init_part1_A_const_121 = A_arbace_spec_alpha__init_part1_A_const_pool.A[251]; A_arbace_spec_alpha__init_part1_A_const_122 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[252]); A_arbace_spec_alpha__init_part1_A_const_123 = A_arbace_spec_alpha__init_part1_A_const_pool.A[253]; A_arbace_spec_alpha__init_part1_A_const_124 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[254]); A_arbace_spec_alpha__init_part1_A_const_125 = A_arbace_spec_alpha__init_part1_A_const_pool.A[255]; var tmp3 *lang.Var; A_arbace_spec_alpha__init_part0_A_Init(); tmp3 = A_arbace_spec_alpha__init_part0_A_const_76; A_arbace_spec_alpha__init_part1_A_const_126 = tmp3; A_arbace_spec_alpha__init_part1_A_const_127 = A_arbace_spec_alpha__init_part1_A_const_pool.A[256]; A_arbace_spec_alpha__init_part1_A_const_128 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[257]); A_arbace_spec_alpha__init_part1_A_const_129 = A_arbace_spec_alpha__init_part1_A_const_pool.A[258]; A_arbace_spec_alpha__init_part1_A_const_130 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[259]); A_arbace_spec_alpha__init_part1_A_const_131 = A_arbace_spec_alpha__init_part1_A_const_pool.A[260]; A_arbace_spec_alpha__init_part1_A_const_132 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[261]); A_arbace_spec_alpha__init_part1_A_const_133 = A_arbace_spec_alpha__init_part1_A_const_pool.A[262]; var tmp4 *lang.Var; A_arbace_spec_alpha__init_part0_A_Init(); tmp4 = A_arbace_spec_alpha__init_part0_A_const_143; A_arbace_spec_alpha__init_part1_A_const_134 = tmp4; A_arbace_spec_alpha__init_part1_A_const_135 = lang.Keyword_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[263]); A_arbace_spec_alpha__init_part1_A_const_136 = A_arbace_spec_alpha__init_part1_A_const_pool.A[264]; A_arbace_spec_alpha__init_part1_A_const_137 = A_arbace_spec_alpha__init_part1_A_const_pool.A[265]; A_arbace_spec_alpha__init_part1_A_const_138 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[266]); A_arbace_spec_alpha__init_part1_A_const_139 = A_arbace_spec_alpha__init_part1_A_const_pool.A[267]; A_arbace_spec_alpha__init_part1_A_const_140 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[268]); A_arbace_spec_alpha__init_part1_A_const_141 = A_arbace_spec_alpha__init_part1_A_const_pool.A[269]; A_arbace_spec_alpha__init_part1_A_const_142 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[270]); A_arbace_spec_alpha__init_part1_A_const_143 = A_arbace_spec_alpha__init_part1_A_const_pool.A[271]; A_arbace_spec_alpha__init_part1_A_const_144 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[272]); A_arbace_spec_alpha__init_part1_A_const_145 = A_arbace_spec_alpha__init_part1_A_const_pool.A[273]; A_arbace_spec_alpha__init_part1_A_const_146 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[274]); A_arbace_spec_alpha__init_part1_A_const_147 = A_arbace_spec_alpha__init_part1_A_const_pool.A[275]; A_arbace_spec_alpha__init_part1_A_const_148 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[276]); A_arbace_spec_alpha__init_part1_A_const_149 = A_arbace_spec_alpha__init_part1_A_const_pool.A[277]; A_arbace_spec_alpha__init_part1_A_const_150 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[278]); A_arbace_spec_alpha__init_part1_A_const_151 = A_arbace_spec_alpha__init_part1_A_const_pool.A[279]; A_arbace_spec_alpha__init_part1_A_const_152 = lang.Var_Cast(A_arbace_spec_alpha__init_part1_A_const_pool.A[280]); A_arbace_spec_alpha__init_part1_A_const_153 = A_arbace_spec_alpha__init_part1_A_const_pool.A[281] }

func A_arbace_spec_alpha__init_part1_A_New() *A_arbace_spec_alpha__init_part1_A { A_arbace_spec_alpha__init_part1_A_Init(); t := &A_arbace_spec_alpha__init_part1_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_alpha__init_part1_A) Ctor() {}

func (t *A_arbace_spec_alpha__init_part1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha__init_part1_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha__init_part1_A_class }

func (t *A_arbace_spec_alpha__init_part1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha__init_part1_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha__init_part1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha__init_part1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha__init_part1_A); return ok }

func A_arbace_spec_alpha__init_part1_A_Cast(x any) *A_arbace_spec_alpha__init_part1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha__init_part1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha__init_part1_A_class)) }; return v }



type A_arbace_spec_alpha__init_part2_A struct{ jrt.Object }

var A_arbace_spec_alpha__init_part2_A_const_pool *jrt.RefArray

var A_arbace_spec_alpha__init_part2_A_const_0 *lang.Var

var A_arbace_spec_alpha__init_part2_A_const_1 *lang.Var

var A_arbace_spec_alpha__init_part2_A_const_2 any

var A_arbace_spec_alpha__init_part2_A_const_3 *lang.Var

var A_arbace_spec_alpha__init_part2_A_const_4 any

var A_arbace_spec_alpha__init_part2_A_const_5 *lang.Var

var A_arbace_spec_alpha__init_part2_A_const_6 any

var A_arbace_spec_alpha__init_part2_A_const_7 *lang.Var

var A_arbace_spec_alpha__init_part2_A_const_8 any

var A_arbace_spec_alpha__init_part2_A_const_9 *lang.Var

var A_arbace_spec_alpha__init_part2_A_const_10 any

var A_arbace_spec_alpha__init_part2_A_const_11 *lang.Var

var A_arbace_spec_alpha__init_part2_A_const_12 any

var A_arbace_spec_alpha__init_part2_A_const_13 *lang.Var

var A_arbace_spec_alpha__init_part2_A_const_14 any

var A_arbace_spec_alpha__init_part2_A_const_15 *lang.Var

var A_arbace_spec_alpha__init_part2_A_const_16 any

var A_arbace_spec_alpha__init_part2_A_const_17 *lang.Var

var A_arbace_spec_alpha__init_part2_A_const_18 any

var A_arbace_spec_alpha__init_part2_A_init jrt.ClassInit

func A_arbace_spec_alpha__init_part2_A_Init() { if !A_arbace_spec_alpha__init_part2_A_init.Done() { A_arbace_spec_alpha__init_part2_A_init.Run(A_arbace_spec_alpha__init_part2_A_clinit) } }

func A_arbace_spec_alpha__init_part2_A_clinit() { jrt.StartCheck(); A_arbace_spec_alpha__init_part2_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_275, 39); var tmp1 *lang.Var; A_arbace_spec_alpha__init_part1_A_Init(); tmp1 = A_arbace_spec_alpha__init_part1_A_const_152; A_arbace_spec_alpha__init_part2_A_const_0 = tmp1; A_arbace_spec_alpha__init_part2_A_const_1 = lang.Var_Cast(A_arbace_spec_alpha__init_part2_A_const_pool.A[21]); A_arbace_spec_alpha__init_part2_A_const_2 = A_arbace_spec_alpha__init_part2_A_const_pool.A[22]; A_arbace_spec_alpha__init_part2_A_const_3 = lang.Var_Cast(A_arbace_spec_alpha__init_part2_A_const_pool.A[23]); A_arbace_spec_alpha__init_part2_A_const_4 = A_arbace_spec_alpha__init_part2_A_const_pool.A[24]; A_arbace_spec_alpha__init_part2_A_const_5 = lang.Var_Cast(A_arbace_spec_alpha__init_part2_A_const_pool.A[25]); A_arbace_spec_alpha__init_part2_A_const_6 = A_arbace_spec_alpha__init_part2_A_const_pool.A[26]; A_arbace_spec_alpha__init_part2_A_const_7 = lang.Var_Cast(A_arbace_spec_alpha__init_part2_A_const_pool.A[27]); A_arbace_spec_alpha__init_part2_A_const_8 = A_arbace_spec_alpha__init_part2_A_const_pool.A[28]; A_arbace_spec_alpha__init_part2_A_const_9 = lang.Var_Cast(A_arbace_spec_alpha__init_part2_A_const_pool.A[29]); A_arbace_spec_alpha__init_part2_A_const_10 = A_arbace_spec_alpha__init_part2_A_const_pool.A[30]; A_arbace_spec_alpha__init_part2_A_const_11 = lang.Var_Cast(A_arbace_spec_alpha__init_part2_A_const_pool.A[31]); A_arbace_spec_alpha__init_part2_A_const_12 = A_arbace_spec_alpha__init_part2_A_const_pool.A[32]; A_arbace_spec_alpha__init_part2_A_const_13 = lang.Var_Cast(A_arbace_spec_alpha__init_part2_A_const_pool.A[33]); A_arbace_spec_alpha__init_part2_A_const_14 = A_arbace_spec_alpha__init_part2_A_const_pool.A[34]; A_arbace_spec_alpha__init_part2_A_const_15 = lang.Var_Cast(A_arbace_spec_alpha__init_part2_A_const_pool.A[35]); A_arbace_spec_alpha__init_part2_A_const_16 = A_arbace_spec_alpha__init_part2_A_const_pool.A[36]; A_arbace_spec_alpha__init_part2_A_const_17 = lang.Var_Cast(A_arbace_spec_alpha__init_part2_A_const_pool.A[37]); A_arbace_spec_alpha__init_part2_A_const_18 = A_arbace_spec_alpha__init_part2_A_const_pool.A[38] }

func A_arbace_spec_alpha__init_part2_A_New() *A_arbace_spec_alpha__init_part2_A { A_arbace_spec_alpha__init_part2_A_Init(); t := &A_arbace_spec_alpha__init_part2_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_alpha__init_part2_A) Ctor() {}

func (t *A_arbace_spec_alpha__init_part2_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_alpha__init_part2_A) GetClass__Class() *jrt.Class { return A_arbace_spec_alpha__init_part2_A_class }

func (t *A_arbace_spec_alpha__init_part2_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_alpha__init_part2_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_alpha__init_part2_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_alpha__init_part2_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_alpha__init_part2_A); return ok }

func A_arbace_spec_alpha__init_part2_A_Cast(x any) *A_arbace_spec_alpha__init_part2_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_alpha__init_part2_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha__init_part2_A_class)) }; return v }
