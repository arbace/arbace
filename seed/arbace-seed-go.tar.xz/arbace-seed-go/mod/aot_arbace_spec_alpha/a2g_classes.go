//line a2g_classes.ae:1
package aot_arbace_spec_alpha

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_spec_alpha_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_A_New()}; return nil }

var A_arbace_spec_alpha_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_alpha_A_new}

var A_arbace_spec_alpha_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_A"})

func init() { i := A_arbace_spec_alpha_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_A_InstanceOf; i.Init = A_arbace_spec_alpha_A_Init; i.Table = A_arbace_spec_alpha_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_A_class, reflect.TypeFor[A_arbace_spec_alpha_A]()) }

func A_arbace_spec_alpha__AMPERSAND__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha__AMPERSAND__A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha__AMPERSAND__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha__AMPERSAND__A_New()}; return nil }

func A_arbace_spec_alpha__AMPERSAND__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha__AMPERSAND__A_fn_class)}; return nil }

var A_arbace_spec_alpha__AMPERSAND__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha__AMPERSAND__A_invoke, New: A_arbace_spec_alpha__AMPERSAND__A_new, Get: A_arbace_spec_alpha__AMPERSAND__A_get}

var A_arbace_spec_alpha__AMPERSAND__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$_AMPERSAND_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "_AMPERSAND_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha__AMPERSAND__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha__AMPERSAND__A_class.Info(); i.IsInstance = A_arbace_spec_alpha__AMPERSAND__A_InstanceOf; i.Init = A_arbace_spec_alpha__AMPERSAND__A_Init; i.Table = A_arbace_spec_alpha__AMPERSAND__A_members; jrt.RegisterGoType(A_arbace_spec_alpha__AMPERSAND__A_class, reflect.TypeFor[A_arbace_spec_alpha__AMPERSAND__A]()) }

func A_arbace_spec_alpha__PLUS__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha__PLUS__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha__PLUS__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha__PLUS__A_New()}; return nil }

func A_arbace_spec_alpha__PLUS__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha__PLUS__A_fn_class)}; return nil }

var A_arbace_spec_alpha__PLUS__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha__PLUS__A_invoke, New: A_arbace_spec_alpha__PLUS__A_new, Get: A_arbace_spec_alpha__PLUS__A_get}

var A_arbace_spec_alpha__PLUS__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$_PLUS_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "_PLUS_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha__PLUS__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha__PLUS__A_class.Info(); i.IsInstance = A_arbace_spec_alpha__PLUS__A_InstanceOf; i.Init = A_arbace_spec_alpha__PLUS__A_Init; i.Table = A_arbace_spec_alpha__PLUS__A_members; jrt.RegisterGoType(A_arbace_spec_alpha__PLUS__A_class, reflect.TypeFor[A_arbace_spec_alpha__PLUS__A]()) }

func A_arbace_spec_alpha__QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha__QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha__QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha__QMARK__A_New()}; return nil }

func A_arbace_spec_alpha__QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha__QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha__QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha__QMARK__A_invoke, New: A_arbace_spec_alpha__QMARK__A_new, Get: A_arbace_spec_alpha__QMARK__A_get}

var A_arbace_spec_alpha__QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha__QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha__QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha__QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha__QMARK__A_Init; i.Table = A_arbace_spec_alpha__QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha__QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha__QMARK__A]()) }

func A_arbace_spec_alpha__STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha__STAR__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha__STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha__STAR__A_New()}; return nil }

func A_arbace_spec_alpha__STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha__STAR__A_fn_class)}; return nil }

var A_arbace_spec_alpha__STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha__STAR__A_invoke, New: A_arbace_spec_alpha__STAR__A_new, Get: A_arbace_spec_alpha__STAR__A_get}

var A_arbace_spec_alpha__STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "_STAR_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha__STAR__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha__STAR__A_class.Info(); i.IsInstance = A_arbace_spec_alpha__STAR__A_InstanceOf; i.Init = A_arbace_spec_alpha__STAR__A_Init; i.Table = A_arbace_spec_alpha__STAR__A_members; jrt.RegisterGoType(A_arbace_spec_alpha__STAR__A_class, reflect.TypeFor[A_arbace_spec_alpha__STAR__A]()) }

func A_arbace_spec_alpha___GT_sym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha___GT_sym_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha___GT_sym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha___GT_sym_A_New()}; return nil }

func A_arbace_spec_alpha___GT_sym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha___GT_sym_A_fn_class)}; return nil }

var A_arbace_spec_alpha___GT_sym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha___GT_sym_A_invoke, New: A_arbace_spec_alpha___GT_sym_A_new, Get: A_arbace_spec_alpha___GT_sym_A_get}

var A_arbace_spec_alpha___GT_sym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$__GT_sym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "__GT_sym", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha___GT_sym_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha___GT_sym_A_class.Info(); i.IsInstance = A_arbace_spec_alpha___GT_sym_A_InstanceOf; i.Init = A_arbace_spec_alpha___GT_sym_A_Init; i.Table = A_arbace_spec_alpha___GT_sym_A_members; jrt.RegisterGoType(A_arbace_spec_alpha___GT_sym_A_class, reflect.TypeFor[A_arbace_spec_alpha___GT_sym_A]()) }

func A_arbace_spec_alpha_abbrev_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_abbrev_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_abbrev_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_abbrev_A_New()}; return nil }

func A_arbace_spec_alpha_abbrev_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_abbrev_A_fn_class)}; return nil }

var A_arbace_spec_alpha_abbrev_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_abbrev_A_invoke, New: A_arbace_spec_alpha_abbrev_A_new, Get: A_arbace_spec_alpha_abbrev_A_get}

var A_arbace_spec_alpha_abbrev_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$abbrev", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "abbrev", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_abbrev_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_abbrev_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_abbrev_A_InstanceOf; i.Init = A_arbace_spec_alpha_abbrev_A_Init; i.Table = A_arbace_spec_alpha_abbrev_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_abbrev_A_class, reflect.TypeFor[A_arbace_spec_alpha_abbrev_A]()) }

func A_arbace_spec_alpha_abbrev_fn__1740000170_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_abbrev_fn__1740000170_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_abbrev_fn__1740000170_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_abbrev_fn__1740000170_A_New()}; return nil }

func A_arbace_spec_alpha_abbrev_fn__1740000170_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_abbrev_fn__1740000170_A_fn_class)}; return nil }

var A_arbace_spec_alpha_abbrev_fn__1740000170_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_abbrev_fn__1740000170_A_invoke, New: A_arbace_spec_alpha_abbrev_fn__1740000170_A_new, Get: A_arbace_spec_alpha_abbrev_fn__1740000170_A_get}

var A_arbace_spec_alpha_abbrev_fn__1740000170_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$abbrev$fn__1740000170", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_abbrev_A_class, Simple: "fn__1740000170", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_abbrev_fn__1740000170_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_abbrev_fn__1740000170_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_abbrev_fn__1740000170_A_InstanceOf; i.Init = A_arbace_spec_alpha_abbrev_fn__1740000170_A_Init; i.Table = A_arbace_spec_alpha_abbrev_fn__1740000170_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_abbrev_fn__1740000170_A_class, reflect.TypeFor[A_arbace_spec_alpha_abbrev_fn__1740000170_A]()) }

func A_arbace_spec_alpha_accept_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_accept_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_accept_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_accept_A_New()}; return nil }

func A_arbace_spec_alpha_accept_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_accept_A_fn_class)}; return nil }

var A_arbace_spec_alpha_accept_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_accept_A_invoke, New: A_arbace_spec_alpha_accept_A_new, Get: A_arbace_spec_alpha_accept_A_get}

var A_arbace_spec_alpha_accept_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$accept", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "accept", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_accept_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_accept_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_accept_A_InstanceOf; i.Init = A_arbace_spec_alpha_accept_A_Init; i.Table = A_arbace_spec_alpha_accept_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_accept_A_class, reflect.TypeFor[A_arbace_spec_alpha_accept_A]()) }

func A_arbace_spec_alpha_accept_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_accept_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_accept_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_accept_QMARK__A_New()}; return nil }

func A_arbace_spec_alpha_accept_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_accept_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha_accept_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_accept_QMARK__A_invoke, New: A_arbace_spec_alpha_accept_QMARK__A_new, Get: A_arbace_spec_alpha_accept_QMARK__A_get}

var A_arbace_spec_alpha_accept_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$accept_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "accept_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_accept_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_accept_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_accept_QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha_accept_QMARK__A_Init; i.Table = A_arbace_spec_alpha_accept_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_accept_QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha_accept_QMARK__A]()) }

func A_arbace_spec_alpha_accept_nil_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_accept_nil_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_accept_nil_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_accept_nil_QMARK__A_New()}; return nil }

func A_arbace_spec_alpha_accept_nil_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_accept_nil_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha_accept_nil_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_accept_nil_QMARK__A_invoke, New: A_arbace_spec_alpha_accept_nil_QMARK__A_new, Get: A_arbace_spec_alpha_accept_nil_QMARK__A_get}

var A_arbace_spec_alpha_accept_nil_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$accept_nil_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "accept_nil_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_accept_nil_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_accept_nil_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_accept_nil_QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha_accept_nil_QMARK__A_Init; i.Table = A_arbace_spec_alpha_accept_nil_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_accept_nil_QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha_accept_nil_QMARK__A]()) }

func A_arbace_spec_alpha_add_ret_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_add_ret_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_add_ret_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_add_ret_A_New()}; return nil }

func A_arbace_spec_alpha_add_ret_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_add_ret_A_fn_class)}; return nil }

var A_arbace_spec_alpha_add_ret_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_add_ret_A_invoke, New: A_arbace_spec_alpha_add_ret_A_new, Get: A_arbace_spec_alpha_add_ret_A_get}

var A_arbace_spec_alpha_add_ret_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$add_ret", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "add_ret", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_add_ret_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_add_ret_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_add_ret_A_InstanceOf; i.Init = A_arbace_spec_alpha_add_ret_A_Init; i.Table = A_arbace_spec_alpha_add_ret_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_add_ret_A_class, reflect.TypeFor[A_arbace_spec_alpha_add_ret_A]()) }

func A_arbace_spec_alpha_add_ret_prop__1740000773_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_add_ret_prop__1740000773_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_add_ret_prop__1740000773_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_add_ret_prop__1740000773_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_add_ret_prop__1740000773_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_add_ret_prop__1740000773_A_fn_class)}; return nil }

var A_arbace_spec_alpha_add_ret_prop__1740000773_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_add_ret_prop__1740000773_A_invoke, New: A_arbace_spec_alpha_add_ret_prop__1740000773_A_new, Get: A_arbace_spec_alpha_add_ret_prop__1740000773_A_get}

var A_arbace_spec_alpha_add_ret_prop__1740000773_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$add_ret$prop__1740000773", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_add_ret_A_class, Simple: "prop__1740000773", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_add_ret_prop__1740000773_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_add_ret_prop__1740000773_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_add_ret_prop__1740000773_A_InstanceOf; i.Init = A_arbace_spec_alpha_add_ret_prop__1740000773_A_Init; i.Table = A_arbace_spec_alpha_add_ret_prop__1740000773_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_add_ret_prop__1740000773_A_class, reflect.TypeFor[A_arbace_spec_alpha_add_ret_prop__1740000773_A]()) }

func A_arbace_spec_alpha_alt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_alt_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_alt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_alt_A_New()}; return nil }

func A_arbace_spec_alpha_alt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_alt_A_fn_class)}; return nil }

var A_arbace_spec_alpha_alt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_alt_A_invoke, New: A_arbace_spec_alpha_alt_A_new, Get: A_arbace_spec_alpha_alt_A_get}

var A_arbace_spec_alpha_alt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$alt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "alt", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_alt_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_alt_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_alt_A_InstanceOf; i.Init = A_arbace_spec_alpha_alt_A_Init; i.Table = A_arbace_spec_alpha_alt_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_alt_A_class, reflect.TypeFor[A_arbace_spec_alpha_alt_A]()) }

func A_arbace_spec_alpha_alt2_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_alt2_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_alt2_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_alt2_A_New()}; return nil }

func A_arbace_spec_alpha_alt2_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_alt2_A_fn_class)}; return nil }

var A_arbace_spec_alpha_alt2_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_alt2_A_invoke, New: A_arbace_spec_alpha_alt2_A_new, Get: A_arbace_spec_alpha_alt2_A_get}

var A_arbace_spec_alpha_alt2_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$alt2", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "alt2", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_alt2_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_alt2_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_alt2_A_InstanceOf; i.Init = A_arbace_spec_alpha_alt2_A_Init; i.Table = A_arbace_spec_alpha_alt2_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_alt2_A_class, reflect.TypeFor[A_arbace_spec_alpha_alt2_A]()) }

func A_arbace_spec_alpha_alt_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_alt_STAR__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_alt_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_alt_STAR__A_New()}; return nil }

func A_arbace_spec_alpha_alt_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_alt_STAR__A_fn_class)}; return nil }

var A_arbace_spec_alpha_alt_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_alt_STAR__A_invoke, New: A_arbace_spec_alpha_alt_STAR__A_new, Get: A_arbace_spec_alpha_alt_STAR__A_get}

var A_arbace_spec_alpha_alt_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$alt_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "alt_STAR_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_alt_STAR__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_alt_STAR__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_alt_STAR__A_InstanceOf; i.Init = A_arbace_spec_alpha_alt_STAR__A_Init; i.Table = A_arbace_spec_alpha_alt_STAR__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_alt_STAR__A_class, reflect.TypeFor[A_arbace_spec_alpha_alt_STAR__A]()) }

func A_arbace_spec_alpha_alt_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_alt_impl_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_alt_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_alt_impl_A_New()}; return nil }

func A_arbace_spec_alpha_alt_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_alt_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_alt_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_alt_impl_A_invoke, New: A_arbace_spec_alpha_alt_impl_A_new, Get: A_arbace_spec_alpha_alt_impl_A_get}

var A_arbace_spec_alpha_alt_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$alt_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "alt_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_alt_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_alt_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_alt_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_alt_impl_A_Init; i.Table = A_arbace_spec_alpha_alt_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_alt_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_alt_impl_A]()) }

func A_arbace_spec_alpha_alts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_alts_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_alts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_alts_A_New()}; return nil }

func A_arbace_spec_alpha_alts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_alts_A_fn_class)}; return nil }

var A_arbace_spec_alpha_alts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_alts_A_invoke, New: A_arbace_spec_alpha_alts_A_new, Get: A_arbace_spec_alpha_alts_A_get}

var A_arbace_spec_alpha_alts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$alts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "alts", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_alts_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_alts_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_alts_A_InstanceOf; i.Init = A_arbace_spec_alpha_alts_A_Init; i.Table = A_arbace_spec_alpha_alts_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_alts_A_class, reflect.TypeFor[A_arbace_spec_alpha_alts_A]()) }

func A_arbace_spec_alpha_amp_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_amp_impl_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_amp_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_amp_impl_A_New()}; return nil }

func A_arbace_spec_alpha_amp_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_amp_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_amp_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_amp_impl_A_invoke, New: A_arbace_spec_alpha_amp_impl_A_new, Get: A_arbace_spec_alpha_amp_impl_A_get}

var A_arbace_spec_alpha_amp_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$amp_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "amp_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_amp_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_amp_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_amp_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_amp_impl_A_Init; i.Table = A_arbace_spec_alpha_amp_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_amp_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_amp_impl_A]()) }

func A_arbace_spec_alpha_and_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_and_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_and_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_and_A_New()}; return nil }

func A_arbace_spec_alpha_and_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_and_A_fn_class)}; return nil }

var A_arbace_spec_alpha_and_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_and_A_invoke, New: A_arbace_spec_alpha_and_A_new, Get: A_arbace_spec_alpha_and_A_get}

var A_arbace_spec_alpha_and_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$and", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "and", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_and_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_and_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_and_A_InstanceOf; i.Init = A_arbace_spec_alpha_and_A_Init; i.Table = A_arbace_spec_alpha_and_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_and_A_class, reflect.TypeFor[A_arbace_spec_alpha_and_A]()) }

func A_arbace_spec_alpha_and_k_gen_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_and_k_gen_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_and_k_gen_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_and_k_gen_A_New()}; return nil }

func A_arbace_spec_alpha_and_k_gen_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_and_k_gen_A_fn_class)}; return nil }

var A_arbace_spec_alpha_and_k_gen_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_and_k_gen_A_invoke, New: A_arbace_spec_alpha_and_k_gen_A_new, Get: A_arbace_spec_alpha_and_k_gen_A_get}

var A_arbace_spec_alpha_and_k_gen_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$and_k_gen", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "and_k_gen", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_and_k_gen_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_and_k_gen_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_and_k_gen_A_InstanceOf; i.Init = A_arbace_spec_alpha_and_k_gen_A_Init; i.Table = A_arbace_spec_alpha_and_k_gen_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_and_k_gen_A_class, reflect.TypeFor[A_arbace_spec_alpha_and_k_gen_A]()) }

func A_arbace_spec_alpha_and_preds_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_and_preds_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_and_preds_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_and_preds_A_New()}; return nil }

func A_arbace_spec_alpha_and_preds_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_and_preds_A_fn_class)}; return nil }

var A_arbace_spec_alpha_and_preds_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_and_preds_A_invoke, New: A_arbace_spec_alpha_and_preds_A_new, Get: A_arbace_spec_alpha_and_preds_A_get}

var A_arbace_spec_alpha_and_preds_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$and_preds", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "and_preds", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_and_preds_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_and_preds_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_and_preds_A_InstanceOf; i.Init = A_arbace_spec_alpha_and_preds_A_Init; i.Table = A_arbace_spec_alpha_and_preds_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_and_preds_A_class, reflect.TypeFor[A_arbace_spec_alpha_and_preds_A]()) }

func A_arbace_spec_alpha_and_spec_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_and_spec_impl_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_and_spec_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_and_spec_impl_A_New()}; return nil }

func A_arbace_spec_alpha_and_spec_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_and_spec_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_and_spec_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_and_spec_impl_A_invoke, New: A_arbace_spec_alpha_and_spec_impl_A_new, Get: A_arbace_spec_alpha_and_spec_impl_A_get}

var A_arbace_spec_alpha_and_spec_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$and_spec_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "and_spec_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_and_spec_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_and_spec_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_and_spec_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_and_spec_impl_A_Init; i.Table = A_arbace_spec_alpha_and_spec_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_and_spec_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_and_spec_impl_A]()) }

func A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_fn_class)}; return nil }

var A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_invoke, New: A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_new, Get: A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_get}

var A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$and_spec_impl$fn__1740000569", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_and_spec_impl_A_class, Simple: "fn__1740000569", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_InstanceOf; i.Init = A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_Init; i.Table = A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A_class, reflect.TypeFor[A_arbace_spec_alpha_and_spec_impl_fn__1740000569_A]()) }

func A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_fn_class)}; return nil }

var A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_invoke, New: A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_new, Get: A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_get}

var A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$and_spec_impl$fn__1740000572", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_and_spec_impl_A_class, Simple: "fn__1740000572", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_InstanceOf; i.Init = A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_Init; i.Table = A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A_class, reflect.TypeFor[A_arbace_spec_alpha_and_spec_impl_fn__1740000572_A]()) }

func A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_fn_class)}; return nil }

var A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_invoke, New: A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_new, Get: A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_get}

var A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$and_spec_impl$fn__1740000574", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_and_spec_impl_A_class, Simple: "fn__1740000574", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_InstanceOf; i.Init = A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_Init; i.Table = A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A_class, reflect.TypeFor[A_arbace_spec_alpha_and_spec_impl_fn__1740000574_A]()) }

func A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_fn_class)}; return nil }

var A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_invoke, New: A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_new, Get: A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_get}

var A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$and_spec_impl$fn__1740000576", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_and_spec_impl_A_class, Simple: "fn__1740000576", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_InstanceOf; i.Init = A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_Init; i.Table = A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A_class, reflect.TypeFor[A_arbace_spec_alpha_and_spec_impl_fn__1740000576_A]()) }

func A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A).Conform_STAR__O__O(args[0]); case 1: return this.(*A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A).Describe_STAR___O(); case 2: return this.(*A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A).Explain_STAR__O_O_O_O__O(args[0], args[1], args[2], args[3]); case 3: return this.(*A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A).Gen_STAR__O_O_O__O(args[0], args[1], args[2]); case 4: return this.(*A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A).Meta__IPersistentMap(); case 5: return this.(*A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A).Specize_STAR___O(); case 6: return this.(*A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A).Specize_STAR__O__O(args[0]); case 7: return this.(*A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A).Unform_STAR__O__O(args[0]); case 8: return this.(*A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 9: return this.(*A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A).With_gen_STAR__O__O(args[0])}; return nil }

func A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_New_IPersistentMap_O_O_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2], args[3], args[4])}; return nil }

var A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 conform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 describe_STAR_ ()Ljava.lang.Object;\nM1 explain_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 gen_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 specize_STAR_ ()Ljava.lang.Object;\nM1 specize_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 unform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 with_gen_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_invoke, New: A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_new}

var A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$and_spec_impl$reify__1740000578", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{A_arbace_spec_alpha_Specize_A_class, A_arbace_spec_alpha_Spec_A_class, lang.IObj_class}, Declaring: A_arbace_spec_alpha_and_spec_impl_A_class, Simple: "reify__1740000578", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_InstanceOf; i.Table = A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_class, reflect.TypeFor[A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A]()) }

func A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_New()}; return nil }

func A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_fn_class)}; return nil }

var A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_invoke, New: A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_new, Get: A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_get}

var A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$and_spec_impl$reify__1740000578$fn__1740000579", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_and_spec_impl_reify__1740000578_A_class, Simple: "fn__1740000579", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_InstanceOf; i.Init = A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_Init; i.Table = A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A_class, reflect.TypeFor[A_arbace_spec_alpha_and_spec_impl_reify__1740000578_fn__1740000579_A]()) }

func A_arbace_spec_alpha_assert_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_assert_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_assert_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_assert_A_New()}; return nil }

func A_arbace_spec_alpha_assert_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_assert_A_fn_class)}; return nil }

var A_arbace_spec_alpha_assert_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_assert_A_invoke, New: A_arbace_spec_alpha_assert_A_new, Get: A_arbace_spec_alpha_assert_A_get}

var A_arbace_spec_alpha_assert_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$assert", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "assert", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_assert_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_assert_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_assert_A_InstanceOf; i.Init = A_arbace_spec_alpha_assert_A_Init; i.Table = A_arbace_spec_alpha_assert_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_assert_A_class, reflect.TypeFor[A_arbace_spec_alpha_assert_A]()) }

func A_arbace_spec_alpha_assert_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_assert_STAR__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_assert_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_assert_STAR__A_New()}; return nil }

func A_arbace_spec_alpha_assert_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_assert_STAR__A_fn_class)}; return nil }

var A_arbace_spec_alpha_assert_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_assert_STAR__A_invoke, New: A_arbace_spec_alpha_assert_STAR__A_new, Get: A_arbace_spec_alpha_assert_STAR__A_get}

var A_arbace_spec_alpha_assert_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$assert_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "assert_STAR_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_assert_STAR__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_assert_STAR__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_assert_STAR__A_InstanceOf; i.Init = A_arbace_spec_alpha_assert_STAR__A_Init; i.Table = A_arbace_spec_alpha_assert_STAR__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_assert_STAR__A_class, reflect.TypeFor[A_arbace_spec_alpha_assert_STAR__A]()) }

func A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_assert_STAR__fn__1740000960_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_fn_class)}; return nil }

var A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_invoke, New: A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_new, Get: A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_get}

var A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$assert_STAR_$fn__1740000960", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_assert_STAR__A_class, Simple: "fn__1740000960", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_assert_STAR__fn__1740000960_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_InstanceOf; i.Init = A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_Init; i.Table = A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_assert_STAR__fn__1740000960_A_class, reflect.TypeFor[A_arbace_spec_alpha_assert_STAR__fn__1740000960_A]()) }

func A_arbace_spec_alpha_call_valid_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_call_valid_QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_call_valid_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_call_valid_QMARK__A_New()}; return nil }

func A_arbace_spec_alpha_call_valid_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_call_valid_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha_call_valid_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_call_valid_QMARK__A_invoke, New: A_arbace_spec_alpha_call_valid_QMARK__A_new, Get: A_arbace_spec_alpha_call_valid_QMARK__A_get}

var A_arbace_spec_alpha_call_valid_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$call_valid_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "call_valid_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_call_valid_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_call_valid_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_call_valid_QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha_call_valid_QMARK__A_Init; i.Table = A_arbace_spec_alpha_call_valid_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_call_valid_QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha_call_valid_QMARK__A]()) }

func A_arbace_spec_alpha_cat_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_cat_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_cat_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_cat_A_New()}; return nil }

func A_arbace_spec_alpha_cat_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_cat_A_fn_class)}; return nil }

var A_arbace_spec_alpha_cat_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_cat_A_invoke, New: A_arbace_spec_alpha_cat_A_new, Get: A_arbace_spec_alpha_cat_A_get}

var A_arbace_spec_alpha_cat_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$cat", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "cat", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_cat_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_cat_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_cat_A_InstanceOf; i.Init = A_arbace_spec_alpha_cat_A_Init; i.Table = A_arbace_spec_alpha_cat_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_cat_A_class, reflect.TypeFor[A_arbace_spec_alpha_cat_A]()) }

func A_arbace_spec_alpha_cat_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_cat_impl_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_cat_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_cat_impl_A_New()}; return nil }

func A_arbace_spec_alpha_cat_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_cat_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_cat_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_cat_impl_A_invoke, New: A_arbace_spec_alpha_cat_impl_A_new, Get: A_arbace_spec_alpha_cat_impl_A_get}

var A_arbace_spec_alpha_cat_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$cat_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "cat_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_cat_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_cat_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_cat_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_cat_impl_A_Init; i.Table = A_arbace_spec_alpha_cat_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_cat_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_cat_impl_A]()) }

func A_arbace_spec_alpha_check_asserts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_check_asserts_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_check_asserts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_check_asserts_A_New()}; return nil }

func A_arbace_spec_alpha_check_asserts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_check_asserts_A_fn_class)}; return nil }

var A_arbace_spec_alpha_check_asserts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_check_asserts_A_invoke, New: A_arbace_spec_alpha_check_asserts_A_new, Get: A_arbace_spec_alpha_check_asserts_A_get}

var A_arbace_spec_alpha_check_asserts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$check_asserts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "check_asserts", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_check_asserts_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_check_asserts_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_check_asserts_A_InstanceOf; i.Init = A_arbace_spec_alpha_check_asserts_A_Init; i.Table = A_arbace_spec_alpha_check_asserts_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_check_asserts_A_class, reflect.TypeFor[A_arbace_spec_alpha_check_asserts_A]()) }

func A_arbace_spec_alpha_check_asserts_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_check_asserts_QMARK__A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_check_asserts_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_check_asserts_QMARK__A_New()}; return nil }

func A_arbace_spec_alpha_check_asserts_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_check_asserts_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha_check_asserts_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_check_asserts_QMARK__A_invoke, New: A_arbace_spec_alpha_check_asserts_QMARK__A_new, Get: A_arbace_spec_alpha_check_asserts_QMARK__A_get}

var A_arbace_spec_alpha_check_asserts_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$check_asserts_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "check_asserts_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_check_asserts_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_check_asserts_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_check_asserts_QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha_check_asserts_QMARK__A_Init; i.Table = A_arbace_spec_alpha_check_asserts_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_check_asserts_QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha_check_asserts_QMARK__A]()) }

func A_arbace_spec_alpha_coll_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_coll_of_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_coll_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_coll_of_A_New()}; return nil }

func A_arbace_spec_alpha_coll_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_coll_of_A_fn_class)}; return nil }

var A_arbace_spec_alpha_coll_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_coll_of_A_invoke, New: A_arbace_spec_alpha_coll_of_A_new, Get: A_arbace_spec_alpha_coll_of_A_get}

var A_arbace_spec_alpha_coll_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$coll_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "coll_of", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_coll_of_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_coll_of_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_coll_of_A_InstanceOf; i.Init = A_arbace_spec_alpha_coll_of_A_Init; i.Table = A_arbace_spec_alpha_coll_of_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_coll_of_A_class, reflect.TypeFor[A_arbace_spec_alpha_coll_of_A]()) }

func A_arbace_spec_alpha_coll_prob_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_coll_prob_A).Invoke_O_O_O_O_O_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10])}; return nil }

func A_arbace_spec_alpha_coll_prob_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_coll_prob_A_New()}; return nil }

func A_arbace_spec_alpha_coll_prob_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_coll_prob_A_fn_class)}; return nil }

var A_arbace_spec_alpha_coll_prob_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_coll_prob_A_invoke, New: A_arbace_spec_alpha_coll_prob_A_new, Get: A_arbace_spec_alpha_coll_prob_A_get}

var A_arbace_spec_alpha_coll_prob_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$coll_prob", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF10_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "coll_prob", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_coll_prob_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_coll_prob_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_coll_prob_A_InstanceOf; i.Init = A_arbace_spec_alpha_coll_prob_A_Init; i.Table = A_arbace_spec_alpha_coll_prob_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_coll_prob_A_class, reflect.TypeFor[A_arbace_spec_alpha_coll_prob_A]()) }

func A_arbace_spec_alpha_conform_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_conform_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_conform_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_conform_A_New()}; return nil }

func A_arbace_spec_alpha_conform_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_conform_A_fn_class)}; return nil }

var A_arbace_spec_alpha_conform_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_conform_A_invoke, New: A_arbace_spec_alpha_conform_A_new, Get: A_arbace_spec_alpha_conform_A_get}

var A_arbace_spec_alpha_conform_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$conform", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "conform", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_conform_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_conform_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_conform_A_InstanceOf; i.Init = A_arbace_spec_alpha_conform_A_Init; i.Table = A_arbace_spec_alpha_conform_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_conform_A_class, reflect.TypeFor[A_arbace_spec_alpha_conform_A]()) }

func A_arbace_spec_alpha_conformer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_conformer_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3]); case 1: return this.(*A_arbace_spec_alpha_conformer_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_conformer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_conformer_A_New()}; return nil }

func A_arbace_spec_alpha_conformer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_conformer_A_fn_class)}; return nil }

var A_arbace_spec_alpha_conformer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_conformer_A_invoke, New: A_arbace_spec_alpha_conformer_A_new, Get: A_arbace_spec_alpha_conformer_A_get}

var A_arbace_spec_alpha_conformer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$conformer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "conformer", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_conformer_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_conformer_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_conformer_A_InstanceOf; i.Init = A_arbace_spec_alpha_conformer_A_Init; i.Table = A_arbace_spec_alpha_conformer_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_conformer_A_class, reflect.TypeFor[A_arbace_spec_alpha_conformer_A]()) }

func A_arbace_spec_alpha_deep_resolve_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_deep_resolve_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_deep_resolve_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_deep_resolve_A_New()}; return nil }

func A_arbace_spec_alpha_deep_resolve_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_deep_resolve_A_fn_class)}; return nil }

var A_arbace_spec_alpha_deep_resolve_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_deep_resolve_A_invoke, New: A_arbace_spec_alpha_deep_resolve_A_new, Get: A_arbace_spec_alpha_deep_resolve_A_get}

var A_arbace_spec_alpha_deep_resolve_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$deep_resolve", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "deep_resolve", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_deep_resolve_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_deep_resolve_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_deep_resolve_A_InstanceOf; i.Init = A_arbace_spec_alpha_deep_resolve_A_Init; i.Table = A_arbace_spec_alpha_deep_resolve_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_deep_resolve_A_class, reflect.TypeFor[A_arbace_spec_alpha_deep_resolve_A]()) }

func A_arbace_spec_alpha_def_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_def_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_def_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_def_A_New()}; return nil }

func A_arbace_spec_alpha_def_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_def_A_fn_class)}; return nil }

var A_arbace_spec_alpha_def_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_def_A_invoke, New: A_arbace_spec_alpha_def_A_new, Get: A_arbace_spec_alpha_def_A_get}

var A_arbace_spec_alpha_def_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$def", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "def", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_def_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_def_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_def_A_InstanceOf; i.Init = A_arbace_spec_alpha_def_A_Init; i.Table = A_arbace_spec_alpha_def_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_def_A_class, reflect.TypeFor[A_arbace_spec_alpha_def_A]()) }

func A_arbace_spec_alpha_def_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_def_impl_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_def_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_def_impl_A_New()}; return nil }

func A_arbace_spec_alpha_def_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_def_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_def_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_def_impl_A_invoke, New: A_arbace_spec_alpha_def_impl_A_new, Get: A_arbace_spec_alpha_def_impl_A_get}

var A_arbace_spec_alpha_def_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$def_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "def_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_def_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_def_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_def_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_def_impl_A_Init; i.Table = A_arbace_spec_alpha_def_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_def_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_def_impl_A]()) }

func A_arbace_spec_alpha_deriv_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_deriv_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_deriv_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_deriv_A_New()}; return nil }

func A_arbace_spec_alpha_deriv_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_deriv_A_fn_class)}; return nil }

var A_arbace_spec_alpha_deriv_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_deriv_A_invoke, New: A_arbace_spec_alpha_deriv_A_new, Get: A_arbace_spec_alpha_deriv_A_get}

var A_arbace_spec_alpha_deriv_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$deriv", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "deriv", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_deriv_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_deriv_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_deriv_A_InstanceOf; i.Init = A_arbace_spec_alpha_deriv_A_Init; i.Table = A_arbace_spec_alpha_deriv_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_deriv_A_class, reflect.TypeFor[A_arbace_spec_alpha_deriv_A]()) }

func A_arbace_spec_alpha_deriv_fn__1740000787_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_deriv_fn__1740000787_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_deriv_fn__1740000787_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_deriv_fn__1740000787_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_deriv_fn__1740000787_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_deriv_fn__1740000787_A_fn_class)}; return nil }

var A_arbace_spec_alpha_deriv_fn__1740000787_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_deriv_fn__1740000787_A_invoke, New: A_arbace_spec_alpha_deriv_fn__1740000787_A_new, Get: A_arbace_spec_alpha_deriv_fn__1740000787_A_get}

var A_arbace_spec_alpha_deriv_fn__1740000787_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$deriv$fn__1740000787", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_deriv_A_class, Simple: "fn__1740000787", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_deriv_fn__1740000787_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_deriv_fn__1740000787_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_deriv_fn__1740000787_A_InstanceOf; i.Init = A_arbace_spec_alpha_deriv_fn__1740000787_A_Init; i.Table = A_arbace_spec_alpha_deriv_fn__1740000787_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_deriv_fn__1740000787_A_class, reflect.TypeFor[A_arbace_spec_alpha_deriv_fn__1740000787_A]()) }

func A_arbace_spec_alpha_describe_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_describe_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_describe_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_describe_A_New()}; return nil }

func A_arbace_spec_alpha_describe_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_describe_A_fn_class)}; return nil }

var A_arbace_spec_alpha_describe_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_describe_A_invoke, New: A_arbace_spec_alpha_describe_A_new, Get: A_arbace_spec_alpha_describe_A_get}

var A_arbace_spec_alpha_describe_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$describe", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "describe", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_describe_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_describe_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_describe_A_InstanceOf; i.Init = A_arbace_spec_alpha_describe_A_Init; i.Table = A_arbace_spec_alpha_describe_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_describe_A_class, reflect.TypeFor[A_arbace_spec_alpha_describe_A]()) }

func A_arbace_spec_alpha_double_in_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_double_in_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_double_in_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_double_in_A_New()}; return nil }

func A_arbace_spec_alpha_double_in_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_double_in_A_fn_class)}; return nil }

var A_arbace_spec_alpha_double_in_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_double_in_A_invoke, New: A_arbace_spec_alpha_double_in_A_new, Get: A_arbace_spec_alpha_double_in_A_get}

var A_arbace_spec_alpha_double_in_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$double_in", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "double_in", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_double_in_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_double_in_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_double_in_A_InstanceOf; i.Init = A_arbace_spec_alpha_double_in_A_Init; i.Table = A_arbace_spec_alpha_double_in_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_double_in_A_class, reflect.TypeFor[A_arbace_spec_alpha_double_in_A]()) }

func A_arbace_spec_alpha_dt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_dt_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3]); case 1: return this.(*A_arbace_spec_alpha_dt_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_dt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_dt_A_New()}; return nil }

func A_arbace_spec_alpha_dt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_dt_A_fn_class)}; return nil }

var A_arbace_spec_alpha_dt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_dt_A_invoke, New: A_arbace_spec_alpha_dt_A_new, Get: A_arbace_spec_alpha_dt_A_get}

var A_arbace_spec_alpha_dt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$dt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "dt", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_dt_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_dt_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_dt_A_InstanceOf; i.Init = A_arbace_spec_alpha_dt_A_Init; i.Table = A_arbace_spec_alpha_dt_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_dt_A_class, reflect.TypeFor[A_arbace_spec_alpha_dt_A]()) }

func A_arbace_spec_alpha_eval1740000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000004_A_New()}; return nil }

var A_arbace_spec_alpha_eval1740000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_alpha_eval1740000004_A_new}

var A_arbace_spec_alpha_eval1740000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_alpha_A_class, Simple: "eval1740000004", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000004_A"})

func init() { i := A_arbace_spec_alpha_eval1740000004_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000004_A_InstanceOf; i.Table = A_arbace_spec_alpha_eval1740000004_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000004_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000004_A]()) }

func A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_invoke, New: A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_new, Get: A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_get}

var A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000004$loading__1927001464__auto____1740000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_eval1740000004_A_class, Simple: "loading__1927001464__auto____1740000005", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_Init; i.Table = A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000004_loading__1927001464__auto____1740000005_A]()) }

func A_arbace_spec_alpha_eval1740000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000008_A_New()}; return nil }

var A_arbace_spec_alpha_eval1740000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_alpha_eval1740000008_A_new}

var A_arbace_spec_alpha_eval1740000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_alpha_A_class, Simple: "eval1740000008", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000008_A"})

func init() { i := A_arbace_spec_alpha_eval1740000008_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000008_A_InstanceOf; i.Table = A_arbace_spec_alpha_eval1740000008_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000008_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000008_A]()) }

func A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000008_fn__1740000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_invoke, New: A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_new, Get: A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_get}

var A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000008$fn__1740000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_eval1740000008_A_class, Simple: "fn__1740000009", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000008_fn__1740000009_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_Init; i.Table = A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000008_fn__1740000009_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000008_fn__1740000009_A]()) }

func A_arbace_spec_alpha_eval1740000034_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_A_New()}; return nil }

var A_arbace_spec_alpha_eval1740000034_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_alpha_eval1740000034_A_new}

var A_arbace_spec_alpha_eval1740000034_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_alpha_A_class, Simple: "eval1740000034", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_A"})

func init() { i := A_arbace_spec_alpha_eval1740000034_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_A_InstanceOf; i.Table = A_arbace_spec_alpha_eval1740000034_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000035_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000035", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000034_A_class, Simple: "fn__1740000035", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000035_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000035_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000035$G__1740000020__1740000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_class, Simple: "G__1740000020__1740000048", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000020__1740000048_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000035$G__1740000021__1740000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_spec_alpha_eval1740000034_fn__1740000035_A_class, Simple: "G__1740000021__1740000041", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000035_G__1740000021__1740000041_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000051_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000051", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000034_A_class, Simple: "fn__1740000051", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000051_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000051_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000051$G__1740000024__1740000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_class, Simple: "G__1740000024__1740000058", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000024__1740000058_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000051$G__1740000025__1740000054", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_eval1740000034_fn__1740000051_A_class, Simple: "G__1740000025__1740000054", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000051_G__1740000025__1740000054_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000061_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000061", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000034_A_class, Simple: "fn__1740000061", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000061_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000061_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000061$G__1740000022__1740000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_class, Simple: "G__1740000022__1740000072", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000022__1740000072_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000061$G__1740000023__1740000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_eval1740000034_fn__1740000061_A_class, Simple: "G__1740000023__1740000066", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000061_G__1740000023__1740000066_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000075_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000075", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000034_A_class, Simple: "fn__1740000075", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000075_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000075_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000075$G__1740000016__1740000082", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_class, Simple: "G__1740000016__1740000082", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000016__1740000082_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000075$G__1740000017__1740000078", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_eval1740000034_fn__1740000075_A_class, Simple: "G__1740000017__1740000078", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000075_G__1740000017__1740000078_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000085_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000034_A_class, Simple: "fn__1740000085", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000085_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000085_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000085$G__1740000026__1740000090", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_class, Simple: "G__1740000026__1740000090", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000026__1740000090_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000085$G__1740000027__1740000087", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000034_fn__1740000085_A_class, Simple: "G__1740000027__1740000087", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000085_G__1740000027__1740000087_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000093_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000093", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000034_A_class, Simple: "fn__1740000093", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000093_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000093_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000093$G__1740000018__1740000100", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_class, Simple: "G__1740000018__1740000100", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000018__1740000100_A]()) }

func A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_invoke, New: A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_new, Get: A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_get}

var A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000034$fn__1740000093$G__1740000019__1740000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_eval1740000034_fn__1740000093_A_class, Simple: "G__1740000019__1740000096", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_Init; i.Table = A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000034_fn__1740000093_G__1740000019__1740000096_A]()) }

func A_arbace_spec_alpha_eval1740000127_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000127_A_New()}; return nil }

var A_arbace_spec_alpha_eval1740000127_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_alpha_eval1740000127_A_new}

var A_arbace_spec_alpha_eval1740000127_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000127", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_alpha_A_class, Simple: "eval1740000127", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000127_A"})

func init() { i := A_arbace_spec_alpha_eval1740000127_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000127_A_InstanceOf; i.Table = A_arbace_spec_alpha_eval1740000127_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000127_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000127_A]()) }

func A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000127_fn__1740000128_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_invoke, New: A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_new, Get: A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_get}

var A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000127$fn__1740000128", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000127_A_class, Simple: "fn__1740000128", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000127_fn__1740000128_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_Init; i.Table = A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000127_fn__1740000128_A]()) }

func A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_invoke, New: A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_new, Get: A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_get}

var A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000127$fn__1740000128$G__1740000119__1740000137", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_class, Simple: "G__1740000119__1740000137", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_Init; i.Table = A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000119__1740000137_A]()) }

func A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_invoke, New: A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_new, Get: A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_get}

var A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000127$fn__1740000128$G__1740000120__1740000132", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000127_fn__1740000128_A_class, Simple: "G__1740000120__1740000132", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_Init; i.Table = A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000127_fn__1740000128_G__1740000120__1740000132_A]()) }

func A_arbace_spec_alpha_eval1740000149_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000149_A_New()}; return nil }

var A_arbace_spec_alpha_eval1740000149_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_alpha_eval1740000149_A_new}

var A_arbace_spec_alpha_eval1740000149_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000149", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_alpha_A_class, Simple: "eval1740000149", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000149_A"})

func init() { i := A_arbace_spec_alpha_eval1740000149_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000149_A_InstanceOf; i.Table = A_arbace_spec_alpha_eval1740000149_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000149_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000149_A]()) }

func A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000149_fn__1740000150_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_spec_alpha_eval1740000149_fn__1740000150_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_invoke, New: A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_new, Get: A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_get}

var A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000149$fn__1740000150", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000149_A_class, Simple: "fn__1740000150", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000149_fn__1740000150_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_Init; i.Table = A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000149_fn__1740000150_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000149_fn__1740000150_A]()) }

func A_arbace_spec_alpha_eval1740000153_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000153_A_New()}; return nil }

var A_arbace_spec_alpha_eval1740000153_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_alpha_eval1740000153_A_new}

var A_arbace_spec_alpha_eval1740000153_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000153", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_alpha_A_class, Simple: "eval1740000153", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000153_A"})

func init() { i := A_arbace_spec_alpha_eval1740000153_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000153_A_InstanceOf; i.Table = A_arbace_spec_alpha_eval1740000153_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000153_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000153_A]()) }

func A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000153_fn__1740000154_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_spec_alpha_eval1740000153_fn__1740000154_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_invoke, New: A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_new, Get: A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_get}

var A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000153$fn__1740000154", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000153_A_class, Simple: "fn__1740000154", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000153_fn__1740000154_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_Init; i.Table = A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000153_fn__1740000154_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000153_fn__1740000154_A]()) }

func A_arbace_spec_alpha_eval1740000157_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000157_A_New()}; return nil }

var A_arbace_spec_alpha_eval1740000157_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_alpha_eval1740000157_A_new}

var A_arbace_spec_alpha_eval1740000157_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000157", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_alpha_A_class, Simple: "eval1740000157", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000157_A"})

func init() { i := A_arbace_spec_alpha_eval1740000157_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000157_A_InstanceOf; i.Table = A_arbace_spec_alpha_eval1740000157_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000157_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000157_A]()) }

func A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000157_fn__1740000158_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_spec_alpha_eval1740000157_fn__1740000158_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_invoke, New: A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_new, Get: A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_get}

var A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000157$fn__1740000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000157_A_class, Simple: "fn__1740000158", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000157_fn__1740000158_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_Init; i.Table = A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000157_fn__1740000158_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000157_fn__1740000158_A]()) }

func A_arbace_spec_alpha_eval1740000161_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000161_A_New()}; return nil }

var A_arbace_spec_alpha_eval1740000161_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_alpha_eval1740000161_A_new}

var A_arbace_spec_alpha_eval1740000161_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000161", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_alpha_A_class, Simple: "eval1740000161", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000161_A"})

func init() { i := A_arbace_spec_alpha_eval1740000161_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000161_A_InstanceOf; i.Table = A_arbace_spec_alpha_eval1740000161_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000161_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000161_A]()) }

func A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_eval1740000161_fn__1740000162_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_spec_alpha_eval1740000161_fn__1740000162_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_New()}; return nil }

func A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_fn_class)}; return nil }

var A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_invoke, New: A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_new, Get: A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_get}

var A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$eval1740000161$fn__1740000162", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_eval1740000161_A_class, Simple: "fn__1740000162", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_eval1740000161_fn__1740000162_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_InstanceOf; i.Init = A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_Init; i.Table = A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_eval1740000161_fn__1740000162_A_class, reflect.TypeFor[A_arbace_spec_alpha_eval1740000161_fn__1740000162_A]()) }

func A_arbace_spec_alpha_every_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_every_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_A_New()}; return nil }

func A_arbace_spec_alpha_every_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_A_invoke, New: A_arbace_spec_alpha_every_A_new, Get: A_arbace_spec_alpha_every_A_get}

var A_arbace_spec_alpha_every_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "every", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_A_Init; i.Table = A_arbace_spec_alpha_every_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_A]()) }

func A_arbace_spec_alpha_every_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3]); case 1: return this.(*A_arbace_spec_alpha_every_impl_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_every_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_A_New()}; return nil }

func A_arbace_spec_alpha_every_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_impl_A_invoke, New: A_arbace_spec_alpha_every_impl_A_new, Get: A_arbace_spec_alpha_every_impl_A_get}

var A_arbace_spec_alpha_every_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "every_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_impl_A_Init; i.Table = A_arbace_spec_alpha_every_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_A]()) }

func A_arbace_spec_alpha_every_impl_addcv__1740000620_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_addcv__1740000620_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_every_impl_addcv__1740000620_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_addcv__1740000620_A_New()}; return nil }

func A_arbace_spec_alpha_every_impl_addcv__1740000620_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_impl_addcv__1740000620_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_impl_addcv__1740000620_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_impl_addcv__1740000620_A_invoke, New: A_arbace_spec_alpha_every_impl_addcv__1740000620_A_new, Get: A_arbace_spec_alpha_every_impl_addcv__1740000620_A_get}

var A_arbace_spec_alpha_every_impl_addcv__1740000620_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl$addcv__1740000620", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_every_impl_A_class, Simple: "addcv__1740000620", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_addcv__1740000620_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_addcv__1740000620_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_addcv__1740000620_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_impl_addcv__1740000620_A_Init; i.Table = A_arbace_spec_alpha_every_impl_addcv__1740000620_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_addcv__1740000620_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_addcv__1740000620_A]()) }

func A_arbace_spec_alpha_every_impl_cfns__1740000622_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_cfns__1740000622_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_every_impl_cfns__1740000622_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_cfns__1740000622_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_every_impl_cfns__1740000622_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_impl_cfns__1740000622_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_impl_cfns__1740000622_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_impl_cfns__1740000622_A_invoke, New: A_arbace_spec_alpha_every_impl_cfns__1740000622_A_new, Get: A_arbace_spec_alpha_every_impl_cfns__1740000622_A_get}

var A_arbace_spec_alpha_every_impl_cfns__1740000622_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl$cfns__1740000622", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_every_impl_A_class, Simple: "cfns__1740000622", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_cfns__1740000622_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_cfns__1740000622_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_cfns__1740000622_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_impl_cfns__1740000622_A_Init; i.Table = A_arbace_spec_alpha_every_impl_cfns__1740000622_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_cfns__1740000622_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_cfns__1740000622_A]()) }

func A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_New()}; return nil }

func A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_invoke, New: A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_new, Get: A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_get}

var A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl$cfns__1740000622$fn__1740000623", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_every_impl_cfns__1740000622_A_class, Simple: "fn__1740000623", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_Init; i.Table = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000623_A]()) }

func A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_invoke, New: A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_new, Get: A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_get}

var A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl$cfns__1740000622$fn__1740000625", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_every_impl_cfns__1740000622_A_class, Simple: "fn__1740000625", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_Init; i.Table = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000625_A]()) }

func A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_invoke, New: A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_new, Get: A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_get}

var A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl$cfns__1740000622$fn__1740000627", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_every_impl_cfns__1740000622_A_class, Simple: "fn__1740000627", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_Init; i.Table = A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_cfns__1740000622_fn__1740000627_A]()) }

func A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_invoke, New: A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_new, Get: A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_get}

var A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl$check_QMARK___1740000616", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_every_impl_A_class, Simple: "check_QMARK___1740000616", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_Init; i.Table = A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_check_QMARK___1740000616_A]()) }

func A_arbace_spec_alpha_every_impl_fn__1740000614_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_fn__1740000614_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_every_impl_fn__1740000614_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_fn__1740000614_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_every_impl_fn__1740000614_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_impl_fn__1740000614_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_impl_fn__1740000614_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_impl_fn__1740000614_A_invoke, New: A_arbace_spec_alpha_every_impl_fn__1740000614_A_new, Get: A_arbace_spec_alpha_every_impl_fn__1740000614_A_get}

var A_arbace_spec_alpha_every_impl_fn__1740000614_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl$fn__1740000614", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_every_impl_A_class, Simple: "fn__1740000614", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_fn__1740000614_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_fn__1740000614_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_fn__1740000614_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_impl_fn__1740000614_A_Init; i.Table = A_arbace_spec_alpha_every_impl_fn__1740000614_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_fn__1740000614_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_fn__1740000614_A]()) }

func A_arbace_spec_alpha_every_impl_fn__1740000618_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_fn__1740000618_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_every_impl_fn__1740000618_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_fn__1740000618_A_New()}; return nil }

func A_arbace_spec_alpha_every_impl_fn__1740000618_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_impl_fn__1740000618_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_impl_fn__1740000618_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_impl_fn__1740000618_A_invoke, New: A_arbace_spec_alpha_every_impl_fn__1740000618_A_new, Get: A_arbace_spec_alpha_every_impl_fn__1740000618_A_get}

var A_arbace_spec_alpha_every_impl_fn__1740000618_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl$fn__1740000618", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_every_impl_A_class, Simple: "fn__1740000618", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_fn__1740000618_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_fn__1740000618_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_fn__1740000618_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_impl_fn__1740000618_A_Init; i.Table = A_arbace_spec_alpha_every_impl_fn__1740000618_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_fn__1740000618_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_fn__1740000618_A]()) }

func A_arbace_spec_alpha_every_impl_reify__1740000630_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_A).Conform_STAR__O__O(args[0]); case 1: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_A).Describe_STAR___O(); case 2: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_A).Explain_STAR__O_O_O_O__O(args[0], args[1], args[2], args[3]); case 3: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_A).Gen_STAR__O_O_O__O(args[0], args[1], args[2]); case 4: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_A).Meta__IPersistentMap(); case 5: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_A).Specize_STAR___O(); case 6: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_A).Specize_STAR__O__O(args[0]); case 7: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_A).Unform_STAR__O__O(args[0]); case 8: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 9: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_A).With_gen_STAR__O__O(args[0])}; return nil }

func A_arbace_spec_alpha_every_impl_reify__1740000630_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_reify__1740000630_A_New_IPersistentMap_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15], args[16], args[17], args[18], args[19])}; return nil }

var A_arbace_spec_alpha_every_impl_reify__1740000630_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 conform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 describe_STAR_ ()Ljava.lang.Object;\nM1 explain_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 gen_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 specize_STAR_ ()Ljava.lang.Object;\nM1 specize_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 unform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 with_gen_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_spec_alpha_every_impl_reify__1740000630_A_invoke, New: A_arbace_spec_alpha_every_impl_reify__1740000630_A_new}

var A_arbace_spec_alpha_every_impl_reify__1740000630_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl$reify__1740000630", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{A_arbace_spec_alpha_Specize_A_class, A_arbace_spec_alpha_Spec_A_class, lang.IObj_class}, Declaring: A_arbace_spec_alpha_every_impl_A_class, Simple: "reify__1740000630", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_reify__1740000630_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_reify__1740000630_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_reify__1740000630_A_InstanceOf; i.Table = A_arbace_spec_alpha_every_impl_reify__1740000630_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_reify__1740000630_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_reify__1740000630_A]()) }

func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_New_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_invoke, New: A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_new, Get: A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_get}

var A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl$reify__1740000630$fn__1740000667", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_every_impl_reify__1740000630_A_class, Simple: "fn__1740000667", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_Init; i.Table = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000667_A]()) }

func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_New()}; return nil }

func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_invoke, New: A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_new, Get: A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_get}

var A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl$reify__1740000630$fn__1740000669", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_every_impl_reify__1740000630_A_class, Simple: "fn__1740000669", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_Init; i.Table = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000669_A]()) }

func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_invoke, New: A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_new, Get: A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_get}

var A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl$reify__1740000630$fn__1740000671", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_every_impl_reify__1740000630_A_class, Simple: "fn__1740000671", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_Init; i.Table = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A]()) }

func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_invoke, New: A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_new, Get: A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_get}

var A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_impl$reify__1740000630$fn__1740000671$fn__1740000672", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_A_class, Simple: "fn__1740000672", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_Init; i.Table = A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_impl_reify__1740000630_fn__1740000671_fn__1740000672_A]()) }

func A_arbace_spec_alpha_every_kv_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_every_kv_A).DoInvoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_every_kv_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_every_kv_A_New()}; return nil }

func A_arbace_spec_alpha_every_kv_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_every_kv_A_fn_class)}; return nil }

var A_arbace_spec_alpha_every_kv_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_every_kv_A_invoke, New: A_arbace_spec_alpha_every_kv_A_new, Get: A_arbace_spec_alpha_every_kv_A_get}

var A_arbace_spec_alpha_every_kv_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$every_kv", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR4_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "every_kv", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_every_kv_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_every_kv_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_every_kv_A_InstanceOf; i.Init = A_arbace_spec_alpha_every_kv_A_Init; i.Table = A_arbace_spec_alpha_every_kv_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_every_kv_A_class, reflect.TypeFor[A_arbace_spec_alpha_every_kv_A]()) }

func A_arbace_spec_alpha_exercise_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_exercise_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_spec_alpha_exercise_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 2: return this.(*A_arbace_spec_alpha_exercise_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_exercise_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_exercise_A_New()}; return nil }

func A_arbace_spec_alpha_exercise_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_exercise_A_fn_class)}; return nil }

var A_arbace_spec_alpha_exercise_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_exercise_A_invoke, New: A_arbace_spec_alpha_exercise_A_new, Get: A_arbace_spec_alpha_exercise_A_get}

var A_arbace_spec_alpha_exercise_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$exercise", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "exercise", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_exercise_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_exercise_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_exercise_A_InstanceOf; i.Init = A_arbace_spec_alpha_exercise_A_Init; i.Table = A_arbace_spec_alpha_exercise_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_exercise_A_class, reflect.TypeFor[A_arbace_spec_alpha_exercise_A]()) }

func A_arbace_spec_alpha_exercise_fn__1740000905_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_exercise_fn__1740000905_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_exercise_fn__1740000905_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_exercise_fn__1740000905_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_exercise_fn__1740000905_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_exercise_fn__1740000905_A_fn_class)}; return nil }

var A_arbace_spec_alpha_exercise_fn__1740000905_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_exercise_fn__1740000905_A_invoke, New: A_arbace_spec_alpha_exercise_fn__1740000905_A_new, Get: A_arbace_spec_alpha_exercise_fn__1740000905_A_get}

var A_arbace_spec_alpha_exercise_fn__1740000905_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$exercise$fn__1740000905", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_exercise_A_class, Simple: "fn__1740000905", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_exercise_fn__1740000905_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_exercise_fn__1740000905_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_exercise_fn__1740000905_A_InstanceOf; i.Init = A_arbace_spec_alpha_exercise_fn__1740000905_A_Init; i.Table = A_arbace_spec_alpha_exercise_fn__1740000905_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_exercise_fn__1740000905_A_class, reflect.TypeFor[A_arbace_spec_alpha_exercise_fn__1740000905_A]()) }

func A_arbace_spec_alpha_exercise_fn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_exercise_fn_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_spec_alpha_exercise_fn_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 2: return this.(*A_arbace_spec_alpha_exercise_fn_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_exercise_fn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_exercise_fn_A_New()}; return nil }

func A_arbace_spec_alpha_exercise_fn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_exercise_fn_A_fn_class)}; return nil }

var A_arbace_spec_alpha_exercise_fn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_exercise_fn_A_invoke, New: A_arbace_spec_alpha_exercise_fn_A_new, Get: A_arbace_spec_alpha_exercise_fn_A_get}

var A_arbace_spec_alpha_exercise_fn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$exercise_fn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "exercise_fn", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_exercise_fn_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_exercise_fn_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_exercise_fn_A_InstanceOf; i.Init = A_arbace_spec_alpha_exercise_fn_A_Init; i.Table = A_arbace_spec_alpha_exercise_fn_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_exercise_fn_A_class, reflect.TypeFor[A_arbace_spec_alpha_exercise_fn_A]()) }

func A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_fn_class)}; return nil }

var A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_invoke, New: A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_new, Get: A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_get}

var A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$exercise_fn$iter__1740000908__1740000912", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_exercise_fn_A_class, Simple: "iter__1740000908__1740000912", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_InstanceOf; i.Init = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_Init; i.Table = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_class, reflect.TypeFor[A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A]()) }

func A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_fn_class)}; return nil }

var A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_invoke, New: A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_new, Get: A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_get}

var A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$exercise_fn$iter__1740000908__1740000912$fn__1740000913", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_A_class, Simple: "fn__1740000913", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_InstanceOf; i.Init = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_Init; i.Table = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_class, reflect.TypeFor[A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A]()) }

func A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_fn_class)}; return nil }

var A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_invoke, New: A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_new, Get: A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_get}

var A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$exercise_fn$iter__1740000908__1740000912$fn__1740000913$fn__1740000914", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_A_class, Simple: "fn__1740000914", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_InstanceOf; i.Init = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_Init; i.Table = A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A_class, reflect.TypeFor[A_arbace_spec_alpha_exercise_fn_iter__1740000908__1740000912_fn__1740000913_fn__1740000914_A]()) }

func A_arbace_spec_alpha_explain_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_explain_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_explain_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_explain_A_New()}; return nil }

func A_arbace_spec_alpha_explain_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_explain_A_fn_class)}; return nil }

var A_arbace_spec_alpha_explain_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_explain_A_invoke, New: A_arbace_spec_alpha_explain_A_new, Get: A_arbace_spec_alpha_explain_A_get}

var A_arbace_spec_alpha_explain_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$explain", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "explain", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_explain_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_explain_A_InstanceOf; i.Init = A_arbace_spec_alpha_explain_A_Init; i.Table = A_arbace_spec_alpha_explain_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_explain_A_class, reflect.TypeFor[A_arbace_spec_alpha_explain_A]()) }

func A_arbace_spec_alpha_explain_1_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_explain_1_A).Invoke_O_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_spec_alpha_explain_1_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_explain_1_A_New()}; return nil }

func A_arbace_spec_alpha_explain_1_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_explain_1_A_fn_class)}; return nil }

var A_arbace_spec_alpha_explain_1_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_explain_1_A_invoke, New: A_arbace_spec_alpha_explain_1_A_new, Get: A_arbace_spec_alpha_explain_1_A_get}

var A_arbace_spec_alpha_explain_1_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$explain_1", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF6_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "explain_1", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_1_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_explain_1_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_explain_1_A_InstanceOf; i.Init = A_arbace_spec_alpha_explain_1_A_Init; i.Table = A_arbace_spec_alpha_explain_1_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_explain_1_A_class, reflect.TypeFor[A_arbace_spec_alpha_explain_1_A]()) }

func A_arbace_spec_alpha_explain_data_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_explain_data_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_explain_data_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_explain_data_A_New()}; return nil }

func A_arbace_spec_alpha_explain_data_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_explain_data_A_fn_class)}; return nil }

var A_arbace_spec_alpha_explain_data_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_explain_data_A_invoke, New: A_arbace_spec_alpha_explain_data_A_new, Get: A_arbace_spec_alpha_explain_data_A_get}

var A_arbace_spec_alpha_explain_data_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$explain_data", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "explain_data", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_data_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_explain_data_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_explain_data_A_InstanceOf; i.Init = A_arbace_spec_alpha_explain_data_A_Init; i.Table = A_arbace_spec_alpha_explain_data_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_explain_data_A_class, reflect.TypeFor[A_arbace_spec_alpha_explain_data_A]()) }

func A_arbace_spec_alpha_explain_data_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_explain_data_STAR__A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_explain_data_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_explain_data_STAR__A_New()}; return nil }

func A_arbace_spec_alpha_explain_data_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_explain_data_STAR__A_fn_class)}; return nil }

var A_arbace_spec_alpha_explain_data_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_explain_data_STAR__A_invoke, New: A_arbace_spec_alpha_explain_data_STAR__A_new, Get: A_arbace_spec_alpha_explain_data_STAR__A_get}

var A_arbace_spec_alpha_explain_data_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$explain_data_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "explain_data_STAR_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_data_STAR__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_explain_data_STAR__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_explain_data_STAR__A_InstanceOf; i.Init = A_arbace_spec_alpha_explain_data_STAR__A_Init; i.Table = A_arbace_spec_alpha_explain_data_STAR__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_explain_data_STAR__A_class, reflect.TypeFor[A_arbace_spec_alpha_explain_data_STAR__A]()) }

func A_arbace_spec_alpha_explain_out_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_explain_out_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_explain_out_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_explain_out_A_New()}; return nil }

func A_arbace_spec_alpha_explain_out_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_explain_out_A_fn_class)}; return nil }

var A_arbace_spec_alpha_explain_out_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_explain_out_A_invoke, New: A_arbace_spec_alpha_explain_out_A_new, Get: A_arbace_spec_alpha_explain_out_A_get}

var A_arbace_spec_alpha_explain_out_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$explain_out", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "explain_out", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_out_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_explain_out_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_explain_out_A_InstanceOf; i.Init = A_arbace_spec_alpha_explain_out_A_Init; i.Table = A_arbace_spec_alpha_explain_out_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_explain_out_A_class, reflect.TypeFor[A_arbace_spec_alpha_explain_out_A]()) }

func A_arbace_spec_alpha_explain_pred_list_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_explain_pred_list_A).Invoke_O_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_spec_alpha_explain_pred_list_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_explain_pred_list_A_New()}; return nil }

func A_arbace_spec_alpha_explain_pred_list_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_explain_pred_list_A_fn_class)}; return nil }

var A_arbace_spec_alpha_explain_pred_list_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_explain_pred_list_A_invoke, New: A_arbace_spec_alpha_explain_pred_list_A_new, Get: A_arbace_spec_alpha_explain_pred_list_A_get}

var A_arbace_spec_alpha_explain_pred_list_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$explain_pred_list", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF6_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "explain_pred_list", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_pred_list_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_explain_pred_list_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_explain_pred_list_A_InstanceOf; i.Init = A_arbace_spec_alpha_explain_pred_list_A_Init; i.Table = A_arbace_spec_alpha_explain_pred_list_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_explain_pred_list_A_class, reflect.TypeFor[A_arbace_spec_alpha_explain_pred_list_A]()) }

func A_arbace_spec_alpha_explain_printer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_explain_printer_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_explain_printer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_explain_printer_A_New()}; return nil }

func A_arbace_spec_alpha_explain_printer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_explain_printer_A_fn_class)}; return nil }

var A_arbace_spec_alpha_explain_printer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_explain_printer_A_invoke, New: A_arbace_spec_alpha_explain_printer_A_new, Get: A_arbace_spec_alpha_explain_printer_A_get}

var A_arbace_spec_alpha_explain_printer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$explain_printer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "explain_printer", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_printer_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_explain_printer_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_explain_printer_A_InstanceOf; i.Init = A_arbace_spec_alpha_explain_printer_A_Init; i.Table = A_arbace_spec_alpha_explain_printer_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_explain_printer_A_class, reflect.TypeFor[A_arbace_spec_alpha_explain_printer_A]()) }

func A_arbace_spec_alpha_explain_printer_fn__1740000179_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_explain_printer_fn__1740000179_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_explain_printer_fn__1740000179_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_explain_printer_fn__1740000179_A_New()}; return nil }

func A_arbace_spec_alpha_explain_printer_fn__1740000179_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_explain_printer_fn__1740000179_A_fn_class)}; return nil }

var A_arbace_spec_alpha_explain_printer_fn__1740000179_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_explain_printer_fn__1740000179_A_invoke, New: A_arbace_spec_alpha_explain_printer_fn__1740000179_A_new, Get: A_arbace_spec_alpha_explain_printer_fn__1740000179_A_get}

var A_arbace_spec_alpha_explain_printer_fn__1740000179_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$explain_printer$fn__1740000179", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_explain_printer_A_class, Simple: "fn__1740000179", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_printer_fn__1740000179_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_explain_printer_fn__1740000179_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_explain_printer_fn__1740000179_A_InstanceOf; i.Init = A_arbace_spec_alpha_explain_printer_fn__1740000179_A_Init; i.Table = A_arbace_spec_alpha_explain_printer_fn__1740000179_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_explain_printer_fn__1740000179_A_class, reflect.TypeFor[A_arbace_spec_alpha_explain_printer_fn__1740000179_A]()) }

func A_arbace_spec_alpha_explain_printer_fn__1740000181_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_explain_printer_fn__1740000181_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_explain_printer_fn__1740000181_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_explain_printer_fn__1740000181_A_New()}; return nil }

func A_arbace_spec_alpha_explain_printer_fn__1740000181_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_explain_printer_fn__1740000181_A_fn_class)}; return nil }

var A_arbace_spec_alpha_explain_printer_fn__1740000181_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_explain_printer_fn__1740000181_A_invoke, New: A_arbace_spec_alpha_explain_printer_fn__1740000181_A_new, Get: A_arbace_spec_alpha_explain_printer_fn__1740000181_A_get}

var A_arbace_spec_alpha_explain_printer_fn__1740000181_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$explain_printer$fn__1740000181", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_explain_printer_A_class, Simple: "fn__1740000181", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_printer_fn__1740000181_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_explain_printer_fn__1740000181_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_explain_printer_fn__1740000181_A_InstanceOf; i.Init = A_arbace_spec_alpha_explain_printer_fn__1740000181_A_Init; i.Table = A_arbace_spec_alpha_explain_printer_fn__1740000181_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_explain_printer_fn__1740000181_A_class, reflect.TypeFor[A_arbace_spec_alpha_explain_printer_fn__1740000181_A]()) }

func A_arbace_spec_alpha_explain_str_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_explain_str_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_explain_str_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_explain_str_A_New()}; return nil }

func A_arbace_spec_alpha_explain_str_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_explain_str_A_fn_class)}; return nil }

var A_arbace_spec_alpha_explain_str_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_explain_str_A_invoke, New: A_arbace_spec_alpha_explain_str_A_new, Get: A_arbace_spec_alpha_explain_str_A_get}

var A_arbace_spec_alpha_explain_str_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$explain_str", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "explain_str", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_str_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_explain_str_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_explain_str_A_InstanceOf; i.Init = A_arbace_spec_alpha_explain_str_A_Init; i.Table = A_arbace_spec_alpha_explain_str_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_explain_str_A_class, reflect.TypeFor[A_arbace_spec_alpha_explain_str_A]()) }

func A_arbace_spec_alpha_fdef_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_fdef_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_fdef_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_fdef_A_New()}; return nil }

func A_arbace_spec_alpha_fdef_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_fdef_A_fn_class)}; return nil }

var A_arbace_spec_alpha_fdef_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_fdef_A_invoke, New: A_arbace_spec_alpha_fdef_A_new, Get: A_arbace_spec_alpha_fdef_A_get}

var A_arbace_spec_alpha_fdef_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$fdef", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "fdef", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_fdef_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_fdef_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_fdef_A_InstanceOf; i.Init = A_arbace_spec_alpha_fdef_A_Init; i.Table = A_arbace_spec_alpha_fdef_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_fdef_A_class, reflect.TypeFor[A_arbace_spec_alpha_fdef_A]()) }

func A_arbace_spec_alpha_filter_alt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_filter_alt_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_filter_alt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_filter_alt_A_New()}; return nil }

func A_arbace_spec_alpha_filter_alt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_filter_alt_A_fn_class)}; return nil }

var A_arbace_spec_alpha_filter_alt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_filter_alt_A_invoke, New: A_arbace_spec_alpha_filter_alt_A_new, Get: A_arbace_spec_alpha_filter_alt_A_get}

var A_arbace_spec_alpha_filter_alt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$filter_alt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "filter_alt", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_filter_alt_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_filter_alt_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_filter_alt_A_InstanceOf; i.Init = A_arbace_spec_alpha_filter_alt_A_Init; i.Table = A_arbace_spec_alpha_filter_alt_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_filter_alt_A_class, reflect.TypeFor[A_arbace_spec_alpha_filter_alt_A]()) }

func A_arbace_spec_alpha_filter_alt_fn__1740000703_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_filter_alt_fn__1740000703_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_filter_alt_fn__1740000703_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_filter_alt_fn__1740000703_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_filter_alt_fn__1740000703_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_filter_alt_fn__1740000703_A_fn_class)}; return nil }

var A_arbace_spec_alpha_filter_alt_fn__1740000703_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_filter_alt_fn__1740000703_A_invoke, New: A_arbace_spec_alpha_filter_alt_fn__1740000703_A_new, Get: A_arbace_spec_alpha_filter_alt_fn__1740000703_A_get}

var A_arbace_spec_alpha_filter_alt_fn__1740000703_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$filter_alt$fn__1740000703", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_filter_alt_A_class, Simple: "fn__1740000703", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_filter_alt_fn__1740000703_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_filter_alt_fn__1740000703_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_filter_alt_fn__1740000703_A_InstanceOf; i.Init = A_arbace_spec_alpha_filter_alt_fn__1740000703_A_Init; i.Table = A_arbace_spec_alpha_filter_alt_fn__1740000703_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_filter_alt_fn__1740000703_A_class, reflect.TypeFor[A_arbace_spec_alpha_filter_alt_fn__1740000703_A]()) }

func A_arbace_spec_alpha_filter_alt_fn__1740000705_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_filter_alt_fn__1740000705_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_filter_alt_fn__1740000705_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_filter_alt_fn__1740000705_A_New()}; return nil }

func A_arbace_spec_alpha_filter_alt_fn__1740000705_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_filter_alt_fn__1740000705_A_fn_class)}; return nil }

var A_arbace_spec_alpha_filter_alt_fn__1740000705_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_filter_alt_fn__1740000705_A_invoke, New: A_arbace_spec_alpha_filter_alt_fn__1740000705_A_new, Get: A_arbace_spec_alpha_filter_alt_fn__1740000705_A_get}

var A_arbace_spec_alpha_filter_alt_fn__1740000705_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$filter_alt$fn__1740000705", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_filter_alt_A_class, Simple: "fn__1740000705", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_filter_alt_fn__1740000705_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_filter_alt_fn__1740000705_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_filter_alt_fn__1740000705_A_InstanceOf; i.Init = A_arbace_spec_alpha_filter_alt_fn__1740000705_A_Init; i.Table = A_arbace_spec_alpha_filter_alt_fn__1740000705_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_filter_alt_fn__1740000705_A_class, reflect.TypeFor[A_arbace_spec_alpha_filter_alt_fn__1740000705_A]()) }

func A_arbace_spec_alpha_fn__1740000868_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_fn__1740000868_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_fn__1740000868_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_fn__1740000868_A_New()}; return nil }

func A_arbace_spec_alpha_fn__1740000868_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_fn__1740000868_A_fn_class)}; return nil }

var A_arbace_spec_alpha_fn__1740000868_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_fn__1740000868_A_invoke, New: A_arbace_spec_alpha_fn__1740000868_A_new, Get: A_arbace_spec_alpha_fn__1740000868_A_get}

var A_arbace_spec_alpha_fn__1740000868_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$fn__1740000868", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "fn__1740000868", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_fn__1740000868_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_fn__1740000868_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_fn__1740000868_A_InstanceOf; i.Init = A_arbace_spec_alpha_fn__1740000868_A_Init; i.Table = A_arbace_spec_alpha_fn__1740000868_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_fn__1740000868_A_class, reflect.TypeFor[A_arbace_spec_alpha_fn__1740000868_A]()) }

func A_arbace_spec_alpha_fn__1740000870_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_fn__1740000870_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_fn__1740000870_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_fn__1740000870_A_New()}; return nil }

func A_arbace_spec_alpha_fn__1740000870_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_fn__1740000870_A_fn_class)}; return nil }

var A_arbace_spec_alpha_fn__1740000870_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_fn__1740000870_A_invoke, New: A_arbace_spec_alpha_fn__1740000870_A_new, Get: A_arbace_spec_alpha_fn__1740000870_A_get}

var A_arbace_spec_alpha_fn__1740000870_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$fn__1740000870", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "fn__1740000870", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_fn__1740000870_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_fn__1740000870_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_fn__1740000870_A_InstanceOf; i.Init = A_arbace_spec_alpha_fn__1740000870_A_Init; i.Table = A_arbace_spec_alpha_fn__1740000870_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_fn__1740000870_A_class, reflect.TypeFor[A_arbace_spec_alpha_fn__1740000870_A]()) }

func A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_New()}; return nil }

func A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_fn_class)}; return nil }

var A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_invoke, New: A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_new, Get: A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_get}

var A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$fn__1740000870$fn__1740000872", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_fn__1740000870_A_class, Simple: "fn__1740000872", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_InstanceOf; i.Init = A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_Init; i.Table = A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A_class, reflect.TypeFor[A_arbace_spec_alpha_fn__1740000870_fn__1740000872_A]()) }

func A_arbace_spec_alpha_fn_sym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_fn_sym_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_fn_sym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_fn_sym_A_New()}; return nil }

func A_arbace_spec_alpha_fn_sym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_fn_sym_A_fn_class)}; return nil }

var A_arbace_spec_alpha_fn_sym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_fn_sym_A_invoke, New: A_arbace_spec_alpha_fn_sym_A_new, Get: A_arbace_spec_alpha_fn_sym_A_get}

var A_arbace_spec_alpha_fn_sym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$fn_sym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "fn_sym", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_fn_sym_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_fn_sym_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_fn_sym_A_InstanceOf; i.Init = A_arbace_spec_alpha_fn_sym_A_Init; i.Table = A_arbace_spec_alpha_fn_sym_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_fn_sym_A_class, reflect.TypeFor[A_arbace_spec_alpha_fn_sym_A]()) }

func A_arbace_spec_alpha_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_form_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_form_A_New()}; return nil }

func A_arbace_spec_alpha_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_form_A_fn_class)}; return nil }

var A_arbace_spec_alpha_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_form_A_invoke, New: A_arbace_spec_alpha_form_A_new, Get: A_arbace_spec_alpha_form_A_get}

var A_arbace_spec_alpha_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "form", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_form_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_form_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_form_A_InstanceOf; i.Init = A_arbace_spec_alpha_form_A_Init; i.Table = A_arbace_spec_alpha_form_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_form_A_class, reflect.TypeFor[A_arbace_spec_alpha_form_A]()) }

func A_arbace_spec_alpha_fspec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_fspec_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_fspec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_fspec_A_New()}; return nil }

func A_arbace_spec_alpha_fspec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_fspec_A_fn_class)}; return nil }

var A_arbace_spec_alpha_fspec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_fspec_A_invoke, New: A_arbace_spec_alpha_fspec_A_new, Get: A_arbace_spec_alpha_fspec_A_get}

var A_arbace_spec_alpha_fspec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$fspec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "fspec", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_fspec_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_fspec_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_fspec_A_InstanceOf; i.Init = A_arbace_spec_alpha_fspec_A_Init; i.Table = A_arbace_spec_alpha_fspec_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_fspec_A_class, reflect.TypeFor[A_arbace_spec_alpha_fspec_A]()) }

func A_arbace_spec_alpha_fspec_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_fspec_impl_A).Invoke_O_O_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7])}; return nil }

func A_arbace_spec_alpha_fspec_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_fspec_impl_A_New()}; return nil }

func A_arbace_spec_alpha_fspec_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_fspec_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_fspec_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_fspec_impl_A_invoke, New: A_arbace_spec_alpha_fspec_impl_A_new, Get: A_arbace_spec_alpha_fspec_impl_A_get}

var A_arbace_spec_alpha_fspec_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$fspec_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF7_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "fspec_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_fspec_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_fspec_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_fspec_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_fspec_impl_A_Init; i.Table = A_arbace_spec_alpha_fspec_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_fspec_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_fspec_impl_A]()) }

func A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A).Conform_STAR__O__O(args[0]); case 1: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A).Describe_STAR___O(); case 2: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A).Explain_STAR__O_O_O_O__O(args[0], args[1], args[2], args[3]); case 3: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A).Gen_STAR__O_O_O__O(args[0], args[1], args[2]); case 4: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A).Meta__IPersistentMap(); case 5: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A).Specize_STAR___O(); case 6: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A).Specize_STAR__O__O(args[0]); case 7: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A).Unform_STAR__O__O(args[0]); case 8: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A).ValAt_O__O(args[0]); case 9: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A).ValAt_O_O__O(args[0], args[1]); case 10: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 11: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_A).With_gen_STAR__O__O(args[0])}; return nil }

func A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_New_IPersistentMap_O_O_O_O_O_O_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8])}; return nil }

var A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 conform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 describe_STAR_ ()Ljava.lang.Object;\nM1 explain_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 gen_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 specize_STAR_ ()Ljava.lang.Object;\nM1 specize_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 unform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 valAt (Ljava.lang.Object;)Ljava.lang.Object;\nM1 valAt (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 with_gen_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_invoke, New: A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_new}

var A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$fspec_impl$reify__1740000857", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.ILookup_class, A_arbace_spec_alpha_Specize_A_class, A_arbace_spec_alpha_Spec_A_class, lang.IObj_class}, Declaring: A_arbace_spec_alpha_fspec_impl_A_class, Simple: "reify__1740000857", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_fspec_impl_reify__1740000857_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_InstanceOf; i.Table = A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_class, reflect.TypeFor[A_arbace_spec_alpha_fspec_impl_reify__1740000857_A]()) }

func A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_fn_class)}; return nil }

var A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_invoke, New: A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_new, Get: A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_get}

var A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$fspec_impl$reify__1740000857$fn__1740000858", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_class, Simple: "fn__1740000858", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_InstanceOf; i.Init = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_Init; i.Table = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A_class, reflect.TypeFor[A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000858_A]()) }

func A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_fn_class)}; return nil }

var A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_invoke, New: A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_new, Get: A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_get}

var A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$fspec_impl$reify__1740000857$fn__1740000860", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_alpha_fspec_impl_reify__1740000857_A_class, Simple: "fn__1740000860", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_InstanceOf; i.Init = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_Init; i.Table = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_class, reflect.TypeFor[A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A]()) }

func A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_fn_class)}; return nil }

var A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_invoke, New: A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_new, Get: A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_get}

var A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$fspec_impl$reify__1740000857$fn__1740000860$fn__1740000861", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_A_class, Simple: "fn__1740000861", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_InstanceOf; i.Init = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_Init; i.Table = A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A_class, reflect.TypeFor[A_arbace_spec_alpha_fspec_impl_reify__1740000857_fn__1740000860_fn__1740000861_A]()) }

func A_arbace_spec_alpha_gen_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_gen_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_spec_alpha_gen_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_gen_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_gen_A_New()}; return nil }

func A_arbace_spec_alpha_gen_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_gen_A_fn_class)}; return nil }

var A_arbace_spec_alpha_gen_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_gen_A_invoke, New: A_arbace_spec_alpha_gen_A_new, Get: A_arbace_spec_alpha_gen_A_get}

var A_arbace_spec_alpha_gen_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$gen", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "gen", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_gen_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_gen_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_gen_A_InstanceOf; i.Init = A_arbace_spec_alpha_gen_A_Init; i.Table = A_arbace_spec_alpha_gen_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_gen_A_class, reflect.TypeFor[A_arbace_spec_alpha_gen_A]()) }

func A_arbace_spec_alpha_gensub_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_gensub_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_gensub_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_gensub_A_New()}; return nil }

func A_arbace_spec_alpha_gensub_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_gensub_A_fn_class)}; return nil }

var A_arbace_spec_alpha_gensub_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_gensub_A_invoke, New: A_arbace_spec_alpha_gensub_A_new, Get: A_arbace_spec_alpha_gensub_A_get}

var A_arbace_spec_alpha_gensub_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$gensub", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "gensub", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_gensub_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_gensub_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_gensub_A_InstanceOf; i.Init = A_arbace_spec_alpha_gensub_A_Init; i.Table = A_arbace_spec_alpha_gensub_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_gensub_A_class, reflect.TypeFor[A_arbace_spec_alpha_gensub_A]()) }

func A_arbace_spec_alpha_gensub_fn__1740000216_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_gensub_fn__1740000216_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_gensub_fn__1740000216_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_gensub_fn__1740000216_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_gensub_fn__1740000216_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_gensub_fn__1740000216_A_fn_class)}; return nil }

var A_arbace_spec_alpha_gensub_fn__1740000216_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_gensub_fn__1740000216_A_invoke, New: A_arbace_spec_alpha_gensub_fn__1740000216_A_new, Get: A_arbace_spec_alpha_gensub_fn__1740000216_A_get}

var A_arbace_spec_alpha_gensub_fn__1740000216_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$gensub$fn__1740000216", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_gensub_A_class, Simple: "fn__1740000216", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_gensub_fn__1740000216_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_gensub_fn__1740000216_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_gensub_fn__1740000216_A_InstanceOf; i.Init = A_arbace_spec_alpha_gensub_fn__1740000216_A_Init; i.Table = A_arbace_spec_alpha_gensub_fn__1740000216_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_gensub_fn__1740000216_A_class, reflect.TypeFor[A_arbace_spec_alpha_gensub_fn__1740000216_A]()) }

func A_arbace_spec_alpha_get_spec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_get_spec_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_get_spec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_get_spec_A_New()}; return nil }

func A_arbace_spec_alpha_get_spec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_get_spec_A_fn_class)}; return nil }

var A_arbace_spec_alpha_get_spec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_get_spec_A_invoke, New: A_arbace_spec_alpha_get_spec_A_new, Get: A_arbace_spec_alpha_get_spec_A_get}

var A_arbace_spec_alpha_get_spec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$get_spec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "get_spec", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_get_spec_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_get_spec_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_get_spec_A_InstanceOf; i.Init = A_arbace_spec_alpha_get_spec_A_Init; i.Table = A_arbace_spec_alpha_get_spec_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_get_spec_A_class, reflect.TypeFor[A_arbace_spec_alpha_get_spec_A]()) }

func A_arbace_spec_alpha_inck_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_inck_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_inck_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_inck_A_New()}; return nil }

func A_arbace_spec_alpha_inck_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_inck_A_fn_class)}; return nil }

var A_arbace_spec_alpha_inck_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_inck_A_invoke, New: A_arbace_spec_alpha_inck_A_new, Get: A_arbace_spec_alpha_inck_A_get}

var A_arbace_spec_alpha_inck_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$inck", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "inck", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_inck_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_inck_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_inck_A_InstanceOf; i.Init = A_arbace_spec_alpha_inck_A_Init; i.Table = A_arbace_spec_alpha_inck_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_inck_A_class, reflect.TypeFor[A_arbace_spec_alpha_inck_A]()) }

func A_arbace_spec_alpha_inst_in_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_inst_in_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_inst_in_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_inst_in_A_New()}; return nil }

func A_arbace_spec_alpha_inst_in_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_inst_in_A_fn_class)}; return nil }

var A_arbace_spec_alpha_inst_in_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_inst_in_A_invoke, New: A_arbace_spec_alpha_inst_in_A_new, Get: A_arbace_spec_alpha_inst_in_A_get}

var A_arbace_spec_alpha_inst_in_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$inst_in", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "inst_in", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_inst_in_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_inst_in_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_inst_in_A_InstanceOf; i.Init = A_arbace_spec_alpha_inst_in_A_Init; i.Table = A_arbace_spec_alpha_inst_in_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_inst_in_A_class, reflect.TypeFor[A_arbace_spec_alpha_inst_in_A]()) }

func A_arbace_spec_alpha_inst_in_range_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_inst_in_range_QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_inst_in_range_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_inst_in_range_QMARK__A_New()}; return nil }

func A_arbace_spec_alpha_inst_in_range_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_inst_in_range_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha_inst_in_range_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_inst_in_range_QMARK__A_invoke, New: A_arbace_spec_alpha_inst_in_range_QMARK__A_new, Get: A_arbace_spec_alpha_inst_in_range_QMARK__A_get}

var A_arbace_spec_alpha_inst_in_range_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$inst_in_range_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "inst_in_range_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_inst_in_range_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_inst_in_range_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_inst_in_range_QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha_inst_in_range_QMARK__A_Init; i.Table = A_arbace_spec_alpha_inst_in_range_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_inst_in_range_QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha_inst_in_range_QMARK__A]()) }

func A_arbace_spec_alpha_int_in_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_int_in_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_int_in_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_int_in_A_New()}; return nil }

func A_arbace_spec_alpha_int_in_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_int_in_A_fn_class)}; return nil }

var A_arbace_spec_alpha_int_in_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_int_in_A_invoke, New: A_arbace_spec_alpha_int_in_A_new, Get: A_arbace_spec_alpha_int_in_A_get}

var A_arbace_spec_alpha_int_in_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$int_in", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "int_in", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_int_in_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_int_in_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_int_in_A_InstanceOf; i.Init = A_arbace_spec_alpha_int_in_A_Init; i.Table = A_arbace_spec_alpha_int_in_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_int_in_A_class, reflect.TypeFor[A_arbace_spec_alpha_int_in_A]()) }

func A_arbace_spec_alpha_int_in_range_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_int_in_range_QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_int_in_range_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_int_in_range_QMARK__A_New()}; return nil }

func A_arbace_spec_alpha_int_in_range_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_int_in_range_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha_int_in_range_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_int_in_range_QMARK__A_invoke, New: A_arbace_spec_alpha_int_in_range_QMARK__A_new, Get: A_arbace_spec_alpha_int_in_range_QMARK__A_get}

var A_arbace_spec_alpha_int_in_range_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$int_in_range_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "int_in_range_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_int_in_range_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_int_in_range_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_int_in_range_QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha_int_in_range_QMARK__A_Init; i.Table = A_arbace_spec_alpha_int_in_range_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_int_in_range_QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha_int_in_range_QMARK__A]()) }

func A_arbace_spec_alpha_invalid_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_invalid_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_invalid_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_invalid_QMARK__A_New()}; return nil }

func A_arbace_spec_alpha_invalid_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_invalid_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha_invalid_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_invalid_QMARK__A_invoke, New: A_arbace_spec_alpha_invalid_QMARK__A_new, Get: A_arbace_spec_alpha_invalid_QMARK__A_get}

var A_arbace_spec_alpha_invalid_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$invalid_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "invalid_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_invalid_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_invalid_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_invalid_QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha_invalid_QMARK__A_Init; i.Table = A_arbace_spec_alpha_invalid_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_invalid_QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha_invalid_QMARK__A]()) }

func A_arbace_spec_alpha_k_gen_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_k_gen_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_k_gen_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_k_gen_A_New()}; return nil }

func A_arbace_spec_alpha_k_gen_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_k_gen_A_fn_class)}; return nil }

var A_arbace_spec_alpha_k_gen_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_k_gen_A_invoke, New: A_arbace_spec_alpha_k_gen_A_new, Get: A_arbace_spec_alpha_k_gen_A_get}

var A_arbace_spec_alpha_k_gen_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$k_gen", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "k_gen", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_k_gen_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_k_gen_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_k_gen_A_InstanceOf; i.Init = A_arbace_spec_alpha_k_gen_A_Init; i.Table = A_arbace_spec_alpha_k_gen_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_k_gen_A_class, reflect.TypeFor[A_arbace_spec_alpha_k_gen_A]()) }

func A_arbace_spec_alpha_keys_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_keys_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_keys_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_keys_A_New()}; return nil }

func A_arbace_spec_alpha_keys_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_keys_A_fn_class)}; return nil }

var A_arbace_spec_alpha_keys_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_keys_A_invoke, New: A_arbace_spec_alpha_keys_A_new, Get: A_arbace_spec_alpha_keys_A_get}

var A_arbace_spec_alpha_keys_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$keys", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "keys", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_keys_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_keys_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_keys_A_InstanceOf; i.Init = A_arbace_spec_alpha_keys_A_Init; i.Table = A_arbace_spec_alpha_keys_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_keys_A_class, reflect.TypeFor[A_arbace_spec_alpha_keys_A]()) }

func A_arbace_spec_alpha_keys_fn__1740000263_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_keys_fn__1740000263_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_keys_fn__1740000263_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_keys_fn__1740000263_A_New()}; return nil }

func A_arbace_spec_alpha_keys_fn__1740000263_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_keys_fn__1740000263_A_fn_class)}; return nil }

var A_arbace_spec_alpha_keys_fn__1740000263_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_keys_fn__1740000263_A_invoke, New: A_arbace_spec_alpha_keys_fn__1740000263_A_new, Get: A_arbace_spec_alpha_keys_fn__1740000263_A_get}

var A_arbace_spec_alpha_keys_fn__1740000263_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$keys$fn__1740000263", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_keys_A_class, Simple: "fn__1740000263", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_keys_fn__1740000263_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_keys_fn__1740000263_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_keys_fn__1740000263_A_InstanceOf; i.Init = A_arbace_spec_alpha_keys_fn__1740000263_A_Init; i.Table = A_arbace_spec_alpha_keys_fn__1740000263_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_keys_fn__1740000263_A_class, reflect.TypeFor[A_arbace_spec_alpha_keys_fn__1740000263_A]()) }

func A_arbace_spec_alpha_keys_fn__1740000271_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_keys_fn__1740000271_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_keys_fn__1740000271_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_keys_fn__1740000271_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_keys_fn__1740000271_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_keys_fn__1740000271_A_fn_class)}; return nil }

var A_arbace_spec_alpha_keys_fn__1740000271_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_keys_fn__1740000271_A_invoke, New: A_arbace_spec_alpha_keys_fn__1740000271_A_new, Get: A_arbace_spec_alpha_keys_fn__1740000271_A_get}

var A_arbace_spec_alpha_keys_fn__1740000271_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$keys$fn__1740000271", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_keys_A_class, Simple: "fn__1740000271", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_keys_fn__1740000271_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_keys_fn__1740000271_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_keys_fn__1740000271_A_InstanceOf; i.Init = A_arbace_spec_alpha_keys_fn__1740000271_A_Init; i.Table = A_arbace_spec_alpha_keys_fn__1740000271_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_keys_fn__1740000271_A_class, reflect.TypeFor[A_arbace_spec_alpha_keys_fn__1740000271_A]()) }

func A_arbace_spec_alpha_keys_parse_req__1740000265_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_keys_parse_req__1740000265_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_keys_parse_req__1740000265_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_keys_parse_req__1740000265_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_keys_parse_req__1740000265_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_keys_parse_req__1740000265_A_fn_class)}; return nil }

var A_arbace_spec_alpha_keys_parse_req__1740000265_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_keys_parse_req__1740000265_A_invoke, New: A_arbace_spec_alpha_keys_parse_req__1740000265_A_new, Get: A_arbace_spec_alpha_keys_parse_req__1740000265_A_get}

var A_arbace_spec_alpha_keys_parse_req__1740000265_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$keys$parse_req__1740000265", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_keys_A_class, Simple: "parse_req__1740000265", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_keys_parse_req__1740000265_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_keys_parse_req__1740000265_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_keys_parse_req__1740000265_A_InstanceOf; i.Init = A_arbace_spec_alpha_keys_parse_req__1740000265_A_Init; i.Table = A_arbace_spec_alpha_keys_parse_req__1740000265_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_keys_parse_req__1740000265_A_class, reflect.TypeFor[A_arbace_spec_alpha_keys_parse_req__1740000265_A]()) }

func A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_fn_class)}; return nil }

var A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_invoke, New: A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_new, Get: A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_get}

var A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$keys$parse_req__1740000265$fn__1740000266", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_keys_parse_req__1740000265_A_class, Simple: "fn__1740000266", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_InstanceOf; i.Init = A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_Init; i.Table = A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_class, reflect.TypeFor[A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A]()) }

func A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_fn_class)}; return nil }

var A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_invoke, New: A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_new, Get: A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_get}

var A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$keys$parse_req__1740000265$fn__1740000266$fn__1740000267", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_A_class, Simple: "fn__1740000267", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_InstanceOf; i.Init = A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_Init; i.Table = A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A_class, reflect.TypeFor[A_arbace_spec_alpha_keys_parse_req__1740000265_fn__1740000266_fn__1740000267_A]()) }

func A_arbace_spec_alpha_keys_unk__1740000261_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_keys_unk__1740000261_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_keys_unk__1740000261_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_keys_unk__1740000261_A_New()}; return nil }

func A_arbace_spec_alpha_keys_unk__1740000261_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_keys_unk__1740000261_A_fn_class)}; return nil }

var A_arbace_spec_alpha_keys_unk__1740000261_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_keys_unk__1740000261_A_invoke, New: A_arbace_spec_alpha_keys_unk__1740000261_A_new, Get: A_arbace_spec_alpha_keys_unk__1740000261_A_get}

var A_arbace_spec_alpha_keys_unk__1740000261_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$keys$unk__1740000261", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_keys_A_class, Simple: "unk__1740000261", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_keys_unk__1740000261_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_keys_unk__1740000261_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_keys_unk__1740000261_A_InstanceOf; i.Init = A_arbace_spec_alpha_keys_unk__1740000261_A_Init; i.Table = A_arbace_spec_alpha_keys_unk__1740000261_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_keys_unk__1740000261_A_class, reflect.TypeFor[A_arbace_spec_alpha_keys_unk__1740000261_A]()) }

func A_arbace_spec_alpha_keys_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_keys_STAR__A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_keys_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_keys_STAR__A_New()}; return nil }

func A_arbace_spec_alpha_keys_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_keys_STAR__A_fn_class)}; return nil }

var A_arbace_spec_alpha_keys_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_keys_STAR__A_invoke, New: A_arbace_spec_alpha_keys_STAR__A_new, Get: A_arbace_spec_alpha_keys_STAR__A_get}

var A_arbace_spec_alpha_keys_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$keys_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "keys_STAR_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_keys_STAR__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_keys_STAR__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_keys_STAR__A_InstanceOf; i.Init = A_arbace_spec_alpha_keys_STAR__A_Init; i.Table = A_arbace_spec_alpha_keys_STAR__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_keys_STAR__A_class, reflect.TypeFor[A_arbace_spec_alpha_keys_STAR__A]()) }

func A_arbace_spec_alpha_macroexpand_check_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_macroexpand_check_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_macroexpand_check_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_macroexpand_check_A_New()}; return nil }

func A_arbace_spec_alpha_macroexpand_check_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_macroexpand_check_A_fn_class)}; return nil }

var A_arbace_spec_alpha_macroexpand_check_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_macroexpand_check_A_invoke, New: A_arbace_spec_alpha_macroexpand_check_A_new, Get: A_arbace_spec_alpha_macroexpand_check_A_get}

var A_arbace_spec_alpha_macroexpand_check_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$macroexpand_check", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "macroexpand_check", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_macroexpand_check_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_macroexpand_check_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_macroexpand_check_A_InstanceOf; i.Init = A_arbace_spec_alpha_macroexpand_check_A_Init; i.Table = A_arbace_spec_alpha_macroexpand_check_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_macroexpand_check_A_class, reflect.TypeFor[A_arbace_spec_alpha_macroexpand_check_A]()) }

func A_arbace_spec_alpha_map_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_map_of_A).DoInvoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_map_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_map_of_A_New()}; return nil }

func A_arbace_spec_alpha_map_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_map_of_A_fn_class)}; return nil }

var A_arbace_spec_alpha_map_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_map_of_A_invoke, New: A_arbace_spec_alpha_map_of_A_new, Get: A_arbace_spec_alpha_map_of_A_get}

var A_arbace_spec_alpha_map_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$map_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR4_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "map_of", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_map_of_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_map_of_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_map_of_A_InstanceOf; i.Init = A_arbace_spec_alpha_map_of_A_Init; i.Table = A_arbace_spec_alpha_map_of_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_map_of_A_class, reflect.TypeFor[A_arbace_spec_alpha_map_of_A]()) }

func A_arbace_spec_alpha_map_spec_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_map_spec_impl_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_map_spec_impl_A_New()}; return nil }

func A_arbace_spec_alpha_map_spec_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_map_spec_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_map_spec_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_map_spec_impl_A_invoke, New: A_arbace_spec_alpha_map_spec_impl_A_new, Get: A_arbace_spec_alpha_map_spec_impl_A_get}

var A_arbace_spec_alpha_map_spec_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$map_spec_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "map_spec_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_map_spec_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_map_spec_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_map_spec_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_map_spec_impl_A_Init; i.Table = A_arbace_spec_alpha_map_spec_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_map_spec_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_map_spec_impl_A]()) }

func A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_fn_class)}; return nil }

var A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_invoke, New: A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_new, Get: A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_get}

var A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$map_spec_impl$keys__GT_specnames__1740000399", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_map_spec_impl_A_class, Simple: "keys__GT_specnames__1740000399", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_InstanceOf; i.Init = A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_Init; i.Table = A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A_class, reflect.TypeFor[A_arbace_spec_alpha_map_spec_impl_keys__GT_specnames__1740000399_A]()) }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A).Conform_STAR__O__O(args[0]); case 1: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A).Describe_STAR___O(); case 2: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A).Explain_STAR__O_O_O_O__O(args[0], args[1], args[2], args[3]); case 3: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A).Gen_STAR__O_O_O__O(args[0], args[1], args[2]); case 4: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A).Meta__IPersistentMap(); case 5: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A).Specize_STAR___O(); case 6: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A).Specize_STAR__O__O(args[0]); case 7: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A).Unform_STAR__O__O(args[0]); case 8: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 9: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A).With_gen_STAR__O__O(args[0])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_New_IPersistentMap_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11], args[12], args[13], args[14], args[15])}; return nil }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 conform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 describe_STAR_ ()Ljava.lang.Object;\nM1 explain_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 gen_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 specize_STAR_ ()Ljava.lang.Object;\nM1 specize_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 unform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 with_gen_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_invoke, New: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_new}

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$map_spec_impl$reify__1740000401", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{A_arbace_spec_alpha_Specize_A_class, A_arbace_spec_alpha_Spec_A_class, lang.IObj_class}, Declaring: A_arbace_spec_alpha_map_spec_impl_A_class, Simple: "reify__1740000401", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_InstanceOf; i.Table = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_class, reflect.TypeFor[A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A]()) }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_fn_class)}; return nil }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_invoke, New: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_new, Get: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_get}

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000431", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_class, Simple: "fn__1740000431", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_InstanceOf; i.Init = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_Init; i.Table = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A_class, reflect.TypeFor[A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000431_A]()) }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_fn_class)}; return nil }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_invoke, New: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_new, Get: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_get}

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000433", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_class, Simple: "fn__1740000433", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_InstanceOf; i.Init = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_Init; i.Table = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A_class, reflect.TypeFor[A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000433_A]()) }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_fn_class)}; return nil }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_invoke, New: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_new, Get: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_get}

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000436", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_class, Simple: "fn__1740000436", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_InstanceOf; i.Init = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_Init; i.Table = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A_class, reflect.TypeFor[A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000436_A]()) }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_fn_class)}; return nil }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_invoke, New: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_new, Get: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_get}

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000448", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_class, Simple: "fn__1740000448", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_InstanceOf; i.Init = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_Init; i.Table = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_class, reflect.TypeFor[A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A]()) }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_fn_class)}; return nil }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_invoke, New: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_new, Get: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_get}

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$map_spec_impl$reify__1740000401$fn__1740000448$fn__1740000452", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_A_class, Simple: "fn__1740000452", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_InstanceOf; i.Init = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_Init; i.Table = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A_class, reflect.TypeFor[A_arbace_spec_alpha_map_spec_impl_reify__1740000401_fn__1740000448_fn__1740000452_A]()) }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_fn_class)}; return nil }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_invoke, New: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_new, Get: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_get}

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$map_spec_impl$reify__1740000401$ogen__1740000443", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_class, Simple: "ogen__1740000443", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_InstanceOf; i.Init = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_Init; i.Table = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_class, reflect.TypeFor[A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A]()) }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_fn_class)}; return nil }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_invoke, New: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_new, Get: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_get}

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$map_spec_impl$reify__1740000401$ogen__1740000443$fn__1740000444", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_A_class, Simple: "fn__1740000444", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_InstanceOf; i.Init = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_Init; i.Table = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A_class, reflect.TypeFor[A_arbace_spec_alpha_map_spec_impl_reify__1740000401_ogen__1740000443_fn__1740000444_A]()) }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_fn_class)}; return nil }

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_invoke, New: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_new, Get: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_get}

var A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$map_spec_impl$reify__1740000401$rgen__1740000441", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_map_spec_impl_reify__1740000401_A_class, Simple: "rgen__1740000441", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_InstanceOf; i.Init = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_Init; i.Table = A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A_class, reflect.TypeFor[A_arbace_spec_alpha_map_spec_impl_reify__1740000401_rgen__1740000441_A]()) }

func A_arbace_spec_alpha_maybe_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_maybe_impl_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_maybe_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_maybe_impl_A_New()}; return nil }

func A_arbace_spec_alpha_maybe_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_maybe_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_maybe_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_maybe_impl_A_invoke, New: A_arbace_spec_alpha_maybe_impl_A_new, Get: A_arbace_spec_alpha_maybe_impl_A_get}

var A_arbace_spec_alpha_maybe_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$maybe_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "maybe_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_maybe_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_maybe_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_maybe_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_maybe_impl_A_Init; i.Table = A_arbace_spec_alpha_maybe_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_maybe_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_maybe_impl_A]()) }

func A_arbace_spec_alpha_maybe_spec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_maybe_spec_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_maybe_spec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_maybe_spec_A_New()}; return nil }

func A_arbace_spec_alpha_maybe_spec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_maybe_spec_A_fn_class)}; return nil }

var A_arbace_spec_alpha_maybe_spec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_maybe_spec_A_invoke, New: A_arbace_spec_alpha_maybe_spec_A_new, Get: A_arbace_spec_alpha_maybe_spec_A_get}

var A_arbace_spec_alpha_maybe_spec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$maybe_spec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "maybe_spec", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_maybe_spec_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_maybe_spec_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_maybe_spec_A_InstanceOf; i.Init = A_arbace_spec_alpha_maybe_spec_A_Init; i.Table = A_arbace_spec_alpha_maybe_spec_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_maybe_spec_A_class, reflect.TypeFor[A_arbace_spec_alpha_maybe_spec_A]()) }

func A_arbace_spec_alpha_merge_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_merge_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_merge_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_merge_A_New()}; return nil }

func A_arbace_spec_alpha_merge_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_merge_A_fn_class)}; return nil }

var A_arbace_spec_alpha_merge_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_merge_A_invoke, New: A_arbace_spec_alpha_merge_A_new, Get: A_arbace_spec_alpha_merge_A_get}

var A_arbace_spec_alpha_merge_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$merge", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "merge", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_merge_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_merge_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_merge_A_InstanceOf; i.Init = A_arbace_spec_alpha_merge_A_Init; i.Table = A_arbace_spec_alpha_merge_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_merge_A_class, reflect.TypeFor[A_arbace_spec_alpha_merge_A]()) }

func A_arbace_spec_alpha_merge_spec_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_merge_spec_impl_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_merge_spec_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_merge_spec_impl_A_New()}; return nil }

func A_arbace_spec_alpha_merge_spec_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_merge_spec_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_merge_spec_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_merge_spec_impl_A_invoke, New: A_arbace_spec_alpha_merge_spec_impl_A_new, Get: A_arbace_spec_alpha_merge_spec_impl_A_get}

var A_arbace_spec_alpha_merge_spec_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$merge_spec_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "merge_spec_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_merge_spec_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_merge_spec_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_merge_spec_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_merge_spec_impl_A_Init; i.Table = A_arbace_spec_alpha_merge_spec_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_merge_spec_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_merge_spec_impl_A]()) }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A).Conform_STAR__O__O(args[0]); case 1: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A).Describe_STAR___O(); case 2: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A).Explain_STAR__O_O_O_O__O(args[0], args[1], args[2], args[3]); case 3: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A).Gen_STAR__O_O_O__O(args[0], args[1], args[2]); case 4: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A).Meta__IPersistentMap(); case 5: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A).Specize_STAR___O(); case 6: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A).Specize_STAR__O__O(args[0]); case 7: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A).Unform_STAR__O__O(args[0]); case 8: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 9: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A).With_gen_STAR__O__O(args[0])}; return nil }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_New_IPersistentMap_O_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2], args[3])}; return nil }

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 conform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 describe_STAR_ ()Ljava.lang.Object;\nM1 explain_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 gen_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 specize_STAR_ ()Ljava.lang.Object;\nM1 specize_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 unform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 with_gen_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_invoke, New: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_new}

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$merge_spec_impl$reify__1740000591", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{A_arbace_spec_alpha_Specize_A_class, A_arbace_spec_alpha_Spec_A_class, lang.IObj_class}, Declaring: A_arbace_spec_alpha_merge_spec_impl_A_class, Simple: "reify__1740000591", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_InstanceOf; i.Table = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_class, reflect.TypeFor[A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A]()) }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_fn_class)}; return nil }

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_invoke, New: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_new, Get: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_get}

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000592", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_class, Simple: "fn__1740000592", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_InstanceOf; i.Init = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_Init; i.Table = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A_class, reflect.TypeFor[A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000592_A]()) }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_fn_class)}; return nil }

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_invoke, New: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_new, Get: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_get}

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000594", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_class, Simple: "fn__1740000594", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_InstanceOf; i.Init = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_Init; i.Table = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A_class, reflect.TypeFor[A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000594_A]()) }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_fn_class)}; return nil }

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_invoke, New: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_new, Get: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_get}

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000596", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_class, Simple: "fn__1740000596", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_InstanceOf; i.Init = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_Init; i.Table = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A_class, reflect.TypeFor[A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000596_A]()) }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_New()}; return nil }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_fn_class)}; return nil }

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_invoke, New: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_new, Get: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_get}

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000598", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_class, Simple: "fn__1740000598", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_InstanceOf; i.Init = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_Init; i.Table = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A_class, reflect.TypeFor[A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000598_A]()) }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_fn_class)}; return nil }

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_invoke, New: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_new, Get: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_get}

var A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$merge_spec_impl$reify__1740000591$fn__1740000600", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_A_class, Simple: "fn__1740000600", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_InstanceOf; i.Init = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_Init; i.Table = A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A_class, reflect.TypeFor[A_arbace_spec_alpha_merge_spec_impl_reify__1740000591_fn__1740000600_A]()) }

func A_arbace_spec_alpha_multi_spec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_multi_spec_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_multi_spec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_multi_spec_A_New()}; return nil }

func A_arbace_spec_alpha_multi_spec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_multi_spec_A_fn_class)}; return nil }

var A_arbace_spec_alpha_multi_spec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_multi_spec_A_invoke, New: A_arbace_spec_alpha_multi_spec_A_new, Get: A_arbace_spec_alpha_multi_spec_A_get}

var A_arbace_spec_alpha_multi_spec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$multi_spec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "multi_spec", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_multi_spec_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_multi_spec_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_multi_spec_A_InstanceOf; i.Init = A_arbace_spec_alpha_multi_spec_A_Init; i.Table = A_arbace_spec_alpha_multi_spec_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_multi_spec_A_class, reflect.TypeFor[A_arbace_spec_alpha_multi_spec_A]()) }

func A_arbace_spec_alpha_multi_spec_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_multi_spec_impl_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3]); case 1: return this.(*A_arbace_spec_alpha_multi_spec_impl_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_multi_spec_impl_A_New()}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_multi_spec_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_multi_spec_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_multi_spec_impl_A_invoke, New: A_arbace_spec_alpha_multi_spec_impl_A_new, Get: A_arbace_spec_alpha_multi_spec_impl_A_get}

var A_arbace_spec_alpha_multi_spec_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$multi_spec_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class, lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "multi_spec_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_multi_spec_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_multi_spec_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_multi_spec_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_multi_spec_impl_A_Init; i.Table = A_arbace_spec_alpha_multi_spec_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_multi_spec_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_multi_spec_impl_A]()) }

func A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_fn_class)}; return nil }

var A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_invoke, New: A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_new, Get: A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_get}

var A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$multi_spec_impl$dval__1740000470", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_multi_spec_impl_A_class, Simple: "dval__1740000470", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_InstanceOf; i.Init = A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_Init; i.Table = A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A_class, reflect.TypeFor[A_arbace_spec_alpha_multi_spec_impl_dval__1740000470_A]()) }

func A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_fn_class)}; return nil }

var A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_invoke, New: A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_new, Get: A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_get}

var A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$multi_spec_impl$fn__1740000472", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_multi_spec_impl_A_class, Simple: "fn__1740000472", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_InstanceOf; i.Init = A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_Init; i.Table = A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A_class, reflect.TypeFor[A_arbace_spec_alpha_multi_spec_impl_fn__1740000472_A]()) }

func A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_fn_class)}; return nil }

var A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_invoke, New: A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_new, Get: A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_get}

var A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$multi_spec_impl$predx__1740000468", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_multi_spec_impl_A_class, Simple: "predx__1740000468", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_InstanceOf; i.Init = A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_Init; i.Table = A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A_class, reflect.TypeFor[A_arbace_spec_alpha_multi_spec_impl_predx__1740000468_A]()) }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A).Conform_STAR__O__O(args[0]); case 1: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A).Describe_STAR___O(); case 2: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A).Explain_STAR__O_O_O_O__O(args[0], args[1], args[2], args[3]); case 3: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A).Gen_STAR__O_O_O__O(args[0], args[1], args[2]); case 4: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A).Meta__IPersistentMap(); case 5: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A).Specize_STAR___O(); case 6: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A).Specize_STAR__O__O(args[0]); case 7: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A).Unform_STAR__O__O(args[0]); case 8: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 9: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A).With_gen_STAR__O__O(args[0])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_New_IPersistentMap_O_O_O_O_O_O_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8])}; return nil }

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 conform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 describe_STAR_ ()Ljava.lang.Object;\nM1 explain_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 gen_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 specize_STAR_ ()Ljava.lang.Object;\nM1 specize_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 unform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 with_gen_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_invoke, New: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_new}

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$multi_spec_impl$reify__1740000474", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{A_arbace_spec_alpha_Specize_A_class, A_arbace_spec_alpha_Spec_A_class, lang.IObj_class}, Declaring: A_arbace_spec_alpha_multi_spec_impl_A_class, Simple: "reify__1740000474", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_InstanceOf; i.Table = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_class, reflect.TypeFor[A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A]()) }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_New()}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_fn_class)}; return nil }

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_invoke, New: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_new, Get: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_get}

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$multi_spec_impl$reify__1740000474$fn__1740000486", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_class, Simple: "fn__1740000486", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_InstanceOf; i.Init = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_Init; i.Table = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A_class, reflect.TypeFor[A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_fn__1740000486_A]()) }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_fn_class)}; return nil }

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_invoke, New: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_new, Get: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_get}

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$multi_spec_impl$reify__1740000474$gen__1740000476", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_A_class, Simple: "gen__1740000476", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_InstanceOf; i.Init = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_Init; i.Table = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_class, reflect.TypeFor[A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A]()) }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_New_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_fn_class)}; return nil }

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_invoke, New: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_new, Get: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_get}

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$multi_spec_impl$reify__1740000474$gen__1740000476$fn__1740000480", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_A_class, Simple: "fn__1740000480", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_InstanceOf; i.Init = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_Init; i.Table = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_class, reflect.TypeFor[A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A]()) }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_fn_class)}; return nil }

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_invoke, New: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_new, Get: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_get}

var A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$multi_spec_impl$reify__1740000474$gen__1740000476$fn__1740000480$fn__1740000481", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_A_class, Simple: "fn__1740000481", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_InstanceOf; i.Init = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_Init; i.Table = A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A_class, reflect.TypeFor[A_arbace_spec_alpha_multi_spec_impl_reify__1740000474_gen__1740000476_fn__1740000480_fn__1740000481_A]()) }

func A_arbace_spec_alpha_nilable_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_nilable_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_nilable_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_nilable_A_New()}; return nil }

func A_arbace_spec_alpha_nilable_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_nilable_A_fn_class)}; return nil }

var A_arbace_spec_alpha_nilable_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_nilable_A_invoke, New: A_arbace_spec_alpha_nilable_A_new, Get: A_arbace_spec_alpha_nilable_A_get}

var A_arbace_spec_alpha_nilable_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$nilable", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "nilable", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_nilable_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_nilable_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_nilable_A_InstanceOf; i.Init = A_arbace_spec_alpha_nilable_A_Init; i.Table = A_arbace_spec_alpha_nilable_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_nilable_A_class, reflect.TypeFor[A_arbace_spec_alpha_nilable_A]()) }

func A_arbace_spec_alpha_nilable_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_nilable_impl_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_nilable_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_nilable_impl_A_New()}; return nil }

func A_arbace_spec_alpha_nilable_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_nilable_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_nilable_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_nilable_impl_A_invoke, New: A_arbace_spec_alpha_nilable_impl_A_new, Get: A_arbace_spec_alpha_nilable_impl_A_get}

var A_arbace_spec_alpha_nilable_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$nilable_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "nilable_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_nilable_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_nilable_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_nilable_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_nilable_impl_A_Init; i.Table = A_arbace_spec_alpha_nilable_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_nilable_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_nilable_impl_A]()) }

func A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_nilable_impl_fn__1740000890_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_fn_class)}; return nil }

var A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_invoke, New: A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_new, Get: A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_get}

var A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$nilable_impl$fn__1740000890", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_nilable_impl_A_class, Simple: "fn__1740000890", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_nilable_impl_fn__1740000890_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_InstanceOf; i.Init = A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_Init; i.Table = A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_nilable_impl_fn__1740000890_A_class, reflect.TypeFor[A_arbace_spec_alpha_nilable_impl_fn__1740000890_A]()) }

func A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_A).Conform_STAR__O__O(args[0]); case 1: return this.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_A).Describe_STAR___O(); case 2: return this.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_A).Explain_STAR__O_O_O_O__O(args[0], args[1], args[2], args[3]); case 3: return this.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_A).Gen_STAR__O_O_O__O(args[0], args[1], args[2]); case 4: return this.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_A).Meta__IPersistentMap(); case 5: return this.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_A).Specize_STAR___O(); case 6: return this.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_A).Specize_STAR__O__O(args[0]); case 7: return this.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_A).Unform_STAR__O__O(args[0]); case 8: return this.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 9: return this.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_A).With_gen_STAR__O__O(args[0])}; return nil }

func A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_New_IPersistentMap_O_O_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2], args[3], args[4])}; return nil }

var A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 conform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 describe_STAR_ ()Ljava.lang.Object;\nM1 explain_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 gen_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 specize_STAR_ ()Ljava.lang.Object;\nM1 specize_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 unform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 with_gen_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_invoke, New: A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_new}

var A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$nilable_impl$reify__1740000892", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{A_arbace_spec_alpha_Specize_A_class, A_arbace_spec_alpha_Spec_A_class, lang.IObj_class}, Declaring: A_arbace_spec_alpha_nilable_impl_A_class, Simple: "reify__1740000892", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_nilable_impl_reify__1740000892_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_InstanceOf; i.Table = A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_class, reflect.TypeFor[A_arbace_spec_alpha_nilable_impl_reify__1740000892_A]()) }

func A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_New()}; return nil }

func A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_fn_class)}; return nil }

var A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_invoke, New: A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_new, Get: A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_get}

var A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$nilable_impl$reify__1740000892$fn__1740000893", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_class, Simple: "fn__1740000893", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_InstanceOf; i.Init = A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_Init; i.Table = A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A_class, reflect.TypeFor[A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000893_A]()) }

func A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_fn_class)}; return nil }

var A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_invoke, New: A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_new, Get: A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_get}

var A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$nilable_impl$reify__1740000892$fn__1740000895", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_nilable_impl_reify__1740000892_A_class, Simple: "fn__1740000895", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_InstanceOf; i.Init = A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_Init; i.Table = A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A_class, reflect.TypeFor[A_arbace_spec_alpha_nilable_impl_reify__1740000892_fn__1740000895_A]()) }

func A_arbace_spec_alpha_nonconforming_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_nonconforming_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_nonconforming_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_nonconforming_A_New()}; return nil }

func A_arbace_spec_alpha_nonconforming_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_nonconforming_A_fn_class)}; return nil }

var A_arbace_spec_alpha_nonconforming_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_nonconforming_A_invoke, New: A_arbace_spec_alpha_nonconforming_A_new, Get: A_arbace_spec_alpha_nonconforming_A_get}

var A_arbace_spec_alpha_nonconforming_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$nonconforming", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "nonconforming", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_nonconforming_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_nonconforming_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_nonconforming_A_InstanceOf; i.Init = A_arbace_spec_alpha_nonconforming_A_Init; i.Table = A_arbace_spec_alpha_nonconforming_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_nonconforming_A_class, reflect.TypeFor[A_arbace_spec_alpha_nonconforming_A]()) }

func A_arbace_spec_alpha_nonconforming_fn__1740000885_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_nonconforming_fn__1740000885_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_nonconforming_fn__1740000885_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_nonconforming_fn__1740000885_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_nonconforming_fn__1740000885_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_nonconforming_fn__1740000885_A_fn_class)}; return nil }

var A_arbace_spec_alpha_nonconforming_fn__1740000885_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_nonconforming_fn__1740000885_A_invoke, New: A_arbace_spec_alpha_nonconforming_fn__1740000885_A_new, Get: A_arbace_spec_alpha_nonconforming_fn__1740000885_A_get}

var A_arbace_spec_alpha_nonconforming_fn__1740000885_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$nonconforming$fn__1740000885", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_nonconforming_A_class, Simple: "fn__1740000885", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_nonconforming_fn__1740000885_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_nonconforming_fn__1740000885_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_nonconforming_fn__1740000885_A_InstanceOf; i.Init = A_arbace_spec_alpha_nonconforming_fn__1740000885_A_Init; i.Table = A_arbace_spec_alpha_nonconforming_fn__1740000885_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_nonconforming_fn__1740000885_A_class, reflect.TypeFor[A_arbace_spec_alpha_nonconforming_fn__1740000885_A]()) }

func A_arbace_spec_alpha_nonconforming_reify__1740000887_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_nonconforming_reify__1740000887_A).Conform_STAR__O__O(args[0]); case 1: return this.(*A_arbace_spec_alpha_nonconforming_reify__1740000887_A).Describe_STAR___O(); case 2: return this.(*A_arbace_spec_alpha_nonconforming_reify__1740000887_A).Explain_STAR__O_O_O_O__O(args[0], args[1], args[2], args[3]); case 3: return this.(*A_arbace_spec_alpha_nonconforming_reify__1740000887_A).Gen_STAR__O_O_O__O(args[0], args[1], args[2]); case 4: return this.(*A_arbace_spec_alpha_nonconforming_reify__1740000887_A).Meta__IPersistentMap(); case 5: return this.(*A_arbace_spec_alpha_nonconforming_reify__1740000887_A).Specize_STAR___O(); case 6: return this.(*A_arbace_spec_alpha_nonconforming_reify__1740000887_A).Specize_STAR__O__O(args[0]); case 7: return this.(*A_arbace_spec_alpha_nonconforming_reify__1740000887_A).Unform_STAR__O__O(args[0]); case 8: return this.(*A_arbace_spec_alpha_nonconforming_reify__1740000887_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 9: return this.(*A_arbace_spec_alpha_nonconforming_reify__1740000887_A).With_gen_STAR__O__O(args[0])}; return nil }

func A_arbace_spec_alpha_nonconforming_reify__1740000887_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_nonconforming_reify__1740000887_A_New_IPersistentMap_O(jrt.As[lang.IPersistentMap](args[0]), args[1])}; return nil }

var A_arbace_spec_alpha_nonconforming_reify__1740000887_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 conform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 describe_STAR_ ()Ljava.lang.Object;\nM1 explain_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 gen_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 specize_STAR_ ()Ljava.lang.Object;\nM1 specize_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 unform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 with_gen_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;)V", Invoke: A_arbace_spec_alpha_nonconforming_reify__1740000887_A_invoke, New: A_arbace_spec_alpha_nonconforming_reify__1740000887_A_new}

var A_arbace_spec_alpha_nonconforming_reify__1740000887_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$nonconforming$reify__1740000887", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{A_arbace_spec_alpha_Specize_A_class, A_arbace_spec_alpha_Spec_A_class, lang.IObj_class}, Declaring: A_arbace_spec_alpha_nonconforming_A_class, Simple: "reify__1740000887", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_nonconforming_reify__1740000887_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_nonconforming_reify__1740000887_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_nonconforming_reify__1740000887_A_InstanceOf; i.Table = A_arbace_spec_alpha_nonconforming_reify__1740000887_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_nonconforming_reify__1740000887_A_class, reflect.TypeFor[A_arbace_spec_alpha_nonconforming_reify__1740000887_A]()) }

func A_arbace_spec_alpha_noret_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_noret_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_noret_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_noret_QMARK__A_New()}; return nil }

func A_arbace_spec_alpha_noret_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_noret_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha_noret_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_noret_QMARK__A_invoke, New: A_arbace_spec_alpha_noret_QMARK__A_new, Get: A_arbace_spec_alpha_noret_QMARK__A_get}

var A_arbace_spec_alpha_noret_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$noret_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "noret_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_noret_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_noret_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_noret_QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha_noret_QMARK__A_Init; i.Table = A_arbace_spec_alpha_noret_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_noret_QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha_noret_QMARK__A]()) }

func A_arbace_spec_alpha_ns_qualify_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_ns_qualify_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_ns_qualify_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_ns_qualify_A_New()}; return nil }

func A_arbace_spec_alpha_ns_qualify_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_ns_qualify_A_fn_class)}; return nil }

var A_arbace_spec_alpha_ns_qualify_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_ns_qualify_A_invoke, New: A_arbace_spec_alpha_ns_qualify_A_new, Get: A_arbace_spec_alpha_ns_qualify_A_get}

var A_arbace_spec_alpha_ns_qualify_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$ns_qualify", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "ns_qualify", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_ns_qualify_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_ns_qualify_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_ns_qualify_A_InstanceOf; i.Init = A_arbace_spec_alpha_ns_qualify_A_Init; i.Table = A_arbace_spec_alpha_ns_qualify_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_ns_qualify_A_class, reflect.TypeFor[A_arbace_spec_alpha_ns_qualify_A]()) }

func A_arbace_spec_alpha_op_describe_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_op_describe_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_op_describe_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_op_describe_A_New()}; return nil }

func A_arbace_spec_alpha_op_describe_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_op_describe_A_fn_class)}; return nil }

var A_arbace_spec_alpha_op_describe_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_op_describe_A_invoke, New: A_arbace_spec_alpha_op_describe_A_new, Get: A_arbace_spec_alpha_op_describe_A_get}

var A_arbace_spec_alpha_op_describe_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$op_describe", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "op_describe", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_op_describe_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_op_describe_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_op_describe_A_InstanceOf; i.Init = A_arbace_spec_alpha_op_describe_A_Init; i.Table = A_arbace_spec_alpha_op_describe_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_op_describe_A_class, reflect.TypeFor[A_arbace_spec_alpha_op_describe_A]()) }

func A_arbace_spec_alpha_op_explain_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_op_explain_A).Invoke_O_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5], args[6])}; return nil }

func A_arbace_spec_alpha_op_explain_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_op_explain_A_New()}; return nil }

func A_arbace_spec_alpha_op_explain_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_op_explain_A_fn_class)}; return nil }

var A_arbace_spec_alpha_op_explain_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_op_explain_A_invoke, New: A_arbace_spec_alpha_op_explain_A_new, Get: A_arbace_spec_alpha_op_explain_A_get}

var A_arbace_spec_alpha_op_explain_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$op_explain", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF6_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "op_explain", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_op_explain_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_op_explain_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_op_explain_A_InstanceOf; i.Init = A_arbace_spec_alpha_op_explain_A_Init; i.Table = A_arbace_spec_alpha_op_explain_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_op_explain_A_class, reflect.TypeFor[A_arbace_spec_alpha_op_explain_A]()) }

func A_arbace_spec_alpha_op_explain_fn__1740000806_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_op_explain_fn__1740000806_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_op_explain_fn__1740000806_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_op_explain_fn__1740000806_A_New()}; return nil }

func A_arbace_spec_alpha_op_explain_fn__1740000806_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_op_explain_fn__1740000806_A_fn_class)}; return nil }

var A_arbace_spec_alpha_op_explain_fn__1740000806_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_op_explain_fn__1740000806_A_invoke, New: A_arbace_spec_alpha_op_explain_fn__1740000806_A_new, Get: A_arbace_spec_alpha_op_explain_fn__1740000806_A_get}

var A_arbace_spec_alpha_op_explain_fn__1740000806_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$op_explain$fn__1740000806", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_op_explain_A_class, Simple: "fn__1740000806", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_op_explain_fn__1740000806_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_op_explain_fn__1740000806_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_op_explain_fn__1740000806_A_InstanceOf; i.Init = A_arbace_spec_alpha_op_explain_fn__1740000806_A_Init; i.Table = A_arbace_spec_alpha_op_explain_fn__1740000806_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_op_explain_fn__1740000806_A_class, reflect.TypeFor[A_arbace_spec_alpha_op_explain_fn__1740000806_A]()) }

func A_arbace_spec_alpha_op_explain_fn__1740000811_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_op_explain_fn__1740000811_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_op_explain_fn__1740000811_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_op_explain_fn__1740000811_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_op_explain_fn__1740000811_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_op_explain_fn__1740000811_A_fn_class)}; return nil }

var A_arbace_spec_alpha_op_explain_fn__1740000811_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_op_explain_fn__1740000811_A_invoke, New: A_arbace_spec_alpha_op_explain_fn__1740000811_A_new, Get: A_arbace_spec_alpha_op_explain_fn__1740000811_A_get}

var A_arbace_spec_alpha_op_explain_fn__1740000811_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$op_explain$fn__1740000811", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_op_explain_A_class, Simple: "fn__1740000811", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_op_explain_fn__1740000811_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_op_explain_fn__1740000811_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_op_explain_fn__1740000811_A_InstanceOf; i.Init = A_arbace_spec_alpha_op_explain_fn__1740000811_A_Init; i.Table = A_arbace_spec_alpha_op_explain_fn__1740000811_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_op_explain_fn__1740000811_A_class, reflect.TypeFor[A_arbace_spec_alpha_op_explain_fn__1740000811_A]()) }

func A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_op_explain_insufficient__1740000799_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_fn_class)}; return nil }

var A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_invoke, New: A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_new, Get: A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_get}

var A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$op_explain$insufficient__1740000799", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_op_explain_A_class, Simple: "insufficient__1740000799", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_op_explain_insufficient__1740000799_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_InstanceOf; i.Init = A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_Init; i.Table = A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_op_explain_insufficient__1740000799_A_class, reflect.TypeFor[A_arbace_spec_alpha_op_explain_insufficient__1740000799_A]()) }

func A_arbace_spec_alpha_op_unform_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_op_unform_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_op_unform_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_op_unform_A_New()}; return nil }

func A_arbace_spec_alpha_op_unform_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_op_unform_A_fn_class)}; return nil }

var A_arbace_spec_alpha_op_unform_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_op_unform_A_invoke, New: A_arbace_spec_alpha_op_unform_A_new, Get: A_arbace_spec_alpha_op_unform_A_get}

var A_arbace_spec_alpha_op_unform_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$op_unform", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "op_unform", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_op_unform_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_op_unform_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_op_unform_A_InstanceOf; i.Init = A_arbace_spec_alpha_op_unform_A_Init; i.Table = A_arbace_spec_alpha_op_unform_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_op_unform_A_class, reflect.TypeFor[A_arbace_spec_alpha_op_unform_A]()) }

func A_arbace_spec_alpha_op_unform_fn__1740000759_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_op_unform_fn__1740000759_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_op_unform_fn__1740000759_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_op_unform_fn__1740000759_A_New()}; return nil }

func A_arbace_spec_alpha_op_unform_fn__1740000759_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_op_unform_fn__1740000759_A_fn_class)}; return nil }

var A_arbace_spec_alpha_op_unform_fn__1740000759_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_op_unform_fn__1740000759_A_invoke, New: A_arbace_spec_alpha_op_unform_fn__1740000759_A_new, Get: A_arbace_spec_alpha_op_unform_fn__1740000759_A_get}

var A_arbace_spec_alpha_op_unform_fn__1740000759_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$op_unform$fn__1740000759", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_op_unform_A_class, Simple: "fn__1740000759", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_op_unform_fn__1740000759_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_op_unform_fn__1740000759_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_op_unform_fn__1740000759_A_InstanceOf; i.Init = A_arbace_spec_alpha_op_unform_fn__1740000759_A_Init; i.Table = A_arbace_spec_alpha_op_unform_fn__1740000759_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_op_unform_fn__1740000759_A_class, reflect.TypeFor[A_arbace_spec_alpha_op_unform_fn__1740000759_A]()) }

func A_arbace_spec_alpha_op_unform_fn__1740000761_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_op_unform_fn__1740000761_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_op_unform_fn__1740000761_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_op_unform_fn__1740000761_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_op_unform_fn__1740000761_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_op_unform_fn__1740000761_A_fn_class)}; return nil }

var A_arbace_spec_alpha_op_unform_fn__1740000761_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_op_unform_fn__1740000761_A_invoke, New: A_arbace_spec_alpha_op_unform_fn__1740000761_A_new, Get: A_arbace_spec_alpha_op_unform_fn__1740000761_A_get}

var A_arbace_spec_alpha_op_unform_fn__1740000761_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$op_unform$fn__1740000761", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_op_unform_A_class, Simple: "fn__1740000761", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_op_unform_fn__1740000761_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_op_unform_fn__1740000761_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_op_unform_fn__1740000761_A_InstanceOf; i.Init = A_arbace_spec_alpha_op_unform_fn__1740000761_A_Init; i.Table = A_arbace_spec_alpha_op_unform_fn__1740000761_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_op_unform_fn__1740000761_A_class, reflect.TypeFor[A_arbace_spec_alpha_op_unform_fn__1740000761_A]()) }

func A_arbace_spec_alpha_op_unform_fn__1740000763_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_op_unform_fn__1740000763_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_op_unform_fn__1740000763_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_op_unform_fn__1740000763_A_New_O(args[0])}; return nil }

func A_arbace_spec_alpha_op_unform_fn__1740000763_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_op_unform_fn__1740000763_A_fn_class)}; return nil }

var A_arbace_spec_alpha_op_unform_fn__1740000763_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_op_unform_fn__1740000763_A_invoke, New: A_arbace_spec_alpha_op_unform_fn__1740000763_A_new, Get: A_arbace_spec_alpha_op_unform_fn__1740000763_A_get}

var A_arbace_spec_alpha_op_unform_fn__1740000763_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$op_unform$fn__1740000763", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_op_unform_A_class, Simple: "fn__1740000763", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_op_unform_fn__1740000763_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_op_unform_fn__1740000763_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_op_unform_fn__1740000763_A_InstanceOf; i.Init = A_arbace_spec_alpha_op_unform_fn__1740000763_A_Init; i.Table = A_arbace_spec_alpha_op_unform_fn__1740000763_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_op_unform_fn__1740000763_A_class, reflect.TypeFor[A_arbace_spec_alpha_op_unform_fn__1740000763_A]()) }

func A_arbace_spec_alpha_op_unform_fn__1740000765_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_op_unform_fn__1740000765_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_op_unform_fn__1740000765_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_op_unform_fn__1740000765_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_op_unform_fn__1740000765_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_op_unform_fn__1740000765_A_fn_class)}; return nil }

var A_arbace_spec_alpha_op_unform_fn__1740000765_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_op_unform_fn__1740000765_A_invoke, New: A_arbace_spec_alpha_op_unform_fn__1740000765_A_new, Get: A_arbace_spec_alpha_op_unform_fn__1740000765_A_get}

var A_arbace_spec_alpha_op_unform_fn__1740000765_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$op_unform$fn__1740000765", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_op_unform_A_class, Simple: "fn__1740000765", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_op_unform_fn__1740000765_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_op_unform_fn__1740000765_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_op_unform_fn__1740000765_A_InstanceOf; i.Init = A_arbace_spec_alpha_op_unform_fn__1740000765_A_Init; i.Table = A_arbace_spec_alpha_op_unform_fn__1740000765_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_op_unform_fn__1740000765_A_class, reflect.TypeFor[A_arbace_spec_alpha_op_unform_fn__1740000765_A]()) }

func A_arbace_spec_alpha_or_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_or_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_or_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_or_A_New()}; return nil }

func A_arbace_spec_alpha_or_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_or_A_fn_class)}; return nil }

var A_arbace_spec_alpha_or_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_or_A_invoke, New: A_arbace_spec_alpha_or_A_new, Get: A_arbace_spec_alpha_or_A_get}

var A_arbace_spec_alpha_or_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$or", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "or", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_or_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_or_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_or_A_InstanceOf; i.Init = A_arbace_spec_alpha_or_A_Init; i.Table = A_arbace_spec_alpha_or_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_or_A_class, reflect.TypeFor[A_arbace_spec_alpha_or_A]()) }

func A_arbace_spec_alpha_or_k_gen_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_or_k_gen_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_spec_alpha_or_k_gen_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_or_k_gen_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_or_k_gen_A_New()}; return nil }

func A_arbace_spec_alpha_or_k_gen_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_or_k_gen_A_fn_class)}; return nil }

var A_arbace_spec_alpha_or_k_gen_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_or_k_gen_A_invoke, New: A_arbace_spec_alpha_or_k_gen_A_new, Get: A_arbace_spec_alpha_or_k_gen_A_get}

var A_arbace_spec_alpha_or_k_gen_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$or_k_gen", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "or_k_gen", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_or_k_gen_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_or_k_gen_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_or_k_gen_A_InstanceOf; i.Init = A_arbace_spec_alpha_or_k_gen_A_Init; i.Table = A_arbace_spec_alpha_or_k_gen_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_or_k_gen_A_class, reflect.TypeFor[A_arbace_spec_alpha_or_k_gen_A]()) }

func A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_or_k_gen_fn__1740000386_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_New()}; return nil }

func A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_fn_class)}; return nil }

var A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_invoke, New: A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_new, Get: A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_get}

var A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$or_k_gen$fn__1740000386", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_or_k_gen_A_class, Simple: "fn__1740000386", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_or_k_gen_fn__1740000386_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_InstanceOf; i.Init = A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_Init; i.Table = A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_or_k_gen_fn__1740000386_A_class, reflect.TypeFor[A_arbace_spec_alpha_or_k_gen_fn__1740000386_A]()) }

func A_arbace_spec_alpha_or_spec_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_or_spec_impl_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_or_spec_impl_A_New()}; return nil }

func A_arbace_spec_alpha_or_spec_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_or_spec_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_or_spec_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_or_spec_impl_A_invoke, New: A_arbace_spec_alpha_or_spec_impl_A_new, Get: A_arbace_spec_alpha_or_spec_impl_A_get}

var A_arbace_spec_alpha_or_spec_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$or_spec_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "or_spec_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_or_spec_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_or_spec_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_or_spec_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_or_spec_impl_A_Init; i.Table = A_arbace_spec_alpha_or_spec_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_or_spec_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_or_spec_impl_A]()) }

func A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_fn_class)}; return nil }

var A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_invoke, New: A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_new, Get: A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_get}

var A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$or_spec_impl$fn__1740000503", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_or_spec_impl_A_class, Simple: "fn__1740000503", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_InstanceOf; i.Init = A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_Init; i.Table = A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A_class, reflect.TypeFor[A_arbace_spec_alpha_or_spec_impl_fn__1740000503_A]()) }

func A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_fn_class)}; return nil }

var A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_invoke, New: A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_new, Get: A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_get}

var A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$or_spec_impl$fn__1740000506", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_or_spec_impl_A_class, Simple: "fn__1740000506", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_InstanceOf; i.Init = A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_Init; i.Table = A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A_class, reflect.TypeFor[A_arbace_spec_alpha_or_spec_impl_fn__1740000506_A]()) }

func A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_fn_class)}; return nil }

var A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_invoke, New: A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_new, Get: A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_get}

var A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$or_spec_impl$fn__1740000508", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_or_spec_impl_A_class, Simple: "fn__1740000508", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_InstanceOf; i.Init = A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_Init; i.Table = A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A_class, reflect.TypeFor[A_arbace_spec_alpha_or_spec_impl_fn__1740000508_A]()) }

func A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_fn_class)}; return nil }

var A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_invoke, New: A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_new, Get: A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_get}

var A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$or_spec_impl$fn__1740000510", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_or_spec_impl_A_class, Simple: "fn__1740000510", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_InstanceOf; i.Init = A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_Init; i.Table = A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A_class, reflect.TypeFor[A_arbace_spec_alpha_or_spec_impl_fn__1740000510_A]()) }

func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A).Conform_STAR__O__O(args[0]); case 1: return this.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A).Describe_STAR___O(); case 2: return this.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A).Explain_STAR__O_O_O_O__O(args[0], args[1], args[2], args[3]); case 3: return this.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A).Gen_STAR__O_O_O__O(args[0], args[1], args[2]); case 4: return this.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A).Meta__IPersistentMap(); case 5: return this.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A).Specize_STAR___O(); case 6: return this.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A).Specize_STAR__O__O(args[0]); case 7: return this.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A).Unform_STAR__O__O(args[0]); case 8: return this.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 9: return this.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A).With_gen_STAR__O__O(args[0])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_New_IPersistentMap_O_O_O_O_O_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2], args[3], args[4], args[5], args[6], args[7])}; return nil }

var A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 conform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 describe_STAR_ ()Ljava.lang.Object;\nM1 explain_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 gen_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 specize_STAR_ ()Ljava.lang.Object;\nM1 specize_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 unform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 with_gen_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_invoke, New: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_new}

var A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$or_spec_impl$reify__1740000513", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{A_arbace_spec_alpha_Specize_A_class, A_arbace_spec_alpha_Spec_A_class, lang.IObj_class}, Declaring: A_arbace_spec_alpha_or_spec_impl_A_class, Simple: "reify__1740000513", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_InstanceOf; i.Table = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_class, reflect.TypeFor[A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A]()) }

func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_fn_class)}; return nil }

var A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_invoke, New: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_new, Get: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_get}

var A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$or_spec_impl$reify__1740000513$fn__1740000517", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_class, Simple: "fn__1740000517", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_InstanceOf; i.Init = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_Init; i.Table = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A_class, reflect.TypeFor[A_arbace_spec_alpha_or_spec_impl_reify__1740000513_fn__1740000517_A]()) }

func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_fn_class)}; return nil }

var A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_invoke, New: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_new, Get: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_get}

var A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$or_spec_impl$reify__1740000513$gen__1740000519", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_A_class, Simple: "gen__1740000519", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_InstanceOf; i.Init = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_Init; i.Table = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_class, reflect.TypeFor[A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A]()) }

func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_fn_class)}; return nil }

var A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_invoke, New: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_new, Get: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_get}

var A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$or_spec_impl$reify__1740000513$gen__1740000519$fn__1740000520", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_A_class, Simple: "fn__1740000520", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_InstanceOf; i.Init = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_Init; i.Table = A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A_class, reflect.TypeFor[A_arbace_spec_alpha_or_spec_impl_reify__1740000513_gen__1740000519_fn__1740000520_A]()) }

func A_arbace_spec_alpha_pcat_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_pcat_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_pcat_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_pcat_A_New()}; return nil }

func A_arbace_spec_alpha_pcat_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_pcat_A_fn_class)}; return nil }

var A_arbace_spec_alpha_pcat_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_pcat_A_invoke, New: A_arbace_spec_alpha_pcat_A_new, Get: A_arbace_spec_alpha_pcat_A_get}

var A_arbace_spec_alpha_pcat_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$pcat", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "pcat", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_pcat_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_pcat_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_pcat_A_InstanceOf; i.Init = A_arbace_spec_alpha_pcat_A_Init; i.Table = A_arbace_spec_alpha_pcat_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_pcat_A_class, reflect.TypeFor[A_arbace_spec_alpha_pcat_A]()) }

func A_arbace_spec_alpha_pcat_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_pcat_STAR__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_pcat_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_pcat_STAR__A_New()}; return nil }

func A_arbace_spec_alpha_pcat_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_pcat_STAR__A_fn_class)}; return nil }

var A_arbace_spec_alpha_pcat_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_pcat_STAR__A_invoke, New: A_arbace_spec_alpha_pcat_STAR__A_new, Get: A_arbace_spec_alpha_pcat_STAR__A_get}

var A_arbace_spec_alpha_pcat_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$pcat_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "pcat_STAR_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_pcat_STAR__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_pcat_STAR__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_pcat_STAR__A_InstanceOf; i.Init = A_arbace_spec_alpha_pcat_STAR__A_Init; i.Table = A_arbace_spec_alpha_pcat_STAR__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_pcat_STAR__A_class, reflect.TypeFor[A_arbace_spec_alpha_pcat_STAR__A]()) }

func A_arbace_spec_alpha_preturn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_preturn_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_preturn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_preturn_A_New()}; return nil }

func A_arbace_spec_alpha_preturn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_preturn_A_fn_class)}; return nil }

var A_arbace_spec_alpha_preturn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_preturn_A_invoke, New: A_arbace_spec_alpha_preturn_A_new, Get: A_arbace_spec_alpha_preturn_A_get}

var A_arbace_spec_alpha_preturn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$preturn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "preturn", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_preturn_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_preturn_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_preturn_A_InstanceOf; i.Init = A_arbace_spec_alpha_preturn_A_Init; i.Table = A_arbace_spec_alpha_preturn_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_preturn_A_class, reflect.TypeFor[A_arbace_spec_alpha_preturn_A]()) }

func A_arbace_spec_alpha_pvalid_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_pvalid_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_spec_alpha_pvalid_QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_pvalid_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_pvalid_QMARK__A_New()}; return nil }

func A_arbace_spec_alpha_pvalid_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_pvalid_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha_pvalid_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_pvalid_QMARK__A_invoke, New: A_arbace_spec_alpha_pvalid_QMARK__A_new, Get: A_arbace_spec_alpha_pvalid_QMARK__A_get}

var A_arbace_spec_alpha_pvalid_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$pvalid_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "pvalid_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_pvalid_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_pvalid_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_pvalid_QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha_pvalid_QMARK__A_Init; i.Table = A_arbace_spec_alpha_pvalid_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_pvalid_QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha_pvalid_QMARK__A]()) }

func A_arbace_spec_alpha_re_conform_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_re_conform_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_re_conform_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_re_conform_A_New()}; return nil }

func A_arbace_spec_alpha_re_conform_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_re_conform_A_fn_class)}; return nil }

var A_arbace_spec_alpha_re_conform_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_re_conform_A_invoke, New: A_arbace_spec_alpha_re_conform_A_new, Get: A_arbace_spec_alpha_re_conform_A_get}

var A_arbace_spec_alpha_re_conform_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$re_conform", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "re_conform", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_re_conform_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_re_conform_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_re_conform_A_InstanceOf; i.Init = A_arbace_spec_alpha_re_conform_A_Init; i.Table = A_arbace_spec_alpha_re_conform_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_re_conform_A_class, reflect.TypeFor[A_arbace_spec_alpha_re_conform_A]()) }

func A_arbace_spec_alpha_re_explain_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_re_explain_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_re_explain_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_re_explain_A_New()}; return nil }

func A_arbace_spec_alpha_re_explain_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_re_explain_A_fn_class)}; return nil }

var A_arbace_spec_alpha_re_explain_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_re_explain_A_invoke, New: A_arbace_spec_alpha_re_explain_A_new, Get: A_arbace_spec_alpha_re_explain_A_get}

var A_arbace_spec_alpha_re_explain_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$re_explain", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "re_explain", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_re_explain_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_re_explain_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_re_explain_A_InstanceOf; i.Init = A_arbace_spec_alpha_re_explain_A_Init; i.Table = A_arbace_spec_alpha_re_explain_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_re_explain_A_class, reflect.TypeFor[A_arbace_spec_alpha_re_explain_A]()) }

func A_arbace_spec_alpha_re_gen_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_re_gen_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_re_gen_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_re_gen_A_New()}; return nil }

func A_arbace_spec_alpha_re_gen_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_re_gen_A_fn_class)}; return nil }

var A_arbace_spec_alpha_re_gen_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_re_gen_A_invoke, New: A_arbace_spec_alpha_re_gen_A_new, Get: A_arbace_spec_alpha_re_gen_A_get}

var A_arbace_spec_alpha_re_gen_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$re_gen", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "re_gen", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_re_gen_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_re_gen_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_re_gen_A_InstanceOf; i.Init = A_arbace_spec_alpha_re_gen_A_Init; i.Table = A_arbace_spec_alpha_re_gen_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_re_gen_A_class, reflect.TypeFor[A_arbace_spec_alpha_re_gen_A]()) }

func A_arbace_spec_alpha_re_gen_fn__1740000825_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_re_gen_fn__1740000825_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_re_gen_fn__1740000825_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_re_gen_fn__1740000825_A_New()}; return nil }

func A_arbace_spec_alpha_re_gen_fn__1740000825_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_re_gen_fn__1740000825_A_fn_class)}; return nil }

var A_arbace_spec_alpha_re_gen_fn__1740000825_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_re_gen_fn__1740000825_A_invoke, New: A_arbace_spec_alpha_re_gen_fn__1740000825_A_new, Get: A_arbace_spec_alpha_re_gen_fn__1740000825_A_get}

var A_arbace_spec_alpha_re_gen_fn__1740000825_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$re_gen$fn__1740000825", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_re_gen_A_class, Simple: "fn__1740000825", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_re_gen_fn__1740000825_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_re_gen_fn__1740000825_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_re_gen_fn__1740000825_A_InstanceOf; i.Init = A_arbace_spec_alpha_re_gen_fn__1740000825_A_Init; i.Table = A_arbace_spec_alpha_re_gen_fn__1740000825_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_re_gen_fn__1740000825_A_class, reflect.TypeFor[A_arbace_spec_alpha_re_gen_fn__1740000825_A]()) }

func A_arbace_spec_alpha_re_gen_ggens__1740000817_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_re_gen_ggens__1740000817_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_re_gen_ggens__1740000817_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_re_gen_ggens__1740000817_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_re_gen_ggens__1740000817_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_re_gen_ggens__1740000817_A_fn_class)}; return nil }

var A_arbace_spec_alpha_re_gen_ggens__1740000817_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_re_gen_ggens__1740000817_A_invoke, New: A_arbace_spec_alpha_re_gen_ggens__1740000817_A_new, Get: A_arbace_spec_alpha_re_gen_ggens__1740000817_A_get}

var A_arbace_spec_alpha_re_gen_ggens__1740000817_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$re_gen$ggens__1740000817", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_re_gen_A_class, Simple: "ggens__1740000817", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_re_gen_ggens__1740000817_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_re_gen_ggens__1740000817_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_re_gen_ggens__1740000817_A_InstanceOf; i.Init = A_arbace_spec_alpha_re_gen_ggens__1740000817_A_Init; i.Table = A_arbace_spec_alpha_re_gen_ggens__1740000817_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_re_gen_ggens__1740000817_A_class, reflect.TypeFor[A_arbace_spec_alpha_re_gen_ggens__1740000817_A]()) }

func A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_fn_class)}; return nil }

var A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_invoke, New: A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_new, Get: A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_get}

var A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$re_gen$ggens__1740000817$gen__1740000818", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_re_gen_ggens__1740000817_A_class, Simple: "gen__1740000818", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_InstanceOf; i.Init = A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_Init; i.Table = A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_class, reflect.TypeFor[A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A]()) }

func A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_fn_class)}; return nil }

var A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_invoke, New: A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_new, Get: A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_get}

var A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$re_gen$ggens__1740000817$gen__1740000818$fn__1740000819", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_A_class, Simple: "fn__1740000819", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_InstanceOf; i.Init = A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_Init; i.Table = A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A_class, reflect.TypeFor[A_arbace_spec_alpha_re_gen_ggens__1740000817_gen__1740000818_fn__1740000819_A]()) }

func A_arbace_spec_alpha_recur_limit_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_recur_limit_QMARK__A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_recur_limit_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_recur_limit_QMARK__A_New()}; return nil }

func A_arbace_spec_alpha_recur_limit_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_recur_limit_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha_recur_limit_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_recur_limit_QMARK__A_invoke, New: A_arbace_spec_alpha_recur_limit_QMARK__A_new, Get: A_arbace_spec_alpha_recur_limit_QMARK__A_get}

var A_arbace_spec_alpha_recur_limit_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$recur_limit_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "recur_limit_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_recur_limit_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_recur_limit_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_recur_limit_QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha_recur_limit_QMARK__A_Init; i.Table = A_arbace_spec_alpha_recur_limit_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_recur_limit_QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha_recur_limit_QMARK__A]()) }

func A_arbace_spec_alpha_reg_resolve_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_reg_resolve_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_reg_resolve_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_reg_resolve_A_New()}; return nil }

func A_arbace_spec_alpha_reg_resolve_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_reg_resolve_A_fn_class)}; return nil }

var A_arbace_spec_alpha_reg_resolve_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_reg_resolve_A_invoke, New: A_arbace_spec_alpha_reg_resolve_A_new, Get: A_arbace_spec_alpha_reg_resolve_A_get}

var A_arbace_spec_alpha_reg_resolve_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$reg_resolve", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "reg_resolve", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_reg_resolve_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_reg_resolve_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_reg_resolve_A_InstanceOf; i.Init = A_arbace_spec_alpha_reg_resolve_A_Init; i.Table = A_arbace_spec_alpha_reg_resolve_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_reg_resolve_A_class, reflect.TypeFor[A_arbace_spec_alpha_reg_resolve_A]()) }

func A_arbace_spec_alpha_reg_resolve_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_reg_resolve_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_reg_resolve_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_reg_resolve_BANG__A_New()}; return nil }

func A_arbace_spec_alpha_reg_resolve_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_reg_resolve_BANG__A_fn_class)}; return nil }

var A_arbace_spec_alpha_reg_resolve_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_reg_resolve_BANG__A_invoke, New: A_arbace_spec_alpha_reg_resolve_BANG__A_new, Get: A_arbace_spec_alpha_reg_resolve_BANG__A_get}

var A_arbace_spec_alpha_reg_resolve_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$reg_resolve_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "reg_resolve_BANG_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_reg_resolve_BANG__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_reg_resolve_BANG__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_reg_resolve_BANG__A_InstanceOf; i.Init = A_arbace_spec_alpha_reg_resolve_BANG__A_Init; i.Table = A_arbace_spec_alpha_reg_resolve_BANG__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_reg_resolve_BANG__A_class, reflect.TypeFor[A_arbace_spec_alpha_reg_resolve_BANG__A]()) }

func A_arbace_spec_alpha_regex_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_regex_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_regex_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_regex_QMARK__A_New()}; return nil }

func A_arbace_spec_alpha_regex_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_regex_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha_regex_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_regex_QMARK__A_invoke, New: A_arbace_spec_alpha_regex_QMARK__A_new, Get: A_arbace_spec_alpha_regex_QMARK__A_get}

var A_arbace_spec_alpha_regex_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$regex_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "regex_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_regex_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_regex_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_regex_QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha_regex_QMARK__A_Init; i.Table = A_arbace_spec_alpha_regex_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_regex_QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha_regex_QMARK__A]()) }

func A_arbace_spec_alpha_regex_spec_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_regex_spec_impl_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_regex_spec_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_regex_spec_impl_A_New()}; return nil }

func A_arbace_spec_alpha_regex_spec_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_regex_spec_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_regex_spec_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_regex_spec_impl_A_invoke, New: A_arbace_spec_alpha_regex_spec_impl_A_new, Get: A_arbace_spec_alpha_regex_spec_impl_A_get}

var A_arbace_spec_alpha_regex_spec_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$regex_spec_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "regex_spec_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_regex_spec_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_regex_spec_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_regex_spec_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_regex_spec_impl_A_Init; i.Table = A_arbace_spec_alpha_regex_spec_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_regex_spec_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_regex_spec_impl_A]()) }

func A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A).Conform_STAR__O__O(args[0]); case 1: return this.(*A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A).Describe_STAR___O(); case 2: return this.(*A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A).Explain_STAR__O_O_O_O__O(args[0], args[1], args[2], args[3]); case 3: return this.(*A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A).Gen_STAR__O_O_O__O(args[0], args[1], args[2]); case 4: return this.(*A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A).Meta__IPersistentMap(); case 5: return this.(*A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A).Specize_STAR___O(); case 6: return this.(*A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A).Specize_STAR__O__O(args[0]); case 7: return this.(*A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A).Unform_STAR__O__O(args[0]); case 8: return this.(*A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 9: return this.(*A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A).With_gen_STAR__O__O(args[0])}; return nil }

func A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_New_IPersistentMap_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2])}; return nil }

var A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 conform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 describe_STAR_ ()Ljava.lang.Object;\nM1 explain_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 gen_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 specize_STAR_ ()Ljava.lang.Object;\nM1 specize_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 unform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 with_gen_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_invoke, New: A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_new}

var A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$regex_spec_impl$reify__1740000846", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{A_arbace_spec_alpha_Specize_A_class, A_arbace_spec_alpha_Spec_A_class, lang.IObj_class}, Declaring: A_arbace_spec_alpha_regex_spec_impl_A_class, Simple: "reify__1740000846", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_InstanceOf; i.Table = A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A_class, reflect.TypeFor[A_arbace_spec_alpha_regex_spec_impl_reify__1740000846_A]()) }

func A_arbace_spec_alpha_registry_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_registry_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_registry_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_registry_A_New()}; return nil }

func A_arbace_spec_alpha_registry_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_registry_A_fn_class)}; return nil }

var A_arbace_spec_alpha_registry_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_registry_A_invoke, New: A_arbace_spec_alpha_registry_A_new, Get: A_arbace_spec_alpha_registry_A_get}

var A_arbace_spec_alpha_registry_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$registry", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "registry", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_registry_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_registry_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_registry_A_InstanceOf; i.Init = A_arbace_spec_alpha_registry_A_Init; i.Table = A_arbace_spec_alpha_registry_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_registry_A_class, reflect.TypeFor[A_arbace_spec_alpha_registry_A]()) }

func A_arbace_spec_alpha_rep_PLUS_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_rep_PLUS_impl_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_rep_PLUS_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_rep_PLUS_impl_A_New()}; return nil }

func A_arbace_spec_alpha_rep_PLUS_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_rep_PLUS_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_rep_PLUS_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_rep_PLUS_impl_A_invoke, New: A_arbace_spec_alpha_rep_PLUS_impl_A_new, Get: A_arbace_spec_alpha_rep_PLUS_impl_A_get}

var A_arbace_spec_alpha_rep_PLUS_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$rep_PLUS_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "rep_PLUS_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_rep_PLUS_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_rep_PLUS_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_rep_PLUS_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_rep_PLUS_impl_A_Init; i.Table = A_arbace_spec_alpha_rep_PLUS_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_rep_PLUS_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_rep_PLUS_impl_A]()) }

func A_arbace_spec_alpha_rep_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_rep_STAR__A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_rep_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_rep_STAR__A_New()}; return nil }

func A_arbace_spec_alpha_rep_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_rep_STAR__A_fn_class)}; return nil }

var A_arbace_spec_alpha_rep_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_rep_STAR__A_invoke, New: A_arbace_spec_alpha_rep_STAR__A_new, Get: A_arbace_spec_alpha_rep_STAR__A_get}

var A_arbace_spec_alpha_rep_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$rep_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "rep_STAR_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_rep_STAR__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_rep_STAR__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_rep_STAR__A_InstanceOf; i.Init = A_arbace_spec_alpha_rep_STAR__A_Init; i.Table = A_arbace_spec_alpha_rep_STAR__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_rep_STAR__A_class, reflect.TypeFor[A_arbace_spec_alpha_rep_STAR__A]()) }

func A_arbace_spec_alpha_rep_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_rep_impl_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_rep_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_rep_impl_A_New()}; return nil }

func A_arbace_spec_alpha_rep_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_rep_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_rep_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_rep_impl_A_invoke, New: A_arbace_spec_alpha_rep_impl_A_new, Get: A_arbace_spec_alpha_rep_impl_A_get}

var A_arbace_spec_alpha_rep_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$rep_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "rep_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_rep_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_rep_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_rep_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_rep_impl_A_Init; i.Table = A_arbace_spec_alpha_rep_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_rep_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_rep_impl_A]()) }

func A_arbace_spec_alpha_res_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_res_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_res_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_res_A_New()}; return nil }

func A_arbace_spec_alpha_res_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_res_A_fn_class)}; return nil }

var A_arbace_spec_alpha_res_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_res_A_invoke, New: A_arbace_spec_alpha_res_A_new, Get: A_arbace_spec_alpha_res_A_get}

var A_arbace_spec_alpha_res_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$res", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "res", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_res_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_res_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_res_A_InstanceOf; i.Init = A_arbace_spec_alpha_res_A_Init; i.Table = A_arbace_spec_alpha_res_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_res_A_class, reflect.TypeFor[A_arbace_spec_alpha_res_A]()) }

func A_arbace_spec_alpha_res_fn__1740000229_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_res_fn__1740000229_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_res_fn__1740000229_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_res_fn__1740000229_A_New()}; return nil }

func A_arbace_spec_alpha_res_fn__1740000229_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_res_fn__1740000229_A_fn_class)}; return nil }

var A_arbace_spec_alpha_res_fn__1740000229_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_res_fn__1740000229_A_invoke, New: A_arbace_spec_alpha_res_fn__1740000229_A_new, Get: A_arbace_spec_alpha_res_fn__1740000229_A_get}

var A_arbace_spec_alpha_res_fn__1740000229_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$res$fn__1740000229", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_res_A_class, Simple: "fn__1740000229", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_res_fn__1740000229_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_res_fn__1740000229_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_res_fn__1740000229_A_InstanceOf; i.Init = A_arbace_spec_alpha_res_fn__1740000229_A_Init; i.Table = A_arbace_spec_alpha_res_fn__1740000229_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_res_fn__1740000229_A_class, reflect.TypeFor[A_arbace_spec_alpha_res_fn__1740000229_A]()) }

func A_arbace_spec_alpha_res_kind_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_res_kind_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_res_kind_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_res_kind_A_New()}; return nil }

func A_arbace_spec_alpha_res_kind_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_res_kind_A_fn_class)}; return nil }

var A_arbace_spec_alpha_res_kind_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_res_kind_A_invoke, New: A_arbace_spec_alpha_res_kind_A_new, Get: A_arbace_spec_alpha_res_kind_A_get}

var A_arbace_spec_alpha_res_kind_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$res_kind", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "res_kind", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_res_kind_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_res_kind_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_res_kind_A_InstanceOf; i.Init = A_arbace_spec_alpha_res_kind_A_Init; i.Table = A_arbace_spec_alpha_res_kind_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_res_kind_A_class, reflect.TypeFor[A_arbace_spec_alpha_res_kind_A]()) }

func A_arbace_spec_alpha_spec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_spec_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_alpha_spec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_spec_A_New()}; return nil }

func A_arbace_spec_alpha_spec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_spec_A_fn_class)}; return nil }

var A_arbace_spec_alpha_spec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_spec_A_invoke, New: A_arbace_spec_alpha_spec_A_new, Get: A_arbace_spec_alpha_spec_A_get}

var A_arbace_spec_alpha_spec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$spec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "spec", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_spec_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_spec_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_spec_A_InstanceOf; i.Init = A_arbace_spec_alpha_spec_A_Init; i.Table = A_arbace_spec_alpha_spec_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_spec_A_class, reflect.TypeFor[A_arbace_spec_alpha_spec_A]()) }

func A_arbace_spec_alpha_spec_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_spec_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_spec_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_spec_QMARK__A_New()}; return nil }

func A_arbace_spec_alpha_spec_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_spec_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha_spec_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_spec_QMARK__A_invoke, New: A_arbace_spec_alpha_spec_QMARK__A_new, Get: A_arbace_spec_alpha_spec_QMARK__A_get}

var A_arbace_spec_alpha_spec_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$spec_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "spec_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_spec_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_spec_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_spec_QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha_spec_QMARK__A_Init; i.Table = A_arbace_spec_alpha_spec_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_spec_QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha_spec_QMARK__A]()) }

func A_arbace_spec_alpha_spec_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_spec_impl_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4]); case 1: return this.(*A_arbace_spec_alpha_spec_impl_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_alpha_spec_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_spec_impl_A_New()}; return nil }

func A_arbace_spec_alpha_spec_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_spec_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_spec_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_spec_impl_A_invoke, New: A_arbace_spec_alpha_spec_impl_A_new, Get: A_arbace_spec_alpha_spec_impl_A_get}

var A_arbace_spec_alpha_spec_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$spec_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class, lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "spec_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_spec_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_spec_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_spec_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_spec_impl_A_Init; i.Table = A_arbace_spec_alpha_spec_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_spec_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_spec_impl_A]()) }

func A_arbace_spec_alpha_spec_impl_reify__1740000460_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_spec_impl_reify__1740000460_A).Conform_STAR__O__O(args[0]); case 1: return this.(*A_arbace_spec_alpha_spec_impl_reify__1740000460_A).Describe_STAR___O(); case 2: return this.(*A_arbace_spec_alpha_spec_impl_reify__1740000460_A).Explain_STAR__O_O_O_O__O(args[0], args[1], args[2], args[3]); case 3: return this.(*A_arbace_spec_alpha_spec_impl_reify__1740000460_A).Gen_STAR__O_O_O__O(args[0], args[1], args[2]); case 4: return this.(*A_arbace_spec_alpha_spec_impl_reify__1740000460_A).Meta__IPersistentMap(); case 5: return this.(*A_arbace_spec_alpha_spec_impl_reify__1740000460_A).Specize_STAR___O(); case 6: return this.(*A_arbace_spec_alpha_spec_impl_reify__1740000460_A).Specize_STAR__O__O(args[0]); case 7: return this.(*A_arbace_spec_alpha_spec_impl_reify__1740000460_A).Unform_STAR__O__O(args[0]); case 8: return this.(*A_arbace_spec_alpha_spec_impl_reify__1740000460_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 9: return this.(*A_arbace_spec_alpha_spec_impl_reify__1740000460_A).With_gen_STAR__O__O(args[0])}; return nil }

func A_arbace_spec_alpha_spec_impl_reify__1740000460_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_spec_impl_reify__1740000460_A_New_IPersistentMap_O_O_O_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1], args[2], args[3], args[4], args[5])}; return nil }

var A_arbace_spec_alpha_spec_impl_reify__1740000460_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 conform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 describe_STAR_ ()Ljava.lang.Object;\nM1 explain_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 gen_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 specize_STAR_ ()Ljava.lang.Object;\nM1 specize_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 unform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 with_gen_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Larbace.lang.IPersistentMap;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_spec_alpha_spec_impl_reify__1740000460_A_invoke, New: A_arbace_spec_alpha_spec_impl_reify__1740000460_A_new}

var A_arbace_spec_alpha_spec_impl_reify__1740000460_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$spec_impl$reify__1740000460", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{A_arbace_spec_alpha_Specize_A_class, A_arbace_spec_alpha_Spec_A_class, lang.IObj_class}, Declaring: A_arbace_spec_alpha_spec_impl_A_class, Simple: "reify__1740000460", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_spec_impl_reify__1740000460_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_spec_impl_reify__1740000460_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_spec_impl_reify__1740000460_A_InstanceOf; i.Table = A_arbace_spec_alpha_spec_impl_reify__1740000460_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_spec_impl_reify__1740000460_A_class, reflect.TypeFor[A_arbace_spec_alpha_spec_impl_reify__1740000460_A]()) }

func A_arbace_spec_alpha_spec_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_spec_name_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_spec_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_spec_name_A_New()}; return nil }

func A_arbace_spec_alpha_spec_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_spec_name_A_fn_class)}; return nil }

var A_arbace_spec_alpha_spec_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_spec_name_A_invoke, New: A_arbace_spec_alpha_spec_name_A_new, Get: A_arbace_spec_alpha_spec_name_A_get}

var A_arbace_spec_alpha_spec_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$spec_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "spec_name", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_spec_name_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_spec_name_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_spec_name_A_InstanceOf; i.Init = A_arbace_spec_alpha_spec_name_A_Init; i.Table = A_arbace_spec_alpha_spec_name_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_spec_name_A_class, reflect.TypeFor[A_arbace_spec_alpha_spec_name_A]()) }

func A_arbace_spec_alpha_specize_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_specize_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_spec_alpha_specize_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_specize_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_specize_A_New()}; return nil }

func A_arbace_spec_alpha_specize_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_specize_A_fn_class)}; return nil }

var A_arbace_spec_alpha_specize_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_specize_A_invoke, New: A_arbace_spec_alpha_specize_A_new, Get: A_arbace_spec_alpha_specize_A_get}

var A_arbace_spec_alpha_specize_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$specize", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "specize", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_specize_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_specize_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_specize_A_InstanceOf; i.Init = A_arbace_spec_alpha_specize_A_Init; i.Table = A_arbace_spec_alpha_specize_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_specize_A_class, reflect.TypeFor[A_arbace_spec_alpha_specize_A]()) }

func A_arbace_spec_alpha_tagged_ret_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_tagged_ret_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_tagged_ret_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_tagged_ret_A_New()}; return nil }

func A_arbace_spec_alpha_tagged_ret_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_tagged_ret_A_fn_class)}; return nil }

var A_arbace_spec_alpha_tagged_ret_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_tagged_ret_A_invoke, New: A_arbace_spec_alpha_tagged_ret_A_new, Get: A_arbace_spec_alpha_tagged_ret_A_get}

var A_arbace_spec_alpha_tagged_ret_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$tagged_ret", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "tagged_ret", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_tagged_ret_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_tagged_ret_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_tagged_ret_A_InstanceOf; i.Init = A_arbace_spec_alpha_tagged_ret_A_Init; i.Table = A_arbace_spec_alpha_tagged_ret_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_tagged_ret_A_class, reflect.TypeFor[A_arbace_spec_alpha_tagged_ret_A]()) }

func A_arbace_spec_alpha_the_spec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_the_spec_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_the_spec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_the_spec_A_New()}; return nil }

func A_arbace_spec_alpha_the_spec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_the_spec_A_fn_class)}; return nil }

var A_arbace_spec_alpha_the_spec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_the_spec_A_invoke, New: A_arbace_spec_alpha_the_spec_A_new, Get: A_arbace_spec_alpha_the_spec_A_get}

var A_arbace_spec_alpha_the_spec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$the_spec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "the_spec", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_the_spec_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_the_spec_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_the_spec_A_InstanceOf; i.Init = A_arbace_spec_alpha_the_spec_A_Init; i.Table = A_arbace_spec_alpha_the_spec_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_the_spec_A_class, reflect.TypeFor[A_arbace_spec_alpha_the_spec_A]()) }

func A_arbace_spec_alpha_tuple_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_tuple_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_tuple_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_tuple_A_New()}; return nil }

func A_arbace_spec_alpha_tuple_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_tuple_A_fn_class)}; return nil }

var A_arbace_spec_alpha_tuple_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_tuple_A_invoke, New: A_arbace_spec_alpha_tuple_A_new, Get: A_arbace_spec_alpha_tuple_A_get}

var A_arbace_spec_alpha_tuple_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$tuple", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "tuple", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_tuple_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_tuple_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_tuple_A_InstanceOf; i.Init = A_arbace_spec_alpha_tuple_A_Init; i.Table = A_arbace_spec_alpha_tuple_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_tuple_A_class, reflect.TypeFor[A_arbace_spec_alpha_tuple_A]()) }

func A_arbace_spec_alpha_tuple_impl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_tuple_impl_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_spec_alpha_tuple_impl_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_tuple_impl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_tuple_impl_A_New()}; return nil }

func A_arbace_spec_alpha_tuple_impl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_tuple_impl_A_fn_class)}; return nil }

var A_arbace_spec_alpha_tuple_impl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_tuple_impl_A_invoke, New: A_arbace_spec_alpha_tuple_impl_A_new, Get: A_arbace_spec_alpha_tuple_impl_A_get}

var A_arbace_spec_alpha_tuple_impl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$tuple_impl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "tuple_impl", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_tuple_impl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_tuple_impl_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_tuple_impl_A_InstanceOf; i.Init = A_arbace_spec_alpha_tuple_impl_A_Init; i.Table = A_arbace_spec_alpha_tuple_impl_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_tuple_impl_A_class, reflect.TypeFor[A_arbace_spec_alpha_tuple_impl_A]()) }

func A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_tuple_impl_fn__1740000493_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_fn_class)}; return nil }

var A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_invoke, New: A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_new, Get: A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_get}

var A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$tuple_impl$fn__1740000493", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_alpha_tuple_impl_A_class, Simple: "fn__1740000493", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_tuple_impl_fn__1740000493_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_InstanceOf; i.Init = A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_Init; i.Table = A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_tuple_impl_fn__1740000493_A_class, reflect.TypeFor[A_arbace_spec_alpha_tuple_impl_fn__1740000493_A]()) }

func A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_A).Conform_STAR__O__O(args[0]); case 1: return this.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_A).Describe_STAR___O(); case 2: return this.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_A).Explain_STAR__O_O_O_O__O(args[0], args[1], args[2], args[3]); case 3: return this.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_A).Gen_STAR__O_O_O__O(args[0], args[1], args[2]); case 4: return this.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_A).Meta__IPersistentMap(); case 5: return this.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_A).Specize_STAR___O(); case 6: return this.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_A).Specize_STAR__O__O(args[0]); case 7: return this.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_A).Unform_STAR__O__O(args[0]); case 8: return this.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_A).WithMeta_IPersistentMap__IObj(jrt.As[lang.IPersistentMap](args[0])); case 9: return this.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_A).With_gen_STAR__O__O(args[0])}; return nil }

func A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_New_IPersistentMap_I_O_O_O_O(jrt.As[lang.IPersistentMap](args[0]), args[1].(int32), args[2], args[3], args[4], args[5])}; return nil }

var A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 conform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 describe_STAR_ ()Ljava.lang.Object;\nM1 explain_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 gen_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 meta ()Larbace.lang.IPersistentMap;\nM1 specize_STAR_ ()Ljava.lang.Object;\nM1 specize_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 unform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1 withMeta (Larbace.lang.IPersistentMap;)Larbace.lang.IObj;\nM1 with_gen_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Larbace.lang.IPersistentMap;ILjava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V", Invoke: A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_invoke, New: A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_new}

var A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$tuple_impl$reify__1740000495", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{A_arbace_spec_alpha_Specize_A_class, A_arbace_spec_alpha_Spec_A_class, lang.IObj_class}, Declaring: A_arbace_spec_alpha_tuple_impl_A_class, Simple: "reify__1740000495", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_tuple_impl_reify__1740000495_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_InstanceOf; i.Table = A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_class, reflect.TypeFor[A_arbace_spec_alpha_tuple_impl_reify__1740000495_A]()) }

func A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_fn_class)}; return nil }

var A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_invoke, New: A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_new, Get: A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_get}

var A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$tuple_impl$reify__1740000495$fn__1740000496", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_class, Simple: "fn__1740000496", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_InstanceOf; i.Init = A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_Init; i.Table = A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A_class, reflect.TypeFor[A_arbace_spec_alpha_tuple_impl_reify__1740000495_fn__1740000496_A]()) }

func A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_fn_class)}; return nil }

var A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_invoke, New: A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_new, Get: A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_get}

var A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$tuple_impl$reify__1740000495$gen__1740000498", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_tuple_impl_reify__1740000495_A_class, Simple: "gen__1740000498", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_InstanceOf; i.Init = A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_Init; i.Table = A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A_class, reflect.TypeFor[A_arbace_spec_alpha_tuple_impl_reify__1740000495_gen__1740000498_A]()) }

func A_arbace_spec_alpha_unfn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_unfn_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_unfn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_unfn_A_New()}; return nil }

func A_arbace_spec_alpha_unfn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_unfn_A_fn_class)}; return nil }

var A_arbace_spec_alpha_unfn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_unfn_A_invoke, New: A_arbace_spec_alpha_unfn_A_new, Get: A_arbace_spec_alpha_unfn_A_get}

var A_arbace_spec_alpha_unfn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$unfn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "unfn", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_unfn_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_unfn_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_unfn_A_InstanceOf; i.Init = A_arbace_spec_alpha_unfn_A_Init; i.Table = A_arbace_spec_alpha_unfn_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_unfn_A_class, reflect.TypeFor[A_arbace_spec_alpha_unfn_A]()) }

func A_arbace_spec_alpha_unform_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_unform_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_unform_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_unform_A_New()}; return nil }

func A_arbace_spec_alpha_unform_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_unform_A_fn_class)}; return nil }

var A_arbace_spec_alpha_unform_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_unform_A_invoke, New: A_arbace_spec_alpha_unform_A_new, Get: A_arbace_spec_alpha_unform_A_get}

var A_arbace_spec_alpha_unform_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$unform", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "unform", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_unform_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_unform_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_unform_A_InstanceOf; i.Init = A_arbace_spec_alpha_unform_A_Init; i.Table = A_arbace_spec_alpha_unform_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_unform_A_class, reflect.TypeFor[A_arbace_spec_alpha_unform_A]()) }

func A_arbace_spec_alpha_valid_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_valid_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_spec_alpha_valid_QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_valid_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_valid_QMARK__A_New()}; return nil }

func A_arbace_spec_alpha_valid_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_valid_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_alpha_valid_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_valid_QMARK__A_invoke, New: A_arbace_spec_alpha_valid_QMARK__A_new, Get: A_arbace_spec_alpha_valid_QMARK__A_get}

var A_arbace_spec_alpha_valid_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$valid_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "valid_QMARK_", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_valid_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_valid_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_alpha_valid_QMARK__A_InstanceOf; i.Init = A_arbace_spec_alpha_valid_QMARK__A_Init; i.Table = A_arbace_spec_alpha_valid_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_alpha_valid_QMARK__A_class, reflect.TypeFor[A_arbace_spec_alpha_valid_QMARK__A]()) }

func A_arbace_spec_alpha_validate_fn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_validate_fn_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_alpha_validate_fn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_validate_fn_A_New()}; return nil }

func A_arbace_spec_alpha_validate_fn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_validate_fn_A_fn_class)}; return nil }

var A_arbace_spec_alpha_validate_fn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_validate_fn_A_invoke, New: A_arbace_spec_alpha_validate_fn_A_new, Get: A_arbace_spec_alpha_validate_fn_A_get}

var A_arbace_spec_alpha_validate_fn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$validate_fn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "validate_fn", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_validate_fn_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_validate_fn_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_validate_fn_A_InstanceOf; i.Init = A_arbace_spec_alpha_validate_fn_A_Init; i.Table = A_arbace_spec_alpha_validate_fn_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_validate_fn_A_class, reflect.TypeFor[A_arbace_spec_alpha_validate_fn_A]()) }

func A_arbace_spec_alpha_validate_fn_fn__1740000851_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_validate_fn_fn__1740000851_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_validate_fn_fn__1740000851_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_validate_fn_fn__1740000851_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_alpha_validate_fn_fn__1740000851_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_validate_fn_fn__1740000851_A_fn_class)}; return nil }

var A_arbace_spec_alpha_validate_fn_fn__1740000851_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_validate_fn_fn__1740000851_A_invoke, New: A_arbace_spec_alpha_validate_fn_fn__1740000851_A_new, Get: A_arbace_spec_alpha_validate_fn_fn__1740000851_A_get}

var A_arbace_spec_alpha_validate_fn_fn__1740000851_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$validate_fn$fn__1740000851", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_alpha_validate_fn_A_class, Simple: "fn__1740000851", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_validate_fn_fn__1740000851_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_validate_fn_fn__1740000851_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_validate_fn_fn__1740000851_A_InstanceOf; i.Init = A_arbace_spec_alpha_validate_fn_fn__1740000851_A_Init; i.Table = A_arbace_spec_alpha_validate_fn_fn__1740000851_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_validate_fn_fn__1740000851_A_class, reflect.TypeFor[A_arbace_spec_alpha_validate_fn_fn__1740000851_A]()) }

func A_arbace_spec_alpha_with_gen_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_with_gen_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_with_gen_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_with_gen_A_New()}; return nil }

func A_arbace_spec_alpha_with_gen_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_with_gen_A_fn_class)}; return nil }

var A_arbace_spec_alpha_with_gen_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_with_gen_A_invoke, New: A_arbace_spec_alpha_with_gen_A_new, Get: A_arbace_spec_alpha_with_gen_A_get}

var A_arbace_spec_alpha_with_gen_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$with_gen", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "with_gen", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_with_gen_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_with_gen_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_with_gen_A_InstanceOf; i.Init = A_arbace_spec_alpha_with_gen_A_Init; i.Table = A_arbace_spec_alpha_with_gen_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_with_gen_A_class, reflect.TypeFor[A_arbace_spec_alpha_with_gen_A]()) }

func A_arbace_spec_alpha_with_name_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_alpha_with_name_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_alpha_with_name_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha_with_name_A_New()}; return nil }

func A_arbace_spec_alpha_with_name_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_alpha_with_name_A_fn_class)}; return nil }

var A_arbace_spec_alpha_with_name_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_alpha_with_name_A_invoke, New: A_arbace_spec_alpha_with_name_A_new, Get: A_arbace_spec_alpha_with_name_A_get}

var A_arbace_spec_alpha_with_name_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha$with_name", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_alpha_A_class, Simple: "with_name", Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_with_name_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha_with_name_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_with_name_A_InstanceOf; i.Init = A_arbace_spec_alpha_with_name_A_Init; i.Table = A_arbace_spec_alpha_with_name_A_members; jrt.RegisterGoType(A_arbace_spec_alpha_with_name_A_class, reflect.TypeFor[A_arbace_spec_alpha_with_name_A]()) }

func A_arbace_spec_alpha_Spec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_spec_alpha_Spec_A).Conform_STAR__O__O(args[0]); case 1: return this.(A_arbace_spec_alpha_Spec_A).Describe_STAR___O(); case 2: return this.(A_arbace_spec_alpha_Spec_A).Explain_STAR__O_O_O_O__O(args[0], args[1], args[2], args[3]); case 3: return this.(A_arbace_spec_alpha_Spec_A).Gen_STAR__O_O_O__O(args[0], args[1], args[2]); case 4: return this.(A_arbace_spec_alpha_Spec_A).Unform_STAR__O__O(args[0]); case 5: return this.(A_arbace_spec_alpha_Spec_A).With_gen_STAR__O__O(args[0])}; return nil }

var A_arbace_spec_alpha_Spec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 conform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1025 describe_STAR_ ()Ljava.lang.Object;\nM1025 explain_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1025 gen_STAR_ (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1025 unform_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;\nM1025 with_gen_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_spec_alpha_Spec_A_invoke}

var A_arbace_spec_alpha_Spec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha.Spec", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_Spec_A"})

func init() { i := A_arbace_spec_alpha_Spec_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_Spec_A_InstanceOf; i.Table = A_arbace_spec_alpha_Spec_A_members }

func A_arbace_spec_alpha_Specize_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_spec_alpha_Specize_A).Specize_STAR___O(); case 1: return this.(A_arbace_spec_alpha_Specize_A).Specize_STAR__O__O(args[0])}; return nil }

var A_arbace_spec_alpha_Specize_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 specize_STAR_ ()Ljava.lang.Object;\nM1025 specize_STAR_ (Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_spec_alpha_Specize_A_invoke}

var A_arbace_spec_alpha_Specize_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha.Specize", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha_Specize_A"})

func init() { i := A_arbace_spec_alpha_Specize_A_class.Info(); i.IsInstance = A_arbace_spec_alpha_Specize_A_InstanceOf; i.Table = A_arbace_spec_alpha_Specize_A_members }

func A_arbace_spec_alpha__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_spec_alpha__init_A_Load__O(); case 1: return A_arbace_spec_alpha__init_A_Unit0__O(); case 2: return A_arbace_spec_alpha__init_A_Unit1__O(); case 3: return A_arbace_spec_alpha__init_A_Unit10__O(); case 4: return A_arbace_spec_alpha__init_A_Unit100__O(); case 5: return A_arbace_spec_alpha__init_A_Unit101__O(); case 6: return A_arbace_spec_alpha__init_A_Unit102__O(); case 7: return A_arbace_spec_alpha__init_A_Unit103__O(); case 8: return A_arbace_spec_alpha__init_A_Unit104__O(); case 9: return A_arbace_spec_alpha__init_A_Unit105__O(); case 10: return A_arbace_spec_alpha__init_A_Unit106__O(); case 11: return A_arbace_spec_alpha__init_A_Unit107__O(); case 12: return A_arbace_spec_alpha__init_A_Unit108__O(); case 13: return A_arbace_spec_alpha__init_A_Unit109__O(); case 14: return A_arbace_spec_alpha__init_A_Unit11__O(); case 15: return A_arbace_spec_alpha__init_A_Unit110__O(); case 16: return A_arbace_spec_alpha__init_A_Unit111__O(); case 17: return A_arbace_spec_alpha__init_A_Unit112__O(); case 18: return A_arbace_spec_alpha__init_A_Unit113__O(); case 19: return A_arbace_spec_alpha__init_A_Unit114__O(); case 20: return A_arbace_spec_alpha__init_A_Unit115__O(); case 21: return A_arbace_spec_alpha__init_A_Unit116__O(); case 22: return A_arbace_spec_alpha__init_A_Unit117__O(); case 23: return A_arbace_spec_alpha__init_A_Unit118__O(); case 24: return A_arbace_spec_alpha__init_A_Unit119__O(); case 25: return A_arbace_spec_alpha__init_A_Unit12__O(); case 26: return A_arbace_spec_alpha__init_A_Unit120__O(); case 27: return A_arbace_spec_alpha__init_A_Unit121__O(); case 28: return A_arbace_spec_alpha__init_A_Unit122__O(); case 29: return A_arbace_spec_alpha__init_A_Unit123__O(); case 30: return A_arbace_spec_alpha__init_A_Unit124__O(); case 31: return A_arbace_spec_alpha__init_A_Unit125__O(); case 32: return A_arbace_spec_alpha__init_A_Unit126__O(); case 33: return A_arbace_spec_alpha__init_A_Unit127__O(); case 34: return A_arbace_spec_alpha__init_A_Unit128__O(); case 35: return A_arbace_spec_alpha__init_A_Unit129__O(); case 36: return A_arbace_spec_alpha__init_A_Unit13__O(); case 37: return A_arbace_spec_alpha__init_A_Unit130__O(); case 38: return A_arbace_spec_alpha__init_A_Unit131__O(); case 39: return A_arbace_spec_alpha__init_A_Unit132__O(); case 40: return A_arbace_spec_alpha__init_A_Unit133__O(); case 41: return A_arbace_spec_alpha__init_A_Unit134__O(); case 42: return A_arbace_spec_alpha__init_A_Unit135__O(); case 43: return A_arbace_spec_alpha__init_A_Unit136__O(); case 44: return A_arbace_spec_alpha__init_A_Unit137__O(); case 45: return A_arbace_spec_alpha__init_A_Unit138__O(); case 46: return A_arbace_spec_alpha__init_A_Unit139__O(); case 47: return A_arbace_spec_alpha__init_A_Unit14__O(); case 48: return A_arbace_spec_alpha__init_A_Unit140__O(); case 49: return A_arbace_spec_alpha__init_A_Unit141__O(); case 50: return A_arbace_spec_alpha__init_A_Unit142__O(); case 51: return A_arbace_spec_alpha__init_A_Unit143__O(); case 52: return A_arbace_spec_alpha__init_A_Unit144__O(); case 53: return A_arbace_spec_alpha__init_A_Unit145__O(); case 54: return A_arbace_spec_alpha__init_A_Unit146__O(); case 55: return A_arbace_spec_alpha__init_A_Unit147__O(); case 56: return A_arbace_spec_alpha__init_A_Unit148__O(); case 57: return A_arbace_spec_alpha__init_A_Unit149__O(); case 58: return A_arbace_spec_alpha__init_A_Unit15__O(); case 59: return A_arbace_spec_alpha__init_A_Unit150__O(); case 60: return A_arbace_spec_alpha__init_A_Unit151__O(); case 61: return A_arbace_spec_alpha__init_A_Unit152__O(); case 62: return A_arbace_spec_alpha__init_A_Unit153__O(); case 63: return A_arbace_spec_alpha__init_A_Unit154__O(); case 64: return A_arbace_spec_alpha__init_A_Unit155__O(); case 65: return A_arbace_spec_alpha__init_A_Unit156__O(); case 66: return A_arbace_spec_alpha__init_A_Unit157__O(); case 67: return A_arbace_spec_alpha__init_A_Unit158__O(); case 68: return A_arbace_spec_alpha__init_A_Unit159__O(); case 69: return A_arbace_spec_alpha__init_A_Unit16__O(); case 70: return A_arbace_spec_alpha__init_A_Unit160__O(); case 71: return A_arbace_spec_alpha__init_A_Unit161__O(); case 72: return A_arbace_spec_alpha__init_A_Unit162__O(); case 73: return A_arbace_spec_alpha__init_A_Unit163__O(); case 74: return A_arbace_spec_alpha__init_A_Unit164__O(); case 75: return A_arbace_spec_alpha__init_A_Unit165__O(); case 76: return A_arbace_spec_alpha__init_A_Unit166__O(); case 77: return A_arbace_spec_alpha__init_A_Unit167__O(); case 78: return A_arbace_spec_alpha__init_A_Unit168__O(); case 79: return A_arbace_spec_alpha__init_A_Unit169__O(); case 80: return A_arbace_spec_alpha__init_A_Unit17__O(); case 81: return A_arbace_spec_alpha__init_A_Unit170__O(); case 82: return A_arbace_spec_alpha__init_A_Unit171__O(); case 83: return A_arbace_spec_alpha__init_A_Unit172__O(); case 84: return A_arbace_spec_alpha__init_A_Unit173__O(); case 85: return A_arbace_spec_alpha__init_A_Unit174__O(); case 86: return A_arbace_spec_alpha__init_A_Unit175__O(); case 87: return A_arbace_spec_alpha__init_A_Unit176__O(); case 88: return A_arbace_spec_alpha__init_A_Unit177__O(); case 89: return A_arbace_spec_alpha__init_A_Unit178__O(); case 90: return A_arbace_spec_alpha__init_A_Unit179__O(); case 91: return A_arbace_spec_alpha__init_A_Unit18__O(); case 92: return A_arbace_spec_alpha__init_A_Unit180__O(); case 93: return A_arbace_spec_alpha__init_A_Unit181__O(); case 94: return A_arbace_spec_alpha__init_A_Unit182__O(); case 95: return A_arbace_spec_alpha__init_A_Unit183__O(); case 96: return A_arbace_spec_alpha__init_A_Unit184__O(); case 97: return A_arbace_spec_alpha__init_A_Unit185__O(); case 98: return A_arbace_spec_alpha__init_A_Unit186__O(); case 99: return A_arbace_spec_alpha__init_A_Unit187__O(); case 100: return A_arbace_spec_alpha__init_A_Unit188__O(); case 101: return A_arbace_spec_alpha__init_A_Unit189__O(); case 102: return A_arbace_spec_alpha__init_A_Unit19__O(); case 103: return A_arbace_spec_alpha__init_A_Unit190__O(); case 104: return A_arbace_spec_alpha__init_A_Unit191__O(); case 105: return A_arbace_spec_alpha__init_A_Unit192__O(); case 106: return A_arbace_spec_alpha__init_A_Unit193__O(); case 107: return A_arbace_spec_alpha__init_A_Unit194__O(); case 108: return A_arbace_spec_alpha__init_A_Unit195__O(); case 109: return A_arbace_spec_alpha__init_A_Unit196__O(); case 110: return A_arbace_spec_alpha__init_A_Unit197__O(); case 111: return A_arbace_spec_alpha__init_A_Unit198__O(); case 112: return A_arbace_spec_alpha__init_A_Unit199__O(); case 113: return A_arbace_spec_alpha__init_A_Unit2__O(); case 114: return A_arbace_spec_alpha__init_A_Unit20__O(); case 115: return A_arbace_spec_alpha__init_A_Unit200__O(); case 116: return A_arbace_spec_alpha__init_A_Unit201__O(); case 117: return A_arbace_spec_alpha__init_A_Unit202__O(); case 118: return A_arbace_spec_alpha__init_A_Unit203__O(); case 119: return A_arbace_spec_alpha__init_A_Unit204__O(); case 120: return A_arbace_spec_alpha__init_A_Unit205__O(); case 121: return A_arbace_spec_alpha__init_A_Unit206__O(); case 122: return A_arbace_spec_alpha__init_A_Unit207__O(); case 123: return A_arbace_spec_alpha__init_A_Unit208__O(); case 124: return A_arbace_spec_alpha__init_A_Unit209__O(); case 125: return A_arbace_spec_alpha__init_A_Unit21__O(); case 126: return A_arbace_spec_alpha__init_A_Unit210__O(); case 127: return A_arbace_spec_alpha__init_A_Unit211__O(); case 128: return A_arbace_spec_alpha__init_A_Unit212__O(); case 129: return A_arbace_spec_alpha__init_A_Unit213__O(); case 130: return A_arbace_spec_alpha__init_A_Unit214__O(); case 131: return A_arbace_spec_alpha__init_A_Unit215__O(); case 132: return A_arbace_spec_alpha__init_A_Unit22__O(); case 133: return A_arbace_spec_alpha__init_A_Unit23__O(); case 134: return A_arbace_spec_alpha__init_A_Unit24__O(); case 135: return A_arbace_spec_alpha__init_A_Unit25__O(); case 136: return A_arbace_spec_alpha__init_A_Unit26__O(); case 137: return A_arbace_spec_alpha__init_A_Unit27__O(); case 138: return A_arbace_spec_alpha__init_A_Unit28__O(); case 139: return A_arbace_spec_alpha__init_A_Unit29__O(); case 140: return A_arbace_spec_alpha__init_A_Unit3__O(); case 141: return A_arbace_spec_alpha__init_A_Unit30__O(); case 142: return A_arbace_spec_alpha__init_A_Unit31__O(); case 143: return A_arbace_spec_alpha__init_A_Unit32__O(); case 144: return A_arbace_spec_alpha__init_A_Unit33__O(); case 145: return A_arbace_spec_alpha__init_A_Unit34__O(); case 146: return A_arbace_spec_alpha__init_A_Unit35__O(); case 147: return A_arbace_spec_alpha__init_A_Unit36__O(); case 148: return A_arbace_spec_alpha__init_A_Unit37__O(); case 149: return A_arbace_spec_alpha__init_A_Unit38__O(); case 150: return A_arbace_spec_alpha__init_A_Unit39__O(); case 151: return A_arbace_spec_alpha__init_A_Unit4__O(); case 152: return A_arbace_spec_alpha__init_A_Unit40__O(); case 153: return A_arbace_spec_alpha__init_A_Unit41__O(); case 154: return A_arbace_spec_alpha__init_A_Unit42__O(); case 155: return A_arbace_spec_alpha__init_A_Unit43__O(); case 156: return A_arbace_spec_alpha__init_A_Unit44__O(); case 157: return A_arbace_spec_alpha__init_A_Unit45__O(); case 158: return A_arbace_spec_alpha__init_A_Unit46__O(); case 159: return A_arbace_spec_alpha__init_A_Unit47__O(); case 160: return A_arbace_spec_alpha__init_A_Unit48__O(); case 161: return A_arbace_spec_alpha__init_A_Unit49__O(); case 162: return A_arbace_spec_alpha__init_A_Unit5__O(); case 163: return A_arbace_spec_alpha__init_A_Unit50__O(); case 164: return A_arbace_spec_alpha__init_A_Unit51__O(); case 165: return A_arbace_spec_alpha__init_A_Unit52__O(); case 166: return A_arbace_spec_alpha__init_A_Unit53__O(); case 167: return A_arbace_spec_alpha__init_A_Unit54__O(); case 168: return A_arbace_spec_alpha__init_A_Unit55__O(); case 169: return A_arbace_spec_alpha__init_A_Unit56__O(); case 170: return A_arbace_spec_alpha__init_A_Unit57__O(); case 171: return A_arbace_spec_alpha__init_A_Unit58__O(); case 172: return A_arbace_spec_alpha__init_A_Unit59__O(); case 173: return A_arbace_spec_alpha__init_A_Unit6__O(); case 174: return A_arbace_spec_alpha__init_A_Unit60__O(); case 175: return A_arbace_spec_alpha__init_A_Unit61__O(); case 176: return A_arbace_spec_alpha__init_A_Unit62__O(); case 177: return A_arbace_spec_alpha__init_A_Unit63__O(); case 178: return A_arbace_spec_alpha__init_A_Unit64__O(); case 179: return A_arbace_spec_alpha__init_A_Unit65__O(); case 180: return A_arbace_spec_alpha__init_A_Unit66__O(); case 181: return A_arbace_spec_alpha__init_A_Unit67__O(); case 182: return A_arbace_spec_alpha__init_A_Unit68__O(); case 183: return A_arbace_spec_alpha__init_A_Unit69__O(); case 184: return A_arbace_spec_alpha__init_A_Unit7__O(); case 185: return A_arbace_spec_alpha__init_A_Unit70__O(); case 186: return A_arbace_spec_alpha__init_A_Unit71__O(); case 187: return A_arbace_spec_alpha__init_A_Unit72__O(); case 188: return A_arbace_spec_alpha__init_A_Unit73__O(); case 189: return A_arbace_spec_alpha__init_A_Unit74__O(); case 190: return A_arbace_spec_alpha__init_A_Unit75__O(); case 191: return A_arbace_spec_alpha__init_A_Unit76__O(); case 192: return A_arbace_spec_alpha__init_A_Unit77__O(); case 193: return A_arbace_spec_alpha__init_A_Unit78__O(); case 194: return A_arbace_spec_alpha__init_A_Unit79__O(); case 195: return A_arbace_spec_alpha__init_A_Unit8__O(); case 196: return A_arbace_spec_alpha__init_A_Unit80__O(); case 197: return A_arbace_spec_alpha__init_A_Unit81__O(); case 198: return A_arbace_spec_alpha__init_A_Unit82__O(); case 199: return A_arbace_spec_alpha__init_A_Unit83__O(); case 200: return A_arbace_spec_alpha__init_A_Unit84__O(); case 201: return A_arbace_spec_alpha__init_A_Unit85__O(); case 202: return A_arbace_spec_alpha__init_A_Unit86__O(); case 203: return A_arbace_spec_alpha__init_A_Unit87__O(); case 204: return A_arbace_spec_alpha__init_A_Unit88__O(); case 205: return A_arbace_spec_alpha__init_A_Unit89__O(); case 206: return A_arbace_spec_alpha__init_A_Unit9__O(); case 207: return A_arbace_spec_alpha__init_A_Unit90__O(); case 208: return A_arbace_spec_alpha__init_A_Unit91__O(); case 209: return A_arbace_spec_alpha__init_A_Unit92__O(); case 210: return A_arbace_spec_alpha__init_A_Unit93__O(); case 211: return A_arbace_spec_alpha__init_A_Unit94__O(); case 212: return A_arbace_spec_alpha__init_A_Unit95__O(); case 213: return A_arbace_spec_alpha__init_A_Unit96__O(); case 214: return A_arbace_spec_alpha__init_A_Unit97__O(); case 215: return A_arbace_spec_alpha__init_A_Unit98__O(); case 216: return A_arbace_spec_alpha__init_A_Unit99__O()}; return nil }

func A_arbace_spec_alpha__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_alpha__init_A_New()}; return nil }

var A_arbace_spec_alpha__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit100 ()Ljava.lang.Object;\nM9 unit101 ()Ljava.lang.Object;\nM9 unit102 ()Ljava.lang.Object;\nM9 unit103 ()Ljava.lang.Object;\nM9 unit104 ()Ljava.lang.Object;\nM9 unit105 ()Ljava.lang.Object;\nM9 unit106 ()Ljava.lang.Object;\nM9 unit107 ()Ljava.lang.Object;\nM9 unit108 ()Ljava.lang.Object;\nM9 unit109 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit110 ()Ljava.lang.Object;\nM9 unit111 ()Ljava.lang.Object;\nM9 unit112 ()Ljava.lang.Object;\nM9 unit113 ()Ljava.lang.Object;\nM9 unit114 ()Ljava.lang.Object;\nM9 unit115 ()Ljava.lang.Object;\nM9 unit116 ()Ljava.lang.Object;\nM9 unit117 ()Ljava.lang.Object;\nM9 unit118 ()Ljava.lang.Object;\nM9 unit119 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit120 ()Ljava.lang.Object;\nM9 unit121 ()Ljava.lang.Object;\nM9 unit122 ()Ljava.lang.Object;\nM9 unit123 ()Ljava.lang.Object;\nM9 unit124 ()Ljava.lang.Object;\nM9 unit125 ()Ljava.lang.Object;\nM9 unit126 ()Ljava.lang.Object;\nM9 unit127 ()Ljava.lang.Object;\nM9 unit128 ()Ljava.lang.Object;\nM9 unit129 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit130 ()Ljava.lang.Object;\nM9 unit131 ()Ljava.lang.Object;\nM9 unit132 ()Ljava.lang.Object;\nM9 unit133 ()Ljava.lang.Object;\nM9 unit134 ()Ljava.lang.Object;\nM9 unit135 ()Ljava.lang.Object;\nM9 unit136 ()Ljava.lang.Object;\nM9 unit137 ()Ljava.lang.Object;\nM9 unit138 ()Ljava.lang.Object;\nM9 unit139 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit140 ()Ljava.lang.Object;\nM9 unit141 ()Ljava.lang.Object;\nM9 unit142 ()Ljava.lang.Object;\nM9 unit143 ()Ljava.lang.Object;\nM9 unit144 ()Ljava.lang.Object;\nM9 unit145 ()Ljava.lang.Object;\nM9 unit146 ()Ljava.lang.Object;\nM9 unit147 ()Ljava.lang.Object;\nM9 unit148 ()Ljava.lang.Object;\nM9 unit149 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit150 ()Ljava.lang.Object;\nM9 unit151 ()Ljava.lang.Object;\nM9 unit152 ()Ljava.lang.Object;\nM9 unit153 ()Ljava.lang.Object;\nM9 unit154 ()Ljava.lang.Object;\nM9 unit155 ()Ljava.lang.Object;\nM9 unit156 ()Ljava.lang.Object;\nM9 unit157 ()Ljava.lang.Object;\nM9 unit158 ()Ljava.lang.Object;\nM9 unit159 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit160 ()Ljava.lang.Object;\nM9 unit161 ()Ljava.lang.Object;\nM9 unit162 ()Ljava.lang.Object;\nM9 unit163 ()Ljava.lang.Object;\nM9 unit164 ()Ljava.lang.Object;\nM9 unit165 ()Ljava.lang.Object;\nM9 unit166 ()Ljava.lang.Object;\nM9 unit167 ()Ljava.lang.Object;\nM9 unit168 ()Ljava.lang.Object;\nM9 unit169 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit170 ()Ljava.lang.Object;\nM9 unit171 ()Ljava.lang.Object;\nM9 unit172 ()Ljava.lang.Object;\nM9 unit173 ()Ljava.lang.Object;\nM9 unit174 ()Ljava.lang.Object;\nM9 unit175 ()Ljava.lang.Object;\nM9 unit176 ()Ljava.lang.Object;\nM9 unit177 ()Ljava.lang.Object;\nM9 unit178 ()Ljava.lang.Object;\nM9 unit179 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit180 ()Ljava.lang.Object;\nM9 unit181 ()Ljava.lang.Object;\nM9 unit182 ()Ljava.lang.Object;\nM9 unit183 ()Ljava.lang.Object;\nM9 unit184 ()Ljava.lang.Object;\nM9 unit185 ()Ljava.lang.Object;\nM9 unit186 ()Ljava.lang.Object;\nM9 unit187 ()Ljava.lang.Object;\nM9 unit188 ()Ljava.lang.Object;\nM9 unit189 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit190 ()Ljava.lang.Object;\nM9 unit191 ()Ljava.lang.Object;\nM9 unit192 ()Ljava.lang.Object;\nM9 unit193 ()Ljava.lang.Object;\nM9 unit194 ()Ljava.lang.Object;\nM9 unit195 ()Ljava.lang.Object;\nM9 unit196 ()Ljava.lang.Object;\nM9 unit197 ()Ljava.lang.Object;\nM9 unit198 ()Ljava.lang.Object;\nM9 unit199 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit200 ()Ljava.lang.Object;\nM9 unit201 ()Ljava.lang.Object;\nM9 unit202 ()Ljava.lang.Object;\nM9 unit203 ()Ljava.lang.Object;\nM9 unit204 ()Ljava.lang.Object;\nM9 unit205 ()Ljava.lang.Object;\nM9 unit206 ()Ljava.lang.Object;\nM9 unit207 ()Ljava.lang.Object;\nM9 unit208 ()Ljava.lang.Object;\nM9 unit209 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit210 ()Ljava.lang.Object;\nM9 unit211 ()Ljava.lang.Object;\nM9 unit212 ()Ljava.lang.Object;\nM9 unit213 ()Ljava.lang.Object;\nM9 unit214 ()Ljava.lang.Object;\nM9 unit215 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit48 ()Ljava.lang.Object;\nM9 unit49 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit50 ()Ljava.lang.Object;\nM9 unit51 ()Ljava.lang.Object;\nM9 unit52 ()Ljava.lang.Object;\nM9 unit53 ()Ljava.lang.Object;\nM9 unit54 ()Ljava.lang.Object;\nM9 unit55 ()Ljava.lang.Object;\nM9 unit56 ()Ljava.lang.Object;\nM9 unit57 ()Ljava.lang.Object;\nM9 unit58 ()Ljava.lang.Object;\nM9 unit59 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit60 ()Ljava.lang.Object;\nM9 unit61 ()Ljava.lang.Object;\nM9 unit62 ()Ljava.lang.Object;\nM9 unit63 ()Ljava.lang.Object;\nM9 unit64 ()Ljava.lang.Object;\nM9 unit65 ()Ljava.lang.Object;\nM9 unit66 ()Ljava.lang.Object;\nM9 unit67 ()Ljava.lang.Object;\nM9 unit68 ()Ljava.lang.Object;\nM9 unit69 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit70 ()Ljava.lang.Object;\nM9 unit71 ()Ljava.lang.Object;\nM9 unit72 ()Ljava.lang.Object;\nM9 unit73 ()Ljava.lang.Object;\nM9 unit74 ()Ljava.lang.Object;\nM9 unit75 ()Ljava.lang.Object;\nM9 unit76 ()Ljava.lang.Object;\nM9 unit77 ()Ljava.lang.Object;\nM9 unit78 ()Ljava.lang.Object;\nM9 unit79 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit80 ()Ljava.lang.Object;\nM9 unit81 ()Ljava.lang.Object;\nM9 unit82 ()Ljava.lang.Object;\nM9 unit83 ()Ljava.lang.Object;\nM9 unit84 ()Ljava.lang.Object;\nM9 unit85 ()Ljava.lang.Object;\nM9 unit86 ()Ljava.lang.Object;\nM9 unit87 ()Ljava.lang.Object;\nM9 unit88 ()Ljava.lang.Object;\nM9 unit89 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nM9 unit90 ()Ljava.lang.Object;\nM9 unit91 ()Ljava.lang.Object;\nM9 unit92 ()Ljava.lang.Object;\nM9 unit93 ()Ljava.lang.Object;\nM9 unit94 ()Ljava.lang.Object;\nM9 unit95 ()Ljava.lang.Object;\nM9 unit96 ()Ljava.lang.Object;\nM9 unit97 ()Ljava.lang.Object;\nM9 unit98 ()Ljava.lang.Object;\nM9 unit99 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_spec_alpha__init_A_invoke, New: A_arbace_spec_alpha__init_A_new}

var A_arbace_spec_alpha__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.alpha__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_spec_alpha.A_arbace_spec_alpha__init_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_alpha__init_A_class.Info(); i.IsInstance = A_arbace_spec_alpha__init_A_InstanceOf; i.Init = A_arbace_spec_alpha__init_A_Init; i.Table = A_arbace_spec_alpha__init_A_members; jrt.RegisterGoType(A_arbace_spec_alpha__init_A_class, reflect.TypeFor[A_arbace_spec_alpha__init_A]()) }
