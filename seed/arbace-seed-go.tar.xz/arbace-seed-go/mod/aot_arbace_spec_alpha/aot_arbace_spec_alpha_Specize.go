//line aot_arbace_spec_alpha_Specize.ae:1
package aot_arbace_spec_alpha

import "arbace/jrt"




type A_arbace_spec_alpha_Specize_A interface{ jrt.Object_I; Is_A_arbace_spec_alpha_Specize_A(); Specize_STAR___O() any; Specize_STAR__O__O(p0 any) any }

func A_arbace_spec_alpha_Specize_A_InstanceOf(x any) bool { _, ok := x.(A_arbace_spec_alpha_Specize_A); if !ok && x != nil && jrt.IsDynamic(x) { d, dyn := x.(jrt.Dynamic); if dyn { ok = d.DynImplements(A_arbace_spec_alpha_Specize_A_class) } }; return ok }

func A_arbace_spec_alpha_Specize_A_Cast(x any) A_arbace_spec_alpha_Specize_A { if x == nil { return nil }; v, ok := x.(A_arbace_spec_alpha_Specize_A); if ok && jrt.IsDynamic(x) { d, dyn := x.(jrt.Dynamic); if dyn { ok = d.DynImplements(A_arbace_spec_alpha_Specize_A_class) } }; if !ok { panic(jrt.ClassCast(x, A_arbace_spec_alpha_Specize_A_class)) }; return v }
