//line aot_arbace_go_check_load__init.ae:1
package aot_arbace_go_check_load

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_load__init_A_Unit0__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_go_check_load__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_load__init_A_const_1) }
//line :1:1
func A_arbace_go_check_load__init_A_Unit1__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_go_check_load__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_2)) }
//line :1:1
func A_arbace_go_check_load__init_A_Unit2__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_57, false, nil); A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_go_check_load__init_A_Unit3__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_go_check_load__init_A_const_1)).Equals_O__Z(A_arbace_go_check_load__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_go_check_load_eval1660000008_fn__1660000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_go_check_load_eval1660000008_fn__1660000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, nil); A_arbace_go_check_load_eval1660000008_fn__1660000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_go_check_load__init_A_Load__O() any { A_arbace_go_check_load__init_A_Init(); jrt.StartCheck(); A_arbace_go_check_load__init_A_Unit0__O(); A_arbace_go_check_load__init_A_Unit1__O(); A_arbace_go_check_load__init_A_Unit2__O(); A_arbace_go_check_load__init_A_Unit3__O(); A_arbace_go_check_load__init_A_Unit4__O(); A_arbace_go_check_load__init_A_Unit5__O(); A_arbace_go_check_load__init_A_Unit6__O(); A_arbace_go_check_load__init_A_Unit7__O(); A_arbace_go_check_load__init_A_Unit8__O(); A_arbace_go_check_load__init_A_Unit9__O(); A_arbace_go_check_load__init_A_Unit10__O(); A_arbace_go_check_load__init_A_Unit11__O(); A_arbace_go_check_load__init_A_Unit12__O(); A_arbace_go_check_load__init_A_Unit13__O(); A_arbace_go_check_load__init_A_Unit14__O(); A_arbace_go_check_load__init_A_Unit15__O(); A_arbace_go_check_load__init_A_Unit16__O(); A_arbace_go_check_load__init_A_Unit17__O(); A_arbace_go_check_load__init_A_Unit18__O(); A_arbace_go_check_load__init_A_Unit19__O(); A_arbace_go_check_load__init_A_Unit20__O(); A_arbace_go_check_load__init_A_Unit21__O(); A_arbace_go_check_load__init_A_Unit22__O(); return nil }










func A_arbace_go_check_load__init_A_Unit4__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(16, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_4; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_go_check_load_path__GT_ns_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_go_check_load_path__GT_ns_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, nil); A_arbace_go_check_load_path__GT_ns_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_5)); return A_arbace_go_check_load__init_A_const_4 }




func A_arbace_go_check_load__init_A_Unit5__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_go_check_load_ns__GT_file_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_go_check_load_ns__GT_file_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_60, false, nil); A_arbace_go_check_load_ns__GT_file_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_7)); return A_arbace_go_check_load__init_A_const_6 }






func A_arbace_go_check_load__init_A_Unit6__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(28, 1); A_arbace_go_check_load__init_A_const_8.BindRoot_O__V(A_arbace_go_check_load__init_A_const_9); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_10)); return A_arbace_go_check_load__init_A_const_8 }

func A_arbace_go_check_load__init_A_Unit7__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); A_arbace_go_check_load__init_A_const_11.BindRoot_O__V(A_arbace_go_check_load__init_A_const_12); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_11; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_13)); return A_arbace_go_check_load__init_A_const_11 }

func A_arbace_go_check_load__init_A_Unit8__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(32, 1); A_arbace_go_check_load__init_A_const_14.BindRoot_O__V(A_arbace_go_check_load__init_A_const_15); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_14; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_16)); return A_arbace_go_check_load__init_A_const_14 }



func A_arbace_go_check_load__init_A_Unit9__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(36, 1); A_arbace_go_check_load__init_A_const_17.BindRoot_O__V(A_arbace_go_check_load__init_A_const_18); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_17; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_19)); return A_arbace_go_check_load__init_A_const_17 }



func A_arbace_go_check_load__init_A_Unit10__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(40, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_go_check_load_tag_set_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_go_check_load_tag_set_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, nil); A_arbace_go_check_load_tag_set_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_21)); return A_arbace_go_check_load__init_A_const_20 }












func A_arbace_go_check_load__init_A_Unit11__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_go_check_load_tokens_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_go_check_load_tokens_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, nil); A_arbace_go_check_load_tokens_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_23)); return A_arbace_go_check_load__init_A_const_22 }


func A_arbace_go_check_load__init_A_Unit12__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(56, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_go_check_load_eval_build_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_go_check_load_eval_build_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, nil); A_arbace_go_check_load_eval_build_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_25)); return A_arbace_go_check_load__init_A_const_24 }

















func A_arbace_go_check_load__init_A_Unit13__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(74, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_go_check_load_good_os_arch_file_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_go_check_load_good_os_arch_file_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_64, false, nil); A_arbace_go_check_load_good_os_arch_file_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_27)); return A_arbace_go_check_load__init_A_const_26 }

















func A_arbace_go_check_load__init_A_Unit14__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(92, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_28; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_go_check_load_file_included_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_go_check_load_file_included_QMARK__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, nil); A_arbace_go_check_load_file_included_QMARK__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_29)); return A_arbace_go_check_load__init_A_const_28 }








func A_arbace_go_check_load__init_A_Unit15__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(101, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_30; tmp1.BindRoot_O__V(jrt.ConcurrentHashMap_New()); var tmp2 *lang.Var = A_arbace_go_check_load__init_A_const_30; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_31)); return A_arbace_go_check_load__init_A_const_30 }

func A_arbace_go_check_load__init_A_Unit16__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(103, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_go_check_load_read_forms_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_go_check_load_read_forms_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, nil); A_arbace_go_check_load_read_forms_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_33)); return A_arbace_go_check_load__init_A_const_32 }








func A_arbace_go_check_load__init_A_Unit17__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_go_check_load_clear_cache_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_go_check_load_clear_cache_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, nil); A_arbace_go_check_load_clear_cache_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_35)); return A_arbace_go_check_load__init_A_const_34 }

func A_arbace_go_check_load__init_A_Unit18__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(114, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_go_check_load_overlay_file_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_go_check_load_overlay_file_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_go_check_load_overlay_file_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_37)); return A_arbace_go_check_load__init_A_const_36 }





func A_arbace_go_check_load__init_A_Unit19__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(120, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_go_check_load_collect_package_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_go_check_load_collect_package_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, nil); A_arbace_go_check_load_collect_package_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_39)); return A_arbace_go_check_load__init_A_const_38 }









func A_arbace_go_check_load__init_A_Unit20__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(130, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_go_check_load_package_source_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_go_check_load_package_source_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, nil); A_arbace_go_check_load_package_source_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_41)); return A_arbace_go_check_load__init_A_const_40 }


















func A_arbace_go_check_load__init_A_Unit21__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(149, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_go_check_load_package_files_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_go_check_load_package_files_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_go_check_load_package_files_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_43)); return A_arbace_go_check_load__init_A_const_42 }











func A_arbace_go_check_load__init_A_Unit22__O() any { A_arbace_go_check_load__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_go_check_load__init_A_const_44; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_go_check_load_package_path_of_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_go_check_load_package_path_of_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, nil); A_arbace_go_check_load_package_path_of_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_go_check_load__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_go_check_load__init_A_const_45)); return A_arbace_go_check_load__init_A_const_44 }



type A_arbace_go_check_load__init_A struct{ jrt.Object }

var A_arbace_go_check_load__init_A_const_pool *jrt.RefArray

var A_arbace_go_check_load__init_A_const_0 *lang.Var

var A_arbace_go_check_load__init_A_const_1 any

var A_arbace_go_check_load__init_A_const_2 any

var A_arbace_go_check_load__init_A_const_3 any

var A_arbace_go_check_load__init_A_const_4 *lang.Var

var A_arbace_go_check_load__init_A_const_5 any

var A_arbace_go_check_load__init_A_const_6 *lang.Var

var A_arbace_go_check_load__init_A_const_7 any

var A_arbace_go_check_load__init_A_const_8 *lang.Var

var A_arbace_go_check_load__init_A_const_9 any

var A_arbace_go_check_load__init_A_const_10 any

var A_arbace_go_check_load__init_A_const_11 *lang.Var

var A_arbace_go_check_load__init_A_const_12 any

var A_arbace_go_check_load__init_A_const_13 any

var A_arbace_go_check_load__init_A_const_14 *lang.Var

var A_arbace_go_check_load__init_A_const_15 any

var A_arbace_go_check_load__init_A_const_16 any

var A_arbace_go_check_load__init_A_const_17 *lang.Var

var A_arbace_go_check_load__init_A_const_18 any

var A_arbace_go_check_load__init_A_const_19 any

var A_arbace_go_check_load__init_A_const_20 *lang.Var

var A_arbace_go_check_load__init_A_const_21 any

var A_arbace_go_check_load__init_A_const_22 *lang.Var

var A_arbace_go_check_load__init_A_const_23 any

var A_arbace_go_check_load__init_A_const_24 *lang.Var

var A_arbace_go_check_load__init_A_const_25 any

var A_arbace_go_check_load__init_A_const_26 *lang.Var

var A_arbace_go_check_load__init_A_const_27 any

var A_arbace_go_check_load__init_A_const_28 *lang.Var

var A_arbace_go_check_load__init_A_const_29 any

var A_arbace_go_check_load__init_A_const_30 *lang.Var

var A_arbace_go_check_load__init_A_const_31 any

var A_arbace_go_check_load__init_A_const_32 *lang.Var

var A_arbace_go_check_load__init_A_const_33 any

var A_arbace_go_check_load__init_A_const_34 *lang.Var

var A_arbace_go_check_load__init_A_const_35 any

var A_arbace_go_check_load__init_A_const_36 *lang.Var

var A_arbace_go_check_load__init_A_const_37 any

var A_arbace_go_check_load__init_A_const_38 *lang.Var

var A_arbace_go_check_load__init_A_const_39 any

var A_arbace_go_check_load__init_A_const_40 *lang.Var

var A_arbace_go_check_load__init_A_const_41 any

var A_arbace_go_check_load__init_A_const_42 *lang.Var

var A_arbace_go_check_load__init_A_const_43 any

var A_arbace_go_check_load__init_A_const_44 *lang.Var

var A_arbace_go_check_load__init_A_const_45 any

var A_arbace_go_check_load__init_A_init jrt.ClassInit

func A_arbace_go_check_load__init_A_Init() { if !A_arbace_go_check_load__init_A_init.Done() { A_arbace_go_check_load__init_A_init.Run(A_arbace_go_check_load__init_A_clinit) } }

func A_arbace_go_check_load__init_A_clinit() { A_arbace_go_check_load__init_A_clinit_p0(); A_arbace_go_check_load__init_A_clinit_p1(); A_arbace_go_check_load__init_A_clinit_p2(); A_arbace_go_check_load__init_A_clinit_p3() }

func A_arbace_go_check_load__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_load__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_56, 70); A_arbace_go_check_load__init_A_const_0 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[24]); A_arbace_go_check_load__init_A_const_1 = A_arbace_go_check_load__init_A_const_pool.A[25]; A_arbace_go_check_load__init_A_const_2 = A_arbace_go_check_load__init_A_const_pool.A[26]; A_arbace_go_check_load__init_A_const_3 = A_arbace_go_check_load__init_A_const_pool.A[27]; A_arbace_go_check_load__init_A_const_4 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[28]); A_arbace_go_check_load__init_A_const_5 = A_arbace_go_check_load__init_A_const_pool.A[29]; A_arbace_go_check_load__init_A_const_6 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[30]); A_arbace_go_check_load__init_A_const_7 = A_arbace_go_check_load__init_A_const_pool.A[31]; A_arbace_go_check_load__init_A_const_8 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[32]); A_arbace_go_check_load__init_A_const_9 = A_arbace_go_check_load__init_A_const_pool.A[33]; A_arbace_go_check_load__init_A_const_10 = A_arbace_go_check_load__init_A_const_pool.A[34]; A_arbace_go_check_load__init_A_const_11 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[35]); A_arbace_go_check_load__init_A_const_12 = A_arbace_go_check_load__init_A_const_pool.A[36] }

func A_arbace_go_check_load__init_A_clinit_p1() { A_arbace_go_check_load__init_A_const_13 = A_arbace_go_check_load__init_A_const_pool.A[37]; A_arbace_go_check_load__init_A_const_14 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[38]); A_arbace_go_check_load__init_A_const_15 = A_arbace_go_check_load__init_A_const_pool.A[39]; A_arbace_go_check_load__init_A_const_16 = A_arbace_go_check_load__init_A_const_pool.A[40]; A_arbace_go_check_load__init_A_const_17 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[41]); A_arbace_go_check_load__init_A_const_18 = A_arbace_go_check_load__init_A_const_pool.A[42]; A_arbace_go_check_load__init_A_const_19 = A_arbace_go_check_load__init_A_const_pool.A[43]; A_arbace_go_check_load__init_A_const_20 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[44]); A_arbace_go_check_load__init_A_const_21 = A_arbace_go_check_load__init_A_const_pool.A[45]; A_arbace_go_check_load__init_A_const_22 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[46]); A_arbace_go_check_load__init_A_const_23 = A_arbace_go_check_load__init_A_const_pool.A[47]; A_arbace_go_check_load__init_A_const_24 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[48]); A_arbace_go_check_load__init_A_const_25 = A_arbace_go_check_load__init_A_const_pool.A[49]; A_arbace_go_check_load__init_A_const_26 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[50]) }

func A_arbace_go_check_load__init_A_clinit_p2() { A_arbace_go_check_load__init_A_const_27 = A_arbace_go_check_load__init_A_const_pool.A[51]; A_arbace_go_check_load__init_A_const_28 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[52]); A_arbace_go_check_load__init_A_const_29 = A_arbace_go_check_load__init_A_const_pool.A[53]; A_arbace_go_check_load__init_A_const_30 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[54]); A_arbace_go_check_load__init_A_const_31 = A_arbace_go_check_load__init_A_const_pool.A[55]; A_arbace_go_check_load__init_A_const_32 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[56]); A_arbace_go_check_load__init_A_const_33 = A_arbace_go_check_load__init_A_const_pool.A[57]; A_arbace_go_check_load__init_A_const_34 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[58]); A_arbace_go_check_load__init_A_const_35 = A_arbace_go_check_load__init_A_const_pool.A[59]; A_arbace_go_check_load__init_A_const_36 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[60]); A_arbace_go_check_load__init_A_const_37 = A_arbace_go_check_load__init_A_const_pool.A[61]; A_arbace_go_check_load__init_A_const_38 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[62]); A_arbace_go_check_load__init_A_const_39 = A_arbace_go_check_load__init_A_const_pool.A[63] }

func A_arbace_go_check_load__init_A_clinit_p3() { A_arbace_go_check_load__init_A_const_40 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[64]); A_arbace_go_check_load__init_A_const_41 = A_arbace_go_check_load__init_A_const_pool.A[65]; A_arbace_go_check_load__init_A_const_42 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[66]); A_arbace_go_check_load__init_A_const_43 = A_arbace_go_check_load__init_A_const_pool.A[67]; A_arbace_go_check_load__init_A_const_44 = lang.Var_Cast(A_arbace_go_check_load__init_A_const_pool.A[68]); A_arbace_go_check_load__init_A_const_45 = A_arbace_go_check_load__init_A_const_pool.A[69] }

func A_arbace_go_check_load__init_A_New() *A_arbace_go_check_load__init_A { A_arbace_go_check_load__init_A_Init(); t := &A_arbace_go_check_load__init_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_load__init_A) Ctor() {}

func (t *A_arbace_go_check_load__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_load__init_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_load__init_A_class }

func (t *A_arbace_go_check_load__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_load__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_load__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_load__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_load__init_A); return ok }

func A_arbace_go_check_load__init_A_Cast(x any) *A_arbace_go_check_load__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_load__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_load__init_A_class)) }; return v }
