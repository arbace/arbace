//line aot_arbace_go_check_load.ae:1
package aot_arbace_go_check_load

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A_New() *A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_load_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_load_A_const_1); lang.IFn_Cast(A_arbace_go_check_load_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_go_check_load_A_const_3, A_arbace_go_check_load_A_const_4, A_arbace_go_check_load_A_const_5); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_load_eval1660000008_fn__1660000009_A_New() *A_arbace_go_check_load_eval1660000008_fn__1660000009_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval1660000008_fn__1660000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_load_eval1660000008_fn__1660000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_load_eval1660000008_fn__1660000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_load_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_go_check_load_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_go_check_load_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_load_A_const_9.GetRawRoot__O(), A_arbace_go_check_load_A_const_10) }














func A_arbace_go_check_load_path__GT_ns_A_New() *A_arbace_go_check_load_path__GT_ns_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_path__GT_ns_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_go_check_load_path__GT_ns_A) Ctor() {}
//line :16:1
func (t *A_arbace_go_check_load_path__GT_ns_A) Invoke_O_O__O(self, path__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_38, nil); var tmp2 any; var root_21 any = A_arbace_go_check_load_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = Lit_24; var arg_25 any; var root_26 any = A_arbace_go_check_load_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any; var fnbody__38 any = A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_39, false, nil); A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; arg_29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); var arg_30 any; var root_39 any = A_arbace_go_check_load_A_const_15.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = path__0; var arg_43 any = A_arbace_go_check_load_A_const_16; if linked_40 == nil { arg_30 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_30 = linked_40.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; if linked_27 == nil { arg_25 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { arg_25 = linked_27.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if linked_22 == nil { tmp2 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { tmp2 = linked_22.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
//line :19:1
func A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_New() *A_arbace_go_check_load_path__GT_ns_fn__1660000013_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_path__GT_ns_fn__1660000013_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_go_check_load_path__GT_ns_fn__1660000013_A) Ctor() {}
//line :19:1
func (t *A_arbace_go_check_load_path__GT_ns_fn__1660000013_A) Invoke_O_O__O(self, p1__1660000012_SHARP___1 any) any { var root_31 any = A_arbace_go_check_load_A_const_13.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = p1__1660000012_SHARP___1; var arg_35 any = A_arbace_go_check_load_A_const_14; var arg_36 any = Lit_17; if linked_32 == nil { return ifn_33.Invoke_O_O_O__O(arg_34, arg_35, arg_36) } else { return linked_32.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_31, arg_34, arg_35, arg_36) } }

func A_arbace_go_check_load_ns__GT_file_A_New() *A_arbace_go_check_load_ns__GT_file_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_ns__GT_file_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_go_check_load_ns__GT_file_A) Ctor() {}
//line :21:1
func (t *A_arbace_go_check_load_ns__GT_file_A) Invoke_O_O__O(self, ns__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_23); var tmp2 any; var root_44 any = A_arbace_go_check_load_A_const_13.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = ns__0; var arg_48 any = Lit_24; var arg_49 any = Lit_25; if linked_45 == nil { tmp2 = ifn_46.Invoke_O_O_O__O(arg_47, arg_48, arg_49) } else { tmp2 = linked_45.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_44, arg_47, arg_48, arg_49) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref()
}














func A_arbace_go_check_load_tag_set_A_New() *A_arbace_go_check_load_tag_set_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_go_check_load_tag_set_A) Ctor() {}
//line :40:1
func (t *A_arbace_go_check_load_tag_set_A) Invoke_O_O__O(self, p__1660000018__0 any) any { var map__1660000019__2 any = p__1660000018__0; var map__1660000019__3 any; if lang.ISeq_InstanceOf(map__1660000019__2) { var tmp1 any; var root_50 any = A_arbace_go_check_load_A_const_17.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = map__1660000019__2; if linked_51 == nil { tmp1 = ifn_52.Invoke_O__O(arg_53) } else { tmp1 = linked_51.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_50, arg_53) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_54 any = A_arbace_go_check_load_A_const_18.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = map__1660000019__2; if linked_55 == nil { tmp2 = ifn_56.Invoke_O__O(arg_57) } else { tmp2 = linked_55.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_54, arg_57) }; map__1660000019__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_58 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = map__1660000019__2; if linked_59 == nil { tmp3 = ifn_60.Invoke_O__O(arg_61) } else { tmp3 = linked_59.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_58, arg_61) }; if jrt.J2g_Truth(tmp3) { var root_62 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = map__1660000019__2; if linked_63 == nil { map__1660000019__3 = ifn_64.Invoke_O__O(arg_65) } else { map__1660000019__3 = linked_63.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_62, arg_65) } } else { map__1660000019__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1660000019__3 = map__1660000019__2 }; var goos__4 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_21); var goarch__5 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_22); var goamd64__6 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_23); var goarm64__7 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_24); var tags__8 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_25); var root_66 any = A_arbace_go_check_load_A_const_26.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_68 lang.IFn; _ = goarm64__7; if


	linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, goos__4, Lit_42, goarch__5)); var arg_70 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_load_A_const_27.GetRawRoot__O()); var tmp5 any; var iter__1927001039__auto____9 any; var fnbody__141 any = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_New(); var tmp6 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_fn_class; if
	fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_fn_class = fncls__140d; tmp6 = fncls__140d } else { tmp6 = fncls__140 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__141, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp8 any; var root_142 any = A_arbace_go_check_load_A_const_37.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = A_arbace_go_check_load_A_const_38; var arg_146 any = A_arbace_go_check_load_A_const_39; if linked_143 == nil { tmp8 = ifn_144.Invoke_O_O__O(arg_145, arg_146) } else { tmp8 = linked_143.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_142, arg_145, arg_146) }; tmp5 = tmp7.Invoke_O__O(tmp8); var tmp9 any = tmp5; var tmp10 any; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_go_check_load_A_const_40.GetRawRoot__O()).Invoke_O__O(goos__4)) { tmp10 = A_arbace_go_check_load_A_const_41 } else { tmp10 = nil }; var tmp11 any = tmp10; var tmp12 any; if
	lang.Util_Equiv_O_O__Z_NoInit(Lit_44, goarch__5) { var lv__9 int64; var tmp13 any; var root_147 any = A_arbace_go_check_load_A_const_42.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_149 lang.IFn
		if linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any; var or__1927000174__auto____9 any = goamd64__6; if jrt.J2g_Truth(or__1927000174__auto____9) { arg_150 = or__1927000174__auto____9 } else { arg_150 = Lit_45 }; var arg_151 any = A_arbace_go_check_load_A_const_38; if linked_148 == nil { tmp13 = ifn_149.Invoke_O_O__O(arg_150, arg_151) } else { tmp13 = linked_148.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_147, arg_150, arg_151) }; lv__9 = jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp13))
//line :46:1
		var iter__1927001039__auto____10 any; var fnbody__213 any = A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A_New(); var tmp14 *jrt.Class
		var fncls__212 /*line :46:1*/*jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A_fn_class

		if fncls__212 == nil { var fncls__212d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, nil); A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A_fn_class = fncls__212d; tmp14 = fncls__212d } else { tmp14 = fncls__212 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__213, tmp14, nil); var tmp15 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____10); var tmp16 any; var root_214 any = A_arbace_go_check_load_A_const_37.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = A_arbace_go_check_load_A_const_38; var arg_218 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(lv__9)).Ref(); if linked_215 == nil { tmp16 = ifn_216.Invoke_O_O__O(arg_217, arg_218) } else { tmp16 = linked_215.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_214, arg_217, arg_218) }; tmp12 = tmp15.Invoke_O__O(tmp16) } else {
//line :46:1
			tmp12 = nil }; var tmp17 any = tmp12; var tmp18 any; if


	lang.Util_Equiv_O_O__Z_NoInit(Lit_47, goarch__5) { tmp18 = A_arbace_go_check_load_A_const_43 } else { tmp18 = nil }; var tmp19 any = tmp18; var tmp20 any; var root_219 any = /*line :44:1*/A_arbace_go_check_load_A_const_12.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_221 lang.IFn; if





	linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any; var fnbody__225 any = A_arbace_go_check_load_tag_set_fn__1660000041_A_New(); var tmp21 *jrt.Class; var fncls__224 *jrt.Class = A_arbace_go_check_load_tag_set_fn__1660000041_A_fn_class; if fncls__224 == nil { var fncls__224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, nil); A_arbace_go_check_load_tag_set_fn__1660000041_A_fn_class = fncls__224d; tmp21 = fncls__224d } else { tmp21 = fncls__224 }; arg_222 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__225, tmp21, nil); var arg_223 any = A_arbace_go_check_load_A_const_44.GetRawRoot__O(); if linked_220 == nil { tmp20 = ifn_221.Invoke_O_O__O(arg_222, arg_223) } else { tmp20 = linked_220.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_219, arg_222, arg_223) }; arg_70 = /*line :44:1*/tmp4.Invoke_O_O_O_O_O_O__O(tmp9, tmp11, tmp17, tmp19, tmp20, tags__8); if /*line :43:1*/ linked_67 == nil { return ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { return linked_67.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) } }
func A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_New() *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A) Ctor() {}
//line :44:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A) Invoke_O_O__O(self, s__1660000022__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__139 any = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_New_O_O(s__1660000022__1, self); var tmp2 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_fn_class; if fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__139); A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_fn_class = fncls__138d; tmp2 = fncls__138d } else { tmp2 = fncls__138 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__139, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :44:1
func A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A{}; t.Ctor_O_O(p0, p1); return t }
//line :44:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A) Ctor_O_O(c__s__1660000022, c__iter__1660000021 any) { t.F_s__1660000022 = c__s__1660000022; t.F_iter__1660000021 = c__iter__1660000021 }
//line :44:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A) Invoke_O__O(self any) any { { var s__1660000022__1 any; var t_ any = t.F_s__1660000022; t.F_s__1660000022 = nil; s__1660000022__1 = t_; for { var temp__1927000414__auto____2 any; var root_80 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_82 lang.IFn; if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any = s__1660000022__1; if linked_81 == nil { temp__1927000414__auto____2 = ifn_82.Invoke_O__O(arg_83) } else { temp__1927000414__auto____2 = linked_81.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_80, arg_83) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1660000022__3 any = temp__1927000414__auto____2; var tmp1 any; var root_84 any = A_arbace_go_check_load_A_const_28.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = s__1660000022__3; if linked_85 == nil { tmp1 = ifn_86.Invoke_O__O(arg_87) } else { tmp1 = linked_85.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_84, arg_87) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_88 any = A_arbace_go_check_load_A_const_29.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = s__1660000022__3; if linked_89 == nil { c__1927001037__auto____4 = ifn_90.Invoke_O__O(arg_91) } else { c__1927001037__auto____4 = linked_89.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_88, arg_91) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1660000024__6 any; var root_92 any = A_arbace_go_check_load_A_const_30.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_93 == nil { b__1660000024__6 = ifn_94.Invoke_O__O(arg_95) } else { b__1660000024__6 = linked_93.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_92, arg_95) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__102 any = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_New_I_O_O(size__1927001038__auto____5, b__1660000024__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, fnbody__102); A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_fn_class = fncls__101d; tmp3 = fncls__101d } else { tmp3 = fncls__101 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__102, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_103 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any; var root_108 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any = b__1660000024__6; if linked_109 == nil { arg_106 = ifn_110.Invoke_O__O(arg_111) } else { arg_106 = linked_109.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_108, arg_111) }; var arg_107 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1660000021); var tmp5 any; var root_112 any = A_arbace_go_check_load_A_const_34.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = s__1660000022__3; if linked_113 == nil { tmp5 = ifn_114.Invoke_O__O(arg_115) } else { tmp5 = linked_113.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_112, arg_115) }; arg_107 = tmp4.Invoke_O__O(tmp5); if linked_104 == nil { return ifn_105.Invoke_O_O__O(arg_106, arg_107) } else { return linked_104.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_103, arg_106, arg_107) } } else { var root_116 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any; var root_121 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = b__1660000024__6; if linked_122 == nil { arg_119 = ifn_123.Invoke_O__O(arg_124) } else { arg_119 = linked_122.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_121, arg_124) }; var arg_120 any; if linked_117 == nil { return ifn_118.Invoke_O_O__O(arg_119, arg_120) } else { return linked_117.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_116, arg_119, arg_120) } } } else { var i__4 any; var root_125 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_127 lang.IFn; if linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = s__1660000022__3; if linked_126 == nil { i__4 = ifn_127.Invoke_O__O(arg_128) } else { i__4 = linked_126.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_125, arg_128) }; var root_129 any = A_arbace_go_check_load_A_const_35.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref(); var arg_133 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1660000021); var tmp7 any; var root_134 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = s__1660000022__3; if linked_135 == nil { tmp7 = ifn_136.Invoke_O__O(arg_137) } else { tmp7 = linked_135.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_134, arg_137) }; arg_133 = tmp6.Invoke_O__O(tmp7); if linked_130 == nil { return ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { return linked_130.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_129, arg_132, arg_133) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :44:1
func A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :44:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1660000024, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1660000024 = c__b__1660000024; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :44:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A) Invoke_O__O(self any) any { { var i__1660000023__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1660000023__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1660000023__1)); var root_96 any = A_arbace_go_check_load_A_const_31.GetRawRoot__O(); var linked_97 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_96, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_98 lang.IFn; if linked_97 == nil { ifn_98 = lang.IFn_Cast(root_96) } else { ifn_98 = nil }; var arg_99 any = t.F_b__1660000024; var arg_100 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref(); if linked_97 == nil { ifn_98.Invoke_O_O__O(arg_99, arg_100) } else { linked_97.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_96, arg_99, arg_100) }; i__1660000023__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1660000023__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A_New() *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A) Ctor() {}
//line :48:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A) Invoke_O_O__O(self, s__1660000032__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__211 any = A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A_New_O_O(s__1660000032__1, self); var tmp2 *jrt.Class; var fncls__210 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A_fn_class; if fncls__210 == nil { var fncls__210d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_53, false, fnbody__211); A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A_fn_class = fncls__210d; tmp2 = fncls__210d } else { tmp2 = fncls__210 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__211, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :48:1
func A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A{}; t.Ctor_O_O(p0, p1); return t }
//line :48:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A) Ctor_O_O(c__s__1660000032, c__iter__1660000031 any) { t.F_s__1660000032 = c__s__1660000032; t.F_iter__1660000031 = c__iter__1660000031 }
//line :48:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A) Invoke_O__O(self any) any { { var s__1660000032__1 any; var t_ any = t.F_s__1660000032; t.F_s__1660000032 = nil; s__1660000032__1 = t_; for { var temp__1927000414__auto____2 any; var root_152 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = s__1660000032__1; if linked_153 == nil { temp__1927000414__auto____2 = ifn_154.Invoke_O__O(arg_155) } else { temp__1927000414__auto____2 = linked_153.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_152, arg_155) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1660000032__3 any = temp__1927000414__auto____2; var tmp1 any; var root_156 any = A_arbace_go_check_load_A_const_28.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = s__1660000032__3; if linked_157 == nil { tmp1 = ifn_158.Invoke_O__O(arg_159) } else { tmp1 = linked_157.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_156, arg_159) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_160 any = A_arbace_go_check_load_A_const_29.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = s__1660000032__3; if linked_161 == nil { c__1927001037__auto____4 = ifn_162.Invoke_O__O(arg_163) } else { c__1927001037__auto____4 = linked_161.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_160, arg_163) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1660000034__6 any; var root_164 any = A_arbace_go_check_load_A_const_30.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_165 == nil { b__1660000034__6 = ifn_166.Invoke_O__O(arg_167) } else { b__1660000034__6 = linked_165.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_164, arg_167) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__174 any = A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A_New_O_I_O(b__1660000034__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A_fn_class; if fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, fnbody__174); A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A_fn_class = fncls__173d; tmp3 = fncls__173d } else { tmp3 = fncls__173 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__174, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_175 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any; var root_180 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = b__1660000034__6; if linked_181 == nil { arg_178 = ifn_182.Invoke_O__O(arg_183) } else { arg_178 = linked_181.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_180, arg_183) }; var arg_179 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1660000031); var tmp5 any; var root_184 any = A_arbace_go_check_load_A_const_34.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = s__1660000032__3; if linked_185 == nil { tmp5 = ifn_186.Invoke_O__O(arg_187) } else { tmp5 = linked_185.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_184, arg_187) }; arg_179 = tmp4.Invoke_O__O(tmp5); if linked_176 == nil { return ifn_177.Invoke_O_O__O(arg_178, arg_179) } else { return linked_176.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_175, arg_178, arg_179) } } else { var root_188 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any; var root_193 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = b__1660000034__6; if linked_194 == nil { arg_191 = ifn_195.Invoke_O__O(arg_196) } else { arg_191 = linked_194.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_193, arg_196) }; var arg_192 any; if linked_189 == nil { return ifn_190.Invoke_O_O__O(arg_191, arg_192) } else { return linked_189.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_188, arg_191, arg_192) } } } else { var i__4 any; var root_197 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = s__1660000032__3; if linked_198 == nil { i__4 = ifn_199.Invoke_O__O(arg_200) } else { i__4 = linked_198.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_197, arg_200) }; var root_201 any = A_arbace_go_check_load_A_const_35.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref(); var arg_205 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1660000031); var tmp7 any; var root_206 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = s__1660000032__3; if linked_207 == nil { tmp7 = ifn_208.Invoke_O__O(arg_209) } else { tmp7 = linked_207.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_206, arg_209) }; arg_205 = tmp6.Invoke_O__O(tmp7); if linked_202 == nil { return ifn_203.Invoke_O_O__O(arg_204, arg_205) } else { return linked_202.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_201, arg_204, arg_205) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :48:1
func A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :48:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A) Ctor_O_I_O(c__b__1660000034 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1660000034 = c__b__1660000034; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :48:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A) Invoke_O__O(self any) any { { var i__1660000033__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1660000033__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1660000033__1)); var root_168 any = A_arbace_go_check_load_A_const_31.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = t.F_b__1660000034; var arg_172 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref(); if linked_169 == nil { ifn_170.Invoke_O_O__O(arg_171, arg_172) } else { linked_169.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_168, arg_171, arg_172) }; i__1660000033__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1660000033__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_load_tag_set_fn__1660000041_A_New() *A_arbace_go_check_load_tag_set_fn__1660000041_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_fn__1660000041_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_check_load_tag_set_fn__1660000041_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_check_load_tag_set_fn__1660000041_A) Invoke_O_O__O(self, p1__1660000017_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_49, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__1660000017_SHARP___1)).Ref() }


func A_arbace_go_check_load_tokens_A_New() *A_arbace_go_check_load_tokens_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tokens_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_go_check_load_tokens_A) Ctor() {}
//line :53:1
func (t *A_arbace_go_check_load_tokens_A) Invoke_O_O__O(self, s__0 any) any {
	var root_226 any = A_arbace_go_check_load_A_const_45.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = A_arbace_go_check_load_A_const_46; var arg_230 any = s__0; if linked_227 == nil { return ifn_228.Invoke_O_O__O(arg_229, arg_230) } else { return linked_227.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_226, arg_229, arg_230)
	} }
func A_arbace_go_check_load_eval_build_A_New() *A_arbace_go_check_load_eval_build_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_go_check_load_eval_build_A) Ctor() {}
//line :56:1
func (t *A_arbace_go_check_load_eval_build_A) Invoke_O_O_O__O(self, line__0, tags__1 any) any { var toks__3 any; var root_231 any = A_arbace_go_check_load_A_const_47.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_233 lang.IFn; if


	linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any; var root_235 any = A_arbace_go_check_load_A_const_48.GetRawRoot__O(); var linked_236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_235, A_arbace_go_check_load_tokens_A_fn_class); var ifn_237 lang.IFn; if linked_236 == nil { ifn_237 = lang.IFn_Cast(root_235) } else { ifn_237 = nil }; var arg_238 any; var root_239 any = A_arbace_go_check_load_A_const_13.GetRawRoot__O(); var linked_240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_239, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_241 lang.IFn; if linked_240 == nil { ifn_241 = lang.IFn_Cast(root_239) } else { ifn_241 = nil }; var arg_242 any = line__0; var arg_243 any = A_arbace_go_check_load_A_const_49; var arg_244 any = Lit_4; if linked_240 == nil { arg_238 = ifn_241.Invoke_O_O_O__O(arg_242, arg_243, arg_244) } else { arg_238 = linked_240.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_239, arg_242, arg_243, arg_244) }; if linked_236 == nil { arg_234 = ifn_237.Invoke_O__O(arg_238) } else { arg_234 = linked_236.(*A_arbace_go_check_load_tokens_A).Invoke_O_O__O(root_235, arg_238) }; if linked_232 == nil { toks__3 = ifn_233.Invoke_O__O(arg_234) } else { toks__3 = linked_232.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_231, arg_234) }; var pos__4 any; var root_245 any = /*line :56:1*/A_arbace_go_check_load_A_const_50.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_247 lang.IFn; if



	linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = A_arbace_go_check_load_A_const_51; if linked_246 == nil { pos__4 = ifn_247.Invoke_O__O(arg_248) } else { pos__4 = linked_246.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_245, arg_248) }; var peek_STAR___5 any; var fnbody__254 any = /*line :56:1*/A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A_New_O_O(toks__3, pos__4); var tmp1 *jrt.Class; var fncls__253 *jrt.Class = A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A_fn_class; if




	fncls__253 == nil { var fncls__253d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__254); A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A_fn_class = fncls__253d; tmp1 = fncls__253d } else { tmp1 = fncls__253 }; peek_STAR___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__254, tmp1, nil); var next_STAR___6 any; var fnbody__262 any = /*line :56:1*/A_arbace_go_check_load_eval_build_next_STAR___1660000047_A_New_O_O(toks__3, pos__4); var tmp2 *jrt.Class; var fncls__261 *jrt.Class = A_arbace_go_check_load_eval_build_next_STAR___1660000047_A_fn_class; if





	fncls__261 == nil { var fncls__261d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__262); A_arbace_go_check_load_eval_build_next_STAR___1660000047_A_fn_class = fncls__261d; tmp2 = fncls__261d } else { tmp2 = fncls__261 }; next_STAR___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__262, tmp2, nil); var body_or_expr__7 /*line :56:1*/*A_arbace_go_check_load_eval_build_or_expr__1660000049_A = A_arbace_go_check_load_eval_build_or_expr__1660000049_A_New_O_O_O(peek_STAR___5, nil, next_STAR___6); var body_and_expr__8 *A_arbace_go_check_load_eval_build_and_expr__1660000051_A = A_arbace_go_check_load_eval_build_and_expr__1660000051_A_New_O_O_O(peek_STAR___5, nil, next_STAR___6); var body_not_expr__9 *A_arbace_go_check_load_eval_build_not_expr__1660000053_A = A_arbace_go_check_load_eval_build_not_expr__1660000053_A_New_O_O_O(peek_STAR___5, nil, next_STAR___6); var body_atom_STAR___10 *A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A = A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A_New_O_O_O(nil, tags__1, next_STAR___6); var or_expr__7 any; var fnbody__273 any = any(body_or_expr__7); var tmp3 *jrt.Class; var fncls__272 *jrt.Class = A_arbace_go_check_load_eval_build_or_expr__1660000049_A_fn_class; if fncls__272 == nil { var fncls__272d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__273); A_arbace_go_check_load_eval_build_or_expr__1660000049_A_fn_class = fncls__272d; tmp3 = fncls__272d } else { tmp3 = fncls__272 }; or_expr__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__273, tmp3, nil); var and_expr__8 any; var fnbody__275 any = any(body_and_expr__8); var tmp4 *jrt.Class; var fncls__274 *jrt.Class = A_arbace_go_check_load_eval_build_and_expr__1660000051_A_fn_class; if fncls__274 == nil { var fncls__274d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__275); A_arbace_go_check_load_eval_build_and_expr__1660000051_A_fn_class = fncls__274d; tmp4 = fncls__274d } else { tmp4 = fncls__274 }; and_expr__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__275, tmp4, nil); var not_expr__9 any; var fnbody__277 any = any(body_not_expr__9); var tmp5 *jrt.Class; var fncls__276 *jrt.Class = A_arbace_go_check_load_eval_build_not_expr__1660000053_A_fn_class; if fncls__276 == nil { var fncls__276d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__277); A_arbace_go_check_load_eval_build_not_expr__1660000053_A_fn_class = fncls__276d; tmp5 = fncls__276d } else { tmp5 = fncls__276 }; not_expr__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__277, tmp5, nil); var atom_STAR___10 any; var fnbody__279 any = any(body_atom_STAR___10); var tmp6 *jrt.Class; var fncls__278 *jrt.Class = A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A_fn_class; if fncls__278 == nil { var fncls__278d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__279); A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A_fn_class = fncls__278d; tmp6 = fncls__278d } else { tmp6 = fncls__278 }; atom_STAR___10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__279, tmp6, nil); body_or_expr__7.F_and_expr = and_expr__8; body_and_expr__8.F_not_expr = not_expr__9; body_not_expr__9.F_atom_STAR_ = atom_STAR___10; body_atom_STAR___10.F_or_expr = or_expr__7; return /*line :72:1*/ lang.IFn_Cast(or_expr__7).Invoke__O() }
//line :61:1
func A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A{}; t.Ctor_O_O(p0, p1); return t }
//line :61:1
func (t *A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A) Ctor_O_O(c__toks, c__pos any) { t.F_toks = c__toks; t.F_pos = c__pos }
//line :61:1
func (t *A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A) Invoke_O__O(self any) any { var tmp1 any = t.F_toks; var tmp2 any; var root_249 any = A_arbace_go_check_load_A_const_7.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = t.F_pos; if linked_250 == nil { tmp2 = ifn_251.Invoke_O__O(arg_252) } else { tmp2 = linked_250.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_249, arg_252) }; return lang.RT_Get_O_O__O_NoInit(tmp1, tmp2) }
func A_arbace_go_check_load_eval_build_next_STAR___1660000047_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_eval_build_next_STAR___1660000047_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_next_STAR___1660000047_A{}; t.Ctor_O_O(p0, p1); return t }
//line :62:1
func (t *A_arbace_go_check_load_eval_build_next_STAR___1660000047_A) Ctor_O_O(c__toks, c__pos any) { t.F_toks = c__toks; t.F_pos = c__pos }
//line :62:1
func (t *A_arbace_go_check_load_eval_build_next_STAR___1660000047_A) Invoke_O__O(self any) any { var t__1 any; var tmp1 any = t.F_toks; var tmp2 any; var root_255 any = A_arbace_go_check_load_A_const_7.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_257 lang.IFn; if linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any = t.F_pos; if linked_256 == nil { tmp2 = ifn_257.Invoke_O__O(arg_258) } else { tmp2 = linked_256.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_255, arg_258) }; t__1 = lang.RT_Get_O_O__O_NoInit(tmp1, tmp2); var tmp3 *lang.Volatile = lang.Volatile_Cast(t.F_pos); var tmp4 jrt.Number_I; var na_259 any = jrt.NN(lang.Volatile_Cast(t.F_pos)).Deref__O(); if jrt.Long_InstanceOf(na_259) { var n0_260 int64 = jrt.NN(jrt.Long_Cast(na_259)).LongValue__J(); if n0_260 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_259) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_260 + 1)) } } else { if jrt.Double_InstanceOf(na_259) { var n0_260_2 float64 = jrt.NN(jrt.Double_Cast(na_259)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_260_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_259) } }; jrt.NN(tmp3).Reset_O__O(tmp4); return t__1 }
func A_arbace_go_check_load_eval_build_and_expr__1660000051_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_load_eval_build_and_expr__1660000051_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_and_expr__1660000051_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_and_expr__1660000051_A) Ctor_O_O_O(c__peek_STAR_, c__not_expr, c__next_STAR_ any) { t.F_peek_STAR_ = c__peek_STAR_; t.F_not_expr = c__not_expr; t.F_next_STAR_ = c__next_STAR_ }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_and_expr__1660000051_A) Invoke_O__O(self any) any { { var v__1 any = lang.IFn_Cast(t.F_not_expr).Invoke__O(); L1: for {


	if lang.Util_Equiv_O_O__Z_NoInit(Lit_11, lang.IFn_Cast(t.F_peek_STAR_).Invoke__O()) { lang.IFn_Cast(t.F_next_STAR_).Invoke__O(); var w__2 any = lang.IFn_Cast(t.F_not_expr).Invoke__O(); var tmp1 any; var and__1927000168__auto____3 any = v__1; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = w__2 } else { tmp1 = and__1927000168__auto____3 }; v__1 = tmp1; continue L1 } else { return v__1 } } }; /*line :63:1*/panic("j2g: unreachable") }
//line :63:1
func A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A) Ctor_O_O_O(c__or_expr, c__tags, c__next_STAR_ any) { t.F_or_expr = c__or_expr; t.F_tags = c__tags; t.F_next_STAR_ = c__next_STAR_ }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A) Invoke_O__O(self any) any { var t__1 any = lang.IFn_Cast(t.F_next_STAR_).Invoke__O(); if





	lang.Util_Equiv_O_O__Z_NoInit(Lit_12, t__1) { var v__2 any = lang.IFn_Cast(t.F_or_expr).Invoke__O()
		lang.IFn_Cast(t.F_next_STAR_).Invoke__O()
//line :69:1
		return v__2 } else {

			var root_267 any = A_arbace_go_check_load_A_const_53.GetRawRoot__O(); var linked_268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_267, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_269 lang.IFn; if linked_268 == nil { ifn_269 = lang.IFn_Cast(root_267) } else { ifn_269 = nil }; var arg_270 any = t.F_tags; var arg_271 any = t__1; if linked_268 == nil { return ifn_269.Invoke_O_O__O(arg_270, arg_271) } else { return linked_268.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_267, arg_270, arg_271) } } }
//line :63:1
func A_arbace_go_check_load_eval_build_not_expr__1660000053_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_load_eval_build_not_expr__1660000053_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_not_expr__1660000053_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_not_expr__1660000053_A) Ctor_O_O_O(c__peek_STAR_, c__atom_STAR_, c__next_STAR_ any) { t.F_peek_STAR_ = c__peek_STAR_; t.F_atom_STAR_ = c__atom_STAR_; t.F_next_STAR_ = c__next_STAR_ }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_not_expr__1660000053_A) Invoke_O__O(self any) any {



	if lang.Util_Equiv_O_O__Z_NoInit(Lit_13, lang.IFn_Cast(t.F_peek_STAR_).Invoke__O()) { lang.IFn_Cast(t.F_next_STAR_).Invoke__O(); var root_263 any = A_arbace_go_check_load_A_const_52.GetRawRoot__O(); var linked_264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_263, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_265 lang.IFn; if linked_264 == nil { ifn_265 = lang.IFn_Cast(root_263) } else { ifn_265 = nil }; var arg_266 any = lang.IFn_Cast(self).Invoke__O(); if linked_264 == nil { return ifn_265.Invoke_O__O(arg_266) } else { return linked_264.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_263, arg_266) } } else { return lang.IFn_Cast(t.F_atom_STAR_).Invoke__O() } }
//line :63:1
func A_arbace_go_check_load_eval_build_or_expr__1660000049_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_load_eval_build_or_expr__1660000049_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_or_expr__1660000049_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_or_expr__1660000049_A) Ctor_O_O_O(c__peek_STAR_, c__and_expr, c__next_STAR_ any) { t.F_peek_STAR_ = c__peek_STAR_; t.F_and_expr = c__and_expr; t.F_next_STAR_ = c__next_STAR_ }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_or_expr__1660000049_A) Invoke_O__O(self any) any { { var v__1 any = lang.IFn_Cast(t.F_and_expr).Invoke__O(); L1: for {
												if lang.Util_Equiv_O_O__Z_NoInit(Lit_14, lang.IFn_Cast(t.F_peek_STAR_).Invoke__O()) { lang.IFn_Cast(t.F_next_STAR_).Invoke__O(); var w__2 any = lang.IFn_Cast(t.F_and_expr).Invoke__O(); var tmp1 any; var or__1927000174__auto____3 any = v__1; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = w__2 }; v__1 = tmp1; continue L1 } else { return v__1 } } }; /*line :63:1*/panic("j2g: unreachable") }










func A_arbace_go_check_load_good_os_arch_file_QMARK__A_New() *A_arbace_go_check_load_good_os_arch_file_QMARK__A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_good_os_arch_file_QMARK__A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_go_check_load_good_os_arch_file_QMARK__A) Ctor() {}
//line :74:1
func (t *A_arbace_go_check_load_good_os_arch_file_QMARK__A) Invoke_O_O_O_O__O(self, fname__0, goos__1, goarch__2 any) any { var n__4 any; var root_280 any = A_arbace_go_check_load_A_const_13.GetRawRoot__O(); var linked_281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_280, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_282 lang.IFn; if


	linked_281 == nil { ifn_282 = lang.IFn_Cast(root_280) } else { ifn_282 = nil }; var arg_283 any = fname__0; var arg_284 any = A_arbace_go_check_load_A_const_54; var arg_285 any = Lit_4; if linked_281 == nil { n__4 = ifn_282.Invoke_O_O_O__O(arg_283, arg_284, arg_285) } else { n__4 = linked_281.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_280, arg_283, arg_284, arg_285) }; var n__5 any; var temp__1927000408__auto____5 any; var root_286 any = /*line :74:1*/A_arbace_go_check_load_A_const_55.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_288 lang.IFn; if



	linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = n__4; var arg_290 any = Lit_17; if linked_287 == nil { temp__1927000408__auto____5 = ifn_288.Invoke_O_O__O(arg_289, arg_290) } else { temp__1927000408__auto____5 = linked_287.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_286, arg_289, arg_290) }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var i__6 any = temp__1927000408__auto____5; var root_291 any = A_arbace_go_check_load_A_const_42.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = n__4; var arg_295 any = i__6; if linked_292 == nil { n__5 = ifn_293.Invoke_O_O__O(arg_294, arg_295) } else { n__5 = linked_292.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_291, arg_294, arg_295) } } else { n__5 = Lit_4 }; var parts__6 any; var root_296 any = /*line :74:1*/A_arbace_go_check_load_A_const_47.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_298 lang.IFn; if




	linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any; var root_300 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any; var root_304 any = A_arbace_go_check_load_A_const_15.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = n__5; var arg_308 any = A_arbace_go_check_load_A_const_56; if linked_305 == nil { arg_303 = ifn_306.Invoke_O_O__O(arg_307, arg_308) } else { arg_303 = linked_305.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_304, arg_307, arg_308) }; if linked_301 == nil { arg_299 = ifn_302.Invoke_O__O(arg_303) } else { arg_299 = linked_301.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_300, arg_303) }; if linked_297 == nil { parts__6 = ifn_298.Invoke_O__O(arg_299) } else { parts__6 = linked_297.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_296, arg_299) }; var l__7 int32 = /*line :74:1*/lang.RT_Count_O__I_NoInit(parts__6); var parts__8 any; var tmp1 bool; var and__1927000168__auto____8 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(l__7), 1); if and__1927000168__auto____8 {






		var tmp2 any; var root_309 any = A_arbace_go_check_load_A_const_57.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any = parts__6; if linked_310 == nil { tmp2 = ifn_311.Invoke_O__O(arg_312) } else { tmp2 = linked_310.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_309, arg_312) }; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(Lit_18, tmp2) } else { tmp1 = and__1927000168__auto____8 }; if tmp1 { var root_313 any = A_arbace_go_check_load_A_const_58.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_pop_A_fn_class); var ifn_315 lang.IFn; if linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = parts__6; if linked_314 == nil { parts__8 = ifn_315.Invoke_O__O(arg_316) } else { parts__8 = linked_314.(*aot_arbace_core.A_arbace_core_pop_A).Invoke_O_O__O(root_313, arg_316) } } else { parts__8 = parts__6 }; var l__9 int32 = /*line :74:1*/lang.RT_Count_O__I_NoInit(parts__8); var tmp3 any; var and__1927000168__auto____10 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(l__9), 2); if and__1927000168__auto____10 {









			var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_go_check_load_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 2)))); if jrt.J2g_Truth(and__1927000168__auto____11) { tmp3 = lang.IFn_Cast(A_arbace_go_check_load_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 1)))) } else { tmp3 = and__1927000168__auto____11 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }; if /*line :83:1*/ jrt.J2g_Truth(tmp3) { var and__1927000168__auto____10_2 bool = lang.Util_Equiv_O_O__Z_NoInit(goarch__2, lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 1))))

				if and__1927000168__auto____10_2 { var or__1927000174__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(goos__1, lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 2)))); if or__1927000174__auto____11 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11).Ref() } else { var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_19, lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 2)))); if and__1927000168__auto____12 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(goos__1, Lit_20)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12).Ref() } } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_2).Ref() } } else {
//line :83:1
					var tmp4 any; var and__1927000168__auto____10_3 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(l__9), 1)


					if and__1927000168__auto____10_3 { tmp4 = lang.IFn_Cast(A_arbace_go_check_load_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 1)))) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_3).Ref() }
//line :83:1
					if jrt.J2g_Truth(tmp4) { var o__10 any = lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 1))); var or__1927000174__auto____11_2 bool = lang.Util_Equiv_O_O__Z_NoInit(o__10, goos__1)




						if or__1927000174__auto____11_2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11_2).Ref() } else { var or__1927000174__auto____12 bool; var and__1927000168__auto____12_2 bool = lang.Util_Equiv_O_O__Z_NoInit(o__10, Lit_19); if and__1927000168__auto____12_2 { or__1927000174__auto____12 = lang.Util_Equiv_O_O__Z_NoInit(goos__1, Lit_20) } else { or__1927000174__auto____12 = and__1927000168__auto____12_2 }; if or__1927000174__auto____12 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____12).Ref() } else { var and__1927000168__auto____13 bool = lang.Util_Equiv_O_O__Z_NoInit(o__10, Lit_21); if and__1927000168__auto____13 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(goos__1, Lit_22)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____13).Ref() } } } } else {
//line :83:1
							var tmp5 any; var and__1927000168__auto____10_4 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(l__9), 1)





							if and__1927000168__auto____10_4 { tmp5 = lang.IFn_Cast(A_arbace_go_check_load_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 1)))) } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_4).Ref() }
//line :83:1
							if jrt.J2g_Truth(tmp5) {





								return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(goarch__2, lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 1))))).Ref() } else {
//line :83:1
									if A_arbace_go_check_load_A_const_61 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } } }








func A_arbace_go_check_load_file_included_QMARK__A_New() *A_arbace_go_check_load_file_included_QMARK__A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_file_included_QMARK__A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_go_check_load_file_included_QMARK__A) Ctor() {}
//line :92:1
func (t *A_arbace_go_check_load_file_included_QMARK__A) Invoke_O_O_O_O_O__O(self, fname__0, opts__1, config__2, tags__3 any) any { var and__1927000168__auto____5 any; var root_317 any = A_arbace_go_check_load_A_const_62.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, A_arbace_go_check_load_good_os_arch_file_QMARK__A_fn_class); var ifn_319 lang.IFn; if


	linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = fname__0; var arg_321 any = A_arbace_go_check_load_A_const_21.Invoke_O__O(config__2); var arg_322 any = A_arbace_go_check_load_A_const_22.Invoke_O__O(config__2); if linked_318 == nil { and__1927000168__auto____5 = ifn_319.Invoke_O_O_O__O(arg_320, arg_321, arg_322) } else { and__1927000168__auto____5 = linked_318.(*A_arbace_go_check_load_good_os_arch_file_QMARK__A).Invoke_O_O_O_O__O(root_317, arg_320, arg_321, arg_322) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
		var root_323 any = A_arbace_go_check_load_A_const_63.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any; var fnbody__339 any = A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A_New_O(tags__3); var tmp1 *jrt.Class; var fncls__338 *jrt.Class = A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A_fn_class; if fncls__338 == nil { var fncls__338d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__339); A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A_fn_class = fncls__338d; tmp1 = fncls__338d } else { tmp1 = fncls__338 }; arg_326 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__339, tmp1, nil); var arg_327 any = A_arbace_go_check_load_A_const_66.Invoke_O__O(opts__1); if linked_324 == nil { return ifn_325.Invoke_O_O__O(arg_326, arg_327) } else { return linked_324.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_323, arg_326, arg_327) } } else {
//line :95:1
			return and__1927000168__auto____5 } }
func A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A_New_O(p0 any) *A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A{}; t.Ctor_O(p0); return t }
//line :96:1
func (t *A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A) Ctor_O(c__tags any) { t.F_tags = c__tags }
//line :96:1
func (t *A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 any; var root_328 any = A_arbace_go_check_load_A_const_64.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = b__1; var arg_332 any = Lit_16; if linked_329 == nil { tmp1 = ifn_330.Invoke_O_O__O(arg_331, arg_332) } else { tmp1 = linked_329.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_328, arg_331, arg_332) }; if jrt.J2g_Truth(tmp1) { var root_333 any = A_arbace_go_check_load_A_const_65.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, A_arbace_go_check_load_eval_build_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = b__1; var arg_337 any = t.F_tags; if linked_334 == nil { return ifn_335.Invoke_O_O__O(arg_336, arg_337) } else { return linked_334.(*A_arbace_go_check_load_eval_build_A).Invoke_O_O_O__O(root_333, arg_336, arg_337) } } else { return jrt.Boolean_TRUE.Ref() } }






func A_arbace_go_check_load_read_forms_A_New() *A_arbace_go_check_load_read_forms_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_read_forms_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_go_check_load_read_forms_A) Ctor() {}
//line :103:1
func (t *A_arbace_go_check_load_read_forms_A) Invoke_O_O__O(self, f__0 any) any { var k__2 any = jrt.File_Cast(f__0).GetPath__String().Ref(); var or__1927000174__auto____3 any = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(A_arbace_go_check_load_A_const_67.GetRawRoot__O(), Lit_40, jrt.RefArrayOf(jrt.Object_class, k__2)); if



	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var v__4 any; var root_340 any = A_arbace_go_check_load_A_const_68.GetRawRoot__O(); var linked_341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_340, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_342 lang.IFn
		if linked_341 == nil { ifn_342 = lang.IFn_Cast(root_340) } else { ifn_342 = nil }; var arg_343 any = f__0; if linked_341 == nil { v__4 = ifn_342.Invoke_O__O(arg_343) } else { v__4 = linked_341.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_340, arg_343) }
		lang.Reflector_InvokeInstanceMethod_O_String_O1__O(A_arbace_go_check_load_A_const_67.GetRawRoot__O(), Lit_41, jrt.RefArrayOf(jrt.Object_class, k__2, v__4))
//line :107:1
		return v__4 } }




func A_arbace_go_check_load_clear_cache_BANG__A_New() *A_arbace_go_check_load_clear_cache_BANG__A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_clear_cache_BANG__A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_go_check_load_clear_cache_BANG__A) Ctor() {}
//line :112:1
func (t *A_arbace_go_check_load_clear_cache_BANG__A) Invoke_O__O(self any) any { return lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(A_arbace_go_check_load_A_const_67.GetRawRoot__O(), Lit_1, false) }

func A_arbace_go_check_load_overlay_file_A_New() *A_arbace_go_check_load_overlay_file_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_overlay_file_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_go_check_load_overlay_file_A) Ctor() {}
//line :114:1
func (t *A_arbace_go_check_load_overlay_file_A) Invoke_O_O_O__O(self, root__0, rel__1 any) any { var ov__3 any; if


	jrt.J2g_Truth(A_arbace_go_check_load_A_const_69.Invoke_O__O(root__0)) { ov__3 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_load_A_const_69.Invoke_O__O(root__0), nil, rel__1))) } else { ov__3 = nil }; var tmp1 any; var and__1927000168__auto____4 any = ov__3; if
	jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(ov__3).IsFile__Z()).Ref() } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { return ov__3 } else { return jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_load_A_const_70.Invoke_O__O(root__0), nil, rel__1))) } }

func A_arbace_go_check_load_collect_package_A_New() *A_arbace_go_check_load_collect_package_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_collect_package_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_go_check_load_collect_package_A) Ctor() {}
//line :120:1
func (t *A_arbace_go_check_load_collect_package_A) Invoke_O_O_O__O(self, root__0, pf__1 any) any { var base__3 any; var tmp1 any; var root_344 any = A_arbace_go_check_load_A_const_71.GetRawRoot__O(); var linked_345 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_344, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_346 lang.IFn; if



	linked_345 == nil { ifn_346 = lang.IFn_Cast(root_344) } else { ifn_346 = nil }; var arg_347 any = A_arbace_go_check_load_A_const_70.Invoke_O__O(root__0); if linked_345 == nil { tmp1 = ifn_346.Invoke_O__O(arg_347) } else { tmp1 = linked_345.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_344, arg_347) }; base__3 = jrt.File_New_String(jrt.String_Cast(tmp1)).GetCanonicalPath__String().Ref(); var root_348 any =
	A_arbace_go_check_load_A_const_72.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = pf__1; var arg_352 any; var fnbody__373 any = A_arbace_go_check_load_collect_package_fn__1660000065_A_New_O_O(root__0, base__3); var tmp2 *jrt.Class; var fncls__372 *jrt.Class = A_arbace_go_check_load_collect_package_fn__1660000065_A_fn_class; if fncls__372 == nil { var fncls__372d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__373); A_arbace_go_check_load_collect_package_fn__1660000065_A_fn_class = fncls__372d; tmp2 = fncls__372d } else { tmp2 = fncls__372 }; arg_352 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__373, tmp2, nil); if linked_349 == nil { return ifn_350.Invoke_O_O__O(arg_351, arg_352) } else { return linked_349.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A).Invoke_O_O_O__O(root_348, arg_351, arg_352) } }
//line :125:1
func A_arbace_go_check_load_collect_package_fn__1660000065_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_collect_package_fn__1660000065_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_collect_package_fn__1660000065_A{}; t.Ctor_O_O(p0, p1); return t }
//line :125:1
func (t *A_arbace_go_check_load_collect_package_fn__1660000065_A) Ctor_O_O(c__root, c__base any) { t.F_root = c__root; t.F_base = c__base }
//line :125:1
func (t *A_arbace_go_check_load_collect_package_fn__1660000065_A) Invoke_O_O__O(self, f__1 any) any { var p__2 any = jrt.File_Cast(f__1).GetCanonicalPath__String().Ref(); var rel__3 any; var tmp1 any; var root_353 any = A_arbace_go_check_load_A_const_64.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_353, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_355 lang.IFn; if

	linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any = p__2; var arg_357 any = t.F_base; if linked_354 == nil { tmp1 = ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { tmp1 = linked_354.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_353, arg_356, arg_357) }; if jrt.J2g_Truth(tmp1) { var root_358 any = A_arbace_go_check_load_A_const_42.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = p__2; var arg_362 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_base)))).Ref(); if linked_359 == nil { rel__3 = ifn_360.Invoke_O_O__O(arg_361, arg_362) } else { rel__3 = linked_359.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_358, arg_361, arg_362) } } else { rel__3 = nil }; var root_363 any =
	A_arbace_go_check_load_A_const_73.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, A_arbace_go_check_load_read_forms_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any; if jrt.J2g_Truth(rel__3) { var root_367 any = A_arbace_go_check_load_A_const_74.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, A_arbace_go_check_load_overlay_file_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = t.F_root; var arg_371 any = rel__3; if linked_368 == nil { arg_366 = ifn_369.Invoke_O_O__O(arg_370, arg_371) } else { arg_366 = linked_368.(*A_arbace_go_check_load_overlay_file_A).Invoke_O_O_O__O(root_367, arg_370, arg_371) } } else { arg_366 = f__1 }; if linked_364 == nil { return ifn_365.Invoke_O__O(arg_366) } else { return linked_364.(*A_arbace_go_check_load_read_forms_A).Invoke_O_O__O(root_363, arg_366) } }

func A_arbace_go_check_load_package_source_A_New() *A_arbace_go_check_load_package_source_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_go_check_load_package_source_A) Ctor() {}
//line :130:1
func (t *A_arbace_go_check_load_package_source_A) Invoke_O_O_O_O_O__O(self, root__0, path__1, config__2, pf__3 any) any { var pf__5 any; var or__1927000174__auto____5 any = pf__3; if





	jrt.J2g_Truth(or__1927000174__auto____5) { pf__5 = or__1927000174__auto____5 } else { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_25, nil); var tmp2 any = A_arbace_go_check_load_A_const_70.Invoke_O__O(root__0); var tmp3 any; var root_374 any = A_arbace_go_check_load_A_const_75.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any; var root_378 any = A_arbace_go_check_load_A_const_76.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = path__1; if linked_379 == nil { arg_377 = ifn_380.Invoke_O__O(arg_381) } else { arg_377 = linked_379.(*A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_378, arg_381) }; if linked_375 == nil { tmp3 = ifn_376.Invoke_O__O(arg_377) } else { tmp3 = linked_375.(*A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_374, arg_377) }; pf__5 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, tmp3))) }; if
	jrt.File_Cast(pf__5).IsFile__Z() { var map__1660000069__6 any; var root_382 any = A_arbace_go_check_load_A_const_77.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_382, A_arbace_go_check_load_collect_package_A_fn_class); var ifn_384 lang.IFn
		if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = root__0; var arg_386 any = pf__5; if linked_383 == nil { map__1660000069__6 = ifn_384.Invoke_O_O__O(arg_385, arg_386) } else { map__1660000069__6 = linked_383.(*A_arbace_go_check_load_collect_package_A).Invoke_O_O_O__O(root_382, arg_385, arg_386) }
//line :137:1
		var map__1660000069__7 any
		if lang.ISeq_InstanceOf(map__1660000069__6) { var tmp4 any; var root_387 any = A_arbace_go_check_load_A_const_17.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any = map__1660000069__6; if linked_388 == nil { tmp4 = ifn_389.Invoke_O__O(arg_390) } else { tmp4 = linked_388.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_387, arg_390) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_391 any = A_arbace_go_check_load_A_const_18.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = map__1660000069__6; if linked_392 == nil { tmp5 = ifn_393.Invoke_O__O(arg_394) } else { tmp5 = linked_392.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_391, arg_394) }; map__1660000069__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp5)).Ref() } else { var tmp6 any; var root_395 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_396 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_395, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_397 lang.IFn; if linked_396 == nil { ifn_397 = lang.IFn_Cast(root_395) } else { ifn_397 = nil }; var arg_398 any = map__1660000069__6; if linked_396 == nil { tmp6 = ifn_397.Invoke_O__O(arg_398) } else { tmp6 = linked_396.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_395, arg_398) }; if jrt.J2g_Truth(tmp6) { var root_399 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any = map__1660000069__6; if linked_400 == nil { map__1660000069__7 = ifn_401.Invoke_O__O(arg_402) } else { map__1660000069__7 = linked_400.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_399, arg_402) } } else { map__1660000069__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1660000069__7 = map__1660000069__6 }
//line :137:1
		var package__8 any = lang.RT_Get_O_O__O_NoInit(map__1660000069__7, A_arbace_go_check_load_A_const_78); var name__9 any = lang.RT_Get_O_O__O_NoInit(map__1660000069__7, A_arbace_go_check_load_A_const_79); var files__10 any = lang.RT_Get_O_O__O_NoInit(map__1660000069__7, A_arbace_go_check_load_A_const_80); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_check_load_A_const_81.GetRawRoot__O()); var tmp8 any = A_arbace_go_check_load_A_const_82; var config__11 any = tmp7.Invoke_O_O_O__O(tmp8, A_arbace_go_check_load_A_const_83.Invoke_O__O(package__8), config__2); var tags__12 any; var root_409 any = A_arbace_go_check_load_A_const_84.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, A_arbace_go_check_load_tag_set_A_fn_class); var ifn_411 lang.IFn


		if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = config__11; if linked_410 == nil { tags__12 = ifn_411.Invoke_O__O(arg_412) } else { tags__12 = linked_410.(*A_arbace_go_check_load_tag_set_A).Invoke_O_O__O(root_409, arg_412) }
//line :137:1
		var files__13 any; var root_413 any = A_arbace_go_check_load_A_const_47.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_415 lang.IFn



		if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any; var iter__1927001039__auto____13 any; var fnbody__508 any = A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A_New_O_O(tags__12, config__11); var tmp9 *jrt.Class; var fncls__507 *jrt.Class = A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A_fn_class; if fncls__507 == nil { var fncls__507d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_34, false, fnbody__508); A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A_fn_class = fncls__507d; tmp9 = fncls__507d } else { tmp9 = fncls__507 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__508, tmp9, nil); arg_416 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(files__10); if linked_414 == nil { files__13 = ifn_415.Invoke_O__O(arg_416) } else { files__13 = linked_414.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_413, arg_416) }
//line :137:1
		var tmp10 any = A_arbace_go_check_load_A_const_88; var tmp11 any; var or__1927000174__auto____14 any = A_arbace_go_check_load_A_const_88.Invoke_O__O(package__8)







		if jrt.J2g_Truth(or__1927000174__auto____14) { tmp11 = or__1927000174__auto____14 } else { tmp11 = path__1 }
//line :137:1
		var tmp12 any = tmp11; var tmp13 any = A_arbace_go_check_load_A_const_79; var tmp14 any; var root_509 any = A_arbace_go_check_load_A_const_89.GetRawRoot__O(); var linked_510 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_509, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_511 lang.IFn







		if linked_510 == nil { ifn_511 = lang.IFn_Cast(root_509) } else { ifn_511 = nil }; var arg_512 any = name__9; if linked_510 == nil { tmp14 = ifn_511.Invoke_O__O(arg_512) } else { tmp14 = linked_510.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_509, arg_512) }
//line :137:1
		var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_load_A_const_83; var tmp17 any = A_arbace_go_check_load_A_const_85; var tmp18 any = A_arbace_go_check_load_A_const_80; var tmp19 any = A_arbace_go_check_load_A_const_90; var tmp20 any = jrt.File_Cast(pf__5).GetPath__String().Ref(); var tmp21 any = A_arbace_go_check_load_A_const_91; var tmp22 any; var root_513 any = A_arbace_go_check_load_A_const_92.GetRawRoot__O(); var linked_514 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_513, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_515 lang.IFn









		if linked_514 == nil { ifn_515 = lang.IFn_Cast(root_513) } else { ifn_515 = nil }; var arg_516 any; var fnbody__527 any = A_arbace_go_check_load_package_source_fn__1660000081_A_New(); var tmp23 *jrt.Class; var fncls__526 *jrt.Class = A_arbace_go_check_load_package_source_fn__1660000081_A_fn_class; if fncls__526 == nil { var fncls__526d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_go_check_load_package_source_fn__1660000081_A_fn_class = fncls__526d; tmp23 = fncls__526d } else { tmp23 = fncls__526 }; arg_516 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__527, tmp23, nil); var arg_517 any; var root_528 any = A_arbace_go_check_load_A_const_73.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, A_arbace_go_check_load_read_forms_A_fn_class); var ifn_530 lang.IFn; if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = pf__5; if linked_529 == nil { arg_517 = ifn_530.Invoke_O__O(arg_531) } else { arg_517 = linked_529.(*A_arbace_go_check_load_read_forms_A).Invoke_O_O__O(root_528, arg_531) }; if linked_514 == nil { tmp22 = ifn_515.Invoke_O_O__O(arg_516, arg_517) } else { tmp22 = linked_514.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_513, arg_516, arg_517) }
//line :137:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp13, tmp15, tmp16, config__11, tmp17, package__8, tmp18, files__13, tmp19, tmp20, tmp21, tmp22)) } else { return nil } }
//line :130:1
func (t *A_arbace_go_check_load_package_source_A) Invoke_O_O_O_O__O(self, root__0, path__1, config__2 any) any {



	var root_532 any = A_arbace_go_check_load_A_const_96.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, A_arbace_go_check_load_package_source_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = root__0; var arg_536 any = path__1; var arg_537 any = config__2; var arg_538 any; if linked_533 == nil { return ifn_534.Invoke_O_O_O_O__O(arg_535, arg_536, arg_537, arg_538) } else { return linked_533.(*A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_532, arg_535, arg_536, arg_537, arg_538)
	}
}




func A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A{}; t.Ctor_O_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A) Ctor_O_O(c__tags, c__config any) { t.F_tags = c__tags; t.F_config = c__config }
//line :141:1
func (t *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A) Invoke_O_O__O(self, s__1660000072__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__506 any = A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A_New_O_O_O_O(s__1660000072__1, t.F_tags, self, t.F_config); var tmp2 *jrt.Class; var fncls__505 *jrt.Class = A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A_fn_class; if fncls__505 == nil { var fncls__505d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__506); A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A_fn_class = fncls__505d; tmp2 = fncls__505d } else { tmp2 = fncls__505 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__506, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :141:1
func A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :141:1
func (t *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A) Ctor_O_O_O_O(c__s__1660000072, c__tags, c__iter__1660000071, c__config any) { t.F_s__1660000072 = c__s__1660000072; t.F_tags = c__tags; t.F_iter__1660000071 = c__iter__1660000071; t.F_config = c__config }
//line :141:1
func (t *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A) Invoke_O__O(self any) any { { var s__1660000072__1 any; var t_ any = t.F_s__1660000072; t.F_s__1660000072 = nil; s__1660000072__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_417 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = s__1660000072__1; if linked_418 == nil { temp__1927000414__auto____2 = ifn_419.Invoke_O__O(arg_420) } else { temp__1927000414__auto____2 = linked_418.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_417, arg_420) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1660000072__3 any = temp__1927000414__auto____2; var tmp1 any; var root_421 any = A_arbace_go_check_load_A_const_28.GetRawRoot__O(); var linked_422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_421, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_423 lang.IFn; if linked_422 == nil { ifn_423 = lang.IFn_Cast(root_421) } else { ifn_423 = nil }; var arg_424 any = s__1660000072__3; if linked_422 == nil { tmp1 = ifn_423.Invoke_O__O(arg_424) } else { tmp1 = linked_422.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_421, arg_424) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_425 any = A_arbace_go_check_load_A_const_29.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_427 lang.IFn; if linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = s__1660000072__3; if linked_426 == nil { c__1927001037__auto____4 = ifn_427.Invoke_O__O(arg_428) } else { c__1927001037__auto____4 = linked_426.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_425, arg_428) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1660000074__6 any; var root_429 any = A_arbace_go_check_load_A_const_30.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_431 lang.IFn; if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_430 == nil { b__1660000074__6 = ifn_431.Invoke_O__O(arg_432) } else { b__1660000074__6 = linked_430.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_429, arg_432) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__452 any = A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A_New_O_O_O_I_O(t.F_tags, t.F_config, b__1660000074__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__451 *jrt.Class = A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A_fn_class; if fncls__451 == nil { var fncls__451d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, fnbody__452); A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A_fn_class = fncls__451d; tmp3 = fncls__451d } else { tmp3 = fncls__451 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__452, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_453 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any; var root_458 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = b__1660000074__6; if linked_459 == nil { arg_456 = ifn_460.Invoke_O__O(arg_461) } else { arg_456 = linked_459.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_458, arg_461) }; var arg_457 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1660000071); var tmp5 any; var root_462 any = A_arbace_go_check_load_A_const_34.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = s__1660000072__3; if linked_463 == nil { tmp5 = ifn_464.Invoke_O__O(arg_465) } else { tmp5 = linked_463.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_462, arg_465) }; arg_457 = tmp4.Invoke_O__O(tmp5); if linked_454 == nil { return ifn_455.Invoke_O_O__O(arg_456, arg_457) } else { return linked_454.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_453, arg_456, arg_457) } } else { var root_466 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any; var root_471 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_471, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_473 lang.IFn; if linked_472 == nil { ifn_473 = lang.IFn_Cast(root_471) } else { ifn_473 = nil }; var arg_474 any = b__1660000074__6; if linked_472 == nil { arg_469 = ifn_473.Invoke_O__O(arg_474) } else { arg_469 = linked_472.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_471, arg_474) }; var arg_470 any; if linked_467 == nil { return ifn_468.Invoke_O_O__O(arg_469, arg_470) } else { return linked_467.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_466, arg_469, arg_470) } } } else { var fi__4 any; var root_475 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = s__1660000072__3; if linked_476 == nil { fi__4 = ifn_477.Invoke_O__O(arg_478) } else { fi__4 = linked_476.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_475, arg_478) }; var opts__5 any = A_arbace_go_check_load_A_const_85.Invoke_O__O(fi__4); var tmp6 any; var root_479 any = A_arbace_go_check_load_A_const_86.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_479, A_arbace_go_check_load_file_included_QMARK__A_fn_class); var ifn_481 lang.IFn

	if linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = A_arbace_go_check_load_A_const_79.Invoke_O__O(fi__4); var arg_483 any = opts__5; var arg_484 any = t.F_config; var arg_485 any = t.F_tags; if linked_480 == nil { tmp6 = ifn_481.Invoke_O_O_O_O__O(arg_482, arg_483, arg_484, arg_485) } else { tmp6 = linked_480.(*A_arbace_go_check_load_file_included_QMARK__A).Invoke_O_O_O_O_O__O(root_479, arg_482, arg_483, arg_484, arg_485) }
//line :141:1
	if jrt.J2g_Truth(tmp6) { var root_486 any = A_arbace_go_check_load_A_const_35.GetRawRoot__O(); var linked_487 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_486, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_488 lang.IFn; if linked_487 == nil { ifn_488 = lang.IFn_Cast(root_486) } else { ifn_488 = nil }; var arg_489 any; var root_491 any = A_arbace_go_check_load_A_const_87.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_493 lang.IFn


		if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = fi__4; var arg_495 any = A_arbace_go_check_load_A_const_85; var arg_496 any = opts__5; if linked_492 == nil { arg_489 = ifn_493.Invoke_O_O_O__O(arg_494, arg_495, arg_496) } else { arg_489 = linked_492.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_491, arg_494, arg_495, arg_496) }
//line :141:1
		var arg_490 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1660000071); var tmp8 any; var root_497 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_499 lang.IFn; if linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = s__1660000072__3; if linked_498 == nil { tmp8 = ifn_499.Invoke_O__O(arg_500) } else { tmp8 = linked_498.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_497, arg_500) }; arg_490 = tmp7.Invoke_O__O(tmp8); if linked_487 == nil { return ifn_488.Invoke_O_O__O(arg_489, arg_490) } else { return linked_487.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_486, arg_489, arg_490) } } else { var tmp9 any; var root_501 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_501, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_503 lang.IFn; if linked_502 == nil { ifn_503 = lang.IFn_Cast(root_501) } else { ifn_503 = nil }; var arg_504 any = s__1660000072__3; if linked_502 == nil { tmp9 = ifn_503.Invoke_O__O(arg_504) } else { tmp9 = linked_502.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_501, arg_504) }; s__1660000072__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :141:1
func A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :141:1
func (t *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A) Ctor_O_O_O_I_O(c__tags, c__config, c__b__1660000074 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_tags = c__tags; t.F_config = c__config; t.F_b__1660000074 = c__b__1660000074; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :141:1
func (t *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A) Invoke_O__O(self any) any { { var i__1660000073__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1660000073__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1660000073__1)); var opts__3 any = A_arbace_go_check_load_A_const_85.Invoke_O__O(fi__2); var tmp2 any; var root_433 any = A_arbace_go_check_load_A_const_86.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, A_arbace_go_check_load_file_included_QMARK__A_fn_class); var ifn_435 lang.IFn

	if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = A_arbace_go_check_load_A_const_79.Invoke_O__O(fi__2); var arg_437 any = opts__3; var arg_438 any = t.F_config; var arg_439 any = t.F_tags; if linked_434 == nil { tmp2 = ifn_435.Invoke_O_O_O_O__O(arg_436, arg_437, arg_438, arg_439) } else { tmp2 = linked_434.(*A_arbace_go_check_load_file_included_QMARK__A).Invoke_O_O_O_O_O__O(root_433, arg_436, arg_437, arg_438, arg_439) }
//line :141:1
	if jrt.J2g_Truth(tmp2) { var root_440 any = A_arbace_go_check_load_A_const_31.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_442 lang.IFn; if linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = t.F_b__1660000074; var arg_444 any; var root_445 any = A_arbace_go_check_load_A_const_87.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_447 lang.IFn


		if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = fi__2; var arg_449 any = A_arbace_go_check_load_A_const_85; var arg_450 any = opts__3; if linked_446 == nil { arg_444 = ifn_447.Invoke_O_O_O__O(arg_448, arg_449, arg_450) } else { arg_444 = linked_446.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_445, arg_448, arg_449, arg_450) }
//line :141:1
		if linked_441 == nil { ifn_442.Invoke_O_O__O(arg_443, arg_444) } else { linked_441.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_440, arg_443, arg_444) }; i__1660000073__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1660000073__1); continue L1 } else { i__1660000073__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1660000073__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_check_load_package_source_fn__1660000081_A_New() *A_arbace_go_check_load_package_source_fn__1660000081_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_fn__1660000081_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_go_check_load_package_source_fn__1660000081_A) Ctor() {}
//line :147:1
func (t *A_arbace_go_check_load_package_source_fn__1660000081_A) Invoke_O_O__O(self, p1__1660000068_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_518 any = A_arbace_go_check_load_A_const_93.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = p1__1660000068_SHARP___1; if linked_519 == nil { and__1927000168__auto____2 = ifn_520.Invoke_O__O(arg_521) } else { and__1927000168__auto____2 = linked_519.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_518, arg_521) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_load_A_const_94; var tmp3 any; var root_522 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = p1__1660000068_SHARP___1; if linked_523 == nil { tmp3 = ifn_524.Invoke_O__O(arg_525) } else { tmp3 = linked_523.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_522, arg_525) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var tmp4 *lang.Keyword = A_arbace_go_check_load_A_const_95; return tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__1660000068_SHARP___1)) } else { return nil } }

func A_arbace_go_check_load_package_files_A_New() *A_arbace_go_check_load_package_files_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_go_check_load_package_files_A) Ctor() {}
//line :149:1
func (t *A_arbace_go_check_load_package_files_A) Invoke_O_O_O__O(self, root__0, sub__1 any) any { var d__3 any = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_load_A_const_70.Invoke_O__O(root__0), nil, sub__1))); var root_539 any = A_arbace_go_check_load_A_const_97.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_541 lang.IFn; if









	linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any; var fnbody__545 any = A_arbace_go_check_load_package_files_fn__1660000085_A_New(); var tmp1 *jrt.Class; var fncls__544 *jrt.Class = A_arbace_go_check_load_package_files_fn__1660000085_A_fn_class; if fncls__544 == nil { var fncls__544d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_go_check_load_package_files_fn__1660000085_A_fn_class = fncls__544d; tmp1 = fncls__544d } else { tmp1 = fncls__544 }; arg_542 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__545, tmp1, nil); var arg_543 any; var root_546 any = A_arbace_go_check_load_A_const_98.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_548 lang.IFn; if /*line :155:1*/ linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any; var fnbody__585 any = A_arbace_go_check_load_package_files_fn__1660000087_A_New(); var tmp2 *jrt.Class; var fncls__584 *jrt.Class = A_arbace_go_check_load_package_files_fn__1660000087_A_fn_class; if fncls__584 == nil { var fncls__584d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); A_arbace_go_check_load_package_files_fn__1660000087_A_fn_class = fncls__584d; tmp2 = fncls__584d } else { tmp2 = fncls__584 }; arg_549 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__585, tmp2, nil); var arg_550 any; var root_586 any = A_arbace_go_check_load_A_const_98.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_588 lang.IFn; if /*line :154:1*/ linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any; var fnbody__597 any = A_arbace_go_check_load_package_files_fn__1660000091_A_New(); var tmp3 *jrt.Class; var fncls__596 *jrt.Class = A_arbace_go_check_load_package_files_fn__1660000091_A_fn_class; if fncls__596 == nil { var fncls__596d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_go_check_load_package_files_fn__1660000091_A_fn_class = fncls__596d; tmp3 = fncls__596d } else { tmp3 = fncls__596 }; arg_589 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__597, tmp3, nil); var arg_590 any; var root_598 any = A_arbace_go_check_load_A_const_104.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_600 lang.IFn; if /*line :153:1*/ linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = d__3; if linked_599 == nil { arg_590 = ifn_600.Invoke_O__O(arg_601) } else { arg_590 = linked_599.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_598, arg_601) }; if
	linked_587 == nil { arg_550 = ifn_588.Invoke_O_O__O(arg_589, arg_590) } else { arg_550 = linked_587.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_586, arg_589, arg_590) }; if
	linked_547 == nil { arg_543 = ifn_548.Invoke_O_O__O(arg_549, arg_550) } else { arg_543 = linked_547.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_546, arg_549, arg_550) }; if



	linked_540 == nil { return ifn_541.Invoke_O_O__O(arg_542, arg_543) } else { return linked_540.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_539, arg_542, arg_543) } }
//line :154:1
func A_arbace_go_check_load_package_files_fn__1660000091_A_New() *A_arbace_go_check_load_package_files_fn__1660000091_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_fn__1660000091_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_go_check_load_package_files_fn__1660000091_A) Ctor() {}
//line :154:1
func (t *A_arbace_go_check_load_package_files_fn__1660000091_A) Invoke_O_O__O(self, f__1 any) any { var and__1927000168__auto____2 bool = jrt.File_Cast(f__1).IsFile__Z(); if and__1927000168__auto____2 { var root_591 any = A_arbace_go_check_load_A_const_103.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = jrt.File_Cast(f__1).GetName__String().Ref(); var arg_595 any = Lit_23; if linked_592 == nil { return ifn_593.Invoke_O_O__O(arg_594, arg_595) } else { return linked_592.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_591, arg_594, arg_595) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
func A_arbace_go_check_load_package_files_fn__1660000087_A_New() *A_arbace_go_check_load_package_files_fn__1660000087_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_fn__1660000087_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_go_check_load_package_files_fn__1660000087_A) Ctor() {}
//line :155:1
func (t *A_arbace_go_check_load_package_files_fn__1660000087_A) Invoke_O_O__O(self, f__1 any) any { var r__2 any = lang.IFn_Cast(A_arbace_go_check_load_A_const_99.GetRawRoot__O()).Invoke_O__O(f__1); var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var l__5 any; var root_555 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_557 lang.IFn

	if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any; var root_559 any = A_arbace_go_check_load_A_const_100.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any; var fnbody__574 any = A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A_New(); var tmp2 *jrt.Class; var fncls__573 *jrt.Class = A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A_fn_class; if fncls__573 == nil { var fncls__573d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_30, false, nil); A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A_fn_class = fncls__573d; tmp2 = fncls__573d } else { tmp2 = fncls__573 }; arg_562 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__574, tmp2, nil); var arg_563 any; var root_575 any = A_arbace_go_check_load_A_const_102.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_line_seq_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any = r__2; if linked_576 == nil { arg_563 = ifn_577.Invoke_O__O(arg_578) } else { arg_563 = linked_576.(*aot_arbace_core.A_arbace_core_line_seq_A).Invoke_O_O__O(root_575, arg_578) }; if linked_560 == nil { arg_558 = ifn_561.Invoke_O_O__O(arg_562, arg_563) } else { arg_558 = linked_560.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_559, arg_562, arg_563) }; if linked_556 == nil { l__5 = ifn_557.Invoke_O__O(arg_558) } else { l__5 = linked_556.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_555, arg_558) }
//line :155:1
	var and__1927000168__auto____6 any = l__5


	if jrt.J2g_Truth(and__1927000168__auto____6) { var root_579 any = A_arbace_go_check_load_A_const_64.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = l__5; var arg_583 any = Lit_31; if linked_580 == nil { tmp1 = ifn_581.Invoke_O_O__O(arg_582, arg_583) } else { tmp1 = linked_580.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_579, arg_582, arg_583) } } else { tmp1 = and__1927000168__auto____6 } }; return nil }(); /*line :156:1*/jrt.Reader_Cast(r__2).Close__V(); if /*line :155:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }

func A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A_New() *A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A) Invoke_O_O__O(self, p1__1660000084_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_564 any = A_arbace_go_check_load_A_const_101.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = p1__1660000084_SHARP___1; if linked_565 == nil { or__1927000174__auto____2 = ifn_566.Invoke_O__O(arg_567) } else { or__1927000174__auto____2 = linked_565.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_564, arg_567) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_568 any = A_arbace_go_check_load_A_const_64.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = p1__1660000084_SHARP___1; var arg_572 any = Lit_32; if linked_569 == nil { return ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { return linked_569.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_568, arg_571, arg_572) } } }

func A_arbace_go_check_load_package_files_fn__1660000085_A_New() *A_arbace_go_check_load_package_files_fn__1660000085_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_fn__1660000085_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_go_check_load_package_files_fn__1660000085_A) Ctor() {}
//line :159:1
func (t *A_arbace_go_check_load_package_files_fn__1660000085_A) Invoke_O_O__O(self, f__1 any) any { return jrt.File_Cast(f__1).GetPath__String().Ref() }

func A_arbace_go_check_load_package_path_of_A_New() *A_arbace_go_check_load_package_path_of_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_path_of_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_go_check_load_package_path_of_A) Ctor() {}
//line :161:1
func (t *A_arbace_go_check_load_package_path_of_A) Invoke_O_O__O(self, pf__0 any) any { var fs__2 any; var root_602 any = A_arbace_go_check_load_A_const_73.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, A_arbace_go_check_load_read_forms_A_fn_class); var ifn_604 lang.IFn; if


	linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = pf__0; if linked_603 == nil { fs__2 = ifn_604.Invoke_O__O(arg_605) } else { fs__2 = linked_603.(*A_arbace_go_check_load_read_forms_A).Invoke_O_O__O(root_602, arg_605) }; var gp__3 any; var root_606 any = /*line :161:1*/A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_608 lang.IFn; if



	linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any; var root_610 any = A_arbace_go_check_load_A_const_98.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any; var fnbody__624 any = A_arbace_go_check_load_package_path_of_fn__1660000095_A_New(); var tmp1 *jrt.Class; var fncls__623 *jrt.Class = A_arbace_go_check_load_package_path_of_fn__1660000095_A_fn_class; if fncls__623 == nil { var fncls__623d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, nil); A_arbace_go_check_load_package_path_of_fn__1660000095_A_fn_class = fncls__623d; tmp1 = fncls__623d } else { tmp1 = fncls__623 }; arg_613 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__624, tmp1, nil); var arg_614 any = fs__2; if linked_611 == nil { arg_609 = ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { arg_609 = linked_611.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_610, arg_613, arg_614) }; if linked_607 == nil { gp__3 = ifn_608.Invoke_O__O(arg_609) } else { gp__3 = linked_607.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_606, arg_609) }; var tmp2 /*line :166:1*/*lang.Keyword = A_arbace_go_check_load_A_const_88; var tmp3 any; var root_625 any = A_arbace_go_check_load_A_const_106.GetRawRoot__O(); var linked_626 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_625, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_627 lang.IFn; if linked_626 == nil { ifn_627 = lang.IFn_Cast(root_625) } else { ifn_627 = nil }; var arg_628 any = A_arbace_go_check_load_A_const_107.GetRawRoot__O(); var arg_629 any; var root_630 any = A_arbace_go_check_load_A_const_108.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = gp__3; if linked_631 == nil { arg_629 = ifn_632.Invoke_O__O(arg_633) } else { arg_629 = linked_631.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_630, arg_633) }; if linked_626 == nil { tmp3 = ifn_627.Invoke_O_O__O(arg_628, arg_629) } else { tmp3 = linked_626.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_625, arg_628, arg_629) }; return tmp2.Invoke_O__O(tmp3) }
//line :165:1
func A_arbace_go_check_load_package_path_of_fn__1660000095_A_New() *A_arbace_go_check_load_package_path_of_fn__1660000095_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_path_of_fn__1660000095_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_go_check_load_package_path_of_fn__1660000095_A) Ctor() {}
//line :165:1
func (t *A_arbace_go_check_load_package_path_of_fn__1660000095_A) Invoke_O_O__O(self, p1__1660000094_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_615 any = A_arbace_go_check_load_A_const_93.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = p1__1660000094_SHARP___1; if linked_616 == nil { and__1927000168__auto____2 = ifn_617.Invoke_O__O(arg_618) } else { and__1927000168__auto____2 = linked_616.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_615, arg_618) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_load_A_const_105; var tmp2 any; var root_619 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = p1__1660000094_SHARP___1; if linked_620 == nil { tmp2 = ifn_621.Invoke_O__O(arg_622) } else { tmp2 = linked_620.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_619, arg_622) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }






























































































type A_arbace_go_check_load_A struct{ jrt.Object }

var A_arbace_go_check_load_A_const_pool *jrt.RefArray

var A_arbace_go_check_load_A_const_0 *lang.Var

var A_arbace_go_check_load_A_const_1 any

var A_arbace_go_check_load_A_const_2 *lang.Var

var A_arbace_go_check_load_A_const_3 any

var A_arbace_go_check_load_A_const_4 any

var A_arbace_go_check_load_A_const_5 any

var A_arbace_go_check_load_A_const_6 *lang.Var

var A_arbace_go_check_load_A_const_7 *lang.Var

var A_arbace_go_check_load_A_const_8 *lang.Var

var A_arbace_go_check_load_A_const_9 *lang.Var

var A_arbace_go_check_load_A_const_10 any

var A_arbace_go_check_load_A_const_11 *lang.Var

var A_arbace_go_check_load_A_const_12 *lang.Var

var A_arbace_go_check_load_A_const_13 *lang.Var

var A_arbace_go_check_load_A_const_14 any

var A_arbace_go_check_load_A_const_15 *lang.Var

var A_arbace_go_check_load_A_const_16 any

var A_arbace_go_check_load_A_const_17 *lang.Var

var A_arbace_go_check_load_A_const_18 *lang.Var

var A_arbace_go_check_load_A_const_19 *lang.Var

var A_arbace_go_check_load_A_const_20 *lang.Var

var A_arbace_go_check_load_A_const_21 *lang.Keyword

var A_arbace_go_check_load_A_const_22 *lang.Keyword

var A_arbace_go_check_load_A_const_23 *lang.Keyword

var A_arbace_go_check_load_A_const_24 *lang.Keyword

var A_arbace_go_check_load_A_const_25 *lang.Keyword

var A_arbace_go_check_load_A_const_26 *lang.Var

var A_arbace_go_check_load_A_const_27 *lang.Var

var A_arbace_go_check_load_A_const_28 *lang.Var

var A_arbace_go_check_load_A_const_29 *lang.Var

var A_arbace_go_check_load_A_const_30 *lang.Var

var A_arbace_go_check_load_A_const_31 *lang.Var

var A_arbace_go_check_load_A_const_32 *lang.Var

var A_arbace_go_check_load_A_const_33 *lang.Var

var A_arbace_go_check_load_A_const_34 *lang.Var

var A_arbace_go_check_load_A_const_35 *lang.Var

var A_arbace_go_check_load_A_const_36 *lang.Var

var A_arbace_go_check_load_A_const_37 *lang.Var

var A_arbace_go_check_load_A_const_38 any

var A_arbace_go_check_load_A_const_39 any

var A_arbace_go_check_load_A_const_40 *lang.Var

var A_arbace_go_check_load_A_const_41 any

var A_arbace_go_check_load_A_const_42 *lang.Var

var A_arbace_go_check_load_A_const_43 any

var A_arbace_go_check_load_A_const_44 *lang.Var

var A_arbace_go_check_load_A_const_45 *lang.Var

var A_arbace_go_check_load_A_const_46 any

var A_arbace_go_check_load_A_const_47 *lang.Var

var A_arbace_go_check_load_A_const_48 *lang.Var

var A_arbace_go_check_load_A_const_49 any

var A_arbace_go_check_load_A_const_50 *lang.Var

var A_arbace_go_check_load_A_const_51 any

var A_arbace_go_check_load_A_const_52 *lang.Var

var A_arbace_go_check_load_A_const_53 *lang.Var

var A_arbace_go_check_load_A_const_54 any

var A_arbace_go_check_load_A_const_55 *lang.Var

var A_arbace_go_check_load_A_const_56 any

var A_arbace_go_check_load_A_const_57 *lang.Var

var A_arbace_go_check_load_A_const_58 *lang.Var

var A_arbace_go_check_load_A_const_59 *lang.Var

var A_arbace_go_check_load_A_const_60 *lang.Var

var A_arbace_go_check_load_A_const_61 *lang.Keyword

var A_arbace_go_check_load_A_const_62 *lang.Var

var A_arbace_go_check_load_A_const_63 *lang.Var

var A_arbace_go_check_load_A_const_64 *lang.Var

var A_arbace_go_check_load_A_const_65 *lang.Var

var A_arbace_go_check_load_A_const_66 *lang.Keyword

var A_arbace_go_check_load_A_const_67 *lang.Var

var A_arbace_go_check_load_A_const_68 *lang.Var

var A_arbace_go_check_load_A_const_69 *lang.Keyword

var A_arbace_go_check_load_A_const_70 *lang.Keyword

var A_arbace_go_check_load_A_const_71 *lang.Var

var A_arbace_go_check_load_A_const_72 *lang.Var

var A_arbace_go_check_load_A_const_73 *lang.Var

var A_arbace_go_check_load_A_const_74 *lang.Var

var A_arbace_go_check_load_A_const_75 *lang.Var

var A_arbace_go_check_load_A_const_76 *lang.Var

var A_arbace_go_check_load_A_const_77 *lang.Var

var A_arbace_go_check_load_A_const_78 *lang.Keyword

var A_arbace_go_check_load_A_const_79 *lang.Keyword

var A_arbace_go_check_load_A_const_80 *lang.Keyword

var A_arbace_go_check_load_A_const_81 *lang.Var

var A_arbace_go_check_load_A_const_82 any

var A_arbace_go_check_load_A_const_83 *lang.Keyword

var A_arbace_go_check_load_A_const_84 *lang.Var

var A_arbace_go_check_load_A_const_85 *lang.Keyword

var A_arbace_go_check_load_A_const_86 *lang.Var

var A_arbace_go_check_load_A_const_87 *lang.Var

var A_arbace_go_check_load_A_const_88 *lang.Keyword

var A_arbace_go_check_load_A_const_89 *lang.Var

var A_arbace_go_check_load_A_const_90 *lang.Keyword

var A_arbace_go_check_load_A_const_91 *lang.Keyword

var A_arbace_go_check_load_A_const_92 *lang.Var

var A_arbace_go_check_load_A_const_93 *lang.Var

var A_arbace_go_check_load_A_const_94 any

var A_arbace_go_check_load_A_const_95 *lang.Keyword

var A_arbace_go_check_load_A_const_96 *lang.Var

var A_arbace_go_check_load_A_const_97 *lang.Var

var A_arbace_go_check_load_A_const_98 *lang.Var

var A_arbace_go_check_load_A_const_99 *lang.Var

var A_arbace_go_check_load_A_const_100 *lang.Var

var A_arbace_go_check_load_A_const_101 *lang.Var

var A_arbace_go_check_load_A_const_102 *lang.Var

var A_arbace_go_check_load_A_const_103 *lang.Var

var A_arbace_go_check_load_A_const_104 *lang.Var

var A_arbace_go_check_load_A_const_105 any

var A_arbace_go_check_load_A_const_106 *lang.Var

var A_arbace_go_check_load_A_const_107 *lang.Var

var A_arbace_go_check_load_A_const_108 *lang.Var

var A_arbace_go_check_load_A_init jrt.ClassInit

func A_arbace_go_check_load_A_Init() { if !A_arbace_go_check_load_A_init.Done() { A_arbace_go_check_load_A_init.Run(A_arbace_go_check_load_A_clinit) } }

func A_arbace_go_check_load_A_clinit() { A_arbace_go_check_load_A_clinit_p0(); A_arbace_go_check_load_A_clinit_p1(); A_arbace_go_check_load_A_clinit_p2(); A_arbace_go_check_load_A_clinit_p3(); A_arbace_go_check_load_A_clinit_p4(); A_arbace_go_check_load_A_clinit_p5(); A_arbace_go_check_load_A_clinit_p6(); A_arbace_go_check_load_A_clinit_p7(); A_arbace_go_check_load_A_clinit_p8() }

func A_arbace_go_check_load_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_load_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 138); A_arbace_go_check_load_A_const_0 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[29]); A_arbace_go_check_load_A_const_1 = A_arbace_go_check_load_A_const_pool.A[30]; A_arbace_go_check_load_A_const_2 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[31]); A_arbace_go_check_load_A_const_3 = A_arbace_go_check_load_A_const_pool.A[32]; A_arbace_go_check_load_A_const_4 = A_arbace_go_check_load_A_const_pool.A[33]; A_arbace_go_check_load_A_const_5 = A_arbace_go_check_load_A_const_pool.A[34]; A_arbace_go_check_load_A_const_6 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[35]); A_arbace_go_check_load_A_const_7 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[36]); A_arbace_go_check_load_A_const_8 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[37]); A_arbace_go_check_load_A_const_9 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[38]); A_arbace_go_check_load_A_const_10 = A_arbace_go_check_load_A_const_pool.A[39]; A_arbace_go_check_load_A_const_11 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[40]) }

func A_arbace_go_check_load_A_clinit_p1() { A_arbace_go_check_load_A_const_12 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[41]); A_arbace_go_check_load_A_const_13 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[42]); A_arbace_go_check_load_A_const_14 = A_arbace_go_check_load_A_const_pool.A[43]; A_arbace_go_check_load_A_const_15 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[44]); A_arbace_go_check_load_A_const_16 = A_arbace_go_check_load_A_const_pool.A[45]; A_arbace_go_check_load_A_const_17 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[46]); A_arbace_go_check_load_A_const_18 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[47]); A_arbace_go_check_load_A_const_19 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[48]); A_arbace_go_check_load_A_const_20 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[49]); A_arbace_go_check_load_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[50]); A_arbace_go_check_load_A_const_22 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[51]); A_arbace_go_check_load_A_const_23 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[52]) }

func A_arbace_go_check_load_A_clinit_p2() { A_arbace_go_check_load_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[53]); A_arbace_go_check_load_A_const_25 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[54]); A_arbace_go_check_load_A_const_26 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[55]); A_arbace_go_check_load_A_const_27 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[56]); A_arbace_go_check_load_A_const_28 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[57]); A_arbace_go_check_load_A_const_29 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[58]); A_arbace_go_check_load_A_const_30 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[59]); A_arbace_go_check_load_A_const_31 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[60]); A_arbace_go_check_load_A_const_32 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[61]); A_arbace_go_check_load_A_const_33 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[62]); A_arbace_go_check_load_A_const_34 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[63]); A_arbace_go_check_load_A_const_35 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[64]) }

func A_arbace_go_check_load_A_clinit_p3() { A_arbace_go_check_load_A_const_36 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[65]); A_arbace_go_check_load_A_const_37 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[66]); A_arbace_go_check_load_A_const_38 = A_arbace_go_check_load_A_const_pool.A[67]; A_arbace_go_check_load_A_const_39 = A_arbace_go_check_load_A_const_pool.A[68]; A_arbace_go_check_load_A_const_40 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[69]); A_arbace_go_check_load_A_const_41 = A_arbace_go_check_load_A_const_pool.A[70]; A_arbace_go_check_load_A_const_42 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[71]); A_arbace_go_check_load_A_const_43 = A_arbace_go_check_load_A_const_pool.A[72]; A_arbace_go_check_load_A_const_44 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[73]); A_arbace_go_check_load_A_const_45 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[74]); A_arbace_go_check_load_A_const_46 = A_arbace_go_check_load_A_const_pool.A[75]; A_arbace_go_check_load_A_const_47 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[76]); A_arbace_go_check_load_A_const_48 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[77]) }

func A_arbace_go_check_load_A_clinit_p4() { A_arbace_go_check_load_A_const_49 = A_arbace_go_check_load_A_const_pool.A[78]; A_arbace_go_check_load_A_const_50 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[79]); A_arbace_go_check_load_A_const_51 = A_arbace_go_check_load_A_const_pool.A[80]; A_arbace_go_check_load_A_const_52 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[81]); A_arbace_go_check_load_A_const_53 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[82]); A_arbace_go_check_load_A_const_54 = A_arbace_go_check_load_A_const_pool.A[83]; A_arbace_go_check_load_A_const_55 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[84]); A_arbace_go_check_load_A_const_56 = A_arbace_go_check_load_A_const_pool.A[85]; A_arbace_go_check_load_A_const_57 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[86]); A_arbace_go_check_load_A_const_58 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[87]); A_arbace_go_check_load_A_const_59 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[88]); A_arbace_go_check_load_A_const_60 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[89]); A_arbace_go_check_load_A_const_61 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[90]) }

func A_arbace_go_check_load_A_clinit_p5() { A_arbace_go_check_load_A_const_62 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[91]); A_arbace_go_check_load_A_const_63 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[92]); A_arbace_go_check_load_A_const_64 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[93]); A_arbace_go_check_load_A_const_65 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[94]); A_arbace_go_check_load_A_const_66 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[95]); A_arbace_go_check_load_A_const_67 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[96]); A_arbace_go_check_load_A_const_68 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[97]); A_arbace_go_check_load_A_const_69 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[98]); A_arbace_go_check_load_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[99]); A_arbace_go_check_load_A_const_71 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[100]); A_arbace_go_check_load_A_const_72 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[101]); A_arbace_go_check_load_A_const_73 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[102]) }

func A_arbace_go_check_load_A_clinit_p6() { A_arbace_go_check_load_A_const_74 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[103]); A_arbace_go_check_load_A_const_75 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[104]); A_arbace_go_check_load_A_const_76 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[105]); A_arbace_go_check_load_A_const_77 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[106]); A_arbace_go_check_load_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[107]); A_arbace_go_check_load_A_const_79 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[108]); A_arbace_go_check_load_A_const_80 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[109]); A_arbace_go_check_load_A_const_81 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[110]); A_arbace_go_check_load_A_const_82 = A_arbace_go_check_load_A_const_pool.A[111]; A_arbace_go_check_load_A_const_83 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[112]); A_arbace_go_check_load_A_const_84 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[113]); A_arbace_go_check_load_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[114]) }

func A_arbace_go_check_load_A_clinit_p7() { A_arbace_go_check_load_A_const_86 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[115]); A_arbace_go_check_load_A_const_87 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[116]); A_arbace_go_check_load_A_const_88 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[117]); A_arbace_go_check_load_A_const_89 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[118]); A_arbace_go_check_load_A_const_90 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[119]); A_arbace_go_check_load_A_const_91 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[120]); A_arbace_go_check_load_A_const_92 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[121]); A_arbace_go_check_load_A_const_93 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[122]); A_arbace_go_check_load_A_const_94 = A_arbace_go_check_load_A_const_pool.A[123]; A_arbace_go_check_load_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[124]); A_arbace_go_check_load_A_const_96 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[125]); A_arbace_go_check_load_A_const_97 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[126]) }

func A_arbace_go_check_load_A_clinit_p8() { A_arbace_go_check_load_A_const_98 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[127]); A_arbace_go_check_load_A_const_99 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[128]); A_arbace_go_check_load_A_const_100 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[129]); A_arbace_go_check_load_A_const_101 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[130]); A_arbace_go_check_load_A_const_102 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[131]); A_arbace_go_check_load_A_const_103 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[132]); A_arbace_go_check_load_A_const_104 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[133]); A_arbace_go_check_load_A_const_105 = A_arbace_go_check_load_A_const_pool.A[134]; A_arbace_go_check_load_A_const_106 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[135]); A_arbace_go_check_load_A_const_107 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[136]); A_arbace_go_check_load_A_const_108 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[137]) }

func A_arbace_go_check_load_A_New() *A_arbace_go_check_load_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_load_A) Ctor() {}

func (t *A_arbace_go_check_load_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_load_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_load_A_class }

func (t *A_arbace_go_check_load_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_load_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_load_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_load_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_load_A); return ok }

func A_arbace_go_check_load_A_Cast(x any) *A_arbace_go_check_load_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_load_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_load_A_class)) }; return v }



type A_arbace_go_check_load_clear_cache_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_load_clear_cache_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_load_collect_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_collect_package_A_fn_class *jrt.Class



type A_arbace_go_check_load_collect_package_fn__1660000065_A struct{ j2g_header uint64; F_root, F_base any }

var A_arbace_go_check_load_collect_package_fn__1660000065_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval1660000004_A struct{ jrt.Object }

func A_arbace_go_check_load_eval1660000004_A_New() *A_arbace_go_check_load_eval1660000004_A { t := &A_arbace_go_check_load_eval1660000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_load_eval1660000004_A) Ctor() {}

func (t *A_arbace_go_check_load_eval1660000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_load_eval1660000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_load_eval1660000004_A_class }

func (t *A_arbace_go_check_load_eval1660000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_load_eval1660000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_load_eval1660000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_load_eval1660000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_load_eval1660000004_A); return ok }

func A_arbace_go_check_load_eval1660000004_A_Cast(x any) *A_arbace_go_check_load_eval1660000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_load_eval1660000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_load_eval1660000004_A_class)) }; return v }



type A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval1660000008_A struct{ jrt.Object }

func A_arbace_go_check_load_eval1660000008_A_New() *A_arbace_go_check_load_eval1660000008_A { t := &A_arbace_go_check_load_eval1660000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_load_eval1660000008_A) Ctor() {}

func (t *A_arbace_go_check_load_eval1660000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_load_eval1660000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_load_eval1660000008_A_class }

func (t *A_arbace_go_check_load_eval1660000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_load_eval1660000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_load_eval1660000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_load_eval1660000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_load_eval1660000008_A); return ok }

func A_arbace_go_check_load_eval1660000008_A_Cast(x any) *A_arbace_go_check_load_eval1660000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_load_eval1660000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_load_eval1660000008_A_class)) }; return v }



type A_arbace_go_check_load_eval1660000008_fn__1660000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_eval1660000008_fn__1660000009_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_eval_build_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_and_expr__1660000051_A struct{ j2g_header uint64; F_peek_STAR_, F_not_expr, F_next_STAR_ any }

var A_arbace_go_check_load_eval_build_and_expr__1660000051_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A struct{ j2g_header uint64; F_or_expr, F_tags, F_next_STAR_ any }

var A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_next_STAR___1660000047_A struct{ j2g_header uint64; F_toks, F_pos any }

var A_arbace_go_check_load_eval_build_next_STAR___1660000047_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_not_expr__1660000053_A struct{ j2g_header uint64; F_peek_STAR_, F_atom_STAR_, F_next_STAR_ any }

var A_arbace_go_check_load_eval_build_not_expr__1660000053_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_or_expr__1660000049_A struct{ j2g_header uint64; F_peek_STAR_, F_and_expr, F_next_STAR_ any }

var A_arbace_go_check_load_eval_build_or_expr__1660000049_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A struct{ j2g_header uint64; F_toks, F_pos any }

var A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A_fn_class *jrt.Class



type A_arbace_go_check_load_file_included_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_load_file_included_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A struct{ j2g_header uint64; F_tags any }

var A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A_fn_class *jrt.Class



type A_arbace_go_check_load_good_os_arch_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_load_good_os_arch_file_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_load_ns__GT_file_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_ns__GT_file_A_fn_class *jrt.Class



type A_arbace_go_check_load_overlay_file_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_overlay_file_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_fn__1660000085_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_fn__1660000085_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_fn__1660000087_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_fn__1660000087_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_fn__1660000091_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_fn__1660000091_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_path_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_path_of_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_path_of_fn__1660000095_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_path_of_fn__1660000095_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_source_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_fn__1660000081_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_source_fn__1660000081_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A struct{ j2g_header uint64; F_tags, F_config any }

var A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A struct{ j2g_header uint64; F_s__1660000072, F_tags, F_iter__1660000071, F_config any }

var A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A struct{ j2g_header uint64; F_tags, F_config, F_b__1660000074 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A_fn_class *jrt.Class



type A_arbace_go_check_load_path__GT_ns_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_path__GT_ns_A_fn_class *jrt.Class



type A_arbace_go_check_load_path__GT_ns_fn__1660000013_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_fn_class *jrt.Class



type A_arbace_go_check_load_read_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_read_forms_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tag_set_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_fn__1660000041_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tag_set_fn__1660000041_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A struct{ j2g_header uint64; F_s__1660000022, F_iter__1660000021 any }

var A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1660000024, F_c__1927001037__auto__ any }

var A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A struct{ j2g_header uint64; F_s__1660000032, F_iter__1660000031 any }

var A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A struct{ j2g_header uint64; F_b__1660000034 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A_fn_class *jrt.Class



type A_arbace_go_check_load_tokens_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tokens_A_fn_class *jrt.Class
