//line aot_arbace_go_check_load.ae:1
package aot_arbace_go_check_load

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A_New() *A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_load_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_load_A_const_1); lang.IFn_Cast(A_arbace_go_check_load_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_go_check_load_A_const_3, A_arbace_go_check_load_A_const_4, A_arbace_go_check_load_A_const_5); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_load_eval1660000008_fn__1660000009_A_New() *A_arbace_go_check_load_eval1660000008_fn__1660000009_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval1660000008_fn__1660000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_load_eval1660000008_fn__1660000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_load_eval1660000008_fn__1660000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_load_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_go_check_load_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_go_check_load_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_load_A_const_9.GetRawRoot__O(), A_arbace_go_check_load_A_const_10) }














func A_arbace_go_check_load_path__GT_ns_A_New() *A_arbace_go_check_load_path__GT_ns_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_path__GT_ns_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_go_check_load_path__GT_ns_A) Ctor() {}
//line :16:1
func (t *A_arbace_go_check_load_path__GT_ns_A) Invoke_O_O__O(self, path__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_38, nil); var tmp2 any; var root_21 any = A_arbace_go_check_load_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = Lit_24; var arg_25 any; var root_26 any = A_arbace_go_check_load_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any; var tmp3 any = A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_New(); var tmp4 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_fn_class = fncls__37d; tmp4 = fncls__37d } else { tmp4 = fncls__37 }; arg_29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_30 any; var root_38 any = A_arbace_go_check_load_A_const_15.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = path__0; var arg_42 any = A_arbace_go_check_load_A_const_16; if linked_39 == nil { arg_30 = ifn_40.Invoke_O_O__O(arg_41, arg_42) } else { arg_30 = linked_39.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_38, arg_41, arg_42) }; if linked_27 == nil { arg_25 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { arg_25 = linked_27.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if linked_22 == nil { tmp2 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { tmp2 = linked_22.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
//line :19:1
func A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_New() *A_arbace_go_check_load_path__GT_ns_fn__1660000013_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_path__GT_ns_fn__1660000013_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_go_check_load_path__GT_ns_fn__1660000013_A) Ctor() {}
//line :19:1
func (t *A_arbace_go_check_load_path__GT_ns_fn__1660000013_A) Invoke_O_O__O(self, p1__1660000012_SHARP___1 any) any { var root_31 any = A_arbace_go_check_load_A_const_13.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = p1__1660000012_SHARP___1; var arg_35 any = A_arbace_go_check_load_A_const_14; var arg_36 any = Lit_17; if linked_32 == nil { return ifn_33.Invoke_O_O_O__O(arg_34, arg_35, arg_36) } else { return linked_32.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_31, arg_34, arg_35, arg_36) } }

func A_arbace_go_check_load_ns__GT_file_A_New() *A_arbace_go_check_load_ns__GT_file_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_ns__GT_file_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_go_check_load_ns__GT_file_A) Ctor() {}
//line :21:1
func (t *A_arbace_go_check_load_ns__GT_file_A) Invoke_O_O__O(self, ns__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_23); var tmp2 any; var root_43 any = A_arbace_go_check_load_A_const_13.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = ns__0; var arg_47 any = Lit_24; var arg_48 any = Lit_25; if linked_44 == nil { tmp2 = ifn_45.Invoke_O_O_O__O(arg_46, arg_47, arg_48) } else { tmp2 = linked_44.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_43, arg_46, arg_47, arg_48) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref()
}














func A_arbace_go_check_load_tag_set_A_New() *A_arbace_go_check_load_tag_set_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_go_check_load_tag_set_A) Ctor() {}
//line :40:1
func (t *A_arbace_go_check_load_tag_set_A) Invoke_O_O__O(self, p__1660000018__0 any) any { var map__1660000019__2 any = p__1660000018__0; var map__1660000019__3 any; if lang.ISeq_InstanceOf(map__1660000019__2) { var tmp1 any; var root_49 any = A_arbace_go_check_load_A_const_17.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = map__1660000019__2; if linked_50 == nil { tmp1 = ifn_51.Invoke_O__O(arg_52) } else { tmp1 = linked_50.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_49, arg_52) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_53 any = A_arbace_go_check_load_A_const_18.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = map__1660000019__2; if linked_54 == nil { tmp2 = ifn_55.Invoke_O__O(arg_56) } else { tmp2 = linked_54.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_53, arg_56) }; map__1660000019__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_57 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = map__1660000019__2; if linked_58 == nil { tmp3 = ifn_59.Invoke_O__O(arg_60) } else { tmp3 = linked_58.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_57, arg_60) }; if jrt.J2g_Truth(tmp3) { var root_61 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_62 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_61, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_63 lang.IFn; if linked_62 == nil { ifn_63 = lang.IFn_Cast(root_61) } else { ifn_63 = nil }; var arg_64 any = map__1660000019__2; if linked_62 == nil { map__1660000019__3 = ifn_63.Invoke_O__O(arg_64) } else { map__1660000019__3 = linked_62.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_61, arg_64) } } else { map__1660000019__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1660000019__3 = map__1660000019__2 }; var goos__4 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_21); var goarch__5 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_22); var goamd64__6 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_23); var goarm64__7 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_24); var tags__8 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_25); var root_65 any = A_arbace_go_check_load_A_const_26.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_67 lang.IFn; _ = goarm64__7; if


	linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, goos__4, Lit_42, goarch__5)); var arg_69 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_load_A_const_27.GetRawRoot__O()); var tmp5 any; var iter__1927001039__auto____9 any; var tmp6 any = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_New(); var tmp7 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_fn_class; if
	fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_fn_class = fncls__137d; tmp7 = fncls__137d } else { tmp7 = fncls__137 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp9 any; var root_138 any = A_arbace_go_check_load_A_const_37.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = A_arbace_go_check_load_A_const_38; var arg_142 any = A_arbace_go_check_load_A_const_39; if linked_139 == nil { tmp9 = ifn_140.Invoke_O_O__O(arg_141, arg_142) } else { tmp9 = linked_139.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_138, arg_141, arg_142) }; tmp5 = tmp8.Invoke_O__O(tmp9); var tmp10 any = tmp5; var tmp11 any; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_go_check_load_A_const_40.GetRawRoot__O()).Invoke_O__O(goos__4)) { tmp11 = A_arbace_go_check_load_A_const_41 } else { tmp11 = nil }; var tmp12 any = tmp11; var tmp13 any; if
	lang.Util_Equiv_O_O__Z_NoInit(Lit_44, goarch__5) { var lv__9 int64; var tmp14 any; var root_143 any = A_arbace_go_check_load_A_const_42.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_145 lang.IFn
		if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any; var or__1927000174__auto____9 any = goamd64__6; if jrt.J2g_Truth(or__1927000174__auto____9) { arg_146 = or__1927000174__auto____9 } else { arg_146 = Lit_45 }; var arg_147 any = A_arbace_go_check_load_A_const_38; if linked_144 == nil { tmp14 = ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { tmp14 = linked_144.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_143, arg_146, arg_147) }; lv__9 = jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp14))
//line :46:1
		var iter__1927001039__auto____10 any; var tmp15 any = A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A_New(); var tmp16 *jrt.Class
		var fncls__206 /*line :46:1*/*jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A_fn_class

		if fncls__206 == nil { var fncls__206d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A_fn_class = fncls__206d; tmp16 = fncls__206d } else { tmp16 = fncls__206 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var tmp17 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____10); var tmp18 any; var root_207 any = A_arbace_go_check_load_A_const_37.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = A_arbace_go_check_load_A_const_38; var arg_211 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(lv__9)).Ref(); if linked_208 == nil { tmp18 = ifn_209.Invoke_O_O__O(arg_210, arg_211) } else { tmp18 = linked_208.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_207, arg_210, arg_211) }; tmp13 = tmp17.Invoke_O__O(tmp18) } else {
//line :46:1
			tmp13 = nil }; var tmp19 any = tmp13; var tmp20 any; if


	lang.Util_Equiv_O_O__Z_NoInit(Lit_47, goarch__5) { tmp20 = A_arbace_go_check_load_A_const_43 } else { tmp20 = nil }; var tmp21 any = tmp20; var tmp22 any; var root_212 any = /*line :44:1*/A_arbace_go_check_load_A_const_12.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_214 lang.IFn; if





	linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any; var tmp23 any = A_arbace_go_check_load_tag_set_fn__1660000041_A_New(); var tmp24 *jrt.Class; var fncls__217 *jrt.Class = A_arbace_go_check_load_tag_set_fn__1660000041_A_fn_class; if fncls__217 == nil { var fncls__217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_go_check_load_tag_set_fn__1660000041_A_fn_class = fncls__217d; tmp24 = fncls__217d } else { tmp24 = fncls__217 }; arg_215 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var arg_216 any = A_arbace_go_check_load_A_const_44.GetRawRoot__O(); if linked_213 == nil { tmp22 = ifn_214.Invoke_O_O__O(arg_215, arg_216) } else { tmp22 = linked_213.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_212, arg_215, arg_216) }; arg_69 = /*line :44:1*/tmp4.Invoke_O_O_O_O_O_O__O(tmp10, tmp12, tmp19, tmp21, tmp22, tags__8); if /*line :43:1*/ linked_66 == nil { return ifn_67.Invoke_O_O__O(arg_68, arg_69) } else { return linked_66.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_65, arg_68, arg_69) } }
func A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_New() *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A{}; t.Ctor(); return t }
//line :44:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A) Ctor() {}
//line :44:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A) Invoke_O_O__O(self, s__1660000022__1 any) any { var tmp1 any = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_New_O_O(s__1660000022__1, self); var tmp2 *jrt.Class; var fncls__136 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_fn_class; if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_fn_class = fncls__136d; tmp2 = fncls__136d } else { tmp2 = fncls__136 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :44:1
func A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A{}; t.Ctor_O_O(p0, p1); return t }
//line :44:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A) Ctor_O_O(c__s__1660000022, c__iter__1660000021 any) { t.F_s__1660000022 = c__s__1660000022; t.F_iter__1660000021 = c__iter__1660000021 }
//line :44:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A) Invoke_O__O(self any) any { { var s__1660000022__1 any; var t_ any = t.F_s__1660000022; t.F_s__1660000022 = nil; s__1660000022__1 = t_; for { var temp__1927000414__auto____2 any; var root_79 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_80 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_79, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_81 lang.IFn; if linked_80 == nil { ifn_81 = lang.IFn_Cast(root_79) } else { ifn_81 = nil }; var arg_82 any = s__1660000022__1; if linked_80 == nil { temp__1927000414__auto____2 = ifn_81.Invoke_O__O(arg_82) } else { temp__1927000414__auto____2 = linked_80.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_79, arg_82) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1660000022__3 any = temp__1927000414__auto____2; var tmp1 any; var root_83 any = A_arbace_go_check_load_A_const_28.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = s__1660000022__3; if linked_84 == nil { tmp1 = ifn_85.Invoke_O__O(arg_86) } else { tmp1 = linked_84.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_83, arg_86) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_87 any = A_arbace_go_check_load_A_const_29.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = s__1660000022__3; if linked_88 == nil { c__1927001037__auto____4 = ifn_89.Invoke_O__O(arg_90) } else { c__1927001037__auto____4 = linked_88.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_87, arg_90) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1660000024__6 any; var root_91 any = A_arbace_go_check_load_A_const_30.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_92 == nil { b__1660000024__6 = ifn_93.Invoke_O__O(arg_94) } else { b__1660000024__6 = linked_92.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_91, arg_94) }; var tmp2 any = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_New_I_O_O(size__1927001038__auto____5, b__1660000024__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_51, false); A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_fn_class = fncls__100d; tmp3 = fncls__100d } else { tmp3 = fncls__100 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_101 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any; var root_106 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = b__1660000024__6; if linked_107 == nil { arg_104 = ifn_108.Invoke_O__O(arg_109) } else { arg_104 = linked_107.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_106, arg_109) }; var arg_105 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1660000021); var tmp5 any; var root_110 any = A_arbace_go_check_load_A_const_34.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = s__1660000022__3; if linked_111 == nil { tmp5 = ifn_112.Invoke_O__O(arg_113) } else { tmp5 = linked_111.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_110, arg_113) }; arg_105 = tmp4.Invoke_O__O(tmp5); if linked_102 == nil { return ifn_103.Invoke_O_O__O(arg_104, arg_105) } else { return linked_102.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_101, arg_104, arg_105) } } else { var root_114 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any; var root_119 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_119, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_121 lang.IFn; if linked_120 == nil { ifn_121 = lang.IFn_Cast(root_119) } else { ifn_121 = nil }; var arg_122 any = b__1660000024__6; if linked_120 == nil { arg_117 = ifn_121.Invoke_O__O(arg_122) } else { arg_117 = linked_120.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_119, arg_122) }; var arg_118 any; if linked_115 == nil { return ifn_116.Invoke_O_O__O(arg_117, arg_118) } else { return linked_115.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_114, arg_117, arg_118) } } } else { var i__4 any; var root_123 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = s__1660000022__3; if linked_124 == nil { i__4 = ifn_125.Invoke_O__O(arg_126) } else { i__4 = linked_124.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_123, arg_126) }; var root_127 any = A_arbace_go_check_load_A_const_35.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref(); var arg_131 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1660000021); var tmp7 any; var root_132 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = s__1660000022__3; if linked_133 == nil { tmp7 = ifn_134.Invoke_O__O(arg_135) } else { tmp7 = linked_133.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_132, arg_135) }; arg_131 = tmp6.Invoke_O__O(tmp7); if linked_128 == nil { return ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { return linked_128.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_127, arg_130, arg_131) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :44:1
func A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :44:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1660000024, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1660000024 = c__b__1660000024; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :44:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A) Invoke_O__O(self any) any { { var i__1660000023__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1660000023__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1660000023__1)); var root_95 any = A_arbace_go_check_load_A_const_31.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = t.F_b__1660000024; var arg_99 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref(); if linked_96 == nil { ifn_97.Invoke_O_O__O(arg_98, arg_99) } else { linked_96.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_95, arg_98, arg_99) }; i__1660000023__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1660000023__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A_New() *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A) Ctor() {}
//line :48:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A) Invoke_O_O__O(self, s__1660000032__1 any) any { var tmp1 any = A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A_New_O_O(s__1660000032__1, self); var tmp2 *jrt.Class; var fncls__205 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A_fn_class; if fncls__205 == nil { var fncls__205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_53, false); A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A_fn_class = fncls__205d; tmp2 = fncls__205d } else { tmp2 = fncls__205 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :48:1
func A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A{}; t.Ctor_O_O(p0, p1); return t }
//line :48:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A) Ctor_O_O(c__s__1660000032, c__iter__1660000031 any) { t.F_s__1660000032 = c__s__1660000032; t.F_iter__1660000031 = c__iter__1660000031 }
//line :48:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A) Invoke_O__O(self any) any { { var s__1660000032__1 any; var t_ any = t.F_s__1660000032; t.F_s__1660000032 = nil; s__1660000032__1 = t_; for { var temp__1927000414__auto____2 any; var root_148 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = s__1660000032__1; if linked_149 == nil { temp__1927000414__auto____2 = ifn_150.Invoke_O__O(arg_151) } else { temp__1927000414__auto____2 = linked_149.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_148, arg_151) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1660000032__3 any = temp__1927000414__auto____2; var tmp1 any; var root_152 any = A_arbace_go_check_load_A_const_28.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = s__1660000032__3; if linked_153 == nil { tmp1 = ifn_154.Invoke_O__O(arg_155) } else { tmp1 = linked_153.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_152, arg_155) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_156 any = A_arbace_go_check_load_A_const_29.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = s__1660000032__3; if linked_157 == nil { c__1927001037__auto____4 = ifn_158.Invoke_O__O(arg_159) } else { c__1927001037__auto____4 = linked_157.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_156, arg_159) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1660000034__6 any; var root_160 any = A_arbace_go_check_load_A_const_30.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_161 == nil { b__1660000034__6 = ifn_162.Invoke_O__O(arg_163) } else { b__1660000034__6 = linked_161.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_160, arg_163) }; var tmp2 any = A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A_New_O_I_O(b__1660000034__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__169 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A_fn_class; if fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A_fn_class = fncls__169d; tmp3 = fncls__169d } else { tmp3 = fncls__169 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_170 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any; var root_175 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_175, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_177 lang.IFn; if linked_176 == nil { ifn_177 = lang.IFn_Cast(root_175) } else { ifn_177 = nil }; var arg_178 any = b__1660000034__6; if linked_176 == nil { arg_173 = ifn_177.Invoke_O__O(arg_178) } else { arg_173 = linked_176.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_175, arg_178) }; var arg_174 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1660000031); var tmp5 any; var root_179 any = A_arbace_go_check_load_A_const_34.GetRawRoot__O(); var linked_180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_179, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_181 lang.IFn; if linked_180 == nil { ifn_181 = lang.IFn_Cast(root_179) } else { ifn_181 = nil }; var arg_182 any = s__1660000032__3; if linked_180 == nil { tmp5 = ifn_181.Invoke_O__O(arg_182) } else { tmp5 = linked_180.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_179, arg_182) }; arg_174 = tmp4.Invoke_O__O(tmp5); if linked_171 == nil { return ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { return linked_171.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_170, arg_173, arg_174) } } else { var root_183 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any; var root_188 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = b__1660000034__6; if linked_189 == nil { arg_186 = ifn_190.Invoke_O__O(arg_191) } else { arg_186 = linked_189.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_188, arg_191) }; var arg_187 any; if linked_184 == nil { return ifn_185.Invoke_O_O__O(arg_186, arg_187) } else { return linked_184.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_183, arg_186, arg_187) } } } else { var i__4 any; var root_192 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = s__1660000032__3; if linked_193 == nil { i__4 = ifn_194.Invoke_O__O(arg_195) } else { i__4 = linked_193.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_192, arg_195) }; var root_196 any = A_arbace_go_check_load_A_const_35.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref(); var arg_200 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1660000031); var tmp7 any; var root_201 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = s__1660000032__3; if linked_202 == nil { tmp7 = ifn_203.Invoke_O__O(arg_204) } else { tmp7 = linked_202.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_201, arg_204) }; arg_200 = tmp6.Invoke_O__O(tmp7); if linked_197 == nil { return ifn_198.Invoke_O_O__O(arg_199, arg_200) } else { return linked_197.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_196, arg_199, arg_200) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :48:1
func A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :48:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A) Ctor_O_I_O(c__b__1660000034 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1660000034 = c__b__1660000034; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :48:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A) Invoke_O__O(self any) any { { var i__1660000033__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1660000033__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1660000033__1)); var root_164 any = A_arbace_go_check_load_A_const_31.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = t.F_b__1660000034; var arg_168 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref(); if linked_165 == nil { ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { linked_165.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_164, arg_167, arg_168) }; i__1660000033__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1660000033__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_load_tag_set_fn__1660000041_A_New() *A_arbace_go_check_load_tag_set_fn__1660000041_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_fn__1660000041_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_check_load_tag_set_fn__1660000041_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_check_load_tag_set_fn__1660000041_A) Invoke_O_O__O(self, p1__1660000017_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_49, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__1660000017_SHARP___1)).Ref() }


func A_arbace_go_check_load_tokens_A_New() *A_arbace_go_check_load_tokens_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tokens_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_go_check_load_tokens_A) Ctor() {}
//line :53:1
func (t *A_arbace_go_check_load_tokens_A) Invoke_O_O__O(self, s__0 any) any {
	var root_218 any = A_arbace_go_check_load_A_const_45.GetRawRoot__O(); var linked_219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_218, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_220 lang.IFn; if linked_219 == nil { ifn_220 = lang.IFn_Cast(root_218) } else { ifn_220 = nil }; var arg_221 any = A_arbace_go_check_load_A_const_46; var arg_222 any = s__0; if linked_219 == nil { return ifn_220.Invoke_O_O__O(arg_221, arg_222) } else { return linked_219.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_218, arg_221, arg_222)
	} }
func A_arbace_go_check_load_eval_build_A_New() *A_arbace_go_check_load_eval_build_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_A{}; t.Ctor(); return t }
//line :56:1
func (t *A_arbace_go_check_load_eval_build_A) Ctor() {}
//line :56:1
func (t *A_arbace_go_check_load_eval_build_A) Invoke_O_O_O__O(self, line__0, tags__1 any) any { var toks__3 any; var root_223 any = A_arbace_go_check_load_A_const_47.GetRawRoot__O(); var linked_224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_223, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_225 lang.IFn; if


	linked_224 == nil { ifn_225 = lang.IFn_Cast(root_223) } else { ifn_225 = nil }; var arg_226 any; var root_227 any = A_arbace_go_check_load_A_const_48.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, A_arbace_go_check_load_tokens_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any; var root_231 any = A_arbace_go_check_load_A_const_13.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = line__0; var arg_235 any = A_arbace_go_check_load_A_const_49; var arg_236 any = Lit_4; if linked_232 == nil { arg_230 = ifn_233.Invoke_O_O_O__O(arg_234, arg_235, arg_236) } else { arg_230 = linked_232.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_231, arg_234, arg_235, arg_236) }; if linked_228 == nil { arg_226 = ifn_229.Invoke_O__O(arg_230) } else { arg_226 = linked_228.(*A_arbace_go_check_load_tokens_A).Invoke_O_O__O(root_227, arg_230) }; if linked_224 == nil { toks__3 = ifn_225.Invoke_O__O(arg_226) } else { toks__3 = linked_224.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_223, arg_226) }; var pos__4 any; var root_237 any = /*line :56:1*/A_arbace_go_check_load_A_const_50.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_239 lang.IFn; if



	linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = A_arbace_go_check_load_A_const_51; if linked_238 == nil { pos__4 = ifn_239.Invoke_O__O(arg_240) } else { pos__4 = linked_238.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_237, arg_240) }; var peek_STAR___5 any; var tmp1 any = /*line :56:1*/A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A_New_O_O(toks__3, pos__4); var tmp2 *jrt.Class; var fncls__245 *jrt.Class = A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A_fn_class; if




	fncls__245 == nil { var fncls__245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A_fn_class = fncls__245d; tmp2 = fncls__245d } else { tmp2 = fncls__245 }; peek_STAR___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var next_STAR___6 any; var tmp3 any = /*line :56:1*/A_arbace_go_check_load_eval_build_next_STAR___1660000047_A_New_O_O(toks__3, pos__4); var tmp4 *jrt.Class; var fncls__252 *jrt.Class = A_arbace_go_check_load_eval_build_next_STAR___1660000047_A_fn_class; if





	fncls__252 == nil { var fncls__252d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_go_check_load_eval_build_next_STAR___1660000047_A_fn_class = fncls__252d; tmp4 = fncls__252d } else { tmp4 = fncls__252 }; next_STAR___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var body_or_expr__7 /*line :56:1*/*A_arbace_go_check_load_eval_build_or_expr__1660000049_A = A_arbace_go_check_load_eval_build_or_expr__1660000049_A_New_O_O_O(peek_STAR___5, nil, next_STAR___6); var body_and_expr__8 *A_arbace_go_check_load_eval_build_and_expr__1660000051_A = A_arbace_go_check_load_eval_build_and_expr__1660000051_A_New_O_O_O(peek_STAR___5, nil, next_STAR___6); var body_not_expr__9 *A_arbace_go_check_load_eval_build_not_expr__1660000053_A = A_arbace_go_check_load_eval_build_not_expr__1660000053_A_New_O_O_O(peek_STAR___5, nil, next_STAR___6); var body_atom_STAR___10 *A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A = A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A_New_O_O_O(nil, tags__1, next_STAR___6); var or_expr__7 any; var tmp5 *jrt.Class; var fncls__262 *jrt.Class = A_arbace_go_check_load_eval_build_or_expr__1660000049_A_fn_class; if fncls__262 == nil { var fncls__262d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_go_check_load_eval_build_or_expr__1660000049_A_fn_class = fncls__262d; tmp5 = fncls__262d } else { tmp5 = fncls__262 }; or_expr__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_or_expr__7), tmp5, nil); var and_expr__8 any; var tmp6 *jrt.Class; var fncls__263 *jrt.Class = A_arbace_go_check_load_eval_build_and_expr__1660000051_A_fn_class; if fncls__263 == nil { var fncls__263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_go_check_load_eval_build_and_expr__1660000051_A_fn_class = fncls__263d; tmp6 = fncls__263d } else { tmp6 = fncls__263 }; and_expr__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_and_expr__8), tmp6, nil); var not_expr__9 any; var tmp7 *jrt.Class; var fncls__264 *jrt.Class = A_arbace_go_check_load_eval_build_not_expr__1660000053_A_fn_class; if fncls__264 == nil { var fncls__264d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_go_check_load_eval_build_not_expr__1660000053_A_fn_class = fncls__264d; tmp7 = fncls__264d } else { tmp7 = fncls__264 }; not_expr__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_not_expr__9), tmp7, nil); var atom_STAR___10 any; var tmp8 *jrt.Class; var fncls__265 *jrt.Class = A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A_fn_class; if fncls__265 == nil { var fncls__265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A_fn_class = fncls__265d; tmp8 = fncls__265d } else { tmp8 = fncls__265 }; atom_STAR___10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_atom_STAR___10), tmp8, nil); body_or_expr__7.F_and_expr = and_expr__8; body_and_expr__8.F_not_expr = not_expr__9; body_not_expr__9.F_atom_STAR_ = atom_STAR___10; body_atom_STAR___10.F_or_expr = or_expr__7; return /*line :72:1*/ lang.IFn_Cast(or_expr__7).Invoke__O() }
//line :61:1
func A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A{}; t.Ctor_O_O(p0, p1); return t }
//line :61:1
func (t *A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A) Ctor_O_O(c__toks, c__pos any) { t.F_toks = c__toks; t.F_pos = c__pos }
//line :61:1
func (t *A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A) Invoke_O__O(self any) any { var tmp1 any = t.F_toks; var tmp2 any; var root_241 any = A_arbace_go_check_load_A_const_7.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = t.F_pos; if linked_242 == nil { tmp2 = ifn_243.Invoke_O__O(arg_244) } else { tmp2 = linked_242.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_241, arg_244) }; return lang.RT_Get_O_O__O_NoInit(tmp1, tmp2) }
func A_arbace_go_check_load_eval_build_next_STAR___1660000047_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_eval_build_next_STAR___1660000047_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_next_STAR___1660000047_A{}; t.Ctor_O_O(p0, p1); return t }
//line :62:1
func (t *A_arbace_go_check_load_eval_build_next_STAR___1660000047_A) Ctor_O_O(c__toks, c__pos any) { t.F_toks = c__toks; t.F_pos = c__pos }
//line :62:1
func (t *A_arbace_go_check_load_eval_build_next_STAR___1660000047_A) Invoke_O__O(self any) any { var t__1 any; var tmp1 any = t.F_toks; var tmp2 any; var root_246 any = A_arbace_go_check_load_A_const_7.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = t.F_pos; if linked_247 == nil { tmp2 = ifn_248.Invoke_O__O(arg_249) } else { tmp2 = linked_247.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_246, arg_249) }; t__1 = lang.RT_Get_O_O__O_NoInit(tmp1, tmp2); var tmp3 *lang.Volatile = lang.Volatile_Cast(t.F_pos); var tmp4 jrt.Number_I; var na_250 any = jrt.NN(lang.Volatile_Cast(t.F_pos)).Deref__O(); if jrt.Long_InstanceOf(na_250) { var n0_251 int64 = jrt.NN(jrt.Long_Cast(na_250)).LongValue__J(); if n0_251 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_250) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_251 + 1)) } } else { if jrt.Double_InstanceOf(na_250) { var n0_251_2 float64 = jrt.NN(jrt.Double_Cast(na_250)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_251_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_250) } }; jrt.NN(tmp3).Reset_O__O(tmp4); return t__1 }
func A_arbace_go_check_load_eval_build_and_expr__1660000051_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_load_eval_build_and_expr__1660000051_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_and_expr__1660000051_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_and_expr__1660000051_A) Ctor_O_O_O(c__peek_STAR_, c__not_expr, c__next_STAR_ any) { t.F_peek_STAR_ = c__peek_STAR_; t.F_not_expr = c__not_expr; t.F_next_STAR_ = c__next_STAR_ }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_and_expr__1660000051_A) Invoke_O__O(self any) any { { var v__1 any = lang.IFn_Cast(t.F_not_expr).Invoke__O(); L1: for {


	if lang.Util_Equiv_O_O__Z_NoInit(Lit_11, lang.IFn_Cast(t.F_peek_STAR_).Invoke__O()) { lang.IFn_Cast(t.F_next_STAR_).Invoke__O(); var w__2 any = lang.IFn_Cast(t.F_not_expr).Invoke__O(); var tmp1 any; var and__1927000168__auto____3 any = v__1; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = w__2 } else { tmp1 = and__1927000168__auto____3 }; v__1 = tmp1; continue L1 } else { return v__1 } } }; /*line :63:1*/panic("j2g: unreachable") }
//line :63:1
func A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A) Ctor_O_O_O(c__or_expr, c__tags, c__next_STAR_ any) { t.F_or_expr = c__or_expr; t.F_tags = c__tags; t.F_next_STAR_ = c__next_STAR_ }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A) Invoke_O__O(self any) any { var t__1 any = lang.IFn_Cast(t.F_next_STAR_).Invoke__O(); if





	lang.Util_Equiv_O_O__Z_NoInit(Lit_12, t__1) { var v__2 any = lang.IFn_Cast(t.F_or_expr).Invoke__O()
		lang.IFn_Cast(t.F_next_STAR_).Invoke__O()
//line :69:1
		return v__2 } else {

			var root_257 any = A_arbace_go_check_load_A_const_53.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = t.F_tags; var arg_261 any = t__1; if linked_258 == nil { return ifn_259.Invoke_O_O__O(arg_260, arg_261) } else { return linked_258.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_257, arg_260, arg_261) } } }
//line :63:1
func A_arbace_go_check_load_eval_build_not_expr__1660000053_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_load_eval_build_not_expr__1660000053_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_not_expr__1660000053_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_not_expr__1660000053_A) Ctor_O_O_O(c__peek_STAR_, c__atom_STAR_, c__next_STAR_ any) { t.F_peek_STAR_ = c__peek_STAR_; t.F_atom_STAR_ = c__atom_STAR_; t.F_next_STAR_ = c__next_STAR_ }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_not_expr__1660000053_A) Invoke_O__O(self any) any {



	if lang.Util_Equiv_O_O__Z_NoInit(Lit_13, lang.IFn_Cast(t.F_peek_STAR_).Invoke__O()) { lang.IFn_Cast(t.F_next_STAR_).Invoke__O(); var root_253 any = A_arbace_go_check_load_A_const_52.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_255 lang.IFn; if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any = lang.IFn_Cast(self).Invoke__O(); if linked_254 == nil { return ifn_255.Invoke_O__O(arg_256) } else { return linked_254.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_253, arg_256) } } else { return lang.IFn_Cast(t.F_atom_STAR_).Invoke__O() } }
//line :63:1
func A_arbace_go_check_load_eval_build_or_expr__1660000049_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_load_eval_build_or_expr__1660000049_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_or_expr__1660000049_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_or_expr__1660000049_A) Ctor_O_O_O(c__peek_STAR_, c__and_expr, c__next_STAR_ any) { t.F_peek_STAR_ = c__peek_STAR_; t.F_and_expr = c__and_expr; t.F_next_STAR_ = c__next_STAR_ }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_or_expr__1660000049_A) Invoke_O__O(self any) any { { var v__1 any = lang.IFn_Cast(t.F_and_expr).Invoke__O(); L1: for {
												if lang.Util_Equiv_O_O__Z_NoInit(Lit_14, lang.IFn_Cast(t.F_peek_STAR_).Invoke__O()) { lang.IFn_Cast(t.F_next_STAR_).Invoke__O(); var w__2 any = lang.IFn_Cast(t.F_and_expr).Invoke__O(); var tmp1 any; var or__1927000174__auto____3 any = v__1; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = w__2 }; v__1 = tmp1; continue L1 } else { return v__1 } } }; /*line :63:1*/panic("j2g: unreachable") }










func A_arbace_go_check_load_good_os_arch_file_QMARK__A_New() *A_arbace_go_check_load_good_os_arch_file_QMARK__A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_good_os_arch_file_QMARK__A{}; t.Ctor(); return t }
//line :74:1
func (t *A_arbace_go_check_load_good_os_arch_file_QMARK__A) Ctor() {}
//line :74:1
func (t *A_arbace_go_check_load_good_os_arch_file_QMARK__A) Invoke_O_O_O_O__O(self, fname__0, goos__1, goarch__2 any) any { var n__4 any; var root_266 any = A_arbace_go_check_load_A_const_13.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_268 lang.IFn; if


	linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = fname__0; var arg_270 any = A_arbace_go_check_load_A_const_54; var arg_271 any = Lit_4; if linked_267 == nil { n__4 = ifn_268.Invoke_O_O_O__O(arg_269, arg_270, arg_271) } else { n__4 = linked_267.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_266, arg_269, arg_270, arg_271) }; var n__5 any; var temp__1927000408__auto____5 any; var root_272 any = /*line :74:1*/A_arbace_go_check_load_A_const_55.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_274 lang.IFn; if



	linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; var arg_275 any = n__4; var arg_276 any = Lit_17; if linked_273 == nil { temp__1927000408__auto____5 = ifn_274.Invoke_O_O__O(arg_275, arg_276) } else { temp__1927000408__auto____5 = linked_273.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_272, arg_275, arg_276) }; if jrt.J2g_Truth(temp__1927000408__auto____5) { var i__6 any = temp__1927000408__auto____5; var root_277 any = A_arbace_go_check_load_A_const_42.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = n__4; var arg_281 any = i__6; if linked_278 == nil { n__5 = ifn_279.Invoke_O_O__O(arg_280, arg_281) } else { n__5 = linked_278.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_277, arg_280, arg_281) } } else { n__5 = Lit_4 }; var parts__6 any; var root_282 any = /*line :74:1*/A_arbace_go_check_load_A_const_47.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_284 lang.IFn; if




	linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any; var root_286 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any; var root_290 any = A_arbace_go_check_load_A_const_15.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = n__5; var arg_294 any = A_arbace_go_check_load_A_const_56; if linked_291 == nil { arg_289 = ifn_292.Invoke_O_O__O(arg_293, arg_294) } else { arg_289 = linked_291.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_290, arg_293, arg_294) }; if linked_287 == nil { arg_285 = ifn_288.Invoke_O__O(arg_289) } else { arg_285 = linked_287.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_286, arg_289) }; if linked_283 == nil { parts__6 = ifn_284.Invoke_O__O(arg_285) } else { parts__6 = linked_283.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_282, arg_285) }; var l__7 int32 = /*line :74:1*/lang.RT_Count_O__I_NoInit(parts__6); var parts__8 any; var tmp1 bool; var and__1927000168__auto____8 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(l__7), 1); if and__1927000168__auto____8 {






		var tmp2 any; var root_295 any = A_arbace_go_check_load_A_const_57.GetRawRoot__O(); var linked_296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_295, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_297 lang.IFn; if linked_296 == nil { ifn_297 = lang.IFn_Cast(root_295) } else { ifn_297 = nil }; var arg_298 any = parts__6; if linked_296 == nil { tmp2 = ifn_297.Invoke_O__O(arg_298) } else { tmp2 = linked_296.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_295, arg_298) }; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(Lit_18, tmp2) } else { tmp1 = and__1927000168__auto____8 }; if tmp1 { var root_299 any = A_arbace_go_check_load_A_const_58.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_pop_A_fn_class); var ifn_301 lang.IFn; if linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = parts__6; if linked_300 == nil { parts__8 = ifn_301.Invoke_O__O(arg_302) } else { parts__8 = linked_300.(*aot_arbace_core.A_arbace_core_pop_A).Invoke_O_O__O(root_299, arg_302) } } else { parts__8 = parts__6 }; var l__9 int32 = /*line :74:1*/lang.RT_Count_O__I_NoInit(parts__8); var tmp3 any; var and__1927000168__auto____10 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(l__9), 2); if and__1927000168__auto____10 {









			var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_go_check_load_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 2)))); if jrt.J2g_Truth(and__1927000168__auto____11) { tmp3 = lang.IFn_Cast(A_arbace_go_check_load_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 1)))) } else { tmp3 = and__1927000168__auto____11 } } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10).Ref() }; if /*line :83:1*/ jrt.J2g_Truth(tmp3) { var and__1927000168__auto____10_2 bool = lang.Util_Equiv_O_O__Z_NoInit(goarch__2, lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 1))))

				if and__1927000168__auto____10_2 { var or__1927000174__auto____11 bool = lang.Util_Equiv_O_O__Z_NoInit(goos__1, lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 2)))); if or__1927000174__auto____11 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11).Ref() } else { var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_19, lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 2)))); if and__1927000168__auto____12 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(goos__1, Lit_20)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12).Ref() } } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_2).Ref() } } else {
//line :83:1
					var tmp4 any; var and__1927000168__auto____10_3 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(l__9), 1)


					if and__1927000168__auto____10_3 { tmp4 = lang.IFn_Cast(A_arbace_go_check_load_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 1)))) } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_3).Ref() }
//line :83:1
					if jrt.J2g_Truth(tmp4) { var o__10 any = lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 1))); var or__1927000174__auto____11_2 bool = lang.Util_Equiv_O_O__Z_NoInit(o__10, goos__1)




						if or__1927000174__auto____11_2 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11_2).Ref() } else { var or__1927000174__auto____12 bool; var and__1927000168__auto____12_2 bool = lang.Util_Equiv_O_O__Z_NoInit(o__10, Lit_19); if and__1927000168__auto____12_2 { or__1927000174__auto____12 = lang.Util_Equiv_O_O__Z_NoInit(goos__1, Lit_20) } else { or__1927000174__auto____12 = and__1927000168__auto____12_2 }; if or__1927000174__auto____12 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____12).Ref() } else { var and__1927000168__auto____13 bool = lang.Util_Equiv_O_O__Z_NoInit(o__10, Lit_21); if and__1927000168__auto____13 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(goos__1, Lit_22)).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____13).Ref() } } } } else {
//line :83:1
							var tmp5 any; var and__1927000168__auto____10_4 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(l__9), 1)





							if and__1927000168__auto____10_4 { tmp5 = lang.IFn_Cast(A_arbace_go_check_load_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 1)))) } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____10_4).Ref() }
//line :83:1
							if jrt.J2g_Truth(tmp5) {





								return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(goarch__2, lang.RT_Nth_O_I__O_NoInit(parts__8, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__9), 1))))).Ref() } else {
//line :83:1
									if A_arbace_go_check_load_A_const_61 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } } }








func A_arbace_go_check_load_file_included_QMARK__A_New() *A_arbace_go_check_load_file_included_QMARK__A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_file_included_QMARK__A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_go_check_load_file_included_QMARK__A) Ctor() {}
//line :92:1
func (t *A_arbace_go_check_load_file_included_QMARK__A) Invoke_O_O_O_O_O__O(self, fname__0, opts__1, config__2, tags__3 any) any { var and__1927000168__auto____5 any; var root_303 any = A_arbace_go_check_load_A_const_62.GetRawRoot__O(); var linked_304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_303, A_arbace_go_check_load_good_os_arch_file_QMARK__A_fn_class); var ifn_305 lang.IFn; if


	linked_304 == nil { ifn_305 = lang.IFn_Cast(root_303) } else { ifn_305 = nil }; var arg_306 any = fname__0; var arg_307 any = A_arbace_go_check_load_A_const_21.Invoke_O__O(config__2); var arg_308 any = A_arbace_go_check_load_A_const_22.Invoke_O__O(config__2); if linked_304 == nil { and__1927000168__auto____5 = ifn_305.Invoke_O_O_O__O(arg_306, arg_307, arg_308) } else { and__1927000168__auto____5 = linked_304.(*A_arbace_go_check_load_good_os_arch_file_QMARK__A).Invoke_O_O_O_O__O(root_303, arg_306, arg_307, arg_308) }; if jrt.J2g_Truth(and__1927000168__auto____5) {
		var root_309 any = A_arbace_go_check_load_A_const_63.GetRawRoot__O(); var linked_310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_309, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_311 lang.IFn; if linked_310 == nil { ifn_311 = lang.IFn_Cast(root_309) } else { ifn_311 = nil }; var arg_312 any; var tmp1 any = A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A_New_O(tags__3); var tmp2 *jrt.Class; var fncls__324 *jrt.Class = A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A_fn_class; if fncls__324 == nil { var fncls__324d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A_fn_class = fncls__324d; tmp2 = fncls__324d } else { tmp2 = fncls__324 }; arg_312 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_313 any = A_arbace_go_check_load_A_const_66.Invoke_O__O(opts__1); if linked_310 == nil { return ifn_311.Invoke_O_O__O(arg_312, arg_313) } else { return linked_310.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_309, arg_312, arg_313) } } else {
//line :95:1
			return and__1927000168__auto____5 } }
func A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A_New_O(p0 any) *A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A{}; t.Ctor_O(p0); return t }
//line :96:1
func (t *A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A) Ctor_O(c__tags any) { t.F_tags = c__tags }
//line :96:1
func (t *A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 any; var root_314 any = A_arbace_go_check_load_A_const_64.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = b__1; var arg_318 any = Lit_16; if linked_315 == nil { tmp1 = ifn_316.Invoke_O_O__O(arg_317, arg_318) } else { tmp1 = linked_315.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_314, arg_317, arg_318) }; if jrt.J2g_Truth(tmp1) { var root_319 any = A_arbace_go_check_load_A_const_65.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, A_arbace_go_check_load_eval_build_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = b__1; var arg_323 any = t.F_tags; if linked_320 == nil { return ifn_321.Invoke_O_O__O(arg_322, arg_323) } else { return linked_320.(*A_arbace_go_check_load_eval_build_A).Invoke_O_O_O__O(root_319, arg_322, arg_323) } } else { return jrt.Boolean_TRUE.Ref() } }






func A_arbace_go_check_load_read_forms_A_New() *A_arbace_go_check_load_read_forms_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_read_forms_A{}; t.Ctor(); return t }
//line :103:1
func (t *A_arbace_go_check_load_read_forms_A) Ctor() {}
//line :103:1
func (t *A_arbace_go_check_load_read_forms_A) Invoke_O_O__O(self, f__0 any) any { var k__2 any = jrt.NN(jrt.File_Cast(f__0)).GetPath__String().Ref(); var or__1927000174__auto____3 any = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(A_arbace_go_check_load_A_const_67.GetRawRoot__O(), Lit_40, jrt.RefArrayOf(jrt.Object_class, k__2)); if



	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var v__4 any; var root_325 any = A_arbace_go_check_load_A_const_68.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_327 lang.IFn
		if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = f__0; if linked_326 == nil { v__4 = ifn_327.Invoke_O__O(arg_328) } else { v__4 = linked_326.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_325, arg_328) }
		lang.Reflector_InvokeInstanceMethod_O_String_O1__O(A_arbace_go_check_load_A_const_67.GetRawRoot__O(), Lit_41, jrt.RefArrayOf(jrt.Object_class, k__2, v__4))
//line :107:1
		return v__4 } }




func A_arbace_go_check_load_clear_cache_BANG__A_New() *A_arbace_go_check_load_clear_cache_BANG__A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_clear_cache_BANG__A{}; t.Ctor(); return t }
//line :112:1
func (t *A_arbace_go_check_load_clear_cache_BANG__A) Ctor() {}
//line :112:1
func (t *A_arbace_go_check_load_clear_cache_BANG__A) Invoke_O__O(self any) any { return lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(A_arbace_go_check_load_A_const_67.GetRawRoot__O(), Lit_1, false) }

func A_arbace_go_check_load_overlay_file_A_New() *A_arbace_go_check_load_overlay_file_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_overlay_file_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_go_check_load_overlay_file_A) Ctor() {}
//line :114:1
func (t *A_arbace_go_check_load_overlay_file_A) Invoke_O_O_O__O(self, root__0, rel__1 any) any { var ov__3 any; if


	jrt.J2g_Truth(A_arbace_go_check_load_A_const_69.Invoke_O__O(root__0)) { ov__3 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_load_A_const_69.Invoke_O__O(root__0), nil, rel__1))) } else { ov__3 = nil }; var tmp1 any; var and__1927000168__auto____4 any = ov__3; if
	jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(ov__3)).IsFile__Z()).Ref() } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { return ov__3 } else { return jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_25, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_load_A_const_70.Invoke_O__O(root__0), nil, rel__1))) } }

func A_arbace_go_check_load_collect_package_A_New() *A_arbace_go_check_load_collect_package_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_collect_package_A{}; t.Ctor(); return t }
//line :120:1
func (t *A_arbace_go_check_load_collect_package_A) Ctor() {}
//line :120:1
func (t *A_arbace_go_check_load_collect_package_A) Invoke_O_O_O__O(self, root__0, pf__1 any) any { var base__3 any; var tmp1 any; var root_329 any = A_arbace_go_check_load_A_const_71.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_331 lang.IFn; if



	linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = A_arbace_go_check_load_A_const_70.Invoke_O__O(root__0); if linked_330 == nil { tmp1 = ifn_331.Invoke_O__O(arg_332) } else { tmp1 = linked_330.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_329, arg_332) }; base__3 = jrt.File_New_String(jrt.String_Cast(tmp1)).GetCanonicalPath__String().Ref(); var root_333 any =
	A_arbace_go_check_load_A_const_72.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any = pf__1; var arg_337 any; var tmp2 any = A_arbace_go_check_load_collect_package_fn__1660000065_A_New_O_O(root__0, base__3); var tmp3 *jrt.Class; var fncls__357 *jrt.Class = A_arbace_go_check_load_collect_package_fn__1660000065_A_fn_class; if fncls__357 == nil { var fncls__357d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_go_check_load_collect_package_fn__1660000065_A_fn_class = fncls__357d; tmp3 = fncls__357d } else { tmp3 = fncls__357 }; arg_337 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); if linked_334 == nil { return ifn_335.Invoke_O_O__O(arg_336, arg_337) } else { return linked_334.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A).Invoke_O_O_O__O(root_333, arg_336, arg_337) } }
//line :125:1
func A_arbace_go_check_load_collect_package_fn__1660000065_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_collect_package_fn__1660000065_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_collect_package_fn__1660000065_A{}; t.Ctor_O_O(p0, p1); return t }
//line :125:1
func (t *A_arbace_go_check_load_collect_package_fn__1660000065_A) Ctor_O_O(c__root, c__base any) { t.F_root = c__root; t.F_base = c__base }
//line :125:1
func (t *A_arbace_go_check_load_collect_package_fn__1660000065_A) Invoke_O_O__O(self, f__1 any) any { var p__2 any = jrt.NN(jrt.File_Cast(f__1)).GetCanonicalPath__String().Ref(); var rel__3 any; var tmp1 any; var root_338 any = A_arbace_go_check_load_A_const_64.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_340 lang.IFn; if

	linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = p__2; var arg_342 any = t.F_base; if linked_339 == nil { tmp1 = ifn_340.Invoke_O_O__O(arg_341, arg_342) } else { tmp1 = linked_339.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_338, arg_341, arg_342) }; if jrt.J2g_Truth(tmp1) { var root_343 any = A_arbace_go_check_load_A_const_42.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_345 lang.IFn; if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = p__2; var arg_347 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_base)))).Ref(); if linked_344 == nil { rel__3 = ifn_345.Invoke_O_O__O(arg_346, arg_347) } else { rel__3 = linked_344.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_343, arg_346, arg_347) } } else { rel__3 = nil }; var root_348 any =
	A_arbace_go_check_load_A_const_73.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, A_arbace_go_check_load_read_forms_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any; if jrt.J2g_Truth(rel__3) { var root_352 any = A_arbace_go_check_load_A_const_74.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, A_arbace_go_check_load_overlay_file_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = t.F_root; var arg_356 any = rel__3; if linked_353 == nil { arg_351 = ifn_354.Invoke_O_O__O(arg_355, arg_356) } else { arg_351 = linked_353.(*A_arbace_go_check_load_overlay_file_A).Invoke_O_O_O__O(root_352, arg_355, arg_356) } } else { arg_351 = f__1 }; if linked_349 == nil { return ifn_350.Invoke_O__O(arg_351) } else { return linked_349.(*A_arbace_go_check_load_read_forms_A).Invoke_O_O__O(root_348, arg_351) } }

func A_arbace_go_check_load_package_source_A_New() *A_arbace_go_check_load_package_source_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_go_check_load_package_source_A) Ctor() {}
//line :130:1
func (t *A_arbace_go_check_load_package_source_A) Invoke_O_O_O_O_O__O(self, root__0, path__1, config__2, pf__3 any) any { var pf__5 any; var or__1927000174__auto____5 any = pf__3; if





	jrt.J2g_Truth(or__1927000174__auto____5) { pf__5 = or__1927000174__auto____5 } else { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_25, nil); var tmp2 any = A_arbace_go_check_load_A_const_70.Invoke_O__O(root__0); var tmp3 any; var root_358 any = A_arbace_go_check_load_A_const_75.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any; var root_362 any = A_arbace_go_check_load_A_const_76.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = path__1; if linked_363 == nil { arg_361 = ifn_364.Invoke_O__O(arg_365) } else { arg_361 = linked_363.(*A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_362, arg_365) }; if linked_359 == nil { tmp3 = ifn_360.Invoke_O__O(arg_361) } else { tmp3 = linked_359.(*A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_358, arg_361) }; pf__5 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, tmp3))) }; if
	jrt.NN(jrt.File_Cast(pf__5)).IsFile__Z() { var map__1660000069__6 any; var root_366 any = A_arbace_go_check_load_A_const_77.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, A_arbace_go_check_load_collect_package_A_fn_class); var ifn_368 lang.IFn
		if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = root__0; var arg_370 any = pf__5; if linked_367 == nil { map__1660000069__6 = ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { map__1660000069__6 = linked_367.(*A_arbace_go_check_load_collect_package_A).Invoke_O_O_O__O(root_366, arg_369, arg_370) }
//line :137:1
		var map__1660000069__7 any
		if lang.ISeq_InstanceOf(map__1660000069__6) { var tmp4 any; var root_371 any = A_arbace_go_check_load_A_const_17.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = map__1660000069__6; if linked_372 == nil { tmp4 = ifn_373.Invoke_O__O(arg_374) } else { tmp4 = linked_372.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_371, arg_374) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_375 any = A_arbace_go_check_load_A_const_18.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = map__1660000069__6; if linked_376 == nil { tmp5 = ifn_377.Invoke_O__O(arg_378) } else { tmp5 = linked_376.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_375, arg_378) }; map__1660000069__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp5, jrt.Object_class.ArrayClass())).Ref() } else { var tmp6 any; var root_379 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_380 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_379, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_381 lang.IFn; if linked_380 == nil { ifn_381 = lang.IFn_Cast(root_379) } else { ifn_381 = nil }; var arg_382 any = map__1660000069__6; if linked_380 == nil { tmp6 = ifn_381.Invoke_O__O(arg_382) } else { tmp6 = linked_380.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_379, arg_382) }; if jrt.J2g_Truth(tmp6) { var root_383 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_385 lang.IFn; if linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any = map__1660000069__6; if linked_384 == nil { map__1660000069__7 = ifn_385.Invoke_O__O(arg_386) } else { map__1660000069__7 = linked_384.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_383, arg_386) } } else { map__1660000069__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1660000069__7 = map__1660000069__6 }
//line :137:1
		var package__8 any = lang.RT_Get_O_O__O_NoInit(map__1660000069__7, A_arbace_go_check_load_A_const_78); var name__9 any = lang.RT_Get_O_O__O_NoInit(map__1660000069__7, A_arbace_go_check_load_A_const_79); var files__10 any = lang.RT_Get_O_O__O_NoInit(map__1660000069__7, A_arbace_go_check_load_A_const_80); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_check_load_A_const_81.GetRawRoot__O()); var tmp8 any = A_arbace_go_check_load_A_const_82; var config__11 any = tmp7.Invoke_O_O_O__O(tmp8, A_arbace_go_check_load_A_const_83.Invoke_O__O(package__8), config__2); var tags__12 any; var root_393 any = A_arbace_go_check_load_A_const_84.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, A_arbace_go_check_load_tag_set_A_fn_class); var ifn_395 lang.IFn


		if linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = config__11; if linked_394 == nil { tags__12 = ifn_395.Invoke_O__O(arg_396) } else { tags__12 = linked_394.(*A_arbace_go_check_load_tag_set_A).Invoke_O_O__O(root_393, arg_396) }
//line :137:1
		var files__13 any; var root_397 any = A_arbace_go_check_load_A_const_47.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_399 lang.IFn



		if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any; var iter__1927001039__auto____13 any; var tmp9 any = A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A_New_O_O(tags__12, config__11); var tmp10 *jrt.Class; var fncls__489 *jrt.Class = A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A_fn_class; if fncls__489 == nil { var fncls__489d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A_fn_class = fncls__489d; tmp10 = fncls__489d } else { tmp10 = fncls__489 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); arg_400 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(files__10); if linked_398 == nil { files__13 = ifn_399.Invoke_O__O(arg_400) } else { files__13 = linked_398.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_397, arg_400) }
//line :137:1
		var tmp11 any = A_arbace_go_check_load_A_const_88; var tmp12 any; var or__1927000174__auto____14 any = A_arbace_go_check_load_A_const_88.Invoke_O__O(package__8)







		if jrt.J2g_Truth(or__1927000174__auto____14) { tmp12 = or__1927000174__auto____14 } else { tmp12 = path__1 }
//line :137:1
		var tmp13 any = tmp12; var tmp14 any = A_arbace_go_check_load_A_const_79; var tmp15 any; var root_490 any = A_arbace_go_check_load_A_const_89.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_492 lang.IFn







		if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = name__9; if linked_491 == nil { tmp15 = ifn_492.Invoke_O__O(arg_493) } else { tmp15 = linked_491.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_490, arg_493) }
//line :137:1
		var tmp16 any = tmp15; var tmp17 any = A_arbace_go_check_load_A_const_83; var tmp18 any = A_arbace_go_check_load_A_const_85; var tmp19 any = A_arbace_go_check_load_A_const_80; var tmp20 any = A_arbace_go_check_load_A_const_90; var tmp21 any = jrt.NN(jrt.File_Cast(pf__5)).GetPath__String().Ref(); var tmp22 any = A_arbace_go_check_load_A_const_91; var tmp23 any; var root_494 any = A_arbace_go_check_load_A_const_92.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_496 lang.IFn









		if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var arg_497 any; var tmp24 any = A_arbace_go_check_load_package_source_fn__1660000081_A_New(); var tmp25 *jrt.Class; var fncls__507 *jrt.Class = A_arbace_go_check_load_package_source_fn__1660000081_A_fn_class; if fncls__507 == nil { var fncls__507d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_go_check_load_package_source_fn__1660000081_A_fn_class = fncls__507d; tmp25 = fncls__507d } else { tmp25 = fncls__507 }; arg_497 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp24, tmp25, nil); var arg_498 any; var root_508 any = A_arbace_go_check_load_A_const_73.GetRawRoot__O(); var linked_509 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_508, A_arbace_go_check_load_read_forms_A_fn_class); var ifn_510 lang.IFn; if linked_509 == nil { ifn_510 = lang.IFn_Cast(root_508) } else { ifn_510 = nil }; var arg_511 any = pf__5; if linked_509 == nil { arg_498 = ifn_510.Invoke_O__O(arg_511) } else { arg_498 = linked_509.(*A_arbace_go_check_load_read_forms_A).Invoke_O_O__O(root_508, arg_511) }; if linked_495 == nil { tmp23 = ifn_496.Invoke_O_O__O(arg_497, arg_498) } else { tmp23 = linked_495.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_494, arg_497, arg_498) }
//line :137:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp13, tmp14, tmp16, tmp17, config__11, tmp18, package__8, tmp19, files__13, tmp20, tmp21, tmp22, tmp23)) } else { return nil } }
//line :130:1
func (t *A_arbace_go_check_load_package_source_A) Invoke_O_O_O_O__O(self, root__0, path__1, config__2 any) any {



	var root_512 any = A_arbace_go_check_load_A_const_96.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, A_arbace_go_check_load_package_source_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = root__0; var arg_516 any = path__1; var arg_517 any = config__2; var arg_518 any; if linked_513 == nil { return ifn_514.Invoke_O_O_O_O__O(arg_515, arg_516, arg_517, arg_518) } else { return linked_513.(*A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_512, arg_515, arg_516, arg_517, arg_518)
	}
}




func A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A{}; t.Ctor_O_O(p0, p1); return t }
//line :141:1
func (t *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A) Ctor_O_O(c__tags, c__config any) { t.F_tags = c__tags; t.F_config = c__config }
//line :141:1
func (t *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A) Invoke_O_O__O(self, s__1660000072__1 any) any { var tmp1 any = A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A_New_O_O_O_O(s__1660000072__1, t.F_tags, self, t.F_config); var tmp2 *jrt.Class; var fncls__488 *jrt.Class = A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A_fn_class; if fncls__488 == nil { var fncls__488d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A_fn_class = fncls__488d; tmp2 = fncls__488d } else { tmp2 = fncls__488 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :141:1
func A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :141:1
func (t *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A) Ctor_O_O_O_O(c__s__1660000072, c__tags, c__iter__1660000071, c__config any) { t.F_s__1660000072 = c__s__1660000072; t.F_tags = c__tags; t.F_iter__1660000071 = c__iter__1660000071; t.F_config = c__config }
//line :141:1
func (t *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A) Invoke_O__O(self any) any { { var s__1660000072__1 any; var t_ any = t.F_s__1660000072; t.F_s__1660000072 = nil; s__1660000072__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_401 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_401, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_403 lang.IFn; if linked_402 == nil { ifn_403 = lang.IFn_Cast(root_401) } else { ifn_403 = nil }; var arg_404 any = s__1660000072__1; if linked_402 == nil { temp__1927000414__auto____2 = ifn_403.Invoke_O__O(arg_404) } else { temp__1927000414__auto____2 = linked_402.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_401, arg_404) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1660000072__3 any = temp__1927000414__auto____2; var tmp1 any; var root_405 any = A_arbace_go_check_load_A_const_28.GetRawRoot__O(); var linked_406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_405, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_407 lang.IFn; if linked_406 == nil { ifn_407 = lang.IFn_Cast(root_405) } else { ifn_407 = nil }; var arg_408 any = s__1660000072__3; if linked_406 == nil { tmp1 = ifn_407.Invoke_O__O(arg_408) } else { tmp1 = linked_406.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_405, arg_408) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_409 any = A_arbace_go_check_load_A_const_29.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any = s__1660000072__3; if linked_410 == nil { c__1927001037__auto____4 = ifn_411.Invoke_O__O(arg_412) } else { c__1927001037__auto____4 = linked_410.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_409, arg_412) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1660000074__6 any; var root_413 any = A_arbace_go_check_load_A_const_30.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_414 == nil { b__1660000074__6 = ifn_415.Invoke_O__O(arg_416) } else { b__1660000074__6 = linked_414.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_413, arg_416) }; var tmp2 any = A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A_New_O_O_O_I_O(t.F_tags, t.F_config, b__1660000074__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__435 *jrt.Class = A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A_fn_class; if fncls__435 == nil { var fncls__435d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A_fn_class = fncls__435d; tmp3 = fncls__435d } else { tmp3 = fncls__435 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_436 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_438 lang.IFn; if linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any; var root_441 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_443 lang.IFn; if linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = b__1660000074__6; if linked_442 == nil { arg_439 = ifn_443.Invoke_O__O(arg_444) } else { arg_439 = linked_442.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_441, arg_444) }; var arg_440 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1660000071); var tmp5 any; var root_445 any = A_arbace_go_check_load_A_const_34.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = s__1660000072__3; if linked_446 == nil { tmp5 = ifn_447.Invoke_O__O(arg_448) } else { tmp5 = linked_446.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_445, arg_448) }; arg_440 = tmp4.Invoke_O__O(tmp5); if linked_437 == nil { return ifn_438.Invoke_O_O__O(arg_439, arg_440) } else { return linked_437.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_436, arg_439, arg_440) } } else { var root_449 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_451 lang.IFn; if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any; var root_454 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_454, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_456 lang.IFn; if linked_455 == nil { ifn_456 = lang.IFn_Cast(root_454) } else { ifn_456 = nil }; var arg_457 any = b__1660000074__6; if linked_455 == nil { arg_452 = ifn_456.Invoke_O__O(arg_457) } else { arg_452 = linked_455.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_454, arg_457) }; var arg_453 any; if linked_450 == nil { return ifn_451.Invoke_O_O__O(arg_452, arg_453) } else { return linked_450.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_449, arg_452, arg_453) } } } else { var fi__4 any; var root_458 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_458, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_460 lang.IFn; if linked_459 == nil { ifn_460 = lang.IFn_Cast(root_458) } else { ifn_460 = nil }; var arg_461 any = s__1660000072__3; if linked_459 == nil { fi__4 = ifn_460.Invoke_O__O(arg_461) } else { fi__4 = linked_459.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_458, arg_461) }; var opts__5 any = A_arbace_go_check_load_A_const_85.Invoke_O__O(fi__4); var tmp6 any; var root_462 any = A_arbace_go_check_load_A_const_86.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, A_arbace_go_check_load_file_included_QMARK__A_fn_class); var ifn_464 lang.IFn

	if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = A_arbace_go_check_load_A_const_79.Invoke_O__O(fi__4); var arg_466 any = opts__5; var arg_467 any = t.F_config; var arg_468 any = t.F_tags; if linked_463 == nil { tmp6 = ifn_464.Invoke_O_O_O_O__O(arg_465, arg_466, arg_467, arg_468) } else { tmp6 = linked_463.(*A_arbace_go_check_load_file_included_QMARK__A).Invoke_O_O_O_O_O__O(root_462, arg_465, arg_466, arg_467, arg_468) }
//line :141:1
	if jrt.J2g_Truth(tmp6) { var root_469 any = A_arbace_go_check_load_A_const_35.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any; var root_474 any = A_arbace_go_check_load_A_const_87.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_476 lang.IFn


		if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = fi__4; var arg_478 any = A_arbace_go_check_load_A_const_85; var arg_479 any = opts__5; if linked_475 == nil { arg_472 = ifn_476.Invoke_O_O_O__O(arg_477, arg_478, arg_479) } else { arg_472 = linked_475.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_474, arg_477, arg_478, arg_479) }
//line :141:1
		var arg_473 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1660000071); var tmp8 any; var root_480 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = s__1660000072__3; if linked_481 == nil { tmp8 = ifn_482.Invoke_O__O(arg_483) } else { tmp8 = linked_481.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_480, arg_483) }; arg_473 = tmp7.Invoke_O__O(tmp8); if linked_470 == nil { return ifn_471.Invoke_O_O__O(arg_472, arg_473) } else { return linked_470.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_469, arg_472, arg_473) } } else { var tmp9 any; var root_484 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_486 lang.IFn; if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = s__1660000072__3; if linked_485 == nil { tmp9 = ifn_486.Invoke_O__O(arg_487) } else { tmp9 = linked_485.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_484, arg_487) }; s__1660000072__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :141:1
func A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :141:1
func (t *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A) Ctor_O_O_O_I_O(c__tags, c__config, c__b__1660000074 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_tags = c__tags; t.F_config = c__config; t.F_b__1660000074 = c__b__1660000074; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :141:1
func (t *A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A) Invoke_O__O(self any) any { { var i__1660000073__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1660000073__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1660000073__1)); var opts__3 any = A_arbace_go_check_load_A_const_85.Invoke_O__O(fi__2); var tmp2 any; var root_417 any = A_arbace_go_check_load_A_const_86.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, A_arbace_go_check_load_file_included_QMARK__A_fn_class); var ifn_419 lang.IFn

	if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = A_arbace_go_check_load_A_const_79.Invoke_O__O(fi__2); var arg_421 any = opts__3; var arg_422 any = t.F_config; var arg_423 any = t.F_tags; if linked_418 == nil { tmp2 = ifn_419.Invoke_O_O_O_O__O(arg_420, arg_421, arg_422, arg_423) } else { tmp2 = linked_418.(*A_arbace_go_check_load_file_included_QMARK__A).Invoke_O_O_O_O_O__O(root_417, arg_420, arg_421, arg_422, arg_423) }
//line :141:1
	if jrt.J2g_Truth(tmp2) { var root_424 any = A_arbace_go_check_load_A_const_31.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_426 lang.IFn; if linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = t.F_b__1660000074; var arg_428 any; var root_429 any = A_arbace_go_check_load_A_const_87.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_429, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_431 lang.IFn


		if linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = fi__2; var arg_433 any = A_arbace_go_check_load_A_const_85; var arg_434 any = opts__3; if linked_430 == nil { arg_428 = ifn_431.Invoke_O_O_O__O(arg_432, arg_433, arg_434) } else { arg_428 = linked_430.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_429, arg_432, arg_433, arg_434) }
//line :141:1
		if linked_425 == nil { ifn_426.Invoke_O_O__O(arg_427, arg_428) } else { linked_425.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_424, arg_427, arg_428) }; i__1660000073__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1660000073__1); continue L1 } else { i__1660000073__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1660000073__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_go_check_load_package_source_fn__1660000081_A_New() *A_arbace_go_check_load_package_source_fn__1660000081_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_fn__1660000081_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_go_check_load_package_source_fn__1660000081_A) Ctor() {}
//line :147:1
func (t *A_arbace_go_check_load_package_source_fn__1660000081_A) Invoke_O_O__O(self, p1__1660000068_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_499 any = A_arbace_go_check_load_A_const_93.GetRawRoot__O(); var linked_500 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_499, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_501 lang.IFn; if linked_500 == nil { ifn_501 = lang.IFn_Cast(root_499) } else { ifn_501 = nil }; var arg_502 any = p1__1660000068_SHARP___1; if linked_500 == nil { and__1927000168__auto____2 = ifn_501.Invoke_O__O(arg_502) } else { and__1927000168__auto____2 = linked_500.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_499, arg_502) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_load_A_const_94; var tmp3 any; var root_503 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_504 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_503, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_505 lang.IFn; if linked_504 == nil { ifn_505 = lang.IFn_Cast(root_503) } else { ifn_505 = nil }; var arg_506 any = p1__1660000068_SHARP___1; if linked_504 == nil { tmp3 = ifn_505.Invoke_O__O(arg_506) } else { tmp3 = linked_504.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_503, arg_506) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var tmp4 *lang.Keyword = A_arbace_go_check_load_A_const_95; return tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__1660000068_SHARP___1)) } else { return nil } }

func A_arbace_go_check_load_package_files_A_New() *A_arbace_go_check_load_package_files_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_A{}; t.Ctor(); return t }
//line :149:1
func (t *A_arbace_go_check_load_package_files_A) Ctor() {}
//line :149:1
func (t *A_arbace_go_check_load_package_files_A) Invoke_O_O_O__O(self, root__0, sub__1 any) any { var d__3 any = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_26, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_load_A_const_70.Invoke_O__O(root__0), nil, sub__1))); var root_519 any = A_arbace_go_check_load_A_const_97.GetRawRoot__O(); var linked_520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_519, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_521 lang.IFn; if









	linked_520 == nil { ifn_521 = lang.IFn_Cast(root_519) } else { ifn_521 = nil }; var arg_522 any; var tmp1 any = A_arbace_go_check_load_package_files_fn__1660000085_A_New(); var tmp2 *jrt.Class; var fncls__524 *jrt.Class = A_arbace_go_check_load_package_files_fn__1660000085_A_fn_class; if fncls__524 == nil { var fncls__524d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_27, false); A_arbace_go_check_load_package_files_fn__1660000085_A_fn_class = fncls__524d; tmp2 = fncls__524d } else { tmp2 = fncls__524 }; arg_522 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_523 any; var root_525 any = A_arbace_go_check_load_A_const_98.GetRawRoot__O(); var linked_526 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_525, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_527 lang.IFn; if /*line :155:1*/ linked_526 == nil { ifn_527 = lang.IFn_Cast(root_525) } else { ifn_527 = nil }; var arg_528 any; var tmp3 any = A_arbace_go_check_load_package_files_fn__1660000087_A_New(); var tmp4 *jrt.Class; var fncls__562 *jrt.Class = A_arbace_go_check_load_package_files_fn__1660000087_A_fn_class; if fncls__562 == nil { var fncls__562d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_go_check_load_package_files_fn__1660000087_A_fn_class = fncls__562d; tmp4 = fncls__562d } else { tmp4 = fncls__562 }; arg_528 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_529 any; var root_563 any = A_arbace_go_check_load_A_const_98.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_565 lang.IFn; if /*line :154:1*/ linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any; var tmp5 any = A_arbace_go_check_load_package_files_fn__1660000091_A_New(); var tmp6 *jrt.Class; var fncls__573 *jrt.Class = A_arbace_go_check_load_package_files_fn__1660000091_A_fn_class; if fncls__573 == nil { var fncls__573d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_go_check_load_package_files_fn__1660000091_A_fn_class = fncls__573d; tmp6 = fncls__573d } else { tmp6 = fncls__573 }; arg_566 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_567 any; var root_574 any = A_arbace_go_check_load_A_const_104.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_576 lang.IFn; if /*line :153:1*/ linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = d__3; if linked_575 == nil { arg_567 = ifn_576.Invoke_O__O(arg_577) } else { arg_567 = linked_575.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_574, arg_577) }; if
	linked_564 == nil { arg_529 = ifn_565.Invoke_O_O__O(arg_566, arg_567) } else { arg_529 = linked_564.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_563, arg_566, arg_567) }; if
	linked_526 == nil { arg_523 = ifn_527.Invoke_O_O__O(arg_528, arg_529) } else { arg_523 = linked_526.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_525, arg_528, arg_529) }; if



	linked_520 == nil { return ifn_521.Invoke_O_O__O(arg_522, arg_523) } else { return linked_520.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_519, arg_522, arg_523) } }
//line :154:1
func A_arbace_go_check_load_package_files_fn__1660000091_A_New() *A_arbace_go_check_load_package_files_fn__1660000091_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_fn__1660000091_A{}; t.Ctor(); return t }
//line :154:1
func (t *A_arbace_go_check_load_package_files_fn__1660000091_A) Ctor() {}
//line :154:1
func (t *A_arbace_go_check_load_package_files_fn__1660000091_A) Invoke_O_O__O(self, f__1 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(f__1)).IsFile__Z(); if and__1927000168__auto____2 { var root_568 any = A_arbace_go_check_load_A_const_103.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = jrt.NN(jrt.File_Cast(f__1)).GetName__String().Ref(); var arg_572 any = Lit_23; if linked_569 == nil { return ifn_570.Invoke_O_O__O(arg_571, arg_572) } else { return linked_569.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_568, arg_571, arg_572) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
func A_arbace_go_check_load_package_files_fn__1660000087_A_New() *A_arbace_go_check_load_package_files_fn__1660000087_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_fn__1660000087_A{}; t.Ctor(); return t }
//line :155:1
func (t *A_arbace_go_check_load_package_files_fn__1660000087_A) Ctor() {}
//line :155:1
func (t *A_arbace_go_check_load_package_files_fn__1660000087_A) Invoke_O_O__O(self, f__1 any) any { var r__2 any = lang.IFn_Cast(A_arbace_go_check_load_A_const_99.GetRawRoot__O()).Invoke_O__O(f__1); var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var l__5 any; var root_534 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_534, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_536 lang.IFn

	if linked_535 == nil { ifn_536 = lang.IFn_Cast(root_534) } else { ifn_536 = nil }; var arg_537 any; var root_538 any = A_arbace_go_check_load_A_const_100.GetRawRoot__O(); var linked_539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_538, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_540 lang.IFn; if linked_539 == nil { ifn_540 = lang.IFn_Cast(root_538) } else { ifn_540 = nil }; var arg_541 any; var tmp2 any = A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A_New(); var tmp3 *jrt.Class; var fncls__552 *jrt.Class = A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A_fn_class; if fncls__552 == nil { var fncls__552d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A_fn_class = fncls__552d; tmp3 = fncls__552d } else { tmp3 = fncls__552 }; arg_541 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_542 any; var root_553 any = A_arbace_go_check_load_A_const_102.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, aot_arbace_core.A_arbace_core_line_seq_A_fn_class); var ifn_555 lang.IFn; if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = r__2; if linked_554 == nil { arg_542 = ifn_555.Invoke_O__O(arg_556) } else { arg_542 = linked_554.(*aot_arbace_core.A_arbace_core_line_seq_A).Invoke_O_O__O(root_553, arg_556) }; if linked_539 == nil { arg_537 = ifn_540.Invoke_O_O__O(arg_541, arg_542) } else { arg_537 = linked_539.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_538, arg_541, arg_542) }; if linked_535 == nil { l__5 = ifn_536.Invoke_O__O(arg_537) } else { l__5 = linked_535.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_534, arg_537) }
//line :155:1
	var and__1927000168__auto____6 any = l__5


	if jrt.J2g_Truth(and__1927000168__auto____6) { var root_557 any = A_arbace_go_check_load_A_const_64.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_559 lang.IFn; if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any = l__5; var arg_561 any = Lit_31; if linked_558 == nil { tmp1 = ifn_559.Invoke_O_O__O(arg_560, arg_561) } else { tmp1 = linked_558.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_557, arg_560, arg_561) } } else { tmp1 = and__1927000168__auto____6 } }; return nil }(); /*line :156:1*/jrt.Reader_Cast(r__2).Close__V(); if /*line :155:1*/ tmp4 != nil { panic(tmp4) }; return tmp1 }

func A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A_New() *A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A{}; t.Ctor(); return t }
//line :157:1
func (t *A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A) Ctor() {}
//line :157:1
func (t *A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A) Invoke_O_O__O(self, p1__1660000084_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_543 any = A_arbace_go_check_load_A_const_101.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = p1__1660000084_SHARP___1; if linked_544 == nil { or__1927000174__auto____2 = ifn_545.Invoke_O__O(arg_546) } else { or__1927000174__auto____2 = linked_544.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_543, arg_546) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_547 any = A_arbace_go_check_load_A_const_64.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = p1__1660000084_SHARP___1; var arg_551 any = Lit_32; if linked_548 == nil { return ifn_549.Invoke_O_O__O(arg_550, arg_551) } else { return linked_548.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_547, arg_550, arg_551) } } }

func A_arbace_go_check_load_package_files_fn__1660000085_A_New() *A_arbace_go_check_load_package_files_fn__1660000085_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_fn__1660000085_A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_go_check_load_package_files_fn__1660000085_A) Ctor() {}
//line :159:1
func (t *A_arbace_go_check_load_package_files_fn__1660000085_A) Invoke_O_O__O(self, f__1 any) any { return jrt.NN(jrt.File_Cast(f__1)).GetPath__String().Ref() }

func A_arbace_go_check_load_package_path_of_A_New() *A_arbace_go_check_load_package_path_of_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_path_of_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_go_check_load_package_path_of_A) Ctor() {}
//line :161:1
func (t *A_arbace_go_check_load_package_path_of_A) Invoke_O_O__O(self, pf__0 any) any { var fs__2 any; var root_578 any = A_arbace_go_check_load_A_const_73.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, A_arbace_go_check_load_read_forms_A_fn_class); var ifn_580 lang.IFn; if


	linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = pf__0; if linked_579 == nil { fs__2 = ifn_580.Invoke_O__O(arg_581) } else { fs__2 = linked_579.(*A_arbace_go_check_load_read_forms_A).Invoke_O_O__O(root_578, arg_581) }; var gp__3 any; var root_582 any = /*line :161:1*/A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_584 lang.IFn; if



	linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any; var root_586 any = A_arbace_go_check_load_A_const_98.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any; var tmp1 any = A_arbace_go_check_load_package_path_of_fn__1660000095_A_New(); var tmp2 *jrt.Class; var fncls__599 *jrt.Class = A_arbace_go_check_load_package_path_of_fn__1660000095_A_fn_class; if fncls__599 == nil { var fncls__599d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_go_check_load_package_path_of_fn__1660000095_A_fn_class = fncls__599d; tmp2 = fncls__599d } else { tmp2 = fncls__599 }; arg_589 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_590 any = fs__2; if linked_587 == nil { arg_585 = ifn_588.Invoke_O_O__O(arg_589, arg_590) } else { arg_585 = linked_587.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_586, arg_589, arg_590) }; if linked_583 == nil { gp__3 = ifn_584.Invoke_O__O(arg_585) } else { gp__3 = linked_583.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_582, arg_585) }; var tmp3 /*line :166:1*/*lang.Keyword = A_arbace_go_check_load_A_const_88; var tmp4 any; var root_600 any = A_arbace_go_check_load_A_const_106.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any = A_arbace_go_check_load_A_const_107.GetRawRoot__O(); var arg_604 any; var root_605 any = A_arbace_go_check_load_A_const_108.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = gp__3; if linked_606 == nil { arg_604 = ifn_607.Invoke_O__O(arg_608) } else { arg_604 = linked_606.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_605, arg_608) }; if linked_601 == nil { tmp4 = ifn_602.Invoke_O_O__O(arg_603, arg_604) } else { tmp4 = linked_601.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_600, arg_603, arg_604) }; return tmp3.Invoke_O__O(tmp4) }
//line :165:1
func A_arbace_go_check_load_package_path_of_fn__1660000095_A_New() *A_arbace_go_check_load_package_path_of_fn__1660000095_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_path_of_fn__1660000095_A{}; t.Ctor(); return t }
//line :165:1
func (t *A_arbace_go_check_load_package_path_of_fn__1660000095_A) Ctor() {}
//line :165:1
func (t *A_arbace_go_check_load_package_path_of_fn__1660000095_A) Invoke_O_O__O(self, p1__1660000094_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_591 any = A_arbace_go_check_load_A_const_93.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = p1__1660000094_SHARP___1; if linked_592 == nil { and__1927000168__auto____2 = ifn_593.Invoke_O__O(arg_594) } else { and__1927000168__auto____2 = linked_592.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_591, arg_594) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_load_A_const_105; var tmp2 any; var root_595 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_597 lang.IFn; if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any = p1__1660000094_SHARP___1; if linked_596 == nil { tmp2 = ifn_597.Invoke_O__O(arg_598) } else { tmp2 = linked_596.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_595, arg_598) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }






























































































type A_arbace_go_check_load_A struct{ jrt.Object }

var A_arbace_go_check_load_A_const_pool *jrt.RefArray

var A_arbace_go_check_load_A_const_0 *lang.Var

var A_arbace_go_check_load_A_const_1 any

var A_arbace_go_check_load_A_const_2 *lang.Var

var A_arbace_go_check_load_A_const_3 any

var A_arbace_go_check_load_A_const_4 any

var A_arbace_go_check_load_A_const_5 any

var A_arbace_go_check_load_A_const_6 *lang.Var

var A_arbace_go_check_load_A_const_7 *lang.Var

var A_arbace_go_check_load_A_const_8 *lang.Var

var A_arbace_go_check_load_A_const_9 *lang.Var

var A_arbace_go_check_load_A_const_10 any

var A_arbace_go_check_load_A_const_11 *lang.Var

var A_arbace_go_check_load_A_const_12 *lang.Var

var A_arbace_go_check_load_A_const_13 *lang.Var

var A_arbace_go_check_load_A_const_14 any

var A_arbace_go_check_load_A_const_15 *lang.Var

var A_arbace_go_check_load_A_const_16 any

var A_arbace_go_check_load_A_const_17 *lang.Var

var A_arbace_go_check_load_A_const_18 *lang.Var

var A_arbace_go_check_load_A_const_19 *lang.Var

var A_arbace_go_check_load_A_const_20 *lang.Var

var A_arbace_go_check_load_A_const_21 *lang.Keyword

var A_arbace_go_check_load_A_const_22 *lang.Keyword

var A_arbace_go_check_load_A_const_23 *lang.Keyword

var A_arbace_go_check_load_A_const_24 *lang.Keyword

var A_arbace_go_check_load_A_const_25 *lang.Keyword

var A_arbace_go_check_load_A_const_26 *lang.Var

var A_arbace_go_check_load_A_const_27 *lang.Var

var A_arbace_go_check_load_A_const_28 *lang.Var

var A_arbace_go_check_load_A_const_29 *lang.Var

var A_arbace_go_check_load_A_const_30 *lang.Var

var A_arbace_go_check_load_A_const_31 *lang.Var

var A_arbace_go_check_load_A_const_32 *lang.Var

var A_arbace_go_check_load_A_const_33 *lang.Var

var A_arbace_go_check_load_A_const_34 *lang.Var

var A_arbace_go_check_load_A_const_35 *lang.Var

var A_arbace_go_check_load_A_const_36 *lang.Var

var A_arbace_go_check_load_A_const_37 *lang.Var

var A_arbace_go_check_load_A_const_38 any

var A_arbace_go_check_load_A_const_39 any

var A_arbace_go_check_load_A_const_40 *lang.Var

var A_arbace_go_check_load_A_const_41 any

var A_arbace_go_check_load_A_const_42 *lang.Var

var A_arbace_go_check_load_A_const_43 any

var A_arbace_go_check_load_A_const_44 *lang.Var

var A_arbace_go_check_load_A_const_45 *lang.Var

var A_arbace_go_check_load_A_const_46 any

var A_arbace_go_check_load_A_const_47 *lang.Var

var A_arbace_go_check_load_A_const_48 *lang.Var

var A_arbace_go_check_load_A_const_49 any

var A_arbace_go_check_load_A_const_50 *lang.Var

var A_arbace_go_check_load_A_const_51 any

var A_arbace_go_check_load_A_const_52 *lang.Var

var A_arbace_go_check_load_A_const_53 *lang.Var

var A_arbace_go_check_load_A_const_54 any

var A_arbace_go_check_load_A_const_55 *lang.Var

var A_arbace_go_check_load_A_const_56 any

var A_arbace_go_check_load_A_const_57 *lang.Var

var A_arbace_go_check_load_A_const_58 *lang.Var

var A_arbace_go_check_load_A_const_59 *lang.Var

var A_arbace_go_check_load_A_const_60 *lang.Var

var A_arbace_go_check_load_A_const_61 *lang.Keyword

var A_arbace_go_check_load_A_const_62 *lang.Var

var A_arbace_go_check_load_A_const_63 *lang.Var

var A_arbace_go_check_load_A_const_64 *lang.Var

var A_arbace_go_check_load_A_const_65 *lang.Var

var A_arbace_go_check_load_A_const_66 *lang.Keyword

var A_arbace_go_check_load_A_const_67 *lang.Var

var A_arbace_go_check_load_A_const_68 *lang.Var

var A_arbace_go_check_load_A_const_69 *lang.Keyword

var A_arbace_go_check_load_A_const_70 *lang.Keyword

var A_arbace_go_check_load_A_const_71 *lang.Var

var A_arbace_go_check_load_A_const_72 *lang.Var

var A_arbace_go_check_load_A_const_73 *lang.Var

var A_arbace_go_check_load_A_const_74 *lang.Var

var A_arbace_go_check_load_A_const_75 *lang.Var

var A_arbace_go_check_load_A_const_76 *lang.Var

var A_arbace_go_check_load_A_const_77 *lang.Var

var A_arbace_go_check_load_A_const_78 *lang.Keyword

var A_arbace_go_check_load_A_const_79 *lang.Keyword

var A_arbace_go_check_load_A_const_80 *lang.Keyword

var A_arbace_go_check_load_A_const_81 *lang.Var

var A_arbace_go_check_load_A_const_82 any

var A_arbace_go_check_load_A_const_83 *lang.Keyword

var A_arbace_go_check_load_A_const_84 *lang.Var

var A_arbace_go_check_load_A_const_85 *lang.Keyword

var A_arbace_go_check_load_A_const_86 *lang.Var

var A_arbace_go_check_load_A_const_87 *lang.Var

var A_arbace_go_check_load_A_const_88 *lang.Keyword

var A_arbace_go_check_load_A_const_89 *lang.Var

var A_arbace_go_check_load_A_const_90 *lang.Keyword

var A_arbace_go_check_load_A_const_91 *lang.Keyword

var A_arbace_go_check_load_A_const_92 *lang.Var

var A_arbace_go_check_load_A_const_93 *lang.Var

var A_arbace_go_check_load_A_const_94 any

var A_arbace_go_check_load_A_const_95 *lang.Keyword

var A_arbace_go_check_load_A_const_96 *lang.Var

var A_arbace_go_check_load_A_const_97 *lang.Var

var A_arbace_go_check_load_A_const_98 *lang.Var

var A_arbace_go_check_load_A_const_99 *lang.Var

var A_arbace_go_check_load_A_const_100 *lang.Var

var A_arbace_go_check_load_A_const_101 *lang.Var

var A_arbace_go_check_load_A_const_102 *lang.Var

var A_arbace_go_check_load_A_const_103 *lang.Var

var A_arbace_go_check_load_A_const_104 *lang.Var

var A_arbace_go_check_load_A_const_105 any

var A_arbace_go_check_load_A_const_106 *lang.Var

var A_arbace_go_check_load_A_const_107 *lang.Var

var A_arbace_go_check_load_A_const_108 *lang.Var

var A_arbace_go_check_load_A_init jrt.ClassInit

func A_arbace_go_check_load_A_Init() { if !A_arbace_go_check_load_A_init.Done() { A_arbace_go_check_load_A_init.Run(A_arbace_go_check_load_A_clinit) } }

func A_arbace_go_check_load_A_clinit() { A_arbace_go_check_load_A_clinit_p0(); A_arbace_go_check_load_A_clinit_p1(); A_arbace_go_check_load_A_clinit_p2(); A_arbace_go_check_load_A_clinit_p3(); A_arbace_go_check_load_A_clinit_p4(); A_arbace_go_check_load_A_clinit_p5(); A_arbace_go_check_load_A_clinit_p6(); A_arbace_go_check_load_A_clinit_p7(); A_arbace_go_check_load_A_clinit_p8() }

func A_arbace_go_check_load_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_load_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 138); A_arbace_go_check_load_A_const_0 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[29]); A_arbace_go_check_load_A_const_1 = A_arbace_go_check_load_A_const_pool.A[30]; A_arbace_go_check_load_A_const_2 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[31]); A_arbace_go_check_load_A_const_3 = A_arbace_go_check_load_A_const_pool.A[32]; A_arbace_go_check_load_A_const_4 = A_arbace_go_check_load_A_const_pool.A[33]; A_arbace_go_check_load_A_const_5 = A_arbace_go_check_load_A_const_pool.A[34]; A_arbace_go_check_load_A_const_6 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[35]); A_arbace_go_check_load_A_const_7 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[36]); A_arbace_go_check_load_A_const_8 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[37]); A_arbace_go_check_load_A_const_9 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[38]); A_arbace_go_check_load_A_const_10 = A_arbace_go_check_load_A_const_pool.A[39]; A_arbace_go_check_load_A_const_11 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[40]) }

func A_arbace_go_check_load_A_clinit_p1() { A_arbace_go_check_load_A_const_12 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[41]); A_arbace_go_check_load_A_const_13 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[42]); A_arbace_go_check_load_A_const_14 = A_arbace_go_check_load_A_const_pool.A[43]; A_arbace_go_check_load_A_const_15 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[44]); A_arbace_go_check_load_A_const_16 = A_arbace_go_check_load_A_const_pool.A[45]; A_arbace_go_check_load_A_const_17 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[46]); A_arbace_go_check_load_A_const_18 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[47]); A_arbace_go_check_load_A_const_19 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[48]); A_arbace_go_check_load_A_const_20 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[49]); A_arbace_go_check_load_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[50]); A_arbace_go_check_load_A_const_22 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[51]); A_arbace_go_check_load_A_const_23 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[52]) }

func A_arbace_go_check_load_A_clinit_p2() { A_arbace_go_check_load_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[53]); A_arbace_go_check_load_A_const_25 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[54]); A_arbace_go_check_load_A_const_26 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[55]); A_arbace_go_check_load_A_const_27 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[56]); A_arbace_go_check_load_A_const_28 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[57]); A_arbace_go_check_load_A_const_29 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[58]); A_arbace_go_check_load_A_const_30 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[59]); A_arbace_go_check_load_A_const_31 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[60]); A_arbace_go_check_load_A_const_32 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[61]); A_arbace_go_check_load_A_const_33 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[62]); A_arbace_go_check_load_A_const_34 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[63]); A_arbace_go_check_load_A_const_35 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[64]) }

func A_arbace_go_check_load_A_clinit_p3() { A_arbace_go_check_load_A_const_36 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[65]); A_arbace_go_check_load_A_const_37 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[66]); A_arbace_go_check_load_A_const_38 = A_arbace_go_check_load_A_const_pool.A[67]; A_arbace_go_check_load_A_const_39 = A_arbace_go_check_load_A_const_pool.A[68]; A_arbace_go_check_load_A_const_40 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[69]); A_arbace_go_check_load_A_const_41 = A_arbace_go_check_load_A_const_pool.A[70]; A_arbace_go_check_load_A_const_42 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[71]); A_arbace_go_check_load_A_const_43 = A_arbace_go_check_load_A_const_pool.A[72]; A_arbace_go_check_load_A_const_44 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[73]); A_arbace_go_check_load_A_const_45 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[74]); A_arbace_go_check_load_A_const_46 = A_arbace_go_check_load_A_const_pool.A[75]; A_arbace_go_check_load_A_const_47 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[76]); A_arbace_go_check_load_A_const_48 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[77]) }

func A_arbace_go_check_load_A_clinit_p4() { A_arbace_go_check_load_A_const_49 = A_arbace_go_check_load_A_const_pool.A[78]; A_arbace_go_check_load_A_const_50 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[79]); A_arbace_go_check_load_A_const_51 = A_arbace_go_check_load_A_const_pool.A[80]; A_arbace_go_check_load_A_const_52 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[81]); A_arbace_go_check_load_A_const_53 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[82]); A_arbace_go_check_load_A_const_54 = A_arbace_go_check_load_A_const_pool.A[83]; A_arbace_go_check_load_A_const_55 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[84]); A_arbace_go_check_load_A_const_56 = A_arbace_go_check_load_A_const_pool.A[85]; A_arbace_go_check_load_A_const_57 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[86]); A_arbace_go_check_load_A_const_58 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[87]); A_arbace_go_check_load_A_const_59 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[88]); A_arbace_go_check_load_A_const_60 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[89]); A_arbace_go_check_load_A_const_61 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[90]) }

func A_arbace_go_check_load_A_clinit_p5() { A_arbace_go_check_load_A_const_62 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[91]); A_arbace_go_check_load_A_const_63 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[92]); A_arbace_go_check_load_A_const_64 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[93]); A_arbace_go_check_load_A_const_65 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[94]); A_arbace_go_check_load_A_const_66 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[95]); A_arbace_go_check_load_A_const_67 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[96]); A_arbace_go_check_load_A_const_68 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[97]); A_arbace_go_check_load_A_const_69 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[98]); A_arbace_go_check_load_A_const_70 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[99]); A_arbace_go_check_load_A_const_71 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[100]); A_arbace_go_check_load_A_const_72 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[101]); A_arbace_go_check_load_A_const_73 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[102]) }

func A_arbace_go_check_load_A_clinit_p6() { A_arbace_go_check_load_A_const_74 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[103]); A_arbace_go_check_load_A_const_75 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[104]); A_arbace_go_check_load_A_const_76 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[105]); A_arbace_go_check_load_A_const_77 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[106]); A_arbace_go_check_load_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[107]); A_arbace_go_check_load_A_const_79 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[108]); A_arbace_go_check_load_A_const_80 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[109]); A_arbace_go_check_load_A_const_81 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[110]); A_arbace_go_check_load_A_const_82 = A_arbace_go_check_load_A_const_pool.A[111]; A_arbace_go_check_load_A_const_83 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[112]); A_arbace_go_check_load_A_const_84 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[113]); A_arbace_go_check_load_A_const_85 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[114]) }

func A_arbace_go_check_load_A_clinit_p7() { A_arbace_go_check_load_A_const_86 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[115]); A_arbace_go_check_load_A_const_87 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[116]); A_arbace_go_check_load_A_const_88 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[117]); A_arbace_go_check_load_A_const_89 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[118]); A_arbace_go_check_load_A_const_90 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[119]); A_arbace_go_check_load_A_const_91 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[120]); A_arbace_go_check_load_A_const_92 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[121]); A_arbace_go_check_load_A_const_93 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[122]); A_arbace_go_check_load_A_const_94 = A_arbace_go_check_load_A_const_pool.A[123]; A_arbace_go_check_load_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[124]); A_arbace_go_check_load_A_const_96 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[125]); A_arbace_go_check_load_A_const_97 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[126]) }

func A_arbace_go_check_load_A_clinit_p8() { A_arbace_go_check_load_A_const_98 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[127]); A_arbace_go_check_load_A_const_99 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[128]); A_arbace_go_check_load_A_const_100 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[129]); A_arbace_go_check_load_A_const_101 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[130]); A_arbace_go_check_load_A_const_102 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[131]); A_arbace_go_check_load_A_const_103 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[132]); A_arbace_go_check_load_A_const_104 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[133]); A_arbace_go_check_load_A_const_105 = A_arbace_go_check_load_A_const_pool.A[134]; A_arbace_go_check_load_A_const_106 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[135]); A_arbace_go_check_load_A_const_107 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[136]); A_arbace_go_check_load_A_const_108 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[137]) }

func A_arbace_go_check_load_A_New() *A_arbace_go_check_load_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_load_A) Ctor() {}

func (t *A_arbace_go_check_load_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_load_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_load_A_class }

func (t *A_arbace_go_check_load_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_load_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_load_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_load_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_load_A); return ok }

func A_arbace_go_check_load_A_Cast(x any) *A_arbace_go_check_load_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_load_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_load_A_class)) }; return v }



type A_arbace_go_check_load_clear_cache_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_load_clear_cache_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_load_collect_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_collect_package_A_fn_class *jrt.Class



type A_arbace_go_check_load_collect_package_fn__1660000065_A struct{ j2g_header uint64; F_root, F_base any }

var A_arbace_go_check_load_collect_package_fn__1660000065_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval1660000004_A struct{ jrt.Object }

func A_arbace_go_check_load_eval1660000004_A_New() *A_arbace_go_check_load_eval1660000004_A { t := &A_arbace_go_check_load_eval1660000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_load_eval1660000004_A) Ctor() {}

func (t *A_arbace_go_check_load_eval1660000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_load_eval1660000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_load_eval1660000004_A_class }

func (t *A_arbace_go_check_load_eval1660000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_load_eval1660000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_load_eval1660000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_load_eval1660000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_load_eval1660000004_A); return ok }

func A_arbace_go_check_load_eval1660000004_A_Cast(x any) *A_arbace_go_check_load_eval1660000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_load_eval1660000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_load_eval1660000004_A_class)) }; return v }



type A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval1660000008_A struct{ jrt.Object }

func A_arbace_go_check_load_eval1660000008_A_New() *A_arbace_go_check_load_eval1660000008_A { t := &A_arbace_go_check_load_eval1660000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_load_eval1660000008_A) Ctor() {}

func (t *A_arbace_go_check_load_eval1660000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_load_eval1660000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_load_eval1660000008_A_class }

func (t *A_arbace_go_check_load_eval1660000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_load_eval1660000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_load_eval1660000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_load_eval1660000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_load_eval1660000008_A); return ok }

func A_arbace_go_check_load_eval1660000008_A_Cast(x any) *A_arbace_go_check_load_eval1660000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_load_eval1660000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_load_eval1660000008_A_class)) }; return v }



type A_arbace_go_check_load_eval1660000008_fn__1660000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_eval1660000008_fn__1660000009_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_eval_build_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_and_expr__1660000051_A struct{ j2g_header uint64; F_peek_STAR_, F_not_expr, F_next_STAR_ any }

var A_arbace_go_check_load_eval_build_and_expr__1660000051_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A struct{ j2g_header uint64; F_or_expr, F_tags, F_next_STAR_ any }

var A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_next_STAR___1660000047_A struct{ j2g_header uint64; F_toks, F_pos any }

var A_arbace_go_check_load_eval_build_next_STAR___1660000047_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_not_expr__1660000053_A struct{ j2g_header uint64; F_peek_STAR_, F_atom_STAR_, F_next_STAR_ any }

var A_arbace_go_check_load_eval_build_not_expr__1660000053_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_or_expr__1660000049_A struct{ j2g_header uint64; F_peek_STAR_, F_and_expr, F_next_STAR_ any }

var A_arbace_go_check_load_eval_build_or_expr__1660000049_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A struct{ j2g_header uint64; F_toks, F_pos any }

var A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A_fn_class *jrt.Class



type A_arbace_go_check_load_file_included_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_load_file_included_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A struct{ j2g_header uint64; F_tags any }

var A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A_fn_class *jrt.Class



type A_arbace_go_check_load_good_os_arch_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_load_good_os_arch_file_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_load_ns__GT_file_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_ns__GT_file_A_fn_class *jrt.Class



type A_arbace_go_check_load_overlay_file_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_overlay_file_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_fn__1660000085_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_fn__1660000085_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_fn__1660000087_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_fn__1660000087_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_fn__1660000091_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_fn__1660000091_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_path_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_path_of_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_path_of_fn__1660000095_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_path_of_fn__1660000095_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_source_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_fn__1660000081_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_source_fn__1660000081_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A struct{ j2g_header uint64; F_tags, F_config any }

var A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A struct{ j2g_header uint64; F_s__1660000072, F_tags, F_iter__1660000071, F_config any }

var A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A struct{ j2g_header uint64; F_tags, F_config, F_b__1660000074 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A_fn_class *jrt.Class



type A_arbace_go_check_load_path__GT_ns_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_path__GT_ns_A_fn_class *jrt.Class



type A_arbace_go_check_load_path__GT_ns_fn__1660000013_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_fn_class *jrt.Class



type A_arbace_go_check_load_read_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_read_forms_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tag_set_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_fn__1660000041_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tag_set_fn__1660000041_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A struct{ j2g_header uint64; F_s__1660000022, F_iter__1660000021 any }

var A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1660000024, F_c__1927001037__auto__ any }

var A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A struct{ j2g_header uint64; F_s__1660000032, F_iter__1660000031 any }

var A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A struct{ j2g_header uint64; F_b__1660000034 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A_fn_class *jrt.Class



type A_arbace_go_check_load_tokens_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tokens_A_fn_class *jrt.Class
