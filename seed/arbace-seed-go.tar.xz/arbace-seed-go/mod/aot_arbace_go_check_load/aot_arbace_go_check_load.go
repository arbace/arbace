//line aot_arbace_go_check_load.ae:1
package aot_arbace_go_check_load

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A_New() *A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_go_check_load_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_go_check_load_A_const_1); lang.IFn_Cast(A_arbace_go_check_load_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_go_check_load_A_const_3, A_arbace_go_check_load_A_const_4, A_arbace_go_check_load_A_const_5); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_go_check_load_eval1660000008_fn__1660000009_A_New() *A_arbace_go_check_load_eval1660000008_fn__1660000009_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval1660000008_fn__1660000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_go_check_load_eval1660000008_fn__1660000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_go_check_load_eval1660000008_fn__1660000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_go_check_load_A_const_6.GetRawRoot__O()); var tmp2 any; var root_17 any = A_arbace_go_check_load_A_const_7.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_19 lang.IFn; if linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any = A_arbace_go_check_load_A_const_8; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_17, arg_20) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_go_check_load_A_const_9.GetRawRoot__O(), A_arbace_go_check_load_A_const_10) }














func A_arbace_go_check_load_path__GT_ns_A_New() *A_arbace_go_check_load_path__GT_ns_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_path__GT_ns_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_go_check_load_path__GT_ns_A) Ctor() {}
//line :16:1
func (t *A_arbace_go_check_load_path__GT_ns_A) Invoke_O_O__O(self, path__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_46, nil); var tmp2 any; var root_21 any = A_arbace_go_check_load_A_const_11.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = Lit_23; var arg_25 any; var root_26 any = A_arbace_go_check_load_A_const_12.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any; var fnbody__38 any = A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, nil); A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; arg_29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); var arg_30 any; var root_39 any = A_arbace_go_check_load_A_const_15.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = path__0; var arg_43 any = A_arbace_go_check_load_A_const_16; if linked_40 == nil { arg_30 = ifn_41.Invoke_O_O__O(arg_42, arg_43) } else { arg_30 = linked_40.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_39, arg_42, arg_43) }; if linked_27 == nil { arg_25 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { arg_25 = linked_27.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if linked_22 == nil { tmp2 = ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { tmp2 = linked_22.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, tmp2)).Ref() }
//line :19:1
func A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_New() *A_arbace_go_check_load_path__GT_ns_fn__1660000013_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_path__GT_ns_fn__1660000013_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_go_check_load_path__GT_ns_fn__1660000013_A) Ctor() {}
//line :19:1
func (t *A_arbace_go_check_load_path__GT_ns_fn__1660000013_A) Invoke_O_O__O(self, p1__1660000012_SHARP___1 any) any { var root_31 any = A_arbace_go_check_load_A_const_13.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = p1__1660000012_SHARP___1; var arg_35 any = A_arbace_go_check_load_A_const_14; var arg_36 any = Lit_24; if linked_32 == nil { return ifn_33.Invoke_O_O_O__O(arg_34, arg_35, arg_36) } else { return linked_32.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_31, arg_34, arg_35, arg_36) } }

func A_arbace_go_check_load_ns__GT_file_A_New() *A_arbace_go_check_load_ns__GT_file_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_ns__GT_file_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_go_check_load_ns__GT_file_A) Ctor() {}
//line :21:1
func (t *A_arbace_go_check_load_ns__GT_file_A) Invoke_O_O__O(self, ns__0 any) any {


	var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_33); var tmp2 any; var root_44 any = A_arbace_go_check_load_A_const_13.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_44, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = ns__0; var arg_48 any = Lit_23; var arg_49 any = Lit_22; if linked_45 == nil { tmp2 = ifn_46.Invoke_O_O_O__O(arg_47, arg_48, arg_49) } else { tmp2 = linked_45.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_44, arg_47, arg_48, arg_49) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil)).Ref()
}














func A_arbace_go_check_load_tag_set_A_New() *A_arbace_go_check_load_tag_set_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_A{}; t.Ctor(); return t }
//line :40:1
func (t *A_arbace_go_check_load_tag_set_A) Ctor() {}
//line :40:1
func (t *A_arbace_go_check_load_tag_set_A) Invoke_O_O__O(self, p__1660000018__0 any) any { var map__1660000019__2 any = p__1660000018__0; var map__1660000019__3 any; if lang.ISeq_InstanceOf(map__1660000019__2) { var tmp1 any; var root_50 any = A_arbace_go_check_load_A_const_17.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = map__1660000019__2; if linked_51 == nil { tmp1 = ifn_52.Invoke_O__O(arg_53) } else { tmp1 = linked_51.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_50, arg_53) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_54 any = A_arbace_go_check_load_A_const_18.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = map__1660000019__2; if linked_55 == nil { tmp2 = ifn_56.Invoke_O__O(arg_57) } else { tmp2 = linked_55.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_54, arg_57) }; map__1660000019__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_58 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = map__1660000019__2; if linked_59 == nil { tmp3 = ifn_60.Invoke_O__O(arg_61) } else { tmp3 = linked_59.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_58, arg_61) }; if jrt.J2g_Truth(tmp3) { var root_62 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = map__1660000019__2; if linked_63 == nil { map__1660000019__3 = ifn_64.Invoke_O__O(arg_65) } else { map__1660000019__3 = linked_63.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_62, arg_65) } } else { map__1660000019__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1660000019__3 = map__1660000019__2 }; var goos__4 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_21); var goarch__5 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_22); var goamd64__6 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_23); var goarm64__7 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_24); var tags__8 any = lang.RT_Get_O_O__O_NoInit(map__1660000019__3, A_arbace_go_check_load_A_const_25); var root_66 any = A_arbace_go_check_load_A_const_26.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_68 lang.IFn; _ = goarm64__7; if



	linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, goos__4, Lit_50, goarch__5)); var arg_70 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_go_check_load_A_const_27.GetRawRoot__O()); var tmp5 any; var iter__1927001039__auto____9 any; var fnbody__142 any = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_New(); var tmp6 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_fn_class; if
	fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_51, false, nil); A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_fn_class = fncls__141d; tmp6 = fncls__141d } else { tmp6 = fncls__141 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__142, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____9); var tmp8 any; var root_143 any = A_arbace_go_check_load_A_const_37.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = A_arbace_go_check_load_A_const_38; var arg_147 any = A_arbace_go_check_load_A_const_39; if linked_144 == nil { tmp8 = ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { tmp8 = linked_144.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_143, arg_146, arg_147) }; tmp5 = tmp7.Invoke_O__O(tmp8); var tmp9 any = tmp5; var tmp10 any; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_go_check_load_A_const_40.GetRawRoot__O()).Invoke_O__O(goos__4)) { tmp10 = A_arbace_go_check_load_A_const_41 } else { tmp10 = nil }; var tmp11 any = tmp10; var tmp12 any; var G__1660000031__9_ any = goos__4; L1:
	switch { default: switch lang.Util_Hash_O__I_NoInit(G__1660000031__9_) >> 5 & 3 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1660000031__9_, Lit_31) { tmp12 = A_arbace_go_check_load_A_const_42; break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1660000031__9_, Lit_29) { tmp12 = A_arbace_go_check_load_A_const_43; break L1 }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1660000031__9_, Lit_27) { tmp12 = A_arbace_go_check_load_A_const_44; break L1 }; default:}; tmp12 = nil}; var tmp13 any = tmp12; var tmp14 any; if
	lang.Util_Equiv_O_O__Z_NoInit(Lit_52, goarch__5) { var lv__9 int64; var tmp15 any; var root_149 any = A_arbace_go_check_load_A_const_45.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_151 lang.IFn
		if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any; var or__1927000174__auto____9 any = goamd64__6; if jrt.J2g_Truth(or__1927000174__auto____9) { arg_152 = or__1927000174__auto____9 } else { arg_152 = Lit_53 }; var arg_153 any = A_arbace_go_check_load_A_const_38; if linked_150 == nil { tmp15 = ifn_151.Invoke_O_O__O(arg_152, arg_153) } else { tmp15 = linked_150.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_149, arg_152, arg_153) }; lv__9 = jrt.Long_ParseLong_String__J_NoInit(jrt.String_Cast(tmp15))
//line :48:1
		var iter__1927001039__auto____10 any; var fnbody__215 any = A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_A_New(); var tmp16 *jrt.Class
		var fncls__214 /*line :48:1*/*jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_A_fn_class

		if fncls__214 == nil { var fncls__214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_54, false, nil); A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_A_fn_class = fncls__214d; tmp16 = fncls__214d } else { tmp16 = fncls__214 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__215, tmp16, nil); var tmp17 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____10); var tmp18 any; var root_216 any = A_arbace_go_check_load_A_const_37.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_range_A_fn_class); var ifn_218 lang.IFn; if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = A_arbace_go_check_load_A_const_38; var arg_220 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(lv__9)).Ref(); if linked_217 == nil { tmp18 = ifn_218.Invoke_O_O__O(arg_219, arg_220) } else { tmp18 = linked_217.(*aot_arbace_core.A_arbace_core_range_A).Invoke_O_O_O__O(root_216, arg_219, arg_220) }; tmp14 = tmp17.Invoke_O__O(tmp18) } else {
//line :48:1
			tmp14 = nil }; var tmp19 any = tmp14; var tmp20 any; if


	lang.Util_Equiv_O_O__Z_NoInit(Lit_55, goarch__5) { tmp20 = A_arbace_go_check_load_A_const_46 } else { tmp20 = nil }; var tmp21 any = tmp20; var tmp22 any; var root_221 any = /*line :45:1*/A_arbace_go_check_load_A_const_12.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_223 lang.IFn; if






	linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any; var fnbody__227 any = A_arbace_go_check_load_tag_set_fn__1660000042_A_New(); var tmp23 *jrt.Class; var fncls__226 *jrt.Class = A_arbace_go_check_load_tag_set_fn__1660000042_A_fn_class; if fncls__226 == nil { var fncls__226d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_56, false, nil); A_arbace_go_check_load_tag_set_fn__1660000042_A_fn_class = fncls__226d; tmp23 = fncls__226d } else { tmp23 = fncls__226 }; arg_224 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__227, tmp23, nil); var arg_225 any = A_arbace_go_check_load_A_const_47.GetRawRoot__O(); if linked_222 == nil { tmp22 = ifn_223.Invoke_O_O__O(arg_224, arg_225) } else { tmp22 = linked_222.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_221, arg_224, arg_225) }; arg_70 = /*line :45:1*/tmp4.Invoke_O_O_O_O_O_O_O__O(tmp9, tmp11, tmp13, tmp19, tmp21, tmp22, tags__8); if /*line :44:1*/ linked_67 == nil { return ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { return linked_67.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) } }
func A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_New() *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A) Ctor() {}
//line :45:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A) Invoke_O_O__O(self, s__1660000022__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__140 any = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_New_O_O(s__1660000022__1, self); var tmp2 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_58, false, fnbody__140); A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_fn_class = fncls__139d; tmp2 = fncls__139d } else { tmp2 = fncls__139 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__140, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :45:1
func A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A{}; t.Ctor_O_O(p0, p1); return t }
//line :45:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A) Ctor_O_O(c__s__1660000022, c__iter__1660000021 any) { t.F_s__1660000022 = c__s__1660000022; t.F_iter__1660000021 = c__iter__1660000021 }
//line :45:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A) Invoke_O__O(self any) any { { var s__1660000022__1 any; var t_ any = t.F_s__1660000022; t.F_s__1660000022 = nil; s__1660000022__1 = t_; for { var temp__1927000414__auto____2 any; var root_81 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = s__1660000022__1; if linked_82 == nil { temp__1927000414__auto____2 = ifn_83.Invoke_O__O(arg_84) } else { temp__1927000414__auto____2 = linked_82.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_81, arg_84) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1660000022__3 any = temp__1927000414__auto____2; var tmp1 any; var root_85 any = A_arbace_go_check_load_A_const_28.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = s__1660000022__3; if linked_86 == nil { tmp1 = ifn_87.Invoke_O__O(arg_88) } else { tmp1 = linked_86.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_85, arg_88) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_89 any = A_arbace_go_check_load_A_const_29.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = s__1660000022__3; if linked_90 == nil { c__1927001037__auto____4 = ifn_91.Invoke_O__O(arg_92) } else { c__1927001037__auto____4 = linked_90.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_89, arg_92) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1660000024__6 any; var root_93 any = A_arbace_go_check_load_A_const_30.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_94 == nil { b__1660000024__6 = ifn_95.Invoke_O__O(arg_96) } else { b__1660000024__6 = linked_94.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_93, arg_96) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__103 any = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_New_I_O_O(size__1927001038__auto____5, b__1660000024__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_fn_class; if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_59, false, fnbody__103); A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_fn_class = fncls__102d; tmp3 = fncls__102d } else { tmp3 = fncls__102 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__103, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_104 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any; var root_109 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = b__1660000024__6; if linked_110 == nil { arg_107 = ifn_111.Invoke_O__O(arg_112) } else { arg_107 = linked_110.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_109, arg_112) }; var arg_108 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1660000021); var tmp5 any; var root_113 any = A_arbace_go_check_load_A_const_34.GetRawRoot__O(); var linked_114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_113, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_115 lang.IFn; if linked_114 == nil { ifn_115 = lang.IFn_Cast(root_113) } else { ifn_115 = nil }; var arg_116 any = s__1660000022__3; if linked_114 == nil { tmp5 = ifn_115.Invoke_O__O(arg_116) } else { tmp5 = linked_114.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_113, arg_116) }; arg_108 = tmp4.Invoke_O__O(tmp5); if linked_105 == nil { return ifn_106.Invoke_O_O__O(arg_107, arg_108) } else { return linked_105.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_104, arg_107, arg_108) } } else { var root_117 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any; var root_122 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_123 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_122, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_124 lang.IFn; if linked_123 == nil { ifn_124 = lang.IFn_Cast(root_122) } else { ifn_124 = nil }; var arg_125 any = b__1660000024__6; if linked_123 == nil { arg_120 = ifn_124.Invoke_O__O(arg_125) } else { arg_120 = linked_123.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_122, arg_125) }; var arg_121 any; if linked_118 == nil { return ifn_119.Invoke_O_O__O(arg_120, arg_121) } else { return linked_118.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_117, arg_120, arg_121) } } } else { var i__4 any; var root_126 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = s__1660000022__3; if linked_127 == nil { i__4 = ifn_128.Invoke_O__O(arg_129) } else { i__4 = linked_127.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_126, arg_129) }; var root_130 any = A_arbace_go_check_load_A_const_35.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref(); var arg_134 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1660000021); var tmp7 any; var root_135 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = s__1660000022__3; if linked_136 == nil { tmp7 = ifn_137.Invoke_O__O(arg_138) } else { tmp7 = linked_136.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_135, arg_138) }; arg_134 = tmp6.Invoke_O__O(tmp7); if linked_131 == nil { return ifn_132.Invoke_O_O__O(arg_133, arg_134) } else { return linked_131.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_130, arg_133, arg_134) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :45:1
func A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :45:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1660000024, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1660000024 = c__b__1660000024; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :45:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A) Invoke_O__O(self any) any { { var i__1660000023__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1660000023__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1660000023__1)); var root_97 any = A_arbace_go_check_load_A_const_31.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_99 lang.IFn; if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = t.F_b__1660000024; var arg_101 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_60, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref(); if linked_98 == nil { ifn_99.Invoke_O_O__O(arg_100, arg_101) } else { linked_98.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_97, arg_100, arg_101) }; i__1660000023__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1660000023__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_A_New() *A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_A) Ctor() {}
//line :50:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_A) Invoke_O_O__O(self, s__1660000033__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__213 any = A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_A_New_O_O(s__1660000033__1, self); var tmp2 *jrt.Class; var fncls__212 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_A_fn_class; if fncls__212 == nil { var fncls__212d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_61, false, fnbody__213); A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_A_fn_class = fncls__212d; tmp2 = fncls__212d } else { tmp2 = fncls__212 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__213, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :50:1
func A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_A{}; t.Ctor_O_O(p0, p1); return t }
//line :50:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_A) Ctor_O_O(c__s__1660000033, c__iter__1660000032 any) { t.F_s__1660000033 = c__s__1660000033; t.F_iter__1660000032 = c__iter__1660000032 }
//line :50:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_A) Invoke_O__O(self any) any { { var s__1660000033__1 any; var t_ any = t.F_s__1660000033; t.F_s__1660000033 = nil; s__1660000033__1 = t_; for { var temp__1927000414__auto____2 any; var root_154 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = s__1660000033__1; if linked_155 == nil { temp__1927000414__auto____2 = ifn_156.Invoke_O__O(arg_157) } else { temp__1927000414__auto____2 = linked_155.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_154, arg_157) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1660000033__3 any = temp__1927000414__auto____2; var tmp1 any; var root_158 any = A_arbace_go_check_load_A_const_28.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = s__1660000033__3; if linked_159 == nil { tmp1 = ifn_160.Invoke_O__O(arg_161) } else { tmp1 = linked_159.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_158, arg_161) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_162 any = A_arbace_go_check_load_A_const_29.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = s__1660000033__3; if linked_163 == nil { c__1927001037__auto____4 = ifn_164.Invoke_O__O(arg_165) } else { c__1927001037__auto____4 = linked_163.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_162, arg_165) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1660000035__6 any; var root_166 any = A_arbace_go_check_load_A_const_30.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_167 == nil { b__1660000035__6 = ifn_168.Invoke_O__O(arg_169) } else { b__1660000035__6 = linked_167.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_166, arg_169) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__176 any = A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_fn__1660000038_A_New_I_O_O(size__1927001038__auto____5, b__1660000035__6, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__175 *jrt.Class = A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_fn__1660000038_A_fn_class; if fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, fnbody__176); A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_fn__1660000038_A_fn_class = fncls__175d; tmp3 = fncls__175d } else { tmp3 = fncls__175 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__176, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_177 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_179 lang.IFn; if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any; var root_182 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = b__1660000035__6; if linked_183 == nil { arg_180 = ifn_184.Invoke_O__O(arg_185) } else { arg_180 = linked_183.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_182, arg_185) }; var arg_181 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1660000032); var tmp5 any; var root_186 any = A_arbace_go_check_load_A_const_34.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = s__1660000033__3; if linked_187 == nil { tmp5 = ifn_188.Invoke_O__O(arg_189) } else { tmp5 = linked_187.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_186, arg_189) }; arg_181 = tmp4.Invoke_O__O(tmp5); if linked_178 == nil { return ifn_179.Invoke_O_O__O(arg_180, arg_181) } else { return linked_178.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_177, arg_180, arg_181) } } else { var root_190 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any; var root_195 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_197 lang.IFn; if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = b__1660000035__6; if linked_196 == nil { arg_193 = ifn_197.Invoke_O__O(arg_198) } else { arg_193 = linked_196.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_195, arg_198) }; var arg_194 any; if linked_191 == nil { return ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { return linked_191.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_190, arg_193, arg_194) } } } else { var i__4 any; var root_199 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = s__1660000033__3; if linked_200 == nil { i__4 = ifn_201.Invoke_O__O(arg_202) } else { i__4 = linked_200.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_199, arg_202) }; var root_203 any = A_arbace_go_check_load_A_const_35.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_205 lang.IFn; if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref(); var arg_207 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1660000032); var tmp7 any; var root_208 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = s__1660000033__3; if linked_209 == nil { tmp7 = ifn_210.Invoke_O__O(arg_211) } else { tmp7 = linked_209.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_208, arg_211) }; arg_207 = tmp6.Invoke_O__O(tmp7); if linked_204 == nil { return ifn_205.Invoke_O_O__O(arg_206, arg_207) } else { return linked_204.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_203, arg_206, arg_207) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :50:1
func A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_fn__1660000038_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_fn__1660000038_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_fn__1660000038_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :50:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_fn__1660000038_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1660000035, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1660000035 = c__b__1660000035; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :50:1
func (t *A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_fn__1660000038_A) Invoke_O__O(self any) any { { var i__1660000034__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1660000034__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1660000034__1)); var root_170 any = A_arbace_go_check_load_A_const_31.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = t.F_b__1660000035; var arg_174 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_63, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref(); if linked_171 == nil { ifn_172.Invoke_O_O__O(arg_173, arg_174) } else { linked_171.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_170, arg_173, arg_174) }; i__1660000034__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1660000034__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_go_check_load_tag_set_fn__1660000042_A_New() *A_arbace_go_check_load_tag_set_fn__1660000042_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tag_set_fn__1660000042_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_go_check_load_tag_set_fn__1660000042_A) Ctor() {}
//line :52:1
func (t *A_arbace_go_check_load_tag_set_fn__1660000042_A) Invoke_O_O__O(self, p1__1660000017_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, p1__1660000017_SHARP___1)).Ref() }


func A_arbace_go_check_load_tokens_A_New() *A_arbace_go_check_load_tokens_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_tokens_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_go_check_load_tokens_A) Ctor() {}
//line :55:1
func (t *A_arbace_go_check_load_tokens_A) Invoke_O_O__O(self, s__0 any) any {
	var root_228 any = A_arbace_go_check_load_A_const_48.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_re_seq_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = A_arbace_go_check_load_A_const_49; var arg_232 any = s__0; if linked_229 == nil { return ifn_230.Invoke_O_O__O(arg_231, arg_232) } else { return linked_229.(*aot_arbace_core.A_arbace_core_re_seq_A).Invoke_O_O_O__O(root_228, arg_231, arg_232)
	} }
func A_arbace_go_check_load_eval_build_A_New() *A_arbace_go_check_load_eval_build_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_go_check_load_eval_build_A) Ctor() {}
//line :58:1
func (t *A_arbace_go_check_load_eval_build_A) Invoke_O_O_O__O(self, line__0, tags__1 any) any { var toks__3 any; var root_233 any = A_arbace_go_check_load_A_const_50.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_235 lang.IFn; if


	linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any; var root_237 any = A_arbace_go_check_load_A_const_51.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, A_arbace_go_check_load_tokens_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any; var root_241 any = A_arbace_go_check_load_A_const_13.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_241, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_243 lang.IFn; if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = line__0; var arg_245 any = A_arbace_go_check_load_A_const_52; var arg_246 any = Lit_4; if linked_242 == nil { arg_240 = ifn_243.Invoke_O_O_O__O(arg_244, arg_245, arg_246) } else { arg_240 = linked_242.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_241, arg_244, arg_245, arg_246) }; if linked_238 == nil { arg_236 = ifn_239.Invoke_O__O(arg_240) } else { arg_236 = linked_238.(*A_arbace_go_check_load_tokens_A).Invoke_O_O__O(root_237, arg_240) }; if linked_234 == nil { toks__3 = ifn_235.Invoke_O__O(arg_236) } else { toks__3 = linked_234.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_233, arg_236) }; var pos__4 any; var root_247 any = /*line :58:1*/A_arbace_go_check_load_A_const_53.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_volatile_BANG__A_fn_class); var ifn_249 lang.IFn; if



	linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = A_arbace_go_check_load_A_const_54; if linked_248 == nil { pos__4 = ifn_249.Invoke_O__O(arg_250) } else { pos__4 = linked_248.(*aot_arbace_core.A_arbace_core_volatile_BANG__A).Invoke_O_O__O(root_247, arg_250) }; var peek_STAR___5 any; var fnbody__256 any = /*line :58:1*/A_arbace_go_check_load_eval_build_peek_STAR___1660000046_A_New_O_O(toks__3, pos__4); var tmp1 *jrt.Class; var fncls__255 *jrt.Class = A_arbace_go_check_load_eval_build_peek_STAR___1660000046_A_fn_class; if




	fncls__255 == nil { var fncls__255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_5, false, fnbody__256); A_arbace_go_check_load_eval_build_peek_STAR___1660000046_A_fn_class = fncls__255d; tmp1 = fncls__255d } else { tmp1 = fncls__255 }; peek_STAR___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__256, tmp1, nil); var next_STAR___6 any; var fnbody__264 any = /*line :58:1*/A_arbace_go_check_load_eval_build_next_STAR___1660000048_A_New_O_O(toks__3, pos__4); var tmp2 *jrt.Class; var fncls__263 *jrt.Class = A_arbace_go_check_load_eval_build_next_STAR___1660000048_A_fn_class; if





	fncls__263 == nil { var fncls__263d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_6, false, fnbody__264); A_arbace_go_check_load_eval_build_next_STAR___1660000048_A_fn_class = fncls__263d; tmp2 = fncls__263d } else { tmp2 = fncls__263 }; next_STAR___6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__264, tmp2, nil); var body_or_expr__7 /*line :58:1*/*A_arbace_go_check_load_eval_build_or_expr__1660000050_A = A_arbace_go_check_load_eval_build_or_expr__1660000050_A_New_O_O_O(peek_STAR___5, nil, next_STAR___6); var body_and_expr__8 *A_arbace_go_check_load_eval_build_and_expr__1660000052_A = A_arbace_go_check_load_eval_build_and_expr__1660000052_A_New_O_O_O(peek_STAR___5, nil, next_STAR___6); var body_not_expr__9 *A_arbace_go_check_load_eval_build_not_expr__1660000054_A = A_arbace_go_check_load_eval_build_not_expr__1660000054_A_New_O_O_O(peek_STAR___5, nil, next_STAR___6); var body_atom_STAR___10 *A_arbace_go_check_load_eval_build_atom_STAR___1660000056_A = A_arbace_go_check_load_eval_build_atom_STAR___1660000056_A_New_O_O_O(nil, tags__1, next_STAR___6); var or_expr__7 any; var fnbody__275 any = any(body_or_expr__7); var tmp3 *jrt.Class; var fncls__274 *jrt.Class = A_arbace_go_check_load_eval_build_or_expr__1660000050_A_fn_class; if fncls__274 == nil { var fncls__274d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_7, false, fnbody__275); A_arbace_go_check_load_eval_build_or_expr__1660000050_A_fn_class = fncls__274d; tmp3 = fncls__274d } else { tmp3 = fncls__274 }; or_expr__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__275, tmp3, nil); var and_expr__8 any; var fnbody__277 any = any(body_and_expr__8); var tmp4 *jrt.Class; var fncls__276 *jrt.Class = A_arbace_go_check_load_eval_build_and_expr__1660000052_A_fn_class; if fncls__276 == nil { var fncls__276d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__277); A_arbace_go_check_load_eval_build_and_expr__1660000052_A_fn_class = fncls__276d; tmp4 = fncls__276d } else { tmp4 = fncls__276 }; and_expr__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__277, tmp4, nil); var not_expr__9 any; var fnbody__279 any = any(body_not_expr__9); var tmp5 *jrt.Class; var fncls__278 *jrt.Class = A_arbace_go_check_load_eval_build_not_expr__1660000054_A_fn_class; if fncls__278 == nil { var fncls__278d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__279); A_arbace_go_check_load_eval_build_not_expr__1660000054_A_fn_class = fncls__278d; tmp5 = fncls__278d } else { tmp5 = fncls__278 }; not_expr__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__279, tmp5, nil); var atom_STAR___10 any; var fnbody__281 any = any(body_atom_STAR___10); var tmp6 *jrt.Class; var fncls__280 *jrt.Class = A_arbace_go_check_load_eval_build_atom_STAR___1660000056_A_fn_class; if fncls__280 == nil { var fncls__280d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__281); A_arbace_go_check_load_eval_build_atom_STAR___1660000056_A_fn_class = fncls__280d; tmp6 = fncls__280d } else { tmp6 = fncls__280 }; atom_STAR___10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__281, tmp6, nil); body_or_expr__7.F_and_expr = and_expr__8; body_and_expr__8.F_not_expr = not_expr__9; body_not_expr__9.F_atom_STAR_ = atom_STAR___10; body_atom_STAR___10.F_or_expr = or_expr__7; return /*line :74:1*/ lang.IFn_Cast(or_expr__7).Invoke__O() }
//line :63:1
func A_arbace_go_check_load_eval_build_peek_STAR___1660000046_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_eval_build_peek_STAR___1660000046_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_peek_STAR___1660000046_A{}; t.Ctor_O_O(p0, p1); return t }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_peek_STAR___1660000046_A) Ctor_O_O(c__toks, c__pos any) { t.F_toks = c__toks; t.F_pos = c__pos }
//line :63:1
func (t *A_arbace_go_check_load_eval_build_peek_STAR___1660000046_A) Invoke_O__O(self any) any { var tmp1 any = t.F_toks; var tmp2 any; var root_251 any = A_arbace_go_check_load_A_const_7.GetRawRoot__O(); var linked_252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_251, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_253 lang.IFn; if linked_252 == nil { ifn_253 = lang.IFn_Cast(root_251) } else { ifn_253 = nil }; var arg_254 any = t.F_pos; if linked_252 == nil { tmp2 = ifn_253.Invoke_O__O(arg_254) } else { tmp2 = linked_252.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_251, arg_254) }; return lang.RT_Get_O_O__O_NoInit(tmp1, tmp2) }
func A_arbace_go_check_load_eval_build_next_STAR___1660000048_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_eval_build_next_STAR___1660000048_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_next_STAR___1660000048_A{}; t.Ctor_O_O(p0, p1); return t }
//line :64:1
func (t *A_arbace_go_check_load_eval_build_next_STAR___1660000048_A) Ctor_O_O(c__toks, c__pos any) { t.F_toks = c__toks; t.F_pos = c__pos }
//line :64:1
func (t *A_arbace_go_check_load_eval_build_next_STAR___1660000048_A) Invoke_O__O(self any) any { var t__1 any; var tmp1 any = t.F_toks; var tmp2 any; var root_257 any = A_arbace_go_check_load_A_const_7.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_259 lang.IFn; if linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any = t.F_pos; if linked_258 == nil { tmp2 = ifn_259.Invoke_O__O(arg_260) } else { tmp2 = linked_258.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_257, arg_260) }; t__1 = lang.RT_Get_O_O__O_NoInit(tmp1, tmp2); var tmp3 *lang.Volatile = lang.Volatile_Cast(t.F_pos); var tmp4 jrt.Number_I; var na_261 any = jrt.NN(lang.Volatile_Cast(t.F_pos)).Deref__O(); if jrt.Long_InstanceOf(na_261) { var n0_262 int64 = jrt.NN(jrt.Long_Cast(na_261)).LongValue__J(); if n0_262 == 9223372036854775807 { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_261) } else { tmp4 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(n0_262 + 1)) } } else { if jrt.Double_InstanceOf(na_261) { var n0_262_2 float64 = jrt.NN(jrt.Double_Cast(na_261)).DoubleValue__D(); tmp4 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_262_2 + 1.0)) } else { tmp4 = lang.Numbers_Inc_O__Number_NoInit(na_261) } }; jrt.NN(tmp3).Reset_O__O(tmp4); return t__1 }
func A_arbace_go_check_load_eval_build_and_expr__1660000052_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_load_eval_build_and_expr__1660000052_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_and_expr__1660000052_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :65:1
func (t *A_arbace_go_check_load_eval_build_and_expr__1660000052_A) Ctor_O_O_O(c__peek_STAR_, c__not_expr, c__next_STAR_ any) { t.F_peek_STAR_ = c__peek_STAR_; t.F_not_expr = c__not_expr; t.F_next_STAR_ = c__next_STAR_ }
//line :65:1
func (t *A_arbace_go_check_load_eval_build_and_expr__1660000052_A) Invoke_O__O(self any) any { { var v__1 any = lang.IFn_Cast(t.F_not_expr).Invoke__O(); L1: for {


	if lang.Util_Equiv_O_O__Z_NoInit(Lit_11, lang.IFn_Cast(t.F_peek_STAR_).Invoke__O()) { lang.IFn_Cast(t.F_next_STAR_).Invoke__O(); var w__2 any = lang.IFn_Cast(t.F_not_expr).Invoke__O(); var tmp1 any; var and__1927000168__auto____3 any = v__1; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = w__2 } else { tmp1 = and__1927000168__auto____3 }; v__1 = tmp1; continue L1 } else { return v__1 } } }; /*line :65:1*/panic("j2g: unreachable") }
//line :65:1
func A_arbace_go_check_load_eval_build_atom_STAR___1660000056_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_load_eval_build_atom_STAR___1660000056_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_atom_STAR___1660000056_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :65:1
func (t *A_arbace_go_check_load_eval_build_atom_STAR___1660000056_A) Ctor_O_O_O(c__or_expr, c__tags, c__next_STAR_ any) { t.F_or_expr = c__or_expr; t.F_tags = c__tags; t.F_next_STAR_ = c__next_STAR_ }
//line :65:1
func (t *A_arbace_go_check_load_eval_build_atom_STAR___1660000056_A) Invoke_O__O(self any) any { var t__1 any = lang.IFn_Cast(t.F_next_STAR_).Invoke__O(); if





	lang.Util_Equiv_O_O__Z_NoInit(Lit_12, t__1) { var v__2 any = lang.IFn_Cast(t.F_or_expr).Invoke__O()
		lang.IFn_Cast(t.F_next_STAR_).Invoke__O()
//line :71:1
		return v__2 } else {

			var root_269 any = A_arbace_go_check_load_A_const_56.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = t.F_tags; var arg_273 any = t__1; if linked_270 == nil { return ifn_271.Invoke_O_O__O(arg_272, arg_273) } else { return linked_270.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_269, arg_272, arg_273) } } }
//line :65:1
func A_arbace_go_check_load_eval_build_not_expr__1660000054_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_load_eval_build_not_expr__1660000054_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_not_expr__1660000054_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :65:1
func (t *A_arbace_go_check_load_eval_build_not_expr__1660000054_A) Ctor_O_O_O(c__peek_STAR_, c__atom_STAR_, c__next_STAR_ any) { t.F_peek_STAR_ = c__peek_STAR_; t.F_atom_STAR_ = c__atom_STAR_; t.F_next_STAR_ = c__next_STAR_ }
//line :65:1
func (t *A_arbace_go_check_load_eval_build_not_expr__1660000054_A) Invoke_O__O(self any) any {



	if lang.Util_Equiv_O_O__Z_NoInit(Lit_13, lang.IFn_Cast(t.F_peek_STAR_).Invoke__O()) { lang.IFn_Cast(t.F_next_STAR_).Invoke__O(); var root_265 any = A_arbace_go_check_load_A_const_55.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = lang.IFn_Cast(self).Invoke__O(); if linked_266 == nil { return ifn_267.Invoke_O__O(arg_268) } else { return linked_266.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_265, arg_268) } } else { return lang.IFn_Cast(t.F_atom_STAR_).Invoke__O() } }
//line :65:1
func A_arbace_go_check_load_eval_build_or_expr__1660000050_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_load_eval_build_or_expr__1660000050_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_build_or_expr__1660000050_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :65:1
func (t *A_arbace_go_check_load_eval_build_or_expr__1660000050_A) Ctor_O_O_O(c__peek_STAR_, c__and_expr, c__next_STAR_ any) { t.F_peek_STAR_ = c__peek_STAR_; t.F_and_expr = c__and_expr; t.F_next_STAR_ = c__next_STAR_ }
//line :65:1
func (t *A_arbace_go_check_load_eval_build_or_expr__1660000050_A) Invoke_O__O(self any) any { { var v__1 any = lang.IFn_Cast(t.F_and_expr).Invoke__O(); L1: for {
												if lang.Util_Equiv_O_O__Z_NoInit(Lit_14, lang.IFn_Cast(t.F_peek_STAR_).Invoke__O()) { lang.IFn_Cast(t.F_next_STAR_).Invoke__O(); var w__2 any = lang.IFn_Cast(t.F_and_expr).Invoke__O(); var tmp1 any; var or__1927000174__auto____3 any = v__1; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp1 = or__1927000174__auto____3 } else { tmp1 = w__2 }; v__1 = tmp1; continue L1 } else { return v__1 } } }; /*line :65:1*/panic("j2g: unreachable") }










func A_arbace_go_check_load_eval_plus_build_A_New() *A_arbace_go_check_load_eval_plus_build_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_plus_build_A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_go_check_load_eval_plus_build_A) Ctor() {}
//line :76:1
func (t *A_arbace_go_check_load_eval_plus_build_A) Invoke_O_O_O__O(self, line__0, tags__1 any) any { var opts__3 any; var root_282 any = A_arbace_go_check_load_A_const_57.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_284 lang.IFn; if



	linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = A_arbace_go_check_load_A_const_58.GetRawRoot__O(); var arg_286 any; var root_287 any = A_arbace_go_check_load_A_const_15.GetRawRoot__O(); var linked_288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_287, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_289 lang.IFn; if linked_288 == nil { ifn_289 = lang.IFn_Cast(root_287) } else { ifn_289 = nil }; var arg_290 any; var root_292 any = A_arbace_go_check_load_A_const_59.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any; var root_296 any = A_arbace_go_check_load_A_const_13.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = line__0; var arg_300 any = A_arbace_go_check_load_A_const_60; var arg_301 any = Lit_4; if linked_297 == nil { arg_295 = ifn_298.Invoke_O_O_O__O(arg_299, arg_300, arg_301) } else { arg_295 = linked_297.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_296, arg_299, arg_300, arg_301) }; if linked_293 == nil { arg_290 = ifn_294.Invoke_O__O(arg_295) } else { arg_290 = linked_293.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_292, arg_295) }; var arg_291 any = A_arbace_go_check_load_A_const_61; if linked_288 == nil { arg_286 = ifn_289.Invoke_O_O__O(arg_290, arg_291) } else { arg_286 = linked_288.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_287, arg_290, arg_291) }; if linked_283 == nil { opts__3 = ifn_284.Invoke_O_O__O(arg_285, arg_286) } else { opts__3 = linked_283.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_282, arg_285, arg_286) }; var tmp1 any; var root_302 any =
	A_arbace_go_check_load_A_const_62.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any; var fnbody__344 any = A_arbace_go_check_load_eval_plus_build_fn__1660000059_A_New_O(tags__1); var tmp2 *jrt.Class; var fncls__343 *jrt.Class = A_arbace_go_check_load_eval_plus_build_fn__1660000059_A_fn_class; if fncls__343 == nil { var fncls__343d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_15, false, fnbody__344); A_arbace_go_check_load_eval_plus_build_fn__1660000059_A_fn_class = fncls__343d; tmp2 = fncls__343d } else { tmp2 = fncls__343 }; arg_305 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__344, tmp2, nil); var arg_306 any = opts__3; if linked_303 == nil { tmp1 = ifn_304.Invoke_O_O__O(arg_305, arg_306) } else { tmp1 = linked_303.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_302, arg_305, arg_306) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() }
//line :81:1
func A_arbace_go_check_load_eval_plus_build_fn__1660000059_A_New_O(p0 any) *A_arbace_go_check_load_eval_plus_build_fn__1660000059_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_plus_build_fn__1660000059_A{}; t.Ctor_O(p0); return t }
//line :81:1
func (t *A_arbace_go_check_load_eval_plus_build_fn__1660000059_A) Ctor_O(c__tags any) { t.F_tags = c__tags }
//line :81:1
func (t *A_arbace_go_check_load_eval_plus_build_fn__1660000059_A) Invoke_O_O__O(self, o__1 any) any { var root_307 any = A_arbace_go_check_load_A_const_63.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any; var fnbody__337 any = A_arbace_go_check_load_eval_plus_build_fn__1660000059_fn__1660000060_A_New_O(t.F_tags); var tmp1 *jrt.Class; var fncls__336 *jrt.Class = A_arbace_go_check_load_eval_plus_build_fn__1660000059_fn__1660000060_A_fn_class; if fncls__336 == nil { var fncls__336d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, fnbody__337); A_arbace_go_check_load_eval_plus_build_fn__1660000059_fn__1660000060_A_fn_class = fncls__336d; tmp1 = fncls__336d } else { tmp1 = fncls__336 }; arg_310 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__337, tmp1, nil); var arg_311 any; var root_338 any = A_arbace_go_check_load_A_const_15.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_340 lang.IFn; if
													linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = o__1; var arg_342 any = A_arbace_go_check_load_A_const_65; if linked_339 == nil { arg_311 = ifn_340.Invoke_O_O__O(arg_341, arg_342) } else { arg_311 = linked_339.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_338, arg_341, arg_342) }; if /*line :81:1*/ linked_308 == nil { return ifn_309.Invoke_O_O__O(arg_310, arg_311) } else { return linked_308.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_307, arg_310, arg_311) } }
//line :81:1
func A_arbace_go_check_load_eval_plus_build_fn__1660000059_fn__1660000060_A_New_O(p0 any) *A_arbace_go_check_load_eval_plus_build_fn__1660000059_fn__1660000060_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_eval_plus_build_fn__1660000059_fn__1660000060_A{}; t.Ctor_O(p0); return t }
//line :81:1
func (t *A_arbace_go_check_load_eval_plus_build_fn__1660000059_fn__1660000060_A) Ctor_O(c__tags any) { t.F_tags = c__tags }
//line :81:1
func (t *A_arbace_go_check_load_eval_plus_build_fn__1660000059_fn__1660000060_A) Invoke_O_O__O(self, t__1 any) any { var tmp1 any; var root_312 any = A_arbace_go_check_load_A_const_64.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = t__1; var arg_316 any = Lit_13; if linked_313 == nil { tmp1 = ifn_314.Invoke_O_O__O(arg_315, arg_316) } else { tmp1 = linked_313.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_312, arg_315, arg_316) }; if jrt.J2g_Truth(tmp1) { var root_317 any = A_arbace_go_check_load_A_const_55.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any; var root_321 any = A_arbace_go_check_load_A_const_56.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = t.F_tags; var arg_325 any; var root_326 any = A_arbace_go_check_load_A_const_45.GetRawRoot__O(); var linked_327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_326, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_328 lang.IFn; if linked_327 == nil { ifn_328 = lang.IFn_Cast(root_326) } else { ifn_328 = nil }; var arg_329 any = t__1; var arg_330 any = A_arbace_go_check_load_A_const_38; if linked_327 == nil { arg_325 = ifn_328.Invoke_O_O__O(arg_329, arg_330) } else { arg_325 = linked_327.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_326, arg_329, arg_330) }; if linked_322 == nil { arg_320 = ifn_323.Invoke_O_O__O(arg_324, arg_325) } else { arg_320 = linked_322.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_321, arg_324, arg_325) }; if linked_318 == nil { return ifn_319.Invoke_O__O(arg_320) } else { return linked_318.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_317, arg_320) } } else { var root_331 any = A_arbace_go_check_load_A_const_56.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = t.F_tags; var arg_335 any = t__1; if linked_332 == nil { return ifn_333.Invoke_O_O__O(arg_334, arg_335) } else { return linked_332.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_331, arg_334, arg_335) } } }



func A_arbace_go_check_load_match_tag_A_New() *A_arbace_go_check_load_match_tag_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_match_tag_A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_go_check_load_match_tag_A) Ctor() {}
//line :85:1
func (t *A_arbace_go_check_load_match_tag_A) Invoke_O_O_O_O_O__O(self, part__0, goos__1, goarch__2, tags__3 any) any { var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z_NoInit(part__0, goos__1); if or__1927000174__auto____5 {



	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 bool = lang.Util_Equiv_O_O__Z_NoInit(part__0, goarch__2); if or__1927000174__auto____6 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____6).Ref() } else { var or__1927000174__auto____7 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z_NoInit(goos__1, Lit_27)
		if and__1927000168__auto____7 { or__1927000174__auto____7 = lang.Util_Equiv_O_O__Z_NoInit(part__0, Lit_28) } else { or__1927000174__auto____7 = and__1927000168__auto____7 }
//line :89:1
		if or__1927000174__auto____7 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____7).Ref() } else { var or__1927000174__auto____8 bool; var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(goos__1, Lit_29)

			if and__1927000168__auto____8 { or__1927000174__auto____8 = lang.Util_Equiv_O_O__Z_NoInit(part__0, Lit_30) } else { or__1927000174__auto____8 = and__1927000168__auto____8 }
//line :89:1
			if or__1927000174__auto____8 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { var or__1927000174__auto____9 bool; var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z_NoInit(goos__1, Lit_31)


				if and__1927000168__auto____9 { or__1927000174__auto____9 = lang.Util_Equiv_O_O__Z_NoInit(part__0, Lit_32) } else { or__1927000174__auto____9 = and__1927000168__auto____9 }
//line :89:1
				if or__1927000174__auto____9 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____9).Ref() } else {



					var tmp1 any; var and__1927000168__auto____10 any = tags__3; if jrt.J2g_Truth(and__1927000168__auto____10) { var root_345 any = A_arbace_go_check_load_A_const_56.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any = tags__3; var arg_349 any = part__0; if linked_346 == nil { tmp1 = ifn_347.Invoke_O_O__O(arg_348, arg_349) } else { tmp1 = linked_346.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_345, arg_348, arg_349) } } else { tmp1 = and__1927000168__auto____10 }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp1)).Ref() } } } } } }

func A_arbace_go_check_load_good_os_arch_file_QMARK__A_New() *A_arbace_go_check_load_good_os_arch_file_QMARK__A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_good_os_arch_file_QMARK__A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_go_check_load_good_os_arch_file_QMARK__A) Ctor() {}
//line :95:1
func (t *A_arbace_go_check_load_good_os_arch_file_QMARK__A) Invoke_O_O_O_O_O__O(self, fname__0, goos__1, goarch__2, tags__3 any) any { var n__5 any; var b__5 any; var root_350 any = A_arbace_go_check_load_A_const_45.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_352 lang.IFn; if





	linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any = fname__0; var arg_354 any; var na_355 any; var or__1927000174__auto____5 any; var root_356 any = A_arbace_go_check_load_A_const_66.GetRawRoot__O(); var linked_357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_356, aot_arbace_string.A_arbace_string_last_index_of_A_fn_class); var ifn_358 lang.IFn; if linked_357 == nil { ifn_358 = lang.IFn_Cast(root_356) } else { ifn_358 = nil }; var arg_359 any = fname__0; var arg_360 any = Lit_22; if linked_357 == nil { or__1927000174__auto____5 = ifn_358.Invoke_O_O__O(arg_359, arg_360) } else { or__1927000174__auto____5 = linked_357.(*aot_arbace_string.A_arbace_string_last_index_of_A).Invoke_O_O_O__O(root_356, arg_359, arg_360) }; if jrt.J2g_Truth(or__1927000174__auto____5) { na_355 = or__1927000174__auto____5 } else { na_355 = A_arbace_go_check_load_A_const_67 }; if jrt.Long_InstanceOf(na_355) { var n0_361 int64 = jrt.NN(jrt.Long_Cast(na_355)).LongValue__J(); if n0_361 == 9223372036854775807 { arg_354 = lang.Numbers_Inc_O__Number_NoInit(na_355) } else { arg_354 = jrt.Long_ValueOf_J__Long_NoInit(n0_361 + 1).Ref() } } else { if jrt.Double_InstanceOf(na_355) { var n0_361_2 float64 = jrt.NN(jrt.Double_Cast(na_355)).DoubleValue__D(); arg_354 = jrt.Double_ValueOf_D__Double_NoInit(n0_361_2 + 1.0).Ref() } else { arg_354 = lang.Numbers_Inc_O__Number_NoInit(na_355) } }; if linked_351 == nil { b__5 = ifn_352.Invoke_O_O__O(arg_353, arg_354) } else { b__5 = linked_351.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_350, arg_353, arg_354) }; var temp__1927000408__auto____6 any; var root_362 any = /*line :95:1*/A_arbace_go_check_load_A_const_68.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_364 lang.IFn; if






	linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = b__5; var arg_366 any = Lit_23; if linked_363 == nil { temp__1927000408__auto____6 = ifn_364.Invoke_O_O__O(arg_365, arg_366) } else { temp__1927000408__auto____6 = linked_363.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_362, arg_365, arg_366) }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var d__7 any = temp__1927000408__auto____6; var root_367 any = A_arbace_go_check_load_A_const_45.GetRawRoot__O(); var linked_368 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_367, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_369 lang.IFn; if linked_368 == nil { ifn_369 = lang.IFn_Cast(root_367) } else { ifn_369 = nil }; var arg_370 any = b__5; var arg_371 any = A_arbace_go_check_load_A_const_54; var arg_372 any = d__7; if linked_368 == nil { n__5 = ifn_369.Invoke_O_O_O__O(arg_370, arg_371, arg_372) } else { n__5 = linked_368.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_367, arg_370, arg_371, arg_372) } } else { n__5 = b__5 }; var n__6 any; var temp__1927000408__auto____6_2 any; var root_373 any = /*line :95:1*/A_arbace_go_check_load_A_const_68.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_373, aot_arbace_string.A_arbace_string_index_of_A_fn_class); var ifn_375 lang.IFn; if







	linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any = n__5; var arg_377 any = Lit_24; if linked_374 == nil { temp__1927000408__auto____6_2 = ifn_375.Invoke_O_O__O(arg_376, arg_377) } else { temp__1927000408__auto____6_2 = linked_374.(*aot_arbace_string.A_arbace_string_index_of_A).Invoke_O_O_O__O(root_373, arg_376, arg_377) }; if jrt.J2g_Truth(temp__1927000408__auto____6_2) { var i__7 any = temp__1927000408__auto____6_2; var root_378 any = A_arbace_go_check_load_A_const_45.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = n__5; var arg_382 any = i__7; if linked_379 == nil { n__6 = ifn_380.Invoke_O_O__O(arg_381, arg_382) } else { n__6 = linked_379.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_378, arg_381, arg_382) } } else { n__6 = Lit_4 }; var parts__7 any; var root_383 any = /*line :95:1*/A_arbace_go_check_load_A_const_50.GetRawRoot__O(); var linked_384 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_383, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_385 lang.IFn; if








	linked_384 == nil { ifn_385 = lang.IFn_Cast(root_383) } else { ifn_385 = nil }; var arg_386 any; var root_387 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any; var root_391 any = A_arbace_go_check_load_A_const_15.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_391, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = n__6; var arg_395 any = A_arbace_go_check_load_A_const_69; if linked_392 == nil { arg_390 = ifn_393.Invoke_O_O__O(arg_394, arg_395) } else { arg_390 = linked_392.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_391, arg_394, arg_395) }; if linked_388 == nil { arg_386 = ifn_389.Invoke_O__O(arg_390) } else { arg_386 = linked_388.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_387, arg_390) }; if linked_384 == nil { parts__7 = ifn_385.Invoke_O__O(arg_386) } else { parts__7 = linked_384.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_383, arg_386) }; var l__8 int32 = /*line :95:1*/lang.RT_Count_O__I_NoInit(parts__7); var parts__9 any; var tmp1 bool; var and__1927000168__auto____9 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(l__8), 1); if and__1927000168__auto____9 {










		var tmp2 any; var root_396 any = A_arbace_go_check_load_A_const_70.GetRawRoot__O(); var linked_397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_396, aot_arbace_core.A_arbace_core_peek_A_fn_class); var ifn_398 lang.IFn; if linked_397 == nil { ifn_398 = lang.IFn_Cast(root_396) } else { ifn_398 = nil }; var arg_399 any = parts__7; if linked_397 == nil { tmp2 = ifn_398.Invoke_O__O(arg_399) } else { tmp2 = linked_397.(*aot_arbace_core.A_arbace_core_peek_A).Invoke_O_O__O(root_396, arg_399) }; tmp1 = lang.Util_Equiv_O_O__Z_NoInit(Lit_25, tmp2) } else { tmp1 = and__1927000168__auto____9 }; if tmp1 { var root_400 any = A_arbace_go_check_load_A_const_71.GetRawRoot__O(); var linked_401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_400, aot_arbace_core.A_arbace_core_pop_A_fn_class); var ifn_402 lang.IFn; if linked_401 == nil { ifn_402 = lang.IFn_Cast(root_400) } else { ifn_402 = nil }; var arg_403 any = parts__7; if linked_401 == nil { parts__9 = ifn_402.Invoke_O__O(arg_403) } else { parts__9 = linked_401.(*aot_arbace_core.A_arbace_core_pop_A).Invoke_O_O__O(root_400, arg_403) } } else { parts__9 = parts__7 }; var l__10 int32 = /*line :95:1*/lang.RT_Count_O__I_NoInit(parts__9); var m__11 any; var fnbody__412 any = A_arbace_go_check_load_good_os_arch_file_QMARK__m__1660000066_A_New_O_O_O(goos__1, tags__3, goarch__2); var tmp3 *jrt.Class; var fncls__411 *jrt.Class = A_arbace_go_check_load_good_os_arch_file_QMARK__m__1660000066_A_fn_class; if





	fncls__411 == nil { var fncls__411d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__412); A_arbace_go_check_load_good_os_arch_file_QMARK__m__1660000066_A_fn_class = fncls__411d; tmp3 = fncls__411d } else { tmp3 = fncls__411 }; m__11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__412, tmp3, nil); var tmp4 any; var and__1927000168__auto____12 bool =







	lang.Numbers_Gte_J_J__Z_NoInit(int64(l__10), 2); if and__1927000168__auto____12 {
		var and__1927000168__auto____13 any = lang.IFn_Cast(A_arbace_go_check_load_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__9, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__10), 2)))); if jrt.J2g_Truth(and__1927000168__auto____13) { tmp4 = lang.IFn_Cast(A_arbace_go_check_load_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__9, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__10), 1)))) } else { tmp4 = and__1927000168__auto____13 } } else { tmp4 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12).Ref() }; if /*line :109:1*/ jrt.J2g_Truth(tmp4) { var and__1927000168__auto____12_2 any = lang.IFn_Cast(m__11).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__9, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__10), 1))))

			if jrt.J2g_Truth(and__1927000168__auto____12_2) { return lang.IFn_Cast(m__11).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__9, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__10), 2)))) } else { return and__1927000168__auto____12_2 } } else {
//line :109:1
				var tmp5 any; var and__1927000168__auto____12_3 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(l__10), 1)


				if and__1927000168__auto____12_3 { var or__1927000174__auto____13 any = lang.IFn_Cast(A_arbace_go_check_load_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__9, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__10), 1)))); if jrt.J2g_Truth(or__1927000174__auto____13) { tmp5 = or__1927000174__auto____13 } else { tmp5 = lang.IFn_Cast(A_arbace_go_check_load_A_const_74.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__9, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__10), 1)))) } } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12_3).Ref() }
//line :109:1
				if jrt.J2g_Truth(tmp5) {



					return lang.IFn_Cast(m__11).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(parts__9, lang.RT_IntCast_J__I_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(l__10), 1)))) } else {
//line :109:1
						if A_arbace_go_check_load_A_const_75 != nil { return jrt.Boolean_TRUE.Ref() } else { return nil } } } }
//line :95:1
func (t *A_arbace_go_check_load_good_os_arch_file_QMARK__A) Invoke_O_O_O_O__O(self, fname__0, goos__1, goarch__2 any) any {



	var root_413 any = A_arbace_go_check_load_A_const_76.GetRawRoot__O(); var linked_414 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_413, A_arbace_go_check_load_good_os_arch_file_QMARK__A_fn_class); var ifn_415 lang.IFn; if linked_414 == nil { ifn_415 = lang.IFn_Cast(root_413) } else { ifn_415 = nil }; var arg_416 any = fname__0; var arg_417 any = goos__1; var arg_418 any = goarch__2; var arg_419 any; if linked_414 == nil { return ifn_415.Invoke_O_O_O_O__O(arg_416, arg_417, arg_418, arg_419) } else { return linked_414.(*A_arbace_go_check_load_good_os_arch_file_QMARK__A).Invoke_O_O_O_O_O__O(root_413, arg_416, arg_417, arg_418, arg_419)
	} }
func A_arbace_go_check_load_good_os_arch_file_QMARK__m__1660000066_A_New_O_O_O(p0, p1, p2 any) *A_arbace_go_check_load_good_os_arch_file_QMARK__m__1660000066_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_good_os_arch_file_QMARK__m__1660000066_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :101:1
func (t *A_arbace_go_check_load_good_os_arch_file_QMARK__m__1660000066_A) Ctor_O_O_O(c__goos, c__tags, c__goarch any) { t.F_goos = c__goos; t.F_tags = c__tags; t.F_goarch = c__goarch }
//line :101:1
func (t *A_arbace_go_check_load_good_os_arch_file_QMARK__m__1660000066_A) Invoke_O_O__O(self, p1__1660000065_SHARP___1 any) any {






	var root_404 any = A_arbace_go_check_load_A_const_72.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, A_arbace_go_check_load_match_tag_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = p1__1660000065_SHARP___1; var arg_408 any = t.F_goos; var arg_409 any = t.F_goarch; var arg_410 any = t.F_tags; if linked_405 == nil { return ifn_406.Invoke_O_O_O_O__O(arg_407, arg_408, arg_409, arg_410) } else { return linked_405.(*A_arbace_go_check_load_match_tag_A).Invoke_O_O_O_O_O__O(root_404, arg_407, arg_408, arg_409, arg_410)
	}
}





func A_arbace_go_check_load_file_included_QMARK__A_New() *A_arbace_go_check_load_file_included_QMARK__A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_file_included_QMARK__A{}; t.Ctor(); return t }
//line :116:1
func (t *A_arbace_go_check_load_file_included_QMARK__A) Ctor() {}
//line :116:1
func (t *A_arbace_go_check_load_file_included_QMARK__A) Invoke_O_O_O_O_O__O(self, fname__0, opts__1, config__2, tags__3 any) any { var bs__5 any; var root_420 any = A_arbace_go_check_load_A_const_12.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_422 lang.IFn; if



	linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = A_arbace_go_check_load_A_const_77.GetRawRoot__O(); var arg_424 any = A_arbace_go_check_load_A_const_78.Invoke_O__O(opts__1); if linked_421 == nil { bs__5 = ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { bs__5 = linked_421.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_420, arg_423, arg_424) }; var gb__6 any; var root_425 any = /*line :116:1*/A_arbace_go_check_load_A_const_79.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_427 lang.IFn; if




	linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any; var fnbody__436 any = A_arbace_go_check_load_file_included_QMARK__fn__1660000073_A_New(); var tmp1 *jrt.Class; var fncls__435 *jrt.Class = A_arbace_go_check_load_file_included_QMARK__fn__1660000073_A_fn_class; if fncls__435 == nil { var fncls__435d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_go_check_load_file_included_QMARK__fn__1660000073_A_fn_class = fncls__435d; tmp1 = fncls__435d } else { tmp1 = fncls__435 }; arg_428 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__436, tmp1, nil); var arg_429 any = bs__5; if linked_426 == nil { gb__6 = ifn_427.Invoke_O_O__O(arg_428, arg_429) } else { gb__6 = linked_426.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_425, arg_428, arg_429) }; var and__1927000168__auto____7 any; var root_437 any = /*line :116:1*/A_arbace_go_check_load_A_const_76.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, A_arbace_go_check_load_good_os_arch_file_QMARK__A_fn_class); var ifn_439 lang.IFn; if





	linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = fname__0; var arg_441 any = A_arbace_go_check_load_A_const_21.Invoke_O__O(config__2); var arg_442 any = A_arbace_go_check_load_A_const_22.Invoke_O__O(config__2); var arg_443 any = tags__3; if linked_438 == nil { and__1927000168__auto____7 = ifn_439.Invoke_O_O_O_O__O(arg_440, arg_441, arg_442, arg_443) } else { and__1927000168__auto____7 = linked_438.(*A_arbace_go_check_load_good_os_arch_file_QMARK__A).Invoke_O_O_O_O_O__O(root_437, arg_440, arg_441, arg_442, arg_443) }; if jrt.J2g_Truth(and__1927000168__auto____7) {
		var tmp2 any; var root_444 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_445 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_444, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_446 lang.IFn; if linked_445 == nil { ifn_446 = lang.IFn_Cast(root_444) } else { ifn_446 = nil }; var arg_447 any = gb__6; if linked_445 == nil { tmp2 = ifn_446.Invoke_O__O(arg_447) } else { tmp2 = linked_445.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_444, arg_447) }; if jrt.J2g_Truth(tmp2) {
			var root_448 any = A_arbace_go_check_load_A_const_63.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any; var fnbody__459 any = A_arbace_go_check_load_file_included_QMARK__fn__1660000075_A_New_O(tags__3); var tmp3 *jrt.Class; var fncls__458 *jrt.Class = A_arbace_go_check_load_file_included_QMARK__fn__1660000075_A_fn_class; if fncls__458 == nil { var fncls__458d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, fnbody__459); A_arbace_go_check_load_file_included_QMARK__fn__1660000075_A_fn_class = fncls__458d; tmp3 = fncls__458d } else { tmp3 = fncls__458 }; arg_451 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__459, tmp3, nil); var arg_452 any = gb__6; if linked_449 == nil { return ifn_450.Invoke_O_O__O(arg_451, arg_452) } else { return linked_449.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_448, arg_451, arg_452) } } else {
				var root_460 any = A_arbace_go_check_load_A_const_63.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any; var fnbody__471 any = A_arbace_go_check_load_file_included_QMARK__fn__1660000077_A_New_O(tags__3); var tmp4 *jrt.Class; var fncls__470 *jrt.Class = A_arbace_go_check_load_file_included_QMARK__fn__1660000077_A_fn_class; if fncls__470 == nil { var fncls__470d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, fnbody__471); A_arbace_go_check_load_file_included_QMARK__fn__1660000077_A_fn_class = fncls__470d; tmp4 = fncls__470d } else { tmp4 = fncls__470 }; arg_463 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__471, tmp4, nil); var arg_464 any; var root_472 any = A_arbace_go_check_load_A_const_79.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; var arg_475 any; var fnbody__483 any = A_arbace_go_check_load_file_included_QMARK__fn__1660000079_A_New(); var tmp5 *jrt.Class; var fncls__482 *jrt.Class = A_arbace_go_check_load_file_included_QMARK__fn__1660000079_A_fn_class; if fncls__482 == nil { var fncls__482d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_go_check_load_file_included_QMARK__fn__1660000079_A_fn_class = fncls__482d; tmp5 = fncls__482d } else { tmp5 = fncls__482 }; arg_475 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__483, tmp5, nil); var arg_476 any = bs__5; if linked_473 == nil { arg_464 = ifn_474.Invoke_O_O__O(arg_475, arg_476) } else { arg_464 = linked_473.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_472, arg_475, arg_476) }; if linked_461 == nil { return ifn_462.Invoke_O_O__O(arg_463, arg_464) } else { return linked_461.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_460, arg_463, arg_464) } } } else {
//line :122:1
					return and__1927000168__auto____7 } }
//line :121:1
func A_arbace_go_check_load_file_included_QMARK__fn__1660000073_A_New() *A_arbace_go_check_load_file_included_QMARK__fn__1660000073_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_file_included_QMARK__fn__1660000073_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_go_check_load_file_included_QMARK__fn__1660000073_A) Ctor() {}
//line :121:1
func (t *A_arbace_go_check_load_file_included_QMARK__fn__1660000073_A) Invoke_O_O__O(self, p1__1660000069_SHARP___1 any) any { var root_430 any = A_arbace_go_check_load_A_const_64.GetRawRoot__O(); var linked_431 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_430, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_432 lang.IFn; if linked_431 == nil { ifn_432 = lang.IFn_Cast(root_430) } else { ifn_432 = nil }; var arg_433 any = p1__1660000069_SHARP___1; var arg_434 any = Lit_21; if linked_431 == nil { return ifn_432.Invoke_O_O__O(arg_433, arg_434) } else { return linked_431.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_430, arg_433, arg_434) } }


func A_arbace_go_check_load_file_included_QMARK__fn__1660000075_A_New_O(p0 any) *A_arbace_go_check_load_file_included_QMARK__fn__1660000075_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_file_included_QMARK__fn__1660000075_A{}; t.Ctor_O(p0); return t }
//line :124:1
func (t *A_arbace_go_check_load_file_included_QMARK__fn__1660000075_A) Ctor_O(c__tags any) { t.F_tags = c__tags }
//line :124:1
func (t *A_arbace_go_check_load_file_included_QMARK__fn__1660000075_A) Invoke_O_O__O(self, p1__1660000070_SHARP___1 any) any { var root_453 any = A_arbace_go_check_load_A_const_80.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, A_arbace_go_check_load_eval_build_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = p1__1660000070_SHARP___1; var arg_457 any = t.F_tags; if linked_454 == nil { return ifn_455.Invoke_O_O__O(arg_456, arg_457) } else { return linked_454.(*A_arbace_go_check_load_eval_build_A).Invoke_O_O_O__O(root_453, arg_456, arg_457) } }
func A_arbace_go_check_load_file_included_QMARK__fn__1660000077_A_New_O(p0 any) *A_arbace_go_check_load_file_included_QMARK__fn__1660000077_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_file_included_QMARK__fn__1660000077_A{}; t.Ctor_O(p0); return t }
//line :125:1
func (t *A_arbace_go_check_load_file_included_QMARK__fn__1660000077_A) Ctor_O(c__tags any) { t.F_tags = c__tags }
//line :125:1
func (t *A_arbace_go_check_load_file_included_QMARK__fn__1660000077_A) Invoke_O_O__O(self, p1__1660000071_SHARP___1 any) any { var root_465 any = A_arbace_go_check_load_A_const_81.GetRawRoot__O(); var linked_466 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_465, A_arbace_go_check_load_eval_plus_build_A_fn_class); var ifn_467 lang.IFn; if linked_466 == nil { ifn_467 = lang.IFn_Cast(root_465) } else { ifn_467 = nil }; var arg_468 any = p1__1660000071_SHARP___1; var arg_469 any = t.F_tags; if linked_466 == nil { return ifn_467.Invoke_O_O__O(arg_468, arg_469) } else { return linked_466.(*A_arbace_go_check_load_eval_plus_build_A).Invoke_O_O_O__O(root_465, arg_468, arg_469) } }
//line :125:1
func A_arbace_go_check_load_file_included_QMARK__fn__1660000079_A_New() *A_arbace_go_check_load_file_included_QMARK__fn__1660000079_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_file_included_QMARK__fn__1660000079_A{}; t.Ctor(); return t }
//line :125:1
func (t *A_arbace_go_check_load_file_included_QMARK__fn__1660000079_A) Ctor() {}
//line :125:1
func (t *A_arbace_go_check_load_file_included_QMARK__fn__1660000079_A) Invoke_O_O__O(self, p1__1660000072_SHARP___1 any) any { var root_477 any = A_arbace_go_check_load_A_const_82.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_479 lang.IFn; if linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = A_arbace_go_check_load_A_const_83; var arg_481 any = p1__1660000072_SHARP___1; if linked_478 == nil { return ifn_479.Invoke_O_O__O(arg_480, arg_481) } else { return linked_478.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_477, arg_480, arg_481) } }





func A_arbace_go_check_load_read_forms_A_New() *A_arbace_go_check_load_read_forms_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_read_forms_A{}; t.Ctor(); return t }
//line :131:1
func (t *A_arbace_go_check_load_read_forms_A) Ctor() {}
//line :131:1
func (t *A_arbace_go_check_load_read_forms_A) Invoke_O_O__O(self, f__0 any) any { var k__2 any = jrt.File_Cast(f__0).GetPath__String().Ref(); var or__1927000174__auto____3 any = lang.Reflector_InvokeInstanceMethod_O_String_O1__O(A_arbace_go_check_load_A_const_84.GetRawRoot__O(), Lit_48, jrt.RefArrayOf(jrt.Object_class, k__2)); if



	jrt.J2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var v__4 any; var root_484 any = A_arbace_go_check_load_A_const_85.GetRawRoot__O(); var linked_485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_484, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_486 lang.IFn
		if linked_485 == nil { ifn_486 = lang.IFn_Cast(root_484) } else { ifn_486 = nil }; var arg_487 any = f__0; if linked_485 == nil { v__4 = ifn_486.Invoke_O__O(arg_487) } else { v__4 = linked_485.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_484, arg_487) }
		lang.Reflector_InvokeInstanceMethod_O_String_O1__O(A_arbace_go_check_load_A_const_84.GetRawRoot__O(), Lit_49, jrt.RefArrayOf(jrt.Object_class, k__2, v__4))
//line :135:1
		return v__4 } }




func A_arbace_go_check_load_clear_cache_BANG__A_New() *A_arbace_go_check_load_clear_cache_BANG__A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_clear_cache_BANG__A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_go_check_load_clear_cache_BANG__A) Ctor() {}
//line :140:1
func (t *A_arbace_go_check_load_clear_cache_BANG__A) Invoke_O__O(self any) any { return lang.Reflector_InvokeNoArgInstanceMember_O_String_Z__O(A_arbace_go_check_load_A_const_84.GetRawRoot__O(), Lit_1, false) }

func A_arbace_go_check_load_overlay_file_A_New() *A_arbace_go_check_load_overlay_file_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_overlay_file_A{}; t.Ctor(); return t }
//line :142:1
func (t *A_arbace_go_check_load_overlay_file_A) Ctor() {}
//line :142:1
func (t *A_arbace_go_check_load_overlay_file_A) Invoke_O_O_O__O(self, root__0, rel__1 any) any { var ov__3 any; if


	jrt.J2g_Truth(A_arbace_go_check_load_A_const_86.Invoke_O__O(root__0)) { ov__3 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_load_A_const_86.Invoke_O__O(root__0), nil, rel__1))) } else { ov__3 = nil }; var tmp1 any; var and__1927000168__auto____4 any = ov__3; if
	jrt.J2g_Truth(and__1927000168__auto____4) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(ov__3).IsFile__Z()).Ref() } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) { return ov__3 } else { return jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_22, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_load_A_const_87.Invoke_O__O(root__0), nil, rel__1))) } }

func A_arbace_go_check_load_collect_package_A_New() *A_arbace_go_check_load_collect_package_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_collect_package_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_go_check_load_collect_package_A) Ctor() {}
//line :148:1
func (t *A_arbace_go_check_load_collect_package_A) Invoke_O_O_O__O(self, root__0, pf__1 any) any { var base__3 any; var tmp1 any; var root_488 any = A_arbace_go_check_load_A_const_77.GetRawRoot__O(); var linked_489 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_488, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_490 lang.IFn; if



	linked_489 == nil { ifn_490 = lang.IFn_Cast(root_488) } else { ifn_490 = nil }; var arg_491 any = A_arbace_go_check_load_A_const_87.Invoke_O__O(root__0); if linked_489 == nil { tmp1 = ifn_490.Invoke_O__O(arg_491) } else { tmp1 = linked_489.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_488, arg_491) }; base__3 = jrt.File_New_String(jrt.String_Cast(tmp1)).GetCanonicalPath__String().Ref(); var root_492 any =
	A_arbace_go_check_load_A_const_88.GetRawRoot__O(); var linked_493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_492, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A_fn_class); var ifn_494 lang.IFn; if linked_493 == nil { ifn_494 = lang.IFn_Cast(root_492) } else { ifn_494 = nil }; var arg_495 any = pf__1; var arg_496 any; var fnbody__517 any = A_arbace_go_check_load_collect_package_fn__1660000085_A_New_O_O(root__0, base__3); var tmp2 *jrt.Class; var fncls__516 *jrt.Class = A_arbace_go_check_load_collect_package_fn__1660000085_A_fn_class; if fncls__516 == nil { var fncls__516d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_2, false, fnbody__517); A_arbace_go_check_load_collect_package_fn__1660000085_A_fn_class = fncls__516d; tmp2 = fncls__516d } else { tmp2 = fncls__516 }; arg_496 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__517, tmp2, nil); if linked_493 == nil { return ifn_494.Invoke_O_O__O(arg_495, arg_496) } else { return linked_493.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A).Invoke_O_O_O__O(root_492, arg_495, arg_496) } }
//line :153:1
func A_arbace_go_check_load_collect_package_fn__1660000085_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_collect_package_fn__1660000085_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_collect_package_fn__1660000085_A{}; t.Ctor_O_O(p0, p1); return t }
//line :153:1
func (t *A_arbace_go_check_load_collect_package_fn__1660000085_A) Ctor_O_O(c__root, c__base any) { t.F_root = c__root; t.F_base = c__base }
//line :153:1
func (t *A_arbace_go_check_load_collect_package_fn__1660000085_A) Invoke_O_O__O(self, f__1 any) any { var p__2 any = jrt.File_Cast(f__1).GetCanonicalPath__String().Ref(); var rel__3 any; var tmp1 any; var root_497 any = A_arbace_go_check_load_A_const_64.GetRawRoot__O(); var linked_498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_497, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_499 lang.IFn; if

	linked_498 == nil { ifn_499 = lang.IFn_Cast(root_497) } else { ifn_499 = nil }; var arg_500 any = p__2; var arg_501 any = t.F_base; if linked_498 == nil { tmp1 = ifn_499.Invoke_O_O__O(arg_500, arg_501) } else { tmp1 = linked_498.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_497, arg_500, arg_501) }; if jrt.J2g_Truth(tmp1) { var root_502 any = A_arbace_go_check_load_A_const_45.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = p__2; var arg_506 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_base)))).Ref(); if linked_503 == nil { rel__3 = ifn_504.Invoke_O_O__O(arg_505, arg_506) } else { rel__3 = linked_503.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_502, arg_505, arg_506) } } else { rel__3 = nil }; var root_507 any =
	A_arbace_go_check_load_A_const_89.GetRawRoot__O(); var linked_508 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_507, A_arbace_go_check_load_read_forms_A_fn_class); var ifn_509 lang.IFn; if linked_508 == nil { ifn_509 = lang.IFn_Cast(root_507) } else { ifn_509 = nil }; var arg_510 any; if jrt.J2g_Truth(rel__3) { var root_511 any = A_arbace_go_check_load_A_const_90.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, A_arbace_go_check_load_overlay_file_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any = t.F_root; var arg_515 any = rel__3; if linked_512 == nil { arg_510 = ifn_513.Invoke_O_O__O(arg_514, arg_515) } else { arg_510 = linked_512.(*A_arbace_go_check_load_overlay_file_A).Invoke_O_O_O__O(root_511, arg_514, arg_515) } } else { arg_510 = f__1 }; if linked_508 == nil { return ifn_509.Invoke_O__O(arg_510) } else { return linked_508.(*A_arbace_go_check_load_read_forms_A).Invoke_O_O__O(root_507, arg_510) } }

func A_arbace_go_check_load_package_source_A_New() *A_arbace_go_check_load_package_source_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_go_check_load_package_source_A) Ctor() {}
//line :158:1
func (t *A_arbace_go_check_load_package_source_A) Invoke_O_O_O_O_O__O(self, root__0, path__1, config__2, pf__3 any) any { var pf__5 any; var or__1927000174__auto____5 any = pf__3; if





	jrt.J2g_Truth(or__1927000174__auto____5) { pf__5 = or__1927000174__auto____5 } else { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_22, nil); var tmp2 any = A_arbace_go_check_load_A_const_87.Invoke_O__O(root__0); var tmp3 any; var root_518 any = A_arbace_go_check_load_A_const_91.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, A_arbace_go_check_load_ns__GT_file_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any; var root_522 any = A_arbace_go_check_load_A_const_92.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, A_arbace_go_check_load_path__GT_ns_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = path__1; if linked_523 == nil { arg_521 = ifn_524.Invoke_O__O(arg_525) } else { arg_521 = linked_523.(*A_arbace_go_check_load_path__GT_ns_A).Invoke_O_O__O(root_522, arg_525) }; if linked_519 == nil { tmp3 = ifn_520.Invoke_O__O(arg_521) } else { tmp3 = linked_519.(*A_arbace_go_check_load_ns__GT_file_A).Invoke_O_O__O(root_518, arg_521) }; pf__5 = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, tmp3))) }; if
	jrt.File_Cast(pf__5).IsFile__Z() { var map__1660000089__6 any; var root_526 any = A_arbace_go_check_load_A_const_93.GetRawRoot__O(); var linked_527 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_526, A_arbace_go_check_load_collect_package_A_fn_class); var ifn_528 lang.IFn
		if linked_527 == nil { ifn_528 = lang.IFn_Cast(root_526) } else { ifn_528 = nil }; var arg_529 any = root__0; var arg_530 any = pf__5; if linked_527 == nil { map__1660000089__6 = ifn_528.Invoke_O_O__O(arg_529, arg_530) } else { map__1660000089__6 = linked_527.(*A_arbace_go_check_load_collect_package_A).Invoke_O_O_O__O(root_526, arg_529, arg_530) }
//line :165:1
		var map__1660000089__7 any
		if lang.ISeq_InstanceOf(map__1660000089__6) { var tmp4 any; var root_531 any = A_arbace_go_check_load_A_const_17.GetRawRoot__O(); var linked_532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_531, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_533 lang.IFn; if linked_532 == nil { ifn_533 = lang.IFn_Cast(root_531) } else { ifn_533 = nil }; var arg_534 any = map__1660000089__6; if linked_532 == nil { tmp4 = ifn_533.Invoke_O__O(arg_534) } else { tmp4 = linked_532.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_531, arg_534) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_535 any = A_arbace_go_check_load_A_const_18.GetRawRoot__O(); var linked_536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_535, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_537 lang.IFn; if linked_536 == nil { ifn_537 = lang.IFn_Cast(root_535) } else { ifn_537 = nil }; var arg_538 any = map__1660000089__6; if linked_536 == nil { tmp5 = ifn_537.Invoke_O__O(arg_538) } else { tmp5 = linked_536.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_535, arg_538) }; map__1660000089__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp5)).Ref() } else { var tmp6 any; var root_539 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = map__1660000089__6; if linked_540 == nil { tmp6 = ifn_541.Invoke_O__O(arg_542) } else { tmp6 = linked_540.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_539, arg_542) }; if jrt.J2g_Truth(tmp6) { var root_543 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_543, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_545 lang.IFn; if linked_544 == nil { ifn_545 = lang.IFn_Cast(root_543) } else { ifn_545 = nil }; var arg_546 any = map__1660000089__6; if linked_544 == nil { map__1660000089__7 = ifn_545.Invoke_O__O(arg_546) } else { map__1660000089__7 = linked_544.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_543, arg_546) } } else { map__1660000089__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1660000089__7 = map__1660000089__6 }
//line :165:1
		var package__8 any = lang.RT_Get_O_O__O_NoInit(map__1660000089__7, A_arbace_go_check_load_A_const_94); var name__9 any = lang.RT_Get_O_O__O_NoInit(map__1660000089__7, A_arbace_go_check_load_A_const_95); var files__10 any = lang.RT_Get_O_O__O_NoInit(map__1660000089__7, A_arbace_go_check_load_A_const_96); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_go_check_load_A_const_97.GetRawRoot__O()); var tmp8 any = A_arbace_go_check_load_A_const_98; var config__11 any = tmp7.Invoke_O_O_O__O(tmp8, A_arbace_go_check_load_A_const_99.Invoke_O__O(package__8), config__2); var tags__12 any; var root_553 any = A_arbace_go_check_load_A_const_100.GetRawRoot__O(); var linked_554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_553, A_arbace_go_check_load_tag_set_A_fn_class); var ifn_555 lang.IFn


		if linked_554 == nil { ifn_555 = lang.IFn_Cast(root_553) } else { ifn_555 = nil }; var arg_556 any = config__11; if linked_554 == nil { tags__12 = ifn_555.Invoke_O__O(arg_556) } else { tags__12 = linked_554.(*A_arbace_go_check_load_tag_set_A).Invoke_O_O__O(root_553, arg_556) }
//line :165:1
		var all__13 any = files__10; var files__14 any; var root_557 any = A_arbace_go_check_load_A_const_50.GetRawRoot__O(); var linked_558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_557, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_559 lang.IFn




		if linked_558 == nil { ifn_559 = lang.IFn_Cast(root_557) } else { ifn_559 = nil }; var arg_560 any; var iter__1927001039__auto____14 any; var fnbody__652 any = A_arbace_go_check_load_package_source_iter__1660000091__1660000095_A_New_O_O(tags__12, config__11); var tmp9 *jrt.Class; var fncls__651 *jrt.Class = A_arbace_go_check_load_package_source_iter__1660000091__1660000095_A_fn_class; if fncls__651 == nil { var fncls__651d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_42, false, fnbody__652); A_arbace_go_check_load_package_source_iter__1660000091__1660000095_A_fn_class = fncls__651d; tmp9 = fncls__651d } else { tmp9 = fncls__651 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__652, tmp9, nil); arg_560 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(files__10); if linked_558 == nil { files__14 = ifn_559.Invoke_O__O(arg_560) } else { files__14 = linked_558.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_557, arg_560) }
//line :165:1
		var tmp10 any = A_arbace_go_check_load_A_const_104; var tmp11 any; var or__1927000174__auto____15 any = A_arbace_go_check_load_A_const_104.Invoke_O__O(package__8)








		if jrt.J2g_Truth(or__1927000174__auto____15) { tmp11 = or__1927000174__auto____15 } else { tmp11 = path__1 }
//line :165:1
		var tmp12 any = tmp11; var tmp13 any = A_arbace_go_check_load_A_const_95; var tmp14 any; var root_653 any = A_arbace_go_check_load_A_const_105.GetRawRoot__O(); var linked_654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_653, aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A_fn_class); var ifn_655 lang.IFn








		if linked_654 == nil { ifn_655 = lang.IFn_Cast(root_653) } else { ifn_655 = nil }; var arg_656 any = name__9; if linked_654 == nil { tmp14 = ifn_655.Invoke_O__O(arg_656) } else { tmp14 = linked_654.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_name_text_A).Invoke_O_O__O(root_653, arg_656) }
//line :165:1
		var tmp15 any = tmp14; var tmp16 any = A_arbace_go_check_load_A_const_99; var tmp17 any = A_arbace_go_check_load_A_const_101; var tmp18 any = A_arbace_go_check_load_A_const_96; var tmp19 any = A_arbace_go_check_load_A_const_106; var tmp20 any = jrt.File_Cast(pf__5).GetPath__String().Ref(); var tmp21 any = A_arbace_go_check_load_A_const_107; var tmp22 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(all__13)), int64(lang.RT_Count_O__I_NoInit(files__14)))).Ref(); var tmp23 any = A_arbace_go_check_load_A_const_108; var tmp24 any; var root_657 any = A_arbace_go_check_load_A_const_62.GetRawRoot__O(); var linked_658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_657, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_659 lang.IFn













		if linked_658 == nil { ifn_659 = lang.IFn_Cast(root_657) } else { ifn_659 = nil }; var arg_660 any; var fnbody__671 any = A_arbace_go_check_load_package_source_fn__1660000101_A_New(); var tmp25 *jrt.Class; var fncls__670 *jrt.Class = A_arbace_go_check_load_package_source_fn__1660000101_A_fn_class; if fncls__670 == nil { var fncls__670d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); A_arbace_go_check_load_package_source_fn__1660000101_A_fn_class = fncls__670d; tmp25 = fncls__670d } else { tmp25 = fncls__670 }; arg_660 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__671, tmp25, nil); var arg_661 any; var root_672 any = A_arbace_go_check_load_A_const_89.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, A_arbace_go_check_load_read_forms_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = pf__5; if linked_673 == nil { arg_661 = ifn_674.Invoke_O__O(arg_675) } else { arg_661 = linked_673.(*A_arbace_go_check_load_read_forms_A).Invoke_O_O__O(root_672, arg_675) }; if linked_658 == nil { tmp24 = ifn_659.Invoke_O_O__O(arg_660, arg_661) } else { tmp24 = linked_658.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_657, arg_660, arg_661) }
//line :165:1
		return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp13, tmp15, tmp16, config__11, tmp17, package__8, tmp18, files__14, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24)) } else { return nil } }
//line :158:1
func (t *A_arbace_go_check_load_package_source_A) Invoke_O_O_O_O__O(self, root__0, path__1, config__2 any) any {



	var root_676 any = A_arbace_go_check_load_A_const_112.GetRawRoot__O(); var linked_677 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_676, A_arbace_go_check_load_package_source_A_fn_class); var ifn_678 lang.IFn; if linked_677 == nil { ifn_678 = lang.IFn_Cast(root_676) } else { ifn_678 = nil }; var arg_679 any = root__0; var arg_680 any = path__1; var arg_681 any = config__2; var arg_682 any; if linked_677 == nil { return ifn_678.Invoke_O_O_O_O__O(arg_679, arg_680, arg_681, arg_682) } else { return linked_677.(*A_arbace_go_check_load_package_source_A).Invoke_O_O_O_O_O__O(root_676, arg_679, arg_680, arg_681, arg_682)
	}
}





func A_arbace_go_check_load_package_source_iter__1660000091__1660000095_A_New_O_O(p0, p1 any) *A_arbace_go_check_load_package_source_iter__1660000091__1660000095_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_iter__1660000091__1660000095_A{}; t.Ctor_O_O(p0, p1); return t }
//line :170:1
func (t *A_arbace_go_check_load_package_source_iter__1660000091__1660000095_A) Ctor_O_O(c__tags, c__config any) { t.F_tags = c__tags; t.F_config = c__config }
//line :170:1
func (t *A_arbace_go_check_load_package_source_iter__1660000091__1660000095_A) Invoke_O_O__O(self, s__1660000092__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__650 any = A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_A_New_O_O_O_O(s__1660000092__1, t.F_tags, self, t.F_config); var tmp2 *jrt.Class; var fncls__649 *jrt.Class = A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_A_fn_class; if fncls__649 == nil { var fncls__649d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__650); A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_A_fn_class = fncls__649d; tmp2 = fncls__649d } else { tmp2 = fncls__649 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__650, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :170:1
func A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :170:1
func (t *A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_A) Ctor_O_O_O_O(c__s__1660000092, c__tags, c__iter__1660000091, c__config any) { t.F_s__1660000092 = c__s__1660000092; t.F_tags = c__tags; t.F_iter__1660000091 = c__iter__1660000091; t.F_config = c__config }
//line :170:1
func (t *A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_A) Invoke_O__O(self any) any { { var s__1660000092__1 any; var t_ any = t.F_s__1660000092; t.F_s__1660000092 = nil; s__1660000092__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_561 any = A_arbace_go_check_load_A_const_19.GetRawRoot__O(); var linked_562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_561, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_563 lang.IFn; if linked_562 == nil { ifn_563 = lang.IFn_Cast(root_561) } else { ifn_563 = nil }; var arg_564 any = s__1660000092__1; if linked_562 == nil { temp__1927000414__auto____2 = ifn_563.Invoke_O__O(arg_564) } else { temp__1927000414__auto____2 = linked_562.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_561, arg_564) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1660000092__3 any = temp__1927000414__auto____2; var tmp1 any; var root_565 any = A_arbace_go_check_load_A_const_28.GetRawRoot__O(); var linked_566 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_565, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_567 lang.IFn; if linked_566 == nil { ifn_567 = lang.IFn_Cast(root_565) } else { ifn_567 = nil }; var arg_568 any = s__1660000092__3; if linked_566 == nil { tmp1 = ifn_567.Invoke_O__O(arg_568) } else { tmp1 = linked_566.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_565, arg_568) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_569 any = A_arbace_go_check_load_A_const_29.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = s__1660000092__3; if linked_570 == nil { c__1927001037__auto____4 = ifn_571.Invoke_O__O(arg_572) } else { c__1927001037__auto____4 = linked_570.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_569, arg_572) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1660000094__6 any; var root_573 any = A_arbace_go_check_load_A_const_30.GetRawRoot__O(); var linked_574 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_573, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_575 lang.IFn; if linked_574 == nil { ifn_575 = lang.IFn_Cast(root_573) } else { ifn_575 = nil }; var arg_576 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_574 == nil { b__1660000094__6 = ifn_575.Invoke_O__O(arg_576) } else { b__1660000094__6 = linked_574.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_573, arg_576) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__596 any = A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_fn__1660000097_A_New_O_O_O_I_O(t.F_tags, b__1660000094__6, t.F_config, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__595 *jrt.Class = A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_fn__1660000097_A_fn_class; if fncls__595 == nil { var fncls__595d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_45, false, fnbody__596); A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_fn__1660000097_A_fn_class = fncls__595d; tmp3 = fncls__595d } else { tmp3 = fncls__595 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__596, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_597 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any; var root_602 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = b__1660000094__6; if linked_603 == nil { arg_600 = ifn_604.Invoke_O__O(arg_605) } else { arg_600 = linked_603.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_602, arg_605) }; var arg_601 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1660000091); var tmp5 any; var root_606 any = A_arbace_go_check_load_A_const_34.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = s__1660000092__3; if linked_607 == nil { tmp5 = ifn_608.Invoke_O__O(arg_609) } else { tmp5 = linked_607.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_606, arg_609) }; arg_601 = tmp4.Invoke_O__O(tmp5); if linked_598 == nil { return ifn_599.Invoke_O_O__O(arg_600, arg_601) } else { return linked_598.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_597, arg_600, arg_601) } } else { var root_610 any = A_arbace_go_check_load_A_const_32.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any; var root_615 any = A_arbace_go_check_load_A_const_33.GetRawRoot__O(); var linked_616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_615, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_617 lang.IFn; if linked_616 == nil { ifn_617 = lang.IFn_Cast(root_615) } else { ifn_617 = nil }; var arg_618 any = b__1660000094__6; if linked_616 == nil { arg_613 = ifn_617.Invoke_O__O(arg_618) } else { arg_613 = linked_616.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_615, arg_618) }; var arg_614 any; if linked_611 == nil { return ifn_612.Invoke_O_O__O(arg_613, arg_614) } else { return linked_611.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_610, arg_613, arg_614) } } } else { var fi__4 any; var root_619 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = s__1660000092__3; if linked_620 == nil { fi__4 = ifn_621.Invoke_O__O(arg_622) } else { fi__4 = linked_620.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_619, arg_622) }; var opts__5 any = A_arbace_go_check_load_A_const_101.Invoke_O__O(fi__4); var tmp6 any; var root_623 any = A_arbace_go_check_load_A_const_102.GetRawRoot__O(); var linked_624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_623, A_arbace_go_check_load_file_included_QMARK__A_fn_class); var ifn_625 lang.IFn

	if linked_624 == nil { ifn_625 = lang.IFn_Cast(root_623) } else { ifn_625 = nil }; var arg_626 any = A_arbace_go_check_load_A_const_95.Invoke_O__O(fi__4); var arg_627 any = opts__5; var arg_628 any = t.F_config; var arg_629 any = t.F_tags; if linked_624 == nil { tmp6 = ifn_625.Invoke_O_O_O_O__O(arg_626, arg_627, arg_628, arg_629) } else { tmp6 = linked_624.(*A_arbace_go_check_load_file_included_QMARK__A).Invoke_O_O_O_O_O__O(root_623, arg_626, arg_627, arg_628, arg_629) }
//line :170:1
	if jrt.J2g_Truth(tmp6) { var root_630 any = A_arbace_go_check_load_A_const_35.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any; var root_635 any = A_arbace_go_check_load_A_const_103.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_637 lang.IFn


		if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any = fi__4; var arg_639 any = A_arbace_go_check_load_A_const_101; var arg_640 any = opts__5; if linked_636 == nil { arg_633 = ifn_637.Invoke_O_O_O__O(arg_638, arg_639, arg_640) } else { arg_633 = linked_636.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_635, arg_638, arg_639, arg_640) }
//line :170:1
		var arg_634 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1660000091); var tmp8 any; var root_641 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_642 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_641, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_643 lang.IFn; if linked_642 == nil { ifn_643 = lang.IFn_Cast(root_641) } else { ifn_643 = nil }; var arg_644 any = s__1660000092__3; if linked_642 == nil { tmp8 = ifn_643.Invoke_O__O(arg_644) } else { tmp8 = linked_642.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_641, arg_644) }; arg_634 = tmp7.Invoke_O__O(tmp8); if linked_631 == nil { return ifn_632.Invoke_O_O__O(arg_633, arg_634) } else { return linked_631.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_630, arg_633, arg_634) } } else { var tmp9 any; var root_645 any = A_arbace_go_check_load_A_const_36.GetRawRoot__O(); var linked_646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_645, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_647 lang.IFn; if linked_646 == nil { ifn_647 = lang.IFn_Cast(root_645) } else { ifn_647 = nil }; var arg_648 any = s__1660000092__3; if linked_646 == nil { tmp9 = ifn_647.Invoke_O__O(arg_648) } else { tmp9 = linked_646.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_645, arg_648) }; s__1660000092__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :170:1
func A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_fn__1660000097_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_fn__1660000097_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_fn__1660000097_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :170:1
func (t *A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_fn__1660000097_A) Ctor_O_O_O_I_O(c__tags, c__b__1660000094, c__config any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_tags = c__tags; t.F_b__1660000094 = c__b__1660000094; t.F_config = c__config; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :170:1
func (t *A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_fn__1660000097_A) Invoke_O__O(self any) any { { var i__1660000093__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1660000093__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var fi__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1660000093__1)); var opts__3 any = A_arbace_go_check_load_A_const_101.Invoke_O__O(fi__2); var tmp2 any; var root_577 any = A_arbace_go_check_load_A_const_102.GetRawRoot__O(); var linked_578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_577, A_arbace_go_check_load_file_included_QMARK__A_fn_class); var ifn_579 lang.IFn

	if linked_578 == nil { ifn_579 = lang.IFn_Cast(root_577) } else { ifn_579 = nil }; var arg_580 any = A_arbace_go_check_load_A_const_95.Invoke_O__O(fi__2); var arg_581 any = opts__3; var arg_582 any = t.F_config; var arg_583 any = t.F_tags; if linked_578 == nil { tmp2 = ifn_579.Invoke_O_O_O_O__O(arg_580, arg_581, arg_582, arg_583) } else { tmp2 = linked_578.(*A_arbace_go_check_load_file_included_QMARK__A).Invoke_O_O_O_O_O__O(root_577, arg_580, arg_581, arg_582, arg_583) }
//line :170:1
	if jrt.J2g_Truth(tmp2) { var root_584 any = A_arbace_go_check_load_A_const_31.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = t.F_b__1660000094; var arg_588 any; var root_589 any = A_arbace_go_check_load_A_const_103.GetRawRoot__O(); var linked_590 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_589, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_591 lang.IFn


		if linked_590 == nil { ifn_591 = lang.IFn_Cast(root_589) } else { ifn_591 = nil }; var arg_592 any = fi__2; var arg_593 any = A_arbace_go_check_load_A_const_101; var arg_594 any = opts__3; if linked_590 == nil { arg_588 = ifn_591.Invoke_O_O_O__O(arg_592, arg_593, arg_594) } else { arg_588 = linked_590.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_589, arg_592, arg_593, arg_594) }
//line :170:1
		if linked_585 == nil { ifn_586.Invoke_O_O__O(arg_587, arg_588) } else { linked_585.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_584, arg_587, arg_588) }; i__1660000093__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1660000093__1); continue L1 } else { i__1660000093__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1660000093__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_go_check_load_package_source_fn__1660000101_A_New() *A_arbace_go_check_load_package_source_fn__1660000101_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_source_fn__1660000101_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_go_check_load_package_source_fn__1660000101_A) Ctor() {}
//line :179:1
func (t *A_arbace_go_check_load_package_source_fn__1660000101_A) Invoke_O_O__O(self, p1__1660000088_SHARP___1 any) any { var tmp1 any; var and__1927000168__auto____2 any; var root_662 any = A_arbace_go_check_load_A_const_109.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = p1__1660000088_SHARP___1; if linked_663 == nil { and__1927000168__auto____2 = ifn_664.Invoke_O__O(arg_665) } else { and__1927000168__auto____2 = linked_663.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_662, arg_665) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 any = A_arbace_go_check_load_A_const_110; var tmp3 any; var root_666 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_666, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_668 lang.IFn; if linked_667 == nil { ifn_668 = lang.IFn_Cast(root_666) } else { ifn_668 = nil }; var arg_669 any = p1__1660000088_SHARP___1; if linked_667 == nil { tmp3 = ifn_668.Invoke_O__O(arg_669) } else { tmp3 = linked_667.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_666, arg_669) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3)).Ref() } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) { var tmp4 *lang.Keyword = A_arbace_go_check_load_A_const_111; return tmp4.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(p1__1660000088_SHARP___1)) } else { return nil } }

func A_arbace_go_check_load_package_files_A_New() *A_arbace_go_check_load_package_files_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_go_check_load_package_files_A) Ctor() {}
//line :181:1
func (t *A_arbace_go_check_load_package_files_A) Invoke_O_O_O__O(self, root__0, sub__1 any) any { var d__3 any = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_go_check_load_A_const_87.Invoke_O__O(root__0), nil, sub__1))); var root_683 any = A_arbace_go_check_load_A_const_113.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_685 lang.IFn; if









	linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any; var fnbody__689 any = A_arbace_go_check_load_package_files_fn__1660000105_A_New(); var tmp1 *jrt.Class; var fncls__688 *jrt.Class = A_arbace_go_check_load_package_files_fn__1660000105_A_fn_class; if fncls__688 == nil { var fncls__688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_go_check_load_package_files_fn__1660000105_A_fn_class = fncls__688d; tmp1 = fncls__688d } else { tmp1 = fncls__688 }; arg_686 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__689, tmp1, nil); var arg_687 any; var root_690 any = A_arbace_go_check_load_A_const_79.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_692 lang.IFn; if /*line :187:1*/ linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any; var fnbody__729 any = A_arbace_go_check_load_package_files_fn__1660000107_A_New(); var tmp2 *jrt.Class; var fncls__728 *jrt.Class = A_arbace_go_check_load_package_files_fn__1660000107_A_fn_class; if fncls__728 == nil { var fncls__728d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, nil); A_arbace_go_check_load_package_files_fn__1660000107_A_fn_class = fncls__728d; tmp2 = fncls__728d } else { tmp2 = fncls__728 }; arg_693 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__729, tmp2, nil); var arg_694 any; var root_730 any = A_arbace_go_check_load_A_const_79.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_732 lang.IFn; if /*line :186:1*/ linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any; var fnbody__741 any = A_arbace_go_check_load_package_files_fn__1660000111_A_New(); var tmp3 *jrt.Class; var fncls__740 *jrt.Class = A_arbace_go_check_load_package_files_fn__1660000111_A_fn_class; if fncls__740 == nil { var fncls__740d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_37, false, nil); A_arbace_go_check_load_package_files_fn__1660000111_A_fn_class = fncls__740d; tmp3 = fncls__740d } else { tmp3 = fncls__740 }; arg_733 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__741, tmp3, nil); var arg_734 any; var root_742 any = A_arbace_go_check_load_A_const_117.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_744 lang.IFn; if /*line :185:1*/ linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = d__3; if linked_743 == nil { arg_734 = ifn_744.Invoke_O__O(arg_745) } else { arg_734 = linked_743.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_742, arg_745) }; if
	linked_731 == nil { arg_694 = ifn_732.Invoke_O_O__O(arg_733, arg_734) } else { arg_694 = linked_731.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_730, arg_733, arg_734) }; if
	linked_691 == nil { arg_687 = ifn_692.Invoke_O_O__O(arg_693, arg_694) } else { arg_687 = linked_691.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_690, arg_693, arg_694) }; if



	linked_684 == nil { return ifn_685.Invoke_O_O__O(arg_686, arg_687) } else { return linked_684.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_683, arg_686, arg_687) } }
//line :186:1
func A_arbace_go_check_load_package_files_fn__1660000111_A_New() *A_arbace_go_check_load_package_files_fn__1660000111_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_fn__1660000111_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_go_check_load_package_files_fn__1660000111_A) Ctor() {}
//line :186:1
func (t *A_arbace_go_check_load_package_files_fn__1660000111_A) Invoke_O_O__O(self, f__1 any) any { var and__1927000168__auto____2 bool = jrt.File_Cast(f__1).IsFile__Z(); if and__1927000168__auto____2 { var root_735 any = A_arbace_go_check_load_A_const_116.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = jrt.File_Cast(f__1).GetName__String().Ref(); var arg_739 any = Lit_33; if linked_736 == nil { return ifn_737.Invoke_O_O__O(arg_738, arg_739) } else { return linked_736.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_735, arg_738, arg_739) } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }
func A_arbace_go_check_load_package_files_fn__1660000107_A_New() *A_arbace_go_check_load_package_files_fn__1660000107_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_fn__1660000107_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_go_check_load_package_files_fn__1660000107_A) Ctor() {}
//line :187:1
func (t *A_arbace_go_check_load_package_files_fn__1660000107_A) Invoke_O_O__O(self, f__1 any) any { var r__2 any = lang.IFn_Cast(A_arbace_go_check_load_A_const_114.GetRawRoot__O()).Invoke_O__O(f__1); var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var l__5 any; var root_699 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_701 lang.IFn

	if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any; var root_703 any = A_arbace_go_check_load_A_const_57.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any; var fnbody__718 any = A_arbace_go_check_load_package_files_fn__1660000107_fn__1660000108_A_New(); var tmp2 *jrt.Class; var fncls__717 *jrt.Class = A_arbace_go_check_load_package_files_fn__1660000107_fn__1660000108_A_fn_class; if fncls__717 == nil { var fncls__717d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_38, false, nil); A_arbace_go_check_load_package_files_fn__1660000107_fn__1660000108_A_fn_class = fncls__717d; tmp2 = fncls__717d } else { tmp2 = fncls__717 }; arg_706 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__718, tmp2, nil); var arg_707 any; var root_719 any = A_arbace_go_check_load_A_const_115.GetRawRoot__O(); var linked_720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_719, aot_arbace_core.A_arbace_core_line_seq_A_fn_class); var ifn_721 lang.IFn; if linked_720 == nil { ifn_721 = lang.IFn_Cast(root_719) } else { ifn_721 = nil }; var arg_722 any = r__2; if linked_720 == nil { arg_707 = ifn_721.Invoke_O__O(arg_722) } else { arg_707 = linked_720.(*aot_arbace_core.A_arbace_core_line_seq_A).Invoke_O_O__O(root_719, arg_722) }; if linked_704 == nil { arg_702 = ifn_705.Invoke_O_O__O(arg_706, arg_707) } else { arg_702 = linked_704.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_703, arg_706, arg_707) }; if linked_700 == nil { l__5 = ifn_701.Invoke_O__O(arg_702) } else { l__5 = linked_700.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_699, arg_702) }
//line :187:1
	var and__1927000168__auto____6 any = l__5


	if jrt.J2g_Truth(and__1927000168__auto____6) { var root_723 any = A_arbace_go_check_load_A_const_64.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any = l__5; var arg_727 any = Lit_39; if linked_724 == nil { tmp1 = ifn_725.Invoke_O_O__O(arg_726, arg_727) } else { tmp1 = linked_724.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_723, arg_726, arg_727) } } else { tmp1 = and__1927000168__auto____6 } }; return nil }(); /*line :188:1*/jrt.Reader_Cast(r__2).Close__V(); if /*line :187:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }

func A_arbace_go_check_load_package_files_fn__1660000107_fn__1660000108_A_New() *A_arbace_go_check_load_package_files_fn__1660000107_fn__1660000108_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_fn__1660000107_fn__1660000108_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_go_check_load_package_files_fn__1660000107_fn__1660000108_A) Ctor() {}
//line :189:1
func (t *A_arbace_go_check_load_package_files_fn__1660000107_fn__1660000108_A) Invoke_O_O__O(self, p1__1660000104_SHARP___1 any) any { var or__1927000174__auto____2 any; var root_708 any = A_arbace_go_check_load_A_const_58.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_string.A_arbace_string_blank_QMARK__A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any = p1__1660000104_SHARP___1; if linked_709 == nil { or__1927000174__auto____2 = ifn_710.Invoke_O__O(arg_711) } else { or__1927000174__auto____2 = linked_709.(*aot_arbace_string.A_arbace_string_blank_QMARK__A).Invoke_O_O__O(root_708, arg_711) }; if jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var root_712 any = A_arbace_go_check_load_A_const_64.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = p1__1660000104_SHARP___1; var arg_716 any = Lit_40; if linked_713 == nil { return ifn_714.Invoke_O_O__O(arg_715, arg_716) } else { return linked_713.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_712, arg_715, arg_716) } } }

func A_arbace_go_check_load_package_files_fn__1660000105_A_New() *A_arbace_go_check_load_package_files_fn__1660000105_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_files_fn__1660000105_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_go_check_load_package_files_fn__1660000105_A) Ctor() {}
//line :191:1
func (t *A_arbace_go_check_load_package_files_fn__1660000105_A) Invoke_O_O__O(self, f__1 any) any { return jrt.File_Cast(f__1).GetPath__String().Ref() }

func A_arbace_go_check_load_package_path_of_A_New() *A_arbace_go_check_load_package_path_of_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_path_of_A{}; t.Ctor(); return t }
//line :193:1
func (t *A_arbace_go_check_load_package_path_of_A) Ctor() {}
//line :193:1
func (t *A_arbace_go_check_load_package_path_of_A) Invoke_O_O__O(self, pf__0 any) any { var fs__2 any; var root_746 any = A_arbace_go_check_load_A_const_89.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, A_arbace_go_check_load_read_forms_A_fn_class); var ifn_748 lang.IFn; if


	linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = pf__0; if linked_747 == nil { fs__2 = ifn_748.Invoke_O__O(arg_749) } else { fs__2 = linked_747.(*A_arbace_go_check_load_read_forms_A).Invoke_O_O__O(root_746, arg_749) }; var gp__3 any; var root_750 any = /*line :193:1*/A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_752 lang.IFn; if



	linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any; var root_754 any = A_arbace_go_check_load_A_const_79.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any; var fnbody__768 any = A_arbace_go_check_load_package_path_of_fn__1660000115_A_New(); var tmp1 *jrt.Class; var fncls__767 *jrt.Class = A_arbace_go_check_load_package_path_of_fn__1660000115_A_fn_class; if fncls__767 == nil { var fncls__767d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, nil); A_arbace_go_check_load_package_path_of_fn__1660000115_A_fn_class = fncls__767d; tmp1 = fncls__767d } else { tmp1 = fncls__767 }; arg_757 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__768, tmp1, nil); var arg_758 any = fs__2; if linked_755 == nil { arg_753 = ifn_756.Invoke_O_O__O(arg_757, arg_758) } else { arg_753 = linked_755.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_754, arg_757, arg_758) }; if linked_751 == nil { gp__3 = ifn_752.Invoke_O__O(arg_753) } else { gp__3 = linked_751.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_750, arg_753) }; var tmp2 /*line :198:1*/*lang.Keyword = A_arbace_go_check_load_A_const_104; var tmp3 any; var root_769 any = A_arbace_go_check_load_A_const_119.GetRawRoot__O(); var linked_770 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_769, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_771 lang.IFn; if linked_770 == nil { ifn_771 = lang.IFn_Cast(root_769) } else { ifn_771 = nil }; var arg_772 any = A_arbace_go_check_load_A_const_120.GetRawRoot__O(); var arg_773 any; var root_774 any = A_arbace_go_check_load_A_const_121.GetRawRoot__O(); var linked_775 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_774, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_776 lang.IFn; if linked_775 == nil { ifn_776 = lang.IFn_Cast(root_774) } else { ifn_776 = nil }; var arg_777 any = gp__3; if linked_775 == nil { arg_773 = ifn_776.Invoke_O__O(arg_777) } else { arg_773 = linked_775.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_774, arg_777) }; if linked_770 == nil { tmp3 = ifn_771.Invoke_O_O__O(arg_772, arg_773) } else { tmp3 = linked_770.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_769, arg_772, arg_773) }; return tmp2.Invoke_O__O(tmp3) }
//line :197:1
func A_arbace_go_check_load_package_path_of_fn__1660000115_A_New() *A_arbace_go_check_load_package_path_of_fn__1660000115_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_package_path_of_fn__1660000115_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_go_check_load_package_path_of_fn__1660000115_A) Ctor() {}
//line :197:1
func (t *A_arbace_go_check_load_package_path_of_fn__1660000115_A) Invoke_O_O__O(self, p1__1660000114_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_759 any = A_arbace_go_check_load_A_const_109.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_761 lang.IFn; if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any = p1__1660000114_SHARP___1; if linked_760 == nil { and__1927000168__auto____2 = ifn_761.Invoke_O__O(arg_762) } else { and__1927000168__auto____2 = linked_760.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_759, arg_762) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_go_check_load_A_const_118; var tmp2 any; var root_763 any = A_arbace_go_check_load_A_const_20.GetRawRoot__O(); var linked_764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_763, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_765 lang.IFn; if linked_764 == nil { ifn_765 = lang.IFn_Cast(root_763) } else { ifn_765 = nil }; var arg_766 any = p1__1660000114_SHARP___1; if linked_764 == nil { tmp2 = ifn_765.Invoke_O__O(arg_766) } else { tmp2 = linked_764.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_763, arg_766) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }















































































































type A_arbace_go_check_load_A struct{ jrt.Object }

var A_arbace_go_check_load_A_const_pool *jrt.RefArray

var A_arbace_go_check_load_A_const_0 *lang.Var

var A_arbace_go_check_load_A_const_1 any

var A_arbace_go_check_load_A_const_2 *lang.Var

var A_arbace_go_check_load_A_const_3 any

var A_arbace_go_check_load_A_const_4 any

var A_arbace_go_check_load_A_const_5 any

var A_arbace_go_check_load_A_const_6 *lang.Var

var A_arbace_go_check_load_A_const_7 *lang.Var

var A_arbace_go_check_load_A_const_8 *lang.Var

var A_arbace_go_check_load_A_const_9 *lang.Var

var A_arbace_go_check_load_A_const_10 any

var A_arbace_go_check_load_A_const_11 *lang.Var

var A_arbace_go_check_load_A_const_12 *lang.Var

var A_arbace_go_check_load_A_const_13 *lang.Var

var A_arbace_go_check_load_A_const_14 any

var A_arbace_go_check_load_A_const_15 *lang.Var

var A_arbace_go_check_load_A_const_16 any

var A_arbace_go_check_load_A_const_17 *lang.Var

var A_arbace_go_check_load_A_const_18 *lang.Var

var A_arbace_go_check_load_A_const_19 *lang.Var

var A_arbace_go_check_load_A_const_20 *lang.Var

var A_arbace_go_check_load_A_const_21 *lang.Keyword

var A_arbace_go_check_load_A_const_22 *lang.Keyword

var A_arbace_go_check_load_A_const_23 *lang.Keyword

var A_arbace_go_check_load_A_const_24 *lang.Keyword

var A_arbace_go_check_load_A_const_25 *lang.Keyword

var A_arbace_go_check_load_A_const_26 *lang.Var

var A_arbace_go_check_load_A_const_27 *lang.Var

var A_arbace_go_check_load_A_const_28 *lang.Var

var A_arbace_go_check_load_A_const_29 *lang.Var

var A_arbace_go_check_load_A_const_30 *lang.Var

var A_arbace_go_check_load_A_const_31 *lang.Var

var A_arbace_go_check_load_A_const_32 *lang.Var

var A_arbace_go_check_load_A_const_33 *lang.Var

var A_arbace_go_check_load_A_const_34 *lang.Var

var A_arbace_go_check_load_A_const_35 *lang.Var

var A_arbace_go_check_load_A_const_36 *lang.Var

var A_arbace_go_check_load_A_const_37 *lang.Var

var A_arbace_go_check_load_A_const_38 any

var A_arbace_go_check_load_A_const_39 any

var A_arbace_go_check_load_A_const_40 *lang.Var

var A_arbace_go_check_load_A_const_41 any

var A_arbace_go_check_load_A_const_42 any

var A_arbace_go_check_load_A_const_43 any

var A_arbace_go_check_load_A_const_44 any

var A_arbace_go_check_load_A_const_45 *lang.Var

var A_arbace_go_check_load_A_const_46 any

var A_arbace_go_check_load_A_const_47 *lang.Var

var A_arbace_go_check_load_A_const_48 *lang.Var

var A_arbace_go_check_load_A_const_49 any

var A_arbace_go_check_load_A_const_50 *lang.Var

var A_arbace_go_check_load_A_const_51 *lang.Var

var A_arbace_go_check_load_A_const_52 any

var A_arbace_go_check_load_A_const_53 *lang.Var

var A_arbace_go_check_load_A_const_54 any

var A_arbace_go_check_load_A_const_55 *lang.Var

var A_arbace_go_check_load_A_const_56 *lang.Var

var A_arbace_go_check_load_A_const_57 *lang.Var

var A_arbace_go_check_load_A_const_58 *lang.Var

var A_arbace_go_check_load_A_const_59 *lang.Var

var A_arbace_go_check_load_A_const_60 any

var A_arbace_go_check_load_A_const_61 any

var A_arbace_go_check_load_A_const_62 *lang.Var

var A_arbace_go_check_load_A_const_63 *lang.Var

var A_arbace_go_check_load_A_const_64 *lang.Var

var A_arbace_go_check_load_A_const_65 any

var A_arbace_go_check_load_A_const_66 *lang.Var

var A_arbace_go_check_load_A_const_67 any

var A_arbace_go_check_load_A_const_68 *lang.Var

var A_arbace_go_check_load_A_const_69 any

var A_arbace_go_check_load_A_const_70 *lang.Var

var A_arbace_go_check_load_A_const_71 *lang.Var

var A_arbace_go_check_load_A_const_72 *lang.Var

var A_arbace_go_check_load_A_const_73 *lang.Var

var A_arbace_go_check_load_A_const_74 *lang.Var

var A_arbace_go_check_load_A_const_75 *lang.Keyword

var A_arbace_go_check_load_A_const_76 *lang.Var

var A_arbace_go_check_load_A_const_77 *lang.Var

var A_arbace_go_check_load_A_const_78 *lang.Keyword

var A_arbace_go_check_load_A_const_79 *lang.Var

var A_arbace_go_check_load_A_const_80 *lang.Var

var A_arbace_go_check_load_A_const_81 *lang.Var

var A_arbace_go_check_load_A_const_82 *lang.Var

var A_arbace_go_check_load_A_const_83 any

var A_arbace_go_check_load_A_const_84 *lang.Var

var A_arbace_go_check_load_A_const_85 *lang.Var

var A_arbace_go_check_load_A_const_86 *lang.Keyword

var A_arbace_go_check_load_A_const_87 *lang.Keyword

var A_arbace_go_check_load_A_const_88 *lang.Var

var A_arbace_go_check_load_A_const_89 *lang.Var

var A_arbace_go_check_load_A_const_90 *lang.Var

var A_arbace_go_check_load_A_const_91 *lang.Var

var A_arbace_go_check_load_A_const_92 *lang.Var

var A_arbace_go_check_load_A_const_93 *lang.Var

var A_arbace_go_check_load_A_const_94 *lang.Keyword

var A_arbace_go_check_load_A_const_95 *lang.Keyword

var A_arbace_go_check_load_A_const_96 *lang.Keyword

var A_arbace_go_check_load_A_const_97 *lang.Var

var A_arbace_go_check_load_A_const_98 any

var A_arbace_go_check_load_A_const_99 *lang.Keyword

var A_arbace_go_check_load_A_const_100 *lang.Var

var A_arbace_go_check_load_A_const_101 *lang.Keyword

var A_arbace_go_check_load_A_const_102 *lang.Var

var A_arbace_go_check_load_A_const_103 *lang.Var

var A_arbace_go_check_load_A_const_104 *lang.Keyword

var A_arbace_go_check_load_A_const_105 *lang.Var

var A_arbace_go_check_load_A_const_106 *lang.Keyword

var A_arbace_go_check_load_A_const_107 *lang.Keyword

var A_arbace_go_check_load_A_const_108 *lang.Keyword

var A_arbace_go_check_load_A_const_109 *lang.Var

var A_arbace_go_check_load_A_const_110 any

var A_arbace_go_check_load_A_const_111 *lang.Keyword

var A_arbace_go_check_load_A_const_112 *lang.Var

var A_arbace_go_check_load_A_const_113 *lang.Var

var A_arbace_go_check_load_A_const_114 *lang.Var

var A_arbace_go_check_load_A_const_115 *lang.Var

var A_arbace_go_check_load_A_const_116 *lang.Var

var A_arbace_go_check_load_A_const_117 *lang.Var

var A_arbace_go_check_load_A_const_118 any

var A_arbace_go_check_load_A_const_119 *lang.Var

var A_arbace_go_check_load_A_const_120 *lang.Var

var A_arbace_go_check_load_A_const_121 *lang.Var

var A_arbace_go_check_load_A_init jrt.ClassInit

func A_arbace_go_check_load_A_Init() { if !A_arbace_go_check_load_A_init.Done() { A_arbace_go_check_load_A_init.Run(A_arbace_go_check_load_A_clinit) } }

func A_arbace_go_check_load_A_clinit() { A_arbace_go_check_load_A_clinit_p0(); A_arbace_go_check_load_A_clinit_p1(); A_arbace_go_check_load_A_clinit_p2(); A_arbace_go_check_load_A_clinit_p3(); A_arbace_go_check_load_A_clinit_p4(); A_arbace_go_check_load_A_clinit_p5(); A_arbace_go_check_load_A_clinit_p6(); A_arbace_go_check_load_A_clinit_p7(); A_arbace_go_check_load_A_clinit_p8(); A_arbace_go_check_load_A_clinit_p9() }

func A_arbace_go_check_load_A_clinit_p0() { jrt.StartCheck(); A_arbace_go_check_load_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 152); A_arbace_go_check_load_A_const_0 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[30]); A_arbace_go_check_load_A_const_1 = A_arbace_go_check_load_A_const_pool.A[31]; A_arbace_go_check_load_A_const_2 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[32]); A_arbace_go_check_load_A_const_3 = A_arbace_go_check_load_A_const_pool.A[33]; A_arbace_go_check_load_A_const_4 = A_arbace_go_check_load_A_const_pool.A[34]; A_arbace_go_check_load_A_const_5 = A_arbace_go_check_load_A_const_pool.A[35]; A_arbace_go_check_load_A_const_6 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[36]); A_arbace_go_check_load_A_const_7 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[37]); A_arbace_go_check_load_A_const_8 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[38]); A_arbace_go_check_load_A_const_9 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[39]); A_arbace_go_check_load_A_const_10 = A_arbace_go_check_load_A_const_pool.A[40]; A_arbace_go_check_load_A_const_11 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[41]) }

func A_arbace_go_check_load_A_clinit_p1() { A_arbace_go_check_load_A_const_12 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[42]); A_arbace_go_check_load_A_const_13 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[43]); A_arbace_go_check_load_A_const_14 = A_arbace_go_check_load_A_const_pool.A[44]; A_arbace_go_check_load_A_const_15 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[45]); A_arbace_go_check_load_A_const_16 = A_arbace_go_check_load_A_const_pool.A[46]; A_arbace_go_check_load_A_const_17 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[47]); A_arbace_go_check_load_A_const_18 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[48]); A_arbace_go_check_load_A_const_19 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[49]); A_arbace_go_check_load_A_const_20 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[50]); A_arbace_go_check_load_A_const_21 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[51]); A_arbace_go_check_load_A_const_22 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[52]); A_arbace_go_check_load_A_const_23 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[53]) }

func A_arbace_go_check_load_A_clinit_p2() { A_arbace_go_check_load_A_const_24 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[54]); A_arbace_go_check_load_A_const_25 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[55]); A_arbace_go_check_load_A_const_26 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[56]); A_arbace_go_check_load_A_const_27 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[57]); A_arbace_go_check_load_A_const_28 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[58]); A_arbace_go_check_load_A_const_29 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[59]); A_arbace_go_check_load_A_const_30 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[60]); A_arbace_go_check_load_A_const_31 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[61]); A_arbace_go_check_load_A_const_32 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[62]); A_arbace_go_check_load_A_const_33 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[63]); A_arbace_go_check_load_A_const_34 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[64]); A_arbace_go_check_load_A_const_35 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[65]) }

func A_arbace_go_check_load_A_clinit_p3() { A_arbace_go_check_load_A_const_36 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[66]); A_arbace_go_check_load_A_const_37 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[67]); A_arbace_go_check_load_A_const_38 = A_arbace_go_check_load_A_const_pool.A[68]; A_arbace_go_check_load_A_const_39 = A_arbace_go_check_load_A_const_pool.A[69]; A_arbace_go_check_load_A_const_40 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[70]); A_arbace_go_check_load_A_const_41 = A_arbace_go_check_load_A_const_pool.A[71]; A_arbace_go_check_load_A_const_42 = A_arbace_go_check_load_A_const_pool.A[72]; A_arbace_go_check_load_A_const_43 = A_arbace_go_check_load_A_const_pool.A[73]; A_arbace_go_check_load_A_const_44 = A_arbace_go_check_load_A_const_pool.A[74]; A_arbace_go_check_load_A_const_45 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[75]); A_arbace_go_check_load_A_const_46 = A_arbace_go_check_load_A_const_pool.A[76]; A_arbace_go_check_load_A_const_47 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[77]); A_arbace_go_check_load_A_const_48 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[78]); A_arbace_go_check_load_A_const_49 = A_arbace_go_check_load_A_const_pool.A[79] }

func A_arbace_go_check_load_A_clinit_p4() { A_arbace_go_check_load_A_const_50 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[80]); A_arbace_go_check_load_A_const_51 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[81]); A_arbace_go_check_load_A_const_52 = A_arbace_go_check_load_A_const_pool.A[82]; A_arbace_go_check_load_A_const_53 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[83]); A_arbace_go_check_load_A_const_54 = A_arbace_go_check_load_A_const_pool.A[84]; A_arbace_go_check_load_A_const_55 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[85]); A_arbace_go_check_load_A_const_56 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[86]); A_arbace_go_check_load_A_const_57 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[87]); A_arbace_go_check_load_A_const_58 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[88]); A_arbace_go_check_load_A_const_59 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[89]); A_arbace_go_check_load_A_const_60 = A_arbace_go_check_load_A_const_pool.A[90]; A_arbace_go_check_load_A_const_61 = A_arbace_go_check_load_A_const_pool.A[91]; A_arbace_go_check_load_A_const_62 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[92]) }

func A_arbace_go_check_load_A_clinit_p5() { A_arbace_go_check_load_A_const_63 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[93]); A_arbace_go_check_load_A_const_64 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[94]); A_arbace_go_check_load_A_const_65 = A_arbace_go_check_load_A_const_pool.A[95]; A_arbace_go_check_load_A_const_66 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[96]); A_arbace_go_check_load_A_const_67 = A_arbace_go_check_load_A_const_pool.A[97]; A_arbace_go_check_load_A_const_68 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[98]); A_arbace_go_check_load_A_const_69 = A_arbace_go_check_load_A_const_pool.A[99]; A_arbace_go_check_load_A_const_70 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[100]); A_arbace_go_check_load_A_const_71 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[101]); A_arbace_go_check_load_A_const_72 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[102]); A_arbace_go_check_load_A_const_73 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[103]); A_arbace_go_check_load_A_const_74 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[104]) }

func A_arbace_go_check_load_A_clinit_p6() { A_arbace_go_check_load_A_const_75 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[105]); A_arbace_go_check_load_A_const_76 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[106]); A_arbace_go_check_load_A_const_77 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[107]); A_arbace_go_check_load_A_const_78 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[108]); A_arbace_go_check_load_A_const_79 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[109]); A_arbace_go_check_load_A_const_80 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[110]); A_arbace_go_check_load_A_const_81 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[111]); A_arbace_go_check_load_A_const_82 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[112]); A_arbace_go_check_load_A_const_83 = A_arbace_go_check_load_A_const_pool.A[113]; A_arbace_go_check_load_A_const_84 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[114]); A_arbace_go_check_load_A_const_85 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[115]); A_arbace_go_check_load_A_const_86 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[116]) }

func A_arbace_go_check_load_A_clinit_p7() { A_arbace_go_check_load_A_const_87 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[117]); A_arbace_go_check_load_A_const_88 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[118]); A_arbace_go_check_load_A_const_89 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[119]); A_arbace_go_check_load_A_const_90 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[120]); A_arbace_go_check_load_A_const_91 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[121]); A_arbace_go_check_load_A_const_92 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[122]); A_arbace_go_check_load_A_const_93 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[123]); A_arbace_go_check_load_A_const_94 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[124]); A_arbace_go_check_load_A_const_95 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[125]); A_arbace_go_check_load_A_const_96 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[126]); A_arbace_go_check_load_A_const_97 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[127]); A_arbace_go_check_load_A_const_98 = A_arbace_go_check_load_A_const_pool.A[128] }

func A_arbace_go_check_load_A_clinit_p8() { A_arbace_go_check_load_A_const_99 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[129]); A_arbace_go_check_load_A_const_100 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[130]); A_arbace_go_check_load_A_const_101 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[131]); A_arbace_go_check_load_A_const_102 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[132]); A_arbace_go_check_load_A_const_103 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[133]); A_arbace_go_check_load_A_const_104 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[134]); A_arbace_go_check_load_A_const_105 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[135]); A_arbace_go_check_load_A_const_106 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[136]); A_arbace_go_check_load_A_const_107 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[137]); A_arbace_go_check_load_A_const_108 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[138]); A_arbace_go_check_load_A_const_109 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[139]); A_arbace_go_check_load_A_const_110 = A_arbace_go_check_load_A_const_pool.A[140] }

func A_arbace_go_check_load_A_clinit_p9() { A_arbace_go_check_load_A_const_111 = lang.Keyword_Cast(A_arbace_go_check_load_A_const_pool.A[141]); A_arbace_go_check_load_A_const_112 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[142]); A_arbace_go_check_load_A_const_113 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[143]); A_arbace_go_check_load_A_const_114 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[144]); A_arbace_go_check_load_A_const_115 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[145]); A_arbace_go_check_load_A_const_116 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[146]); A_arbace_go_check_load_A_const_117 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[147]); A_arbace_go_check_load_A_const_118 = A_arbace_go_check_load_A_const_pool.A[148]; A_arbace_go_check_load_A_const_119 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[149]); A_arbace_go_check_load_A_const_120 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[150]); A_arbace_go_check_load_A_const_121 = lang.Var_Cast(A_arbace_go_check_load_A_const_pool.A[151]) }

func A_arbace_go_check_load_A_New() *A_arbace_go_check_load_A { A_arbace_go_check_load_A_Init(); t := &A_arbace_go_check_load_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_load_A) Ctor() {}

func (t *A_arbace_go_check_load_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_load_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_load_A_class }

func (t *A_arbace_go_check_load_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_load_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_load_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_load_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_load_A); return ok }

func A_arbace_go_check_load_A_Cast(x any) *A_arbace_go_check_load_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_load_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_load_A_class)) }; return v }



type A_arbace_go_check_load_clear_cache_BANG__A struct{ j2g_header uint64 }

var A_arbace_go_check_load_clear_cache_BANG__A_fn_class *jrt.Class



type A_arbace_go_check_load_collect_package_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_collect_package_A_fn_class *jrt.Class



type A_arbace_go_check_load_collect_package_fn__1660000085_A struct{ j2g_header uint64; F_root, F_base any }

var A_arbace_go_check_load_collect_package_fn__1660000085_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval1660000004_A struct{ jrt.Object }

func A_arbace_go_check_load_eval1660000004_A_New() *A_arbace_go_check_load_eval1660000004_A { t := &A_arbace_go_check_load_eval1660000004_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_load_eval1660000004_A) Ctor() {}

func (t *A_arbace_go_check_load_eval1660000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_load_eval1660000004_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_load_eval1660000004_A_class }

func (t *A_arbace_go_check_load_eval1660000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_load_eval1660000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_load_eval1660000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_load_eval1660000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_load_eval1660000004_A); return ok }

func A_arbace_go_check_load_eval1660000004_A_Cast(x any) *A_arbace_go_check_load_eval1660000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_load_eval1660000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_load_eval1660000004_A_class)) }; return v }



type A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval1660000008_A struct{ jrt.Object }

func A_arbace_go_check_load_eval1660000008_A_New() *A_arbace_go_check_load_eval1660000008_A { t := &A_arbace_go_check_load_eval1660000008_A{}; t.Ctor(); return t }

func (t *A_arbace_go_check_load_eval1660000008_A) Ctor() {}

func (t *A_arbace_go_check_load_eval1660000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_go_check_load_eval1660000008_A) GetClass__Class() *jrt.Class { return A_arbace_go_check_load_eval1660000008_A_class }

func (t *A_arbace_go_check_load_eval1660000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_go_check_load_eval1660000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_go_check_load_eval1660000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_go_check_load_eval1660000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_go_check_load_eval1660000008_A); return ok }

func A_arbace_go_check_load_eval1660000008_A_Cast(x any) *A_arbace_go_check_load_eval1660000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_go_check_load_eval1660000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_go_check_load_eval1660000008_A_class)) }; return v }



type A_arbace_go_check_load_eval1660000008_fn__1660000009_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_eval1660000008_fn__1660000009_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_eval_build_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_and_expr__1660000052_A struct{ j2g_header uint64; F_peek_STAR_, F_not_expr, F_next_STAR_ any }

var A_arbace_go_check_load_eval_build_and_expr__1660000052_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_atom_STAR___1660000056_A struct{ j2g_header uint64; F_or_expr, F_tags, F_next_STAR_ any }

var A_arbace_go_check_load_eval_build_atom_STAR___1660000056_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_next_STAR___1660000048_A struct{ j2g_header uint64; F_toks, F_pos any }

var A_arbace_go_check_load_eval_build_next_STAR___1660000048_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_not_expr__1660000054_A struct{ j2g_header uint64; F_peek_STAR_, F_atom_STAR_, F_next_STAR_ any }

var A_arbace_go_check_load_eval_build_not_expr__1660000054_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_or_expr__1660000050_A struct{ j2g_header uint64; F_peek_STAR_, F_and_expr, F_next_STAR_ any }

var A_arbace_go_check_load_eval_build_or_expr__1660000050_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_build_peek_STAR___1660000046_A struct{ j2g_header uint64; F_toks, F_pos any }

var A_arbace_go_check_load_eval_build_peek_STAR___1660000046_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_plus_build_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_eval_plus_build_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_plus_build_fn__1660000059_A struct{ j2g_header uint64; F_tags any }

var A_arbace_go_check_load_eval_plus_build_fn__1660000059_A_fn_class *jrt.Class



type A_arbace_go_check_load_eval_plus_build_fn__1660000059_fn__1660000060_A struct{ j2g_header uint64; F_tags any }

var A_arbace_go_check_load_eval_plus_build_fn__1660000059_fn__1660000060_A_fn_class *jrt.Class



type A_arbace_go_check_load_file_included_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_load_file_included_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_load_file_included_QMARK__fn__1660000073_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_file_included_QMARK__fn__1660000073_A_fn_class *jrt.Class



type A_arbace_go_check_load_file_included_QMARK__fn__1660000075_A struct{ j2g_header uint64; F_tags any }

var A_arbace_go_check_load_file_included_QMARK__fn__1660000075_A_fn_class *jrt.Class



type A_arbace_go_check_load_file_included_QMARK__fn__1660000077_A struct{ j2g_header uint64; F_tags any }

var A_arbace_go_check_load_file_included_QMARK__fn__1660000077_A_fn_class *jrt.Class



type A_arbace_go_check_load_file_included_QMARK__fn__1660000079_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_file_included_QMARK__fn__1660000079_A_fn_class *jrt.Class



type A_arbace_go_check_load_good_os_arch_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_go_check_load_good_os_arch_file_QMARK__A_fn_class *jrt.Class



type A_arbace_go_check_load_good_os_arch_file_QMARK__m__1660000066_A struct{ j2g_header uint64; F_goos, F_tags, F_goarch any }

var A_arbace_go_check_load_good_os_arch_file_QMARK__m__1660000066_A_fn_class *jrt.Class



type A_arbace_go_check_load_match_tag_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_match_tag_A_fn_class *jrt.Class



type A_arbace_go_check_load_ns__GT_file_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_ns__GT_file_A_fn_class *jrt.Class



type A_arbace_go_check_load_overlay_file_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_overlay_file_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_fn__1660000105_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_fn__1660000105_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_fn__1660000107_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_fn__1660000107_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_fn__1660000107_fn__1660000108_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_fn__1660000107_fn__1660000108_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_files_fn__1660000111_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_files_fn__1660000111_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_path_of_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_path_of_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_path_of_fn__1660000115_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_path_of_fn__1660000115_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_source_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_fn__1660000101_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_package_source_fn__1660000101_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_iter__1660000091__1660000095_A struct{ j2g_header uint64; F_tags, F_config any }

var A_arbace_go_check_load_package_source_iter__1660000091__1660000095_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_A struct{ j2g_header uint64; F_s__1660000092, F_tags, F_iter__1660000091, F_config any }

var A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_A_fn_class *jrt.Class



type A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_fn__1660000097_A struct{ j2g_header uint64; F_tags, F_b__1660000094, F_config any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_go_check_load_package_source_iter__1660000091__1660000095_fn__1660000096_fn__1660000097_A_fn_class *jrt.Class



type A_arbace_go_check_load_path__GT_ns_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_path__GT_ns_A_fn_class *jrt.Class



type A_arbace_go_check_load_path__GT_ns_fn__1660000013_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_fn_class *jrt.Class



type A_arbace_go_check_load_read_forms_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_read_forms_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tag_set_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_fn__1660000042_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tag_set_fn__1660000042_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A struct{ j2g_header uint64; F_s__1660000022, F_iter__1660000021 any }

var A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1660000024, F_c__1927001037__auto__ any }

var A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_A struct{ j2g_header uint64; F_s__1660000033, F_iter__1660000032 any }

var A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_A_fn_class *jrt.Class



type A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_fn__1660000038_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1660000035, F_c__1927001037__auto__ any }

var A_arbace_go_check_load_tag_set_iter__1660000032__1660000036_fn__1660000037_fn__1660000038_A_fn_class *jrt.Class



type A_arbace_go_check_load_tokens_A struct{ j2g_header uint64 }

var A_arbace_go_check_load_tokens_A_fn_class *jrt.Class
