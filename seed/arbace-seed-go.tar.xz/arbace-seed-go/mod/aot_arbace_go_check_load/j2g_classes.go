//line j2g_classes.ae:1
package aot_arbace_go_check_load

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_go_check_load_clear_cache_BANG__A_class, Name: "arbace.go.check.load$clear_cache_BANG_", Modifiers: 25, Simple: "clear_cache_BANG_", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_clear_cache_BANG__A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_collect_package_A_class, Name: "arbace.go.check.load$collect_package", Modifiers: 25, Simple: "collect_package", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_collect_package_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_collect_package_fn__1660000065_A_class, Name: "arbace.go.check.load$collect_package$fn__1660000065", Modifiers: 25, Simple: "fn__1660000065", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_collect_package_fn__1660000065_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_collect_package_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A_class, Name: "arbace.go.check.load$eval1660000004$loading__1927001464__auto____1660000005", Modifiers: 25, Simple: "loading__1927001464__auto____1660000005", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_eval1660000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_eval1660000008_fn__1660000009_A_class, Name: "arbace.go.check.load$eval1660000008$fn__1660000009", Modifiers: 25, Simple: "fn__1660000009", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_eval1660000008_fn__1660000009_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_eval1660000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_eval_build_A_class, Name: "arbace.go.check.load$eval_build", Modifiers: 25, Simple: "eval_build", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_eval_build_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_eval_build_and_expr__1660000051_A_class, Name: "arbace.go.check.load$eval_build$and_expr__1660000051", Modifiers: 25, Simple: "and_expr__1660000051", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_eval_build_and_expr__1660000051_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_eval_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A_class, Name: "arbace.go.check.load$eval_build$atom_STAR___1660000055", Modifiers: 25, Simple: "atom_STAR___1660000055", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_eval_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_eval_build_next_STAR___1660000047_A_class, Name: "arbace.go.check.load$eval_build$next_STAR___1660000047", Modifiers: 25, Simple: "next_STAR___1660000047", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_eval_build_next_STAR___1660000047_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_eval_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_eval_build_not_expr__1660000053_A_class, Name: "arbace.go.check.load$eval_build$not_expr__1660000053", Modifiers: 25, Simple: "not_expr__1660000053", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_eval_build_not_expr__1660000053_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_eval_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_eval_build_or_expr__1660000049_A_class, Name: "arbace.go.check.load$eval_build$or_expr__1660000049", Modifiers: 25, Simple: "or_expr__1660000049", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_eval_build_or_expr__1660000049_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_eval_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A_class, Name: "arbace.go.check.load$eval_build$peek_STAR___1660000045", Modifiers: 25, Simple: "peek_STAR___1660000045", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_eval_build_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_file_included_QMARK__A_class, Name: "arbace.go.check.load$file_included_QMARK_", Modifiers: 25, Simple: "file_included_QMARK_", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_file_included_QMARK__A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A_class, Name: "arbace.go.check.load$file_included_QMARK_$fn__1660000059", Modifiers: 25, Simple: "fn__1660000059", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_file_included_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_good_os_arch_file_QMARK__A_class, Name: "arbace.go.check.load$good_os_arch_file_QMARK_", Modifiers: 25, Simple: "good_os_arch_file_QMARK_", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_good_os_arch_file_QMARK__A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_ns__GT_file_A_class, Name: "arbace.go.check.load$ns__GT_file", Modifiers: 25, Simple: "ns__GT_file", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_ns__GT_file_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_overlay_file_A_class, Name: "arbace.go.check.load$overlay_file", Modifiers: 25, Simple: "overlay_file", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_overlay_file_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_package_files_A_class, Name: "arbace.go.check.load$package_files", Modifiers: 25, Simple: "package_files", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_package_files_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_package_files_fn__1660000085_A_class, Name: "arbace.go.check.load$package_files$fn__1660000085", Modifiers: 25, Simple: "fn__1660000085", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_package_files_fn__1660000085_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_package_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_package_files_fn__1660000087_A_class, Name: "arbace.go.check.load$package_files$fn__1660000087", Modifiers: 25, Simple: "fn__1660000087", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_package_files_fn__1660000087_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_package_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A_class, Name: "arbace.go.check.load$package_files$fn__1660000087$fn__1660000088", Modifiers: 25, Simple: "fn__1660000088", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_package_files_fn__1660000087_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_package_files_fn__1660000091_A_class, Name: "arbace.go.check.load$package_files$fn__1660000091", Modifiers: 25, Simple: "fn__1660000091", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_package_files_fn__1660000091_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_package_files_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_package_path_of_A_class, Name: "arbace.go.check.load$package_path_of", Modifiers: 25, Simple: "package_path_of", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_package_path_of_fn__1660000095_A_class, Name: "arbace.go.check.load$package_path_of$fn__1660000095", Modifiers: 25, Simple: "fn__1660000095", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_package_path_of_fn__1660000095_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_package_path_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_package_source_A_class, Name: "arbace.go.check.load$package_source", Modifiers: 25, Simple: "package_source", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_package_source_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class, &lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_package_source_fn__1660000081_A_class, Name: "arbace.go.check.load$package_source$fn__1660000081", Modifiers: 25, Simple: "fn__1660000081", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_package_source_fn__1660000081_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_package_source_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A_class, Name: "arbace.go.check.load$package_source$iter__1660000071__1660000075", Modifiers: 25, Simple: "iter__1660000071__1660000075", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_package_source_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A_class, Name: "arbace.go.check.load$package_source$iter__1660000071__1660000075$fn__1660000076", Modifiers: 25, Simple: "fn__1660000076", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A_class, Name: "arbace.go.check.load$package_source$iter__1660000071__1660000075$fn__1660000076$fn__1660000077", Modifiers: 25, Simple: "fn__1660000077", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_path__GT_ns_A_class, Name: "arbace.go.check.load$path__GT_ns", Modifiers: 25, Simple: "path__GT_ns", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_class, Name: "arbace.go.check.load$path__GT_ns$fn__1660000013", Modifiers: 25, Simple: "fn__1660000013", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_path__GT_ns_fn__1660000013_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_path__GT_ns_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_read_forms_A_class, Name: "arbace.go.check.load$read_forms", Modifiers: 25, Simple: "read_forms", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_read_forms_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_tag_set_A_class, Name: "arbace.go.check.load$tag_set", Modifiers: 25, Simple: "tag_set", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_tag_set_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_tag_set_fn__1660000041_A_class, Name: "arbace.go.check.load$tag_set$fn__1660000041", Modifiers: 25, Simple: "fn__1660000041", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_tag_set_fn__1660000041_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_tag_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_class, Name: "arbace.go.check.load$tag_set$iter__1660000021__1660000025", Modifiers: 25, Simple: "iter__1660000021__1660000025", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_tag_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_class, Name: "arbace.go.check.load$tag_set$iter__1660000021__1660000025$fn__1660000026", Modifiers: 25, Simple: "fn__1660000026", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_class, Name: "arbace.go.check.load$tag_set$iter__1660000021__1660000025$fn__1660000026$fn__1660000027", Modifiers: 25, Simple: "fn__1660000027", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A_class, Name: "arbace.go.check.load$tag_set$iter__1660000031__1660000035", Modifiers: 25, Simple: "iter__1660000031__1660000035", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_tag_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A_class, Name: "arbace.go.check.load$tag_set$iter__1660000031__1660000035$fn__1660000036", Modifiers: 25, Simple: "fn__1660000036", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A_class, Name: "arbace.go.check.load$tag_set$iter__1660000031__1660000035$fn__1660000036$fn__1660000037", Modifiers: 25, Simple: "fn__1660000037", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_go_check_load_tokens_A_class, Name: "arbace.go.check.load$tokens", Modifiers: 25, Simple: "tokens", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_tokens_A", Source: "load.ae", Declaring: &A_arbace_go_check_load_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_go_check_load_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_load_A_New()}; return nil }

var A_arbace_go_check_load_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_check_load_A_new}

var A_arbace_go_check_load_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.load", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_A"})

func init() { i := A_arbace_go_check_load_A_class.Info(); i.IsInstance = A_arbace_go_check_load_A_InstanceOf; i.Init = A_arbace_go_check_load_A_Init; i.Table = A_arbace_go_check_load_A_members }

var A_arbace_go_check_load_clear_cache_BANG__A_class *jrt.Class

var A_arbace_go_check_load_collect_package_A_class *jrt.Class

var A_arbace_go_check_load_collect_package_fn__1660000065_A_class *jrt.Class

func A_arbace_go_check_load_eval1660000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_load_eval1660000004_A_New()}; return nil }

var A_arbace_go_check_load_eval1660000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_check_load_eval1660000004_A_new}

var A_arbace_go_check_load_eval1660000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.load$eval1660000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_check_load_A_class, Simple: "eval1660000004", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_eval1660000004_A"})

func init() { i := A_arbace_go_check_load_eval1660000004_A_class.Info(); i.IsInstance = A_arbace_go_check_load_eval1660000004_A_InstanceOf; i.Table = A_arbace_go_check_load_eval1660000004_A_members }

var A_arbace_go_check_load_eval1660000004_loading__1927001464__auto____1660000005_A_class *jrt.Class

func A_arbace_go_check_load_eval1660000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_load_eval1660000008_A_New()}; return nil }

var A_arbace_go_check_load_eval1660000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_go_check_load_eval1660000008_A_new}

var A_arbace_go_check_load_eval1660000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.load$eval1660000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_go_check_load_A_class, Simple: "eval1660000008", Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load_eval1660000008_A"})

func init() { i := A_arbace_go_check_load_eval1660000008_A_class.Info(); i.IsInstance = A_arbace_go_check_load_eval1660000008_A_InstanceOf; i.Table = A_arbace_go_check_load_eval1660000008_A_members }

var A_arbace_go_check_load_eval1660000008_fn__1660000009_A_class *jrt.Class

var A_arbace_go_check_load_eval_build_A_class *jrt.Class

var A_arbace_go_check_load_eval_build_and_expr__1660000051_A_class *jrt.Class

var A_arbace_go_check_load_eval_build_atom_STAR___1660000055_A_class *jrt.Class

var A_arbace_go_check_load_eval_build_next_STAR___1660000047_A_class *jrt.Class

var A_arbace_go_check_load_eval_build_not_expr__1660000053_A_class *jrt.Class

var A_arbace_go_check_load_eval_build_or_expr__1660000049_A_class *jrt.Class

var A_arbace_go_check_load_eval_build_peek_STAR___1660000045_A_class *jrt.Class

var A_arbace_go_check_load_file_included_QMARK__A_class *jrt.Class

var A_arbace_go_check_load_file_included_QMARK__fn__1660000059_A_class *jrt.Class

var A_arbace_go_check_load_good_os_arch_file_QMARK__A_class *jrt.Class

var A_arbace_go_check_load_ns__GT_file_A_class *jrt.Class

var A_arbace_go_check_load_overlay_file_A_class *jrt.Class

var A_arbace_go_check_load_package_files_A_class *jrt.Class

var A_arbace_go_check_load_package_files_fn__1660000085_A_class *jrt.Class

var A_arbace_go_check_load_package_files_fn__1660000087_A_class *jrt.Class

var A_arbace_go_check_load_package_files_fn__1660000087_fn__1660000088_A_class *jrt.Class

var A_arbace_go_check_load_package_files_fn__1660000091_A_class *jrt.Class

var A_arbace_go_check_load_package_path_of_A_class *jrt.Class

var A_arbace_go_check_load_package_path_of_fn__1660000095_A_class *jrt.Class

var A_arbace_go_check_load_package_source_A_class *jrt.Class

var A_arbace_go_check_load_package_source_fn__1660000081_A_class *jrt.Class

var A_arbace_go_check_load_package_source_iter__1660000071__1660000075_A_class *jrt.Class

var A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_A_class *jrt.Class

var A_arbace_go_check_load_package_source_iter__1660000071__1660000075_fn__1660000076_fn__1660000077_A_class *jrt.Class

var A_arbace_go_check_load_path__GT_ns_A_class *jrt.Class

var A_arbace_go_check_load_path__GT_ns_fn__1660000013_A_class *jrt.Class

var A_arbace_go_check_load_read_forms_A_class *jrt.Class

var A_arbace_go_check_load_tag_set_A_class *jrt.Class

var A_arbace_go_check_load_tag_set_fn__1660000041_A_class *jrt.Class

var A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_A_class *jrt.Class

var A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_A_class *jrt.Class

var A_arbace_go_check_load_tag_set_iter__1660000021__1660000025_fn__1660000026_fn__1660000027_A_class *jrt.Class

var A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_A_class *jrt.Class

var A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_A_class *jrt.Class

var A_arbace_go_check_load_tag_set_iter__1660000031__1660000035_fn__1660000036_fn__1660000037_A_class *jrt.Class

var A_arbace_go_check_load_tokens_A_class *jrt.Class

func A_arbace_go_check_load__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_go_check_load__init_A_Load__O()}; return nil }

func A_arbace_go_check_load__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_go_check_load__init_A_New()}; return nil }

var A_arbace_go_check_load__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_go_check_load__init_A_invoke, New: A_arbace_go_check_load__init_A_new}

var A_arbace_go_check_load__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.go.check.load__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_go_check_load.A_arbace_go_check_load__init_A", Source: "load.ae"})

func init() { i := A_arbace_go_check_load__init_A_class.Info(); i.IsInstance = A_arbace_go_check_load__init_A_InstanceOf; i.Init = A_arbace_go_check_load__init_A_Init; i.Table = A_arbace_go_check_load__init_A_members }
