//line j2g_strings.ae:1
package aot_arbace_go_check_load

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn14,arbace.java.ioyn2,ioyn20,arbace.repr.go.printyn2,rpkn3,dockn4,gooskn6,goarchkn7,goamd64kn7,goarm64kn4,tagskn4,elsekn5,buildkn7,overlaykn3,dirkn7,packagekn4,namekn5,fileskn4,langkn6,configkn4,optskn4,pathkn2,pfkn8,pkg-lineys2,go7,packagekn4,linev11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn20,arbace.go.check.loadm2,R8,s511,goi's checker: Go packages read as forms from forms roots (doc/go/GOI-SPEC.md §3.1, §3.9;\n  doc/go/SPEC.md §4.1): the package file and its files, each file's build constraints and name\n  evaluated against the configuration as gc does, and import paths resolved to packages of the\n  roots (the standard library's vendored packages, a directory test's local paths).\n\n  A root is {:dir D :overlay D2?}: packages at D/go/<path>.ae (SPEC §4.1), with D2/go/ laid over\n  them file by file (tamago/goroot's arch/ARCH/).v13,arbace.string4,joinv11,arbace.core3,mapv13,arbace.string7,replacep4,[.-]v13,arbace.string5,splitp1,/v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstR9,R10,R11,R12,R13,v11,arbace.core4,intov11,arbace.core6,concatv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core5,rangel1,l28,v20,arbace.go.check.load7,unix-osV1,s4,unixv11,arbace.core4,subsV1,s10,arm64.v8.0v20,arbace.go.check.load19,default-experimentsv11,arbace.core6,re-seqp30,\\(|\\)|&&|\\|\\||!|[A-Za-z0-9_.]+v11,arbace.core3,vecv20,arbace.go.check.load6,tokensp14,^//go:build\\s*v11,arbace.core9,volatile!l0,v11,arbace.core3,notv11,arbace.core9,contains?p5,\\.go$v13,arbace.string8,index-ofp1,_v11,arbace.core4,peekv11,arbace.core3,popv20,arbace.go.check.load8,known-osv20,arbace.go.check.load10,known-archR14,v20,arbace.go.check.load18,good-os-arch-file?v11,arbace.core6,every?v13,arbace.string12,starts-with?v20,arbace.go.check.load10,eval-buildR15,v20,arbace.go.check.load10,read-cachev20,arbace.repr.go.print10,read-formsR16,R17,v11,arbace.core3,strv20,arbace.repr.go.print7,collectv20,arbace.go.check.load10,read-formsv20,arbace.go.check.load12,overlay-filev20,arbace.go.check.load8,ns->filev20,arbace.go.check.load8,path->nsv20,arbace.go.check.load15,collect-packageR18,R19,R20,v11,arbace.core5,mergem2,R21,s6,go1.27R22,v20,arbace.go.check.load7,tag-setR23,v20,arbace.go.check.load14,file-included?v11,arbace.core5,assocR24,v20,arbace.repr.go.print9,name-textR25,R26,v11,arbace.core4,somev11,arbace.core4,seq?R27,R28,v20,arbace.go.check.load14,package-sourcev11,arbace.core7,sort-byv11,arbace.core6,filterv14,arbace.java.io6,readerv11,arbace.core6,removev13,arbace.string6,blank?v11,arbace.core8,line-seqv13,arbace.string10,ends-with?v11,arbace.core8,file-seqR27,v11,arbace.core5,applyv11,arbace.core8,hash-mapv11,arbace.core5,nnext")

var Lit_1 *jrt.String = jrt.Intern("clear")

var Lit_2 *jrt.String = jrt.Intern("arbace.go.check.load$collect_package$fn__1660000065")

var Lit_3 *jrt.String = jrt.Intern("java.io.File")

var Lit_4 *jrt.String = jrt.Intern("")

var Lit_5 *jrt.String = jrt.Intern("arbace.go.check.load$eval_build$peek_STAR___1660000045")

var Lit_6 *jrt.String = jrt.Intern("arbace.go.check.load$eval_build$next_STAR___1660000047")

var Lit_7 *jrt.String = jrt.Intern("arbace.go.check.load$eval_build$or_expr__1660000049")

var Lit_8 *jrt.String = jrt.Intern("arbace.go.check.load$eval_build$and_expr__1660000051")

var Lit_9 *jrt.String = jrt.Intern("arbace.go.check.load$eval_build$not_expr__1660000053")

var Lit_10 *jrt.String = jrt.Intern("arbace.go.check.load$eval_build$atom_STAR___1660000055")

var Lit_11 *jrt.String = jrt.Intern("&&")

var Lit_12 *jrt.String = jrt.Intern("(")

var Lit_13 *jrt.String = jrt.Intern("!")

var Lit_14 *jrt.String = jrt.Intern("||")

var Lit_15 *jrt.String = jrt.Intern("arbace.go.check.load$file_included_QMARK_$fn__1660000059")

var Lit_16 *jrt.String = jrt.Intern("//go:build")

var Lit_17 *jrt.String = jrt.Intern("_")

var Lit_18 *jrt.String = jrt.Intern("test")

var Lit_19 *jrt.String = jrt.Intern("android")

var Lit_20 *jrt.String = jrt.Intern("linux")

var Lit_21 *jrt.String = jrt.Intern("illumos")

var Lit_22 *jrt.String = jrt.Intern("solaris")

var Lit_23 *jrt.String = jrt.Intern(".ae")

var Lit_24 *jrt.String = jrt.Intern(".")

var Lit_25 *jrt.String = jrt.Intern("/")

var Lit_26 *jrt.String = jrt.Intern("/go/")

var Lit_27 *jrt.String = jrt.Intern("arbace.go.check.load$package_files$fn__1660000085")

var Lit_28 *jrt.String = jrt.Intern("arbace.go.check.load$package_files$fn__1660000087")

var Lit_29 *jrt.String = jrt.Intern("arbace.go.check.load$package_files$fn__1660000091")

var Lit_30 *jrt.String = jrt.Intern("arbace.go.check.load$package_files$fn__1660000087$fn__1660000088")

var Lit_31 *jrt.String = jrt.Intern("(ns ")

var Lit_32 *jrt.String = jrt.Intern(";")

var Lit_33 *jrt.String = jrt.Intern("arbace.go.check.load$package_path_of$fn__1660000095")

var Lit_34 *jrt.String = jrt.Intern("arbace.go.check.load$package_source$iter__1660000071__1660000075")

var Lit_35 *jrt.String = jrt.Intern("arbace.go.check.load$package_source$fn__1660000081")

var Lit_36 *jrt.String = jrt.Intern("arbace.go.check.load$package_source$iter__1660000071__1660000075$fn__1660000076")

var Lit_37 *jrt.String = jrt.Intern("arbace.go.check.load$package_source$iter__1660000071__1660000075$fn__1660000076$fn__1660000077")

var Lit_38 *jrt.String = jrt.Intern("go.")

var Lit_39 *jrt.String = jrt.Intern("arbace.go.check.load$path__GT_ns$fn__1660000013")

var Lit_40 *jrt.String = jrt.Intern("get")

var Lit_41 *jrt.String = jrt.Intern("put")

var Lit_42 *jrt.String = jrt.Intern("gc")

var Lit_43 *jrt.String = jrt.Intern("arbace.go.check.load$tag_set$iter__1660000021__1660000025")

var Lit_44 *jrt.String = jrt.Intern("amd64")

var Lit_45 *jrt.String = jrt.Intern("v1")

var Lit_46 *jrt.String = jrt.Intern("arbace.go.check.load$tag_set$iter__1660000031__1660000035")

var Lit_47 *jrt.String = jrt.Intern("arm64")

var Lit_48 *jrt.String = jrt.Intern("arbace.go.check.load$tag_set$fn__1660000041")

var Lit_49 *jrt.String = jrt.Intern("goexperiment.")

var Lit_50 *jrt.String = jrt.Intern("arbace.go.check.load$tag_set$iter__1660000021__1660000025$fn__1660000026")

var Lit_51 *jrt.String = jrt.Intern("arbace.go.check.load$tag_set$iter__1660000021__1660000025$fn__1660000026$fn__1660000027")

var Lit_52 *jrt.String = jrt.Intern("go1.")

var Lit_53 *jrt.String = jrt.Intern("arbace.go.check.load$tag_set$iter__1660000031__1660000035$fn__1660000036")

var Lit_54 *jrt.String = jrt.Intern("arbace.go.check.load$tag_set$iter__1660000031__1660000035$fn__1660000036$fn__1660000037")

var Lit_55 *jrt.String = jrt.Intern("amd64.v")

var Lit_56 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistskn3,tagyn6,Stringyn16,java.lang.Stringkn4,linekn6,columnkn4,filekn4,keysyn4,goosyn6,goarchyn7,goamd64yn7,goarm64yn4,tagskn7,privateyn5,fnameyn4,optsyn6,configyn4,Fileyn4,rootyn12,java.io.Fileyn4,pathyn3,subv11,arbace.core5,in-nsMyn20,arbace.go.check.loadm2,R0,s511,goi's checker: Go packages read as forms from forms roots (doc/go/GOI-SPEC.md §3.1, §3.9;\n  doc/go/SPEC.md §4.1): the package file and its files, each file's build constraints and name\n  evaluated against the configuration as gc does, and import paths resolved to packages of the\n  roots (the standard library's vendored packages, a directory test's local paths).\n\n  A root is {:dir D :overlay D2?}: packages at D/go/<path>.ae (SPEC §4.1), with D2/go/ laid over\n  them file by file (tamago/goroot's arch/ARCH/).m2,R0,s511,goi's checker: Go packages read as forms from forms roots (doc/go/GOI-SPEC.md §3.1, §3.9;\n  doc/go/SPEC.md §4.1): the package file and its files, each file's build constraints and name\n  evaluated against the configuration as gc does, and import paths resolved to packages of the\n  roots (the standard library's vendored packages, a directory test's local paths).\n\n  A root is {:dir D :overlay D2?}: packages at D/go/<path>.ae (SPEC §4.1), with D2/go/ laid over\n  them file by file (tamago/goroot's arch/ARCH/).R1,v20,arbace.go.check.load8,path->nsm10,R2,L1,MV1,Myn4,pathm2,R3,R4,m2,R3,R5,R0,s37,The namespace name of an import path.R6,i16,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load8,ns->filem10,R2,L1,MV1,Myn2,nsm2,R3,R4,m2,R3,R5,R0,s52,The package file of a namespace, relative to a root.R6,i21,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load8,known-osS19,s2,jss7,freebsds7,openbsds4,nacls6,wasip1s5,linuxs6,tamagos6,darwins5,plan9s7,windowss3,aixs3,zoss7,solariss3,ioss4,hurds9,dragonflys7,illumoss6,netbsds7,androidm6,R6,i28,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load7,unix-osS12,s7,freebsds7,openbsds5,linuxs6,darwins3,aixs7,solariss3,ioss4,hurds9,dragonflys7,illumoss6,netbsds7,androidm6,R6,i30,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load10,known-archS24,s7,arm64bes7,riscv64s11,mips64p32les7,ppc64les5,sparcs5,amd64s3,arms3,386s7,sparc64s4,mipss5,armbes5,s390xs9,mips64p32s5,ppc64s5,riscvs7,loong64s3,ppcs5,arm64s4,s390s4,wasms8,mips64les8,amd64p32s6,mipsles6,mips64m6,R6,i32,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load19,default-experimentsV7,s14,regabiwrapperss10,regabiargss6,dwarf5s20,randomizedheapbase64s10,greenteagcs6,jsonv2s21,sizespecializedmallocm8,R6,i36,R7,i1,R8,s23,arbace/go/check/load.aeR0,s78,go1.27.1's baseline experiments on amd64 and arm64 (internal/buildcfg/exp.go).v20,arbace.go.check.load7,tag-setm10,R2,L1,V1,m2,R9,V5,R10,R11,R12,R13,R14,R0,s84,The build tags satisfied by a configuration {:goos :goarch :goamd64 :goarm64 :tags}.R6,i40,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load6,tokensm10,R15,TR2,L1,V1,Myn1,sm2,R3,R4,R6,i53,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load10,eval-buildm10,R2,L1,V2,Myn4,linem2,R3,R4,R14,R0,s60,The value of a //go:build expression for the satisfied tags.R6,i56,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load18,good-os-arch-file?m10,R2,L1,V3,Myn5,fnamem2,R3,R4,R10,R11,R0,s79,go/build's goodOSArchFile: a file name's _GOOS, _GOARCH, _GOOS_GOARCH suffixes.R6,i74,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load14,file-included?m10,R2,L1,V4,R16,R17,R18,R14,R0,s82,Whether a file (its go/file options) is part of the package for the configuration.R6,i92,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load10,read-cachem8,R15,TR6,i101,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load10,read-formsm10,R2,L1,V1,Myn1,fm2,R3,R19,R0,s69,A file's forms, cached by path (the roots are read once per session).R6,i103,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load12,clear-cache!m8,R2,L1,V0,R6,i112,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load12,overlay-filem12,R15,TR2,L1,MV2,R20,Myn3,relm2,R3,R4,m2,R3,R21,R0,s61,A file of the root, or its overlay's when the overlay has it.R6,i114,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load15,collect-packagem10,R2,L1,V2,R20,Myn2,pfm2,R3,R19,R0,s113,The package of the forms file pf in root: arbace.repr.go.print's collect, with files\n  replaced by the overlay's.R6,i120,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load14,package-sourcem10,R2,L2,V3,R20,R22,R18,V4,R20,R22,R18,Myn2,pfm2,R3,R19,R0,s223,The source of the package with import path in root for config: {:path :name :config\n  :opts (go/package's) :files [{:name :opts :decls}] :pf}, or nil when the root has none;\n  pf the package file when known (test programs).R6,i130,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load13,package-filesm10,R2,L1,V2,R20,R23,R0,s75,The package files (whose first form is ns) under root's dir/go/sub, sorted.R6,i149,R7,i1,R8,s23,arbace/go/check/load.aev20,arbace.go.check.load15,package-path-ofm10,R2,L1,V1,Myn2,pfm2,R3,R19,R0,s63,The import path a package file declares (its go/package :path).R6,i161,R7,i1,R8,s23,arbace/go/check/load.ae")

var Lit_57 *jrt.String = jrt.Intern("arbace.go.check.load$eval1660000004$loading__1927001464__auto____1660000005")

var Lit_58 *jrt.String = jrt.Intern("arbace.go.check.load$eval1660000008$fn__1660000009")

var Lit_59 *jrt.String = jrt.Intern("arbace.go.check.load$path__GT_ns")

var Lit_60 *jrt.String = jrt.Intern("arbace.go.check.load$ns__GT_file")

var Lit_61 *jrt.String = jrt.Intern("arbace.go.check.load$tag_set")

var Lit_62 *jrt.String = jrt.Intern("arbace.go.check.load$tokens")

var Lit_63 *jrt.String = jrt.Intern("arbace.go.check.load$eval_build")

var Lit_64 *jrt.String = jrt.Intern("arbace.go.check.load$good_os_arch_file_QMARK_")

var Lit_65 *jrt.String = jrt.Intern("arbace.go.check.load$file_included_QMARK_")

var Lit_66 *jrt.String = jrt.Intern("arbace.go.check.load$read_forms")

var Lit_67 *jrt.String = jrt.Intern("arbace.go.check.load$clear_cache_BANG_")

var Lit_68 *jrt.String = jrt.Intern("arbace.go.check.load$overlay_file")

var Lit_69 *jrt.String = jrt.Intern("arbace.go.check.load$collect_package")

var Lit_70 *jrt.String = jrt.Intern("arbace.go.check.load$package_source")

var Lit_71 *jrt.String = jrt.Intern("arbace.go.check.load$package_files")

var Lit_72 *jrt.String = jrt.Intern("arbace.go.check.load$package_path_of")
