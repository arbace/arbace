//line a2g_classes.ae:1
package aot_arbace_box

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_box_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_A_New()}; return nil }

var A_arbace_box_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_A_new}

var A_arbace_box_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box.A_arbace_box_A"})

func init() { i := A_arbace_box_A_class.Info(); i.IsInstance = A_arbace_box_A_InstanceOf; i.Init = A_arbace_box_A_Init; i.Table = A_arbace_box_A_members; jrt.RegisterGoType(A_arbace_box_A_class, reflect.TypeFor[A_arbace_box_A]()) }

func A_arbace_box_answer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_answer_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_answer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_answer_A_New()}; return nil }

func A_arbace_box_answer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_answer_A_fn_class)}; return nil }

var A_arbace_box_answer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_answer_A_invoke, New: A_arbace_box_answer_A_new, Get: A_arbace_box_answer_A_get}

var A_arbace_box_answer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$answer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_box_A_class, Simple: "answer", Go: "arbace/aot_arbace_box.A_arbace_box_answer_A", Source: "box.ae"})

func init() { i := A_arbace_box_answer_A_class.Info(); i.IsInstance = A_arbace_box_answer_A_InstanceOf; i.Init = A_arbace_box_answer_A_Init; i.Table = A_arbace_box_answer_A_members; jrt.RegisterGoType(A_arbace_box_answer_A_class, reflect.TypeFor[A_arbace_box_answer_A]()) }

func A_arbace_box_boxed_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_boxed_QMARK__A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_boxed_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_boxed_QMARK__A_New()}; return nil }

func A_arbace_box_boxed_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_boxed_QMARK__A_fn_class)}; return nil }

var A_arbace_box_boxed_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_boxed_QMARK__A_invoke, New: A_arbace_box_boxed_QMARK__A_new, Get: A_arbace_box_boxed_QMARK__A_get}

var A_arbace_box_boxed_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$boxed_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_A_class, Simple: "boxed_QMARK_", Go: "arbace/aot_arbace_box.A_arbace_box_boxed_QMARK__A", Source: "box.ae"})

func init() { i := A_arbace_box_boxed_QMARK__A_class.Info(); i.IsInstance = A_arbace_box_boxed_QMARK__A_InstanceOf; i.Init = A_arbace_box_boxed_QMARK__A_Init; i.Table = A_arbace_box_boxed_QMARK__A_members; jrt.RegisterGoType(A_arbace_box_boxed_QMARK__A_class, reflect.TypeFor[A_arbace_box_boxed_QMARK__A]()) }

func A_arbace_box_eval533000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_eval533000004_A_New()}; return nil }

var A_arbace_box_eval533000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_eval533000004_A_new}

var A_arbace_box_eval533000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$eval533000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_A_class, Simple: "eval533000004", Go: "arbace/aot_arbace_box.A_arbace_box_eval533000004_A"})

func init() { i := A_arbace_box_eval533000004_A_class.Info(); i.IsInstance = A_arbace_box_eval533000004_A_InstanceOf; i.Table = A_arbace_box_eval533000004_A_members; jrt.RegisterGoType(A_arbace_box_eval533000004_A_class, reflect.TypeFor[A_arbace_box_eval533000004_A]()) }

func A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_New()}; return nil }

func A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_fn_class)}; return nil }

var A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_invoke, New: A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_new, Get: A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_get}

var A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$eval533000004$loading__1927001464__auto____533000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_eval533000004_A_class, Simple: "loading__1927001464__auto____533000005", Go: "arbace/aot_arbace_box.A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A", Source: "box.ae"})

func init() { i := A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_class.Info(); i.IsInstance = A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_InstanceOf; i.Init = A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_Init; i.Table = A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_members; jrt.RegisterGoType(A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A_class, reflect.TypeFor[A_arbace_box_eval533000004_loading__1927001464__auto____533000005_A]()) }

func A_arbace_box_eval533000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_eval533000008_A_New()}; return nil }

var A_arbace_box_eval533000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_eval533000008_A_new}

var A_arbace_box_eval533000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$eval533000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_A_class, Simple: "eval533000008", Go: "arbace/aot_arbace_box.A_arbace_box_eval533000008_A"})

func init() { i := A_arbace_box_eval533000008_A_class.Info(); i.IsInstance = A_arbace_box_eval533000008_A_InstanceOf; i.Table = A_arbace_box_eval533000008_A_members; jrt.RegisterGoType(A_arbace_box_eval533000008_A_class, reflect.TypeFor[A_arbace_box_eval533000008_A]()) }

func A_arbace_box_eval533000008_fn__533000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_eval533000008_fn__533000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_eval533000008_fn__533000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_eval533000008_fn__533000009_A_New()}; return nil }

func A_arbace_box_eval533000008_fn__533000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_eval533000008_fn__533000009_A_fn_class)}; return nil }

var A_arbace_box_eval533000008_fn__533000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_eval533000008_fn__533000009_A_invoke, New: A_arbace_box_eval533000008_fn__533000009_A_new, Get: A_arbace_box_eval533000008_fn__533000009_A_get}

var A_arbace_box_eval533000008_fn__533000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$eval533000008$fn__533000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_eval533000008_A_class, Simple: "fn__533000009", Go: "arbace/aot_arbace_box.A_arbace_box_eval533000008_fn__533000009_A", Source: "box.ae"})

func init() { i := A_arbace_box_eval533000008_fn__533000009_A_class.Info(); i.IsInstance = A_arbace_box_eval533000008_fn__533000009_A_InstanceOf; i.Init = A_arbace_box_eval533000008_fn__533000009_A_Init; i.Table = A_arbace_box_eval533000008_fn__533000009_A_members; jrt.RegisterGoType(A_arbace_box_eval533000008_fn__533000009_A_class, reflect.TypeFor[A_arbace_box_eval533000008_fn__533000009_A]()) }

func A_arbace_box_fail_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_fail_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_fail_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_fail_A_New()}; return nil }

func A_arbace_box_fail_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_fail_A_fn_class)}; return nil }

var A_arbace_box_fail_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_fail_A_invoke, New: A_arbace_box_fail_A_new, Get: A_arbace_box_fail_A_get}

var A_arbace_box_fail_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$fail", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_box_A_class, Simple: "fail", Go: "arbace/aot_arbace_box.A_arbace_box_fail_A", Source: "box.ae"})

func init() { i := A_arbace_box_fail_A_class.Info(); i.IsInstance = A_arbace_box_fail_A_InstanceOf; i.Init = A_arbace_box_fail_A_Init; i.Table = A_arbace_box_fail_A_members; jrt.RegisterGoType(A_arbace_box_fail_A_class, reflect.TypeFor[A_arbace_box_fail_A]()) }

func A_arbace_box_fs_dir_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_fs_dir_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_fs_dir_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_fs_dir_A_New()}; return nil }

func A_arbace_box_fs_dir_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_fs_dir_A_fn_class)}; return nil }

var A_arbace_box_fs_dir_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_fs_dir_A_invoke, New: A_arbace_box_fs_dir_A_new, Get: A_arbace_box_fs_dir_A_get}

var A_arbace_box_fs_dir_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$fs_dir", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_A_class, Simple: "fs_dir", Go: "arbace/aot_arbace_box.A_arbace_box_fs_dir_A", Source: "box.ae"})

func init() { i := A_arbace_box_fs_dir_A_class.Info(); i.IsInstance = A_arbace_box_fs_dir_A_InstanceOf; i.Init = A_arbace_box_fs_dir_A_Init; i.Table = A_arbace_box_fs_dir_A_members; jrt.RegisterGoType(A_arbace_box_fs_dir_A_class, reflect.TypeFor[A_arbace_box_fs_dir_A]()) }

func A_arbace_box_get_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_get_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_get_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_get_A_New()}; return nil }

func A_arbace_box_get_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_get_A_fn_class)}; return nil }

var A_arbace_box_get_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_get_A_invoke, New: A_arbace_box_get_A_new, Get: A_arbace_box_get_A_get}

var A_arbace_box_get_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$get", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "get", Go: "arbace/aot_arbace_box.A_arbace_box_get_A", Source: "box.ae"})

func init() { i := A_arbace_box_get_A_class.Info(); i.IsInstance = A_arbace_box_get_A_InstanceOf; i.Init = A_arbace_box_get_A_Init; i.Table = A_arbace_box_get_A_members; jrt.RegisterGoType(A_arbace_box_get_A_class, reflect.TypeFor[A_arbace_box_get_A]()) }

func A_arbace_box_get_bytes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_get_bytes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_get_bytes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_get_bytes_A_New()}; return nil }

func A_arbace_box_get_bytes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_get_bytes_A_fn_class)}; return nil }

var A_arbace_box_get_bytes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_get_bytes_A_invoke, New: A_arbace_box_get_bytes_A_new, Get: A_arbace_box_get_bytes_A_get}

var A_arbace_box_get_bytes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$get_bytes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "get_bytes", Go: "arbace/aot_arbace_box.A_arbace_box_get_bytes_A", Source: "box.ae"})

func init() { i := A_arbace_box_get_bytes_A_class.Info(); i.IsInstance = A_arbace_box_get_bytes_A_InstanceOf; i.Init = A_arbace_box_get_bytes_A_Init; i.Table = A_arbace_box_get_bytes_A_members; jrt.RegisterGoType(A_arbace_box_get_bytes_A_class, reflect.TypeFor[A_arbace_box_get_bytes_A]()) }

func A_arbace_box_get_tree_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_get_tree_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_get_tree_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_get_tree_A_New()}; return nil }

func A_arbace_box_get_tree_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_get_tree_A_fn_class)}; return nil }

var A_arbace_box_get_tree_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_get_tree_A_invoke, New: A_arbace_box_get_tree_A_new, Get: A_arbace_box_get_tree_A_get}

var A_arbace_box_get_tree_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$get_tree", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_A_class, Simple: "get_tree", Go: "arbace/aot_arbace_box.A_arbace_box_get_tree_A", Source: "box.ae"})

func init() { i := A_arbace_box_get_tree_A_class.Info(); i.IsInstance = A_arbace_box_get_tree_A_InstanceOf; i.Init = A_arbace_box_get_tree_A_Init; i.Table = A_arbace_box_get_tree_A_members; jrt.RegisterGoType(A_arbace_box_get_tree_A_class, reflect.TypeFor[A_arbace_box_get_tree_A]()) }

func A_arbace_box_get_tree_fn__533000077_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_get_tree_fn__533000077_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_get_tree_fn__533000077_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_get_tree_fn__533000077_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_get_tree_fn__533000077_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_get_tree_fn__533000077_A_fn_class)}; return nil }

var A_arbace_box_get_tree_fn__533000077_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_get_tree_fn__533000077_A_invoke, New: A_arbace_box_get_tree_fn__533000077_A_new, Get: A_arbace_box_get_tree_fn__533000077_A_get}

var A_arbace_box_get_tree_fn__533000077_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$get_tree$fn__533000077", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_get_tree_A_class, Simple: "fn__533000077", Go: "arbace/aot_arbace_box.A_arbace_box_get_tree_fn__533000077_A", Source: "box.ae"})

func init() { i := A_arbace_box_get_tree_fn__533000077_A_class.Info(); i.IsInstance = A_arbace_box_get_tree_fn__533000077_A_InstanceOf; i.Init = A_arbace_box_get_tree_fn__533000077_A_Init; i.Table = A_arbace_box_get_tree_fn__533000077_A_members; jrt.RegisterGoType(A_arbace_box_get_tree_fn__533000077_A_class, reflect.TypeFor[A_arbace_box_get_tree_fn__533000077_A]()) }

func A_arbace_box_get_tree_fn__533000085_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_get_tree_fn__533000085_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_get_tree_fn__533000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_get_tree_fn__533000085_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_get_tree_fn__533000085_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_get_tree_fn__533000085_A_fn_class)}; return nil }

var A_arbace_box_get_tree_fn__533000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_get_tree_fn__533000085_A_invoke, New: A_arbace_box_get_tree_fn__533000085_A_new, Get: A_arbace_box_get_tree_fn__533000085_A_get}

var A_arbace_box_get_tree_fn__533000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$get_tree$fn__533000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_get_tree_A_class, Simple: "fn__533000085", Go: "arbace/aot_arbace_box.A_arbace_box_get_tree_fn__533000085_A", Source: "box.ae"})

func init() { i := A_arbace_box_get_tree_fn__533000085_A_class.Info(); i.IsInstance = A_arbace_box_get_tree_fn__533000085_A_InstanceOf; i.Init = A_arbace_box_get_tree_fn__533000085_A_Init; i.Table = A_arbace_box_get_tree_fn__533000085_A_members; jrt.RegisterGoType(A_arbace_box_get_tree_fn__533000085_A_class, reflect.TypeFor[A_arbace_box_get_tree_fn__533000085_A]()) }

func A_arbace_box_hash_bytes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_hash_bytes_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_hash_bytes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_hash_bytes_A_New()}; return nil }

func A_arbace_box_hash_bytes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_hash_bytes_A_fn_class)}; return nil }

var A_arbace_box_hash_bytes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_hash_bytes_A_invoke, New: A_arbace_box_hash_bytes_A_new, Get: A_arbace_box_hash_bytes_A_get}

var A_arbace_box_hash_bytes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$hash_bytes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_A_class, Simple: "hash_bytes", Go: "arbace/aot_arbace_box.A_arbace_box_hash_bytes_A", Source: "box.ae"})

func init() { i := A_arbace_box_hash_bytes_A_class.Info(); i.IsInstance = A_arbace_box_hash_bytes_A_InstanceOf; i.Init = A_arbace_box_hash_bytes_A_Init; i.Table = A_arbace_box_hash_bytes_A_members; jrt.RegisterGoType(A_arbace_box_hash_bytes_A_class, reflect.TypeFor[A_arbace_box_hash_bytes_A]()) }

func A_arbace_box_hex_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_hex_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_hex_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_hex_A_New()}; return nil }

func A_arbace_box_hex_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_hex_A_fn_class)}; return nil }

var A_arbace_box_hex_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_hex_A_invoke, New: A_arbace_box_hex_A_new, Get: A_arbace_box_hex_A_get}

var A_arbace_box_hex_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$hex", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "hex", Go: "arbace/aot_arbace_box.A_arbace_box_hex_A", Source: "box.ae"})

func init() { i := A_arbace_box_hex_A_class.Info(); i.IsInstance = A_arbace_box_hex_A_InstanceOf; i.Init = A_arbace_box_hex_A_Init; i.Table = A_arbace_box_hex_A_members; jrt.RegisterGoType(A_arbace_box_hex_A_class, reflect.TypeFor[A_arbace_box_hex_A]()) }

func A_arbace_box_load_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_load_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_load_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_load_A_New()}; return nil }

func A_arbace_box_load_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_load_A_fn_class)}; return nil }

var A_arbace_box_load_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_load_A_invoke, New: A_arbace_box_load_A_new, Get: A_arbace_box_load_A_get}

var A_arbace_box_load_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$load", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "load", Go: "arbace/aot_arbace_box.A_arbace_box_load_A", Source: "box.ae"})

func init() { i := A_arbace_box_load_A_class.Info(); i.IsInstance = A_arbace_box_load_A_InstanceOf; i.Init = A_arbace_box_load_A_Init; i.Table = A_arbace_box_load_A_members; jrt.RegisterGoType(A_arbace_box_load_A_class, reflect.TypeFor[A_arbace_box_load_A]()) }

func A_arbace_box_load_fs_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_load_fs_BANG__A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_box_load_fs_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_load_fs_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_load_fs_BANG__A_New()}; return nil }

func A_arbace_box_load_fs_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_load_fs_BANG__A_fn_class)}; return nil }

var A_arbace_box_load_fs_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_load_fs_BANG__A_invoke, New: A_arbace_box_load_fs_BANG__A_new, Get: A_arbace_box_load_fs_BANG__A_get}

var A_arbace_box_load_fs_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$load_fs_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "load_fs_BANG_", Go: "arbace/aot_arbace_box.A_arbace_box_load_fs_BANG__A", Source: "box.ae"})

func init() { i := A_arbace_box_load_fs_BANG__A_class.Info(); i.IsInstance = A_arbace_box_load_fs_BANG__A_InstanceOf; i.Init = A_arbace_box_load_fs_BANG__A_Init; i.Table = A_arbace_box_load_fs_BANG__A_members; jrt.RegisterGoType(A_arbace_box_load_fs_BANG__A_class, reflect.TypeFor[A_arbace_box_load_fs_BANG__A]()) }

func A_arbace_box_load_ref_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_load_ref_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_load_ref_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_load_ref_A_New()}; return nil }

func A_arbace_box_load_ref_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_load_ref_A_fn_class)}; return nil }

var A_arbace_box_load_ref_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_load_ref_A_invoke, New: A_arbace_box_load_ref_A_new, Get: A_arbace_box_load_ref_A_get}

var A_arbace_box_load_ref_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$load_ref", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "load_ref", Go: "arbace/aot_arbace_box.A_arbace_box_load_ref_A", Source: "box.ae"})

func init() { i := A_arbace_box_load_ref_A_class.Info(); i.IsInstance = A_arbace_box_load_ref_A_InstanceOf; i.Init = A_arbace_box_load_ref_A_Init; i.Table = A_arbace_box_load_ref_A_members; jrt.RegisterGoType(A_arbace_box_load_ref_A_class, reflect.TypeFor[A_arbace_box_load_ref_A]()) }

func A_arbace_box_put_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_put_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_put_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_put_A_New()}; return nil }

func A_arbace_box_put_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_put_A_fn_class)}; return nil }

var A_arbace_box_put_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_put_A_invoke, New: A_arbace_box_put_A_new, Get: A_arbace_box_put_A_get}

var A_arbace_box_put_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$put", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "put", Go: "arbace/aot_arbace_box.A_arbace_box_put_A", Source: "box.ae"})

func init() { i := A_arbace_box_put_A_class.Info(); i.IsInstance = A_arbace_box_put_A_InstanceOf; i.Init = A_arbace_box_put_A_Init; i.Table = A_arbace_box_put_A_members; jrt.RegisterGoType(A_arbace_box_put_A_class, reflect.TypeFor[A_arbace_box_put_A]()) }

func A_arbace_box_put_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_put_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_put_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_put_BANG__A_New()}; return nil }

func A_arbace_box_put_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_put_BANG__A_fn_class)}; return nil }

var A_arbace_box_put_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_put_BANG__A_invoke, New: A_arbace_box_put_BANG__A_new, Get: A_arbace_box_put_BANG__A_get}

var A_arbace_box_put_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$put_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_A_class, Simple: "put_BANG_", Go: "arbace/aot_arbace_box.A_arbace_box_put_BANG__A", Source: "box.ae"})

func init() { i := A_arbace_box_put_BANG__A_class.Info(); i.IsInstance = A_arbace_box_put_BANG__A_InstanceOf; i.Init = A_arbace_box_put_BANG__A_Init; i.Table = A_arbace_box_put_BANG__A_members; jrt.RegisterGoType(A_arbace_box_put_BANG__A_class, reflect.TypeFor[A_arbace_box_put_BANG__A]()) }

func A_arbace_box_put_dir_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_put_dir_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_put_dir_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_put_dir_A_New()}; return nil }

func A_arbace_box_put_dir_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_put_dir_A_fn_class)}; return nil }

var A_arbace_box_put_dir_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_put_dir_A_invoke, New: A_arbace_box_put_dir_A_new, Get: A_arbace_box_put_dir_A_get}

var A_arbace_box_put_dir_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$put_dir", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "put_dir", Go: "arbace/aot_arbace_box.A_arbace_box_put_dir_A", Source: "box.ae"})

func init() { i := A_arbace_box_put_dir_A_class.Info(); i.IsInstance = A_arbace_box_put_dir_A_InstanceOf; i.Init = A_arbace_box_put_dir_A_Init; i.Table = A_arbace_box_put_dir_A_members; jrt.RegisterGoType(A_arbace_box_put_dir_A_class, reflect.TypeFor[A_arbace_box_put_dir_A]()) }

func A_arbace_box_put_dir_iter__533000056__533000060_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_put_dir_iter__533000056__533000060_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_put_dir_iter__533000056__533000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_put_dir_iter__533000056__533000060_A_New()}; return nil }

func A_arbace_box_put_dir_iter__533000056__533000060_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_put_dir_iter__533000056__533000060_A_fn_class)}; return nil }

var A_arbace_box_put_dir_iter__533000056__533000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_put_dir_iter__533000056__533000060_A_invoke, New: A_arbace_box_put_dir_iter__533000056__533000060_A_new, Get: A_arbace_box_put_dir_iter__533000056__533000060_A_get}

var A_arbace_box_put_dir_iter__533000056__533000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$put_dir$iter__533000056__533000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_put_dir_A_class, Simple: "iter__533000056__533000060", Go: "arbace/aot_arbace_box.A_arbace_box_put_dir_iter__533000056__533000060_A", Source: "box.ae"})

func init() { i := A_arbace_box_put_dir_iter__533000056__533000060_A_class.Info(); i.IsInstance = A_arbace_box_put_dir_iter__533000056__533000060_A_InstanceOf; i.Init = A_arbace_box_put_dir_iter__533000056__533000060_A_Init; i.Table = A_arbace_box_put_dir_iter__533000056__533000060_A_members; jrt.RegisterGoType(A_arbace_box_put_dir_iter__533000056__533000060_A_class, reflect.TypeFor[A_arbace_box_put_dir_iter__533000056__533000060_A]()) }

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_fn_class)}; return nil }

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_invoke, New: A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_new, Get: A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_get}

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$put_dir$iter__533000056__533000060$fn__533000061", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_put_dir_iter__533000056__533000060_A_class, Simple: "fn__533000061", Go: "arbace/aot_arbace_box.A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A", Source: "box.ae"})

func init() { i := A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_class.Info(); i.IsInstance = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_InstanceOf; i.Init = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_Init; i.Table = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_members; jrt.RegisterGoType(A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_class, reflect.TypeFor[A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A]()) }

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_fn_class)}; return nil }

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_invoke, New: A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_new, Get: A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_get}

var A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$put_dir$iter__533000056__533000060$fn__533000061$fn__533000062", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_A_class, Simple: "fn__533000062", Go: "arbace/aot_arbace_box.A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A", Source: "box.ae"})

func init() { i := A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_class.Info(); i.IsInstance = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_InstanceOf; i.Init = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_Init; i.Table = A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_members; jrt.RegisterGoType(A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A_class, reflect.TypeFor[A_arbace_box_put_dir_iter__533000056__533000060_fn__533000061_fn__533000062_A]()) }

func A_arbace_box_put_file_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_put_file_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_box_put_file_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_put_file_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_put_file_A_New()}; return nil }

func A_arbace_box_put_file_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_put_file_A_fn_class)}; return nil }

var A_arbace_box_put_file_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_put_file_A_invoke, New: A_arbace_box_put_file_A_new, Get: A_arbace_box_put_file_A_get}

var A_arbace_box_put_file_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$put_file", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "put_file", Go: "arbace/aot_arbace_box.A_arbace_box_put_file_A", Source: "box.ae"})

func init() { i := A_arbace_box_put_file_A_class.Info(); i.IsInstance = A_arbace_box_put_file_A_InstanceOf; i.Init = A_arbace_box_put_file_A_Init; i.Table = A_arbace_box_put_file_A_members; jrt.RegisterGoType(A_arbace_box_put_file_A_class, reflect.TypeFor[A_arbace_box_put_file_A]()) }

func A_arbace_box_put_tree_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_put_tree_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_put_tree_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_put_tree_A_New()}; return nil }

func A_arbace_box_put_tree_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_put_tree_A_fn_class)}; return nil }

var A_arbace_box_put_tree_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_put_tree_A_invoke, New: A_arbace_box_put_tree_A_new, Get: A_arbace_box_put_tree_A_get}

var A_arbace_box_put_tree_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$put_tree", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "put_tree", Go: "arbace/aot_arbace_box.A_arbace_box_put_tree_A", Source: "box.ae"})

func init() { i := A_arbace_box_put_tree_A_class.Info(); i.IsInstance = A_arbace_box_put_tree_A_InstanceOf; i.Init = A_arbace_box_put_tree_A_Init; i.Table = A_arbace_box_put_tree_A_members; jrt.RegisterGoType(A_arbace_box_put_tree_A_class, reflect.TypeFor[A_arbace_box_put_tree_A]()) }

func A_arbace_box_quote_str_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_quote_str_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_quote_str_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_quote_str_A_New()}; return nil }

func A_arbace_box_quote_str_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_quote_str_A_fn_class)}; return nil }

var A_arbace_box_quote_str_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_quote_str_A_invoke, New: A_arbace_box_quote_str_A_new, Get: A_arbace_box_quote_str_A_get}

var A_arbace_box_quote_str_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$quote_str", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "quote_str", Go: "arbace/aot_arbace_box.A_arbace_box_quote_str_A", Source: "box.ae"})

func init() { i := A_arbace_box_quote_str_A_class.Info(); i.IsInstance = A_arbace_box_quote_str_A_InstanceOf; i.Init = A_arbace_box_quote_str_A_Init; i.Table = A_arbace_box_quote_str_A_members; jrt.RegisterGoType(A_arbace_box_quote_str_A_class, reflect.TypeFor[A_arbace_box_quote_str_A]()) }

func A_arbace_box_ref_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_ref_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_ref_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_ref_A_New()}; return nil }

func A_arbace_box_ref_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_ref_A_fn_class)}; return nil }

var A_arbace_box_ref_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_ref_A_invoke, New: A_arbace_box_ref_A_new, Get: A_arbace_box_ref_A_get}

var A_arbace_box_ref_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$ref", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "ref", Go: "arbace/aot_arbace_box.A_arbace_box_ref_A", Source: "box.ae"})

func init() { i := A_arbace_box_ref_A_class.Info(); i.IsInstance = A_arbace_box_ref_A_InstanceOf; i.Init = A_arbace_box_ref_A_Init; i.Table = A_arbace_box_ref_A_members; jrt.RegisterGoType(A_arbace_box_ref_A_class, reflect.TypeFor[A_arbace_box_ref_A]()) }

func A_arbace_box_ref_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_ref_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_box_ref_BANG__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_ref_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_ref_BANG__A_New()}; return nil }

func A_arbace_box_ref_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_ref_BANG__A_fn_class)}; return nil }

var A_arbace_box_ref_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_ref_BANG__A_invoke, New: A_arbace_box_ref_BANG__A_new, Get: A_arbace_box_ref_BANG__A_get}

var A_arbace_box_ref_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$ref_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_A_class, Simple: "ref_BANG_", Go: "arbace/aot_arbace_box.A_arbace_box_ref_BANG__A", Source: "box.ae"})

func init() { i := A_arbace_box_ref_BANG__A_class.Info(); i.IsInstance = A_arbace_box_ref_BANG__A_InstanceOf; i.Init = A_arbace_box_ref_BANG__A_Init; i.Table = A_arbace_box_ref_BANG__A_members; jrt.RegisterGoType(A_arbace_box_ref_BANG__A_class, reflect.TypeFor[A_arbace_box_ref_BANG__A]()) }

func A_arbace_box_ref_BANG__answer_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_ref_BANG__answer_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_box_ref_BANG__answer_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_ref_BANG__answer_A_New()}; return nil }

func A_arbace_box_ref_BANG__answer_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_ref_BANG__answer_A_fn_class)}; return nil }

var A_arbace_box_ref_BANG__answer_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_ref_BANG__answer_A_invoke, New: A_arbace_box_ref_BANG__answer_A_new, Get: A_arbace_box_ref_BANG__answer_A_get}

var A_arbace_box_ref_BANG__answer_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$ref_BANG__answer", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_box_A_class, Simple: "ref_BANG__answer", Go: "arbace/aot_arbace_box.A_arbace_box_ref_BANG__answer_A", Source: "box.ae"})

func init() { i := A_arbace_box_ref_BANG__answer_A_class.Info(); i.IsInstance = A_arbace_box_ref_BANG__answer_A_InstanceOf; i.Init = A_arbace_box_ref_BANG__answer_A_Init; i.Table = A_arbace_box_ref_BANG__answer_A_members; jrt.RegisterGoType(A_arbace_box_ref_BANG__answer_A_class, reflect.TypeFor[A_arbace_box_ref_BANG__answer_A]()) }

func A_arbace_box_request_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_request_text_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_request_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_request_text_A_New()}; return nil }

func A_arbace_box_request_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_request_text_A_fn_class)}; return nil }

var A_arbace_box_request_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_request_text_A_invoke, New: A_arbace_box_request_text_A_new, Get: A_arbace_box_request_text_A_get}

var A_arbace_box_request_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$request_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "request_text", Go: "arbace/aot_arbace_box.A_arbace_box_request_text_A", Source: "box.ae"})

func init() { i := A_arbace_box_request_text_A_class.Info(); i.IsInstance = A_arbace_box_request_text_A_InstanceOf; i.Init = A_arbace_box_request_text_A_Init; i.Table = A_arbace_box_request_text_A_members; jrt.RegisterGoType(A_arbace_box_request_text_A_class, reflect.TypeFor[A_arbace_box_request_text_A]()) }

func A_arbace_box_request_text_iter__533000096__533000100_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_request_text_iter__533000096__533000100_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_request_text_iter__533000096__533000100_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_request_text_iter__533000096__533000100_A_New()}; return nil }

func A_arbace_box_request_text_iter__533000096__533000100_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_request_text_iter__533000096__533000100_A_fn_class)}; return nil }

var A_arbace_box_request_text_iter__533000096__533000100_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_request_text_iter__533000096__533000100_A_invoke, New: A_arbace_box_request_text_iter__533000096__533000100_A_new, Get: A_arbace_box_request_text_iter__533000096__533000100_A_get}

var A_arbace_box_request_text_iter__533000096__533000100_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$request_text$iter__533000096__533000100", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_request_text_A_class, Simple: "iter__533000096__533000100", Go: "arbace/aot_arbace_box.A_arbace_box_request_text_iter__533000096__533000100_A", Source: "box.ae"})

func init() { i := A_arbace_box_request_text_iter__533000096__533000100_A_class.Info(); i.IsInstance = A_arbace_box_request_text_iter__533000096__533000100_A_InstanceOf; i.Init = A_arbace_box_request_text_iter__533000096__533000100_A_Init; i.Table = A_arbace_box_request_text_iter__533000096__533000100_A_members; jrt.RegisterGoType(A_arbace_box_request_text_iter__533000096__533000100_A_class, reflect.TypeFor[A_arbace_box_request_text_iter__533000096__533000100_A]()) }

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_fn_class)}; return nil }

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_invoke, New: A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_new, Get: A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_get}

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$request_text$iter__533000096__533000100$fn__533000101", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_request_text_iter__533000096__533000100_A_class, Simple: "fn__533000101", Go: "arbace/aot_arbace_box.A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A", Source: "box.ae"})

func init() { i := A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_class.Info(); i.IsInstance = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_InstanceOf; i.Init = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_Init; i.Table = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_members; jrt.RegisterGoType(A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_class, reflect.TypeFor[A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A]()) }

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_fn_class)}; return nil }

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_invoke, New: A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_new, Get: A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_get}

var A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$request_text$iter__533000096__533000100$fn__533000101$fn__533000102", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_A_class, Simple: "fn__533000102", Go: "arbace/aot_arbace_box.A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A", Source: "box.ae"})

func init() { i := A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_class.Info(); i.IsInstance = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_InstanceOf; i.Init = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_Init; i.Table = A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_members; jrt.RegisterGoType(A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A_class, reflect.TypeFor[A_arbace_box_request_text_iter__533000096__533000100_fn__533000101_fn__533000102_A]()) }

func A_arbace_box_request_text_v__533000094_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_request_text_v__533000094_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_request_text_v__533000094_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_request_text_v__533000094_A_New()}; return nil }

func A_arbace_box_request_text_v__533000094_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_request_text_v__533000094_A_fn_class)}; return nil }

var A_arbace_box_request_text_v__533000094_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_request_text_v__533000094_A_invoke, New: A_arbace_box_request_text_v__533000094_A_new, Get: A_arbace_box_request_text_v__533000094_A_get}

var A_arbace_box_request_text_v__533000094_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$request_text$v__533000094", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_request_text_A_class, Simple: "v__533000094", Go: "arbace/aot_arbace_box.A_arbace_box_request_text_v__533000094_A", Source: "box.ae"})

func init() { i := A_arbace_box_request_text_v__533000094_A_class.Info(); i.IsInstance = A_arbace_box_request_text_v__533000094_A_InstanceOf; i.Init = A_arbace_box_request_text_v__533000094_A_Init; i.Table = A_arbace_box_request_text_v__533000094_A_members; jrt.RegisterGoType(A_arbace_box_request_text_v__533000094_A_class, reflect.TypeFor[A_arbace_box_request_text_v__533000094_A]()) }

func A_arbace_box_result_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_result_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_result_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_result_A_New()}; return nil }

func A_arbace_box_result_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_result_A_fn_class)}; return nil }

var A_arbace_box_result_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_result_A_invoke, New: A_arbace_box_result_A_new, Get: A_arbace_box_result_A_get}

var A_arbace_box_result_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$result", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "result", Go: "arbace/aot_arbace_box.A_arbace_box_result_A", Source: "box.ae"})

func init() { i := A_arbace_box_result_A_class.Info(); i.IsInstance = A_arbace_box_result_A_InstanceOf; i.Init = A_arbace_box_result_A_Init; i.Table = A_arbace_box_result_A_members; jrt.RegisterGoType(A_arbace_box_result_A_class, reflect.TypeFor[A_arbace_box_result_A]()) }

func A_arbace_box_run_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_run_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_run_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_run_A_New()}; return nil }

func A_arbace_box_run_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_run_A_fn_class)}; return nil }

var A_arbace_box_run_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_run_A_invoke, New: A_arbace_box_run_A_new, Get: A_arbace_box_run_A_get}

var A_arbace_box_run_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$run", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "run", Go: "arbace/aot_arbace_box.A_arbace_box_run_A", Source: "box.ae"})

func init() { i := A_arbace_box_run_A_class.Info(); i.IsInstance = A_arbace_box_run_A_InstanceOf; i.Init = A_arbace_box_run_A_Init; i.Table = A_arbace_box_run_A_members; jrt.RegisterGoType(A_arbace_box_run_A_class, reflect.TypeFor[A_arbace_box_run_A]()) }

func A_arbace_box_save_fs_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_save_fs_BANG__A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_box_save_fs_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_save_fs_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_save_fs_BANG__A_New()}; return nil }

func A_arbace_box_save_fs_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_save_fs_BANG__A_fn_class)}; return nil }

var A_arbace_box_save_fs_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_save_fs_BANG__A_invoke, New: A_arbace_box_save_fs_BANG__A_new, Get: A_arbace_box_save_fs_BANG__A_get}

var A_arbace_box_save_fs_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$save_fs_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "save_fs_BANG_", Go: "arbace/aot_arbace_box.A_arbace_box_save_fs_BANG__A", Source: "box.ae"})

func init() { i := A_arbace_box_save_fs_BANG__A_class.Info(); i.IsInstance = A_arbace_box_save_fs_BANG__A_InstanceOf; i.Init = A_arbace_box_save_fs_BANG__A_Init; i.Table = A_arbace_box_save_fs_BANG__A_members; jrt.RegisterGoType(A_arbace_box_save_fs_BANG__A_class, reflect.TypeFor[A_arbace_box_save_fs_BANG__A]()) }

func A_arbace_box_size_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_size_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_size_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_size_A_New()}; return nil }

func A_arbace_box_size_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_size_A_fn_class)}; return nil }

var A_arbace_box_size_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_size_A_invoke, New: A_arbace_box_size_A_new, Get: A_arbace_box_size_A_get}

var A_arbace_box_size_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$size", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "size", Go: "arbace/aot_arbace_box.A_arbace_box_size_A", Source: "box.ae"})

func init() { i := A_arbace_box_size_A_class.Info(); i.IsInstance = A_arbace_box_size_A_InstanceOf; i.Init = A_arbace_box_size_A_Init; i.Table = A_arbace_box_size_A_members; jrt.RegisterGoType(A_arbace_box_size_A_class, reflect.TypeFor[A_arbace_box_size_A]()) }

func A_arbace_box_spawn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_spawn_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_spawn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_spawn_A_New()}; return nil }

func A_arbace_box_spawn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_spawn_A_fn_class)}; return nil }

var A_arbace_box_spawn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_spawn_A_invoke, New: A_arbace_box_spawn_A_new, Get: A_arbace_box_spawn_A_get}

var A_arbace_box_spawn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$spawn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "spawn", Go: "arbace/aot_arbace_box.A_arbace_box_spawn_A", Source: "box.ae"})

func init() { i := A_arbace_box_spawn_A_class.Info(); i.IsInstance = A_arbace_box_spawn_A_InstanceOf; i.Init = A_arbace_box_spawn_A_Init; i.Table = A_arbace_box_spawn_A_members; jrt.RegisterGoType(A_arbace_box_spawn_A_class, reflect.TypeFor[A_arbace_box_spawn_A]()) }

func A_arbace_box_spawn_wait_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_spawn_wait_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_spawn_wait_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_spawn_wait_A_New()}; return nil }

func A_arbace_box_spawn_wait_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_spawn_wait_A_fn_class)}; return nil }

var A_arbace_box_spawn_wait_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_spawn_wait_A_invoke, New: A_arbace_box_spawn_wait_A_new, Get: A_arbace_box_spawn_wait_A_get}

var A_arbace_box_spawn_wait_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$spawn_wait", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "spawn_wait", Go: "arbace/aot_arbace_box.A_arbace_box_spawn_wait_A", Source: "box.ae"})

func init() { i := A_arbace_box_spawn_wait_A_class.Info(); i.IsInstance = A_arbace_box_spawn_wait_A_InstanceOf; i.Init = A_arbace_box_spawn_wait_A_Init; i.Table = A_arbace_box_spawn_wait_A_members; jrt.RegisterGoType(A_arbace_box_spawn_wait_A_class, reflect.TypeFor[A_arbace_box_spawn_wait_A]()) }

func A_arbace_box_store_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_store_QMARK__A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_store_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_store_QMARK__A_New()}; return nil }

func A_arbace_box_store_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_store_QMARK__A_fn_class)}; return nil }

var A_arbace_box_store_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_store_QMARK__A_invoke, New: A_arbace_box_store_QMARK__A_new, Get: A_arbace_box_store_QMARK__A_get}

var A_arbace_box_store_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$store_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_A_class, Simple: "store_QMARK_", Go: "arbace/aot_arbace_box.A_arbace_box_store_QMARK__A", Source: "box.ae"})

func init() { i := A_arbace_box_store_QMARK__A_class.Info(); i.IsInstance = A_arbace_box_store_QMARK__A_InstanceOf; i.Init = A_arbace_box_store_QMARK__A_Init; i.Table = A_arbace_box_store_QMARK__A_members; jrt.RegisterGoType(A_arbace_box_store_QMARK__A_class, reflect.TypeFor[A_arbace_box_store_QMARK__A]()) }

func A_arbace_box_tree_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_tree_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_tree_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_tree_A_New()}; return nil }

func A_arbace_box_tree_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_tree_A_fn_class)}; return nil }

var A_arbace_box_tree_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_tree_A_invoke, New: A_arbace_box_tree_A_new, Get: A_arbace_box_tree_A_get}

var A_arbace_box_tree_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$tree", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "tree", Go: "arbace/aot_arbace_box.A_arbace_box_tree_A", Source: "box.ae"})

func init() { i := A_arbace_box_tree_A_class.Info(); i.IsInstance = A_arbace_box_tree_A_InstanceOf; i.Init = A_arbace_box_tree_A_Init; i.Table = A_arbace_box_tree_A_members; jrt.RegisterGoType(A_arbace_box_tree_A_class, reflect.TypeFor[A_arbace_box_tree_A]()) }

func A_arbace_box_tree_get_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_tree_get_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_tree_get_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_tree_get_A_New()}; return nil }

func A_arbace_box_tree_get_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_tree_get_A_fn_class)}; return nil }

var A_arbace_box_tree_get_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_tree_get_A_invoke, New: A_arbace_box_tree_get_A_new, Get: A_arbace_box_tree_get_A_get}

var A_arbace_box_tree_get_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$tree_get", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_A_class, Simple: "tree_get", Go: "arbace/aot_arbace_box.A_arbace_box_tree_get_A", Source: "box.ae"})

func init() { i := A_arbace_box_tree_get_A_class.Info(); i.IsInstance = A_arbace_box_tree_get_A_InstanceOf; i.Init = A_arbace_box_tree_get_A_Init; i.Table = A_arbace_box_tree_get_A_members; jrt.RegisterGoType(A_arbace_box_tree_get_A_class, reflect.TypeFor[A_arbace_box_tree_get_A]()) }

func A_arbace_box_tree_get_fn__533000088_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_tree_get_fn__533000088_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_tree_get_fn__533000088_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_tree_get_fn__533000088_A_New()}; return nil }

func A_arbace_box_tree_get_fn__533000088_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_tree_get_fn__533000088_A_fn_class)}; return nil }

var A_arbace_box_tree_get_fn__533000088_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_tree_get_fn__533000088_A_invoke, New: A_arbace_box_tree_get_fn__533000088_A_new, Get: A_arbace_box_tree_get_fn__533000088_A_get}

var A_arbace_box_tree_get_fn__533000088_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$tree_get$fn__533000088", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_tree_get_A_class, Simple: "fn__533000088", Go: "arbace/aot_arbace_box.A_arbace_box_tree_get_fn__533000088_A", Source: "box.ae"})

func init() { i := A_arbace_box_tree_get_fn__533000088_A_class.Info(); i.IsInstance = A_arbace_box_tree_get_fn__533000088_A_InstanceOf; i.Init = A_arbace_box_tree_get_fn__533000088_A_Init; i.Table = A_arbace_box_tree_get_fn__533000088_A_members; jrt.RegisterGoType(A_arbace_box_tree_get_fn__533000088_A_class, reflect.TypeFor[A_arbace_box_tree_get_fn__533000088_A]()) }

func A_arbace_box_tree_name_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_tree_name_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_tree_name_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_tree_name_QMARK__A_New()}; return nil }

func A_arbace_box_tree_name_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_tree_name_QMARK__A_fn_class)}; return nil }

var A_arbace_box_tree_name_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_tree_name_QMARK__A_invoke, New: A_arbace_box_tree_name_QMARK__A_new, Get: A_arbace_box_tree_name_QMARK__A_get}

var A_arbace_box_tree_name_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$tree_name_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "tree_name_QMARK_", Go: "arbace/aot_arbace_box.A_arbace_box_tree_name_QMARK__A", Source: "box.ae"})

func init() { i := A_arbace_box_tree_name_QMARK__A_class.Info(); i.IsInstance = A_arbace_box_tree_name_QMARK__A_InstanceOf; i.Init = A_arbace_box_tree_name_QMARK__A_Init; i.Table = A_arbace_box_tree_name_QMARK__A_members; jrt.RegisterGoType(A_arbace_box_tree_name_QMARK__A_class, reflect.TypeFor[A_arbace_box_tree_name_QMARK__A]()) }

func A_arbace_box_tree_name_QMARK__fn__533000038_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_tree_name_QMARK__fn__533000038_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_tree_name_QMARK__fn__533000038_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_tree_name_QMARK__fn__533000038_A_New()}; return nil }

func A_arbace_box_tree_name_QMARK__fn__533000038_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_tree_name_QMARK__fn__533000038_A_fn_class)}; return nil }

var A_arbace_box_tree_name_QMARK__fn__533000038_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_tree_name_QMARK__fn__533000038_A_invoke, New: A_arbace_box_tree_name_QMARK__fn__533000038_A_new, Get: A_arbace_box_tree_name_QMARK__fn__533000038_A_get}

var A_arbace_box_tree_name_QMARK__fn__533000038_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$tree_name_QMARK_$fn__533000038", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_tree_name_QMARK__A_class, Simple: "fn__533000038", Go: "arbace/aot_arbace_box.A_arbace_box_tree_name_QMARK__fn__533000038_A", Source: "box.ae"})

func init() { i := A_arbace_box_tree_name_QMARK__fn__533000038_A_class.Info(); i.IsInstance = A_arbace_box_tree_name_QMARK__fn__533000038_A_InstanceOf; i.Init = A_arbace_box_tree_name_QMARK__fn__533000038_A_Init; i.Table = A_arbace_box_tree_name_QMARK__fn__533000038_A_members; jrt.RegisterGoType(A_arbace_box_tree_name_QMARK__fn__533000038_A_class, reflect.TypeFor[A_arbace_box_tree_name_QMARK__fn__533000038_A]()) }

func A_arbace_box_tree_text_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_tree_text_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_tree_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_tree_text_A_New()}; return nil }

func A_arbace_box_tree_text_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_tree_text_A_fn_class)}; return nil }

var A_arbace_box_tree_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_tree_text_A_invoke, New: A_arbace_box_tree_text_A_new, Get: A_arbace_box_tree_text_A_get}

var A_arbace_box_tree_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$tree_text", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_A_class, Simple: "tree_text", Go: "arbace/aot_arbace_box.A_arbace_box_tree_text_A", Source: "box.ae"})

func init() { i := A_arbace_box_tree_text_A_class.Info(); i.IsInstance = A_arbace_box_tree_text_A_InstanceOf; i.Init = A_arbace_box_tree_text_A_Init; i.Table = A_arbace_box_tree_text_A_members; jrt.RegisterGoType(A_arbace_box_tree_text_A_class, reflect.TypeFor[A_arbace_box_tree_text_A]()) }

func A_arbace_box_tree_text_fn__533000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_tree_text_fn__533000042_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_tree_text_fn__533000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_tree_text_fn__533000042_A_New()}; return nil }

func A_arbace_box_tree_text_fn__533000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_tree_text_fn__533000042_A_fn_class)}; return nil }

var A_arbace_box_tree_text_fn__533000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_tree_text_fn__533000042_A_invoke, New: A_arbace_box_tree_text_fn__533000042_A_new, Get: A_arbace_box_tree_text_fn__533000042_A_get}

var A_arbace_box_tree_text_fn__533000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$tree_text$fn__533000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_tree_text_A_class, Simple: "fn__533000042", Go: "arbace/aot_arbace_box.A_arbace_box_tree_text_fn__533000042_A", Source: "box.ae"})

func init() { i := A_arbace_box_tree_text_fn__533000042_A_class.Info(); i.IsInstance = A_arbace_box_tree_text_fn__533000042_A_InstanceOf; i.Init = A_arbace_box_tree_text_fn__533000042_A_Init; i.Table = A_arbace_box_tree_text_fn__533000042_A_members; jrt.RegisterGoType(A_arbace_box_tree_text_fn__533000042_A_class, reflect.TypeFor[A_arbace_box_tree_text_fn__533000042_A]()) }

func A_arbace_box_utf8_compare_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_utf8_compare_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_box_utf8_compare_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_utf8_compare_A_New()}; return nil }

func A_arbace_box_utf8_compare_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_utf8_compare_A_fn_class)}; return nil }

var A_arbace_box_utf8_compare_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_utf8_compare_A_invoke, New: A_arbace_box_utf8_compare_A_new, Get: A_arbace_box_utf8_compare_A_get}

var A_arbace_box_utf8_compare_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box$utf8_compare", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_box_A_class, Simple: "utf8_compare", Go: "arbace/aot_arbace_box.A_arbace_box_utf8_compare_A", Source: "box.ae"})

func init() { i := A_arbace_box_utf8_compare_A_class.Info(); i.IsInstance = A_arbace_box_utf8_compare_A_InstanceOf; i.Init = A_arbace_box_utf8_compare_A_Init; i.Table = A_arbace_box_utf8_compare_A_members; jrt.RegisterGoType(A_arbace_box_utf8_compare_A_class, reflect.TypeFor[A_arbace_box_utf8_compare_A]()) }

func A_arbace_box__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_box__init_A_Load__O(); case 1: return A_arbace_box__init_A_Unit0__O(); case 2: return A_arbace_box__init_A_Unit1__O(); case 3: return A_arbace_box__init_A_Unit10__O(); case 4: return A_arbace_box__init_A_Unit11__O(); case 5: return A_arbace_box__init_A_Unit12__O(); case 6: return A_arbace_box__init_A_Unit13__O(); case 7: return A_arbace_box__init_A_Unit14__O(); case 8: return A_arbace_box__init_A_Unit15__O(); case 9: return A_arbace_box__init_A_Unit16__O(); case 10: return A_arbace_box__init_A_Unit17__O(); case 11: return A_arbace_box__init_A_Unit18__O(); case 12: return A_arbace_box__init_A_Unit19__O(); case 13: return A_arbace_box__init_A_Unit2__O(); case 14: return A_arbace_box__init_A_Unit20__O(); case 15: return A_arbace_box__init_A_Unit21__O(); case 16: return A_arbace_box__init_A_Unit22__O(); case 17: return A_arbace_box__init_A_Unit23__O(); case 18: return A_arbace_box__init_A_Unit24__O(); case 19: return A_arbace_box__init_A_Unit25__O(); case 20: return A_arbace_box__init_A_Unit26__O(); case 21: return A_arbace_box__init_A_Unit27__O(); case 22: return A_arbace_box__init_A_Unit28__O(); case 23: return A_arbace_box__init_A_Unit29__O(); case 24: return A_arbace_box__init_A_Unit3__O(); case 25: return A_arbace_box__init_A_Unit30__O(); case 26: return A_arbace_box__init_A_Unit31__O(); case 27: return A_arbace_box__init_A_Unit32__O(); case 28: return A_arbace_box__init_A_Unit33__O(); case 29: return A_arbace_box__init_A_Unit34__O(); case 30: return A_arbace_box__init_A_Unit35__O(); case 31: return A_arbace_box__init_A_Unit36__O(); case 32: return A_arbace_box__init_A_Unit37__O(); case 33: return A_arbace_box__init_A_Unit4__O(); case 34: return A_arbace_box__init_A_Unit5__O(); case 35: return A_arbace_box__init_A_Unit6__O(); case 36: return A_arbace_box__init_A_Unit7__O(); case 37: return A_arbace_box__init_A_Unit8__O(); case 38: return A_arbace_box__init_A_Unit9__O()}; return nil }

func A_arbace_box__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box__init_A_New()}; return nil }

var A_arbace_box__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_box__init_A_invoke, New: A_arbace_box__init_A_new}

var A_arbace_box__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box.A_arbace_box__init_A", Source: "box.ae"})

func init() { i := A_arbace_box__init_A_class.Info(); i.IsInstance = A_arbace_box__init_A_InstanceOf; i.Init = A_arbace_box__init_A_Init; i.Table = A_arbace_box__init_A_members; jrt.RegisterGoType(A_arbace_box__init_A_class, reflect.TypeFor[A_arbace_box__init_A]()) }
